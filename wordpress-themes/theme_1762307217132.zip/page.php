<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="site-main container section">
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <?php get_template_part('template-parts/hero/hero-title-only'); ?>
            <div class="page-content">
                <?php get_template_part('template-parts/content/breadcrumbs'); ?>
                <div class="page-body">
                    <?php the_content(); ?>
                </div>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</main>
<?php get_sidebar(); ?>
<?php
get_footer();
?>