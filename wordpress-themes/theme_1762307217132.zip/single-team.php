<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="container section">
    <?php get_template_part('template-parts/content/breadcrumbs'); ?>
    <?php while (have_posts()) : the_post(); ?>
        <article <?php post_class('team-single'); ?>>
            <header class="post-header">
                <h1><?php the_title(); ?></h1>
                <h2 class="team-role">
                    <?php echo esc_html(get_post_meta(get_the_ID(), 'aurion_team_role', true)); ?>
                </h2>
            </header>
            <div class="split">
                <div data-aos="fade-right">
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="team-photo">
                            <?php the_post_thumbnail('team-photo'); ?>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <h3><?php esc_html_e('Connect', 'aurion-energy'); ?></h3>
                        <ul class="list-contact">
                            <?php
                            $email = get_post_meta(get_the_ID(), 'aurion_team_email', true);
                            if ($email) :
                                ?>
                                <li><strong><?php esc_html_e('Email:', 'aurion-energy'); ?></strong> <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></li>
                            <?php endif; ?>
                            <?php
                            $phone = get_post_meta(get_the_ID(), 'aurion_team_phone', true);
                            if ($phone) :
                                ?>
                                <li><strong><?php esc_html_e('Phone:', 'aurion-energy'); ?></strong> <a href="tel:<?php echo esc_attr(aurion_sanitize_phone($phone)); ?>"><?php echo esc_html($phone); ?></a></li>
                            <?php endif; ?>
                            <?php
                            $linkedin = get_post_meta(get_the_ID(), 'aurion_team_linkedin', true);
                            if ($linkedin) :
                                ?>
                                <li><a class="button button--outline" href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(sprintf(__('Connect with %s on LinkedIn', 'aurion-energy'), get_the_title())); ?></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div data-aos="fade-left">
                    <div class="post-content">
                        <?php the_content(); ?>
                    </div>
                    <?php
                    $expertise_terms = get_the_terms(get_the_ID(), 'expertise');
                    if ($expertise_terms && !is_wp_error($expertise_terms)) :
                        ?>
                        <section>
                            <h3><?php esc_html_e('Expertise Areas', 'aurion-energy'); ?></h3>
                            <div class="post-tags">
                                <?php foreach ($expertise_terms as $term) : ?>
                                    <span><?php echo esc_html($term->name); ?></span>
                                <?php endforeach; ?>
                            </div>
                        </section>
                    <?php endif; ?>
                </div>
            </div>
        </article>
    <?php endwhile; ?>

    <section class="section section--light">
        <div class="container">
            <h2><?php esc_html_e('Meet Other Leaders', 'aurion-energy'); ?></h2>
            <div class="team-grid">
                <?php
                $related_team = new WP_Query(array(
                    'post_type' => 'team',
                    'posts_per_page' => 3,
                    'post__not_in' => array(get_the_ID())
                ));
                if ($related_team->have_posts()) :
                    while ($related_team->have_posts()) :
                        $related_team->the_post();
                        get_template_part('template-parts/content/card-team');
                    endwhile;
                    wp_reset_postdata();
                else :
                    ?>
                    <p><?php esc_html_e('Additional team profiles are coming soon.', 'aurion-energy'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>
</main>
<?php
get_footer();
?>