<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="container section">
    <section class="error-404">
        <h1 class="error-404__title">404</h1>
        <h2><?php esc_html_e('Page Not Found', 'aurion-energy'); ?></h2>
        <p><?php esc_html_e('The page you are looking for might have been moved or is no longer available. Try one of the links below or search for what you need.', 'aurion-energy'); ?></p>
        <?php get_search_form(); ?>
        <div class="grid grid--two" style="margin-top: 32px;">
            <a class="button" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Go to Homepage', 'aurion-energy'); ?></a>
            <a class="button button--outline" href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact Aurion', 'aurion-energy'); ?></a>
        </div>
    </section>
</main>
<?php
get_footer();
?>