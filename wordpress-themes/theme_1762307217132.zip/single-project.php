<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="container section">
    <?php get_template_part('template-parts/content/breadcrumbs'); ?>
    <?php while (have_posts()) : the_post(); ?>
        <article <?php post_class('project-single'); ?>>
            <header class="post-header">
                <h1><?php the_title(); ?></h1>
                <div class="post-meta">
                    <span><?php echo esc_html(get_the_date()); ?></span>
                    <?php
                    $terms = get_the_terms(get_the_ID(), 'project_type');
                    if ($terms && !is_wp_error($terms)) {
                        $term_names = wp_list_pluck($terms, 'name');
                        echo '<span>' . esc_html(implode(', ', $term_names)) . '</span>';
                    }
                    ?>
                </div>
            </header>
            <?php if (has_post_thumbnail()) : ?>
                <div class="project-featured-image" data-aos="fade-up">
                    <?php the_post_thumbnail('hero-banner'); ?>
                </div>
            <?php endif; ?>
            <div class="post-content" data-aos="fade-up">
                <?php the_content(); ?>
            </div>
            <?php
            $outcomes = get_post_meta(get_the_ID(), 'aurion_project_outcomes', true);
            if (!empty($outcomes) && is_array($outcomes)) :
                ?>
                <section class="section section--light">
                    <h2><?php esc_html_e('Key Outcomes', 'aurion-energy'); ?></h2>
                    <ul class="list-check">
                        <?php foreach ($outcomes as $outcome) : ?>
                            <li><?php echo esc_html($outcome); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </section>
            <?php endif; ?>

            <?php
            $technologies = get_post_meta(get_the_ID(), 'aurion_project_technologies', true);
            if (!empty($technologies)) :
                ?>
                <section class="section">
                    <h2><?php esc_html_e('Technologies & Expertise', 'aurion-energy'); ?></h2>
                    <p><?php echo esc_html($technologies); ?></p>
                </section>
            <?php endif; ?>

            <section class="section section--light">
                <h2><?php esc_html_e('Related Projects', 'aurion-energy'); ?></h2>
                <div class="featured-projects__grid">
                    <?php
                    $related = new WP_Query(array(
                        'post_type' => 'project',
                        'posts_per_page' => 3,
                        'post__not_in' => array(get_the_ID()),
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'project_type',
                                'field' => 'slug',
                                'terms' => $terms ? wp_list_pluck($terms, 'slug') : array()
                            )
                        )
                    ));
                    if ($related->have_posts()) :
                        while ($related->have_posts()) :
                            $related->the_post();
                            get_template_part('template-parts/content/card-project');
                        endwhile;
                        wp_reset_postdata();
                    else :
                        ?>
                        <p><?php esc_html_e('More projects will be published soon.', 'aurion-energy'); ?></p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="section container">
                <div class="card">
                    <h2><?php esc_html_e('Interested in a Similar Project?', 'aurion-energy'); ?></h2>
                    <p><?php esc_html_e('Connect with our industrial engineering and consulting specialists to explore how Aurion can support your next initiative.', 'aurion-energy'); ?></p>
                    <a class="button" href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact Aurion Energy Advisory', 'aurion-energy'); ?></a>
                </div>
            </section>
        </article>
    <?php endwhile; ?>
</main>
<?php
get_footer();
?>