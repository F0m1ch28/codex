<?php
defined('ABSPATH') || exit;
?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-widgets">
            <?php
            for ($i = 1; $i <= 4; $i++) {
                if (is_active_sidebar('footer-' . $i)) {
                    dynamic_sidebar('footer-' . $i);
                }
            }
            ?>
        </div>
        <div class="footer-bottom">
            <div class="footer-bottom__left">
                <?php echo esc_html(aurion_get_theme_mod('footer_copyright', sprintf(__('© %s Aurion Energy Advisory. All rights reserved.', 'aurion-energy'), date_i18n('Y')))); ?>
            </div>
            <div class="footer-bottom__middle">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer-1',
                    'container' => false,
                    'menu_class' => 'footer-menu',
                    'fallback_cb' => false
                ));
                ?>
            </div>
            <div class="footer-bottom__right">
                <?php get_template_part('template-parts/footer/footer-social-links'); ?>
            </div>
        </div>
    </div>
</footer>
<a href="#top" id="back-to-top" aria-label="<?php esc_attr_e('Back to top', 'aurion-energy'); ?>">
    <span class="dashicons dashicons-arrow-up-alt2"></span>
</a>
<?php wp_footer(); ?>
</body>
</html>