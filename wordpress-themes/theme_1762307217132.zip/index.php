<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="site-main container section">
    <?php if (have_posts()) : ?>
        <header class="page-header">
            <?php if (is_home() && !is_front_page()) : ?>
                <h1 class="page-title"><?php single_post_title(); ?></h1>
            <?php endif; ?>
        </header>
        <div class="grid grid--three">
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class('post-card'); ?> data-aos="fade-up">
                    <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('blog-featured', array('class' => 'post-card__thumbnail')); ?>
                        </a>
                    <?php endif; ?>
                    <div class="post-card__meta">
                        <span><?php echo esc_html(get_the_date()); ?></span>
                        <span><?php echo esc_html(get_the_author()); ?></span>
                    </div>
                    <h3 class="post-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo esc_html(get_the_excerpt()); ?></p>
                    <a class="button button--outline" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'aurion-energy'); ?></a>
                </article>
            <?php endwhile; ?>
        </div>
        <?php aurion_pagination(); ?>
    <?php else : ?>
        <section class="no-results">
            <h2><?php esc_html_e('Nothing Found', 'aurion-energy'); ?></h2>
            <p><?php esc_html_e('It looks like nothing was found at this location. Try searching.', 'aurion-energy'); ?></p>
            <?php get_search_form(); ?>
        </section>
    <?php endif; ?>
</main>
<?php get_sidebar(); ?>
<?php
get_footer();
?>