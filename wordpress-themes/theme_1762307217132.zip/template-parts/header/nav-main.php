<?php
defined('ABSPATH') || exit;
wp_nav_menu(array(
    'theme_location' => 'primary',
    'container' => false,
    'menu_class' => 'menu',
    'fallback_cb' => '__return_false'
));
?>