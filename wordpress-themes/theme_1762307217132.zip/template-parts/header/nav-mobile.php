<?php
defined('ABSPATH') || exit;
wp_nav_menu(array(
    'theme_location' => 'primary',
    'container' => false,
    'menu_class' => 'menu menu--mobile',
    'fallback_cb' => '__return_false'
));
if (has_nav_menu('utility')) {
    wp_nav_menu(array(
        'theme_location' => 'utility',
        'container' => false,
        'menu_class' => 'menu menu--utility',
        'fallback_cb' => '__return_false'
    ));
}
?>
<div class="mobile-menu__actions">
    <a class="button" href="<?php echo esc_url(aurion_get_theme_mod('cta_link', home_url('/contact'))); ?>">
        <?php echo esc_html(aurion_get_theme_mod('cta_text', __('Partner with Aurion', 'aurion-energy'))); ?>
    </a>
</div>