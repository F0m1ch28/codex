<?php
defined('ABSPATH') || exit;
?>
<div class="footer-widget">
    <h3><?php esc_html_e('Contact Aurion Energy Advisory', 'aurion-energy'); ?></h3>
    <p><?php esc_html_e('460 Bay St, Toronto, ON M5H 2Y4, Canada', 'aurion-energy'); ?></p>
    <p><a href="tel:+14167924583"><?php esc_html_e('+1 (416) 792-4583', 'aurion-energy'); ?></a></p>
    <p><a href="mailto:<?php echo esc_attr(aurion_get_theme_mod('contact_email', 'info@aurionenergy.com')); ?>"><?php echo esc_html(aurion_get_theme_mod('contact_email', 'info@aurionenergy.com')); ?></a></p>
</div>