<?php
defined('ABSPATH') || exit;
$social_links = aurion_get_social_links();
if (!empty($social_links)) :
    ?>
    <div class="footer-social">
        <?php foreach ($social_links as $network => $link) :
            if (!empty($link['url'])) :
                ?>
                <a href="<?php echo esc_url($link['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($link['label']); ?>">
                    <span class="dashicons dashicons-<?php echo esc_attr($link['icon']); ?>"></span>
                </a>
            <?php endif;
        endforeach; ?>
    </div>
<?php endif; ?>