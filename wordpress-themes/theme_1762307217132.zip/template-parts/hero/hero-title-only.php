<?php
defined('ABSPATH') || exit;
$title = get_the_title();
$background_image = '';
if (has_post_thumbnail()) {
    $background_image = get_the_post_thumbnail_url(get_the_ID(), 'hero-banner');
}
if (empty($background_image)) {
    $background_image = get_template_directory_uri() . '/assets/images/placeholder-hero.jpg';
}
?>
<section class="hero hero--title-only" style="background-image: url('<?php echo esc_url($background_image); ?>');">
    <div class="container hero__content">
        <span class="hero__eyebrow"><?php esc_html_e('Aurion Energy Advisory', 'aurion-energy'); ?></span>
        <h1 class="hero__title"><?php echo esc_html($title); ?></h1>
    </div>
</section>