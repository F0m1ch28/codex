<?php
defined('ABSPATH') || exit;
$args = isset($args) ? $args : array();
$title = isset($args['title']) ? $args['title'] : get_the_title();
$description = isset($args['description']) ? $args['description'] : '';
$cta_text = isset($args['cta_text']) ? $args['cta_text'] : '';
$cta_link = isset($args['cta_link']) ? $args['cta_link'] : '';
$background_image = '';
if (has_post_thumbnail()) {
    $background_image = get_the_post_thumbnail_url(get_the_ID(), 'hero-banner');
}
if (empty($background_image)) {
    $background_image = get_template_directory_uri() . '/assets/images/placeholder-hero.jpg';
}
?>
<section class="hero" style="background-image: url('<?php echo esc_url($background_image); ?>');">
    <div class="container hero__content">
        <span class="hero__eyebrow"><?php esc_html_e('Aurion Energy Advisory', 'aurion-energy'); ?></span>
        <h1 class="hero__title"><?php echo esc_html($title); ?></h1>
        <?php if ($description) : ?>
            <p class="hero__description"><?php echo esc_html($description); ?></p>
        <?php endif; ?>
        <?php if ($cta_text && $cta_link) : ?>
            <a class="button" href="<?php echo esc_url($cta_link); ?>"><?php echo esc_html($cta_text); ?></a>
        <?php endif; ?>
    </div>
</section>