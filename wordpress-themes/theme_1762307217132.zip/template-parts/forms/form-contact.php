<?php
defined('ABSPATH') || exit;
$success = isset($_GET['form']) && 'success' === sanitize_text_field(wp_unslash($_GET['form']));
$error = isset($_GET['form']) && 'error' === sanitize_text_field(wp_unslash($_GET['form']));
?>
<div class="contact-form-wrapper">
    <h2><?php esc_html_e('Send Us a Message', 'aurion-energy'); ?></h2>
    <?php if ($success) : ?>
        <div class="contact-form__messages contact-form__messages--success">
            <?php esc_html_e('Thank you for reaching out. A member of our team will contact you shortly.', 'aurion-energy'); ?>
        </div>
    <?php elseif ($error) : ?>
        <div class="contact-form__messages contact-form__messages--error">
            <?php esc_html_e('There was a problem submitting your message. Please complete the required fields and try again.', 'aurion-energy'); ?>
        </div>
    <?php endif; ?>
    <form class="contact-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" novalidate>
        <?php wp_nonce_field('aurion_contact_form', 'aurion_contact_nonce'); ?>
        <input type="hidden" name="action" value="aurion_contact_form">
        <div class="contact-form__row">
            <label for="contact-name"><?php esc_html_e('Name', 'aurion-energy'); ?> <span>*</span>
                <input id="contact-name" name="name" type="text" required aria-required="true">
            </label>
            <label for="contact-email"><?php esc_html_e('Email', 'aurion-energy'); ?> <span>*</span>
                <input id="contact-email" name="email" type="email" required aria-required="true">
            </label>
        </div>
        <div class="contact-form__row">
            <label for="contact-phone"><?php esc_html_e('Phone', 'aurion-energy'); ?>
                <input id="contact-phone" name="phone" type="text">
            </label>
            <label for="contact-company"><?php esc_html_e('Company', 'aurion-energy'); ?>
                <input id="contact-company" name="company" type="text">
            </label>
        </div>
        <label for="contact-subject"><?php esc_html_e('Subject', 'aurion-energy'); ?>
            <input id="contact-subject" name="subject" type="text">
        </label>
        <label for="contact-message"><?php esc_html_e('Message', 'aurion-energy'); ?> <span>*</span>
            <textarea id="contact-message" name="message" required aria-required="true"></textarea>
        </label>
        <button class="button" type="submit"><?php esc_html_e('Send Message', 'aurion-energy'); ?></button>
    </form>
</div>