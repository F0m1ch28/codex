<?php
defined('ABSPATH') || exit;
?>
<section class="section section--light">
    <div class="container" data-aos="fade-up">
        <div class="card">
            <h2><?php esc_html_e('Partner with Aurion Energy Advisory', 'aurion-energy'); ?></h2>
            <p><?php esc_html_e('Ready to advance your next energy consulting, oilfield research, or industrial engineering project in Canada? Our experts are prepared to support every phase.', 'aurion-energy'); ?></p>
            <a class="button" href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Start the Conversation', 'aurion-energy'); ?></a>
        </div>
    </div>
</section>