<?php
defined('ABSPATH') || exit;
$args = isset($args) ? $args : array();
$title = isset($args['title']) ? $args['title'] : '';
$description = isset($args['description']) ? $args['description'] : '';
$icon = isset($args['icon']) ? $args['icon'] : 'dashicons-admin-tools';
?>
<article class="card card--service" data-aos="fade-up">
    <div class="card__icon">
        <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
    </div>
    <h3 class="card__title"><?php echo esc_html($title); ?></h3>
    <p class="card__text"><?php echo esc_html($description); ?></p>
</article>