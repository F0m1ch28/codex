<?php
defined('ABSPATH') || exit;
?>
<article <?php post_class('team-card'); ?> data-aos="fade-up">
    <div class="team-card__photo">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('team-photo'); ?>
        <?php else : ?>
            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder-team.jpg'); ?>" alt="<?php the_title_attribute(); ?>">
        <?php endif; ?>
    </div>
    <h3 class="team-card__name"><?php the_title(); ?></h3>
    <p class="team-card__role"><?php echo esc_html(get_post_meta(get_the_ID(), 'aurion_team_role', true)); ?></p>
    <p class="team-card__bio"><?php echo esc_html(get_the_excerpt()); ?></p>
    <?php
    $linkedin = get_post_meta(get_the_ID(), 'aurion_team_linkedin', true);
    if ($linkedin) :
        ?>
        <div class="team-card__social">
            <a href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer">
                <span class="dashicons dashicons-linkedin"></span>
                <span class="screen-reader-text"><?php esc_html_e('LinkedIn profile', 'aurion-energy'); ?></span>
            </a>
        </div>
    <?php endif; ?>
    <a class="button button--outline" href="<?php the_permalink(); ?>"><?php esc_html_e('View Profile', 'aurion-energy'); ?></a>
</article>