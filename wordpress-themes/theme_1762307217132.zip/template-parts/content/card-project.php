<?php
defined('ABSPATH') || exit;
?>
<article <?php post_class('project-card'); ?> data-aos="fade-up">
    <?php if (has_post_thumbnail()) : ?>
        <div class="project-card__media">
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail('project-thumbnail'); ?>
            </a>
        </div>
    <?php endif; ?>
    <div class="project-card__body">
        <div class="project-card__meta">
            <?php echo esc_html(get_the_date()); ?>
        </div>
        <h3 class="project-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <p class="project-card__excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
        <div class="project-card__actions">
            <a href="<?php the_permalink(); ?>"><?php esc_html_e('View Case Study', 'aurion-energy'); ?></a>
        </div>
    </div>
</article>