<?php
defined('ABSPATH') || exit;
$role = get_post_meta(get_the_ID(), 'aurion_testimonial_role', true);
?>
<article <?php post_class('card card--testimonial'); ?> data-aos="fade-up">
    <h3><?php the_title(); ?></h3>
    <p><?php echo esc_html(get_the_content()); ?></p>
    <?php if ($role) : ?>
        <p><strong><?php echo esc_html($role); ?></strong></p>
    <?php endif; ?>
</article>