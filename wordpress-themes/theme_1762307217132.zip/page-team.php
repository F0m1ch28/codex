<?php
defined('ABSPATH') || exit;
/*
Template Name: Team Archive
*/
get_header();
?>
<main id="primary">
    <?php get_template_part('template-parts/hero/hero-title-only'); ?>
    <section class="section container">
        <?php get_template_part('template-parts/content/breadcrumbs'); ?>
        <div class="team-grid">
            <?php
            $team_members = new WP_Query(array(
                'post_type' => 'team',
                'posts_per_page' => 12,
                'paged' => get_query_var('paged') ? get_query_var('paged') : 1
            ));
            if ($team_members->have_posts()) :
                while ($team_members->have_posts()) :
                    $team_members->the_post();
                    get_template_part('template-parts/content/card-team');
                endwhile;
                aurion_pagination($team_members);
                wp_reset_postdata();
            else :
                ?>
                <p><?php esc_html_e('Team profiles will be available soon.', 'aurion-energy'); ?></p>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php
get_footer();
?>