<?php
defined('ABSPATH') || exit;

function aurion_theme_setup() {
    load_theme_textdomain('aurion-energy', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    add_editor_style('assets/css/main.css');
    add_theme_support('custom-logo', array(
        'height' => 80,
        'width' => 240,
        'flex-width' => true,
        'flex-height' => true
    ));

    register_nav_menus(array(
        'primary' => __('Primary Menu', 'aurion-energy'),
        'utility' => __('Utility Menu', 'aurion-energy'),
        'footer-1' => __('Footer Menu 1', 'aurion-energy'),
        'footer-2' => __('Footer Menu 2', 'aurion-energy')
    ));

    add_image_size('hero-banner', 1920, 600, true);
    add_image_size('project-thumbnail', 600, 400, true);
    add_image_size('team-photo', 400, 500, true);
    add_image_size('testimonial-avatar', 100, 100, true);
    add_image_size('blog-featured', 800, 450, true);
}
add_action('after_setup_theme', 'aurion_theme_setup');

function aurion_set_content_width() {
    $GLOBALS['content_width'] = 1280;
}
add_action('after_setup_theme', 'aurion_set_content_width', 0);

function aurion_enqueue_assets() {
    $theme_version = wp_get_theme()->get('Version');

    wp_enqueue_style('aurion-google-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@500;600;700&family=Inter:wght@400;500;600&display=swap', array(), null);
    wp_enqueue_style('aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css', array(), '2.3.4');
    wp_enqueue_style('aurion-style', get_stylesheet_uri(), array('aurion-google-fonts', 'aos'), $theme_version);

    wp_enqueue_script('aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.min.js', array(), '2.3.4', true);
    wp_enqueue_script('aurion-main', get_template_directory_uri() . '/assets/js/main.js', array(), $theme_version, true);
    wp_localize_script('aurion-main', 'aurionTheme', array(
        'ajaxUrl' => admin_url('admin-ajax.php')
    ));

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'aurion_enqueue_assets');

function aurion_register_sidebars() {
    register_sidebar(array(
        'name' => __('Primary Sidebar', 'aurion-energy'),
        'id' => 'sidebar-primary',
        'description' => __('Main sidebar for pages and posts', 'aurion-energy'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>'
    ));

    for ($i = 1; $i <= 4; $i++) {
        register_sidebar(array(
            'name' => sprintf(__('Footer Column %d', 'aurion-energy'), $i),
            'id' => 'footer-' . $i,
            'description' => sprintf(__('Footer widget area %d', 'aurion-energy'), $i),
            'before_widget' => '<section id="%1$s" class="footer-widget widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>'
        ));
    }
}
add_action('widgets_init', 'aurion_register_sidebars');

function aurion_register_custom_post_types() {
    $project_labels = array(
        'name' => __('Projects', 'aurion-energy'),
        'singular_name' => __('Project', 'aurion-energy'),
        'add_new' => __('Add New Project', 'aurion-energy'),
        'add_new_item' => __('Add New Project', 'aurion-energy'),
        'edit_item' => __('Edit Project', 'aurion-energy'),
        'new_item' => __('New Project', 'aurion-energy'),
        'view_item' => __('View Project', 'aurion-energy'),
        'search_items' => __('Search Projects', 'aurion-energy'),
        'not_found' => __('No projects found', 'aurion-energy'),
        'menu_name' => __('Projects', 'aurion-energy')
    );

    $project_args = array(
        'labels' => $project_labels,
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'projects'),
        'menu_icon' => 'dashicons-analytics',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'revisions'),
        'show_in_rest' => true
    );
    register_post_type('project', $project_args);

    $team_labels = array(
        'name' => __('Team Members', 'aurion-energy'),
        'singular_name' => __('Team Member', 'aurion-energy'),
        'add_new' => __('Add New Member', 'aurion-energy'),
        'edit_item' => __('Edit Team Member', 'aurion-energy'),
        'new_item' => __('New Team Member', 'aurion-energy'),
        'view_item' => __('View Team Member', 'aurion-energy'),
        'search_items' => __('Search Team Members', 'aurion-energy'),
        'not_found' => __('No team members found', 'aurion-energy'),
        'menu_name' => __('Team', 'aurion-energy')
    );

    $team_args = array(
        'labels' => $team_labels,
        'public' => true,
        'has_archive' => false,
        'rewrite' => array('slug' => 'team'),
        'menu_icon' => 'dashicons-id',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'revisions'),
        'show_in_rest' => true
    );
    register_post_type('team', $team_args);

    $testimonial_labels = array(
        'name' => __('Testimonials', 'aurion-energy'),
        'singular_name' => __('Testimonial', 'aurion-energy'),
        'add_new' => __('Add New Testimonial', 'aurion-energy'),
        'edit_item' => __('Edit Testimonial', 'aurion-energy'),
        'menu_name' => __('Testimonials', 'aurion-energy')
    );

    $testimonial_args = array(
        'labels' => $testimonial_labels,
        'public' => true,
        'has_archive' => false,
        'rewrite' => array('slug' => 'testimonials'),
        'menu_icon' => 'dashicons-format-quote',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest' => true
    );
    register_post_type('testimonial', $testimonial_args);

    register_taxonomy('project_type', 'project', array(
        'label' => __('Project Types', 'aurion-energy'),
        'rewrite' => array('slug' => 'project-type'),
        'hierarchical' => true,
        'show_admin_column' => true,
        'show_in_rest' => true
    ));

    register_taxonomy('expertise', 'team', array(
        'label' => __('Expertise Areas', 'aurion-energy'),
        'rewrite' => array('slug' => 'expertise'),
        'hierarchical' => false,
        'show_admin_column' => true,
        'show_in_rest' => true
    ));
}
add_action('init', 'aurion_register_custom_post_types');

class Aurion_Contact_Info_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'aurion_contact_info_widget',
            __('Aurion Contact Info', 'aurion-energy'),
            array('description' => __('Displays company contact information', 'aurion-energy'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        $title = isset($instance['title']) ? $instance['title'] : __('Contact Us', 'aurion-energy');
        if (!empty($title)) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }
        $address = aurion_get_theme_mod('contact_address', '460 Bay St, Toronto, ON M5H 2Y4, Canada');
        $phone = aurion_get_theme_mod('contact_phone', '+1 (416) 792-4583');
        $email = aurion_get_theme_mod('contact_email', 'info@aurionenergy.com');
        $hours = aurion_get_theme_mod('contact_hours', __('Monday to Friday: 8 AM – 6 PM', 'aurion-energy'));
        ?>
        <ul class="list-contact">
            <li><strong><?php esc_html_e('Address:', 'aurion-energy'); ?></strong><br><?php echo esc_html($address); ?></li>
            <li><strong><?php esc_html_e('Phone:', 'aurion-energy'); ?></strong><br><a href="tel:<?php echo esc_attr(aurion_sanitize_phone($phone)); ?>"><?php echo esc_html($phone); ?></a></li>
            <li><strong><?php esc_html_e('Email:', 'aurion-energy'); ?></strong><br><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></li>
            <li><strong><?php esc_html_e('Hours:', 'aurion-energy'); ?></strong><br><?php echo esc_html($hours); ?></li>
        </ul>
        <?php
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = isset($instance['title']) ? $instance['title'] : __('Contact Us', 'aurion-energy');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'aurion-energy'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        return $instance;
    }
}

class Aurion_Quick_CTA_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'aurion_quick_cta_widget',
            __('Aurion Quick CTA', 'aurion-energy'),
            array('description' => __('Displays a quick call-to-action', 'aurion-energy'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        $title = isset($instance['title']) ? $instance['title'] : __('Partner with Aurion', 'aurion-energy');
        $text = isset($instance['text']) ? $instance['text'] : __('Connect with our consulting team to discuss your next industrial project.', 'aurion-energy');
        $button_text = isset($instance['button_text']) ? $instance['button_text'] : __('Start a Conversation', 'aurion-energy');
        $button_url = isset($instance['button_url']) ? $instance['button_url'] : wp_make_link_relative(home_url('/contact'));
        if (!empty($title)) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }
        echo '<p>' . esc_html($text) . '</p>';
        echo '<a class="button" href="' . esc_url($button_url) . '">' . esc_html($button_text) . '</a>';
        echo $args['after_widget'];
    }

    public function form($instance) {
        $defaults = array(
            'title' => __('Partner with Aurion', 'aurion-energy'),
            'text' => __('Connect with our consulting team to discuss your next industrial project.', 'aurion-energy'),
            'button_text' => __('Start a Conversation', 'aurion-energy'),
            'button_url' => wp_make_link_relative(home_url('/contact'))
        );
        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'aurion-energy'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('text')); ?>"><?php esc_html_e('Description:', 'aurion-energy'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('text')); ?>" name="<?php echo esc_attr($this->get_field_name('text')); ?>" rows="4"><?php echo esc_textarea($instance['text']); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('button_text')); ?>"><?php esc_html_e('Button Text:', 'aurion-energy'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('button_text')); ?>" name="<?php echo esc_attr($this->get_field_name('button_text')); ?>" type="text" value="<?php echo esc_attr($instance['button_text']); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('button_url')); ?>"><?php esc_html_e('Button URL:', 'aurion-energy'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('button_url')); ?>" name="<?php echo esc_attr($this->get_field_name('button_url')); ?>" type="text" value="<?php echo esc_url($instance['button_url']); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['text'] = sanitize_textarea_field($new_instance['text']);
        $instance['button_text'] = sanitize_text_field($new_instance['button_text']);
        $instance['button_url'] = esc_url_raw($new_instance['button_url']);
        return $instance;
    }
}

class Aurion_Social_Links_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'aurion_social_links_widget',
            __('Aurion Social Links', 'aurion-energy'),
            array('description' => __('Displays social media links', 'aurion-energy'))
        );
    }

    public function widget($args, $instance) {
        $social_links = aurion_get_social_links();
        if (empty($social_links)) {
            return;
        }
        echo $args['before_widget'];
        $title = isset($instance['title']) ? $instance['title'] : __('Connect with Aurion', 'aurion-energy');
        echo $args['before_title'] . esc_html($title) . $args['after_title'];
        echo '<div class="footer-social">';
        foreach ($social_links as $network => $link) {
            if (!empty($link['url'])) {
                echo '<a href="' . esc_url($link['url']) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr($link['label']) . '">';
                echo '<span class="dashicons dashicons-' . esc_attr($link['icon']) . '"></span>';
                echo '</a>';
            }
        }
        echo '</div>';
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = isset($instance['title']) ? $instance['title'] : __('Connect with Aurion', 'aurion-energy');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'aurion-energy'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        return $instance;
    }
}

function aurion_register_widgets() {
    register_widget('Aurion_Contact_Info_Widget');
    register_widget('Aurion_Quick_CTA_Widget');
    register_widget('Aurion_Social_Links_Widget');
}
add_action('widgets_init', 'aurion_register_widgets');

function aurion_customize_register($wp_customize) {
    $wp_customize->add_section('aurion_branding_section', array(
        'title' => __('Branding', 'aurion-energy'),
        'priority' => 30
    ));

    $wp_customize->add_setting('cta_text', array(
        'default' => __('Partner with Aurion', 'aurion-energy'),
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cta_text', array(
        'label' => __('Header CTA Text', 'aurion-energy'),
        'section' => 'aurion_branding_section',
        'type' => 'text'
    ));

    $wp_customize->add_setting('cta_link', array(
        'default' => wp_make_link_relative(home_url('/contact')),
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cta_link', array(
        'label' => __('Header CTA Link', 'aurion-energy'),
        'section' => 'aurion_branding_section',
        'type' => 'url'
    ));

    $wp_customize->add_section('aurion_color_section', array(
        'title' => __('Theme Colors', 'aurion-energy'),
        'priority' => 31
    ));

    $color_settings = array(
        'color_primary' => array(__('Primary Color', 'aurion-energy'), '#0F172A'),
        'color_secondary' => array(__('Secondary Color', 'aurion-energy'), '#475569'),
        'color_accent' => array(__('Accent Color', 'aurion-energy'), '#2563EB')
    );

    foreach ($color_settings as $id => $data) {
        $wp_customize->add_setting($id, array(
            'default' => $data[1],
            'sanitize_callback' => 'sanitize_hex_color'
        ));
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, $id, array(
            'label' => $data[0],
            'section' => 'aurion_color_section'
        )));
    }

    $wp_customize->add_section('aurion_contact_section', array(
        'title' => __('Contact Information', 'aurion-energy'),
        'priority' => 32
    ));

    $contact_settings = array(
        'contact_email' => array(__('Email Address', 'aurion-energy'), 'info@aurionenergy.com', 'sanitize_email'),
        'contact_phone' => array(__('Phone Number', 'aurion-energy'), '+1 (416) 792-4583', 'sanitize_text_field'),
        'contact_address' => array(__('Address', 'aurion-energy'), '460 Bay St, Toronto, ON M5H 2Y4, Canada', 'sanitize_text_field'),
        'contact_hours' => array(__('Business Hours', 'aurion-energy'), __('Monday to Friday: 8 AM – 6 PM', 'aurion-energy'), 'sanitize_text_field'),
        'contact_linkedin' => array(__('LinkedIn URL', 'aurion-energy'), 'https://www.linkedin.com', 'esc_url_raw')
    );

    foreach ($contact_settings as $id => $data) {
        $wp_customize->add_setting($id, array(
            'default' => $data[1],
            'sanitize_callback' => $data[2]
        ));
        $wp_customize->add_control($id, array(
            'label' => $data[0],
            'section' => 'aurion_contact_section',
            'type' => 'text'
        ));
    }

    $wp_customize->add_section('aurion_social_section', array(
        'title' => __('Social Profiles', 'aurion-energy'),
        'priority' => 33
    ));

    $social_networks = array(
        'linkedin' => __('LinkedIn', 'aurion-energy'),
        'twitter' => __('Twitter', 'aurion-energy'),
        'facebook' => __('Facebook', 'aurion-energy')
    );

    foreach ($social_networks as $network => $label) {
        $setting_id = 'social_' . $network;
        $wp_customize->add_setting($setting_id, array(
            'default' => '',
            'sanitize_callback' => 'esc_url_raw'
        ));
        $wp_customize->add_control($setting_id, array(
            'label' => $label . ' URL',
            'section' => 'aurion_social_section',
            'type' => 'url'
        ));
    }

    $wp_customize->add_section('aurion_footer_section', array(
        'title' => __('Footer', 'aurion-energy'),
        'priority' => 34
    ));

    $wp_customize->add_setting('footer_copyright', array(
        'default' => sprintf(__('© %s Aurion Energy Advisory. All rights reserved.', 'aurion-energy'), date_i18n('Y')),
        'sanitize_callback' => 'sanitize_text_field'
    ));

    $wp_customize->add_control('footer_copyright', array(
        'label' => __('Copyright Text', 'aurion-energy'),
        'section' => 'aurion_footer_section',
        'type' => 'text'
    ));
}
add_action('customize_register', 'aurion_customize_register');

function aurion_customizer_css() {
    $primary = aurion_get_theme_mod('color_primary', '#0F172A');
    $secondary = aurion_get_theme_mod('color_secondary', '#475569');
    $accent = aurion_get_theme_mod('color_accent', '#2563EB');
    ?>
    <style>
        :root {
            --color-primary-dark: <?php echo esc_html($primary); ?>;
            --color-secondary-gray: <?php echo esc_html($secondary); ?>;
            --color-accent-blue: <?php echo esc_html($accent); ?>;
        }
    </style>
    <?php
}
add_action('wp_head', 'aurion_customizer_css', 100);

function aurion_get_theme_mod($name, $default = '') {
    $value = get_theme_mod($name, $default);
    if (empty($value)) {
        return $default;
    }
    return $value;
}

function aurion_sanitize_phone($phone) {
    $clean = preg_replace('/[^0-9+]/', '', $phone);
    return $clean;
}

function aurion_format_address($address) {
    return nl2br(esc_html($address));
}

function aurion_get_social_links() {
    return array(
        'linkedin' => array(
            'label' => __('LinkedIn', 'aurion-energy'),
            'url' => aurion_get_theme_mod('social_linkedin', ''),
            'icon' => 'linkedin'
        ),
        'twitter' => array(
            'label' => __('Twitter', 'aurion-energy'),
            'url' => aurion_get_theme_mod('social_twitter', ''),
            'icon' => 'twitter'
        ),
        'facebook' => array(
            'label' => __('Facebook', 'aurion-energy'),
            'url' => aurion_get_theme_mod('social_facebook', ''),
            'icon' => 'facebook'
        )
    );
}

function aurion_breadcrumbs() {
    if (is_front_page()) {
        return;
    }

    $breadcrumbs = array();
    $breadcrumbs[] = array(
        'url' => home_url('/'),
        'label' => __('Home', 'aurion-energy')
    );

    if (is_home()) {
        $breadcrumbs[] = array(
            'label' => get_the_title(get_option('page_for_posts', true))
        );
    } elseif (is_singular('project')) {
        $breadcrumbs[] = array(
            'url' => get_post_type_archive_link('project'),
            'label' => __('Projects', 'aurion-energy')
        );
    } elseif (is_singular('team')) {
        $breadcrumbs[] = array(
            'url' => home_url('/team'),
            'label' => __('Team', 'aurion-energy')
        );
    } elseif (is_archive()) {
        if (is_post_type_archive('project')) {
            $breadcrumbs[] = array('label' => __('Projects', 'aurion-energy'));
        } elseif (is_post_type_archive('team')) {
            $breadcrumbs[] = array('label' => __('Team', 'aurion-energy'));
        } elseif (is_category() || is_tag() || is_tax()) {
            $breadcrumbs[] = array('label' => single_term_title('', false));
        } elseif (is_author()) {
            $breadcrumbs[] = array('label' => get_the_author());
        } elseif (is_date()) {
            $breadcrumbs[] = array('label' => get_the_archive_title());
        }
    } elseif (is_search()) {
        $breadcrumbs[] = array(
            'label' => sprintf(__('Search results for "%s"', 'aurion-energy'), get_search_query())
        );
    } else {
        $parents = array_reverse(get_post_ancestors(get_the_ID()));
        foreach ($parents as $parent_id) {
            $breadcrumbs[] = array(
                'url' => get_permalink($parent_id),
                'label' => get_the_title($parent_id)
            );
        }
        $breadcrumbs[] = array(
            'label' => get_the_title()
        );
    }

    $schema_items = array();
    ?>
    <nav class="breadcrumbs" aria-label="<?php esc_attr_e('Breadcrumb', 'aurion-energy'); ?>">
        <ol class="breadcrumbs__list">
            <?php foreach ($breadcrumbs as $index => $crumb) :
                $schema_items[] = array(
                    '@type' => 'ListItem',
                    'position' => $index + 1,
                    'name' => wp_strip_all_tags($crumb['label']),
                    'item' => isset($crumb['url']) ? esc_url($crumb['url']) : ''
                );
                ?>
                <li class="breadcrumbs__item">
                    <?php if (isset($crumb['url'])) : ?>
                        <a href="<?php echo esc_url($crumb['url']); ?>"><?php echo esc_html($crumb['label']); ?></a>
                    <?php else : ?>
                        <span aria-current="page"><?php echo esc_html($crumb['label']); ?></span>
                    <?php endif; ?>
                    <?php if ($index + 1 < count($breadcrumbs)) : ?>
                        <span class="breadcrumbs__separator">/</span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ol>
    </nav>
    <script type="application/ld+json">
        <?php echo wp_json_encode(array(
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $schema_items
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>
    </script>
    <?php
}

function aurion_pagination($query = null) {
    if (!$query) {
        global $wp_query;
        $query = $wp_query;
    }
    $links = paginate_links(array(
        'total' => $query->max_num_pages,
        'current' => max(1, get_query_var('paged')),
        'type' => 'array',
        'mid_size' => 2,
        'prev_text' => __('« Prev', 'aurion-energy'),
        'next_text' => __('Next »', 'aurion-energy')
    ));
    if ($links) {
        echo '<nav class="pagination" aria-label="' . esc_attr__('Pagination', 'aurion-energy') . '">';
        foreach ($links as $link) {
            echo wp_kses_post($link);
        }
        echo '</nav>';
    }
}

function aurion_cookie_notice() {
    ?>
    <div class="cookie-banner" data-cookie-banner role="dialog" aria-live="polite" aria-label="<?php esc_attr_e('Cookie message', 'aurion-energy'); ?>">
        <p><?php esc_html_e('This site uses cookies to improve your experience. By using this site, you agree to our Cookie Policy.', 'aurion-energy'); ?></p>
        <div class="cookie-banner__actions">
            <a class="button button--outline" href="<?php echo esc_url(home_url('/policy')); ?>"><?php esc_html_e('View Policy', 'aurion-energy'); ?></a>
            <button type="button" class="button" data-cookie-accept><?php esc_html_e('Accept', 'aurion-energy'); ?></button>
        </div>
        <button type="button" class="cookie-banner__close" data-cookie-close><?php esc_html_e('Close', 'aurion-energy'); ?></button>
    </div>
    <?php
}
add_action('wp_body_open', 'aurion_cookie_notice');

function aurion_handle_contact_form() {
    if (!isset($_POST['aurion_contact_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['aurion_contact_nonce'])), 'aurion_contact_form')) {
        wp_safe_redirect(add_query_arg('form', 'error', wp_get_referer()));
        exit;
    }

    $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $company = isset($_POST['company']) ? sanitize_text_field(wp_unslash($_POST['company'])) : '';
    $subject = isset($_POST['subject']) ? sanitize_text_field(wp_unslash($_POST['subject'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';

    if (empty($name) || empty($email) || empty($message)) {
        wp_safe_redirect(add_query_arg('form', 'error', wp_get_referer()));
        exit;
    }

    $admin_email = aurion_get_theme_mod('contact_email', get_option('admin_email'));
    $email_subject = sprintf(__('New inquiry from %s', 'aurion-energy'), $name);
    $body = sprintf(
        "Name: %s\nEmail: %s\nPhone: %s\nCompany: %s\nSubject: %s\n\nMessage:\n%s",
        $name,
        $email,
        $phone,
        $company,
        $subject,
        $message
    );

    $headers = array('Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $email);

    wp_mail($admin_email, $email_subject, $body, $headers);

    wp_safe_redirect(add_query_arg('form', 'success', wp_get_referer()));
    exit;
}
add_action('admin_post_nopriv_aurion_contact_form', 'aurion_handle_contact_form');
add_action('admin_post_aurion_contact_form', 'aurion_handle_contact_form');

function aurion_open_graph_tags() {
    if (!is_singular()) {
        return;
    }
    global $post;
    setup_postdata($post);
    $title = get_the_title();
    $description = get_the_excerpt();
    $url = get_permalink();
    $image = '';
    if (has_post_thumbnail()) {
        $image_data = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
        if ($image_data) {
            $image = $image_data[0];
        }
    }
    ?>
    <meta property="og:title" content="<?php echo esc_attr($title); ?>">
    <meta property="og:description" content="<?php echo esc_attr($description); ?>">
    <meta property="og:url" content="<?php echo esc_url($url); ?>">
    <meta property="og:site_name" content="<?php bloginfo('name'); ?>">
    <?php if ($image) : ?>
        <meta property="og:image" content="<?php echo esc_url($image); ?>">
    <?php endif; ?>
    <meta name="twitter:card" content="summary_large_image">
    <?php
    wp_reset_postdata();
}
add_action('wp_head', 'aurion_open_graph_tags', 5);

function aurion_preload_fonts() {
    ?>
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php
}
add_action('wp_head', 'aurion_preload_fonts', 2);

function aurion_document_title_separator($sep) {
    return '|';
}
add_filter('document_title_separator', 'aurion_document_title_separator');

function aurion_document_title_parts($title) {
    if (is_front_page()) {
        $title['tagline'] = __('Engineering the Future of Energy', 'aurion-energy');
    }
    return $title;
}
add_filter('document_title_parts', 'aurion_document_title_parts');

function aurion_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'aurion_excerpt_more');

function aurion_required_indicator() {
    return '<span class="required" aria-hidden="true">*</span>';
}