<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary">
    <?php get_template_part('template-parts/hero/hero-banner', null, array(
        'title' => __('Engineering the Future of Energy', 'aurion-energy'),
        'description' => __('Aurion Energy Advisory delivers integrated consulting, industrial engineering, and field execution for Canada’s most complex energy infrastructure initiatives.', 'aurion-energy'),
        'cta_text' => __('Partner with Aurion', 'aurion-energy'),
        'cta_link' => home_url('/contact')
    )); ?>

    <section class="section" id="about" data-aos="fade-up">
        <div class="container">
            <div class="section__header">
                <h2 class="section__title"><?php esc_html_e('Who We Are', 'aurion-energy'); ?></h2>
                <p class="section__subtitle">
                    <?php esc_html_e('Aurion Energy Advisory is a Toronto-based consulting firm guiding Canadian operators through every phase of energy infrastructure development. Our engineers, project managers, and field specialists unite to deliver resilient solutions tailored for demanding environments.', 'aurion-energy'); ?>
                </p>
            </div>
            <div class="split">
                <div>
                    <p><?php esc_html_e('From feasibility assessments to on-site execution, we combine data-driven insight with deep oilfield experience to mitigate risk and maintain project certainty. Our collaborative approach leverages cross-functional expertise spanning energy consulting, oilfield research, and industrial engineering.', 'aurion-energy'); ?></p>
                    <p><?php esc_html_e('Aurion teams operate across Canada, supporting clients with strategic planning, regulatory compliance, crane and heavy-lift coordination, and integrated logistics. Our focus on safety, innovation, and sustainability ensures every project advances responsibly.', 'aurion-energy'); ?></p>
                    <a class="button button--outline" href="<?php echo esc_url(home_url('/about')); ?>"><?php esc_html_e('Discover Our Story', 'aurion-energy'); ?></a>
                </div>
                <div>
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder-industrial.jpg'); ?>" alt="<?php esc_attr_e('Engineers reviewing energy infrastructure plans', 'aurion-energy'); ?>">
                </div>
            </div>
        </div>
    </section>

    <section class="section section--light" id="expertise">
        <div class="container">
            <div class="section__header" data-aos="fade-up">
                <h2 class="section__title"><?php esc_html_e('Our Expertise', 'aurion-energy'); ?></h2>
                <p class="section__subtitle"><?php esc_html_e('Integrated services engineered to support energy consulting in Canada, oilfield research environments, and critical infrastructure deployment.', 'aurion-energy'); ?></p>
            </div>
            <div class="grid grid--three">
                <?php
                $services = array(
                    array(
                        'title' => __('Consulting Services', 'aurion-energy'),
                        'description' => __('Strategic advisory for upstream, midstream, and downstream initiatives with actionable insights, regulatory guidance, and risk management.', 'aurion-energy'),
                        'icon' => 'dashicons-chart-area'
                    ),
                    array(
                        'title' => __('Oilfield Research', 'aurion-energy'),
                        'description' => __('Applied research programs focused on reservoir performance, compliance assurance, and technology adoption for Canadian oil and gas operations.', 'aurion-energy'),
                        'icon' => 'dashicons-search'
                    ),
                    array(
                        'title' => __('Installation & Logistics', 'aurion-energy'),
                        'description' => __('End-to-end coordination for crane installation, heavy-lift operations, and site logistics to keep industrial projects on schedule.', 'aurion-energy'),
                        'icon' => 'dashicons-hammer'
                    )
                );
                foreach ($services as $service) {
                    get_template_part('template-parts/content/card-service', null, $service);
                }
                ?>
            </div>
        </div>
    </section>

    <section class="section" id="oilfield-research">
        <div class="container split">
            <div data-aos="fade-right">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder-oilfield.jpg'); ?>" alt="<?php esc_attr_e('Oilfield research operations in Canada', 'aurion-energy'); ?>">
            </div>
            <div data-aos="fade-left">
                <h2><?php esc_html_e('Oilfield Research Excellence', 'aurion-energy'); ?></h2>
                <p><?php esc_html_e('Aurion provides oilfield research programs that bridge data science and field operations. Our teams assess reservoir behavior, emissions profiles, and infrastructure integrity to support compliant, high-performing assets.', 'aurion-energy'); ?></p>
                <ul class="list-check">
                    <li><?php esc_html_e('Exploration and reservoir analytics tailored to Canadian basins', 'aurion-energy'); ?></li>
                    <li><?php esc_html_e('Regulatory compliance tracking for evolving provincial requirements', 'aurion-energy'); ?></li>
                    <li><?php esc_html_e('Technology validation and pilot coordination for field deployment', 'aurion-energy'); ?></li>
                </ul>
            </div>
        </div>
    </section>

    <section class="section section--light" id="engineering">
        <div class="container split">
            <div data-aos="fade-right">
                <h2><?php esc_html_e('Engineering Solutions for Crane and Heavy-Lift Operations', 'aurion-energy'); ?></h2>
                <p><?php esc_html_e('Our industrial engineering specialists align design, fabrication, and field execution to safely manage crane installation and heavy-lift scopes. From modularized plant components to offshore platforms, Aurion orchestrates every milestone.', 'aurion-energy'); ?></p>
                <ul class="list-check">
                    <li><?php esc_html_e('3D lift planning and clash detection for complex rigging programs', 'aurion-energy'); ?></li>
                    <li><?php esc_html_e('On-site technical supervision ensuring precision lifts and alignment', 'aurion-energy'); ?></li>
                    <li><?php esc_html_e('Logistics support integrating transport permits, sequencing, and staging', 'aurion-energy'); ?></li>
                </ul>
                <a class="button" href="<?php echo esc_url(home_url('/services')); ?>"><?php esc_html_e('Explore Engineering Services', 'aurion-energy'); ?></a>
            </div>
            <div data-aos="fade-left">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder-crane.jpg'); ?>" alt="<?php esc_attr_e('Heavy lift crane installation support', 'aurion-energy'); ?>">
            </div>
        </div>
    </section>

    <section class="section" id="sustainability">
        <div class="container">
            <div class="section__header" data-aos="fade-up">
                <h2 class="section__title"><?php esc_html_e('Sustainability Innovation', 'aurion-energy'); ?></h2>
                <p class="section__subtitle"><?php esc_html_e('We embed sustainable engineering practices into every industrial project, advancing energy transition goals while maintaining operational excellence.', 'aurion-energy'); ?></p>
            </div>
            <div class="grid grid--three">
                <article class="card" data-aos="fade-up">
                    <h3><?php esc_html_e('Low-Emission Project Design', 'aurion-energy'); ?></h3>
                    <p><?php esc_html_e('Energy modeling, electrification strategies, and process optimization to reduce emissions across capital programs.', 'aurion-energy'); ?></p>
                </article>
                <article class="card" data-aos="fade-up">
                    <h3><?php esc_html_e('Lifecycle Asset Strategies', 'aurion-energy'); ?></h3>
                    <p><?php esc_html_e('Integrated planning that balances reliability, maintenance, and environmental performance for long-term resilience.', 'aurion-energy'); ?></p>
                </article>
                <article class="card" data-aos="fade-up">
                    <h3><?php esc_html_e('Compliance & Reporting', 'aurion-energy'); ?></h3>
                    <p><?php esc_html_e('Robust data frameworks to support ESG disclosure, regulatory reporting, and continuous improvement initiatives.', 'aurion-energy'); ?></p>
                </article>
            </div>
        </div>
    </section>

    <section class="section section--light" id="projects">
        <div class="container">
            <div class="section__header" data-aos="fade-up">
                <h2 class="section__title"><?php esc_html_e('Featured Projects', 'aurion-energy'); ?></h2>
                <p class="section__subtitle"><?php esc_html_e('Recent work delivering energy consulting in Canada, advanced oilfield research, and turnkey industrial engineering programs.', 'aurion-energy'); ?></p>
            </div>
            <div class="featured-projects__grid">
                <?php
                $featured_projects = new WP_Query(array(
                    'post_type' => 'project',
                    'posts_per_page' => 3
                ));
                if ($featured_projects->have_posts()) :
                    while ($featured_projects->have_posts()) :
                        $featured_projects->the_post();
                        get_template_part('template-parts/content/card-project');
                    endwhile;
                    wp_reset_postdata();
                else :
                    ?>
                    <p><?php esc_html_e('Project case studies will appear here as they are published.', 'aurion-energy'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="section" id="testimonials">
        <div class="container">
            <div class="section__header" data-aos="fade-up">
                <h2 class="section__title"><?php esc_html_e('Client Testimonials', 'aurion-energy'); ?></h2>
                <p class="section__subtitle"><?php esc_html_e('Leaders across Canada’s energy sector rely on Aurion to deliver safe, responsible, and high-performing outcomes.', 'aurion-energy'); ?></p>
            </div>
            <div class="grid grid--three">
                <?php
                $testimonials = new WP_Query(array(
                    'post_type' => 'testimonial',
                    'posts_per_page' => 3
                ));
                if ($testimonials->have_posts()) :
                    while ($testimonials->have_posts()) :
                        $testimonials->the_post();
                        get_template_part('template-parts/content/card-testimonial');
                    endwhile;
                    wp_reset_postdata();
                else :
                    ?>
                    <article class="card card--testimonial" data-aos="fade-up">
                        <p><?php esc_html_e('Testimonials from Aurion Energy Advisory clients will be featured soon.', 'aurion-energy'); ?></p>
                    </article>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php get_template_part('template-parts/cta/cta-partner'); ?>
</main>
<?php
get_footer();
?>