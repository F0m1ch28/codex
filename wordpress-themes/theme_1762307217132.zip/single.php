<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="container section">
    <?php get_template_part('template-parts/content/breadcrumbs'); ?>
    <?php while (have_posts()) : the_post(); ?>
        <article <?php post_class('post-single'); ?>>
            <header class="post-header">
                <h1><?php the_title(); ?></h1>
                <div class="post-meta">
                    <span><?php echo esc_html(get_the_date()); ?></span>
                    <span><?php echo esc_html(get_the_author()); ?></span>
                    <?php
                    $categories = get_the_category();
                    if ($categories) {
                        echo '<span>' . esc_html($categories[0]->name) . '</span>';
                    }
                    ?>
                </div>
            </header>
            <?php if (has_post_thumbnail()) : ?>
                <div class="post-featured-image" data-aos="fade-up">
                    <?php the_post_thumbnail('blog-featured'); ?>
                </div>
            <?php endif; ?>
            <div class="post-content" data-aos="fade-up">
                <?php the_content(); ?>
            </div>
            <?php
            $post_tags = get_the_tags();
            if ($post_tags) :
                ?>
                <div class="post-tags">
                    <?php foreach ($post_tags as $tag) : ?>
                        <a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>"><?php echo esc_html($tag->name); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="author-box">
                <div class="author-box__avatar">
                    <?php echo get_avatar(get_the_author_meta('ID'), 96); ?>
                </div>
                <div class="author-box__content">
                    <h4><?php echo esc_html(get_the_author()); ?></h4>
                    <p><?php echo esc_html(get_the_author_meta('description')); ?></p>
                </div>
            </div>
            <nav class="post-navigation">
                <div class="post-navigation__previous">
                    <?php previous_post_link('%link', __('« Previous Post', 'aurion-energy')); ?>
                </div>
                <div class="post-navigation__next">
                    <?php next_post_link('%link', __('Next Post »', 'aurion-energy')); ?>
                </div>
            </nav>
            <?php
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;
            ?>
        </article>
    <?php endwhile; ?>
</main>
<?php get_sidebar(); ?>
<?php
get_footer();
?>