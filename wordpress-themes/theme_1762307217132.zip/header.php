<?php
defined('ABSPATH') || exit;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
<?php
$organization_schema = array(
    '@context' => 'https://schema.org',
    '@type' => 'Organization',
    'name' => 'Aurion Energy Advisory',
    'url' => home_url('/'),
    'telephone' => aurion_get_theme_mod('contact_phone', '+1 (416) 792-4583'),
    'email' => aurion_get_theme_mod('contact_email', 'info@aurionenergy.com'),
    'address' => array(
        '@type' => 'PostalAddress',
        'streetAddress' => '460 Bay St',
        'addressLocality' => 'Toronto',
        'addressRegion' => 'ON',
        'postalCode' => 'M5H 2Y4',
        'addressCountry' => 'CA'
    ),
    'sameAs' => array_filter(array(
        aurion_get_theme_mod('social_linkedin', ''),
        aurion_get_theme_mod('social_twitter', ''),
        aurion_get_theme_mod('social_facebook', '')
    ))
);
?>
<script type="application/ld+json">
<?php echo wp_json_encode($organization_schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>
</script>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to main content', 'aurion-energy'); ?></a>
<header class="site-header" data-sticky>
    <div class="container site-header__inner">
        <div class="site-branding">
            <?php if (has_custom_logo()) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="site-branding__title"><?php bloginfo('name'); ?></a>
            <?php endif; ?>
        </div>
        <nav class="main-navigation" aria-label="<?php esc_attr_e('Primary Menu', 'aurion-energy'); ?>">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'menu_class' => 'menu'
            ));
            ?>
        </nav>
        <div class="site-header__cta">
            <div class="site-header__search">
                <?php get_search_form(); ?>
            </div>
            <a class="button" href="<?php echo esc_url(aurion_get_theme_mod('cta_link', home_url('/contact'))); ?>">
                <?php echo esc_html(aurion_get_theme_mod('cta_text', __('Partner with Aurion', 'aurion-energy'))); ?>
            </a>
            <button class="mobile-toggle" data-menu-toggle aria-label="<?php esc_attr_e('Toggle navigation', 'aurion-energy'); ?>">
                <span></span>
            </button>
        </div>
    </div>
</header>
<div class="mobile-menu" data-mobile-menu>
    <div class="mobile-menu__panel">
        <?php
        get_template_part('template-parts/header/nav-mobile');
        ?>
    </div>
</div>