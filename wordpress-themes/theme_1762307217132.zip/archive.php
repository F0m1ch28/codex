<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="container section">
    <?php get_template_part('template-parts/content/breadcrumbs'); ?>
    <header class="page-header">
        <h1 class="page-title"><?php the_archive_title(); ?></h1>
        <div class="archive-description"><?php the_archive_description(); ?></div>
    </header>
    <?php if (have_posts()) : ?>
        <div class="grid grid--three">
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class('post-card'); ?> data-aos="fade-up">
                    <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('blog-featured'); ?>
                        </a>
                    <?php endif; ?>
                    <div class="post-card__meta">
                        <span><?php echo esc_html(get_the_date()); ?></span>
                        <span><?php echo esc_html(get_the_author()); ?></span>
                    </div>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo esc_html(get_the_excerpt()); ?></p>
                    <a class="button button--outline" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'aurion-energy'); ?></a>
                </article>
            <?php endwhile; ?>
        </div>
        <?php aurion_pagination(); ?>
    <?php else : ?>
        <section class="no-results">
            <h2><?php esc_html_e('No Posts Found', 'aurion-energy'); ?></h2>
            <p><?php esc_html_e('We could not find any posts matching your criteria.', 'aurion-energy'); ?></p>
        </section>
    <?php endif; ?>
</main>
<?php get_sidebar(); ?>
<?php
get_footer();
?>