"use strict";

document.addEventListener("DOMContentLoaded", function () {
    var header = document.querySelector("[data-sticky]");
    var backToTop = document.getElementById("back-to-top");
    var menuToggle = document.querySelector("[data-menu-toggle]");
    var mobileMenu = document.querySelector("[data-mobile-menu]");
    var cookieBanner = document.querySelector("[data-cookie-banner]");
    var acceptCookie = document.querySelector("[data-cookie-accept]");
    var closeCookie = document.querySelector("[data-cookie-close]");
    var focusableMenuElements;

    function setHeaderState() {
        if (!header) {
            return;
        }
        var scrolled = window.scrollY > 48;
        header.classList.toggle("is-scrolled", scrolled);
    }

    function setBackToTopState() {
        if (!backToTop) {
            return;
        }
        var scrolled = window.scrollY > 400;
        backToTop.classList.toggle("is-visible", scrolled);
    }

    function toggleMobileMenu(forceClose) {
        if (!menuToggle || !mobileMenu) {
            return;
        }
        var isOpen = forceClose ? false : !mobileMenu.classList.contains("is-open");
        mobileMenu.classList.toggle("is-open", isOpen);
        menuToggle.classList.toggle("is-open", isOpen);
        document.body.classList.toggle("mobile-menu-open", isOpen);

        if (isOpen) {
            focusableMenuElements = mobileMenu.querySelectorAll("a, button");
            if (focusableMenuElements.length) {
                focusableMenuElements[0].focus();
            }
        } else {
            menuToggle.focus();
        }
    }

    if (menuToggle) {
        menuToggle.addEventListener("click", function () {
            toggleMobileMenu(false);
        });
    }

    if (mobileMenu) {
        mobileMenu.addEventListener("click", function (event) {
            if (event.target === mobileMenu) {
                toggleMobileMenu(true);
            }
        });
    }

    if (backToTop) {
        backToTop.addEventListener("click", function (event) {
            event.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    window.addEventListener("scroll", function () {
        setHeaderState();
        setBackToTopState();
    });

    setHeaderState();
    setBackToTopState();

    if (cookieBanner && acceptCookie) {
        var consent = localStorage.getItem("aurionCookieConsent");
        if (!consent) {
            cookieBanner.style.display = "flex";
        }

        acceptCookie.addEventListener("click", function () {
            localStorage.setItem("aurionCookieConsent", "accepted");
            cookieBanner.style.display = "none";
        });

        if (closeCookie) {
            closeCookie.addEventListener("click", function () {
                cookieBanner.style.display = "none";
            });
        }
    }

    if (typeof AOS !== "undefined") {
        AOS.init({
            duration: 600,
            easing: "ease-out-quart",
            once: true
        });
    }

    var anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(function (link) {
        link.addEventListener("click", function (event) {
            var targetId = link.getAttribute("href").substring(1);
            var targetElement = document.getElementById(targetId);
            if (targetElement) {
                event.preventDefault();
                targetElement.scrollIntoView({ behavior: "smooth" });
            }
        });
    });
});