<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="primary" class="container section search-results">
    <?php get_template_part('template-parts/content/breadcrumbs'); ?>
    <header class="page-header">
        <h1><?php printf(esc_html__('Search Results for: %s', 'aurion-energy'), '<span>' . esc_html(get_search_query()) . '</span>'); ?></h1>
    </header>
    <?php if (have_posts()) : ?>
        <div class="grid grid--three">
            <?php while (have_posts()) : the_post(); ?>
                <article <?php post_class('post-card'); ?> data-aos="fade-up">
                    <div class="post-card__meta">
                        <span><?php echo esc_html(get_the_date()); ?></span>
                        <span><?php echo esc_html(get_the_author()); ?></span>
                    </div>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo esc_html(get_the_excerpt()); ?></p>
                    <a class="button button--outline" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'aurion-energy'); ?></a>
                </article>
            <?php endwhile; ?>
        </div>
        <?php aurion_pagination(); ?>
    <?php else : ?>
        <section class="no-results">
            <h2><?php esc_html_e('No Results Found', 'aurion-energy'); ?></h2>
            <p><?php esc_html_e('Try refining your search or explore the links below.', 'aurion-energy'); ?></p>
            <?php get_search_form(); ?>
            <div class="grid grid--two" style="margin-top: 32px;">
                <a class="button button--outline" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Return to Homepage', 'aurion-energy'); ?></a>
                <a class="button button--outline" href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact Aurion', 'aurion-energy'); ?></a>
            </div>
        </section>
    <?php endif; ?>
</main>
<?php get_sidebar(); ?>
<?php
get_footer();
?>