<?php
defined('ABSPATH') || exit;
/*
Template Name: About Page
*/
get_header();
?>
<main id="primary">
    <?php get_template_part('template-parts/hero/hero-title-only'); ?>
    <section class="section container">
        <?php get_template_part('template-parts/content/breadcrumbs'); ?>
        <div class="split">
            <div data-aos="fade-right">
                <h2><?php esc_html_e('Company History', 'aurion-energy'); ?></h2>
                <p><?php esc_html_e('Founded in Toronto, Aurion Energy Advisory emerged from a collective of engineers and consultants committed to modernizing Canada’s energy infrastructure. Over the past decade, our team has supported operators through project identification, oilfield data programs, and the deployment of heavy industrial assets.', 'aurion-energy'); ?></p>
                <p><?php esc_html_e('Today, Aurion aligns strategic planning, field intelligence, and execution oversight to help clients deliver responsible energy projects across the country.', 'aurion-energy'); ?></p>
            </div>
            <div data-aos="fade-left">
                <h2><?php esc_html_e('Mission Statement', 'aurion-energy'); ?></h2>
                <div class="card">
                    <p><?php esc_html_e('Aurion Energy Advisory empowers Canadian energy developers with integrated consulting, engineering, and research services that advance safe, sustainable, and future-ready infrastructure.', 'aurion-energy'); ?></p>
                </div>
                <h3><?php esc_html_e('Leadership Team', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('Our leadership combines decades of oilfield research, industrial engineering, and project management experience.', 'aurion-energy'); ?></p>
                <a class="button button--outline" href="<?php echo esc_url(home_url('/team')); ?>"><?php esc_html_e('Meet the Team', 'aurion-energy'); ?></a>
            </div>
        </div>
    </section>

    <section class="section section--light">
        <div class="container split">
            <div data-aos="fade-right">
                <h2><?php esc_html_e('Safety Philosophy', 'aurion-energy'); ?></h2>
                <p><?php esc_html_e('Safety is the foundation of every Aurion engagement. We integrate hazard mitigation, crew competency development, and real-time monitoring into each project stage.', 'aurion-energy'); ?></p>
                <ul class="list-check">
                    <li><?php esc_html_e('Proactive risk assessments for crane installation and heavy-lift operations', 'aurion-energy'); ?></li>
                    <li><?php esc_html_e('Comprehensive orientation and competency validation for field teams', 'aurion-energy'); ?></li>
                    <li><?php esc_html_e('Continuous improvement driven by incident-free performance targets', 'aurion-energy'); ?></li>
                </ul>
            </div>
            <div data-aos="fade-left">
                <h2><?php esc_html_e('Sustainability Commitment', 'aurion-energy'); ?></h2>
                <p><?php esc_html_e('Aurion supports clients in advancing sustainable engineering solutions. Our teams collaborate on emissions reduction strategies, electrification studies, and lifecycle planning that align with Canadian regulations and climate goals.', 'aurion-energy'); ?></p>
                <p><?php esc_html_e('We combine data analytics with field insight to design programs that balance operational reliability with environmental stewardship.', 'aurion-energy'); ?></p>
            </div>
        </div>
    </section>

    <section class="section container" data-aos="fade-up">
        <h2><?php esc_html_e('Our Values', 'aurion-energy'); ?></h2>
        <div class="grid grid--four">
            <article class="card">
                <h3><?php esc_html_e('Integrity in Action', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('We operate transparently across planning rooms and field sites, building trust through dependable execution.', 'aurion-energy'); ?></p>
            </article>
            <article class="card">
                <h3><?php esc_html_e('Operational Excellence', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('Our teams drive performance through disciplined project controls, quality assurance, and adaptive planning.', 'aurion-energy'); ?></p>
            </article>
            <article class="card">
                <h3><?php esc_html_e('Innovation Mindset', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('We apply emerging technology and collaborative research to solve complex energy challenges.', 'aurion-energy'); ?></p>
            </article>
            <article class="card">
                <h3><?php esc_html_e('People First', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('Safety, wellbeing, and leadership development keep our teams and partners resilient.', 'aurion-energy'); ?></p>
            </article>
        </div>
    </section>

    <section class="section section--light">
        <div class="container">
            <h2><?php esc_html_e('Team Spotlight', 'aurion-energy'); ?></h2>
            <div class="team-grid">
                <?php
                $team_preview = new WP_Query(array(
                    'post_type' => 'team',
                    'posts_per_page' => 4
                ));
                if ($team_preview->have_posts()) :
                    while ($team_preview->have_posts()) :
                        $team_preview->the_post();
                        get_template_part('template-parts/content/card-team');
                    endwhile;
                    wp_reset_postdata();
                else :
                    ?>
                    <p><?php esc_html_e('Team profiles are being prepared. Please check back soon.', 'aurion-energy'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php get_template_part('template-parts/cta/cta-partner'); ?>
</main>
<?php
get_footer();
?>