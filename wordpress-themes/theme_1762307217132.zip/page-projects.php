<?php
defined('ABSPATH') || exit;
/*
Template Name: Projects Archive
*/
get_header();
?>
<main id="primary">
    <?php get_template_part('template-parts/hero/hero-title-only'); ?>
    <section class="section container">
        <?php get_template_part('template-parts/content/breadcrumbs'); ?>
        <?php
        $project_types = get_terms(array('taxonomy' => 'project_type', 'hide_empty' => true));
        if (!empty($project_types) && !is_wp_error($project_types)) :
            ?>
            <form method="get" class="project-filter" data-aos="fade-up">
                <label for="project-type"><?php esc_html_e('Filter by Project Type', 'aurion-energy'); ?></label>
                <select id="project-type" name="type" onchange="this.form.submit()">
                    <option value=""><?php esc_html_e('All Project Types', 'aurion-energy'); ?></option>
                    <?php foreach ($project_types as $type) : ?>
                        <option value="<?php echo esc_attr($type->slug); ?>" <?php selected(isset($_GET['type']) ? sanitize_text_field(wp_unslash($_GET['type'])) : '', $type->slug); ?>>
                            <?php echo esc_html($type->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        <?php endif; ?>

        <?php
        $args = array(
            'post_type' => 'project',
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
        );
        if (!empty($_GET['type'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'project_type',
                    'field' => 'slug',
                    'terms' => sanitize_text_field(wp_unslash($_GET['type']))
                )
            );
        }
        $projects = new WP_Query($args);
        ?>
        <div class="featured-projects__grid">
            <?php if ($projects->have_posts()) : ?>
                <?php while ($projects->have_posts()) : $projects->the_post(); ?>
                    <?php get_template_part('template-parts/content/card-project'); ?>
                <?php endwhile; ?>
            <?php else : ?>
                <p><?php esc_html_e('Project case studies will be available shortly.', 'aurion-energy'); ?></p>
            <?php endif; ?>
        </div>
        <?php aurion_pagination($projects); ?>
        <?php wp_reset_postdata(); ?>
    </section>
</main>
<?php
get_footer();
?>