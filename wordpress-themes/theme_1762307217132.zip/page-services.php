<?php
defined('ABSPATH') || exit;
/*
Template Name: Services Page
*/
get_header();
?>
<main id="primary">
    <?php get_template_part('template-parts/hero/hero-title-only'); ?>
    <section class="section container">
        <?php get_template_part('template-parts/content/breadcrumbs'); ?>
        <p><?php esc_html_e('Aurion Energy Advisory delivers a comprehensive suite of energy consulting, industrial engineering, and oilfield research services tailored for Canadian operators. Explore our core service lines below.', 'aurion-energy'); ?></p>
        <div class="grid grid--three">
            <?php
            $services = array(
                array(
                    'title' => __('Energy Consulting', 'aurion-energy'),
                    'description' => __('Strategic planning, feasibility assessments, and integrated risk evaluation for energy infrastructure investments across Canada.', 'aurion-energy'),
                    'icon' => 'dashicons-lightbulb'
                ),
                array(
                    'title' => __('Oilfield Research', 'aurion-energy'),
                    'description' => __('Reservoir analytics, production optimization, and environmental monitoring programs to support oil and gas operations.', 'aurion-energy'),
                    'icon' => 'dashicons-admin-site-alt3'
                ),
                array(
                    'title' => __('Installation & Heavy-Lift Services', 'aurion-energy'),
                    'description' => __('Execution support for crane installation, rigging supervision, and heavy-lift coordination on industrial sites.', 'aurion-energy'),
                    'icon' => 'dashicons-admin-generic'
                ),
                array(
                    'title' => __('Environmental Assessment', 'aurion-energy'),
                    'description' => __('Baseline studies, impact assessments, and mitigation planning aligned with provincial and federal regulations.', 'aurion-energy'),
                    'icon' => 'dashicons-admin-site'
                ),
                array(
                    'title' => __('Project Management', 'aurion-energy'),
                    'description' => __('Integrated project controls, scheduling, and multidisciplinary coordination from concept through commissioning.', 'aurion-energy'),
                    'icon' => 'dashicons-calendar-alt'
                ),
                array(
                    'title' => __('Custom Solutions', 'aurion-energy'),
                    'description' => __('Tailored engineering and consulting packages for unique industrial challenges and emerging technologies.', 'aurion-energy'),
                    'icon' => 'dashicons-hammer'
                )
            );
            foreach ($services as $service) {
                get_template_part('template-parts/content/card-service', null, $service);
            }
            ?>
        </div>
    </section>

    <section class="section section--light">
        <div class="container">
            <h2><?php esc_html_e('Service Comparison', 'aurion-energy'); ?></h2>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Service', 'aurion-energy'); ?></th>
                            <th><?php esc_html_e('Focus Areas', 'aurion-energy'); ?></th>
                            <th><?php esc_html_e('Deliverables', 'aurion-energy'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php esc_html_e('Energy Consulting', 'aurion-energy'); ?></td>
                            <td><?php esc_html_e('Strategy, regulatory readiness, risk mitigation', 'aurion-energy'); ?></td>
                            <td><?php esc_html_e('Roadmaps, cost-benefit analysis, permitting plans', 'aurion-energy'); ?></td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e('Oilfield Research', 'aurion-energy'); ?></td>
                            <td><?php esc_html_e('Reservoir performance, emissions monitoring', 'aurion-energy'); ?></td>
                            <td><?php esc_html_e('Data models, compliance reports, technology pilots', 'aurion-energy'); ?></td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e('Installation & Heavy-Lift', 'aurion-energy'); ?></td>
                            <td><?php esc_html_e('Crane engineering, rigging supervision', 'aurion-energy'); ?></td>
                            <td><?php esc_html_e('Lift plans, safety documentation, execution oversight', 'aurion-energy'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <section class="section container">
        <div class="section__header">
            <h2 class="section__title"><?php esc_html_e('Our Process', 'aurion-energy'); ?></h2>
        </div>
        <div class="grid grid--four">
            <article class="card">
                <h3><?php esc_html_e('1. Discover', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('Collaborate with stakeholders to define objectives, constraints, and regulatory context.', 'aurion-energy'); ?></p>
            </article>
            <article class="card">
                <h3><?php esc_html_e('2. Design', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('Develop engineering models, research frameworks, and risk-informed project plans.', 'aurion-energy'); ?></p>
            </article>
            <article class="card">
                <h3><?php esc_html_e('3. Deliver', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('Oversee field execution, logistics, and commissioning with disciplined controls.', 'aurion-energy'); ?></p>
            </article>
            <article class="card">
                <h3><?php esc_html_e('4. Optimize', 'aurion-energy'); ?></h3>
                <p><?php esc_html_e('Monitor outcomes, capture lessons learned, and implement continuous improvements.', 'aurion-energy'); ?></p>
            </article>
        </div>
    </section>

    <section class="section section--light">
        <div class="container">
            <h2><?php esc_html_e('Client Feedback', 'aurion-energy'); ?></h2>
            <div class="grid grid--three">
                <?php
                $service_testimonials = new WP_Query(array(
                    'post_type' => 'testimonial',
                    'posts_per_page' => 3
                ));
                if ($service_testimonials->have_posts()) :
                    while ($service_testimonials->have_posts()) :
                        $service_testimonials->the_post();
                        get_template_part('template-parts/content/card-testimonial');
                    endwhile;
                    wp_reset_postdata();
                else :
                    ?>
                    <article class="card card--testimonial">
                        <p><?php esc_html_e('Service-specific testimonials are coming soon.', 'aurion-energy'); ?></p>
                    </article>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="section container" data-aos="fade-up">
        <div class="card">
            <h2><?php esc_html_e('Discuss Your Project', 'aurion-energy'); ?></h2>
            <p><?php esc_html_e('Our consultants are ready to support your next industrial project with tailored solutions and proven expertise.', 'aurion-energy'); ?></p>
            <a class="button" href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact Aurion', 'aurion-energy'); ?></a>
        </div>
    </section>
</main>
<?php
get_footer();
?>