<?php
defined('ABSPATH') || exit;
/*
Template Name: Privacy Policy
*/
get_header();
?>
<main id="primary">
    <?php get_template_part('template-parts/hero/hero-title-only'); ?>
    <section class="section container print-friendly">
        <?php get_template_part('template-parts/content/breadcrumbs'); ?>
        <article class="post-content">
            <?php while (have_posts()) : the_post(); ?>
                <?php the_content(); ?>
            <?php endwhile; ?>
        </article>
    </section>
</main>
<?php
get_footer();
?>