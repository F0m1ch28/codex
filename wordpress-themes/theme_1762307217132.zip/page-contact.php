<?php
defined('ABSPATH') || exit;
/*
Template Name: Contact Page
*/
get_header();
?>
<main id="primary">
    <?php get_template_part('template-parts/hero/hero-title-only'); ?>
    <section class="section container">
        <?php get_template_part('template-parts/content/breadcrumbs'); ?>
        <div class="split">
            <div data-aos="fade-right">
                <?php get_template_part('template-parts/forms/form-contact'); ?>
            </div>
            <div data-aos="fade-left">
                <div class="card">
                    <h2><?php esc_html_e('Contact Information', 'aurion-energy'); ?></h2>
                    <p><strong><?php esc_html_e('Address:', 'aurion-energy'); ?></strong><br><?php echo esc_html(aurion_get_theme_mod('contact_address', '460 Bay St, Toronto, ON M5H 2Y4, Canada')); ?></p>
                    <p><strong><?php esc_html_e('Phone:', 'aurion-energy'); ?></strong><br><a href="tel:<?php echo esc_attr(aurion_sanitize_phone(aurion_get_theme_mod('contact_phone', '+1 (416) 792-4583'))); ?>"><?php echo esc_html(aurion_get_theme_mod('contact_phone', '+1 (416) 792-4583')); ?></a></p>
                    <p><strong><?php esc_html_e('Email:', 'aurion-energy'); ?></strong><br><a href="mailto:<?php echo esc_attr(aurion_get_theme_mod('contact_email', 'info@aurionenergy.com')); ?>"><?php echo esc_html(aurion_get_theme_mod('contact_email', 'info@aurionenergy.com')); ?></a></p>
                    <?php
                    $linkedin = aurion_get_theme_mod('contact_linkedin', '');
                    if ($linkedin) :
                        ?>
                        <p><strong><?php esc_html_e('LinkedIn:', 'aurion-energy'); ?></strong><br><a href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Aurion Energy Advisory on LinkedIn', 'aurion-energy'); ?></a></p>
                    <?php endif; ?>
                    <p><strong><?php esc_html_e('Business Hours:', 'aurion-energy'); ?></strong><br><?php echo esc_html(aurion_get_theme_mod('contact_hours', __('Monday to Friday: 8 AM – 6 PM', 'aurion-energy'))); ?></p>
                </div>
                <div class="map-embed" data-aos="fade-up">
                    <iframe title="<?php esc_attr_e('Aurion Energy Advisory location map', 'aurion-energy'); ?>" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.3155755781205!2d-79.38422242351867!3d43.651748257757806!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d18cf38d53%3A0x62b8af5120a0610!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1700000000000" width="100%" height="360" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </section>
</main>
<?php
get_footer();
?>