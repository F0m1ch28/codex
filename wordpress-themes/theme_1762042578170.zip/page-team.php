<?php
/**
 * Template Name: Team
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero team-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>Meet the leaders who guide Aurion’s advisory, engineering, and research efforts.</p>
	</div>
</section>

<section class="page-content container team-grid">
	<article class="team-card">
		<img src="https://picsum.photos/800/600?random=601" alt="Portrait of Maya Thompson Aurion Energy Advisory">
		<h2>Maya Thompson</h2>
		<p class="team-role">Managing Partner</p>
		<p>Maya oversees strategic direction and client delivery. With more than 20 years in energy project leadership, she specializes in aligning corporate objectives with practical site execution.</p>
	</article>
	<article class="team-card">
		<img src="https://picsum.photos/800/600?random=602" alt="Portrait of Daniel Chen Aurion Energy Advisory">
		<h2>Daniel Chen, P.Eng.</h2>
		<p class="team-role">Director of Engineering</p>
		<p>Daniel leads the mechanical and structural engineering team, focusing on heavy lift planning, equipment integration, and commissioning leadership for complex builds.</p>
	</article>
	<article class="team-card">
		<img src="https://picsum.photos/800/600?random=603" alt="Portrait of Aisha Malik Aurion Energy Advisory">
		<h2>Aisha Malik</h2>
		<p class="team-role">Principal Research Scientist</p>
		<p>Aisha directs field research programs, blending reservoir analytics with real-time monitoring insights to help clients enhance performance and safety.</p>
	</article>
	<article class="team-card">
		<img src="https://picsum.photos/800/600?random=604" alt="Portrait of Marc Levesque Aurion Energy Advisory">
		<h2>Marc Levesque, PMP</h2>
		<p class="team-role">Program Manager</p>
		<p>Marc ensures multi-site initiatives stay aligned, coordinating contractors, logistics, and stakeholder reporting across Canada.</p>
	</article>
</section>
<?php
get_footer();