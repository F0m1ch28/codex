<?php
/**
 * Template Name: Projects
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero projects-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>A snapshot of recent engagements showcasing our approach and measurable outcomes.</p>
	</div>
</section>

<section class="page-content container projects-list">
	<article class="project-card">
		<img src="https://picsum.photos/800/600?random=501" alt="Aurion team managing compressor station upgrade">
		<div class="project-card__content">
			<h2>Compressor Station Modernization</h2>
			<p>Coordinated mechanical redesign, vibration analysis, and commissioning for a major compressor station in Alberta, improving reliability and reducing maintenance interruptions.</p>
			<ul class="project-details">
				<li><strong>Scope:</strong> Mechanical redesign, vibration diagnostics, commissioning oversight</li>
				<li><strong>Outcome:</strong> Increased throughput stability and optimized maintenance intervals</li>
			</ul>
		</div>
	</article>

	<article class="project-card">
		<img src="https://picsum.photos/800/600?random=502" alt="Aurion engineers planning an industrial crane installation">
		<div class="project-card__content">
			<h2>Heavy Lift Program Management</h2>
			<p>Delivered lift studies, contractor coordination, and safety supervision for crane operations supporting a refinery infrastructure expansion in Ontario.</p>
			<ul class="project-details">
				<li><strong>Scope:</strong> Lift planning, field supervision, compliance assurance</li>
				<li><strong>Outcome:</strong> Zero incidents and schedule certainty across critical lifts</li>
			</ul>
		</div>
	</article>

	<article class="project-card">
		<img src="https://picsum.photos/800/600?random=503" alt="Control room operators using systems implemented by Aurion">
		<div class="project-card__content">
			<h2>Control System Refresh</h2>
			<p>Managed the rollout of upgraded automation software, alarm rationalization, and operator training for a petrochemical control room.</p>
			<ul class="project-details">
				<li><strong>Scope:</strong> Automation planning, training, commissioning support</li>
				<li><strong>Outcome:</strong> Streamlined operator workflows and improved situational awareness</li>
			</ul>
		</div>
	</article>
</section>
<?php
get_footer();