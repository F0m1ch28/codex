<?php
/**
 * Template Name: About Aurion
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero about-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>Aurion Energy Advisory is grounded in decades of field experience, engineering knowledge, and a commitment to collaborative delivery.</p>
	</div>
</section>

<section class="page-content container">
	<div class="two-column">
		<div>
			<h2>Who We Are</h2>
			<p>Headquartered in Toronto, Aurion Energy Advisory serves clients across Canada’s industrial landscape. Our team blends engineering disciplines, project management, and operational analysis to steer major initiatives toward safe and dependable outcomes.</p>
			<p>We operate as an extension of your team, closing gaps between strategic direction and the realities of implementation. That philosophy shapes how we recruit, mentor, and deploy experts to every assignment.</p>
		</div>
		<div>
			<img src="https://picsum.photos/800/600?random=401" alt="Aurion leadership team meeting in Toronto office">
		</div>
	</div>

	<div class="values-section">
		<h2>Guiding Principles</h2>
		<div class="values-grid">
			<div class="value-card">
				<h3>Field-Tested Thinking</h3>
				<p>Our insights are built on lessons learned in active facilities, construction sites, and remote operations.</p>
			</div>
			<div class="value-card">
				<h3>Transparent Collaboration</h3>
				<p>Decisions are documented and communicated in plain language, building trust among all project stakeholders.</p>
			</div>
			<div class="value-card">
				<h3>Continuous Improvement</h3>
				<p>We embrace new technologies and methodologies that enhance safety, reliability, and sustainability.</p>
			</div>
		</div>
	</div>

	<div class="timeline-section">
		<h2>Milestones</h2>
		<ul class="timeline">
			<li>
				<span class="timeline-year">2012</span>
				<p>Founding team launches Aurion with a focus on oilfield research and engineering advisory services.</p>
			</li>
			<li>
				<span class="timeline-year">2016</span>
				<p>Expanded capabilities to include large-scale crane installation oversight and power systems engineering.</p>
			</li>
			<li>
				<span class="timeline-year">2020</span>
				<p>Introduced remote monitoring analytics, supporting clients through adaptive work models.</p>
			</li>
			<li>
				<span class="timeline-year">2023</span>
				<p>Strengthened sustainability and emissions planning services to support emerging regulatory expectations.</p>
			</li>
		</ul>
	</div>
</section>
<?php
get_footer();