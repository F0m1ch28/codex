document.addEventListener('DOMContentLoaded', function () {
	const navigation = document.querySelector('.primary-navigation');
	const menuToggle = document.querySelector('.menu-toggle');

	if (menuToggle && navigation) {
		menuToggle.addEventListener('click', function () {
			const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
			menuToggle.setAttribute('aria-expanded', !isExpanded);
			navigation.classList.toggle('is-open');
		});

		navigation.addEventListener('click', function (event) {
			if (event.target.tagName === 'A' && navigation.classList.contains('is-open')) {
				navigation.classList.remove('is-open');
				menuToggle.setAttribute('aria-expanded', 'false');
			}
		});
	}

	const scrollButton = document.getElementById('scrollToTop');
	if (scrollButton) {
		window.addEventListener('scroll', function () {
			if (window.scrollY > 400) {
				scrollButton.classList.add('show');
			} else {
				scrollButton.classList.remove('show');
			}
		});

		scrollButton.addEventListener('click', function () {
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	}

	const cookieBanner = document.getElementById('cookie-banner');
	const cookieAccept = document.getElementById('cookie-accept');
	const cookieKey = (window.aurionData && window.aurionData.cookieKey) ? window.aurionData.cookieKey : 'aurionCookieAccepted';

	if (cookieBanner && cookieAccept) {
		if (!localStorage.getItem(cookieKey)) {
			cookieBanner.style.display = 'block';
		}

		cookieAccept.addEventListener('click', function () {
			localStorage.setItem(cookieKey, 'true');
			cookieBanner.style.display = 'none';
		});
	}

	const slider = document.querySelector('[data-slider]');
	if (slider) {
		const slides = Array.from(slider.querySelectorAll('.slide'));
		const dotsContainer = slider.querySelector('.slider-dots');
		let activeIndex = 0;

		const renderDots = () => {
			slides.forEach(function (_slide, index) {
				const dot = document.createElement('button');
				dot.setAttribute('type', 'button');
				dot.setAttribute('aria-label', 'Display slide ' + (index + 1));
				if (index === 0) {
					dot.classList.add('is-active');
				}
				dot.addEventListener('click', function () {
					updateSlide(index);
				});
				dotsContainer.appendChild(dot);
			});
		};

		const updateSlide = (newIndex) => {
			slides[activeIndex].classList.remove('is-active');
			dotsContainer.children[activeIndex].classList.remove('is-active');
			slides[newIndex].classList.add('is-active');
			dotsContainer.children[newIndex].classList.add('is-active');
			activeIndex = newIndex;
		};

		const autoAdvance = () => {
			const nextIndex = (activeIndex + 1) % slides.length;
			updateSlide(nextIndex);
		};

		if (slides.length > 1) {
			renderDots();
			setInterval(autoAdvance, 6000);
		}
	}
});