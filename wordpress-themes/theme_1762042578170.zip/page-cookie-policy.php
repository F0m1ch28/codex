<?php
/**
 * Template Name: Cookie Policy
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero legal-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>Learn how Aurion Energy Advisory uses cookies and similar technologies.</p>
	</div>
</section>

<section class="page-content container legal-content">
	<h2>1. What Are Cookies?</h2>
	<p>Cookies are small text files stored on your device when you visit a website. They help remember preferences, support essential functionality, and provide analytics insights.</p>

	<h2>2. Types of Cookies We Use</h2>
	<ul>
		<li><strong>Essential Cookies:</strong> Enable core features such as page navigation and secure access.</li>
		<li><strong>Performance Cookies:</strong> Collect anonymous data about how visitors interact with the site to inform improvements.</li>
		<li><strong>Functional Cookies:</strong> Remember selections that enhance your browsing experience.</li>
	</ul>

	<h2>3. Managing Cookies</h2>
	<p>You can adjust cookie settings through your browser preferences. Please note that disabling certain cookies may affect how the site functions.</p>

	<h2>4. Third-Party Cookies</h2>
	<p>We may use third-party services, such as analytics providers, that place cookies on our site to deliver aggregated usage information.</p>

	<h2>5. Consent</h2>
	<p>Upon your first visit, you are presented with a banner requesting consent for non-essential cookies. You can withdraw consent at any time by clearing your browser cookies.</p>

	<h2>6. Contact</h2>
	<p>For questions about this Cookie Policy, email <a href="mailto:privacy@aurionenergy.com">privacy@aurionenergy.com</a>.</p>
</section>
<?php
get_footer();