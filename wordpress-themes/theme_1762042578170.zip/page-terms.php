<?php
/**
 * Template Name: Terms of Use
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero legal-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>Understand the terms that govern your use of the Aurion Energy Advisory website.</p>
	</div>
</section>

<section class="page-content container legal-content">
	<h2>1. Acceptance of Terms</h2>
	<p>By accessing aurionenergy.com, you agree to comply with these terms of use. If you do not agree, please discontinue your use of the site.</p>

	<h2>2. Use of Content</h2>
	<p>Materials published on this website are provided for general information. You may not reproduce, modify, or distribute any content without prior written consent from Aurion Energy Advisory.</p>

	<h2>3. Professional Services</h2>
	<p>Website content does not constitute engineering or advisory services. Formal engagements are subject to specific contracts and scopes agreed upon between Aurion Energy Advisory and the client.</p>

	<h2>4. User Responsibilities</h2>
	<p>You agree not to introduce malware, disrupt site operations, or attempt unauthorized access to systems connected to aurionenergy.com.</p>

	<h2>5. Third-Party Links</h2>
	<p>Links to external websites are provided for convenience. Aurion Energy Advisory does not control and is not responsible for the content or practices of third-party sites.</p>

	<h2>6. Limitation of Liability</h2>
	<p>We strive to ensure the accuracy of the information provided, but we make no warranties regarding completeness or suitability. Aurion Energy Advisory is not liable for any losses arising from use of this site.</p>

	<h2>7. Governing Law</h2>
	<p>These terms are governed by the laws of the Province of Ontario and the laws of Canada applicable therein.</p>

	<h2>8. Updates</h2>
	<p>We may revise these terms without notice. Continued use of the site after changes are posted indicates acceptance of the revised terms.</p>

	<h2>9. Contact</h2>
	<p>Questions about these terms can be sent to <a href="mailto:info@aurionenergy.com">info@aurionenergy.com</a>.</p>
</section>
<?php
get_footer();