<?php
/**
 * Front page template.
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="hero-section">
	<div class="hero-image">
		<img src="https://picsum.photos/1200/800?random=301" alt="Aurion engineers overseeing Canadian energy infrastructure">
	</div>
	<div class="hero-content container">
		<h1>Reliable Advisory for Canada’s Industrial Energy Future</h1>
		<p>Aurion Energy Advisory helps operators design, modernize, and monitor infrastructure that must perform in demanding environments.</p>
		<a class="btn-primary" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>">Discuss Your Project</a>
	</div>
</section>

<section class="intro-section container">
	<div class="intro-text">
		<h2>Built on Field Experience and Analytical Rigor</h2>
		<p>We combine engineering expertise with in-depth research to guide organizations through the complete lifecycle of large-scale energy systems. From feasibility to commissioning, we ensure every phase aligns with operational requirements and regulatory expectations.</p>
	</div>
	<div class="intro-highlights">
		<div class="highlight-card">
			<h3>Multi-Disciplinary Insight</h3>
			<p>Mechanical, electrical, and process specialists collaborate to evaluate challenges across asset portfolios.</p>
		</div>
		<div class="highlight-card">
			<h3>Data-Driven Decisions</h3>
			<p>Field intelligence, modelling, and testing support resilient plans for remote and urban environments alike.</p>
		</div>
	</div>
</section>

<section class="expertise-section">
	<div class="container section-header">
		<h2>Core Expertise</h2>
		<p>Strategic advisory and hands-on engineering support for complex industrial operations.</p>
	</div>
	<div class="expertise-grid container">
		<article class="expertise-item">
			<img src="https://picsum.photos/800/600?random=302" alt="Aurion consultant reviewing energy control systems">
			<h3>Energy Strategy Alignment</h3>
			<p>Translating corporate goals into operational plans that consider permitting, integration, and asset lifecycle implications.</p>
		</article>
		<article class="expertise-item">
			<img src="https://picsum.photos/800/600?random=303" alt="Industrial engineers evaluating pipeline schematics">
			<h3>Engineering Program Management</h3>
			<p>Coordinating multidisciplinary workstreams, contractor oversight, and commissioning readiness for large builds and retrofits.</p>
		</article>
		<article class="expertise-item">
			<img src="https://picsum.photos/800/600?random=304" alt="Oilfield research team assessing drilling data in Canada">
			<h3>Operational Analytics</h3>
			<p>Applying instrumentation data, diagnostics, and on-site assessments to optimize performance and mitigate unplanned downtime.</p>
		</article>
	</div>
</section>

<section class="oilfield-section container">
	<div class="section-header">
		<h2>Oilfield Research Advantage</h2>
		<p>Targeted studies that solve immediate field challenges while informing long-range capital priorities.</p>
	</div>
	<div class="split-grid">
		<div>
			<ul class="feature-list">
				<li>Reservoir and drilling data interpretation guided by field-proven methodologies.</li>
				<li>Evaluation of lifting equipment, cranes, and rigs to maintain safe operational envelopes.</li>
				<li>Remote monitoring frameworks that deliver actionable intelligence to control rooms.</li>
			</ul>
		</div>
		<div>
			<img src="https://picsum.photos/800/600?random=305" alt="Aurion field researchers inspecting oilfield lifting systems">
		</div>
	</div>
</section>

<section class="engineering-section">
	<div class="container section-header">
		<h2>Engineering Solutions</h2>
		<p>Integrating design, construction, and commissioning expertise into reliable delivery plans.</p>
	</div>
	<div class="container split-grid reverse">
		<div>
			<img src="https://picsum.photos/800/600?random=306" alt="Engineering team planning crane installation for industrial facility">
		</div>
		<div>
			<h3>What We Deliver</h3>
			<p>Our engineers develop specifications for new builds and upgrades, coordinate vendor qualifications, and provide on-site leadership during installation and start-up. Every deliverable is mapped to the realities of your site.</p>
			<ul class="feature-list">
				<li>Mechanical and structural design packages tailored to harsh climates.</li>
				<li>Electrical systems planning for high-demand industrial environments.</li>
				<li>Commissioning protocols that ensure safe ramp-up and stakeholder confidence.</li>
			</ul>
		</div>
	</div>
</section>

<section class="sustainability-section container">
	<div class="section-header">
		<h2>Sustainability in Practice</h2>
		<p>Embedding responsible energy choices within operational and maintenance programs.</p>
	</div>
	<div class="sustainability-grid">
		<div class="s-card">
			<h3>Efficiency Assessments</h3>
			<p>Benchmarking legacy systems against modern standards to prioritize upgrades that reduce energy intensity.</p>
		</div>
		<div class="s-card">
			<h3>Emissions Planning</h3>
			<p>Scenario modelling and mitigation strategies aligned with Canadian regulatory pathways.</p>
		</div>
		<div class="s-card">
			<h3>Lifecycle Stewardship</h3>
			<p>Maintenance planning that extends asset performance while supporting environmental goals.</p>
		</div>
	</div>
</section>

<section class="projects-section">
	<div class="container section-header">
		<h2>Representative Projects</h2>
		<p>Delivering measurable improvements from northern field sites to urban industrial hubs.</p>
	</div>
	<div class="aurion-slider container" data-slider>
		<div class="slide is-active">
			<img src="https://picsum.photos/1200/800?random=307" alt="Pipeline integrity upgrade led by Aurion engineers">
			<div class="slide-caption">
				<h3>Pipeline Integrity Upgrade</h3>
				<p>Directed assessment and remediation work for a midstream operator, improving throughput reliability while meeting regulatory checkpoints.</p>
			</div>
		</div>
		<div class="slide">
			<img src="https://picsum.photos/1200/800?random=308" alt="Aurion advisory supporting industrial microgrid deployment">
			<div class="slide-caption">
				<h3>Industrial Microgrid Deployment</h3>
				<p>Guided design integration, vendor coordination, and commissioning oversight for a remote facility microgrid in northern Ontario.</p>
			</div>
		</div>
		<div class="slide">
			<img src="https://picsum.photos/1200/800?random=309" alt="Control room modernization project managed by Aurion Energy Advisory">
			<div class="slide-caption">
				<h3>Control Room Modernization</h3>
				<p>Delivered human-centered layout improvements, alarm rationalization, and software upgrades for a downstream control centre.</p>
			</div>
		</div>
		<div class="slider-dots" role="tablist" aria-label="Project highlights"></div>
	</div>
</section>

<section class="testimonials-section">
	<div class="container section-header">
		<h2>Voices from the Field</h2>
		<p>Leaders trust Aurion because we work alongside their teams every step of the way.</p>
	</div>
	<div class="testimonial-grid container">
		<blockquote class="testimonial-card">
			<p>“Aurion’s advisors embedded with our operations group and helped us chart a practical path for a complex brownfield expansion.”</p>
			<cite>Operations Director, Western Canadian Producer</cite>
		</blockquote>
		<blockquote class="testimonial-card">
			<p>“Their engineering team coordinated multiple contractors seamlessly, keeping our schedule intact despite extreme weather shifts.”</p>
			<cite>Capital Projects Lead, Utility Client</cite>
		</blockquote>
		<blockquote class="testimonial-card">
			<p>“Our control team now receives timely insights thanks to the monitoring framework Aurion designed and commissioned.”</p>
			<cite>Maintenance Manager, Refining Facility</cite>
		</blockquote>
	</div>
</section>

<section class="cta-section">
	<div class="container cta-content">
		<h2>Ready to Move from Concept to Commissioning?</h2>
		<p>Connect with our Toronto-based advisors to align strategy, engineering, and field execution.</p>
		<a class="btn-secondary" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>">Connect with Aurion</a>
	</div>
</section>
<?php
get_footer();