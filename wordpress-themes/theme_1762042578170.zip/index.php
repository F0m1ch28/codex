<?php
/**
 * Default template.
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="archive-hero">
	<div class="container">
		<h1><?php wp_title( '' ); ?></h1>
		<p><?php esc_html_e( 'Latest insights and updates from Aurion Energy Advisory.', 'aurion-energy' ); ?></p>
	</div>
</section>

<section class="content-area">
	<div class="container content-grid">
		<?php if ( have_posts() ) : ?>
			<div class="post-list">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'card' ); ?>>
						<a class="card-media" href="<?php the_permalink(); ?>">
							<?php
							if ( has_post_thumbnail() ) {
								the_post_thumbnail( 'medium_large', array( 'alt' => esc_attr( get_the_title() ) ) );
							} else {
								?>
								<img src="https://picsum.photos/800/600?random=201" alt="<?php echo esc_attr( get_bloginfo( 'name' ) . ' editorial placeholder image' ); ?>">
								<?php
							}
							?>
						</a>
						<div class="card-content">
							<h2 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<p class="card-meta"><?php echo esc_html( get_the_date() ); ?></p>
							<p><?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 28, '...' ) ); ?></p>
							<a class="btn-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Continue Reading', 'aurion-energy' ); ?></a>
						</div>
					</article>
					<?php
				endwhile;

				the_posts_pagination(
					array(
						'prev_text' => __( 'Previous', 'aurion-energy' ),
						'next_text' => __( 'Next', 'aurion-energy' ),
					)
				);
				?>
			</div>
			<?php get_sidebar(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'No posts found.', 'aurion-energy' ); ?></p>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();