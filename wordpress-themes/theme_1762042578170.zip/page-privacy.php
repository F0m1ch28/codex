<?php
/**
 * Template Name: Privacy Policy
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero legal-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>How Aurion Energy Advisory collects, uses, and safeguards personal information.</p>
	</div>
</section>

<section class="page-content container legal-content">
	<h2>1. Information We Collect</h2>
	<p>We gather contact details submitted via forms, emails, and phone calls. We also collect technical data such as IP addresses, browser type, and pages visited to understand site performance.</p>

	<h2>2. Use of Information</h2>
	<p>Personal information is used to respond to inquiries, manage client relationships, and improve the website. We may analyze aggregated data to understand user behavior and enhance content relevance.</p>

	<h2>3. Sharing of Information</h2>
	<p>We do not sell or lease personal data. Information may be shared with trusted service providers who help us operate the site or deliver services, subject to confidentiality obligations.</p>

	<h2>4. Data Security</h2>
	<p>We implement administrative, technical, and physical safeguards to protect personal information against unauthorized access, alteration, or disclosure.</p>

	<h2>5. Retention</h2>
	<p>Information is retained as long as necessary to fulfill the purposes outlined in this policy or as required by law.</p>

	<h2>6. Your Choices</h2>
	<p>You may request access to your personal information or ask for corrections by contacting <a href="mailto:privacy@aurionenergy.com">privacy@aurionenergy.com</a>.</p>

	<h2>7. International Transfers</h2>
	<p>Data may be stored or processed in jurisdictions outside your province. We take steps to ensure appropriate protections are in place.</p>

	<h2>8. Updates</h2>
	<p>We may revise this policy to reflect changes in our practices or legal requirements. The revised policy will be posted with an updated effective date.</p>

	<h2>9. Contact</h2>
	<p>Questions regarding privacy can be directed to: Aurion Energy Advisory, 460 Bay St, Toronto, ON M5H 2Y4, Canada or <a href="mailto:privacy@aurionenergy.com">privacy@aurionenergy.com</a>.</p>
</section>
<?php
get_footer();