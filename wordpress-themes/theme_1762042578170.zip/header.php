<?php
/**
 * Header template.
 *
 * @package Aurion_Energy_Advisory
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#primary-content"><?php esc_html_e( 'Skip to content', 'aurion-energy' ); ?></a>
<header class="site-header" role="banner">
	<div class="container header-inner">
		<div class="site-branding">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				?>
				<a class="site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
				<?php
			}
			?>
		</div>
		<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
			<span class="menu-icon" aria-hidden="true"></span>
			<span class="menu-label"><?php esc_html_e( 'Menu', 'aurion-energy' ); ?></span>
		</button>
		<nav id="site-navigation" class="primary-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary menu', 'aurion-energy' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_id'        => 'primary-menu',
					'menu_class'     => 'menu reset-list',
					'container'      => false,
					'fallback_cb'    => 'aurion_fallback_menu',
				)
			);
			?>
		</nav>
	</div>
</header>
<main id="primary-content" class="site-main" tabindex="-1">

<?php
/**
 * Fallback for primary menu.
 */
function aurion_fallback_menu() {
	echo '<ul class="menu reset-list">';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
		)
	);
	echo '</ul>';
}
?>