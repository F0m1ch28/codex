<?php
/**
 * Template Name: Contact
 *
 * @package Aurion_Energy_Advisory
 */

$errors  = array();
$success = '';
$name    = '';
$email   = '';
$company = '';
$message = '';

if ( isset( $_POST['aurion_contact_nonce'] ) && wp_verify_nonce( wp_unslash( $_POST['aurion_contact_nonce'] ), 'aurion_contact_form' ) ) {
	$name    = sanitize_text_field( wp_unslash( $_POST['aurion_name'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $_POST['aurion_email'] ?? '' ) );
	$company = sanitize_text_field( wp_unslash( $_POST['aurion_company'] ?? '' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['aurion_message'] ?? '' ) );

	if ( empty( $name ) ) {
		$errors['name'] = __( 'Please enter your name.', 'aurion-energy' );
	}

	if ( empty( $email ) || ! is_email( $email ) ) {
		$errors['email'] = __( 'Please provide a valid email address.', 'aurion-energy' );
	}

	if ( empty( $message ) ) {
		$errors['message'] = __( 'Please include a brief summary of your needs.', 'aurion-energy' );
	}

	if ( empty( $errors ) ) {
		$admin_email = get_option( 'admin_email' );
		$subject     = 'New inquiry from Aurion Energy Advisory website';
		$body        = "Name: {$name}\nEmail: {$email}\nCompany: {$company}\n\nMessage:\n{$message}";
		$headers     = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

		if ( wp_mail( $admin_email, $subject, $body, $headers ) ) {
			$success = __( 'Thank you for reaching out. Our team will follow up shortly.', 'aurion-energy' );
			$name    = '';
			$email   = '';
			$company = '';
			$message = '';
		} else {
			$errors['general'] = __( 'We were unable to send your message. Please try again later.', 'aurion-energy' );
		}
	}
}

get_header();
?>
<section class="page-hero contact-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>Let’s explore how Aurion Energy Advisory can support your next project.</p>
	</div>
</section>

<section class="page-content container contact-grid">
	<div class="contact-details">
		<h2>Head Office</h2>
		<p>460 Bay St<br>Toronto, ON M5H 2Y4, Canada</p>
		<p><strong>Phone:</strong> <a href="tel:+14167924583">+1 (416) 792-4583</a></p>
		<p><strong>Email:</strong> <a href="mailto:info@aurionenergy.com">info@aurionenergy.com</a></p>
		<h3>Office Hours</h3>
		<p>Monday – Friday<br>8:00 a.m. – 6:00 p.m. ET</p>
		<img src="https://picsum.photos/800/600?random=701" alt="Aurion Energy Advisory Toronto office exterior">
	</div>
	<div class="contact-form-wrapper">
		<h2>Send Us a Message</h2>
		<?php if ( ! empty( $success ) ) : ?>
			<div class="notice success"><?php echo esc_html( $success ); ?></div>
		<?php endif; ?>

		<?php if ( isset( $errors['general'] ) ) : ?>
			<div class="notice error"><?php echo esc_html( $errors['general'] ); ?></div>
		<?php endif; ?>

		<form class="contact-form" method="post" action="<?php echo esc_url( get_permalink() ); ?>" novalidate>
			<div class="form-group">
				<label for="aurion_name">Name <span aria-hidden="true">*</span></label>
				<input type="text" id="aurion_name" name="aurion_name" value="<?php echo esc_attr( $name ); ?>" required>
				<?php if ( isset( $errors['name'] ) ) : ?>
					<p class="form-error"><?php echo esc_html( $errors['name'] ); ?></p>
				<?php endif; ?>
			</div>
			<div class="form-group">
				<label for="aurion_email">Email <span aria-hidden="true">*</span></label>
				<input type="email" id="aurion_email" name="aurion_email" value="<?php echo esc_attr( $email ); ?>" required>
				<?php if ( isset( $errors['email'] ) ) : ?>
					<p class="form-error"><?php echo esc_html( $errors['email'] ); ?></p>
				<?php endif; ?>
			</div>
			<div class="form-group">
				<label for="aurion_company">Company</label>
				<input type="text" id="aurion_company" name="aurion_company" value="<?php echo esc_attr( $company ); ?>">
			</div>
			<div class="form-group">
				<label for="aurion_message">How can we help? <span aria-hidden="true">*</span></label>
				<textarea id="aurion_message" name="aurion_message" rows="6" required><?php echo esc_textarea( $message ); ?></textarea>
				<?php if ( isset( $errors['message'] ) ) : ?>
					<p class="form-error"><?php echo esc_html( $errors['message'] ); ?></p>
				<?php endif; ?>
			</div>
			<div class="form-group form-actions">
				<?php wp_nonce_field( 'aurion_contact_form', 'aurion_contact_nonce' ); ?>
				<button type="submit" class="btn-primary"><?php esc_html_e( 'Submit Inquiry', 'aurion-energy' ); ?></button>
			</div>
		</form>
	</div>
</section>
<?php
get_footer();