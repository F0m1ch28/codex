<?php
/**
 * Footer template.
 *
 * @package Aurion_Energy_Advisory
 */
?>
</main>
<footer class="site-footer" role="contentinfo">
	<div class="container footer-grid">
		<div class="footer-brand">
			<h3><?php bloginfo( 'name' ); ?></h3>
			<p>Aurion Energy Advisory partners with Canadian industrial operators to shape resilient energy systems through engineering insight, practical research, and on-site collaboration.</p>
			<ul class="social-links reset-list">
				<li><a href="https://www.linkedin.com" aria-label="Aurion Energy Advisory on LinkedIn">LinkedIn</a></li>
				<li><a href="https://twitter.com" aria-label="Aurion Energy Advisory on X">X</a></li>
				<li><a href="https://www.youtube.com" aria-label="Aurion Energy Advisory on YouTube">YouTube</a></li>
			</ul>
		</div>
		<div class="footer-nav">
			<h4><?php esc_html_e( 'Sitemap', 'aurion-energy' ); ?></h4>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer',
					'menu_class'     => 'reset-list footer-menu',
					'container'      => false,
					'fallback_cb'    => 'aurion_fallback_menu',
				)
			);
			?>
		</div>
		<div class="footer-contact">
			<h4><?php esc_html_e( 'Contact', 'aurion-energy' ); ?></h4>
			<p>460 Bay St<br>Toronto, ON M5H 2Y4, Canada</p>
			<p><a href="tel:+14167924583">+1 (416) 792-4583</a></p>
			<p><a href="mailto:info@aurionenergy.com">info@aurionenergy.com</a></p>
		</div>
		<div class="footer-widgets">
			<?php
			if ( is_active_sidebar( 'footer-1' ) ) {
				dynamic_sidebar( 'footer-1' );
			} else {
				echo '<p>' . esc_html__( 'Add a footer widget to share updates or accreditation details.', 'aurion-energy' ) . '</p>';
			}
			?>
		</div>
	</div>
	<div class="footer-bottom">
		<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'aurion-energy' ); ?></p>
	</div>
</footer>

<div id="cookie-banner" class="cookie-banner" role="dialog" aria-live="polite" aria-label="<?php esc_attr_e( 'Cookie consent message', 'aurion-energy' ); ?>">
	<div class="cookie-banner__inner">
		<p>We use cookies to improve site performance and analyze traffic. By selecting “Accept”, you agree to our <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'cookie-policy' ) ) ); ?>">Cookie Policy</a>.</p>
		<button id="cookie-accept" class="btn-primary"><?php esc_html_e( 'Accept', 'aurion-energy' ); ?></button>
	</div>
</div>

<button id="scrollToTop" class="scroll-top" aria-label="<?php esc_attr_e( 'Scroll to top', 'aurion-energy' ); ?>">
	<span aria-hidden="true">&uarr;</span>
</button>

<?php wp_footer(); ?>
</body>
</html>