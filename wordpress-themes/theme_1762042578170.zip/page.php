<?php
/**
 * Default page template.
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
	</div>
</section>
<section class="page-content container">
	<?php
	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;
	?>
</section>
<?php
get_footer();