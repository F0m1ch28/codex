<?php
/**
 * Theme functions and definitions
 *
 * @package Aurion_Energy_Advisory
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'aurion_setup' ) ) :
	/**
	 * Theme setup.
	 */
	function aurion_setup() {
		load_theme_textdomain( 'aurion-energy', get_template_directory() . '/languages' );

		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 80,
				'width'       => 220,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);

		register_nav_menus(
			array(
				'primary' => __( 'Primary Menu', 'aurion-energy' ),
				'footer'  => __( 'Footer Menu', 'aurion-energy' ),
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'aurion_setup' );

/**
 * Set the content width in pixels.
 */
function aurion_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'aurion_content_width', 1200 );
}
add_action( 'after_setup_theme', 'aurion_content_width', 0 );

/**
 * Enqueue scripts and styles.
 */
function aurion_enqueue_scripts() {
	wp_enqueue_style(
		'aurion-google-fonts',
		'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Inter:wght@400;500;600;700&display=swap',
		array(),
		null
	);

	wp_enqueue_style(
		'aurion-main-style',
		get_template_directory_uri() . '/assets/css/style.css',
		array( 'aurion-google-fonts' ),
		'1.0.0'
	);

	wp_enqueue_script(
		'aurion-main-js',
		get_template_directory_uri() . '/assets/js/script.js',
		array(),
		'1.0.0',
		true
	);

	wp_localize_script(
		'aurion-main-js',
		'aurionData',
		array(
			'themeUrl'  => get_template_directory_uri(),
			'cookieKey' => 'aurionCookieAccepted',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'aurion_enqueue_scripts' );

/**
 * Register widget area.
 */
function aurion_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Footer Widgets', 'aurion-energy' ),
			'id'            => 'footer-1',
			'description'   => __( 'Widgets added here will appear in the footer column.', 'aurion-energy' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		)
	);
}
add_action( 'widgets_init', 'aurion_widgets_init' );

/**
 * Output custom meta tags for SEO.
 */
function aurion_meta_tags() {
	if ( is_admin() ) {
		return;
	}

	if ( is_front_page() || is_home() ) {
		$description = 'Aurion Energy Advisory delivers consulting, engineering, and oilfield research services that help Canadian industrial operators build resilient energy infrastructure.';
		$keywords    = 'energy consulting Canada, oilfield research, industrial engineering, sustainable infrastructure';
	} elseif ( is_singular() && has_excerpt() ) {
		$description = wp_strip_all_tags( get_the_excerpt(), true );
		$keywords    = 'engineering advisory, energy projects, industrial strategy';
	} else {
		$description = 'Aurion Energy Advisory partners with industrial and energy-sector leaders across Canada to plan, engineer, and optimize complex infrastructure.';
		$keywords    = 'energy advisory, industrial engineering, infrastructure planning';
	}

	$description = mb_substr( $description, 0, 155 );

	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta name="keywords" content="' . esc_attr( $keywords ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";

	if ( is_singular() ) {
		echo '<meta property="og:title" content="' . esc_attr( get_the_title() ) . '">' . "\n";
		echo '<meta property="og:url" content="' . esc_url( get_permalink() ) . '">' . "\n";
	} else {
		echo '<meta property="og:title" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
		echo '<meta property="og:url" content="' . esc_url( home_url( '/' ) ) . '">' . "\n";
	}

	$canonical = ( is_singular() ) ? get_permalink() : home_url( add_query_arg( array(), $wp->request ) );
	if ( is_front_page() ) {
		$canonical = home_url( '/' );
	}
	echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
}
add_action( 'wp_head', 'aurion_meta_tags', 1 );

/**
 * Add sitemap reference to robots.txt.
 *
 * @param string $output Existing robots.txt output.
 * @param bool   $public Whether the site is indexed.
 *
 * @return string
 */
function aurion_robots_txt( $output, $public ) {
	$output .= "\nSitemap: " . esc_url_raw( home_url( '/wp-sitemap.xml' ) ) . "\n";
	return $output;
}
add_filter( 'robots_txt', 'aurion_robots_txt', 10, 2 );

/**
 * Ensure theme supports editor styles.
 */
function aurion_editor_assets() {
	add_editor_style( 'assets/css/style.css' );
}
add_action( 'admin_init', 'aurion_editor_assets' );