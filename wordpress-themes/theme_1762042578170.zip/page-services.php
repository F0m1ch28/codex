<?php
/**
 * Template Name: Services
 *
 * @package Aurion_Energy_Advisory
 */

get_header();
?>
<section class="page-hero services-hero">
	<div class="container">
		<h1><?php the_title(); ?></h1>
		<p>Integrated consulting and engineering services tailored to Canada’s energy and industrial sectors.</p>
	</div>
</section>

<section class="page-content container services-content">
	<div class="service-block">
		<h2>Strategic Advisory</h2>
		<p>We align technical execution with corporate objectives, ensuring your leadership teams have the clarity needed to advance major initiatives.</p>
		<ul class="feature-list">
			<li>Feasibility and concept studies for new builds and facility upgrades.</li>
			<li>Risk workshops and operational readiness assessments.</li>
			<li>Stakeholder engagement and regulatory coordination.</li>
		</ul>
	</div>

	<div class="service-block">
		<h2>Engineering &amp; Design</h2>
		<p>Our engineers translate project goals into technical documentation, specifications, and on-site support that drive safe execution.</p>
		<ul class="feature-list">
			<li>Mechanical, structural, and electrical design packages.</li>
			<li>Equipment selection, bid evaluations, and vendor oversight.</li>
			<li>Cranes and lifting systems planning, including lift studies and compliance reviews.</li>
		</ul>
	</div>

	<div class="service-block">
		<h2>Oilfield Research &amp; Analytics</h2>
		<p>We help operators capture and interpret field data to enhance productivity, anticipate issues, and streamline maintenance.</p>
		<ul class="feature-list">
			<li>Reservoir performance analysis and drilling optimization.</li>
			<li>Instrumentation strategies and data visualization dashboards.</li>
			<li>Reliability engineering and root cause investigations.</li>
		</ul>
	</div>

	<div class="service-block">
		<h2>Implementation Support</h2>
		<p>From mobilization to commissioning, Aurion provides leadership that keeps complex projects on track.</p>
		<ul class="feature-list">
			<li>Project controls, scheduling, and contractor coordination.</li>
			<li>Construction quality assurance and inspection services.</li>
			<li>Commissioning management with structured punch-list completion.</li>
		</ul>
	</div>
</section>
<?php
get_footer();