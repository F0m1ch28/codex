```php
<?php
/**
 * Template Name: Contact Page
 *
 * @package Aurion_Energy
 */

$errors          = array();
$success_message = '';

if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['aurion_contact_nonce'] ) ) {
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['aurion_contact_nonce'] ) ), 'aurion_contact_form' ) ) {
		$errors[] = __( 'Security validation failed. Please refresh the page and try again.', 'aurion-energy' );
	} elseif ( ! empty( $_POST['aurion_contact_guard'] ) ) {
		$errors[] = __( 'Submission could not be processed.', 'aurion-energy' );
	} else {
		$name    = isset( $_POST['full_name'] ) ? sanitize_text_field( wp_unslash( $_POST['full_name'] ) ) : '';
		$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$company = isset( $_POST['company'] ) ? sanitize_text_field( wp_unslash( $_POST['company'] ) ) : '';
		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

		if ( empty( $name ) ) {
			$errors[] = __( 'Please provide your name.', 'aurion-energy' );
		}
		if ( empty( $email ) || ! is_email( $email ) ) {
			$errors[] = __( 'Please provide a valid email address.', 'aurion-energy' );
		}
		if ( empty( $subject ) ) {
			$errors[] = __( 'Please select a subject.', 'aurion-energy' );
		}
		if ( empty( $message ) ) {
			$errors[] = __( 'Please provide a message.', 'aurion-energy' );
		}

		if ( empty( $errors ) ) {
			$admin_email = get_theme_mod( 'aurion_contact_email', get_option( 'admin_email' ) );
			$mail_subject = sprintf( __( 'New enquiry from %s', 'aurion-energy' ), $name );
			$mail_headers = array(
				'Content-Type: text/plain; charset=UTF-8',
				'Reply-To: ' . $name . ' <' . $email . '>',
			);

			$body  = "Name: {$name}\n";
			$body .= "Email: {$email}\n";
			if ( $phone ) {
				$body .= "Phone: {$phone}\n";
			}
			if ( $company ) {
				$body .= "Company: {$company}\n";
			}
			$body .= "Subject: {$subject}\n\n";
			$body .= "Message:\n{$message}\n";

			$sent = wp_mail( $admin_email, $mail_subject, $body, $mail_headers );

			if ( $sent ) {
				$success_message = __( 'Thank you for contacting Aurion Energy Advisory. We will respond soon.', 'aurion-energy' );
			} else {
				$errors[] = __( 'There was an issue sending your message. Please try again later.', 'aurion-energy' );
			}
		}
	}
}

get_header();

$hero_image = 'https://picsum.photos/1920/800?random=51';
$address    = get_theme_mod( 'aurion_contact_address', '460 Bay St, Toronto, ON M5H 2Y4, Canada' );
$phone      = get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' );
$email      = get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' );
$linkedin   = get_theme_mod( 'aurion_social_linkedin', 'https://www.linkedin.com' );
?>
<main id="site-content" class="page-default contact-page">
	<section class="page-hero" style="background-image: url('<?php echo esc_url( $hero_image ); ?>');">
		<div class="page-hero-overlay"></div>
		<div class="container">
			<h1><?php the_title(); ?></h1>
			<?php aurion_energy_breadcrumbs(); ?>
		</div>
	</section>

	<section class="section contact-intro">
		<div class="container split-grid">
			<div class="text-column">
				<h2><?php esc_html_e( 'Connect with Our Team', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'Share the details of your project and our consultants will coordinate the right specialists to respond.', 'aurion-energy' ); ?></p>
				<div class="contact-details">
					<p><strong><?php esc_html_e( 'Address:', 'aurion-energy' ); ?></strong> <?php echo esc_html( $address ); ?></p>
					<p><strong><?php esc_html_e( 'Phone:', 'aurion-energy' ); ?></strong> <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p>
					<p><strong><?php esc_html_e( 'Email:', 'aurion-energy' ); ?></strong> <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
					<p><strong><?php esc_html_e( 'LinkedIn:', 'aurion-energy' ); ?></strong> <a href="<?php echo esc_url( $linkedin ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Aurion Energy Advisory on LinkedIn', 'aurion-energy' ); ?></a></p>
					<p><strong><?php esc_html_e( 'Business Hours:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Monday to Friday, 8:00 a.m. – 6:00 p.m. EST', 'aurion-energy' ); ?></p>
				</div>
			</div>
			<div class="form-column">
				<?php if ( ! empty( $errors ) ) : ?>
					<div class="form-alert is-error">
						<ul>
							<?php foreach ( $errors as $error ) : ?>
								<li><?php echo esc_html( $error ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<?php if ( $success_message ) : ?>
					<div class="form-alert is-success">
						<p><?php echo esc_html( $success_message ); ?></p>
					</div>
				<?php endif; ?>

				<form class="contact-form js-contact-form" method="post" action="<?php echo esc_url( get_permalink() ); ?>" novalidate>
					<?php wp_nonce_field( 'aurion_contact_form', 'aurion_contact_nonce' ); ?>
					<input type="text" name="aurion_contact_guard" id="aurion_contact_guard" value="" class="aurion-guard" tabindex="-1" aria-hidden="true">
					<div class="form-group">
						<label for="full_name"><?php esc_html_e( 'Full Name*', 'aurion-energy' ); ?></label>
						<input type="text" id="full_name" name="full_name" required value="<?php echo isset( $name ) ? esc_attr( $name ) : ''; ?>">
					</div>
					<div class="form-group">
						<label for="email"><?php esc_html_e( 'Email*', 'aurion-energy' ); ?></label>
						<input type="email" id="email" name="email" required value="<?php echo isset( $email ) ? esc_attr( $email ) : ''; ?>">
					</div>
					<div class="form-group">
						<label for="phone"><?php esc_html_e( 'Phone', 'aurion-energy' ); ?></label>
						<input type="tel" id="phone" name="phone" value="<?php echo isset( $phone ) ? esc_attr( $phone ) : ''; ?>">
					</div>
					<div class="form-group">
						<label for="company"><?php esc_html_e( 'Company', 'aurion-energy' ); ?></label>
						<input type="text" id="company" name="company" value="<?php echo isset( $company ) ? esc_attr( $company ) : ''; ?>">
					</div>
					<div class="form-group">
						<label for="subject"><?php esc_html_e( 'Subject*', 'aurion-energy' ); ?></label>
						<select id="subject" name="subject" required>
							<option value=""><?php esc_html_e( 'Select an option', 'aurion-energy' ); ?></option>
							<option value="Consulting" <?php selected( isset( $subject ) ? $subject : '', 'Consulting' ); ?>><?php esc_html_e( 'Consulting enquiry', 'aurion-energy' ); ?></option>
							<option value="Project Support" <?php selected( isset( $subject ) ? $subject : '', 'Project Support' ); ?>><?php esc_html_e( 'Project support request', 'aurion-energy' ); ?></option>
							<option value="Partnership" <?php selected( isset( $subject ) ? $subject : '', 'Partnership' ); ?>><?php esc_html_e( 'Partnership discussion', 'aurion-energy' ); ?></option>
							<option value="Other" <?php selected( isset( $subject ) ? $subject : '', 'Other' ); ?>><?php esc_html_e( 'Other', 'aurion-energy' ); ?></option>
						</select>
					</div>
					<div class="form-group">
						<label for="message"><?php esc_html_e( 'Message*', 'aurion-energy' ); ?></label>
						<textarea id="message" name="message" rows="6" required><?php echo isset( $message ) ? esc_textarea( $message ) : ''; ?></textarea>
					</div>
					<div class="form-group">
						<label class="checkbox">
							<input type="checkbox" name="consent" value="1" required>
							<span><?php esc_html_e( 'I consent to Aurion Energy Advisory storing my submitted information.', 'aurion-energy' ); ?></span>
						</label>
					</div>
					<button type="submit" class="btn btn-primary"><?php esc_html_e( 'Send Message', 'aurion-energy' ); ?></button>
				</form>
			</div>
		</div>
	</section>

	<section class="section contact-map">
		<div class="container">
			<h2><?php esc_html_e( 'Visit Our Toronto Office', 'aurion-energy' ); ?></h2>
			<div class="map-wrapper" aria-label="<?php esc_attr_e( 'Aurion Energy Advisory office on Map', 'aurion-energy' ); ?>">
				<iframe
					title="<?php esc_attr_e( 'Aurion Energy Advisory Location', 'aurion-energy' ); ?>"
					src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.520508458845!2d-79.38445192351477!3d43.65065905327234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d3eae5ba6d%3A0x7e4bea63f36cb3d5!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1700000000000"
					width="600"
					height="450"
					style="border:0;"
					allowfullscreen=""
					loading="lazy"
					referrerpolicy="no-referrer-when-downgrade"></iframe>
			</div>
		</div>
	</section>
</main>
<?php
get_footer();
```