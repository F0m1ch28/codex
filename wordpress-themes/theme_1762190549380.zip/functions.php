```php
<?php
/**
 * Aurion Energy Advisory theme functions and definitions.
 *
 * @package Aurion_Energy
 */

if ( ! defined( 'AEA_THEME_VERSION' ) ) {
	define( 'AEA_THEME_VERSION', '1.0.0' );
}

if ( ! function_exists( 'aurion_energy_setup' ) ) :
	/**
	 * Sets up theme defaults.
	 */
	function aurion_energy_setup() {
		load_theme_textdomain( 'aurion-energy', get_template_directory() . '/languages' );

		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);
		add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 220, 'flex-height' => true, 'flex-width' => true ) );
		add_theme_support( 'automatic-feed-links' );

		register_nav_menus(
			array(
				'primary' => __( 'Primary Menu', 'aurion-energy' ),
				'footer'  => __( 'Footer Menu', 'aurion-energy' ),
				'mobile'  => __( 'Mobile Menu', 'aurion-energy' ),
			)
		);

		add_image_size( 'hero-full', 1920, 800, true );
		add_image_size( 'project-thumb', 600, 400, true );
		add_image_size( 'team-portrait', 400, 500, true );
		add_image_size( 'testimonial-avatar', 80, 80, true );
	}
endif;
add_action( 'after_setup_theme', 'aurion_energy_setup' );

/**
 * Set the content width based on the theme's design.
 */
function aurion_energy_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'aurion_energy_content_width', 960 );
}
add_action( 'after_setup_theme', 'aurion_energy_content_width', 0 );

/**
 * Enqueue scripts and styles.
 */
function aurion_energy_scripts() {
	wp_enqueue_style(
		'aurion-energy-fonts',
		'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Inter:wght@300;400;500;600;700&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'aurion-energy-style', get_stylesheet_uri(), array(), AEA_THEME_VERSION );
	wp_enqueue_style(
		'aurion-energy-main',
		get_template_directory_uri() . '/assets/css/style.css',
		array( 'aurion-energy-style' ),
		AEA_THEME_VERSION
	);

	$primary   = sanitize_hex_color( get_theme_mod( 'aurion_primary_color', '#2563EB' ) );
	$secondary = sanitize_hex_color( get_theme_mod( 'aurion_secondary_color', '#475569' ) );

	$inline_styles = ':root{--color-primary:' . ( $primary ? $primary : '#2563EB' ) . ';--color-secondary:' . ( $secondary ? $secondary : '#475569' ) . ';}';
	wp_add_inline_style( 'aurion-energy-main', $inline_styles );

	wp_enqueue_script(
		'aurion-energy-main',
		get_template_directory_uri() . '/assets/js/script.js',
		array( 'jquery' ),
		AEA_THEME_VERSION,
		true
	);

	wp_localize_script(
		'aurion-energy-main',
		'AurionSettings',
		array(
			'cookieAccepted' => esc_html__( 'Cookie preferences saved.', 'aurion-energy' ),
			'cookieDeclined' => esc_html__( 'Cookie usage declined.', 'aurion-energy' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'aurion_energy_scripts' );

/**
 * Register widget areas.
 */
function aurion_energy_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Sidebar', 'aurion-energy' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Add widgets for the sidebar.', 'aurion-energy' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d: Footer column number */
				'name'          => sprintf( __( 'Footer Column %d', 'aurion-energy' ), $i ),
				'id'            => 'footer-col-' . $i,
				'description'   => __( 'Add widgets for the footer region.', 'aurion-energy' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
	}
}
add_action( 'widgets_init', 'aurion_energy_widgets_init' );

/**
 * Register custom post types.
 */
function aurion_energy_register_post_types() {

	$project_labels = array(
		'name'               => _x( 'Projects', 'Post type general name', 'aurion-energy' ),
		'singular_name'      => _x( 'Project', 'Post type singular name', 'aurion-energy' ),
		'menu_name'          => _x( 'Projects', 'Admin Menu text', 'aurion-energy' ),
		'name_admin_bar'     => _x( 'Project', 'Add New on Toolbar', 'aurion-energy' ),
		'add_new'            => __( 'Add New', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Project', 'aurion-energy' ),
		'new_item'           => __( 'New Project', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Project', 'aurion-energy' ),
		'view_item'          => __( 'View Project', 'aurion-energy' ),
		'all_items'          => __( 'All Projects', 'aurion-energy' ),
		'search_items'       => __( 'Search Projects', 'aurion-energy' ),
		'parent_item_colon'  => __( 'Parent Projects:', 'aurion-energy' ),
		'not_found'          => __( 'No projects found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No projects found in Trash.', 'aurion-energy' ),
	);

	$project_args = array(
		'labels'             => $project_labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_in_rest'       => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'projects' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'menu_icon'          => 'dashicons-analytics',
	);

	register_post_type( 'projects', $project_args );

	$team_labels = array(
		'name'               => _x( 'Team Members', 'Post type general name', 'aurion-energy' ),
		'singular_name'      => _x( 'Team Member', 'Post type singular name', 'aurion-energy' ),
		'menu_name'          => _x( 'Team', 'Admin Menu text', 'aurion-energy' ),
		'name_admin_bar'     => _x( 'Team Member', 'Add New on Toolbar', 'aurion-energy' ),
		'add_new'            => __( 'Add New', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Team Member', 'aurion-energy' ),
		'new_item'           => __( 'New Team Member', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Team Member', 'aurion-energy' ),
		'view_item'          => __( 'View Team Member', 'aurion-energy' ),
		'all_items'          => __( 'All Team Members', 'aurion-energy' ),
		'search_items'       => __( 'Search Team Members', 'aurion-energy' ),
		'parent_item_colon'  => __( 'Parent Team Members:', 'aurion-energy' ),
		'not_found'          => __( 'No team members found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No team members found in Trash.', 'aurion-energy' ),
	);

	$team_args = array(
		'labels'             => $team_labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_in_rest'       => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'team' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 21,
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'menu_icon'          => 'dashicons-groups',
	);

	register_post_type( 'team-members', $team_args );
}
add_action( 'init', 'aurion_energy_register_post_types' );

/**
 * Register custom taxonomies.
 */
function aurion_energy_register_taxonomies() {
	$project_tax_labels = array(
		'name'              => _x( 'Project Categories', 'taxonomy general name', 'aurion-energy' ),
		'singular_name'     => _x( 'Project Category', 'taxonomy singular name', 'aurion-energy' ),
		'search_items'      => __( 'Search Project Categories', 'aurion-energy' ),
		'all_items'         => __( 'All Project Categories', 'aurion-energy' ),
		'parent_item'       => __( 'Parent Project Category', 'aurion-energy' ),
		'parent_item_colon' => __( 'Parent Project Category:', 'aurion-energy' ),
		'edit_item'         => __( 'Edit Project Category', 'aurion-energy' ),
		'update_item'       => __( 'Update Project Category', 'aurion-energy' ),
		'add_new_item'      => __( 'Add New Project Category', 'aurion-energy' ),
		'new_item_name'     => __( 'New Project Category Name', 'aurion-energy' ),
		'menu_name'         => __( 'Project Categories', 'aurion-energy' ),
	);

	$project_tax_args = array(
		'hierarchical'      => true,
		'labels'            => $project_tax_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'project-category' ),
	);

	register_taxonomy( 'project-category', array( 'projects' ), $project_tax_args );

	$expertise_labels = array(
		'name'              => _x( 'Expertise Areas', 'taxonomy general name', 'aurion-energy' ),
		'singular_name'     => _x( 'Expertise Area', 'taxonomy singular name', 'aurion-energy' ),
		'search_items'      => __( 'Search Expertise Areas', 'aurion-energy' ),
		'all_items'         => __( 'All Expertise Areas', 'aurion-energy' ),
		'parent_item'       => __( 'Parent Expertise Area', 'aurion-energy' ),
		'parent_item_colon' => __( 'Parent Expertise Area:', 'aurion-energy' ),
		'edit_item'         => __( 'Edit Expertise Area', 'aurion-energy' ),
		'update_item'       => __( 'Update Expertise Area', 'aurion-energy' ),
		'add_new_item'      => __( 'Add New Expertise Area', 'aurion-energy' ),
		'new_item_name'     => __( 'New Expertise Area Name', 'aurion-energy' ),
		'menu_name'         => __( 'Expertise Areas', 'aurion-energy' ),
	);

	$expertise_args = array(
		'hierarchical'      => false,
		'labels'            => $expertise_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'expertise-area' ),
	);

	register_taxonomy( 'expertise-area', array( 'projects', 'team-members' ), $expertise_args );
}
add_action( 'init', 'aurion_energy_register_taxonomies' );

/**
 * Customize excerpt read more text.
 *
 * @param string $more The string shown within the more link.
 */
function aurion_energy_excerpt_more( $more ) {
	if ( is_admin() ) {
		return $more;
	}
	return sprintf(
		' <a class="read-more" href="%1$s">%2$s</a>',
		esc_url( get_permalink() ),
		esc_html__( 'Continue reading', 'aurion-energy' )
	);
}
add_filter( 'excerpt_more', 'aurion_energy_excerpt_more' );

/**
 * Breadcrumbs generator.
 */
function aurion_energy_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}

	$home_link = esc_url( home_url( '/' ) );
	echo '<nav class="breadcrumb" aria-label="' . esc_attr__( 'Breadcrumb', 'aurion-energy' ) . '">';
	echo '<a href="' . $home_link . '">' . esc_html__( 'Home', 'aurion-energy' ) . '</a>';

	if ( is_singular() ) {
		$post_type = get_post_type();
		if ( 'projects' === $post_type ) {
			echo '<span class="breadcrumb-sep">/</span><a href="' . esc_url( get_post_type_archive_link( 'projects' ) ) . '">' . esc_html__( 'Projects', 'aurion-energy' ) . '</a>';
		} elseif ( 'team-members' === $post_type ) {
			echo '<span class="breadcrumb-sep">/</span><a href="' . esc_url( get_post_type_archive_link( 'team-members' ) ) . '">' . esc_html__( 'Team', 'aurion-energy' ) . '</a>';
		}
		echo '<span class="breadcrumb-sep">/</span><span class="breadcrumb-current">' . esc_html( get_the_title() ) . '</span>';
	} elseif ( is_archive() ) {
		echo '<span class="breadcrumb-sep">/</span><span class="breadcrumb-current">' . esc_html( get_the_archive_title() ) . '</span>';
	} elseif ( is_search() ) {
		/* translators: %s: Search query */
		echo '<span class="breadcrumb-sep">/</span><span class="breadcrumb-current">' . sprintf( esc_html__( 'Search results for "%s"', 'aurion-energy' ), esc_html( get_search_query() ) ) . '</span>';
	} elseif ( is_404() ) {
		echo '<span class="breadcrumb-sep">/</span><span class="breadcrumb-current">' . esc_html__( 'Page not found', 'aurion-energy' ) . '</span>';
	}

	echo '</nav>';
}

/**
 * Customizer settings.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function aurion_energy_customize_register( $wp_customize ) {

	$wp_customize->add_section(
		'aurion_colors_section',
		array(
			'title'    => __( 'Theme Colors', 'aurion-energy' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'aurion_primary_color',
		array(
			'default'           => '#2563EB',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'aurion_primary_color',
			array(
				'label'   => __( 'Primary Accent Colour', 'aurion-energy' ),
				'section' => 'aurion_colors_section',
			)
		)
	);

	$wp_customize->add_setting(
		'aurion_secondary_color',
		array(
			'default'           => '#475569',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'aurion_secondary_color',
			array(
				'label'   => __( 'Secondary Colour', 'aurion-energy' ),
				'section' => 'aurion_colors_section',
			)
		)
	);

	$wp_customize->add_section(
		'aurion_contact_section',
		array(
			'title'    => __( 'Contact Information', 'aurion-energy' ),
			'priority' => 35,
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_phone',
		array(
			'default'           => '+1 (416) 792-4583',
			'sanitize_callback' => 'aurion_energy_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_phone',
		array(
			'label'   => __( 'Phone Number', 'aurion-energy' ),
			'section' => 'aurion_contact_section',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_email',
		array(
			'default'           => 'info@aurionenergy.com',
			'sanitize_callback' => 'sanitize_email',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_email',
		array(
			'label'   => __( 'Email Address', 'aurion-energy' ),
			'section' => 'aurion_contact_section',
			'type'    => 'email',
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_address',
		array(
			'default'           => '460 Bay St, Toronto, ON M5H 2Y4, Canada',
			'sanitize_callback' => 'aurion_energy_sanitize_textarea',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_address',
		array(
			'label'   => __( 'Address', 'aurion-energy' ),
			'section' => 'aurion_contact_section',
			'type'    => 'textarea',
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_tagline',
		array(
			'default'           => __( 'Engineering the Future of Energy', 'aurion-energy' ),
			'sanitize_callback' => 'aurion_energy_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_tagline',
		array(
			'label'   => __( 'Company Tagline', 'aurion-energy' ),
			'section' => 'title_tagline',
			'type'    => 'text',
		)
	);

	$wp_customize->add_section(
		'aurion_social_section',
		array(
			'title'    => __( 'Social Links', 'aurion-energy' ),
			'priority' => 40,
		)
	);

	$wp_customize->add_setting(
		'aurion_social_linkedin',
		array(
			'default'           => 'https://www.linkedin.com',
			'sanitize_callback' => 'esc_url_raw',
		)
	);

	$wp_customize->add_control(
		'aurion_social_linkedin',
		array(
			'label'   => __( 'LinkedIn URL', 'aurion-energy' ),
			'section' => 'aurion_social_section',
			'type'    => 'url',
		)
	);
}
add_action( 'customize_register', 'aurion_energy_customize_register' );

/**
 * Sanitize text.
 *
 * @param string $input Input string.
 */
function aurion_energy_sanitize_text( $input ) {
	return sanitize_text_field( $input );
}

/**
 * Sanitize textarea.
 *
 * @param string $input Input string.
 */
function aurion_energy_sanitize_textarea( $input ) {
	return sanitize_textarea_field( $input );
}

/**
 * Register custom widgets.
 */
function aurion_energy_register_widgets_custom() {
	register_widget( 'Aurion_Energy_Team_Widget' );
	register_widget( 'Aurion_Energy_Testimonial_Widget' );
}
add_action( 'widgets_init', 'aurion_energy_register_widgets_custom' );

/**
 * Team member widget.
 */
class Aurion_Energy_Team_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'aurion_energy_team_widget',
			__( 'Aurion Team Highlight', 'aurion-energy' ),
			array(
				'description' => __( 'Showcase a team member with role and summary.', 'aurion-energy' ),
			)
		);
	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		if ( $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
		}

		$name        = ! empty( $instance['name'] ) ? $instance['name'] : '';
		$role        = ! empty( $instance['role'] ) ? $instance['role'] : '';
		$summary     = ! empty( $instance['summary'] ) ? $instance['summary'] : '';
		$link        = ! empty( $instance['link'] ) ? $instance['link'] : '';
		$link_label  = ! empty( $instance['link_label'] ) ? $instance['link_label'] : '';

		echo '<div class="widget-team-card">';
		if ( $name ) {
			echo '<p class="team-name">' . esc_html( $name ) . '</p>';
		}
		if ( $role ) {
			echo '<p class="team-role">' . esc_html( $role ) . '</p>';
		}
		if ( $summary ) {
			echo '<p class="team-summary">' . esc_html( $summary ) . '</p>';
		}
		if ( $link ) {
			echo '<a class="team-link" href="' . esc_url( $link ) . '">' . esc_html( $link_label ? $link_label : __( 'View Profile', 'aurion-energy' ) ) . '</a>';
		}
		echo '</div>';

		echo $args['after_widget'];
	}

	public function form( $instance ) {
		$title      = isset( $instance['title'] ) ? $instance['title'] : '';
		$name       = isset( $instance['name'] ) ? $instance['name'] : '';
		$role       = isset( $instance['role'] ) ? $instance['role'] : '';
		$summary    = isset( $instance['summary'] ) ? $instance['summary'] : '';
		$link       = isset( $instance['link'] ) ? $instance['link'] : '';
		$link_label = isset( $instance['link_label'] ) ? $instance['link_label'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>"><?php esc_html_e( 'Name:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'name' ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'role' ) ); ?>"><?php esc_html_e( 'Role:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'role' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'role' ) ); ?>" type="text" value="<?php echo esc_attr( $role ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'summary' ) ); ?>"><?php esc_html_e( 'Summary:', 'aurion-energy' ); ?></label>
			<textarea class="widefat" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'summary' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'summary' ) ); ?>"><?php echo esc_textarea( $summary ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Profile URL:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="url" value="<?php echo esc_attr( $link ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'link_label' ) ); ?>"><?php esc_html_e( 'Link Label:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_label' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_label' ) ); ?>" type="text" value="<?php echo esc_attr( $link_label ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance               = array();
		$instance['title']      = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['name']       = ! empty( $new_instance['name'] ) ? sanitize_text_field( $new_instance['name'] ) : '';
		$instance['role']       = ! empty( $new_instance['role'] ) ? sanitize_text_field( $new_instance['role'] ) : '';
		$instance['summary']    = ! empty( $new_instance['summary'] ) ? sanitize_textarea_field( $new_instance['summary'] ) : '';
		$instance['link']       = ! empty( $new_instance['link'] ) ? esc_url_raw( $new_instance['link'] ) : '';
		$instance['link_label'] = ! empty( $new_instance['link_label'] ) ? sanitize_text_field( $new_instance['link_label'] ) : '';
		return $instance;
	}
}

/**
 * Testimonial widget.
 */
class Aurion_Energy_Testimonial_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'aurion_energy_testimonial_widget',
			__( 'Aurion Testimonial', 'aurion-energy' ),
			array(
				'description' => __( 'Display a client testimonial with rating.', 'aurion-energy' ),
			)
		);
	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		if ( $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
		}

		$quote     = ! empty( $instance['quote'] ) ? $instance['quote'] : '';
		$client    = ! empty( $instance['client'] ) ? $instance['client'] : '';
		$position  = ! empty( $instance['position'] ) ? $instance['position'] : '';
		$company   = ! empty( $instance['company'] ) ? $instance['company'] : '';
		$rating    = ! empty( $instance['rating'] ) ? absint( $instance['rating'] ) : 5;

		if ( $quote ) {
			echo '<blockquote class="widget-testimonial-quote">&ldquo;' . esc_html( $quote ) . '&rdquo;</blockquote>';
		}
		if ( $client ) {
			echo '<p class="widget-testimonial-client"><strong>' . esc_html( $client ) . '</strong>';
			if ( $position ) {
				echo ' &middot; ' . esc_html( $position );
			}
			if ( $company ) {
				echo ' &middot; ' . esc_html( $company );
			}
			echo '</p>';
		}
		if ( $rating ) {
			echo '<div class="widget-testimonial-rating" aria-label="' . esc_attr__( 'Client rating', 'aurion-energy' ) . '">';
			for ( $i = 0; $i < $rating; $i++ ) {
				echo '<span class="star" aria-hidden="true">&#9733;</span>';
			}
			echo '</div>';
		}

		echo $args['after_widget'];
	}

	public function form( $instance ) {
		$title    = isset( $instance['title'] ) ? $instance['title'] : '';
		$quote    = isset( $instance['quote'] ) ? $instance['quote'] : '';
		$client   = isset( $instance['client'] ) ? $instance['client'] : '';
		$position = isset( $instance['position'] ) ? $instance['position'] : '';
		$company  = isset( $instance['company'] ) ? $instance['company'] : '';
		$rating   = isset( $instance['rating'] ) ? absint( $instance['rating'] ) : 5;
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'quote' ) ); ?>"><?php esc_html_e( 'Quote:', 'aurion-energy' ); ?></label>
			<textarea class="widefat" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'quote' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'quote' ) ); ?>"><?php echo esc_textarea( $quote ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'client' ) ); ?>"><?php esc_html_e( 'Client Name:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'client' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'client' ) ); ?>" type="text" value="<?php echo esc_attr( $client ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'position' ) ); ?>"><?php esc_html_e( 'Position:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'position' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'position' ) ); ?>" type="text" value="<?php echo esc_attr( $position ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'company' ) ); ?>"><?php esc_html_e( 'Company:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'company' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'company' ) ); ?>" type="text" value="<?php echo esc_attr( $company ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'rating' ) ); ?>"><?php esc_html_e( 'Rating (1-5):', 'aurion-energy' ); ?></label>
			<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'rating' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'rating' ) ); ?>" type="number" step="1" min="1" max="5" value="<?php echo esc_attr( $rating ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance              = array();
		$instance['title']     = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['quote']     = ! empty( $new_instance['quote'] ) ? sanitize_textarea_field( $new_instance['quote'] ) : '';
		$instance['client']    = ! empty( $new_instance['client'] ) ? sanitize_text_field( $new_instance['client'] ) : '';
		$instance['position']  = ! empty( $new_instance['position'] ) ? sanitize_text_field( $new_instance['position'] ) : '';
		$instance['company']   = ! empty( $new_instance['company'] ) ? sanitize_text_field( $new_instance['company'] ) : '';
		$instance['rating']    = ! empty( $new_instance['rating'] ) ? absint( $new_instance['rating'] ) : 5;
		return $instance;
	}
}

/**
 * Output organization schema.
 */
function aurion_energy_output_schema() {
	$org_schema = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'ProfessionalService',
		'name'            => get_bloginfo( 'name' ),
		'url'             => home_url( '/' ),
		'description'     => get_bloginfo( 'description' ),
		'telephone'       => get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ),
		'email'           => get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ),
		'address'         => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => '460 Bay St',
			'addressLocality' => 'Toronto',
			'addressRegion'   => 'ON',
			'postalCode'      => 'M5H 2Y4',
			'addressCountry'  => 'CA',
		),
		'sameAs'          => array(
			get_theme_mod( 'aurion_social_linkedin', 'https://www.linkedin.com' ),
		),
		'serviceArea'     => array(
			'@type'   => 'Place',
			'name'    => 'Canada',
		),
	);

	echo '<script type="application/ld+json">' . wp_json_encode( $org_schema ) . '</script>';
}
add_action( 'wp_head', 'aurion_energy_output_schema', 5 );
```