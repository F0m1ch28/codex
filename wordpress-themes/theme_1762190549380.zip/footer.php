```php
<?php
/**
 * Footer template.
 *
 * @package Aurion_Energy
 */

$address = get_theme_mod( 'aurion_contact_address', '460 Bay St, Toronto, ON M5H 2Y4, Canada' );
$phone   = get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' );
$email   = get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' );
?>
<footer class="site-footer">
	<div class="footer-widgets container">
		<div class="footer-column">
			<h3><?php esc_html_e( 'Aurion Energy Advisory', 'aurion-energy' ); ?></h3>
			<p><?php echo esc_html( $address ); ?></p>
			<p><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p>
			<p><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
		</div>
		<div class="footer-column">
			<?php if ( is_active_sidebar( 'footer-col-1' ) ) : ?>
				<?php dynamic_sidebar( 'footer-col-1' ); ?>
			<?php else : ?>
				<h3><?php esc_html_e( 'Quick Links', 'aurion-energy' ); ?></h3>
				<ul class="footer-links">
					<li><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Services', 'aurion-energy' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/projects/' ) ); ?>"><?php esc_html_e( 'Projects', 'aurion-energy' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php esc_html_e( 'About', 'aurion-energy' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact', 'aurion-energy' ); ?></a></li>
				</ul>
			<?php endif; ?>
		</div>
		<div class="footer-column">
			<?php if ( is_active_sidebar( 'footer-col-2' ) ) : ?>
				<?php dynamic_sidebar( 'footer-col-2' ); ?>
			<?php else : ?>
				<h3><?php esc_html_e( 'Connect', 'aurion-energy' ); ?></h3>
				<ul class="footer-links">
					<li><a href="<?php echo esc_url( get_theme_mod( 'aurion_social_linkedin', 'https://www.linkedin.com' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'LinkedIn', 'aurion-energy' ); ?></a></li>
				</ul>
			<?php endif; ?>
		</div>
		<div class="footer-column">
			<?php if ( is_active_sidebar( 'footer-col-3' ) ) : ?>
				<?php dynamic_sidebar( 'footer-col-3' ); ?>
			<?php else : ?>
				<h3><?php esc_html_e( 'Newsletter', 'aurion-energy' ); ?></h3>
				<p><?php esc_html_e( 'Subscribe for project updates and engineering insights.', 'aurion-energy' ); ?></p>
				<form class="newsletter-form" action="#" method="post">
					<label for="newsletter-email" class="screen-reader-text"><?php esc_html_e( 'Email address', 'aurion-energy' ); ?></label>
					<input type="email" id="newsletter-email" name="newsletter-email" placeholder="<?php esc_attr_e( 'Email address', 'aurion-energy' ); ?>" required>
					<button type="submit" class="btn btn-primary"><?php esc_html_e( 'Subscribe', 'aurion-energy' ); ?></button>
				</form>
			<?php endif; ?>
		</div>
	</div>
	<div class="footer-bottom">
		<div class="container footer-bottom-inner">
			<p>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php esc_html_e( 'Aurion Energy Advisory. All rights reserved.', 'aurion-energy' ); ?></p>
			<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer navigation', 'aurion-energy' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'menu_class'     => 'footer-menu',
						'depth'          => 1,
						'container'      => false,
					)
				);
				?>
			</nav>
			<div class="footer-legal">
				<a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>"><?php esc_html_e( 'Terms of Use', 'aurion-energy' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'aurion-energy' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>"><?php esc_html_e( 'Cookie Policy', 'aurion-energy' ); ?></a>
			</div>
		</div>
	</div>
</footer>

<button id="back-to-top" class="back-to-top" type="button" aria-label="<?php esc_attr_e( 'Back to top', 'aurion-energy' ); ?>">
	<span>&uarr;</span>
</button>

<?php wp_footer(); ?>
</body>
</html>
```