```javascript
(function ($) {
	'use strict';

	const $document = $(document);
	const $window = $(window);

	function initNavigation() {
		const $toggle = $('.nav-toggle');
		const $menu = $('.primary-navigation .menu');

		$toggle.on('click', function () {
			const isOpen = $menu.hasClass('is-open');
			$menu.toggleClass('is-open', !isOpen);
			$toggle.attr('aria-expanded', !isOpen);
		});

		$window.on('resize', function () {
			if ($window.width() > 1024) {
				$menu.removeClass('is-open');
				$('.nav-toggle').attr('aria-expanded', false);
			}
		});
	}

	function initStickyHeader() {
		const $header = $('.site-header');
		if (!$header.length) {
			return;
		}

		$window.on('scroll', function () {
			if ($window.scrollTop() > 100) {
				$header.addClass('is-sticky');
			} else {
				$header.removeClass('is-sticky');
			}
		});
	}

	function initBackToTop() {
		const $button = $('#back-to-top');
		if (!$button.length) {
			return;
		}

		$window.on('scroll', function () {
			if ($window.scrollTop() > 300) {
				$button.addClass('show');
			} else {
				$button.removeClass('show');
			}
		});

		$button.on('click', function () {
			$('html, body').animate({ scrollTop: 0 }, 600);
		});
	}

	function initCookieBanner() {
		const banner = document.getElementById('cookie-consent');
		if (!banner) {
			return;
		}
		const acceptBtn = document.getElementById('cookie-accept');
		const declineBtn = document.getElementById('cookie-decline');
		const preference = localStorage.getItem('aurionCookiePreference');

		if (!preference) {
			setTimeout(function () {
				banner.classList.add('active');
			}, 800);
		} else {
			banner.classList.add('hidden');
		}

		function closeBanner(choice) {
			localStorage.setItem('aurionCookiePreference', choice);
			banner.classList.remove('active');
			setTimeout(function () {
				banner.classList.add('hidden');
			}, 300);
		}

		if (acceptBtn) {
			acceptBtn.addEventListener('click', function () {
				closeBanner('accepted');
				if (window.AurionSettings) {
					console.log(AurionSettings.cookieAccepted);
				}
			});
		}

		if (declineBtn) {
			declineBtn.addEventListener('click', function () {
				closeBanner('declined');
				if (window.AurionSettings) {
					console.log(AurionSettings.cookieDeclined);
				}
			});
		}
	}

	function initTestimonialSlider() {
		const $slider = $('.testimonial-slider[data-slider="true"]');
		if (!$slider.length) {
			return;
		}

		const $cards = $slider.find('.testimonial-card');
		let current = 0;

		function activateSlide(index) {
			$cards.removeClass('is-active');
			$cards.eq(index).addClass('is-active');
		}

		if ($cards.length > 1) {
			setInterval(function () {
				current = (current + 1) % $cards.length;
				activateSlide(current);
			}, 7000);
		}
	}

	function initFormValidation() {
		const $form = $('.js-contact-form');
		if (!$form.length) {
			return;
		}

		$form.on('submit', function (event) {
			let valid = true;
			$form.find('[required]').each(function () {
				const $field = $(this);
				if (!$field.val()) {
					valid = false;
					$field.addClass('has-error');
				} else {
					$field.removeClass('has-error');
				}
			});

			const emailField = $form.find('input[type="email"]');
			if (emailField.length && emailField.val()) {
				const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
				if (!emailPattern.test(emailField.val())) {
					valid = false;
					emailField.addClass('has-error');
				}
			}

			if (!valid) {
				event.preventDefault();
			}
		});

		$form.find('input, textarea, select').on('input change', function () {
			$(this).removeClass('has-error');
		});
	}

	$document.ready(function () {
		initNavigation();
		initStickyHeader();
		initBackToTop();
		initCookieBanner();
		initTestimonialSlider();
		initFormValidation();
	});
})(jQuery);
```