```php
<?php
/**
 * Header template.
 *
 * @package Aurion_Energy
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#site-content"><?php esc_html_e( 'Skip to content', 'aurion-energy' ); ?></a>

<header class="site-header" data-header-sticky="true">
	<div class="top-bar">
		<div class="container top-bar-inner">
			<p class="header-tagline"><?php echo esc_html( get_theme_mod( 'aurion_contact_tagline', __( 'Engineering the Future of Energy', 'aurion-energy' ) ) ); ?></p>
			<div class="header-contact">
				<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ) ); ?>">
					<?php echo esc_html( get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ); ?>
				</a>
				<a href="mailto:<?php echo esc_attr( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?>">
					<?php echo esc_html( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?>
				</a>
			</div>
		</div>
	</div>
	<div class="container header-main">
		<div class="site-branding">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				?>
				<a class="site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
				<?php
			}
			?>
		</div>
		<nav class="primary-navigation" aria-label="<?php esc_attr_e( 'Primary navigation', 'aurion-energy' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_id'        => 'primary-menu',
					'menu_class'     => 'menu',
					'container'      => false,
					'fallback_cb'    => '__return_false',
				)
			);
			?>
		</nav>
		<button class="nav-toggle" aria-expanded="false" aria-controls="primary-menu">
			<span class="nav-toggle-bar"></span>
			<span class="nav-toggle-bar"></span>
			<span class="nav-toggle-bar"></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Toggle navigation', 'aurion-energy' ); ?></span>
		</button>
	</div>
</header>

<div id="cookie-consent" class="cookie-banner" role="dialog" aria-live="polite" aria-label="<?php esc_attr_e( 'Cookie consent', 'aurion-energy' ); ?>">
	<div class="cookie-banner-inner container">
		<p>
			<?php esc_html_e( 'We use cookies to enhance your browsing experience and analyse site traffic.', 'aurion-energy' ); ?>
			<a href="<?php echo esc_url( get_permalink( get_page_by_path( 'cookie-policy' ) ) ?: home_url( '/' ) ); ?>">
				<?php esc_html_e( 'Read our cookie policy.', 'aurion-energy' ); ?>
			</a>
		</p>
		<div class="cookie-actions">
			<button class="btn btn-secondary" type="button" id="cookie-decline"><?php esc_html_e( 'Decline', 'aurion-energy' ); ?></button>
			<button class="btn btn-primary" type="button" id="cookie-accept"><?php esc_html_e( 'Accept', 'aurion-energy' ); ?></button>
		</div>
	</div>
</div>
```