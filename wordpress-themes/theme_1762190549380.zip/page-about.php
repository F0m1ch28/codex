```php
<?php
/**
 * Template Name: About Page
 *
 * @package Aurion_Energy
 */

get_header();

$hero_image = 'https://picsum.photos/1920/800?random=31';
?>
<main id="site-content" class="page-default about-page">
	<section class="page-hero" style="background-image: url('<?php echo esc_url( $hero_image ); ?>');">
		<div class="page-hero-overlay"></div>
		<div class="container">
			<h1><?php the_title(); ?></h1>
			<?php aurion_energy_breadcrumbs(); ?>
		</div>
	</section>

	<section class="section about-story">
		<div class="container split-grid">
			<div class="text-column">
				<h2><?php esc_html_e( 'Our Story', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'Founded in Toronto, Aurion Energy Advisory emerged from a collective of project engineers and consultants who understood the pressures facing energy operations. Today we partner with upstream and industrial clients across North America, combining field experience with data-driven insights to keep critical assets online.', 'aurion-energy' ); ?></p>
				<p><?php esc_html_e( 'We deliver multidisciplinary support that spans feasibility studies, major equipment installation, and sustainability strategy. Throughout each engagement, our teams stay embedded with client stakeholders to guarantee every recommendation is actionable, defensible, and aligned with operational objectives.', 'aurion-energy' ); ?></p>
			</div>
			<div class="image-column">
				<img src="https://picsum.photos/800/600?random=32" alt="<?php esc_attr_e( 'Aurion project team reviewing engineering schematics', 'aurion-energy' ); ?>">
			</div>
		</div>
	</section>

	<section class="section values">
		<div class="container">
			<h2 class="section-title"><?php esc_html_e( 'Our Values', 'aurion-energy' ); ?></h2>
			<div class="card-grid">
				<div class="value-card">
					<h3><?php esc_html_e( 'Integrity First', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Transparent communication and evidence-based recommendations underpin every client relationship.', 'aurion-energy' ); ?></p>
				</div>
				<div class="value-card">
					<h3><?php esc_html_e( 'Safety & Reliability', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'We design programmes that protect people, facilities, and the ecosystems that support them.', 'aurion-energy' ); ?></p>
				</div>
				<div class="value-card">
					<h3><?php esc_html_e( 'Collaboration', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Our teams work shoulder-to-shoulder with client resources to ensure knowledge transfer and long-term resilience.', 'aurion-energy' ); ?></p>
				</div>
				<div class="value-card">
					<h3><?php esc_html_e( 'Technical Excellence', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Continuous learning and certification keep Aurion specialists at the forefront of industry standards.', 'aurion-energy' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<section class="section timeline">
		<div class="container">
			<h2 class="section-title"><?php esc_html_e( 'Milestones', 'aurion-energy' ); ?></h2>
			<ul class="timeline-list">
				<li>
					<div class="timeline-year">2014</div>
					<div class="timeline-content">
						<h3><?php esc_html_e( 'Aurion Energy Advisory Established', 'aurion-energy' ); ?></h3>
						<p><?php esc_html_e( 'Our founding team launched the firm to bridge engineering execution with strategic consulting.', 'aurion-energy' ); ?></p>
					</div>
				</li>
				<li>
					<div class="timeline-year">2017</div>
					<div class="timeline-content">
						<h3><?php esc_html_e( 'Major Turnaround Programme', 'aurion-energy' ); ?></h3>
						<p><?php esc_html_e( 'Delivered multi-discipline coordination for a refinery upgrade across four provinces.', 'aurion-energy' ); ?></p>
					</div>
				</li>
				<li>
					<div class="timeline-year">2020</div>
					<div class="timeline-content">
						<h3><?php esc_html_e( 'Sustainability Practice Launched', 'aurion-energy' ); ?></h3>
						<p><?php esc_html_e( 'Introduced lifecycle planning and emissions assessment services to support client ESG objectives.', 'aurion-energy' ); ?></p>
					</div>
				</li>
				<li>
					<div class="timeline-year">2023</div>
					<div class="timeline-content">
						<h3><?php esc_html_e( 'Integrated Digital Field Monitoring', 'aurion-energy' ); ?></h3>
						<p><?php esc_html_e( 'Deployed instrumentation programmes combining IoT analytics with predictive maintenance insights.', 'aurion-energy' ); ?></p>
					</div>
				</li>
			</ul>
		</div>
	</section>

	<section class="section leadership">
		<div class="container">
			<h2 class="section-title"><?php esc_html_e( 'Leadership Team', 'aurion-energy' ); ?></h2>
			<div class="card-grid">
				<?php
				$leaders = new WP_Query(
					array(
						'post_type'      => 'team-members',
						'posts_per_page' => 6,
					)
				);

				if ( $leaders->have_posts() ) :
					while ( $leaders->have_posts() ) :
						$leaders->the_post();
						$role = get_post_meta( get_the_ID(), 'role_title', true );
						?>
						<article class="team-card">
							<div class="team-photo">
								<?php
								if ( has_post_thumbnail() ) {
									the_post_thumbnail( 'team-portrait', array( 'alt' => esc_attr( get_the_title() ) ) );
								} else {
									echo '<img src="https://picsum.photos/400/500?random=' . esc_attr( get_the_ID() + 10 ) . '" alt="' . esc_attr( get_the_title() ) . '">';
								}
								?>
							</div>
							<div class="team-info">
								<h3><?php the_title(); ?></h3>
								<p class="team-role"><?php echo esc_html( $role ? $role : __( 'Leadership Team', 'aurion-energy' ) ); ?></p>
								<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22, '…' ) ); ?></p>
								<a class="btn-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read bio', 'aurion-energy' ); ?></a>
							</div>
						</article>
						<?php
					endwhile;
					wp_reset_postdata();
				else :
					?>
					<article class="team-card">
						<img src="https://picsum.photos/400/500?random=33" alt="<?php esc_attr_e( 'Aurion leadership placeholder', 'aurion-energy' ); ?>">
						<div class="team-info">
							<h3><?php esc_html_e( 'Leadership Team', 'aurion-energy' ); ?></h3>
							<p><?php esc_html_e( 'Aurion leaders bring together decades of experience across energy consulting and industrial engineering.', 'aurion-energy' ); ?></p>
						</div>
					</article>
					<?php
				endif;
				?>
			</div>
		</div>
	</section>

	<section class="section safety">
		<div class="container split-grid">
			<div class="text-column">
				<h2><?php esc_html_e( 'Commitment to Safety & Sustainability', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'We operate under a safety-first mindset. Aurion’s procedural frameworks exceed provincial and federal standards, supported by rigorous training and ongoing competency assessments. Environmental guardianship forms a core part of our decision-making, from conceptual design through to decommissioning.', 'aurion-energy' ); ?></p>
				<ul class="feature-list">
					<li><?php esc_html_e( 'ISNetworld and COR certified subcontractor networks', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Environmental mitigation plans integrated with project schedules', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Regular safety drills and reporting dashboards for stakeholders', 'aurion-energy' ); ?></li>
				</ul>
			</div>
			<div class="image-column">
				<img src="https://picsum.photos/800/600?random=34" alt="<?php esc_attr_e( 'Field safety inspection conducted by Aurion team', 'aurion-energy' ); ?>">
			</div>
		</div>
	</section>
</main>
<?php
get_footer();
```