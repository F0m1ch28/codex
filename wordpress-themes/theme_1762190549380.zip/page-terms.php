```php
<?php
/**
 * Template Name: Terms of Use
 *
 * @package Aurion_Energy
 */

get_header();
?>
<main id="site-content" class="page-default legal-page">
	<section class="page-hero legal-hero">
		<div class="container">
			<h1><?php esc_html_e( 'Terms of Use', 'aurion-energy' ); ?></h1>
			<?php aurion_energy_breadcrumbs(); ?>
		</div>
	</section>

	<section class="section legal-content">
		<div class="container legal-text">
			<p><strong><?php esc_html_e( 'Effective Date:', 'aurion-energy' ); ?></strong> <?php echo esc_html( date_i18n( 'F j, Y' ) ); ?></p>

			<h2><?php esc_html_e( '1. Acceptance of Terms', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'By accessing or using the Aurion Energy Advisory website (the “Site”), you acknowledge that you have read, understood, and agree to be bound by these Terms of Use (“Terms”). If you do not agree with these Terms, please refrain from using the Site.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '2. Use of the Site', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'You may use the Site solely for lawful purposes and in accordance with these Terms. You agree not to use the Site in any manner that could damage, disable, overburden, or impair the Site or interfere with any other party’s use of the Site.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '3. Intellectual Property', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'All content, design elements, graphics, and documentation on the Site are the property of Aurion Energy Advisory or its licensors and are protected by applicable intellectual property laws. You may not reproduce, distribute, or create derivative works from any content without prior written consent.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '4. Informational Purposes Only', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Content published on the Site is provided for informational purposes. While we strive for accuracy, the information may not reflect the most current developments. Decisions should not be made solely on the basis of Site content without consulting Aurion Energy Advisory directly.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '5. Third-Party Links', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'The Site may include links to third-party websites for convenience. Aurion Energy Advisory does not control and is not responsible for the content or practices of any third-party websites. Accessing such sites is at your own risk.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '6. Privacy', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Your use of the Site is also governed by our Privacy Policy, which explains how we collect, use, and safeguard personal information. By using the Site, you consent to the practices described in the Privacy Policy.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '7. Limitation of Liability', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'To the maximum extent permitted by law, Aurion Energy Advisory shall not be liable for any direct, indirect, incidental, or consequential damages arising from your use of the Site or reliance on any information provided.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '8. Indemnification', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'You agree to indemnify and hold harmless Aurion Energy Advisory, its affiliates, and employees from any claims, losses, liabilities, and expenses arising from your violation of these Terms or misuse of the Site.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '9. Changes to These Terms', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Aurion Energy Advisory reserves the right to modify these Terms at any time. Changes will be posted on this page with an updated effective date. Your continued use of the Site constitutes acceptance of any changes.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '10. Governing Law', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'These Terms are governed by the laws of the Province of Ontario and the laws of Canada applicable therein. Any disputes shall be resolved in the courts located in Toronto, Ontario.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '11. Contact Information', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'If you have questions about these Terms, please contact us at:', 'aurion-energy' ); ?></p>
			<address>
				Aurion Energy Advisory<br>
				460 Bay St, Toronto, ON M5H 2Y4, Canada<br>
				<a href="mailto:<?php echo esc_attr( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?>"><?php echo esc_html( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?></a><br>
				<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ) ); ?>"><?php echo esc_html( get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ); ?></a>
			</address>

			<p><?php esc_html_e( 'By using the Site, you acknowledge that you have read and understand these Terms of Use.', 'aurion-energy' ); ?></p>
		</div>
	</section>
</main>
<?php
get_footer();
```