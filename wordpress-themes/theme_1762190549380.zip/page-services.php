```php
<?php
/**
 * Template Name: Services Page
 *
 * @package Aurion_Energy
 */

get_header();

$hero_image = 'https://picsum.photos/1920/800?random=41';
?>
<main id="site-content" class="page-default services-page">
	<section class="page-hero" style="background-image: url('<?php echo esc_url( $hero_image ); ?>');">
		<div class="page-hero-overlay"></div>
		<div class="container">
			<h1><?php the_title(); ?></h1>
			<?php aurion_energy_breadcrumbs(); ?>
		</div>
	</section>

	<section class="section service-overview">
		<div class="container">
			<h2 class="section-title"><?php esc_html_e( 'Integrated Capabilities', 'aurion-energy' ); ?></h2>
			<p class="section-lead"><?php esc_html_e( 'Aurion Energy Advisory delivers a connected suite of consulting, research, and engineering services tailored to complex energy infrastructure across Canada and beyond.', 'aurion-energy' ); ?></p>
		</div>
	</section>

	<section class="section service-detail">
		<div class="container">
			<article class="service-detail-card">
				<div class="service-detail-media">
					<img src="https://picsum.photos/800/600?random=42" alt="<?php esc_attr_e( 'Consultants reviewing energy infrastructure strategy', 'aurion-energy' ); ?>">
				</div>
				<div class="service-detail-content">
					<h2><?php esc_html_e( 'Energy Consulting', 'aurion-energy' ); ?></h2>
					<p><?php esc_html_e( 'We guide executive and field teams through planning, feasibility, and execution decisions. Our consultants draw on asset performance data, regulatory requirements, and stakeholder priorities to ensure every project advances strategic goals.', 'aurion-energy' ); ?></p>
					<ul class="feature-list">
						<li><?php esc_html_e( 'Asset readiness assessments and due diligence', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Infrastructure roadmap development with cross-functional input', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Regulatory submissions and documentation support', 'aurion-energy' ); ?></li>
					</ul>
				</div>
			</article>

			<article class="service-detail-card reverse">
				<div class="service-detail-media">
					<img src="https://picsum.photos/800/600?random=43" alt="<?php esc_attr_e( 'Researchers analysing oilfield data visualisations', 'aurion-energy' ); ?>">
				</div>
				<div class="service-detail-content">
					<h2><?php esc_html_e( 'Oilfield Research', 'aurion-energy' ); ?></h2>
					<p><?php esc_html_e( 'Our research group combines geoscience expertise with real-time monitoring to deliver precise insights on reservoirs, production performance, and asset reliability. We translate technical findings into clear recommendations.', 'aurion-energy' ); ?></p>
					<ul class="feature-list">
						<li><?php esc_html_e( 'Subsurface interpretation and volumetric analysis', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Production diagnostics and decline curve evaluation', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Compliance audits and reporting for federal and provincial standards', 'aurion-energy' ); ?></li>
					</ul>
				</div>
			</article>

			<article class="service-detail-card">
				<div class="service-detail-media">
					<img src="https://picsum.photos/800/600?random=44" alt="<?php esc_attr_e( 'Crane installation supervision at industrial site', 'aurion-energy' ); ?>">
				</div>
				<div class="service-detail-content">
					<h2><?php esc_html_e( 'Engineering Solutions', 'aurion-energy' ); ?></h2>
					<p><?php esc_html_e( 'Aurion engineers manage end-to-end installation and commissioning programmes. From crane selection to final verification, we ensure every phase follows structured safety protocols and quality expectations.', 'aurion-energy' ); ?></p>
					<ul class="feature-list">
						<li><?php esc_html_e( 'Heavy-lift planning and rigging certifications', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Construction sequencing and contractor oversight', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Commissioning procedures and digital turnover packages', 'aurion-energy' ); ?></li>
					</ul>
				</div>
			</article>

			<article class="service-detail-card reverse">
				<div class="service-detail-media">
					<img src="https://picsum.photos/800/600?random=45" alt="<?php esc_attr_e( 'Environmental specialist conducting site assessment', 'aurion-energy' ); ?>">
				</div>
				<div class="service-detail-content">
					<h2><?php esc_html_e( 'Environmental Assessment', 'aurion-energy' ); ?></h2>
					<p><?php esc_html_e( 'We support environmental accountability through detailed baseline studies, mitigation planning, and ongoing monitoring. Our specialists collaborate with regulatory bodies to maintain compliance across project lifecycles.', 'aurion-energy' ); ?></p>
					<ul class="feature-list">
						<li><?php esc_html_e( 'Environmental impact studies and stakeholder engagement', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Emissions tracking and reporting dashboards', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Reclamation strategies and closure documentation', 'aurion-energy' ); ?></li>
					</ul>
				</div>
			</article>

			<article class="service-detail-card">
				<div class="service-detail-media">
					<img src="https://picsum.photos/800/600?random=46" alt="<?php esc_attr_e( 'Project managers coordinating infrastructure schedule', 'aurion-energy' ); ?>">
				</div>
				<div class="service-detail-content">
					<h2><?php esc_html_e( 'Project Management', 'aurion-energy' ); ?></h2>
					<p><?php esc_html_e( 'Complex programmes demand rigorous coordination. Aurion project managers integrate schedule, cost, and risk controls with on-site leadership to deliver predictable outcomes.', 'aurion-energy' ); ?></p>
					<ul class="feature-list">
						<li><?php esc_html_e( 'Stage-gate project planning and governance', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Integrated risk registers and mitigation planning', 'aurion-energy' ); ?></li>
						<li><?php esc_html_e( 'Stakeholder reporting with performance dashboards', 'aurion-energy' ); ?></li>
					</ul>
				</div>
			</article>
		</div>
	</section>

	<section class="section service-cta">
		<div class="container cta-inner">
			<h2><?php esc_html_e( 'Ready to discuss your next project?', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Connect with our consulting team to design a roadmap tailored to your operational objectives.', 'aurion-energy' ); ?></p>
			<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact Aurion', 'aurion-energy' ); ?></a>
		</div>
	</section>
</main>
<?php
get_footer();
```