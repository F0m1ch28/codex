```php
<?php
/**
 * Template Name: Cookie Policy
 *
 * @package Aurion_Energy
 */

get_header();
?>
<main id="site-content" class="page-default legal-page">
	<section class="page-hero legal-hero">
		<div class="container">
			<h1><?php esc_html_e( 'Cookie Policy', 'aurion-energy' ); ?></h1>
			<?php aurion_energy_breadcrumbs(); ?>
		</div>
	</section>

	<section class="section legal-content">
		<div class="container legal-text">
			<p><strong><?php esc_html_e( 'Effective Date:', 'aurion-energy' ); ?></strong> <?php echo esc_html( date_i18n( 'F j, Y' ) ); ?></p>

			<p><?php esc_html_e( 'This Cookie Policy explains how Aurion Energy Advisory (“Aurion”, “we”, “our”) uses cookies and similar technologies on our website.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '1. What Are Cookies?', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Cookies are small text files stored on your device when you visit a website. They help the site remember your preferences and improve usability. Some cookies are necessary for the website to function, while others support analytics or personalization.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '2. Types of Cookies We Use', 'aurion-energy' ); ?></h2>
			<ul>
				<li><strong><?php esc_html_e( 'Essential Cookies:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Enable core functionality such as page navigation and access to secure areas. The website cannot function properly without these cookies.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Analytics Cookies:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Help us understand how visitors interact with the Site by collecting information anonymously.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Preference Cookies:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Remember your settings and choices to provide a more personalised experience.', 'aurion-energy' ); ?></li>
			</ul>

			<h2><?php esc_html_e( '3. Third-Party Cookies', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'We may use third-party services that set cookies on our behalf to perform analytics or deliver content. These third parties have their own privacy policies outlining how they use data.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '4. Managing Your Preferences', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'You can manage or disable cookies through your browser settings. Most browsers allow you to refuse or delete cookies. Note that disabling essential cookies may impact the functionality of the Site.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '5. Consent', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'When you first visit our Site, you are prompted to accept or decline non-essential cookies. Your preference is stored using a cookie so that we can honour your choice on subsequent visits.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '6. Updates to This Policy', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'We may update this Cookie Policy to reflect changes in technology or legal requirements. Updates will be posted on this page with a new effective date.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '7. Contact Us', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'If you have questions about our use of cookies, please contact Aurion Energy Advisory at:', 'aurion-energy' ); ?></p>
			<address>
				460 Bay St, Toronto, ON M5H 2Y4, Canada<br>
				<a href="mailto:<?php echo esc_attr( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?>"><?php echo esc_html( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?></a><br>
				<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ) ); ?>"><?php echo esc_html( get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ); ?></a>
			</address>
		</div>
	</section>
</main>
<?php
get_footer();
```