```php
<?php
/**
 * Template Name: Privacy Policy
 *
 * @package Aurion_Energy
 */

get_header();
?>
<main id="site-content" class="page-default legal-page">
	<section class="page-hero legal-hero">
		<div class="container">
			<h1><?php esc_html_e( 'Privacy Policy', 'aurion-energy' ); ?></h1>
			<?php aurion_energy_breadcrumbs(); ?>
		</div>
	</section>

	<section class="section legal-content">
		<div class="container legal-text">
			<p><strong><?php esc_html_e( 'Effective Date:', 'aurion-energy' ); ?></strong> <?php echo esc_html( date_i18n( 'F j, Y' ) ); ?></p>

			<p><?php esc_html_e( 'Aurion Energy Advisory (“Aurion”, “we”, “our”, or “us”) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard personal information when you visit our website or communicate with us.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '1. Information We Collect', 'aurion-energy' ); ?></h2>
			<ul>
				<li><strong><?php esc_html_e( 'Contact Information:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Includes your name, email address, phone number, and company details when you submit a contact form or communicate with us.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Usage Information:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Includes IP address, browser type, pages visited, and interaction with our website, collected through analytics tools and cookies.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Communications:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Includes correspondence and notes related to your enquiries or engagements with Aurion.', 'aurion-energy' ); ?></li>
			</ul>

			<h2><?php esc_html_e( '2. How We Use Information', 'aurion-energy' ); ?></h2>
			<ul>
				<li><?php esc_html_e( 'Respond to enquiries and provide requested information.', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'Manage and improve our services, website, and client experience.', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'Send updates or communications related to our services, subject to applicable consent requirements.', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'Meet legal, regulatory, or contractual obligations.', 'aurion-energy' ); ?></li>
			</ul>

			<h2><?php esc_html_e( '3. Legal Bases for Processing', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'We process personal information where lawful and appropriate, including based on your consent, to perform a contract, to comply with legal obligations, or to pursue legitimate business interests such as improving our services and maintaining site security.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '4. Sharing of Information', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'We do not sell personal information. We may share information with trusted service providers who assist in operating our website, sending communications, or delivering services, provided they agree to safeguard the information and use it only for authorised purposes.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '5. International Transfers', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Your information may be processed in jurisdictions where our service providers are located. We take steps to ensure that data transferred outside your jurisdiction receives a comparable level of protection.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '6. Data Retention', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'We retain personal information only as long as necessary for the purposes outlined in this policy or as required by law. Once no longer needed, information is securely deleted or anonymised.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '7. Your Rights', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Depending on your jurisdiction, you may have the right to access, correct, update, or delete your personal information, withdraw consent, restrict or object to processing, and request data portability. To exercise these rights, contact us using the details below.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '8. Cookies and Tracking Technologies', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'We use cookies and similar technologies to enhance user experience, analyse website performance, and tailor content. You can manage cookie preferences through your browser settings or via our Cookie Policy.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '9. Data Security', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Aurion implements administrative, technical, and physical safeguards designed to protect personal information against unauthorised access, alteration, or disclosure.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '10. Children’s Privacy', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Our website is not directed to individuals under the age of 16. We do not knowingly collect personal information from children. If you believe we have collected information from a child, please contact us to request deletion.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '11. Updates to This Policy', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'We may revise this Privacy Policy periodically. Updates will be posted on this page with a new effective date. Continued use of the Site after changes signifies acceptance of the updated policy.', 'aurion-energy' ); ?></p>

			<h2><?php esc_html_e( '12. Contact Us', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'For questions or to exercise your privacy rights, please contact Aurion Energy Advisory at:', 'aurion-energy' ); ?></p>
			<address>
				460 Bay St, Toronto, ON M5H 2Y4, Canada<br>
				<a href="mailto:<?php echo esc_attr( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?>"><?php echo esc_html( get_theme_mod( 'aurion_contact_email', 'info@aurionenergy.com' ) ); ?></a><br>
				<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ) ); ?>"><?php echo esc_html( get_theme_mod( 'aurion_contact_phone', '+1 (416) 792-4583' ) ); ?></a>
			</address>
		</div>
	</section>
</main>
<?php
get_footer();
```