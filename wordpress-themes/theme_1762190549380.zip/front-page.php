```php
<?php
/**
 * Front page template.
 *
 * @package Aurion_Energy
 */

get_header();

$hero_image = 'https://picsum.photos/1920/800?random=11';
?>
<main id="site-content" class="front-page">
	<section class="hero" style="background-image: url('<?php echo esc_url( $hero_image ); ?>');">
		<div class="hero-overlay"></div>
		<div class="container hero-content">
			<h1><?php esc_html_e( 'Engineering the Future of Energy', 'aurion-energy' ); ?></h1>
			<p><?php esc_html_e( 'Advanced consulting and industrial engineering solutions for energy sector infrastructure.', 'aurion-energy' ); ?></p>
			<div class="hero-actions">
				<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Explore Our Services', 'aurion-energy' ); ?></a>
				<a class="btn btn-secondary" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Get in Touch', 'aurion-energy' ); ?></a>
			</div>
		</div>
	</section>

	<section class="section intro" id="about">
		<div class="container intro-grid">
			<div>
				<h2><?php esc_html_e( 'Who We Are', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'Aurion Energy Advisory is a Toronto-based team of consultants, industrial engineers, and field specialists delivering reliable guidance across upstream and midstream energy operations. We align technology, compliance, and execution to keep critical infrastructure performing.', 'aurion-energy' ); ?></p>
			</div>
			<div class="intro-stats">
				<div class="stat-card">
					<h3><?php esc_html_e( 'Field-Tested Expertise', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Integrated research and engineering teams deliver actionable strategies tailored to complex environments.', 'aurion-energy' ); ?></p>
				</div>
				<div class="stat-card">
					<h3><?php esc_html_e( 'Sustainable Outcomes', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Our solutions prioritise lifecycle performance, safety, and environmental responsibility.', 'aurion-energy' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<section class="section services" id="services">
		<div class="container">
			<h2 class="section-title"><?php esc_html_e( 'Our Expertise', 'aurion-energy' ); ?></h2>
			<div class="card-grid">
				<article class="service-card">
					<div class="service-icon">
						<span class="material-icon" aria-hidden="true">&#9881;</span>
					</div>
					<h3><?php esc_html_e( 'Energy Consulting', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Strategic assessments that align infrastructure investments with operational goals and regulatory expectations.', 'aurion-energy' ); ?></p>
					<a class="btn-link" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Learn more', 'aurion-energy' ); ?></a>
				</article>
				<article class="service-card">
					<div class="service-icon">
						<span class="material-icon" aria-hidden="true">&#9921;</span>
					</div>
					<h3><?php esc_html_e( 'Oilfield Research', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Data-driven subsurface analysis, asset integrity reviews, and compliance reporting for field operations.', 'aurion-energy' ); ?></p>
					<a class="btn-link" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Learn more', 'aurion-energy' ); ?></a>
				</article>
				<article class="service-card">
					<div class="service-icon">
						<span class="material-icon" aria-hidden="true">&#9874;</span>
					</div>
					<h3><?php esc_html_e( 'Engineering Solutions', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Precision-led installation management, crane coordination, and commissioning support for heavy assets.', 'aurion-energy' ); ?></p>
					<a class="btn-link" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Learn more', 'aurion-energy' ); ?></a>
				</article>
				<article class="service-card">
					<div class="service-icon">
						<span class="material-icon" aria-hidden="true">&#9873;</span>
					</div>
					<h3><?php esc_html_e( 'Environmental Assessment', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Regulatory alignment, emissions reporting, and environmental stewardship planning for infrastructure programmes.', 'aurion-energy' ); ?></p>
					<a class="btn-link" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Learn more', 'aurion-energy' ); ?></a>
				</article>
				<article class="service-card">
					<div class="service-icon">
						<span class="material-icon" aria-hidden="true">&#128736;</span>
					</div>
					<h3><?php esc_html_e( 'Project Management', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Integrated planning, stakeholder alignment, and execution support to keep complex programmes on schedule.', 'aurion-energy' ); ?></p>
					<a class="btn-link" href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Learn more', 'aurion-energy' ); ?></a>
				</article>
			</div>
		</div>
	</section>

	<section class="section oilfield">
		<div class="container split-grid">
			<div class="image-column">
				<img src="https://picsum.photos/800/600?random=21" alt="<?php esc_attr_e( 'Aurion engineers analysing data for oilfield operations', 'aurion-energy' ); ?>">
			</div>
			<div class="text-column">
				<h2><?php esc_html_e( 'Oilfield Research & Compliance', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'Our research specialists combine geoscience insight with regulatory rigour. From exploratory modelling to production optimisation, we translate complex datasets into actionable plans for operating teams.', 'aurion-energy' ); ?></p>
				<ul class="feature-list">
					<li><?php esc_html_e( 'Reservoir modelling and production forecasting', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Integrity inspections and risk mitigation strategies', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Detailed reporting for Canadian and cross-border compliance', 'aurion-energy' ); ?></li>
				</ul>
			</div>
		</div>
	</section>

	<section class="section engineering">
		<div class="container split-grid">
			<div class="text-column">
				<h2><?php esc_html_e( 'Engineering & Installation Coordination', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'Aurion engineers plan, supervise, and validate heavy-lift operations, equipment installation, and commissioning assignments. Our approach combines safety-first procedures with on-the-ground leadership to keep every lift precise and every milestone on track.', 'aurion-energy' ); ?></p>
				<ul class="feature-list">
					<li><?php esc_html_e( 'Crane lift planning and rigging design', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Vendor coordination and site logistics oversight', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Commissioning checklists aligned with ISO and CSA standards', 'aurion-energy' ); ?></li>
				</ul>
			</div>
			<div class="image-column">
				<img src="https://picsum.photos/800/600?random=22" alt="<?php esc_attr_e( 'Installation team managing crane operations at energy facility', 'aurion-energy' ); ?>">
			</div>
		</div>
	</section>

	<section class="section sustainability">
		<div class="container">
			<div class="sustainability-card">
				<h2><?php esc_html_e( 'Sustainability in Practice', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'From emissions benchmarking to circular asset planning, we design pathways that move operational performance forward while reducing environmental impact.', 'aurion-energy' ); ?></p>
				<div class="highlight-grid">
					<div>
						<h3><?php esc_html_e( 'Lifecycle Reviews', 'aurion-energy' ); ?></h3>
						<p><?php esc_html_e( 'Facility-wide audits highlight energy efficiency opportunities and maintenance priorities.', 'aurion-energy' ); ?></p>
					</div>
					<div>
						<h3><?php esc_html_e( 'Carbon Strategy', 'aurion-energy' ); ?></h3>
						<p><?php esc_html_e( 'Scenario planning ensures sustainability commitments align with measurable results.', 'aurion-energy' ); ?></p>
					</div>
					<div>
						<h3><?php esc_html_e( 'Community Alignment', 'aurion-energy' ); ?></h3>
						<p><?php esc_html_e( 'Consultation frameworks foster trust with regulators, partners, and communities.', 'aurion-energy' ); ?></p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="section projects" id="projects">
		<div class="container">
			<h2 class="section-title"><?php esc_html_e( 'Featured Projects', 'aurion-energy' ); ?></h2>
			<div class="card-grid">
				<?php
				$projects_query = new WP_Query(
					array(
						'post_type'      => 'projects',
						'posts_per_page' => 3,
					)
				);

				if ( $projects_query->have_posts() ) :
					while ( $projects_query->have_posts() ) :
						$projects_query->the_post();
						?>
						<article class="project-card">
							<a href="<?php the_permalink(); ?>" class="project-thumb">
								<?php
								if ( has_post_thumbnail() ) {
									the_post_thumbnail( 'project-thumb', array( 'alt' => esc_attr( get_the_title() ) ) );
								} else {
									echo '<img src="https://placehold.co/600x400/E2E8F0/475569?text=' . rawurlencode( get_the_title() ) . '" alt="' . esc_attr( get_the_title() ) . '">';
								}
								?>
							</a>
							<div class="project-content">
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '…' ) ); ?></p>
								<a class="btn-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View details', 'aurion-energy' ); ?></a>
							</div>
						</article>
						<?php
					endwhile;
					wp_reset_postdata();
				else :
					?>
					<article class="project-card">
						<img src="https://picsum.photos/600/400?random=23" alt="<?php esc_attr_e( 'Energy infrastructure project case study placeholder', 'aurion-energy' ); ?>">
						<div class="project-content">
							<h3><?php esc_html_e( 'Infrastructure Upgrade Programme', 'aurion-energy' ); ?></h3>
							<p><?php esc_html_e( 'Optimised heavy-lift sequencing and integrity verification for a multi-phase pipeline facility expansion.', 'aurion-energy' ); ?></p>
							<a class="btn-link" href="<?php echo esc_url( home_url( '/projects/' ) ); ?>"><?php esc_html_e( 'View details', 'aurion-energy' ); ?></a>
						</div>
					</article>
					<?php
				endif;
				?>
			</div>
		</div>
	</section>

	<section class="section testimonials">
		<div class="container">
			<h2 class="section-title"><?php esc_html_e( 'Client Perspectives', 'aurion-energy' ); ?></h2>
			<div class="testimonial-slider" data-slider="true">
				<div class="testimonial-card is-active">
					<p class="testimonial-quote">&ldquo;Aurion provided disciplined project controls and an engineering perspective that kept our offshore upgrade running smoothly.&rdquo;</p>
					<p class="testimonial-author">Jamie Stewart, Operations Director &middot; North Channel Resources</p>
					<div class="testimonial-rating" aria-label="<?php esc_attr_e( 'Five star rating', 'aurion-energy' ); ?>">
						<span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span>
					</div>
				</div>
				<div class="testimonial-card">
					<p class="testimonial-quote">&ldquo;Their research team translated complex subsurface data into confident decisions that satisfied both our technical and regulatory stakeholders.&rdquo;</p>
					<p class="testimonial-author">Priya Desai, Exploration Manager &middot; Meridian Energy Partners</p>
					<div class="testimonial-rating" aria-label="<?php esc_attr_e( 'Five star rating', 'aurion-energy' ); ?>">
						<span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span>
					</div>
				</div>
				<div class="testimonial-card">
					<p class="testimonial-quote">&ldquo;Aurion’s installation management team coordinated every crane pick with precision, reducing downtime across our turnaround schedule.&rdquo;</p>
					<p class="testimonial-author">Martin Chen, Turnaround Lead &middot; Northern Prairie Refining</p>
					<div class="testimonial-rating" aria-label="<?php esc_attr_e( 'Five star rating', 'aurion-energy' ); ?>">
						<span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="section team" id="team">
		<div class="container">
			<div class="section-header">
				<h2><?php esc_html_e( 'Leadership Team', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'Engineers, planners, and researchers united by a commitment to operational excellence.', 'aurion-energy' ); ?></p>
			</div>
			<div class="card-grid">
				<?php
				$team_query = new WP_Query(
					array(
						'post_type'      => 'team-members',
						'posts_per_page' => 4,
					)
				);

				if ( $team_query->have_posts() ) :
					while ( $team_query->have_posts() ) :
						$team_query->the_post();
						$role = get_post_meta( get_the_ID(), 'role_title', true );
						?>
						<article class="team-card">
							<div class="team-photo">
								<?php
								if ( has_post_thumbnail() ) {
									the_post_thumbnail( 'team-portrait', array( 'alt' => esc_attr( get_the_title() ) ) );
								} else {
									echo '<img src="https://picsum.photos/400/500?random=' . esc_attr( get_the_ID() ) . '" alt="' . esc_attr( get_the_title() ) . '">';
								}
								?>
							</div>
							<div class="team-info">
								<h3><?php the_title(); ?></h3>
								<p class="team-role"><?php echo esc_html( $role ? $role : __( 'Team Lead', 'aurion-energy' ) ); ?></p>
								<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18, '…' ) ); ?></p>
								<a class="btn-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View profile', 'aurion-energy' ); ?></a>
							</div>
						</article>
						<?php
					endwhile;
					wp_reset_postdata();
				else :
					?>
					<article class="team-card">
						<img src="https://picsum.photos/400/500?random=24" alt="<?php esc_attr_e( 'Aurion leadership team member placeholder', 'aurion-energy' ); ?>">
						<div class="team-info">
							<h3><?php esc_html_e( 'Leah O’Connor', 'aurion-energy' ); ?></h3>
							<p class="team-role"><?php esc_html_e( 'Principal Engineer', 'aurion-energy' ); ?></p>
							<p><?php esc_html_e( 'Leads execution planning and technical oversight for large-scale installation programmes.', 'aurion-energy' ); ?></p>
						</div>
					</article>
					<?php
				endif;
				?>
			</div>
		</div>
	</section>

	<section class="section cta" id="contact">
		<div class="container cta-inner">
			<h2><?php esc_html_e( 'Partner with Aurion Energy Advisory', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Let our consultants and engineering teams support your next infrastructure milestone with clarity and precision.', 'aurion-energy' ); ?></p>
			<div class="cta-actions">
				<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Start a conversation', 'aurion-energy' ); ?></a>
				<a class="btn btn-outline" href="<?php echo esc_url( home_url( '/projects/' ) ); ?>"><?php esc_html_e( 'View case studies', 'aurion-energy' ); ?></a>
			</div>
		</div>
	</section>
</main>
<?php
get_footer();
```