<?php
/**
 * Header template.
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="aurion-skip-link" href="#primary-content"><?php esc_html_e( 'Skip to main content', 'aurion-energy' ); ?></a>
<header class="site-header" data-header>
	<div class="site-header__inner container">
		<div class="site-header__branding">
			<?php if ( has_custom_logo() ) : ?>
				<div class="site-logo"><?php the_custom_logo(); ?></div>
			<?php else : ?>
				<a class="site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
				<p class="site-tagline"><?php bloginfo( 'description' ); ?></p>
			<?php endif; ?>
		</div>
		<div class="site-header__nav">
			<nav class="primary-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'aurion-energy' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_class'     => 'primary-menu',
						'container'      => false,
						'fallback_cb'    => 'wp_page_menu',
					)
				);
				?>
			</nav>
			<button class="site-header__toggle" type="button" aria-expanded="false" aria-controls="mobile-menu" data-menu-toggle>
				<span class="site-header__toggle-line"></span>
				<span class="site-header__toggle-line"></span>
				<span class="site-header__toggle-line"></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Toggle navigation', 'aurion-energy' ); ?></span>
			</button>
		</div>
	</div>
	<div class="mobile-navigation" id="mobile-menu" hidden>
		<nav aria-label="<?php esc_attr_e( 'Mobile Menu', 'aurion-energy' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'mobile',
					'menu_class'     => 'mobile-menu',
					'container'      => false,
					'fallback_cb'    => 'wp_page_menu',
				)
			);
			?>
		</nav>
	</div>
</header>
<?php if ( ! is_front_page() ) : ?>
	<div class="site-hero--inner">
		<div class="container">
			<h1 class="site-hero--inner__title"><?php echo esc_html( get_the_title() ); ?></h1>
			<?php aurion_breadcrumbs(); ?>
		</div>
	</div>
<?php endif; ?>
<main id="primary-content" class="site-main">