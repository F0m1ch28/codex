<?php
/**
 * Template Name: Services Page
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="section section--services-detail">
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Comprehensive Services', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Aurion integrates strategy, engineering, and field coordination to deliver end-to-end solutions.', 'aurion-energy' ); ?></p>
		</div>
		<div class="cards cards--services cards--grid">
			<article class="card card--service" id="energy-consulting">
				<div class="card__icon" aria-hidden="true">📊</div>
				<h3 class="card__title"><?php esc_html_e( 'Energy Consulting', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Network modelling, capacity planning, and asset integrity programs that optimize performance across upstream, midstream, and industrial assets.', 'aurion-energy' ); ?></p>
				<ul class="card__list">
					<li><?php esc_html_e( 'Operational diagnostics and benchmarking', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Lifecycle planning and maintenance roadmaps', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Stakeholder facilitation and change management', 'aurion-energy' ); ?></li>
				</ul>
			</article>
			<article class="card card--service" id="oilfield-research">
				<div class="card__icon" aria-hidden="true">🧭</div>
				<h3 class="card__title"><?php esc_html_e( 'Oilfield Research', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Reservoir and production research services that support exploration decisions, regulatory compliance, and field development strategies.', 'aurion-energy' ); ?></p>
				<ul class="card__list">
					<li><?php esc_html_e( 'Geoscience interpretation and data integration', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Regulatory filings and stakeholder reporting', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Production optimization analytics', 'aurion-energy' ); ?></li>
				</ul>
			</article>
			<article class="card card--service" id="installation">
				<div class="card__icon" aria-hidden="true">🏗️</div>
				<h3 class="card__title"><?php esc_html_e( 'Installation & Coordination', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Crane planning, hoisting studies, and onsite coordination ensuring heavy lifts and infrastructure installs are precise and safe.', 'aurion-energy' ); ?></p>
				<ul class="card__list">
					<li><?php esc_html_e( 'Lift simulations and engineered rigging plans', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Equipment mobilization and logistics management', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Onsite supervision and control tower coordination', 'aurion-energy' ); ?></li>
				</ul>
			</article>
			<article class="card card--service" id="environmental-assessment">
				<div class="card__icon" aria-hidden="true">🌿</div>
				<h3 class="card__title"><?php esc_html_e( 'Environmental Assessment', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Comprehensive environmental reviews and ESG alignment services to manage risk and support sustainable development.', 'aurion-energy' ); ?></p>
				<ul class="card__list">
					<li><?php esc_html_e( 'Baseline studies and environmental impact analyses', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Mitigation plans and remediation oversight', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'ESG reporting frameworks and stakeholder engagement', 'aurion-energy' ); ?></li>
				</ul>
			</article>
			<article class="card card--service" id="project-management">
				<div class="card__icon" aria-hidden="true">🗂️</div>
				<h3 class="card__title"><?php esc_html_e( 'Project Management', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Full project lifecycle leadership, from initiation through commissioning, tailored to energy infrastructure programs.', 'aurion-energy' ); ?></p>
				<ul class="card__list">
					<li><?php esc_html_e( 'Integrated schedule and cost control', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Contractor alignment and vendor oversight', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Quality assurance and turnover documentation', 'aurion-energy' ); ?></li>
				</ul>
			</article>
		</div>
	</div>
</section>

<section class="section section--resources">
	<div class="container section__container section__container--split">
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Downloadable Resources', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Access technical briefs and project spotlights that illustrate how Aurion tackles unique energy challenges.', 'aurion-energy' ); ?></p>
			<ul class="list list--download">
				<li><a href="#"><?php esc_html_e( 'Industrial Crane Coordination Playbook (PDF)', 'aurion-energy' ); ?></a></li>
				<li><a href="#"><?php esc_html_e( 'Carbon Reduction in Brownfield Facilities (PDF)', 'aurion-energy' ); ?></a></li>
				<li><a href="#"><?php esc_html_e( 'Oilfield Data Integration Framework (PDF)', 'aurion-energy' ); ?></a></li>
			</ul>
		</div>
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Need Detailed Support?', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Our service leaders are available to walk through requirements, timelines, and resourcing for your upcoming initiative.', 'aurion-energy' ); ?></p>
			<a class="button button--primary" href="<?php echo esc_url( home_url( '/contact' ) ); ?>"><?php esc_html_e( 'Schedule Consultation', 'aurion-energy' ); ?></a>
		</div>
	</div>
</section>

<?php
get_footer();