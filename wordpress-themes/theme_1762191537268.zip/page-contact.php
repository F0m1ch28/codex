<?php
/**
 * Template Name: Contact Page
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="section section--contact">
	<div class="container section__container section__container--split">
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Get in Touch', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Let us know how we can support your next project. Our advisory team responds within one business day.', 'aurion-energy' ); ?></p>
			<ul class="list list--contact">
				<li><strong><?php esc_html_e( 'Address:', 'aurion-energy' ); ?></strong> 460 Bay St, Toronto, ON M5H 2Y4, Canada</li>
				<li><strong><?php esc_html_e( 'Phone:', 'aurion-energy' ); ?></strong> <a href="tel:+14167924583">+1 (416) 792-4583</a></li>
				<li><strong><?php esc_html_e( 'Email:', 'aurion-energy' ); ?></strong> <a href="mailto:contact@aurionenergy.com">contact@aurionenergy.com</a></li>
				<li><strong><?php esc_html_e( 'Office Hours:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Monday to Friday, 8:00 AM – 6:00 PM ET', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Response Time:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Within 24 hours', 'aurion-energy' ); ?></li>
			</ul>
			<div class="contact-map">
				<iframe title="<?php esc_attr_e( 'Aurion Energy Advisory Toronto Office', 'aurion-energy' ); ?>" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.812187487521!2d-79.38318482363692!3d43.65028177110221!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d4b0b46f0b%3A0x7dbac3e0c1cb555f!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4!5e0!3m2!1sen!2sca!4v1700000000000" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>
		</div>
		<div class="section__content">
			<form class="form js-aurion-contact-form" method="post" novalidate>
				<div class="form__group">
					<label for="contact-name"><?php esc_html_e( 'Name', 'aurion-energy' ); ?> *</label>
					<input type="text" id="contact-name" name="name" required>
				</div>
				<div class="form__group">
					<label for="contact-email"><?php esc_html_e( 'Email', 'aurion-energy' ); ?> *</label>
					<input type="email" id="contact-email" name="email" required>
				</div>
				<div class="form__group">
					<label for="contact-phone"><?php esc_html_e( 'Phone', 'aurion-energy' ); ?></label>
					<input type="tel" id="contact-phone" name="phone">
				</div>
				<div class="form__group">
					<label for="contact-company"><?php esc_html_e( 'Company', 'aurion-energy' ); ?></label>
					<input type="text" id="contact-company" name="company">
				</div>
				<div class="form__group">
					<label for="contact-subject"><?php esc_html_e( 'Subject', 'aurion-energy' ); ?> *</label>
					<input type="text" id="contact-subject" name="subject" required>
				</div>
				<div class="form__group">
					<label for="contact-message"><?php esc_html_e( 'Message', 'aurion-energy' ); ?> *</label>
					<textarea id="contact-message" name="message" rows="6" required></textarea>
				</div>
				<div class="form__actions">
					<button class="button button--primary" type="submit"><?php esc_html_e( 'Send Message', 'aurion-energy' ); ?></button>
					<input type="hidden" name="action" value="aurion_contact_form">
					<?php wp_nonce_field( 'aurion_contact_nonce', 'aurion_contact_nonce_field' ); ?>
					<div class="form__response" aria-live="polite"></div>
				</div>
			</form>
		</div>
	</div>
</section>

<?php
get_footer();