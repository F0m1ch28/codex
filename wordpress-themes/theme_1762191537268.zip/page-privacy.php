<?php
/**
 * Template Name: Privacy Policy
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="section section--legal">
	<div class="container">
		<h2 class="section__title"><?php esc_html_e( 'Privacy Policy', 'aurion-energy' ); ?></h2>
		<p class="section__meta"><?php esc_html_e( 'Last updated: January 1, 2024', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Introduction', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Aurion Energy Advisory respects your privacy and is committed to protecting your personal information. This policy describes how we collect, use, and safeguard data when you visit aurionenergy.com or engage with our services.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Information We Collect', 'aurion-energy' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Contact details provided through web forms or communications (name, email, phone, company).', 'aurion-energy' ); ?></li>
			<li><?php esc_html_e( 'Professional details necessary to discuss service inquiries.', 'aurion-energy' ); ?></li>
			<li><?php esc_html_e( 'Technical data such as IP address, browser type, and usage patterns via analytics tools.', 'aurion-energy' ); ?></li>
		</ul>

		<h3><?php esc_html_e( 'How We Use Information', 'aurion-energy' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'To respond to inquiries and provide requested services.', 'aurion-energy' ); ?></li>
			<li><?php esc_html_e( 'To manage business relationships and maintain records in compliance with Canadian regulations.', 'aurion-energy' ); ?></li>
			<li><?php esc_html_e( 'To improve website performance and user experience.', 'aurion-energy' ); ?></li>
		</ul>

		<h3><?php esc_html_e( 'Data Sharing', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'We do not sell personal information. Data may be shared with trusted service providers who support our operations under strict confidentiality agreements, or when required by law.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Cookies and Analytics', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'We use cookies to enhance site functionality and analyze traffic. You can manage cookie preferences through your browser settings or our cookie banner. Analytics data is processed in aggregate and does not identify individual users.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Data Security', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Aurion Energy Advisory employs administrative, technical, and physical safeguards to protect personal information against unauthorized access, disclosure, or misuse.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Retention', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'We retain personal information only as long as necessary to fulfill the purposes outlined in this policy and comply with legal obligations.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Your Rights', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Depending on your jurisdiction, you may have rights to access, correct, or delete personal data held by us. Submit requests to contact@aurionenergy.com, and we will respond within applicable timelines.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'International Transfers', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Aurion Energy Advisory operates primarily in Canada. If data is processed outside Canada, we ensure appropriate safeguards consistent with Canadian privacy laws.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Policy Updates', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'We may update this policy to reflect regulatory changes or operational updates. Revisions will be posted with an updated effective date.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Contact', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'For privacy questions or requests, contact our Privacy Officer at contact@aurionenergy.com.', 'aurion-energy' ); ?></p>
	</div>
</section>

<?php
get_footer();