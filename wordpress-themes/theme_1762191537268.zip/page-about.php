<?php
/**
 * Template Name: About Page
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="section section--about">
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Our Story', 'aurion-energy' ); ?></h2>
		</div>
		<div class="section__content">
			<p><?php esc_html_e( 'Aurion Energy Advisory was founded in Toronto by engineering leaders who recognized the need for a consultancy capable of bridging strategic thinking with practical field execution. We combine decades of experience in industrial engineering, oilfield research, and complex crane logistics to support clients navigating Canada’s evolving energy landscape.', 'aurion-energy' ); ?></p>
			<p><?php esc_html_e( 'From early feasibility studies to full-scope implementation, our multidisciplinary team partners with operators, developers, and industrial stakeholders to confront operational challenges head-on. We deliver evidence-based insights and fully coordinated delivery plans that bring projects online safely, efficiently, and with lasting value.', 'aurion-energy' ); ?></p>
			<p><?php esc_html_e( 'Today, Aurion continues to expand its footprint across North America while maintaining the client-first principles that defined our beginnings: integrity, technical rigor, and a relentless focus on execution.', 'aurion-energy' ); ?></p>
		</div>
	</div>
</section>

<section class="section section--mission">
	<div class="container section__container section__container--split">
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Mission & Values', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Aurion delivers resilient energy infrastructure solutions that balance operational excellence with environmental stewardship. Our work is guided by core values that shape every engagement.', 'aurion-energy' ); ?></p>
			<ul class="list list--values">
				<li><strong><?php esc_html_e( 'Technical Integrity:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'We ground our recommendations in science, data, and proven engineering discipline.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Collaboration:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Stakeholders, field teams, and consultants work as one integrated unit.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Safety Leadership:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'We embed risk mitigation, training, and compliance into every plan.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Sustainable Innovation:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Resource-conscious design and emissions reduction strategies are prioritized from the outset.', 'aurion-energy' ); ?></li>
			</ul>
		</div>
		<div class="section__media">
			<img src="https://picsum.photos/800/600?industrial=5" alt="<?php esc_attr_e( 'Engineers reviewing industrial blueprints', 'aurion-energy' ); ?>">
		</div>
	</div>
</section>

<section class="section section--leadership">
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Leadership Team', 'aurion-energy' ); ?></h2>
		</div>
		<div class="cards cards--team">
			<article class="card card--team">
				<img class="card__image" src="https://picsum.photos/400/400?portrait=1" alt="<?php esc_attr_e( 'Portrait of Elena Martel', 'aurion-energy' ); ?>">
				<div class="card__body">
					<h3 class="card__title"><?php esc_html_e( 'Elena Martel, P.Eng.', 'aurion-energy' ); ?></h3>
					<p class="card__text"><?php esc_html_e( 'Managing Director', 'aurion-energy' ); ?></p>
					<p class="card__text card__text--small"><?php esc_html_e( 'Elena leads Aurion’s integrated consulting practice with 18 years of experience in heavy industrial design and energy program governance.', 'aurion-energy' ); ?></p>
				</div>
			</article>
			<article class="card card--team">
				<img class="card__image" src="https://picsum.photos/400/400?portrait=2" alt="<?php esc_attr_e( 'Portrait of Michael Summers', 'aurion-energy' ); ?>">
				<div class="card__body">
					<h3 class="card__title"><?php esc_html_e( 'Michael Summers, MBA', 'aurion-energy' ); ?></h3>
					<p class="card__text"><?php esc_html_e( 'Director, Oilfield Research', 'aurion-energy' ); ?></p>
					<p class="card__text card__text--small"><?php esc_html_e( 'Michael oversees exploration analytics and compliance programs, delivering insight across conventional and unconventional reservoirs.', 'aurion-energy' ); ?></p>
				</div>
			</article>
			<article class="card card--team">
				<img class="card__image" src="https://picsum.photos/400/400?portrait=3" alt="<?php esc_attr_e( 'Portrait of Priya Das', 'aurion-energy' ); ?>">
				<div class="card__body">
					<h3 class="card__title"><?php esc_html_e( 'Priya Das, PMP', 'aurion-energy' ); ?></h3>
					<p class="card__text"><?php esc_html_e( 'Director, Project Delivery', 'aurion-energy' ); ?></p>
					<p class="card__text card__text--small"><?php esc_html_e( 'Priya ensures project continuity from concept through commissioning with disciplined planning and stakeholder alignment.', 'aurion-energy' ); ?></p>
				</div>
			</article>
		</div>
	</div>
</section>

<section class="section section--commitments">
	<div class="container section__container section__container--split">
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Safety & Certifications', 'aurion-energy' ); ?></h2>
			<ul class="list list--check">
				<li><?php esc_html_e( 'COR-certified safety management systems and continuous improvement audits.', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'ISNetworld and ComplyWorks registered contractor with active status.', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'Comprehensive training programs covering confined space, rigging, and heavy-lift protocols.', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'Dedicated HSE advisors engaged on every active site.', 'aurion-energy' ); ?></li>
			</ul>
		</div>
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Sustainability Initiatives', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Aurion collaborates with clients to reduce lifecycle emissions, enhance energy efficiency, and align with ESG reporting frameworks. Our team conducts carbon intensity assessments, integrates renewable technologies, and designs circular workflows for material reuse wherever feasible.', 'aurion-energy' ); ?></p>
			<p><?php esc_html_e( 'We maintain active partnerships with environmental scientists and Indigenous communities to ensure inclusive, responsible project outcomes.', 'aurion-energy' ); ?></p>
		</div>
	</div>
</section>

<?php
get_footer();