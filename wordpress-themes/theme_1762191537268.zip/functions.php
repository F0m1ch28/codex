<?php
/**
 * Aurion Energy Advisory Theme Functions
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AURION_THEME_VERSION', '1.0.0' );
define( 'AURION_THEME_DIR', get_template_directory() );
define( 'AURION_THEME_URI', get_template_directory_uri() );

/**
 * Theme setup.
 */
function aurion_theme_setup() {
	load_theme_textdomain( 'aurion-energy', AURION_THEME_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 220,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'align-wide' );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'aurion-energy' ),
			'footer'  => __( 'Footer Menu', 'aurion-energy' ),
			'mobile'  => __( 'Mobile Menu', 'aurion-energy' ),
		)
	);

	add_image_size( 'hero_image', 1920, 600, true );
	add_image_size( 'project_card', 800, 600, true );
	add_image_size( 'team_member', 400, 500, true );
	add_image_size( 'testimonial_thumb', 100, 100, true );
}
add_action( 'after_setup_theme', 'aurion_theme_setup' );

/**
 * Register widget areas.
 */
function aurion_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Primary Sidebar', 'aurion-energy' ),
			'id'            => 'primary-sidebar',
			'description'   => __( 'Main sidebar that appears on pages and posts.', 'aurion-energy' ),
			'before_widget' => '<section id="%1$s" class="widget aurion-widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget__title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Homepage Widgets', 'aurion-energy' ),
			'id'            => 'homepage-widgets',
			'description'   => __( 'Widgets displayed on the homepage.', 'aurion-energy' ),
			'before_widget' => '<section id="%1$s" class="widget aurion-widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget__title">',
			'after_title'   => '</h3>',
		)
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar(
			array(
				/* translators: %s: column number */
				'name'          => sprintf( __( 'Footer Column %s', 'aurion-energy' ), $i ),
				'id'            => 'footer-' . $i,
				'description'   => __( 'Footer widget area.', 'aurion-energy' ),
				'before_widget' => '<section id="%1$s" class="widget aurion-widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h4 class="widget__title">',
				'after_title'   => '</h4>',
			)
		);
	}
}
add_action( 'widgets_init', 'aurion_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function aurion_enqueue_scripts() {
	wp_enqueue_style( 'aurion-google-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@500;600;700&family=Inter:wght@400;500;600&display=swap', array(), null );
	wp_enqueue_style( 'aurion-style', AURION_THEME_URI . '/assets/css/style.css', array(), AURION_THEME_VERSION );

	wp_enqueue_script( 'aurion-script', AURION_THEME_URI . '/assets/js/script.js', array(), AURION_THEME_VERSION, true );

	wp_localize_script(
		'aurion-script',
		'aurionData',
		array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'aurion_contact_nonce' ),
			'successMsg'  => __( "Thank you for reaching out. We'll respond within 24 hours.", 'aurion-energy' ),
			'errorMsg'    => __( 'There was an issue sending your message. Please try again later.', 'aurion-energy' ),
			'cookieLabel' => __( 'This website uses cookies to enhance your experience and analyze traffic. By continuing, you accept our use of cookies.', 'aurion-energy' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'aurion_enqueue_scripts' );

/**
 * Disable emojis for performance.
 */
function aurion_disable_emojis() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
}
add_action( 'init', 'aurion_disable_emojis' );

/**
 * Register Custom Post Types and Taxonomies.
 */
function aurion_register_cpts() {

	// Projects.
	$project_labels = array(
		'name'                  => __( 'Projects', 'aurion-energy' ),
		'singular_name'         => __( 'Project', 'aurion-energy' ),
		'add_new'               => __( 'Add New', 'aurion-energy' ),
		'add_new_item'          => __( 'Add New Project', 'aurion-energy' ),
		'edit_item'             => __( 'Edit Project', 'aurion-energy' ),
		'new_item'              => __( 'New Project', 'aurion-energy' ),
		'view_item'             => __( 'View Project', 'aurion-energy' ),
		'search_items'          => __( 'Search Projects', 'aurion-energy' ),
		'not_found'             => __( 'No projects found.', 'aurion-energy' ),
		'not_found_in_trash'    => __( 'No projects found in Trash.', 'aurion-energy' ),
		'all_items'             => __( 'All Projects', 'aurion-energy' ),
		'archives'              => __( 'Project Archives', 'aurion-energy' ),
		'attributes'            => __( 'Project Attributes', 'aurion-energy' ),
		'insert_into_item'      => __( 'Insert into project', 'aurion-energy' ),
		'uploaded_to_this_item' => __( 'Uploaded to this project', 'aurion-energy' ),
	);

	$project_args = array(
		'labels'             => $project_labels,
		'public'             => true,
		'has_archive'        => true,
		'show_in_rest'       => true,
		'menu_icon'          => 'dashicons-hammer',
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'rewrite'            => array( 'slug' => 'projects' ),
	);
	register_post_type( 'projects', $project_args );

	register_taxonomy(
		'project_type',
		'projects',
		array(
			'label'        => __( 'Project Type', 'aurion-energy' ),
			'hierarchical' => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'project-type' ),
		)
	);

	register_taxonomy(
		'project_sector',
		'projects',
		array(
			'label'        => __( 'Project Sector', 'aurion-energy' ),
			'hierarchical' => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'project-sector' ),
		)
	);

	// Team.
	$team_labels = array(
		'name'               => __( 'Team Members', 'aurion-energy' ),
		'singular_name'      => __( 'Team Member', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Team Member', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Team Member', 'aurion-energy' ),
		'new_item'           => __( 'New Team Member', 'aurion-energy' ),
		'view_item'          => __( 'View Team Member', 'aurion-energy' ),
		'search_items'       => __( 'Search Team Members', 'aurion-energy' ),
		'not_found'          => __( 'No team members found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No team members found in Trash.', 'aurion-energy' ),
	);
	$team_args   = array(
		'labels'       => $team_labels,
		'public'       => true,
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-groups',
		'supports'     => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
		'rewrite'      => array( 'slug' => 'team' ),
	);
	register_post_type( 'team', $team_args );

	register_taxonomy(
		'expertise',
		'team',
		array(
			'label'        => __( 'Expertise', 'aurion-energy' ),
			'hierarchical' => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'expertise' ),
		)
	);

	// Testimonials.
	$testimonial_labels = array(
		'name'               => __( 'Testimonials', 'aurion-energy' ),
		'singular_name'      => __( 'Testimonial', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Testimonial', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Testimonial', 'aurion-energy' ),
		'new_item'           => __( 'New Testimonial', 'aurion-energy' ),
		'view_item'          => __( 'View Testimonial', 'aurion-energy' ),
		'search_items'       => __( 'Search Testimonials', 'aurion-energy' ),
		'not_found'          => __( 'No testimonials found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No testimonials found in Trash.', 'aurion-energy' ),
	);
	$testimonial_args   = array(
		'labels'       => $testimonial_labels,
		'public'       => true,
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-format-quote',
		'supports'     => array( 'title', 'editor', 'custom-fields' ),
		'rewrite'      => array( 'slug' => 'testimonials' ),
	);
	register_post_type( 'testimonials', $testimonial_args );
}
add_action( 'init', 'aurion_register_cpts' );

/**
 * Custom Widget Example.
 */
class Aurion_CTA_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'aurion_cta_widget',
			__( 'Aurion CTA Widget', 'aurion-energy' ),
			array( 'description' => __( 'Displays a call-to-action card.', 'aurion-energy' ) )
		);
	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		$title   = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Strategic Advisory', 'aurion-energy' );
		$message = ! empty( $instance['message'] ) ? $instance['message'] : __( 'Connect with our engineers to discuss your next project.', 'aurion-energy' );
		$link    = ! empty( $instance['link'] ) ? $instance['link'] : home_url( '/contact' );

		if ( ! empty( $title ) ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
		}
		echo '<p>' . esc_html( $message ) . '</p>';
		echo '<a class="button button--primary" href="' . esc_url( $link ) . '">' . esc_html__( 'Schedule Consultation', 'aurion-energy' ) . '</a>';
		echo $args['after_widget'];
	}

	public function form( $instance ) {
		$title   = isset( $instance['title'] ) ? $instance['title'] : '';
		$message = isset( $instance['message'] ) ? $instance['message'] : '';
		$link    = isset( $instance['link'] ) ? $instance['link'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'message' ) ); ?>"><?php esc_html_e( 'Message:', 'aurion-energy' ); ?></label>
			<textarea class="widefat" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'message' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'message' ) ); ?>"><?php echo esc_textarea( $message ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Link URL:', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="url" value="<?php echo esc_attr( $link ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance             = array();
		$instance['title']    = sanitize_text_field( $new_instance['title'] );
		$instance['message']  = sanitize_textarea_field( $new_instance['message'] );
		$instance['link']     = esc_url_raw( $new_instance['link'] );
		return $instance;
	}
}
function aurion_register_widgets() {
	register_widget( 'Aurion_CTA_Widget' );
}
add_action( 'widgets_init', 'aurion_register_widgets' );

/**
 * Contact form AJAX handler.
 */
function aurion_handle_contact_form() {
	check_ajax_referer( 'aurion_contact_nonce', 'security' );

	$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$company = isset( $_POST['company'] ) ? sanitize_text_field( wp_unslash( $_POST['company'] ) ) : '';
	$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( empty( $name ) || empty( $email ) || empty( $subject ) || empty( $message ) ) {
		wp_send_json_error( __( 'Please complete all required fields.', 'aurion-energy' ), 400 );
	}

	if ( ! is_email( $email ) ) {
		wp_send_json_error( __( 'Please provide a valid email address.', 'aurion-energy' ), 400 );
	}

	$admin_email = get_option( 'admin_email' );
	$email_subject = sprintf( __( 'New Inquiry: %s', 'aurion-energy' ), $subject );

	$body  = "Name: {$name}\n";
	$body .= "Email: {$email}\n";
	$body .= "Phone: {$phone}\n";
	$body .= "Company: {$company}\n";
	$body .= "Subject: {$subject}\n\n";
	$body .= "Message:\n{$message}\n";

	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'Reply-To: ' . $name . ' <' . $email . '>',
	);

	wp_mail( $admin_email, $email_subject, $body, $headers );

	wp_send_json_success( __( "Thank you for reaching out. We'll respond within 24 hours.", 'aurion-energy' ), 200 );
}
add_action( 'wp_ajax_aurion_contact_form', 'aurion_handle_contact_form' );
add_action( 'wp_ajax_nopriv_aurion_contact_form', 'aurion_handle_contact_form' );

/**
 * Breadcrumbs.
 */
function aurion_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}

	$home_link = home_url( '/' );
	echo '<nav class="aurion-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'aurion-energy' ) . '">';
	echo '<ol class="aurion-breadcrumbs__list" itemscope itemtype="https://schema.org/BreadcrumbList">';
	echo '<li class="aurion-breadcrumbs__item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
	echo '<a href="' . esc_url( $home_link ) . '" itemprop="item"><span itemprop="name">' . esc_html__( 'Home', 'aurion-energy' ) . '</span></a>';
	echo '<meta itemprop="position" content="1" />';
	echo '</li>';

	$position = 2;

	if ( is_singular() ) {
		$post_type = get_post_type();
		if ( 'post' === $post_type ) {
			echo '<li class="aurion-breadcrumbs__item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
			echo '<a href="' . esc_url( get_permalink( get_option( 'page_for_posts' ) ) ) . '" itemprop="item"><span itemprop="name">' . esc_html__( 'Insights', 'aurion-energy' ) . '</span></a>';
			echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
			echo '</li>';
			$position++;
		} elseif ( 'projects' === $post_type ) {
			$projects_archive = get_post_type_archive_link( 'projects' );
			if ( $projects_archive ) {
				echo '<li class="aurion-breadcrumbs__item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
				echo '<a href="' . esc_url( $projects_archive ) . '" itemprop="item"><span itemprop="name">' . esc_html__( 'Projects', 'aurion-energy' ) . '</span></a>';
				echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
				echo '</li>';
				$position++;
			}
		}
		echo '<li class="aurion-breadcrumbs__item aurion-breadcrumbs__item--current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<span itemprop="name">' . esc_html( get_the_title() ) . '</span>';
		echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
		echo '</li>';
	} elseif ( is_archive() ) {
		echo '<li class="aurion-breadcrumbs__item aurion-breadcrumbs__item--current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<span itemprop="name">' . esc_html( get_the_archive_title() ) . '</span>';
		echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
		echo '</li>';
	} elseif ( is_search() ) {
		echo '<li class="aurion-breadcrumbs__item aurion-breadcrumbs__item--current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<span itemprop="name">' . esc_html__( 'Search Results', 'aurion-energy' ) . '</span>';
		echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
		echo '</li>';
	} elseif ( is_404() ) {
		echo '<li class="aurion-breadcrumbs__item aurion-breadcrumbs__item--current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<span itemprop="name">' . esc_html__( 'Page Not Found', 'aurion-energy' ) . '</span>';
		echo '<meta itemprop="position" content="' . esc_attr( $position ) . '" />';
		echo '</li>';
	}

	echo '</ol>';
	echo '</nav>';
}

/**
 * Customizer options.
 */
function aurion_customize_register( $wp_customize ) {

	$wp_customize->add_section(
		'aurion_contact_section',
		array(
			'title'    => __( 'Contact Details', 'aurion-energy' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_phone',
		array(
			'default'           => '+1 (416) 792-4583',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_phone',
		array(
			'label'   => __( 'Phone Number', 'aurion-energy' ),
			'section' => 'aurion_contact_section',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_email',
		array(
			'default'           => 'contact@aurionenergy.com',
			'sanitize_callback' => 'sanitize_email',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_email',
		array(
			'label'   => __( 'Email Address', 'aurion-energy' ),
			'section' => 'aurion_contact_section',
			'type'    => 'text',
		)
	);

	$wp_customize->add_section(
		'aurion_social_section',
		array(
			'title'    => __( 'Social Links', 'aurion-energy' ),
			'priority' => 40,
		)
	);

	$social_networks = array(
		'linkedin' => __( 'LinkedIn URL', 'aurion-energy' ),
		'twitter'  => __( 'Twitter URL', 'aurion-energy' ),
		'facebook' => __( 'Facebook URL', 'aurion-energy' ),
	);

	foreach ( $social_networks as $slug => $label ) {
		$wp_customize->add_setting(
			'aurion_social_' . $slug,
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);

		$wp_customize->add_control(
			'aurion_social_' . $slug,
			array(
				'label'   => $label,
				'section' => 'aurion_social_section',
				'type'    => 'url',
			)
		);
	}
}
add_action( 'customize_register', 'aurion_customize_register' );

/**
 * Output schema in footer.
 */
function aurion_schema_footer() {
	$schema = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'Organization',
		'name'            => 'Aurion Energy Advisory',
		'url'             => home_url(),
		'logo'            => get_logo_url(),
		'address'         => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => '460 Bay St',
			'addressLocality' => 'Toronto',
			'addressRegion'   => 'ON',
			'postalCode'      => 'M5H 2Y4',
			'addressCountry'  => 'CA',
		),
		'contactPoint'    => array(
			array(
				'@type'       => 'ContactPoint',
				'telephone'   => '+1 (416) 792-4583',
				'contactType' => 'customer service',
			),
		),
		'sameAs'          => array_filter(
			array(
				get_theme_mod( 'aurion_social_linkedin' ),
				get_theme_mod( 'aurion_social_twitter' ),
				get_theme_mod( 'aurion_social_facebook' ),
			)
		),
	);

	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>';
}
add_action( 'wp_footer', 'aurion_schema_footer', 20 );

/**
 * Helper to get logo URL.
 */
function get_logo_url() {
	if ( has_custom_logo() ) {
		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$logo           = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		if ( $logo ) {
			return esc_url_raw( $logo[0] );
		}
	}
	return esc_url_raw( AURION_THEME_URI . '/assets/images/logo.png' );
}

?>