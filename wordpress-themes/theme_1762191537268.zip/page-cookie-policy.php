<?php
/**
 * Template Name: Cookie Policy
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="section section--legal">
	<div class="container">
		<h2 class="section__title"><?php esc_html_e( 'Cookie Policy', 'aurion-energy' ); ?></h2>
		<p class="section__meta"><?php esc_html_e( 'Last updated: January 1, 2024', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'What Are Cookies?', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Cookies are small text files stored on your device when you visit a website. They help us remember your preferences and analyze how the site is used.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Types of Cookies We Use', 'aurion-energy' ); ?></h3>
		<ul>
			<li><strong><?php esc_html_e( 'Essential Cookies:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Required for the website to function, such as recognizing cookie preferences.', 'aurion-energy' ); ?></li>
			<li><strong><?php esc_html_e( 'Analytics Cookies:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Help us understand site performance and user activity to improve our services.', 'aurion-energy' ); ?></li>
			<li><strong><?php esc_html_e( 'Functional Cookies:', 'aurion-energy' ); ?></strong> <?php esc_html_e( 'Remember your settings to enhance your experience.', 'aurion-energy' ); ?></li>
		</ul>

		<h3><?php esc_html_e( 'Managing Cookies', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'You can manage cookies through your browser settings and by using the controls in our cookie banner. Adjusting browser settings may affect website functionality.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Third-Party Cookies', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Some analytics and embedded content providers may set their own cookies. These providers maintain their own privacy policies and cookie practices.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Updates to this Policy', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'We may update this policy to reflect changes in technology or regulations. Please review periodically for the latest information.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Contact', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'For questions about our cookie practices, contact us at contact@aurionenergy.com.', 'aurion-energy' ); ?></p>
	</div>
</section>

<?php
get_footer();