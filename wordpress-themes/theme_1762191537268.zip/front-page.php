<?php
/**
 * Front Page Template.
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="hero hero--home" style="background-image: url('https://picsum.photos/1920/900?industrial=1');">
	<div class="hero__overlay"></div>
	<div class="container hero__content">
		<h1 class="hero__title"><?php esc_html_e( 'Engineering the Future of Energy', 'aurion-energy' ); ?></h1>
		<p class="hero__subtitle"><?php esc_html_e( 'Aurion Energy Advisory delivers strategic consulting, engineered installations, and research-backed insights for critical energy infrastructure.', 'aurion-energy' ); ?></p>
		<a class="button button--primary" href="<?php echo esc_url( home_url( '/contact' ) ); ?>"><?php esc_html_e( 'Partner with Aurion', 'aurion-energy' ); ?></a>
	</div>
</section>

<section class="section section--who-we-are">
	<div class="container section__container">
		<div class="section__intro">
			<h2 class="section__title"><?php esc_html_e( 'Who We Are', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Aurion Energy Advisory is a Canadian engineering consultancy focused on complex industrial energy systems. From oilfield studies to full-scale crane coordination, we align technical expertise with operational discipline to help organizations execute safely and efficiently.', 'aurion-energy' ); ?></p>
			<p><?php esc_html_e( 'Our Toronto-based team integrates research, engineering, and field leadership to deliver data-rich strategies, pragmatic implementation, and measurable results across the energy value chain.', 'aurion-energy' ); ?></p>
		</div>
	</div>
</section>

<section class="section section--services" id="services">
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Our Expertise', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Consulting, applied research, and engineered installation services built for demanding industrial environments.', 'aurion-energy' ); ?></p>
		</div>
		<div class="cards cards--services">
			<article class="card card--service">
				<div class="card__icon" aria-hidden="true">🔍</div>
				<h3 class="card__title"><?php esc_html_e( 'Energy Consulting', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Strategic planning, asset optimization, and operational advisory tailored to Canadian energy producers and industrial operators.', 'aurion-energy' ); ?></p>
				<a class="card__link" href="<?php echo esc_url( home_url( '/services#energy-consulting' ) ); ?>"><?php esc_html_e( 'Learn More', 'aurion-energy' ); ?></a>
			</article>
			<article class="card card--service">
				<div class="card__icon" aria-hidden="true">🧪</div>
				<h3 class="card__title"><?php esc_html_e( 'Oilfield Research', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Reservoir analytics, regulatory compliance studies, and performance benchmarking for onshore and offshore operations.', 'aurion-energy' ); ?></p>
				<a class="card__link" href="<?php echo esc_url( home_url( '/services#oilfield-research' ) ); ?>"><?php esc_html_e( 'Learn More', 'aurion-energy' ); ?></a>
			</article>
			<article class="card card--service">
				<div class="card__icon" aria-hidden="true">🏗️</div>
				<h3 class="card__title"><?php esc_html_e( 'Installation & Coordination', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Turnkey crane planning, heavy-lift logistics, and onsite coordination for critical infrastructure installs.', 'aurion-energy' ); ?></p>
				<a class="card__link" href="<?php echo esc_url( home_url( '/services#installation' ) ); ?>"><?php esc_html_e( 'Learn More', 'aurion-energy' ); ?></a>
			</article>
		</div>
	</div>
</section>

<section class="section section--about-preview">
	<div class="container section__container section__container--split">
		<div class="section__media">
			<img src="https://picsum.photos/800/600?office=2" alt="<?php esc_attr_e( 'Aurion Energy engineering team collaborating in control room', 'aurion-energy' ); ?>">
		</div>
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Strategic Guidance Grounded in Field Experience', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Our consultants have led complex industrial programs across Canada and internationally. We translate real-world operational lessons into safe, scalable project execution plans that stand up to regulatory scrutiny and site realities alike.', 'aurion-energy' ); ?></p>
			<p><?php esc_html_e( 'From early-stage feasibility through commissioning, Aurion teams stay embedded with your stakeholders to ensure each deliverable aligns with technical requirements, sustainability objectives, and organizational vision.', 'aurion-energy' ); ?></p>
			<a class="button button--secondary" href="<?php echo esc_url( home_url( '/about' ) ); ?>"><?php esc_html_e( 'Discover Our Story', 'aurion-energy' ); ?></a>
		</div>
	</div>
</section>

<section class="section section--why">
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Why Choose Aurion', 'aurion-energy' ); ?></h2>
		</div>
		<div class="cards cards--features">
			<article class="card card--feature">
				<h3 class="card__title"><?php esc_html_e( 'Integrated Expertise', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Consultants, engineers, and field supervisors collaborate under one roof to deliver unified solutions.', 'aurion-energy' ); ?></p>
			</article>
			<article class="card card--feature">
				<h3 class="card__title"><?php esc_html_e( 'Safety by Design', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Risk mitigation, procedural discipline, and compliance mapping built into every engagement.', 'aurion-energy' ); ?></p>
			</article>
			<article class="card card--feature">
				<h3 class="card__title"><?php esc_html_e( 'Innovation with Accountability', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Data-driven recommendations backed by transparent reporting and measurable outcomes.', 'aurion-energy' ); ?></p>
			</article>
			<article class="card card--feature">
				<h3 class="card__title"><?php esc_html_e( 'Sustainable Engineering', 'aurion-energy' ); ?></h3>
				<p class="card__text"><?php esc_html_e( 'Low-carbon strategies and resource stewardship woven through planning, design, and delivery.', 'aurion-energy' ); ?></p>
			</article>
		</div>
	</div>
</section>

<section class="section section--projects" id="projects">
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Featured Projects', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Recent engagements demonstrating our approach to complex energy infrastructure initiatives.', 'aurion-energy' ); ?></p>
		</div>
		<div class="cards cards--projects">
			<?php
			$projects_query = new WP_Query(
				array(
					'post_type'      => 'projects',
					'posts_per_page' => 3,
					'no_found_rows'  => true,
				)
			);

			if ( $projects_query->have_posts() ) :
				while ( $projects_query->have_posts() ) :
					$projects_query->the_post();
					?>
					<article <?php post_class( 'card card--project' ); ?>>
						<a class="card__media" href="<?php the_permalink(); ?>">
							<?php
							if ( has_post_thumbnail() ) {
								the_post_thumbnail( 'project_card', array( 'class' => 'card__image' ) );
							} else {
								echo '<img class="card__image" src="https://picsum.photos/800/500?industrial=2" alt="' . esc_attr( get_the_title() ) . '">';
							}
							?>
						</a>
						<div class="card__body">
							<h3 class="card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<div class="card__excerpt"><?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 20 ) ); ?></div>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p class="section__empty"><?php esc_html_e( 'Project highlights coming soon.', 'aurion-energy' ); ?></p>
			<?php endif; ?>
		</div>
		<div class="section__actions">
			<a class="button button--outline" href="<?php echo esc_url( home_url( '/projects' ) ); ?>"><?php esc_html_e( 'View All Projects', 'aurion-energy' ); ?></a>
		</div>
	</div>
</section>

<section class="section section--testimonials" id="testimonials">
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Client Perspectives', 'aurion-energy' ); ?></h2>
		</div>
		<div class="testimonial-slider" data-testimonial-slider>
			<?php
			$testimonial_query = new WP_Query(
				array(
					'post_type'      => 'testimonials',
					'posts_per_page' => 4,
					'no_found_rows'  => true,
				)
			);

			if ( $testimonial_query->have_posts() ) :
				while ( $testimonial_query->have_posts() ) :
					$testimonial_query->the_post();
					$client_role = get_post_meta( get_the_ID(), 'client_title', true );
					$client_company = get_post_meta( get_the_ID(), 'client_company', true );
					?>
					<article class="testimonial">
						<div class="testimonial__content">
							<p><?php echo wp_kses_post( get_the_content() ); ?></p>
						</div>
						<div class="testimonial__meta">
							<h3 class="testimonial__name"><?php the_title(); ?></h3>
							<?php if ( $client_role || $client_company ) : ?>
								<p class="testimonial__role"><?php echo esc_html( trim( $client_role . ' • ' . $client_company, ' •' ) ); ?></p>
							<?php endif; ?>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p class="section__empty"><?php esc_html_e( 'Testimonials will be published shortly.', 'aurion-energy' ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</section>

<section class="section section--cta">
	<div class="container section__container section__container--cta">
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Ready to Modernize Your Energy Operations?', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Share your upcoming project, and our advisors will align the right specialists to guide you from assessment to implementation.', 'aurion-energy' ); ?></p>
		</div>
		<form class="form form--inline js-aurion-contact-form" method="post" novalidate>
			<div class="form__row">
				<div class="form__group">
					<label for="home-name"><?php esc_html_e( 'Name', 'aurion-energy' ); ?> *</label>
					<input type="text" id="home-name" name="name" required>
				</div>
				<div class="form__group">
					<label for="home-email"><?php esc_html_e( 'Email', 'aurion-energy' ); ?> *</label>
					<input type="email" id="home-email" name="email" required>
				</div>
				<div class="form__group">
					<label for="home-phone"><?php esc_html_e( 'Phone', 'aurion-energy' ); ?></label>
					<input type="tel" id="home-phone" name="phone">
				</div>
			</div>
			<div class="form__row">
				<div class="form__group">
					<label for="home-company"><?php esc_html_e( 'Company', 'aurion-energy' ); ?></label>
					<input type="text" id="home-company" name="company">
				</div>
				<div class="form__group">
					<label for="home-subject"><?php esc_html_e( 'Subject', 'aurion-energy' ); ?> *</label>
					<input type="text" id="home-subject" name="subject" required>
				</div>
			</div>
			<div class="form__group">
				<label for="home-message"><?php esc_html_e( 'Message', 'aurion-energy' ); ?> *</label>
				<textarea id="home-message" name="message" rows="4" required></textarea>
			</div>
			<div class="form__actions">
				<button class="button button--primary" type="submit"><?php esc_html_e( 'Submit Inquiry', 'aurion-energy' ); ?></button>
				<input type="hidden" name="action" value="aurion_contact_form">
				<?php wp_nonce_field( 'aurion_contact_nonce', 'aurion_contact_nonce_field' ); ?>
				<div class="form__response" aria-live="polite"></div>
			</div>
		</form>
	</div>
</section>

<?php
get_footer();