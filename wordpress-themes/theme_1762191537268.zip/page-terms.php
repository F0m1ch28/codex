<?php
/**
 * Template Name: Terms of Use
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="section section--legal">
	<div class="container">
		<h2 class="section__title"><?php esc_html_e( 'Website Terms of Use', 'aurion-energy' ); ?></h2>
		<p class="section__meta"><?php esc_html_e( 'Last updated: January 1, 2024', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Acceptance of Terms', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'By accessing aurionenergy.com, you agree to comply with these Terms of Use and all applicable laws. If you do not agree, please discontinue use of the site.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Use of Content', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'All content, including text, graphics, logos, and media, is owned by Aurion Energy Advisory or its licensors. You may view, download, or print materials for personal reference only. Any other use requires prior written consent.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Acceptable Use', 'aurion-energy' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Do not use the website in any manner that could disable, damage, or impair the site or interfere with any other party’s use.', 'aurion-energy' ); ?></li>
			<li><?php esc_html_e( 'Do not attempt to gain unauthorized access to systems, data, or networks associated with the site.', 'aurion-energy' ); ?></li>
			<li><?php esc_html_e( 'Do not introduce malicious code, including viruses, trojans, or worms.', 'aurion-energy' ); ?></li>
		</ul>

		<h3><?php esc_html_e( 'Intellectual Property', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'The Aurion Energy Advisory name and logo are trademarks of Aurion Energy Advisory. Nothing in these terms grants you any right to use our trademarks without written permission.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Third-Party Links', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Our website may reference third-party sites. Aurion Energy Advisory is not responsible for the content or practices of those sites.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Limitation of Liability', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Aurion Energy Advisory provides this website on an “as is” basis. We make no representations or warranties of any kind regarding accuracy, completeness, or suitability of the information provided. In no event shall Aurion Energy Advisory be liable for any damages arising from your use of the website.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Indemnification', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'You agree to indemnify and hold Aurion Energy Advisory, its officers, employees, and partners harmless from any claims arising out of your use of the website or violation of these terms.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Governing Law', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'These Terms of Use are governed by the laws of the Province of Ontario and applicable federal laws of Canada. Any dispute shall be brought before the courts located in Toronto, Ontario.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Changes to Terms', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'Aurion Energy Advisory reserves the right to update these terms at any time. Updates will be posted on this page with a revised effective date.', 'aurion-energy' ); ?></p>

		<h3><?php esc_html_e( 'Contact Information', 'aurion-energy' ); ?></h3>
		<p><?php esc_html_e( 'If you have questions about these Terms of Use, contact us at contact@aurionenergy.com.', 'aurion-energy' ); ?></p>
	</div>
</section>

<?php
get_footer();