(function () {
	"use strict";

	const header = document.querySelector("[data-header]");
	const toggle = document.querySelector("[data-menu-toggle]");
	const mobileMenu = document.getElementById("mobile-menu");
	const cookieBanner = document.querySelector("[data-cookie-banner]");
	const cookieAccept = document.querySelector("[data-cookie-accept]");
	const cookieDecline = document.querySelector("[data-cookie-decline]");

	/* Sticky header shadow */
	function handleScroll() {
		if (!header) {
			return;
		}
		if (window.scrollY > 40) {
			header.classList.add("is-scrolled");
		} else {
			header.classList.remove("is-scrolled");
		}
	}
	window.addEventListener("scroll", handleScroll);

	/* Mobile menu toggle */
	if (toggle && mobileMenu) {
		toggle.addEventListener("click", function () {
			const expanded = toggle.getAttribute("aria-expanded") === "true";
			toggle.setAttribute("aria-expanded", (!expanded).toString());
			if (expanded) {
				mobileMenu.setAttribute("hidden", "hidden");
			} else {
				mobileMenu.removeAttribute("hidden");
			}
		});
	}

	/* Smooth scroll for anchor links */
	const anchorLinks = document.querySelectorAll('a[href^="#"]');
	anchorLinks.forEach(function (link) {
		link.addEventListener("click", function (event) {
			const targetId = link.getAttribute("href").substring(1);
			const targetElement = document.getElementById(targetId);
			if (targetElement) {
				event.preventDefault();
				targetElement.scrollIntoView({ behavior: "smooth" });
			}
		});
	});

	/* AJAX contact forms */
	const forms = document.querySelectorAll(".js-aurion-contact-form");
	forms.forEach(function (form) {
		form.addEventListener("submit", function (event) {
			event.preventDefault();
			const responseEl = form.querySelector(".form__response");
			if (responseEl) {
				responseEl.textContent = "";
			}
			const formData = new FormData(form);
			formData.append("security", aurionData.nonce);

			fetch(aurionData.ajaxUrl, {
				method: "POST",
				body: formData,
				headers: {
					"X-Requested-With": "XMLHttpRequest"
				}
			})
				.then(function (res) {
					if (!res.ok) {
						throw new Error("Network response was not ok");
					}
					return res.json();
				})
				.then(function (json) {
					if (json.success) {
						if (responseEl) {
							responseEl.textContent = aurionData.successMsg;
							responseEl.style.color = "#0d9488";
						}
						form.reset();
					} else {
						if (responseEl) {
							responseEl.textContent = json.data || aurionData.errorMsg;
							responseEl.style.color = "#dc2626";
						}
					}
				})
				.catch(function () {
					if (responseEl) {
						responseEl.textContent = aurionData.errorMsg;
						responseEl.style.color = "#dc2626";
					}
				});
		});
	});

	/* Cookie banner */
	if (cookieBanner && cookieAccept && cookieDecline) {
		const storageKey = "aurion_cookie_preference";
		const storedPreference = window.localStorage.getItem(storageKey);

		if (!storedPreference) {
			cookieBanner.removeAttribute("hidden");
			const messageEl = cookieBanner.querySelector(".aurion-cookie-banner__message");
			if (messageEl) {
				messageEl.textContent = aurionData.cookieLabel;
			}
		}

		function setPreference(value) {
			window.localStorage.setItem(storageKey, value);
			cookieBanner.setAttribute("hidden", "hidden");
		}

		cookieAccept.addEventListener("click", function () {
			setPreference("accepted");
		});

		cookieDecline.addEventListener("click", function () {
			setPreference("declined");
		});
	}

	/* Simple testimonial slider (auto scroll) */
	const slider = document.querySelector("[data-testimonial-slider]");
	if (slider) {
		let index = 0;
		const items = slider.children;
		const total = items.length;

		function cycleTestimonials() {
			for (let i = 0; i < total; i++) {
				items[i].style.display = "none";
			}
			items[index].style.display = "block";
			index = (index + 1) % total;
		}

		if (total > 1) {
			cycleTestimonials();
			setInterval(cycleTestimonials, 6000);
		}
	}
})();