<?php
/**
 * Footer template.
 *
 * @package AurionEnergy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main>
<footer class="site-footer">
	<div class="site-footer__top">
		<div class="container site-footer__grid">
			<div class="site-footer__column">
				<h4 class="site-footer__title"><?php esc_html_e( 'Aurion Energy Advisory', 'aurion-energy' ); ?></h4>
				<p><?php esc_html_e( 'Engineering clarity for complex energy systems across Canada.', 'aurion-energy' ); ?></p>
				<ul class="site-footer__contact">
					<li><span><?php esc_html_e( 'Address:', 'aurion-energy' ); ?></span> 460 Bay St, Toronto, ON M5H 2Y4, Canada</li>
					<li><span><?php esc_html_e( 'Phone:', 'aurion-energy' ); ?></span> <a href="tel:+14167924583">+1 (416) 792-4583</a></li>
					<li><span><?php esc_html_e( 'Email:', 'aurion-energy' ); ?></span> <a href="mailto:contact@aurionenergy.com">contact@aurionenergy.com</a></li>
				</ul>
			</div>
			<div class="site-footer__column">
				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<?php dynamic_sidebar( 'footer-1' ); ?>
				<?php endif; ?>
			</div>
			<div class="site-footer__column">
				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
					<?php dynamic_sidebar( 'footer-2' ); ?>
				<?php endif; ?>
				<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer Menu', 'aurion-energy' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'footer',
							'menu_class'     => 'footer-menu',
							'container'      => false,
							'fallback_cb'    => false,
						)
					);
					?>
				</nav>
				<div class="site-footer__social">
					<?php if ( get_theme_mod( 'aurion_social_linkedin' ) ) : ?>
						<a href="<?php echo esc_url( get_theme_mod( 'aurion_social_linkedin' ) ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'LinkedIn', 'aurion-energy' ); ?>">LinkedIn</a>
					<?php endif; ?>
					<?php if ( get_theme_mod( 'aurion_social_twitter' ) ) : ?>
						<a href="<?php echo esc_url( get_theme_mod( 'aurion_social_twitter' ) ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Twitter', 'aurion-energy' ); ?>">Twitter</a>
					<?php endif; ?>
					<?php if ( get_theme_mod( 'aurion_social_facebook' ) ) : ?>
						<a href="<?php echo esc_url( get_theme_mod( 'aurion_social_facebook' ) ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Facebook', 'aurion-energy' ); ?>">Facebook</a>
					<?php endif; ?>
				</div>
			</div>
			<div class="site-footer__column">
				<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
					<?php dynamic_sidebar( 'footer-3' ); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<div class="site-footer__bottom">
		<div class="container site-footer__bottom-inner">
			<p>© 2024 Aurion Energy Advisory. All rights reserved.</p>
			<div class="site-footer__legal">
				<a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'aurion-energy' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/terms' ) ); ?>"><?php esc_html_e( 'Terms of Use', 'aurion-energy' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/cookie-policy' ) ); ?>"><?php esc_html_e( 'Cookie Policy', 'aurion-energy' ); ?></a>
			</div>
		</div>
	</div>
</footer>
<div class="aurion-cookie-banner" data-cookie-banner hidden>
	<p class="aurion-cookie-banner__message"></p>
	<div class="aurion-cookie-banner__actions">
		<button class="button button--primary" type="button" data-cookie-accept><?php esc_html_e( 'Accept', 'aurion-energy' ); ?></button>
		<button class="button button--secondary" type="button" data-cookie-decline><?php esc_html_e( 'Decline', 'aurion-energy' ); ?></button>
		<a class="aurion-cookie-banner__link" href="<?php echo esc_url( home_url( '/cookie-policy' ) ); ?>"><?php esc_html_e( 'Learn more', 'aurion-energy' ); ?></a>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>