```
<?php
/**
 * Footer template.
 *
 * @package Aurion_Energy
 */
?>
</main>
<footer class="site-footer" data-observe>
	<div class="site-footer__top">
		<div class="site-footer__brand">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				echo '<span class="site-footer__title">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
			}
			?>
			<p class="site-footer__tagline"><?php esc_html_e( 'Engineering the Future of Energy', 'aurion-energy' ); ?></p>
			<ul class="site-footer__contact">
				<li>
					<span class="site-footer__label"><?php esc_html_e( 'Address', 'aurion-energy' ); ?>:</span>
					<span>460 Bay St, Toronto, ON M5H 2Y4, Canada</span>
				</li>
				<li>
					<span class="site-footer__label"><?php esc_html_e( 'Phone', 'aurion-energy' ); ?>:</span>
					<a href="tel:+14167924583">+1 (416) 792-4583</a>
				</li>
				<li>
					<span class="site-footer__label"><?php esc_html_e( 'Email', 'aurion-energy' ); ?>:</span>
					<a href="mailto:<?php echo esc_attr( aurion_energy_get_contact_email() ); ?>"><?php echo esc_html( aurion_energy_get_contact_email() ); ?></a>
				</li>
			</ul>
			<div class="site-footer__social">
				<a href="https://www.linkedin.com" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Aurion on LinkedIn', 'aurion-energy' ); ?>">
					<span class="site-footer__social-icon site-footer__social-icon--linkedin" aria-hidden="true"></span>
				</a>
			</div>
		</div>
		<div class="site-footer__widgets">
			<?php for ( $i = 1; $i <= 4; $i++ ) : ?>
				<div class="site-footer__column">
					<?php if ( is_active_sidebar( 'footer-' . $i ) ) : ?>
						<?php dynamic_sidebar( 'footer-' . $i ); ?>
					<?php endif; ?>
				</div>
			<?php endfor; ?>
		</div>
	</div>
	<div class="site-footer__bottom">
		<nav class="site-footer__nav" aria-label="<?php esc_attr_e( 'Footer Menu', 'aurion-energy' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer-menu',
					'menu_class'     => 'footer-menu',
					'container'      => false,
					'fallback_cb'    => false,
					'depth'          => 1,
				)
			);
			?>
		</nav>
		<p class="site-footer__copy">&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'aurion-energy' ); ?></p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
```