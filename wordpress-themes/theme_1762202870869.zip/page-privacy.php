```
<?php
/**
 * Template Name: Privacy Policy
 *
 * @package Aurion_Energy
 */

get_header();
?>
<section class="page-hero" data-observe>
	<div class="page-hero__content container">
		<h1 class="page-hero__title"><?php the_title(); ?></h1>
		<p class="page-hero__subtitle"><?php esc_html_e( 'How Aurion Energy Advisory collects, uses, and protects personal information.', 'aurion-energy' ); ?></p>
	</div>
</section>

<div class="container">
	<?php aurion_energy_breadcrumbs(); ?>
</div>

<section class="section section--legal container" data-observe>
	<?php
	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;
	?>
</section>
<?php
get_footer();
```