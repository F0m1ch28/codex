```
<?php
/**
 * Template Name: Contact Aurion
 *
 * @package Aurion_Energy
 */

get_header();
$status = isset( $_GET['contact-status'] ) ? sanitize_text_field( wp_unslash( $_GET['contact-status'] ) ) : '';
?>
<section class="page-hero" data-observe>
	<div class="page-hero__content container">
		<h1 class="page-hero__title"><?php the_title(); ?></h1>
		<p class="page-hero__subtitle"><?php esc_html_e( 'Connect with our consultants to plan your next energy initiative.', 'aurion-energy' ); ?></p>
	</div>
</section>

<div class="container">
	<?php aurion_energy_breadcrumbs(); ?>
</div>

<section class="section section--contact container" data-observe>
	<div class="contact-grid">
		<div class="contact-grid__form">
			<?php if ( 'success' === $status ) : ?>
				<div class="notice notice--success" role="status">
					<p><?php esc_html_e( 'Thank you for reaching out. A member of our advisory team will respond shortly.', 'aurion-energy' ); ?></p>
				</div>
			<?php elseif ( 'error' === $status ) : ?>
				<div class="notice notice--error" role="alert">
					<p><?php esc_html_e( 'Please complete all required fields and try again.', 'aurion-energy' ); ?></p>
				</div>
			<?php endif; ?>

			<form class="aurion-form" method="post" action="<?php echo esc_url( get_permalink() ); ?>" novalidate>
				<?php wp_nonce_field( 'aurion_energy_contact', 'aurion_energy_contact_nonce' ); ?>
				<div class="aurion-form__row">
					<div class="aurion-form__field">
						<label for="aurion_name"><?php esc_html_e( 'Name*', 'aurion-energy' ); ?></label>
						<input type="text" id="aurion_name" name="aurion_name" required>
					</div>
					<div class="aurion-form__field">
						<label for="aurion_email"><?php esc_html_e( 'Email*', 'aurion-energy' ); ?></label>
						<input type="email" id="aurion_email" name="aurion_email" required>
					</div>
				</div>
				<div class="aurion-form__row">
					<div class="aurion-form__field">
						<label for="aurion_phone"><?php esc_html_e( 'Phone', 'aurion-energy' ); ?></label>
						<input type="tel" id="aurion_phone" name="aurion_phone">
					</div>
					<div class="aurion-form__field">
						<label for="aurion_company"><?php esc_html_e( 'Company', 'aurion-energy' ); ?></label>
						<input type="text" id="aurion_company" name="aurion_company">
					</div>
				</div>
				<div class="aurion-form__field">
					<label for="aurion_subject"><?php esc_html_e( 'Subject', 'aurion-energy' ); ?></label>
					<input type="text" id="aurion_subject" name="aurion_subject">
				</div>
				<div class="aurion-form__field">
					<label for="aurion_message"><?php esc_html_e( 'Message*', 'aurion-energy' ); ?></label>
					<textarea id="aurion_message" name="aurion_message" rows="6" required></textarea>
				</div>
				<p class="aurion-form__footnote"><?php esc_html_e( 'By submitting this form you consent to Aurion Energy Advisory contacting you regarding your inquiry. View our Privacy Policy for details.', 'aurion-energy' ); ?></p>
				<button type="submit" class="btn btn--primary"><?php esc_html_e( 'Send Message', 'aurion-energy' ); ?></button>
			</form>
		</div>
		<div class="contact-grid__info">
			<div class="contact-card">
				<h2 class="contact-card__title"><?php esc_html_e( 'Aurion Energy Advisory', 'aurion-energy' ); ?></h2>
				<ul class="contact-card__list">
					<li>
						<span class="contact-card__label"><?php esc_html_e( 'Address', 'aurion-energy' ); ?></span>
						<span>460 Bay St, Toronto, ON M5H 2Y4, Canada</span>
					</li>
					<li>
						<span class="contact-card__label"><?php esc_html_e( 'Phone', 'aurion-energy' ); ?></span>
						<a href="tel:+14167924583">+1 (416) 792-4583</a>
					</li>
					<li>
						<span class="contact-card__label"><?php esc_html_e( 'Email', 'aurion-energy' ); ?></span>
						<a href="mailto:<?php echo esc_attr( aurion_energy_get_contact_email() ); ?>"><?php echo esc_html( aurion_energy_get_contact_email() ); ?></a>
					</li>
					<li>
						<span class="contact-card__label"><?php esc_html_e( 'LinkedIn', 'aurion-energy' ); ?></span>
						<a href="https://www.linkedin.com" target="_blank" rel="noopener"><?php esc_html_e( 'Follow Aurion Energy Advisory', 'aurion-energy' ); ?></a>
					</li>
					<li>
						<span class="contact-card__label"><?php esc_html_e( 'Office Hours', 'aurion-energy' ); ?></span>
						<span><?php esc_html_e( 'Monday – Friday, 8:30 a.m. to 5:00 p.m. EST', 'aurion-energy' ); ?></span>
					</li>
				</ul>
			</div>
			<div class="contact-map" aria-label="<?php esc_attr_e( 'Aurion Energy Advisory Toronto Office Map', 'aurion-energy' ); ?>">
				<iframe title="<?php esc_attr_e( 'Aurion Energy Advisory Toronto Office Map', 'aurion-energy' ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.797555682002!2d-79.38308442368636!3d43.65042425237844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d5fac23d5d%3A0x61c65b83c0d2326c!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4!5e0!3m2!1sen!2sca!4v1707070712345"></iframe>
			</div>
		</div>
	</div>
</section>
<?php
get_footer();
```