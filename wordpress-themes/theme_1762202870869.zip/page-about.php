```
<?php
/**
 * Template Name: About Aurion
 *
 * @package Aurion_Energy
 */

get_header();
?>
<section class="page-hero" data-observe>
	<div class="page-hero__content container">
		<h1 class="page-hero__title"><?php the_title(); ?></h1>
		<p class="page-hero__subtitle"><?php esc_html_e( 'A Canadian energy advisory built on engineering heritage, operational insight, and trusted relationships.', 'aurion-energy' ); ?></p>
	</div>
</section>

<div class="container">
	<?php aurion_energy_breadcrumbs(); ?>
</div>

<section class="section section--page container" data-observe>
	<div class="page-content">
		<?php
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
		?>
	</div>
</section>

<section class="section section--history" data-observe>
	<div class="container">
		<h2 class="section__title"><?php esc_html_e( 'Our Story', 'aurion-energy' ); ?></h2>
		<div class="timeline">
			<div class="timeline__item">
				<div class="timeline__year">2006</div>
				<div class="timeline__content">
					<h3><?php esc_html_e( 'Origins in Industrial Engineering', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Aurion formed in Toronto as a collaborative of engineers advising energy clients on infrastructure modernization.', 'aurion-energy' ); ?></p>
				</div>
			</div>
			<div class="timeline__item">
				<div class="timeline__year">2012</div>
				<div class="timeline__content">
					<h3><?php esc_html_e( 'Expansion into Oilfield Research', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Our team introduced dedicated field research capabilities to support upstream operations and regulatory reporting.', 'aurion-energy' ); ?></p>
				</div>
			</div>
			<div class="timeline__item">
				<div class="timeline__year">2018</div>
				<div class="timeline__content">
					<h3><?php esc_html_e( 'Sustainability Integration', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'Aurion embedded environmental strategy specialists, aligning every project with responsible energy goals.', 'aurion-energy' ); ?></p>
				</div>
			</div>
			<div class="timeline__item">
				<div class="timeline__year">2023</div>
				<div class="timeline__content">
					<h3><?php esc_html_e( 'National Delivery Network', 'aurion-energy' ); ?></h3>
					<p><?php esc_html_e( 'We now support clients from coast to coast, integrating consulting, engineering, and installation services.', 'aurion-energy' ); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="section section--mission" data-observe>
	<div class="container section__flex">
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Mission & Values', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Aurion Energy Advisory exists to help clients engineer resilient energy systems that excel in performance, safety, and environmental stewardship.', 'aurion-energy' ); ?></p>
			<ul class="pillars">
				<li><strong><?php esc_html_e( 'Integrity', 'aurion-energy' ); ?></strong> — <?php esc_html_e( 'Transparent collaborations built on trust and accountability.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Precision', 'aurion-energy' ); ?></strong> — <?php esc_html_e( 'Analytical rigour guiding every recommendation, design, and deployment.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Safety', 'aurion-energy' ); ?></strong> — <?php esc_html_e( 'Field-first protocols prioritizing people, communities, and assets.', 'aurion-energy' ); ?></li>
				<li><strong><?php esc_html_e( 'Sustainability', 'aurion-energy' ); ?></strong> — <?php esc_html_e( 'Progressive energy solutions aligned with environmental commitments.', 'aurion-energy' ); ?></li>
			</ul>
		</div>
		<div class="section__visual">
			<picture>
				<source srcset="<?php echo esc_url( get_theme_file_uri( 'assets/images/mission-collaboration.webp' ) ); ?>" type="image/webp">
				<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/mission-collaboration.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Leadership team collaborating in conference room', 'aurion-energy' ); ?>" loading="lazy">
			</picture>
		</div>
	</div>
</section>

<section class="section section--leadership" data-observe>
	<div class="container">
		<h2 class="section__title"><?php esc_html_e( 'Leadership Team', 'aurion-energy' ); ?></h2>
		<div class="card-grid card-grid--team">
			<?php
			$leaders_query = new WP_Query(
				array(
					'post_type'      => 'team',
					'posts_per_page' => 6,
					'meta_query'     => array(
						array(
							'key'     => 'aurion_leadership',
							'value'   => '1',
							'compare' => '=',
						),
					),
				)
			);

			if ( $leaders_query->have_posts() ) :
				while ( $leaders_query->have_posts() ) :
					$leaders_query->the_post();
					$role = get_post_meta( get_the_ID(), 'aurion_role', true );
					?>
					<article class="team-card team-card--leadership">
						<div class="team-card__media">
							<?php the_post_thumbnail( 'aurion-team', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
						</div>
						<div class="team-card__body">
							<h3 class="team-card__name"><?php the_title(); ?></h3>
							<?php if ( $role ) : ?>
								<p class="team-card__role"><?php echo esc_html( $role ); ?></p>
							<?php endif; ?>
							<a class="team-card__link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View Biography', 'aurion-energy' ); ?></a>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p><?php esc_html_e( 'Leadership profiles will be available soon.', 'aurion-energy' ); ?></p>
				<?php
			endif;
			?>
		</div>
	</div>
</section>

<section class="section section--safety" data-observe>
	<div class="container section__flex">
		<div class="section__content">
			<h2 class="section__title"><?php esc_html_e( 'Safety Excellence', 'aurion-energy' ); ?></h2>
			<p><?php esc_html_e( 'Our safety culture is built on proactive planning, rigorous training, and continuous improvement. Every Aurion team member is empowered to anticipate risks and protect our people, partners, and environment.', 'aurion-energy' ); ?></p>
			<ul class="checklist">
				<li><?php esc_html_e( 'COR and ISNetworld compliant field procedures', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'Real-time safety reporting through digital dashboards', 'aurion-energy' ); ?></li>
				<li><?php esc_html_e( 'Joint site inspections with clients and regulators', 'aurion-energy' ); ?></li>
			</ul>
		</div>
		<div class="section__visual">
			<picture>
				<source srcset="<?php echo esc_url( get_theme_file_uri( 'assets/images/safety-briefing.webp' ) ); ?>" type="image/webp">
				<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/safety-briefing.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Aurion field safety briefing', 'aurion-energy' ); ?>" loading="lazy">
			</picture>
		</div>
	</div>
</section>

<section class="section section--sustainability" data-observe>
	<div class="container">
		<h2 class="section__title"><?php esc_html_e( 'Sustainability Commitment', 'aurion-energy' ); ?></h2>
		<div class="sustainability-grid sustainability-grid--about">
			<div class="sustainability-card">
				<h3 class="sustainability-card__title"><?php esc_html_e( 'Carbon Intelligence', 'aurion-energy' ); ?></h3>
				<p class="sustainability-card__text"><?php esc_html_e( 'Lifecycle modeling to reduce emissions across engineering, logistics, and operations.', 'aurion-energy' ); ?></p>
			</div>
			<div class="sustainability-card">
				<h3 class="sustainability-card__title"><?php esc_html_e( 'Community Engagement', 'aurion-energy' ); ?></h3>
				<p class="sustainability-card__text"><?php esc_html_e( 'Indigenous partnership protocols and stakeholder transparency.', 'aurion-energy' ); ?></p>
			</div>
			<div class="sustainability-card">
				<h3 class="sustainability-card__title"><?php esc_html_e( 'Continuous Improvement', 'aurion-energy' ); ?></h3>
				<p class="sustainability-card__text"><?php esc_html_e( 'Annual sustainability scorecard measuring progress against environmental goals.', 'aurion-energy' ); ?></p>
			</div>
		</div>
	</div>
</section>
<?php
get_footer();
```