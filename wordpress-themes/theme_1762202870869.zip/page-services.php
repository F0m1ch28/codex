```
<?php
/**
 * Template Name: Aurion Services
 *
 * @package Aurion_Energy
 */

get_header();
?>
<section class="page-hero" data-observe>
	<div class="page-hero__content container">
		<h1 class="page-hero__title"><?php the_title(); ?></h1>
		<p class="page-hero__subtitle"><?php esc_html_e( 'Integrated capabilities powering industrial energy progress.', 'aurion-energy' ); ?></p>
	</div>
</section>

<div class="container">
	<?php aurion_energy_breadcrumbs(); ?>
</div>

<section class="section section--page container" data-observe>
	<div class="page-content page-content--intro">
		<?php
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
		?>
	</div>
</section>

<section class="section section--services-grid" data-observe>
	<div class="container">
		<div class="service-grid">
			<?php
			$services = new WP_Query(
				array(
					'post_type'      => 'services',
					'posts_per_page' => -1,
					'orderby'        => array(
						'menu_order' => 'ASC',
						'title'      => 'ASC',
					),
				)
			);

			if ( $services->have_posts() ) :
				while ( $services->have_posts() ) :
					$services->the_post();
					$types = get_the_terms( get_the_ID(), 'service-type' );
					?>
					<article class="service-detail-card" data-observe>
						<div class="service-detail-card__header">
							<?php if ( $types && ! is_wp_error( $types ) ) : ?>
								<span class="service-detail-card__tag"><?php echo esc_html( $types[0]->name ); ?></span>
							<?php endif; ?>
							<h2 class="service-detail-card__title"><?php the_title(); ?></h2>
						</div>
						<div class="service-detail-card__body">
							<?php if ( has_post_thumbnail() ) : ?>
								<div class="service-detail-card__media">
									<?php the_post_thumbnail( 'aurion-project-thumb', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
								</div>
							<?php endif; ?>
							<div class="service-detail-card__content">
								<?php the_content(); ?>
							</div>
						</div>
						<div class="service-detail-card__footer">
							<a class="service-detail-card__link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Engage Aurion', 'aurion-energy' ); ?></a>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p><?php esc_html_e( 'Service information is being prepared.', 'aurion-energy' ); ?></p>
				<?php
			endif;
			?>
		</div>
	</div>
</section>

<section class="section section--cta" data-observe>
	<div class="container">
		<div class="cta-card">
			<div class="cta-card__content">
				<h2 class="cta-card__title"><?php esc_html_e( 'Ready to Start Your Project?', 'aurion-energy' ); ?></h2>
				<p class="cta-card__text"><?php esc_html_e( 'Aurion delivers consulting, research, and field execution tailored to your objectives.', 'aurion-energy' ); ?></p>
			</div>
			<div class="cta-card__actions">
				<a class="btn btn--contrast" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>">
					<?php esc_html_e( 'Contact Aurion', 'aurion-energy' ); ?>
				</a>
			</div>
		</div>
	</div>
</section>
<?php
get_footer();
```