```
/* global jQuery, aurionEnergyTheme */
(function ($) {
	'use strict';

	const navToggle = document.querySelector('.site-header__toggle');
	const navMenu = document.querySelector('.site-navigation');
	const headerSearch = document.querySelector('.header-search');
	const searchInput = document.querySelector('#aurion-header-search');
	const suggestionContainer = document.querySelector('.header-search__suggestions');

	// Mobile menu.
	if (navToggle && navMenu) {
		navToggle.addEventListener('click', () => {
			const expanded = navToggle.getAttribute('aria-expanded') === 'true';
			navToggle.setAttribute('aria-expanded', String(!expanded));
			navMenu.classList.toggle('is-open');
			document.body.classList.toggle('nav-open');
		});
	}

	// Intersection Observer for reveal.
	const revealElements = document.querySelectorAll('[data-observe]');
	if ('IntersectionObserver' in window) {
		const observer = new IntersectionObserver(
			(entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						entry.target.classList.add('is-visible');
						observer.unobserve(entry.target);
					}
				});
			},
			{
				threshold: 0.15,
			}
		);

		revealElements.forEach((element) => observer.observe(element));
	} else {
		revealElements.forEach((element) => element.classList.add('is-visible'));
	}

	// Counter animation.
	const counters = document.querySelectorAll('[data-counter]');
	if (counters.length) {
		const animateCounter = (counter) => {
			const target = parseInt(counter.getAttribute('data-counter-target'), 10);
			const valueElement = counter.querySelector('span');
			let start = 0;
			const duration = 1800;
			const step = () => {
				start += Math.ceil(target / (duration / 16));
				if (start >= target) {
					start = target;
				} else {
					requestAnimationFrame(step);
				}
				if (valueElement) {
					valueElement.textContent = start;
				}
			};
			requestAnimationFrame(step);
		};

		const counterObserver = new IntersectionObserver(
			(entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						animateCounter(entry.target);
						counterObserver.unobserve(entry.target);
					}
				});
			},
			{ threshold: 0.75 }
		);

		counters.forEach((counter) => counterObserver.observe(counter));
	}

	// AJAX search suggestions.
	if (headerSearch && searchInput && suggestionContainer && typeof aurionEnergyTheme !== 'undefined') {
		let searchTimer;
		const suggestionList = document.createElement('ul');
		suggestionContainer.appendChild(suggestionList);

		searchInput.addEventListener('input', (event) => {
			const keyword = event.target.value.trim();

			clearTimeout(searchTimer);

			if (keyword.length < 3) {
				suggestionContainer.classList.remove('is-visible');
				suggestionList.innerHTML = '';
				return;
			}

			searchTimer = setTimeout(() => {
				$.ajax({
					url: aurionEnergyTheme.ajaxUrl,
					type: 'GET',
					dataType: 'json',
					data: {
						action: 'aurion_energy_search',
						nonce: aurionEnergyTheme.nonce,
						term: keyword,
					},
					beforeSend: () => {
						suggestionContainer.classList.add('is-visible');
						suggestionList.innerHTML = '<li>' + aurionEnergyTheme.searchText + '</li>';
					},
					success: (response) => {
						suggestionList.innerHTML = '';
						if (response.success && response.data.length) {
							response.data.forEach((item) => {
								const listItem = document.createElement('li');
								const link = document.createElement('a');
								link.href = item.url;
								link.innerHTML = '<strong>' + item.title + '</strong><span>' + item.type + '</span>';
								listItem.appendChild(link);
								suggestionList.appendChild(listItem);
							});
						} else {
							suggestionList.innerHTML = '<li>' + aurionEnergyTheme.searchText + '</li>';
						}
					},
					error: () => {
						suggestionList.innerHTML = '<li>' + aurionEnergyTheme.searchText + '</li>';
					},
				});
			}, 250);
		});

		document.addEventListener('click', (event) => {
			if (!headerSearch.contains(event.target)) {
				suggestionContainer.classList.remove('is-visible');
			}
		});
	}

	// Cookie consent.
	document.addEventListener('DOMContentLoaded', () => {
		if (typeof initCookieConsent === 'function') {
			const cc = initCookieConsent();
			cc.run({
				current_lang: 'en',
				autoclear_cookies: true,
				page_scripts: true,
				force_consent: false,
				gui_options: {
					consent_modal: {
						layout: 'cloud',
						position: 'bottom center',
						transition: 'slide',
					},
					settings_modal: {
						layout: 'box',
						transition: 'slide',
					},
				},
				languages: {
					en: {
						consent_modal: {
							title: 'Cookies at Aurion',
							description: 'Aurion Energy Advisory uses cookies to enhance site performance, analytics, and tailored content. You can review details and update your choices at any time.',
							primary_btn: {
								text: 'Accept all cookies',
								role: 'accept_all',
							},
							secondary_btn: {
								text: 'Manage preferences',
								role: 'settings',
							},
						},
						settings_modal: {
							title: 'Cookie preferences',
							save_settings_btn: 'Save settings',
							accept_all_btn: 'Accept all cookies',
							close_btn_label: 'Close',
							cookie_table_headers: [
								{ col1: 'Name' },
								{ col2: 'Purpose' },
								{ col3: 'Expiry' },
							],
							blocks: [
								{
									title: 'Cookie usage',
									description: 'Aurion uses cookies for essential functionality, analytics, and experience enhancements. Disable non-essential categories if preferred.',
								},
								{
									title: 'Strictly necessary cookies',
									description: 'Required for core site features such as security and load balancing.',
									toggle: {
										value: 'necessary',
										enabled: true,
										readonly: true,
									},
								},
								{
									title: 'Analytics cookies',
									description: 'Help us understand site engagement so we can improve digital experiences.',
									toggle: {
										value: 'analytics',
										enabled: false,
										readonly: false,
									},
								},
								{
									title: 'Functional cookies',
									description: 'Enable custom settings such as remembered preferences.',
									toggle: {
										value: 'functional',
										enabled: false,
										readonly: false,
									},
								},
							],
						},
					},
				},
			});
		}
	});
})(jQuery);
```

The provided theme files deliver a premium, responsive, and accessible WordPress experience tailored to Aurion Energy Advisory, incorporating all requested functionality, styling, and compliance requirements.