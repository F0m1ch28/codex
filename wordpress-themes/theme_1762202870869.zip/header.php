```
<?php
/**
 * Header template.
 *
 * @package Aurion_Energy
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main-content"><?php esc_html_e( 'Skip to main content', 'aurion-energy' ); ?></a>
<header class="site-header" data-observe>
	<div class="site-header__inner">
		<div class="site-branding">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				echo '<a class="site-title" href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
			}
			?>
		</div>
		<button class="site-header__toggle" aria-expanded="false" aria-controls="primary-menu">
			<span class="site-header__toggle-line"></span>
			<span class="site-header__toggle-line"></span>
			<span class="site-header__toggle-line"></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'aurion-energy' ); ?></span>
		</button>
		<nav class="site-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'aurion-energy' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location'  => 'primary-menu',
					'menu_id'         => 'primary-menu',
					'menu_class'      => 'primary-menu',
					'container'       => false,
					'fallback_cb'     => false,
					'depth'           => 2,
				)
			);
			?>
			<div class="site-navigation__cta">
				<a class="btn btn--outline" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>">
					<?php esc_html_e( 'Connect with Aurion', 'aurion-energy' ); ?>
				</a>
			</div>
		</nav>
	</div>
	<div class="site-header__search">
		<form class="header-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label for="aurion-header-search" class="screen-reader-text"><?php esc_html_e( 'Search', 'aurion-energy' ); ?></label>
			<input id="aurion-header-search" type="search" name="s" placeholder="<?php esc_attr_e( 'Search insights and projects', 'aurion-energy' ); ?>" autocomplete="off">
			<button type="submit" class="header-search__submit" aria-label="<?php esc_attr_e( 'Submit search', 'aurion-energy' ); ?>">
				<span class="header-search__icon" aria-hidden="true"></span>
			</button>
			<div class="header-search__suggestions" aria-live="polite"></div>
		</form>
	</div>
</header>
<main id="main-content" class="site-main">
```