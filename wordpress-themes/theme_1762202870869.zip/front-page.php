```
<?php
/**
 * Front Page template.
 *
 * @package Aurion_Energy
 */

get_header();
?>
<section class="hero" data-observe>
	<div class="hero__media" role="presentation">
		<picture>
			<source srcset="<?php echo esc_url( get_theme_file_uri( 'assets/images/hero-industrial.webp' ) ); ?>" type="image/webp">
			<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/hero-industrial.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Engineers overseeing energy infrastructure', 'aurion-energy' ); ?>" loading="lazy">
		</picture>
	</div>
	<div class="hero__overlay"></div>
	<div class="hero__content container">
		<p class="hero__eyebrow"><?php esc_html_e( 'Integrated Energy Consulting & Engineering', 'aurion-energy' ); ?></p>
		<h1 class="hero__title"><?php esc_html_e( 'Engineering the Future of Energy', 'aurion-energy' ); ?></h1>
		<p class="hero__subtitle"><?php esc_html_e( 'Aurion Energy Advisory delivers multi-disciplinary consulting, project leadership, and oilfield research across Canadian energy corridors.', 'aurion-energy' ); ?></p>
		<div class="hero__actions">
			<a class="btn btn--primary" href="<?php echo esc_url( get_permalink( get_page_by_path( 'services' ) ) ); ?>">
				<?php esc_html_e( 'Discover Our Services', 'aurion-energy' ); ?>
			</a>
			<a class="btn btn--ghost" href="<?php echo esc_url( get_permalink( get_page_by_path( 'projects' ) ) ); ?>">
				<?php esc_html_e( 'View Case Studies', 'aurion-energy' ); ?>
			</a>
		</div>
	</div>
</section>

<section class="section section--split container" data-observe>
	<div class="section__content">
		<h2 class="section__title"><?php esc_html_e( 'Who We Are', 'aurion-energy' ); ?></h2>
		<p><?php esc_html_e( 'Aurion Energy Advisory partners with industrial leaders to design resilient infrastructure, streamline operations, and accelerate sustainable energy transitions. Our practice unites engineers, analysts, and field specialists with decades of experience in complex project environments.', 'aurion-energy' ); ?></p>
		<ul class="feature-list">
			<li class="feature-list__item">
				<span class="feature-list__icon" aria-hidden="true"></span>
				<div>
					<h3 class="feature-list__title"><?php esc_html_e( 'Strategic Consulting', 'aurion-energy' ); ?></h3>
					<p class="feature-list__text"><?php esc_html_e( 'Data-driven assessments aligning energy infrastructure with enterprise objectives.', 'aurion-energy' ); ?></p>
				</div>
			</li>
			<li class="feature-list__item">
				<span class="feature-list__icon feature-list__icon--emerald" aria-hidden="true"></span>
				<div>
					<h3 class="feature-list__title"><?php esc_html_e( 'Field Intelligence', 'aurion-energy' ); ?></h3>
					<p class="feature-list__text"><?php esc_html_e( 'Comprehensive oilfield research supporting compliance, production, and safety decisions.', 'aurion-energy' ); ?></p>
				</div>
			</li>
			<li class="feature-list__item">
				<span class="feature-list__icon feature-list__icon--gold" aria-hidden="true"></span>
				<div>
					<h3 class="feature-list__title"><?php esc_html_e( 'Delivery Excellence', 'aurion-energy' ); ?></h3>
					<p class="feature-list__text"><?php esc_html_e( 'Integrated project execution and installation services for heavy industry.', 'aurion-energy' ); ?></p>
				</div>
			</li>
		</ul>
	</div>
	<div class="section__visual">
		<picture>
			<source srcset="<?php echo esc_url( get_theme_file_uri( 'assets/images/office-strategy.webp' ) ); ?>" type="image/webp">
			<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/office-strategy.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Aurion consultants reviewing industrial data on screens', 'aurion-energy' ); ?>" loading="lazy">
		</picture>
	</div>
</section>

<section class="section section--services" data-observe>
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Our Expertise', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Comprehensive services supporting the full lifecycle of energy infrastructure.', 'aurion-energy' ); ?></p>
		</div>
		<div class="card-grid card-grid--services">
			<?php
			$service_query = new WP_Query(
				array(
					'post_type'      => 'services',
					'posts_per_page' => 4,
					'orderby'        => 'menu_order',
					'order'          => 'ASC',
				)
			);

			if ( $service_query->have_posts() ) :
				while ( $service_query->have_posts() ) :
					$service_query->the_post();
					?>
					<article class="service-card" data-observe>
						<div class="service-card__icon">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'aurion-service', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
							<?php else : ?>
								<span class="service-card__icon-fallback" aria-hidden="true"></span>
							<?php endif; ?>
						</div>
						<h3 class="service-card__title"><?php the_title(); ?></h3>
						<p class="service-card__excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
						<a class="service-card__link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Learn More', 'aurion-energy' ); ?> <span aria-hidden="true">&rarr;</span></a>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p><?php esc_html_e( 'Service information will be published soon.', 'aurion-energy' ); ?></p>
				<?php
			endif;
			?>
		</div>
	</div>
</section>

<section class="section section--metrics" data-observe>
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Why Organizations Choose Aurion', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Operational rigour, safety-first thinking, and measurable project outcomes.', 'aurion-energy' ); ?></p>
		</div>
		<div class="metrics-grid">
			<div class="metric-card" data-counter data-counter-target="250">
				<h3 class="metric-card__number"><span>0</span>+</h3>
				<p class="metric-card__label"><?php esc_html_e( 'Energy & industrial initiatives supported', 'aurion-energy' ); ?></p>
			</div>
			<div class="metric-card" data-counter data-counter-target="18">
				<h3 class="metric-card__number"><span>0</span></h3>
				<p class="metric-card__label"><?php esc_html_e( 'Provinces & territories served across Canada', 'aurion-energy' ); ?></p>
			</div>
			<div class="metric-card" data-counter data-counter-target="35">
				<h3 class="metric-card__number"><span>0</span></h3>
				<p class="metric-card__label"><?php esc_html_e( 'Specialists spanning engineering and field research', 'aurion-energy' ); ?></p>
			</div>
			<div class="metric-card" data-counter data-counter-target="12">
				<h3 class="metric-card__number"><span>0</span></h3>
				<p class="metric-card__label"><?php esc_html_e( 'Integrated service lines covering the project lifecycle', 'aurion-energy' ); ?></p>
			</div>
		</div>
	</div>
</section>

<section class="section section--oilfield" data-observe>
	<div class="container">
		<div class="section__flex">
			<div class="section__visual">
				<picture>
					<source srcset="<?php echo esc_url( get_theme_file_uri( 'assets/images/oilfield-research.webp' ) ); ?>" type="image/webp">
					<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/oilfield-research.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Oilfield researchers monitoring drilling data', 'aurion-energy' ); ?>" loading="lazy">
				</picture>
			</div>
			<div class="section__content">
				<h2 class="section__title"><?php esc_html_e( 'Oilfield Research & Compliance', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'We enable operators to capture real-time well intelligence, meet regulatory commitments, and improve asset uptime through field-driven research programmes.', 'aurion-energy' ); ?></p>
				<ul class="checklist">
					<li><?php esc_html_e( 'Reservoir analysis and production optimization', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Regulatory documentation and stakeholder reporting', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Emissions monitoring with actionable analytics', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Field-to-head office collaboration workflows', 'aurion-energy' ); ?></li>
				</ul>
				<a class="btn btn--primary" href="<?php echo esc_url( get_permalink( get_page_by_path( 'services' ) ) ); ?>">
					<?php esc_html_e( 'Explore Research Services', 'aurion-energy' ); ?>
				</a>
			</div>
		</div>
	</div>
</section>

<section class="section section--engineering" data-observe>
	<div class="container">
		<div class="section__flex section__flex--reverse">
			<div class="section__visual">
				<picture>
					<source srcset="<?php echo esc_url( get_theme_file_uri( 'assets/images/heavy-lift-crane.webp' ) ); ?>" type="image/webp">
					<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/heavy-lift-crane.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Heavy-lift crane installation at industrial facility', 'aurion-energy' ); ?>" loading="lazy">
				</picture>
			</div>
			<div class="section__content">
				<h2 class="section__title"><?php esc_html_e( 'Engineering & Installation', 'aurion-energy' ); ?></h2>
				<p><?php esc_html_e( 'From concept to commissioning, Aurion coordinates engineering discipline leads, lifting strategies, and commissioning activities for complex infrastructure.', 'aurion-energy' ); ?></p>
				<ul class="checklist">
					<li><?php esc_html_e( 'Multi-discipline engineering management', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Cranes and heavy logistics coordination', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Commissioning and start-up readiness planning', 'aurion-energy' ); ?></li>
					<li><?php esc_html_e( 'Digital twins and asset integrity monitoring', 'aurion-energy' ); ?></li>
				</ul>
				<a class="btn btn--ghost" href="<?php echo esc_url( get_permalink( get_page_by_path( 'projects' ) ) ); ?>">
					<?php esc_html_e( 'See Delivery Examples', 'aurion-energy' ); ?>
				</a>
			</div>
		</div>
	</div>
</section>

<section class="section section--sustainability" data-observe>
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Sustainable Innovation', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Integrating low-carbon strategies and environmental stewardship across every engagement.', 'aurion-energy' ); ?></p>
		</div>
		<div class="sustainability-grid">
			<div class="sustainability-card">
				<h3 class="sustainability-card__title"><?php esc_html_e( 'Lifecycle Carbon Planning', 'aurion-energy' ); ?></h3>
				<p class="sustainability-card__text"><?php esc_html_e( 'Scenarios and modeling for emissions reduction embedded within capital and operational planning.', 'aurion-energy' ); ?></p>
			</div>
			<div class="sustainability-card">
				<h3 class="sustainability-card__title"><?php esc_html_e( 'Environmental Compliance', 'aurion-energy' ); ?></h3>
				<p class="sustainability-card__text"><?php esc_html_e( 'Compliance frameworks that align federal, provincial, and territorial requirements with operational realities.', 'aurion-energy' ); ?></p>
			</div>
			<div class="sustainability-card">
				<h3 class="sustainability-card__title"><?php esc_html_e( 'Renewable Integration', 'aurion-energy' ); ?></h3>
				<p class="sustainability-card__text"><?php esc_html_e( 'Hybrid solutions leveraging wind, solar, and storage to enhance industrial resilience.', 'aurion-energy' ); ?></p>
			</div>
		</div>
	</div>
</section>

<section class="section section--projects" data-observe>
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Recent Projects', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'A selection of recent engagements delivering reliable energy systems.', 'aurion-energy' ); ?></p>
		</div>
		<div class="card-grid card-grid--projects">
			<?php
			$projects_query = new WP_Query(
				array(
					'post_type'      => 'projects',
					'posts_per_page' => 3,
				)
			);

			if ( $projects_query->have_posts() ) :
				while ( $projects_query->have_posts() ) :
					$projects_query->the_post();
					$terms = get_the_terms( get_the_ID(), 'project-category' );
					?>
					<article class="project-card" data-observe>
						<a class="project-card__link" href="<?php the_permalink(); ?>">
							<div class="project-card__media">
								<?php if ( has_post_thumbnail() ) : ?>
									<?php the_post_thumbnail( 'aurion-project-thumb', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
								<?php else : ?>
									<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/project-placeholder.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Industrial project site', 'aurion-energy' ); ?>" loading="lazy">
								<?php endif; ?>
								<?php if ( $terms && ! is_wp_error( $terms ) ) : ?>
									<span class="project-card__badge"><?php echo esc_html( $terms[0]->name ); ?></span>
								<?php endif; ?>
							</div>
							<div class="project-card__body">
								<h3 class="project-card__title"><?php the_title(); ?></h3>
								<p class="project-card__excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
							</div>
						</a>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p><?php esc_html_e( 'Project highlights will be published shortly.', 'aurion-energy' ); ?></p>
				<?php
			endif;
			?>
		</div>
		<div class="section__actions">
			<a class="btn btn--outline" href="<?php echo esc_url( get_permalink( get_page_by_path( 'projects' ) ) ); ?>">
				<?php esc_html_e( 'Browse All Projects', 'aurion-energy' ); ?>
			</a>
		</div>
	</div>
</section>

<section class="section section--team" data-observe>
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Meet the Aurion Team', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Engineers, consultants, and researchers aligned around client success.', 'aurion-energy' ); ?></p>
		</div>
		<div class="card-grid card-grid--team">
			<?php
			$team_query = new WP_Query(
				array(
					'post_type'      => 'team',
					'posts_per_page' => 4,
					'orderby'        => 'menu_order',
					'order'          => 'ASC',
				)
			);

			if ( $team_query->have_posts() ) :
				while ( $team_query->have_posts() ) :
					$team_query->the_post();
					$position = get_post_meta( get_the_ID(), 'aurion_role', true );
					?>
					<article class="team-card" data-observe>
						<div class="team-card__media">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'aurion-team', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
							<?php else : ?>
								<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/team-member.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Aurion Energy Advisory team member', 'aurion-energy' ); ?>" loading="lazy">
							<?php endif; ?>
						</div>
						<div class="team-card__body">
							<h3 class="team-card__name"><?php the_title(); ?></h3>
							<?php if ( $position ) : ?>
								<p class="team-card__role"><?php echo esc_html( $position ); ?></p>
							<?php endif; ?>
							<a class="team-card__link" href="<?php the_permalink(); ?>">
								<?php esc_html_e( 'Profile', 'aurion-energy' ); ?>
								<span aria-hidden="true">&rarr;</span>
							</a>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p><?php esc_html_e( 'Team introductions will be available soon.', 'aurion-energy' ); ?></p>
				<?php
			endif;
			?>
		</div>
		<div class="section__actions">
			<a class="btn btn--primary" href="<?php echo esc_url( get_permalink( get_page_by_path( 'team' ) ) ); ?>">
				<?php esc_html_e( 'View Full Team', 'aurion-energy' ); ?>
			</a>
		</div>
	</div>
</section>

<section class="section section--testimonials" data-observe>
	<div class="container">
		<div class="section__header">
			<h2 class="section__title"><?php esc_html_e( 'Client Perspectives', 'aurion-energy' ); ?></h2>
			<p class="section__subtitle"><?php esc_html_e( 'Voices from partners who rely on Aurion for strategic energy advancement.', 'aurion-energy' ); ?></p>
		</div>
		<div class="testimonial-slider" data-slider>
			<?php
			$testimonial_query = new WP_Query(
				array(
					'post_type'      => 'testimonials',
					'posts_per_page' => 5,
					'orderby'        => 'menu_order',
					'order'          => 'ASC',
				)
			);

			if ( $testimonial_query->have_posts() ) :
				while ( $testimonial_query->have_posts() ) :
					$testimonial_query->the_post();
					$company = get_post_meta( get_the_ID(), 'aurion_company', true );
					?>
					<article class="testimonial-card" data-observe>
						<div class="testimonial-card__body">
							<div class="testimonial-card__quote">
								<p><?php echo esc_html( wp_strip_all_tags( get_the_content() ) ); ?></p>
							</div>
							<div class="testimonial-card__footer">
								<div class="testimonial-card__meta">
									<h3 class="testimonial-card__name"><?php the_title(); ?></h3>
									<?php if ( $company ) : ?>
										<p class="testimonial-card__company"><?php echo esc_html( $company ); ?></p>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<p><?php esc_html_e( 'Testimonials will be published shortly.', 'aurion-energy' ); ?></p>
				<?php
			endif;
			?>
		</div>
	</div>
</section>

<section class="section section--cta" data-observe>
	<div class="container">
		<div class="cta-card">
			<div class="cta-card__content">
				<h2 class="cta-card__title"><?php esc_html_e( 'Partner with Aurion', 'aurion-energy' ); ?></h2>
				<p class="cta-card__text"><?php esc_html_e( 'Let’s co-design resilient energy systems that elevate performance, compliance, and sustainability.', 'aurion-energy' ); ?></p>
			</div>
			<div class="cta-card__actions">
				<a class="btn btn--contrast" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>">
					<?php esc_html_e( 'Schedule a Consultation', 'aurion-energy' ); ?>
				</a>
			</div>
		</div>
	</div>
</section>
<?php
get_footer();
```