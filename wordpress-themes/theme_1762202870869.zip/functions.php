```
<?php
/**
 * Aurion Energy Advisory theme functions.
 *
 * @package Aurion_Energy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_template_directory() . '/inc/helpers.php';

/**
 * Theme setup.
 */
function aurion_energy_setup() {
	load_theme_textdomain( 'aurion-energy', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'custom-logo', array(
		'height'      : 48,
		'width'       : 200,
		'flex-width'  : true,
		'flex-height' : true,
	) );
	add_theme_support( 'html5', array(
		'search-form',
		'caption',
		'comment-form',
		'comment-list',
		'gallery',
		'script',
		'style',
	) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'woocommerce' );

	register_nav_menus(
		array(
			'primary-menu'   => __( 'Primary Menu', 'aurion-energy' ),
			'secondary-menu' => __( 'Secondary Menu', 'aurion-energy' ),
			'footer-menu'    => __( 'Footer Menu', 'aurion-energy' ),
		)
	);

	add_image_size( 'aurion-hero', 1920, 600, true );
	add_image_size( 'aurion-project-thumb', 600, 400, true );
	add_image_size( 'aurion-project-full', 1200, 600, true );
	add_image_size( 'aurion-team', 300, 300, true );
	add_image_size( 'aurion-testimonial', 150, 150, true );
	add_image_size( 'aurion-service', 200, 200, true );
}
add_action( 'after_setup_theme', 'aurion_energy_setup' );

/**
 * Set content width.
 */
function aurion_energy_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'aurion_energy_content_width', 1200 );
}
add_action( 'after_setup_theme', 'aurion_energy_content_width', 0 );

/**
 * Register widget areas.
 */
function aurion_energy_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Sidebar', 'aurion-energy' ),
			'id'            => 'sidebar-primary',
			'description'   => __( 'Main sidebar area.', 'aurion-energy' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget__title">',
			'after_title'   => '</h3>',
		)
	);

	for ( $i = 1; $i <= 4; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d footer column number */
				'name'          => sprintf( __( 'Footer Column %d', 'aurion-energy' ), $i ),
				'id'            => 'footer-' . $i,
				'description'   => __( 'Footer widget area.', 'aurion-energy' ),
				'before_widget' => '<section id="%1$s" class="widget footer-widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h3 class="footer-widget__title">',
				'after_title'   => '</h3>',
			)
		);
	}
}
add_action( 'widgets_init', 'aurion_energy_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function aurion_energy_scripts() {
	$theme_version = wp_get_theme()->get( 'Version' );

	wp_enqueue_style( 'aurion-energy-cookieconsent', 'https://cdn.jsdelivr.net/npm/vanilla-cookieconsent@2.0.0/dist/cookieconsent.css', array(), '2.0.0' );
	wp_enqueue_style( 'aurion-energy-google-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@500;600;700&family=Inter:wght@400;500;600&display=swap', array(), null );
	wp_enqueue_style( 'aurion-energy-main', get_template_directory_uri() . '/assets/css/style.css', array(), $theme_version );
	wp_enqueue_style( 'aurion-energy-style', get_stylesheet_uri(), array( 'aurion-energy-main' ), $theme_version );

	wp_enqueue_script( 'aurion-energy-cookieconsent', 'https://cdn.jsdelivr.net/npm/vanilla-cookieconsent@2.0.0/dist/cookieconsent.js', array(), '2.0.0', true );
	wp_enqueue_script( 'aurion-energy-script', get_template_directory_uri() . '/assets/js/script.js', array( 'jquery' ), $theme_version, true );

	wp_localize_script(
		'aurion-energy-script',
		'aurionEnergyTheme',
		array(
			'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'aurion-energy-ajax' ),
			'searchText' => __( 'Start typing to search projects and insights...', 'aurion-energy' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'aurion_energy_scripts' );

/**
 * Register Custom Post Types.
 */
function aurion_energy_register_cpts() {

	// Projects.
	$labels = array(
		'name'               => __( 'Projects', 'aurion-energy' ),
		'singular_name'      => __( 'Project', 'aurion-energy' ),
		'add_new'            => __( 'Add Project', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Project', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Project', 'aurion-energy' ),
		'new_item'           => __( 'New Project', 'aurion-energy' ),
		'view_item'          => __( 'View Project', 'aurion-energy' ),
		'search_items'       => __( 'Search Projects', 'aurion-energy' ),
		'not_found'          => __( 'No projects found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No projects found in Trash.', 'aurion-energy' ),
		'menu_name'          => __( 'Projects', 'aurion-energy' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields' ),
		'has_archive'        => true,
		'menu_icon'          => 'dashicons-admin-multisite',
		'show_in_rest'       => true,
		'rewrite'            => array( 'slug' => 'projects' ),
	);
	register_post_type( 'projects', $args );

	// Team.
	$team_labels = array(
		'name'               => __( 'Team Members', 'aurion-energy' ),
		'singular_name'      => __( 'Team Member', 'aurion-energy' ),
		'add_new'            => __( 'Add Team Member', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Team Member', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Team Member', 'aurion-energy' ),
		'new_item'           => __( 'New Team Member', 'aurion-energy' ),
		'view_item'          => __( 'View Team Member', 'aurion-energy' ),
		'search_items'       => __( 'Search Team Members', 'aurion-energy' ),
		'not_found'          => __( 'No team members found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No team members found in Trash.', 'aurion-energy' ),
		'menu_name'          => __( 'Team', 'aurion-energy' ),
	);

	$team_args = array(
		'labels'        => $team_labels,
		'public'        => true,
		'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		'menu_icon'     => 'dashicons-groups',
		'show_in_rest'  => true,
		'rewrite'       => array( 'slug' => 'team' ),
	);

	register_post_type( 'team', $team_args );

	// Testimonials.
	$testimonial_labels = array(
		'name'               => __( 'Testimonials', 'aurion-energy' ),
		'singular_name'      => __( 'Testimonial', 'aurion-energy' ),
		'add_new'            => __( 'Add Testimonial', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Testimonial', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Testimonial', 'aurion-energy' ),
		'new_item'           => __( 'New Testimonial', 'aurion-energy' ),
		'view_item'          => __( 'View Testimonial', 'aurion-energy' ),
		'search_items'       => __( 'Search Testimonials', 'aurion-energy' ),
		'not_found'          => __( 'No testimonials found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No testimonials found in Trash.', 'aurion-energy' ),
		'menu_name'          => __( 'Testimonials', 'aurion-energy' ),
	);

	$testimonial_args = array(
		'labels'       => $testimonial_labels,
		'public'       => true,
		'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		'menu_icon'    => 'dashicons-format-quote',
		'show_in_rest' => true,
		'rewrite'      => array( 'slug' => 'testimonials' ),
	);

	register_post_type( 'testimonials', $testimonial_args );

	// Services.
	$service_labels = array(
		'name'               => __( 'Services', 'aurion-energy' ),
		'singular_name'      => __( 'Service', 'aurion-energy' ),
		'add_new'            => __( 'Add Service', 'aurion-energy' ),
		'add_new_item'       => __( 'Add New Service', 'aurion-energy' ),
		'edit_item'          => __( 'Edit Service', 'aurion-energy' ),
		'new_item'           => __( 'New Service', 'aurion-energy' ),
		'view_item'          => __( 'View Service', 'aurion-energy' ),
		'search_items'       => __( 'Search Services', 'aurion-energy' ),
		'not_found'          => __( 'No services found.', 'aurion-energy' ),
		'not_found_in_trash' => __( 'No services found in Trash.', 'aurion-energy' ),
		'menu_name'          => __( 'Services', 'aurion-energy' ),
	);

	$service_args = array(
		'labels'       => $service_labels,
		'public'       => true,
		'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		'menu_icon'    => 'dashicons-hammer',
		'show_in_rest' => true,
		'rewrite'      => array( 'slug' => 'service' ),
	);
	register_post_type( 'services', $service_args );
}
add_action( 'init', 'aurion_energy_register_cpts' );

/**
 * Register taxonomies.
 */
function aurion_energy_register_taxonomies() {

	register_taxonomy(
		'project-category',
		'projects',
		array(
			'labels'            => array(
				'name'          => __( 'Project Categories', 'aurion-energy' ),
				'singular_name' => __( 'Project Category', 'aurion-energy' ),
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
		)
	);

	register_taxonomy(
		'service-type',
		'services',
		array(
			'labels'            => array(
				'name'          => __( 'Service Types', 'aurion-energy' ),
				'singular_name' => __( 'Service Type', 'aurion-energy' ),
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
		)
	);

	register_taxonomy(
		'team-department',
		'team',
		array(
			'labels'            => array(
				'name'          => __( 'Departments', 'aurion-energy' ),
				'singular_name' => __( 'Department', 'aurion-energy' ),
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
		)
	);
}
add_action( 'init', 'aurion_energy_register_taxonomies', 0 );

/**
 * Customize excerpt length.
 */
function aurion_energy_excerpt_length( $length ) {
	return 24;
}
add_filter( 'excerpt_length', 'aurion_energy_excerpt_length', 99 );

/**
 * Customize excerpt more text.
 */
function aurion_energy_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'aurion_energy_excerpt_more' );

/**
 * Customizer settings.
 */
function aurion_energy_customize_register( $wp_customize ) {

	$wp_customize->add_section(
		'aurion_energy_branding',
		array(
			'title'    => __( 'Aurion Branding', 'aurion-energy' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'aurion_primary_color',
		array(
			'default'           => '#1e40af',
			'transport'         => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'aurion_primary_color',
			array(
				'label'   => __( 'Primary Accent Colour', 'aurion-energy' ),
				'section' => 'aurion_energy_branding',
			)
		)
	);

	$wp_customize->add_setting(
		'aurion_secondary_color',
		array(
			'default'           => '#047857',
			'transport'         => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'aurion_secondary_color',
			array(
				'label'   => __( 'Secondary Accent Colour', 'aurion-energy' ),
				'section' => 'aurion_energy_branding',
			)
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_email',
		array(
			'default'           => 'contact@aurionenergy.com',
			'transport'         => 'refresh',
			'sanitize_callback' => 'sanitize_email',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_email',
		array(
			'label'       => __( 'Contact Email Address', 'aurion-energy' ),
			'section'     => 'aurion_energy_branding',
			'type'        => 'email',
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_phone',
		array(
			'default'           => '+1 (416) 792-4583',
			'transport'         => 'refresh',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_phone',
		array(
			'label'   => __( 'Contact Phone Number', 'aurion-energy' ),
			'section' => 'aurion_energy_branding',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'aurion_contact_address',
		array(
			'default'           => '460 Bay St, Toronto, ON M5H 2Y4, Canada',
			'transport'         => 'refresh',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'aurion_contact_address',
		array(
			'label'   => __( 'Office Address', 'aurion-energy' ),
			'section' => 'aurion_energy_branding',
			'type'    => 'text',
		)
	);
}
add_action( 'customize_register', 'aurion_energy_customize_register' );

/**
 * Helper to get contact email.
 */
function aurion_energy_get_contact_email() {
	$email = get_theme_mod( 'aurion_contact_email', 'contact@aurionenergy.com' );
	return sanitize_email( $email );
}

/**
 * Breadcrumb trail.
 */
function aurion_energy_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}

	echo '<nav class="aurion-breadcrumb" aria-label="' . esc_attr__( 'Breadcrumb', 'aurion-energy' ) . '">';
	echo '<ol class="aurion-breadcrumb__list">';
	echo '<li class="aurion-breadcrumb__item"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'aurion-energy' ) . '</a></li>';

	if ( is_singular() ) {
		$post = get_post();
		if ( $post->post_type !== 'post' && get_post_type_archive_link( $post->post_type ) ) {
			echo '<li class="aurion-breadcrumb__item"><a href="' . esc_url( get_post_type_archive_link( $post->post_type ) ) . '">' . esc_html( get_post_type_object( $post->post_type )->labels->name ) . '</a></li>';
		}
		echo '<li class="aurion-breadcrumb__item aurion-breadcrumb__item--current" aria-current="page">' . esc_html( get_the_title() ) . '</li>';
	} elseif ( is_archive() ) {
		echo '<li class="aurion-breadcrumb__item aurion-breadcrumb__item--current" aria-current="page">' . esc_html( get_the_archive_title() ) . '</li>';
	} elseif ( is_search() ) {
		echo '<li class="aurion-breadcrumb__item aurion-breadcrumb__item--current" aria-current="page">' . esc_html__( 'Search', 'aurion-energy' ) . '</li>';
	} elseif ( is_404() ) {
		echo '<li class="aurion-breadcrumb__item aurion-breadcrumb__item--current" aria-current="page">' . esc_html__( 'Not Found', 'aurion-energy' ) . '</li>';
	}

	echo '</ol>';
	echo '</nav>';
}

/**
 * Pagination helper.
 */
function aurion_energy_pagination() {
	the_posts_pagination(
		array(
			'mid_size'  => 2,
			'prev_text' => __( 'Previous', 'aurion-energy' ),
			'next_text' => __( 'Next', 'aurion-energy' ),
		)
	);
}

/**
 * AJAX search handler.
 */
function aurion_energy_ajax_search() {
	check_ajax_referer( 'aurion-energy-ajax', 'nonce' );

	$keyword = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';

	$response = array();

	if ( ! empty( $keyword ) ) {
		$query = new WP_Query(
			array(
				'post_type'      => array( 'post', 'projects', 'services' ),
				's'              => $keyword,
				'post_status'    => 'publish',
				'posts_per_page' => 5,
			)
		);

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$response[] = array(
					'title' => get_the_title(),
					'url'   => get_permalink(),
					'type'  => get_post_type_object( get_post_type() )->labels->singular_name,
				);
			}
			wp_reset_postdata();
		}
	}

	wp_send_json_success( $response );
}
add_action( 'wp_ajax_aurion_energy_search', 'aurion_energy_ajax_search' );
add_action( 'wp_ajax_nopriv_aurion_energy_search', 'aurion_energy_ajax_search' );

/**
 * Contact form handler.
 */
function aurion_energy_handle_contact_form() {
	if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		return;
	}

	if ( isset( $_POST['aurion_energy_contact_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['aurion_energy_contact_nonce'] ) ), 'aurion_energy_contact' ) ) {

		$name    = isset( $_POST['aurion_name'] ) ? sanitize_text_field( wp_unslash( $_POST['aurion_name'] ) ) : '';
		$email   = isset( $_POST['aurion_email'] ) ? sanitize_email( wp_unslash( $_POST['aurion_email'] ) ) : '';
		$phone   = isset( $_POST['aurion_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['aurion_phone'] ) ) : '';
		$company = isset( $_POST['aurion_company'] ) ? sanitize_text_field( wp_unslash( $_POST['aurion_company'] ) ) : '';
		$subject = isset( $_POST['aurion_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['aurion_subject'] ) ) : '';
		$message = isset( $_POST['aurion_message'] ) ? wp_kses_post( wp_unslash( $_POST['aurion_message'] ) ) : '';

		if ( empty( $name ) || empty( $email ) || empty( $message ) ) {
			wp_safe_redirect( add_query_arg( 'contact-status', 'error', wp_get_referer() ) );
			exit;
		}

		$to       = aurion_energy_get_contact_email();
		$headers  = array( 'Reply-To: ' . $name . ' <' . $email . '>' );
		$email_subject = sprintf(
			/* translators: %s subject line */
			__( 'Aurion Energy Advisory Inquiry: %s', 'aurion-energy' ),
			$subject ? $subject : __( 'General Inquiry', 'aurion-energy' )
		);

		$body  = sprintf( __( "Name: %s\n", 'aurion-energy' ), $name );
		$body .= sprintf( __( "Email: %s\n", 'aurion-energy' ), $email );
		$body .= sprintf( __( "Phone: %s\n", 'aurion-energy' ), $phone );
		$body .= sprintf( __( "Company: %s\n", 'aurion-energy' ), $company );
		$body .= sprintf( __( "Subject: %s\n\n", 'aurion-energy' ), $subject );
		$body .= __( 'Message:', 'aurion-energy' ) . "\n" . $message;

		wp_mail( $to, $email_subject, $body, $headers );

		wp_safe_redirect( add_query_arg( 'contact-status', 'success', wp_get_referer() ) );
		exit;
	}
}
add_action( 'init', 'aurion_energy_handle_contact_form' );

/**
 * Schema & meta tags.
 */
function aurion_energy_meta_tags() {
	$description = get_bloginfo( 'description', 'display' );
	?>
	<meta property="og:site_name" content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
	<meta property="og:locale" content="en_CA">
	<meta name="description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
	<meta name="twitter:card" content="summary_large_image">
	<script type="application/ld+json">
	{
		"@context": "https://schema.org",
		"@type": "Corporation",
		"name": "Aurion Energy Advisory",
		"url": "<?php echo esc_url( home_url( '/' ) ); ?>",
		"logo": "<?php echo esc_url( get_theme_file_uri( 'assets/images/logo-aurion.svg' ) ); ?>",
		"email": "<?php echo esc_js( aurion_energy_get_contact_email() ); ?>",
		"telephone": "+1 (416) 792-4583",
		"address": {
			"@type": "PostalAddress",
			"streetAddress": "460 Bay St",
			"addressLocality": "Toronto",
			"addressRegion": "ON",
			"postalCode": "M5H 2Y4",
			"addressCountry": "CA"
		}
	}
	</script>
	<?php
}
add_action( 'wp_head', 'aurion_energy_meta_tags' );

/**
 * Custom widgets.
 */
class Aurion_Energy_Testimonial_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'aurion_energy_testimonial_widget',
			__( 'Aurion Testimonial Highlight', 'aurion-energy' ),
			array(
				'description' => __( 'Showcase a testimonial with name and role.', 'aurion-energy' ),
			)
		);
	}

	public function widget( $args, $instance ) {
		$title   = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$content = ! empty( $instance['content'] ) ? $instance['content'] : '';
		$name    = ! empty( $instance['name'] ) ? $instance['name'] : '';
		$role    = ! empty( $instance['role'] ) ? $instance['role'] : '';

		echo $args['before_widget'];

		if ( ! empty( $title ) ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
		}

		if ( ! empty( $content ) ) {
			echo '<p class="aurion-testimonial-widget__quote">' . esc_html( $content ) . '</p>';
		}

		if ( ! empty( $name ) || ! empty( $role ) ) {
			echo '<p class="aurion-testimonial-widget__author">';
			echo '<strong>' . esc_html( $name ) . '</strong>';
			if ( ! empty( $role ) ) {
				echo '<span class="aurion-testimonial-widget__role">' . esc_html( $role ) . '</span>';
			}
			echo '</p>';
		}

		echo $args['after_widget'];
	}

	public function form( $instance ) {
		$title   = isset( $instance['title'] ) ? $instance['title'] : '';
		$content = isset( $instance['content'] ) ? $instance['content'] : '';
		$name    = isset( $instance['name'] ) ? $instance['name'] : '';
		$role    = isset( $instance['role'] ) ? $instance['role'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Quote', 'aurion-energy' ); ?></label>
			<textarea class="widefat" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>"><?php echo esc_textarea( $content ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>"><?php esc_html_e( 'Name', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'name' ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'role' ) ); ?>"><?php esc_html_e( 'Role / Company', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'role' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'role' ) ); ?>" type="text" value="<?php echo esc_attr( $role ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance              = array();
		$instance['title']     = sanitize_text_field( $new_instance['title'] );
		$instance['content']   = sanitize_text_field( $new_instance['content'] );
		$instance['name']      = sanitize_text_field( $new_instance['name'] );
		$instance['role']      = sanitize_text_field( $new_instance['role'] );
		return $instance;
	}
}

class Aurion_Energy_Service_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'aurion_energy_service_widget',
			__( 'Aurion Service Highlight', 'aurion-energy' ),
			array(
				'description' => __( 'Display a featured service with summary.', 'aurion-energy' ),
			)
		);
	}

	public function widget( $args, $instance ) {
		$title       = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$description = ! empty( $instance['description'] ) ? $instance['description'] : '';
		$link        = ! empty( $instance['link'] ) ? $instance['link'] : '';

		echo $args['before_widget'];

		if ( ! empty( $title ) ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
		}

		if ( ! empty( $description ) ) {
			echo '<p class="aurion-service-widget__summary">' . esc_html( $description ) . '</p>';
		}

		if ( ! empty( $link ) ) {
			echo '<a class="aurion-link aurion-service-widget__link" href="' . esc_url( $link ) . '">' . esc_html__( 'Explore Service', 'aurion-energy' ) . '</a>';
		}

		echo $args['after_widget'];
	}

	public function form( $instance ) {
		$title       = isset( $instance['title'] ) ? $instance['title'] : '';
		$description = isset( $instance['description'] ) ? $instance['description'] : '';
		$link        = isset( $instance['link'] ) ? $instance['link'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>"><?php esc_html_e( 'Summary', 'aurion-energy' ); ?></label>
			<textarea class="widefat" rows="4" id="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'description' ) ); ?>"><?php echo esc_textarea( $description ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Link URL', 'aurion-energy' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="url" value="<?php echo esc_attr( $link ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance                 = array();
		$instance['title']        = sanitize_text_field( $new_instance['title'] );
		$instance['description']  = sanitize_textarea_field( $new_instance['description'] );
		$instance['link']         = esc_url_raw( $new_instance['link'] );
		return $instance;
	}
}

function aurion_energy_register_widgets() {
	register_widget( 'Aurion_Energy_Testimonial_Widget' );
	register_widget( 'Aurion_Energy_Service_Widget' );
}
add_action( 'widgets_init', 'aurion_energy_register_widgets' );

/**
 * Local business schema for footer.
 */
function aurion_energy_footer_schema() {
	if ( ! is_front_page() ) {
		return;
	}
	?>
	<script type="application/ld+json">
	{
		"@context": "https://schema.org",
		"@type": "LocalBusiness",
		"name": "Aurion Energy Advisory",
		"image": "<?php echo esc_url( get_theme_file_uri( 'assets/images/office-collaboration.jpg' ) ); ?>",
		"address": {
			"@type": "PostalAddress",
			"streetAddress": "460 Bay St",
			"addressLocality": "Toronto",
			"addressRegion": "Ontario",
			"postalCode": "M5H 2Y4",
			"addressCountry": "CA"
		},
		"telephone": "+1 (416) 792-4583"
	}
	</script>
	<?php
}
add_action( 'wp_footer', 'aurion_energy_footer_schema', 20 );
```