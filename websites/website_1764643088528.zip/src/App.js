import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import styles from './App.module.css';

const RouteChangeHandler = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
};

const DisclaimerModal = ({ onConfirm }) => (
  <div className={styles.disclaimerOverlay} role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
    <div className={styles.disclaimerContent}>
      <h2 id="disclaimer-title">Мы не предоставляем финансовые услуги</h2>
      <p lang="ru">Наша платформа создана для обучения. Мы не предоставляем финансовые услуги и не являемся консультантами.</p>
      <p lang="en">We do not provide financial services. Tu Progreso Hoy is an educational platform offering transparent insights, not financial advice.</p>
      <p lang="es">No brindamos servicios financieros. Tu Progreso Hoy es una plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
      <button type="button" className={styles.disclaimerButton} onClick={onConfirm}>
        I Understand / Comprendo
      </button>
    </div>
  </div>
);

function App() {
  const [showDisclaimer, setShowDisclaimer] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('tphDisclaimerAccepted');
    if (!stored) {
      setShowDisclaimer(true);
    }
  }, []);

  const handleDisclaimerConfirm = () => {
    localStorage.setItem('tphDisclaimerAccepted', 'true');
    setShowDisclaimer(false);
  };

  return (
    <Router>
      <div className={styles.appWrapper}>
        <RouteChangeHandler />
        {showDisclaimer && <DisclaimerModal onConfirm={handleDisclaimerConfirm} />}
        <Header />
        <main className={styles.mainContent}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/inflation" element={<Inflation />} />
            <Route path="/course" element={<Course />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<CookiePolicy />} />
            <Route path="/terms" element={<Terms />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTopButton />
      </div>
    </Router>
  );
}

export default App;