import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-labelledby="footer-heading">
    <div className={styles.container}>
      <div className={styles.column}>
        <h2 id="footer-heading">Tu Progreso Hoy</h2>
        <p>Datos verificados para planificar tu presupuesto. Decisiones responsables, objetivos nítidos.</p>
        <p lang="es">Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
        <p lang="ru">Мы не предоставляем финансовые услуги. Информация предназначена для обучения.</p>
      </div>
      <div className={styles.column}>
        <h3>Explore</h3>
        <ul>
          <li><Link to="/inflation">Inflation Insights</Link></li>
          <li><Link to="/course">Course Overview</Link></li>
          <li><Link to="/resources">Resources</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Support</h3>
        <ul>
          <li><Link to="/privacy">Privacy Policy</Link></li>
          <li><Link to="/cookies">Cookies</Link></li>
          <li><Link to="/terms">Terms &amp; Conditions</Link></li>
          <li><a href="https://tuprogresohoy.com/sitemap.xml" rel="nofollow">Sitemap</a></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Contact</h3>
        <p>Av. 9 de Julio 1000<br />C1043 Buenos Aires, Argentina</p>
        <p>Phone: <a href="tel:+541155551234">+54 11 5555-1234</a></p>
        <p>Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a></p>
        <div className={styles.social}>
          <a href="https://www.linkedin.com" aria-label="LinkedIn">LinkedIn</a>
          <a href="https://twitter.com" aria-label="X">X</a>
          <a href="https://www.youtube.com" aria-label="YouTube">YouTube</a>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Tu Progreso Hoy. Conocimiento financiero impulsado por tendencias.</p>
    </div>
  </footer>
);

export default Footer;