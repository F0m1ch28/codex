import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('tphCookieConsent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('tphCookieConsent', 'granted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('tphCookieConsent', 'declined');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <p>
          We use analytical cookies to improve learning journeys. Accepting helps us deliver datos confiables about argentina inflation and ars usd signals.
        </p>
        <p lang="es">Utilizamos cookies analíticas para mejorar tu experiencia. Información confiable que respalda elecciones responsables sobre tu dinero.</p>
        <p lang="ru">Мы не предоставляем финансовые услуги. Cookies помогают нам совершенствовать образовательную платформу.</p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={handleDecline} className={styles.secondary}>Decline non-essential</button>
        <button type="button" onClick={handleAccept} className={styles.primary}>Accept cookies</button>
      </div>
    </div>
  );
};

export default CookieBanner;