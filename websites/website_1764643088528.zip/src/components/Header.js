import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);

  const handleToggle = () => setOpen((prev) => !prev);
  const handleClose = () => setOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Tu Progreso Hoy home">
          Tu Progreso Hoy
        </Link>
        <nav className={`${styles.nav} ${open ? styles.navOpen : ''}`} aria-label="Main navigation">
          <NavLink to="/" onClick={handleClose} className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Home / Inicio
          </NavLink>
          <NavLink to="/inflation" onClick={handleClose} className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Inflation / Inflación
          </NavLink>
          <NavLink to="/course" onClick={handleClose} className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Course / Curso
          </NavLink>
          <NavLink to="/resources" onClick={handleClose} className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Resources / Recursos
          </NavLink>
          <NavLink to="/contact" onClick={handleClose} className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Contact / Contacto
          </NavLink>
        </nav>
        <button
          type="button"
          className={styles.menuToggle}
          onClick={handleToggle}
          aria-expanded={open}
          aria-controls="mobile-menu"
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className="visually-hidden">Toggle menu</span>
        </button>
      </div>
    </header>
  );
};

export default Header;