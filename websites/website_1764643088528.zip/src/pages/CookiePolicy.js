import React from 'react';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <h1>Cookie Policy</h1>
    <p>Effective date: 15 May 2024</p>
    <section>
      <h2>What are cookies?</h2>
      <p>Cookies are small text files stored on your device to remember preferences. We use them solely for analytics and session management.</p>
    </section>
    <section>
      <h2>Types of cookies we use</h2>
      <ul>
        <li><strong>Essential</strong>: Required for security and login.</li>
        <li><strong>Analytics</strong>: Measure course engagement. Enabled only after opt-in.</li>
      </ul>
    </section>
    <section>
      <h2>Managing cookies</h2>
      <p>You can adjust browser settings or update your consent via the banner. Declining non-essential cookies will not block access to educational content.</p>
    </section>
    <section>
      <h2>Third-party services</h2>
      <p>We may use privacy-focused analytics providers with anonymised data. No targeted advertising occurs.</p>
    </section>
    <section>
      <h2>Contact</h2>
      <p>Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a></p>
    </section>
  </div>
);

export default CookiePolicy;