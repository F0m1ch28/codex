import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './Home.module.css';

const testimonials = [
  {
    name: 'Lucía R.',
    role: 'Analista Junior',
    quote: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. El curso me ayudó a entender cómo impacta la inflación en mis ahorros.'
  },
  {
    name: 'Martín S.',
    role: 'Emprendedor',
    quote: 'Gracias a los módulos de presupuesto, hice pasos acertados hoy, mejor futuro mañana. Información confiable que respalda mis decisiones.'
  },
  {
    name: 'Ana P.',
    role: 'Docente',
    quote: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Los datos sobre ars usd son claros y prácticos.'
  }
];

const insights = [
  {
    title: 'Real-time ARS ➝ USD pulse',
    description: 'Visualiza el tipo de cambio y la brecha con tasas alternativas para planificar tu presupuesto semanal.',
    metric: 'Brecha monitoreada: responsable decisions'
  },
  {
    title: 'Argentina inflation tracker',
    description: 'Datos verificados para planificar tu presupuesto, incluyendo variaciones del IPC y contexto macro regional.',
    metric: 'Último IPC mensual: 17.2%'
  },
  {
    title: 'Tendencias que educan',
    description: 'Conocimiento financiero impulsado por tendencias, con foco en finanzas personales y budgeting argentina.',
    metric: '3 macro alertas activas'
  }
];

const Home = () => {
  const [rate, setRate] = useState(null);
  const [usdToArs, setUsdToArs] = useState(null);
  const [updatedAt, setUpdatedAt] = useState('');
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    goal: ''
  });
  const [consentUpdates, setConsentUpdates] = useState(false);
  const [consentPolicy, setConsentPolicy] = useState(false);
  const [step, setStep] = useState('form');
  const [formError, setFormError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const response = await fetch('https://api.exchangerate.host/latest?base=ARS&symbols=USD');
        if (!response.ok) {
          throw new Error('Network error');
        }
        const data = await response.json();
        if (data?.rates?.USD) {
          const arsUsd = data.rates.USD;
          setRate(arsUsd);
          setUsdToArs(1 / arsUsd);
          setUpdatedAt(new Date(data.date || Date.now()).toLocaleString('en-GB'));
        }
      } catch (err) {
        setError('Live data temporarily unavailable. Showing last verified reference: 1 ARS ≈ 0.0011 USD.');
        setRate(0.0011);
        setUsdToArs(910);
        setUpdatedAt(new Date().toLocaleString('en-GB'));
      }
    };
    fetchRate();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      setFormError('Please complete all required fields.');
      return;
    }
    if (!consentUpdates || !consentPolicy) {
      setFormError('Please accept both consent statements to continue.');
      return;
    }
    setFormError('');
    setStep('pending');
  };

  const handleConfirm = () => {
    navigate('/thank-you');
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className={styles.heroContent}>
          <p className={styles.pill}>Argentina · Data-Driven Learning</p>
          <h1 id="hero-heading">Argentina inflation insights and a personal finance starter course you can trust.</h1>
          <p className={styles.heroText}>
            Análisis transparentes y datos de mercado para decidir con seguridad. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
          <div className={styles.heroNote}>
            <p lang="en">We do not provide financial services. Educational content only.</p>
            <p lang="es">No brindamos servicios financieros. Contenido educativo.</p>
            <p lang="ru">Мы не предоставляем финансовые услуги.</p>
          </div>
        </div>
      </section>

      <section className={styles.promises} aria-labelledby="promises-heading">
        <h2 id="promises-heading">Why Tu Progreso Hoy</h2>
        <div className={styles.promiseGrid}>
          <article className={styles.card}>
            <h3>Datos verificados para planificar tu presupuesto</h3>
            <p>Decisiones responsables, objetivos nítidos. Información confiable que respalda elecciones responsables sobre tu dinero.</p>
          </article>
          <article className={styles.card}>
            <h3>Economic trends with context</h3>
            <p>Conocimiento financiero impulsado por tendencias para entender argentina inflation y movimientos ars usd.</p>
          </article>
          <article className={styles.card}>
            <h3>Practical personal finance</h3>
            <p>De la información al aprendizaje: fortalece tu criterio financiero paso a paso con herramientas sencillas.</p>
          </article>
        </div>
      </section>

      <section className={styles.tracker} aria-labelledby="tracker-heading">
        <div className={styles.trackerInner}>
          <div>
            <h2 id="tracker-heading">Live ARS → USD tracker</h2>
            <p>Stay aligned with market movements to anticipate budgeting Argentina scenarios. Pasos acertados hoy, mejor futuro mañana.</p>
          </div>
          <div className={styles.rateBox} role="status" aria-live="polite">
            <p>1 ARS ➝ {rate ? rate.toFixed(4) : '0.0000'} USD</p>
            <p>1 USD ➝ {usdToArs ? usdToArs.toFixed(2) : '0.00'} ARS</p>
            <p className={styles.timestamp}>Updated: {updatedAt}</p>
            {error && <p className={styles.error}>{error}</p>}
          </div>
        </div>
      </section>

      <section className={styles.insights} aria-labelledby="insights-heading">
        <h2 id="insights-heading">Insights to guide mindful financial choices</h2>
        <div className={styles.insightGrid}>
          {insights.map((item) => (
            <article key={item.title} className={styles.insightCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <span>{item.metric}</span>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.course} aria-labelledby="course-heading">
        <div className={styles.courseContent}>
          <div>
            <h2 id="course-heading">Personal finance starter course</h2>
            <p>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera con módulos claros y aplicables.</p>
            <ul className={styles.courseList}>
              <li>Module 1: Inflation context &amp; argentina inflation drivers.</li>
              <li>Module 2: ARS USD fundamentals and budgeting Argentina scenarios.</li>
              <li>Module 3: Building a resilient spending plan.</li>
              <li>Module 4: Savings goals and responsible decision-making.</li>
            </ul>
            <p className={styles.courseDisclaimer}>
              Мы не предоставляем финансовые услуги · We do not provide financial services · No brindamos servicios financieros.
            </p>
          </div>
          <div className={styles.courseImage} role="presentation" aria-hidden="true" />
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonial-heading">
        <h2 id="testimonial-heading">Learners building confident habits</h2>
        <div className={styles.testimonialGrid}>
          {testimonials.map((item) => (
            <figure key={item.name} className={styles.testimonialCard}>
              <blockquote>{item.quote}</blockquote>
              <figcaption>
                <span>{item.name}</span>
                <span className={styles.role}>{item.role}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.formSection} id="trial-form" aria-labelledby="form-heading">
        <h2 id="form-heading">Получить бесплатный пробный урок</h2>
        <p>Double opt-in keeps your inbox safe. After submitting, confirm to access your session.</p>
        {step === 'form' && (
          <form onSubmit={handleSubmit} className={styles.form}>
            <div className={styles.field}>
              <label htmlFor="name">Name / Nombre</label>
              <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} required />
            </div>
            <div className={styles.field}>
              <label htmlFor="email">Email</label>
              <input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
            </div>
            <div className={styles.field}>
              <label htmlFor="goal">Your learning goal (optional)</label>
              <textarea id="goal" name="goal" value={formData.goal} onChange={handleChange} rows="3" />
            </div>
            <div className={styles.checkboxGroup}>
              <label>
                <input type="checkbox" checked={consentUpdates} onChange={(e) => setConsentUpdates(e.target.checked)} />
                I agree to receive educational updates about economic trends.
              </label>
              <label>
                <input type="checkbox" checked={consentPolicy} onChange={(e) => setConsentPolicy(e.target.checked)} />
                I accept the <a href="/privacy">Privacy Policy</a> and <a href="/terms">Terms</a>.
              </label>
            </div>
            {formError && <p className={styles.error} role="alert">{formError}</p>}
            <button type="submit" className={styles.submit}>Send verification email</button>
          </form>
        )}
        {step === 'pending' && (
          <div className={styles.confirmation}>
            <h3>Step 2: Confirm your request</h3>
            <p>We emailed a verification message to {formData.email}. Click the button below after confirming to access your free trial.</p>
            <button type="button" onClick={handleConfirm} className={styles.submit}>
              I confirm my subscription
            </button>
          </div>
        )}
        <p className={styles.note}>
          Educational disclaimer · Мы не предоставляем финансовые услуги · No brindamos servicios financieros.
        </p>
      </section>
    </div>
  );
};

export default Home;