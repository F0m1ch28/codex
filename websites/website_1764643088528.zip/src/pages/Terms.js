import React from 'react';
import styles from './Terms.module.css';

const Terms = () => (
  <div className={styles.page}>
    <h1>Terms &amp; Conditions</h1>
    <p>Effective date: 15 May 2024</p>

    <section>
      <h2>1. Purpose</h2>
      <p>
        Tu Progreso Hoy is an educational SaaS platform based in Argentina that provides data-informed content on argentina inflation, ars usd references, and finanzas personales. Мы не предоставляем финансовые услуги.
      </p>
    </section>

    <section>
      <h2>2. Eligibility</h2>
      <p>
        By accessing the platform you confirm you are at least 18 years old or have guardian consent. Usage is strictly for educational purposes and does not create advisor-client relationships.
      </p>
    </section>

    <section>
      <h2>3. Subscription</h2>
      <p>
        Access to premium modules requires account registration. Double opt-in verification ensures valid consent. Fees, if applicable, are disclosed in Argentine pesos (ARS) with indicative USD references.
      </p>
    </section>

    <section>
      <h2>4. Content</h2>
      <p>
        All content is provided “as is” and may include third-party sources. Datos verificados para planificar tu presupuesto, sin garantizar resultados financieros.
      </p>
    </section>

    <section>
      <h2>5. Acceptable use</h2>
      <p>
        You agree not to misuse the platform, attempt unauthorized access, or redistribute materials without permission. Respectful conduct is mandatory in community spaces.
      </p>
    </section>

    <section>
      <h2>6. Liability</h2>
      <p>
        Tu Progreso Hoy shall not be liable for losses arising from economic decisions. Users remain responsible for consulting licensed professionals where needed.
      </p>
    </section>

    <section>
      <h2>7. Governing law</h2>
      <p>
        These terms are governed by the laws of Argentina. Disputes will be handled in competent courts in Buenos Aires.
      </p>
    </section>

    <section>
      <h2>8. Contact</h2>
      <p>
        Address: Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina<br />
        Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
      </p>
    </section>
  </div>
);

export default Terms;