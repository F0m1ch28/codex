import React from 'react';
import styles from './Privacy.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <h1>Privacy Policy</h1>
    <p>Effective date: 15 May 2024</p>
    <section>
      <h2>Data controller</h2>
      <p>Tu Progreso Hoy, Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina.</p>
    </section>
    <section>
      <h2>Information we collect</h2>
      <ul>
        <li>Contact details provided via forms.</li>
        <li>Course progress metrics to tailor learning.</li>
        <li>Cookie data for analytics (opt-in only).</li>
      </ul>
    </section>
    <section>
      <h2>Use of information</h2>
      <p>
        We use data to deliver educational content, communicate course updates, and monitor plataforma performance. Обратите внимание: Мы не предоставляем финансовые услуги ni recomendaciones personalizadas.
      </p>
    </section>
    <section>
      <h2>Legal basis</h2>
      <p>Consent (double opt-in), contractual necessity for subscribers, and legitimate interests in improving resources.</p>
    </section>
    <section>
      <h2>Retention</h2>
      <p>We retain records only while you maintain an account or until you request deletion.</p>
    </section>
    <section>
      <h2>Your rights</h2>
      <p>You can access, rectify, or delete your data, withdraw consent, and lodge complaints with the AAIP (Argentina).</p>
    </section>
    <section>
      <h2>International transfers</h2>
      <p>When using cloud services, we implement safeguards aligned with GDPR and Argentine Law 25.326.</p>
    </section>
    <section>
      <h2>Contact</h2>
      <p>Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a></p>
    </section>
  </div>
);

export default Privacy;