import React from 'react';
import styles from './ThankYou.module.css';

const ThankYou = () => (
  <div className={styles.page}>
    <div className={styles.card}>
      <h1>Thank you! / ¡Gracias!</h1>
      <p>
        Your double opt-in was successful. Conocimiento financiero impulsado por tendencias te espera en Tu Progreso Hoy.
      </p>
      <p lang="es">Recibirás en tu correo el acceso al módulo introductorio y a la guía de budgeting Argentina.</p>
      <p className={styles.note}>Мы не предоставляем финансовые услуги · We do not provide financial services.</p>
      <a href="/" className={styles.link}>Return to homepage</a>
    </div>
  </div>
);

export default ThankYou;