import React from 'react';
import styles from './Course.module.css';

const modules = [
  {
    title: 'Module 1 · Inflation literacy',
    summary: 'Understand argentina inflation drivers, IPC composition, and how macro shocks ripple through household budgets.'
  },
  {
    title: 'Module 2 · ARS USD explained',
    summary: 'Explore official and alternative exchange rates, spreads, and practical implications for finanzas personales.'
  },
  {
    title: 'Module 3 · Budgeting Argentina',
    summary: 'Build a resilient spending structure, categorise essentials, and plan savings with datos confiables.'
  },
  {
    title: 'Module 4 · Financial decision-making',
    summary: 'Decisiones responsables, objetivos nítidos. Evaluate scenarios and craft actionable steps.'
  }
];

const audience = [
  'Individuals starting their finanzas personales journey and seeking clarity.',
  'SMB owners needing economic trends context to inform cash flow planning.',
  'Students wanting a structured overview of argentina inflation and currency dynamics.',
  'Teams designing onboarding on budgeting Argentina realities.'
];

const syllabus = [
  'Weekly live sessions (60 minutes) and on-demand video lessons.',
  'Interactive dashboards tracking inflation, salary baskets, and ARS USD ranges.',
  'Downloadable templates for budgeting Argentina households.',
  'Discussion forums moderated by Tu Progreso Hoy analysts.',
  'Assessments to reinforce learning and highlight next steps.'
];

const Course = () => (
  <div className={styles.page}>
    <section className={styles.hero}>
      <h1>Personal finance starter syllabus</h1>
      <p>Conocimiento financiero impulsado por tendencias. No brindamos asesoría directa; ofrecemos recursos educativos para pasos acertados hoy, mejor futuro mañana.</p>
      <a className={styles.cta} href="/#trial-form">Join the free trial lesson</a>
      <p className={styles.disclaimer}>Мы не предоставляем финансовые услуги · Educational purposes only · Sólo fines educativos.</p>
    </section>

    <section className={styles.section} aria-labelledby="syllabus-heading">
      <div className={styles.sectionInner}>
        <h2 id="syllabus-heading">Syllabus overview</h2>
        <ul className={styles.list}>
          {syllabus.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </div>
    </section>

    <section className={styles.sectionAlt} aria-labelledby="modules-heading">
      <div className={styles.sectionInner}>
        <h2 id="modules-heading">Modules in detail</h2>
        <div className={styles.moduleGrid}>
          {modules.map((module) => (
            <article key={module.title} className={styles.moduleCard}>
              <h3>{module.title}</h3>
              <p>{module.summary}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.section} aria-labelledby="audience-heading">
      <div className={styles.sectionInner}>
        <h2 id="audience-heading">Who benefits</h2>
        <ul className={styles.list}>
          {audience.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.sectionInner}>
        <h2>Learning outcomes</h2>
        <p>Información confiable que respalda elecciones responsables sobre tu dinero. Al finalizar, podrás interpretar indicadores clave, desarrollar presupuestos realistas y usar herramientas digitales sin depender de promesas irreales.</p>
        <a className={styles.ctaSecondary} href="/#trial-form">Start with double opt-in access</a>
      </div>
    </section>
  </div>
);

export default Course;