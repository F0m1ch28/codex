import React from 'react';
import styles from './Resources.module.css';

const resources = [
  {
    titleEn: 'How inflation reshapes everyday spending',
    titleEs: 'Cómo la inflación redefine el gasto cotidiano',
    summaryEn: 'Explore shifts in grocery, housing, and transport categories with practical budgeting Argentina tips.',
    summaryEs: 'Explora los cambios en alimentos, vivienda y transporte con consejos prácticos de presupuesto.',
    link: '#'
  },
  {
    titleEn: 'Understanding ARS USD spreads',
    titleEs: 'Comprender la brecha entre las cotizaciones del dólar',
    summaryEn: 'Clarifies why multiple rates exist and how to read market signals without overreacting.',
    summaryEs: 'Aclara por qué existen múltiples tipos de cambio y cómo interpretar las señales de mercado.',
    link: '#'
  },
  {
    titleEn: 'Starter glossary for finanzas personales',
    titleEs: 'Glosario inicial de finanzas personales',
    summaryEn: 'Key concepts explained in plain English to support your learning path.',
    summaryEs: 'Conceptos clave explicados en español para acompañar tu aprendizaje.',
    link: '#'
  }
];

const Resources = () => (
  <div className={styles.page}>
    <section className={styles.hero}>
      <h1>Resources &amp; Glossaries</h1>
      <p lang="en">Curated articles to accompany your course progress.</p>
      <p lang="es">Artículos y glosarios para fortalecer tu progreso.</p>
    </section>

    <section className={styles.resourceSection} aria-labelledby="resource-heading">
      <h2 id="resource-heading">Latest educational highlights</h2>
      <div className={styles.grid}>
        {resources.map((item) => (
          <article key={item.titleEn} className={styles.card}>
            <h3>{item.titleEn}</h3>
            <p>{item.summaryEn}</p>
            <hr />
            <h3 lang="es">{item.titleEs}</h3>
            <p lang="es">{item.summaryEs}</p>
            <a href={item.link} className={styles.link} aria-label={`Read more about ${item.titleEn}`}>
              Coming soon
            </a>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.glossary}>
      <h2>Mini glossary</h2>
      <dl>
        <dt lang="en">Inflation (EN)</dt>
        <dd lang="en">Persistent increase in general prices reducing purchasing power.</dd>
        <dt lang="es">Inflación (ES)</dt>
        <dd lang="es">Aumento persistente de precios que reduce el poder adquisitivo.</dd>
        <dt lang="en">Budgeting Argentina</dt>
        <dd lang="en">Adapting spending to local inflation and ARS USD movements.</dd>
        <dt lang="es">Tipo de cambio oficial vs. paralelo</dt>
        <dd lang="es">Cotizaciones con regulaciones diferentes que impactan decisiones responsables.</dd>
      </dl>
    </section>
  </div>
);

export default Resources;