import React, { useState } from 'react';
import styles from './Contact.module.css';

const Contact = () => {
  const [status, setStatus] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setStatus('Thanks for reaching out. Our team will reply within 48 hours.');
    (e.target).reset();
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>Contact Tu Progreso Hoy</h1>
        <p>Estamos en Buenos Aires, conectando datos confiables con aprendizaje práctico.</p>
      </section>

      <section className={styles.gridSection}>
        <div className={styles.mapWrapper} aria-label="Map of Buenos Aires">
          <iframe
            title="Buenos Aires Map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.141084917094!2d-58.38599282363223!3d-34.60261027295596!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacb2b63d7d5%3A0x8864c8ad5ac2ffb5!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1717083212345"
            loading="lazy"
          />
        </div>
        <div className={styles.info}>
          <h2>Reach us</h2>
          <p>Address: Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <p>Phone: <a href="tel:+541155551234">+54 11 5555-1234</a></p>
          <p>Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a></p>
          <div className={styles.social}>
            <a href="https://www.linkedin.com">LinkedIn</a>
            <a href="https://twitter.com">X</a>
            <a href="https://www.instagram.com">Instagram</a>
          </div>
          <p className={styles.disclaimer}>Мы не предоставляем финансовые услуги · No brindamos servicios financieros · Educational content only.</p>
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Drop us a message</h2>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.field}>
            <label htmlFor="contact-name">Name</label>
            <input id="contact-name" name="name" type="text" required />
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-email">Email</label>
            <input id="contact-email" name="email" type="email" required />
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-message">Message</label>
            <textarea id="contact-message" name="message" rows="4" required />
          </div>
          <button type="submit" className={styles.submit}>Send message</button>
          {status && <p className={styles.status} role="status">{status}</p>}
        </form>
      </section>
    </div>
  );
};

export default Contact;