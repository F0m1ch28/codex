import React, { useMemo } from 'react';
import styles from './Inflation.module.css';

const inflationData = [
  { month: 'Oct 2023', value: 8.3 },
  { month: 'Nov 2023', value: 12.8 },
  { month: 'Dec 2023', value: 25.5 },
  { month: 'Jan 2024', value: 20.6 },
  { month: 'Feb 2024', value: 13.2 },
  { month: 'Mar 2024', value: 11.0 },
  { month: 'Apr 2024', value: 8.8 }
];

const fxData = [
  { label: 'Official USD/ARS', value: 880 },
  { label: 'MEP USD/ARS', value: 1045 },
  { label: 'CCL USD/ARS', value: 1120 }
];

const methodologyPoints = [
  'Combining INDEC CPI releases with trusted private dashboards to capture argentina inflation trends.',
  'Leveraging exchangerate.host and market close data for ars usd references.',
  'Aligning data refresh windows with BCRA announcements and regional economic trends.',
  'Quality checks ensure datos confiables before publishing.'
];

const faq = [
  {
    question: 'Does Tu Progreso Hoy provide financial advice?',
    answer: 'No. Мы не предоставляем финансовые услуги. We interpret publicly available data for educational purposes so you can make informed, responsible decisions.'
  },
  {
    question: 'How often are inflation figures updated?',
    answer: 'Monthly, aligned with INDEC releases. Interim estimates rely on reputable research firms and are labelled accordingly.'
  },
  {
    question: 'Why include multiple ARS USD rates?',
    answer: 'Understanding multiple quotes supports budgeting Argentina decisions and highlights market dispersion.'
  },
  {
    question: 'Can companies use the charts?',
    answer: 'Yes. Our methodology is transparent so teams can integrate insights into internal briefings with attribution.'
  }
];

const Inflation = () => {
  const maxInflation = useMemo(() => Math.max(...inflationData.map((item) => item.value)), []);
  const maxFX = useMemo(() => Math.max(...fxData.map((item) => item.value)), []);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>Inflation &amp; FX Methodology</h1>
        <p>Análisis transparentes y datos de mercado para decidir con seguridad. We convert complex indicators into clear visuals without promising guaranteed outcomes.</p>
        <p className={styles.disclaimer}>Мы не предоставляем финансовые услуги · We do not provide financial services · No brindamos servicios financieros.</p>
      </section>

      <section className={styles.methodology} aria-labelledby="methodology-heading">
        <h2 id="methodology-heading">Methodology at a glance</h2>
        <ul>
          {methodologyPoints.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className={styles.chartSection} aria-labelledby="inflation-chart-heading">
        <div>
          <h2 id="inflation-chart-heading">Monthly CPI evolution (MoM %)</h2>
          <div className={styles.chart} role="img" aria-label="Monthly inflation chart showing deceleration after December 2023 peak">
            {inflationData.map((item) => (
              <div key={item.month} className={styles.barRow}>
                <span>{item.month}</span>
                <div className={styles.barWrapper}>
                  <div
                    className={styles.bar}
                    style={{ width: `${(item.value / maxInflation) * 100}%` }}
                    aria-hidden="true"
                  />
                </div>
                <span className={styles.value}>{item.value}%</span>
              </div>
            ))}
          </div>
          <p className={styles.chartNote}>Source: INDEC &amp; curated economic trends datasets. Datos verificados para planificar tu presupuesto.</p>
        </div>
      </section>

      <section className={styles.chartSection} aria-labelledby="fx-chart-heading">
        <div>
          <h2 id="fx-chart-heading">ARS USD references (closing quotations)</h2>
          <div className={styles.chart} role="img" aria-label="Comparison of USD exchange references in Argentina">
            {fxData.map((item) => (
              <div key={item.label} className={styles.barRow}>
                <span>{item.label}</span>
                <div className={styles.barWrapper}>
                  <div
                    className={`${styles.bar} ${styles.altBar}`}
                    style={{ width: `${(item.value / maxFX) * 100}%` }}
                    aria-hidden="true"
                  />
                </div>
                <span className={styles.value}>ARS {item.value}</span>
              </div>
            ))}
          </div>
          <p className={styles.chartNote}>Valores de referencia educativos. Información confiable que respalda elecciones responsables sobre tu dinero.</p>
        </div>
      </section>

      <section className={styles.context} aria-labelledby="context-heading">
        <h2 id="context-heading">CPI &amp; FX context</h2>
        <p>
          Argentina inflation remains elevated, but sequential CPI prints show moderating monthly variations after the December spike. Energy adjustments and regulated tariffs still impact the basket. On the FX front, the official crawling peg coexists with alternative dollar quotes. Understanding the spread is key for businesses budgeting Argentina cash flows.
        </p>
        <p>
          Our dashboards highlight economic trends without forecasting guaranteed profit scenarios; instead we map sensitivity ranges so teams can take decisiones responsables, objetivos nítidos.
        </p>
      </section>

      <section className={styles.faq} aria-labelledby="faq-heading">
        <h2 id="faq-heading">FAQ</h2>
        <div className={styles.faqGrid}>
          {faq.map((item) => (
            <article key={item.question} className={styles.faqItem}>
              <h3>{item.question}</h3>
              <p>{item.answer}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Inflation;