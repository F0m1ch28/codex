document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('[data-nav-link]');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const currentYearEl = document.getElementById('currentYear');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem('inciteaoqkCookieConsent');
        if (consent === 'accepted') {
            cookieBanner.classList.add('is-hidden');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('inciteaoqkCookieConsent', 'accepted');
            cookieBanner.classList.add('is-hidden');
        });
    }

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }
});