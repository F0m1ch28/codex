document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".mobile-nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const cookieBanner = document.getElementById("cookieBanner");
    const cookieAccept = document.getElementById("cookieAccept");
    const cookieDecline = document.getElementById("cookieDecline");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("active");
        });
    }

    if (cookieBanner && cookieAccept && cookieDecline) {
        const consentStatus = localStorage.getItem("mtslnCookieConsent");
        if (!consentStatus) {
            cookieBanner.classList.add("active");
        }

        cookieAccept.addEventListener("click", () => {
            localStorage.setItem("mtslnCookieConsent", "accepted");
            cookieBanner.classList.remove("active");
        });

        cookieDecline.addEventListener("click", () => {
            localStorage.setItem("mtslnCookieConsent", "declined");
            cookieBanner.classList.remove("active");
        });
    }

    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            const emailField = contactForm.querySelector('input[type="email"]');
            const nameField = contactForm.querySelector('input[name="name"]');
            const messageField = contactForm.querySelector("textarea");
            let valid = true;

            [emailField, nameField, messageField].forEach((field) => {
                field.classList.remove("error");
                if (!field.value.trim()) {
                    field.classList.add("error");
                    valid = false;
                }
            });

            if (emailField && emailField.value) {
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailField.value.trim())) {
                    emailField.classList.add("error");
                    valid = false;
                }
            }

            if (!valid) {
                event.preventDefault();
                alert("Please complete all required fields with valid information before submitting.");
            }
        });
    }
});