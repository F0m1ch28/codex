import React from 'react';
import Meta from '../components/Meta';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Meta
        title="Cookie Policy | IT Learning Hub Belgium"
        description="Understand how IT Learning Hub Belgium uses cookies to improve your browsing experience and manage your preferences."
        keywords="cookie policy, cookie preferences, IT Learning Hub Belgium"
      />
      <section className={`${styles.legal} section`}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>Last updated: January 2024</p>
          <article>
            <h2>1. What are cookies?</h2>
            <p>
              Cookies are small text files stored on your device to enhance website functionality, remember preferences, and help us understand how visitors engage with our content.
            </p>
          </article>
          <article>
            <h2>2. Types of cookies we use</h2>
            <ul>
              <li><strong>Essential cookies:</strong> Required for core functionality such as navigation and secure access.</li>
              <li><strong>Performance cookies:</strong> Help us measure engagement and improve site experience.</li>
              <li><strong>Functional cookies:</strong> Remember preferences to personalise your visit.</li>
              <li><strong>Analytics cookies:</strong> Provide insights into programme interest and content performance.</li>
            </ul>
          </article>
          <article>
            <h2>3. Managing cookies</h2>
            <p>
              You can accept or decline cookies via our cookie banner or adjust settings in your browser. Disabling certain cookies may impact website functionality.
            </p>
          </article>
          <article>
            <h2>4. Updates to this policy</h2>
            <p>
              We may revise this policy to reflect regulatory changes or enhancements to our services. Any updates will be posted on this page.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;