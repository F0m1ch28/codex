import React from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import blogPosts from '../data/blogPosts';
import styles from './Blog.module.css';

const Blog = () => {
  return (
    <>
      <Meta
        title="IT Learning Hub Belgium Blog | Tech Insights & Careers"
        description="Read the latest articles on IT careers, cybersecurity, data analytics, cloud engineering, and community stories from IT Learning Hub Belgium."
        keywords="IT blog Belgium, cybersecurity advice, data analytics tips, tech career blog"
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <h1>Insights from the IT Learning Hub Belgium community</h1>
          <p>
            Discover strategies, success stories, and practical tips on navigating the evolving world of technology in Belgium.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.postGrid}>
            {blogPosts.map((post) => (
              <article key={post.slug}>
                <img src={post.image} alt={`${post.title} cover image`} />
                <div className={styles.postBody}>
                  <span>{post.date} · {post.readingTime}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`}>Read more →</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;