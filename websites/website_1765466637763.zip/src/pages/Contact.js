import React, { useState } from 'react';
import Meta from '../components/Meta';
import styles from './Contact.module.css';

const initialForm = {
  name: '',
  email: '',
  topic: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialForm);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setSubmitted(false);
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormData(initialForm);
  };

  return (
    <>
      <Meta
        title="Contact IT Learning Hub Belgium | Brussels Campus"
        description="Reach out to IT Learning Hub Belgium to discuss courses, partnerships, or community events. Visit us at Avenue de la Toison d'Or 56, 1060 Brussels."
        keywords="contact IT Learning Hub Belgium, Brussels tech education, IT training contact"
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <h1>Let&apos;s design your next step</h1>
          <p>
            Whether you&apos;re planning a career transition, upskilling your team, or hosting a community event, we are here to collaborate.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.layout}>
            <form className={styles.form} onSubmit={handleSubmit}>
              <h2>Send us a message</h2>
              <label htmlFor="contact-name">Name</label>
              <input
                id="contact-name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
              />

              <label htmlFor="contact-email">Email</label>
              <input
                id="contact-email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />

              <label htmlFor="contact-topic">Topic</label>
              <select
                id="contact-topic"
                name="topic"
                value={formData.topic}
                onChange={handleChange}
                required
              >
                <option value="">Select a topic</option>
                <option value="Admissions">Admissions</option>
                <option value="Corporate Training">Corporate Training</option>
                <option value="Partnerships">Partnerships</option>
                <option value="Events">Events</option>
              </select>

              <label htmlFor="contact-message">Message</label>
              <textarea
                id="contact-message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                required
              />

              <button type="submit" className="btn btn-primary">
                Submit message
              </button>

              {submitted && <div className={styles.success}>Thank you! We&apos;ll get back to you shortly.</div>}
            </form>

            <aside className={styles.details}>
              <div>
                <h3>Visit us</h3>
                <p>IT Learning Hub, Avenue de la Toison d&apos;Or 56, 1060 Brussels, Belgium</p>
              </div>
              <div>
                <h3>Contact</h3>
                <p>Phone: <a href="tel:+3221234567">+32 2 123 45 67</a></p>
                <p>Email: <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a></p>
              </div>
              <div>
                <h3>Hours</h3>
                <p>Monday to Friday · 09:00 – 18:00 CET</p>
                <p>Hybrid appointments available on request.</p>
              </div>
              <div className={styles.map}>
                <img src="https://maps.googleapis.com/maps/api/staticmap?center=Brussels,Belgium&zoom=13&size=600x400&maptype=roadmap&markers=color:blue%7C50.8354,4.3560&key=AIzaSyD-Placeholder" alt="Map of Brussels showing IT Learning Hub location" />
                <span>Directions: Avenue de la Toison d&apos;Or 56, 1060 Brussels</span>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;