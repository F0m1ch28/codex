import React from 'react';
import { Link, useParams } from 'react-router-dom';
import Meta from '../components/Meta';
import blogPosts from '../data/blogPosts';
import styles from './BlogArticle.module.css';

const BlogArticle = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className="section">
        <div className="container">
          <h1>Article not found</h1>
          <p>The article you tried to view is not available.</p>
          <Link to="/blog" className="btn btn-primary">Back to blog</Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Meta
        title={`${post.title} | IT Learning Hub Belgium`}
        description={post.excerpt}
        keywords={`${post.tags?.join(', ')}, IT Learning Hub Belgium blog`}
      />
      <article className={`${styles.article} section`}>
        <div className="container">
          <Link to="/blog" className={styles.backLink}>← Back to blog</Link>
          <header className={styles.header}>
            <h1>{post.title}</h1>
            <div className={styles.meta}>
              <span>By {post.author}</span>
              <span>{post.date}</span>
              <span>{post.readingTime}</span>
            </div>
            <div className={styles.tagList}>
              {post.tags?.map((tag) => (
                <span key={tag}>{tag}</span>
              ))}
            </div>
          </header>
          <img src={post.image} alt={`${post.title} featured`} className={styles.heroImage} />
          <div className={styles.content}>
            {post.sections?.map((section) => (
              <section key={section.heading}>
                <h2>{section.heading}</h2>
                <p>{section.content}</p>
              </section>
            ))}
            {post.conclusion && (
              <section>
                <h2>Conclusion</h2>
                <p>{post.conclusion}</p>
              </section>
            )}
          </div>
        </div>
      </article>
    </>
  );
};

export default BlogArticle;