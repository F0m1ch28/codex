import React from 'react';
import Meta from '../components/Meta';
import styles from './Legal.module.css';

const Terms = () => {
  return (
    <>
      <Meta
        title="Terms of Service | IT Learning Hub Belgium"
        description="Read the terms of service for IT Learning Hub Belgium covering course participation, intellectual property, and user responsibilities."
        keywords="terms of service, IT Learning Hub Belgium"
      />
      <section className={`${styles.legal} section`}>
        <div className="container">
          <h1>Terms of Service</h1>
          <p>Last updated: January 2024</p>
          <article>
            <h2>1. Overview</h2>
            <p>
              IT Learning Hub Belgium provides technology education services. By accessing our website or participating in any programme, you agree to comply with these Terms of Service.
            </p>
          </article>
          <article>
            <h2>2. Programme participation</h2>
            <p>
              Learners are expected to maintain respectful conduct, engage in collaborative activities, and uphold confidentiality regarding partner projects and proprietary content.
            </p>
          </article>
          <article>
            <h2>3. Intellectual property</h2>
            <p>
              All course materials, documentation, and resources are protected by intellectual property laws. Learners may use materials for personal development but are prohibited from distributing them without written consent.
            </p>
          </article>
          <article>
            <h2>4. Code of conduct</h2>
            <p>
              We foster an inclusive, harassment-free environment. Any discriminatory behaviour or violation of our community guidelines may result in dismissal from programmes.
            </p>
          </article>
          <article>
            <h2>5. Limitation of liability</h2>
            <p>
              IT Learning Hub Belgium is not liable for indirect or consequential damages arising from the use of our services. Programme outcomes depend on individual effort and market conditions.
            </p>
          </article>
          <article>
            <h2>6. Contact</h2>
            <p>
              Questions about these terms may be directed to info@itlearninghub.be or our registered address: IT Learning Hub, Avenue de la Toison d&apos;Or 56, 1060 Brussels, Belgium.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Terms;