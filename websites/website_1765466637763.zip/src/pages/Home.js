import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import courses from '../data/courses';
import blogPosts from '../data/blogPosts';
import styles from './Home.module.css';

const stats = [
  { label: 'Learners Empowered', value: 2800 },
  { label: 'Industry Mentors', value: 120 },
  { label: 'Hiring Partners', value: 95 },
  { label: 'Workshops per Year', value: 160 }
];

const testimonials = [
  {
    quote: 'The mentorship and Brussels community events accelerated my transition from finance to data analytics within months.',
    name: 'Charlotte De Vos',
    role: 'Data Analyst at GreenPulse',
    image: 'https://picsum.photos/200/200?random=41'
  },
  {
    quote: 'Hands-on labs, cyber ranges, and the supportive alumni network prepared me for my current cybersecurity role.',
    name: 'Olivier Van Damme',
    role: 'Security Operations Analyst at ProShield',
    image: 'https://picsum.photos/200/200?random=42'
  },
  {
    quote: 'I loved the collaborative studio. Working with Belgian startups on real devops challenges was a game changer.',
    name: 'Sara Rahmani',
    role: 'Cloud Engineer at BlueOrbit',
    image: 'https://picsum.photos/200/200?random=43'
  }
];

const faqItems = [
  {
    question: 'Who can apply for IT Learning Hub Belgium programmes?',
    answer:
      'We welcome aspiring technologists, career switchers, and professionals seeking to upskill. Each cohort brings together diverse backgrounds to promote peer learning and collaborative innovation.'
  },
  {
    question: 'Do you provide career support after graduation?',
    answer:
      'Yes. Our Career Studio delivers personalised coaching, CV refinement, interview preparation, and introductions to our network of Belgian employers across finance, mobility, and public sectors.'
  },
  {
    question: 'How are courses delivered?',
    answer:
      'We blend live virtual sessions, on-campus immersions in Brussels, and project-driven sprints. This hybrid approach offers flexibility while ensuring immersive collaboration with mentors and peers.'
  }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(stats.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const animationDuration = 1400;
    const start = performance.now();

    const animate = (timestamp) => {
      const progress = Math.min((timestamp - start) / animationDuration, 1);
      setAnimatedStats(
        stats.map((stat, index) => Math.floor(stat.value * progress))
      );
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const featuredCourses = useMemo(() => courses.slice(0, 3), []);

  const latestPosts = useMemo(() => blogPosts.slice(0, 3), []);

  return (
    <>
      <Meta
        title="IT Learning Hub Belgium | Launch Your IT Career"
        description="IT Learning Hub Belgium provides immersive IT education in Brussels. Build skills in web development, data analytics, cybersecurity, and cloud-native engineering."
        keywords="IT courses Belgium, coding bootcamp Brussels, data analytics training, cybersecurity education, cloud engineering Belgium"
      />
      <section className={styles.hero} id="main-content">
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <span className={styles.heroBadge}>Future-ready tech education</span>
              <h1>Launch Your IT Career in Belgium</h1>
              <p>
                Join a community of curious minds reinventing Belgium&apos;s digital landscape. From foundational web skills to advanced cloud engineering, our mentors, labs, and career experts power every step.
              </p>
              <div className={styles.heroActions}>
                <Link to="/courses" className="btn btn-primary">
                  Explore Programmes
                </Link>
                <Link to="/contact" className={`${styles.heroSecondary} btn btn-secondary`}>
                  Talk to an Advisor
                </Link>
              </div>
              <div className={styles.heroHighlights}>
                <div>
                  <strong>Hybrid campus in Brussels</strong>
                  <span>Immersive studios and virtual collaboration</span>
                </div>
                <div>
                  <strong>Mentors from Belgian scale-ups</strong>
                  <span>Guidance tailored to local tech needs</span>
                </div>
              </div>
            </div>
            <div className={styles.heroVisual} role="presentation">
              <img src="https://picsum.photos/1600/900?random=1" alt="Learners collaborating in a modern tech classroom" />
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((stat, index) => (
              <div className={styles.statCard} key={stat.label}>
                <span className={styles.statValue}>{animatedStats[index]}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Why learners choose IT Learning Hub Belgium</h2>
            <p className="section-subtitle">
              Our programmes are designed around the demands of Belgian employers, combining humanised mentorship, industry projects, and community-driven learning.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <article className={styles.whyCard}>
              <h3>Industry-crafted curriculum</h3>
              <p>We work alongside CTOs, CISOs, and data leaders to ensure every module matches the needs of Belgian tech teams.</p>
            </article>
            <article className={styles.whyCard}>
              <h3>Project-rich experience</h3>
              <p>Practical sprints mirror real-world challenges from Brussels startups and Leuven research labs.</p>
            </article>
            <article className={styles.whyCard}>
              <h3>Career studio support</h3>
              <p>Career strategists coach you through interviews, networking, and personal branding tailored to local opportunities.</p>
            </article>
            <article className={styles.whyCard}>
              <h3>Inclusive community</h3>
              <p>We cultivate a culture where every learner feels empowered, supported, and connected to a global alumni network.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.featuredCourses} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Featured learning journeys</h2>
            <p className="section-subtitle">Discover pathways that shape versatile IT professionals ready for Belgium&apos;s tech roles.</p>
          </div>
          <div className={styles.courseGrid}>
            {featuredCourses.map((course) => (
              <article key={course.id} className={styles.courseCard}>
                <img src={course.image} alt={`${course.title} class project preview`} />
                <div className={styles.courseContent}>
                  <div className={styles.courseMeta}>
                    <span>{course.category}</span>
                    <span>{course.level}</span>
                  </div>
                  <h3>{course.title}</h3>
                  <p>{course.summary}</p>
                  <ul className={styles.skillList}>
                    {course.skills.slice(0, 4).map((skill) => (
                      <li key={skill}>{skill}</li>
                    ))}
                  </ul>
                  <Link to={`/courses/${course.slug}`} className={styles.courseLink}>
                    View course details →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.sectionAction}>
            <Link to="/courses" className="btn btn-primary">
              Browse all courses
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.successStories} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Success stories from our alumni</h2>
            <p className="section-subtitle">From career changers to upskilling professionals, our alumni are shaping Belgium&apos;s digital future.</p>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
                aria-hidden={index !== activeTestimonial}
              >
                <div className={styles.testimonialQuote}>
                  <p>“{testimonial.quote}”</p>
                </div>
                <div className={styles.testimonialAuthor}>
                  <img src={testimonial.image} alt={`${testimonial.name} portrait`} />
                  <div>
                    <strong>{testimonial.name}</strong>
                    <span>{testimonial.role}</span>
                  </div>
                </div>
              </article>
            ))}
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTestimonial(index)}
                  className={index === activeTestimonial ? styles.activeDot : ''}
                  aria-label={`Show testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.methodPreview} section`}>
        <div className="container">
          <div className={styles.methodGrid}>
            <div>
              <h2 className="section-title">Our learning method in action</h2>
              <p className="section-subtitle">
                Every programme blends live expert sessions, collaborative labs, and personalised coaching to turn potential into career momentum.
              </p>
              <ul className={styles.methodList}>
                <li>
                  <strong>Launch:</strong> Diagnostic onboarding to map your strengths and growth areas.
                </li>
                <li>
                  <strong>Immerse:</strong> Weekly studio sessions, pair-programming, and design sprints guided by practitioners.
                </li>
                <li>
                  <strong>Build:</strong> Real-world product challenges sourced from Belgian organisations.
                </li>
                <li>
                  <strong>Elevate:</strong> Career Studio roadmap, portfolio reviews, and employer showcases.
                </li>
              </ul>
              <Link to="/method" className="btn btn-secondary">
                Explore the full method
              </Link>
            </div>
            <div className={styles.methodVisual}>
              <img src="https://picsum.photos/1000/800?random=44" alt="Workshop session at IT Learning Hub Belgium" />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.careerPaths} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Belgian IT career paths to watch</h2>
            <p className="section-subtitle">Stay ahead with an overview of high-growth roles our learners are stepping into.</p>
          </div>
          <div className={styles.careerGrid}>
            <article>
              <h3>Cybersecurity Analyst</h3>
              <p>Safeguard enterprises with proactive monitoring, incident response, and compliance knowledge.</p>
              <span>Key sectors: Finance, public services, critical infrastructure</span>
            </article>
            <article>
              <h3>Data Product Owner</h3>
              <p>Bridge business goals and analytics teams by translating insights into strategic initiatives.</p>
              <span>Key sectors: Mobility, healthcare, smart cities</span>
            </article>
            <article>
              <h3>Cloud Solutions Engineer</h3>
              <p>Design resilient platforms leveraging DevOps practices, automation, and observability.</p>
              <span>Key sectors: SaaS scale-ups, logistics, media</span>
            </article>
            <article>
              <h3>Full-Stack Developer</h3>
              <p>Create seamless experiences across front-end and back-end, focusing on accessibility and performance.</p>
              <span>Key sectors: E-commerce, fintech, digital agencies</span>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.processSection} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Your journey with us</h2>
            <p className="section-subtitle">From first conversation to career launch, we walk beside you.</p>
          </div>
          <div className={styles.processSteps}>
            <div>
              <span>01</span>
              <h4>Discover</h4>
              <p>Meet with an advisor for a personalised learning assessment and programme alignment.</p>
            </div>
            <div>
              <span>02</span>
              <h4>Engage</h4>
              <p>Join collaborative cohorts, attend live expert sessions, and access digital learning labs.</p>
            </div>
            <div>
              <span>03</span>
              <h4>Build</h4>
              <p>Ship portfolio-ready projects backed by real scenarios from Belgian partners.</p>
            </div>
            <div>
              <span>04</span>
              <h4>Thrive</h4>
              <p>Activate your career plan with mentorship, hiring events, and alumni connections.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.blogSection} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Latest insights from our blog</h2>
            <p className="section-subtitle">Stay informed on emerging technologies, career advice, and community stories.</p>
          </div>
          <div className={styles.blogGrid}>
            {latestPosts.map((post) => (
              <article key={post.slug} className={styles.blogCard}>
                <img src={post.image} alt={`${post.title} feature photo`} />
                <div className={styles.blogContent}>
                  <span className={styles.blogMeta}>{post.date} · {post.readingTime}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                    Read article →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.sectionAction}>
            <Link to="/blog" className="btn btn-primary">
              Visit the blog
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.faqSection} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Frequently asked questions</h2>
            <p className="section-subtitle">Answers to common questions about admissions, learning design, and support.</p>
          </div>
          <div className={styles.faqItems}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  onClick={() => setExpandedFaq(index === expandedFaq ? null : index)}
                  aria-expanded={index === expandedFaq}
                >
                  <span>{item.question}</span>
                  <span>{index === expandedFaq ? '−' : '+'}</span>
                </button>
                {index === expandedFaq && <p>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.contactCta} section`}>
        <div className="container">
          <div className={styles.contactCard}>
            <div>
              <h2>Ready to map your next chapter in IT?</h2>
              <p>Let&apos;s build a personalised learning plan aligned with your ambitions and Belgium&apos;s tech landscape.</p>
            </div>
            <Link to="/contact" className="btn btn-secondary">
              Connect with us
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;