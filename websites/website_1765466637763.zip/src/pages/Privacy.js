import React from 'react';
import Meta from '../components/Meta';
import styles from './Legal.module.css';

const Privacy = () => {
  return (
    <>
      <Meta
        title="Privacy Policy | IT Learning Hub Belgium"
        description="Learn how IT Learning Hub Belgium collects, uses, and protects your personal data in compliance with GDPR."
        keywords="privacy policy, GDPR Belgium, IT Learning Hub Belgium"
      />
      <section className={`${styles.legal} section`}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Last updated: January 2024</p>
          <article>
            <h2>1. Data controller</h2>
            <p>
              IT Learning Hub Belgium acts as the data controller for personal data collected through our services and communications. We comply with the EU General Data Protection Regulation (GDPR).
            </p>
          </article>
          <article>
            <h2>2. Information we collect</h2>
            <p>
              We gather information you provide voluntarily (such as name, contact details, professional background) and information collected automatically (such as device data and website usage metrics).
            </p>
          </article>
          <article>
            <h2>3. Use of information</h2>
            <p>
              Data is used to deliver programmes, personalise learning experiences, communicate updates, and evaluate service quality. We rely on consent, legitimate interest, and contractual obligations as legal bases.
            </p>
          </article>
          <article>
            <h2>4. Data sharing</h2>
            <p>
              We may share data with trusted partners who support training delivery, career services, or analytics. All partners adhere to GDPR-compliant data processing agreements.
            </p>
          </article>
          <article>
            <h2>5. Data subject rights</h2>
            <p>
              You have the right to access, rectify, erase, or restrict processing of your data. Requests can be made via info@itlearninghub.be. We aim to respond within 30 days.
            </p>
          </article>
          <article>
            <h2>6. Data retention &amp; security</h2>
            <p>
              We retain personal data for as long as needed to deliver services and comply with legal obligations. Security measures include encryption, access controls, and regular audits.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Privacy;