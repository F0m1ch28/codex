import React from 'react';
import Meta from '../components/Meta';
import styles from './About.module.css';

const leadership = [
  {
    name: 'Elise Martens',
    role: 'Executive Director',
    bio: 'Former digital transformation lead at a Brussels fintech, Elise champions inclusive tech education across Belgium.',
    image: 'https://picsum.photos/400/400?random=51'
  },
  {
    name: 'Jonas Peeters',
    role: 'Head of Learning Experience',
    bio: 'Jonas designs immersive curricula blending human-centered design with evidence-based pedagogy.',
    image: 'https://picsum.photos/400/400?random=52'
  },
  {
    name: 'Anouk Verbeeck',
    role: 'Talent & Partnerships Lead',
    bio: 'Anouk cultivates relationships with employers, ensuring learners step into meaningful roles.',
    image: 'https://picsum.photos/400/400?random=53'
  }
];

const About = () => {
  return (
    <>
      <Meta
        title="About IT Learning Hub Belgium | Mission & Team"
        description="Meet the mission-driven team accelerating IT talent in Belgium. Discover our story, values, and commitment to hands-on, inclusive tech education."
        keywords="IT Learning Hub Belgium mission, tech education Brussels, coding community Belgium"
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <span className={styles.kicker}>About Us</span>
          <h1>We empower people to drive Belgium&apos;s digital evolution</h1>
          <p>
            IT Learning Hub Belgium was founded on the belief that meaningful tech education is human-centered, collaborative, and closely tied to industry realities. From Brussels to Ghent, we guide learners to transform ambition into impact.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.missionGrid}>
            <article>
              <h2>Our mission</h2>
              <p>
                To create accessible pathways into IT careers by combining expert mentorship, real-world projects, and personalised career support rooted in Belgium&apos;s diverse tech ecosystem.
              </p>
            </article>
            <article>
              <h2>Our vision</h2>
              <p>
                A future where Belgium leads Europe in tech innovation through inclusive talent development, cross-disciplinary collaboration, and continuous learning cultures inside every organisation.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.values} section`}>
        <div className="container">
          <h2 className="section-title">Values that guide our work</h2>
          <div className={styles.valuesGrid}>
            <div>
              <h3>Human-first innovation</h3>
              <p>We design programmes that honour each learner&apos;s story, strengths, and aspirations.</p>
            </div>
            <div>
              <h3>Learning by doing</h3>
              <p>We believe insight is forged through action, iteration, and reflective practice.</p>
            </div>
            <div>
              <h3>Community care</h3>
              <p>We nurture spaces where collaboration thrives and wellbeing is prioritised.</p>
            </div>
            <div>
              <h3>Impact in Belgium</h3>
              <p>We align efforts with local industry needs to support sustainable growth.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.timelineSection} section`}>
        <div className="container">
          <h2 className="section-title">Our story</h2>
          <div className={styles.timeline}>
            <div>
              <span>2018</span>
              <p>Launched the first cohort of 20 learners focused on web development fundamentals.</p>
            </div>
            <div>
              <span>2019</span>
              <p>Expanded into data analytics with industry partners in Brussels and Antwerp.</p>
            </div>
            <div>
              <span>2021</span>
              <p>Opened the hybrid campus at Avenue de la Toison d&apos;Or 56, blending studios and remote labs.</p>
            </div>
            <div>
              <span>2023</span>
              <p>Introduced cybersecurity and cloud-native pathways to answer Belgium&apos;s talent needs.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.leadership} section`}>
        <div className="container">
          <h2 className="section-title">Leadership team</h2>
          <p className="section-subtitle">Experienced practitioners shaping strategic, learner-centered programmes.</p>
          <div className={styles.leadershipGrid}>
            {leadership.map((leader) => (
              <article key={leader.name}>
                <img src={leader.image} alt={`${leader.name}, ${leader.role}`} />
                <h3>{leader.name}</h3>
                <span>{leader.role}</span>
                <p>{leader.bio}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.community} section`}>
        <div className="container">
          <div className={styles.communityGrid}>
            <div>
              <h2 className="section-title">A community of mentors, alumni, and partners</h2>
              <p className="section-subtitle">
                With mentors drawn from Belgian scale-ups, public institutions, and international tech organisations, our learners access diverse perspectives and real-world challenges.
              </p>
            </div>
            <div className={styles.communityVisual}>
              <img src="https://picsum.photos/1000/700?random=54" alt="IT Learning Hub Belgium community event" />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;