import React from 'react';
import Meta from '../components/Meta';
import styles from './Method.module.css';

const phases = [
  {
    title: 'Diagnostic Onboarding',
    description:
      'Personalised assessments identify your strengths, learning preferences, and goals to tailor your roadmap.',
    image: 'https://picsum.photos/800/600?random=61'
  },
  {
    title: 'Immersive Learning Sprints',
    description:
      'Weekly sprints combine live expert sessions, collaborative labs, and peer mentorship to deepen mastery.',
    image: 'https://picsum.photos/800/600?random=62'
  },
  {
    title: 'Industry Studio Projects',
    description:
      'Solve real challenges provided by Belgian partners, presenting solutions to stakeholders for actionable feedback.',
    image: 'https://picsum.photos/800/600?random=63'
  },
  {
    title: 'Career Studio',
    description:
      'Refine portfolios, storytelling, and interviewing with career strategists focused on Belgium\'s tech landscape.',
    image: 'https://picsum.photos/800/600?random=64'
  }
];

const Method = () => {
  return (
    <>
      <Meta
        title="Learning Method | IT Learning Hub Belgium"
        description="Discover the IT Learning Hub Belgium method: diagnostic onboarding, immersive sprints, industry studio projects, and dedicated career support."
        keywords="learning method, IT education Belgium, project-based learning, IT career coaching"
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <h1>A learning approach engineered for momentum</h1>
          <p>
            Our method blends human connection with cutting-edge practice. Every step is designed to build confidence,
            drive tangible outcomes, and connect you to Belgium&apos;s tech ecosystem.
          </p>
        </div>
      </section>

      <section className={`${styles.phases} section`}>
        <div className="container">
          <div className={styles.phaseGrid}>
            {phases.map((phase) => (
              <article key={phase.title}>
                <img src={phase.image} alt={`${phase.title} illustration`} />
                <div>
                  <h2>{phase.title}</h2>
                  <p>{phase.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.pillars} section`}>
        <div className="container">
          <h2 className="section-title">Core pillars of our pedagogy</h2>
          <div className={styles.pillarGrid}>
            <div>
              <h3>Applied learning</h3>
              <p>Every concept is reinforced through projects, labs, and demos that simulate real workplace scenarios.</p>
            </div>
            <div>
              <h3>Collaborative intelligence</h3>
              <p>We nurture cross-functional teamwork, communication skills, and inclusive collaboration practices.</p>
            </div>
            <div>
              <h3>Continuous feedback</h3>
              <p>Mentors, peers, and industry partners provide iterative feedback loops that accelerate growth.</p>
            </div>
            <div>
              <h3>Career integration</h3>
              <p>Career coaching is embedded throughout your journey, aligning skills with employer expectations.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.experience} section`}>
        <div className="container">
          <div className={styles.experienceGrid}>
            <div>
              <h2>Experience days &amp; hackathons</h2>
              <p>
                Each quarter we host experience days and hackathons with Belgian partners. You collaborate with cross-disciplinary teams to tackle pressing industry challenges, present to stakeholders, and expand your professional network.
              </p>
            </div>
            <div className={styles.experienceVisual}>
              <img src="https://picsum.photos/900/700?random=65" alt="Hackathon event at IT Learning Hub Belgium" />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Method;