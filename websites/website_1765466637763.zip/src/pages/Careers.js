import React from 'react';
import Meta from '../components/Meta';
import styles from './Careers.module.css';

const careerTracks = [
  {
    title: 'Cybersecurity Analyst',
    description: 'Monitor, detect, and mitigate security threats across complex infrastructures.',
    skills: ['SIEM tools', 'Threat intelligence', 'Incident response', 'Risk assessment'],
    image: 'https://picsum.photos/800/600?random=71'
  },
  {
    title: 'Full-Stack Developer',
    description: 'Design, develop, and deploy user-centric applications from concept to production.',
    skills: ['React', 'Node.js', 'REST APIs', 'Design systems'],
    image: 'https://picsum.photos/800/600?random=72'
  },
  {
    title: 'Data Product Owner',
    description: 'Translate analytics insights into strategic decisions and measurable outcomes.',
    skills: ['Product discovery', 'Data storytelling', 'Stakeholder management', 'SQL'],
    image: 'https://picsum.photos/800/600?random=73'
  },
  {
    title: 'Cloud Engineer',
    description: 'Build resilient cloud solutions leveraging automation, containerization, and monitoring.',
    skills: ['Kubernetes', 'Terraform', 'CI/CD', 'Observability'],
    image: 'https://picsum.photos/800/600?random=74'
  }
];

const Careers = () => {
  return (
    <>
      <Meta
        title="IT Careers in Belgium | Paths & Opportunities"
        description="Explore high-growth IT careers in Belgium. Understand roles, skills, and pathways to become a cybersecurity analyst, full-stack developer, cloud engineer, and more."
        keywords="IT careers Belgium, tech jobs Brussels, cybersecurity jobs Belgium, cloud engineer Belgium"
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <h1>IT career pathways in Belgium</h1>
          <p>
            Belgium&apos;s tech ecosystem is vibrant and expanding. Explore the roles our learners pursue and the skills that set them apart in a competitive landscape.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.careerGrid}>
            {careerTracks.map((track) => (
              <article key={track.title}>
                <img src={track.image} alt={`${track.title} role illustration`} />
                <div className={styles.cardBody}>
                  <h2>{track.title}</h2>
                  <p>{track.description}</p>
                  <h4>Core skills</h4>
                  <ul>
                    {track.skills.map((skill) => (
                      <li key={skill}>{skill}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.resources} section`}>
        <div className="container">
          <div className={styles.resourceGrid}>
            <div>
              <h2>Career Studio services</h2>
              <ul>
                <li>Personalised coaching aligned with Belgian employer expectations</li>
                <li>Technical interview prep and mock assessments</li>
                <li>Portfolio storytelling and pitch refinement</li>
                <li>Exclusive hiring events with partner organisations</li>
              </ul>
            </div>
            <div>
              <h2>Belgian tech landscape insights</h2>
              <p>
                From Brussels&apos; fintech corridor to Ghent&apos;s healthtech scene, opportunities are thriving. We regularly publish market insights,
                salary benchmarks (upon request), and skill demand reports to keep our community ahead of trends.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Careers;