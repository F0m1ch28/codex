import React from 'react';
import { Link, useParams } from 'react-router-dom';
import Meta from '../components/Meta';
import courses from '../data/courses';
import styles from './CourseDetails.module.css';

const CourseDetails = () => {
  const { courseSlug } = useParams();
  const course = courses.find((item) => item.slug === courseSlug);

  if (!course) {
    return (
      <section className="section">
        <div className="container">
          <h1>Course not found</h1>
          <p>The course you are looking for is no longer available.</p>
          <Link to="/courses" className="btn btn-primary">
            Back to courses
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Meta
        title={`${course.title} | IT Learning Hub Belgium`}
        description={course.summary}
        keywords={`${course.title}, ${course.category}, IT Learning Hub Belgium course`}
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <Link to="/courses" className={styles.backLink}>← Back to courses</Link>
          <h1>{course.title}</h1>
          <p>{course.summary}</p>
          <div className={styles.meta}>
            <span>{course.category}</span>
            <span>{course.duration}</span>
            <span>{course.level}</span>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.mainContent}>
              <img src={course.image} alt={`${course.title} learning session`} />
              <section>
                <h2>What you will accomplish</h2>
                <ul>
                  {course.learningOutcomes.map((outcome) => (
                    <li key={outcome}>{outcome}</li>
                  ))}
                </ul>
              </section>
              <section>
                <h2>Skills you will master</h2>
                <div className={styles.skillChips}>
                  {course.skills.map((skill) => (
                    <span key={skill}>{skill}</span>
                  ))}
                </div>
              </section>
            </div>
            <aside className={styles.sidebar}>
              <div className={styles.sidebarCard}>
                <h3>Programme highlights</h3>
                <ul>
                  {course.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
              </div>
              <div className={styles.sidebarCard}>
                <h3>Prerequisites</h3>
                <ul>
                  {course.prerequisites.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
              <div className={styles.sidebarAction}>
                <Link to="/contact" className="btn btn-secondary">
                  Enquire about this course
                </Link>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default CourseDetails;