import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import courses from '../data/courses';
import styles from './Services.module.css';

const categories = ['All', 'Software Engineering', 'Data & AI', 'Security', 'Cloud & DevOps'];

const Courses = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const filteredCourses = useMemo(() => {
    if (activeCategory === 'All') return courses;
    return courses.filter((course) => course.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Meta
        title="IT Courses in Belgium | Web, Data, Cybersecurity & Cloud"
        description="Discover IT Learning Hub Belgium courses across software engineering, data analytics, cybersecurity, and cloud-native engineering. Hands-on, mentor-guided, and industry-aligned."
        keywords="IT courses Belgium, cybersecurity training Brussels, data analytics course Belgium, cloud engineering programme"
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <h1>Our courses</h1>
          <p>
            Explore immersive programmes designed with Belgian industry partners. From code to cloud, each pathway blends live expert sessions, project-based learning, and personalised coaching.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.filters}>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={activeCategory === category ? styles.activeFilter : ''}
              >
                {category}
              </button>
            ))}
          </div>

          <div className={styles.courseGrid}>
            {filteredCourses.map((course) => (
              <article key={course.id} className={styles.courseCard}>
                <img src={course.image} alt={`${course.title} course preview`} />
                <div className={styles.courseBody}>
                  <div className={styles.courseHeader}>
                    <span>{course.category}</span>
                    <span>{course.level}</span>
                  </div>
                  <h2>{course.title}</h2>
                  <p>{course.summary}</p>
                  <div className={styles.infoRow}>
                    <div>
                      <strong>Duration</strong>
                      <span>{course.duration}</span>
                    </div>
                    <div>
                      <strong>Key skills</strong>
                      <span>{course.skills.join(', ')}</span>
                    </div>
                  </div>
                  <ul className={styles.highlights}>
                    {course.highlights.map((highlight) => (
                      <li key={highlight}>{highlight}</li>
                    ))}
                  </ul>
                  <Link to={`/courses/${course.slug}`} className={styles.courseLink}>
                    Explore course →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Courses;