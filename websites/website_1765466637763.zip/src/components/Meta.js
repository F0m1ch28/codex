import { useEffect } from 'react';

const Meta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    const updateMeta = (name, content) => {
      if (!content) return;
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };
    updateMeta('description', description);
    updateMeta('keywords', keywords);

    return () => {};
  }, [title, description, keywords]);

  return null;
};

export default Meta;