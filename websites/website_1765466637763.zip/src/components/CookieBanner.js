import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const storageKey = 'itlhb-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(storageKey);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(storageKey, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h4>We Respect Your Privacy</h4>
        <p>
          We use cookies to enhance your browsing experience, tailor learning recommendations, and analyze engagement.
          Manage your preferences anytime in our cookie policy.
        </p>
        <div className={styles.actions}>
          <button onClick={() => handleConsent('accepted')} className={styles.accept}>
            Accept
          </button>
          <button onClick={() => handleConsent('declined')} className={styles.decline}>
            Decline
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;