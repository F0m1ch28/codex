import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.container}>
        <div className={styles.brandColumn}>
          <h2 id="footer-heading" className={styles.logo}>
            IT Learning Hub Belgium
          </h2>
          <p>
            Empowering tomorrow&apos;s tech talent across Belgium through immersive, industry-led learning experiences that open doors to thriving IT careers.
          </p>
          <div className={styles.contactDetails}>
            <p>IT Learning Hub, Avenue de la Toison d&apos;Or 56, 1060 Brussels, Belgium</p>
            <p>Phone: <a href="tel:+3221234567">+32 2 123 45 67</a></p>
            <p>Email: <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a></p>
          </div>
        </div>
        <div className={styles.linksColumn}>
          <h3>Explore</h3>
          <ul>
            <li><NavLink to="/">Home</NavLink></li>
            <li><NavLink to="/about">About Us</NavLink></li>
            <li><NavLink to="/courses">Our Courses</NavLink></li>
            <li><NavLink to="/method">Learning Method</NavLink></li>
            <li><NavLink to="/careers">IT Careers</NavLink></li>
            <li><NavLink to="/blog">Blog</NavLink></li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3>Support</h3>
          <ul>
            <li><NavLink to="/contact">Contact</NavLink></li>
            <li><NavLink to="/terms">Terms of Service</NavLink></li>
            <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
            <li><NavLink to="/cookie-policy">Cookie Policy</NavLink></li>
          </ul>
        </div>
        <div className={styles.newsletterColumn}>
          <h3>Stay in the Loop</h3>
          <p>Subscribe to insights on evolving tech roles, exclusives on workshops, and more.</p>
          <form className={styles.newsletterForm}>
            <label htmlFor="footer-email" className="sr-only">Email address</label>
            <input type="email" id="footer-email" placeholder="Enter your email" required aria-label="Email address" />
            <button type="submit">Join the Community</button>
          </form>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} IT Learning Hub Belgium. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;