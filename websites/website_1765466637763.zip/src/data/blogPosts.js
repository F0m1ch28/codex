const blogPosts = [
  {
    slug: 'how-to-start-a-career-in-cybersecurity',
    title: 'How to Start a Career in Cybersecurity in Belgium',
    author: 'Lina Vermeulen',
    date: '2024-02-10',
    readingTime: '6 min read',
    excerpt: 'Belgium’s demand for cybersecurity specialists continues to soar. Explore the essential skills, certifications, and growth paths to launch your protective career.',
    image: 'https://picsum.photos/1200/800?random=31',
    tags: ['Cybersecurity', 'Career Tips', 'Belgium'],
    sections: [
      {
        heading: 'Understand the Belgian Cyber Landscape',
        content:
          'Belgian organisations—from Brussels-based institutions to Antwerp startups—are accelerating digital transformation. This growth fuels demand for specialists who can mitigate evolving threats. Begin by exploring national frameworks such as the Centre for Cybersecurity Belgium (CCB) guidelines, and stay informed on EU directives like NIS2.'
      },
      {
        heading: 'Build Strong Technical Fundamentals',
        content:
          'Focus on mastering networking concepts, operating systems, and scripting languages like Python or PowerShell. Hands-on labs, cyber ranges, and capture-the-flag challenges help you experiment safely, understand attacker mindsets, and refine your defensive strategies.'
      },
      {
        heading: 'Showcase a Learning Mindset',
        content:
          'Employers value professionals who remain curious. Document your progress through blogs, GitHub repositories, or community talks. Participate in Belgian meetups, volunteer at security conferences, and demonstrate how you keep pace with an ever-changing field.'
      }
    ],
    conclusion:
      'Cybersecurity careers reward resilience, collaboration, and ethical responsibility. With dedicated learning, guidance from experienced mentors, and the vibrant Belgian tech ecosystem, your journey toward protecting critical infrastructure can start today.'
  },
  {
    slug: 'designing-user-centric-digital-products',
    title: 'Designing User-Centric Digital Products',
    author: 'Youssef Maes',
    date: '2024-01-22',
    readingTime: '5 min read',
    excerpt: 'Human-centred design is the heartbeat of successful digital experiences. Here is how multidisciplinary Belgian teams craft products that users love.',
    image: 'https://picsum.photos/1200/800?random=32',
    tags: ['UX', 'Product Design', 'Innovation']
  },
  {
    slug: 'ai-skills-for-belgian-professionals',
    title: 'AI Skills Belgian Professionals Need in 2024',
    author: 'Mira Janssens',
    date: '2024-01-12',
    readingTime: '7 min read',
    excerpt: 'Artificial Intelligence is reshaping industries across Belgium. Discover the core competencies driving career growth and cross-functional collaboration.',
    image: 'https://picsum.photos/1200/800?random=33',
    tags: ['AI', 'Career Growth', 'Skills']
  }
];

export default blogPosts;