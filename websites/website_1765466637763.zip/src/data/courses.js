const courses = [
  {
    id: 1,
    slug: 'web-development-fundamentals',
    title: 'Web Development Fundamentals',
    category: 'Software Engineering',
    summary: 'Build a rock-solid foundation in HTML, CSS, modern JavaScript, and responsive design to craft delightful web experiences.',
    level: 'Beginner',
    duration: '12 weeks',
    skills: ['HTML5', 'CSS3', 'JavaScript ES6', 'Responsive Design', 'Accessibility'],
    learningOutcomes: [
      'Create interactive web pages with semantic, accessible structure.',
      'Implement responsive layouts that look sharp on every device.',
      'Collaborate with designers using modern component-driven workflows.'
    ],
    image: 'https://picsum.photos/800/600?random=21',
    prerequisites: ['Curiosity to build experiences on the web', 'Basic computer literacy'],
    highlights: ['Weekly live coding labs', '1:1 mentorship sessions', 'Real-world project prototype']
  },
  {
    id: 2,
    slug: 'data-analytics-with-python',
    title: 'Data Analytics with Python',
    category: 'Data & AI',
    summary: 'Transform raw data into clear insights using Python, Pandas, and data visualization to support strategic decisions.',
    level: 'Intermediate',
    duration: '10 weeks',
    skills: ['Python', 'Pandas', 'Data Visualization', 'SQL', 'Storytelling'],
    learningOutcomes: [
      'Automate data wrangling and cleansing with Python notebooks.',
      'Design dashboards that communicate patterns and KPIs effectively.',
      'Collaborate with stakeholders to translate analytics into action.'
    ],
    image: 'https://picsum.photos/800/600?random=22',
    prerequisites: ['Basic programming knowledge', 'Understanding of spreadsheets'],
    highlights: ['Industry dataset sprints', 'Guest lectures from Belgian data leaders', 'Capstone analytics story']
  },
  {
    id: 3,
    slug: 'cybersecurity-foundations',
    title: 'Cybersecurity Foundations',
    category: 'Security',
    summary: 'Protect modern infrastructures by mastering key cybersecurity principles, threat modelling, and ethical hacking basics.',
    level: 'Intermediate',
    duration: '14 weeks',
    skills: ['Network Security', 'Threat Modelling', 'Risk Assessment', 'Incident Response', 'Security Automation'],
    learningOutcomes: [
      'Design layered defense strategies tailored to Belgian enterprises.',
      'Conduct vulnerability assessments and respond to incidents.',
      'Advise teams on governance, compliance, and security culture.'
    ],
    image: 'https://picsum.photos/800/600?random=23',
    prerequisites: ['Understanding of networking basics', 'Motivation to secure systems'],
    highlights: ['Live attack-defense simulations', 'Access to cyber ranges', 'Mentorship from CISOs']
  },
  {
    id: 4,
    slug: 'cloud-native-engineering',
    title: 'Cloud Native Engineering',
    category: 'Cloud & DevOps',
    summary: 'Deploy resilient applications at scale with containers, orchestration, and observability driven by DevOps practices.',
    level: 'Advanced',
    duration: '16 weeks',
    skills: ['Docker', 'Kubernetes', 'CI/CD', 'Infrastructure as Code', 'Monitoring'],
    learningOutcomes: [
      'Containerize applications and orchestrate them across clusters.',
      'Design CI/CD pipelines that support rapid, reliable releases.',
      'Implement observability to keep services healthy and performant.'
    ],
    image: 'https://picsum.photos/800/600?random=24',
    prerequisites: ['Experience with scripting languages', 'Understanding of application architectures'],
    highlights: ['Partnership projects with Brussels startups', '24/7 access to lab environment', 'DevOps playbook templates']
  }
];

export default courses;