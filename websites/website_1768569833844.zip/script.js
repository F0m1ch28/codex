document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const mobileNav = document.querySelector('.mobile-nav');

    if (navToggle && mobileNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            mobileNav.classList.toggle('active');
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const storageKey = 'tablecdgaeCookieConsent';

    function hideBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    }

    if (cookieBanner && acceptBtn && declineBtn) {
        const savedPreference = localStorage.getItem(storageKey);
        if (!savedPreference) {
            cookieBanner.classList.add('active');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'accepted');
            hideBanner();
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'declined');
            hideBanner();
        });
    }
});