document.addEventListener("DOMContentLoaded", function () {
    const banner = document.querySelector(".cookie-banner");
    if (!banner) return;

    const storedPreference = localStorage.getItem("monroewjdx_cookie_pref");
    if (storedPreference) {
        banner.classList.remove("is-visible");
        return;
    }

    banner.classList.add("is-visible");

    const acceptBtn = banner.querySelector(".cookie-accept");
    const declineBtn = banner.querySelector(".cookie-decline");

    acceptBtn.addEventListener("click", function () {
        localStorage.setItem("monroewjdx_cookie_pref", "accepted");
        banner.classList.remove("is-visible");
    });

    declineBtn.addEventListener("click", function () {
        localStorage.setItem("monroewjdx_cookie_pref", "declined");
        banner.classList.remove("is-visible");
    });
});