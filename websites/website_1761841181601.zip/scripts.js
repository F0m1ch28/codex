document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    const scrollTopBtn = document.querySelector('.scroll-top');
    const metrics = document.querySelectorAll('.metric-value');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const yearSpan = document.getElementById('current-year');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            nav.classList.toggle('open');
        });
    }

    const smoothLinks = document.querySelectorAll('a[href^="#"]');
    smoothLinks.forEach(link => {
        link.addEventListener('click', e => {
            const targetId = link.getAttribute('href');
            if (targetId.length > 1) {
                const target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth' });
                    if (navToggle && nav.classList.contains('open')) {
                        navToggle.setAttribute('aria-expanded', 'false');
                        nav.classList.remove('open');
                    }
                }
            }
        });
    });

    const handleScroll = () => {
        if (window.scrollY > 300) {
            scrollTopBtn.style.display = 'flex';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    };

    document.addEventListener('scroll', handleScroll);

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const animateMetric = (metric) => {
        const target = parseInt(metric.getAttribute('data-target'), 10);
        const duration = 2000;
        const start = 0;
        const startTime = performance.now();

        const step = (currentTime) => {
            const progress = Math.min((currentTime - startTime) / duration, 1);
            const value = Math.floor(progress * (target - start) + start);
            metric.textContent = value.toLocaleString();
            if (progress < 1) {
                requestAnimationFrame(step);
            }
        };
        requestAnimationFrame(step);
    };

    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateMetric(entry.target);
                obs.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.5
    });

    metrics.forEach(metric => observer.observe(metric));

    const cookieKey = 'enervailCookieConsent';

    const showCookieBanner = () => {
        if (!localStorage.getItem(cookieKey) && cookieBanner) {
            cookieBanner.classList.add('active');
        }
    };

    const acceptCookies = () => {
        localStorage.setItem(cookieKey, 'accepted');
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    };

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', acceptCookies);
    }

    showCookieBanner();
});