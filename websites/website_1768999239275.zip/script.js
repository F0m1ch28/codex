(function () {
  function ready(fn) {
    if (document.readyState !== 'loading') {
      fn();
    } else {
      document.addEventListener('DOMContentLoaded', fn);
    }
  }

  ready(function () {
    var navToggle = document.querySelector('.nav-toggle');
    var siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
      navToggle.addEventListener('click', function () {
        var expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        navToggle.classList.toggle('open');
        siteNav.classList.toggle('open');
        try {
          if (!expanded) {
            localStorage.setItem('mnx-nav', 'open');
          } else {
            localStorage.removeItem('mnx-nav');
          }
        } catch (e) {}
      });
    }

    try {
      var navState = localStorage.getItem('mnx-nav');
      if (navState === 'open' && siteNav) {
        siteNav.classList.add('open');
        if (navToggle) {
          navToggle.classList.add('open');
          navToggle.setAttribute('aria-expanded', 'true');
        }
      }
    } catch (e) {}

    var banner = document.querySelector('.cookie-banner');
    if (banner) {
      var acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
      var declineBtn = banner.querySelector('[data-cookie-action="decline"]');
      var consentKey = 'mnx-consent';

      function hideBanner() {
        banner.classList.remove('visible');
        banner.setAttribute('aria-hidden', 'true');
      }

      function showBanner() {
        banner.classList.add('visible');
        banner.removeAttribute('aria-hidden');
      }

      try {
        var storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
          showBanner();
        }
        if (storedConsent === 'accepted') {
          document.documentElement.classList.add('cookies-accepted');
        }
      } catch (e) {
        showBanner();
      }

      if (acceptBtn) {
        acceptBtn.addEventListener('click', function () {
          try {
            localStorage.setItem(consentKey, 'accepted');
          } catch (e) {}
          document.documentElement.classList.add('cookies-accepted');
          hideBanner();
        });
      }

      if (declineBtn) {
        declineBtn.addEventListener('click', function () {
          try {
            localStorage.setItem(consentKey, 'declined');
          } catch (e) {}
          document.documentElement.classList.remove('cookies-accepted');
          hideBanner();
        });
      }
    }

    var redirectMap = {
      'history': 'atlas.html',
      'history.html': 'atlas.html',
      'network-atlas': 'atlas.html',
      'network-atlas.html': 'atlas.html'
    };
    var path = window.location.pathname.replace(/^\//, '').toLowerCase();
    if (redirectMap[path] && path !== redirectMap[path]) {
      window.location.replace(redirectMap[path]);
    }
  });
})();