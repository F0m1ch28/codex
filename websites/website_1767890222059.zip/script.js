document.addEventListener('DOMContentLoaded', function () {
    const banner = document.querySelector('.cookie-banner');
    if (!banner) return;

    const storageKey = 'particinmz_cookie_consent';
    const existingConsent = localStorage.getItem(storageKey);

    if (!existingConsent) {
        banner.classList.add('visible');
    }

    const acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
    const declineBtn = banner.querySelector('[data-cookie-action="decline"]');

    if (acceptBtn) {
        acceptBtn.addEventListener('click', function () {
            localStorage.setItem(storageKey, 'accepted');
            banner.classList.remove('visible');
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', function () {
            localStorage.setItem(storageKey, 'declined');
            banner.classList.remove('visible');
        });
    }
});