import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const consent = window.localStorage.getItem('kotokontrol_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('kotokontrol_cookie_consent', 'accepted');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Повідомлення про використання cookies">
      <p>
        Ми використовуємо cookie, щоб зробити ваш досвід на сайті ще комфортнішим. Детальніше у{' '}
        <Link to="/polityka-cookie">Політиці щодо cookie</Link>.
      </p>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Згоден
      </button>
    </div>
  );
};

export default CookieBanner;