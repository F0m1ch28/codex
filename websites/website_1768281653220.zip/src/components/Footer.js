import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-labelledby="footer-heading">
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <h2 id="footer-heading">КотоКонтроль</h2>
          <p>
            Гуманна програма TNR допомагає містам України співіснувати з котячими колоніями відповідально
            та з любов&apos;ю до тварин.
          </p>
          <div className={styles.socials} aria-label="Соціальні мережі">
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook КотоКонтроль"
            >
              f
            </a>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram КотоКонтроль"
            >
              in
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube КотоКонтроль"
            >
              yt
            </a>
          </div>
        </div>
        <div className={styles.links}>
          <h3>Навігація</h3>
          <ul>
            <li>
              <Link to="/pro-nas">Про нас</Link>
            </li>
            <li>
              <Link to="/metod-tnr">Метод TNR</Link>
            </li>
            <li>
              <Link to="/yak-dopomogty">Як допомогти</Link>
            </li>
            <li>
              <Link to="/korysni-porady">Корисні поради</Link>
            </li>
          </ul>
        </div>
        <div className={styles.contact}>
          <h3>Контакти</h3>
          <address>
            <p>Україна, м. Київ</p>
            <p>
              <Link to="/kontakty" className={styles.contactLink}>
                +380 (44) 123-45-67
              </Link>
            </p>
            <p>
              <Link to="/kontakty" className={styles.contactLink}>
                info@kotokontrol.org.ua
              </Link>
            </p>
          </address>
          <ul className={styles.legal}>
            <li>
              <Link to="/umovy-vykorystannya">Умови використання</Link>
            </li>
            <li>
              <Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link>
            </li>
            <li>
              <Link to="/polityka-cookie">Політика щодо cookie</Link>
            </li>
          </ul>
        </div>
      </div>
      <p className={styles.copy}>© {new Date().getFullYear()} КотоКонтроль. Усі права захищено.</p>
    </div>
  </footer>
);

export default Footer;