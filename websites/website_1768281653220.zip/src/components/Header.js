import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  const navLinkClass = ({ isActive }) =>
    isActive ? "${styles.link} ${styles.active}" : styles.link;

  return (
    <header className={styles.header}>
      <div className={"container ${styles.container}"}>
        <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="Перейти на головну сторінку">
          Кото<span>Контроль</span>
        </Link>
        <button
          type="button"
          className={styles.navToggle}
          onClick={toggleMenu}
          aria-expanded={isOpen}
          aria-controls="primary-navigation"
          aria-label={isOpen ? 'Закрити меню' : 'Відкрити меню'}
        >
          ☰
        </button>
        <nav
          id="primary-navigation"
          className={"${styles.nav} ${isOpen ? styles.open : ''}"}
          aria-label="Головна навігація"
        >
          <NavLink to="/pro-nas" className={navLinkClass} onClick={closeMenu}>
            Про нас
          </NavLink>
          <NavLink to="/metod-tnr" className={navLinkClass} onClick={closeMenu}>
            Метод TNR
          </NavLink>
          <NavLink to="/yak-dopomogty" className={navLinkClass} onClick={closeMenu}>
            Як допомогти
          </NavLink>
          <NavLink to="/korysni-porady" className={navLinkClass} onClick={closeMenu}>
            Корисні поради
          </NavLink>
          <NavLink to="/kontakty" className={navLinkClass} onClick={closeMenu}>
            Контакти
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;