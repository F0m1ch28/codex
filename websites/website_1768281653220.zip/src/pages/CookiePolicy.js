import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Політика щодо cookie | КотоКонтроль</title>
      <meta
        name="description"
        content="Політика використання cookie-файлів на сайті КотоКонтроль: які файли ми застосовуємо і як ви можете керувати налаштуваннями."
      />
    </Helmet>

    <section className={styles.section}>
      <div className="container">
        <h1>Політика щодо cookie</h1>
        <p>
          Cookie допомагають нам аналізувати відвідуваність, покращувати контент і пропонувати матеріали, які
          відповідають вашим інтересам.
        </p>

        <h2>Які cookie ми використовуємо</h2>
        <ul>
          <li>
            <strong>Аналітичні.</strong> Анонімно збирають статистику відвідувань, щоб ми розуміли, які сторінки
            популярні.
          </li>
          <li>
            <strong>Функціональні.</strong> Запам’ятовують ваші налаштування (наприклад, прийняття банера cookie).
          </li>
        </ul>

        <h2>Управління cookie</h2>
        <p>
          Ви можете видалити або заблокувати cookie у налаштуваннях браузера. Якщо відмовитесь від cookie, частина
          функцій може працювати обмежено.
        </p>

        <h2>Зв’язок з нами</h2>
        <p>З питаннями щодо cookie пишіть на info@kotokontrol.org.ua. Ми відповімо протягом двох робочих днів.</p>
      </div>
    </section>
  </>
);

export default CookiePolicy;