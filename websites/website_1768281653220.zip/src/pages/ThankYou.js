import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useLocation } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYou = () => {
  const location = useLocation();
  const visitorName = location.state?.name ? location.state.name.trim() : '';

  return (
    <>
      <Helmet>
        <title>Дякуємо за звернення | КотоКонтроль</title>
        <meta
          name="description"
          content="Дякуємо за звернення до КотоКонтролю! Ми відповімо на ваш лист найближчим часом."
        />
      </Helmet>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.card} role="status">
            <h1>Дякуємо за довіру! 🐾</h1>
            <p>
              {visitorName ? "${visitorName}, " : ''}
              ми отримали ваше повідомлення та відповімо найближчими днями. Якщо питання термінове, зателефонуйте за
              номером +380 (44) 123-45-67.
            </p>
            <Link to="/" className={styles.button}>
              Повернутися на головну
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default ThankYou;