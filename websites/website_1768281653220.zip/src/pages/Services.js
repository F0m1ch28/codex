import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Метод TNR | КотоКонтроль</title>
      <meta
        name="description"
        content="Дізнайтеся, як працює метод TNR: від безпечного відлову до повернення котів під опіку кураторів."
      />
      <meta
        name="keywords"
        content="TNR, Trap Neuter Return, стерилізація котів, контроль популяції котів, КотоКонтроль TNR"
      />
    </Helmet>

    <section className={styles.hero} aria-labelledby="tnr-title">
      <div className="container">
        <h1 id="tnr-title">Метод TNR — покроково та прозоро</h1>
        <p>
          TNR (Trap-Neuter-Return) — це гуманна стратегія, що стабілізує кількість безпритульних котів. Нижче — наш
          стандартний алгоритм, який ми адаптуємо під потреби кожної громади.
        </p>
      </div>
    </section>

    <section className={styles.steps}>
      <div className="container">
        <div className={styles.stepCard}>
          <span>Крок 1</span>
          <h2>Моніторинг та планування</h2>
          <p>
            Разом із мешканцями визначаємо колонії, рахуємо котів, призначаємо відповідальних людей та вибудовуємо
            графік відлову. Обов’язково інформуємо сусідів про нашу діяльність.
          </p>
        </div>
        <div className={styles.stepCard}>
          <span>Крок 2</span>
          <h2>Гуманний відлов</h2>
          <p>
            Використовуємо спеціальні пастки, що не травмують тварин. Кожну пастку накриваємо, аби знизити стрес. Після
            відлову коти прямують до перевіреної ветклініки.
          </p>
        </div>
        <div className={styles.stepCard}>
          <span>Крок 3</span>
          <h2>Операція та вакцинація</h2>
          <p>
            Ветеринар проводить стерилізацію, вакцинацію, дегельмінтизацію, обробку від паразитів. Кішок маркують
            спеціальною насічкою на вушку, щоб уникнути повторного відлову.
          </p>
        </div>
        <div className={styles.stepCard}>
          <span>Крок 4</span>
          <h2>Повернення та опіка</h2>
          <p>
            Після відновлення коти повертаються до звичних територій. Куратори забезпечують харчування, укриття та
            ведуть облік колонії, звітуючи громаді про пророблену роботу.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.callout}>
      <div className="container">
        <h2>Чому TNR працює?</h2>
        <ul>
          <li>
            <strong>Стабільність колоній.</strong> Стерилізовані коти охороняють територію від нових тварин і не
            розмножуються.
          </li>
          <li>
            <strong>Мовчазні ночі.</strong> Відсутність тічки — відсутність нічних криків і бійок.
          </li>
          <li>
            <strong>Здорові спільноти.</strong> Щеплені та доглянуті коти не переносять небезпечні для людей хвороби.
          </li>
        </ul>
      </div>
    </section>

    <section className={styles.resources}>
      <div className="container">
        <h2>Ресурси для впровадження TNR</h2>
        <div className={styles.resourceGrid}>
          <article>
            <h3>Інструкція для ОСББ</h3>
            <p>Готові шаблони оголошень, угод та протоколів зборів, щоб пояснити користь стерилізації мешканцям.</p>
          </article>
          <article>
            <h3>Посібник для волонтерів</h3>
            <p>Поради з безпечного транспортування, догляду після операції та комунікації з ветеринарами.</p>
          </article>
          <article>
            <h3>База ветеринарів</h3>
            <p>Список партнерських клінік із зазначенням графіку прийому, контактів та програм знижок.</p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default Services;