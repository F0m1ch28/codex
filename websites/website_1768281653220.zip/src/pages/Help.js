import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Help.module.css';

const Help = () => (
  <>
    <Helmet>
      <title>Як допомогти | КотоКонтроль</title>
      <meta
        name="description"
        content="Долучайтеся до КотоКонтролю: волонтерство, фінансова підтримка, інформаційні кампанії та партнерство з громадами."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Як ви можете допомогти</h1>
        <p>
          Кожен внесок — це врятовані котячі життя, стабільні колонії та чисті двори. Оберіть формат участі, який
          підходить саме вам.
        </p>
      </div>
    </section>

    <section className={styles.options}>
      <div className="container">
        <div className={styles.grid}>
          <article>
            <h2>Волонтерство</h2>
            <p>
              Допомагайте з відловом, транспортуванням, післяопераційним доглядом або інформаційними кампаніями у своєму
              місті.
            </p>
            <ul>
              <li>Навчання та кураторство від досвідчених волонтерів</li>
              <li>Доступ до закритих чатів та інструкцій</li>
              <li>Страхування під час операційних виїздів</li>
            </ul>
            <Link to="/kontakty">Подати заявку</Link>
          </article>

          <article>
            <h2>Фінансова підтримка</h2>
            <p>
              Ваш регулярний внесок покриває стерилізацію, вакцини, пастки та лікування котів, які потрапили у біду.
            </p>
            <ul>
              <li>Публікуємо прозорі фінансові звіти</li>
              <li>Працюємо з офіційними платежами та квитанціями</li>
              <li>Комунікуємо з місцевою владою щодо співфінансування</li>
            </ul>
            <a
              href="https://send.monobank.ua/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Підтримати програму
            </a>
          </article>

          <article>
            <h2>Комунікація та адвокація</h2>
            <p>
              Розповідайте сусідам, поширюйте матеріали КотоКонтролю, ініціюйте обговорення TNR на зборах ОСББ та в
              школах.
            </p>
            <ul>
              <li>Отримайте безкоштовний пакет друкованих листівок</li>
              <li>Скористайтеся готовими презентаціями для громад</li>
              <li>Запросіть нашого спікера на подію</li>
            </ul>
            <Link to="/korysni-porady">Матеріали для поширення</Link>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.cta}>
      <div className="container">
        <div className={styles.ctaInner}>
          <h2>Об’єднаймо громаду навколо котів</h2>
          <p>Напишіть нам про свої ідеї або запросіть тренінг. Ми допоможемо від старту до впровадження.</p>
          <Link to="/kontakty" className={styles.button}>
            Зв’язатися з координатором
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default Help;