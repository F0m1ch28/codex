import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const Home = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState({ type: 'idle', message: '' });

  const handleSubmit = (event) => {
    event.preventDefault();
    const trimmedEmail = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setStatus({ type: 'error', message: 'Будь ласка, введіть коректну електронну адресу.' });
      return;
    }
    setStatus({ type: 'success', message: 'Дякуємо! Ми додали вас до списку оновлень.' });
    setEmail('');
  };

  return (
    <>
      <Helmet>
        <title>КотоКонтроль | Гуманний контроль популяції бродячих котів</title>
        <meta
          name="description"
          content="КотоКонтроль впроваджує гуманний метод TNR по всій Україні. Долучайтеся до порятунку бродячих котів та розвитку відповідальних громад."
        />
        <meta
          name="keywords"
          content="КотоКонтроль, TNR, стерилізація котів, волонтерство, опіка над котами, гуманний метод"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={"container ${styles.heroInner}"}>
          <p className={styles.pretitle}>Всеукраїнська ініціатива</p>
          <h1>Гуманний контроль популяції бродячих котів</h1>
          <p>
            Ми впроваджуємо метод TNR (Впіймати — Стерилізувати — Повернути), щоб зменшити страждання тварин і
            створити безпечні вулиці для людей та котячих спільнот.
          </p>
          <div className={styles.heroActions}>
            <Link to="/metod-tnr" className={styles.heroButton}>
              Дізнатися більше
            </Link>
            <Link to="/yak-dopomogty" className={styles.secondaryButton}>
              Долучитися
            </Link>
          </div>
          <dl className={styles.heroStats}>
            <div>
              <dt>1200+</dt>
              <dd>стерилізованих котів за рік</dd>
            </div>
            <div>
              <dt>48</dt>
              <dd>міст та громад України</dd>
            </div>
            <div>
              <dt>350</dt>
              <dd>активних волонтерів</dd>
            </div>
          </dl>
        </div>
      </section>

      <section className={styles.problem}>
        <div className="container">
          <h2>Чому це важливо?</h2>
          <p>
            Бездоглядна популяція котів росте щороку. Відсутність стерилізації призводить до голоду, хвороб,
            конфліктів у дворі та перенавантаження притулків. TNR — науково доведений інструмент контролю,
            що зберігає життя, зменшує шум під час тічки та стабілізує колонії.
          </p>
          <div className={styles.problemGrid}>
            <article>
              <h3>Здоров&apos;я тварин</h3>
              <p>Стерилізовані та вакциновані коти мають більше шансів прожити довге та безпечне життя.</p>
            </article>
            <article>
              <h3>Баланс у місті</h3>
              <p>Керовані колонії запобігають розповсюдженню сміття, паразитів і конфліктів у дворах.</p>
            </article>
            <article>
              <h3>Освітня місія</h3>
              <p>Просвітництво та співпраця з ОСББ допомагають закріпити гуманні практики на законодавчому рівні.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.tnrIntro}>
        <div className="container">
          <h2>Що таке TNR?</h2>
          <p>
            TNR (Trap-Neuter-Return) — міжнародний стандарт. Котів безпечно відловлюють, стерилізують, вакцинують
            та повертають у знайоме середовище під опіку кураторів.
          </p>
          <div className={styles.tnrSteps}>
            <div>
              <span>01</span>
              <h3>Впіймати</h3>
              <p>Використовуємо гуманне обладнання та працюємо тільки з ветеринарами-партнерами.</p>
            </div>
            <div>
              <span>02</span>
              <h3>Стерилізувати</h3>
              <p>Операція, вакцинація, дегельмінтизація та маркування для обліку колоній.</p>
            </div>
            <div>
              <span>03</span>
              <h3>Повернути</h3>
              <p>Повертаємо котів до місця проживання, забезпечуємо опіку та комунікацію з мешканцями.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <h2>Наша місія</h2>
          <p>
            КотоКонтроль об’єднує волонтерів, громади та ветеринарів, щоб розбудувати систему TNR у кожному
            українському місті. Ми прагнемо, аби співжиття людей і котів було комфортним, передбачуваним та етичним.
          </p>
          <div className={styles.missionGrid}>
            <article>
              <h3>Навчання громад</h3>
              <p>Проводимо тренінги для ОСББ, шкіл і муніципалітетів щодо TNR та догляду за колоніями.</p>
            </article>
            <article>
              <h3>Партнерство з ветклініками</h3>
              <p>Працюємо лише з клініками, які дотримуються високих стандартів безпеки та антибіотик-стewardship.</p>
            </article>
            <article>
              <h3>Підтримка волонтерів</h3>
              <p>Забезпечуємо обладнанням, інструкціями та інформаційною підтримкою кураторів колоній.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <h2>Наші напрями роботи</h2>
          <div className={styles.serviceCards}>
            <article>
              <img
                src="https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=800&q=80"
                alt="Волонтер годує кота після стерилізації"
                loading="lazy"
              />
              <h3>Координація TNR-програм</h3>
              <p>Допомагаємо організувати відлов, стерилізацію та повернення у вашому місті.</p>
              <Link to="/metod-tnr">Детально про процес</Link>
            </article>
            <article>
              <img
                src="https://images.unsplash.com/photo-1513105737059-ff0cf0580e5a?auto=format&fit=crop&w=800&q=80"
                alt="Волонтерська команда готує обладнання"
                loading="lazy"
              />
              <h3>Підтримка волонтерів</h3>
              <p>Навчаємо безпечному поводженню з котами, ведемо базу контактів кураторів.</p>
              <Link to="/yak-dopomogty">Стати волонтером</Link>
            </article>
            <article>
              <img
                src="https://images.unsplash.com/photo-1514986888952-8cd320577b68?auto=format&fit=crop&w=800&q=80"
                alt="Соціальна кампанія щодо стерилізації котів"
                loading="lazy"
              />
              <h3>Інформаційні кампанії</h3>
              <p>Друкуємо листівки, проводимо лекції та створюємо медіа-матеріали про відповідальну опіку.</p>
              <Link to="/korysni-porady">Переглянути поради</Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <h2>Відгуки партнерів</h2>
          <div className={styles.testimonialGrid}>
            <article>
              <img
                src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80"
                alt="Портрет ветлікарки Марії"
                loading="lazy"
              />
              <blockquote>
                «Завдяки КотоКонтролю наш район перестав потерпати від постійного кошлатого приросту. Люди бачать, що
                стерилізація — це про турботу, а не загрозу».
              </blockquote>
              <p className={styles.author}>Марія, ветеринарка м. Дніпро</p>
            </article>
            <article>
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80"
                alt="Портрет координатора Сергія"
                loading="lazy"
              />
              <blockquote>
                «Ми створили групу швидкого реагування, яка працює за чітким алгоритмом. Зараз мешканці самі
                звертаються до нас по консультацію, як поводитися з котами».
              </blockquote>
              <p className={styles.author}>Сергій, координатор ОСББ, Львів</p>
            </article>
            <article>
              <img
                src="https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?auto=format&fit=crop&w=200&q=80"
                alt="Портрет волонтерки Іри"
                loading="lazy"
              />
              <blockquote>
                «Опіка над колоніями стала системною. Маємо графіки годування, фінансовий план і ніколи не залишаємо
                котів без нагляду».
              </blockquote>
              <p className={styles.author}>Іра, волонтерка, Харків</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.tipsPreview}>
        <div className="container">
          <h2>Корисні поради від кураторів</h2>
          <div className={styles.tipCards}>
            <article>
              <h3>Як допомогти котам узимку</h3>
              <p>Розкажемо, як утеплити будиночки, підібрати корм та налагодити чергування з годування.</p>
              <Link to="/korysni-porady">Читати далі</Link>
            </article>
            <article>
              <h3>Що робити, якщо знайшли кошенят</h3>
              <p>Покрокова інструкція: від обстеження до безпечного соціалізування малюків.</p>
              <Link to="/korysni-porady">Детальна інструкція</Link>
            </article>
            <article>
              <h3>Комунікація з сусідами</h3>
              <p>Шаблони оголошень, аргументи для загальних зборів та кращі практики взаємодії.</p>
              <Link to="/korysni-porady">Дізнатися як</Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaInner}>
            <h2>Хочете отримувати оновлення та освітні матеріали?</h2>
            <p>Залиште свій email, і ми щомісяця надсилатимемо найважливіші новини про TNR в Україні.</p>
            <form className={styles.newsletterForm} onSubmit={handleSubmit} noValidate>
              <label htmlFor="newsletter-email" className="sr-only">
                Електронна адреса
              </label>
              <div className={styles.inputGroup}>
                <input
                  id="newsletter-email"
                  type="email"
                  name="email"
                  placeholder="Ваш email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  required
                  aria-required="true"
                  aria-describedby="newsletter-feedback"
                />
                <button type="submit">Підписатися</button>
              </div>
              <p
                id="newsletter-feedback"
                className={"${styles.feedback} ${status.type === 'error' ? styles.error : styles.success}"}
                aria-live="polite"
              >
                {status.message}
              </p>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;