import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const Contact = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', city: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) {
      newErrors.name = 'Вкажіть, будь ласка, ваше ім’я.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      newErrors.email = 'Перевірте правильність електронної адреси.';
    }
    if (!form.message.trim() || form.message.trim().length < 10) {
      newErrors.message = 'Напишіть хоча б декілька речень, щоб ми могли допомогти.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const foundErrors = validate();
    if (Object.keys(foundErrors).length > 0) {
      setErrors(foundErrors);
      return;
    }
    setErrors({});
    setSubmitting(true);
    const sanitizedName = form.name.trim();
    setTimeout(() => {
      setSubmitting(false);
      setForm({ name: '', email: '', city: '', message: '' });
      navigate('/dyakuyemo', { state: { name: sanitizedName } });
    }, 500);
  };

  return (
    <>
      <Helmet>
        <title>Контакти | КотоКонтроль</title>
        <meta
          name="description"
          content="Зв’яжіться з командою КотоКонтролю: консультації з TNR, підтримка волонтерів та партнерство з громадами."
        />
        <meta name="keywords" content="контакти КотоКонтроль, TNR Україна, волонтери котів, консультація TNR" />
      </Helmet>

      <section className={styles.hero} aria-labelledby="contact-title">
        <div className="container">
          <h1 id="contact-title">Контакти КотоКонтролю</h1>
          <p>
            Ми відкриті до співпраці з громадами, ОСББ, волонтерами та ветеринарними клініками. Залиште запит — і наша
            команда зв’яжеться з вами впродовж двох робочих днів.
          </p>
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.details}>
              <h2>Як нас знайти</h2>
              <ul>
                <li>
                  <strong>Адреса:</strong> Україна, м. Київ
                </li>
                <li>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+380441234567" aria-label="Подзвонити на номер +380441234567">
                    +380 (44) 123-45-67
                  </a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@kotokontrol.org.ua" aria-label="Написати листа на info@kotokontrol.org.ua">
                    info@kotokontrol.org.ua
                  </a>
                </li>
              </ul>
              <div className={styles.contactCard}>
                <h3>Години роботи</h3>
                <p>Пн — Пт: 10:00 — 18:00</p>
                <p>Субота: консультації за попереднім записом</p>
              </div>
              <div className={styles.contactCard}>
                <h3>Чат підтримки волонтерів</h3>
                <p>Долучайтесь до нашої телеграм-групи після короткої анкетування на сторінці «Як допомогти».</p>
              </div>
            </div>

            <div className={styles.formWrapper}>
              <h2>Напишіть нам</h2>
              <form onSubmit={handleSubmit} noValidate>
                <div className={styles.field}>
                  <label htmlFor="name">Ім’я *</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={form.name}
                    onChange={handleChange}
                    maxLength={80}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                    required
                  />
                  {errors.name && (
                    <p className={styles.error} id="name-error" role="alert">
                      {errors.name}
                    </p>
                  )}
                </div>

                <div className={styles.field}>
                  <label htmlFor="email">Електронна пошта *</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                    required
                  />
                  {errors.email && (
                    <p className={styles.error} id="email-error" role="alert">
                      {errors.email}
                    </p>
                  )}
                </div>

                <div className={styles.field}>
                  <label htmlFor="city">Місто</label>
                  <input
                    id="city"
                    name="city"
                    type="text"
                    value={form.city}
                    onChange={handleChange}
                    maxLength={60}
                    placeholder="Ваш населений пункт"
                  />
                </div>

                <div className={styles.field}>
                  <label htmlFor="message">Ваше повідомлення *</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={form.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                    required
                    minLength={10}
                    placeholder="Опишіть запит або ідею співпраці"
                  />
                  {errors.message && (
                    <p className={styles.error} id="message-error" role="alert">
                      {errors.message}
                    </p>
                  )}
                </div>

                <button type="submit" disabled={submitting}>
                  {submitting ? 'Надсилання…' : 'Надіслати повідомлення'}
                </button>
              </form>
              <p className={styles.note}>
                Надсилаючи форму, ви погоджуєтесь з{' '}
                <a href="/polityka-konfidentsiinosti">Політикою конфіденційності</a> та{' '}
                <a href="/umovy-vykorystannya">Умовами використання</a>.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;