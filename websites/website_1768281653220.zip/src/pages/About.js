import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>Про нас | КотоКонтроль</title>
      <meta
        name="description"
        content="Дізнайтеся, як КотоКонтроль розвиває мережу волонтерських груп TNR по всій Україні та співпрацює з громадами."
      />
      <meta
        name="keywords"
        content="про КотоКонтроль, історія організації, команда, TNR Україна, волонтери котів"
      />
    </Helmet>

    <section className={styles.hero} aria-labelledby="about-title">
      <div className="container">
        <h1 id="about-title">Ми змінюємо ставлення до бродячих котів</h1>
        <p>
          КотоКонтроль сформувався у 2016 році як спільнота небайдужих людей, які хотіли гуманно контролювати популяцію
          котів у Києві. Сьогодні ми підтримуємо волонтерські групи у 48 містах України та проводимо навчальні програми
          для муніципалітетів.
        </p>
      </div>
    </section>

    <section className={styles.story}>
      <div className="container">
        <h2>Історія ініціативи</h2>
        <div className={styles.storyGrid}>
          <article>
            <h3>2016 — старт у столиці</h3>
            <p>Перші пілотні TNR-проєкти в київських дворах показали ефективність гуманного підходу.</p>
          </article>
          <article>
            <h3>2018 — освітні програми</h3>
            <p>Ми розробили тренінги для ОСББ та школярів щодо догляду за колоніями та відповідального поводження.</p>
          </article>
          <article>
            <h3>2020 — національний масштаб</h3>
            <p>Запустили онлайн-платформу з матеріалами, базою ветеринарів і чатом підтримки волонтерів.</p>
          </article>
          <article>
            <h3>2023 — партнерство з громадами</h3>
            <p>Підписали меморандуми з громадами щодо фінансування стерилізацій за рахунок місцевих програм.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <h2>Наші принципи</h2>
        <ul className={styles.valuesList}>
          <li>
            <strong>Гуманність</strong>
            <p>Жодних жорстоких методів. TNR — єдина етична стратегія, яку ми підтримуємо.</p>
          </li>
          <li>
            <strong>Відкритість</strong>
            <p>Ми ділимося статистикою, найкращими практиками та вчимося у партнерів з усього світу.</p>
          </li>
          <li>
            <strong>Відповідальність</strong>
            <p>Кожен волонтер проходить інструктаж, ми слідкуємо за стандартами безпеки та обліку.</p>
          </li>
        </ul>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <h2>Команда КотоКонтролю</h2>
        <div className={styles.teamGrid}>
          <article>
            <img
              src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80"
              alt="Координаторка проєкту Оксана"
              loading="lazy"
            />
            <h3>Оксана Мельник</h3>
            <p>Національна координаторка TNR. Відповідає за співпрацю з громадами та партнерами.</p>
          </article>
          <article>
            <img
              src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80"
              alt="Ветеринарний консультант Андрій"
              loading="lazy"
            />
            <h3>Андрій Коваленко</h3>
            <p>Ветеринарний консультант. Розробляє протоколи операцій та післяопераційного догляду.</p>
          </article>
          <article>
            <img
              src="https://images.unsplash.com/photo-1541534401786-2077eed87a76?auto=format&fit=crop&w=600&q=80"
              alt="Менеджерка волонтерів Ганна"
              loading="lazy"
            />
            <h3>Ганна Сидоренко</h3>
            <p>Менеджерка волонтерів. Підтримує кураторів колоній та організовує навчання.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.impact}>
      <div className="container">
        <h2>Наш вплив у цифрах</h2>
        <div className={styles.impactGrid}>
          <div>
            <strong>87%</strong>
            <p>партнерських дворів відмітили зниження кількості конфліктів з мешканцями</p>
          </div>
          <div>
            <strong>65%</strong>
            <p>колоній мають постійних кураторів та забезпечені будиночками</p>
          </div>
          <div>
            <strong>140+</strong>
            <p>проведених тренінгів для волонтерів та комунальних служб</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;