import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Help from './pages/Help';
import Tips from './pages/Tips';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';

const App = () => (
  <>
    <Header />
    <ScrollToTop />
    <main id="main-content" className="main-content" tabIndex="-1">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/pro-nas" element={<About />} />
        <Route path="/metod-tnr" element={<Services />} />
        <Route path="/yak-dopomogty" element={<Help />} />
        <Route path="/korysni-porady" element={<Tips />} />
        <Route path="/kontakty" element={<Contact />} />
        <Route path="/dyakuyemo" element={<ThankYou />} />
        <Route path="/umovy-vykorystannya" element={<TermsOfService />} />
        <Route path="/polityka-konfidentsiinosti" element={<PrivacyPolicy />} />
        <Route path="/polityka-cookie" element={<CookiePolicy />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
  </>
);

export default App;