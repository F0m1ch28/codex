document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('#primary-navigation');
    const scrollBtn = document.getElementById('scrollToTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    const yearSpan = document.getElementById('current-year');
    const legalYears = document.querySelectorAll('.legal-year');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            primaryNav.classList.toggle('active');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                primaryNav.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    const updateYear = year => {
        if (yearSpan) yearSpan.textContent = year;
        legalYears.forEach(span => span.textContent = year);
    };
    updateYear(new Date().getFullYear());

    const toggleScrollButton = () => {
        if (!scrollBtn) return;
        if (window.scrollY > 200) {
            scrollBtn.classList.add('show');
        } else {
            scrollBtn.classList.remove('show');
        }
    };

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        window.addEventListener('scroll', toggleScrollButton);
    }

    // Cookie banner logic
    const cookieConsentKey = 'alvintoCookieConsent';
    const hasConsent = localStorage.getItem(cookieConsentKey);

    if (!hasConsent && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    if (acceptCookies) {
        acceptCookies.addEventListener('click', () => {
            localStorage.setItem(cookieConsentKey, 'accepted');
            cookieBanner.classList.remove('active');
        });
    }
});