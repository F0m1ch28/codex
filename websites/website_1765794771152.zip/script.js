document.addEventListener('DOMContentLoaded', () => {
  const menuToggle = document.querySelector('.menu-toggle');
  const navMenu = document.getElementById('navMenu');
  const menuBackdrop = document.getElementById('menuBackdrop');

  function closeMenu() {
    document.body.classList.remove('nav-open');
    if (menuToggle) {
      menuToggle.setAttribute('aria-expanded', 'false');
    }
  }

  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
      const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!expanded));
      document.body.classList.toggle('nav-open', !expanded);
    });

    navMenu.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          closeMenu();
        }
      });
    });
  }

  if (menuBackdrop) {
    menuBackdrop.addEventListener('click', closeMenu);
  }

  const cookieKey = 'cce_cookie_consent';
  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const stored = localStorage.getItem(cookieKey);
    if (!stored) {
      cookieBanner.classList.add('is-visible');
    }
    cookieBanner.querySelectorAll('[data-cookie-action]').forEach((btn) => {
      btn.addEventListener('click', (event) => {
        const action = event.currentTarget.getAttribute('data-cookie-action');
        localStorage.setItem(cookieKey, action);
        cookieBanner.classList.remove('is-visible');
      });
    });
  }

  const waitlistForm = document.getElementById('waitlistForm');
  if (waitlistForm) {
    waitlistForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const message = waitlistForm.querySelector('.form-message');
      if (message) {
        message.textContent = 'Thank you. A hash activation strategist will contact you within 24 hours.';
        message.classList.add('is-visible');
      }
      waitlistForm.reset();
    });
  }

  if (document.body.dataset.page === 'plans') {
    const rows = document.querySelectorAll('[data-plan-row]');
    const detail = document.querySelector('[data-plan-detail]');
    if (rows.length && detail) {
      const nameField = detail.querySelector('[data-plan-name]');
      const boostField = detail.querySelector('[data-plan-boost]');
      const activationField = detail.querySelector('[data-plan-activation]');
      const rewardField = detail.querySelector('[data-plan-reward]');
      rows.forEach((row) => {
        row.addEventListener('click', () => {
          rows.forEach((r) => r.classList.remove('is-active'));
          row.classList.add('is-active');
          if (nameField) nameField.textContent = row.dataset.name;
          if (boostField) boostField.textContent = row.dataset.boost;
          if (activationField) activationField.textContent = row.dataset.activation;
          if (rewardField) rewardField.textContent = row.dataset.reward;
        });
      });
      rows[0].click();
    }
  }

  if (document.body.dataset.page === 'wallet') {
    const copyBtn = document.querySelector('[data-copy-wallet]');
    const walletText = document.querySelector('[data-wallet-address]');
    const feedback = document.querySelector('[data-copy-feedback]');
    if (copyBtn && walletText && feedback) {
      copyBtn.addEventListener('click', async () => {
        const value = walletText.textContent.trim();
        try {
          await navigator.clipboard.writeText(value);
          feedback.textContent = 'Wallet copied to clipboard.';
        } catch (error) {
          feedback.textContent = 'Copy not supported. Please copy manually.';
        }
        feedback.classList.add('is-visible');
        setTimeout(() => {
          feedback.classList.remove('is-visible');
        }, 2600);
      });
    }
  }

  if (document.body.dataset.page === 'extraction') {
    const tracks = document.querySelectorAll('[data-progress-bar]');
    tracks.forEach((track) => {
      const valueLabel = track.querySelector('.progress-value');
      const fill = track.querySelector('.progress-fill');
      let current = Math.floor(Math.random() * 35) + 15;
      function animate() {
        const increment = Math.floor(Math.random() * 25) + 10;
        current = (current + increment) % 110;
        if (current < 15) current = Math.floor(Math.random() * 30) + 20;
        if (fill) fill.style.setProperty('--progress', current);
        if (valueLabel) valueLabel.textContent = `${current}%`;
      }
      animate();
      setInterval(animate, 1800);
    });
  }
});