document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".primary-nav");
  const navLinks = document.querySelectorAll(".primary-nav a");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navMenu.classList.toggle("is-open");
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (navMenu.classList.contains("is-open")) {
          navMenu.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const currentYearElements = document.querySelectorAll(".current-year");
  const now = new Date();
  currentYearElements.forEach((el) => {
    el.textContent = now.getFullYear();
  });

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptCookieButton = document.querySelector("[data-cookie-accept]");
  const declineCookieButton = document.querySelector("[data-cookie-decline]");
  const cookieStorageKey = "ffn_cookie_choice";

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("active");
    }
  }

  const storedChoice = localStorage.getItem(cookieStorageKey);
  if (!storedChoice) {
    showCookieBanner();
  }

  if (acceptCookieButton) {
    acceptCookieButton.addEventListener("click", () => {
      localStorage.setItem(cookieStorageKey, "accepted");
      hideCookieBanner();
    });
  }

  if (declineCookieButton) {
    declineCookieButton.addEventListener("click", () => {
      localStorage.setItem(cookieStorageKey, "declined");
      hideCookieBanner();
    });
  }

  const toast = document.getElementById("global-toast");

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => {
      toast.classList.remove("show");
    }, 4000);
  }

  document.querySelectorAll(".form-to-thankyou").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Thank you. Redirecting to confirmation.");
      setTimeout(() => {
        const target = form.getAttribute("action") || "thank-you.html";
        window.location.href = target;
      }, 1500);
    });
  });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.25,
    }
  );

  document.querySelectorAll(".animate-on-scroll").forEach((element) => {
    observer.observe(element);
  });
});