import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import ContactsPage from './pages/Contacts';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import TermsOfUsePage from './pages/TermsOfUse';
import CookiePolicyPage from './pages/CookiePolicy';
import styles from './App.module.css';

const App = () => (
  <Router basename="/">
    <div className={styles.appWrapper}>
      <Header />
      <main className={styles.main} id="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/o-kompanii" element={<AboutPage />} />
          <Route path="/uslugi" element={<ServicesPage />} />
          <Route path="/kontakty" element={<ContactsPage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPolicyPage />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsOfUsePage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  </Router>
);

export default App;