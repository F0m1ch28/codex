import React from 'react';
import Seo from '../components/Seo';
import styles from '../styles/Legal.module.css';

const CookiePolicyPage = () => (
  <>
    <Seo
      title="Политика использования cookie"
      description="Политика использования файлов cookie компании Компания. Узнайте, какие cookie мы применяем и как управлять настройками."
      keywords="cookie, политика cookie, Компания"
    />
    <div className={styles.page}>
      <div className="container">
        <h1>Политика использования файлов cookie</h1>
        <p className={styles.updated}>Последнее обновление: 1 марта 2024 года</p>

        <section className={styles.section}>
          <h2>1. Что такое cookie</h2>
          <p>
            Файлы cookie — это небольшие фрагменты данных, которые сохраняются на вашем устройстве при
            посещении сайта. Они помогают запоминать настройки и улучшать работу сайта.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Какие cookie мы используем</h2>
          <ul>
            <li>Функциональные cookie — для сохранения настроек и предпочтений;</li>
            <li>
              Аналитические cookie — для понимания того, как используется Сайт и улучшения нашего
              контента;
            </li>
            <li>Cookie сторонних сервисов — для интеграции с инструментами аналитики и чатов.</li>
          </ul>
        </section>

        <section className={styles.section}>
          <h2>3. Управление cookie</h2>
          <p>
            Вы можете управлять cookie через настройки браузера и отказаться от их использования.
            Обратите внимание, что отключение cookie может повлиять на функциональность Сайта.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Контакты</h2>
          <p>
            По вопросам, связанным с использованием cookie, свяжитесь с нами:{" "}
            <a href="mailto:info@kompaniya.ru">info@komпанию.ru</a>.
          </p>
        </section>
      </div>
    </div>
  </>
);

export default CookiePolicyPage;