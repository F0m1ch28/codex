import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const leadershipTeam = [
  {
    name: 'Ольга Емельянова',
    role: 'Управляющий партнер',
    description:
      'Отвечает за стратегию и построение партнерств. Ранее возглавляла программы трансформации в международной компании.',
    image: 'https://picsum.photos/600/600?random=41',
  },
  {
    name: 'Игорь Назаров',
    role: 'Директор по операционной эффективности',
    description:
      'Специализируется на оптимизации процессов и внедрении бережливых подходов в производстве и сервисе.',
    image: 'https://picsum.photos/600/600?random=42',
  },
  {
    name: 'Елизавета Щербакова',
    role: 'Партнер по клиентскому опыту',
    description:
      'Создает системные подходы к поддержке клиентов, развивает культуры сервисности и управления лояльностью.',
    image: 'https://picsum.photos/600/600?random=43',
  },
];

const milestones = [
  {
    year: '2012',
    title: 'Основание компании',
    description:
      'Собрали команду экспертов из консалтинга, технологических и продуктовых компаний.',
  },
  {
    year: '2016',
    title: 'Развитие продуктовой экспертизы',
    description: 'Запустили практику цифровых решений и аналитики, сформировали продуктовые команды.',
  },
  {
    year: '2019',
    title: 'Международные проекты',
    description:
      'Вышли на рынки Восточной Европы и Центральной Азии, расширили сеть партнеров.',
  },
  {
    year: '2023',
    title: 'Экосистема знаний',
    description:
      'Создали набор методологий и обучающих программ для клиентов и внутренней команды.',
  },
];

const values = [
  {
    title: 'Ответственность за результат',
    description:
      'Мы достигаем договоренных целей и поддерживаем клиента до достижения эффектов.',
  },
  {
    title: 'Партнерство и доверие',
    description:
      'Работаем открыто, делимся знаниями и строим долгосрочные отношения с командами.',
  },
  {
    title: 'Живое лидерство',
    description:
      'Развиваем культуру, в которой люди вдохновляют друг друга на рост и изменения.',
  },
];

const expertise = [
  'Стратегическое развитие и организационный дизайн',
  'Цифровые продукты и технологические платформы',
  'Управление данными, BI и аналитика',
  'Клиентский опыт и сервис',
  'Обучение и развитие команд',
  'Изменения и коммуникации',
];

const AboutPage = () => (
  <>
    <Seo
      title="О компании"
      description="Компания — команда экспертов, которая соединяет стратегию, технологии и опыт работы с людьми, чтобы помогать бизнесу уверенно расти."
      keywords="о компании, команда, ценности, опыт, Компания"
    />
    <div className={styles.page}>
      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introContent}>
            <div>
              <p className={styles.label}>О нас</p>
              <h1>Соединяем стратегию, технологии и культуру изменений</h1>
              <p>
                Компания появилась из идеи, что трансформация должна быть осознанной и вдохновляющей.
                Мы верим в силу команд и системный подход, поэтому сопровождаем бизнес на каждом этапе
                — от поиска фокуса до масштабирования результатов.
              </p>
            </div>
            <div className={styles.figure}>
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Команда, обсуждающая стратегию проекта"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Наши ценности</h2>
          <p className={styles.sectionSubtitle}>
            Ценности — это принципы, на которых строится поведение команды и принятие решений в любых
            ситуациях.
          </p>
          <div className={styles.valueGrid}>
            {values.map((value) => (
              <div key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className="container">
          <h2>Ключевые этапы</h2>
          <p className={styles.sectionSubtitle}>
            Мы растем вместе с клиентами, расширяя экспертизу и инвестиции в развитие людей.
          </p>
          <div className={styles.timeline}>
            {milestones.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{item.year}</span>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <h2>Лидеры практик</h2>
          <p className={styles.sectionSubtitle}>
            Руководители проектов постоянно включены в рабочие группы, обеспечивают единство подхода и
            поддерживают команду клиента.
          </p>
          <div className={styles.teamGrid}>
            {leadershipTeam.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImage}>
                  <img src={member.image} alt={member.name} loading="lazy" />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.expertise}>
        <div className="container">
          <div className={styles.expertiseContent}>
            <div>
              <h2>Наши направления</h2>
              <p>
                Мы собираем экспертов под задачу, используем гибкие методологии и передаем знания
                команде клиента, чтобы результат закрепился внутри организации.
              </p>
            </div>
            <ul className={styles.expertiseList}>
              {expertise.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.culture}>
        <div className="container">
          <div className={styles.cultureGrid}>
            <div className={styles.cultureImage}>
              <img
                src="https://picsum.photos/800/600?random=52"
                alt="Совместная работа команды Компания"
                loading="lazy"
              />
            </div>
            <div className={styles.cultureContent}>
              <h2>Культура и развитие</h2>
              <p>
                Мы учимся вместе с клиентами: проводим ретроспективы, внутренние конференции,
                настраиваем обмен знаниями и поддерживаем развитие специалистов через менторство и
                проектную ротацию.
              </p>
              <ul>
                <li>Корпоративная академия и программы наставничества</li>
                <li>Обязательная рефлексия после каждого проекта</li>
                <li>Клуб практиков по направлениям</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  </>
);

export default AboutPage;