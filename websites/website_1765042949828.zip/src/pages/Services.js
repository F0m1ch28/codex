import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const servicesCatalog = [
  {
    title: 'Стратегия роста и бизнес-модели',
    description:
      'Проводим стратегические сессии, формируем карту возможностей, выстраиваем систему OKR и управляем портфелем инициатив.',
    details: [
      'Рынок и конкурентный анализ',
      'Бизнес-модель и финансовые сценарии',
      'Управление портфелем проектов',
      'Создание системы OKR и KPI',
    ],
    image: 'https://picsum.photos/1000/700?random=61',
  },
  {
    title: 'Цифровые продукты и технологические решения',
    description:
      'Помогаем оценить текущий ландшафт систем, разработать архитектуру, внедрить продукты и выстроить работу продуктовых команд.',
    details: [
      'Аудит ИТ-ландшафта',
      'Создание продуктовой стратегии',
      'Внедрение платформ и интеграция',
      'Поддержка продуктовых команд',
    ],
    image: 'https://picsum.photos/1000/700?random=62',
  },
  {
    title: 'Аналитика и управление данными',
    description:
      'Формируем целевую модель данных, строим BI-решения, развиваем культуру принятия решений на основе аналитики.',
    details: [
      'Data Strategy и governance',
      'BI-платформы и визуализация',
      'Автоматизация отчётности',
      'Центр компетенций по аналитике',
    ],
    image: 'https://picsum.photos/1000/700?random=63',
  },
  {
    title: 'Клиентский опыт и сервисные процессы',
    description:
      'Создаем непрерывный клиентский путь, повышаем уровень сервиса и внедряем инструменты обратной связи и NPS.',
    details: [
      'Карта клиентского пути',
      'Сервисный дизайн и сценарии',
      'NPS и VOC программы',
      'Внедрение сервисных стандартов',
    ],
    image: 'https://picsum.photos/1000/700?random=64',
  },
  {
    title: 'Изменения и развитие команд',
    description:
      'Разрабатываем программы развития, выстраиваем коммуникации, помогаем лидерам и командам адаптироваться к изменениям.',
    details: [
      'Change management',
      'Программы обучения и воркшопы',
      'HR-аналитика и развитие компетенций',
      'Коммуникационная стратегия изменений',
    ],
    image: 'https://picsum.photos/1000/700?random=65',
  },
];

const ServicesPage = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Seo
        title="Услуги"
        description="Команда Компания предлагает стратегические и технологические услуги: разработка стратегии, внедрение цифровых решений, аналитика, клиентский опыт и управление изменениями."
        keywords="услуги, стратегия, цифровые решения, аналитика, изменения"
      />
      <div className={styles.page}>
        <section className={styles.hero}>
          <div className="container">
            <div className={styles.heroContent}>
              <h1>Мы создаём решения, которые работают в реальности</h1>
              <p>
                Каждая услуга — это набор проверенных практик, адаптированных под вашу отрасль и
                амбиции. Мы погружаемся в детали, чтобы предложить путь с понятными результатами на
                каждом этапе.
              </p>
            </div>
          </div>
        </section>

        <section className={styles.catalog}>
          <div className="container">
            <div className={styles.catalogWrapper}>
              <div className={styles.catalogMenu} role="tablist" aria-label="Категории услуг">
                {servicesCatalog.map((service, index) => (
                  <button
                    key={service.title}
                    type="button"
                    className={`${styles.catalogButton} ${
                      activeIndex === index ? styles.catalogButtonActive : ''
                    }`}
                    onClick={() => setActiveIndex(index)}
                    role="tab"
                    aria-selected={activeIndex === index}
                  >
                    <span>{service.title}</span>
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      aria-hidden="true"
                    >
                      <path
                        d="M7.5 5L12.5 10L7.5 15"
                        stroke="currentColor"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </button>
                ))}
              </div>

              <div className={styles.catalogDetails}>
                {servicesCatalog.map((service, index) => (
                  <article
                    key={service.title}
                    className={`${styles.detailCard} ${
                      activeIndex === index ? styles.detailCardVisible : styles.detailCardHidden
                    }`}
                    role="tabpanel"
                    aria-hidden={activeIndex !== index}
                  >
                    <div className={styles.detailImage}>
                      <img src={service.image} alt={service.title} loading="lazy" />
                    </div>
                    <div className={styles.detailContent}>
                      <h2>{service.title}</h2>
                      <p>{service.description}</p>
                      <ul>
                        {service.details.map((item) => (
                          <li key={item}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className={styles.approach}>
          <div className="container">
            <div className={styles.approachGrid}>
              <div className={styles.approachCard}>
                <h3>Делаем вместе</h3>
                <p>
                  Интегрируемся в контекст, работаем рядом с вашими командами и передаём экспертизу,
                  чтобы изменения закрепились внутри организации.
                </p>
              </div>
              <div className={styles.approachCard}>
                <h3>Фокус на эффект</h3>
                <p>
                  На старте фиксируем целевые бизнес-метрики, строим систему отслеживания результата и
                  держим вас в курсе на каждом этапе.
                </p>
              </div>
              <div className={styles.approachCard}>
                <h3>Гибкость и скорость</h3>
                <p>
                  Применяем agile-подходы, быстро тестируем гипотезы, подключаем нужные ресурсы и
                  фиксируем выводы в базе знаний.
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ServicesPage;