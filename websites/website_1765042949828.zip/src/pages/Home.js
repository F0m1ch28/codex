import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const statsInfo = [
  { label: 'Лет на рынке', value: 12, suffix: '+' },
  { label: 'Реализованных проектов', value: 480, suffix: '+' },
  { label: 'Постоянных клиентов', value: 92, suffix: '' },
  { label: 'Уровень удовлетворенности', value: 98, suffix: '%' },
];

const servicesHighlights = [
  {
    title: 'Стратегическое консультирование',
    description:
      'Мы помогаем сформировать четкий план роста, протестировать гипотезы и выстроить систему принятия решений на основе данных.',
    icon: '🧭',
  },
  {
    title: 'Цифровая трансформация',
    description:
      'Внедряем современные технологические решения, оптимизируем процессы и интегрируем платформы, чтобы усилить вашу команду.',
    icon: '⚙️',
  },
  {
    title: 'Аналитика и BI',
    description:
      'Строим прозрачные модели отчетности, формируем единое информационное поле и превращаем данные в действенные инсайты.',
    icon: '📊',
  },
  {
    title: 'Управление изменениями',
    description:
      'Сопровождаем организационные изменения, обучаем команды и создаем среду, в которой инновации становятся нормой.',
    icon: '🚀',
  },
];

const advantagesList = [
  {
    title: 'Фокус на результате',
    text: 'Мы измеряем успех через достижение конкретных бизнес-целей и прозрачные метрики.',
  },
  {
    title: 'Команда экспертов',
    text: 'На проектах работают практики из отрасли с опытом внедрений в компаниях разного масштаба.',
  },
  {
    title: 'Партнерский подход',
    text: 'Строим долгосрочные отношения и разделяем ответственность за общий успех.',
  },
  {
    title: 'Гибкие форматы работы',
    text: 'Адаптируемся под ваши процессы, комбинируем команду in-house и внешних специалистов.',
  },
];

const processSteps = [
  {
    title: 'Диагностика и интервью',
    text: 'Проводим углублённые интервью с ключевыми стейкхолдерами и собираем исходные данные.',
  },
  {
    title: 'Проектирование решения',
    text: 'Формируем гипотезы, оцениваем влияние и создаем дорожную карту трансформации.',
  },
  {
    title: 'Запуск и пилотирование',
    text: 'Запускаем пилотные инициативы, быстро тестируем решения и фиксируем лучшие практики.',
  },
  {
    title: 'Масштабирование',
    text: 'Расширяем успешные изменения на все подразделения, обучаем команды и создаем систему управления.',
  },
  {
    title: 'Поддержка и рост',
    text: 'Остаёмся рядом, чтобы отслеживать результаты и развивать новую культуру работы.',
  },
];

const testimonialsList = [
  {
    quote:
      'Команда Компания помогла нам выстроить систему продуктовой аналитики и ускорить вывод обновлений. Сейчас мы принимаем решения быстрее и увереннее.',
    name: 'Екатерина Соколова',
    position: 'Руководитель цифровых продуктов',
    company: 'FinTech Solutions',
  },
  {
    quote:
      'С их поддержкой мы перезапустили стратегический портфель проектов, оптимизировали процессы и укрепили командные роли.',
    name: 'Андрей Петров',
    position: 'Директор по развитию',
    company: 'Инновационные Сервисы',
  },
  {
    quote:
      'Компания включилась в наш проект как партнер. Вместе мы переработали операционную модель и заложили фундамент для глобального роста.',
    name: 'Мария Иванова',
    position: 'Генеральный директор',
    company: 'Retail&Co',
  },
];

const teamPreview = [
  {
    name: 'Алексей Корнеев',
    role: 'Партнер по стратегии',
    bio: '15 лет руководит программами трансформации в телеком и финансовом секторе.',
    image: 'https://picsum.photos/400/400?random=11',
  },
  {
    name: 'Наталья Орлова',
    role: 'Директор по аналитике',
    bio: 'Специализируется на построении BI-экосистем и внедрении data-driven подхода.',
    image: 'https://picsum.photos/400/400?random=12',
  },
  {
    name: 'Дмитрий Чернов',
    role: 'Руководитель цифровых решений',
    bio: 'Отвечает за интеграцию технологий, платформ и автоматизацию процессов.',
    image: 'https://picsum.photos/400/400?random=13',
  },
];

const projectPortfolio = [
  {
    title: 'Переосмысление клиентского пути',
    category: 'Маркетинг',
    description:
      'Создали единую систему коммуникаций с клиентами, внедрили персонализацию и повысили NPS на 18 пунктов.',
    image: 'https://picsum.photos/1200/800?random=21',
    tags: ['CX', 'CRM', 'NPS'],
  },
  {
    title: 'Цифровой запуск нового направления',
    category: 'Технологии',
    description:
      'С нуля спроектировали цифровую платформу, внедрили Agile-практики и построили продуктовую команду.',
    image: 'https://picsum.photos/1200/800?random=22',
    tags: ['Agile', 'Product', 'MVP'],
  },
  {
    title: 'Аналитический центр принятия решений',
    category: 'Аналитика',
    description:
      'Сформировали BI-ландшафт, автоматизировали отчётность и внедрили единую витрину данных.',
    image: 'https://picsum.photos/1200/800?random=23',
    tags: ['BI', 'DataOps', 'Automation'],
  },
  {
    title: 'Трансформация операционной модели',
    category: 'Стратегия',
    description:
      'Перестроили процессы, внедрили KPI и систему развития компетенций, повысив эффективность на 27%.',
    image: 'https://picsum.photos/1200/800?random=24',
    tags: ['Lean', 'Оргструктура', 'KPI'],
  },
];

const faqList = [
  {
    question: 'С чего начинается работа с вашей командой?',
    answer:
      'Мы начинаем с фокус-сессии и экспресс-диагностики, чтобы понять контекст, цели и ограничения. После этого предлагаем дорожную карту с приоритетами и быстрыми победами.',
  },
  {
    question: 'Как формируется проектная команда?',
    answer:
      'Мы собираем гибридную команду из экспертов Компания и вашей стороны. Назначаем единый центр ответственности и настраиваем регулярные координации.',
  },
  {
    question: 'Можете ли вы подключаться точечно?',
    answer:
      'Да, мы работаем как с крупными трансформациями, так и с точечными задачами: аудит процессов, запуск пилота, разработка стратегии или наставничество для команд.',
  },
  {
    question: 'Как оцениваете эффективность проектов?',
    answer:
      'Перед стартом фиксируем метрики успеха и ожидаемый эффект. В ходе работы проводим регулярные срезы и корректируем план, чтобы результат был измеримым и устойчивым.',
  },
];

const blogPosts = [
  {
    title: 'Пять шагов к устойчивой цифровой трансформации',
    excerpt:
      'Разбираем, как удержать баланс между технологиями, людьми и операционной гибкостью, чтобы изменения укоренились.',
    date: '12 марта 2024',
    readingTime: '6 минут чтения',
    image: 'https://picsum.photos/800/600?random=31',
    link: '/uslugi',
  },
  {
    title: 'Как данные помогают управлять продуктовым портфелем',
    excerpt:
      'Рассказываем, как настроить цикл принятия решений на основе данных и вовлечь команды в использование аналитики.',
    date: '28 февраля 2024',
    readingTime: '5 минут чтения',
    image: 'https://picsum.photos/800/600?random=32',
    link: '/o-kompanii',
  },
  {
    title: 'Новый взгляд на клиентский опыт в b2b',
    excerpt:
      'Поделились практическими инструментами, которые помогают выстроить персональный сервис и измерить удовлетворенность.',
    date: '8 февраля 2024',
    readingTime: '7 минут чтения',
    image: 'https://picsum.photos/800/600?random=33',
    link: '/kontakty',
  },
];

const HomePage = () => {
  const [animatedStats, setAnimatedStats] = useState(statsInfo.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [openFaqIndex, setOpenFaqIndex] = useState(null);

  useEffect(() => {
    let frame = 0;
    const duration = 1200;
    const intervalTime = 32;
    const totalFrames = Math.round(duration / intervalTime);
    const intervals = statsInfo.map((stat) => stat.value / totalFrames);

    const interval = setInterval(() => {
      frame += 1;
      setAnimatedStats((prev) =>
        prev.map((value, index) => {
          const nextValue = value + intervals[index];
          return frame >= totalFrames ? statsInfo[index].value : nextValue;
        })
      );
      if (frame >= totalFrames) {
        clearInterval(interval);
      }
    }, intervalTime);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonialsList.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handlePrevTestimonial = () => {
    setTestimonialIndex((prev) =>
      prev === 0 ? testimonialsList.length - 1 : prev - 1
    );
  };

  const handleNextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % testimonialsList.length);
  };

  const categories = ['Все', 'Стратегия', 'Технологии', 'Маркетинг', 'Аналитика'];
  const filteredProjects =
    selectedCategory === 'Все'
      ? projectPortfolio
      : projectPortfolio.filter((project) => project.category === selectedCategory);

  const toggleFaq = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Seo
        title="Главная"
        description="Компания — стратегический партнер для бизнеса. Разрабатываем стратегии, внедряем технологии и помогаем командам достигать устойчивых результатов."
        keywords="консалтинг, цифровая трансформация, аналитика, стратегия, Компания"
      />
      <div className={styles.page}>
        <section
          className={styles.hero}
          style={{
            backgroundImage:
              'linear-gradient(120deg, rgba(15, 23, 42, 0.75), rgba(37, 99, 235, 0.65)), url("https://picsum.photos/1600/900?random=1")',
          }}
        >
          <div className="container">
            <div className={styles.heroContent}>
              <p className={styles.heroLabel}>Стратегия. Технологии. Люди.</p>
              <h1 className={styles.heroTitle}>
                Партнер, который помогает бизнесу уверенно расти и создавать ценность для клиентов
              </h1>
              <p className={styles.heroSubtitle}>
                Мы соединяем стратегическое видение, цифровую экспертизу и гибкие процессы, чтобы
                запускать изменения и закреплять результат на уровне всей организации.
              </p>
              <div className={styles.heroActions}>
                <Link to="/kontakty" className={styles.ctaButton}>
                  Запланировать встречу
                </Link>
                <Link to="/uslugi" className={styles.secondaryButton}>
                  Посмотреть услуги
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className={styles.stats}>
          <div className="container">
            <div className={styles.statsGrid} role="list">
              {statsInfo.map((stat, index) => (
                <div key={stat.label} className={styles.statCard} role="listitem">
                  <p className={styles.statValue}>
                    {Math.round(animatedStats[index])}
                    <span className={styles.statSuffix}>{stat.suffix}</span>
                  </p>
                  <p className={styles.statLabel}>{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.aboutPreview}>
          <div className="container">
            <div className={styles.aboutGrid}>
              <div>
                <h2 className={styles.sectionTitle}>Компания — команда, которая идёт рядом</h2>
                <p className={styles.sectionSubtitle}>
                  Мы помогаем организациям реализовывать потенциал: наводим порядок в процессах,
                  внедряем технологии, выращиваем команды и управляем изменениями без стресса.
                </p>
                <Link to="/o-kompanii" className={styles.linkButton}>
                  Узнать о нас
                </Link>
              </div>
              <div className={styles.aboutCard}>
                <h3>Миссия</h3>
                <p>
                  Ускорять развитие компаний через грамотную стратегию, технологичность и уважение к
                  людям, которые создают продукт каждый день.
                </p>
                <div className={styles.aboutPoints}>
                  <span>Прозрачные процессы</span>
                  <span>Командная работа</span>
                  <span>Обучение и развитие</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className={styles.services}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Ключевые услуги</h2>
              <p className={styles.sectionSubtitle}>
                Выбираем оптимальную комбинацию инструментов, чтобы совместно добиться значимых
                результатов и быстро показать ценность для бизнеса.
              </p>
            </div>

            <div className={styles.serviceGrid}>
              {servicesHighlights.map((service) => (
                <article key={service.title} className={styles.serviceCard}>
                  <div className={styles.serviceIcon} aria-hidden="true">
                    {service.icon}
                  </div>
                  <h3 className={styles.serviceTitle}>{service.title}</h3>
                  <p className={styles.serviceText}>{service.description}</p>
                  <Link to="/uslugi" className={styles.serviceLink}>
                    Подробнее
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.advantages}>
          <div className="container">
            <div className={styles.sectionHeaderCompact}>
              <h2 className={styles.sectionTitle}>Почему выбирают нас</h2>
              <p className={styles.sectionSubtitle}>
                Работаем прозрачно, синхронизируем цели и создаем решения, которые продолжают
                работать и после завершения проекта.
              </p>
            </div>
            <div className={styles.advantagesGrid}>
              {advantagesList.map((advantage) => (
                <div key={advantage.title} className={styles.advantageCard}>
                  <h3 className={styles.advantageTitle}>{advantage.title}</h3>
                  <p className={styles.advantageText}>{advantage.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.process}>
          <div className="container">
            <div className={styles.processHeader}>
              <h2 className={styles.sectionTitle}>Как мы работаем</h2>
              <p className={styles.sectionSubtitle}>
                У каждой трансформации есть ясные шаги. Мы сопровождаем команду на каждом этапе и
                сохраняем прозрачность в коммуникации.
              </p>
            </div>
            <div className={styles.processTimeline}>
              {processSteps.map((step, index) => (
                <div key={step.title} className={styles.processStep}>
                  <span className={styles.processIndex}>{index + 1}</span>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.testimonials} aria-label="Отзывы клиентов">
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Отзывы партнеров</h2>
              <p className={styles.sectionSubtitle}>
                Команда Компания становится продолжением вашей команды, поэтому мы дорожим
                доверительными отношениями и честной обратной связью.
              </p>
            </div>
            <div className={styles.testimonialWrapper} role="region" aria-live="polite">
              <div className={styles.testimonialCard}>
                <p className={styles.testimonialQuote}>
                  «{testimonialsList[testimonialIndex].quote}»
                </p>
                <div className={styles.testimonialAuthor}>
                  <p className={styles.testimonialName}>
                    {testimonialsList[testimonialIndex].name}
                  </p>
                  <p className={styles.testimonialRole}>
                    {testimonialsList[testimonialIndex].position} ·{' '}
                    {testimonialsList[testimonialIndex].company}
                  </p>
                </div>
              </div>
              <div className={styles.testimonialControls}>
                <button
                  type="button"
                  onClick={handlePrevTestimonial}
                  className={styles.testimonialButton}
                  aria-label="Предыдущий отзыв"
                >
                  ←
                </button>
                <button
                  type="button"
                  onClick={handleNextTestimonial}
                  className={styles.testimonialButton}
                  aria-label="Следующий отзыв"
                >
                  →
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className={styles.team}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Команда лидеров направления</h2>
              <p className={styles.sectionSubtitle}>
                Узкая специализация и опыт в разных отраслях позволяют нам собирать команды под
                конкретную задачу.
              </p>
            </div>
            <div className={styles.teamGrid}>
              {teamPreview.map((member) => (
                <article key={member.name} className={styles.teamCard}>
                  <div className={styles.teamImageWrapper}>
                    <img src={member.image} alt={member.name} loading="lazy" />
                  </div>
                  <div className={styles.teamInfo}>
                    <h3>{member.name}</h3>
                    <p className={styles.teamRole}>{member.role}</p>
                    <p className={styles.teamBio}>{member.bio}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.projects}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Проекты</h2>
              <p className={styles.sectionSubtitle}>
                Делимся примерами, где компания помогла сформировать стратегию, внедрить продукты и
                улучшить клиентский опыт.
              </p>
            </div>
            <div className={styles.filterGroup} role="tablist" aria-label="Фильтр проектов">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`${styles.filterButton} ${
                    selectedCategory === category ? styles.filterButtonActive : ''
                  }`}
                  onClick={() => setSelectedCategory(category)}
                  role="tab"
                  aria-selected={selectedCategory === category}
                >
                  {category}
                </button>
              ))}
            </div>
            <div className={styles.projectGrid}>
              {filteredProjects.map((project) => (
                <article key={project.title} className={styles.projectCard}>
                  <div className={styles.projectImageWrapper}>
                    <img
                      src={project.image}
                      alt={`Проект: ${project.title}`}
                      loading="lazy"
                    />
                    <span className={styles.projectCategory}>{project.category}</span>
                  </div>
                  <div className={styles.projectBody}>
                    <h3>{project.title}</h3>
                    <p>{project.description}</p>
                    <div className={styles.projectTags}>
                      {project.tags.map((tag) => (
                        <span key={tag}>{tag}</span>
                      ))}
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.faq}>
          <div className="container">
            <div className={styles.sectionHeaderCompact}>
              <h2 className={styles.sectionTitle}>Частые вопросы</h2>
              <p className={styles.sectionSubtitle}>
                Если не нашли ответ — напишите нам, и мы подготовим решение именно под ваш контекст.
              </p>
            </div>
            <div className={styles.faqList}>
              {faqList.map((item, index) => (
                <div
                  key={item.question}
                  className={`${styles.faqItem} ${
                    openFaqIndex === index ? styles.faqItemOpen : ''
                  }`}
                >
                  <button
                    type="button"
                    className={styles.faqQuestion}
                    onClick={() => toggleFaq(index)}
                    aria-expanded={openFaqIndex === index}
                  >
                    {item.question}
                    <span aria-hidden="true">{openFaqIndex === index ? '−' : '+'}</span>
                  </button>
                  <div
                    className={styles.faqAnswer}
                    role="region"
                    hidden={openFaqIndex !== index}
                  >
                    <p>{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.blog}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Свежие материалы</h2>
              <p className={styles.sectionSubtitle}>
                Делимся опытом, инсайтами и практиками, которые помогают лидерам быстро ориентироваться
                в изменениях.
              </p>
            </div>
            <div className={styles.blogGrid}>
              {blogPosts.map((post) => (
                <article key={post.title} className={styles.blogCard}>
                  <div className={styles.blogImageWrapper}>
                    <img src={post.image} alt={post.title} loading="lazy" />
                  </div>
                  <div className={styles.blogBody}>
                    <p className={styles.blogMeta}>
                      {post.date} · {post.readingTime}
                    </p>
                    <h3>{post.title}</h3>
                    <p>{post.excerpt}</p>
                    <Link to={post.link} className={styles.blogLink}>
                      Читать далее
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.ctaSection}>
          <div className="container">
            <div className={styles.ctaInner}>
              <div>
                <h2>Готовы обсудить задачу?</h2>
                <p>
                  Расскажите о цели и текущем контексте — мы подготовим варианты сотрудничества и
                  предложим первый шаг, который даст результат уже в ближайший месяц.
                </p>
              </div>
              <div className={styles.ctaActions}>
                <Link to="/kontakty" className={styles.ctaButtonLight}>
                  Оставить заявку
                </Link>
                <a href="tel:+74951234567" className={styles.ctaPhone}>
                  Позвонить: +7 (495) 123-45-67
                </a>
              </div>
            </div>
          </div>
        </section>

        <section className={styles.miniContacts}>
          <div className="container">
            <div className={styles.miniCard}>
              <h3>Контакты</h3>
              <p>г. Москва, ул. Примерная, д. 1, офис 101</p>
              <p>Пн-Пт: 9:00-18:00, Сб-Вс: выходной</p>
              <div className={styles.contactLinks}>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                <a href="mailto:info@kompaniya.ru">info@kompaniya.ru</a>
              </div>
            </div>
            <div className={styles.miniCard}>
              <h3>Хотите презентацию?</h3>
              <p>
                Подготовим кастомную презентацию под вашу отрасль и поделимся примерами проектов с
                похожими задачами.
              </p>
              <Link to="/kontakty" className={styles.linkButton}>
                Запросить материалы
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;