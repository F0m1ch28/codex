import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contacts.module.css';

const ContactsPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Введите имя';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email.trim())) {
      newErrors.email = 'Введите корректный email';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Опишите задачу';
    }
    if (formData.phone && !/^[\d+()\s-]+$/.test(formData.phone)) {
      newErrors.phone = 'Введите корректный телефон';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData({
      name: '',
      company: '',
      email: '',
      phone: '',
      message: '',
    });
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <>
      <Seo
        title="Контакты"
        description="Свяжитесь с командой Компания: г. Москва, ул. Примерная, д. 1, офис 101. Телефон +7 (495) 123-45-67, email info@kompaniya.ru, график Пн-Пт 9:00-18:00."
        keywords="контакты, Компания, телефон, адрес, email"
      />
      <div className={styles.page}>
        <section className={styles.details}>
          <div className="container">
            <div className={styles.detailsGrid}>
              <div className={styles.card}>
                <h1>Давайте обсудим вашу задачу</h1>
                <p>
                  Расскажите о проекте и текущем контексте — мы свяжемся в течение одного рабочего дня
                  и предложим план дальнейших шагов.
                </p>

                <div className={styles.infoBlocks}>
                  <div>
                    <h3>Офис</h3>
                    <p>г. Москва, ул. Примерная, д. 1, офис 101</p>
                  </div>
                  <div>
                    <h3>Связаться</h3>
                    <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                    <a href="mailto:info@kompaniya.ru">info@kompaniya.ru</a>
                  </div>
                  <div>
                    <h3>Часы работы</h3>
                    <p>Пн-Пт: 9:00-18:00</p>
                    <p>Сб-Вс: выходной</p>
                  </div>
                </div>
              </div>

              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <div className={styles.field}>
                  <label htmlFor="name">Имя *</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="Как к вам обращаться?"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={!!errors.name}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                  />
                  {errors.name && <span id="name-error">{errors.name}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="company">Компания</label>
                  <input
                    id="company"
                    name="company"
                    type="text"
                    placeholder="Название вашей компании"
                    value={formData.company}
                    onChange={handleChange}
                  />
                </div>

                <div className={styles.field}>
                  <label htmlFor="email">Email *</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="example@company.ru"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={!!errors.email}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                  />
                  {errors.email && <span id="email-error">{errors.email}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="phone">Телефон</label>
                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="+7 (___) ___-__-__"
                    value={formData.phone}
                    onChange={handleChange}
                    aria-invalid={!!errors.phone}
                    aria-describedby={errors.phone ? 'phone-error' : undefined}
                  />
                  {errors.phone && <span id="phone-error">{errors.phone}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="message">Опишите задачу *</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    placeholder="Какая цель, какие сроки, что важно учесть?"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={!!errors.message}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                  />
                  {errors.message && <span id="message-error">{errors.message}</span>}
                </div>

                <button type="submit" className={styles.submit}>
                  Отправить запрос
                </button>

                {submitted && (
                  <div role="status" className={styles.success}>
                    Спасибо! Мы получили ваше сообщение и свяжемся в ближайшее время.
                  </div>
                )}
              </form>
            </div>
          </div>
        </section>

        <section className={styles.mapSection} aria-label="Карта расположения офиса">
          <div className="container">
            <div className={styles.mapWrapper}>
              <iframe
                title="Офис Компания на карте"
                src="https://yandex.ru/map-widget/v1/?um=constructor%3A0a7c21b38cd7df97c8d0b5c6f357f7ab97406a1e355d9c0305e0a82f1b0df6da&amp;source=constructor"
                width="100%"
                height="360"
                frameBorder="0"
                loading="lazy"
              />
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ContactsPage;