import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (consent !== 'accepted') {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('cookieConsent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div
      className={styles.banner}
      role="dialog"
      aria-live="polite"
      aria-label="Информация об использовании cookie"
    >
      <div className={styles.text}>
        Используя этот сайт, вы соглашаетесь с тем, что мы применяем cookie и похожие технологии для
        аналитики и улучшения пользовательского опыта.
      </div>
      <div className={styles.actions}>
        <NavLink to="/politika-cookie" className={styles.more}>
          Подробнее
        </NavLink>
        <button type="button" className={styles.accept} onClick={handleAccept}>
          Согласен
        </button>
        <button type="button" className={styles.decline} onClick={handleDecline}>
          Отказать
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;