import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <div className={styles.logo}>Компания</div>
          <p className={styles.tagline}>
            Мы объединяем стратегию, технологии и человеческий подход, чтобы создавать измеримый
            результат и устойчивый рост бизнеса.
          </p>
        </div>

        <div className={styles.column}>
          <h3 className={styles.title}>Меню</h3>
          <ul className={styles.list}>
            <li>
              <NavLink to="/" className={styles.link}>
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink to="/o-kompanii" className={styles.link}>
                О компании
              </NavLink>
            </li>
            <li>
              <NavLink to="/uslugi" className={styles.link}>
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink to="/kontakty" className={styles.link}>
                Контакты
              </NavLink>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.title}>Документы</h3>
          <ul className={styles.list}>
            <li>
              <NavLink to="/politika-konfidencialnosti" className={styles.link}>
                Политика конфиденциальности
              </NavLink>
            </li>
            <li>
              <NavLink to="/usloviya-ispolzovaniya" className={styles.link}>
                Условия использования
              </NavLink>
            </li>
            <li>
              <NavLink to="/politika-cookie" className={styles.link}>
                Политика использования cookie
              </NavLink>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.title}>Контакты</h3>
          <p className={styles.contact}>
            г. Москва, ул. Примерная, д. 1, офис 101
            <br />
            Пн-Пт: 9:00-18:00
          </p>
          <a className={styles.link} href="tel:+74951234567">
            +7 (495) 123-45-67
          </a>
          <a className={styles.link} href="mailto:info@kompaniya.ru">
            info@kompaniya.ru
          </a>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Компания. Все права защищены.</p>
        <p className={styles.madeWith}>
          Создано с вниманием к людям и технологиям.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;