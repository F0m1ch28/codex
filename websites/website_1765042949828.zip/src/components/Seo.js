import { useEffect } from 'react';

const Seo = ({ title = '', description = '', keywords = '' }) => {
  useEffect(() => {
    const siteName = 'Компания';
    const defaultTitle = `${siteName} — ваш партнер в развитии бизнеса`;
    const computedTitle = title ? `${title} | ${siteName}` : defaultTitle;
    const defaultDescription =
      'Компания разрабатывает стратегические, цифровые и операционные решения, которые помогают бизнесу расти и работать устойчиво.';
    const metaDescription = description || defaultDescription;
    const metaKeywords =
      keywords ||
      'Компания, бизнес, стратегия, цифровая трансформация, консалтинг, развитие бизнеса';

    document.title = computedTitle;

    const updateMetaTag = (selector, attrName, attrValue) => {
      let element = document.head.querySelector(selector);
      if (!element) {
        element = document.createElement('meta');
        if (attrName === 'name') {
          element.name = attrValue;
        } else {
          element.setAttribute('property', attrValue);
        }
        document.head.appendChild(element);
      }
      element.setAttribute('content', attrValue === 'og:type' ? 'website' : '');
    };

    const setMetaContent = (nameOrProperty, value, isProperty = false) => {
      const selector = isProperty
        ? `meta[property="${nameOrProperty}"]`
        : `meta[name="${nameOrProperty}"]`;
      let element = document.head.querySelector(selector);
      if (!element) {
        element = document.createElement('meta');
        if (isProperty) {
          element.setAttribute('property', nameOrProperty);
        } else {
          element.setAttribute('name', nameOrProperty);
        }
        document.head.appendChild(element);
      }
      element.setAttribute('content', value);
    };

    setMetaContent('description', metaDescription);
    setMetaContent('keywords', metaKeywords);
    setMetaContent('og:title', computedTitle, true);
    setMetaContent('og:description', metaDescription, true);
    setMetaContent('og:site_name', siteName, true);
    setMetaContent('og:type', 'website', true);
    setMetaContent('og:locale', 'ru_RU', true);
  }, [title, description, keywords]);

  return null;
};

export default Seo;