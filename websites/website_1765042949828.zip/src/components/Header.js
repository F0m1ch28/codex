import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Главная' },
  { path: '/o-kompanii', label: 'О компании' },
  { path: '/uslugi', label: 'Услуги' },
  { path: '/kontakty', label: 'Контакты' },
];

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isMenuOpen ? 'hidden' : '';
  }, [isMenuOpen]);

  const handleToggleMenu = () => setIsMenuOpen((prev) => !prev);
  const handleCloseMenu = () => setIsMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} aria-label="Компания — переход на главную">
            Компания
          </NavLink>

          <nav
            className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`}
            aria-label="Основная навигация"
          >
            {navLinks.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.path === '/'}
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={handleCloseMenu}
              >
                {item.label}
              </NavLink>
            ))}
            <NavLink
              to="/kontakty"
              className={styles.contactButton}
              onClick={handleCloseMenu}
            >
              Связаться
            </NavLink>
          </nav>

          <button
            type="button"
            className={`${styles.burger} ${isMenuOpen ? styles.burgerActive : ''}`}
            onClick={handleToggleMenu}
            aria-label="Переключить навигацию"
            aria-expanded={isMenuOpen}
            aria-controls="navigation-menu"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;