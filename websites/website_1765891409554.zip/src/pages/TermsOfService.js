import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

const TermsOfServicePage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Service | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Review the TalentScope Diagnostics terms of service outlining website usage rules, intellectual property, and liability limitations."
      />
      <meta
        name="keywords"
        content="terms of service, TalentScope Diagnostics terms, workforce diagnostics terms"
      />
      <meta property="og:title" content="Terms of Service | TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Terms governing access and use of TalentScope Diagnostics services and website."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <h1>Terms of Service</h1>
    <p className={styles.effectiveDate}>Effective date: January 1, 2024</p>

    <section>
      <h2>1. Acceptance of terms</h2>
      <p>
        By accessing the TalentScope Diagnostics website or engaging our services, you agree to these Terms of Service and any
        accompanying documents referenced herein. If you do not agree, please discontinue use of our site.
      </p>
    </section>

    <section>
      <h2>2. Services</h2>
      <p>
        Workforce diagnostics, analytics, and advisory services are provided according to written agreements between TalentScope
        Diagnostics and each client. These terms govern website usage and general obligations unless superseded by a specific
        contract.
      </p>
    </section>

    <section>
      <h2>3. Intellectual property</h2>
      <p>
        All content on this website, including text, graphics, and designs, is the property of TalentScope Diagnostics or our
        licensors. You may view the content for informational purposes but may not reproduce or distribute it without written
        permission.
      </p>
    </section>

    <section>
      <h2>4. User responsibilities</h2>
      <p>
        Users must access the website in compliance with applicable laws. You agree not to attempt unauthorized access to
        systems, interfere with website functionality, or misuse content provided on the site.
      </p>
    </section>

    <section>
      <h2>5. Confidentiality</h2>
      <p>
        Information shared with us through the contact form or during service engagements will be handled in accordance with our
        Privacy Policy and contractual obligations.
      </p>
    </section>

    <section>
      <h2>6. Disclaimer</h2>
      <p>
        The website is provided on an informational basis. While we strive to ensure accuracy, content may not always reflect
        the latest developments. We are not liable for decisions made based solely on website information without consulting us
        directly.
      </p>
    </section>

    <section>
      <h2>7. Limitation of liability</h2>
      <p>
        To the extent permitted by law, TalentScope Diagnostics shall not be liable for any indirect, incidental, special, or
        consequential damages arising from use of the website or services unless otherwise specified in a written agreement.
      </p>
    </section>

    <section>
      <h2>8. Governing law</h2>
      <p>
        These Terms of Service are governed by the laws of the Province of Alberta and the laws of Canada applicable therein,
        without regard to conflicts of law principles.
      </p>
    </section>

    <section>
      <h2>9. Changes to terms</h2>
      <p>
        We may update these terms periodically. The current version will be posted on our website with the effective date. By
        continuing to use the site after changes are posted, you accept the updated terms.
      </p>
    </section>

    <section>
      <h2>10. Contact</h2>
      <p>
        For questions about these terms, contact TalentScope Diagnostics at 123 Scope St, Edmonton, AB T5J 3R8, Canada or call
        +1 780 555 7890.
      </p>
    </section>
  </div>
);

export default TermsOfServicePage;