import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const milestones = [
  { year: '2016', detail: 'Founded in Edmonton with a mission to unify workforce analytics for Canadian organizations.' },
  { year: '2018', detail: 'Launched diagnostic frameworks supporting bilingual training pathways across provinces.' },
  { year: '2020', detail: 'Expanded data engineering practice to integrate HRIS, LMS, and credentialing repositories securely.' },
  { year: '2022', detail: 'Introduced retention insight models combining sentiment analysis and mobility predictors.' },
  { year: '2023', detail: 'Scaled client collaboration hubs enabling real-time scenario planning with leadership teams.' },
];

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Learn about TalentScope Diagnostics, our mission, multidisciplinary team, and milestones in workforce development diagnostics across Canada."
      />
      <meta
        name="keywords"
        content="TalentScope Diagnostics, workforce analytics team, Canadian workforce diagnostics, training evaluation experts"
      />
      <meta property="og:title" content="About TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Discover the mission, team, and milestones of TalentScope Diagnostics in Canada."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <section className={styles.intro}>
      <h1>Our mission</h1>
      <p>
        TalentScope Diagnostics empowers Canadian organizations to understand their workforce through precise diagnostics,
        trustworthy data operations, and collaborative advisory support. We translate raw metrics into narratives that spark
        informed action, capture training momentum, and nurture sustainable employee retention.
      </p>
    </section>

    <section className={styles.values}>
      <div>
        <h2>Values in practice</h2>
        <p>
          We focus on clarity, accountability, and measurable progression. Every engagement starts by aligning diagnostic
          goals with organizational outcomes, ensuring stakeholders gain insight that informs policy, programming, and continuous
          improvement.
        </p>
      </div>
      <ul>
        <li>
          <h3>Transparency</h3>
          <p>Data lineage, methodology documentation, and repeatable processes build confidence among executive teams.</p>
        </li>
        <li>
          <h3>Collaboration</h3>
          <p>We embed alongside HR, L&amp;D, and operations groups to co-design strategies that reflect lived realities.</p>
        </li>
        <li>
          <h3>Reliability</h3>
          <p>Governed architecture and data validation ensure every insight is accurate, timely, and ready for stakeholder review.</p>
        </li>
      </ul>
    </section>

    <section className={styles.milestones}>
      <h2>Milestones</h2>
      <div className={styles.timeline}>
        {milestones.map((item) => (
          <article key={item.year}>
            <span>{item.year}</span>
            <p>{item.detail}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.team}>
      <h2>Leadership team</h2>
      <div className={styles.teamGrid}>
        <article>
          <img src="https://picsum.photos/420/420?random=51" alt="Laura Bennett, Founder" loading="lazy" />
          <h3>Laura Bennett</h3>
          <span>Founder &amp; Managing Director</span>
          <p>Guides strategic partnerships and ensures every diagnostic engagement translates into operational clarity.</p>
        </article>
        <article>
          <img src="https://picsum.photos/420/420?random=52" alt="Samuel Ip, Data Engineering Lead" loading="lazy" />
          <h3>Samuel Ip</h3>
          <span>Data Engineering Lead</span>
          <p>Architects ingestion pipelines, schema governance, and automation that support large-scale workforce datasets.</p>
        </article>
        <article>
          <img src="https://picsum.photos/420/420?random=53" alt="Gabrielle Pelletier, Client Advisory Lead" loading="lazy" />
          <h3>Gabrielle Pelletier</h3>
          <span>Client Advisory Lead</span>
          <p>Facilitates workshops, builds collaborative plans, and ensures stakeholders gain actionable understanding.</p>
        </article>
      </div>
    </section>
  </div>
);

export default AboutPage;