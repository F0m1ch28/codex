import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './ThankYou.module.css';

const ThankYouPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Thank You | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Thank you for contacting TalentScope Diagnostics. We will respond to your workforce diagnostics inquiry shortly."
      />
      <meta property="og:title" content="Thank You | TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="TalentScope Diagnostics has received your message."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <div className={styles.card}>
      <h1>Thank you for reaching out</h1>
      <p>
        Your message has been received. A member of the TalentScope Diagnostics team will respond to discuss your workforce
        objectives and schedule next steps.
      </p>
      <Link to="/" className={styles.button}>Return to Home</Link>
    </div>
  </div>
);

export default ThankYouPage;