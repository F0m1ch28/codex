import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Solutions.module.css';

const SolutionsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Solutions | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Discover TalentScope Diagnostics solutions including dashboards, scenario modelling, and workforce insight playbooks tailored for Canadian organizations."
      />
      <meta
        name="keywords"
        content="workforce dashboards, scenario modelling, retention insights, training analytics solutions"
      />
      <meta property="og:title" content="Solutions | TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Interactive dashboards and diagnostic playbooks that support workforce development across Canada."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <section className={styles.intro}>
      <h1>Solutions that connect analytics to action</h1>
      <p>
        Our solutions bring diagnostics to life through configurable dashboards, narrative playbooks, and activation
        toolkits. We prioritize clarity, interactivity, and secure data handling to support Canadian organizations of every size.
      </p>
    </section>

    <section className={styles.solutionsGrid}>
      <article>
        <img src="https://picsum.photos/900/600?random=71" alt="Interactive workforce insight dashboard" loading="lazy" />
        <h2>Insight Dashboards</h2>
        <p>
          Tailored dashboards display critical metrics such as capability readiness, training momentum, and retention signals.
          Visual layers allow leaders to explore organization-wide patterns, drill down by region, and track longitudinal change.
        </p>
        <ul>
          <li>Responsive layouts optimized for executive reviews.</li>
          <li>Role-based access controls protecting sensitive information.</li>
          <li>Exportable snapshots for board and council reporting.</li>
        </ul>
      </article>
      <article>
        <img src="https://picsum.photos/900/600?random=72" alt="Scenario modelling interface with charts" loading="lazy" />
        <h2>Scenario Modelling</h2>
        <p>
          Interactive models simulate workforce outcomes related to training adoption, certification progress, and retention
          initiatives. Scenario analyses assist in resourcing plans and confirm readiness for strategic programs.
        </p>
        <ul>
          <li>Adjustable assumptions reflecting recruitment, training, and attrition variables.</li>
          <li>Immediate visibility into impact on capability coverage and project timelines.</li>
          <li>Guidance notes to assist stakeholders when interpreting outcomes.</li>
        </ul>
      </article>
      <article>
        <img src="https://picsum.photos/900/600?random=73" alt="Diagnostic playbook being reviewed in meeting" loading="lazy" />
        <h2>Diagnostic Playbooks</h2>
        <p>
          Our playbooks convert analytics into initiatives with defined owners, milestones, and measurement checkpoints.
          They provide a shared reference for HR, learning, and operations teams implementing workforce strategies.
        </p>
        <ul>
          <li>Action plans with prioritized interventions and resource recommendations.</li>
          <li>Change management templates supporting communications and adoption.</li>
          <li>Measurement frameworks to track ongoing effectiveness.</li>
        </ul>
      </article>
    </section>
  </div>
);

export default SolutionsPage;