import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const ServicesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Services | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Explore TalentScope Diagnostics services including workforce development diagnostics, training needs analysis, and employee retention monitoring."
      />
      <meta
        name="keywords"
        content="development diagnostics, training needs analysis, retention monitoring, workforce services Canada"
      />
      <meta property="og:title" content="Services | TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Comprehensive workforce diagnostics and development services crafted for Canadian organizations."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <header className={styles.header}>
      <h1>Diagnostic services for focused workforce progress</h1>
      <p>
        Each service is engineered to convert complex workforce datasets into targeted recommendations. We assess capability,
        align learning, and monitor retention using transparent methodologies and collaborative delivery models.
      </p>
    </header>

    <section className={styles.serviceSection}>
      <div className={styles.serviceCard}>
        <img src="https://picsum.photos/800/560?random=61" alt="Workforce development diagnostics report on screen" loading="lazy" />
        <div className={styles.cardContent}>
          <h2>Workforce Development Diagnostics</h2>
          <p>
            We evaluate organizational capacity by combining skills inventories, project requirements, and competency frameworks.
            Our analyses highlight readiness for upcoming initiatives, succession planning opportunities, and cross-functional
            skill availability.
          </p>
          <ul>
            <li>Comprehensive capability mapping with proficiency scoring.</li>
            <li>Gap analysis between current skills and strategic priorities.</li>
            <li>Scenario modelling to test staffing configurations.</li>
          </ul>
        </div>
      </div>
      <div className={styles.serviceCard}>
        <img src="https://picsum.photos/800/560?random=62" alt="Training needs analysis workshop session" loading="lazy" />
        <div className={styles.cardContent}>
          <h2>Training Needs Analysis</h2>
          <p>
            Our analysts align learning programs with regulatory obligations and competency goals. We review course completion,
            credential pathways, and experiential learning to determine which initiatives accelerate performance.
          </p>
          <ul>
            <li>Learning activity audits and curriculum alignment.</li>
            <li>Recommendation matrices prioritizing training investments.</li>
            <li>Measurement frameworks tracking knowledge transfer and adoption.</li>
          </ul>
        </div>
      </div>
      <div className={styles.serviceCard}>
        <img src="https://picsum.photos/800/560?random=63" alt="Employee retention monitoring dashboard" loading="lazy" />
        <div className={styles.cardContent}>
          <h2>Employee Retention &amp; Growth Monitoring</h2>
          <p>
            We connect engagement indicators, internal mobility, and coaching outcomes to understand retention drivers. Customized
            dashboards highlight progression through development plans and flag early risk signals.
          </p>
          <ul>
            <li>Retention diagnostics integrating sentiment and performance markers.</li>
            <li>Mobility analytics showing pathways and transitions.</li>
            <li>Action plans for leadership, HR, and learning partners.</li>
          </ul>
        </div>
      </div>
    </section>
  </div>
);

export default ServicesPage;