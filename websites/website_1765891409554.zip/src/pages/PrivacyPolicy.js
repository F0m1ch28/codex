import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

const PrivacyPolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Review the TalentScope Diagnostics privacy policy covering data collection, usage, security, and rights for workforce diagnostics clients."
      />
      <meta
        name="keywords"
        content="privacy policy, data privacy, workforce diagnostics privacy, TalentScope Diagnostics privacy"
      />
      <meta property="og:title" content="Privacy Policy | TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Privacy practices and commitments from TalentScope Diagnostics."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <h1>Privacy Policy</h1>
    <p className={styles.effectiveDate}>Effective date: January 1, 2024</p>

    <section>
      <h2>1. Overview</h2>
      <p>
        TalentScope Diagnostics (“we”, “our”, “us”) is committed to protecting personal information entrusted to us by
        clients, partners, and website visitors. This Privacy Policy explains how we collect, use, disclose, and safeguard
        personal information in compliance with applicable Canadian privacy laws.
      </p>
    </section>

    <section>
      <h2>2. Information we collect</h2>
      <p>
        We collect personal information when it is voluntarily provided, including contact details, organizational role,
        and diagnostics-related preferences. When providing workforce analytics services, we process employee data supplied
        under written agreements. Such data may include identifiers, job information, competency assessments, and training
        histories as required to deliver services.
      </p>
    </section>

    <section>
      <h2>3. How we use information</h2>
      <p>
        Personal information is used to respond to inquiries, provide contracted services, manage accounts, and communicate
        relevant updates. Workforce data processed on behalf of clients is used strictly for diagnostic analysis, reporting,
        and insights defined in the applicable statement of work.
      </p>
    </section>

    <section>
      <h2>4. Legal basis and consent</h2>
      <p>
        We rely on consent, contractual necessity, or legitimate business purposes to process personal information. When we
        act as a service provider, our processing is governed by agreements with clients who collect consent from their
        workforce as required.
      </p>
    </section>

    <section>
      <h2>5. Disclosure to third parties</h2>
      <p>
        We do not sell or disclose personal information except to trusted service providers who assist us in delivering
        diagnostics, hosting systems, or performing professional services. These providers are bound by confidentiality and
        security obligations consistent with this policy.
      </p>
    </section>

    <section>
      <h2>6. Data retention</h2>
      <p>
        Personal information is retained only for as long as necessary to fulfil the purposes outlined in this policy or to
        comply with legal obligations. Client data is retained according to contractual requirements and securely destroyed
        upon completion.
      </p>
    </section>

    <section>
      <h2>7. Security</h2>
      <p>
        We implement administrative, technical, and physical safeguards to protect personal information against unauthorized
        access, alteration, disclosure, or destruction. Security measures include access controls, encryption in transit,
        monitoring, and staff training on privacy practices.
      </p>
    </section>

    <section>
      <h2>8. International transfers</h2>
      <p>
        Where personal information is stored or processed outside of Canada, we ensure that appropriate protections are in
        place and that service providers adhere to privacy requirements equivalent to those in Canada.
      </p>
    </section>

    <section>
      <h2>9. Access and correction</h2>
      <p>
        Individuals have the right to request access to personal information we hold and to request corrections. Requests
        may be submitted using the contact information below. We will respond within reasonable timelines as mandated by law.
      </p>
    </section>

    <section>
      <h2>10. Updates to this policy</h2>
      <p>
        We may update this Privacy Policy periodically to reflect changes in legislation or our practices. The updated policy
        will be posted on our website with a revised effective date.
      </p>
    </section>

    <section>
      <h2>11. Contact</h2>
      <p>
        Questions about this Privacy Policy or our privacy practices can be directed to our privacy representative at
        TalentScope Diagnostics, 123 Scope St, Edmonton, AB T5J 3R8, Canada, or by calling +1 780 555 7890.
      </p>
    </section>
  </div>
);

export default PrivacyPolicyPage;