import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const faqItems = [
  {
    question: 'How does TalentScope structure workforce diagnostics?',
    answer:
      'We combine employee skill audits, training activity datasets, and retention metrics into unified dashboards that highlight capability gaps and development priorities for each business unit.',
  },
  {
    question: 'What data sources can be integrated with your platform?',
    answer:
      'We securely connect to HRIS records, learning management systems, credentialing repositories, and employee engagement surveys to ensure consistent, high-quality inputs.',
  },
  {
    question: 'How frequently are insights refreshed?',
    answer:
      'Our clients schedule refresh cycles ranging from weekly to quarterly. Automated ingestion pipelines ensure that refreshed metrics are synchronized with change management checkpoints.',
  },
];

const testimonials = [
  {
    name: 'Alex Chen',
    role: 'Director of Workforce Planning, Calgary',
    quote:
      'The diagnostics dashboard clarified retention triggers and helped align talent programs with certification targets within a single quarter.',
  },
  {
    name: 'Morgan Patel',
    role: 'Learning Architect, Vancouver',
    quote:
      'Scenario modelling from TalentScope guided our reskilling roadmap and kept leadership informed through accessible visualizations.',
  },
  {
    name: 'Sonia Laurent',
    role: 'Operations Lead, Toronto',
    quote:
      'We gained visibility into training adoption and progression milestones that were previously hidden across separate systems.',
  },
];

const projects = [
  {
    title: 'Provincial Upskilling Observatory',
    description:
      'Consolidated data from seven regional training providers to evaluate competency coverage for critical infrastructure teams.',
    image: 'https://picsum.photos/1200/800?random=14',
  },
  {
    title: 'Retention Heatmap Initiative',
    description:
      'Developed predictive retention indicators for a Canadian logistics network, enabling proactive coaching and mentoring support.',
    image: 'https://picsum.photos/1200/800?random=15',
  },
];

const blogPosts = [
  {
    title: 'Benchmarking Workforce Diagnostics in Canadian Provinces',
    excerpt:
      'A practical framework for comparing skill depth, training velocity, and retention markers across distributed teams.',
    link: '/services',
  },
  {
    title: 'Aligning Learning Journeys with Compliance Pathways',
    excerpt:
      'Strategies for synchronizing regulated training requirements with progressive competency checkpoints.',
    link: '/solutions',
  },
];

const teamMembers = [
  {
    name: 'Priya Desai',
    role: 'Principal Workforce Analyst',
    bio: 'Specializes in multi-source data orchestration and advanced segmentation for complex workforce ecosystems.',
    image: 'https://picsum.photos/400/400?random=21',
  },
  {
    name: 'James Whitmore',
    role: 'Learning Evaluation Strategist',
    bio: 'Designs evidence-based training evaluations focusing on skill progression and longitudinal retention tracing.',
    image: 'https://picsum.photos/400/400?random=22',
  },
  {
    name: 'Hailey Morin',
    role: 'People Analytics Engineer',
    bio: 'Builds automation pipelines that convert enterprise HR data into actionable dashboards and diagnostic models.',
    image: 'https://picsum.photos/400/400?random=23',
  },
];

const HomePage = () => {
  const [activeFaq, setActiveFaq] = React.useState(0);
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Home | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="TalentScope Diagnostics delivers workforce development diagnostics, training needs analysis, and employee retention insights tailored for Canadian organizations."
        />
        <meta
          name="keywords"
          content="workforce development diagnostics Canada, training needs analysis, employee retention insights, professional growth monitoring, staff skill evaluation"
        />
        <meta property="og:title" content="TalentScope Diagnostics | Workforce Development Diagnostics" />
        <meta
          property="og:description"
          content="Data-driven workforce diagnostics, training needs analysis, and retention monitoring for Canadian teams."
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay}>
          <div className={styles.heroContent}>
            <h1>Data-Driven Workforce Diagnostics Across Canada</h1>
            <p>
              TalentScope Diagnostics equips HR and learning leaders with precise analytics covering workforce development,
              training needs, and retention dynamics. Our Canadian expertise ensures localized context, compliance alignment,
              and measurable progression insights.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className={styles.primaryCta}>Explore Our Diagnostics</Link>
              <Link to="/services" className={styles.secondaryCta}>View Services</Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className={styles.sectionHeader}>
          <h2>Structured analytics that clarify action</h2>
          <p>Quantitative indicators translate workforce data into priorities for development, retention, and compliance.</p>
        </div>
        <div className={styles.statsGrid}>
          <article>
            <span className={styles.statNumber}>48</span>
            <h3>Active diagnostic models</h3>
            <p>Customizable models evaluate capability, mentoring progress, and readiness for business-critical roles.</p>
          </article>
          <article>
            <span className={styles.statNumber}>72K</span>
            <h3>Employee records aligned</h3>
            <p>Secure integrations standardize datasets across HRIS, LMS, and assessment platforms to maintain integrity.</p>
          </article>
          <article>
            <span className={styles.statNumber}>14</span>
            <h3>Provincial benchmarking sets</h3>
            <p>Comparative metrics monitor provincial nuances while respecting regional workforce legislation.</p>
          </article>
        </div>
      </section>

      <section className={styles.services} id="services">
        <div className={styles.sectionHeader}>
          <h2>Service Overview</h2>
          <p>Each service area brings together qualitative feedback, quantitative metrics, and forward-looking recommendations.</p>
        </div>
        <div className={styles.serviceCards}>
          <article>
            <img src="https://picsum.photos/600/400?random=31" alt="Analyst reviewing workforce development dashboards" />
            <h3>Workforce Development Diagnostics</h3>
            <p>Structured assessments map capability distribution, identify proficiency clusters, and surface emerging workforce gaps.</p>
            <Link to="/services" aria-label="Learn more about workforce development diagnostics">Learn more</Link>
          </article>
          <article>
            <img src="https://picsum.photos/600/400?random=32" alt="Team discussing training needs analysis insights" />
            <h3>Training Needs Analysis</h3>
            <p>Evidence-based training plans align learning activities with operational requirements and regulatory obligations.</p>
            <Link to="/services" aria-label="Learn more about training needs analysis">Learn more</Link>
          </article>
          <article>
            <img src="https://picsum.photos/600/400?random=33" alt="Professional reviewing retention dashboards on laptop" />
            <h3>Employee Retention & Growth Monitoring</h3>
            <p>Retention dashboards combine sentiment tracking, mobility indicators, and coaching outcomes to reduce attrition risk.</p>
            <Link to="/services" aria-label="Learn more about retention monitoring">Learn more</Link>
          </article>
        </div>
      </section>

      <section className={styles.why}>
        <div className={styles.sectionHeader}>
          <h2>Why TalentScope Diagnostics?</h2>
          <p>We translate complex workforce inputs into accessible, audited narratives that inform strategic planning.</p>
        </div>
        <div className={styles.whyGrid}>
          <div>
            <h3>Canadian Regulatory Insight</h3>
            <p>Observes provincial labour standards, bilingual training requirements, and sector-specific accreditation frameworks.</p>
          </div>
          <div>
            <h3>Multi-Source Integration</h3>
            <p>Connects HRIS, LMS, credentialing, and engagement data through governed ingestion pipelines and validation checks.</p>
          </div>
          <div>
            <h3>Actionable Visuals</h3>
            <p>Interactive dashboards and narrative summaries transform data into initiatives that leadership teams can sponsor.</p>
          </div>
          <div>
            <h3>Collaborative Delivery</h3>
            <p>Workshops, stakeholder interviews, and working sessions ensure diagnostics reflect organizational context.</p>
          </div>
        </div>
      </section>

      <section className={styles.visuals}>
        <div className={styles.sectionHeader}>
          <h2>Visual insights in action</h2>
          <p>Dashboards deliver clarity on capability maturity, learning velocity, and retention signals.</p>
        </div>
        <div className={styles.visualGrid}>
          <figure>
            <img src="https://picsum.photos/800/600?random=41" alt="Dashboard with workforce capability distribution chart" loading="lazy" />
            <figcaption>Capability distribution snapshots highlight readiness across divisions.</figcaption>
          </figure>
          <figure>
            <img src="https://picsum.photos/800/600?random=42" alt="Retention monitoring heatmap example" loading="lazy" />
            <figcaption>Retention heatmaps surface hotspots requiring targeted interventions.</figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.processProjects}>
        <div className={styles.process}>
          <div className={styles.sectionHeader}>
            <h2>Methodical engagement process</h2>
            <p>Our collaborative framework ensures diagnostics align with stakeholder expectations and technical requirements.</p>
          </div>
          <ol className={styles.processSteps}>
            <li>
              <h3>1. Discovery & Data Audit</h3>
              <p>Catalogue data systems, validate attributes, and map workforce objectives to diagnostic questions.</p>
            </li>
            <li>
              <h3>2. Diagnostic Blueprinting</h3>
              <p>Define models, KPIs, and governance standards supplying clarity on methodology and deliverables.</p>
            </li>
            <li>
              <h3>3. Insight Production</h3>
              <p>Generate dashboards, narrative briefings, and scenario simulations to support informed decisions.</p>
            </li>
            <li>
              <h3>4. Activation Support</h3>
              <p>Facilitate workshops, upskill internal teams, and provide playbooks that sustain momentum.</p>
            </li>
          </ol>
        </div>
        <div className={styles.projects}>
          <div className={styles.sectionHeader}>
            <h2>Project highlights</h2>
            <p>Technical engagements tailored to diverse Canadian contexts.</p>
          </div>
          <div className={styles.projectCards}>
            {projects.map((project) => (
              <article key={project.title}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Voices from Canadian teams</h2>
          <p>Stakeholders share how diagnostics informed strategy and accelerated change.</p>
        </div>
        <div className={styles.testimonialCard}>
          <p className={styles.quote}>{testimonials[testimonialIndex].quote}</p>
          <div className={styles.author}>
            <span className={styles.name}>{testimonials[testimonialIndex].name}</span>
            <span className={styles.role}>{testimonials[testimonialIndex].role}</span>
          </div>
          <div className={styles.indicators} role="tablist" aria-label="Testimonials">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                onClick={() => setTestimonialIndex(index)}
                className={index === testimonialIndex ? styles.dotActive : styles.dot}
                aria-label={`View testimonial ${index + 1}`}
                aria-selected={index === testimonialIndex}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.insightsHub}>
        <div className={styles.sectionHeader}>
          <h2>Insights hub</h2>
          <p>A collaborative network combining technical expertise, responsive support, and knowledge sharing.</p>
        </div>
        <div className={styles.teamSection}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </article>
          ))}
        </div>
        <div className={styles.faqBlog}>
          <div className={styles.faq}>
            <h3>Frequently asked questions</h3>
            <ul>
              {faqItems.map((item, index) => (
                <li key={item.question}>
                  <button
                    type="button"
                    onClick={() => setActiveFaq(index)}
                    aria-expanded={activeFaq === index}
                  >
                    {item.question}
                    <span>{activeFaq === index ? '−' : '+'}</span>
                  </button>
                  {activeFaq === index && <p>{item.answer}</p>}
                </li>
              ))}
            </ul>
          </div>
          <div className={styles.blog}>
            <h3>Latest perspectives</h3>
            {blogPosts.map((post) => (
              <article key={post.title}>
                <h4>{post.title}</h4>
                <p>{post.excerpt}</p>
                <Link to={post.link}>Continue reading</Link>
              </article>
            ))}
          </div>
        </div>
        <div className={styles.finalCta}>
          <h3>Ready to clarify your workforce trajectory?</h3>
          <p>Connect with TalentScope Diagnostics to schedule a discovery session and receive a tailored plan.</p>
          <Link to="/contact" className={styles.primaryCta}>Get Your Workforce Insights</Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;