import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const ContactPage = () => {
  const navigate = useNavigate();
  const [formState, setFormState] = React.useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = React.useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) {
      newErrors.name = 'Please enter your name.';
    }
    if (!formState.email.trim()) {
      newErrors.email = 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formState.message.trim()) {
      newErrors.message = 'Please describe your request.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      navigate('/thank-you');
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Contact TalentScope Diagnostics to discuss workforce development diagnostics, training needs analysis, and retention insights."
        />
        <meta
          name="keywords"
          content="contact TalentScope Diagnostics, workforce diagnostics Canada contact, training analysis contact"
        />
        <meta property="og:title" content="Contact TalentScope Diagnostics" />
        <meta
          property="og:description"
          content="Connect with TalentScope Diagnostics for workforce analytics consultations."
        />
        <meta property="og:type" content="article" />
      </Helmet>

      <section className={styles.intro}>
        <h1>Connect with our team</h1>
        <p>
          Share your workforce objectives, diagnostic requirements, or questions. We will coordinate a discovery session to
          understand your context and outline next steps.
        </p>
      </section>

      <section className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">Name</label>
          <input
            id="name"
            name="name"
            type="text"
            value={formState.name}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={Boolean(errors.name)}
          />
          {errors.name && <span className={styles.error}>{errors.name}</span>}

          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            value={formState.email}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={Boolean(errors.email)}
          />
          {errors.email && <span className={styles.error}>{errors.email}</span>}

          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            rows="6"
            value={formState.message}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={Boolean(errors.message)}
          />
          {errors.message && <span className={styles.error}>{errors.message}</span>}

          <button type="submit">Submit</button>
        </form>

        <div className={styles.details}>
          <div className={styles.infoCard}>
            <h2>Contact details</h2>
            <p>Address: 123 Scope St, Edmonton, AB T5J 3R8, Canada</p>
            <p>Phone: <a href="tel:+17805557890">+1 780 555 7890</a></p>
            <p>Hours: Monday to Friday, 9:00–17:00 MT</p>
          </div>
          <div className={styles.mapWrapper}>
            <iframe
              title="TalentScope Diagnostics location"
              src="https://www.google.com/maps?q=123+Scope+St,+Edmonton,+AB+T5J+3R8,+Canada&output=embed"
              loading="lazy"
              allowFullScreen
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;