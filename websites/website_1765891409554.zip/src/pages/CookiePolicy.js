import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Read the TalentScope Diagnostics cookie policy describing how cookies and similar technologies are used on our website."
      />
      <meta
        name="keywords"
        content="cookie policy, tracking cookies, TalentScope Diagnostics cookies"
      />
      <meta property="og:title" content="Cookie Policy | TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Cookie usage details for the TalentScope Diagnostics website."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <h1>Cookie Policy</h1>
    <p className={styles.effectiveDate}>Effective date: January 1, 2024</p>

    <section>
      <h2>1. Introduction</h2>
      <p>
        This Cookie Policy explains how TalentScope Diagnostics (“we”, “our”, “us”) uses cookies and similar technologies on
        our website. By using our site, you acknowledge that we may store and access cookies as described here.
      </p>
    </section>

    <section>
      <h2>2. What are cookies?</h2>
      <p>
        Cookies are small text files stored on your device when you browse websites. They enable features such as remembering
        preferences or understanding how visitors interact with pages.
      </p>
    </section>

    <section>
      <h2>3. Types of cookies we use</h2>
      <ul>
        <li>
          <strong>Essential cookies:</strong> Required for the website to operate properly, such as maintaining session
          state and remembering consent choices.
        </li>
        <li>
          <strong>Analytics cookies:</strong> Help us understand page usage and improve content. These cookies collect
          aggregated information and do not identify individuals.
        </li>
        <li>
          <strong>Functional cookies:</strong> Support features like remembering display preferences or language settings.
        </li>
      </ul>
    </section>

    <section>
      <h2>4. Managing cookies</h2>
      <p>
        You can control cookies through your browser settings. Most browsers allow you to delete cookies, block them entirely,
        or receive alerts before they are stored. Adjusting settings may impact site functionality.
      </p>
    </section>

    <section>
      <h2>5. Third-party technologies</h2>
      <p>
        We may use third-party analytics services that set their own cookies to provide aggregated reporting. These providers
        are contractually required to protect information and use it only to deliver analytics services to us.
      </p>
    </section>

    <section>
      <h2>6. Updates to this policy</h2>
      <p>
        We may revise this Cookie Policy periodically. Updates will be posted on our website with the revised effective date.
        Continued use of our site signifies acceptance of the updated policy.
      </p>
    </section>

    <section>
      <h2>7. Contact</h2>
      <p>
        For questions regarding this Cookie Policy, please contact TalentScope Diagnostics at 123 Scope St, Edmonton, AB T5J 3R8,
        Canada or call +1 780 555 7890.
      </p>
    </section>
  </div>
);

export default CookiePolicyPage;