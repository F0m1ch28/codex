import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CaseStudies.module.css';

const caseStudies = [
  {
    title: 'National Energy Cooperative',
    description:
      'Developed a comprehensive workforce diagnostic aligning technical certifications with infrastructure modernization projects.',
    impact:
      'Improved visibility into skill readiness across 14 regions and guided training priorities for new energy systems.',
    image: 'https://picsum.photos/900/600?random=81',
  },
  {
    title: 'Healthcare Training Consortium',
    description:
      'Unified data from multiple colleges and hospitals to monitor clinical training pathways and retention outcomes.',
    impact:
      'Enabled scenario planning that balanced enrolment, practicum capacity, and regional staffing demands.',
    image: 'https://picsum.photos/900/600?random=82',
  },
  {
    title: 'Transportation Services Network',
    description:
      'Implemented retention monitoring and coaching analytics for a distributed fleet and operations workforce.',
    impact:
      'Identified critical attrition triggers and supported targeted coaching programs that stabilized staffing levels.',
    image: 'https://picsum.photos/900/600?random=83',
  },
  {
    title: 'Technology Scale-Up',
    description:
      'Mapped competency frameworks to product roadmap milestones, ensuring talent readiness for rapid growth.',
    impact:
      'Delivered cross-functional training sequences that accelerated onboarding and reduced time to productivity.',
    image: 'https://picsum.photos/900/600?random=84',
  },
];

const CaseStudiesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Case Studies | TalentScope Diagnostics</title>
      <meta
        name="description"
        content="Review TalentScope Diagnostics case studies demonstrating workforce diagnostics, training analysis, and retention insights across Canadian sectors."
      />
      <meta
        name="keywords"
        content="workforce diagnostics case studies, training analysis Canada, retention insights projects"
      />
      <meta property="og:title" content="Case Studies | TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Success stories featuring workforce diagnostics and development insights for Canadian organizations."
      />
      <meta property="og:type" content="article" />
    </Helmet>

    <section className={styles.header}>
      <h1>Case studies</h1>
      <p>
        Our engagements span critical infrastructure, healthcare, technology, and public sector organizations. Explore how
        TalentScope Diagnostics collaborates with clients to illuminate workforce potential and drive development decisions.
      </p>
    </section>

    <section className={styles.grid}>
      {caseStudies.map((item) => (
        <article key={item.title}>
          <img src={item.image} alt={item.title} loading="lazy" />
          <div className={styles.content}>
            <h2>{item.title}</h2>
            <p>{item.description}</p>
            <h3>Impact</h3>
            <p>{item.impact}</p>
          </div>
        </article>
      ))}
    </section>
  </div>
);

export default CaseStudiesPage;