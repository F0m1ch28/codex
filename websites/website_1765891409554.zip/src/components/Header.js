import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          TalentScope Diagnostics
        </NavLink>
        <button
          className={styles.menuToggle}
          type="button"
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={toggleMenu}
        >
          <span className={styles.menuBar} />
          <span className={styles.menuBar} />
          <span className={styles.menuBar} />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Primary Navigation">
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : '')}>
            Home
          </NavLink>
          <NavLink to="/about" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : '')}>
            About
          </NavLink>
          <NavLink to="/services" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : '')}>
            Services
          </NavLink>
          <NavLink to="/solutions" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : '')}>
            Solutions
          </NavLink>
          <NavLink to="/case-studies" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : '')}>
            Case Studies
          </NavLink>
          <NavLink to="/contact" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : '')}>
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;