import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem('tsd_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('tsd_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Consent">
      <div className={styles.content}>
        <p>
          TalentScope Diagnostics uses essential cookies to maintain site performance analytics and remember your
          preferences. Continuing navigation indicates consent.
        </p>
        <button type="button" onClick={acceptCookies} className={styles.button}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;