import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brandColumn}>
        <h2>TalentScope Diagnostics</h2>
        <p>
          Technical workforce analytics that clarify training priorities, strengthen retention strategies, and guide
          growth pathways for Canadian organizations.
        </p>
        <address>
          <span>123 Scope St, Edmonton, AB T5J 3R8, Canada</span>
          <span>Phone: <a href="tel:+17805557890">+1 780 555 7890</a></span>
        </address>
      </div>
      <div className={styles.linkColumn}>
        <h3>Explore</h3>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/services">Services</Link></li>
          <li><Link to="/solutions">Solutions</Link></li>
          <li><Link to="/case-studies">Case Studies</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>
      </div>
      <div className={styles.linkColumn}>
        <h3>Governance</h3>
        <ul>
          <li><Link to="/privacy-policy">Privacy Policy</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
          <li><Link to="/terms-of-service">Terms of Service</Link></li>
        </ul>
      </div>
    </div>
    <div className={styles.footerNote}>
      <p>© {new Date().getFullYear()} TalentScope Diagnostics. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;