import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import SolutionsPage from './pages/Solutions';
import CaseStudiesPage from './pages/CaseStudies';
import ContactPage from './pages/Contact';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import CookiePolicyPage from './pages/CookiePolicy';
import TermsOfServicePage from './pages/TermsOfService';
import ThankYouPage from './pages/ThankYou';
import styles from './App.module.css';

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
};

const App = () => (
  <div className={styles.appWrapper}>
    <Helmet htmlAttributes={{ lang: 'en' }}>
      <title>TalentScope Diagnostics | Workforce Development Insights</title>
      <meta
        name="description"
        content="TalentScope Diagnostics delivers workforce development diagnostics, training needs analysis, and employee retention insights across Canada."
      />
      <meta
        name="keywords"
        content="workforce development diagnostics Canada, training needs analysis, employee retention insights, professional growth monitoring, staff skill evaluation, workforce performance assessment, talent development compliance, career progression diagnostics"
      />
      <meta property="og:title" content="TalentScope Diagnostics" />
      <meta
        property="og:description"
        content="Data-driven diagnostics for workforce development, training planning, and retention monitoring in Canada."
      />
      <meta property="og:type" content="website" />
      <meta property="og:url" content="https://www.example.com/" />
    </Helmet>
    <ScrollToTopOnRoute />
    <Header />
    <main className={styles.mainContent}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/solutions" element={<SolutionsPage />} />
        <Route path="/case-studies" element={<CaseStudiesPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
        <Route path="/cookie-policy" element={<CookiePolicyPage />} />
        <Route path="/terms-of-service" element={<TermsOfServicePage />} />
        <Route path="/thank-you" element={<ThankYouPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

export default App;