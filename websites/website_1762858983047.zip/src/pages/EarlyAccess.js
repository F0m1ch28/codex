import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './EarlyAccess.module.css';

const upcomingProducts = [
  {
    name: 'NeuroWave AR Lens',
    release: 'Q3 2024',
    description: 'AR-Brille mit neuronaler Gestensteuerung und holografischer UI.',
    image: 'https://picsum.photos/900/600?random=51'
  },
  {
    name: 'FluxPad Studio Dock',
    release: 'Q3 2024',
    description: 'Thunderbolt Dock mit aktiver Wärmeableitung und KI-basiertem Device-Manager.',
    image: 'https://picsum.photos/900/600?random=52'
  },
  {
    name: 'Aerius Airbuds GenX',
    release: 'Q4 2024',
    description: 'Adaptive Audioanalyse mit personalisiertem Soundprofil in Echtzeit.',
    image: 'https://picsum.photos/900/600?random=53'
  }
];

const benefits = [
  'Vorabzugriff auf unveröffentlichte Reviews und Rohdaten',
  'Einladungen zu virtuellen Lab-Sessions und Roundtables',
  'Möglichkeit, Feedback in finale Ratings einzubringen',
  'Frühzeitige Produktwarnungen bei Firmware-Problemen',
  'Zugang zu Whitepapers, Power User Guides und Vergleichstabellen'
];

const EarlyAccess = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    motivation: ''
  });
  const [formMessage, setFormMessage] = useState('');

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.motivation) {
      setFormMessage('Bitte füllen Sie alle Felder aus.');
      return;
    }
    setFormMessage('Vielen Dank! Wir melden uns nach Prüfung Ihrer Angaben.');
    setFormData({ name: '', email: '', motivation: '' });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Early Access Programm - Slexorifyx</title>
        <meta
          name="description"
          content="Werden Sie Teil des Early Access Programms von Slexorifyx und erhalten Sie frühe Einblicke in aufstrebende Technologien."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Early Access Programm</h1>
        <p>
          Erhalten Sie Zugang zu Prototypen, exklusiven Daten und direkten Feedbackrunden mit unserem
          Review-Team. Wir arbeiten mit einer kuratierten Community von Tech-Enthusiasten zusammen,
          um neue Geräte auf Herz und Nieren zu prüfen.
        </p>
      </header>

      <section className={styles.benefits}>
        <h2>Ihre Vorteile</h2>
        <ul>
          {benefits.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className={styles.upcoming}>
        <h2>Kommende Produkte</h2>
        <div className={styles.productGrid}>
          {upcomingProducts.map((product) => (
            <article key={product.name} className={styles.productCard}>
              <img src={product.image} alt={product.name} loading="lazy" />
              <header>
                <h3>{product.name}</h3>
                <span>Release: {product.release}</span>
              </header>
              <p>{product.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Jetzt bewerben</h2>
        <p>
          Bitte stellen Sie sich kurz vor und teilen Sie uns mit, warum Sie an unserem Early Access
          teilnehmen möchten.
        </p>
        <form onSubmit={handleSubmit} className={styles.form} noValidate>
          <label>
            Name
            <input
              type="text"
              name="name"
              placeholder="Ihr vollständiger Name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            E-Mail-Adresse
            <input
              type="email"
              name="email"
              placeholder="mail@example.com"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Motivation
            <textarea
              name="motivation"
              rows="5"
              placeholder="Warum möchten Sie Teil des Early Access werden?"
              value={formData.motivation}
              onChange={handleChange}
              required
            ></textarea>
          </label>
          <button type="submit">Bewerbung absenden</button>
        </form>
        {formMessage && <p className={styles.formMessage}>{formMessage}</p>}
      </section>
    </div>
  );
};

export default EarlyAccess;