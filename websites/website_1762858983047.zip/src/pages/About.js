import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const labValues = [
  {
    title: 'Unabhängig Zertifiziert',
    description:
      'Unsere Labore arbeiten mit ISO-konformen Mess-protokollen. Jedes Review ist mit Rohdaten hinterlegt, die von unserem Data-Team geprüft werden.'
  },
  {
    title: 'Transparente Finanzierungsstruktur',
    description:
      'Wir finanzieren uns über Mitgliedschaften, Event-Formate und Beratungsprojekte. Hersteller haben keinen Einfluss auf Bewertungen.'
  },
  {
    title: 'Ethik-Board',
    description:
      'Ein unabhängiges Board aus Journalist:innen, Wissenschaft und Datenschutz prüft unsere Prozesse halbjährlich.'
  }
];

const timeline = [
  {
    year: '2018',
    title: 'Gründung von Slexorifyx',
    text: 'Vier Tech-Journalist:innen gründen Slexorifyx in einem Loft in Prenzlauer Berg, um tiefere Analysen zu liefern.'
  },
  {
    year: '2020',
    title: 'Eröffnung des Berliner Labors',
    text: 'Wir ziehen in die Friedrichstraße 95 um. Neue Testflächen für Netzwerk, Sensorik und Audio entstehen.'
  },
  {
    year: '2022',
    title: 'Launch des Early Access Programms',
    text: 'Community-Mitglieder erhalten frühzeitige Einblicke, Feedback-Loops und virtuelle Lab-Touren.'
  },
  {
    year: '2024',
    title: 'Ausbau der Vergleichsplattform',
    text: 'Produktvergleiche werden interaktiv, inklusive Live-Updates zu Firmware-Versionen.'
  }
];

const competencies = [
  'Smartphone-SoC-Benchmarking',
  'Wearable-Metrik-Validierung',
  'Akustische Messungen & 3D Sound Mapping',
  'Smart-Home Sicherheit & Penetration Tests',
  'Thermische Analyse & Energieeffizienz',
  'UX Research mit longitudinalen Tagebüchern'
];

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Über Slexorifyx - Wer wir sind</title>
        <meta
          name="description"
          content="Lernen Sie das Team, die Mission und die unabhängige Testmethodik von Slexorifyx kennen."
        />
      </Helmet>

      <header className={styles.hero}>
        <div>
          <h1>Die Geschichte hinter Slexorifyx</h1>
          <p>
            Slexorifyx ist eine Tech-Review-Plattform aus Berlin, geschaffen von Menschen, die
            Technologie mit wissenschaftlicher Präzision analysieren möchten. Unser Name steht für
            Neugier, Tiefe und Verantwortung im Umgang mit Daten.
          </p>
        </div>
        <img
          src="https://picsum.photos/800/600?random=41"
          alt="Blick in das Slexorifyx Testlabor"
          loading="lazy"
        />
      </header>

      <section className={styles.values}>
        {labValues.map((value) => (
          <article key={value.title} className={styles.valueCard}>
            <h2>{value.title}</h2>
            <p>{value.description}</p>
          </article>
        ))}
      </section>

      <section className={styles.timeline} aria-label="Historie">
        <h2>Meilensteine</h2>
        <div className={styles.timelineGrid}>
          {timeline.map((item) => (
            <article key={item.year} className={styles.timelineItem}>
              <span>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.mission}>
        <div className={styles.missionText}>
          <h2>Unsere Mission</h2>
          <p>
            Wir möchten Technologie für alle greifbar machen, bevor sie in den Regalen steht. Unser
            Team setzt auf interdisziplinäre Forschung, transparente Kommunikation und einen
            respektvollen Umgang mit Nutzerdaten.
          </p>
          <p>
            Dabei handelt Slexorifyx unabhängig von Herstellern und legt sämtliche Kooperationen
            offen. Wir setzen auf Vielfalt im Team, um Bias zu minimieren und inklusive Perspektiven
            zu fördern.
          </p>
        </div>
        <div className={styles.missionList}>
          <h3>Kompetenzen</h3>
          <ul>
            {competencies.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className={styles.methodik}>
        <h2>Testmethodik</h2>
        <div className={styles.methodikGrid}>
          <article>
            <h3>Labordaten</h3>
            <p>
              Wir nutzen kalibrierte Messgeräte, Klimakammern und abgeschirmte Räume für präzise
              Sensor-Daten. Alle Messungen erhalten Messprotokolle, die einsehbar sind.
            </p>
          </article>
          <article>
            <h3>Real-Life Szenarien</h3>
            <p>
              Unsere Reviewer:innen verwenden Geräte mehrere Wochen im Alltag, dokumentieren
              Auffälligkeiten und verifizieren diese nochmals im Labor.
            </p>
          </article>
          <article>
            <h3>Community Feedback</h3>
            <p>
              Die Community liefert praxisnahe Einblicke aus unterschiedlichen Einsatzbereichen.
              Feedback fließt in unsere finalen Bewertungen ein.
            </p>
          </article>
          <article>
            <h3>Unabhängigkeitserklärung</h3>
            <p>
              Alle Teammitglieder unterschreiben eine jährliche Selbstverpflichtung, Interessenkonflikte offenzulegen. Jede Prüfung erfolgt mit Vier-Augen-Prinzip.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default About;