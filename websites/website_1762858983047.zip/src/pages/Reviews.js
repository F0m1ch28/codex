import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useLocation } from 'react-router-dom';
import styles from './Reviews.module.css';

const reviewData = [
  {
    id: 'r1',
    title: 'Nebula X1 Smartphone',
    brand: 'Nebula Tech',
    category: 'Smartphones',
    rating: 4.5,
    date: '2024-05-12',
    summary:
      'LTPO-Display mit 120 Hz, adaptive Kühlung und eine Kamera, die bei Low-Light überrascht. Firmware 1.0.6 getestet.',
    video: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: 'r2',
    title: 'PulseBand Horizon',
    brand: 'PulseBand',
    category: 'Wearables',
    rating: 4.8,
    date: '2024-05-02',
    summary:
      'Präzise EKG-Messungen, umfangreiche Schlafanalyse und nahtlose Integration in Apple Health sowie Google Fit.',
    video: 'https://www.youtube.com/embed/mRf3-JkwqfU'
  },
  {
    id: 'r3',
    title: 'LumoSphere Aura Hub',
    brand: 'LumoSphere',
    category: 'Smart-Home',
    rating: 3.8,
    date: '2024-04-18',
    summary:
      'Matter-Support, leistungsstarker Zigbee-Hub und flexible Szenensteuerung. Set-up benötigt erfahrene Hände.'
  },
  {
    id: 'r4',
    title: 'Auralink Echo Pro',
    brand: 'Auralink',
    category: 'Audio',
    rating: 4.0,
    date: '2024-04-29',
    summary:
      'Studioverliebter Sound, adaptives ANC und Spatial Audio. App-UX könnte intuitiver sein.',
    video: 'https://www.youtube.com/embed/FTQbiNvZqaY'
  },
  {
    id: 'r5',
    title: 'StreamForge Z15',
    brand: 'StreamForge',
    category: 'Gaming',
    rating: 4.2,
    date: '2024-03-30',
    summary:
      'Hybrid-Handheld mit 144 Hz OLED und aktiver Kühlung. Perfekt für Cloud-Gaming, lokale Titel benötigen Profilanpassungen.'
  },
  {
    id: 'r6',
    title: 'PhotonAir Lite Cam',
    brand: 'PhotonAir',
    category: 'Kamera',
    rating: 4.4,
    date: '2024-04-11',
    summary:
      'APS-C Kamera mit neuronaler Autofokus-Engine. Video-Workflow mit LUTs nachrüstbar, Rolling-Shutter sehr gering.'
  },
  {
    id: 'r7',
    title: 'ZenSlate Flex 2',
    brand: 'ZenSlate',
    category: 'Laptops',
    rating: 4.1,
    date: '2024-04-24',
    summary:
      'Ultraleichtes Convertible mit OLED 3K Display und aktiver Stiftunterstützung. Akkulaufzeit solide, Lüfter im Turbo hörbar.'
  }
];

const categories = [
  'Alle',
  'Smartphones',
  'Wearables',
  'Smart-Home',
  'Audio',
  'Laptops',
  'Gaming',
  'Kamera'
];

const Reviews = () => {
  const [categoryFilter, setCategoryFilter] = useState('Alle');
  const [brandFilter, setBrandFilter] = useState('');
  const [ratingFilter, setRatingFilter] = useState('0');
  const [filteredReviews, setFilteredReviews] = useState(reviewData);
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const searchQuery = params.get('suche');
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const results = reviewData.filter(
        (review) =>
          review.title.toLowerCase().includes(query) ||
          review.brand.toLowerCase().includes(query) ||
          review.category.toLowerCase().includes(query)
      );
      setFilteredReviews(results);
    } else {
      setFilteredReviews(reviewData);
    }
  }, [location.search]);

  useEffect(() => {
    const filtered = reviewData.filter((review) => {
      const matchesCategory = categoryFilter === 'Alle' || review.category === categoryFilter;
      const matchesBrand =
        !brandFilter.trim() ||
        review.brand.toLowerCase().includes(brandFilter.trim().toLowerCase());
      const matchesRating = review.rating >= parseFloat(ratingFilter);
      return matchesCategory && matchesBrand && matchesRating;
    });
    setFilteredReviews(filtered);
  }, [categoryFilter, brandFilter, ratingFilter]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Reviews - Slexorifyx Techniktests</title>
        <meta
          name="description"
          content="Durchsuchen Sie ausführliche Reviews zu Smartphones, Wearables, Smart-Home-Lösungen, Audio, Gaming und mehr."
        />
      </Helmet>
      <header className={styles.header}>
        <h1>Reviews</h1>
        <p>Fundierte Tests, klare Bewertungskriterien, umfangreiche Daten.</p>
      </header>

      <section className={styles.filters} aria-label="Filter">
        <div className={styles.filterGroup}>
          <span>Kategorie</span>
          <div className={styles.filterButtons}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  categoryFilter === category ? styles.active : ''
                }`}
                onClick={() => setCategoryFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.filterRow}>
          <label>
            Marke
            <input
              type="text"
              placeholder="z. B. Nebula Tech"
              value={brandFilter}
              onChange={(event) => setBrandFilter(event.target.value)}
            />
          </label>
          <label>
            Mindestbewertung
            <select
              value={ratingFilter}
              onChange={(event) => setRatingFilter(event.target.value)}
            >
              <option value="0">Alle</option>
              <option value="3.5">ab 3.5</option>
              <option value="4.0">ab 4.0</option>
              <option value="4.5">ab 4.5</option>
            </select>
          </label>
        </div>
      </section>

      <section className={styles.reviewList}>
        {filteredReviews.length === 0 && (
          <p className={styles.emptyState}>Keine Ergebnisse für Ihre Filter vorhanden.</p>
        )}
        {filteredReviews.map((review) => (
          <article key={review.id} className={styles.reviewCard}>
            <header>
              <span className={styles.category}>{review.category}</span>
              <h2>{review.title}</h2>
              <p className={styles.brand}>Marke: {review.brand}</p>
            </header>
            <p>{review.summary}</p>
            <div className={styles.meta}>
              <span>Veröffentlicht am {new Date(review.date).toLocaleDateString('de-DE')}</span>
              <span className={styles.rating}>
                {Array.from({ length: 5 }).map((_, index) => (
                  <span
                    key={index}
                    className={index + 1 <= Math.round(review.rating) ? styles.starFilled : styles.starEmpty}
                  >
                    ★
                  </span>
                ))}
                <strong>{review.rating.toFixed(1)}</strong>
              </span>
            </div>
            {review.video && (
              <div className={styles.videoWrapper}>
                <iframe
                  src={review.video}
                  title={`Video Review ${review.title}`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            )}
          </article>
        ))}
      </section>
    </div>
  );
};

export default Reviews;