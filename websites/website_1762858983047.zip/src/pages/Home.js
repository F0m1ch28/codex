import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import { Link } from 'react-router-dom';

const reviews = [
  {
    id: 1,
    title: 'Nebula X1 Smartphone',
    category: 'Smartphones',
    rating: 4.5,
    status: 'success',
    excerpt:
      'Das Nebula X1 überzeugt mit einem außergewöhnlich klaren LTPO-Display und einem adaptiven Performance-Profil, das Energie spart.',
    image: 'https://picsum.photos/800/600?random=21',
    brand: 'Nebula Tech',
    date: '2024-05-12'
  },
  {
    id: 2,
    title: 'Auralink Echo Pro',
    category: 'Audio',
    rating: 4.0,
    status: 'warning',
    excerpt:
      'Kraftvolles Klangbild mit präziser Räumlichkeit, jedoch mit einem komplexen App-Setup. Ideal für Audio-Enthusiasten mit Geduld.',
    image: 'https://picsum.photos/800/600?random=22',
    brand: 'Auralink',
    date: '2024-04-29'
  },
  {
    id: 3,
    title: 'PulseBand Horizon',
    category: 'Wearables',
    rating: 4.8,
    status: 'success',
    excerpt:
      'Brillante Sensorik, wissenschaftlich validierte Schlafanalyse und ein haptisches Feedback, das Trainingssteuerung neu denkt.',
    image: 'https://picsum.photos/800/600?random=23',
    brand: 'PulseBand',
    date: '2024-05-02'
  },
  {
    id: 4,
    title: 'LumoSphere Aura Hub',
    category: 'Smart-Home',
    rating: 3.8,
    status: 'warning',
    excerpt:
      'Stimmige Lichtautomation mit Matter-Support. Die Einrichtung ist aufwendig, belohnt danach aber mit flexiblen Szenen.',
    image: 'https://picsum.photos/800/600?random=24',
    brand: 'LumoSphere',
    date: '2024-04-18'
  }
];

const featuredComparisons = [
  {
    id: 1,
    title: 'Nebula X1 vs. OrbPhone Nova',
    highlight: 'Display-Helligkeit, Akkulaufzeit, Kamera-Matrix',
    image: 'https://picsum.photos/1200/800?random=25'
  },
  {
    id: 2,
    title: 'Auralink Echo Pro vs. Sonique Beam Plus',
    highlight: 'ANC-Filter, Studio-Modi, Bluetooth-Stabilität',
    image: 'https://picsum.photos/1200/800?random=26'
  },
  {
    id: 3,
    title: 'PulseBand Horizon vs. VigorTrack Apex',
    highlight: 'Trainingsprofile, VO2max-Kalibrierung, Latenzfreie Synchronisation',
    image: 'https://picsum.photos/1200/800?random=27'
  }
];

const faqs = [
  {
    question: 'Wie testet Slexorifyx neue Geräte?',
    answer:
      'Unsere Labore kombinieren Benchmarks, Praxis-Use-Cases und Langzeittests. Wir dokumentieren jede Messung transparent und verifizieren Ergebnisse mit unabhängigen Referenzsystemen.'
  },
  {
    question: 'Wann erscheinen neue Reviews?',
    answer:
      'Wir veröffentlichen wöchentlich frische Analysen. Early-Access-Mitglieder erhalten vorab Einblicke und können Feedback in die finale Bewertung einbringen.'
  },
  {
    question: 'Wie kann ich Teil der Community werden?',
    answer:
      'Registrieren Sie sich für unser Early-Access-Programm und nehmen Sie an digitalen Roundtables, Beta-Streams und Feedback-Sessions teil.'
  }
];

const testimonials = [
  {
    quote:
      'Slexorifyx liefert eine beeindruckende Tiefe. Die Methodik ist nachvollziehbar und hilft unserem Einkaufsteam bei Entscheidungen.',
    name: 'Svenja Roth',
    role: 'Head of Product Strategy, Techhaus Berlin'
  },
  {
    quote:
      'Dank der präzisen Messdaten konnten wir unsere Launch-Planung anpassen. Die Insights sind klar strukturiert und auf den Punkt.',
    name: 'Dr. Leonhard Wagner',
    role: 'Innovation Lead, Auria Labs'
  },
  {
    quote:
      'Die Community-Calls von Slexorifyx sind ein Highlight. Hier wird offen diskutiert und kritisch hinterfragt – genau das, was wir brauchen.',
    name: 'Mareike Hahn',
    role: 'Editor-in-Chief, FutureDevices Magazin'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Scouting & Auswahl',
    description:
      'Wir identifizieren aufstrebende Hersteller und Prototypen, kuratieren relevante Geräte für den deutschsprachigen Markt und sichern Testgeräte vor Release.'
  },
  {
    step: '02',
    title: 'Labortests & Benchmarks',
    description:
      'In kontrollierten Umgebungen prüfen wir Leistung, Ausdauer und Sicherheit. Alle Ergebnisse werden mit Referenzwerten abgeglichen.'
  },
  {
    step: '03',
    title: 'Hands-on & Community',
    description:
      'Unsere Reviewer verbringen mehrere Wochen mit realen Szenarien und teilen Eindrücke in Sessions mit unserer Community.'
  },
  {
    step: '04',
    title: 'Veröffentlichung & Updates',
    description:
      'Wir veröffentlichen Ratings, Vergleichsanalysen und ergänzen Firmware-Updates in Form von Living Documents.'
  }
];

const projectGallery = [
  {
    id: 'p1',
    title: 'Ultra-Mini PCs 2024 Benchmark',
    category: 'Laptops',
    image: 'https://picsum.photos/900/600?random=28'
  },
  {
    id: 'p2',
    title: 'Neural Audio Processing Suites',
    category: 'Audio',
    image: 'https://picsum.photos/900/600?random=29'
  },
  {
    id: 'p3',
    title: 'Wearable Health Metrics Audit',
    category: 'Wearables',
    image: 'https://picsum.photos/900/600?random=30'
  },
  {
    id: 'p4',
    title: 'Smart-Home Security Sandbox',
    category: 'Smart-Home',
    image: 'https://picsum.photos/900/600?random=31'
  }
];

const Home = () => {
  const [stats, setStats] = useState({
    reports: 0,
    prototypes: 0,
    community: 0,
    partners: 0
  });
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [lightboxImage, setLightboxImage] = useState(null);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Alle') return projectGallery;
    return projectGallery.filter((item) => item.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    const timer = setTimeout(
      () =>
        setStats({
          reports: 248,
          prototypes: 36,
          community: 9400,
          partners: 58
        }),
      800
    );
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Slexorifyx - Gadget-Reviews &amp; Early Access zu Neuester Technologie</title>
        <meta
          name="description"
          content="Führende deutsche Plattform für exklusive Gadget-Reviews, Hands-On-Tests und frühen Zugang zu neuester Technologie."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Entdecke Technologie, bevor sie viral geht.</h1>
          <p>
            Slexorifyx prüft Innovationen, bevor sie Mainstream werden. Wir liefern fundierte
            Reviews, präzise Benchmarks und einen Early-Access-Club für engagierte Tech-Fans.
          </p>
          <div className={styles.heroActions}>
            <Link to="/early-access" className={styles.primaryCta}>
              Zum Early Access anmelden
            </Link>
            <Link to="/reviews" className={styles.secondaryCta}>
              Aktuelle Reviews ansehen
            </Link>
          </div>
          <div className={styles.heroMeta}>
            <span>Unabhängige Labore aus Berlin</span>
            <span>Community-Feedback in Echtzeit</span>
            <span>Updates nach jedem Firmware-Release</span>
          </div>
        </div>
        <div className={styles.heroMedia}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Moderne Technologie auf einem Schreibtisch"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.stats} aria-label="Kennzahlen">
        <div className={styles.statCard}>
          <span className={styles.statNumber} aria-live="polite">
            {stats.reports}+
          </span>
          <span className={styles.statLabel}>Veröffentlichte Reviews</span>
        </div>
        <div className={styles.statCard}>
          <span className={styles.statNumber} aria-live="polite">
            {stats.prototypes}
          </span>
          <span className={styles.statLabel}>Exklusive Prototypen im Test</span>
        </div>
        <div className={styles.statCard}>
          <span className={styles.statNumber} aria-live="polite">
            {stats.community}
          </span>
          <span className={styles.statLabel}>Community-Mitglieder</span>
        </div>
        <div className={styles.statCard}>
          <span className={styles.statNumber} aria-live="polite">
            {stats.partners}
          </span>
          <span className={styles.statLabel}>Hersteller in Kooperation</span>
        </div>
      </section>

      <section className={styles.intro}>
        <div className={styles.introText}>
          <h2>Über Slexorifyx</h2>
          <p>
            Wir sind Slexorifyx, das Berliner Tech-Review-Hub für anspruchsvolle Leserinnen und
            Leser. Unser Anspruch ist eine transparente, reproduzierbare Testmethodik mit klarer
            Datengrundlage. Jedes Review ist Ergebnis eines kollaborativen Prozesses zwischen
            Laborteam, Herausgeber:innen und Community-Mitgliedern.
          </p>
          <p>
            Von Smartphones über Wearables bis Smart-Home: Wir bewerten Produkte mit Fokus auf
            Alltagstauglichkeit, Sicherheitsstandards und Update-Zyklen. Unsere Reviews sind
            lebende Dokumente, die Firmware-Anpassungen und Nutzererfahrungen aufnehmen.
          </p>
          <Link to="/ueber-uns" className={styles.linkCta}>
            Mehr über unsere Mission
          </Link>
        </div>
        <div className={styles.introCards}>
          <article className={styles.introCard}>
            <h3>Expertentests</h3>
            <p>Laborgestützte Messungen mit validierten Referenzen und dokumentierten Abläufen.</p>
          </article>
          <article className={styles.introCard}>
            <h3>Unabhängigkeit</h3>
            <p>Keine Einflussnahme durch Hersteller, finanzielle Transparenz, klare Offenlegung.</p>
          </article>
          <article className={styles.introCard}>
            <h3>Community</h3>
            <p>
              Aktive Diskussionsformate, Beta-Sessions, Live-Streams und wissensbasierter Austausch.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.latestReviews}>
        <div className={styles.sectionHeading}>
          <h2>Aktuelle Reviews</h2>
          <p>Unsere neuesten Tests mit detaillierten Benchmarks und klarer Einschätzung.</p>
        </div>
        <div className={styles.reviewGrid}>
          {reviews.map((review) => (
            <article key={review.id} className={styles.reviewCard}>
              <div className={styles.reviewImageWrapper}>
                <img src={review.image} alt={`${review.title} Produktfoto`} loading="lazy" />
                <span
                  className={`${styles.badge} ${
                    review.status === 'success' ? styles.badgeSuccess : styles.badgeWarning
                  }`}
                >
                  {review.status === 'success' ? 'Sehr empfehlenswert' : 'Mit Vorbehalt'}
                </span>
              </div>
              <header>
                <span className={styles.reviewCategory}>{review.category}</span>
                <h3>{review.title}</h3>
              </header>
              <p>{review.excerpt}</p>
              <div className={styles.reviewMeta}>
                <span>Marke: {review.brand}</span>
                <span>Veröffentlicht am {new Date(review.date).toLocaleDateString('de-DE')}</span>
              </div>
              <div className={styles.rating} aria-label={`Bewertung ${review.rating} von 5 Sternen`}>
                {Array.from({ length: 5 }).map((_, index) => (
                  <span key={index} className={index + 1 <= Math.round(review.rating) ? styles.starFilled : styles.starEmpty}>
                    ★
                  </span>
                ))}
                <span className={styles.ratingValue}>{review.rating.toFixed(1)}</span>
              </div>
              <Link to="/reviews" className={styles.cardLink}>
                Zum Review
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.categories}>
        <h2>Kategorien</h2>
        <div className={styles.categoryGrid}>
          {['Smartphones', 'Wearables', 'Smart-Home', 'Audio', 'Laptops', 'Gaming', 'Kamera'].map(
            (category) => (
              <Link key={category} to="/reviews" className={styles.categoryCard}>
                <span>{category}</span>
              </Link>
            )
          )}
        </div>
      </section>

      <section className={styles.featured}>
        <div className={styles.sectionHeading}>
          <h2>Featured Vergleiche</h2>
          <p>Direkte Gegenüberstellungen mit praxisnahen Use-Cases.</p>
        </div>
        <div className={styles.featuredGrid}>
          {featuredComparisons.map((item) => (
            <article key={item.id} className={styles.featuredCard}>
              <img
                src={item.image}
                alt={`Vergleich: ${item.title}`}
                loading="lazy"
                onClick={() => setLightboxImage(item.image)}
                role="button"
                tabIndex={0}
                onKeyDown={(event) => event.key === 'Enter' && setLightboxImage(item.image)}
              />
              <div className={styles.featuredContent}>
                <h3>{item.title}</h3>
                <p>{item.highlight}</p>
                <Link to="/vergleiche" className={styles.cardLink}>
                  Vergleich ansehen
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeading}>
          <h2>Unser Testprozess</h2>
          <p>Transparente Schritte für reproduzierbare Ergebnisse.</p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.step} className={styles.processCard}>
              <span>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeading}>
          <h2>Projekt-Highlights</h2>
          <p>Unsere Teamprojekte mit tiefer Marktrelevanz.</p>
        </div>
        <div className={styles.projectFilters}>
          {['Alle', 'Laptops', 'Audio', 'Wearables', 'Smart-Home'].map((filter) => (
            <button
              key={filter}
              type="button"
              className={`${styles.filterButton} ${
                projectFilter === filter ? styles.filterActive : ''
              }`}
              onClick={() => setProjectFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <figure key={project.id} className={styles.projectCard}>
              <img
                src={project.image}
                alt={`Projekt: ${project.title}`}
                loading="lazy"
                onClick={() => setLightboxImage(project.image)}
                role="button"
                tabIndex={0}
                onKeyDown={(event) => event.key === 'Enter' && setLightboxImage(project.image)}
              />
              <figcaption>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <h2>Stimmen aus der Branche</h2>
        <div className={styles.testimonialCard} aria-live="polite">
          <blockquote>“{testimonials[testimonialIndex].quote}”</blockquote>
          <p>
            <strong>{testimonials[testimonialIndex].name}</strong>
            <br />
            <span>{testimonials[testimonialIndex].role}</span>
          </p>
        </div>
        <div className={styles.testimonialControls}>
          {testimonials.map((_, index) => (
            <button
              key={index}
              type="button"
              aria-label={`Testimonial ${index + 1} anzeigen`}
              className={`${styles.dot} ${testimonialIndex === index ? styles.dotActive : ''}`}
              onClick={() => setTestimonialIndex(index)}
            />
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeading}>
          <h2>FAQ</h2>
          <p>Antworten auf häufig gestellte Fragen.</p>
        </div>
        <div className={styles.accordion}>
          {faqs.map((faq, index) => (
            <details key={faq.question} open={index === 0}>
              <summary>{faq.question}</summary>
              <p>{faq.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.newsletter}>
        <div className={styles.sectionHeading}>
          <h2>Newsletter abonnieren</h2>
          <p>Wöchentliche Updates mit unveröffentlichten Messwerten direkt in Ihre Inbox.</p>
        </div>
        <form className={styles.newsletterForm}>
          <label htmlFor="newsletter-email" className="sr-only">
            E-Mail-Adresse
          </label>
          <input
            id="newsletter-email"
            type="email"
            name="email"
            placeholder="E-Mail-Adresse"
            required
            autoComplete="email"
          />
          <button type="submit">Abonnieren</button>
        </form>
        <p className={styles.newsletterHint}>
          Mit Ihrer Anmeldung bestätigen Sie die Verarbeitung Ihrer Daten gemäß unserer{' '}
          <Link to="/datenschutz">Datenschutzerklärung</Link>.
        </p>
      </section>

      <section className={styles.earlyAccess}>
        <div className={styles.sectionHeading}>
          <h2>Early Access Programm</h2>
          <p>
            Testberichte vor Launch lesen, Q&amp;A mit unseren Reviewer:innen und Prototypen in Live
            Sessions erleben.
          </p>
        </div>
        <Link to="/early-access" className={styles.primaryCta}>
          Jetzt Plätze sichern
        </Link>
      </section>

      {lightboxImage && (
        <div
          className={styles.lightbox}
          role="dialog"
          aria-modal="true"
          aria-label="Bild vergrößern"
          onClick={() => setLightboxImage(null)}
        >
          <button
            type="button"
            className={styles.lightboxClose}
            aria-label="Lightbox schließen"
            onClick={() => setLightboxImage(null)}
          >
            ✕
          </button>
          <img src={lightboxImage} alt="Vergrößerte Ansicht" />
        </div>
      )}
    </div>
  );
};

export default Home;