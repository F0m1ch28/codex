import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'slexorifyx-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="region" aria-label="Cookie Hinweis">
      <div className={styles.content}>
        <p>
          Slexorifyx nutzt Cookies, um Inhalte zu optimieren und anonyme Nutzungsstatistiken zu
          erfassen. Weitere Informationen finden Sie in unserer{' '}
          <a href="/datenschutz">Datenschutzerklärung</a>.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={handleAccept} className={styles.primaryButton}>
            Einverstanden
          </button>
          <a href="/datenschutz" className={styles.secondaryButton}>
            Mehr erfahren
          </a>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;