import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const handleSearchSubmit = (event) => {
    event.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/reviews?suche=${encodeURIComponent(searchTerm.trim())}`);
      setMenuOpen(false);
    }
  };

  return (
    <header className={styles.header} role="banner">
      <a className={styles.skipLink} href="#hauptinhalt">
        Zum Inhalt springen
      </a>
      <div className={styles.inner}>
        <div className={styles.logoArea}>
          <span className={styles.logo} aria-label="Slexorifyx Logo">
            Slexorifyx
          </span>
          <button
            className={styles.menuToggle}
            aria-expanded={menuOpen}
            aria-controls="hauptnavigation"
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span className={styles.menuBar}></span>
            <span className={styles.menuBar}></span>
            <span className={styles.menuBar}></span>
            <span className="sr-only">Navigation umschalten</span>
          </button>
        </div>
        <nav
          id="hauptnavigation"
          className={`${styles.nav} ${menuOpen ? styles.open : ''}`}
          aria-label="Hauptnavigation"
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Start
          </NavLink>
          <NavLink
            to="/ueber-uns"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Über uns
          </NavLink>
          <NavLink
            to="/reviews"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Reviews
          </NavLink>
          <NavLink
            to="/vergleiche"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Vergleiche
          </NavLink>
          <NavLink
            to="/news"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            News
          </NavLink>
          <NavLink
            to="/guides"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Guides
          </NavLink>
          <NavLink
            to="/early-access"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Early Access
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Services
          </NavLink>
          <NavLink
            to="/team"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Team
          </NavLink>
          <NavLink
            to="/kontakt"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.active : ''}`
            }
            onClick={() => setMenuOpen(false)}
          >
            Kontakt
          </NavLink>
        </nav>
        <form
          className={styles.searchForm}
          role="search"
          aria-label="Seitensuche"
          onSubmit={handleSearchSubmit}
        >
          <label htmlFor="seitensuche" className="sr-only">
            Suche
          </label>
          <input
            id="seitensuche"
            type="search"
            name="suche"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Gerät oder Marke finden..."
            className={styles.searchInput}
          />
          <button type="submit" className={styles.searchButton}>
            Suchen
          </button>
        </form>
      </div>
    </header>
  );
};

export default Header;