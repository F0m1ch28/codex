import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <span className={styles.logo}>Slexorifyx</span>
          <p>
            Präzise Gadget-Analysen, frühe Einblicke und eine Community, die Technik mit Leidenschaft
            lebt. Wir testen unabhängig und teilen fundierte Empfehlungen.
          </p>
        </div>
        <div className={styles.column}>
          <h3>Navigation</h3>
          <ul>
            <li>
              <NavLink to="/">Start</NavLink>
            </li>
            <li>
              <NavLink to="/ueber-uns">Über uns</NavLink>
            </li>
            <li>
              <NavLink to="/reviews">Reviews</NavLink>
            </li>
            <li>
              <NavLink to="/guides">Guides</NavLink>
            </li>
            <li>
              <NavLink to="/vergleiche">Vergleiche</NavLink>
            </li>
            <li>
              <NavLink to="/news">News</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Rechtliches</h3>
          <ul>
            <li>
              <NavLink to="/agb">AGB</NavLink>
            </li>
            <li>
              <NavLink to="/datenschutz">Datenschutz</NavLink>
            </li>
            <li>
              <NavLink to="/impressum">Impressum</NavLink>
            </li>
            <li>
              <NavLink to="/medienkit">Medienkit</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Kontakt</h3>
          <address className={styles.address}>
            <span>Slexorifyx</span>
            <span>Friedrichstraße 95</span>
            <span>10117 Berlin</span>
            <span>Deutschland</span>
            <a href="tel:+493098765432">+49 30 9876 5432</a>
            <a href="mailto:hello@slexorifyx.com">hello@slexorifyx.com</a>
          </address>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>&copy; {new Date().getFullYear()} Slexorifyx. Alle Rechte vorbehalten.</p>
      </div>
    </footer>
  );
};

export default Footer;