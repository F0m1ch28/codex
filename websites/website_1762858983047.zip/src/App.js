import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Reviews from './pages/Reviews';
import EarlyAccess from './pages/EarlyAccess';
import Vergleiche from './pages/Vergleiche';
import News from './pages/News';
import Guides from './pages/Guides';
import Team from './pages/Team';
import Kontakt from './pages/Kontakt';
import Medienkit from './pages/Medienkit';
import Services from './pages/Services';
import AGB from './pages/AGB';
import Datenschutz from './pages/Datenschutz';
import Impressum from './pages/Impressum';

const App = () => {
  return (
    <div className="app">
      <Header />
      <main id="hauptinhalt" className="main-content" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="/early-access" element={<EarlyAccess />} />
          <Route path="/vergleiche" element={<Vergleiche />} />
          <Route path="/news" element={<News />} />
          <Route path="/guides" element={<Guides />} />
          <Route path="/team" element={<Team />} />
          <Route path="/kontakt" element={<Kontakt />} />
          <Route path="/medienkit" element={<Medienkit />} />
          <Route path="/services" element={<Services />} />
          <Route path="/agb" element={<AGB />} />
          <Route path="/datenschutz" element={<Datenschutz />} />
          <Route path="/impressum" element={<Impressum />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;