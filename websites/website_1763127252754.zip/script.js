document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");
    const navLinks = document.querySelectorAll(".main-nav a");
    const scrollTopButton = document.getElementById("scrollTopButton");
    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            mainNav.classList.toggle("open");
        });
    }

    navLinks.forEach(link => {
        if (link.dataset.link && document.body.dataset.page === link.dataset.link) {
            link.classList.add("active");
        }
        link.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
            if (mainNav.classList.contains("open")) {
                mainNav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    });

    window.addEventListener("scroll", () => {
        if (window.scrollY > 240) {
            scrollTopButton.classList.add("visible");
        } else {
            scrollTopButton.classList.remove("visible");
        }
    });

    scrollTopButton.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    const consentKey = "ecovilleCookieConsent";
    if (localStorage.getItem(consentKey) === "accepted") {
        cookieBanner.classList.add("hidden");
    }

    acceptCookiesBtn.addEventListener("click", () => {
        localStorage.setItem(consentKey, "accepted");
        cookieBanner.classList.add("hidden");
    });

    const newsletterForm = document.querySelector(".newsletter-form");
    if (newsletterForm) {
        newsletterForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const emailField = newsletterForm.querySelector("input[type='email']");
            if (emailField.validity.valid) {
                alert("Merci pour votre inscription. Nous revenons vers vous très vite.");
                emailField.value = "";
            } else {
                emailField.focus();
            }
        });
    }
});