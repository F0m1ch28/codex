document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const acceptBtn = banner.querySelector('[data-cookie-accept]');
  const declineBtn = banner.querySelector('[data-cookie-decline]');
  const storedPreference = localStorage.getItem('cookieConsent');

  if (!storedPreference) {
    banner.classList.add('is-visible');
  }

  const closeBanner = (value) => {
    localStorage.setItem('cookieConsent', value);
    banner.classList.remove('is-visible');
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => closeBanner('accepted'));
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => closeBanner('declined'));
  }
});