(function () {
  const navToggle = document.querySelector('[data-js="nav-toggle"]');
  const navMenu = document.querySelector('[data-js="nav-menu"]');
  const cookiesBanner = document.querySelector('[data-js="cookies-banner"]');
  const cookiesModal = document.querySelector('[data-js="cookies-modal"]');
  const acceptCookiesBtn = document.querySelector('[data-js="accept-cookies"]');
  const rejectCookiesBtn = document.querySelector('[data-js="reject-cookies"]');
  const customizeCookiesBtn = document.querySelector('[data-js="customize-cookies"]');
  const resetPreferencesBtn = document.querySelector('[data-js="reset-preferences"]');
  const closePreferencesBtns = document.querySelectorAll('[data-js="close-preferences"]');
  const cookiesForm = document.querySelector('[data-js="cookies-form"]');
  const currentYearEl = document.querySelector('[data-js="current-year"]');

  const STORAGE_KEY = 'verdantgrid-cookie-preferences';
  const defaultPreferences = {
    necessary: true,
    analytics: false,
    marketing: false,
    timestamp: null
  };

  function toggleNav() {
    if (!navToggle || !navMenu) return;
    const isOpen = navMenu.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  }

  function trapFocus(element) {
    if (!element) return;
    const focusableSelectors = [
      'a[href]',
      'button:not([disabled])',
      'textarea:not([disabled])',
      'input:not([disabled])',
      'select:not([disabled])',
      '[tabindex]:not([tabindex="-1"])'
    ];
    const focusable = element.querySelectorAll(focusableSelectors.join(','));
    if (!focusable.length) return;

    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    function handleKeydown(event) {
      if (event.key !== 'Tab') return;

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    element.addEventListener('keydown', handleKeydown);
  }

  function getStoredPreferences() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) return null;
      return JSON.parse(stored);
    } catch (error) {
      console.error('Unable to parse cookie preferences', error);
      return null;
    }
  }

  function storePreferences(preferences) {
    try {
      const payload = {
        ...preferences,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (error) {
      console.error('Unable to store cookie preferences', error);
    }
  }

  function hideBanner() {
    if (cookiesBanner) {
      cookiesBanner.classList.remove('is-visible');
    }
  }

  function showBanner() {
    if (cookiesBanner) {
      cookiesBanner.classList.add('is-visible');
    }
  }

  function openModal() {
    if (!cookiesModal) return;
    cookiesModal.classList.add('is-visible');
    cookiesModal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('is-modal-open');
    const focusTarget = cookiesModal.querySelector('[data-js="save-preferences"]') || cookiesModal;
    focusTarget.focus({ preventScroll: true });
    trapFocus(cookiesModal);
  }

  function closeModal() {
    if (!cookiesModal) return;
    cookiesModal.classList.remove('is-visible');
    cookiesModal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('is-modal-open');
  }

  function populateForm(preferences) {
    if (!cookiesForm) return;
    const formData = { ...defaultPreferences, ...preferences };
    Array.from(cookiesForm.elements).forEach((input) => {
      if (input.type === 'checkbox' && formData.hasOwnProperty(input.name)) {
        input.checked = Boolean(formData[input.name]);
      }
    });
  }

  function initializeCookies() {
    const stored = getStoredPreferences();
    if (stored) {
      hideBanner();
      populateForm(stored);
    } else {
      showBanner();
      populateForm(defaultPreferences);
    }
  }

  function handleAcceptAll() {
    const preferences = {
      necessary: true,
      analytics: true,
      marketing: true
    };
    storePreferences(preferences);
    populateForm(preferences);
    hideBanner();
    closeModal();
  }

  function handleRejectAll() {
    const preferences = {
      necessary: true,
      analytics: false,
      marketing: false
    };
    storePreferences(preferences);
    populateForm(preferences);
    hideBanner();
    closeModal();
  }

  function handleSavePreferences(event) {
    event.preventDefault();
    if (!cookiesForm) return;
    const formData = new FormData(cookiesForm);
    const preferences = {
      necessary: true,
      analytics: formData.get('analytics') === 'on',
      marketing: formData.get('marketing') === 'on'
    };
    storePreferences(preferences);
    hideBanner();
    closeModal();
  }

  function handleResetPreferences() {
    populateForm(defaultPreferences);
  }

  if (navToggle) {
    navToggle.addEventListener('click', toggleNav);
  }

  if (navMenu) {
    navMenu.addEventListener('click', (event) => {
      if (event.target.closest('a') && window.innerWidth < 960) {
        toggleNav();
      }
    });
  }

  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener('click', handleAcceptAll);
  }

  if (rejectCookiesBtn) {
    rejectCookiesBtn.addEventListener('click', handleRejectAll);
  }

  if (customizeCookiesBtn) {
    customizeCookiesBtn.addEventListener('click', () => {
      openModal();
    });
  }

  closePreferencesBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      closeModal();
    });
  });

  if (cookiesModal) {
    cookiesModal.addEventListener('click', (event) => {
      if (event.target === cookiesModal) {
        closeModal();
      }
    });
  }

  if (cookiesForm) {
    cookiesForm.addEventListener('submit', handleSavePreferences);
  }

  if (resetPreferencesBtn) {
    resetPreferencesBtn.addEventListener('click', handleResetPreferences);
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && cookiesModal && cookiesModal.classList.contains('is-visible')) {
      closeModal();
    }
  });

  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear().toString();
  }

  initializeCookies();
})();