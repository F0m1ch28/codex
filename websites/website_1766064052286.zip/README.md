VERDANTGRID URBAN FARMING COOPERATIVE WEBSITE

Overview:
This repository contains the VerdantGrid multi-page marketing and compliance website featuring adaptive typography, responsive imagery, and accessible navigation for the cooperative’s digital presence.

Key features:
- Eleven fully responsive HTML pages with consistent navigation and footer systems.
- Modular CSS architecture using variables, utility classes, and multi-class inheritance.
- Real Pexels imagery served via picture elements with tailored srcset and sizes attributes.
- Cookies consent banner and modal with localStorage-powered preference management.
- Dedicated Privacy Policy, Terms of Service, and FAQ pages meeting compliance requirements.
- Supplemental files including sitemap, robots, manifest, and README for deployment readiness.

Getting started:
1. Place all files on a modern web server or open index.html in a browser.
2. Generate the favicon assets (see favicon.ico instructions) and add favicon-192.png and favicon-512.png for manifest compliance.
3. Customize copy, imagery, or color tokens in styles.css as needed; leverage CSS variables for theme updates.
4. Deploy to production and ensure HTTPS so cookie preferences persist reliably.

Scripts:
- script.js handles mobile navigation toggling, current year injection, and cookies banner + preferences logic.

Support:
Reach VerdantGrid digital stewardship at hello@verdantgrid.com for implementation questions.