document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const navToggle = document.getElementById('navToggle');
    const primaryNav = document.getElementById('primaryNav');
    const scrollTopBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const COOKIE_KEY = 'ordavision_cookie_accepted';

    // Mobile navigation
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.classList.toggle('active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen);
            body.classList.toggle('no-scroll', isOpen);
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (primaryNav.classList.contains('open')) {
                    primaryNav.classList.remove('open');
                    navToggle.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', false);
                    body.classList.remove('no-scroll');
                }
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    // Scroll to top button
    const toggleScrollButton = () => {
        if (!scrollTopBtn) return;
        if (window.scrollY > 400) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    };

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        window.addEventListener('scroll', toggleScrollButton);
        toggleScrollButton();
    }

    // Cookie banner logic
    if (cookieBanner && cookieAccept) {
        const accepted = localStorage.getItem(COOKIE_KEY);
        if (!accepted) {
            cookieBanner.classList.add('active');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'true');
            cookieBanner.classList.remove('active');
        });
    }

    // Contact form handling
    const contactForms = document.querySelectorAll('.contact-form');
    contactForms.forEach(form => {
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            const status = form.querySelector('.form-status');
            if (status) {
                status.textContent = 'Хабарламаңыз қабылданды. Біз жақын арада хабарласамыз.';
                status.style.color = '#1b998b';
            }
            form.reset();
        });
    });
});