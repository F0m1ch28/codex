document.addEventListener('DOMContentLoaded', () => {
  const currentYearEl = document.getElementById('current-year');
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.getElementById('nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('is-open');
    });

    navMenu.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', event => {
      const targetId = anchor.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
        event.preventDefault();
        targetElement.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const cookieChoice = localStorage.getItem('polarionCookieChoice');
    if (!cookieChoice) {
      cookieBanner.classList.add('is-visible');
    }

    cookieBanner.addEventListener('click', event => {
      const button = event.target.closest('button[data-cookie-action]');
      if (!button) return;

      const action = button.getAttribute('data-cookie-action');
      localStorage.setItem('polarionCookieChoice', action);
      cookieBanner.classList.remove('is-visible');
    });
  }

  const caseCards = document.querySelectorAll('.case-card');
  const caseDots = document.querySelectorAll('.carousel-dot');
  let caseIndex = 0;

  const updateCaseCarousel = (index) => {
    caseCards.forEach((card, i) => {
      card.classList.toggle('is-active', i === index);
    });
    caseDots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === index);
    });
  };

  if (caseCards.length > 0) {
    caseDots.forEach(dot => {
      dot.addEventListener('click', () => {
        caseIndex = Number(dot.dataset.target);
        updateCaseCarousel(caseIndex);
      });
    });

    setInterval(() => {
      caseIndex = (caseIndex + 1) % caseCards.length;
      updateCaseCarousel(caseIndex);
    }, 8000);
  }

  const testimonialCards = document.querySelectorAll('.testimonial-card');
  const testimonialDots = document.querySelectorAll('.testimonial-dot');
  let testimonialIndex = 0;

  const updateTestimonial = (index) => {
    testimonialCards.forEach((card, i) => {
      card.classList.toggle('is-active', i === index);
    });
    testimonialDots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === index);
    });
  };

  if (testimonialCards.length > 0) {
    testimonialDots.forEach(dot => {
      dot.addEventListener('click', () => {
        testimonialIndex = Number(dot.dataset.target);
        updateTestimonial(testimonialIndex);
      });
    });

    setInterval(() => {
      testimonialIndex = (testimonialIndex + 1) % testimonialCards.length;
      updateTestimonial(testimonialIndex);
    }, 9000);
  }

  const contactForm = document.getElementById('contact-form');
  const formMessage = document.getElementById('form-message');
  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();

      const name = contactForm.querySelector('#name');
      const email = contactForm.querySelector('#email');
      const service = contactForm.querySelector('#service');
      const message = contactForm.querySelector('#message');

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      let valid = true;

      [name, email, service, message].forEach(field => {
        if (!field.value.trim()) {
          valid = false;
          field.setAttribute('aria-invalid', 'true');
        } else {
          field.removeAttribute('aria-invalid');
        }
      });

      if (!emailPattern.test(email.value.trim())) {
        valid = false;
        email.setAttribute('aria-invalid', 'true');
      }

      if (valid) {
        if (formMessage) {
          formMessage.textContent = 'Thank you. Our engineering team will respond shortly.';
          formMessage.style.color = '#96f1ff';
        }
        contactForm.reset();
      } else {
        if (formMessage) {
          formMessage.textContent = 'Please complete all required fields with valid information.';
          formMessage.style.color = '#ff8080';
        }
      }
    });
  }
});