document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.primary-navigation');
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const currentYearSpan = document.getElementById('current-year');
  const contactForm = document.getElementById('contact-form');

  /* Mobile navigation toggle */
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (navMenu.classList.contains('open')) {
          navMenu.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  /* Active navigation highlighting */
  const pageKey = document.body.dataset.page;
  if (pageKey) {
    document.querySelectorAll('.nav-menu a').forEach(link => {
      if (link.dataset.page === pageKey) {
        link.classList.add('active');
      }
    });
  }

  /* Update current year */
  if (currentYearSpan) {
    currentYearSpan.textContent = new Date().getFullYear();
  }

  /* Smooth scroll for internal anchors */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', event => {
      const targetId = anchor.getAttribute('href').substring(1);
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        event.preventDefault();
        targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* Cookie banner logic */
  const COOKIE_KEY = 'apexhorizon.cookieConsent';
  const consent = localStorage.getItem(COOKIE_KEY);

  if (!consent && cookieBanner) {
    setTimeout(() => cookieBanner.classList.add('show'), 600);
  }

  const handleConsent = choice => {
    localStorage.setItem(COOKIE_KEY, choice);
    cookieBanner.classList.remove('show');
  };

  if (acceptBtn) acceptBtn.addEventListener('click', () => handleConsent('accepted'));
  if (declineBtn) declineBtn.addEventListener('click', () => handleConsent('declined'));

  /* Contact form validation */
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      let isValid = true;

      const nameInput = contactForm.querySelector('#name');
      const emailInput = contactForm.querySelector('#email');
      const messageInput = contactForm.querySelector('#message');
      const successMessage = document.getElementById('form-success');

      const showError = (input, message) => {
        const errorEl = contactForm.querySelector(`.error-message[data-for="${input.id}"]`);
        if (errorEl) {
          errorEl.textContent = message;
        }
        input.setAttribute('aria-invalid', 'true');
        isValid = false;
      };

      const clearError = input => {
        const errorEl = contactForm.querySelector(`.error-message[data-for="${input.id}"]`);
        if (errorEl) {
          errorEl.textContent = '';
        }
        input.removeAttribute('aria-invalid');
      };

      /* Name validation */
      if (!nameInput.value.trim()) {
        showError(nameInput, 'Please enter your full name.');
      } else {
        clearError(nameInput);
      }

      /* Email validation */
      const emailValue = emailInput.value.trim();
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailValue) {
        showError(emailInput, 'Please enter your email address.');
      } else if (!emailPattern.test(emailValue)) {
        showError(emailInput, 'Please enter a valid email address.');
      } else {
        clearError(emailInput);
      }

      /* Message validation */
      if (!messageInput.value.trim()) {
        showError(messageInput, 'Please provide project details.');
      } else {
        clearError(messageInput);
      }

      if (isValid) {
        if (successMessage) {
          successMessage.textContent = 'Thank you! We will connect with you shortly.';
        }
        contactForm.reset();
      } else if (successMessage) {
        successMessage.textContent = '';
      }
    });
  }
});