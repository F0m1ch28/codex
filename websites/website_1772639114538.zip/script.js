document.addEventListener('DOMContentLoaded', () => {
  const bodyDataset = document.body.dataset.page;
  if (bodyDataset) {
    const activeLink = document.querySelector(`.site-nav a[data-page="${bodyDataset}"]`);
    if (activeLink) activeLink.classList.add('is-active');
  }

  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('active');
      siteNav.classList.toggle('open');
    });
  }

  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    const status = contactForm.querySelector('.form-status');
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!contactForm.checkValidity()) {
        status.textContent = 'Проверьте корректность данных.';
        status.style.color = '#d95c5c';
        contactForm.reportValidity();
        return;
      }
      status.textContent = 'Спасибо! Мы свяжемся с вами в ближайшее время.';
      status.style.color = '#4fc3f7';
      contactForm.reset();
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const preference = localStorage.getItem('cookiePreference');
    if (!preference) {
      setTimeout(() => cookieBanner.classList.add('show'), 600);
    }
    cookieBanner.addEventListener('click', (event) => {
      const button = event.target.closest('[data-cookie]');
      if (!button) return;
      const value = button.dataset.cookie;
      localStorage.setItem('cookiePreference', value);
      cookieBanner.classList.remove('show');
    });
  }
});