import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Как создавать эмоциональные визуальные концепции',
    date: '5 марта 2024',
    category: 'Арт-дирекшн',
    description:
      'Говорим о визуальном сторителлинге, настроении и работе с референсами, чтобы усилить эмоции зрителя.',
    image: 'https://picsum.photos/id/160/780/480'
  },
  {
    title: 'Гибрид физических и цифровых пространств',
    date: '19 февраля 2024',
    category: 'Инсталляции',
    description:
      'Исследуем как AR и интерактивные элементы смешивают реальности, создавая новый опыт взаимодействия.',
    image: 'https://picsum.photos/id/170/780/480'
  },
  {
    title: 'Современная типографика для бренда',
    date: '2 февраля 2024',
    category: 'Дизайн',
    description:
      'Отбираем шрифтовые пары, систематизируем масштаб и сетку, чтобы айдентика звучала цельно в любых носителях.',
    image: 'https://picsum.photos/id/190/780/480'
  }
];

const Blog = () => (
  <>
    <Helmet>
      <title>Блог ArtVista — заметки о дизайне и искусстве</title>
      <meta
        name="description"
        content="Статьи студии ArtVista о дизайне, арт-дирекшне, иллюстрации и экспериментальных проектах."
      />
    </Helmet>
    <section className={`${styles.hero} container`}>
      <h1>Блог ArtVista</h1>
      <p>
        Делимся наблюдениями и идеями о визуальной культуре, рассказываем о backstage проектов и
        вдохновляющих практиках из мира искусства.
      </p>
    </section>
    <section className="container">
      <div className={styles.grid}>
        {posts.map((post) => (
          <article key={post.title} className={styles.card}>
            <div className={styles.imageWrap}>
              <img src={post.image} alt={`Статья студии ArtVista: ${post.title}`} />
            </div>
            <div className={styles.cardBody}>
              <p className={styles.meta}>
                {post.date} · {post.category}
              </p>
              <h2>{post.title}</h2>
              <p>{post.description}</p>
              <button type="button">Читать полностью</button>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;