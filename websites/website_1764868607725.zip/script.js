document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = mainNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen);
      navToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const consentKey = "icaCookieConsent";

  if (cookieBanner && acceptBtn && declineBtn) {
    const savedConsent = localStorage.getItem(consentKey);

    if (!savedConsent) {
      requestAnimationFrame(() => cookieBanner.classList.add("visible"));
    }

    const handleConsent = (value) => {
      localStorage.setItem(consentKey, value);
      cookieBanner.classList.remove("visible");
    };

    acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    declineBtn.addEventListener("click", () => handleConsent("declined"));
  }
});