document.addEventListener('DOMContentLoaded', function () {
  const docBody = document.body;

  const navToggle = document.getElementById('nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      siteNav.classList.toggle('open');
      navToggle.classList.toggle('open');
    });
  }

  const cookieKey = 'noelGiftCookiesChoice';
  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const cookieDecline = document.getElementById('cookie-decline');

  if (cookieBanner && cookieAccept && cookieDecline) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (!storedChoice) {
      setTimeout(() => cookieBanner.classList.add('show'), 600);
    }

    cookieAccept.addEventListener('click', function () {
      localStorage.setItem(cookieKey, 'accepted');
      cookieBanner.classList.remove('show');
    });

    cookieDecline.addEventListener('click', function () {
      localStorage.setItem(cookieKey, 'declined');
      cookieBanner.classList.remove('show');
    });
  }

  const cartKey = 'noelGiftCartCount';
  let cartCount = parseInt(localStorage.getItem(cartKey), 10);
  if (Number.isNaN(cartCount)) cartCount = 0;

  const cartDisplay = document.getElementById('cart-count');
  const renderCartCount = () => {
    if (cartDisplay) cartDisplay.textContent = String(cartCount);
  };
  renderCartCount();

  const addToCartButtons = document.querySelectorAll('[data-add-to-cart]');
  addToCartButtons.forEach((button) => {
    button.addEventListener('click', function (event) {
      event.preventDefault();
      cartCount += 1;
      localStorage.setItem(cartKey, String(cartCount));
      renderCartCount();
      button.classList.add('added');
      button.textContent = 'Added!';
      setTimeout(() => {
        button.classList.remove('added');
        const original = button.getAttribute('data-original-text');
        button.textContent = original || 'Add to Cart';
      }, 1500);
    });
    if (!button.getAttribute('data-original-text')) {
      button.setAttribute('data-original-text', button.textContent.trim());
    }
  });

  const customizeForm = document.getElementById('customize-form');
  if (customizeForm) {
    const occasionSelect = document.getElementById('gift-occasion');
    const paletteRadios = customizeForm.querySelectorAll('input[name="gift-palette"]');
    const recipientInput = document.getElementById('recipient-name');
    const messageInput = document.getElementById('gift-message');
    const previewPalette = document.querySelector('.preview-palette');
    const previewTitle = document.querySelector('.preview-title');
    const previewMessage = document.querySelector('.preview-message');
    const previewOccasion = document.querySelector('.preview-occasion');
    const previewImage = document.getElementById('custom-preview-image');
    const previewCTA = document.querySelector('.preview-cta');
    const formMessage = document.getElementById('customizer-message');

    const paletteMap = {
      ruby: {
        color: '#bf1730',
        image: 'https://picsum.photos/seed/rubybox/720/480'
      },
      evergreen: {
        color: '#145c3a',
        image: 'https://picsum.photos/seed/evergreenbox/720/480'
      },
      champagne: {
        color: '#d4af37',
        image: 'https://picsum.photos/seed/champagnebox/720/480'
      }
    };

    const renderPreview = () => {
      const occasionValue = occasionSelect ? occasionSelect.value : 'celebration';
      const paletteValue = Array.from(paletteRadios).find((radio) => radio.checked)?.value || 'ruby';
      const recipientValue = recipientInput?.value.trim() || 'Dear Friend';
      const messageValue = messageInput?.value.trim() || 'Wishing you the most magical celebration filled with love, sparkle, and sweet surprises.';

      const paletteData = paletteMap[paletteValue] || paletteMap.ruby;

      if (previewPalette) previewPalette.style.background = paletteData.color;
      if (previewImage) previewImage.src = paletteData.image;
      if (previewTitle) previewTitle.textContent = `${occasionValue} Gift Box`;
      if (previewOccasion) previewOccasion.textContent = `For ${recipientValue}`;
      if (previewMessage) previewMessage.textContent = messageValue;
      if (previewCTA) previewCTA.textContent = `Palette • ${paletteValue.charAt(0).toUpperCase() + paletteValue.slice(1)}`;
    };

    renderPreview();

    occasionSelect?.addEventListener('change', renderPreview);
    recipientInput?.addEventListener('input', renderPreview);
    messageInput?.addEventListener('input', renderPreview);
    paletteRadios.forEach((radio) => radio.addEventListener('change', renderPreview));

    customizeForm.addEventListener('submit', function (event) {
      event.preventDefault();
      if (recipientInput && !recipientInput.value.trim()) {
        recipientInput.focus();
        if (formMessage) {
          formMessage.textContent = 'Please add a recipient name to personalize the gift.';
          formMessage.style.color = '#b80d28';
        }
        return;
      }
      cartCount += 1;
      localStorage.setItem(cartKey, String(cartCount));
      renderCartCount();
      if (formMessage) {
        formMessage.textContent = 'Your custom gift box was added to the cart with your personal touches!';
        formMessage.style.color = '#0f5f3f';
      }
      customizeForm.reset();
      renderPreview();
    });
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    const status = document.getElementById('contact-form-message');
    contactForm.addEventListener('submit', function (event) {
      const formValid = contactForm.checkValidity();
      if (!formValid) {
        status.textContent = 'Please fill in all required fields so we can assist you promptly.';
        status.style.color = '#b80d28';
        status.style.display = 'block';
        return;
      }
      event.preventDefault();
      status.textContent = 'Thank you! Our concierge team will reach out within 24 hours.';
      status.style.color = '#0f5f3f';
      status.style.display = 'block';
      contactForm.reset();
    });
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const occasionCards = document.querySelectorAll('[data-occasion]');
  if (filterButtons.length && occasionCards.length) {
    filterButtons.forEach((button) => {
      button.addEventListener('click', function () {
        const target = button.getAttribute('data-filter');
        filterButtons.forEach((btn) => btn.classList.remove('active'));
        button.classList.add('active');

        occasionCards.forEach((card) => {
          const category = card.getAttribute('data-occasion');
          if (target === 'all' || category === target) {
            card.style.display = '';
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
          } else {
            card.style.opacity = '0';
            card.style.transform = 'scale(0.95)';
            setTimeout(() => {
              card.style.display = 'none';
            }, 280);
          }
        });
      });
    });
  }
});