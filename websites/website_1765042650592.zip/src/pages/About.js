import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './About.module.css';

const AboutPage = () => {
  usePageMetadata(
    'О компании — Компания',
    'Компания объединяет экспертов в консалтинге, технологиях и аналитике, помогая бизнесу выстраивать устойчивое развитие.'
  );

  const milestones = [
    {
      year: '2012',
      title: 'Основание компании',
      description: 'Команда консультантов и продуктовых экспертов запускает совместную практику.',
    },
    {
      year: '2015',
      title: 'Первый международный проект',
      description: 'Выигран тендер на трансформацию операционной модели европейского холдинга.',
    },
    {
      year: '2019',
      title: 'Собственная аналитическая платформа',
      description: 'Разработан модуль быстрых бизнес-дашбордов на основе открытых данных и BI-инструментов.',
    },
    {
      year: '2023',
      title: 'Расширение партнерской сети',
      description: 'К компании присоединились команды design thinking и специалистов по внедрению AI-решений.',
    },
  ];

  const values = [
    {
      title: 'Ответственность',
      description: 'Держим слово и сопровождаем клиента до момента, когда изменение закреплено в компании.',
    },
    {
      title: 'Прозрачность',
      description: 'Строим процессы открыто, чтобы все участники понимали, что происходит на каждом этапе.',
    },
    {
      title: 'Практичность',
      description: 'Проверяем идеи на жизнеспособность и помогаем внедрять только то, что работает.',
    },
    {
      title: 'Поддержка',
      description: 'Инвестируем в развитие команд клиента и готовы оставаться рядом в новых проектах.',
    },
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-labelledby="about-hero-title">
        <div className={styles.heroContent}>
          <span className={styles.tag}>О компании</span>
          <h1 id="about-hero-title">Мы строим долгосрочные партнерства, а не разовые проекты</h1>
          <p>
            «Компания» — это экосистема экспертов, объединенная общей целью: помогать организациям двигаться быстрее,
            оставаясь гибкими и ориентированными на клиента. Мы собрали компетенции в консалтинге, цифровых продуктах,
            аналитике и управлении изменениями, чтобы закрывать задачи целиком.
          </p>
        </div>
      </section>

      <section className={styles.mission} aria-labelledby="mission-title">
        <div className={styles.missionContent}>
          <div>
            <span className={styles.tag}>Миссия</span>
            <h2 id="mission-title">Вдохновлять команды на изменения и помогать им реализовывать идеи</h2>
          </div>
          <p>
            Мы верим, что любая трансформация начинается с людей. Наша роль — обеспечить уверенность в каждом шаге
            и создать условия, в которых инновации становятся частью культуры компании. Мы предлагаем стратегическую
            экспертизу, технологическую поддержку и внимание к деталям.
          </p>
        </div>
      </section>

      <section className={styles.values} aria-labelledby="values-title">
        <div className={styles.sectionHeader}>
          <span className={styles.tag}>Ценности</span>
          <h2 id="values-title">Принципы, которые ведут нас вперед</h2>
        </div>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.milestones} aria-labelledby="milestones-title">
        <div className={styles.sectionHeader}>
          <span className={styles.tag}>История</span>
          <h2 id="milestones-title">Несколько важных этапов пути</h2>
        </div>
        <div className={styles.timeline}>
          {milestones.map((item) => (
            <article key={item.year} className={styles.milestone}>
              <span className={styles.year}>{item.year}</span>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.approach} aria-labelledby="approach-title">
        <div className={styles.approachContent}>
          <div>
            <span className={styles.tag}>Подход</span>
            <h2 id="approach-title">Работаем на стыке стратегии, продукта и технологий</h2>
          </div>
          <ul className={styles.approachList}>
            <li>
              <h3>Единая команда</h3>
              <p>Мы интегрируемся в структуру клиента, чтобы ускорить коммуникацию и достичь целостности решений.</p>
            </li>
            <li>
              <h3>Проверка гипотез</h3>
              <p>Быстро тестируем идеи и считаем экономический эффект до старта внедрения.</p>
            </li>
            <li>
              <h3>Система знаний</h3>
              <p>Документируем процессы и передаем методики, чтобы развитие продолжалось и после завершения проекта.</p>
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;