import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Home.module.css';

const HomePage = () => {
  usePageMetadata(
    'Компания — Ваш надежный партнер',
    'Компания предлагает комплексные бизнес-решения: консалтинг, цифровые продукты, сопровождение проектов и поддержку команд.'
  );

  const heroImage = 'https://picsum.photos/1600/900?random=101';
  const secondaryImage = 'https://picsum.photos/800/600?random=102';

  const statsData = [
    { label: 'Лет на рынке', value: 12, suffix: '+' },
    { label: 'Реализованных проектов', value: 180, suffix: '+' },
    { label: 'Экспертов в команде', value: 65, suffix: '' },
    { label: 'Партнеров по всему миру', value: 24, suffix: '' },
  ];

  const services = [
    {
      title: 'Стратегический консалтинг',
      description: 'Помогаем выработать устойчивую стратегию развития и управлять изменениями.',
      icon: (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path
            d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
          />
          <path
            d="M7 7l10 10M7 17l10-10"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      ),
    },
    {
      title: 'Цифровые продукты',
      description: 'Проектируем и внедряем цифровые решения, ориентированные на пользователя.',
      icon: (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <rect x="3" y="3" width="18" height="14" rx="2" fill="none" stroke="currentColor" strokeWidth="1.6" />
          <path d="M8 21h8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M12 17v4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      title: 'Операционная поддержка',
      description: 'Берем на себя контроль проектов, оптимизируем процессы и обучаем команды.',
      icon: (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.6" />
          <path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      title: 'Аналитика и инсайты',
      description: 'Собираем данные, строим модели и находим точки роста для вашего бизнеса.',
      icon: (
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path
            d="M4 19V5M8 19v-7M12 19v-4M16 19V8M20 19V3"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      ),
    },
  ];

  const testimonials = [
    {
      quote:
        'Команда «Компания» помогла нам выстроить прозрачные процессы и запустить новую цифровую платформу. Благодаря их сопровождению мы ускорили вывод продукта на рынок и повысили удовлетворенность клиентов.',
      author: 'Ирина Кузнецова',
      role: 'Директор по развитию, «Альфа Про»',
    },
    {
      quote:
        'Умеют слушать, предлагают конкретные решения и работают как единая команда с нашими специалистами. Особенно ценим их способность быстро адаптироваться к изменениям и держать курс на результат.',
      author: 'Андрей Смирнов',
      role: 'Генеральный директор, «Бета Консалт»',
    },
    {
      quote:
        'Благодаря совместному проекту мы получили прозрачную аналитическую систему и сэкономили значительные ресурсы. Это надежный партнер, которому можно доверить сложные задачи.',
      author: 'Наталья Петрова',
      role: 'Операционный директор, «Gamma Labs»',
    },
  ];

  const teamMembers = [
    {
      name: 'Станислав Елисеев',
      role: 'Управляющий партнер',
      description: 'Стратег и наставник команд с опытом трансформации международных проектов.',
      image: 'https://picsum.photos/400/400?random=301',
    },
    {
      name: 'Мария Орлова',
      role: 'Директор по продукту',
      description: 'Выстраивает продуктовое видение и управляет портфелем цифровых решений.',
      image: 'https://picsum.photos/400/400?random=302',
    },
    {
      name: 'Алексей Гордеев',
      role: 'Руководитель практики аналитики',
      description: 'Создает аналитические модели и внедряет культуру принятия решений на основе данных.',
      image: 'https://picsum.photos/400/400?random=303',
    },
    {
      name: 'Елена Миронова',
      role: 'Партнер по операционной эффективности',
      description: 'Оптимизирует процессы и помогает командам работать слаженно и прозрачно.',
      image: 'https://picsum.photos/400/400?random=304',
    },
  ];

  const projects = [
    {
      title: 'Переосмысление клиентского пути',
      category: 'Консалтинг',
      description: 'Комплексный аудит процессов обслуживания и внедрение системы управления опытом клиентов.',
      image: 'https://picsum.photos/1200/800?random=401',
    },
    {
      title: 'Цифровая платформа партнеров',
      category: 'Технологии',
      description: 'Создание единого цифрового пространства для взаимодействия с партнерской сетью.',
      image: 'https://picsum.photos/1200/800?random=402',
    },
    {
      title: 'Система аналитики данных',
      category: 'Аналитика',
      description: 'Автоматизация отчетности и внедрение dashboards для управленческой команды.',
      image: 'https://picsum.photos/1200/800?random=403',
    },
    {
      title: 'Программа развития команд',
      category: 'Инициативы',
      description: 'Серия обучающих модулей и наставничество для лидеров проектных групп.',
      image: 'https://picsum.photos/1200/800?random=404',
    },
  ];

  const faqItems = [
    {
      question: 'Какие задачи вы помогаете решать в первую очередь?',
      answer:
        'Мы работаем с компаниями, которым необходимо ускорить рост, оптимизировать процессы и внедрять цифровые продукты. Берем на себя стратегические и операционные задачи, чтобы команда клиента сосредоточилась на ключевых инициативах.',
    },
    {
      question: 'С какими отраслями вы работаете?',
      answer:
        'Наши проекты охватывают финансы, ритейл, логистику, производство и технологические компании. Мы адаптируем подход, ориентируясь на специфику отрасли и внутреннюю культуру организации.',
    },
    {
      question: 'Можно ли начинать сотрудничество с пилотного проекта?',
      answer:
        'Да, мы часто начинаем с пилотной инициативы, чтобы подтвердить гипотезы и показать результат. После этого формируем масштабный план и команду внедрения.',
    },
    {
      question: 'Как организована коммуникация с вашей командой?',
      answer:
        'Мы формируем совместную рабочую группу, устанавливаем прозрачный график встреч и предоставляем доступ к единому рабочему пространству, чтобы статус проекта всегда был виден в режиме реального времени.',
    },
  ];

  const blogPosts = [
    {
      title: 'Как выстроить устойчивую цифровую стратегию в условиях неопределенности',
      date: '12 марта 2024',
      excerpt:
        'Пять практических шагов, которые помогут руководителям сочетать системное планирование и гибкость, не теряя фокус на клиенте.',
      link: '/o-kompanii',
    },
    {
      title: 'Операционная трансформация: что важно контролировать ежедневно',
      date: '26 февраля 2024',
      excerpt:
        'Разбираем ключевые метрики, без которых сложно управлять масштабными проектами и поддерживать качество процессов.',
      link: '/uslugi',
    },
    {
      title: 'Командная культура как драйвер инноваций',
      date: '7 февраля 2024',
      excerpt:
        'Поделились опытом, как создать среду, в которой идеи сотрудников превращаются в измеримый бизнес-результат.',
      link: '/o-kompanii',
    },
  ];

  const [statsValues, setStatsValues] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Все');
  const [openQuestion, setOpenQuestion] = useState(null);

  useEffect(() => {
    let animationFrame;
    const start = performance.now();
    const duration = 1600;

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setStatsValues(
        statsData.map((item) => Math.round(item.value * progress))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      } else {
        setStatsValues(statsData.map((item) => item.value));
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  const filteredProjects =
    activeCategory === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const toggleQuestion = (index) => {
    setOpenQuestion((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-label="Главный раздел">
        <div
          className={styles.heroBackground}
          style={{ backgroundImage: `url(${heroImage})` }}
          role="presentation"
        />
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <div className={styles.heroText}>
            <span className={styles.heroTag}>Премиальное сопровождение бизнеса</span>
            <h1 className={styles.heroTitle}>
              «Компания» — ваш надежный партнер в стратегических решениях
            </h1>
            <p className={styles.heroSubtitle}>
              Соединяем стратегию, технологии и команду, чтобы ваши проекты приносили результат
              быстрее. Мы сопровождаем бизнес от идеи до масштабирования.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryAction}>
                Связаться с консультантом
              </Link>
              <Link to="/o-kompanii" className={styles.secondaryAction}>
                Узнать больше о нас
              </Link>
            </div>
          </div>
          <div className={styles.heroCard} role="presentation">
            <h2>Сфокусированы на результате</h2>
            <p>
              Превращаем сложные задачи в понятные шаги и строим систему, в которой каждое решение подкреплено данными.
            </p>
            <div className={styles.heroHighlights}>
              <div>
                <span>01</span>
                <p>Планируем и реализуем изменения, не нарушая текущие процессы.</p>
              </div>
              <div>
                <span>02</span>
                <p>Предлагаем решения, которые остаются эффективными после завершения проекта.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.aboutPreview} aria-labelledby="about-preview-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>О компании</span>
          <h2 id="about-preview-title">Делаем бизнес гибким, технологичным и ориентированным на клиента</h2>
          <p>
            Мы объединяем консультантов, аналитиков и продуктовых менеджеров, чтобы вместе с вами находить
            точки роста, выстраивать процессы и внедрять цифровые решения. Узнайте больше о подходе команды «Компания».
          </p>
          <Link to="/o-kompanii" className={styles.inlineLink}>Подробнее о компании</Link>
        </div>
        <div className={styles.aboutImageWrapper}>
          <img src={secondaryImage} alt="Команда компании обсуждает проект" loading="lazy" />
        </div>
      </section>

      <section className={styles.stats} aria-label="Ключевые показатели">
        <div className={styles.statsGrid}>
          {statsData.map((item, index) => (
            <article key={item.label} className={styles.statCard}>
              <p className={styles.statValue}>
                {statsValues[index]}
                <span>{item.suffix}</span>
              </p>
              <p className={styles.statLabel}>{item.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.services} aria-labelledby="home-services-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Услуги</span>
          <h2 id="home-services-title">Выбирайте направление развития</h2>
          <p>
            Мы создаем команды под задачи клиента и фиксируем понятные точки контроля, чтобы проекты
            двигались без задержек.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <div className={styles.serviceIcon}>{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
        <div className={styles.servicesCta}>
          <Link to="/uslugi" className={styles.primaryAction}>Посмотреть все направления</Link>
        </div>
      </section>

      <section className={styles.advantages} aria-labelledby="advantages-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Почему мы</span>
          <h2 id="advantages-title">Сфокусированы на том, что важно вашему бизнесу</h2>
        </div>
        <ul className={styles.advantagesList}>
          <li>
            <h3>Работаем в логике партнёрства</h3>
            <p>Погружаемся в контекст бизнеса и выстраиваем команду вместе с клиентом.</p>
          </li>
          <li>
            <h3>Поддержка на каждом этапе</h3>
            <p>Берем ответственность за результат: от идеи до внедрения и обучения команды.</p>
          </li>
          <li>
            <h3>Аналитика в основе решений</h3>
            <p>Строим систему показателей и делаем так, чтобы данные были доступны в любое время.</p>
          </li>
          <li>
            <h3>Гибкость и прозрачность</h3>
            <p>Фиксируем промежуточные результаты и корректируем план вместе с вами.</p>
          </li>
        </ul>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Как мы работаем</span>
          <h2 id="process-title">От первой встречи до запуска</h2>
        </div>
        <ol className={styles.processSteps}>
          <li>
            <span>1</span>
            <h3>Диагностика и приоритезация</h3>
            <p>Выявляем точки роста, определяем ключевые метрики и согласуем цель проекта.</p>
          </li>
          <li>
            <span>2</span>
            <h3>Дизайн решения</h3>
            <p>Формируем дорожную карту, создаем прототипы и согласуем архитектуру изменений.</p>
          </li>
          <li>
            <span>3</span>
            <h3>Внедрение и контроль</h3>
            <p>Запускаем пилоты, расширяем решение и выстраиваем процессы управления.</p>
          </li>
          <li>
            <span>4</span>
            <h3>Масштабирование и обучение</h3>
            <p>Передаем знания команде, настраиваем систему мониторинга и поддержку.</p>
          </li>
        </ol>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Отзывы</span>
          <h2 id="testimonials-title">Партнеры о сотрудничестве</h2>
        </div>
        <div className={styles.testimonialCard}>
          <p className={styles.testimonialQuote}>«{testimonials[testimonialIndex].quote}»</p>
          <p className={styles.testimonialAuthor}>
            {testimonials[testimonialIndex].author} — {testimonials[testimonialIndex].role}
          </p>
          <div className={styles.testimonialDots} role="tablist" aria-label="Переключить отзыв">
            {testimonials.map((_, index) => (
              <button
                key={`dot-${index}`}
                type="button"
                className={`${styles.dot} ${testimonialIndex === index ? styles.dotActive : ''}`}
                onClick={() => setTestimonialIndex(index)}
                aria-label={`Показать отзыв ${index + 1}`}
                aria-selected={testimonialIndex === index}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Команда</span>
          <h2 id="team-title">Эксперты, которые ведут проекты</h2>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImageWrapper}>
                <img src={member.image} alt={`${member.name} — ${member.role}`} loading="lazy" />
              </div>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.role}</p>
                <p className={styles.teamDescription}>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Проекты</span>
          <h2 id="projects-title">Недавние истории успеха</h2>
        </div>
        <div className={styles.projectFilters} role="tablist" aria-label="Фильтр проектов">
          {['Все', 'Консалтинг', 'Технологии', 'Аналитика', 'Инициативы'].map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
              onClick={() => setActiveCategory(category)}
              aria-pressed={activeCategory === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectInfo}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>FAQ</span>
          <h2 id="faq-title">Частые вопросы</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div key={item.question} className={styles.faqItem}>
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => toggleQuestion(index)}
                aria-expanded={openQuestion === index}
              >
                <span>{item.question}</span>
                <span className={styles.faqIcon}>{openQuestion === index ? '–' : '+'}</span>
              </button>
              {openQuestion === index && (
                <div className={styles.faqAnswer}>
                  <p>{item.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-title">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Идеи и практика</span>
          <h2 id="blog-title">Что мы обсуждаем сегодня</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <p className={styles.blogDate}>{post.date}</p>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <Link to={post.link} className={styles.inlineLink}>
                Читать дальше
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-title">
        <div className={styles.ctaContent}>
          <h2 id="cta-title">Готовы обсудить задачу? Давайте назначим встречу</h2>
          <p>
            Оставьте заявку и мы предложим удобный формат взаимодействия. Начнем с диагностики и определим,
            как быстро можно перейти к результату.
          </p>
          <Link to="/kontakty" className={styles.primaryAction}>
            Запланировать консультацию
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;