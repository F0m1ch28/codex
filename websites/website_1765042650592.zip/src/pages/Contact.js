import React, { useState } from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Contact.module.css';

const ContactsPage = () => {
  usePageMetadata(
    'Контакты — Компания',
    'Свяжитесь с компанией Компания: адрес в Москве, телефон +7 (495) 000-00-00, электронная почта info@kompaniya.ru.'
  );

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Укажите ваше имя';
    if (!formData.email.trim()) newErrors.email = 'Введите email';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Введите корректный email';
    if (!formData.message.trim()) newErrors.message = 'Расскажите о задаче';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus({ type: 'error', message: 'Проверьте, пожалуйста, корректность данных.' });
      return;
    }
    setStatus({
      type: 'success',
      message: 'Спасибо! Мы получили ваше сообщение и свяжемся с вами в ближайшее время.',
    });
    setFormData({ name: '', email: '', company: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-labelledby="contact-hero-title">
        <div className={styles.heroContent}>
          <span className={styles.tag}>Контакты</span>
          <h1 id="contact-hero-title">Расскажите нам о вашей задаче</h1>
          <p>
            Мы организуем встречу, предложим формат сотрудничества и команду, которая поможет быстро перейти к результату.
          </p>
        </div>
        <div className={styles.contactInfo}>
          <h2>Наша площадка в Москве</h2>
          <ul>
            <li>
              <span>Адрес</span>
              <p>г. Москва, ул. Примерная, д. 10</p>
            </li>
            <li>
              <span>Телефон</span>
              <a href="tel:+74950000000">+7 (495) 000-00-00</a>
            </li>
            <li>
              <span>Email</span>
              <a href="mailto:info@kompaniya.ru">info@kompaniya.ru</a>
            </li>
          </ul>
        </div>
      </section>

      <section className={styles.formSection} aria-labelledby="contact-form-title">
        <div className={styles.formCard}>
          <h2 id="contact-form-title">Напишите нам</h2>
          <p>
            Чем подробнее вы опишете задачу, тем точнее мы сможем подготовиться к первому разговору.
          </p>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <label className={styles.field}>
              <span>Имя*</span>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </label>

            <label className={styles.field}>
              <span>Email*</span>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </label>

            <label className={styles.field}>
              <span>Компания</span>
              <input
                type="text"
                name="company"
                value={formData.company}
                onChange={handleChange}
              />
            </label>

            <label className={styles.field}>
              <span>Сообщение*</span>
              <textarea
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </label>

            <button type="submit" className={styles.submitButton}>
              Отправить сообщение
            </button>
            {status.message && (
              <div
                className={`${styles.status} ${status.type === 'success' ? styles.success : styles.errorMessage}`}
                role="status"
                aria-live="polite"
              >
                {status.message}
              </div>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;