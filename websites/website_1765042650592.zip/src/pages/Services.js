import React, { useState } from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Services.module.css';

const services = [
  {
    name: 'Стратегический консалтинг',
    description:
      'Проводим стратегические сессии, оцениваем потенциал рынков, формируем roadmap и помогаем командам увидеть единое направление развития.',
    benefits: [
      'Совместная разработка стратегических инициатив',
      'Формирование прозрачной системы KPI',
      'Поддержка руководителей в управлении изменениями',
    ],
  },
  {
    name: 'Цифровые продукты',
    description:
      'Создаем цифровые решения, начиная с исследования пользовательских сценариев и заканчивая сопровождением продукта после запуска.',
    benefits: [
      'Product discovery и управление бэклогом',
      'UI/UX-дизайн, основанный на данных',
      'Разработка MVP и дальнейшее масштабирование',
    ],
  },
  {
    name: 'Операционная поддержка',
    description:
      'Выстраиваем процессы, автоматизируем рутину и заботимся о том, чтобы команды работали слаженно и эффективно.',
    benefits: [
      'Настройка операционных процессов и регламентов',
      'Управление проектами и PMO',
      'Обучение ключевых ролей и поддержка внедрения',
    ],
  },
  {
    name: 'Бизнес-аналитика',
    description:
      'Помогаем выстроить культуру работы с данными, создаем архитектуру аналитических решений и развиваем BI-инструменты.',
    benefits: [
      'Аудит и настройка источников данных',
      'Построение dashboards и прогнозных моделей',
      'Внедрение дата-архитектуры и governance',
    ],
  },
];

const extras = [
  {
    title: 'Лаборатория инноваций',
    text: 'Проводим воркшопы, помогаем с генерацией идей и запускаем пилоты вместе с командами клиента.',
  },
  {
    title: 'Обучающие программы',
    text: 'Разрабатываем корпоративные курсы и индивидуальные треки развития для ключевых специалистов.',
  },
  {
    title: 'Подбор и онбординг команд',
    text: 'Формируем проектные команды и сопровождаем новые роли до полного ввода в работу.',
  },
];

const ServicesPage = () => {
  usePageMetadata(
    'Услуги — Компания',
    'Компания предлагает стратегический консалтинг, разработку цифровых продуктов, операционную поддержку и внедрение бизнес-аналитики.'
  );

  const [activeService, setActiveService] = useState(services[0]);

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-labelledby="services-hero-title">
        <div className={styles.heroContent}>
          <span className={styles.tag}>Услуги</span>
          <h1 id="services-hero-title">Комплексная поддержка бизнеса на каждом этапе развития</h1>
          <p>
            Мы формируем команды под задачи клиента, комбинируем методологии и отвечаем за результат.
            Выбирайте направление — и мы предложим формат сотрудничества, подходящий именно вам.
          </p>
        </div>
      </section>

      <section className={styles.services} aria-labelledby="services-list-title">
        <div className={styles.sectionHeader}>
          <span className={styles.tag}>Направления</span>
          <h2 id="services-list-title">Четыре ядра экспертизы</h2>
          <p>Каждое направление можно запустить как отдельный проект или объединить в масштабную программу трансформации.</p>
        </div>
        <div className={styles.layout}>
          <ul className={styles.menu} role="tablist" aria-label="Выберите услугу">
            {services.map((service) => (
              <li key={service.name}>
                <button
                  type="button"
                  className={`${styles.menuButton} ${activeService.name === service.name ? styles.active : ''}`}
                  onClick={() => setActiveService(service)}
                  aria-selected={activeService.name === service.name}
                >
                  {service.name}
                </button>
              </li>
            ))}
          </ul>
          <article className={styles.details} role="tabpanel">
            <h3>{activeService.name}</h3>
            <p>{activeService.description}</p>
            <ul className={styles.benefits}>
              {activeService.benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
          </article>
        </div>
      </section>

      <section className={styles.extras} aria-labelledby="extras-title">
        <div className={styles.sectionHeader}>
          <span className={styles.tag}>Дополнительно</span>
          <h2 id="extras-title">Расширяем возможности команды</h2>
        </div>
        <div className={styles.extrasGrid}>
          {extras.map((item) => (
            <article key={item.title} className={styles.extraCard}>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;