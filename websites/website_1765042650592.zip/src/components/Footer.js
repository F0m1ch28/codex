import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.inner}>
        <div className={styles.column}>
          <div className={styles.brand}>
            <span className={styles.brandMark}>Компания</span>
            <p className={styles.subtitle}>
              Мы помогаем бизнесу расти и трансформироваться, опираясь на технологии и экспертизу.
            </p>
          </div>
        </div>

        <div className={styles.column}>
          <h3 className={styles.heading}>Навигация</h3>
          <ul className={styles.list}>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/o-kompanii">О компании</Link></li>
            <li><Link to="/uslugi">Услуги</Link></li>
            <li><Link to="/kontakty">Контакты</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.heading}>Документы</h3>
          <ul className={styles.list}>
            <li><Link to="/usloviya-ispolzovaniya">Условия использования</Link></li>
            <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
            <li><Link to="/politika-cookie">Политика использования cookie</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.heading}>Контакты</h3>
          <ul className={styles.contactList}>
            <li>
              <span className={styles.contactLabel}>Адрес:</span>
              <span>г. Москва, ул. Примерная, д. 10</span>
            </li>
            <li>
              <span className={styles.contactLabel}>Телефон:</span>
              <a href="tel:+74950000000">+7 (495) 000-00-00</a>
            </li>
            <li>
              <span className={styles.contactLabel}>Email:</span>
              <a href="mailto:info@kompaniya.ru">info@kompaniya.ru</a>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Компания. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;