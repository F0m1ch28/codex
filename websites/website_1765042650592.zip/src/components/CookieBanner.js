import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'company-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timeout = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timeout);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(STORAGE_KEY, 'declined');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h2 className={styles.title}>Мы используем cookie</h2>
        <p className={styles.text}>
          Файлы cookie помогают улучшить работу сайта и адаптировать контент под ваши интересы. Ознакомьтесь с
          <Link to="/politika-cookie" className={styles.link}> политикой использования cookie</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={handleAccept}>
          Принять
        </button>
        <button type="button" className={styles.decline} onClick={handleDecline}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;