document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('.main-nav');
    const menuToggle = document.querySelector('.menu-toggle');
    const scrollBtn = document.querySelector('.scroll-to-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const cookieConsentKey = 'tn-cookie-consent';
    const currentYearEl = document.getElementById('current-year');
    const contactForm = document.getElementById('contactForm');
    const formResponse = document.getElementById('formResponse');

    if (menuToggle && nav) {
        menuToggle.addEventListener('click', () => {
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', String(!expanded));
            nav.classList.toggle('open');
        });
        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    const handleScrollButton = () => {
        if (window.scrollY > 300) {
            scrollBtn.style.display = 'block';
        } else {
            scrollBtn.style.display = 'none';
        }
    };
    window.addEventListener('scroll', handleScrollButton);

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (cookieBanner && acceptCookiesBtn) {
        const consentGiven = localStorage.getItem(cookieConsentKey);
        if (consentGiven === 'accepted') {
            cookieBanner.classList.add('hidden');
        }
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(cookieConsentKey, 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    if (contactForm && formResponse) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('fullName');
            const email = formData.get('email');
            const message = formData.get('message');

            if (!name || !email || !message) {
                formResponse.textContent = 'Please complete the required fields before submitting.';
                formResponse.style.color = '#C0392B';
                return;
            }

            formResponse.textContent = 'Thank you for your message. A member of our team will reach out shortly.';
            formResponse.style.color = '#0A4D68';
            contactForm.reset();
        });
    }
});