export const interviewsData = [
  {
    id: 'veronique-soler',
    slug: 'veronique-soler-architecture-batteries',
    title: 'Architecture batterie : la montée en cadence des centres d’ingénierie',
    expertName: 'Véronique Soler',
    expertRole: 'Responsable architecture batterie chez un constructeur français',
    expertType: 'Ingénieure',
    summary:
      'Véronique Soler décrit l’organisation des équipes batterie et les leviers de fiabilité mis en place dans les centres d’ingénierie hexagonaux.',
    quote:
      'L’ingénieure souligne que la coordination quotidienne entre chimistes, automaticiens et spécialistes du logiciel sécurise la qualité des cellules livrées aux usines.',
    image: 'https://picsum.photos/800/600?random=7',
    themes: ['batteries et électrification', 'R&D et laboratoires industriels'],
    date: '2024-02-21',
  },
  {
    id: 'dimitri-leblanc',
    slug: 'dimitri-leblanc-logistique',
    title: 'Logistique industrielle : ajuster les flux aux gigafactories européennes',
    expertName: 'Dimitri Leblanc',
    expertRole: 'Coordinateur logistique grand export',
    expertType: 'Spécialiste logistique',
    summary:
      'Dimitri Leblanc détaille la structuration des corridors logistiques reliant les sites français aux nouvelles usines de cellules européennes.',
    quote:
      'Le spécialiste insiste sur la nécessité de synchroniser rail et route afin de rallier les gigafactories tout en respectant les objectifs environnementaux imposés.',
    image: 'https://picsum.photos/800/600?random=8',
    themes: ["chaîne d'approvisionnement et logistique industrielle", 'compétitivité en Europe et dans le monde'],
    date: '2024-01-30',
  },
  {
    id: 'claire-mazet',
    slug: 'claire-mazet-design-ergo',
    title: 'Design intérieur : l’impact des nouveaux usages connectés',
    expertName: 'Claire Mazet',
    expertRole: 'Directrice du design expérience utilisateur',
    expertType: 'Designer',
    summary:
      'Claire Mazet analyse la manière dont les usages numériques transforment la conception des interfaces et des espaces intérieurs.',
    quote:
      'La designer observe que les nouveaux parcours utilisateurs requièrent des interfaces plus sobres, articulant assistance à la conduite et lisibilité.',
    image: 'https://picsum.photos/800/600?random=9',
    themes: ['évolution du design automobile', 'systèmes d’aide à la conduite et conduite autonome'],
    date: '2024-02-05',
  },
  {
    id: 'sadek-haddad',
    slug: 'sadek-haddad-marche-mobilite',
    title: 'Mobilité intérieure : lecture des arbitrages des ménages',
    expertName: 'Sadek Haddad',
    expertRole: 'Chercheur en socio-économie des mobilités',
    expertType: 'Chercheur',
    summary:
      'Sadek Haddad explique les facteurs qui orientent les choix des ménages entre motorisations électrique, hybride et thermique.',
    quote:
      'Le chercheur rappelle que la lisibilité des infrastructures et la compréhension des technologies conditionnent l’adhésion à la transition énergétique.',
    image: 'https://picsum.photos/800/600?random=10',
    themes: ['marché intérieur et tendances de consommation', 'infrastructures de recharge'],
    date: '2024-03-02',
  },
];