export const authorsData = [
  {
    id: 'anais-bernard',
    name: 'Anaïs Bernard',
    role: 'Analyste en politiques industrielles',
    bio: `Anaïs Bernard observe les transformations de l’industrie automobile française depuis quinze ans. Elle coordonne les enquêtes territoriales et suit les coopérations entre constructeurs et pouvoirs publics.`,
    expertise: ['Transition énergétique', 'Politiques publiques', 'Territoires'],
    portrait: 'https://picsum.photos/seed/anaisbernard/400/400',
  },
  {
    id: 'malik-duret',
    name: 'Malik Duret',
    role: 'Ingénieur en systèmes de production',
    bio: `Malik Duret analyse les chaînes d’assemblage et les stratégies d’automatisation des sites français. Ses dossiers s’appuient sur des visites régulières d’usines et des échanges avec des responsables méthodes.`,
    expertise: ['Robotisation', 'Ingénierie de production', 'Qualité'],
    portrait: 'https://picsum.photos/seed/malikduret/400/400',
  },
  {
    id: 'lea-moreau',
    name: 'Léa Moreau',
    role: 'Spécialiste du stockage d’énergie',
    bio: `Léa Moreau suit la filière batterie européenne, des matières premières aux gigafactories. Elle met en perspective les coopérations industrielles et les avancées technologiques.`,
    expertise: ['Batteries', 'Chaînes d’approvisionnement', 'Innovation'],
    portrait: 'https://picsum.photos/seed/leamoreau/400/400',
  },
  {
    id: 'julien-arnoux',
    name: 'Julien Arnoux',
    role: 'Analyste des mobilités',
    bio: `Julien Arnoux étudie l’évolution de la demande automobile, les usages numériques et les politiques de mobilité. Ses analyses croisent données de marché et terrain.`,
    expertise: ['Marché intérieur', 'Services numériques', 'Systèmes d’aide à la conduite'],
    portrait: 'https://picsum.photos/seed/julienarnoux/400/400',
  },
];