export const themesData = [
  {
    id: 'industrie-automobile-francaise',
    title: 'industrie automobile française',
    description:
      'Panorama de la structure productive nationale, des sites d’assemblage aux centres d’ingénierie, en passant par les liens avec les territoires.',
  },
  {
    id: 'constructeurs-nationaux-groupes-historiques',
    title: 'constructeurs nationaux et groupes historiques',
    description:
      'Analyse des stratégies des constructeurs français, de la gouvernance industrielle à la configuration des portefeuilles de modèles.',
  },
  {
    id: 'ingenierie-innovation-technologique',
    title: 'ingénierie et innovation technologique',
    description:
      'Étude des trajectoires R&D, des plateformes modulaires et des nouvelles pratiques de conception produit.',
  },
  {
    id: 'moteurs-thermiques-hybrides-electriques',
    title: 'moteurs thermiques hybrides et électriques',
    description:
      'Comparaison des motorisations disponibles, des chaînes de traction hybrides aux architectures 100 % électriques.',
  },
  {
    id: 'batteries-electrification',
    title: 'batteries et électrification',
    description:
      'Suivi des projets de gigafactories, des innovations cellulaire et des coopérations européennes sur la batterie.',
  },
  {
    id: 'infrastructures-de-recharge',
    title: 'infrastructures de recharge',
    description:
      'Cartographie du déploiement des bornes, des corridors de recharge rapide et des services associés.',
  },
  {
    id: 'chaine-approvisionnement-logistique',
    title: "chaîne d'approvisionnement et logistique industrielle",
    description:
      'Observation des flux matières, des plateformes logistiques et des stratégies de sécurisation des approvisionnements.',
  },
  {
    id: 'equipementiers-sous-traitants',
    title: 'équipementiers et sous-traitants',
    description:
      'Analyse des relations entre donneurs d’ordre et fournisseurs, de la diversification des compétences aux transitions d’activité.',
  },
  {
    id: 'normes-environnementales-directives',
    title: 'normes environnementales et directives européennes',
    description:
      'Décryptage du cadre réglementaire européen, des nouvelles obligations et de leurs impacts opérationnels.',
  },
  {
    id: 'reduction-emissions-transition',
    title: 'réduction des émissions et transition énergétique',
    description:
      'Suivi des objectifs climatiques, des plans de décarbonation et des indicateurs d’efficacité énergétique.',
  },
  {
    id: 'robotisation-automatisation',
    title: 'robotisation et automatisation',
    description:
      'État des lieux des déploiements robotiques, de la cobotique et de l’automatisation adaptative dans les usines.',
  },
  {
    id: 'systemes-aide-conduite',
    title: 'systèmes d’aide à la conduite et conduite autonome',
    description:
      'Veille technologique sur les aides à la conduite, les architectures logicielles et la normalisation des systèmes automatisés.',
  },
  {
    id: 'rd-laboratoires-industriels',
    title: 'R&D et laboratoires industriels',
    description:
      'Cartographie des laboratoires internes, des collaboratifs publics-privés et des programmes d’innovation.',
  },
  {
    id: 'marche-interieur-tendances',
    title: 'marché intérieur et tendances de consommation',
    description:
      'Étude de l’évolution de la demande, des préférences des ménages et des flottes professionnelles.',
  },
  {
    id: 'exportations-francaises',
    title: 'exportations françaises',
    description:
      'Analyse des destinations des véhicules produits en France et des stratégies d’exportation.',
  },
  {
    id: 'competitivite-europe-monde',
    title: 'compétitivité en Europe et dans le monde',
    description:
      'Comparaison des performances françaises avec celles des principaux concurrents européens et internationaux.',
  },
  {
    id: 'evolution-design-automobile',
    title: 'évolution du design automobile',
    description:
      'Suivi des tendances stylistiques, des matériaux et des interfaces utilisateur dans le design automobile français.',
  },
  {
    id: 'histoire-automobile-france',
    title: 'histoire de l’automobile en France',
    description:
      'Mise en perspective historique des innovations, des acteurs et des transformations sociétales de l’automobile.',
  },
];