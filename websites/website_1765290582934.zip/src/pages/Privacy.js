import React from 'react';
import styles from './LegalPages.module.css';
import Seo from '../components/Seo';

function Privacy() {
  return (
    <div className={styles.page}>
      <Seo
        title="Politique de confidentialité"
        description="Politique de confidentialité appliquée par French Automotive Sector Analysis."
      />
      <section>
        <div className="layout">
          <div className={styles.card}>
            <h1 className="section-title">Politique de confidentialité</h1>
            <div className={styles.section}>
              <h3>Responsable du traitement</h3>
              <p>
                Le responsable de publication assure la gestion des données personnelles collectées via le site. Les
                coordonnées figurent dans la rubrique contact.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Données collectées</h3>
              <p>
                Le site collecte uniquement les informations transmises volontairement via le formulaire de contact :
                nom, organisation, adresse électronique et message.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Finalités</h3>
              <p>
                Les données servent exclusivement à répondre aux sollicitations et à organiser les échanges éditoriaux.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Durée de conservation</h3>
              <p>
                Les messages sont conservés pendant une durée maximale de deux ans afin d’assurer le suivi des échanges.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Droits des personnes</h3>
              <p>
                Chaque personne dispose d’un droit d’accès, de rectification, d’effacement et d’opposition. Une demande
                peut être adressée via le formulaire de contact.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Sécurité</h3>
              <p>
                Des mesures techniques et organisationnelles protègent les données contre tout accès non autorisé.
              </p>
            </div>
            <p>Dernière mise à jour : 12 mars 2024.</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Privacy;