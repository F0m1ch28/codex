import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Archives.module.css';
import Seo from '../components/Seo';
import { articlesData } from '../data/articles';
import formatDate from '../utils/formatDate';
import ThemeTag from '../components/ThemeTag';

function Archives() {
  const years = useMemo(() => {
    const allYears = articlesData.map((article) => new Date(article.date).getFullYear());
    return Array.from(new Set(allYears)).sort((a, b) => b - a);
  }, []);

  const [selectedYear, setSelectedYear] = useState(years[0]);

  const grouped = useMemo(() => {
    const byYear = {};
    articlesData.forEach((article) => {
      const year = new Date(article.date).getFullYear();
      const month = new Date(article.date).toLocaleDateString('fr-FR', { month: 'long' });
      if (!byYear[year]) byYear[year] = {};
      if (!byYear[year][month]) byYear[year][month] = [];
      byYear[year][month].push(article);
    });
    Object.keys(byYear).forEach((year) => {
      Object.keys(byYear[year]).forEach((month) => {
        byYear[year][month].sort((a, b) => new Date(b.date) - new Date(a.date));
      });
    });
    return byYear;
  }, []);

  const monthsOrder = [
    'janvier',
    'février',
    'mars',
    'avril',
    'mai',
    'juin',
    'juillet',
    'août',
    'septembre',
    'octobre',
    'novembre',
    'décembre',
  ];

  return (
    <div className={styles.page}>
      <Seo
        title="Archives"
        description="Archives chronologiques des publications de French Automotive Sector Analysis depuis 2015."
      />
      <section>
        <div className="layout">
          <h1 className="section-title">Archives des publications</h1>
          <p className="section-subtitle">
            Les documents sont classés par année et par mois de publication. Chaque fiche rappelle la thématique
            principale abordée.
          </p>
          <div className={styles.controls}>
            <label htmlFor="year-select">Sélectionner une année</label>
            <select
              id="year-select"
              value={selectedYear}
              onChange={(event) => setSelectedYear(Number(event.target.value))}
            >
              {years.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </div>
          {years.map((year) => (
            <div key={year} className={styles.yearGroup} hidden={year !== selectedYear}>
              <h2 className={styles.yearTitle}>{year}</h2>
              {monthsOrder.map((month) => (
                <div key={month} className={styles.monthGroup}>
                  {grouped[year] && grouped[year][month] && (
                    <>
                      <h3 className={styles.monthTitle}>{month}</h3>
                      <ul className={styles.articleList}>
                        {grouped[year][month].map((article) => (
                          <li key={article.id} className={styles.articleItem}>
                            <Link to={`/article/${article.slug}`}>{article.title}</Link>
                            <span className={styles.articleMeta}>{formatDate(article.date)}</span>
                            <div className={styles.tagRow}>
                              {article.themes.slice(0, 2).map((theme) => (
                                <ThemeTag key={`${article.slug}-${theme}`} label={theme} />
                              ))}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Archives;