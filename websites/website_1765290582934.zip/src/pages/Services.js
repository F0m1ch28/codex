import React, { useMemo, useState } from 'react';
import styles from './Services.module.css';
import Seo from '../components/Seo';
import { articlesData } from '../data/articles';
import { themesData } from '../data/themes';
import ArticleCard from '../components/ArticleCard';

function Services() {
  const [selectedTheme, setSelectedTheme] = useState('Toutes les thématiques');

  const sortedArticles = useMemo(
    () => [...articlesData].sort((a, b) => new Date(b.date) - new Date(a.date)),
    []
  );

  const themeLabels = useMemo(
    () => ['Toutes les thématiques', ...themesData.map((theme) => theme.title)],
    []
  );

  const filteredArticles = useMemo(() => {
    if (selectedTheme === 'Toutes les thématiques') return sortedArticles;
    return sortedArticles.filter((article) => article.themes.includes(selectedTheme));
  }, [selectedTheme, sortedArticles]);

  return (
    <div className={styles.page}>
      <Seo
        title="Analyses et publications"
        description="Panorama complet des analyses publiées par French Automotive Sector Analysis, classées par thématique industrielle."
      />
      <section>
        <div className="layout">
          <div className={styles.metaInfo}>
            <h1 className="section-title">Analyses et publications</h1>
            <p>
              Ce répertoire présente l’ensemble des dossiers parus, classés par date de publication et par thématique
              de recherche.
            </p>
          </div>
          <div className={styles.filters}>
            {themeLabels.map((theme) => (
              <button
                key={theme}
                type="button"
                onClick={() => setSelectedTheme(theme)}
                className={`${styles.filterButton} ${
                  selectedTheme === theme ? styles.filterButtonActive : ''
                }`}
                aria-pressed={selectedTheme === theme}
              >
                {theme}
              </button>
            ))}
          </div>
          <div className={styles.list}>
            {filteredArticles.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Services;