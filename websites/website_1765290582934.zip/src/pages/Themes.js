import React from 'react';
import styles from './Themes.module.css';
import Seo from '../components/Seo';
import { themesData } from '../data/themes';

function Themes() {
  return (
    <div className={styles.page}>
      <Seo
        title="Thématiques de recherche"
        description="Panorama des thématiques suivies par French Automotive Sector Analysis, couvrant l’ingénierie, les chaînes d’approvisionnement et la mobilité."
      />
      <section>
        <div className="layout">
          <h1 className="section-title">Thèmes de recherche</h1>
          <p className="section-subtitle">
            Les axes suivants structurent la veille et les publications du site. Chaque entrée renvoie à des dossiers
            approfondis consultables dans les archives.
          </p>
          <div className={styles.themeList}>
            {themesData.map((theme) => (
              <article key={theme.id} className={styles.themeCard}>
                <h3>{theme.title}</h3>
                <p>{theme.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Themes;