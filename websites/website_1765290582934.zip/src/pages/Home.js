import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import Seo from '../components/Seo';
import { articlesData } from '../data/articles';
import { themesData } from '../data/themes';
import { authorsData } from '../data/authors';
import { interviewsData } from '../data/interviews';
import ArticleCard from '../components/ArticleCard';
import ThemeTag from '../components/ThemeTag';

const stats = [
  { label: 'Dossiers techniques suivis', value: 48, suffix: '' },
  { label: 'Entretiens qualifiés', value: 72, suffix: '' },
  { label: 'Sites industriels observés', value: 26, suffix: '' },
  { label: 'Années de veille cumulées', value: 18, suffix: '' },
];

const processSteps = [
  {
    title: 'Cartographie documentaire',
    description:
      'Veille quotidienne des sources publiques, techniques et académiques afin de consolider les tendances du secteur.',
  },
  {
    title: 'Analyse de terrain',
    description:
      'Observation de sites industriels, échanges réguliers avec des responsables d’ingénierie et des coordinations territoriales.',
  },
  {
    title: 'Validation croisée',
    description:
      'Relecture par un comité éditorial pluridisciplinaire garantissant la neutralité des conclusions.',
  },
  {
    title: 'Publication structurée',
    description:
      'Synthèse en langage clair, enrichie d’indicateurs comparables et de pistes de suivi.',
  },
];

const projects = [
  {
    title: 'Observatoire des plateformes électriques',
    description:
      'Étude longitudinale des transformations d’usines dédiées aux motorisations électriques et hybrides.',
    image: 'https://picsum.photos/1200/800?random=4',
  },
  {
    title: 'Cartographie de la chaîne batterie',
    description:
      'Analyse des capacités européennes, des coopérations industrielles et des besoins en compétences.',
    image: 'https://picsum.photos/1200/800?random=5',
  },
  {
    title: 'Veille design et ergonomie',
    description:
      'Suivi de l’évolution des signatures esthétiques et des interfaces utilisateur des constructeurs français.',
    image: 'https://picsum.photos/1200/800?random=6',
  },
];

const faq = [
  {
    question: 'Comment les analyses sont-elles produites ?',
    answer:
      'Chaque dossier combine données publiques, entretiens confidentiels et validation croisée par le comité éditorial afin de maintenir un haut niveau de fiabilité.',
  },
  {
    question: 'Quels territoires sont couverts ?',
    answer:
      'L’observatoire suit l’ensemble du territoire français, avec un accent particulier sur les bassins industriels historiques et les nouveaux pôles de l’électrification.',
  },
  {
    question: 'Quels sont les profils des experts consultés ?',
    answer:
      'Les analyses reposent sur des échanges avec des ingénieurs, des responsables d’usine, des spécialistes en logistique et des chercheurs académiques.',
  },
  {
    question: 'À quelle fréquence les dossiers sont-ils mis à jour ?',
    answer:
      'Les publications majeures sont actualisées tous les trimestres et complétées par des notes de veille hebdomadaires lorsque l’actualité le nécessite.',
  },
];

function Home() {
  const [displayedStats, setDisplayedStats] = useState(stats.map(() => 0));

  useEffect(() => {
    let frameId;
    const start = performance.now();
    const duration = 1200;

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      setDisplayedStats(stats.map((stat) => Math.round(stat.value * progress)));
      if (progress < 1) {
        frameId = requestAnimationFrame(animate);
      }
    };

    frameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameId);
  }, []);

  const latestArticles = [...articlesData]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 6);
  const additionalArticles = latestArticles.slice(3);
  const keyThemes = themesData.slice(0, 9);
  const highlightedExperts = authorsData;
  const testimonials = interviewsData.slice(0, 3);

  return (
    <div className={styles.home}>
      <Seo
        title="Accueil"
        description="Analyses neutres de la filière automobile française : transition énergétique, robotisation, batteries et transformation des usages."
      />
      <section className={styles.hero}>
        <div className="layout">
          <div className={styles.heroContent}>
            <h1>French Automotive Sector Analysis</h1>
            <p>
              Publication analytique dédiée aux transformations de l’industrie automobile française :
              transition énergétique, recomposition des chaînes de valeur et innovations d’ingénierie.
            </p>
            <a href="#dernieres-analyses" className={styles.heroCta}>
              <span>Panorama analytique 2024</span>
            </a>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Indicateurs clés">
        <div className="layout">
          <div className={styles.statsGrid}>
            {stats.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <p className={styles.statValue}>
                  {displayedStats[index]}
                  {stat.suffix}
                </p>
                <p className={styles.statLabel}>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="dernieres-analyses">
        <div className="layout">
          <h2 className="section-title">Dernières analyses</h2>
          <p className="section-subtitle">
            Sélection de dossiers récents mettant en lumière les recompositions industrielles, les trajectoires
            technologiques et les dynamiques territoriales.
          </p>
          <div className={styles.latestGrid}>
            {latestArticles.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="themes-clefs">
        <div className="layout">
          <h2 id="themes-clefs" className="section-title">Thématiques observées</h2>
          <div className={styles.themeCloud}>
            {keyThemes.map((theme) => (
              <ThemeTag key={theme.id} label={theme.title} />
            ))}
          </div>
        </div>
      </section>

      <section>
        <div className="layout">
          <div className={styles.methodologyCard}>
            <h2 className="section-title">Méthodologie</h2>
            <p>
              Chaque publication s’appuie sur un protocole transparent combinant observation de terrain, analyse
              documentaire et confrontation des sources. Les étapes sont décrites ci-dessous.
            </p>
            <div className={styles.processGrid}>
              {processSteps.map((step) => (
                <div key={step.title} className={styles.processCard}>
                  <h4>{step.title}</h4>
                  <p>{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="experts">
        <div className="layout">
          <h2 id="experts" className="section-title">Experts et auteurs</h2>
          <p className="section-subtitle">
            Le collectif rassemble des analystes aux profils complémentaires, couvrant l’ingénierie, la logistique,
            la batterie et les usages.
          </p>
          <div className={styles.expertGrid}>
            {highlightedExperts.map((expert) => (
              <div key={expert.id} className={styles.expertCard}>
                <img src={expert.portrait} alt={`Portrait de ${expert.name}`} loading="lazy" />
                <h4>{expert.name}</h4>
                <p className={styles.expertRole}>{expert.role}</p>
                <p>{expert.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="temoignages">
        <div className="layout">
          <h2 id="temoignages" className="section-title">Regards croisés</h2>
          <p className="section-subtitle">
            Extraits d’entretiens publiés dans la rubrique interviews, illustrant les évolutions observées sur le terrain.
          </p>
          <div className={styles.testimonialGrid}>
            {testimonials.map((item) => (
              <article key={item.id} className={styles.testimonialCard}>
                <p className={styles.testimonialQuote}>{item.quote}</p>
                <p className={styles.testimonialMeta}>
                  {item.expertName} — {item.expertRole}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="programmes">
        <div className="layout">
          <h2 id="programmes" className="section-title">Programmes d’étude</h2>
          <div className={styles.projectsGrid}>
            {projects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={`Illustration du programme ${project.title}`} loading="lazy" />
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="faq">
        <div className="layout">
          <h2 id="faq" className="section-title">Questions fréquentes</h2>
          <div className={styles.faqList}>
            {faq.map((item) => (
              <details key={item.question}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="veille">
        <div className="layout">
          <h2 id="veille" className="section-title">Notes de veille</h2>
          <p className="section-subtitle">
            Ces synthèses complètent les dossiers majeurs en mettant en avant des signaux faibles observés au cours des dernières semaines.
          </p>
          <div className={styles.blogGrid}>
            {additionalArticles.map((article) => (
              <ArticleCard key={`${article.id}-preview`} article={article} />
            ))}
          </div>
        </div>
      </section>

      <section>
        <div className="layout">
          <div className={styles.ctaSection}>
            <h3>Archive documentaire</h3>
            <p>
              Les publications depuis 2015 sont regroupées dans un espace de consultation chronologique. Les dossiers peuvent être filtrés par thématique, période ou territoire étudié.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/archives" className={styles.ctaLink}>
                Consulter l’archive structurée
              </Link>
              <Link to="/analyses" className={styles.ctaLink}>
                Voir toutes les analyses
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;