import React from 'react';
import styles from './About.module.css';
import Seo from '../components/Seo';
import { authorsData } from '../data/authors';

function About() {
  return (
    <div className={styles.page}>
      <Seo
        title="À propos"
        description="Mission, gouvernance éditoriale et équipe de French Automotive Sector Analysis, observatoire des dynamiques automobiles françaises."
      />
      <section>
        <div className="layout">
          <div className={styles.introCard}>
            <h1 className="section-title">Mission éditoriale</h1>
            <p>
              French Automotive Sector Analysis documente les dynamiques techniques et industrielles de la filière
              automobile française. L’équipe analyse les recompositions des chaînes de valeur, les mutations du travail
              et les innovations d’ingénierie en s’appuyant sur des données vérifiées.
            </p>
            <p>
              Le projet privilégie une écriture neutre, une vérification croisée des sources et une attention portée aux
              territoires. Chaque publication expose les méthodes mobilisées et précise les limites d’interprétation.
            </p>
          </div>

          <div className={styles.grid}>
            <div className={styles.highlightBox}>
              <h2 className="section-title">Approche méthodologique</h2>
              <ul className={styles.principlesList}>
                <li>Collecte quotidienne de données techniques, réglementaires et scientifiques.</li>
                <li>Entretiens menés avec des responsables d’usine, des ingénieurs et des chercheurs.</li>
                <li>Analyses croisées par un comité éditorial pluridisciplinaire garantissant une lecture neutre.</li>
                <li>Mise à jour régulière des dossiers pour intégrer les évolutions industrielles et territoriales.</li>
              </ul>
            </div>
            <div className={styles.highlightBox}>
              <h2 className="section-title">Principes éditoriaux</h2>
              <ul className={styles.principlesList}>
                <li>Neutralité : absence de promotion et restitution équilibrée des points de vue recueillis.</li>
                <li>Traçabilité : mention systématique des sources publiques et des indicateurs utilisés.</li>
                <li>Pérennité : archivage chronologique des dossiers afin de suivre les trajectoires sur plusieurs années.</li>
                <li>Accessibilité : écriture claire, lexique défini et mise en perspective des termes techniques.</li>
              </ul>
            </div>
          </div>

          <section className={styles.grid}>
            <div>
              <h2 className="section-title">Repères chronologiques</h2>
              <div className={styles.timeline}>
                <div className={styles.timelineItem}>
                  <h4>2015</h4>
                  <p>
                    Lancement d’une première veille dédiée aux usines françaises et aux politiques de décarbonation.
                  </p>
                </div>
                <div className={styles.timelineItem}>
                  <h4>2019</h4>
                  <p>
                    Structuration d’un réseau d’observateurs régionaux et ouverture d’un protocole de partage avec des
                    laboratoires académiques.
                  </p>
                </div>
                <div className={styles.timelineItem}>
                  <h4>2022</h4>
                  <p>
                    Extension des analyses aux systèmes d’aide à la conduite, aux logiciels embarqués et aux services
                    numériques.
                  </p>
                </div>
                <div className={styles.timelineItem}>
                  <h4>2024</h4>
                  <p>
                    Consolidation des archives et mise en ligne d’un portail unifié regroupant analyses, interviews et
                    notes méthodologiques.
                  </p>
                </div>
              </div>
            </div>
            <div>
              <h2 className="section-title">Gouvernance</h2>
              <div className={styles.highlightBox}>
                <p>
                  Le comité éditorial se compose d’analystes seniors spécialisés en ingénierie, en économie industrielle
                  et en politiques publiques. Chaque publication passe par une relecture collégiale garantissant
                  l’équilibre des références et la précision du vocabulaire technique.
                </p>
                <p>
                  Un réseau de correspondants territoriaux fournit des observations directes sur les sites industriels,
                  tandis que des partenaires universitaires relisent les dossiers consacrés aux innovations de rupture.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="section-title">Équipe de rédaction</h2>
            <div className={styles.teamGrid}>
              {authorsData.map((author) => (
                <div key={author.id} className={styles.teamCard}>
                  <img src={author.portrait} alt={`Portrait de ${author.name}`} loading="lazy" />
                  <h3 className={styles.teamName}>{author.name}</h3>
                  <p className={styles.teamRole}>{author.role}</p>
                  <p>{author.bio}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </section>
    </div>
  );
}

export default About;