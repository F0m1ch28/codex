import React from 'react';
import { useParams, Link } from 'react-router-dom';
import styles from './Article.module.css';
import Seo from '../components/Seo';
import { articlesData } from '../data/articles';
import { authorsData } from '../data/authors';
import ThemeTag from '../components/ThemeTag';
import formatDate from '../utils/formatDate';

function Article() {
  const { slug } = useParams();
  const article = articlesData.find((item) => item.slug === slug);

  if (!article) {
    return (
      <div className={styles.page}>
        <Seo
          title="Article introuvable"
          description="L’article recherché n’a pas été trouvé dans les archives de French Automotive Sector Analysis."
        />
        <section className={styles.notFound}>
          <div className="layout">
            <h1 className="section-title">Article non disponible</h1>
            <p>Le document demandé n’est pas référencé. L’archive peut avoir été déplacée ou renommée.</p>
            <Link to="/analyses">Retour à la liste des analyses</Link>
          </div>
        </section>
      </div>
    );
  }

  const author = authorsData.find((person) => person.id === article.authorId);
  const relatedArticles = articlesData.filter((item) => article.relatedSlugs.includes(item.slug));

  return (
    <div className={styles.page}>
      <Seo title={article.title} description={article.description} />
      <section>
        <div className="layout">
          <div className={styles.heroImage}>
            <img src={article.heroImage} alt={article.title} loading="lazy" />
          </div>
          <div className={styles.meta}>
            <span>{formatDate(article.date)}</span>
            {author && <span>{author.name}</span>}
            <span>{article.themes[0]}</span>
          </div>
          <h1 className={styles.title}>{article.title}</h1>
          {article.subtitle && <p className={styles.subtitle}>{article.subtitle}</p>}
          <div className={styles.tags}>
            {article.themes.map((theme) => (
              <ThemeTag key={`${article.slug}-${theme}`} label={theme} />
            ))}
            {article.tags.map((tag) => (
              <ThemeTag key={`${article.slug}-${tag}`} label={tag} />
            ))}
          </div>
          <p className={styles.introduction}>{article.introduction}</p>
          {article.sections.map((section) => (
            <div key={section.heading} className={styles.section}>
              <h2>{section.heading}</h2>
              {section.paragraphs.map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
          ))}
          <div className={styles.conclusion}>
            <p>{article.conclusion}</p>
          </div>
          {author && (
            <div className={styles.authorBox}>
              <div className={styles.authorInfo}>
                <img src={author.portrait} alt={`Portrait de ${author.name}`} loading="lazy" />
                <div>
                  <h3>{author.name}</h3>
                  <p>{author.role}</p>
                </div>
              </div>
              <p>{author.bio}</p>
            </div>
          )}
          {relatedArticles.length > 0 && (
            <div className={styles.related}>
              <h2 className="section-title">Analyses complémentaires</h2>
              <div className={styles.relatedGrid}>
                {relatedArticles.map((item) => (
                  <article key={item.id} className={styles.relatedCard}>
                    <Link to={`/article/${item.slug}`}>{item.title}</Link>
                    <p>{item.description}</p>
                  </article>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

export default Article;