import React, { useMemo, useState } from 'react';
import styles from './Interviews.module.css';
import Seo from '../components/Seo';
import { interviewsData } from '../data/interviews';
import formatDate from '../utils/formatDate';
import ThemeTag from '../components/ThemeTag';

function Interviews() {
  const [filter, setFilter] = useState('Tous les profils');

  const types = useMemo(
    () => ['Tous les profils', ...new Set(interviewsData.map((item) => item.expertType))],
    []
  );

  const filtered = useMemo(() => {
    if (filter === 'Tous les profils') return interviewsData;
    return interviewsData.filter((item) => item.expertType === filter);
  }, [filter]);

  return (
    <div className={styles.page}>
      <Seo
        title="Interviews et commentaires"
        description="Entretiens avec des ingénieurs, designers et spécialistes évoquant les mutations de la filière automobile française."
      />
      <section>
        <div className="layout">
          <h1 className="section-title">Interviews et éclairages</h1>
          <p className="section-subtitle">
            Chaque échange met en perspective une transformation opérationnelle observée sur le terrain ou dans les bureaux d’études.
          </p>
          <div className={styles.filterRow}>
            {types.map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setFilter(type)}
                className={`${styles.filterButton} ${filter === type ? styles.filterActive : ''}`}
                aria-pressed={filter === type}
              >
                {type}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filtered.map((item) => (
              <article key={item.id} className={styles.card}>
                <img src={item.image} alt={`Portrait d’interview de ${item.expertName}`} loading="lazy" />
                <div className={styles.cardContent}>
                  <span className={styles.meta}>{`${item.expertType} · ${formatDate(item.date)}`}</span>
                  <h3>{item.title}</h3>
                  <p className={styles.meta}>
                    {item.expertName} — {item.expertRole}
                  </p>
                  <p>{item.summary}</p>
                  <blockquote className={styles.quote}>{item.quote}</blockquote>
                  <div className={styles.tagRow}>
                    {item.themes.map((theme) => (
                      <ThemeTag key={`${item.id}-${theme}`} label={theme} />
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Interviews;