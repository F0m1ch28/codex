import React from 'react';
import styles from './LegalPages.module.css';
import Seo from '../components/Seo';

function CookiesPolicy() {
  return (
    <div className={styles.page}>
      <Seo
        title="Politique de cookies"
        description="Politique de cookies appliquée sur le site French Automotive Sector Analysis."
      />
      <section>
        <div className="layout">
          <div className={styles.card}>
            <h1 className="section-title">Politique de cookies</h1>
            <div className={styles.section}>
              <h3>Cookies techniques</h3>
              <p>
                Le site utilise des cookies strictement nécessaires pour assurer le fonctionnement de la navigation et
                conserver les préférences de consentement.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Gestion du consentement</h3>
              <p>
                Lors de la première visite, une bannière présente les options d’acceptation ou de refus. Le choix peut
                être modifié en supprimant les cookies du navigateur.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Absence de traçage publicitaire</h3>
              <p>Aucun cookie publicitaire ou de mesure d’audience à des fins commerciales n’est déposé.</p>
            </div>
            <div className={styles.section}>
              <h3>Durée de conservation</h3>
              <p>
                Le cookie de consentement est conservé pendant treize mois maximum avant de solliciter un nouveau
                choix.
              </p>
            </div>
            <p>Dernière mise à jour : 12 mars 2024.</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default CookiesPolicy;