import React from 'react';
import styles from './LegalPages.module.css';
import Seo from '../components/Seo';

function Terms() {
  return (
    <div className={styles.page}>
      <Seo
        title="Conditions d’utilisation"
        description="Conditions générales d’utilisation du site French Automotive Sector Analysis."
      />
      <section>
        <div className="layout">
          <div className={styles.card}>
            <h1 className="section-title">Conditions d’utilisation</h1>
            <div className={styles.section}>
              <h3>Objet</h3>
              <p>
                Les présentes conditions définissent les règles applicables à la consultation du site French Automotive
                Sector Analysis. L’accès implique l’acceptation sans réserve de ces dispositions.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Accès au service</h3>
              <p>
                Le site demeure accessible gratuitement. Il peut être suspendu pour maintenance ou mise à jour sans
                préavis. L’équipe s’efforce de limiter la durée des interruptions.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Responsabilité éditoriale</h3>
              <p>
                Les contenus sont fournis à titre informatif. Malgré les vérifications, des inexactitudes peuvent
                subsister. Toute remarque peut être signalée via la rubrique contact pour rectification.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Propriété intellectuelle</h3>
              <p>
                Les textes, visuels et éléments graphiques sont protégés. Toute reproduction doit faire l’objet d’une
                autorisation explicite de la rédaction.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Liens externes</h3>
              <p>
                Le site peut contenir des liens vers des ressources de référence. La rédaction ne saurait être tenue
                responsable du contenu de ces ressources externes.
              </p>
            </div>
            <div className={styles.section}>
              <h3>Évolution des conditions</h3>
              <p>
                Les présentes conditions peuvent être mises à jour pour s’adapter à l’évolution des services ou du cadre
                légal. La date de dernière modification est indiquée en bas de page.
              </p>
            </div>
            <p>Dernière mise à jour : 12 mars 2024.</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Terms;