import React, { useState } from 'react';
import styles from './Contact.module.css';
import Seo from '../components/Seo';

const initialState = {
  name: '',
  organisation: '',
  email: '',
  subject: '',
  message: '',
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Le nom de l’interlocuteur est requis.';
    if (!formData.organisation.trim()) newErrors.organisation = 'Le nom de la structure est requis.';
    if (!formData.email.trim()) {
      newErrors.email = 'Une adresse électronique valide est requise.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Le format de l’adresse électronique doit être conforme.';
    }
    if (!formData.subject.trim()) newErrors.subject = 'L’objet du message précise la thématique.';
    if (!formData.message.trim()) newErrors.message = 'Le corps du message ne peut pas être vide.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Contact"
        description="Coordonnées éditoriales de French Automotive Sector Analysis et formulaire de mise en relation professionnelle."
      />
      <section>
        <div className="layout">
          <h1 className="section-title">Coordonnées éditoriales</h1>
          <div className={styles.contactGrid}>
            <div className={styles.infoCard}>
              <p>
                Le comité éditorial reçoit les contributions, les demandes d’entretien et les précisions méthodologiques
                via les coordonnées suivantes. Chaque sollicitation est traitée de manière confidentielle.
              </p>
              <div>
                <h3>Adresse postale</h3>
                <p>
                  French Automotive Sector Analysis
                  <br />
                  12 rue des Ateliers
                  <br />
                  75011 Paris
                  <br />
                  France
                </p>
              </div>
              <div>
                <h3>Contact éditorial</h3>
                <p aria-label="adresse électronique">contact@french-automotive-analysis.fr</p>
                <p aria-label="numéro de téléphone">+33 (0)1 42 00 00 00</p>
              </div>
              <div>
                <h3>Disponibilité</h3>
                <p>Réponses assurées du lundi au vendredi, hors jours fériés nationaux.</p>
              </div>
            </div>
            <div className={styles.formCard}>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <div className={styles.formGroup}>
                  <label htmlFor="name">Nom et prénom</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Nom de l’interlocuteur"
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="organisation">Organisation</label>
                  <input
                    id="organisation"
                    name="organisation"
                    type="text"
                    value={formData.organisation}
                    onChange={handleChange}
                    placeholder="Structure ou institution"
                  />
                  {errors.organisation && <span className={styles.error}>{errors.organisation}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="email">Adresse électronique</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="adresse@example.fr"
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="subject">Objet</label>
                  <input
                    id="subject"
                    name="subject"
                    type="text"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Thématique abordée"
                  />
                  {errors.subject && <span className={styles.error}>{errors.subject}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="message">Message</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="6"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Précisions sur la demande ou la contribution proposée."
                  />
                  {errors.message && <span className={styles.error}>{errors.message}</span>}
                </div>
                <button type="submit" className={styles.submitButton}>
                  Valider le message
                </button>
                {submitted && (
                  <p className={styles.successMessage}>
                    La demande a été transmise. Une réponse sera apportée après examen par le comité éditorial.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;