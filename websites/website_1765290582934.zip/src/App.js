import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Services from './pages/Services';
import Themes from './pages/Themes';
import Interviews from './pages/Interviews';
import About from './pages/About';
import Archives from './pages/Archives';
import Contact from './pages/Contact';
import Article from './pages/Article';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiesPolicy from './pages/CookiesPolicy';

function App() {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return (
    <>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/analyses" element={<Services />} />
          <Route path="/services" element={<Services />} />
          <Route path="/themes" element={<Themes />} />
          <Route path="/interviews" element={<Interviews />} />
          <Route path="/archives" element={<Archives />} />
          <Route path="/apropos" element={<About />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/article/:slug" element={<Article />} />
          <Route path="/conditions-utilisation" element={<Terms />} />
          <Route path="/politique-confidentialite" element={<Privacy />} />
          <Route path="/politique-cookies" element={<CookiesPolicy />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </>
  );
}

export default App;