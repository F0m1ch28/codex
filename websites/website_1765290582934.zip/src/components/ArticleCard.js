import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ArticleCard.module.css';
import ThemeTag from './ThemeTag';
import formatDate from '../utils/formatDate';

function ArticleCard({ article }) {
  return (
    <article className={styles.card}>
      <Link to={`/article/${article.slug}`} className={styles.imageWrapper}>
        <img src={article.image} alt={article.title} loading="lazy" />
      </Link>
      <div className={styles.content}>
        <p className={styles.date}>{formatDate(article.date)}</p>
        <h3>
          <Link to={`/article/${article.slug}`}>{article.title}</Link>
        </h3>
        {article.subtitle && <p className={styles.subtitle}>{article.subtitle}</p>}
        <p className={styles.description}>{article.description}</p>
        <div className={styles.tags}>
          {article.themes.slice(0, 3).map((theme) => (
            <ThemeTag key={`${article.slug}-${theme}`} label={theme} />
          ))}
        </div>
      </div>
    </article>
  );
}

export default ArticleCard;