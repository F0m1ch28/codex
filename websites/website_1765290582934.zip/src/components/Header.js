import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { label: 'Accueil', path: '/' },
  { label: 'Analyses', path: '/analyses' },
  { label: 'Thèmes', path: '/themes' },
  { label: 'Interviews', path: '/interviews' },
  { label: 'Archives', path: '/archives' },
  { label: 'À propos', path: '/apropos' },
  { label: 'Contact', path: '/contact' },
];

function Header() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [hasShadow, setHasShadow] = useState(false);

  useEffect(() => {
    const onScroll = () => setHasShadow(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isMobileOpen ? 'hidden' : 'auto';
  }, [isMobileOpen]);

  const closeMenu = () => setIsMobileOpen(false);

  return (
    <header className={`${styles.header} ${hasShadow ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          French Automotive Sector Analysis
        </NavLink>
        <nav className={styles.nav} aria-label="Navigation principale">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <button
          type="button"
          className={styles.mobileToggle}
          onClick={() => setIsMobileOpen((prev) => !prev)}
          aria-label={isMobileOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
          aria-expanded={isMobileOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          className={`${styles.mobileMenu} ${isMobileOpen ? styles.mobileOpen : ''}`}
          aria-label="Navigation mobile"
        >
          <ul>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  onClick={closeMenu}
                  className={({ isActive }) => (isActive ? styles.mobileActive : '')}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;