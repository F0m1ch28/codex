import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brand}>
          <h3>French Automotive Sector Analysis</h3>
          <p>
            Revue analytique indépendante consacrée aux mutations de la filière automobile française,
            fondée sur des données vérifiées et des observations de terrain.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h4>Navigation</h4>
            <ul>
              <li><NavLink to="/">Accueil</NavLink></li>
              <li><NavLink to="/analyses">Analyses</NavLink></li>
              <li><NavLink to="/themes">Thèmes</NavLink></li>
              <li><NavLink to="/interviews">Interviews</NavLink></li>
              <li><NavLink to="/archives">Archives</NavLink></li>
              <li><NavLink to="/contact">Contact</NavLink></li>
            </ul>
          </div>
          <div>
            <h4>Références éditoriales</h4>
            <ul>
              <li><NavLink to="/apropos">À propos</NavLink></li>
              <li><NavLink to="/conditions-utilisation">Conditions d’utilisation</NavLink></li>
              <li><NavLink to="/politique-confidentialite">Politique de confidentialité</NavLink></li>
              <li><NavLink to="/politique-cookies">Politique de cookies</NavLink></li>
            </ul>
          </div>
          <div>
            <h4>Coordonnées</h4>
            <ul>
              <li>contact@french-automotive-analysis.fr</li>
              <li>12 rue des Ateliers, 75011 Paris</li>
              <li>+33 (0)1 42 00 00 00</li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <span>© {year} French Automotive Sector Analysis. Tous droits réservés.</span>
          <span>Publication hébergée en France. Dernière mise à jour : mars 2024.</span>
        </div>
      </div>
    </footer>
  );
}

export default Footer;