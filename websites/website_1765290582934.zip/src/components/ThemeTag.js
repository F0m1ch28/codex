import React from 'react';
import styles from './ThemeTag.module.css';

function ThemeTag({ label }) {
  return <span className={styles.tag}>{label}</span>;
}

export default ThemeTag;