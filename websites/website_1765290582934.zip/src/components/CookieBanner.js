import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const stored = typeof window !== 'undefined'
      ? window.localStorage.getItem('cookie-consent-fasa')
      : null;
    if (!stored) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (value) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('cookie-consent-fasa', value);
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        French Automotive Sector Analysis utilise des cookies techniques afin d’assurer le bon fonctionnement du site.
        Les données collectées sont limitées au strict nécessaire.
      </p>
      <div className={styles.actions}>
        <button type="button" onClick={() => handleChoice('accepted')}>
          Accepter
        </button>
        <button type="button" onClick={() => handleChoice('refused')} className={styles.secondary}>
          Refuser
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;