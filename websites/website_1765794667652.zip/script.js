document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const header = document.querySelector(".site-header");
  const menu = document.getElementById("primary-menu");
  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const cookieAccept = cookieBanner?.querySelector("[data-cookie-accept]");
  const cookieDecline = cookieBanner?.querySelector("[data-cookie-decline]");
  const regForm = document.querySelector("[data-registration-form]");
  const regResult = document.querySelector("[data-registration-result]");
  const planCards = document.querySelectorAll("[data-plan]");
  const summaryName = document.querySelector("[data-plan-name]");
  const summaryPrice = document.querySelector("[data-plan-price]");
  const summaryPower = document.querySelector("[data-plan-power]");
  const copyButton = document.querySelector("[data-copy-wallet]");
  const copyFeedback = document.querySelector("[data-copy-feedback]");
  const counters = document.querySelectorAll("[data-count-to]");
  const progressBars = document.querySelectorAll("[data-progress]");
  const currentPage = body.dataset.page;

  /* Navigation active state */
  if (currentPage) {
    const activeLink = document.querySelector(`[data-nav="${currentPage}"]`);
    if (activeLink) activeLink.classList.add("active");
  }

  /* Mobile navigation toggle */
  if (navToggle && header) {
    navToggle.addEventListener("click", () => {
      const isOpen = header.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    menu?.addEventListener("click", (event) => {
      if (event.target.tagName === "A" && header.classList.contains("nav-open")) {
        header.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* Cookie banner */
  try {
    const consent = localStorage.getItem("ccxConsent");
    if (!consent && cookieBanner) {
      setTimeout(() => cookieBanner.classList.add("show"), 600);
    }
    const handleConsent = (value) => {
      localStorage.setItem("ccxConsent", value);
      cookieBanner?.classList.remove("show");
    };
    cookieAccept?.addEventListener("click", () => handleConsent("accepted"));
    cookieDecline?.addEventListener("click", () => handleConsent("declined"));
  } catch (error) {
    cookieBanner?.classList.add("show");
  }

  /* Registration form */
  if (regForm && regResult) {
    regForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(regForm);
      const name = formData.get("name");
      const amount = formData.get("amount");
      regResult.textContent = `Welcome ${name}! Your deposit intent of ${amount} USDT (TRC20) has been logged. Expect activation details in your inbox within 6 minutes.`;
      regResult.classList.add("visible");
      regForm.reset();
      setTimeout(() => regResult.classList.remove("visible"), 8000);
    });
  }

  /* Plan selection */
  if (planCards.length && summaryName && summaryPrice && summaryPower) {
    let selectedCard = null;
    const activateCard = (card) => {
      selectedCard?.classList.remove("selected");
      selectedCard = card;
      selectedCard.classList.add("selected");
      summaryName.textContent = selectedCard.dataset.planName;
      summaryPrice.textContent = selectedCard.dataset.planPrice;
      summaryPower.textContent = selectedCard.dataset.planPower;
    };
    planCards.forEach((card, index) => {
      card.addEventListener("click", () => activateCard(card));
      if (index === 0) activateCard(card);
    });
  }

  /* Copy wallet address */
  if (copyButton && copyFeedback) {
    copyButton.addEventListener("click", async () => {
      const wallet = copyButton.dataset.wallet;
      try {
        await navigator.clipboard.writeText(wallet);
        copyFeedback.textContent = "Wallet address copied to clipboard.";
      } catch (error) {
        copyFeedback.textContent = "Unable to copy automatically. Please copy manually.";
      }
      copyFeedback.classList.add("visible");
      setTimeout(() => copyFeedback.classList.remove("visible"), 4000);
    });
  }

  /* Dashboard stats counters */
  if (counters.length) {
    const animateCounter = (counter) => {
      const target = parseFloat(counter.dataset.countTo);
      const duration = parseInt(counter.dataset.countDuration || "1500", 10);
      const start = 0;
      const startTime = performance.now();

      const update = (currentTime) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        const value = start + eased * (target - start);
        counter.textContent = value.toLocaleString(undefined, {
          maximumFractionDigits: counter.dataset.decimals ? parseInt(counter.dataset.decimals, 10) : 0
        });
        if (progress < 1) requestAnimationFrame(update);
      };
      requestAnimationFrame(update);
    };

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.35 });

    counters.forEach((counter) => observer.observe(counter));
  }

  /* Progress bars */
  if (progressBars.length) {
    progressBars.forEach((bar) => {
      const percent = bar.dataset.progress;
      requestAnimationFrame(() => {
        bar.style.setProperty("--progress", `${percent}%`);
      });
    });
  }
});