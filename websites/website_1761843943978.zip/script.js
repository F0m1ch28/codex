document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const scrollTopButton = document.querySelector(".scroll-top");
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAccept = document.querySelector(".cookie-accept");
    const steamBackground = document.querySelector(".steam-background");
    const currentYearEl = document.getElementById("current-year");

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    // Mobile navigation
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = siteNav.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", isOpen.toString());
        });

        siteNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                siteNav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    // Scroll to top button visibility
    const handleScrollTopVisibility = () => {
        if (window.scrollY > 320) {
            scrollTopButton?.classList.add("visible");
        } else {
            scrollTopButton?.classList.remove("visible");
        }

        if (steamBackground) {
            const offset = window.scrollY * 0.06;
            steamBackground.style.transform = `translateY(${offset}px)`;
        }
    };

    window.addEventListener("scroll", handleScrollTopVisibility);
    handleScrollTopVisibility();

    scrollTopButton?.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    // Cookie banner
    const COOKIE_KEY = "northbrewCookieConsent";

    if (cookieBanner && cookieAccept) {
        const consent = localStorage.getItem(COOKIE_KEY);
        if (!consent) {
            requestAnimationFrame(() => cookieBanner.classList.add("show"));
        }

        cookieAccept.addEventListener("click", () => {
            localStorage.setItem(COOKIE_KEY, "accepted");
            cookieBanner.classList.remove("show");
        });
    }
});