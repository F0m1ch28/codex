```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please share your name.';
    if (!formData.company.trim())
      newErrors.company = 'Please add your company or organization.';
    if (!formData.message.trim())
      newErrors.message = 'Let us know how we can help.';
    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else {
      const emailRegex =
        /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
      if (!emailRegex.test(formData.email)) {
        newErrors.email = 'Please enter a valid email address.';
      }
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus('');
      return;
    }
    setErrors({});
    setStatus(
      'Thank you for reaching out. Our consultants will respond within one business day.'
    );
    setFormData(initialState);
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className={styles.contact}>
      <Helmet>
        <title>Contact TechSolutions | Let’s Talk Cloud &amp; Digital Strategy</title>
        <meta
          name="description"
          content="Connect with TechSolutions to discuss your cloud strategy, modernization roadmap, or digital transformation questions."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Let’s explore what’s next</h1>
          <p>
            Share a few details about your needs and a consultant will respond
            promptly. We look forward to learning more about your goals.
          </p>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your full name"
                  aria-required="true"
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@company.com"
                  aria-required="true"
                />
                {errors.email && (
                  <span className={styles.error}>{errors.email}</span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Company or organization"
                  aria-required="true"
                />
                {errors.company && (
                  <span className={styles.error}>{errors.company}</span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="How can we help?"
                  aria-required="true"
                />
                {errors.message && (
                  <span className={styles.error}>{errors.message}</span>
                )}
              </div>

              <button type="submit" className={styles.submit}>
                Submit message
              </button>
              {status && <p className={styles.status}>{status}</p>}
            </form>

            <aside className={styles.sidebar}>
              <h2>Contact information</h2>
              <p>
                We’re available Monday through Friday from 9:00 AM to 6:00 PM
                Pacific Time. We’ll respond to every inquiry as quickly as
                possible.
              </p>
              <div className={styles.infoBlock}>
                <h3>Visit us</h3>
                <p>
                  123 Tech Avenue, Innovation District,
                  <br />
                  San Francisco, CA 94105
                </p>
              </div>
              <div className={styles.infoBlock}>
                <h3>Call</h3>
                <a href="tel:+15551234567">+1 (555) 123-4567</a>
              </div>
              <div className={styles.infoBlock}>
                <h3>Email</h3>
                <a href="mailto:info@techsolutions.com">
                  info@techsolutions.com
                </a>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```