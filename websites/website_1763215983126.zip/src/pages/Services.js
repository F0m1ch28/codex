```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Cloud strategy and planning',
    description:
      'We evaluate your current landscape, clarify objectives, and design a roadmap that aligns architecture, security, operations, and people.',
    image: 'https://picsum.photos/seed/cloudplanning/600/420',
    outcomes: [
      'Comprehensive cloud readiness assessment',
      'Clear implementation priorities and milestones',
      'Adoption playbooks for teams and stakeholders',
    ],
  },
  {
    title: 'Migration and modernization',
    description:
      'From application migration to platform modernization, we guide every step so your move to the cloud is predictable, secure, and well-supported.',
    image: 'https://picsum.photos/seed/migration/600/420',
    outcomes: [
      'Modern reference architectures',
      'Cost management and governance frameworks',
      'Shared accountability models for operations',
    ],
  },
  {
    title: 'Digital experience acceleration',
    description:
      'We help you create intuitive experiences across web, mobile, and workplace tools that improve customer and employee engagement.',
    image: 'https://picsum.photos/seed/digitalexperience/600/420',
    outcomes: [
      'Experience journey mapping and visioning',
      'Prioritized backlog and measurement plan',
      'A roadmap to deliver quick wins and scale',
    ],
  },
  {
    title: 'Managed cloud advisory',
    description:
      'Receive ongoing strategic guidance, architecture reviews, and enablement to ensure your cloud investments continue to deliver value.',
    image: 'https://picsum.photos/seed/managedcloud/600/420',
    outcomes: [
      'Quarterly strategy checkpoints and insights',
      'Proactive risk and compliance oversight',
      'Tailored coaching for engineering teams',
    ],
  },
];

const Services = () => {
  return (
    <div className={styles.services}>
      <Helmet>
        <title>Services | TechSolutions Cloud &amp; Digital Consulting</title>
        <meta
          name="description"
          content="Explore TechSolutions services covering cloud strategy, migration, modernization, digital experience acceleration, and managed advisory."
        />
      </Helmet>
      <section className={styles.intro}>
        <div className="container">
          <h1>Services designed to keep momentum on your side</h1>
          <p>
            From first assessment to continuous optimization, we work alongside
            your teams to deliver technology change that is clear, responsible,
            and measurable.
          </p>
        </div>
      </section>
      <section className="container">
        <div className={styles.serviceList}>
          {services.map((service) => (
            <article className={styles.card} key={service.title}>
              <div className={styles.media}>
                <img src={service.image} alt={service.title} />
              </div>
              <div className={styles.details}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.outcomes.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Services;
```