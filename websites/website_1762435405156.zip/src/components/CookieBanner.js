import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'ae_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  const rejectCookies = () => {
    window.localStorage.setItem(COOKIE_KEY, 'rejected');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Informativa sui cookie">
      <div className={styles.text}>
        <h4>La tua privacy è importante</h4>
        <p>
          Utilizziamo cookie tecnici e analitici per migliorare l&apos;esperienza di navigazione. Scopri di più nella nostra{' '}
          <a href="/cookie-policy">Cookie Policy</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button className={styles.secondary} onClick={rejectCookies}>
          Rifiuta
        </button>
        <button className={styles.primary} onClick={acceptCookies}>
          Accetta
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;