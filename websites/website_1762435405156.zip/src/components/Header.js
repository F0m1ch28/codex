import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Intestazione principale">
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} aria-label="Accademia Europea di Comunicazione Digitale">
            <span className={styles.logoMark}>AE</span>
            <span className={styles.logoText}>
              Accademia Europea<br />
              <span className={styles.logoSub}>di Comunicazione Digitale</span>
            </span>
          </NavLink>
          <nav className={`${styles.nav} ${open ? styles.navOpen : ''}`} aria-label="Navigazione principale">
            <NavLink to="/" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}>
              Home
            </NavLink>
            <NavLink to="/chi-siamo" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}>
              Chi siamo
            </NavLink>
            <NavLink to="/corsi" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}>
              Corsi
            </NavLink>
            <NavLink to="/programma" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}>
              Programma
            </NavLink>
            <NavLink to="/docenti" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}>
              Docenti
            </NavLink>
            <NavLink to="/contatti" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}>
              Contatti
            </NavLink>
          </nav>
          <button
            aria-label="Apri menu di navigazione"
            className={`${styles.burger} ${open ? styles.burgerOpen : ''}`}
            onClick={() => setOpen(!open)}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;