import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Piè di pagina">
    <div className="container">
      <div className={styles.grid}>
        <div>
          <h3 className={styles.heading}>Accademia Europea di Comunicazione Digitale</h3>
          <p className={styles.text}>
            Centro di formazione professionale online con sede a Milano, dedicato alla crescita delle competenze in branding, content strategy, sviluppo e marketing digitale.
          </p>
        </div>
        <div>
          <h4 className={styles.subheading}>Sede</h4>
          <address className={styles.address}>
            Via Milano, 22<br />
            20121 Milano MI<br />
            Italia
          </address>
          <a className={styles.link} href="tel:+390294568113">+39 02 9456 8113</a><br />
          <a className={styles.link} href="mailto:info@accademiadigitale.it">info@accademiadigitale.it</a>
        </div>
        <div>
          <h4 className={styles.subheading}>Navigazione</h4>
          <ul className={styles.list}>
            <li><NavLink to="/chi-siamo">Chi siamo</NavLink></li>
            <li><NavLink to="/corsi">Corsi</NavLink></li>
            <li><NavLink to="/programma">Programma</NavLink></li>
            <li><NavLink to="/docenti">Docenti</NavLink></li>
            <li><NavLink to="/contatti">Contatti</NavLink></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.subheading}>Supporto</h4>
          <ul className={styles.list}>
            <li><NavLink to="/termini">Termini e condizioni</NavLink></li>
            <li><NavLink to="/privacy">Privacy</NavLink></li>
            <li><NavLink to="/cookie-policy">Cookie Policy</NavLink></li>
          </ul>
          <div className={styles.socials} aria-label="Social media">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">LI</a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">IG</a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">YT</a>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Accademia Europea di Comunicazione Digitale. Tutti i diritti riservati.</p>
      </div>
    </div>
  </footer>
);

export default Footer;