import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Informativa Privacy | Accademia Europea</title>
      <meta
        name="description"
        content="Informativa completa sul trattamento dei dati personali in conformità al GDPR da parte dell'Accademia Europea di Comunicazione Digitale."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Informativa privacy</h1>
        <p>Tutela dei dati personali ai sensi del Regolamento (UE) 2016/679 (GDPR).</p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <h2>1. Titolare del trattamento</h2>
        <p>Accademia Europea di Comunicazione Digitale, con sede in Via Milano, 22, 20121 Milano MI.</p>

        <h2>2. Tipologie di dati raccolti</h2>
        <p>
          Dati identificativi (nome, cognome), dati di contatto (email, telefono) e informazioni inerenti agli interessi formativi.
          I dati sono forniti volontariamente tramite i form presenti sul sito.
        </p>

        <h2>3. Finalità del trattamento</h2>
        <ul>
          <li>Gestione delle richieste di informazione.</li>
          <li>Invio di comunicazioni relative ai corsi e ai programmi formativi.</li>
          <li>Analisi statistica anonima per migliorare l’offerta formativa.</li>
        </ul>

        <h2>4. Base giuridica del trattamento</h2>
        <p>Consenso dell’interessato e legittimo interesse relativo ai servizi richiesti.</p>

        <h2>5. Conservazione dei dati</h2>
        <p>I dati sono conservati per il tempo strettamente necessario alla gestione delle richieste e comunque non oltre 24 mesi.</p>

        <h2>6. Diritti dell’interessato</h2>
        <p>
          Gli interessati possono esercitare i diritti previsti dagli articoli 15-22 del GDPR scrivendo a info@accademiadigitale.it.
        </p>

        <h2>7. Sicurezza</h2>
        <p>
          L’accademia adotta misure tecniche e organizzative adeguate per garantire la riservatezza e l’integrità dei dati trattati.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;