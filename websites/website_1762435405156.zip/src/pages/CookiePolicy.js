import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Accademia Europea</title>
      <meta
        name="description"
        content="Dettagli sull'utilizzo dei cookie tecnici e analitici da parte dell'Accademia Europea di Comunicazione Digitale in conformità alle normative vigenti."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Informazioni sull’uso dei cookie tecnici e analitici su questo sito.</p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <h2>1. Cosa sono i cookie</h2>
        <p>
          I cookie sono piccoli file di testo inviati dal sito web al dispositivo dell’utente, dove vengono memorizzati per essere poi ritrasmessi alla visita successiva.
        </p>

        <h2>2. Tipologie di cookie utilizzati</h2>
        <ul>
          <li>Cookie tecnici: necessari per il corretto funzionamento del sito.</li>
          <li>Cookie analitici: usati per raccogliere informazioni aggregate sull’utilizzo del sito.</li>
        </ul>

        <h2>3. Gestione dei cookie</h2>
        <p>
          L’utente può modificare in qualsiasi momento le impostazioni del browser per bloccare o eliminare i cookie.
          La disattivazione dei cookie tecnici potrebbe compromettere alcune funzionalità del sito.
        </p>

        <h2>4. Aggiornamenti</h2>
        <p>
          Questa informativa può essere aggiornata in base a modifiche normative o alle funzionalità del sito. Si consiglia di consultarla periodicamente.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;