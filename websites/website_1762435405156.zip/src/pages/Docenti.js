import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Docenti.module.css';

const docenti = [
  {
    name: 'Andrea Lombardi',
    role: 'Head of Digital Advertising',
    bio: 'Specialista in Facebook e Google Ads con 12 anni di esperienza. Coordina i moduli su funnel, tracking e ottimizzazione.',
    image: 'https://picsum.photos/400/400?random=12'
  },
  {
    name: 'Francesca Vitale',
    role: 'Lead Content Strategist',
    bio: 'Copywriter e strategist, lavora su brand identity, storytelling e content governance per aziende tech e lifestyle.',
    image: 'https://picsum.photos/400/400?random=13'
  },
  {
    name: 'Giorgio Milani',
    role: 'Senior Full Stack Developer',
    bio: 'Ingegnere del software. Ha progettato architetture cloud, componenti riutilizzabili e flussi di automazione in Python.',
    image: 'https://picsum.photos/400/400?random=14'
  },
  {
    name: 'Ilaria Boschi',
    role: 'Social Media Strategist',
    bio: 'Esperta di Instagram e TikTok marketing, analizza insight e pianifica calendari editoriali cross-platform.',
    image: 'https://picsum.photos/400/400?random=15'
  },
  {
    name: 'Marco Sarti',
    role: 'Data Analyst',
    bio: 'Supporta gli studenti nell’interpretazione dei dati, nella creazione di dashboard e nell’applicazione di modelli previsionali.',
    image: 'https://picsum.photos/400/400?random=16'
  },
  {
    name: 'Chiara De Luca',
    role: 'UX Engineer',
    bio: 'Combina ricerca utente, prototipazione e sviluppo front-end per creare interfacce inclusive e performanti.',
    image: 'https://picsum.photos/400/400?random=17'
  }
];

const Docenti = () => (
  <>
    <Helmet>
      <title>Docenti e mentor | Accademia Europea</title>
      <meta
        name="description"
        content="Conosci i docenti dell'Accademia Europea di Comunicazione Digitale: professionisti senior in branding, sviluppo, data analysis e social media marketing."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Docenti e mentor</h1>
        <p>
          Professionisti attivi nel settore digitale, pronti a condividere metodi, strumenti e processi operativi.
        </p>
      </div>
    </section>

    <section className={styles.gridSection}>
      <div className="container">
        <div className={styles.grid}>
          {docenti.map((docente) => (
            <article key={docente.name} className={styles.card}>
              <img src={`${docente.image}`} alt={`${docente.name}, ${docente.role}`} loading="lazy" />
              <div>
                <h2>{docente.name}</h2>
                <span className={styles.role}>{docente.role}</span>
                <p>{docente.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Docenti;