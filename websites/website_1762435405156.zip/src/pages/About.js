import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>Chi siamo | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Scopri la storia, la missione e la metodologia dell'Accademia Europea di Comunicazione Digitale di Milano. Un centro di formazione professionale online orientato all'innovazione."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Chi siamo</h1>
        <p>
          Dal cuore di Milano guidiamo professionisti, aziende e team nel mondo della comunicazione digitale,
          con percorsi su misura che uniscono strategia, tecnologia e creatività.
        </p>
      </div>
    </section>

    <section className={styles.storySection}>
      <div className="container">
        <div className={styles.grid}>
          <div>
            <h2>La nostra storia</h2>
            <p>
              L’Accademia Europea di Comunicazione Digitale nasce dall’incontro di docenti universitari, professionisti del marketing e ingegneri del software.
              Dal 2014 collaboriamo con aziende e istituzioni per diffondere competenze avanzate in Italia e in Europa, costruendo percorsi formativi orientati all’esperienza.
            </p>
            <p>
              Il campus digitale di Milano è il punto di riferimento per laboratori online, project work condivisi e mentoring individuale.
              Ogni programma è aggiornato costantemente per rispondere alle evoluzioni del mercato.
            </p>
          </div>
          <div className={styles.valuesCard}>
            <h3>I nostri valori</h3>
            <ul>
              <li>Innovazione continua e sperimentazione controllata.</li>
              <li>Metodo scientifico applicato a branding, analisi e sviluppo.</li>
              <li>Collaborazione interdisciplinare tra docenti e studenti.</li>
              <li>Impatto misurabile su progetti reali e carriere professionali.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.missionSection}>
      <div className="container">
        <div className={styles.missionGrid}>
          <div>
            <h2>Missione</h2>
            <p>
              Rendere accessibili competenze digitali avanzate attraverso percorsi strutturati, modulabili e orientati ai KPI.
              Crediamo in un apprendimento pratico, basato sull’analisi dei dati e sulla capacità di comunicare valore.
            </p>
          </div>
          <div>
            <h2>Metodo</h2>
            <p>
              Alterniamo live session, laboratori pratici, attività asincrone e verifiche progettuali.
              Ogni modulo integra toolkit collaborativi, checklist operative e momenti di confronto con i docenti.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.timelineSection}>
      <div className="container">
        <h2>Percorso evolutivo</h2>
        <div className={styles.timeline}>
          <div className={styles.timelineItem}>
            <span className={styles.year}>2014</span>
            <p>Lancio dell’accademia a Milano con i primi corsi in comunicazione digitale e sviluppo front-end.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.year}>2017</span>
            <p>Introduzione di moduli su analisi matematica applicata e calcoli strutturali per progetti digitali complessi.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.year}>2020</span>
            <p>Trasformazione in campus online, con laboratori live, mentoring remoto e partnership aziendali.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.year}>2023</span>
            <p>Inserimento di percorsi su content strategy, componenti riutilizzabili e social media marketing avanzato.</p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <h2>Il team accademico</h2>
        <div className={styles.teamGrid}>
          <article className={styles.teamCard}>
            <img src="https://picsum.photos/400/400?random=9" alt="Direttrice accademica durante una presentazione" loading="lazy" />
            <h3>Elena Rinaldi</h3>
            <p>Direttrice accademica · Specialista in branding online e content strategy, coordina i percorsi multidisciplinari.</p>
          </article>
          <article className={styles.teamCard}>
            <img src="https://picsum.photos/400/400?random=10" alt="Responsabile dei laboratori digitali" loading="lazy" />
            <h3>Matteo Grassi</h3>
            <p>Responsabile laboratori · Ingegnere informatico, guida i moduli di coding e sviluppo di componenti.</p>
          </article>
          <article className={styles.teamCard}>
            <img src="https://picsum.photos/400/400?random=11" alt="Coordinatrice dei progetti social media" loading="lazy" />
            <h3>Valeria Contini</h3>
            <p>Coordinatrice Social Media · Esperta in Instagram marketing, storytelling visuale e community management.</p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default About;