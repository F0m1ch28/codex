import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programma.module.css';

const Programma = () => (
  <>
    <Helmet>
      <title>Programma dei corsi | Accademia Europea</title>
      <meta
        name="description"
        content="Struttura dei moduli, durata, project work e certificazioni dell'Accademia Europea di Comunicazione Digitale."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Programma didattico</h1>
        <p>
          Un percorso modulare progettato per integrare branding, sviluppo e social media marketing.
          Ogni fase unisce teoria, pratica e valutazioni continue.
        </p>
      </div>
    </section>

    <section className={styles.modulesSection}>
      <div className="container">
        <div className={styles.modulesGrid}>
          <article className={styles.moduleCard}>
            <span className={styles.moduleBadge}>Modulo 1</span>
            <h2>Fondamenti strategici</h2>
            <ul>
              <li>Analisi di mercato, benchmark e posizionamento digitale.</li>
              <li>Brand identity, tono di voce e architettura dei contenuti.</li>
              <li>UX writing e progettazione di esperienze cross-canale.</li>
            </ul>
          </article>
          <article className={styles.moduleCard}>
            <span className={styles.moduleBadge}>Modulo 2</span>
            <h2>Progettazione tecnica</h2>
            <ul>
              <li>HTML semantico, CSS modulare e componenti React.</li>
              <li>JavaScript asincrono, API REST e gestione dello stato.</li>
              <li>Python per automazioni, analisi dati e calcoli strutturali.</li>
            </ul>
          </article>
          <article className={styles.moduleCard}>
            <span className={styles.moduleBadge}>Modulo 3</span>
            <h2>Social &amp; performance</h2>
            <ul>
              <li>Content strategy, format video e ottimizzazione per Instagram e TikTok.</li>
              <li>Advertising multicanale con Facebook e Google Ads.</li>
              <li>Dashboard per monitoraggio KPI, attribution e reporting.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.structureSection}>
      <div className="container">
        <div className={styles.structureGrid}>
          <div className={styles.structureCard}>
            <h3>Durata</h3>
            <p>
              18 settimane complessive con 2 incontri live a settimana, attività asincrone guidate e sessioni di tutoring personalizzato.
            </p>
          </div>
          <div className={styles.structureCard}>
            <h3>Project work</h3>
            <p>
              Tre progetti finali: strategia di branding online, sviluppo di un prototipo web e piano di social media marketing con analisi dei risultati.
            </p>
          </div>
          <div className={styles.structureCard}>
            <h3>Certificazioni</h3>
            <p>
              Attestati nominativi e badge digitali. Supporto per certificazioni esterne (Facebook Blueprint, Google Analytics, HTML/CSS).
            </p>
          </div>
          <div className={styles.structureCard}>
            <h3>Career Lab</h3>
            <p>
              Revisione del portfolio, simulazione di colloqui, potenziamento del personal branding e creazione di case study professionali.
            </p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Programma;