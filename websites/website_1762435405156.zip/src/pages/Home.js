import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Percorsi completati', value: 480 },
  { label: 'Professionisti supportati', value: 1350 },
  { label: 'Ore di mentoring', value: 7200 },
  { label: 'Project work validati', value: 280 }
];

const testimonialsData = [
  {
    name: 'Sara Conti',
    role: 'Brand Strategist',
    quote:
      'Il percorso di branding online mi ha permesso di trasformare dati complessi in strategie chiare. L’approccio laboratoriale è la vera forza dell’accademia.'
  },
  {
    name: 'Luca Moretti',
    role: 'Full Stack Developer',
    quote:
      'Docenti aggiornati, tutor disponibili e project work concreti: ho potuto applicare immediatamente quanto appreso nel mio team di sviluppo.'
  },
  {
    name: 'Giulia Ferraro',
    role: 'Content Designer',
    quote:
      'La combinazione di analisi, storytelling e KPI digitali è stata preziosa. Oggi coordino contenuti multicanale con più sicurezza e metodo.'
  }
];

const projectsData = [
  { id: 1, title: 'Dashboard per Analisi di Campagne', category: 'Analisi', image: 'https://picsum.photos/1200/800?random=4', description: 'Visualizzazione dei dati per campagne multicanale con tracciamento dei KPI principali.' },
  { id: 2, title: 'Brand Book Digitale', category: 'Strategia', image: 'https://picsum.photos/1200/800?random=5', description: 'Guida completa per la coerenza del tono di voce e dei contenuti su piattaforme digitali.' },
  { id: 3, title: 'Prototipo UX per eCommerce', category: 'Design', image: 'https://picsum.photos/1200/800?random=6', description: 'Interfacce responsive ottimizzate per la conversione e la fidelizzazione degli utenti.' },
  { id: 4, title: 'Workflow Automation Social', category: 'Strategia', image: 'https://picsum.photos/1200/800?random=7', description: 'Sistema di pianificazione e automazione per contenuti social con analisi delle performance.' }
];

const faqData = [
  {
    question: 'Qual è il livello di esperienza richiesto per accedere ai corsi?',
    answer:
      'I percorsi sono modulati su tre livelli. Durante il colloquio iniziale valutiamo le competenze e proponiamo un piano personalizzato per branding, sviluppo o social media marketing.'
  },
  {
    question: 'Come sono strutturati i project work?',
    answer:
      'Ogni modulo prevede un project work reale: dati da interpretare, briefing del cliente, coinvolgimento di tutor e presentazione finale con feedback orientato al miglioramento continuo.'
  },
  {
    question: 'È previsto il supporto dopo il termine del corso?',
    answer:
      'Sì, offriamo sessioni di follow-up, revisione portfolio, mentoring individuale e accesso a una community professionale per confrontarsi e collaborare.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Framework per una Content Strategy Data-Informed',
    excerpt: 'Integrare analisi matematica e insight qualitativi per costruire contenuti che rispondono a obiettivi misurabili.',
    link: '/programma'
  },
  {
    id: 2,
    title: 'Come progettare funnel integrati con Facebook e Instagram Ads',
    excerpt: 'Segmentazione, testing e ottimizzazione continua degli annunci per raggiungere pubblico e risultati affidabili.',
    link: '/corsi'
  },
  {
    id: 3,
    title: 'Sviluppo web: dal prototipo al deploy con HTML, CSS, JS e Python',
    excerpt: 'Un percorso che unisce progettazione tecnica, modellazione di prodotti e componenti interattivi.',
    link: '/chi-siamo'
  }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('Tutti');
  const [faqOpen, setFaqOpen] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatedStats((prev) =>
        prev.map((value, index) => {
          if (value < statsData[index].value) {
            return Math.min(value + Math.ceil(statsData[index].value / 40), statsData[index].value);
          }
          return value;
        })
      );
    }, 50);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const slider = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 5000);
    return () => clearInterval(slider);
  }, []);

  const filteredProjects = useMemo(() => {
    if (selectedCategory === 'Tutti') return projectsData;
    return projectsData.filter((project) => project.category === selectedCategory);
  }, [selectedCategory]);

  const toggleFaq = (index) => {
    setFaqOpen((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Trasforma la tua carriera digitale | Accademia Europea</title>
        <meta
          name="description"
          content="Accademia Europea di Comunicazione Digitale a Milano: corsi avanzati su branding online, content strategy, coding, social media marketing e sviluppo di componenti digitali."
        />
      </Helmet>
      <div className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <p className={styles.heroEyebrow}>Centro di formazione professionale online · Milano</p>
              <h1 className={styles.heroTitle}>Trasforma la Tua Carriera Digitale</h1>
              <p className={styles.heroSubtitle}>
                Dal branding alla modellazione di prodotti digitali, passando per analisi matematica applicata e calcoli strutturali:
                accompagniamo professionisti e team nella costruzione di strategie affidabili e misurabili.
              </p>
              <div className={styles.heroActions}>
                <Link to="/contatti" className="btn-primary" aria-label="Richiedi informazioni sui corsi">
                  Inizia oggi
                </Link>
                <Link to="/programma" className="btn-outline" aria-label="Scopri il programma completo">
                  Scopri il programma
                </Link>
              </div>
            </div>
            <div className={styles.heroImageWrapper} aria-hidden="true">
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Studenti impegnati in un laboratorio digitale"
                className={styles.heroImage}
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </div>

      <section className={styles.introSection}>
        <div className="container">
          <div className={styles.introLayout}>
            <div className={styles.introText}>
              <h2>Accademia Europea di Comunicazione Digitale</h2>
              <p>
                Siamo un hub di formazione avanzata con sede a Milano, che unisce progettazione tecnica, sviluppo di componenti e visione strategica.
                I nostri percorsi integrano branding online, content strategy, coding e social media marketing per preparare figure professionali complete e autonome.
              </p>
              <Link to="/chi-siamo" className={styles.subtleLink}>
                Conosci la nostra visione →
              </Link>
            </div>
            <div className={styles.introStats} role="list" aria-label="Risultati dell'accademia">
              {statsData.map((stat, index) => (
                <div className={styles.statCard} key={stat.label} role="listitem">
                  <span className={styles.statValue}>{animatedStats[index]}+</span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.coursesSection} id="corsi">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>I nostri corsi</h2>
            <p>
              Percorsi verticali e integrati su branding online, sviluppo e comunicazione digitale. Ogni corso prevede laboratorio, mentoring e project work.
            </p>
          </div>
          <div className={styles.coursesGrid}>
            <article className={styles.courseCard}>
              <div>
                <h3>Pubblicità Targetizzata</h3>
                <p>
                  Pianifica campagne su Facebook e Google Ads, interpreta dati in tempo reale, imposta funnel e ottimizza le conversioni con modelli predittivi.
                </p>
              </div>
              <Link to="/corsi" className={styles.cardLink}>Approfondisci</Link>
            </article>
            <article className={styles.courseCard}>
              <div>
                <h3>Coding &amp; Sviluppo</h3>
                <p>
                  HTML, CSS, JavaScript e Python per costruire interfacce, API e sistemi scalabili. Focus su componenti riutilizzabili e test di qualità.
                </p>
              </div>
              <Link to="/corsi" className={styles.cardLink}>Esplora il percorso</Link>
            </article>
            <article className={styles.courseCard}>
              <div>
                <h3>Social Media Marketing</h3>
                <p>
                  Strategie per Instagram e TikTok, content design, pianificazione editoriale, metriche di engagement e storytelling coerente con il brand.
                </p>
              </div>
              <Link to="/corsi" className={styles.cardLink}>Scopri i moduli</Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.processSection} aria-label="Come funziona il percorso formativo">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Come funziona</h2>
            <p>Un processo chiaro, orientato a risultati concreti e alla crescita continua delle competenze.</p>
          </div>
          <div className={styles.processSteps}>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>01</span>
              <h3>Assessment iniziale</h3>
              <p>Analisi delle competenze, definizione degli obiettivi professionali e personalizzazione del piano formativo.</p>
            </div>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>02</span>
              <h3>Moduli avanzati</h3>
              <p>Lezioni live, laboratori pratici, toolkit e risorse per applicare subito concetti di comunicazione e sviluppo.</p>
            </div>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>03</span>
              <h3>Project work</h3>
              <p>Simulazioni reali, coaching con i docenti, validazione del lavoro e ottimizzazione dei deliverable.</p>
            </div>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>04</span>
              <h3>Certificazione e mentoring</h3>
              <p>Attestati riconosciuti, portfolio revisionato e mentoring per supportare l’ingresso in nuovi ruoli digitali.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.whySection}>
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <h2>Perché scegliere l’accademia</h2>
              <p>
                Lavoriamo con metodologie ibride: analisi dati, creatività, prototipazione e sviluppo. Ogni modulo è progettato per generare impatto immediato sul lavoro quotidiano.
              </p>
            </div>
            <ul className={styles.whyList}>
              <li>
                <h3>Docenti senior</h3>
                <p>Professionisti attivi in branding, sviluppo web, data analysis e marketing multicanale.</p>
              </li>
              <li>
                <h3>Learning Lab</h3>
                <p>Laboratori interattivi con strumenti reali, ambienti di test e feedback continuo.</p>
              </li>
              <li>
                <h3>Community professionale</h3>
                <p>Network di alumni e partner in tutta Italia, con eventi e collaborazioni periodiche.</p>
              </li>
              <li>
                <h3>Monitoraggio KPI</h3>
                <p>Ogni progetto è accompagnato da indicatori chiari per misurare progressi e risultati.</p>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-label="Testimonianze degli studenti">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Esperienze degli studenti</h2>
            <p>Storie di crescita professionale e di progetti sviluppati all’interno dell’accademia.</p>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.quote}>
              “{testimonialsData[currentTestimonial].quote}”
            </p>
            <p className={styles.testimonialAuthor}>
              {testimonialsData[currentTestimonial].name} · {testimonialsData[currentTestimonial].role}
            </p>
            <div className={styles.dots} role="tablist" aria-label="Navigazione testimonianze">
              {testimonialsData.map((item, index) => (
                <button
                  key={item.name}
                  className={`${styles.dot} ${currentTestimonial === index ? styles.dotActive : ''}`}
                  aria-label={`Mostra testimonianza di ${item.name}`}
                  aria-selected={currentTestimonial === index}
                  onClick={() => setCurrentTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} id="progetti">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Project work</h2>
            <p>Applicazione concreta delle competenze attraverso casi di studio reali e simulazioni aziendali.</p>
          </div>
          <div className={styles.filters}>
            {['Tutti', 'Strategia', 'Design', 'Analisi'].map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`${styles.filterButton} ${selectedCategory === category ? styles.filterButtonActive : ''}`}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article className={styles.projectCard} key={project.id}>
                <div className={styles.projectImageWrapper}>
                  <img src={`${project.image}&sig=${project.id}`} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Mentor e coach</h2>
            <p>Professionisti che affiancano gli studenti con feedback personalizzati e sessioni dedicate.</p>
          </div>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <img src="https://picsum.photos/400/400?random=3" alt="Mentor durante una sessione formativa" loading="lazy" />
              <div>
                <h3>Simplifica processi complessi</h3>
                <p>Approccio pratico, strumenti collaborativi e task board condivise per seguire ogni progetto.</p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img src="https://picsum.photos/400/400?random=8" alt="Coach che supporta un team digitale" loading="lazy" />
              <div>
                <h3>Mentoring continuo</h3>
                <p>Check-in settimanali, criteri di valutazione trasparenti e roadmap evolutive per ogni studente.</p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Domande frequenti</h2>
            <p>Informazioni utili per orientarti nella scelta del percorso formativo.</p>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <div key={item.question} className={`${styles.faqItem} ${faqOpen === index ? styles.faqOpen : ''}`}>
                <button
                  className={styles.faqButton}
                  onClick={() => toggleFaq(index)}
                  aria-expanded={faqOpen === index}
                  aria-controls={`faq-panel-${index}`}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{faqOpen === index ? '-' : '+'}</span>
                </button>
                <div
                  id={`faq-panel-${index}`}
                  className={styles.faqPanel}
                  aria-hidden={faqOpen !== index}
                >
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Dal nostro laboratorio</h2>
            <p>Insight, metodi e strumenti per progettare strategie digitali consapevoli.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <span className={styles.blogTag}>Aggiornamento</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink} aria-label={`Leggi l'articolo: ${post.title}`}>
                  Continua a leggere →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <div>
              <h2>Pronto a progettare il tuo prossimo salto professionale?</h2>
              <p>Costruiamo insieme un piano di studio su misura per branding, sviluppo o content strategy.</p>
            </div>
            <Link to="/contatti" className="btn-primary" aria-label="Prenota un colloquio con l'accademia">
              Prenota un colloquio
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;