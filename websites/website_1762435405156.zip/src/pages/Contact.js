import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', interest: '', message: '' });
  const [status, setStatus] = useState({ submitted: false, error: false });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus({ submitted: false, error: true });
      return;
    }
    setStatus({ submitted: true, error: false });
    setFormData({ name: '', email: '', interest: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contatti | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Contatta l'Accademia Europea di Comunicazione Digitale a Milano. Compila il form per ricevere informazioni sui corsi e sul programma."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Contattaci</h1>
          <p>Organizziamo un colloquio per definire il percorso formativo più adatto a te o al tuo team.</p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Accademia Europea di Comunicazione Digitale</h2>
              <p>
                Via Milano, 22, 20121 Milano MI<br />
                +39 02 9456 8113<br />
                info@accademiadigitale.it
              </p>
              <p>
                Siamo disponibili dal lunedì al venerdì, dalle 9:00 alle 18:00.
                Rispondiamo a ogni richiesta entro 24 ore lavorative.
              </p>
              <div className={styles.mapWrapper} aria-label="Mappa della sede di Milano">
                <iframe
                  title="Mappa Accademia Europea di Comunicazione Digitale"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2796.944089660875!2d9.1887921!3d45.4713613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDUuNDcxMzYxLCA5LjE4ODc5MjE!5e0!3m2!1sit!2sit!4v1714560000"
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Richiedi informazioni</h2>
              <label htmlFor="name">Nome e cognome*</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
                aria-required="true"
              />

              <label htmlFor="email">Email*</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                aria-required="true"
              />

              <label htmlFor="interest">Area di interesse</label>
              <select id="interest" name="interest" value={formData.interest} onChange={handleChange}>
                <option value="">Seleziona</option>
                <option value="branding">Branding Online</option>
                <option value="coding">Coding &amp; Sviluppo</option>
                <option value="social">Social Media Marketing</option>
              </select>

              <label htmlFor="message">Messaggio*</label>
              <textarea
                id="message"
                name="message"
                rows="4"
                value={formData.message}
                onChange={handleChange}
                required
                aria-required="true"
              />

              <button type="submit" className="btn-primary">Invia richiesta</button>
              {status.error && <p className={styles.error}>Compila tutti i campi obbligatori.</p>}
              {status.submitted && <p className={styles.success}>Grazie! Ti ricontatteremo entro 24 ore.</p>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;