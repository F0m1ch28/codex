import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Termini e condizioni | Accademia Europea</title>
      <meta
        name="description"
        content="Termini e condizioni di utilizzo del sito e dei servizi offerti dall'Accademia Europea di Comunicazione Digitale."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Termini e condizioni</h1>
        <p>Leggi attentamente i termini che regolano l’accesso e l’uso del nostro sito e dei servizi formativi.</p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <h2>1. Introduzione</h2>
        <p>
          L&apos;utilizzo del sito dell&apos;Accademia Europea di Comunicazione Digitale implica l&apos;accettazione dei presenti termini.
          Il sito è destinato a utenti interessati a percorsi formativi professionali in ambito digitale.
        </p>

        <h2>2. Servizi offerti</h2>
        <p>
          Il sito fornisce informazioni su corsi, programmi, docenti e attività formative. Eventuali aggiornamenti dei contenuti possono avvenire senza preavviso.
        </p>

        <h2>3. Proprietà intellettuale</h2>
        <p>
          Tutti i contenuti, compresi testi, grafica e materiale didattico, sono di proprietà dell&apos;Accademia e non possono essere riprodotti senza consenso scritto.
        </p>

        <h2>4. Limitazioni di responsabilità</h2>
        <p>
          L&apos;Accademia si impegna a mantenere informazioni accurate e aggiornate, tuttavia non può garantire l&apos;assenza di eventuali inesattezze.
        </p>

        <h2>5. Legge applicabile</h2>
        <p>
          I presenti termini sono disciplinati dalla legge italiana. Per eventuali controversie è competente il Foro di Milano.
        </p>
      </div>
    </section>
  </>
);

export default Terms;