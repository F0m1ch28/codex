import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Corsi Professionali | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Dettagli sui corsi dell'Accademia Europea: Pubblicità Targetizzata, Coding e Social Media Marketing. Formazione digitale avanzata a Milano e online."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Corsi professionali</h1>
        <p>
          Percorsi completi su pubblicità targetizzata, sviluppo web e social media marketing.
          Ogni corso è progettato con moduli progressivi, project work e coaching individuale.
        </p>
      </div>
    </section>

    <section className={styles.coursesSection}>
      <div className="container">
        <div className={styles.coursesGrid}>
          <article className={styles.courseCard}>
            <h2>Pubblicità Targetizzata</h2>
            <p>
              Progetta campagne performanti su Facebook e Google Ads. Dalla definizione delle audience alla creazione di creatività coerenti con il brand.
            </p>
            <ul>
              <li>Segmentazione del pubblico e definizione delle buyer personas.</li>
              <li>Setup tecnico di Business Manager, pixel e tracciamenti avanzati.</li>
              <li>Gestione budget, testing A/B e ottimizzazione continua.</li>
              <li>Dashboard e reportistica con lettura dei KPI strategici.</li>
            </ul>
          </article>

          <article className={styles.courseCard}>
            <h2>Coding &amp; Sviluppo</h2>
            <p>
              Percorso pratico su HTML, CSS, JavaScript e Python. Dallo sviluppo front-end alla creazione di API, componenti riutilizzabili e automazioni.
            </p>
            <ul>
              <li>Struttura semantica, responsive design e accessibilità.</li>
              <li>JavaScript moderno, integrazione API e testing.</li>
              <li>Python per automazioni, analisi dati e scripting.</li>
              <li>Deploy, versioning e best practice di sicurezza.</li>
            </ul>
          </article>

          <article className={styles.courseCard}>
            <h2>Social Media Marketing</h2>
            <p>
              Strategie per Instagram, TikTok e piattaforme emergenti. Ideazione, produzione e pianificazione di contenuti coerenti con la brand identity.
            </p>
            <ul>
              <li>Analisi del posizionamento e definizione delle tone of voice.</li>
              <li>Content design, format storytelling e calendari editoriali.</li>
              <li>Metriche di engagement, reach, retention e sentiment.</li>
              <li>Gestione community, social care e monitoraggio conversazioni.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.benefitsSection}>
      <div className="container">
        <h2>Strumenti e risorse incluse</h2>
        <div className={styles.benefitsGrid}>
          <div className={styles.benefitCard}>
            <h3>Toolkit operativi</h3>
            <p>
              Template, canvas e checklist per pianificare campagne, progettare interfacce e gestire piani editoriali.
            </p>
          </div>
          <div className={styles.benefitCard}>
            <h3>Sessioni live</h3>
            <p>
              Workshop interattivi, coding lab e analisi di case study con feedback immediato dai docenti.
            </p>
          </div>
          <div className={styles.benefitCard}>
            <h3>Community professionale</h3>
            <p>
              Canali dedicati per confrontarsi, condividere progetti e trovare collaborazioni lungo tutto il percorso.
            </p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Services;