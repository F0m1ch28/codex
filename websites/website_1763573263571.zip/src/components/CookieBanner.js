import React, { useEffect, useState } from 'react';

const STORAGE_KEY = 'lumina-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>
        We use cookies to personalize content, optimize performance, and analyze traffic. Read our{' '}
        <a href="/privacy">privacy policy</a>.
      </p>
      <button className="btn btn--small" onClick={acceptCookies}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;