import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="logo footer-logo">
            <span className="logo-mark">LP</span>
            <span className="logo-text">
              Lumina<span>Partners</span>
            </span>
          </div>
          <p>
            We partner with ambitious brands to architect resilient digital strategies that drive measurable growth and sustainable success.
          </p>
          <div className="footer-contact">
            <a href="mailto:hello@luminapartners.co">hello@luminapartners.co</a>
            <a href="tel:+1234567890">+1 (234) 567-890</a>
          </div>
        </div>

        <div>
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">About us</Link>
            </li>
            <li>
              <Link to="/services">Our services</Link>
            </li>
            <li>
              <Link to="/contact">Careers</Link>
            </li>
            <li>
              <Link to="/contact">Press</Link>
            </li>
          </ul>
        </div>

        <div>
          <h4>Resources</h4>
          <ul>
            <li>
              <Link to="/">Insights</Link>
            </li>
            <li>
              <Link to="/terms">Terms of service</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy policy</Link>
            </li>
            <li>
              <Link to="/contact">Support</Link>
            </li>
          </ul>
        </div>

        <div>
          <h4>Stay in the loop</h4>
          <p>Subscribe for curated insights, industry trends, and leadership resources.</p>
          <form
            className="newsletter-form"
            onSubmit={(e) => {
              e.preventDefault();
              e.target.reset();
            }}
          >
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input type="email" id="newsletter-email" name="email" placeholder="you@company.com" required />
            <button type="submit" className="btn btn--small">
              Subscribe
            </button>
          </form>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {year} Lumina Partners. All rights reserved.</p>
        <div className="footer-social">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            LinkedIn
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
            Twitter
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
            YouTube
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;