import React, { useEffect, useState } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'About', path: '/about' },
    { label: 'Services', path: '/services' },
    { label: 'Contact', path: '/contact' }
  ];

  return (
    <header className={`site-header ${scrolled ? 'site-header--scrolled' : ''}`}>
      <div className="container header-container">
        <Link to="/" className="logo" aria-label="Lumina Partners Home">
          <span className="logo-mark">LP</span>
          <span className="logo-text">
            Lumina<span>Partners</span>
          </span>
        </Link>

        <nav className={`nav ${menuOpen ? 'nav--open' : ''}`} aria-label="Primary navigation">
          <ul>
            {navLinks.map((link) => (
              <li key={link.path}>
                <NavLink
                  end={link.path === '/'}
                  to={link.path}
                  className={({ isActive }) => (isActive ? 'active' : undefined)}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
            <li className="nav-cta">
              <NavLink to="/contact" className="btn btn--small">
                Let’s Talk
              </NavLink>
            </li>
          </ul>
        </nav>

        <button
          className={`nav-toggle ${menuOpen ? 'nav-toggle--open' : ''}`}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;