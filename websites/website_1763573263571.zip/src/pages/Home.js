import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

const statsData = [
  { label: 'Revenue growth delivered', target: 38, suffix: '%', duration: 1800 },
  { label: 'Digital transformations completed', target: 120, suffix: '+', duration: 2200 },
  { label: 'Strategic partners worldwide', target: 35, suffix: '', duration: 1500 },
  { label: 'Client satisfaction score', target: 4.9, suffix: '/5', duration: 2000 }
];

const servicesData = [
  {
    title: 'Digital Strategy',
    description: 'Market intelligence, positioning, and long-term roadmaps anchored in measurable outcomes.',
    icon: '🧭'
  },
  {
    title: 'Experience Design',
    description: 'Human-centered design systems that create effortless customer journeys across every touchpoint.',
    icon: '🎨'
  },
  {
    title: 'Technology Enablement',
    description: 'Platform modernization, cloud migrations, and automation to power resilient operations.',
    icon: '🚀'
  },
  {
    title: 'Growth Acceleration',
    description: 'Campaign orchestration, revenue operations, and analytics for compounding growth.',
    icon: '📈'
  }
];

const processSteps = [
  {
    step: 'Discover',
    detail: 'Immersive research, stakeholder workshops, and data audits to uncover strategic opportunities.'
  },
  {
    step: 'Design',
    detail: 'Experience blueprints, north-star journeys, and solution architecture to align teams around the vision.'
  },
  {
    step: 'Build',
    detail: 'Agile implementation with rapid prototyping, quality sprints, and iterative optimization.'
  },
  {
    step: 'Scale',
    detail: 'Transformation governance, change enablement, and performance dashboards to sustain momentum.'
  }
];

const testimonialsData = [
  {
    quote:
      'Lumina Partners helped us reimagine our customer lifecycle. Within six months our retention jumped 27%. Their team felt like an extension of ours.',
    name: 'Danielle Carter',
    role: 'Chief Digital Officer, Horizon Bank',
    image: 'https://picsum.photos/200/200?random=12'
  },
  {
    quote:
      'A rare combination of strategic clarity and flawless execution. We launched on time globally and exceeded every KPI we set.',
    name: 'Marcus Lin',
    role: 'VP of Product, NovaTech',
    image: 'https://picsum.photos/200/200?random=13'
  },
  {
    quote:
      'From the first strategy sprint to the final enablement workshop, Lumina gave us confidence, momentum, and measurable results.',
    name: 'Priya Natarajan',
    role: 'Global Marketing Lead, Elevate Labs',
    image: 'https://picsum.photos/200/200?random=14'
  }
];

const teamData = [
  {
    name: 'Elena Ruiz',
    role: 'Managing Partner',
    image: 'https://picsum.photos/400/400?random=3',
    bio: 'Architects enterprise growth strategies informed by 15 years of digital transformation leadership.'
  },
  {
    name: 'Samuel Bishop',
    role: 'Chief Experience Officer',
    image: 'https://picsum.photos/400/400?random=31',
    bio: 'Design leader focused on inclusive experiences and measurable product-market fit.'
  },
  {
    name: 'Maya Chen',
    role: 'Head of Innovation',
    image: 'https://picsum.photos/400/400?random=32',
    bio: 'Accelerates technology adoption with a human-centered approach to change management.'
  }
];

const projectsData = [
  {
    id: 1,
    title: 'Global Banking Platform Reimagination',
    category: 'Strategy',
    description: 'Unified 12 regional experiences into a single scalable ecosystem with a 40% increase in cross-sell.',
    image: 'https://picsum.photos/1200/800?random=4'
  },
  {
    id: 2,
    title: 'Pharma Connected Care Portal',
    category: 'Experience',
    description: 'Designed a digital companion experience driving adherence and doubling monthly active engagement.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    id: 3,
    title: 'AI-Powered Retail Forecasting',
    category: 'Technology',
    description: 'Operationalized predictive analytics reducing inventory waste by $3.5M annually.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    id: 4,
    title: 'SaaS Demand Acceleration Engine',
    category: 'Growth',
    description: 'Implemented full-funnel automation increasing qualified pipeline velocity by 62%.',
    image: 'https://picsum.photos/1200/800?random=43'
  }
];

const faqData = [
  {
    question: 'How do you tailor engagements for different industries?',
    answer:
      'We combine sector-specific research with stakeholder interviews and data diagnostics to build bespoke transformation roadmaps aligned to your operating model and culture.'
  },
  {
    question: 'What does a typical partnership timeline look like?',
    answer:
      'Engagements begin with a 4-6 week discovery phase, followed by iterative design and implementation sprints. We establish success metrics and governance checkpoints from day one.'
  },
  {
    question: 'Do you work with in-house teams or manage everything end-to-end?',
    answer:
      'Both. We augment in-house capabilities with specialized expertise, co-create with internal teams, and can manage delivery end-to-end depending on your goals.'
  },
  {
    question: 'How do you measure success?',
    answer:
      'Success metrics are defined collaboratively — spanning operational efficiency, customer engagement, revenue impact, and experience quality. We create dashboards for visibility and iterate in real time.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Rebuilding Trust in Digital Experiences',
    excerpt:
      'As customer expectations evolve, trust becomes the currency of loyalty. Here is how leaders are redesigning journeys around transparency.',
    image: 'https://picsum.photos/800/600?random=2',
    date: 'June 20, 2024'
  },
  {
    id: 2,
    title: 'AI Governance: From Pilot to Scale',
    excerpt:
      'A framework for responsibly scaling intelligent automation without compromising compliance or customer empathy.',
    image: 'https://picsum.photos/800/600?random=21',
    date: 'May 30, 2024'
  },
  {
    id: 3,
    title: 'The Future of Connected Commerce',
    excerpt:
      'Omnichannel is now table stakes. We explore how integrated platforms unlock new value across the commerce ecosystem.',
    image: 'https://picsum.photos/800/600?random=22',
    date: 'May 08, 2024'
  }
];

const Home = () => {
  const [activeFilter, setActiveFilter] = useState('All');
  const [filteredProjects, setFilteredProjects] = useState(projectsData);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const statsRef = useRef(null);
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);

  const categories = useMemo(
    () => ['All', ...new Set(projectsData.map((project) => project.category))],
    []
  );

  useEffect(() => {
    if (activeFilter === 'All') {
      setFilteredProjects(projectsData);
    } else {
      setFilteredProjects(projectsData.filter((project) => project.category === activeFilter));
    }
  }, [activeFilter]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const sections = document.querySelectorAll('[data-animate]');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );

    sections.forEach((section) => observer.observe(section));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const node = statsRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsAnimated) {
            setStatsAnimated(true);
          }
        });
      },
      { threshold: 0.4 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [statsAnimated]);

  useEffect(() => {
    if (!statsAnimated) return;

    const start = performance.now();
    const durations = statsData.map((stat) => stat.duration);

    const animate = (timestamp) => {
      const progress = timestamp - start;
      const newCounts = statsData.map((stat, index) => {
        const percent = Math.min(progress / durations[index], 1);
        const value = stat.target * percent;
        return stat.suffix === '/5' ? Number(value.toFixed(1)) : Math.round(value);
      });
      setCounts(newCounts);

      if (progress < Math.max(...durations)) {
        requestAnimationFrame(animate);
      } else {
        setCounts(
          statsData.map((stat) => (stat.suffix === '/5' ? stat.target.toFixed(1) : stat.target))
        );
      }
    };

    const frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [statsAnimated]);

  return (
    <div className="home">
      <section
        className="hero"
        data-animate
        style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=1)' }}
      >
        <div className="container hero-content">
          <span className="hero-eyebrow">Strategic Digital Consultancy</span>
          <h1>
            Lead the market with deliberate digital transformation.
          </h1>
          <p>
            We empower trailblazing organizations to align strategy, design, and technology — accelerating growth with purpose, precision, and measurable impact.
          </p>
          <div className="hero-actions">
            <Link to="/contact" className="btn btn--primary btn--pulse">
              Book a discovery session
            </Link>
            <Link to="/services" className="btn btn--link">
              Explore our capabilities
            </Link>
          </div>
          <div className="hero-partners">
            <span>Trusted by leaders at</span>
            <div className="hero-partners-logos">
              <span>Atlas</span>
              <span>Echelon</span>
              <span>Vantage</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section stats" data-animate ref={statsRef}>
        <div className="container section-header">
          <h2>Proof in the numbers.</h2>
          <p>
            Outcome-driven engagements designed to unlock efficiency, strengthen relationships, and accelerate growth.
          </p>
        </div>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <article key={stat.label} className="stat-card">
              <h3>
                {counts[index]}
                <span>{stat.suffix}</span>
              </h3>
              <p>{stat.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section services" data-animate>
        <div className="container section-header">
          <h2>Services engineered for scale.</h2>
          <p>
            Integrated expertise spanning strategy, experience, technology, and revenue operations to transform your business end-to-end.
          </p>
        </div>
        <div className="container services-grid">
          {servicesData.map((service) => (
            <article key={service.title} className="service-card">
              <div className="service-icon" aria-hidden="true">
                {service.icon}
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-link">
                Discover more
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="section process" data-animate>
        <div className="container process-wrapper">
          <div className="section-header">
            <h2>
              A collaborative framework that converts vision into velocity.
            </h2>
            <p>
              Each engagement is choreographed to maintain clarity, momentum, and confidence with a transparent roadmap and embedded change enablement.
            </p>
          </div>
          <div className="process-steps">
            {processSteps.map((step, index) => (
              <article key={step.step} className="process-step">
                <span className="process-number">{index + 1}</span>
                <div>
                  <h3>{step.step}</h3>
                  <p>{step.detail}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section testimonials" data-animate>
        <div className="container section-header">
          <h2>What partners are saying.</h2>
          <p>Momentum built on trust, clarity, and the confidence to take bold action.</p>
        </div>
        <div className="container testimonial-carousel">
          {testimonialsData.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`testimonial-card ${index === testimonialIndex ? 'active' : ''}`}
            >
              <img
                src={testimonial.image}
                alt={`${testimonial.name} headshot`}
                loading="lazy"
              />
              <blockquote>“{testimonial.quote}”</blockquote>
              <p className="testimonial-name">{testimonial.name}</p>
              <span className="testimonial-role">{testimonial.role}</span>
            </article>
          ))}
          <div className="testimonial-dots" role="tablist">
            {testimonialsData.map((_, index) => (
              <button
                key={index}
                className={index === testimonialIndex ? 'active' : ''}
                onClick={() => setTestimonialIndex(index)}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section team" data-animate>
        <div className="container section-header">
          <h2>Meet the leadership guiding transformation.</h2>
          <p>
            Bringing together strategists, designers, engineers, and growth operators to deliver outcomes that compound over time.
          </p>
        </div>
        <div className="container team-grid">
          {teamData.map((member) => (
            <article key={member.name} className="team-card">
              <div className="team-image">
                <img src={member.image} alt={`${member.name} - ${member.role}`} loading="lazy" />
                <div className="team-overlay">
                  <p>{member.bio}</p>
                </div>
              </div>
              <div className="team-info">
                <h3>{member.name}</h3>
                <span>{member.role}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section projects" data-animate>
        <div className="container section-header">
          <h2>Selected engagements.</h2>
          <p>
            Cross-industry collaborations where ambition met clarity — unlocking sustainable advantage.
          </p>
        </div>
        <div className="container project-filter">
          <div className="filter-buttons" role="tablist" aria-label="Project categories">
            {categories.map((category) => (
              <button
                key={category}
                className={`filter-button ${activeFilter === category ? 'active' : ''}`}
                onClick={() => setActiveFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="project-grid">
            {filteredProjects.map((project) => (
              <article key={project.id} className="project-card">
                <div className="project-image">
                  <img
                    src={project.image}
                    alt={`${project.title} case study`}
                    loading="lazy"
                  />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/contact" className="project-link">
                    Request the full case study
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section faq" data-animate>
        <div className="container section-header">
          <h2>Frequently asked questions.</h2>
          <p>Transparency and alignment from the start of every partnership.</p>
        </div>
        <div className="container faq-accordion">
          {faqData.map((item, index) => (
            <details key={item.question}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="section blog" data-animate>
        <div className="container section-header">
          <h2>Latest insights.</h2>
          <p>Perspectives on the strategies, technologies, and experiences re-shaping industries.</p>
        </div>
        <div className="container blog-grid">
          {blogPosts.map((post) => (
            <article key={post.id} className="blog-card">
              <div className="blog-image">
                <img src={post.image} alt={`${post.title} article cover`} loading="lazy" />
              </div>
              <div className="blog-content">
                <span className="blog-date">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/contact" className="blog-link">
                  Talk to an advisor
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section cta" data-animate>
        <div className="container cta-content">
          <h2>Shape what’s next — today.</h2>
          <p>
            Let’s architect a roadmap that converts your ambition into measurable value. Our senior team will assemble a tailored point of view before our first working session.
          </p>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn--primary">
              Schedule a consultation
            </Link>
            <Link to="/about" className="btn btn--outline">
              Meet our team
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;