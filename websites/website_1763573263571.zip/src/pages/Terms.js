import React from 'react';

const Terms = () => {
  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container">
          <h1>Terms of Service</h1>
          <p>Effective as of May 1, 2024.</p>
        </div>
      </section>

      <section className="section legal-content">
        <div className="container">
          <h2>1. Introduction</h2>
          <p>
            These Terms of Service (“Terms”) govern your use of the Lumina Partners website, services, and any related content. By accessing or using our services you agree to be bound by these Terms.
          </p>

          <h2>2. Use of Services</h2>
          <p>
            You may use our services only for lawful purposes and in accordance with these Terms. You agree not to use our services in any way that violates any applicable federal, state, local, or international law or regulation.
          </p>

          <h2>3. Intellectual Property</h2>
          <p>
            All content, features, and functionality are owned by Lumina Partners and are protected by international copyright, trademark, and other proprietary rights laws.
          </p>

          <h2>4. Confidentiality</h2>
          <p>
            We maintain strict confidentiality of client data and expect the same level of discretion with any proprietary information we provide during engagements.
          </p>

          <h2>5. Limitation of Liability</h2>
          <p>
            In no event shall Lumina Partners be liable for any indirect, incidental, special, consequential, or punitive damages arising out of or related to your use of our services.
          </p>

          <h2>6. Governing Law</h2>
          <p>
            These Terms are governed by the laws of the State of California without regard to its conflict of law provisions.
          </p>

          <h2>7. Contact</h2>
          <p>
            For questions about these Terms, please contact us at <a href="mailto:legal@luminapartners.co">legal@luminapartners.co</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;