import React from 'react';

const About = () => {
  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <span className="hero-eyebrow">Our Story</span>
          <h1>Standing at the intersection of strategy, design, and technology.</h1>
          <p>
            Lumina Partners was founded to close the gap between bold vision and operational reality. We navigate complexity with clarity, helping modern organizations transform with intention and confidence.
          </p>
        </div>
      </section>

      <section className="section" data-animate>
        <div className="container two-column">
          <article>
            <h2>Our mission.</h2>
            <p>
              We empower leaders to orchestrate human-centered transformations that unlock resilient growth. Our team of strategists, designers, engineers, and change specialists align around measurable value and shared accountability.
            </p>
            <p>
              From discovery to enablement, we co-create adaptive frameworks that fuel momentum and embed capability across your organization.
            </p>
          </article>
          <article className="about-highlight">
            <h3>Values that guide us</h3>
            <ul className="checklist">
              <li>Clarity over complexity</li>
              <li>Momentum through partnership</li>
              <li>Integrity in every decision</li>
              <li>Inclusive solutions by design</li>
            </ul>
          </article>
        </div>
      </section>

      <section className="section about-metrics" data-animate>
        <div className="container section-header">
          <h2>Global impact, tailored engagements.</h2>
          <p>We operate across industries and geographies with a boutique approach and enterprise scale.</p>
        </div>
        <div className="container stats-grid">
          <article className="stat-card">
            <h3>15</h3>
            <p>Countries where clients have launched with Lumina</p>
          </article>
          <article className="stat-card">
            <h3>68%</h3>
            <p>Average reduction in time-to-market for new initiatives</p>
          </article>
          <article className="stat-card">
            <h3>4.8/5</h3>
            <p>Post-engagement leadership satisfaction score</p>
          </article>
          <article className="stat-card">
            <h3>250k+</h3>
            <p>Customers reached through redesigned experiences</p>
          </article>
        </div>
      </section>

      <section className="section about-team" data-animate>
        <div className="container section-header">
          <h2>Leadership team.</h2>
          <p>Seasoned operators, entrepreneurs, and strategists who have delivered transformation within Fortune 100 and high-growth startups alike.</p>
        </div>
        <div className="container team-grid">
          <article className="team-card">
            <div className="team-image">
              <img src="https://picsum.photos/400/400?random=33" alt="Dominic Hale - Chief Strategy Officer" loading="lazy" />
            </div>
            <div className="team-info">
              <h3>Dominic Hale</h3>
              <span>Chief Strategy Officer</span>
            </div>
          </article>
          <article className="team-card">
            <div className="team-image">
              <img src="https://picsum.photos/400/400?random=34" alt="Anika Desai - Director of Research" loading="lazy" />
            </div>
            <div className="team-info">
              <h3>Anika Desai</h3>
              <span>Director of Research</span>
            </div>
          </article>
          <article className="team-card">
            <div className="team-image">
              <img src="https://picsum.photos/400/400?random=35" alt="Julien Park - Head of Engineering" loading="lazy" />
            </div>
            <div className="team-info">
              <h3>Julien Park</h3>
              <span>Head of Engineering</span>
            </div>
          </article>
          <article className="team-card">
            <div className="team-image">
              <img src="https://picsum.photos/400/400?random=36" alt="Fatima Al-Hassan - Principal Consultant" loading="lazy" />
            </div>
            <div className="team-info">
              <h3>Fatima Al-Hassan</h3>
              <span>Principal Consultant</span>
            </div>
          </article>
        </div>
      </section>

      <section className="section about-timeline" data-animate>
        <div className="container section-header">
          <h2>Milestones of momentum.</h2>
        </div>
        <div className="container timeline">
          <article>
            <span className="timeline-year">2016</span>
            <p>Founded Lumina Partners to help organizations bridge the strategy-execution gap.</p>
          </article>
          <article>
            <span className="timeline-year">2018</span>
            <p>Expanded to EMEA, launching digital transformation programs for financial services and healthcare leaders.</p>
          </article>
          <article>
            <span className="timeline-year">2020</span>
            <p>Introduced our experience design studio and intelligent automation practice.</p>
          </article>
          <article>
            <span className="timeline-year">2023</span>
            <p>Recognized as a top boutique consultancy for experience-led innovation.</p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default About;