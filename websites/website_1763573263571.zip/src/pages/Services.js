import React from 'react';

const Services = () => {
  const capabilities = [
    {
      title: 'Insight & Strategy',
      description:
        'Market intelligence, customer research, and opportunity mapping to define north-star strategies backed by validated data.',
      deliverables: ['Growth strategy blueprint', 'Experience vision', 'Measurement framework', 'Innovation pipeline']
    },
    {
      title: 'Experience & Product',
      description:
        'Design systems, prototyping, and product optimisation to craft seamless experiences across web, mobile, and emerging platforms.',
      deliverables: ['Customer journey orchestration', 'Design system development', 'Prototyping & usability testing', 'Service design']
    },
    {
      title: 'Technology Enablement',
      description:
        'Modern architectures, automation, and platform integration ensuring scalability, security, and future-ready operations.',
      deliverables: ['Cloud migration', 'API strategy', 'AI + automation', 'Enterprise architecture']
    },
    {
      title: 'Revenue Operations',
      description:
        'Full-funnel alignment, campaign orchestration, and analytics to build repeatable growth engines tuned for velocity.',
      deliverables: ['Lifecycle marketing', 'Attribution modelling', 'Sales enablement', 'Analytics dashboards']
    }
  ];

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <span className="hero-eyebrow">Capabilities</span>
          <h1>Purpose-built services for ambitious teams.</h1>
          <p>
            Every engagement is designed to meet your organization where it is today — and build the momentum required for tomorrow. Our multidisciplinary teams align around your goals to accelerate outcomes.
          </p>
        </div>
      </section>

      <section className="section" data-animate>
        <div className="container service-list">
          {capabilities.map((capability) => (
            <article key={capability.title} className="service-detail">
              <div>
                <h2>{capability.title}</h2>
                <p>{capability.description}</p>
              </div>
              <div>
                <h4>Sample deliverables</h4>
                <ul>
                  {capability.deliverables.map((deliverable) => (
                    <li key={deliverable}>{deliverable}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section service-differentiators" data-animate>
        <div className="container two-column">
          <article>
            <h2>How we engage.</h2>
            <p>
              We build blended teams with your internal stakeholders to co-create solutions, accelerate capability transfer, and ensure sustainability long after launch.
            </p>
            <ul className="checklist">
              <li>Executive alignment and vision workshops</li>
              <li>Agile delivery with transparent governance</li>
              <li>Embedded change enablement and training</li>
              <li>Continuous optimization informed by insights</li>
            </ul>
          </article>
          <article>
            <h3>Engagement models</h3>
            <div className="engagement-cards">
              <div>
                <h4>Transformation Program</h4>
                <p>End-to-end partnership for reimagining products, services, and operations.</p>
              </div>
              <div>
                <h4>Strategic Sprint</h4>
                <p>Focused accelerator unlocking clarity in 4-6 weeks with a prioritized roadmap.</p>
              </div>
              <div>
                <h4>Capability Augmentation</h4>
                <p>Specialist teams embedded with yours to amplify delivery and knowledge transfer.</p>
              </div>
            </div>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Services;