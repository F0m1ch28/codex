import React from 'react';

const Privacy = () => {
  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Updated May 1, 2024.</p>
        </div>
      </section>

      <section className="section legal-content">
        <div className="container">
          <h2>1. Overview</h2>
          <p>
            This Privacy Policy explains how Lumina Partners (“we”, “us”, or “our”) collects, uses, and protects your personal information when you interact with our website and services.
          </p>

          <h2>2. Information We Collect</h2>
          <ul>
            <li>Contact information such as name, email address, and phone number.</li>
            <li>Company information including role, industry, and objectives.</li>
            <li>Usage data such as pages visited, engagement, and device information.</li>
          </ul>

          <h2>3. How We Use Information</h2>
          <p>We use collected information to:</p>
          <ul>
            <li>Respond to inquiries and provide requested services.</li>
            <li>Improve our website, offerings, and customer experience.</li>
            <li>Send relevant insights, updates, and marketing communications (with consent).</li>
            <li>Ensure compliance with legal and regulatory obligations.</li>
          </ul>

          <h2>4. Data Security</h2>
          <p>
            We implement technical and organizational safeguards to protect your data against unauthorized access, disclosure, alteration, or destruction.
          </p>

          <h2>5. Data Retention</h2>
          <p>
            We retain personal information for as long as necessary to fulfill the purposes outlined in this policy unless a longer retention period is required by law.
          </p>

          <h2>6. Your Rights</h2>
          <p>
            You may request access to, correction of, or deletion of your personal information. To exercise these rights, contact <a href="mailto:privacy@luminapartners.co">privacy@luminapartners.co</a>.
          </p>

          <h2>7. Changes</h2>
          <p>
            We may update this policy periodically. We will post the revised policy with an updated effective date when changes occur.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;