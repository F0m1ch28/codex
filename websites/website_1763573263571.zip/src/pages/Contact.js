import React, { useState } from 'react';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Please enter your full name.';
    if (!form.email.trim()) {
      newErrors.email = 'An email address is required.';
    } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!form.company.trim()) newErrors.company = 'Let us know where you work.';
    if (!form.message.trim()) newErrors.message = 'Share a brief overview of your goals.';
    return newErrors;
  };

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => ({ ...prev, [e.target.name]: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setForm(initialState);
  };

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <span className="hero-eyebrow">Let’s collaborate</span>
          <h1>We’d love to understand your next bold move.</h1>
          <p>
            Share your goals and we’ll assemble the right experts to explore how Lumina Partners can help accelerate your vision.
          </p>
        </div>
      </section>

      <section className="section contact-section" data-animate>
        <div className="container contact-grid">
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Full name</label>
              <input
                id="name"
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Alex Johnson"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="email">Business email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="alex@company.com"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                value={form.company}
                onChange={handleChange}
                placeholder="Company name"
                aria-invalid={Boolean(errors.company)}
              />
              {errors.company && <span className="form-error">{errors.company}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="message">How can we help?</label>
              <textarea
                id="message"
                name="message"
                rows="4"
                value={form.message}
                onChange={handleChange}
                placeholder="Tell us about your goals, timeline, and stakeholders."
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className="form-error">{errors.message}</span>}
            </div>

            <button type="submit" className="btn btn--primary">
              Submit inquiry
            </button>

            {submitted && (
              <p role="status" className="form-success">
                Thank you! Someone from Lumina Partners will reach out within 1 business day.
              </p>
            )}
          </form>

          <aside className="contact-info">
            <h2>Prefer a direct connection?</h2>
            <p>We’re available Monday–Friday from 8 a.m. to 6 p.m. ET.</p>
            <div className="contact-block">
              <h4>Email</h4>
              <a href="mailto:hello@luminapartners.co">hello@luminapartners.co</a>
            </div>
            <div className="contact-block">
              <h4>Phone</h4>
              <a href="tel:+1234567890">+1 (234) 567-890</a>
            </div>
            <div className="contact-block">
              <h4>HQ</h4>
              <p>1450 Market Street, Suite 2300<br />San Francisco, CA 94103</p>
            </div>
            <div className="contact-block">
              <h4>Office hours</h4>
              <p>Global team with presence in New York, London, and Singapore.</p>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
};

export default Contact;