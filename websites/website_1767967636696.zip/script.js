document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navLinks.classList.toggle("open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieChoice = localStorage.getItem("nph_cookie_choice");
    if (cookieBanner && !cookieChoice) {
        cookieBanner.classList.add("active");
    }
    const cookieButtons = document.querySelectorAll(".cookie-actions a");
    cookieButtons.forEach((button) => {
        button.addEventListener("click", (event) => {
            event.preventDefault();
            const choice = button.dataset.choice;
            localStorage.setItem("nph_cookie_choice", choice);
            if (cookieBanner) {
                cookieBanner.classList.remove("active");
            }
            window.open("cookies.html", "_blank", "noopener");
        });
    });

    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const requiredFields = contactForm.querySelectorAll("[required]");
            let valid = true;
            requiredFields.forEach((field) => {
                if (!field.value.trim()) {
                    valid = false;
                    field.classList.add("error");
                } else {
                    field.classList.remove("error");
                }
            });
            if (valid) {
                window.location.href = "thanks.html";
            }
        });
    }

    const subscribeForm = document.getElementById("subscribe-form");
    if (subscribeForm) {
        subscribeForm.addEventListener("submit", (event) => {
            event.preventDefault();
            window.location.href = "thanks.html";
        });
    }

    const postsList = document.getElementById("posts-list");
    if (postsList) {
        const postsData = [
            {
                title: "Modernizing Community Runways Across Nunavut",
                excerpt: "Insights from collaborative upgrades that strengthen vital air links supporting essential goods and emergency services.",
                category: "Delivery Models",
                date: "April 2, 2024",
                author: "Eliza Martens",
                image: "https://picsum.photos/600/400?random=201&gravity=north"
            },
            {
                title: "Adapting Procurement for Remote Health Facilities",
                excerpt: "Coordinating northern supplier networks to deliver resilient medical infrastructure in challenging climates.",
                category: "Procurement & Logistics",
                date: "March 27, 2024",
                author: "Isiah Cardinal",
                image: "https://picsum.photos/600/400?random=202&gravity=north"
            },
            {
                title: "Hydropower Upgrades in the Yukon River Basin",
                excerpt: "Engineering teams outline approaches to extend asset life while respecting environmental safeguards.",
                category: "Project Controls",
                date: "March 18, 2024",
                author: "Lucie Tremblay",
                image: "https://picsum.photos/600/400?random=203&gravity=north"
            },
            {
                title: "Seasonal Construction Windows in Northern Alberta",
                excerpt: "How delivery leaders plan work packages around daylight, ground conditions, and community schedules.",
                category: "Field Notes",
                date: "March 8, 2024",
                author: "Noah Lefebvre",
                image: "https://picsum.photos/600/400?random=204&gravity=north"
            },
            {
                title: "Data-Driven Corridor Planning in the Northwest Territories",
                excerpt: "Using geospatial platforms to align corridor visions with community priorities and ecological thresholds.",
                category: "Regional Planning",
                date: "February 28, 2024",
                author: "Danika Price",
                image: "https://picsum.photos/600/400?random=205&gravity=north"
            },
            {
                title: "Partnering With Indigenous Guardians on Project Monitoring",
                excerpt: "Shared observation protocols reinforce cultural stewardship while advancing infrastructure assurance.",
                category: "Project Controls",
                date: "February 19, 2024",
                author: "Aiden Morrissey",
                image: "https://picsum.photos/600/400?random=206&gravity=north"
            },
            {
                title: "Modular Housing Logistics for Arctic Educators",
                excerpt: "Transporting and assembling staff residences through coordinated sealift and winter road programs.",
                category: "Procurement & Logistics",
                date: "February 5, 2024",
                author: "Mira Chau",
                image: "https://picsum.photos/600/400?random=207&gravity=north"
            },
            {
                title: "Wind Monitoring Stations Above the Tree Line",
                excerpt: "Field crews share lessons on maintaining sensors through sustained gusts and icing.",
                category: "Field Notes",
                date: "January 26, 2024",
                author: "Paulo Bouchard",
                image: "https://picsum.photos/600/400?random=208&gravity=north"
            },
            {
                title: "Community Design Charrettes for Arctic Resilience",
                excerpt: "A step-by-step look at facilitated sessions integrating cultural design and permafrost research.",
                category: "Regional Planning",
                date: "January 12, 2024",
                author: "Hannah Greyeyes",
                image: "https://picsum.photos/600/400?random=209&gravity=north"
            },
            {
                title: "Bridge Inspections Along the Mackenzie Valley Highway",
                excerpt: "Tracking structural performance with drone-based sensing and on-site verification.",
                category: "Project Controls",
                date: "December 28, 2023",
                author: "Ravi Kohli",
                image: "https://picsum.photos/600/400?random=210&gravity=north"
            },
            {
                title: "Integrated Project Delivery in Northern Wastewater Upgrades",
                excerpt: "Stakeholders map transparent governance to deliver treatment upgrades before winter closure.",
                category: "Delivery Models",
                date: "December 14, 2023",
                author: "Isobel Howard",
                image: "https://picsum.photos/600/400?random=211&gravity=north"
            },
            {
                title: "Satellite Connectivity for Mobile Field Teams",
                excerpt: "Evaluating bandwidth needs for inspection crews operating in mountainous regions.",
                category: "Procurement & Logistics",
                date: "December 3, 2023",
                author: "Jules Moreau",
                image: "https://picsum.photos/600/400?random=212&gravity=north"
            }
        ];

        const postsPerPage = 6;
        let currentPage = 1;
        let activeCategory = "All";
        let searchTerm = "";

        const paginationContainer = document.getElementById("pagination");
        const filterButtons = document.querySelectorAll(".filters button[data-category]");
        const searchInput = document.getElementById("posts-search");

        function filterPosts() {
            return postsData.filter((post) => {
                const matchesCategory = activeCategory === "All" || post.category === activeCategory;
                const matchesSearch =
                    post.title.toLowerCase().includes(searchTerm) ||
                    post.excerpt.toLowerCase().includes(searchTerm);
                return matchesCategory && matchesSearch;
            });
        }

        function renderPosts() {
            const filtered = filterPosts();
            const totalPages = Math.max(1, Math.ceil(filtered.length / postsPerPage));
            if (currentPage > totalPages) currentPage = totalPages;
            const start = (currentPage - 1) * postsPerPage;
            const paginated = filtered.slice(start, start + postsPerPage);

            postsList.innerHTML = paginated
                .map((post) => {
                    return `
                    <article class="card">
                        <figure>
                            <img src="${post.image}" loading="lazy" alt="${post.title}">
                        </figure>
                        <div class="card-content">
                            <span class="badge">${post.category}</span>
                            <h3><a href="article.html">${post.title}</a></h3>
                            <p>${post.excerpt}</p>
                            <div class="metadata">
                                <span>${post.date}</span>
                                <span>By <strong>${post.author}</strong></span>
                            </div>
                        </div>
                    </article>`;
                })
                .join("");

            renderPagination(totalPages);
        }

        function renderPagination(totalPages) {
            if (!paginationContainer) return;
            paginationContainer.innerHTML = "";
            for (let i = 1; i <= totalPages; i++) {
                const button = document.createElement("button");
                button.textContent = i;
                if (i === currentPage) {
                    button.classList.add("active");
                }
                button.addEventListener("click", () => {
                    currentPage = i;
                    renderPosts();
                    window.scrollTo({ top: 0, behavior: "smooth" });
                });
                paginationContainer.appendChild(button);
            }
        }

        filterButtons.forEach((button) => {
            button.addEventListener("click", () => {
                filterButtons.forEach((btn) => btn.classList.remove("active"));
                button.classList.add("active");
                activeCategory = button.dataset.category;
                currentPage = 1;
                renderPosts();
            });
        });

        if (searchInput) {
            searchInput.addEventListener("input", (event) => {
                searchTerm = event.target.value.trim().toLowerCase();
                currentPage = 1;
                renderPosts();
            });
        }

        renderPosts();
    }
});