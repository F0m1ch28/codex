document.addEventListener('DOMContentLoaded', () => {
    const bars = document.querySelectorAll('.chart-bar');
    if (bars.length) {
        setTimeout(() => {
            bars.forEach(bar => {
                const value = parseInt(bar.dataset.value, 10) || 0;
                bar.style.width = `${Math.min(Math.max(value, 0), 100)}%`;
            });
        }, 150);
    }

    const banner = document.querySelector('.cookie-banner');
    const cookieKey = 'bicornydfx_cookie_choice';

    if (banner) {
        const storedChoice = localStorage.getItem(cookieKey);
        if (!storedChoice) {
            setTimeout(() => {
                banner.classList.add('visible');
            }, 600);
        }

        banner.addEventListener('click', (event) => {
            const target = event.target.closest('.cookie-action');
            if (target) {
                event.preventDefault();
                const choice = target.dataset.choice || 'undecided';
                localStorage.setItem(cookieKey, choice);
                banner.classList.remove('visible');
            }
        });
    }
});