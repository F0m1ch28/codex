document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    const scrollTopBtn = document.getElementById('scrollTop');
    const contactForm = document.getElementById('contactForm');
    const formFeedback = document.getElementById('formFeedback');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');

    // Navigation toggle
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 840) {
                    primaryNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    // Scroll to top button behaviour
    const toggleScrollTop = () => {
        if (window.scrollY > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    };

    window.addEventListener('scroll', toggleScrollTop);

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Contact form submission handling
    if (contactForm && formFeedback) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            formFeedback.textContent = `Thank you, ${name}. Our advisory team will connect with you shortly.`;
            contactForm.reset();
        });
    }

    // Cookie banner logic
    const consentKey = 'smCookieConsent';

    const hideCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove('show');
        }
    };

    const showCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add('show');
        }
    };

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            hideCookieBanner();
        });
    }

    if (localStorage.getItem(consentKey) === 'accepted') {
        hideCookieBanner();
    } else {
        showCookieBanner();
    }

    // Current year in footer
    const yearSpan = document.getElementById('currentYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});