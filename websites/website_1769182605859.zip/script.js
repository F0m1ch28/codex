document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      mainNav.classList.toggle('is-open');
      if (!expanded) {
        mainNav.querySelector('a')?.focus();
      }
    });

    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 780) {
          navToggle.setAttribute('aria-expanded', 'false');
          mainNav.classList.remove('is-open');
        }
      });
    });
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('[data-animate]').forEach(element => observer.observe(element));

  const cookieBanner = document.querySelector('.cookie-banner');
  const COOKIE_KEY = 'insightreport_cookie_preference';

  if (cookieBanner) {
    const stored = localStorage.getItem(COOKIE_KEY);
    if (!stored) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }
    cookieBanner.querySelectorAll('button[data-action]').forEach(button => {
      button.addEventListener('click', () => {
        const action = button.dataset.action;
        localStorage.setItem(COOKIE_KEY, action);
        cookieBanner.classList.remove('is-visible');
      });
    });
  }

  const toast = document.querySelector('.global-toast');

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 2200);
  }

  document.querySelectorAll('form[data-redirect]').forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const redirectTarget = form.dataset.redirect || 'thank-you.html';
      showToast('Mesajul a fost înregistrat. Veți fi redirecționat în scurt timp.');
      setTimeout(() => {
        window.location.href = redirectTarget;
      }, 1400);
    });
  });

  const currentYearEl = document.getElementById('current-year');
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }
});