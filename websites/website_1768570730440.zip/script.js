(function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('open')) {
                    navLinks.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const storageKey = 'axilepulqt_cookie_preference';

    if (cookieBanner && acceptBtn && declineBtn) {
        const savedPreference = localStorage.getItem(storageKey);
        if (!savedPreference) {
            cookieBanner.classList.add('is-visible');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'accepted');
            cookieBanner.classList.remove('is-visible');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'declined');
            cookieBanner.classList.remove('is-visible');
        });
    }
})();