import React, { useEffect, useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import DisclaimerModal from "./components/DisclaimerModal";

import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import Inflation from "./pages/Inflation";
import Course from "./pages/Course";
import Resources from "./pages/Resources";
import ThankYou from "./pages/ThankYou";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import CookiePolicy from "./pages/CookiePolicy";

function AppContent() {
  const location = useLocation();
  const [showDisclaimer, setShowDisclaimer] = useState(false);

  useEffect(() => {
    const hasSeenDisclaimer = localStorage.getItem("altorumbo_disclaimer");
    if (!hasSeenDisclaimer) {
      setShowDisclaimer(true);
    }
  }, []);

  const handleCloseDisclaimer = () => {
    localStorage.setItem("altorumbo_disclaimer", "true");
    setShowDisclaimer(false);
  };

  return (
    <>
      <Helmet>
        <html lang="en" />
        <title>Altorumbo | Data-Driven Learning on ARS Inflation & Personal Finance</title>
        <meta
          name="description"
          content="Altorumbo empowers Argentina with reliable ARS→USD inflation data, personal finance education, and responsible planning insights."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, economic trends, datos confiables"
        />
        <link rel="canonical" href={`https://www.altorumbo.com${location.pathname}`} />
        <link
          rel="alternate"
          href="https://www.altorumbo.com/"
          hrefLang="en"
        />
        <link
          rel="alternate"
          href="https://www.altorumbo.com/es"
          hrefLang="es-AR"
        />
      </Helmet>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/inflation" element={<Inflation />} />
          <Route path="/course" element={<Course />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
      <DisclaimerModal open={showDisclaimer} onClose={handleCloseDisclaimer} />
    </>
  );
}

function App() {
  return <AppContent />;
}

export default App;