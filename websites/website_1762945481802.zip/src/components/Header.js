import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.container}>
        <div className={styles.brand}>
          <div className={styles.logoCircle} aria-hidden="true">
            AR
          </div>
          <div>
            <span className={styles.brandName}>Altorumbo</span>
            <span className={styles.tagline}>
              Finanzas inteligentes para tu futuro
            </span>
          </div>
        </div>
        <button
          aria-label="Toggle navigation menu"
          className={`${styles.menuButton} ${isMenuOpen ? styles.open : ""}`}
          onClick={handleToggle}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ""}`}
          aria-label="Primary navigation"
        >
          <NavLink
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
            to="/"
          >
            Home
          </NavLink>
          <NavLink
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
            to="/inflation"
          >
            Inflation
          </NavLink>
          <NavLink
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
            to="/course"
          >
            Course
          </NavLink>
          <NavLink
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
            to="/resources"
          >
            Resources
          </NavLink>
          <NavLink
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
            to="/about"
          >
            About
          </NavLink>
          <NavLink
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
            to="/services"
          >
            Services
          </NavLink>
          <NavLink
            onClick={closeMenu}
            className={`${styles.contactLink} ${
              isMenuOpen ? styles.navOpen : ""
            }`}
            to="/contact"
            onClickCapture={closeMenu}
          >
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;