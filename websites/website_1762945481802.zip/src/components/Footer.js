import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.col}>
        <h3>Altorumbo</h3>
        <p>
          Datos confiables para tu presupuesto y Sabiduría financiera con
          tendencias, desarrollados para decisiones responsables, planes claros.
        </p>
        <p className={styles.disclaimer}>
          Plataforma educativa con datos esenciales, sin consejos financieros
          directos.
        </p>
      </div>
      <div className={styles.col}>
        <h4>Explore</h4>
        <ul className={styles.links}>
          <li>
            <Link to="/inflation">Inflation Tracker</Link>
          </li>
          <li>
            <Link to="/course">Course Overview</Link>
          </li>
          <li>
            <Link to="/resources">Resources</Link>
          </li>
          <li>
            <Link to="/services">Services</Link>
          </li>
        </ul>
      </div>
      <div className={styles.col}>
        <h4>Policies</h4>
        <ul className={styles.links}>
          <li>
            <Link to="/terms">Terms of Use</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
          <li>
            <a href="/sitemap.xml">Sitemap</a>
          </li>
        </ul>
      </div>
      <div className={styles.col}>
        <h4>Contact</h4>
        <ul className={styles.contactInfo}>
          <li>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</li>
          <li>
            <a href="tel:+541155551234">+54 11 5555-1234</a>
          </li>
          <li>info@altorumbo.com</li>
          <li className={styles.socials}>
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer">
              Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>&copy; {new Date().getFullYear()} Altorumbo. All rights reserved.</span>
    </div>
  </footer>
);

export default Footer;