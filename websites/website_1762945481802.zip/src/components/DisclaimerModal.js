import React from "react";
import styles from "./DisclaimerModal.module.css";

const DisclaimerModal = ({ open, onClose }) => {
  if (!open) return null;
  return (
    <div
      className={styles.overlay}
      role="dialog"
      aria-modal="true"
      aria-labelledby="disclaimer-title"
    >
      <div className={styles.modal}>
        <h3 id="disclaimer-title">Información importante</h3>
        <p>
          Мы не предоставляем финансовые услуги. Nuestra plataforma comparte
          análisis claros y datos de mercado para decisiones financieras seguras
          por cuenta propia. Información confiable que respalda tus elecciones
          responsables de dinero.
        </p>
        <button className={styles.button} onClick={onClose}>
          Entendido
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;