import React, { useEffect, useState } from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("altorumbo_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem("altorumbo_cookie_consent", value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h3>Cookies & Data Transparency</h3>
        <p>
          We use essential cookies to understand usage and improve experiences.
          Choose Accept to enable analytics or Decline to continue with
          necessary cookies only.
        </p>
        <div className={styles.actions}>
          <button
            className={styles.secondary}
            onClick={() => handleConsent("declined")}
          >
            Decline
          </button>
          <button
            className={styles.primary}
            onClick={() => handleConsent("accepted")}
          >
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;