import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const [values, setValues] = useState({
    name: "",
    email: "",
    confirmEmail: "",
    message: "",
    consent: false,
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("");

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setValues((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!values.name.trim()) newErrors.name = "Please enter your name.";
    if (!values.email.trim()) newErrors.email = "Email is required.";
    if (
      values.email &&
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
    ) {
      newErrors.email = "Invalid email format.";
    }
    if (!values.confirmEmail.trim()) newErrors.confirmEmail = "Confirm your email.";
    if (values.email !== values.confirmEmail) {
      newErrors.confirmEmail = "Emails must match.";
    }
    if (!values.message.trim())
      newErrors.message = "Tell us about your project.";
    if (!values.consent)
      newErrors.consent =
        "We need your approval to send the confirmation email (double opt-in).";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length > 0) return;
    setStatus("Sending...");
    setTimeout(() => {
      setStatus(
        "Thank you! Please check your inbox and confirm your email to complete the request."
      );
      setValues({
        name: "",
        email: "",
        confirmEmail: "",
        message: "",
        consent: false,
      });
    }, 1200);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contacto | Altorumbo en Buenos Aires</title>
        <meta
          name="description"
          content="Contacta a Altorumbo en Buenos Aires para conocer más sobre la plataforma educativa de inflación argentina y finanzas personales."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Contacta a nuestro equipo</h1>
          <p>
            Estamos en Av. 9 de Julio 1000, C1043 Buenos Aires. Agenda una
            conversación para conocer cómo apoyar tus objetivos educativos.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Datos de contacto</h2>
              <ul>
                <li>
                  <strong>Teléfono:</strong>{" "}
                  <a href="tel:+541155551234">+54 11 5555-1234</a>
                </li>
                <li>
                  <strong>Email:</strong> info@altorumbo.com
                </li>
                <li>
                  <strong>Dirección:</strong> Av. 9 de Julio 1000, C1043 Buenos
                  Aires, Argentina
                </li>
              </ul>
              <iframe
                title="Altorumbo office location"
                className={styles.map}
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.728495496589!2d-58.38159212351204!3d-34.60373477295516!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacce3814767%3A0x66f002988dc64c44!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1692800000000!5m2!1sen!2sar"
                loading="lazy"
              ></iframe>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Escríbenos</h2>
              <div className={styles.formGroup}>
                <label htmlFor="contact-name">Name</label>
                <input
                  id="contact-name"
                  name="name"
                  value={values.name}
                  onChange={handleChange}
                  aria-invalid={!!errors.name}
                  required
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  value={values.email}
                  onChange={handleChange}
                  aria-invalid={!!errors.email}
                  required
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="contact-confirmEmail">Confirm Email</label>
                <input
                  id="contact-confirmEmail"
                  name="confirmEmail"
                  type="email"
                  value={values.confirmEmail}
                  onChange={handleChange}
                  aria-invalid={!!errors.confirmEmail}
                  required
                />
                {errors.confirmEmail && (
                  <span className={styles.error}>{errors.confirmEmail}</span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="contact-message">Message</label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows="4"
                  value={values.message}
                  onChange={handleChange}
                  aria-invalid={!!errors.message}
                  required
                />
                {errors.message && (
                  <span className={styles.error}>{errors.message}</span>
                )}
              </div>
              <div className={styles.checkboxGroup}>
                <input
                  id="contact-consent"
                  name="consent"
                  type="checkbox"
                  checked={values.consent}
                  onChange={handleChange}
                  aria-invalid={!!errors.consent}
                  required
                />
                <label htmlFor="contact-consent">
                  I agree to receive a confirmation email and understand the
                  double opt-in requirement.
                </label>
              </div>
              {errors.consent && (
                <span className={styles.error}>{errors.consent}</span>
              )}
              <button type="submit" className={styles.submitButton}>
                Send message
              </button>
              {status && <p className={styles.status}>{status}</p>}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;