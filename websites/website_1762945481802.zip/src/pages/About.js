import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const teamMembers = [
  {
    name: "Sofía Altamirano",
    role: "Co-founder & Economic Research",
    bio: "Economista con 12 años de experiencia en análisis macro y modelado de inflación argentina.",
    image: "https://picsum.photos/seed/altorumbo-team1/400/400",
  },
  {
    name: "Lucas Romero",
    role: "Data Strategy Lead",
    bio: "Especialista en inteligencia de datos y construcción de pipelines para series temporales.",
    image: "https://picsum.photos/seed/altorumbo-team2/400/400",
  },
  {
    name: "Emily Carter",
    role: "Learning Experience Director",
    bio: "Diseña trayectorias educativas bilingües con foco en aprendizaje aplicado y accesible.",
    image: "https://picsum.photos/seed/altorumbo-team3/400/400",
  },
  {
    name: "Martina Quiroga",
    role: "Community & Partnerships",
    bio: "Conecta instituciones, emprendedores y familias para compartir mejores prácticas.",
    image: "https://picsum.photos/seed/altorumbo-team4/400/400",
  },
];

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About Altorumbo | Nuestra misión y equipo</title>
      <meta
        name="description"
        content="Conoce la misión, visión y equipo de Altorumbo. Transformamos datos económicos en educación responsable para Argentina."
      />
    </Helmet>

    <section className={styles.intro}>
      <div className="container">
        <div className={styles.introGrid}>
          <div>
            <h1>Transformar datos en sabiduría financiera colectiva</h1>
            <p>
              Altorumbo nace en Buenos Aires con la misión de brindar acceso a
              información confiable que respalda tus elecciones responsables de
              dinero. Creemos en la educación como herramienta para navegar
              contextos económicos complejos con serenidad.
            </p>
            <p>
              Cada herramienta que construimos parte de investigación profunda,
              ética de datos y accesibilidad. Nuestras experiencias combinan
              inglés y español, entendiendo las necesidades reales de hogares e
              instituciones argentinas.
            </p>
          </div>
          <div className={styles.introCard}>
            <h3>Principios de Altorumbo</h3>
            <ul>
              <li>Datos abiertos y verificables</li>
              <li>Transparencia total en metodologías</li>
              <li>Experiencias centradas en el usuario</li>
              <li>Compromiso con la accesibilidad WCAG AA</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Nuestros valores esenciales</h2>
          <p>La base que guía cada decisión, funcionalidad y pieza educativa.</p>
        </div>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Responsabilidad</h3>
            <p>
              Ofrecemos análisis claros y datos de mercado para decisiones
              financieras seguras, siempre dejando la acción final en manos del
              usuario.
            </p>
          </article>
          <article>
            <h3>Colaboración</h3>
            <p>
              Trabajamos junto a universidades, cámaras empresarias y ONGs para
              compartir mejores pasos hacia un mejor porvenir colectivo.
            </p>
          </article>
          <article>
            <h3>Innovación educativa</h3>
            <p>
              Construimos experiencias digitales que integran dashboards,
              simulaciones y aprendizaje social.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Equipo de liderazgo</h2>
          <p>
            Diversidad de disciplinas para diseñar una plataforma educativa con
            impacto tangible.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.avatar}>
                <img
                  src={member.image}
                  alt={`${member.name} - ${member.role}`}
                  loading="lazy"
                />
                <div className={styles.overlay}>
                  <span>Conecta</span>
                </div>
              </div>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default About;