import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Use | Altorumbo</title>
      <meta
        name="description"
        content="Review the terms of use for Altorumbo's educational platform and data services."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Terms of Use</h1>
        <p>
          Altorumbo provides educational content and data visualizations about
          inflation, ARS→USD and personal finance. We do not provide financial
          services or manage assets. By accessing our platform you agree to use
          the information responsibly and acknowledge that decisions are your
          own.
        </p>
        <h2>Accountability</h2>
        <p>
          Users are responsible for verifying data suitability for their
          context. We offer transparency in sources and methodologies but cannot
          guarantee uninterrupted availability.
        </p>
        <h2>Usage</h2>
        <p>
          Content is for personal or institutional educational use. Redistribution
          requires prior authorization. Please contact us for licensing options.
        </p>
      </div>
    </section>
  </div>
);

export default Terms;