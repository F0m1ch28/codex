import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Inflation.module.css";

const faq = [
  {
    q: "¿Qué fuentes usamos para el CPI?",
    a: "INDEC, BCRA, Ministerio de Economía, relevamientos provinciales y series de organismos multilaterales. Todas las fuentes se citan en los reportes descargables.",
  },
  {
    q: "¿Cada cuánto actualizamos los datos?",
    a: "Publicamos actualizaciones semanales y cortes especiales cuando la volatilidad supera umbrales definidos.",
  },
  {
    q: "¿Se puede integrar el API?",
    a: "Sí, ofrecemos endpoints REST con autenticación para instituciones educativas y empresas. Incluye documentación en inglés y español.",
  },
];

const Inflation = () => {
  const [open, setOpen] = useState(null);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Seguimiento de inflación y ARS→USD | Metodología Altorumbo</title>
        <meta
          name="description"
          content="Conoce la metodología, fuentes y visualizaciones de Altorumbo para seguir la inflación argentina, CPI y tipo de cambio ARS→USD."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Metodología ARS→USD y CPI</h1>
          <p>
            Transparencia total: documentamos cómo recopilamos, limpiamos y
            presentamos los datos. Este enfoque asegura que tomes decisiones
            informadas con responsabilidad.
          </p>
        </div>
      </section>

      <section className={styles.methodology}>
        <div className="container">
          <div className={styles.grid}>
            <article>
              <h2>Fuentes primarias</h2>
              <p>
                Recolectamos información del BCRA, INDEC, mercados financieros y
                proveedores de FX alternativos con series históricas de al menos
                5 años.
              </p>
              <ul>
                <li>Verificación cruzada automática cada 30 minutos.</li>
                <li>Alertas educativas cuando las variaciones superan 2σ.</li>
                <li>Archivo histórico disponible en formatos CSV y JSON.</li>
              </ul>
            </article>
            <article>
              <h2>Modelos de agregación</h2>
              <p>
                Empleamos técnicas de smoothing y promedio ponderado para
                estimar valores intradiarios. Los modelos se recalibran mensualmente.
              </p>
              <div className={styles.chart} role="img" aria-label="Aggregation methodology diagram">
                <svg viewBox="0 0 320 160">
                  <circle cx="80" cy="80" r="60" fill="#cbd5f5" />
                  <circle cx="160" cy="80" r="60" fill="#93c5fd" />
                  <circle cx="240" cy="80" r="60" fill="#60a5fa" />
                </svg>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <h2>Preguntas comunes</h2>
          <div className={styles.accordion}>
            {faq.map((item, index) => (
              <div key={item.q} className={styles.accordionItem}>
                <button
                  onClick={() => setOpen(open === index ? null : index)}
                  aria-expanded={open === index}
                >
                  {item.q}
                  <span>{open === index ? "−" : "+"}</span>
                </button>
                {open === index && <p>{item.a}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Inflation;