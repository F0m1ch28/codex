import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Resources.module.css";

const resources = [
  {
    id: 1,
    title: "Glosario bilingüe de inflación y finanzas personales",
    language: "EN & ES",
    description:
      "Definiciones claras de términos macro y financieros en inglés y español rioplatense.",
    link: "#",
  },
  {
    id: 2,
    title: "Guía para leer indicadores del BCRA",
    language: "Spanish",
    description:
      "Aprende a interpretar comunicados, tasas y series históricas del Banco Central.",
    link: "#",
  },
  {
    id: 3,
    title: "Budgeting toolkit for Argentine households",
    language: "English",
    description:
      "Plantillas y recomendaciones educativas para planificar gastos en contextos volátiles.",
    link: "#",
  },
];

const Resources = () => {
  const [languageFilter, setLanguageFilter] = useState("All");

  const filtered = resources.filter((item) =>
    languageFilter === "All" ? true : item.language.includes(languageFilter)
  );

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Recursos | Artículos y glosarios Altorumbo</title>
        <meta
          name="description"
          content="Accede a artículos, glosarios bilingües y herramientas de budgeting para Argentina. Recursos educativos confiables de Altorumbo."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Recursos educativos</h1>
          <p>
            Información confiable que respalda tus elecciones responsables de
            dinero. Explora artículos y guías en inglés y español.
          </p>
        </div>
      </section>

      <section className={styles.filter}>
        <div className="container">
          <div className={styles.filterGroup} role="radiogroup" aria-label="Filter resources by language">
            {["All", "English", "Spanish", "EN & ES"].map((lang) => (
              <button
                key={lang}
                className={`${styles.filterButton} ${
                  languageFilter === lang ? styles.active : ""
                }`}
                onClick={() => setLanguageFilter(lang)}
                role="radio"
                aria-checked={languageFilter === lang}
              >
                {lang}
              </button>
            ))}
          </div>
          <div className={styles.resourceGrid}>
            {filtered.map((item) => (
              <article key={item.id} className={styles.card}>
                <h3>{item.title}</h3>
                <span className={styles.badge}>{item.language}</span>
                <p>{item.description}</p>
                <a className={styles.link} href={item.link}>
                  Descargar recurso
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Resources;