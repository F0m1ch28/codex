import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const serviceItems = [
  {
    title: "Dashboards de inflación y FX",
    description:
      "Monitoreo integral de inflación, tasas, FX oficial y alternativo con alertas educativas configurables.",
  },
  {
    title: "Simuladores de presupuesto",
    description:
      "Herramientas interactivas en inglés y español para proyectar gastos, ingresos y objetivos.",
  },
  {
    title: "Workshops corporativos",
    description:
      "Sesiones personalizadas para equipos que necesitan interpretar datos macro y comunicar escenarios.",
  },
  {
    title: "Laboratorios académicos",
    description:
      "Kits con datasets, guías y ejercicios para universidades y centros de investigación.",
  },
];

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Servicios | Altorumbo plataformas y acompañamiento</title>
      <meta
        name="description"
        content="Descubre los servicios educativos de Altorumbo: dashboards de inflación, simuladores, workshops corporativos y laboratorios académicos."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Servicios y soluciones educativas</h1>
        <p>
          Diseñamos experiencias modulares para instituciones, empresas y
          familias que buscan acompañamiento basado en datos. La información se
          entrega con transparencia y éticas responsables.
        </p>
      </div>
    </section>

    <section className={styles.serviceCards}>
      <div className="container">
        <div className={styles.grid}>
          {serviceItems.map((service) => (
            <article key={service.title} className={styles.card}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.callout}>
      <div className="container">
        <div className={styles.calloutBox}>
          <h2>Consultoría educativa responsable</h2>
          <p>
            Información confiable que respalda tus elecciones responsables de
            dinero. Brindamos acompañamiento metodológico y transferencia de
            conocimiento sin gestionar activos ni prometer resultados.
          </p>
          <a className={styles.button} href="/contact">
            Solicitar propuesta
          </a>
        </div>
      </div>
    </section>
  </div>
);

export default Services;