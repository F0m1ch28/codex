import React from "react";
import { useLocation, Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./ThankYou.module.css";

const ThankYou = () => {
  const location = useLocation();
  const { state } = location;
  const name = state?.name || "Friend";

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Gracias | Confirmación pendiente</title>
        <meta
          name="description"
          content="Gracias por contactar a Altorumbo. Revisa tu correo para completar el doble opt-in y activar tu solicitud."
        />
      </Helmet>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.card}>
            <h1>Gracias, {name}.</h1>
            <p>
              Hemos enviado un correo de confirmación. Para completar tu
              solicitud, por favor sigue el enlace en ese correo (double opt-in).
              Si no lo encuentras, revisa tu carpeta de spam o comunícate con
              nosotros por teléfono.
            </p>
            <Link to="/" className={styles.button}>
              Volver a la página principal
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ThankYou;