import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | Altorumbo</title>
      <meta
        name="description"
        content="Read Altorumbo's cookie policy and learn about cookie preferences and data usage."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>
          Utilizamos cookies esenciales para mantener sesiones y cookies
          analíticas opcionales. El banner de consentimiento permite aceptar o
          rechazar la recopilación estadística.
        </p>
        <h2>Tipos de cookies</h2>
        <ul>
          <li>Esenciales: autenticación y seguridad.</li>
          <li>Analíticas (opt-in): métricas anónimas de uso.</li>
        </ul>
      </div>
    </section>
  </div>
);

export default CookiePolicy;