import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const statsData = [
  { label: "Market Indicators Tracked", value: 48 },
  { label: "Learner Community Insights", value: 1200 },
  { label: "Weekly Data Updates", value: 24 },
  { label: "Interactive Lessons", value: 36 },
];

const keyPromises = [
  {
    title: "Datos confiables para tu presupuesto",
    description:
      "Seguimos la dinámica ARS→USD, inflation CPI y liquidez para brindar un panorama claro sosteniendo decisiones responsables, planes claros.",
  },
  {
    title: "Sigue tendencias, detecta oportunidades",
    description:
      "Sabiduría financiera con tendencias detectadas en series temporales, escenarios comparativos y dashboards interactivos.",
  },
  {
    title: "De la información al conocimiento",
    description:
      "De la información al conocimiento: crece tu sabiduría financiera paso a paso con contenidos accesibles y tareas prácticas guiadas.",
  },
];

const testimonials = [
  {
    name: "Carla Méndez",
    role: "Planificadora independiente",
    quote:
      "El seguimiento diario de ARS→USD y los módulos mixtos en inglés y español me ayudaron a anticipar ajustes de presupuesto sin perder control.",
  },
  {
    name: "Matías Rodríguez",
    role: "Consultor económico",
    quote:
      "La plataforma ofrece análisis claros y datos de mercado para decisiones financieras seguras, manteniendo la responsabilidad final en el usuario.",
  },
  {
    name: "Lucía Herrera",
    role: "Emprendedora en Buenos Aires",
    quote:
      "Mejor visibilidad del flujo de caja y riesgos cambiarios. Las simulaciones permiten mejores pasos, mejor porvenir para mi negocio.",
  },
];

const processSteps = [
  {
    step: "01",
    title: "Descubre indicadores clave",
    text: "Explora dashboards interactivos con FX, CPI y tasas reales para entender el contexto actual.",
  },
  {
    step: "02",
    title: "Construye tu plan",
    text: "Utiliza plantillas responsables para armar presupuestos mensuales, objetivos y fondos de inversión personal.",
  },
  {
    step: "03",
    title: "Simula escenarios",
    text: "Corre simulaciones ARS→USD bajo distintos supuestos y analiza riesgos en tres niveles de impacto.",
  },
  {
    step: "04",
    title: "Monitorea el progreso",
    text: "Configura alertas educativas y revisa tus avances con check-ins semanales dentro de la comunidad.",
  },
];

const faqItems = [
  {
    question: "¿Qué incluye el seguimiento ARS→USD?",
    answer:
      "Incluye cotizaciones oficiales, mercados paralelos relevantes, contexto de tasas de interés y proyecciones basadas en datos públicos.",
  },
  {
    question: "¿La plataforma da asesoría financiera personalizada?",
    answer:
      "No. Altorumbo es una plataforma educativa con datos esenciales, sin consejos financieros directos. Ofrecemos marcos analíticos para que tomes decisiones informadas.",
  },
  {
    question: "¿Qué es el doble opt-in en los formularios?",
    answer:
      "Al completar un formulario, recibirás un correo para confirmar tu solicitud. Sólo después de confirmar podremos activar tu acceso o contacto.",
  },
  {
    question: "¿En qué idiomas está el contenido?",
    answer:
      "Nuestro contenido principal está en inglés, con módulos clave en español rioplatense para apoyar a quienes prefieren ese idioma.",
  },
];

const blogPosts = [
  {
    id: 1,
    title: "5 señales macro que afectan el tipo de cambio argentino",
    summary:
      "Analizamos perspectivas fiscales, expectativas inflacionarias y comportamiento de reservas, traducidos a acciones educativas.",
    date: "Aug 21, 2024",
  },
  {
    id: 2,
    title: "Checklist mensual de presupuesto para hogares argentinos",
    summary:
      "Guía paso a paso para seguir gastos esenciales, amortiguadores y reservas en un contexto de precios cambiantes.",
    date: "Aug 9, 2024",
  },
  {
    id: 3,
    title: "Comparativo histórico de inflación regional",
    summary:
      "Estudio sobre Argentina frente a LATAM con datos oficiales y lecciones prácticas para interpretar la volatilidad.",
    date: "Jul 27, 2024",
  },
];

const projectData = [
  {
    id: "fx",
    category: "FX",
    title: "Seguimiento intradiario ARS→USD",
    description:
      "Dashboard con promedios ponderados, brechas y sensibilidad histórica de 7 días.",
    image: "https://picsum.photos/seed/altoru-fx/1200/800",
  },
  {
    id: "budget",
    category: "Budgeting",
    title: "Plantilla de presupuesto responsivo",
    description:
      "Modelo interactivo con categorías flexibles y alertas educativas de gasto.",
    image: "https://picsum.photos/seed/altoru-budget/1200/800",
  },
  {
    id: "education",
    category: "Education",
    title: "Laboratorio de escenarios CPI",
    description:
      "Simulador CPI por rubros con tasas oficiales y supuestos personalizables.",
    image: "https://picsum.photos/seed/altoru-edu/1200/800",
  },
  {
    id: "fx",
    category: "FX",
    title: "Reportes semanales FX & commodities",
    description:
      "Resumen en inglés y español con implicancias educativas y gráficas.",
    image: "https://picsum.photos/seed/altoru-report/1200/800",
  },
];

const Home = () => {
  const navigate = useNavigate();
  const [rate, setRate] = useState(null);
  const [rateError, setRateError] = useState("");
  const [lastUpdated, setLastUpdated] = useState(null);
  const [loadingRate, setLoadingRate] = useState(false);
  const [trackerTrend, setTrackerTrend] = useState([]);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("All");

  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    confirmEmail: "",
    goal: "",
    consent: false,
  });
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const countersRef = useRef(null);
  const [startCount, setStartCount] = useState(false);

  const fetchRate = useCallback(async () => {
    setLoadingRate(true);
    setRateError("");
    try {
      const response = await fetch(
        "https://api.exchangerate.host/latest?base=ARS&symbols=USD"
      );
      if (!response.ok) {
        throw new Error("Network error");
      }
      const data = await response.json();
      const newRate = data?.rates?.USD;
      if (newRate) {
        setRate(newRate);
        setLastUpdated(new Date().toLocaleString());
        setTrackerTrend((prev) => {
          const updated = [...prev, Number(newRate)];
          return updated.slice(-10);
        });
      }
    } catch (error) {
      setRateError("Unable to refresh ARS→USD data. Showing last saved value.");
    } finally {
      setLoadingRate(false);
    }
  }, []);

  useEffect(() => {
    fetchRate();
    const interval = setInterval(fetchRate, 60000);
    return () => clearInterval(interval);
  }, [fetchRate]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStartCount(true);
          }
        });
      },
      { threshold: 0.4 }
    );
    if (countersRef.current) observer.observe(countersRef.current);
    return () => {
      if (countersRef.current) observer.unobserve(countersRef.current);
    };
  }, []);

  useEffect(() => {
    const testimonialTimer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(testimonialTimer);
  }, []);

  const animatedStats = useMemo(() => {
    if (!startCount) {
      return statsData.map((stat) => ({ ...stat, animatedValue: 0 }));
    }
    return statsData.map((stat) => ({ ...stat, animatedValue: stat.value }));
  }, [startCount]);

  const filteredProjects =
    selectedCategory === "All"
      ? projectData
      : projectData.filter((project) => project.category === selectedCategory);

  const handleInputChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormValues((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formValues.name.trim()) errors.name = "Name is required.";
    if (!formValues.email.trim()) errors.email = "Email is required.";
    if (
      formValues.email &&
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formValues.email)
    ) {
      errors.email = "Enter a valid email address.";
    }
    if (!formValues.confirmEmail.trim())
      errors.confirmEmail = "Please confirm your email.";
    if (
      formValues.email &&
      formValues.confirmEmail &&
      formValues.email !== formValues.confirmEmail
    ) {
      errors.confirmEmail = "Emails do not match.";
    }
    if (!formValues.goal.trim()) errors.goal = "Tell us about your goal.";
    if (!formValues.consent)
      errors.consent = "Please confirm you agree to the double opt-in process.";
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validateForm();
    setFormErrors(errors);
    if (Object.keys(errors).length > 0) return;
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      navigate("/thank-you", {
        state: { name: formValues.name, email: formValues.email },
      });
    }, 1200);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>
          Altorumbo | Argentina ARS→USD Tracker & Personal Finance Learning Hub
        </title>
        <meta
          name="description"
          content="Track Argentina ARS→USD fluctuations, master personal finance skills, and access reliable inflation data with Altorumbo’s educational SaaS."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={styles.heroOverlay} aria-hidden="true" />
        <div className={styles.heroContent}>
          <div className={styles.heroText}>
            <span className={styles.heroKicker}>
              Datos confiables. Insights en tiempo real.
            </span>
            <h1 id="hero-title">
              Finanzas inteligentes para tu futuro en Argentina
            </h1>
            <p>
              Plataforma educativa con datos esenciales sobre la inflación
              argentina. Analizamos ARS→USD, CPI y tendencias macro para ayudar
              a crear planes responsables sin promesas irreales.
            </p>
            <div className={styles.heroActions}>
              <button
                className={`${styles.cta} ${styles.ctaPrimary}`}
                onClick={() => document.getElementById("trial-form").scrollIntoView({ behavior: "smooth" })}
              >
                Solicitar prueba gratuita
              </button>
              <button
                className={`${styles.cta} ${styles.ctaSecondary}`}
                onClick={() => navigate("/inflation")}
              >
                Ver seguimiento ARS→USD
              </button>
            </div>
          </div>
          <div className={styles.heroVisual} role="presentation">
            <div className={styles.flagBackground} />
            <img
              src="https://picsum.photos/seed/altorumbo-hero/1600/900"
              alt="Professional data team collaborating on financial dashboards"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.promiseSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Decisiones responsables, planes claros</h2>
            <p>
              Mejores pasos, mejor porvenir: combina analítica y educación para
              navegar escenarios económicos complejos.
            </p>
          </div>
          <div className={styles.promiseGrid}>
            {keyPromises.map((item) => (
              <article key={item.title} className={styles.promiseCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Key achievements">
        <div className="container">
          <div className={styles.statsGrid} ref={countersRef}>
            {animatedStats.map((stat) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {startCount ? (
                    <AnimatedCounter target={stat.value} />
                  ) : (
                    "0"
                  )}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.trackerSection}>
        <div className="container">
          <div className={styles.trackerGrid}>
            <div>
              <h2>Seguimiento ARS→USD en tiempo real</h2>
              <p>
                Actualizaciones al minuto para visualizar volatilidad, brechas y
                promedios ponderados. Utiliza el tracker para alimentar tus
                simulaciones y mantener un presupuesto adaptativo.
              </p>
              <ul className={styles.trackerHighlights}>
                <li>Fuente: ExchangeRate Host + datos públicos del BCRA.</li>
                <li>
                  Descarga CSV y conecta el API con tus modelos (disponible para
                  planes educativos avanzados).
                </li>
                <li>
                  Visualiza curva histórica y zonas de alerta diseñadas para
                  análisis responsables.
                </li>
              </ul>
              <button
                className={`${styles.cta} ${styles.ctaPrimary}`}
                onClick={() => navigate("/inflation")}
              >
                Explorar metodología completa
              </button>
            </div>
            <div className={styles.trackerWidget} aria-live="polite">
              <div className={styles.trackerHeader}>
                <h3>Tipo de cambio ARS→USD</h3>
                <span className={styles.trackerBadge}>Actualizado</span>
              </div>
              <div className={styles.rateDisplay}>
                <span className={styles.rateValue}>
                  {rate ? rate.toFixed(6) : "--"}
                </span>
                <span className={styles.rateLabel}>1 ARS equivale a</span>
              </div>
              {rateError && <p className={styles.trackerError}>{rateError}</p>}
              <div className={styles.trendChart} role="img" aria-label="Recent ARS to USD trend line">
                <svg width="100%" height="120" viewBox="0 0 300 120">
                  <polyline
                    fill="none"
                    stroke="#2563EB"
                    strokeWidth="3"
                    points={trackerTrend
                      .map((value, index) => {
                        const x = (index / Math.max(trackerTrend.length - 1, 1)) * 300;
                        const y = 100 - (value / Math.max(...trackerTrend, 1)) * 80;
                        return `${x},${y}`;
                      })
                      .join(" ")}
                  />
                </svg>
              </div>
              <div className={styles.trackerMeta}>
                <span>
                  Última actualización:{" "}
                  {lastUpdated ? lastUpdated : "Buscando datos..."}
                </span>
                <button
                  className={styles.refreshButton}
                  onClick={fetchRate}
                  disabled={loadingRate}
                >
                  {loadingRate ? "Actualizando..." : "Actualizar ahora"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.insightSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Insights estructurados para analizar tendencias</h2>
            <p>
              Analiza inflación mensual, expectativas basadas en encuestas y
              escenarios de tipo de cambio con visualizaciones claras.
            </p>
          </div>
          <div className={styles.insightGrid}>
            <div className={styles.insightCard}>
              <h3>Inflación interanual CPI</h3>
              <p>
                Compara evolución CPI de Argentina con promedios LATAM y
                identifica meses críticos para el bolsillo.
              </p>
              <div className={styles.chartContainer} role="img" aria-label="Interannual CPI comparison chart">
                <svg viewBox="0 0 320 160">
                  <g strokeWidth="1.5" fill="none">
                    <polyline
                      points="10,140 70,90 130,70 190,60 250,50 310,45"
                      stroke="#2563EB"
                    />
                    <polyline
                      points="10,120 70,100 130,95 190,90 250,92 310,88"
                      stroke="#94a3b8"
                    />
                  </g>
                </svg>
              </div>
            </div>
            <div className={styles.insightCard}>
              <h3>Brecha de mercado oficial vs. paralelo</h3>
              <p>
                Seguimiento diario con bandas de riesgo para observar turnos
                abruptos y actuar con previsión educativa.
              </p>
              <div className={styles.chartContainer} role="img" aria-label="Spread chart between official and parallel market">
                <svg viewBox="0 0 320 160">
                  <rect x="20" y="30" width="60" height="90" fill="#1F3A6F" opacity="0.8" />
                  <rect x="120" y="50" width="60" height="70" fill="#2563EB" opacity="0.8" />
                  <rect x="220" y="40" width="60" height="80" fill="#60a5fa" opacity="0.8" />
                </svg>
              </div>
            </div>
            <div className={styles.insightCard}>
              <h3>Escenarios de tasa real ex ante</h3>
              <p>
                Modela escenarios conservador, base y acelerado para prever
                impacto sobre tu plan de gastos.
              </p>
              <div className={styles.chartContainer} role="img" aria-label="Scenario comparison chart">
                <svg viewBox="0 0 320 160">
                  <path
                    d="M10 140 Q80 100 140 90 T310 80"
                    stroke="#2563EB"
                    strokeWidth="3"
                    fill="none"
                  />
                  <path
                    d="M10 140 Q80 110 140 105 T310 100"
                    stroke="#38bdf8"
                    strokeWidth="3"
                    fill="none"
                  />
                  <path
                    d="M10 140 Q80 120 140 125 T310 120"
                    stroke="#cbd5f5"
                    strokeWidth="3"
                    fill="none"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.courseSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Course Overview</h2>
            <p>
              Aprende a interpretar datos macro, crear presupuestos resilientes
              y evaluar riesgos cambiarios con módulos bilingües.
            </p>
          </div>
          <div className={styles.courseGrid}>
            <div className={styles.courseCard}>
              <span className={styles.courseBadge}>Module 1</span>
              <h3>Contexto macro argentino</h3>
              <p>
                Historia de la inflación, drivers principales y lectura de
                indicadores oficiales vs. alternativos.
              </p>
            </div>
            <div className={styles.courseCard}>
              <span className={styles.courseBadge}>Module 2</span>
              <h3>Presupuesto personal adaptativo</h3>
              <p>
                Diseña un plan flexible con buffers educativos, objetivos
                realistas y revisión mensual basada en datos.
              </p>
            </div>
            <div className={styles.courseCard}>
              <span className={styles.courseBadge}>Module 3</span>
              <h3>Gestión del riesgo cambiario</h3>
              <p>
                Construye escenarios, interpreta volatilidad y alinea tus metas
                con alertas responsables.
              </p>
            </div>
            <div className={styles.courseCard}>
              <span className={styles.courseBadge}>Module 4</span>
              <h3>Comunidades y accountability</h3>
              <p>
                Crea rutinas de seguimiento con la comunidad y comparte
                aprendizajes bilingües.
              </p>
            </div>
          </div>
          <button
            className={`${styles.cta} ${styles.ctaPrimary}`}
            onClick={() => navigate("/course")}
          >
            Ver detalle del curso
          </button>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Cómo Altorumbo impulsa mejores decisiones</h2>
            <p>
              Nuestro proceso combina data, educación y herramientas prácticas
              para transformaciones sostenibles.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.step} className={styles.processCard}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <div>
              <h2>Portfolio de herramientas y dashboards</h2>
              <p>
                Soluciones diseñadas para convertir datos complejos en insights
                accionables y responsables.
              </p>
            </div>
            <div className={styles.filterGroup} role="radiogroup" aria-label="Filter projects by category">
              {["All", "FX", "Budgeting", "Education"].map((category) => (
                <button
                  key={category}
                  className={`${styles.filterButton} ${
                    selectedCategory === category ? styles.filterActive : ""
                  }`}
                  onClick={() => setSelectedCategory(category)}
                  role="radio"
                  aria-checked={selectedCategory === category}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={project.image}
                    alt={`Project showcase: ${project.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectTag}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Historias de aprendizaje responsable</h2>
            <p>
              Usuarios profesionales y familias comparten cómo usan Altorumbo
              como brújula educativa.
            </p>
          </div>
          <div className={styles.testimonialCarousel}>
            <div className={styles.testimonialTrack}>
              {testimonials.map((testimonial, index) => (
                <article
                  key={testimonial.name}
                  className={`${styles.testimonialCard} ${
                    index === currentTestimonial ? styles.testimonialActive : ""
                  }`}
                  aria-hidden={index !== currentTestimonial}
                >
                  <p className={styles.testimonialQuote}>
                    “{testimonial.quote}”
                  </p>
                  <div className={styles.testimonialMeta}>
                    <span className={styles.testimonialName}>
                      {testimonial.name}
                    </span>
                    <span className={styles.testimonialRole}>
                      {testimonial.role}
                    </span>
                  </div>
                </article>
              ))}
            </div>
            <div className={styles.carouselControls} role="group" aria-label="Testimonials navigation">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`${styles.dot} ${
                    index === currentTestimonial ? styles.dotActive : ""
                  }`}
                  onClick={() => setCurrentTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                  aria-pressed={index === currentTestimonial}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Preguntas frecuentes</h2>
            <p>
              Resolvemos las dudas más comunes para que puedas comenzar con
              seguridad.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <FaqItem key={item.question} item={item} index={index} />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Últimas perspectivas</h2>
            <p>
              Sabiduría financiera con tendencias, basada en datos y con foco en
              acción responsable.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img
                  src={`https://picsum.photos/seed/altorumbo-blog-${post.id}/800/600`}
                  alt={`Article illustration for ${post.title}`}
                  loading="lazy"
                />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.summary}</p>
                  <button
                    className={styles.textButton}
                    onClick={() => navigate("/resources")}
                  >
                    Read more →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.trialSection} id="trial-form">
        <div className="container">
          <div className={styles.trialGrid}>
            <div className={styles.trialContent}>
              <h2>Solicita tu clase introductoria gratuita</h2>
              <p>
                Conoce la plataforma, revisa dashboards en vivo y descubra cómo
                transformamos datos en acciones educativas. Double opt-in para
                proteger tu información.
              </p>
              <ul className={styles.trialList}>
                <li>Sesión de 30 minutos con walkthrough bilingüe.</li>
                <li>Panel personalizado con tus indicadores favoritos.</li>
                <li>Recibirás un correo para confirmar tu participación.</li>
              </ul>
            </div>
            <form className={styles.trialForm} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="trial-name">Full name</label>
                <input
                  id="trial-name"
                  name="name"
                  type="text"
                  placeholder="Ingresa tu nombre completo"
                  value={formValues.name}
                  onChange={handleInputChange}
                  aria-invalid={!!formErrors.name}
                  required
                />
                {formErrors.name && (
                  <span className={styles.error} role="alert">
                    {formErrors.name}
                  </span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="trial-email">Email</label>
                <input
                  id="trial-email"
                  name="email"
                  type="email"
                  placeholder="tu@email.com"
                  value={formValues.email}
                  onChange={handleInputChange}
                  aria-invalid={!!formErrors.email}
                  required
                />
                {formErrors.email && (
                  <span className={styles.error} role="alert">
                    {formErrors.email}
                  </span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="trial-confirmEmail">Confirm email</label>
                <input
                  id="trial-confirmEmail"
                  name="confirmEmail"
                  type="email"
                  placeholder="Confirma tu email"
                  value={formValues.confirmEmail}
                  onChange={handleInputChange}
                  aria-invalid={!!formErrors.confirmEmail}
                  required
                />
                {formErrors.confirmEmail && (
                  <span className={styles.error} role="alert">
                    {formErrors.confirmEmail}
                  </span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="trial-goal">What is your primary goal?</label>
                <textarea
                  id="trial-goal"
                  name="goal"
                  rows="3"
                  placeholder="Cuéntanos sobre tu reto financiero o educativo"
                  value={formValues.goal}
                  onChange={handleInputChange}
                  aria-invalid={!!formErrors.goal}
                  required
                />
                {formErrors.goal && (
                  <span className={styles.error} role="alert">
                    {formErrors.goal}
                  </span>
                )}
              </div>
              <div className={styles.checkboxGroup}>
                <input
                  id="trial-consent"
                  name="consent"
                  type="checkbox"
                  checked={formValues.consent}
                  onChange={handleInputChange}
                  aria-invalid={!!formErrors.consent}
                  required
                />
                <label htmlFor="trial-consent">
                  I agree to receive a confirmation email and understand that my
                  access activates after I confirm (double opt-in).
                </label>
              </div>
              {formErrors.consent && (
                <span className={styles.error} role="alert">
                  {formErrors.consent}
                </span>
              )}
              <button
                type="submit"
                className={`${styles.cta} ${styles.ctaPrimary}`}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Enviando..." : "Enviar solicitud"}
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

const AnimatedCounter = ({ target }) => {
  const [value, setValue] = useState(0);

  useEffect(() => {
    let start = 0;
    const duration = 1400;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setValue(target);
        clearInterval(timer);
      } else {
        setValue(Math.round(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [target]);

  return <>{value}+</>;
};

const FaqItem = ({ item, index }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className={styles.faqItem}>
      <button
        className={styles.faqToggle}
        onClick={() => setOpen((prev) => !prev)}
        aria-expanded={open}
        aria-controls={`faq-content-${index}`}
      >
        <span>{item.question}</span>
        <span aria-hidden="true">{open ? "−" : "+"}</span>
      </button>
      {open && (
        <div
          id={`faq-content-${index}`}
          className={styles.faqContent}
          role="region"
        >
          <p>{item.answer}</p>
        </div>
      )}
    </div>
  );
};

export default Home;