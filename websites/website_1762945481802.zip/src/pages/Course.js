import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Course.module.css";

const modules = [
  {
    number: "Module 1",
    title: "Panorama macro argentino",
    details:
      "Historia reciente, drivers de inflación, impacto del dólar oficial y paralelo, análisis de expectativas.",
  },
  {
    number: "Module 2",
    title: "Presupuesto y liquidez",
    details:
      "Mapeo de flujos, colchón de emergencia, asignación de objetivos y seguimiento mensual responsable.",
  },
  {
    number: "Module 3",
    title: "Gestión del riesgo cambiario",
    details:
      "Simulaciones ARS→USD, sensibilidad del presupuesto, estrategias de cobertura educativa.",
  },
  {
    number: "Module 4",
    title: "Comunicación y accountability",
    details:
      "Herramientas para la toma de decisiones en familia y organizaciones, check-ins y métricas compartidas.",
  },
];

const Course = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Curso Altorumbo | Syllabus y módulos</title>
      <meta
        name="description"
        content="Explora el syllabus del curso Altorumbo con módulos sobre macro argentina, presupuestos adaptativos, riesgo cambiario y accountability."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Syllabus del curso Altorumbo</h1>
        <p>
          Aprendizaje inmersivo con sesiones en vivo, guías descargables y
          herramientas digitales. Cada módulo mezcla teoría, datos actuales y
          ejercicios prácticos.
        </p>
      </div>
    </section>

    <section className={styles.moduleSection}>
      <div className="container">
        <div className={styles.moduleGrid}>
          {modules.map((module) => (
            <article key={module.number} className={styles.moduleCard}>
              <span className={styles.moduleNumber}>{module.number}</span>
              <h3>{module.title}</h3>
              <p>{module.details}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.audience}>
      <div className="container">
        <div className={styles.audienceGrid}>
          <div>
            <h2>¿Quiénes participan?</h2>
            <ul>
              <li>Profesionales que gestionan presupuesto familiar o pymes.</li>
              <li>Estudiantes universitarios de economía y negocios.</li>
              <li>Organizaciones que desean formar a sus equipos.</li>
            </ul>
          </div>
          <div>
            <h2>Experiencia del curso</h2>
            <ul>
              <li>Clases híbridas con sesiones síncronas y asincrónicas.</li>
              <li>Material en inglés y español con terminología clave.</li>
              <li>Evaluaciones formativas y retroalimentación personalizada.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </div>
);

export default Course;