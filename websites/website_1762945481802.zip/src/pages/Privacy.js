import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | Altorumbo</title>
      <meta
        name="description"
        content="Learn how Altorumbo handles personal data, cookies, and user privacy."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>
          Altorumbo recolecta datos mínimos para ofrecer acceso a la plataforma,
          como nombre, correo electrónico y preferencias de idioma. Implementamos
          doble opt-in para proteger tu información.
        </p>
        <h2>Data Usage</h2>
        <p>
          Utilizamos la información para gestionar acceso, enviar notificaciones
          educativas y mejorar la experiencia. No vendemos tus datos.
        </p>
        <h2>Cookies</h2>
        <p>
          Sólo usamos cookies esenciales y opcionales de analítica. Puedes
          gestionar tu consentimiento en cualquier momento desde el banner de
          cookies.
        </p>
      </div>
    </section>
  </div>
);

export default Privacy;