document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      nav.classList.toggle('open');
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (nav.classList.contains('open')) {
          nav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const yearSpan = document.getElementById('current-year');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  document.querySelectorAll('.fade-in-element').forEach(element => {
    observer.observe(element);
  });

  const banner = document.getElementById('cookie-banner');
  const consentKey = 'qdg_cookie_consent';
  if (banner) {
    const savedConsent = localStorage.getItem(consentKey);
    if (!savedConsent) {
      banner.classList.add('active');
    }
    banner.querySelectorAll('[data-cookie-consent]').forEach(button => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-cookie-consent');
        localStorage.setItem(consentKey, choice);
        banner.classList.remove('active');
      });
    });
  }

  const toast = document.getElementById('form-toast');
  const form = document.querySelector('form[data-behavior="contact-form"]');
  if (form && toast) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      toast.textContent = 'Mesajul a fost trimis. Vei fi redirecționat în scurt timp.';
      toast.classList.add('visible');
      setTimeout(() => {
        toast.classList.remove('visible');
        window.location.href = form.getAttribute('action');
      }, 1600);
    });
  }
});