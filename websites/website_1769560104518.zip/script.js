const DEFAULT_LANG = "fr";
const I18N = {
  fr: {
    "brand.name": "danswholesaleplants",
    "brand.tagline": "Systèmes d'orientation spatiale pour bâtiments publics et espaces urbains",
    "nav.home": "Accueil",
    "nav.services": "Services",
    "nav.about": "À propos",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "nav.toggle": "Ouvrir la navigation principale",
    "lang.switch": "Changer de langue",
    "lang.fr": "FR",
    "lang.en": "EN",
    "meta.home": "Analyses expertes en signalétique numérique, navigation intérieure et UX spatiale pour les environnements bâtis complexes.",
    "meta.services": "Panorama des missions de conseil en orientation spatiale, plans interactifs et design informationnel pour les bâtiments publics.",
    "meta.about": "Profil de danswholesaleplants, recherche et démarches en signalétique numérique, mobilité piétonne et architecture de l'information.",
    "meta.blog": "Articles approfondis sur l'orientation spatiale, la signalétique numérique et la cartographie des environnements complexes.",
    "meta.contact": "Coordonnées de danswholesaleplants, formulaire de contact et localisation à Bruxelles pour les projets d'orientation.",
    "meta.faq": "Réponses détaillées sur la signalétique numérique, l'accessibilité et la cartographie intérieure proposées par danswholesaleplants.",
    "meta.terms": "Conditions d'utilisation de danswholesaleplants pour la consultation de contenus spécialisés sur l'orientation spatiale.",
    "meta.privacy": "Politique de confidentialité décrivant les pratiques de traitement de données de danswholesaleplants.",
    "meta.cookies": "Politique relative aux cookies pour la plateforme éditoriale de danswholesaleplants.",
    "meta.refund": "Procédure d'annulation et de modification des prestations intellectuelles de danswholesaleplants.",
    "meta.disclaimer": "Avertissement concernant les limites d'interprétation des contenus publiés par danswholesaleplants.",
    "meta.thank": "Confirmation de réception du message adressé à danswholesaleplants.",
    "meta.post1": "Étude sur la modélisation des flux piétons et de l'orientation multi-niveaux dans les infrastructures publiques.",
    "meta.post2": "Analyse des protocoles de collecte de données spatiales pour l'UX intérieure et les plans interactifs.",
    "meta.post3": "Retour d'expérience sur la signalétique numérique inclusive et la lisibilité dans les environnements hybrides.",
    "meta.post4": "Synthèse des indicateurs de performance pour les parcours utilisateurs dans les gares et hubs urbains.",
    "meta.post5": "Méthodologie pour intégrer la navigation intérieure dans les projets de réhabilitation d'espaces publics.",
    "meta.blogpost": "Lecture approfondie sur la signalétique numérique et l'orientation spatiale par danswholesaleplants.",
    "title.home": "danswholesaleplants | Orientation spatiale et signalétique numérique",
    "title.services": "Services | danswholesaleplants",
    "title.about": "À propos | danswholesaleplants",
    "title.blog": "Blog | danswholesaleplants",
    "title.contact": "Contact | danswholesaleplants",
    "title.faq": "FAQ | danswholesaleplants",
    "title.terms": "Conditions d'utilisation | danswholesaleplants",
    "title.privacy": "Politique de confidentialité | danswholesaleplants",
    "title.cookies": "Politique de cookies | danswholesaleplants",
    "title.refund": "Politique d'annulation | danswholesaleplants",
    "title.disclaimer": "Clause de non-responsabilité | danswholesaleplants",
    "title.thank": "Merci pour votre message | danswholesaleplants",
    "title.post1": "Structurer l'orientation multi-niveaux | danswholesaleplants",
    "title.post2": "Protocole de données spatiales fiables | danswholesaleplants",
    "title.post3": "Signalétique numérique inclusive | danswholesaleplants",
    "title.post4": "Indicateurs de performance pour les hubs urbains | danswholesaleplants",
    "title.post5": "Réhabilitation et navigation intérieure | danswholesaleplants",
    "home.hero.title": "Cartographier, guider et clarifier les environnements complexes",
    "home.hero.text": "danswholesaleplants conçoit des cadres analytiques et visuels pour comprendre les flux de circulation, structurer la signalétique numérique et rendre lisibles les territoires bâtis. Chaque intervention s'appuie sur une observation fine des usages piétons et sur une cartographie précise des espaces.",
    "home.hero.primary": "Explorer les services",
    "home.hero.secondary": "Découvrir le blog",
    "home.hero.badge": "Orientation spatiale intégrée",
    "home.hero.alt": "Représentation immersive d'un plan intérieur numérique affichant des repères interactifs.",
    "home.featured.title": "Champs d'intervention prioritaires",
    "home.featured.subtitle": "Nos analyses couvrent la mobilisation des données spatiales, la scénarisation des parcours utilisateurs et la cohabitation des publics dans des infrastructures partagées.",
    "home.featured.card1.title": "Modélisation des flux piétons",
    "home.featured.card1.text": "Simulation des trajectoires et identification des points de friction pour les déplacements quotidiens et évènementiels à l'échelle du bâtiment.",
    "home.featured.card1.alt": "Schéma conceptuel représentant des flux piétons colorés convergeant vers différents points d'intérêt.",
    "home.featured.card2.title": "Plans interactifs contextualisés",
    "home.featured.card2.text": "Structuration d'interfaces cartographiques stratifiées offrant des vues multi-échelles et des filtres adaptés aux profils d'usagers.",
    "home.featured.card2.alt": "Interface cartographique interactive avec différentes couches d'information superposées.",
    "home.featured.card3.title": "Signalétique numérique adaptative",
    "home.featured.card3.text": "Création d'architectures d'information souples qui combinent repères visuels, messages contextuels et dispositifs connectés.",
    "home.featured.card3.alt": "Écran de signalétique numérique affichant des directions dynamiques dans un hall public.",
    "home.recommendations.title": "Recommandations structurantes",
    "home.recommendations.subtitle": "Synthèses opérationnelles issues de missions menées dans des gares, bibliothèques, campus et équipements sportifs en Belgique.",
    "home.recommendations.card1.title": "Aligner spatial et numérique",
    "home.recommendations.card1.text": "Synchronisez la signalétique physique avec les dispositifs numériques pour que chaque repère crée un écho cohérent dans le parcours global.",
    "home.recommendations.card2.title": "Contextualiser les parcours",
    "home.recommendations.card2.text": "Intégrez des scénarios horaires, saisonniers et événementiels afin d'anticiper les besoins d'orientation qui fluctuent dans le temps.",
    "home.recommendations.card3.title": "Documenter les usages",
    "home.recommendations.card3.text": "Alimentez les décisions de design informationnel avec des journaux de parcours, des cartes d'effort et des mesures d'accessibilité terrain.",
    "home.testimonials.title": "Témoignages croisés",
    "home.testimonials.subtitle": "Points de vue recueillis auprès de directions d'équipements, de praticiens UX et de gestionnaires d'infrastructures publiques.",
    "home.testimonials.card1.quote": "La localisation des ruptures de lisibilité dans notre musée a été cartographiée avec précision. Les recommandations ont éclairé la refonte de nos repères sans alourdir l'expérience.",
    "home.testimonials.card1.author": "Directrice de musée, Bruxelles",
    "home.testimonials.card2.quote": "Le modèle de parcours proposé a permis d'équilibrer les flux lors des correspondances du soir et de mieux orienter les voyageurs occasionnels.",
    "home.testimonials.card2.author": "Responsable d'un hub de mobilité, Liège",
    "home.testimonials.card3.quote": "Les ateliers d'analyse d'accessibilité ont révélé des micro-obstacles que nous n'avions jamais identifiés. Les solutions ont été hiérarchisées avec clarté.",
    "home.testimonials.card3.author": "Coordination accessibilité, Namur",
    "home.latest.title": "Analyses récentes",
    "home.latest.subtitle": "Lectures détaillées sur la navigation intérieure et l'architecture de l'information spatiale.",
    "home.latest.post1.title": "Structurer l'orientation multi-niveaux",
    "home.latest.post1.excerpt": "Évaluation de la granularité des repères verticaux, articulation entre ascenseurs, escaliers et plateformes numériques.",
    "home.latest.post2.title": "Assurer des données spatiales fiables",
    "home.latest.post2.excerpt": "Méthodologie de collecte, vérification topologique et diffusion des mises à jour cartographiques.",
    "home.latest.post3.title": "Signalétique inclusive en contexte hybride",
    "home.latest.post3.excerpt": "Combiner lecture visuelle, sonore et tactile pour couvrir l'ensemble des profils d'usagers.",
    "buttons.readMore": "Lire l'analyse",
    "services.hero.title": "Champs d'expertise cartographiés",
    "services.hero.subtitle": "Nous élaborons des cadres méthodologiques pour comprendre les espaces, orienter les publics et structurer les supports numériques.",
    "services.section1.title": "Analyse des besoins d'orientation",
    "services.section1.p1": "Nous évaluons les itinéraires formels et informels, mesurons la charge cognitive des usagers et identifions les zones d'ambiguïté. Les diagnostics s'appuient sur des relevés photo, des entretiens in situ et des mesures de densité.",
    "services.section1.p2": "Les résultats alimentent une cartographie priorisée des interventions : hiérarchisation des repères, axes principaux, relais informationnels et points de friction liés à l'accessibilité.",
    "services.section2.title": "Design de systèmes de signalétique numérique",
    "services.section2.p1": "Nous structurons des familles d'écrans, des plans interactifs et des interfaces mobiles cohérentes. L'objectif est de proposer des repères synchronisés qui s'adaptent aux volumes de fréquentation et aux scénarios d'exploitation.",
    "services.section2.p2": "Chaque dispositif est relié à un référentiel éditorial éprouvé, garant de la cohérence linguistique et visuelle entre les différentes strates d'information.",
    "services.section3.title": "Modélisation des parcours utilisateurs",
    "services.section3.p1": "Nous constituons des parcours cibles et alternatifs, évaluons les temps de traversée et modélisons les flux latéraux. Les représentations sont livrées sous forme de cartes narratives et de diagrammes orientés.",
    "services.section3.p2": "Cette modélisation nourrit les arbitrages sur les volumes de signalétique à déployer, les points de décision critiques et la gestion des correspondances.",
    "services.section4.title": "Design informationnel et lisibilité",
    "services.section4.p1": "Les contenus sont organisés selon des structures de sens progressif, avec des familles typographiques adaptées aux contraintes lumineuses et de distance. Nous veillons à la hiérarchie visuelle, au contraste et à la cohérence des pictogrammes.",
    "services.section4.p2": "Chaque recommandation est accompagnée de prototypes statiques et d'exemples d'application contextualisés dans l'espace étudié.",
    "services.section5.title": "Recherche sur l'accessibilité et l'UX spatiale",
    "services.section5.p1": "En collaboration avec des associations et des groupes d'usagers, nous documentons les besoins spécifiques : repères tactiles, consignes sonores, hauts contrastes et rythmes de progression.",
    "services.section5.p2": "Les livrables incluent des canevas d'évaluation, des fiches de bonnes pratiques et des indicateurs d'amélioration continue.",
    "services.figure.alt": "Illustration montrant un plan de circulation avec points d'arrêt et légende dynamique.",
    "about.hero.title": "Cartographier l'expérience des lieux complexes",
    "about.hero.subtitle": "danswholesaleplants est une structure basée à Bruxelles qui articule recherche, design et documentation pour des environnements publics denses.",
    "about.intro.p1": "Notre approche repose sur l'observation des usages réels et la transformation de ces insights en architectures informationnelles tangibles. Nous collaborons avec des collectivités, institutions culturelles, opérateurs de transport et universités.",
    "about.intro.p2": "Les projets traitent de mobilité piétonne, de lisibilité des parcours, d'interfaces de guidage et d'accessibilité universelle. Nous intervenons dès les phases exploratoires pour structurer des cadres de décision partagés.",
    "about.timeline.title": "Repères clés",
    "about.timeline.item1.title": "Fondation de danswholesaleplants",
    "about.timeline.item1.text": "Lancement d'une cellule dédiée à la lecture spatiale des bâtiments publics en Région de Bruxelles-Capitale.",
    "about.timeline.item2.title": "Premiers audits de gares",
    "about.timeline.item2.text": "Déploiement d'audits multi-supports dans trois nœuds de mobilité afin de calibrer la signalétique numérique existante.",
    "about.timeline.item3.title": "Programme accessibilité",
    "about.timeline.item3.text": "Co-construction d'ateliers avec des associations pour tester la lisibilité des parcours et prototyper de nouveaux repères tactiles.",
    "about.timeline.item4.title": "Plateforme cartographique",
    "about.timeline.item4.text": "Mise en place d'un référentiel de plans interactifs capitalisant les données topologiques et les scénarios d'exploitation.",
    "about.values.title": "Principes d'intervention",
    "about.values.card1.title": "Observation immersive",
    "about.values.card1.text": "Chaque mission démarre par une immersion prolongée permettant de comprendre les usages situés, les rythmes et les arbitrages des usagers.",
    "about.values.card2.title": "Transparence méthodologique",
    "about.values.card2.text": "Les hypothèses, métriques et sources sont documentées afin que les organisations puissent répliquer les analyses.",
    "about.values.card3.title": "Compatibilité systémique",
    "about.values.card3.text": "Les recommandations sont pensées pour dialoguer avec les systèmes existants et faciliter l'intégration progressive des nouveautés.",
    "about.media.alt": "Vue intérieure d'un bâtiment public avec signalétique claire et zones de circulation définies.",
    "blog.hero.title": "Lectures spatiales",
    "blog.hero.subtitle": "Chaque article s'appuie sur des retours terrain, des jeux de données structurés et des cadres théoriques dédiés à l'orientation.",
    "blog.list.post1.category": "Analyse de flux",
    "blog.list.post1.title": "Structurer l'orientation multi-niveaux",
    "blog.list.post1.excerpt": "Comment articuler plans verticaux, repères sensoriels et dispositifs connectés dans les bâtiments stratifiés.",
    "blog.list.post2.category": "Données spatiales",
    "blog.list.post2.title": "Assurer des données spatiales fiables",
    "blog.list.post2.excerpt": "Stratégies de collecte, validation topologique et diffusion continue pour les plans intérieurs.",
    "blog.list.post3.category": "Accessibilité",
    "blog.list.post3.title": "Signalétique numérique inclusive",
    "blog.list.post3.excerpt": "Construire des parcours accessibles qui combinent guidage visuel, sonore et tactile.",
    "blog.list.post4.category": "Indicateurs",
    "blog.list.post4.title": "Mesurer les performances des hubs urbains",
    "blog.list.post4.excerpt": "Définir des indicateurs lisibles pour piloter les expériences de mobilité.",
    "blog.list.post5.category": "Réhabilitation",
    "blog.list.post5.title": "Réhabiliter avec la navigation intérieure",
    "blog.list.post5.excerpt": "Intégrer la signalétique dès les phases de transformation d'espaces publics.",
    "blog.card.alt1": "Plan architectural avec différents niveaux reliés par des icônes de circulation.",
    "blog.card.alt2": "Équipe analysant un plan interactif projeté sur un mur.",
    "blog.card.alt3": "Signalétique tactile et visuelle intégrée dans un couloir lumineux.",
    "blog.card.alt4": "Tableau de bord affichant des indicateurs de flux piétons.",
    "blog.card.alt5": "Plan de réhabilitation d'un quartier avec annotations de guidage.",
    "contact.hero.title": "Entrer en relation",
    "contact.hero.subtitle": "Nous analysons les contextes, partageons des outils et construisons des dispositifs sur mesure pour clarifier les espaces.",
    "contact.details.title": "Coordonnées",
    "contact.details.phoneLabel": "Téléphone",
    "contact.details.phoneValue": "+32 2 280 45 67",
    "contact.details.emailLabel": "Courriel",
    "contact.details.emailValue": "contact@danswholesaleplants.com",
    "contact.details.addressLabel": "Adresse",
    "contact.details.addressValue": "Rue de la Loi 155, 1040 Bruxelles, Belgique",
    "contact.details.hours": "Réunions sur rendez-vous du lundi au vendredi.",
    "contact.form.title": "Formulaire de contact",
    "contact.form.nameLabel": "Nom complet",
    "contact.form.namePlaceholder": "Votre nom",
    "contact.form.emailLabel": "Adresse électronique",
    "contact.form.emailPlaceholder": "nom@exemple.com",
    "contact.form.orgLabel": "Organisation",
    "contact.form.orgPlaceholder": "Structure ou département",
    "contact.form.messageLabel": "Message",
    "contact.form.messagePlaceholder": "Décrivez vos besoins liés à l'orientation spatiale…",
    "contact.form.submit": "Envoyer et poursuivre",
    "contact.map.title": "Localisation",
    "contact.map.caption": "Localisation de danswholesaleplants à Bruxelles sur la carte OpenStreetMap.",
    "faq.hero.title": "Questions récurrentes",
    "faq.hero.subtitle": "Précisions sur notre approche, la collecte de données et la gouvernance des dispositifs d'orientation.",
    "faq.item1.question": "Comment abordez-vous la modélisation des parcours dans des bâtiments multi-niveaux ?",
    "faq.item1.answer": "Nous combinons relevés lidar, journalisation vidéo et ateliers avec les personnels d'accueil pour cartographier les points de décision. Les modèles sont ensuite validés par des simulations de temps de parcours.",
    "faq.item2.question": "Quels livrables accompagnez-vous d'indicateurs de suivi ?",
    "faq.item2.answer": "Les plans interactifs, guides éditoriaux et grilles de scénarios sont fournis avec des indicateurs de lisibilité, de charge cognitive et de réactivité des mises à jour.",
    "faq.item3.question": "Comment intégrez-vous l'accessibilité universelle ?",
    "faq.item3.answer": "Chaque diagnostic inclut une lecture des contraintes motrices, sensorielles et cognitives. Les recommandations mentionnent les contrastes, signalétiques tactiles, annonces sonores et supports alternatifs.",
    "faq.item4.question": "Travaillez-vous avec des données existantes des clients ?",
    "faq.item4.answer": "Oui, nous auditons la qualité des plans existants, réalignons les couches d'information et assurons une traçabilité entre les sources internes et les observations terrain.",
    "faq.item5.question": "Quel est votre cadre de collaboration avec les architectes ?",
    "faq.item5.answer": "Nous intervenons en complément, en apportant une lecture orientée usagers. Les livrables sont articulés avec les phases de conception architecturale.",
    "faq.item6.question": "Comment garantissez-vous la mise à jour des dispositifs numériques ?",
    "faq.item6.answer": "Nous définissons des protocoles d'administration, des check-lists éditoriales et des déclencheurs basés sur les changements de scénarios de circulation.",
    "terms.hero.title": "Conditions d'utilisation",
    "terms.hero.subtitle": "Référentiel contractuel de consultation et d'utilisation de la plateforme éditoriale de danswholesaleplants.",
    "terms.section1.title": "1. Objet",
    "terms.section1.content": "Les présentes conditions définissent les modalités d'accès aux contenus, ressources et documents mis à disposition par danswholesaleplants via le domaine danswholesaleplants.com.",
    "terms.section2.title": "2. Acceptation",
    "terms.section2.content": "Toute consultation du site implique l'acceptation sans réserve des présentes conditions. En cas de désaccord, l'utilisateur est invité à interrompre sa visite.",
    "terms.section3.title": "3. Disponibilité",
    "terms.section3.content": "Le site est accessible 24h/24 sous réserve d'interruptions techniques nécessaires à la maintenance ou à l'évolution des contenus.",
    "terms.section4.title": "4. Propriété intellectuelle",
    "terms.section4.content": "Les textes, schémas, images et structures informationnelles sont protégés par le droit d'auteur. Toute reproduction nécessite l'accord écrit préalable de danswholesaleplants.",
    "terms.section5.title": "5. Usage autorisé",
    "terms.section5.content": "Les contenus sont fournis pour un usage documentaire et analytique. Toute diffusion doit mentionner la source et conserver l'intégrité des informations.",
    "terms.section6.title": "6. Responsabilité",
    "terms.section6.content": "danswholesaleplants met tout en œuvre pour garantir l'exactitude des informations. Néanmoins, l'utilisateur exploite les contenus à ses propres risques.",
    "terms.section7.title": "7. Liens externes",
    "terms.section7.content": "Les liens vers des ressources tierces sont fournis pour information. danswholesaleplants n'assume aucune responsabilité quant à leur contenu.",
    "terms.section8.title": "8. Données personnelles",
    "terms.section8.content": "Le traitement des données issues du formulaire de contact est décrit dans la politique de confidentialité et respecte les exigences du RGPD.",
    "terms.section9.title": "9. Cookies",
    "terms.section9.content": "L'utilisation de cookies est détaillée dans la politique dédiée. L'utilisateur peut gérer ses préférences à tout moment via le module prévu.",
    "terms.section10.title": "10. Modifications",
    "terms.section10.content": "danswholesaleplants se réserve le droit de modifier les présentes conditions. Les nouvelles dispositions s'appliquent dès leur publication.",
    "terms.section11.title": "11. Loi applicable",
    "terms.section11.content": "Les présentes conditions sont régies par le droit belge. Tout litige relève de la compétence des juridictions de Bruxelles.",
    "terms.section12.title": "12. Nullité partielle",
    "terms.section12.content": "Si une clause est jugée invalide, les autres dispositions restent applicables.",
    "terms.section13.title": "13. Contact juridique",
    "terms.section13.content": "Pour toute question relative aux conditions d'utilisation, merci de contacter notre équipe via la page Contact.",
    "terms.section14.title": "14. Entrée en vigueur",
    "terms.section14.content": "Les présentes conditions sont effectives depuis le 2 janvier 2024 et demeurent valables jusqu'à publication d'une nouvelle version.",
    "privacy.hero.title": "Politique de confidentialité",
    "privacy.hero.subtitle": "Gestion des données personnelles collectées via danswholesaleplants.com.",
    "privacy.section1.title": "1. Responsable du traitement",
    "privacy.section1.content": "Le responsable du traitement est danswholesaleplants, établi Rue de la Loi 155, 1040 Bruxelles, Belgique.",
    "privacy.section2.title": "2. Données collectées",
    "privacy.section2.content": "Les données collectées via le formulaire de contact comprennent le nom, l'adresse électronique, l'organisation et le contenu du message.",
    "privacy.section3.title": "3. Finalités",
    "privacy.section3.content": "Les informations sont utilisées pour répondre aux demandes, organiser des rendez-vous et assurer le suivi des échanges.",
    "privacy.section4.title": "4. Base légale",
    "privacy.section4.content": "Le traitement repose sur l'intérêt légitime de répondre aux sollicitations professionnelles et sur le consentement explicite lors de l'envoi du formulaire.",
    "privacy.section5.title": "5. Conservation",
    "privacy.section5.content": "Les données sont conservées pendant une durée maximale de deux ans après le dernier échange, sauf obligation légale contraire.",
    "privacy.section6.title": "6. Partage",
    "privacy.section6.content": "Les données ne sont pas cédées à des tiers. Elles peuvent être hébergées sur des serveurs situés au sein de l'Union européenne.",
    "privacy.section7.title": "7. Droits",
    "privacy.section7.content": "Toute personne peut demander l'accès, la rectification, la limitation ou l'effacement de ses données en utilisant les coordonnées de contact.",
    "privacy.section8.title": "8. Sécurité",
    "privacy.section8.content": "Des mesures techniques et organisationnelles sont mises en place pour préserver la confidentialité et l'intégrité des informations.",
    "privacy.section9.title": "9. Cookies",
    "privacy.section9.content": "La gestion des cookies est décrite dans la politique dédiée et peut être ajustée via le module de consentement.",
    "privacy.section10.title": "10. Contact",
    "privacy.section10.content": "Pour exercer vos droits ou poser une question, écrivez à contact@danswholesaleplants.com.",
    "cookies.hero.title": "Politique de cookies",
    "cookies.hero.subtitle": "Fonctionnement, finalité et gestion des cookies utilisés sur danswholesaleplants.com.",
    "cookies.intro": "Le site utilise des cookies strictement nécessaires et facultatifs pour mesurer l'audience et affiner la présentation de ses contenus.",
    "cookies.table.heading.name": "Nom du cookie",
    "cookies.table.heading.provider": "Fournisseur",
    "cookies.table.heading.type": "Type",
    "cookies.table.heading.purpose": "Finalité",
    "cookies.table.heading.duration": "Durée",
    "cookies.table.row1.name": "site_session",
    "cookies.table.row1.provider": "danswholesaleplants",
    "cookies.table.row1.type": "Nécessaire",
    "cookies.table.row1.purpose": "Maintien des préférences linguistiques et de navigation.",
    "cookies.table.row1.duration": "Session",
    "cookies.table.row2.name": "analytics_opt",
    "cookies.table.row2.provider": "danswholesaleplants",
    "cookies.table.row2.type": "Analytique",
    "cookies.table.row2.purpose": "Suivi agrégé de la fréquentation pour améliorer les contenus.",
    "cookies.table.row2.duration": "6 mois",
    "cookies.table.row3.name": "pref_layout",
    "cookies.table.row3.provider": "danswholesaleplants",
    "cookies.table.row3.type": "Préférences",
    "cookies.table.row3.purpose": "Mémorisation des options d'affichage et de contraste.",
    "cookies.table.row3.duration": "6 mois",
    "cookies.table.row4.name": "camp_context",
    "cookies.table.row4.provider": "danswholesaleplants",
    "cookies.table.row4.type": "Marketing",
    "cookies.table.row4.purpose": "Compréhension des sources de trafic pour contextualiser les publications.",
    "cookies.table.row4.duration": "3 mois",
    "cookies.manage.title": "Gestion des préférences",
    "cookies.manage.desc": "Vous pouvez modifier vos choix à tout moment via le module de consentement disponible en bas de page.",
    "refund.hero.title": "Politique d'annulation",
    "refund.hero.subtitle": "Modalités d'ajustement des prestations intellectuelles menées par danswholesaleplants.",
    "refund.section1.title": "1. Champ d'application",
    "refund.section1.content": "Cette politique concerne les missions de conseil, d'analyse et de documentation réalisées par danswholesaleplants.",
    "refund.section2.title": "2. Notification",
    "refund.section2.content": "Toute demande d'annulation ou de modification doit être formulée par écrit via contact@danswholesaleplants.com.",
    "refund.section3.title": "3. Délai de prévenance",
    "refund.section3.content": "Les ajustements sont possibles jusqu'à quinze jours ouvrables avant la date prévue de livraison d'un livrable intermédiaire.",
    "refund.section4.title": "4. Travaux engagés",
    "refund.section4.content": "Les analyses déjà réalisées et documentées restent dues. Un relevé détaillé des tâches est fourni sur demande.",
    "refund.section5.title": "5. Rééchelonnement",
    "refund.section5.content": "Toute replanification est conditionnée aux disponibilités de l'équipe et donne lieu à un calendrier mis à jour.",
    "refund.section6.title": "6. Collaboration externe",
    "refund.section6.content": "Lorsque des experts associés sont mobilisés, les conditions d'annulation spécifiques sont notifiées à l'avance.",
    "refund.section7.title": "7. Documentation transmise",
    "refund.section7.content": "Les documents déjà remis dans le cadre de la mission restent utilisables par le client selon les termes contractuels.",
    "refund.section8.title": "8. Cas de force majeure",
    "refund.section8.content": "En cas d'événement imprévisible empêchant la réalisation de la mission, les parties conviennent d'un plan d'action adapté.",
    "refund.section9.title": "9. Communication",
    "refund.section9.content": "Un point de situation est systématiquement proposé pour clarifier l'état d'avancement et les suites envisageables.",
    "refund.section10.title": "10. Contact",
    "refund.section10.content": "Pour toute question, la page Contact du site précise les moyens d'échange privilégiés.",
    "disclaimer.hero.title": "Clause de non-responsabilité",
    "disclaimer.hero.subtitle": "Cadrage des limites d'interprétation des contenus publiés sur danswholesaleplants.com.",
    "disclaimer.section1.title": "1. Nature des informations",
    "disclaimer.section1.content": "Les contenus présentent des analyses générales et ne remplacent pas une étude dédiée à un contexte particulier.",
    "disclaimer.section2.title": "2. Absence de garantie",
    "disclaimer.section2.content": "Danswholesaleplants ne garantit pas l'exhaustivité ni l'actualité permanente des informations mises en ligne.",
    "disclaimer.section3.title": "3. Utilisation",
    "disclaimer.section3.content": "L'utilisateur demeure responsable des interprétations et décisions prises sur la base des contenus consultés.",
    "disclaimer.section4.title": "4. Références tierces",
    "disclaimer.section4.content": "Les citations de tiers sont indiquées pour contextualisation. Elles n'impliquent pas d'accord formel ou de validation réciproque.",
    "disclaimer.section5.title": "5. Mise à jour",
    "disclaimer.section5.content": "Les informations peuvent être modifiées sans préavis afin de refléter l'évolution des travaux et publications.",
    "disclaimer.section6.title": "6. Contact",
    "disclaimer.section6.content": "Pour toute précision, utilisez le formulaire de contact disponible sur le site.",
    "thank.hero.title": "Merci pour votre message",
    "thank.hero.subtitle": "Votre demande a bien été transmise. Nous reviendrons vers vous après analyse du contexte.",
    "thank.content": "Une confirmation vous sera également envoyée si vous avez laissé vos coordonnées complètes.",
    "footer.tagline": "Structures d'orientation spatiale et cartographies pour environnements complexes.",
    "footer.phoneLabel": "Téléphone :",
    "footer.emailLabel": "Courriel :",
    "footer.addressLabel": "Adresse :",
    "footer.addressValue": "Rue de la Loi 155, 1040 Bruxelles, Belgique",
    "footer.rightsPrefix": "©",
    "footer.rightsSuffix": "danswholesaleplants. Tous droits réservés.",
    "footer.terms": "Conditions d'utilisation",
    "footer.privacy": "Politique de confidentialité",
    "footer.cookies": "Politique de cookies",
    "footer.refund": "Politique d'annulation",
    "footer.disclaimer": "Clause de non-responsabilité",
    "cookie.bannerTitle": "Gestion des cookies",
    "cookie.bannerDescription": "Nous utilisons des cookies pour comprendre les usages et améliorer la lisibilité du site. Vous pouvez personnaliser vos choix.",
    "cookie.moreLink": "Consulter la politique de cookies",
    "cookie.toggle.necessary": "Nécessaires",
    "cookie.toggle.necessaryDesc": "Indispensables au fonctionnement du site et à la sauvegarde de vos préférences.",
    "cookie.toggle.preferences": "Préférences",
    "cookie.toggle.preferencesDesc": "Enregistre vos réglages d'affichage et de contraste.",
    "cookie.toggle.analytics": "Analytique",
    "cookie.toggle.analyticsDesc": "Mesure l'audience de manière agrégée pour améliorer les contenus.",
    "cookie.toggle.marketing": "Contextuels",
    "cookie.toggle.marketingDesc": "Analyse les sources de consultation pour adapter la présentation des publications.",
    "cookie.actions.accept": "Tout accepter",
    "cookie.actions.decline": "Tout refuser",
    "cookie.actions.save": "Enregistrer",
    "toast.formError": "Merci de vérifier les champs requis avant l'envoi.",
    "toast.formSubmit": "Votre message est en cours de transmission vers l'équipe.",
    "toast.preferencesSaved": "Vos préférences de cookies ont été mises à jour.",
    "toast.preferencesDeclined": "Les cookies facultatifs ont été désactivés.",
    "toast.preferencesAccepted": "Tous les cookies ont été activés.",
    "blog.post1.h1": "Structurer l'orientation multi-niveaux",
    "blog.post1.h2a": "Analyser la verticalité des parcours",
    "blog.post1.h3a": "Observer la distribution des repères",
    "blog.post1.p1": "Les environnements multi-niveaux imposent de comprendre la verticalité comme un canal d'information à part entière. Dans les gares ou les campus hospitaliers, les usagers doivent mémoriser l'enchaînement des transitions entre ascenseurs, escaliers et passerelles. L'étude démarre par une cartographie tridimensionnelle qui recense les points de décision, les vues dégagées et les secteurs saturés. Chaque repère est positionné selon son efficacité perçue, sa visibilité à distance et sa redondance avec d'autres supports. Cette lecture offre une base solide pour hiérarchiser les interventions à mener et canaliser les flux vers des noyaux clairement identifiés.",
    "blog.post1.p2": "Une attention particulière est portée aux zones de convergence où les trajectoires se croisent sous plusieurs angles. L'objectif est de limiter la surcharge cognitive au niveau des plateaux d'échanges tout en garantissant des alternatives explicitement documentées. Les simulations réalisées avec des scénarios de trafic différenciés mettent en évidence les temporalités critiques. Ces données alimentent ensuite la conception des plans verticaux et la coordination entre signalétique physique et dispositifs numériques installés sur site.",
    "blog.post1.h2b": "Synchroniser les supports physiques et digitaux",
    "blog.post1.h3b": "Étager les niveaux d'information",
    "blog.post1.p3": "La synchronisation des supports repose sur une structuration éditoriale finement hiérarchisée. Les repères physiques, comme les totems et panneaux suspendus, délivrent une information synthétique et stable. Les écrans numériques, quant à eux, jouent sur la flexibilité et la personnalisation en fonction de l'heure, des événements ou des affluences exceptionnelles. La cohérence se construit grâce à un référentiel commun qui décrit le vocabulaire, la syntaxe graphique et les zones d'implantation possibles.",
    "blog.post1.p4": "Dans un centre administratif bruxellois, la démarche a consisté à mesurer la concordance entre les annonces numériques et la réalité des flux observés. Les écarts ont été mis en évidence au moyen de matrices qui confrontent type de public, destination et support consulté. Le travail final a proposé un parcours de validation hebdomadaire afin de garantir que les informations diffusées restent alignées sur la configuration spatiale effective.",
    "blog.post1.h2c": "Mesurer l'efficacité des parcours",
    "blog.post1.h3c": "Capitaliser sur les retours d'usage",
    "blog.post1.p5": "L'efficacité d'un dispositif d'orientation multi-niveaux se mesure autant par l'aisance ressentie que par les temps de déplacement. Des entretiens situés ont permis de recueillir des verbatims sur la compréhension des changements de niveau, notamment pour les usagers découvrant le bâtiment. Ces retours ont été croisés avec des relevés anonymisés de déplacements afin d'identifier les divergences entre intention de parcours et trajectoire réelle.",
    "blog.post1.p6": "Les enseignements tirés soulignent la nécessité de consolider les repères dès l'entrée dans le bâtiment, de multiplier les rappels visuels avant une bifurcation majeure et d'exploiter les supports numériques comme un filet de sécurité. La modélisation continue des flux contribue à maintenir la qualité de l'orientation dans la durée.",
    "blog.post2.h1": "Assurer des données spatiales fiables pour la navigation intérieure",
    "blog.post2.h2a": "Collecter les données fondamentales",
    "blog.post2.h3a": "Constituer un référentiel robuste",
    "blog.post2.p1": "Le déploiement de plans interactifs n'a de sens que si les données structurelles sont maîtrisées. Nous commençons par un inventaire précis des niveaux, zones fonctionnelles et circulations. Les relevés se combinent à des sources existantes : plans de prévention, fichiers BIM et relevés topographiques. Chaque couche est nettoyée pour supprimer les doublons et harmoniser les nomenclatures.",
    "blog.post2.p2": "Une grille de validation vérifie l'intégrité des données. Elle s'appuie sur des règles simples : continuité des circulations, cohérence des attributs, absence de zones orphelines. Ce contrôle garantit que les futurs outils numériques reposent sur un socle stable et facilement maintenable.",
    "blog.post2.h2b": "Structurer la chaîne de mise à jour",
    "blog.post2.h3b": "Mettre en place des protocoles documentés",
    "blog.post2.p3": "Les mises à jour constituent un enjeu majeur pour la crédibilité des plans interactifs. Nous instaurant une chaîne claire : déclaration des changements par les équipes terrain, validation par un référent cartographique, déploiement dans l'outil de diffusion. Chaque étape est tracée pour assurer la réversibilité et la compréhension des modifications.",
    "blog.post2.p4": "Dans un réseau de bibliothèques, nous avons défini des cycles trimestriels de vérification. Les déplacements de collections, travaux ou changements de circulation temporaire sont ainsi intégrés sans délai. Le protocole inclut des check-lists et une communication structurée vers les équipes d'accueil.",
    "blog.post2.h2c": "Diffuser l'information auprès des usagers",
    "blog.post2.h3c": "Rendre les données lisibles et fiables",
    "blog.post2.p5": "La diffusion s'effectue via différents canaux : bornes tactiles, versions imprimées, micro-affichages et intégrations web. Chaque support se voit attribuer un niveau de détail adapté. Les informations contextuelles comme les temps de marche estimés ou les contraintes temporaires sont maintenues à jour grâce à des flux synchronisés.",
    "blog.post2.p6": "La fiabilité est renforcée par des mécanismes de contrôle automatique : les liens vers les étages et les correspondances doivent rester actifs, les pictogrammes suivent une nomenclature commune et les couleurs respectent des règles de contraste. Ces éléments participent à la confiance accordée par les usagers aux dispositifs.",
    "blog.post3.h1": "Construire une signalétique numérique inclusive",
    "blog.post3.h2a": "Prendre en compte la diversité des profils",
    "blog.post3.h3a": "Croiser les modes de perception",
    "blog.post3.p1": "L'inclusion en signalétique numérique passe par la reconnaissance de la diversité des manières de percevoir l'espace. Notre démarche consiste à croiser les modes visuels, auditifs et tactiles pour proposer des repères qui ne reposent pas sur un seul canal sensoriel. Les ateliers menés avec des publics variés révèlent les obstacles liés aux contrastes insuffisants, aux messages trop textuels ou aux parcours non balisés.",
    "blog.post3.p2": "Nous intégrons ces enseignements dans des chartes de conception. Les écrans sont paramétrés pour proposer des niveaux de contraste ajustables et des textes reformulés en messages synthétiques. Les séquences audio sont synchronisées avec les indications visuelles pour renforcer la compréhension.",
    "blog.post3.h2b": "Orchestrer la complémentarité des supports",
    "blog.post3.h3b": "Garantir une continuité sensorielle",
    "blog.post3.p3": "Les dispositifs numériques ne fonctionnent pas isolément. Ils dialoguent avec des repères physiques : bandes de guidage, pictogrammes tactiles, codes couleur. En orchestrant ces supports, on assure une continuité sensorielle qui facilite l'orientation des personnes circulant à différents rythmes.",
    "blog.post3.p4": "Dans une médiathèque rénovée, nous avons associé les écrans d'accueil à des cartographies tactiles et à un système de notifications sonores. Ce trio offre plusieurs chemins d'accès à la même information, réduisant les risques d'exclusion pour les personnes ayant une perception partielle.",
    "blog.post3.h2c": "Évaluer et ajuster",
    "blog.post3.h3c": "Mesurer l'impact utilisateur",
    "blog.post3.p5": "L'évaluation se fait par des tests en situation réelle. Les parcours sont chronométrés et accompagnés d'entretiens pour comprendre la charge cognitive et la facilité à suivre les indications. Les retours alimentent des ajustements progressifs, du calibrage des icônes à la formulation des consignes.",
    "blog.post3.p6": "Les résultats montrent que la combinaison de plusieurs signaux cohérents renforce la confiance des usagers dans les dispositifs numériques. Une attention continue garantit que les améliorations restent pertinentes face à l'évolution des usages.",
    "blog.post4.h1": "Mesurer les performances des hubs urbains",
    "blog.post4.h2a": "Identifier les métriques essentielles",
    "blog.post4.h3a": "Relier flux et perception",
    "blog.post4.p1": "Les hubs urbains concentrent des flux intenses qui nécessitent un pilotage fin. Les indicateurs retenus doivent refléter à la fois la fluidité des déplacements et la perception qualitative des usagers. Nous articulons des données quantitatives, comme le temps de traversée et la densité par zone, avec des mesures subjectives collectées lors d'entretiens rapides.",
    "blog.post4.p2": "Cette approche mixte met en lumière les écarts entre performance objective et ressenti. Un itinéraire rapide peut être perçu comme complexe s'il multiplie les bifurcations. Les indicateurs deviennent alors un outil de dialogue entre les équipes opérationnelles et les designers d'information.",
    "blog.post4.h2b": "Consolider les tableaux de bord",
    "blog.post4.h3b": "Structurer des rapports lisibles",
    "blog.post4.p3": "Les tableaux de bord sont construits à partir de données structurées. Ils mettent en évidence les zones à surveiller, les horaires sensibles et les points d'attention pour l'accessibilité. Le visuel privilégie des codes cohérents avec la signalétique sur site afin de faciliter la lecture par les équipes.",
    "blog.post4.p4": "Un hub multimodal bruxellois utilise désormais une grille mensuelle qui recoupe données de fréquentation, incidents signalés et retours utilisateurs. Les décisions d'ajout de repères ou de repositionnement d'écrans sont ainsi objectivées.",
    "blog.post4.h2c": "Instaurer un cycle d'amélioration continue",
    "blog.post4.h3c": "Activer les retours terrain",
    "blog.post4.p5": "L'amélioration continue repose sur un dialogue constant avec les équipes de terrain. Les agents d'accueil alimentent une base d'observations décrivant les incompréhensions récurrentes. Ces remontées sont croisées avec les données quantitatives pour prioriser les actions.",
    "blog.post4.p6": "Le cycle se conclut par des ateliers de restitution associant usagers et opérateurs. Les indicateurs servent de support pour imaginer de nouveaux scénarios et tester des prototypes de signalétique.",
    "blog.post5.h1": "Réhabiliter les espaces publics avec une navigation intérieure maîtrisée",
    "blog.post5.h2a": "Anticiper la transformation des parcours",
    "blog.post5.h3a": "Cartographier les usages superposés",
    "blog.post5.p1": "La réhabilitation d'un équipement public implique de reconfigurer des parcours habitués. Avant tout chantier, nous analysons les usages actuels : cheminements, points d'arrêt, séquences de service. Cette cartographie met en évidence les zones sensibles qui nécessitent des mesures d'accompagnement spécifiques.",
    "blog.post5.p2": "Les scénarios de travaux sont simulés pour prévoir les détours temporaires. Les repères numériques servent alors de relais d'information pour expliquer les phases, proposer des itinéraires alternatifs et rassurer les usagers réguliers.",
    "blog.post5.h2b": "Coordonner communication et signalétique",
    "blog.post5.h3b": "Maintenir la lisibilité pendant les travaux",
    "blog.post5.p3": "La communication de chantier est articulée avec la signalétique. Les écrans, affiches et agents de médiation utilisent un vocabulaire commun afin de limiter les divergences. Les supports temporaires sont pensés dès la phase de conception et testés sur des prototypes à échelle réduite.",
    "blog.post5.p4": "Une bibliothèque en rénovation a adopté un kit d'information comprenant plans révisés, pictogrammes temporaires et messages audio. Cette cohérence multi-supports a permis d'éviter les ruptures de service durant les phases critiques.",
    "blog.post5.h2c": "Capitaliser après la réouverture",
    "blog.post5.h3c": "Inscrire les apprentissages dans la durée",
    "blog.post5.p5": "À l'issue de la réhabilitation, un retour d'expérience est mené pour identifier ce qui doit être pérennisé. Les nouveaux parcours sont évalués selon leur lisibilité, leur accessibilité et leur capacité à absorber les événements spéciaux.",
    "blog.post5.p6": "Les enseignements alimentent un référentiel interne destiné aux futures évolutions du site. Cette mémoire opérationnelle garantit la cohérence de la navigation intérieure sur le long terme.",
    "post1.hero.alt": "Escaliers mécaniques et ascenseurs connectés par des panneaux directionnels lumineux.",
    "post2.hero.alt": "Spécialistes examinant des données cartographiques sur plusieurs écrans.",
    "post3.hero.alt": "Signalétique numérique affichant des consignes en formats visuel et tactile.",
    "post4.hero.alt": "Vue d'un hub urbain avec flux piétons et affichage en temps réel.",
    "post5.hero.alt": "Plan de réhabilitation avec zones de circulation temporaires indiquées.",
    "thank.link.home": "Retourner à l'accueil",
    "thank.link.blog": "Consulter les analyses",
    "contact.requiredNotice": "Les champs marqués d'un astérisque sont obligatoires.",
    "form.required": "Champ requis",
    "form.emailInvalid": "Adresse électronique non valide."
  },
  en: {
    "brand.name": "danswholesaleplants",
    "brand.tagline": "Spatial orientation systems for public buildings and urban environments",
    "nav.home": "Home",
    "nav.services": "Services",
    "nav.about": "About",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "nav.toggle": "Open main navigation",
    "lang.switch": "Change language",
    "lang.fr": "FR",
    "lang.en": "EN",
    "meta.home": "Expert insights on digital wayfinding, interior navigation and spatial UX within complex built environments.",
    "meta.services": "Overview of consulting capabilities in spatial orientation, interactive mapping and informational design for public buildings.",
    "meta.about": "Profile of danswholesaleplants, research and practice in digital signage, pedestrian mobility and information architecture.",
    "meta.blog": "In-depth articles on spatial orientation, digital signage and mapping of complex environments.",
    "meta.contact": "Contact details for danswholesaleplants, enquiry form and Brussels location for orientation projects.",
    "meta.faq": "Detailed answers on digital signage, accessibility and interior mapping provided by danswholesaleplants.",
    "meta.terms": "Terms of use for consulting specialized content on spatial orientation from danswholesaleplants.",
    "meta.privacy": "Privacy policy describing data handling practices at danswholesaleplants.",
    "meta.cookies": "Cookie policy for the danswholesaleplants editorial platform.",
    "meta.refund": "Procedure for adjusting intellectual services delivered by danswholesaleplants.",
    "meta.disclaimer": "Disclaimer outlining interpretation limits of publications released by danswholesaleplants.",
    "meta.thank": "Confirmation of the message sent to danswholesaleplants.",
    "meta.post1": "Study on pedestrian flow modelling and multi-level orientation in public infrastructures.",
    "meta.post2": "Analysis of spatial data collection protocols for interior UX and interactive maps.",
    "meta.post3": "Field report on inclusive digital signage and legibility across hybrid environments.",
    "meta.post4": "Summary of performance indicators for user journeys within urban transport hubs.",
    "meta.post5": "Methodology for embedding indoor navigation in public space refurbishment projects.",
    "meta.blogpost": "Detailed reading on digital signage and spatial orientation by danswholesaleplants.",
    "title.home": "danswholesaleplants | Spatial Orientation and Digital Signage",
    "title.services": "Services | danswholesaleplants",
    "title.about": "About | danswholesaleplants",
    "title.blog": "Blog | danswholesaleplants",
    "title.contact": "Contact | danswholesaleplants",
    "title.faq": "FAQ | danswholesaleplants",
    "title.terms": "Terms of Use | danswholesaleplants",
    "title.privacy": "Privacy Policy | danswholesaleplants",
    "title.cookies": "Cookie Policy | danswholesaleplants",
    "title.refund": "Cancellation Policy | danswholesaleplants",
    "title.disclaimer": "Disclaimer | danswholesaleplants",
    "title.thank": "Thank You | danswholesaleplants",
    "title.post1": "Structuring Multi-Level Orientation | danswholesaleplants",
    "title.post2": "Reliable Spatial Data Protocol | danswholesaleplants",
    "title.post3": "Inclusive Digital Signage | danswholesaleplants",
    "title.post4": "Performance Indicators for Urban Hubs | danswholesaleplants",
    "title.post5": "Refurbishment and Indoor Navigation | danswholesaleplants",
    "home.hero.title": "Mapping, guiding and clarifying complex environments",
    "home.hero.text": "danswholesaleplants develops analytical and visual frameworks to understand pedestrian flows, organise digital signage and promote legible built territories. Each assignment relies on close observation of usage patterns and on detailed mapping of interior and urban spaces.",
    "home.hero.primary": "View services",
    "home.hero.secondary": "Browse the blog",
    "home.hero.badge": "Integrated spatial orientation",
    "home.hero.alt": "Immersive view of a digital indoor map showing interactive landmarks.",
    "home.featured.title": "Priority fields of action",
    "home.featured.subtitle": "Our work covers spatial data mobilisation, user journey scripting and coexistence of audiences in shared infrastructures.",
    "home.featured.card1.title": "Pedestrian flow modelling",
    "home.featured.card1.text": "Simulating trajectories and identifying friction points for daily and event traffic across entire buildings.",
    "home.featured.card1.alt": "Concept diagram displaying coloured pedestrian flows converging on key destinations.",
    "home.featured.card2.title": "Contextual interactive maps",
    "home.featured.card2.text": "Structuring layered cartographic interfaces that provide multi-scale views and filters adapted to user profiles.",
    "home.featured.card2.alt": "Interactive mapping interface with stacked information layers.",
    "home.featured.card3.title": "Adaptive digital signage",
    "home.featured.card3.text": "Designing flexible information architectures that blend visual cues, contextual messaging and connected devices.",
    "home.featured.card3.alt": "Digital signage screen with dynamic directions in a public hall.",
    "home.recommendations.title": "Structuring recommendations",
    "home.recommendations.subtitle": "Operational insights informed by missions in Belgian stations, libraries, campuses and sports facilities.",
    "home.recommendations.card1.title": "Align spatial and digital",
    "home.recommendations.card1.text": "Synchronise physical signage with digital devices so each landmark resonates within the overall journey.",
    "home.recommendations.card2.title": "Contextualise journeys",
    "home.recommendations.card2.text": "Factor in daily, seasonal and event scenarios to anticipate how orientation needs evolve over time.",
    "home.recommendations.card3.title": "Document user practices",
    "home.recommendations.card3.text": "Support information design decisions with journey diaries, effort maps and on-site accessibility metrics.",
    "home.testimonials.title": "Shared testimonials",
    "home.testimonials.subtitle": "Perspectives collected from facility managers, UX practitioners and public infrastructure operators.",
    "home.testimonials.card1.quote": "Navigation gaps inside our museum were mapped with precision. The guidance clarified how to rethink our markers without overwhelming visitors.",
    "home.testimonials.card1.author": "Museum Director, Brussels",
    "home.testimonials.card2.quote": "The proposed journey model balanced evening transfer flows and made orientation clearer for occasional passengers.",
    "home.testimonials.card2.author": "Mobility Hub Manager, Liège",
    "home.testimonials.card3.quote": "Accessibility workshops exposed micro barriers we had never spotted. The recommended actions were prioritised with transparency.",
    "home.testimonials.card3.author": "Accessibility Coordination, Namur",
    "home.latest.title": "Recent analyses",
    "home.latest.subtitle": "Detailed readings on indoor navigation and spatial information architecture.",
    "home.latest.post1.title": "Structuring multi-level orientation",
    "home.latest.post1.excerpt": "Evaluating vertical signposting granularity, connecting elevators, stairs and digital platforms.",
    "home.latest.post2.title": "Ensuring reliable spatial data",
    "home.latest.post2.excerpt": "Methodology for collection, topological checking and dissemination of mapping updates.",
    "home.latest.post3.title": "Inclusive signage in hybrid contexts",
    "home.latest.post3.excerpt": "Blending visual, auditory and tactile guidance to support every user profile.",
    "buttons.readMore": "Read analysis",
    "services.hero.title": "Cartographed expertise areas",
    "services.hero.subtitle": "We craft methodological frameworks to understand spaces, guide audiences and structure digital assets.",
    "services.section1.title": "Spatial orientation needs assessment",
    "services.section1.p1": "We evaluate formal and informal routes, measure user cognitive load and pinpoint ambiguous zones. Diagnostics combine photo surveys, on-site interviews and density metrics.",
    "services.section1.p2": "Results feed a prioritised map: landmark hierarchy, main axes, information relays and accessibility-related friction points.",
    "services.section2.title": "Designing digital wayfinding systems",
    "services.section2.p1": "We organise families of screens, interactive maps and mobile interfaces. The goal is to deliver synchronised reference points that adapt to attendance levels and operational scenarios.",
    "services.section2.p2": "Each device connects to a proven editorial backbone ensuring linguistic and visual consistency across every information layer.",
    "services.section3.title": "User journey modelling",
    "services.section3.p1": "We build primary and alternative journeys, evaluate traversal times and model lateral flows. Outputs include narrative maps and oriented diagrams.",
    "services.section3.p2": "Modelling supports decisions on signage volume, critical decision points and transfer management.",
    "services.section4.title": "Information design and legibility",
    "services.section4.p1": "Content structures follow progressive disclosure, with typographic selections attuned to lighting and viewing distance. We address hierarchy, contrast and pictogram consistency.",
    "services.section4.p2": "Recommendations come with static prototypes and contextual application examples.",
    "services.section5.title": "Spatial UX and accessibility research",
    "services.section5.p1": "Alongside associations and user groups, we document specific needs: tactile cues, audio prompts, high contrasts and progression rhythms.",
    "services.section5.p2": "Deliverables include evaluation frameworks, practice sheets and continuous improvement indicators.",
    "services.figure.alt": "Illustration displaying a circulation plan with stops and dynamic legend.",
    "about.hero.title": "Mapping experience within complex places",
    "about.hero.subtitle": "danswholesaleplants is based in Brussels and bridges research, design and documentation for dense public environments.",
    "about.intro.p1": "Our approach builds on real-life observations and converts insights into tangible information architectures. We collaborate with municipalities, cultural institutions, transport operators and universities.",
    "about.intro.p2": "Projects span pedestrian mobility, journey legibility, guidance interfaces and universal accessibility. We intervene from exploratory phases to structure shared decision frameworks.",
    "about.timeline.title": "Key milestones",
    "about.timeline.item1.title": "Founding danswholesaleplants",
    "about.timeline.item1.text": "Launch of a unit dedicated to spatial literacy for public buildings in the Brussels Region.",
    "about.timeline.item2.title": "First station audits",
    "about.timeline.item2.text": "Deployment of multi-support audits across three mobility nodes to recalibrate existing digital signage.",
    "about.timeline.item3.title": "Accessibility programme",
    "about.timeline.item3.text": "Co-designed workshops with associations to test journey legibility and prototype new tactile markers.",
    "about.timeline.item4.title": "Cartographic platform",
    "about.timeline.item4.text": "Creation of an interactive plan repository consolidating topological data and operational scenarios.",
    "about.values.title": "Guiding principles",
    "about.values.card1.title": "Immersive observation",
    "about.values.card1.text": "Every mission begins with sustained immersion that captures situated practices, rhythms and user trade-offs.",
    "about.values.card2.title": "Method transparency",
    "about.values.card2.text": "Hypotheses, metrics and sources are documented so organisations can replicate the analyses.",
    "about.values.card3.title": "System compatibility",
    "about.values.card3.text": "Recommendations are designed to interface with existing systems and ease phased integration.",
    "about.media.alt": "Interior view of a public building with clear signage and defined circulation areas.",
    "blog.hero.title": "Spatial readings",
    "blog.hero.subtitle": "Each article relies on field feedback, structured datasets and theoretical frameworks dedicated to orientation.",
    "blog.list.post1.category": "Flow analysis",
    "blog.list.post1.title": "Structuring multi-level orientation",
    "blog.list.post1.excerpt": "How to articulate vertical plans, sensory landmarks and connected devices in stratified buildings.",
    "blog.list.post2.category": "Spatial data",
    "blog.list.post2.title": "Ensuring reliable spatial data",
    "blog.list.post2.excerpt": "Collection strategies, topological validation and continuous roll-out for interior maps.",
    "blog.list.post3.category": "Accessibility",
    "blog.list.post3.title": "Inclusive digital signage",
    "blog.list.post3.excerpt": "Building accessible journeys by combining visual, audio and tactile guidance.",
    "blog.list.post4.category": "Indicators",
    "blog.list.post4.title": "Measuring hub performance",
    "blog.list.post4.excerpt": "Defining readable indicators to steer mobility experiences.",
    "blog.list.post5.category": "Refurbishment",
    "blog.list.post5.title": "Refurbishment with indoor navigation",
    "blog.list.post5.excerpt": "Embedding signage design during public space transformation phases.",
    "blog.card.alt1": "Architectural plan with multiple levels linked by circulation icons.",
    "blog.card.alt2": "Team reviewing an interactive plan projected on a wall.",
    "blog.card.alt3": "Tactile and visual signage integrated in a bright corridor.",
    "blog.card.alt4": "Dashboard displaying pedestrian flow indicators.",
    "blog.card.alt5": "Refurbishment plan of a district with guidance annotations.",
    "contact.hero.title": "Get in touch",
    "contact.hero.subtitle": "We analyse contexts, share tools and craft tailored frameworks that clarify complex spaces.",
    "contact.details.title": "Contact details",
    "contact.details.phoneLabel": "Phone",
    "contact.details.phoneValue": "+32 2 280 45 67",
    "contact.details.emailLabel": "Email",
    "contact.details.emailValue": "contact@danswholesaleplants.com",
    "contact.details.addressLabel": "Address",
    "contact.details.addressValue": "Rue de la Loi 155, 1040 Brussels, Belgium",
    "contact.details.hours": "Meetings by appointment from Monday to Friday.",
    "contact.form.title": "Contact form",
    "contact.form.nameLabel": "Full name",
    "contact.form.namePlaceholder": "Your name",
    "contact.form.emailLabel": "Email address",
    "contact.form.emailPlaceholder": "name@example.com",
    "contact.form.orgLabel": "Organisation",
    "contact.form.orgPlaceholder": "Structure or department",
    "contact.form.messageLabel": "Message",
    "contact.form.messagePlaceholder": "Describe your orientation and wayfinding needs…",
    "contact.form.submit": "Send and continue",
    "contact.map.title": "Location",
    "contact.map.caption": "danswholesaleplants location in Brussels shown on OpenStreetMap.",
    "faq.hero.title": "Recurring questions",
    "faq.hero.subtitle": "Clarifications about our approach, data collection and governance of orientation devices.",
    "faq.item1.question": "How do you model journeys in multi-level buildings?",
    "faq.item1.answer": "We combine lidar surveys, video journaling and workshops with front desk teams to map decision points. Models are validated via travel-time simulations.",
    "faq.item2.question": "Which deliverables include monitoring indicators?",
    "faq.item2.answer": "Interactive plans, editorial guides and scenario grids include legibility, cognitive load and update responsiveness indicators.",
    "faq.item3.question": "How is universal accessibility integrated?",
    "faq.item3.answer": "Each assessment covers mobility, sensory and cognitive requirements. Recommendations reference contrast, tactile signage, audio prompts and alternative supports.",
    "faq.item4.question": "Do you work with existing client data?",
    "faq.item4.answer": "Yes, we audit plan quality, realign information layers and ensure traceability between internal sources and field observations.",
    "faq.item5.question": "How do you collaborate with architects?",
    "faq.item5.answer": "We act as a complement, bringing a user-oriented perspective. Deliverables align with architectural design phases.",
    "faq.item6.question": "How do you secure updates for digital devices?",
    "faq.item6.answer": "We define administration protocols, editorial checklists and triggers based on changing circulation scenarios.",
    "terms.hero.title": "Terms of use",
    "terms.hero.subtitle": "Contractual framework for accessing and using content on danswholesaleplants.",
    "terms.section1.title": "1. Purpose",
    "terms.section1.content": "These terms define access conditions to content, resources and documents published by danswholesaleplants on danswholesaleplants.com.",
    "terms.section2.title": "2. Acceptance",
    "terms.section2.content": "Visiting the site implies full acceptance of these terms. If you disagree, please discontinue browsing.",
    "terms.section3.title": "3. Availability",
    "terms.section3.content": "The site is available 24/7 subject to technical interruptions required for maintenance or content updates.",
    "terms.section4.title": "4. Intellectual property",
    "terms.section4.content": "Texts, diagrams, images and information structures are protected. Reproduction requires prior written consent.",
    "terms.section5.title": "5. Permitted use",
    "terms.section5.content": "Content is provided for documentation and analysis. Any diffusion must reference the source and preserve integrity.",
    "terms.section6.title": "6. Liability",
    "terms.section6.content": "danswholesaleplants strives for accuracy yet users remain responsible for how they use the information.",
    "terms.section7.title": "7. External links",
    "terms.section7.content": "Links to third-party resources are for information. danswholesaleplants is not accountable for their content.",
    "terms.section8.title": "8. Personal data",
    "terms.section8.content": "Processing of contact form data is described in the privacy policy and complies with GDPR requirements.",
    "terms.section9.title": "9. Cookies",
    "terms.section9.content": "Cookie usage is detailed in the dedicated policy. Users can adjust preferences via the consent module.",
    "terms.section10.title": "10. Changes",
    "terms.section10.content": "danswholesaleplants may amend these terms. Updates apply once published.",
    "terms.section11.title": "11. Governing law",
    "terms.section11.content": "These terms are governed by Belgian law. Brussels courts have jurisdiction over disputes.",
    "terms.section12.title": "12. Severability",
    "terms.section12.content": "If any clause is invalid, remaining provisions continue to apply.",
    "terms.section13.title": "13. Legal contact",
    "terms.section13.content": "For questions about these terms, please reach us via the Contact page.",
    "terms.section14.title": "14. Effective date",
    "terms.section14.content": "These terms have been effective since 2 January 2024 until a new version is issued.",
    "privacy.hero.title": "Privacy policy",
    "privacy.hero.subtitle": "Management of personal data collected on danswholesaleplants.com.",
    "privacy.section1.title": "1. Data controller",
    "privacy.section1.content": "The controller is danswholesaleplants, Rue de la Loi 155, 1040 Brussels, Belgium.",
    "privacy.section2.title": "2. Data collected",
    "privacy.section2.content": "Contact form submissions include name, email, organisation and message content.",
    "privacy.section3.title": "3. Purpose",
    "privacy.section3.content": "Information is used to respond to enquiries, schedule meetings and ensure follow-up.",
    "privacy.section4.title": "4. Legal basis",
    "privacy.section4.content": "Processing relies on legitimate interest to answer professional requests and explicit consent when submitting the form.",
    "privacy.section5.title": "5. Retention",
    "privacy.section5.content": "Data is stored for up to two years after the last exchange, unless legal obligations require otherwise.",
    "privacy.section6.title": "6. Sharing",
    "privacy.section6.content": "Data is not sold to third parties. Hosting occurs on servers located within the European Union.",
    "privacy.section7.title": "7. Rights",
    "privacy.section7.content": "Individuals may request access, rectification, restriction or deletion by using the contact details provided.",
    "privacy.section8.title": "8. Security",
    "privacy.section8.content": "Technical and organisational measures protect confidentiality and integrity of the information.",
    "privacy.section9.title": "9. Cookies",
    "privacy.section9.content": "Cookie management is detailed in the dedicated policy and adjustable through the consent module.",
    "privacy.section10.title": "10. Contact",
    "privacy.section10.content": "To exercise rights or ask questions, write to contact@danswholesaleplants.com.",
    "cookies.hero.title": "Cookie policy",
    "cookies.hero.subtitle": "Operation, purpose and management of cookies used on danswholesaleplants.com.",
    "cookies.intro": "The site relies on strictly necessary and optional cookies to measure audience and refine content presentation.",
    "cookies.table.heading.name": "Cookie name",
    "cookies.table.heading.provider": "Provider",
    "cookies.table.heading.type": "Type",
    "cookies.table.heading.purpose": "Purpose",
    "cookies.table.heading.duration": "Duration",
    "cookies.table.row1.name": "site_session",
    "cookies.table.row1.provider": "danswholesaleplants",
    "cookies.table.row1.type": "Necessary",
    "cookies.table.row1.purpose": "Maintains language and navigation preferences.",
    "cookies.table.row1.duration": "Session",
    "cookies.table.row2.name": "analytics_opt",
    "cookies.table.row2.provider": "danswholesaleplants",
    "cookies.table.row2.type": "Analytics",
    "cookies.table.row2.purpose": "Aggregated attendance monitoring to improve content.",
    "cookies.table.row2.duration": "6 months",
    "cookies.table.row3.name": "pref_layout",
    "cookies.table.row3.provider": "danswholesaleplants",
    "cookies.table.row3.type": "Preferences",
    "cookies.table.row3.purpose": "Stores display and contrast settings.",
    "cookies.table.row3.duration": "6 months",
    "cookies.table.row4.name": "camp_context",
    "cookies.table.row4.provider": "danswholesaleplants",
    "cookies.table.row4.type": "Marketing",
    "cookies.table.row4.purpose": "Understands traffic sources to contextualise publications.",
    "cookies.table.row4.duration": "3 months",
    "cookies.manage.title": "Managing preferences",
    "cookies.manage.desc": "You may adjust your choices at any time via the consent module available at the bottom of the page.",
    "refund.hero.title": "Cancellation policy",
    "refund.hero.subtitle": "Adjustment terms for intellectual services delivered by danswholesaleplants.",
    "refund.section1.title": "1. Scope",
    "refund.section1.content": "This policy applies to consulting, analysis and documentation assignments performed by danswholesaleplants.",
    "refund.section2.title": "2. Notice",
    "refund.section2.content": "Requests for cancellation or change must be submitted in writing to contact@danswholesaleplants.com.",
    "refund.section3.title": "3. Lead time",
    "refund.section3.content": "Adjustments are possible up to fifteen business days before the planned delivery of an interim deliverable.",
    "refund.section4.title": "4. Work performed",
    "refund.section4.content": "Completed analyses and documented work remain due. A detailed task log is available on request.",
    "refund.section5.title": "5. Rescheduling",
    "refund.section5.content": "Rescheduling depends on team availability and results in an updated timeline.",
    "refund.section6.title": "6. External collaboration",
    "refund.section6.content": "When associated experts are involved, specific cancellation terms are communicated beforehand.",
    "refund.section7.title": "7. Delivered documentation",
    "refund.section7.content": "Documents already provided remain usable according to contractual terms.",
    "refund.section8.title": "8. Force majeure",
    "refund.section8.content": "In the event of unforeseen circumstances preventing the mission, parties agree on an adapted action plan.",
    "refund.section9.title": "9. Communication",
    "refund.section9.content": "A status meeting is offered to clarify progress and potential next steps.",
    "refund.section10.title": "10. Contact",
    "refund.section10.content": "For questions, refer to the Contact page listing preferred exchange channels.",
    "disclaimer.hero.title": "Disclaimer",
    "disclaimer.hero.subtitle": "Framing the interpretation limits of content published on danswholesaleplants.com.",
    "disclaimer.section1.title": "1. Information nature",
    "disclaimer.section1.content": "Content delivers general analyses and does not replace a study tailored to a specific context.",
    "disclaimer.section2.title": "2. No guarantee",
    "disclaimer.section2.content": "danswholesaleplants does not guarantee completeness or permanent accuracy of online information.",
    "disclaimer.section3.title": "3. Use",
    "disclaimer.section3.content": "Users remain responsible for interpretations and decisions based on consulted content.",
    "disclaimer.section4.title": "4. Third-party references",
    "disclaimer.section4.content": "Cited third parties are mentioned for context and do not imply formal agreement or endorsement.",
    "disclaimer.section5.title": "5. Updates",
    "disclaimer.section5.content": "Information may change without notice to reflect evolving work and publications.",
    "disclaimer.section6.title": "6. Contact",
    "disclaimer.section6.content": "For clarifications, use the contact form available on the site.",
    "thank.hero.title": "Thank you for your message",
    "thank.hero.subtitle": "Your request has been transmitted. We will reply after reviewing the context.",
    "thank.content": "A confirmation will also be sent if all contact details were provided.",
    "footer.tagline": "Spatial orientation frameworks and mapping for complex environments.",
    "footer.phoneLabel": "Phone:",
    "footer.emailLabel": "Email:",
    "footer.addressLabel": "Address:",
    "footer.addressValue": "Rue de la Loi 155, 1040 Brussels, Belgium",
    "footer.rightsPrefix": "©",
    "footer.rightsSuffix": "danswholesaleplants. All rights reserved.",
    "footer.terms": "Terms of Use",
    "footer.privacy": "Privacy Policy",
    "footer.cookies": "Cookie Policy",
    "footer.refund": "Cancellation Policy",
    "footer.disclaimer": "Disclaimer",
    "cookie.bannerTitle": "Cookie management",
    "cookie.bannerDescription": "We use cookies to understand usage and improve clarity. You may personalise your choices.",
    "cookie.moreLink": "Read the cookie policy",
    "cookie.toggle.necessary": "Necessary",
    "cookie.toggle.necessaryDesc": "Essential for site operation and saving your preferences.",
    "cookie.toggle.preferences": "Preferences",
    "cookie.toggle.preferencesDesc": "Stores display and contrast settings.",
    "cookie.toggle.analytics": "Analytics",
    "cookie.toggle.analyticsDesc": "Aggregated audience measurement to enhance content.",
    "cookie.toggle.marketing": "Contextual",
    "cookie.toggle.marketingDesc": "Understands traffic sources to contextualise publications.",
    "cookie.actions.accept": "Accept all",
    "cookie.actions.decline": "Decline all",
    "cookie.actions.save": "Save",
    "toast.formError": "Please verify required fields before sending.",
    "toast.formSubmit": "Your message is being forwarded to the team.",
    "toast.preferencesSaved": "Your cookie preferences have been updated.",
    "toast.preferencesDeclined": "Optional cookies are now disabled.",
    "toast.preferencesAccepted": "All cookies are now enabled.",
    "blog.post1.h1": "Structuring multi-level orientation",
    "blog.post1.h2a": "Analysing vertical journeys",
    "blog.post1.h3a": "Observing landmark distribution",
    "blog.post1.p1": "Multi-level environments require treating verticality as an information channel. Stations or hospital campuses demand that users remember the sequence of transitions between elevators, stairs and walkways. We start with a three-dimensional map that records decision points, open views and dense zones. Each marker is positioned according to perceived efficiency, long-range visibility and redundancy with other supports. This reading forms a strong foundation for prioritising interventions and steering flows towards clearly identified cores.",
    "blog.post1.p2": "Special focus is placed on convergence areas where trajectories intersect from several angles. The goal is to limit cognitive overload across exchange platforms while documenting explicit alternatives. Simulations covering varied traffic scenarios highlight critical time frames. These results feed the design of vertical plans and the coordination between physical signage and digital devices installed on site.",
    "blog.post1.h2b": "Synchronising physical and digital media",
    "blog.post1.h3b": "Layering information levels",
    "blog.post1.p3": "Synchronisation relies on a finely tiered editorial structure. Physical markers such as totems and suspended panels deliver concise, stable information. Digital screens provide flexible, contextual messages aligned with time, events or exceptional attendance. Consistency is secured through a shared reference describing vocabulary, graphic syntax and permissible installation zones.",
    "blog.post1.p4": "In a Brussels administrative centre we measured alignment between digital announcements and observed flows. Gaps emerged through matrices cross-referencing audience type, destination and medium consulted. The final deliverable proposed a weekly validation path ensuring broadcast information matches the actual spatial configuration.",
    "blog.post1.h2c": "Measuring journey effectiveness",
    "blog.post1.h3c": "Building on usage feedback",
    "blog.post1.p5": "Effectiveness is evaluated through both perceived ease and travel times. Situated interviews captured quotes on how level changes are understood, especially by first-time visitors. Feedback was combined with anonymised movement logs to identify discrepancies between intended and actual routes.",
    "blog.post1.p6": "Findings underline the need to consolidate landmarks at entry points, multiply visual reminders before major bifurcations and use digital devices as safety nets. Continuous flow modelling sustains guidance quality over time.",
    "blog.post2.h1": "Ensuring reliable spatial data for indoor navigation",
    "blog.post2.h2a": "Collecting foundational data",
    "blog.post2.h3a": "Building a robust repository",
    "blog.post2.p1": "Interactive maps only make sense when underlying data is controlled. We inventory levels, functional zones and circulations. Surveys combine existing sources such as safety plans, BIM files and topographic records. Each layer is cleansed to remove duplicates and harmonise nomenclatures.",
    "blog.post2.p2": "A validation grid checks data integrity. It relies on simple rules: circulation continuity, attribute consistency, absence of orphan areas. This ensures future digital tools rest on a stable, maintainable base.",
    "blog.post2.h2b": "Structuring the update chain",
    "blog.post2.h3b": "Documenting clear protocols",
    "blog.post2.p3": "Updates represent a key credibility challenge. We establish a clear chain: field teams report changes, a mapping lead validates them, deployment occurs in the publication tool. Each step is traceable for reversibility and understanding.",
    "blog.post2.p4": "Within a library network we defined quarterly verification cycles. Collection moves, works or temporary circulation changes are integrated without delay. The protocol includes checklists and structured communication to front-desk teams.",
    "blog.post2.h2c": "Distributing information to users",
    "blog.post2.h3c": "Maintaining readable, trustworthy data",
    "blog.post2.p5": "Distribution spans tactile kiosks, printed versions, micro-displays and web integrations. Each medium carries an appropriate detail level. Contextual items such as estimated walking times or temporary constraints stay current thanks to synchronised feeds.",
    "blog.post2.p6": "Reliability is strengthened through automated controls: floor links must remain active, pictograms follow a shared nomenclature and colours respect contrast guidelines. These components foster user trust in the devices.",
    "blog.post3.h1": "Building inclusive digital signage",
    "blog.post3.h2a": "Addressing diverse profiles",
    "blog.post3.h3a": "Crossing perception modes",
    "blog.post3.p1": "Inclusion in digital signage means acknowledging varied ways of perceiving space. We combine visual, audio and tactile cues so orientation does not rely on a single sensory channel. Workshops with mixed audiences reveal obstacles linked to insufficient contrast, text-heavy messages or unmarked journeys.",
    "blog.post3.p2": "Insights feed design briefs. Screens offer adjustable contrast levels and reformulated messages. Audio sequences are synchronised with visual hints to reinforce comprehension.",
    "blog.post3.h2b": "Orchestrating media complementarity",
    "blog.post3.h3b": "Ensuring sensory continuity",
    "blog.post3.p3": "Digital devices interact with physical cues such as guidance strips, tactile pictograms and colour codes. Orchestration safeguards sensory continuity, supporting people moving at different paces.",
    "blog.post3.p4": "In a renovated media library, welcome screens were paired with tactile maps and audio notifications. This trio offers multiple access paths to identical information, reducing exclusion risks for partially perceiving visitors.",
    "blog.post3.h2c": "Evaluating and refining",
    "blog.post3.h3c": "Measuring user impact",
    "blog.post3.p5": "Evaluation occurs through real-life tests. Journeys are timed and interviews document cognitive load and clarity. Feedback informs iterative adjustments, from icon calibration to instruction phrasing.",
    "blog.post3.p6": "Results show that combining coherent signals increases trust in digital devices. Ongoing attention keeps improvements relevant as usage evolves.",
    "blog.post4.h1": "Measuring urban hub performance",
    "blog.post4.h2a": "Identifying core metrics",
    "blog.post4.h3a": "Linking flows and perception",
    "blog.post4.p1": "Urban hubs channel intense flows requiring precise steering. Indicators must reflect both movement fluidity and qualitative perception. We articulate quantitative data such as travel time and zone density with quick interviews capturing subjective experience.",
    "blog.post4.p2": "This hybrid approach reveals gaps between performance and perception. A fast itinerary can feel complex if it multiplies bifurcations. Indicators thus become a shared language connecting operations teams and information designers.",
    "blog.post4.h2b": "Consolidating dashboards",
    "blog.post4.h3b": "Framing legible reports",
    "blog.post4.p3": "Dashboards draw on structured data, highlighting watch zones, sensitive schedules and accessibility priorities. Visual language aligns with on-site signage to support staff comprehension.",
    "blog.post4.p4": "A Brussels multimodal hub now uses a monthly grid combining attendance data, reported incidents and user feedback. Decisions on adding markers or repositioning screens are evidence-based.",
    "blog.post4.h2c": "Embedding continuous improvement",
    "blog.post4.h3c": "Activating field feedback",
    "blog.post4.p5": "Continuous improvement depends on dialogue with field teams. Frontline staff document recurring misunderstandings. These observations merge with quantitative data to prioritise actions.",
    "blog.post4.p6": "The cycle concludes with restitution workshops involving users and operators. Indicators support brainstorming of new scenarios and testing of signage prototypes.",
    "blog.post5.h1": "Refurbishing public spaces with indoor navigation",
    "blog.post5.h2a": "Anticipating journey transformation",
    "blog.post5.h3a": "Mapping overlapping uses",
    "blog.post5.p1": "Refurbishing a public facility reshapes well-established journeys. Before works begin we analyse current practices: paths, dwell points, service sequences. Mapping highlights sensitive areas requiring dedicated support measures.",
    "blog.post5.p2": "Work scenarios are simulated to forecast detours. Digital signage then relays information about phases, alternative itineraries and reassurance for recurring users.",
    "blog.post5.h2b": "Coordinating communication and signage",
    "blog.post5.h3b": "Maintaining clarity during works",
    "blog.post5.p3": "Construction communication aligns with signage. Screens, posters and mediation staff share vocabulary to prevent conflicting messages. Temporary supports are pre-designed and tested through scaled prototypes.",
    "blog.post5.p4": "A library renovation adopted an information kit comprising updated plans, temporary pictograms and audio messages. This coherence across media avoided service breaks at critical stages.",
    "blog.post5.h2c": "Building post-reopening capital",
    "blog.post5.h3c": "Embedding learnings long-term",
    "blog.post5.p5": "Once refurbishment is complete, lessons learned are consolidated. New journeys are assessed for legibility, accessibility and ability to absorb special events.",
    "blog.post5.p6": "Insights feed an internal reference for future evolutions. This operational memory keeps indoor navigation consistent over time.",
    "post1.hero.alt": "Escalators and elevators linked by luminous directional panels.",
    "post2.hero.alt": "Specialists reviewing mapping data across multiple screens.",
    "post3.hero.alt": "Digital signage displaying instructions in visual and tactile formats.",
    "post4.hero.alt": "Urban hub view with pedestrian flows and real-time displays.",
    "post5.hero.alt": "Refurbishment plan with highlighted temporary circulation routes.",
    "thank.link.home": "Back to home",
    "thank.link.blog": "View analyses",
    "contact.requiredNotice": "Fields marked with an asterisk are required.",
    "form.required": "Required field",
    "form.emailInvalid": "Please provide a valid email address."
  }
};

let currentLanguage = localStorage.getItem("site_lang") || DEFAULT_LANG;

function getTranslation(lang, key) {
  const dict = I18N[lang];
  if (dict && Object.prototype.hasOwnProperty.call(dict, key)) {
    return dict[key];
  }
  const fallbackDict = I18N[DEFAULT_LANG];
  if (fallbackDict && Object.prototype.hasOwnProperty.call(fallbackDict, key)) {
    return fallbackDict[key];
  }
  return "";
}

function applyTranslations(lang) {
  document.documentElement.setAttribute("lang", lang);
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.textContent = translation;
    }
  });
  document.querySelectorAll("[data-i18n-html]").forEach((el) => {
    const key = el.getAttribute("data-i18n-html");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.innerHTML = translation;
    }
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("placeholder", translation);
    }
  });
  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("alt", translation);
    }
  });
  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria-label");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("aria-label", translation);
    }
  });
  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.textContent = translation;
    }
  });
  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.getAttribute("data-i18n-meta");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("content", translation);
    }
  });
  document.querySelectorAll("[data-i18n-value]").forEach((el) => {
    const key = el.getAttribute("data-i18n-value");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("value", translation);
    }
  });
  document.querySelectorAll("[data-current-year]").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });
  updateLanguageToggle(lang);
}

function updateLanguageToggle(lang) {
  document.querySelectorAll(".language-toggle button").forEach((btn) => {
    const btnLang = btn.getAttribute("data-lang");
    if (btnLang === lang) {
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
}

function switchLanguage(lang) {
  currentLanguage = lang;
  localStorage.setItem("site_lang", lang);
  applyTranslations(lang);
}

function initLanguageToggle() {
  document.querySelectorAll(".language-toggle button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.getAttribute("data-lang");
      if (lang && lang !== currentLanguage) {
        switchLanguage(lang);
      }
    });
  });
}

function initNavigation() {
  const navToggle = document.querySelector(".nav-toggle");
  const navList = document.querySelector(".primary-nav ul");
  if (navToggle && navList) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navList.classList.toggle("open");
    });
    navList.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navList.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }
  const header = document.querySelector(".site-header");
  if (header) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 40) {
        header.classList.add("scrolled");
      } else {
        header.classList.remove("scrolled");
      }
    });
  }
}

function initScrollAnimations() {
  const animatedElements = document.querySelectorAll(".animate-on-scroll");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  animatedElements.forEach((el) => observer.observe(el));
}

const toastContainer = document.createElement("div");
toastContainer.className = "toast-container";
document.addEventListener("DOMContentLoaded", () => {
  document.body.appendChild(toastContainer);
});

function showToast(key, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast ${type === "error" ? "error" : "success"}`;
  toast.textContent = getTranslation(currentLanguage, key);
  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("fade-out");
    toast.addEventListener("transitionend", () => {
      toast.remove();
    });
    toast.remove();
  }, 3200);
}

function initContactForm() {
  const form = document.querySelector("[data-form-contact]");
  if (!form) return;
  form.setAttribute("novalidate", "true");
  form.addEventListener("submit", (event) => {
    const nameField = form.querySelector("[name='name']");
    const emailField = form.querySelector("[name='email']");
    const messageField = form.querySelector("[name='message']");
    let valid = true;

    if (!nameField.value.trim()) {
      valid = false;
      nameField.setCustomValidity(getTranslation(currentLanguage, "form.required"));
    } else {
      nameField.setCustomValidity("");
    }

    if (!emailField.value.trim()) {
      valid = false;
      emailField.setCustomValidity(getTranslation(currentLanguage, "form.required"));
    } else if (!/\S+@\S+\.\S+/.test(emailField.value.trim())) {
      valid = false;
      emailField.setCustomValidity(getTranslation(currentLanguage, "form.emailInvalid"));
    } else {
      emailField.setCustomValidity("");
    }

    if (!messageField.value.trim()) {
      valid = false;
      messageField.setCustomValidity(getTranslation(currentLanguage, "form.required"));
    } else {
      messageField.setCustomValidity("");
    }

    if (!valid) {
      event.preventDefault();
      showToast("toast.formError", "error");
    } else {
      showToast("toast.formSubmit", "success");
    }
  });
}

function saveConsent(consent) {
  localStorage.setItem("cookie_consent", JSON.stringify(consent));
}

function getConsent() {
  const stored = localStorage.getItem("cookie_consent");
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch (e) {
    return null;
  }
}

function updateCookieUI(consent) {
  const preferencesToggle = document.querySelector("[data-cookie-toggle='preferences']");
  const analyticsToggle = document.querySelector("[data-cookie-toggle='analytics']");
  const marketingToggle = document.querySelector("[data-cookie-toggle='marketing']");
  if (preferencesToggle) preferencesToggle.checked = !!consent?.preferences;
  if (analyticsToggle) analyticsToggle.checked = !!consent?.analytics;
  if (marketingToggle) marketingToggle.checked = !!consent?.marketing;
}

function setCookieBannerVisibility(show) {
  const banner = document.querySelector("[data-cookie-banner]");
  if (!banner) return;
  if (show) {
    banner.classList.add("is-visible");
  } else {
    banner.classList.remove("is-visible");
  }
}

function initCookieBanner() {
  const banner = document.querySelector("[data-cookie-banner]");
  if (!banner) return;
  const acceptBtn = banner.querySelector("[data-cookie-action='accept']");
  const declineBtn = banner.querySelector("[data-cookie-action='decline']");
  const saveBtn = banner.querySelector("[data-cookie-action='save']");
  const consent = getConsent();

  if (consent) {
    updateCookieUI(consent);
    setCookieBannerVisibility(false);
  } else {
    setCookieBannerVisibility(true);
  }

  acceptBtn?.addEventListener("click", () => {
    const newConsent = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      decidedAt: new Date().toISOString()
    };
    saveConsent(newConsent);
    updateCookieUI(newConsent);
    setCookieBannerVisibility(false);
    showToast("toast.preferencesAccepted", "success");
  });

  declineBtn?.addEventListener("click", () => {
    const newConsent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      decidedAt: new Date().toISOString()
    };
    saveConsent(newConsent);
    updateCookieUI(newConsent);
    setCookieBannerVisibility(false);
    showToast("toast.preferencesDeclined", "success");
  });

  saveBtn?.addEventListener("click", () => {
    const preferencesToggle = banner.querySelector("[data-cookie-toggle='preferences']");
    const analyticsToggle = banner.querySelector("[data-cookie-toggle='analytics']");
    const marketingToggle = banner.querySelector("[data-cookie-toggle='marketing']");
    const newConsent = {
      necessary: true,
      preferences: !!preferencesToggle?.checked,
      analytics: !!analyticsToggle?.checked,
      marketing: !!marketingToggle?.checked,
      decidedAt: new Date().toISOString()
    };
    saveConsent(newConsent);
    setCookieBannerVisibility(false);
    showToast("toast.preferencesSaved", "success");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  applyTranslations(currentLanguage);
  initLanguageToggle();
  initNavigation();
  initScrollAnimations();
  initContactForm();
  initCookieBanner();
});