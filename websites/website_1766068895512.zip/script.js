document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  if (navToggle) {
    navToggle.addEventListener('click', () => {
      const isOpen = document.body.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  const navLinks = document.querySelectorAll('.site-nav a');
  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      if (window.innerWidth < 768) {
        document.body.classList.remove('nav-open');
        if (navToggle) {
          navToggle.setAttribute('aria-expanded', 'false');
        }
      }
    });
  });

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineButton = cookieBanner.querySelector('[data-cookie="decline"]');
    const storedPreference = localStorage.getItem('cookieConsentKazNews');

    if (storedPreference) {
      cookieBanner.classList.add('hidden');
    }

    const hideBanner = () => {
      cookieBanner.classList.add('hidden');
    };

    if (acceptButton) {
      acceptButton.addEventListener('click', () => {
        localStorage.setItem('cookieConsentKazNews', 'accepted');
        hideBanner();
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', () => {
        localStorage.setItem('cookieConsentKazNews', 'declined');
        hideBanner();
      });
    }
  }

  const contactForms = document.querySelectorAll('.contact-form');
  contactForms.forEach((form) => {
    const messageBox = form.querySelector('.form-message');
    form.addEventListener('submit', (event) => {
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      event.preventDefault();
      if (messageBox) {
        messageBox.textContent = 'Хабарламаңыз сәтті жіберілді. Біз жақын уақытта жауап береміз.';
        messageBox.classList.add('visible');
      }
      form.reset();
    });
  });
});