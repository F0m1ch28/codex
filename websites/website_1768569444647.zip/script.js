document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.menu-toggle');
    const navGroup = document.querySelector('.nav-group');
    const navLinks = document.querySelectorAll('.primary-nav a');
    if (navToggle && navGroup) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-open');
            navGroup.classList.toggle('is-open');
        });
        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                if (navGroup.classList.contains('is-open')) {
                    navGroup.classList.remove('is-open');
                    navToggle.classList.remove('is-open');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const storageKey = 'trotueeuCookieConsent';

    if (cookieBanner) {
        const savedPreference = localStorage.getItem(storageKey);
        if (savedPreference) {
            cookieBanner.classList.add('is-hidden');
        }

        const handleChoice = (choice) => {
            localStorage.setItem(storageKey, choice);
            cookieBanner.classList.add('is-hidden');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleChoice('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleChoice('declined'));
        }
    }
});