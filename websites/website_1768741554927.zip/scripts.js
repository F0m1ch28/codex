document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            siteNav.classList.toggle('active');
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navToggle.classList.remove('active');
                    siteNav.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptButton = document.getElementById('cookieAccept');
    const declineButton = document.getElementById('cookieDecline');
    const consent = localStorage.getItem('variantyCookieConsent');

    if (cookieBanner && !consent) {
        cookieBanner.classList.add('active');
    }

    if (acceptButton) {
        acceptButton.addEventListener('click', () => {
            localStorage.setItem('variantyCookieConsent', 'accepted');
            cookieBanner.classList.remove('active');
        });
    }

    if (declineButton) {
        declineButton.addEventListener('click', () => {
            localStorage.setItem('variantyCookieConsent', 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});