```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#E6ECF6',
          100: '#CBD8EE',
          200: '#A8BDE2',
          300: '#7D9FD5',
          400: '#567FC7',
          500: '#2563EB',
          600: '#1F3A6F',
          700: '#17315C',
          800: '#11284A',
          900: '#0F172A'
        },
        neutral: {
          50: '#F8FAFC',
          100: '#E2E8F0',
          200: '#CBD5E1',
          300: '#94A3B8',
          400: '#64748B',
          500: '#475569',
          600: '#334155',
          700: '#1E293B',
          800: '#0F172A'
        }
      },
      fontFamily: {
        heading: ['"DM Sans"', 'sans-serif'],
        body: ['Inter', 'sans-serif']
      },
      boxShadow: {
        brand: '0 20px 60px -25px rgba(31, 58, 111, 0.45)'
      },
      backgroundImage: {
        'hero-gradient': 'radial-gradient(circle at top left, rgba(37,99,235,0.18), rgba(15,23,42,0.75))',
        'card-gradient': 'linear-gradient(135deg, rgba(255,255,255,0.92), rgba(226,232,240,0.75))'
      }
    },
  },
  plugins: [],
}
```