```tsx
import { FormEvent, useState } from 'react'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { FiSend, FiMapPin, FiPhone, FiMail } from 'react-icons/fi'

const Footer = () => {
  const { t } = useTranslation()
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!email.trim()) return
    setSubmitted(true)
    setEmail('')
  }

  return (
    <footer className="relative overflow-hidden bg-primary-900 text-neutral-100">
      <div className="absolute inset-0 opacity-40">
        <div className="absolute -left-32 top-0 h-64 w-64 rounded-full bg-primary-500 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-primary-600 blur-3xl" />
      </div>
      <div className="container-section relative py-16">
        <div className="grid gap-12 lg:grid-cols-4">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-3 rounded-2xl bg-white/10 px-4 py-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-lg font-bold text-primary-700">
                TPH
              </div>
              <div>
                <p className="font-heading text-xl font-semibold text-white">Tu Progreso Hoy</p>
                <p className="text-sm text-neutral-200">{t('footer.companyDescription')}</p>
              </div>
            </div>
            <div className="space-y-3 text-sm text-neutral-300">
              <p className="flex items-center gap-3">
                <FiMapPin aria-hidden="true" />
                <span>{t('common.address')}</span>
              </p>
              <p className="flex items-center gap-3">
                <FiPhone aria-hidden="true" />
                <a className="hover:text-white" href="tel:+541155551234">
                  {t('common.phone')}
                </a>
              </p>
              <p className="flex items-center gap-3">
                <FiMail aria-hidden="true" />
                <a className="hover:text-white" href="mailto:hola@tuprogresohoy.com">
                  hola@tuprogresohoy.com
                </a>
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white">{t('footer.explore')}</h3>
            <ul className="mt-4 space-y-3 text-sm text-neutral-300">
              <li>
                <Link to="/" className="hover:text-white">
                  {t('nav.home')}
                </Link>
              </li>
              <li>
                <Link to="/inflation" className="hover:text-white">
                  {t('nav.inflation')}
                </Link>
              </li>
              <li>
                <Link to="/course" className="hover:text-white">
                  {t('nav.course')}
                </Link>
              </li>
              <li>
                <Link to="/resources" className="hover:text-white">
                  {t('nav.resources')}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white">
                  {t('nav.contact')}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white">{t('footer.legal')}</h3>
            <ul className="mt-4 space-y-3 text-sm text-neutral-300">
              <li>
                <Link to="/privacy" className="hover:text-white">
                  Privacy
                </Link>
              </li>
              <li>
                <Link to="/cookies" className="hover:text-white">
                  Cookies
                </Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-white">
                  Terms
                </Link>
              </li>
            </ul>
            <div className="mt-6">
              <p className="text-sm font-semibold text-white">{t('footer.hours')}</p>
              <p className="text-sm text-neutral-300">Lunes a viernes · 9:00 - 18:00 (GMT-3)</p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white">{t('footer.newsletter')}</h3>
            <p className="mt-3 text-sm text-neutral-300">
              {t('home.newsletterSubtitle')}
            </p>
            <form onSubmit={handleSubmit} className="mt-4 space-y-3">
              <label htmlFor="footer-email" className="sr-only">
                {t('footer.newsletterPlaceholder')}
              </label>
              <input
                id="footer-email"
                type="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder={t('footer.newsletterPlaceholder')}
                className="w-full rounded-xl border border-white/30 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-neutral-400 focus:border-white focus:outline-none focus:ring-2 focus:ring-white/70"
              />
              <button
                type="submit"
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-white px-4 py-3 text-sm font-semibold text-primary-700 transition hover:-translate-y-0.5 hover:bg-neutral-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <FiSend aria-hidden="true" />
                {t('footer.newsletterButton')}
              </button>
              {submitted && (
                <p className="text-xs text-neutral-200" aria-live="polite">
                  {t('home.newsletterSuccess')}
                </p>
              )}
            </form>
          </div>
        </div>
        <div className="mt-12 text-center text-xs text-neutral-400">
          © {new Date().getFullYear()} Tu Progreso Hoy. Derechos reservados.
        </div>
      </div>
    </footer>
  )
}

export default Footer
```