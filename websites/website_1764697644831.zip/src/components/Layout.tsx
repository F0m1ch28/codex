```tsx
import { useState } from 'react'
import { NavLink, Link, useLocation } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { FiMenu, FiX, FiGlobe, FiArrowUpRight } from 'react-icons/fi'
import CookieBanner from './CookieBanner'
import Footer from './Footer'

type LayoutProps = {
  children: React.ReactNode
}

const Layout = ({ children }: LayoutProps) => {
  const { t, i18n } = useTranslation()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const location = useLocation()

  const navItems = [
    { path: '/', label: t('nav.home') },
    { path: '/inflation', label: t('nav.inflation') },
    { path: '/course', label: t('nav.course') },
    { path: '/resources', label: t('nav.resources') },
    { path: '/contact', label: t('nav.contact') }
  ]

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'es' : 'en'
    i18n.changeLanguage(newLang)
  }

  const closeMenu = () => setIsMenuOpen(false)

  return (
    <div className="flex min-h-screen flex-col bg-neutral-50 text-neutral-800">
      <header className="sticky top-0 z-50 border-b border-white/50 bg-white/80 backdrop-blur">
        <div className="container-section">
          <div className="flex items-center justify-between py-4">
            <Link
              to="/"
              className="group flex items-center gap-3 rounded-xl bg-primary-500/10 px-3 py-2 text-neutral-900 transition hover:bg-primary-500/15"
              onClick={closeMenu}
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-500 text-lg font-semibold text-white shadow-brand transition group-hover:-translate-y-0.5">
                TPH
              </div>
              <div className="flex flex-col">
                <span className="font-heading text-lg font-semibold text-primary-900">
                  Tu Progreso Hoy
                </span>
                <span className="text-sm font-medium text-neutral-500">
                  ARS→USD Insights &nbsp;·&nbsp; Finance Education
                </span>
              </div>
            </Link>

            <div className="hidden items-center gap-8 lg:flex">
              <nav className="flex items-center gap-6">
                {navItems.map((item) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    className={({ isActive }) =>
                      [
                        'relative text-sm font-semibold transition',
                        isActive
                          ? 'text-primary-600'
                          : 'text-neutral-500 hover:text-primary-600'
                      ].join(' ')
                    }
                  >
                    {({ isActive }) => (
                      <>
                        {item.label}
                        {isActive && (
                          <span className="absolute -bottom-2 left-0 h-0.5 w-full rounded-full bg-primary-500" />
                        )}
                      </>
                    )}
                  </NavLink>
                ))}
              </nav>

              <span className="hidden items-center gap-2 rounded-full bg-primary-500/10 px-4 py-2 text-xs font-semibold uppercase tracking-widest text-primary-600 xl:flex">
                {t('layout.tagline')}
              </span>

              <button
                type="button"
                onClick={toggleLanguage}
                className="inline-flex items-center gap-2 rounded-xl border border-primary-500/30 bg-white px-4 py-2 text-sm font-semibold text-primary-700 transition hover:bg-primary-500/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
                aria-label="Toggle language"
              >
                <FiGlobe className="text-lg" />
                {i18n.language === 'en' ? 'ES' : 'EN'}
              </button>

              <Link
                to="/inflation"
                className="btn-primary hidden lg:inline-flex"
                onClick={closeMenu}
              >
                <span>{t('home.heroCtaPrimary')}</span>
                <FiArrowUpRight className="ml-2 text-lg" aria-hidden="true" />
              </Link>
            </div>

            <button
              type="button"
              className="inline-flex items-center justify-center rounded-xl border border-primary-500/20 p-2 text-primary-600 transition hover:bg-primary-500/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500 lg:hidden"
              onClick={() => setIsMenuOpen((prev) => !prev)}
              aria-expanded={isMenuOpen}
              aria-controls="mobile-menu"
              aria-label="Toggle navigation menu"
            >
              {isMenuOpen ? <FiX className="text-2xl" /> : <FiMenu className="text-2xl" />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <nav
            id="mobile-menu"
            className="border-t border-neutral-100 bg-white/95 px-4 py-6 shadow-lg shadow-primary-900/5 lg:hidden"
          >
            <ul className="space-y-4 text-base font-semibold text-neutral-600">
              {navItems.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    onClick={closeMenu}
                    className={({ isActive }) =>
                      [
                        'flex items-center justify-between rounded-xl border px-4 py-3 transition',
                        isActive
                          ? 'border-primary-500 bg-primary-500/10 text-primary-600'
                          : 'border-transparent bg-neutral-50 text-neutral-600 hover:border-primary-100 hover:bg-primary-500/5'
                      ].join(' ')
                    }
                  >
                    <span>{item.label}</span>
                    <FiArrowUpRight className="text-lg" aria-hidden="true" />
                  </NavLink>
                </li>
              ))}
              <li>
                <button
                  type="button"
                  onClick={() => {
                    toggleLanguage()
                    closeMenu()
                  }}
                  className="flex w-full items-center justify-between rounded-xl border border-primary-500/30 bg-white px-4 py-3 text-sm font-semibold text-primary-700 transition hover:bg-primary-500/10"
                >
                  <span>{i18n.language === 'en' ? 'Cambiar a español' : 'Switch to English'}</span>
                  <FiGlobe className="text-lg" aria-hidden="true" />
                </button>
              </li>
            </ul>
          </nav>
        )}
      </header>

      <main className="flex-1">{children}</main>

      <Footer />

      <div className="border-t border-neutral-100 bg-white/90 py-3 text-center text-xs font-medium text-neutral-500">
        {t('disclaimers.en')} &nbsp;|&nbsp; {t('disclaimers.es')} &nbsp;|&nbsp; {t('disclaimers.ru')}
      </div>

      <CookieBanner key={location.pathname} />
    </div>
  )
}

export default Layout
```