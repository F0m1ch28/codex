```tsx
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FiShield } from 'react-icons/fi'

const COOKIE_KEY = 'tph-cookie-consent'

const CookieBanner = () => {
  const { t } = useTranslation()
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const storedConsent = window.localStorage.getItem(COOKIE_KEY)
    if (!storedConsent) {
      setIsVisible(true)
    }
  }, [])

  const handleConsent = (value: 'accepted' | 'declined') => {
    window.localStorage.setItem(COOKIE_KEY, value)
    setIsVisible(false)
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[60] px-4 pb-4 sm:px-6 lg:px-8">
      <div className="mx-auto flex max-w-5xl flex-col gap-4 rounded-2xl border border-primary-500/20 bg-white p-5 shadow-2xl shadow-primary-900/10 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-start gap-3">
          <span className="mt-1 rounded-full bg-primary-500/10 p-2 text-primary-600">
            <FiShield aria-hidden="true" className="text-xl" />
          </span>
          <div>
            <p className="font-heading text-lg font-semibold text-primary-700">
              {t('cookie.title')}
            </p>
            <p className="mt-1 text-sm text-neutral-600">{t('cookie.message')}</p>
          </div>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <button
            type="button"
            onClick={() => handleConsent('declined')}
            className="inline-flex items-center justify-center rounded-xl border border-primary-500/40 px-5 py-2.5 text-sm font-semibold text-primary-600 transition hover:bg-primary-500/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
          >
            {t('cookie.decline')}
          </button>
          <button
            type="button"
            onClick={() => handleConsent('accepted')}
            className="inline-flex items-center justify-center rounded-xl bg-primary-500 px-6 py-2.5 text-sm font-semibold text-white shadow-brand transition hover:-translate-y-0.5 hover:bg-primary-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
          >
            {t('cookie.accept')}
          </button>
        </div>
      </div>
    </div>
  )
}

export default CookieBanner
```