```tsx
import { useTranslation } from 'react-i18next'

const TermsPage = () => {
  const { t } = useTranslation()

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section">
        <div className="mx-auto max-w-3xl space-y-6 rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
          <h1 className="text-3xl font-semibold text-primary-900">{t('legal.termsTitle')}</h1>
          <p className="text-sm text-neutral-600">{t('legal.termsIntro')}</p>
          <section className="space-y-4 text-sm text-neutral-600">
            <h2 className="text-lg font-semibold text-primary-800">1. Alcance del servicio</h2>
            <p>
              Tu Progreso Hoy ofrece datos y contenidos educativos para fortalecer tu criterio financiero. No brindamos
              asesoría financiera directa ni intermediamos en operaciones cambiarias o de inversión.
            </p>
            <h2 className="text-lg font-semibold text-primary-800">2. Uso responsable</h2>
            <p>
              Toda la información se entrega tal como es y puede cambiar sin previo aviso. Te recomendamos contrastar
              datos oficiales antes de tomar decisiones económicas. El acceso al curso requiere completar el proceso de
              doble confirmación.
            </p>
            <h2 className="text-lg font-semibold text-primary-800">3. Limitación de responsabilidad</h2>
            <p>
              No asumimos responsabilidad por pérdidas derivadas del uso de la información publicada. Nuestro objetivo es
              educativo y orientado a la toma de decisiones responsables, siempre bajo tu propio criterio.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}

export default TermsPage
```