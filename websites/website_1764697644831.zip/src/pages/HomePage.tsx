```tsx
import { FormEvent, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'
import { FiArrowUpRight, FiCheckCircle, FiTrendingUp, FiPieChart, FiLayers } from 'react-icons/fi'

const fixedTexts = [
  'Datos verificados para planificar tu presupuesto.',
  'Decisiones responsables, objetivos nítidos.',
  'Conocimiento financiero impulsado por tendencias.',
  'Pasos acertados hoy, mejor futuro mañana.',
  'Análisis transparentes y datos de mercado para decidir con seguridad.',
  'Información confiable que respalda elecciones responsables sobre tu dinero.',
  'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
  'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
  'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
]

type StatItem = {
  label: string
  value: string
  description: string
}

type ModuleItem = {
  title: string
  description: string
}

const HomePage = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [consent, setConsent] = useState(false)
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [message, setMessage] = useState<string | null>(null)

  const stats = useMemo(
    () => t('home.stats', { returnObjects: true }) as StatItem[],
    [t]
  )
  const modules = useMemo(
    () => t('home.modules', { returnObjects: true }) as ModuleItem[],
    [t]
  )

  const validateEmail = (value: string) => /\S+@\S+\.\S+/.test(value)

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!validateEmail(email) || !consent) {
      setStatus('error')
      setMessage(t('home.newsletterAlert'))
      return
    }

    setStatus('loading')
    setMessage(null)

    window.setTimeout(() => {
      window.localStorage.setItem('tph-double-opt-email', email)
      setStatus('success')
      setMessage(t('home.newsletterSuccess'))
      setEmail('')
      setConsent(false)
      navigate('/thank-you?source=newsletter', { state: { email } })
    }, 1200)
  }

  return (
    <div className="overflow-hidden">
      <section className="relative isolate">
        <div className="absolute inset-0 -z-10 bg-hero-gradient" />
        <div className="container-section">
          <div className="grid items-center gap-12 py-16 lg:grid-cols-2 lg:py-24">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <span className="badge-soft">{fixedTexts[0]}</span>
              <h1 className="text-4xl font-bold text-primary-900 sm:text-5xl">
                {t('home.heroTitle')}
              </h1>
              <p className="text-lg text-neutral-600">{t('home.heroSubtitle')}</p>
              <div className="rounded-2xl border border-primary-500/20 bg-white/70 p-4 shadow-brand backdrop-blur">
                <p className="text-sm font-semibold text-primary-600">
                  {t('home.heroCaption')}
                </p>
                <p className="mt-1 text-sm text-neutral-500">{fixedTexts[1]}</p>
              </div>

              <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                <Link to="/inflation" className="btn-primary">
                  {t('home.heroCtaPrimary')}
                  <FiArrowUpRight className="ml-2 text-lg" aria-hidden="true" />
                </Link>
                <Link to="/course" className="btn-secondary">
                  {t('home.heroCtaSecondary')}
                  <FiArrowUpRight className="ml-2 text-lg" aria-hidden="true" />
                </Link>
              </div>

              <ul className="mt-4 grid gap-2 text-sm text-neutral-600 sm:grid-cols-2">
                <li className="flex items-start gap-2">
                  <FiCheckCircle className="mt-1 text-primary-500" aria-hidden="true" />
                  <span>{fixedTexts[2]}</span>
                </li>
                <li className="flex items-start gap-2">
                  <FiCheckCircle className="mt-1 text-primary-500" aria-hidden="true" />
                  <span>{fixedTexts[3]}</span>
                </li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="relative"
            >
              <div className="card-glass p-6 sm:p-10">
                <div className="overflow-hidden rounded-2xl">
                  <img
                    src="https://picsum.photos/800/600?grayscale"
                    alt="Analyst reviewing inflation data charts"
                    loading="lazy"
                    className="h-64 w-full rounded-2xl object-cover"
                  />
                </div>
                <div className="mt-6 grid gap-4 sm:grid-cols-3">
                  <div className="rounded-2xl border border-primary-500/15 bg-white/30 p-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-primary-500">
                      CPI Focus
                    </p>
                    <p className="mt-2 text-2xl font-bold text-primary-700">+8.3%</p>
                    <p className="text-xs text-neutral-500">Last monthly variation</p>
                  </div>
                  <div className="rounded-2xl border border-primary-500/15 bg-white/30 p-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-primary-500">
                      FX Watch
                    </p>
                    <p className="mt-2 text-2xl font-bold text-primary-700">$976</p>
                    <p className="text-xs text-neutral-500">ARS per USD (CCL)</p>
                  </div>
                  <div className="rounded-2xl border border-primary-500/15 bg-white/30 p-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-primary-500">
                      Households
                    </p>
                    <p className="mt-2 text-2xl font-bold text-primary-700">-12%</p>
                    <p className="text-xs text-neutral-500">Quarterly purchasing power</p>
                  </div>
                </div>
              </div>
              <div className="absolute -right-8 -top-8 hidden h-48 w-48 rounded-full bg-primary-500/20 blur-3xl lg:block" />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="container-section py-16">
        <div className="rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
          <div className="flex flex-col gap-4 border-b border-neutral-100 pb-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-primary-900">{t('home.statsTitle')}</h2>
              <p className="text-sm text-neutral-500">{t('home.statsSubtitle')}</p>
            </div>
            <div className="flex items-center gap-3 text-sm text-neutral-500">
              <FiTrendingUp className="text-xl text-primary-500" aria-hidden="true" />
              <span>{fixedTexts[4]}</span>
            </div>
          </div>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            {stats.map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-primary-500/10 bg-primary-500/5 p-6"
              >
                <p className="text-sm font-semibold text-primary-600">{item.label}</p>
                <p className="mt-2 text-3xl font-bold text-primary-900">{item.value}</p>
                <p className="mt-2 text-sm text-neutral-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-neutral-50 py-16">
        <div className="container-section space-y-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <span className="badge-soft">{fixedTexts[5]}</span>
              <h2 className="mt-3 text-3xl font-semibold text-primary-900">{t('home.insightsTitle')}</h2>
              <p className="text-sm text-neutral-600">{t('home.insightsDescription')}</p>
            </div>
            <div className="flex items-center gap-2 text-sm text-primary-600">
              <FiPieChart aria-hidden="true" />
              {fixedTexts[6]}
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {modules.map((module, index) => (
              <div key={module.title} className="card-glass p-6">
                <div className="flex items-center gap-3">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-500/10 text-xl font-semibold text-primary-600">
                    {index + 1}
                  </span>
                  <h3 className="text-xl font-semibold text-primary-800">{module.title}</h3>
                </div>
                <p className="mt-4 text-sm text-neutral-600">{module.description}</p>
              </div>
            ))}
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="card-glass p-6">
              <div className="flex items-center gap-3">
                <div className="rounded-2xl bg-primary-500/10 p-3 text-primary-600">
                  <FiLayers aria-hidden="true" className="text-xl" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-primary-900">Data + Learning</h3>
                  <p className="text-sm text-neutral-600">{fixedTexts[7]}</p>
                </div>
              </div>
              <p className="mt-4 text-sm text-neutral-600">
                {fixedTexts[8]}
              </p>
              <Link
                to="/course"
                className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary-600 hover:text-primary-500"
              >
                {t('course.ctaSecondary')}
                <FiArrowUpRight aria-hidden="true" />
              </Link>
            </div>

            <div className="card-glass p-0">
              <img
                src="https://picsum.photos/900/600?blur=2"
                alt="Team session planning finance curriculum"
                loading="lazy"
                className="h-40 w-full rounded-t-2xl object-cover"
              />
              <div className="p-6">
                <p className="text-sm font-semibold text-primary-600">{t('common.updated')} · Buenos Aires</p>
                <p className="mt-2 text-lg font-semibold text-primary-900">
                  {t('course.badge')}
                </p>
                <p className="mt-3 text-sm text-neutral-600">
                  {t('course.subtitle')}
                </p>
                <Link
                  to="/contact"
                  className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary-600 hover:text-primary-500"
                >
                  {t('common.learnMore')}
                  <FiArrowUpRight aria-hidden="true" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container-section py-16">
        <div className="grid items-center gap-8 rounded-3xl border border-primary-500/15 bg-white p-8 shadow-brand lg:grid-cols-[1.2fr,1fr]">
          <div className="space-y-4">
            <span className="badge-soft">{t('home.newsletterTitle')}</span>
            <h2 className="text-3xl font-semibold text-primary-900">
              {fixedTexts[4]}
            </h2>
            <p className="text-sm text-neutral-600">{t('home.newsletterSubtitle')}</p>
            <form onSubmit={handleSubmit} className="space-y-4" aria-live="polite">
              <div>
                <label htmlFor="hero-email" className="text-label">
                  {t('home.newsletterPlaceholder')}
                </label>
                <input
                  id="hero-email"
                  type="email"
                  className="input-field"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder={t('home.newsletterPlaceholder')}
                  autoComplete="email"
                  required
                />
              </div>
              <div className="flex items-start gap-3">
                <input
                  id="hero-consent"
                  type="checkbox"
                  className="mt-1 h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                  checked={consent}
                  onChange={(event) => setConsent(event.target.checked)}
                  required
                />
                <label htmlFor="hero-consent" className="text-xs text-neutral-600">
                  {t('home.newsletterConsent')}
                </label>
              </div>
              <button
                type="submit"
                className="btn-primary inline-flex items-center gap-2"
                disabled={status === 'loading'}
              >
                {status === 'loading' ? 'Enviando…' : t('home.newsletterButton')}
                <FiArrowUpRight aria-hidden="true" />
              </button>
              {message && (
                <p
                  className={`text-sm ${status === 'error' ? 'text-red-600' : 'text-primary-600'}`}
                >
                  {message}
                </p>
              )}
            </form>
          </div>
          <div className="card-glass p-6">
            <ul className="space-y-4 text-sm text-neutral-600">
              <li className="flex items-start gap-3">
                <FiCheckCircle className="mt-1 text-primary-500" aria-hidden="true" />
                <span>{fixedTexts[5]}</span>
              </li>
              <li className="flex items-start gap-3">
                <FiCheckCircle className="mt-1 text-primary-500" aria-hidden="true" />
                <span>{fixedTexts[6]}</span>
              </li>
              <li className="flex items-start gap-3">
                <FiCheckCircle className="mt-1 text-primary-500" aria-hidden="true" />
                <span>{fixedTexts[7]}</span>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage
```