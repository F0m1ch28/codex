```tsx
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { FiArrowLeft } from 'react-icons/fi'

const NotFoundPage = () => {
  const { t } = useTranslation()

  return (
    <div className="bg-neutral-50 pb-16 pt-24">
      <div className="container-section">
        <div className="mx-auto max-w-xl rounded-3xl border border-neutral-100 bg-white p-8 text-center shadow-brand">
          <h1 className="text-4xl font-bold text-primary-900">{t('notFound.title')}</h1>
          <p className="mt-3 text-sm text-neutral-600">{t('notFound.subtitle')}</p>
          <Link
            to="/"
            className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary-600 hover:text-primary-500"
          >
            <FiArrowLeft aria-hidden="true" />
            {t('notFound.backHome')}
          </Link>
        </div>
      </div>
    </div>
  )
}

export default NotFoundPage
```