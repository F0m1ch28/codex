```tsx
import { useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'
import { FiCalendar, FiArrowUpRight, FiShield, FiUsers } from 'react-icons/fi'
import { Link } from 'react-router-dom'

type Outcome = {
  title: string
  description: string
}

type Module = {
  week: string
  title: string
  description: string
}

const CoursePage = () => {
  const { t } = useTranslation()
  const outcomes = useMemo(() => t('course.outcomes', { returnObjects: true }) as Outcome[], [t])
  const modules = useMemo(() => t('course.modules', { returnObjects: true }) as Module[], [t])

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section space-y-12">
        <section className="grid gap-10 lg:grid-cols-[1.2fr,0.8fr]">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-5"
          >
            <span className="badge-soft">{t('course.badge')}</span>
            <h1 className="text-4xl font-bold text-primary-900">{t('course.title')}</h1>
            <p className="text-lg text-neutral-600">{t('course.subtitle')}</p>
            <div className="rounded-2xl border border-primary-500/20 bg-white p-6 shadow-brand">
              <div className="flex items-center gap-3 text-sm text-primary-600">
                <FiShield aria-hidden="true" />
                <span>{t('course.guarantee')}</span>
              </div>
              <p className="mt-3 text-sm text-neutral-600">
                {fixedTexts[5]}
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <Link to="/contact" className="btn-primary inline-flex items-center gap-2">
                {t('course.ctaPrimary')}
                <FiArrowUpRight aria-hidden="true" />
              </Link>
              <Link to="/resources" className="btn-secondary inline-flex items-center gap-2">
                {t('course.ctaSecondary')}
                <FiArrowUpRight aria-hidden="true" />
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="card-glass overflow-hidden"
          >
            <img
              src="https://picsum.photos/900/650?blur=1"
              alt="Students learning about personal finance"
              loading="lazy"
              className="h-64 w-full object-cover"
            />
            <div className="space-y-4 p-6">
              <p className="text-sm font-semibold text-primary-600">{fixedTexts[2]}</p>
              <div className="flex items-center gap-3 text-sm text-neutral-500">
                <FiUsers aria-hidden="true" />
                <span>20 learners per cohort</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-neutral-500">
                <FiCalendar aria-hidden="true" />
                <span>4 weeks · 2 live sessions + self-paced lessons each week</span>
              </div>
            </div>
          </motion.div>
        </section>

        <section className="rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-primary-900">{t('course.outcomesTitle')}</h2>
              <p className="text-sm text-neutral-600">{fixedTexts[3]}</p>
            </div>
            <Link
              to="/inflation"
              className="inline-flex items-center gap-2 text-sm font-semibold text-primary-600 hover:text-primary-500"
            >
              {t('common.learnMore')}
              <FiArrowUpRight aria-hidden="true" />
            </Link>
          </div>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            {outcomes.map((outcome) => (
              <div key={outcome.title} className="rounded-2xl border border-primary-500/10 bg-primary-500/5 p-6">
                <h3 className="text-lg font-semibold text-primary-800">{outcome.title}</h3>
                <p className="mt-2 text-sm text-neutral-600">{outcome.description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-3xl border border-primary-500/10 bg-white p-8 shadow-brand">
          <h2 className="text-2xl font-semibold text-primary-900">{t('course.modulesTitle')}</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {modules.map((module) => (
              <div key={module.week} className="rounded-2xl border border-primary-500/15 bg-primary-500/5 p-6">
                <span className="text-xs font-semibold uppercase tracking-wide text-primary-600">
                  {module.week}
                </span>
                <h3 className="mt-2 text-xl font-semibold text-primary-800">{module.title}</h3>
                <p className="mt-2 text-sm text-neutral-600">{module.description}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

export default CoursePage
```