```tsx
import { useTranslation } from 'react-i18next'

const CookiesPage = () => {
  const { t } = useTranslation()

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section">
        <div className="mx-auto max-w-3xl space-y-6 rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
          <h1 className="text-3xl font-semibold text-primary-900">{t('legal.cookiesTitle')}</h1>
          <p className="text-sm text-neutral-600">{t('legal.cookiesIntro')}</p>
          <section className="space-y-4 text-sm text-neutral-600">
            <h2 className="text-lg font-semibold text-primary-800">1. Cookies esenciales</h2>
            <p>
              Utilizamos cookies esenciales para mantener tus sesiones activas y recordar tu preferencia de idioma.
              Estas cookies son necesarias para que el sitio funcione correctamente.
            </p>
            <h2 className="text-lg font-semibold text-primary-800">2. Cookies analíticas</h2>
            <p>
              Medimos interacciones de forma agregada para mejorar las funcionalidades del dashboard y del curso. Puedes
              rechazar estas cookies desde el banner y seguiremos respetando tu elección.
            </p>
            <h2 className="text-lg font-semibold text-primary-800">3. Gestión de cookies</h2>
            <p>
              Puedes limpiar o bloquear cookies desde la configuración de tu navegador en cualquier momento. Si deseas
              actualizar tu consentimiento, enviános un correo a hola@tuprogresohoy.com.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}

export default CookiesPage
```