```tsx
import { useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'
import { FiArrowUpRight } from 'react-icons/fi'

type ResourceItem = {
  title: string
  description: string
  link: string
}

const ResourcesPage = () => {
  const { t } = useTranslation()
  const items = useMemo(
    () => t('resources.items', { returnObjects: true }) as ResourceItem[],
    [t]
  )

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section space-y-12">
        <header className="space-y-4">
          <span className="badge-soft">{fixedTexts[2]}</span>
          <h1 className="text-4xl font-bold text-primary-900">{t('resources.title')}</h1>
          <p className="max-w-3xl text-lg text-neutral-600">{t('resources.subtitle')}</p>
        </header>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="grid gap-8 lg:grid-cols-3"
        >
          {items.map((item, index) => (
            <div key={item.title} className="card-glass overflow-hidden">
              <img
                src={`https://picsum.photos/800/50${index}?grayscale`}
                alt={item.title}
                loading="lazy"
                className="h-48 w-full object-cover"
              />
              <div className="space-y-3 p-6">
                <h3 className="text-xl font-semibold text-primary-900">{item.title}</h3>
                <p className="text-sm text-neutral-600">{item.description}</p>
                <button
                  type="button"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-primary-600 hover:text-primary-500"
                >
                  {item.link}
                  <FiArrowUpRight aria-hidden="true" />
                </button>
              </div>
            </div>
          ))}
        </motion.div>

        <div className="rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-primary-900">{fixedTexts[6]}</h2>
              <p className="mt-2 text-sm text-neutral-600">{fixedTexts[5]}</p>
            </div>
            <a
              href="#top"
              className="inline-flex items-center gap-2 rounded-xl border border-primary-500/20 px-4 py-2 text-sm font-semibold text-primary-700 hover:bg-primary-500/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
            >
              {t('resources.cta')}
              <FiArrowUpRight aria-hidden="true" />
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ResourcesPage
```