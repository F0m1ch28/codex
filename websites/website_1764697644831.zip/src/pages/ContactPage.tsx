```tsx
import { FormEvent, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { FiSend, FiMapPin, FiPhone, FiMail } from 'react-icons/fi'

const ContactPage = () => {
  const { t } = useTranslation()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: '',
    message: ''
  })
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle')

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!formData.name || !formData.email || !formData.message) {
      setStatus('error')
      return
    }
    setStatus('success')
    setFormData({
      name: '',
      email: '',
      topic: '',
      message: ''
    })
  }

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section space-y-12">
        <header className="space-y-3">
          <span className="badge-soft">{fixedTexts[1]}</span>
          <h1 className="text-4xl font-bold text-primary-900">{t('contact.title')}</h1>
            <p className="max-w-2xl text-lg text-neutral-600">{t('contact.subtitle')}</p>
        </header>

        <div className="grid gap-10 lg:grid-cols-[1.2fr,0.8fr]">
          <div className="rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
            <h2 className="text-2xl font-semibold text-primary-900">{t('contact.formTitle')}</h2>
            <form onSubmit={handleSubmit} className="mt-6 space-y-5">
              <div>
                <label htmlFor="contact-name" className="text-label">
                  {t('contact.formName')}
                </label>
                <input
                  id="contact-name"
                  type="text"
                  className="input-field"
                  value={formData.name}
                  onChange={(event) => setFormData((prev) => ({ ...prev, name: event.target.value }))}
                  required
                />
              </div>
              <div>
                <label htmlFor="contact-email" className="text-label">
                  {t('contact.formEmail')}
                </label>
                <input
                  id="contact-email"
                  type="email"
                  className="input-field"
                  value={formData.email}
                  onChange={(event) => setFormData((prev) => ({ ...prev, email: event.target.value }))}
                  required
                />
              </div>
              <div>
                <label htmlFor="contact-topic" className="text-label">
                  {t('contact.formTopic')}
                </label>
                <input
                  id="contact-topic"
                  type="text"
                  className="input-field"
                  value={formData.topic}
                  onChange={(event) => setFormData((prev) => ({ ...prev, topic: event.target.value }))}
                />
              </div>
              <div>
                <label htmlFor="contact-message" className="text-label">
                  {t('contact.formMessage')}
                </label>
                <textarea
                  id="contact-message"
                  rows={4}
                  className="input-field"
                  value={formData.message}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, message: event.target.value }))
                  }
                  required
                />
              </div>
              <button type="submit" className="btn-primary inline-flex items-center gap-2">
                <FiSend aria-hidden="true" />
                {t('contact.formSubmit')}
              </button>
              <div aria-live="polite" className="text-sm">
                {status === 'error' && <p className="text-red-600">{t('contact.alert')}</p>}
                {status === 'success' && <p className="text-primary-600">{t('contact.success')}</p>}
              </div>
            </form>
          </div>

          <div className="space-y-6">
            <div className="card-glass p-6">
              <h2 className="text-xl font-semibold text-primary-900">{t('contact.visitUs')}</h2>
              <p className="mt-2 flex items-center gap-2 text-sm text-neutral-600">
                <FiMapPin aria-hidden="true" />
                {t('common.address')}
              </p>
              <p className="mt-2 text-sm text-neutral-600">{t('contact.officeHours')}</p>
              <p className="mt-3 flex items-center gap-2 text-sm text-neutral-600">
                <FiPhone aria-hidden="true" />
                <a href="tel:+541155551234" className="hover:text-primary-600">
                  {t('contact.phoneLabel')}: {t('common.phone')}
                </a>
              </p>
              <p className="mt-2 flex items-center gap-2 text-sm text-neutral-600">
                <FiMail aria-hidden="true" />
                <a href="mailto:hola@tuprogresohoy.com" className="hover:text-primary-600">
                  {t('contact.emailLabel')}: hola@tuprogresohoy.com
                </a>
              </p>
            </div>
            <div className="overflow-hidden rounded-3xl border border-neutral-100 shadow-brand">
              <iframe
                title={t('contact.mapTitle')}
                src="https://www.openstreetmap.org/export/embed.html?bbox=-58.3850%2C-34.6050%2C-58.3780%2C-34.6000&amp;layer=mapnik&amp;marker=-34.6037%2C-58.3816"
                className="h-64 w-full border-0"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ContactPage
```