```tsx
import { useTranslation } from 'react-i18next'

const PrivacyPage = () => {
  const { t } = useTranslation()

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section">
        <div className="mx-auto max-w-3xl space-y-6 rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
          <h1 className="text-3xl font-semibold text-primary-900">{t('legal.privacyTitle')}</h1>
          <p className="text-sm text-neutral-600">{t('legal.privacyIntro')}</p>
          <section className="space-y-4 text-sm text-neutral-600">
            <h2 className="text-lg font-semibold text-primary-800">1. Datos que recopilamos</h2>
            <p>
              Recopilamos nombre, correo electrónico y preferencias de idioma cuando completas formularios en Tu
              Progreso Hoy. También almacenamos métricas de uso agregadas para mejorar la plataforma educativa.
            </p>
            <h2 className="text-lg font-semibold text-primary-800">2. Cómo usamos los datos</h2>
            <p>
              Los datos permiten habilitar el doble opt-in, enviarte contenidos educativos y recordatorios sobre tu
              progreso. Jamás vendemos ni cedemos información personal a terceros con fines comerciales.
            </p>
            <h2 className="text-lg font-semibold text-primary-800">3. Derechos de los usuarios</h2>
            <p>
              Puedes solicitar acceso, corrección o eliminación de tus datos escribiendo a hola@tuprogresohoy.com.
              Respondemos dentro de 10 días hábiles conforme a la Ley de Protección de Datos Personales de Argentina.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}

export default PrivacyPage
```