```tsx
import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  CartesianGrid,
  Tooltip,
  Legend,
  XAxis,
  YAxis
} from 'recharts'
import { FiArrowDownRight, FiDownload, FiInfo } from 'react-icons/fi'

type ChartPoint = {
  month: string
  inflation: number
  usdRate: number
}

type ProjectionPoint = {
  month: string
  optimistic: number
  base: number
  conservative: number
}

const cpiSeries: ChartPoint[] = [
  { month: 'Feb', inflation: 6.6, usdRate: 772 },
  { month: 'Mar', inflation: 7.8, usdRate: 804 },
  { month: 'Apr', inflation: 8.4, usdRate: 832 },
  { month: 'May', inflation: 7.5, usdRate: 851 },
  { month: 'Jun', inflation: 7.7, usdRate: 872 },
  { month: 'Jul', inflation: 7.4, usdRate: 895 },
  { month: 'Aug', inflation: 8.0, usdRate: 918 },
  { month: 'Sep', inflation: 8.6, usdRate: 947 },
  { month: 'Oct', inflation: 8.7, usdRate: 962 },
  { month: 'Nov', inflation: 8.3, usdRate: 976 },
  { month: 'Dec', inflation: 8.9, usdRate: 998 },
  { month: 'Jan', inflation: 9.1, usdRate: 1015 }
]

const projectionSeries: ProjectionPoint[] = [
  { month: 'Q1', optimistic: 82, base: 96, conservative: 110 },
  { month: 'Q2', optimistic: 78, base: 90, conservative: 103 },
  { month: 'Q3', optimistic: 74, base: 86, conservative: 99 },
  { month: 'Q4', optimistic: 70, base: 82, conservative: 95 }
]

const InflationPage = () => {
  const { t } = useTranslation()
  const [timeframe, setTimeframe] = useState<'three' | 'six' | 'twelve'>('six')

  const filteredData = useMemo(() => {
    if (timeframe === 'three') return cpiSeries.slice(-3)
    if (timeframe === 'six') return cpiSeries.slice(-6)
    return cpiSeries.slice(-12)
  }, [timeframe])

  const insightBullets = t('inflation.insightBullets', { returnObjects: true }) as string[]

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section space-y-12">
        <header className="space-y-4">
          <span className="badge-soft">{t('inflation.updatedLabel')}</span>
          <h1 className="text-4xl font-bold text-primary-900">{t('inflation.title')}</h1>
          <p className="max-w-3xl text-lg text-neutral-600">{t('inflation.subtitle')}</p>
        </header>

        <section className="rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-primary-900">{t('inflation.chartCpiTitle')}</h2>
              <p className="text-sm text-neutral-600">{t('inflation.chartCpiDescription')}</p>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-sm text-neutral-600">
              <label htmlFor="timeframe" className="font-semibold text-primary-700">
                {t('inflation.filterLabel')}
              </label>
              <select
                id="timeframe"
                value={timeframe}
                onChange={(event) => setTimeframe(event.target.value as 'three' | 'six' | 'twelve')}
                className="rounded-xl border border-primary-500/20 bg-primary-500/5 px-4 py-2 text-sm text-primary-700 focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-500/30"
              >
                <option value="three">{t('inflation.filterOptions.three')}</option>
                <option value="six">{t('inflation.filterOptions.six')}</option>
                <option value="twelve">{t('inflation.filterOptions.twelve')}</option>
              </select>
            </div>
          </div>

          <div className="mt-8 h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={filteredData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" />
                <XAxis dataKey="month" tick={{ fill: '#475569', fontSize: 12 }} />
                <YAxis
                  yAxisId="left"
                  tickFormatter={(value: number) => `${value}%`}
                  tick={{ fill: '#475569', fontSize: 12 }}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tickFormatter={(value: number) => `$${value}`}
                  tick={{ fill: '#475569', fontSize: 12 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="rounded-3xl border border-primary-500/10 bg-white p-8 shadow-brand">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-primary-900">{t('inflation.chartProjectionTitle')}</h2>
              <p className="text-sm text-neutral-600">{t('inflation.chartProjectionDescription')}</p>
            </div>
            <a
              href="#"
              className="inline-flex items-center gap-2 rounded-xl border border-primary-500/20 bg-primary-500/10 px-4 py-2 text-sm font-semibold text-primary-700 transition hover:bg-primary-500/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
            >
              <FiDownload aria-hidden="true" />
              {t('inflation.downloadLabel')}
            </a>
          </div>
          <div className="mt-8 h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={projectionSeries}>
                <defs>
                  <linearGradient id="colorOptimistic" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorBase" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1F3A6F" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#1F3A6F" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorConservative" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0F172A" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#0F172A" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="4 4" stroke="#E2E8F0" />
                <XAxis dataKey="month" tick={{ fill: '#475569', fontSize: 12 }} />
                <YAxis tickFormatter={(value: number) => `${value}%`} tick={{ fill: '#475569', fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="optimistic"
                  stroke="#2563EB"
                  fillOpacity={1}
                  fill="url(#colorOptimistic)"
                />
                <Area
                  type="monotone"
                  dataKey="base"
                  stroke="#1F3A6F"
                  fillOpacity={1}
                  fill="url(#colorBase)"
                />
                <Area
                  type="monotone"
                  dataKey="conservative"
                  stroke="#0F172A"
                  fillOpacity={1}
                  fill="url(#colorConservative)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="grid gap-8 rounded-3xl border border-neutral-100 bg-white p-8 shadow-brand lg:grid-cols-[1.2fr,0.8fr]">
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-primary-600">
              <FiInfo aria-hidden="true" />
              <span className="font-semibold uppercase tracking-wide">{t('inflation.insightHeading')}</span>
            </div>
            <ul className="space-y-3 text-sm text-neutral-600">
              {insightBullets.map((bullet) => (
                <li key={bullet} className="flex items-start gap-3">
                  <FiArrowDownRight className="mt-1 text-primary-500" aria-hidden="true" />
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-primary-500/10 bg-primary-500/5 p-6">
            <p className="text-sm font-semibold text-primary-600">ARS→USD focus</p>
            <p className="mt-3 text-2xl font-bold text-primary-900">Benchmark layers</p>
            <p className="mt-3 text-sm text-neutral-600">
              {fixedTexts[4]}
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              <span className="rounded-full bg-white px-4 py-1 text-xs font-semibold text-primary-700">
                CPI Oficial
              </span>
              <span className="rounded-full bg-white px-4 py-1 text-xs font-semibold text-primary-700">
                Survey Expectations
              </span>
              <span className="rounded-full bg-white px-4 py-1 text-xs font-semibold text-primary-700">
                FX Blue-chip swap
              </span>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default InflationPage
```