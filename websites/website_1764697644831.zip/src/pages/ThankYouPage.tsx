```tsx
import { useLocation, Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { FiArrowLeft, FiCheckCircle } from 'react-icons/fi'

type LocationState = {
  email?: string
}

const ThankYouPage = () => {
  const { t } = useTranslation()
  const location = useLocation()
  const state = location.state as LocationState | null
  const checklist = t('thankyou.checklist', { returnObjects: true }) as string[]

  return (
    <div className="bg-neutral-50 pb-16 pt-12">
      <div className="container-section">
        <div className="mx-auto max-w-2xl rounded-3xl border border-neutral-100 bg-white p-8 text-center shadow-brand">
          <span className="badge-soft">Double opt-in</span>
          <h1 className="mt-4 text-3xl font-semibold text-primary-900">{t('thankyou.title')}</h1>
          <p className="mt-3 text-sm text-neutral-600">
            {t('thankyou.subtitle')}
          </p>
          {state?.email && (
            <p className="mt-2 text-sm font-semibold text-primary-600">
              {state.email}
            </p>
          )}
          <ul className="mt-6 space-y-3 text-left text-sm text-neutral-600">
            {checklist.map((item) => (
              <li key={item} className="flex items-start gap-3">
                <FiCheckCircle className="mt-1 text-primary-500" aria-hidden="true" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <Link
            to="/"
            className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-primary-600 hover:text-primary-500"
          >
            <FiArrowLeft aria-hidden="true" />
            {t('thankyou.backHome')}
          </Link>
        </div>
      </div>
    </div>
  )
}

export default ThankYouPage
```