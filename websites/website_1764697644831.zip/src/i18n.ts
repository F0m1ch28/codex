```ts
import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'

const resources = {
  en: {
    translation: {
      nav: {
        home: 'Home',
        inflation: 'Inflation',
        course: 'Course',
        resources: 'Resources',
        contact: 'Contact'
      },
      layout: {
        tagline: 'Argentina-focused insights for responsible planning.'
      },
      disclaimers: {
        en: 'We do not provide financial services.',
        es: 'No proporcionamos servicios financieros.',
        ru: 'Мы не предоставляем финансовые услуги.'
      },
      home: {
        heroTitle: 'Navigate Argentina’s inflation with clarity.',
        heroSubtitle: 'ARS→USD inflation insights and personal finance essentials designed for resilient planning.',
        heroCaption: 'Weekly ARS→USD movement summaries validated with official and market data.',
        heroCtaPrimary: 'Explore Inflation Dashboard',
        heroCtaSecondary: 'Preview the Course',
        statsTitle: 'Momentum metrics at a glance',
        statsSubtitle: 'Track changing prices and currency movements to plan with precision.',
        stats: [
          {
            label: 'Latest CPI YoY',
            value: '124.5%',
            description: 'INDEC official CPI variation year-on-year (Nov 2023).'
          },
          {
            label: 'ARS→USD blue-chip swap',
            value: '976',
            description: 'Indicative mid-market exchange rate (ARS) per USD.'
          },
          {
            label: 'Savings impact',
            value: '-12.4%',
            description: 'Average purchasing power shift in the past quarter.'
          }
        ],
        insightsTitle: 'Essential pulses to stay ahead',
        insightsDescription: 'Combine real-time inflation indicators with curated lessons to strengthen your decision-making.',
        modules: [
          {
            title: 'Inflation Radar',
            description: 'Monitor core and headline CPI plus tradable currency spreads every week.'
          },
          {
            title: 'Budget Resilience',
            description: 'Learn to adjust household budgets to inflation expectations and currency stress.'
          },
          {
            title: 'Scenario Planning',
            description: 'Simulate ARS→USD conversion strategies aligned with personal goals.'
          }
        ],
        newsletterTitle: 'Start your double opt-in preview',
        newsletterSubtitle: 'Get a guided email sequence to confirm your account and unlock the first lesson.',
        newsletterPlaceholder: 'Email address',
        newsletterButton: 'Request Access',
        newsletterConsent: 'I agree to receive the double opt-in email from Tu Progreso Hoy.',
        newsletterAlert: 'Please enter a valid email address and consent to continue.',
        newsletterSuccess: 'Check your inbox to confirm your subscription. We just sent you a verification link.'
      },
      inflation: {
        title: 'Inflation & Currency Dashboard',
        subtitle: 'Clean data layers to understand how prices and ARS→USD dynamics move together.',
        chartCpiTitle: 'Monthly inflation vs ARS→USD reference',
        chartCpiDescription: 'View the interplay between monthly CPI variation and informal market exchange benchmarks.',
        chartProjectionTitle: 'Projected inflation bands',
        chartProjectionDescription: 'A scenario range based on economists’ consensus and real-time survey expectations.',
        insightHeading: 'How to read the dashboard',
        insightBullets: [
          'Highlights focus on monthly CPI from INDEC and projected annualised inflation.',
          'ARS→USD figures reference blue-chip swap indications for comparative purchasing power.',
          'Use the filters below to align insights with your planning window.'
        ],
        updatedLabel: 'Updated today with aggregated market checks.',
        filterLabel: 'Select timeframe',
        filterOptions: {
          three: 'Last 3 months',
          six: 'Last 6 months',
          twelve: 'Last 12 months'
        },
        downloadLabel: 'Download methodology (PDF)'
      },
      course: {
        title: 'Personal Finance Starter Course',
        subtitle: 'Build critical money habits with expert-led lessons tailored to Argentina’s evolving economy.',
        badge: 'Cohort-based learning · Next start: February 2024',
        outcomesTitle: 'What you will learn',
        outcomes: [
          {
            title: 'Decode inflation signals',
            description: 'Interpret CPI prints and currency spreads to anticipate price moves.'
          },
          {
            title: 'Budget with flexibility',
            description: 'Structure spending plans that absorb volatility while funding your priorities.'
          },
          {
            title: 'Protect your savings',
            description: 'Evaluate diversified saving vehicles and manage ARS→USD conversions responsibly.'
          }
        ],
        modulesTitle: 'Course outline',
        modules: [
          {
            week: 'Week 1',
            title: 'Argentina today',
            description: 'Understanding macro context, CPI components, and currency pressures.'
          },
          {
            week: 'Week 2',
            title: 'Budget mapping',
            description: 'Designing inflation-adjusted budgets and emergency buffers.'
          },
          {
            week: 'Week 3',
            title: 'Currency strategies',
            description: 'Scenario planning for ARS→USD conversions and timing considerations.'
          },
          {
            week: 'Week 4',
            title: 'Action roadmap',
            description: 'Setting measurable goals, tracking progress, and staying accountable.'
          }
        ],
        ctaPrimary: 'Join the waiting list',
        ctaSecondary: 'See enrollment details',
        guarantee: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
      },
      resources: {
        title: 'Resources & tools',
        subtitle: 'Curated guides, checklists, and data explainers to support your daily decisions.',
        items: [
          {
            title: 'Inflation survival kit',
            description: 'Step-by-step plan to update your budget every month.',
            link: 'Download guide'
          },
          {
            title: 'Currency conversion worksheet',
            description: 'Model different ARS→USD rates and their impact on your goals.',
            link: 'Open worksheet'
          },
          {
            title: 'Household essentials tracker',
            description: 'Compare price evolution across essential categories.',
            link: 'Track pricing'
          }
        ],
        cta: 'Browse all resources'
      },
      contact: {
        title: 'Contact Tu Progreso Hoy',
        subtitle: 'We are ready to help you navigate the platform and plan your learning path.',
        formTitle: 'Send us a message',
        formName: 'Full name',
        formEmail: 'Email',
        formTopic: 'Topic',
        formMessage: 'How can we help?',
        formSubmit: 'Send message',
        alert: 'Please fill in all required fields.',
        success: 'Message received. We will reply within 2 business days.',
        visitUs: 'Visit our office',
        officeHours: 'Monday to Friday · 9:00 - 18:00 (GMT-3)',
        phoneLabel: 'Phone',
        emailLabel: 'Email',
        mapTitle: 'Map showing Tu Progreso Hoy office location'
      },
      thankyou: {
        title: 'Thank you for joining Tu Progreso Hoy',
        subtitle: 'We sent you a verification email. Please confirm to activate your access.',
        backHome: 'Return to homepage',
        checklist: [
          'Open the email we just sent to confirm your subscription.',
          'Add us to your safe senders list to receive upcoming updates.',
          'Complete the interest survey to tailor your learning path.'
        ]
      },
      legal: {
        privacyTitle: 'Privacy Policy',
        privacyIntro: 'We collect minimal personal data to deliver educational services and comply with Argentine regulations.',
        cookiesTitle: 'Cookie Policy',
        cookiesIntro: 'We use cookies to personalise content, analyse visits, and store language preferences.',
        termsTitle: 'Terms & Conditions',
        termsIntro: 'Read how Tu Progreso Hoy provides its educational services and uses data responsibly.'
      },
      footer: {
        explore: 'Explore',
        legal: 'Legal',
        newsletter: 'Stay informed',
        newsletterPlaceholder: 'Your email',
        newsletterButton: 'Get updates',
        localeLabel: 'Language',
        companyDescription: 'Tu Progreso Hoy delivers inflation intelligence and practical finance education for people in Argentina.',
        hours: 'Customer hours'
      },
      cookie: {
        title: 'Cookie Policy',
        message: 'We use cookies to improve your experience, analyse traffic, and remember your language preferences.',
        accept: 'Accept',
        decline: 'Decline'
      },
      common: {
        updated: 'Updated',
        readMore: 'Read more',
        learnMore: 'Learn more',
        address: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
        phone: '+54 11 5555-1234'
      },
      notFound: {
        title: 'Page not found',
        subtitle: 'Sorry, the page you are looking for does not exist.',
        backHome: 'Go back home'
      }
    }
  },
  es: {
    translation: {
      nav: {
        home: 'Inicio',
        inflation: 'Inflación',
        course: 'Curso',
        resources: 'Recursos',
        contact: 'Contacto'
      },
      layout: {
        tagline: 'Información enfocada en Argentina para planificar con responsabilidad.'
      },
      disclaimers: {
        en: 'We do not provide financial services.',
        es: 'No proporcionamos servicios financieros.',
        ru: 'Мы не предоставляем финансовые услуги.'
      },
      home: {
        heroTitle: 'Comprende la inflación argentina con claridad.',
        heroSubtitle: 'Insights sobre la inflación ARS→USD y fundamentos de finanzas personales para planificar con resiliencia.',
        heroCaption: 'Resumen semanal de movimientos ARS→USD validado con datos oficiales y de mercado.',
        heroCtaPrimary: 'Explorar dashboard de inflación',
        heroCtaSecondary: 'Ver adelanto del curso',
        statsTitle: 'Métricas clave en un vistazo',
        statsSubtitle: 'Sigue la evolución de precios y del tipo de cambio para planificar con precisión.',
        stats: [
          {
            label: 'Última inflación interanual',
            value: '124,5%',
            description: 'Variación interanual oficial del IPC (noviembre 2023).'
          },
          {
            label: 'Dólar contado con liquidación',
            value: '976',
            description: 'Cotización referencial (ARS) por USD en mercado bursátil.'
          },
          {
            label: 'Impacto en ahorros',
            value: '-12,4%',
            description: 'Cambio promedio del poder adquisitivo en el último trimestre.'
          }
        ],
        insightsTitle: 'Pulso esencial para adelantarte',
        insightsDescription: 'Combina indicadores de inflación en tiempo real con lecciones curadas para fortalecer tus decisiones.',
        modules: [
          {
            title: 'Radar de inflación',
            description: 'Monitorea IPC núcleo, general y brechas cambiarias cada semana.'
          },
          {
            title: 'Resiliencia presupuestaria',
            description: 'Aprende a ajustar tu presupuesto al ritmo de la inflación y al estrés cambiario.'
          },
          {
            title: 'Planificación de escenarios',
            description: 'Simula estrategias ARS→USD alineadas con tus metas personales.'
          }
        ],
        newsletterTitle: 'Inicia tu doble confirmación',
        newsletterSubtitle: 'Recibe una serie de correos para confirmar tu cuenta y acceder a la primera lección.',
        newsletterPlaceholder: 'Correo electrónico',
        newsletterButton: 'Solicitar acceso',
        newsletterConsent: 'Acepto recibir el correo de doble confirmación de Tu Progreso Hoy.',
        newsletterAlert: 'Ingresa un correo válido y acepta el consentimiento para continuar.',
        newsletterSuccess: 'Revisa tu bandeja de entrada para confirmar tu suscripción. Te enviamos un enlace de verificación.'
      },
      inflation: {
        title: 'Dashboard de inflación y moneda',
        subtitle: 'Capas de datos limpias para entender cómo se mueven los precios y la dinámica ARS→USD.',
        chartCpiTitle: 'Inflación mensual vs referencia ARS→USD',
        chartCpiDescription: 'Observa la relación entre la variación mensual del IPC y las referencias cambiarias del mercado.',
        chartProjectionTitle: 'Bandas de inflación proyectada',
        chartProjectionDescription: 'Escenarios basados en consensos de economistas y expectativas relevadas en tiempo real.',
        insightHeading: 'Cómo interpretar el dashboard',
        insightBullets: [
          'Los destacados muestran IPC mensual del INDEC y proyecciones anualizadas.',
          'Las referencias ARS→USD utilizan indicaciones de contado con liquidación para comparar poder adquisitivo.',
          'Usa los filtros para alinear los insights con tu horizonte de planificación.'
        ],
        updatedLabel: 'Actualizado hoy con verificaciones de mercado agregadas.',
        filterLabel: 'Selecciona período',
        filterOptions: {
          three: 'Últimos 3 meses',
          six: 'Últimos 6 meses',
          twelve: 'Últimos 12 meses'
        },
        downloadLabel: 'Descargar metodología (PDF)'
      },
      course: {
        title: 'Curso inicial de finanzas personales',
        subtitle: 'Desarrolla hábitos financieros críticos con lecciones guiadas y enfocadas en la economía argentina.',
        badge: 'Aprendizaje por cohortes · Próximo inicio: febrero 2024',
        outcomesTitle: 'Lo que vas a aprender',
        outcomes: [
          {
            title: 'Decodificar señales de inflación',
            description: 'Interpretar datos del IPC y brechas cambiarias para anticipar movimientos de precios.'
          },
          {
            title: 'Presupuestar con flexibilidad',
            description: 'Armar planes de gasto que absorban la volatilidad y sostengan tus prioridades.'
          },
          {
            title: 'Cuidar tus ahorros',
            description: 'Evaluar alternativas de ahorro y gestionar conversions ARS→USD con responsabilidad.'
          }
        ],
        modulesTitle: 'Programa del curso',
        modules: [
          {
            week: 'Semana 1',
            title: 'Argentina hoy',
            description: 'Contexto macro, componentes del IPC y presiones cambiarias.'
          },
          {
            week: 'Semana 2',
            title: 'Mapeo de presupuesto',
            description: 'Diseño de presupuestos ajustados por inflación y fondos de emergencia.'
          },
          {
            week: 'Semana 3',
            title: 'Estrategias cambiarias',
            description: 'Planificación de conversiones ARS→USD y análisis de timing.'
          },
          {
            week: 'Semana 4',
            title: 'Hoja de ruta de acción',
            description: 'Metas medibles, seguimiento y accountability.'
          }
        ],
        ctaPrimary: 'Sumarte a la lista de espera',
        ctaSecondary: 'Ver detalles de inscripción',
        guarantee: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
      },
      resources: {
        title: 'Recursos y herramientas',
        subtitle: 'Guías, checklists y explicadores de datos para tu día a día.',
        items: [
          {
            title: 'Kit de supervivencia inflacionaria',
            description: 'Plan paso a paso para actualizar tu presupuesto cada mes.',
            link: 'Descargar guía'
          },
          {
            title: 'Hoja de conversión cambiaria',
            description: 'Modela distintos tipos de cambio ARS→USD y su impacto en tus metas.',
            link: 'Abrir hoja'
          },
          {
            title: 'Tracker de esenciales del hogar',
            description: 'Compara la evolución de precios de categorías imprescindibles.',
            link: 'Seguir precios'
          }
        ],
        cta: 'Ver todos los recursos'
      },
      contact: {
        title: 'Contacto Tu Progreso Hoy',
        subtitle: 'Estamos a disposición para ayudarte con la plataforma y tu plan de aprendizaje.',
        formTitle: 'Envíanos un mensaje',
        formName: 'Nombre completo',
        formEmail: 'Correo electrónico',
        formTopic: 'Tema',
        formMessage: '¿Cómo podemos ayudarte?',
        formSubmit: 'Enviar mensaje',
        alert: 'Por favor completa todos los campos requeridos.',
        success: 'Recibimos tu mensaje. Responderemos dentro de 2 días hábiles.',
        visitUs: 'Visitá nuestra oficina',
        officeHours: 'Lunes a viernes · 9:00 - 18:00 (GMT-3)',
        phoneLabel: 'Teléfono',
        emailLabel: 'Correo',
        mapTitle: 'Mapa con la ubicación de Tu Progreso Hoy'
      },
      thankyou: {
        title: 'Gracias por sumarte a Tu Progreso Hoy',
        subtitle: 'Te enviamos un correo de verificación. Confirmalo para activar tu acceso.',
        backHome: 'Volver al inicio',
        checklist: [
          'Abrí el correo que te acabamos de enviar y confirmá tu suscripción.',
          'Agreganos a tu lista de remitentes seguros para recibir próximos envíos.',
          'Completá la encuesta de intereses para personalizar tu recorrido de aprendizaje.'
        ]
      },
      legal: {
        privacyTitle: 'Política de privacidad',
        privacyIntro: 'Recopilamos datos personales mínimos para brindar nuestros servicios educativos y cumplir con regulaciones argentinas.',
        cookiesTitle: 'Política de cookies',
        cookiesIntro: 'Usamos cookies para personalizar contenido, analizar visitas y guardar preferencias de idioma.',
        termsTitle: 'Términos y condiciones',
        termsIntro: 'Leé cómo Tu Progreso Hoy brinda sus servicios educativos y utiliza los datos de forma responsable.'
      },
      footer: {
        explore: 'Explorar',
        legal: 'Legales',
        newsletter: 'Mantente informado',
        newsletterPlaceholder: 'Tu correo',
        newsletterButton: 'Recibir novedades',
        localeLabel: 'Idioma',
        companyDescription: 'Tu Progreso Hoy ofrece inteligencia inflacionaria y educación financiera práctica para personas en Argentina.',
        hours: 'Horario de atención'
      },
      cookie: {
        title: 'Política de cookies',
        message: 'Usamos cookies para mejorar tu experiencia, analizar el tráfico y recordar tus preferencias de idioma.',
        accept: 'Aceptar',
        decline: 'Rechazar'
      },
      common: {
        updated: 'Actualizado',
        readMore: 'Leer más',
        learnMore: 'Conocer más',
        address: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
        phone: '+54 11 5555-1234'
      },
      notFound: {
        title: 'Página no encontrada',
        subtitle: 'Lo sentimos, la página que buscas no existe.',
        backHome: 'Regresar al inicio'
      }
    }
  }
}

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  })

export default i18n
```