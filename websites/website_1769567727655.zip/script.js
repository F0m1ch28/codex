const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const COOKIE_KEY = "cookie_consent";
const I18N = {
  fr: {
    common: {
      skipLink: "Aller directement au contenu",
      brandName: "danswholesaleplants",
      nav: {
        home: "Accueil",
        services: "Services",
        about: "À propos",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      navToggle: "Ouvrir ou fermer la navigation principale",
      languageFrench: "FR",
      languageEnglish: "EN",
      footer: {
        phoneLabel: "Téléphone",
        phoneValue: "+32 2 123 45 67",
        emailLabel: "Email",
        emailValue: "contact@danswholesaleplants.com",
        addressLabel: "Adresse",
        addressValue: "Rue de la Loi 200, 1040 Bruxelles, Belgique",
        manageCookies: "Gérer les cookies",
        copyright: "© {year} danswholesaleplants. Tous droits réservés.",
        terms: "Conditions",
        privacy: "Confidentialité",
        cookies: "Cookies",
        refund: "Politique de remboursement",
        disclaimer: "Avertissement"
      },
      readMore: "Consulter l’analyse",
      learnMore: "Explorer les détails",
      viewAll: "Voir toutes les ressources",
      form: {
        submit: "Envoyer",
        nameLabel: "Nom complet",
        namePlaceholder: "Entrez votre nom",
        emailLabel: "Adresse email",
        emailPlaceholder: "nom@domaine.com",
        orgLabel: "Organisation",
        orgPlaceholder: "Nom de votre structure",
        messageLabel: "Message",
        messagePlaceholder: "Décrivez votre demande",
        submitSuccess: "Transmission en cours : redirection vers la confirmation.",
        submitError: "Veuillez compléter les champs obligatoires avant envoi."
      },
      mapLabel: "Localisation interactive autour de Rue de la Loi 200 à Bruxelles"
    },
    cookies: {
      title: "Gestion des préférences de cookies",
      description: "Nous utilisons des cookies pour comprendre les interactions avec le site et améliorer l’orientation des contenus. Ajustez vos préférences à tout moment.",
      linkText: "En savoir plus dans la politique de cookies",
      manageToggle: "Afficher ou masquer les préférences détaillées",
      acceptAll: "Tout accepter",
      declineAll: "Tout refuser",
      saveSelection: "Enregistrer les préférences",
      categories: {
        necessary: {
          title: "Essentiels",
          description: "Actifs pour assurer la sécurité, la gestion de session et la mémorisation de votre langue. Ils ne peuvent pas être désactivés."
        },
        preferences: {
          title: "Préférences",
          description: "Utilisés pour conserver vos choix d’interface, comme l’affichage des cartes et les paramètres de navigation."
        },
        analytics: {
          title: "Analyse",
          description: "Aident à comprendre les parcours utilisateurs de manière agrégée afin d’améliorer nos publications."
        },
        marketing: {
          title: "Communication",
          description: "Servent à ajuster nos informations institutionnelles sur les canaux externes."
        }
      },
      toast: {
        accepted: "Toutes les catégories de cookies ont été activées.",
        declined: "Seuls les cookies essentiels restent actifs.",
        saved: "Vos préférences de cookies ont été mises à jour."
      }
    },
    toast: {
      languageSwitched: "La langue d’affichage a été mise à jour.",
      preferencesSaved: "Préférences enregistrées.",
      cookiesDeclined: "Cookies non essentiels désactivés.",
      cookiesAccepted: "Cookies activés.",
      formError: "Veuillez vérifier les champs requis.",
      formSuccess: "Soumission en cours, merci de patienter.",
      reopenCookies: "Ouverture des paramètres de cookies."
    },
    home: {
      meta: {
        title: "Orientation spatiale numérique en environnements complexes",
        description: "Analyses et cadres méthodologiques pour la signalétique numérique, la navigation intérieure et les parcours usagers dans les bâtiments publics et espaces urbains."
      },
      hero: {
        title: "Cartographier les parcours pour des environnements bâtis lisibles",
        subtitle: "Nous étudions la mobilité piétonne, la signalétique numérique et la conception informationnelle pour renforcer l’accessibilité et la compréhension spatiale en Belgique.",
        primary: "Explorer nos axes de recherche",
        secondary: "Consulter notre approche méthodologique",
        imageAlt: "Vue immersive d’un hall public avec signalétique numérique et flux piétons"
      },
      orientation: {
        heading: "Comprendre les comportements spatiaux",
        paragraph1: "Les environnements complexes exigent une lecture fine des interactions entre architecture, flux et information. Nous analysons les trajectoires, les points de décision et la perception des repères afin de qualifier la lisibilité des lieux.",
        paragraph2: "Cette compréhension nourrit des cartes narratives, des plans interactifs et des supports physiques cohérents qui facilitent la prise de décision des usagers tout en respectant les contraintes du bâti existant.",
        imageAlt: "Cartographie analytique des déplacements dans un bâtiment public",
        caption: "Visualisation des densités de circulation pour ajuster les jalons directionnels."
      },
      matrix: {
        heading: "Matrice d’orientation digitale",
        card1: {
          title: "Observation in situ",
          text: "Suivi qualitatif des déplacements, identification des temps d’arrêt et des zones de friction dans les bâtiments ouverts au public."
        },
        card2: {
          title: "Synthèse signalétique",
          text: "Alignement des dispositifs analogiques et numériques pour offrir des strates d’information complémentaires aux usagers."
        },
        card3: {
          title: "Scénarios utilisateurs",
          text: "Construction de parcours types par profils afin d’évaluer la continuité d’information et la cohérence des jalons."
        }
      },
      systems: {
        heading: "Systèmes dynamiques de guidage",
        paragraph1: "La signalétique numérique pose la question de la mise à jour en temps réel et de la gouvernance des contenus. Nous élaborons des protocoles pour garantir la fiabilité et la cohérence des messages diffusés.",
        paragraph2: "Nos livrables incluent des typologies de contenus, des matrices éditoriales et des conventions graphiques permettant d’orchestrer des réseaux d’écrans en lien avec la signalétique fixe.",
        imageAlt: "Mur interactif présentant un plan dynamique et des informations contextuelles",
        caption: "Interface contextuelle pour redistribuer les flux piétons lors d’événements ponctuels."
      },
      recommendations: {
        heading: "Recommandations structurantes",
        intro: "Axes de travail prioritaires pour renforcer la lisibilité des espaces publics complexes.",
        card1: {
          title: "Cohérence intermodale",
          text: "Relier les repères extérieurs et intérieurs grâce à un vocabulaire cartographique partagé."
        },
        card2: {
          title: "Accessibilité inclusive",
          text: "Prévoir des parcours multi-sensoriels garantissant une compréhension équivalente pour tous."
        },
        card3: {
          title: "Maintenance éditoriale",
          text: "Structurer des rôles et procédures pour garder chaque support pertinent dans le temps."
        }
      },
      testimonials: {
        heading: "Témoignages",
        intro: "Retours d’équipes publiques accompagnées sur des programmes d’orientation.",
        quote1: {
          text: "Le diagnostic réalisé a clarifié les zones de confusion et permis de prioriser des actions concrètes sur la signalétique existante.",
          author: "Claire Dumont, Direction des infrastructures urbaines de Bruxelles"
        },
        quote2: {
          text: "Les cartes d’usage proposent une lecture fine des besoins des visiteurs et constituent un support solide pour nos décisions futures.",
          author: "Marc Vandenberg, Responsable innovation d’un réseau hospitalier belge"
        }
      },
      latest: {
        heading: "Ressource récente",
        description: "Analyses détaillées des enjeux spatiaux et des outils numériques pour guider les usagers.",
        card: {
          title: "Indicatorisation des parcours piétons dans les pôles multimodaux",
          excerpt: "Quels indicateurs suivre pour qualifier les correspondances entre transports et cheminements piétons, et comment piloter les mises à jour en temps réel ?"
        },
        button: "Accéder à toutes les analyses"
      }
    },
    services: {
      meta: {
        title: "Axes d’expertise en orientation et cartographie des espaces",
        description: "Cinq volets d’intervention couvrant l’analyse des flux, la conception signalétique, la cartographie interactive, l’accessibilité et la recherche sur la lisibilité architecturale."
      },
      hero: {
        title: "Cinq axes pour orchestrer l’orientation spatiale",
        subtitle: "Chaque démarche repose sur des données contextuelles, une compréhension des flux et des conventions graphiques adaptées aux bâtiments publics belges."
      },
      overview: {
        intro: "Nos interventions se structurent en modules complémentaires, activables selon la maturité des dispositifs existants et les objectifs de transformation."
      },
      list: {
        item1: {
          title: "Analyse des comportements de déplacement",
          text: "Observation qualitative, instrumentation légère et modélisation des flux pour caractériser les points de friction et les besoins d’accompagnement."
        },
        item2: {
          title: "Design des systèmes informationnels",
          text: "Mise en cohérence des supports statiques et numériques, définition des gabarits et de la hiérarchie visuelle appliquée aux parcours."
        },
        item3: {
          title: "Cartographie interactive",
          text: "Conception d’interfaces cartographiques adaptatives, exploitation de données géospatiales et scénarios d’usage multi-supports."
        },
        item4: {
          title: "Conseil en UX spatiale",
          text: "Ateliers avec parties prenantes, matrices de besoins, scripts utilisateurs et recommandations pour des parcours inclusifs."
        },
        item5: {
          title: "Recherche sur la lisibilité architecturale",
          text: "Études comparatives et protocoles d’évaluation pour mesurer l’effet des interventions sur les trajectoires et la compréhension des lieux."
        }
      },
      methodology: {
        heading: "Méthodologie transversale",
        point1: "Immersion terrain, analyse documentaire et collecte de données quantitatives.",
        point2: "Cartes narratives reliant intentions architecturales et usages observés.",
        point3: "Boucles de test avec prototypes légers et retours utilisateurs ciblés."
      },
      imageAlt: "Équipe analysant des plans de signalétique dans une salle de projet"
    },
    about: {
      meta: {
        title: "Profil et approche de danswholesaleplants",
        description: "Organisation dédiée à l’étude de l’orientation spatiale, combinant recherche, analyse comportementale et conception informationnelle pour les espaces publics."
      },
      hero: {
        title: "Une approche systémique de l’orientation spatiale",
        subtitle: "Nous combinons urbanisme, design informationnel et sciences du comportement pour éclairer les décisions liées aux parcours usagers."
      },
      mission: {
        heading: "Mission",
        paragraph1: "Danswholesaleplants explore les interactions entre infrastructures publiques, repères visuels et attentes des usagers. Nous documentons la manière dont la signalétique influence les choix de déplacement et la perception des espaces.",
        paragraph2: "Les enseignements produits soutiennent les collectivités et institutions belges dans la transformation d’environnements complexes, sans démarche commerciale ni incitation à la consommation."
      },
      values: {
        heading: "Principes structurants",
        point1: "Evidence-based : chaque recommandation repose sur des données qualifiées et des observations croisées.",
        point2: "Inclusive : la pluralité des profils mobilitaires est prise en compte dès la phase de diagnostic.",
        point3: "Pérennité : nous accompagnons les équipes pour maintenir la cohérence éditoriale et graphique dans le temps."
      },
      history: {
        heading: "Repères chronologiques",
        milestone1: "2016 — Premières analyses de flux internes dans des campus hospitaliers bruxellois.",
        milestone2: "2019 — Intégration de cartographies interactives pour les réseaux de transport métropolitains.",
        milestone3: "2022 — Déploiement d’un protocole d’audit de lisibilité pour les équipements culturels régionaux."
      },
      imageAlt: "Table ronde d’experts examinant des plans d’orientation spatiale"
    },
    blog: {
      meta: {
        title: "Analyses et publications sur l’orientation spatiale",
        description: "Articles approfondis sur la signalétique numérique, la cartographie des espaces et l’accessibilité des parcours en Belgique."
      },
      hero: {
        title: "Analyses approfondies des environnements publics",
        subtitle: "Chaque publication documente une problématique de signalétique, de cartographie ou de mobilité piétonne à partir de terrains belges."
      },
      intro: "Sélectionnez un article pour approfondir les cadres méthodologiques et les indicateurs mobilisés.",
      cards: {
        post1: {
          title: "Indicatorisation des parcours piétons dans les pôles multimodaux",
          excerpt: "Méthodes pour qualifier la fluidité des correspondances et synchroniser les supports numériques aux usages temporels."
        },
        post2: {
          title: "Signalétique numérique dans les hôpitaux à circulation complexe",
          excerpt: "Analyse des besoins d’orientation des publics sensibles et articulation entre écrans et repères fixes."
        },
        post3: {
          title: "Cartographie narrative pour les campus universitaires ouverts",
          excerpt: "Comment structurer des plans interactifs intégrant temporalités, densités et services transverses."
        },
        post4: {
          title: "Flux piétonniers dans les équipements culturels patrimoniaux",
          excerpt: "Étudier l’influence de l’architecture historique sur la perception des itinéraires et l’accès aux zones temporaires."
        },
        post5: {
          title: "Expérimentation de balises visuelles dans les mairies belges",
          excerpt: "Retour sur des prototypes de guidage visuel et leur impact sur l’accueil des visiteurs."
        }
      },
      images: {
        post1Alt: "Schéma de correspondances piétonnes autour d’un hub multimodal",
        post2Alt: "Hall hospitalier avec signalétique digitale et visiteurs",
        post3Alt: "Plan interactif d’un campus universitaire affiché sur une borne",
        post4Alt: "Galerie d’un musée avec signalétique discrète orientant les visiteurs",
        post5Alt: "Couloir administratif avec repères colorés et pictogrammes directionnels"
      }
    },
    contact: {
      meta: {
        title: "Contact et coordination des échanges",
        description: "Coordonnées, carte interactive et formulaire pour initier des échanges concernant l’orientation spatiale en Belgique."
      },
      hero: {
        title: "Entrer en relation avec Danswholesaleplants",
        subtitle: "Partagez votre contexte pour que nous puissions documenter les enjeux d’orientation et de lisibilité des espaces."
      },
      details: {
        heading: "Coordonnées principales",
        phoneLabel: "Téléphone",
        emailLabel: "Email",
        addressLabel: "Adresse",
        hoursLabel: "Disponibilité",
        hoursValue: "Du lundi au vendredi, 09h00 – 17h30",
        mapTitle: "Carte interactive"
      },
      form: {
        heading: "Formulaire de prise de contact",
        consent: "Les informations transmises serviront uniquement à organiser un échange et ne seront pas utilisées à d’autres fins."
      },
      imageAlt: "Plan détaillé de Bruxelles avec surlignage du quartier européen"
    },
    faq: {
      meta: {
        title: "Questions fréquentes sur l’orientation spatiale",
        description: "Réponses concernant les méthodes d’analyse, la signalétique numérique et la cartographie des espaces publics."
      },
      hero: {
        title: "FAQ Orientation et signalétique",
        subtitle: "Précisions sur nos outils, nos livrables et notre périmètre d’étude."
      },
      questions: {
        q1: {
          question: "Comment sont observés les comportements de déplacement ?",
          answer: "Nous combinons observations discrètes, entretiens rapides et collecte anonymisée de données de flux afin d’identifier les points de décision et les zones de confusion."
        },
        q2: {
          question: "Quel rôle joue la signalétique numérique ?",
          answer: "Elle complète les supports physiques en apportant des informations contextuelles et évolutives, tout en respectant la charte graphique et les messages de référence."
        },
        q3: {
          question: "Comment intégrer l’accessibilité universelle ?",
          answer: "Les recommandations incluent des parcours multipliant les modalités sensorielles, des contrastes adaptés et des contenus audio ou tactiles lorsque pertinent."
        },
        q4: {
          question: "Quels livrables sont produits ?",
          answer: "Cartographies analytiques, scripts utilisateurs, matrices éditoriales et guides de déploiement, tous documentés pour faciliter la maintenance interne."
        },
        q5: {
          question: "Comment sont évalués les prototypes ?",
          answer: "Des tests in situ confrontent les hypothèses aux usages réels, avant d’itérer sur les supports ou d’ajuster la hiérarchie de l’information."
        },
        q6: {
          question: "Le travail couvre-t-il les espaces extérieurs ?",
          answer: "Oui, nous articulons les itinéraires extérieurs et intérieurs afin de garantir une continuité d’orientation entre espace public et bâtiment."
        }
      }
    },
    terms: {
      meta: {
        title: "Conditions d’utilisation",
        description: "Conditions d’utilisation du site danswholesaleplants décrivant responsabilités et engagements autour des contenus publiés."
      },
      hero: {
        title: "Conditions d’utilisation",
        subtitle: "Règles encadrant l’accès et l’usage des informations proposées sur ce site."
      },
      sections: {
        s1: {
          title: "1. Objet",
          text: "Les présentes conditions définissent le cadre d’utilisation du site danswholesaleplants.com et des contenus mis à disposition des visiteurs."
        },
        s2: {
          title: "2. Acceptation",
          text: "L’accès au site implique l’acceptation pleine et entière des présentes conditions, susceptibles d’être mises à jour sans préavis."
        },
        s3: {
          title: "3. Accès au site",
          text: "Le site est accessible gratuitement depuis la Belgique. Danswholesaleplants ne garantit pas l’absence d’interruptions techniques."
        },
        s4: {
          title: "4. Propriété intellectuelle",
          text: "Les textes, schémas et visuels publiés sont protégés. Toute reproduction nécessite l’accord préalable et écrit de danswholesaleplants."
        },
        s5: {
          title: "5. Contenus tiers",
          text: "Les références externes sont fournies à titre informatif. Danswholesaleplants ne peut être tenu responsable de leurs évolutions."
        },
        s6: {
          title: "6. Utilisation des données",
          text: "Aucune donnée personnelle n’est collectée sans consentement explicite. Les informations transmises via le formulaire sont traitées conformément à la politique de confidentialité."
        },
        s7: {
          title: "7. Responsabilités",
          text: "Les informations sont fournies à titre indicatif. Danswholesaleplants ne peut être tenu responsable des décisions prises sur la base des contenus publiés."
        },
        s8: {
          title: "8. Sécurité",
          text: "Des mesures techniques raisonnables protègent le site. L’utilisateur s’engage à ne pas porter atteinte à son intégrité."
        },
        s9: {
          title: "9. Liens entrants",
          text: "La création de liens vers le site est autorisée sous réserve de mentionner clairement la source et de ne pas dénaturer les contenus."
        },
        s10: {
          title: "10. Modifications",
          text: "Danswholesaleplants peut adapter les contenus et fonctionnalités du site pour les maintenir à jour avec les pratiques d’orientation spatiale."
        },
        s11: {
          title: "11. Suspension",
          text: "Le site peut être suspendu temporairement pour maintenance ou mise à jour sans engager la responsabilité de l’éditeur."
        },
        s12: {
          title: "12. Droit applicable",
          text: "Les présentes conditions sont régies par le droit belge. Tout litige relève de la compétence des tribunaux de Bruxelles."
        },
        s13: {
          title: "13. Contact",
          text: "Pour toute question liée aux conditions, merci d’utiliser le formulaire disponible sur la page de contact."
        },
        s14: {
          title: "14. Entrée en vigueur",
          text: "La dernière mise à jour des présentes conditions date du 15 mars 2024."
        }
      }
    },
    privacy: {
      meta: {
        title: "Politique de confidentialité",
        description: "Informations sur la collecte, l’usage, la conservation et les droits liés aux données personnelles gérées par danswholesaleplants."
      },
      hero: {
        title: "Politique de confidentialité",
        subtitle: "Transparence sur le traitement des données collectées via danswholesaleplants.com."
      },
      sections: {
        s1: {
          title: "1. Responsable du traitement",
          text: "Danswholesaleplants, Rue de la Loi 200, 1040 Bruxelles, assure la gestion des données collectées via ce site."
        },
        s2: {
          title: "2. Données collectées",
          text: "Les informations fournies via le formulaire de contact (nom, email, organisation, message) sont les seules données personnelles collectées."
        },
        s3: {
          title: "3. Finalités",
          text: "Les données servent exclusivement à répondre aux demandes reçues et à organiser un échange documentaire sur l’orientation spatiale."
        },
        s4: {
          title: "4. Base légale",
          text: "Le traitement repose sur le consentement explicite donné au moment de l’envoi du formulaire."
        },
        s5: {
          title: "5. Conservation",
          text: "Les données sont conservées pour une durée maximale de douze mois, sauf demande contraire de la personne concernée."
        },
        s6: {
          title: "6. Partage",
          text: "Aucune donnée n’est cédée à des tiers. Les informations restent au sein de l’équipe de danswholesaleplants."
        },
        s7: {
          title: "7. Sécurité",
          text: "Les échanges sont protégés par SSL/TLS et des mesures internes limitent l’accès aux seules personnes autorisées."
        },
        s8: {
          title: "8. Droits",
          text: "Vous disposez d’un droit d’accès, de rectification, d’effacement et de limitation du traitement en contactant contact@danswholesaleplants.com."
        },
        s9: {
          title: "9. Cookies",
          text: "Les préférences de cookies sont gérées via le bandeau dédié. Les détails figurent dans la politique de cookies."
        },
        s10: {
          title: "10. Mise à jour",
          text: "Cette politique peut évoluer pour refléter les pratiques en matière de données. La date de révision est indiquée ci-dessous."
        },
        s11: {
          title: "11. Contact",
          text: "Pour toute question relative à la confidentialité, utilisez le formulaire de contact ou écrivez à contact@danswholesaleplants.com."
        },
        s12: {
          title: "12. Date de révision",
          text: "Dernière mise à jour : 15 mars 2024."
        }
      }
    },
    cookiesPolicy: {
      meta: {
        title: "Politique de cookies",
        description: "Détails sur l’usage des cookies nécessaires, de préférences, d’analyse et de communication sur danswholesaleplants.com."
      },
      hero: {
        title: "Politique de cookies",
        subtitle: "Description des catégories de cookies et de leur finalité."
      },
      intro: {
        paragraph1: "Danswholesaleplants utilise des cookies afin d’assurer le fonctionnement du site, de mémoriser la langue choisie et d’évaluer l’usage des pages.",
        paragraph2: "Les cookies non essentiels ne sont activés qu’après votre consentement explicite. Vous pouvez ajuster vos préférences via le bandeau ou le lien en pied de page."
      },
      table: {
        heading: "Tableau récapitulatif des cookies",
        columns: {
          name: "Nom",
          provider: "Fournisseur",
          type: "Type",
          purpose: "Utilité",
          duration: "Durée"
        },
        rows: {
          r1: {
            name: "site_lang",
            provider: "danswholesaleplants.com",
            type: "Essentiel",
            purpose: "Mémorise la langue sélectionnée sur le site.",
            duration: "12 mois"
          },
          r2: {
            name: "cookie_consent",
            provider: "danswholesaleplants.com",
            type: "Essentiel",
            purpose: "Stocke les préférences exprimées dans le bandeau cookies.",
            duration: "12 mois"
          },
          r3: {
            name: "ux_preferences",
            provider: "danswholesaleplants.com",
            type: "Préférences",
            purpose: "Sauvegarde les modules visuels activés par l’utilisateur.",
            duration: "6 mois"
          },
          r4: {
            name: "analytics_viewport",
            provider: "danswholesaleplants.com",
            type: "Analyse",
            purpose: "Mesure anonymisée des dimensions d’écran pour adapter les contenus.",
            duration: "1 mois"
          },
          r5: {
            name: "outreach_context",
            provider: "danswholesaleplants.com",
            type: "Communication",
            purpose: "Ajuste la fréquence des messages institutionnels affichés sur le site.",
            duration: "3 mois"
          }
        }
      },
      choices: {
        heading: "Gestion de vos choix",
        paragraph1: "Vous pouvez à tout moment modifier votre décision en utilisant le bouton « Gérer les cookies » situé en bas de chaque page.",
        paragraph2: "La révocation du consentement n’affecte pas la légalité des traitements effectués avant cette modification."
      }
    },
    refund: {
      meta: {
        title: "Politique de remboursement",
        description: "Cadre applicable aux demandes de correction ou de retrait concernant les contenus publiés par danswholesaleplants."
      },
      hero: {
        title: "Politique de remboursement et de rectification",
        subtitle: "Modalités de traitement des demandes liées aux contenus diffusés."
      },
      sections: {
        s1: {
          title: "1. Champ d’application",
          text: "La présente politique s’applique aux demandes de correction ou de retrait concernant les analyses publiées sur le site."
        },
        s2: {
          title: "2. Absence de transaction",
          text: "Aucun service payant n’est proposé. Les demandes concernent uniquement la rectification des informations."
        },
        s3: {
          title: "3. Motifs recevables",
          text: "Sont recevables les demandes démontrant une inexactitude factuelle ou un préjudice lié à la diffusion d’un contenu."
        },
        s4: {
          title: "4. Procédure",
          text: "Les demandes doivent être formulées via le formulaire de contact avec une description précise de l’élément contesté."
        },
        s5: {
          title: "5. Analyse interne",
          text: "Chaque requête est examinée par l’équipe éditoriale qui vérifie les sources et l’intention initiale de la publication."
        },
        s6: {
          title: "6. Délai de traitement",
          text: "Une réponse est adressée sous trente jours calendaires à compter de la réception de la demande complète."
        },
        s7: {
          title: "7. Issues possibles",
          text: "La demande peut aboutir à une correction, un complément d’information ou un retrait partiel du contenu concerné."
        },
        s8: {
          title: "8. Information du demandeur",
          text: "Le demandeur est informé par email de la décision prise et des éventuelles actions réalisées."
        },
        s9: {
          title: "9. Conservation des échanges",
          text: "Les échanges relatifs à la demande sont conservés pour assurer un suivi et documenter les décisions."
        },
        s10: {
          title: "10. Révision de la politique",
          text: "Cette politique peut être ajustée afin de refléter l’évolution des pratiques éditoriales."
        }
      }
    },
    disclaimer: {
      meta: {
        title: "Avertissement",
        description: "Limites de responsabilité et absence de garanties relatives aux contenus du site danswholesaleplants."
      },
      hero: {
        title: "Avertissement",
        subtitle: "Les contenus sont fournis à titre informatif sans garantie de résultats."
      },
      sections: {
        s1: {
          title: "1. Nature des informations",
          text: "Les analyses proposées décrivent des méthodologies et observations liées à l’orientation spatiale. Elles ne constituent pas un engagement contractuel."
        },
        s2: {
          title: "2. Absence de garantie",
          text: "Danswholesaleplants ne garantit pas l’exactitude exhaustive ou la pérennité des informations publiées."
        },
        s3: {
          title: "3. Usage des contenus",
          text: "Toute utilisation des contenus se fait sous la responsabilité de l’utilisateur qui doit procéder aux vérifications nécessaires."
        },
        s4: {
          title: "4. Références externes",
          text: "Les liens vers des sites tiers sont fournis pour approfondir un sujet. Danswholesaleplants décline toute responsabilité quant à leur contenu."
        },
        s5: {
          title: "5. Modifications",
          text: "Les contenus peuvent être modifiés ou supprimés sans préavis pour refléter l’évolution des recherches."
        },
        s6: {
          title: "6. Contact",
          text: "Toute question relative à cet avertissement peut être adressée via le formulaire de contact."
        }
      }
    },
    thankYou: {
      meta: {
        title: "Confirmation d’envoi",
        description: "Message de confirmation suite à l’envoi du formulaire de contact."
      },
      hero: {
        title: "Merci pour votre message",
        subtitle: "Nous analysons votre demande et revenons vers vous dans les meilleurs délais."
      },
      content: {
        paragraph: "Un récapitulatif a été transmis à l’adresse fournie. Si vous n’avez rien reçu, pensez à vérifier votre dossier de courriers indésirables."
      },
      back: "Retourner à l’accueil"
    },
    notFound: {
      meta: {
        title: "Page non trouvée",
        description: "La page recherchée n’existe pas ou a été déplacée."
      },
      hero: {
        title: "404",
        subtitle: "La ressource demandée est introuvable."
      },
      content: {
        paragraph: "Vous pouvez revenir à l’accueil ou utiliser le menu principal pour explorer les autres sections.",
        button: "Retour vers l’accueil"
      }
    },
    posts: {
      post1: {
        meta: {
          title: "Indicatorisation des parcours piétons multimodaux",
          description: "Cadre méthodologique pour mesurer et piloter les parcours piétons dans les hubs multimodaux belges."
        },
        heroAlt: "Flux piétons traversant une gare multimodale moderne",
        title: "Indicatorisation des parcours piétons dans les pôles multimodaux belges",
        intro: "Les pôles multimodaux concentrent des flux piétons intenses où la synchronisation entre transports et information conditionne l’expérience. L’édification d’un référentiel d’indicateurs permet de qualifier les besoins d’orientation et d’établir des priorités de transformation.",
        section1: {
          title: "Construire un référentiel partagé",
          paragraph1: "La première étape consiste à cartographier les points d’intermodalité en distinguant les nœuds où les usagers arbitrent entre plusieurs options. À chaque nœud sont associés des éléments mesurables : densité horaire, temps d’attente, visibilité des jalons et clarté des pictogrammes. Les données proviennent d’observations, de comptages anonymisés et d’entretiens express organisés sur différentes plages horaires pour refléter la diversité des usages.",
          paragraph2: "L’indicateur principal agrège trois dimensions : le temps de décision, la cohérence des repères d’une étape à l’autre et la capacité à rejoindre la destination sans retour en arrière. Chaque dimension est notée sur une grille qualitative convertie en score. Ce référentiel partagé permet aux opérateurs de comparer les performances entre sites et d’identifier les zones prioritaires pour la mise à jour de la signalétique."
        },
        section1b: {
          title: "Affiner la lecture des flux secondaires",
          paragraph1: "Au-delà des axes principaux, les flux secondaires révèlent des itinéraires d’évitement ou des stratégies de contournement face à des zones perçues comme complexes. Leur analyse nécessite des relevés discrets et la superposition de trajectoires sur des plans à haute résolution. Ces données éclairent la perception des espaces dits de transition, souvent négligés dans les schémas directeurs.",
          paragraph2: "Les cartographies issues de cette analyse nourrissent la réflexion sur l’ajout de jalons temporaires ou la redistribution de l’information. Elles alimentent également des simulations de charge permettant d’anticiper l’impact d’événements exceptionnels tels que travaux, afflux saisonniers ou modifications d’horaires. Les indicateurs secondaires deviennent ainsi des leviers d’anticipation plutôt que de simples constats postérieurs."
        },
        section2: {
          title: "Piloter les mises à jour en continu",
          paragraph1: "L’indicateur de fiabilité temporelle mesure l’écart entre les données affichées et les changements réels de service. Pour rester pertinent, il s’appuie sur un protocole de coordination entre opérateurs : dès qu’un changement est acté, il est horodaté, catégorisé et diffusé via un tableau de bord partagé. Chaque mise à jour est auditée pour s’assurer que les supports physiques, numériques et audio délivrent une information harmonisée.",
          paragraph2: "Enfin, la boucle d’amélioration intègre des retours d’usagers collectés lors de campagnes ciblées. Les commentaires sont transformés en métadonnées qui viennent pondérer les indicateurs existants. Ce pilotage continu favorise une orientation fluide même en contexte de forte variabilité, condition essentielle pour des hubs multimodaux centrés sur la mobilité piétonne."
        }
      },
      post2: {
        meta: {
          title: "Signalétique numérique pour les hôpitaux complexes",
          description: "Étude de la signalétique numérique dans les hôpitaux belges aux circulations multiples."
        },
        heroAlt: "Couloir hospitalier avec écran d’orientation et visiteurs",
        title: "Signalétique numérique dans les hôpitaux à circulation complexe",
        intro: "La configuration labyrinthique de nombreux hôpitaux belges rend cruciale la mise en place de systèmes d’orientation fiables. Les écrans numériques complètent les repères physiques pour guider les publics sensibles, mais nécessitent une gouvernance attentive et des contenus fortement contextualisés.",
        section1: {
          title: "Diagnostiquer les parcours sensibles",
          paragraph1: "Le diagnostic débute par un repérage des segments où les patients cherchent le plus fréquemment de l’aide. Les observations montrent que les zones de jonction entre ascenseurs, services techniques et accueils spécialisés concentrent les sollicitations. Cartographier ces segments permet de cibler les emplacements d’écrans prioritaires, en lien avec la signalétique fixe existante.",
          paragraph2: "L’analyse qualitative révèle également l’importance de la tonalité des messages. Les patients attendent des formulations rassurantes, précises et exemptes d’ambiguïté. Les scénarios rédigés en co-construction avec les équipes médicales garantissent un vocabulaire aligné sur les pratiques internes tout en restant compréhensible pour un public non expert."
        },
        section1b: {
          title: "Synchroniser écrans et supports statiques",
          paragraph1: "La coexistence d’écrans et de panneaux physiques nécessite un protocole éditorial. Chaque mise à jour numérique est accompagnée d’une vérification de cohérence des supports statiques adjacents. Un tableau d’équivalence liste les destinations, les codes couleurs et les pictogrammes de référence afin d’éviter les divergences qui nuisent à la compréhension.",
          paragraph2: "Lorsque des travaux temporaires modifient les circulations, les écrans diffusent des messages contextuels enrichis de cartes simplifiées. Ces contenus sont validés via un circuit court impliquant maintenance, communication interne et responsables médicaux, ce qui limite le délai entre l’annonce et la diffusion. Les panneaux physiques reçoivent simultanément des compléments temporaires afin de conserver une expérience fluide."
        },
        section2: {
          title: "Mesurer l’efficacité des interventions",
          paragraph1: "L’efficacité de la signalétique numérique est évaluée grâce à des enquêtes légères menées auprès des patients à la sortie des services. Les questions portent sur la facilité à trouver la destination, la clarté des écrans et la complémentarité avec les supports existants. Les réponses sont corrélées avec des indicateurs de temps de parcours recueillis via des observations discrètes.",
          paragraph2: "Ces données alimentent une matrice de priorisation des améliorations. Les écrans dont la compréhension est jugée faible font l’objet d’un audit de contenu, tandis que les zones où les temps de trajet restent élevés sont réévaluées du point de vue architectural. Cette approche intégrée associe design informationnel, gestion de contenu et adaptation spatiale."
        }
      },
      post3: {
        meta: {
          title: "Cartographie narrative pour campus universitaires",
          description: "Méthodologie de cartographie narrative appliquée aux campus universitaires ouverts en Belgique."
        },
        heroAlt: "Étudiants consultant un plan interactif sur un campus",
        title: "Cartographie narrative pour les campus universitaires ouverts",
        intro: "Les campus ouverts combinent espaces académiques, services publics et lieux de vie. Pour faciliter la navigation, la cartographie narrative introduit des couches d’information adaptées aux temporalités et aux profils des usagers, tout en valorisant la spatialité singulière de chaque site.",
        section1: {
          title: "Décomposer les temporalités d’usage",
          paragraph1: "Un campus varie selon les heures de cours, les événements et les périodes d’examen. La cartographie narrative dissocie ces temporalités en créant des scénarios de fréquentation. Chaque scénario est associé à une palette graphique et à des jalons qui reflètent l’ambiance recherchée : sérénité pendant les révisions, convivialité lors des forums ou ouverture lors des visites.",
          paragraph2: "Cette approche renforce l’appropriation des lieux en donnant aux usagers des repères contextualisés. Les cartes dynamiques affichent par exemple les bâtiments accessibles tard le soir ou les itinéraires les plus calmes. Les informations sont filtrables afin de ne pas saturer l’écran, ce qui préserve la lisibilité pour des publics variés."
        },
        section1b: {
          title: "Intégrer les services transverses",
          paragraph1: "Les campus hébergent bibliothèques, restaurants, fablabs et services citoyens. La cartographie narrative relie ces ressources aux itinéraires principaux en créant des micro-histoires : « du laboratoire à la cafétéria en cinq minutes », « parcours accessible entre amphithéâtres ». Ces récits facilitent la projection et encouragent la découverte de lieux moins connus.",
          paragraph2: "Le système s’appuie sur une base de données centralisée décrivant les horaires, niveaux d’accessibilité, capacités et contacts. Chaque fiche est reliée à des pictogrammes et à des consignes simples que l’on retrouve sur les supports physiques. Cette cohérence visuelle renforce la crédibilité de la carte numérique et limite les divergences."
        },
        section2: {
          title: "Évaluer l’impact sur les pratiques",
          paragraph1: "Pour mesurer l’effet de la cartographie narrative, des ateliers sont organisés avec étudiants, chercheurs et visiteurs. Ils permettent d’observer la manière dont chacun interprète les cartes et de recueillir des suggestions de scénarios complémentaires. Les retours sont intégrés dans un tableau de bord alimenté par des indicateurs d’usage numérique.",
          paragraph2: "Les résultats montrent une meilleure répartition des flux et une réduction des questions d’orientation adressées au personnel d’accueil. Les données alimentent enfin une stratégie de maintenance des contenus, avec des alertes lorsque des informations deviennent obsolètes. La cartographie narrative devient ainsi un outil vivant, aligné sur la dynamique du campus."
        }
      },
      post4: {
        meta: {
          title: "Flux piétons dans les équipements culturels patrimoniaux",
          description: "Étude des flux piétonniers et de la signalétique dans les musées et centres patrimoniaux belges."
        },
        heroAlt: "Visiteurs circulant dans une galerie patrimoniale avec panneaux discrets",
        title: "Flux piétonniers dans les équipements culturels patrimoniaux",
        intro: "Les bâtiments patrimoniaux accueillent un public varié tout en préservant des éléments historiques. Construire une orientation efficace implique de concilier authenticité et lisibilité, en particulier lorsque les espaces ont été réaffectés ou réaménagés.",
        section1: {
          title: "Composer avec l’héritage architectural",
          paragraph1: "Les parcours d’origine n’étaient pas conçus pour accueillir les volumes actuels de visiteurs. Les circulations verticales ou les enfilades de salles imposent des rythmes spécifiques. L’analyse débute par une lecture attentive des contraintes patrimoniales pour identifier les zones où des ajouts de signalétique sont permis sans altérer les décors protégés.",
          paragraph2: "Des dispositifs légers, posés au sol ou suspendus à distance des structures, sont privilégiés. Ils renvoient vers des plans simplifiés disponibles sur supports numériques complémentaires. Cette stratégie limite l’impact visuel sur les murs tout en donnant aux visiteurs des repères indispensables pour se situer."
        },
        section1b: {
          title: "Répartir les flux selon les intentions curatoriales",
          paragraph1: "Les parcours doivent guider les visiteurs vers des salles clés tout en évitant la congestion. Des cartes thermiques obtenues par comptage discret révèlent les points de saturation. Elles servent à ajuster la hiérarchie des jalons, par exemple en proposant des itinéraires alternatifs vers des expositions temporaires.",
          paragraph2: "Les contenus diffusés sur les écrans d’accueil mettent en avant des suggestions de visites adaptées au temps disponible. Les textes sont concis, traduits et associés à des repères visuels que l’on retrouve sur les plans imprimés. Cette cohérence aide les visiteurs à mémoriser les enchaînements de salles."
        },
        section2: {
          title: "Documenter les retours visiteurs",
          paragraph1: "Des dispositifs de collecte qualitative sont installés à la sortie des parcours. Ils invitent les visiteurs à partager les zones de difficulté, l’efficacité des plans ou la pertinence des repères. Les retours sont classés par thématiques et reliés à des actions prioritaires, telles que l’ajout d’un jalon temporaire ou la simplification d’un texte.",
          paragraph2: "En parallèle, des indicateurs quantitatifs suivent la durée des visites et la répartition des flux. La confrontation entre données et retours qualitatifs permet d’ajuster la stratégie d’orientation sans compromettre la dimension patrimoniale des lieux."
        }
      },
      post5: {
        meta: {
          title: "Balises visuelles expérimentales dans les mairies",
          description: "Analyse de prototypes de balises visuelles installées dans des mairies belges pour orienter les visiteurs."
        },
        heroAlt: "Hall d’une mairie avec balises colorées et pictogrammes directionnels",
        title: "Expérimentation de balises visuelles dans les mairies belges",
        intro: "Les mairies concentrent de nombreux services et accueillent quotidiennement des usagers aux profils variés. Pour fluidifier l’orientation, plusieurs communes belges testent des balises visuelles modulaires intégrées aux espaces d’accueil.",
        section1: {
          title: "Identifier les points de décision",
          paragraph1: "Les balises sont positionnées aux intersections où les visiteurs hésitent ou sollicitent l’accueil. Une phase d’observation a permis de repérer ces zones : sorties d’ascenseurs, bifurcations entre services sociaux et services administratifs, accès aux salles de mariage. Chaque balise reprend une couleur associée à une typologie de service.",
          paragraph2: "Les pictogrammes sont conçus pour rester lisibles à plus de quinze mètres. Leur dessin respecte un code graphique partagé et s’accompagne d’un texte court. Les tests utilisateurs réalisés avec des groupes intergénérationnels ont affiné la taille des caractères et la hauteur des supports, assurant une visibilité pour tous."
        },
        section1b: {
          title: "Articuler balises et supports existants",
          paragraph1: "L’expérimentation ne remplace pas la signalétique existante ; elle vient la compléter. Des plans muraux actualisés rappellent la correspondance entre couleurs et services. Les agents d’accueil utilisent ce référentiel pour orienter verbalement les usagers, renforçant ainsi la cohérence du dispositif.",
          paragraph2: "Des mini-cartes distribuées aux visiteurs reprennent les repères colorés. Elles sont imprimées sur un support effaçable permettant d’ajouter des annotations temporaires. Cette solution simple aide à personnaliser l’information sans multiplier les dispositifs."
        },
        section2: {
          title: "Mesurer l’impact sur l’accueil",
          paragraph1: "Après trois mois d’essai, les mairies pilotes ont observé une baisse des demandes d’orientation génériques. Les agents peuvent se consacrer à des demandes plus complexes tandis que les visiteurs gagnent en autonomie. Les indicateurs proviennent d’un relevé quotidien du nombre de sollicitations et de questionnaires distribués en sortie.",
          paragraph2: "Les résultats montrent également une meilleure répartition des flux dans les couloirs. Les balises visuelles ont été adoptées durablement, avec un plan de maintenance qui inclut une vérification trimestrielle des supports et des contenus. L’expérimentation démontre la valeur des dispositifs modulaires dans les environnements administratifs."
        }
      }
    }
  },
  en: {
    common: {
      skipLink: "Skip to main content",
      brandName: "danswholesaleplants",
      nav: {
        home: "Home",
        services: "Services",
        about: "About",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      navToggle: "Open or close the primary navigation",
      languageFrench: "FR",
      languageEnglish: "EN",
      footer: {
        phoneLabel: "Phone",
        phoneValue: "+32 2 123 45 67",
        emailLabel: "Email",
        emailValue: "contact@danswholesaleplants.com",
        addressLabel: "Address",
        addressValue: "Rue de la Loi 200, 1040 Brussels, Belgium",
        manageCookies: "Manage cookies",
        copyright: "© {year} danswholesaleplants. All rights reserved.",
        terms: "Terms",
        privacy: "Privacy",
        cookies: "Cookies",
        refund: "Refund policy",
        disclaimer: "Disclaimer"
      },
      readMore: "Read the analysis",
      learnMore: "Discover details",
      viewAll: "See all resources",
      form: {
        submit: "Send",
        nameLabel: "Full name",
        namePlaceholder: "Enter your name",
        emailLabel: "Email address",
        emailPlaceholder: "name@domain.com",
        orgLabel: "Organisation",
        orgPlaceholder: "Name of your organisation",
        messageLabel: "Message",
        messagePlaceholder: "Describe your request",
        submitSuccess: "Submitting your message: redirecting to confirmation.",
        submitError: "Please complete the required fields before sending."
      },
      mapLabel: "Interactive map centered on Rue de la Loi 200 in Brussels"
    },
    cookies: {
      title: "Cookie preference management",
      description: "We use cookies to understand interactions with the site and improve wayfinding content. Adjust your choices at any moment.",
      linkText: "Learn more in the cookie policy",
      manageToggle: "Show or hide detailed preferences",
      acceptAll: "Accept all",
      declineAll: "Decline all",
      saveSelection: "Save preferences",
      categories: {
        necessary: {
          title: "Necessary",
          description: "Required for security, session management and language storage. They cannot be disabled."
        },
        preferences: {
          title: "Preferences",
          description: "Used to remember interface options such as map display and navigation settings."
        },
        analytics: {
          title: "Analytics",
          description: "Help us understand aggregated user journeys to improve our publications."
        },
        marketing: {
          title: "Communication",
          description: "Adjusts institutional messages displayed on the site."
        }
      },
      toast: {
        accepted: "All cookie categories have been enabled.",
        declined: "Only essential cookies remain active.",
        saved: "Your cookie preferences have been updated."
      }
    },
    toast: {
      languageSwitched: "Display language has been updated.",
      preferencesSaved: "Preferences saved.",
      cookiesDeclined: "Non-essential cookies disabled.",
      cookiesAccepted: "Cookies enabled.",
      formError: "Please review the required fields.",
      formSuccess: "Submission in progress, thank you.",
      reopenCookies: "Opening cookie settings."
    },
    home: {
      meta: {
        title: "Digital wayfinding in complex environments",
        description: "Research insights on digital signage, indoor navigation and user journeys across public buildings and urban spaces."
      },
      hero: {
        title: "Mapping journeys for legible built environments",
        subtitle: "We study pedestrian mobility, digital signage and information design to strengthen accessibility and spatial comprehension across Belgium.",
        primary: "Explore our research pillars",
        secondary: "Review our methodological approach",
        imageAlt: "Immersive view of a public hall with digital signage and pedestrian flow"
      },
      orientation: {
        heading: "Understanding spatial behaviours",
        paragraph1: "Complex environments require a precise reading of how architecture, flows and information interact. We analyse trajectories, decision points and landmark perception to qualify the legibility of places.",
        paragraph2: "These insights feed narrative maps, interactive plans and coherent physical supports that help people make decisions while respecting existing built constraints.",
        imageAlt: "Analytical mapping of movement inside a large public building",
        caption: "Circulation density visualisation informing the placement of directional cues."
      },
      matrix: {
        heading: "Digital wayfinding matrix",
        card1: {
          title: "In-situ observation",
          text: "Qualitative monitoring of movements, identification of dwell times and friction zones in public-facing buildings."
        },
        card2: {
          title: "Signage synthesis",
          text: "Alignment of analogue and digital systems to offer complementary layers of information to visitors."
        },
        card3: {
          title: "User scenarios",
          text: "Building journey profiles to evaluate continuity of information and the consistency of touchpoints."
        }
      },
      systems: {
        heading: "Dynamic guidance systems",
        paragraph1: "Digital signage questions real-time updates and content governance. We design protocols that guarantee reliable, coherent messaging across networks of screens.",
        paragraph2: "Deliverables include content typologies, editorial matrices and graphic conventions enabling coordinated deployment alongside fixed signage.",
        imageAlt: "Interactive wall showing a dynamic map with contextual information",
        caption: "Contextual interface redirecting pedestrian flows during temporary events."
      },
      recommendations: {
        heading: "Structuring recommendations",
        intro: "Priority workstreams to reinforce legibility across complex public spaces.",
        card1: {
          title: "Intermodal coherence",
          text: "Link outdoor and indoor landmarks with a shared cartographic vocabulary."
        },
        card2: {
          title: "Inclusive accessibility",
          text: "Plan multi-sensory journeys to guarantee equivalent understanding for everyone."
        },
        card3: {
          title: "Editorial maintenance",
          text: "Structure roles and procedures to keep every support relevant over time."
        }
      },
      testimonials: {
        heading: "Testimonials",
        intro: "Feedback from public teams supported on orientation programmes.",
        quote1: {
          text: "The diagnostic clarified confusion points and helped us prioritise concrete actions on existing signage.",
          author: "Claire Dumont, Brussels Urban Infrastructure Directorate"
        },
        quote2: {
          text: "The usage maps provide a fine reading of visitor needs and form a robust basis for our future decisions.",
          author: "Marc Vandenberg, Innovation Lead, Belgian hospital network"
        }
      },
      latest: {
        heading: "Latest resource",
        description: "Detailed analyses of spatial issues and digital tools guiding users.",
        card: {
          title: "Tracking pedestrian indicators in multimodal hubs",
          excerpt: "Which metrics qualify the link between transport connections and pedestrian journeys, and how to orchestrate real-time updates?"
        },
        button: "Access all analyses"
      }
    },
    services: {
      meta: {
        title: "Wayfinding and spatial mapping expertise",
        description: "Five areas of work covering flow analysis, signage design, interactive mapping, accessibility consulting and legibility research."
      },
      hero: {
        title: "Five pillars to orchestrate spatial orientation",
        subtitle: "Each initiative relies on contextual data, flow comprehension and tailored graphic conventions for Belgian public buildings."
      },
      overview: {
        intro: "Our contributions are organised into complementary modules activated according to existing systems and transformation goals."
      },
      list: {
        item1: {
          title: "Movement behaviour analysis",
          text: "Qualitative observation, light instrumentation and flow modelling to characterise friction points and support needs."
        },
        item2: {
          title: "Information system design",
          text: "Bringing static and digital supports into alignment, defining templates and visual hierarchy along user journeys."
        },
        item3: {
          title: "Interactive mapping",
          text: "Designing adaptive cartographic interfaces, leveraging geospatial data and multi-device usage scenarios."
        },
        item4: {
          title: "Spatial UX consulting",
          text: "Workshops with stakeholders, need matrices, user scripts and recommendations for inclusive journeys."
        },
        item5: {
          title: "Legibility research",
          text: "Comparative studies and evaluation protocols to measure the impact of interventions on trajectories and understanding."
        }
      },
      methodology: {
        heading: "Cross-cutting methodology",
        point1: "Field immersion, document review and quantitative data capture.",
        point2: "Narrative mapping connecting architectural intent with observed usage.",
        point3: "Testing loops with lightweight prototypes and targeted user feedback."
      },
      imageAlt: "Team reviewing wayfinding plans around a project table"
    },
    about: {
      meta: {
        title: "About danswholesaleplants",
        description: "Entity dedicated to spatial orientation, combining research, behavioural analysis and information design for public spaces."
      },
      hero: {
        title: "A systemic approach to spatial orientation",
        subtitle: "We combine urban planning, information design and behavioural science to support decisions about user journeys."
      },
      mission: {
        heading: "Mission",
        paragraph1: "Danswholesaleplants explores how public infrastructures, visual cues and user expectations interact. We document how signage influences movement choices and space perception.",
        paragraph2: "Our findings support Belgian authorities and institutions in transforming complex environments, without commercial objectives or promotional incentives."
      },
      values: {
        heading: "Core principles",
        point1: "Evidence-based: every recommendation is grounded in qualified data and converging observations.",
        point2: "Inclusive: diverse mobility profiles are considered from the diagnostic phase onward.",
        point3: "Continuity: we help teams maintain editorial and graphic coherence over time."
      },
      history: {
        heading: "Timeline",
        milestone1: "2016 — Initial flow analyses within Brussels hospital campuses.",
        milestone2: "2019 — Integration of interactive mapping for metropolitan transport networks.",
        milestone3: "2022 — Deployment of a legibility audit protocol for regional cultural venues."
      },
      imageAlt: "Expert roundtable reviewing spatial orientation diagrams"
    },
    blog: {
      meta: {
        title: "Wayfinding insights and publications",
        description: "In-depth articles on digital signage, spatial mapping and accessibility for public spaces in Belgium."
      },
      hero: {
        title: "Deep dives into public environments",
        subtitle: "Each publication documents a signage, mapping or pedestrian mobility topic grounded in Belgian contexts."
      },
      intro: "Select an article to explore methodological frameworks and indicators in detail.",
      cards: {
        post1: {
          title: "Tracking pedestrian indicators in multimodal hubs",
          excerpt: "Methods to qualify transfer fluidity and align digital supports with time-based usage."
        },
        post2: {
          title: "Digital signage within complex hospital circulations",
          excerpt: "Analysing orientation needs of sensitive audiences and articulating screens with fixed landmarks."
        },
        post3: {
          title: "Narrative mapping for open university campuses",
          excerpt: "Structuring interactive plans that integrate temporalities, densities and transversal services."
        },
        post4: {
          title: "Pedestrian flows in heritage cultural venues",
          excerpt: "Studying how historical architecture shapes route perception and access to temporary zones."
        },
        post5: {
          title: "Visual beacons tested in Belgian town halls",
          excerpt: "Reviewing prototype guidance devices and their impact on visitor reception."
        }
      },
      images: {
        post1Alt: "Diagram of pedestrian transfers around a multimodal hub",
        post2Alt: "Hospital lobby featuring digital guidance screens",
        post3Alt: "Interactive campus map displayed on a kiosk",
        post4Alt: "Museum gallery with discreet signage guiding visitors",
        post5Alt: "Administrative corridor with coloured directional beacons"
      }
    },
    contact: {
      meta: {
        title: "Contact and coordination",
        description: "Contact details, interactive map and form to initiate exchanges about spatial orientation in Belgium."
      },
      hero: {
        title: "Connect with Danswholesaleplants",
        subtitle: "Share your context so we can document orientation and legibility challenges."
      },
      details: {
        heading: "Primary contact details",
        phoneLabel: "Phone",
        emailLabel: "Email",
        addressLabel: "Address",
        hoursLabel: "Availability",
        hoursValue: "Monday to Friday, 09:00 – 17:30",
        mapTitle: "Interactive map"
      },
      form: {
        heading: "Contact form",
        consent: "Submitted information will be used solely to organise an exchange and will not be repurposed."
      },
      imageAlt: "Detailed map of Brussels highlighting the European quarter"
    },
    faq: {
      meta: {
        title: "Wayfinding FAQ",
        description: "Answers about analysis methods, digital signage and mapping of public environments."
      },
      hero: {
        title: "FAQ Wayfinding and signage",
        subtitle: "Clarifications on our tools, deliverables and scope of study."
      },
      questions: {
        q1: {
          question: "How are movement behaviours observed?",
          answer: "We combine discreet observation, short interviews and anonymised flow data to identify decision points and areas of confusion."
        },
        q2: {
          question: "What role does digital signage play?",
          answer: "It complements physical supports by delivering contextual and evolving information while respecting core guidelines and reference messages."
        },
        q3: {
          question: "How is universal accessibility addressed?",
          answer: "Recommendations include multi-sensory journeys, appropriate contrast levels and audio or tactile content whenever relevant."
        },
        q4: {
          question: "What deliverables are provided?",
          answer: "Analytical maps, user scripts, editorial matrices and deployment guides, all documented to support internal maintenance."
        },
        q5: {
          question: "How are prototypes evaluated?",
          answer: "In-situ testing confronts hypotheses with actual usage before iterating on supports or adjusting information hierarchy."
        },
        q6: {
          question: "Does the work cover outdoor spaces?",
          answer: "Yes, we articulate outdoor and indoor routes to guarantee continuous orientation across public space and buildings."
        }
      }
    },
    terms: {
      meta: {
        title: "Terms of use",
        description: "Terms governing the use of danswholesaleplants content and responsibilities."
      },
      hero: {
        title: "Terms of use",
        subtitle: "Rules governing access to and use of information published on this site."
      },
      sections: {
        s1: {
          title: "1. Purpose",
          text: "These terms define the framework for using danswholesaleplants.com and its content."
        },
        s2: {
          title: "2. Acceptance",
          text: "Accessing the site implies full acceptance of these terms, which may be updated without notice."
        },
        s3: {
          title: "3. Site access",
          text: "The site is freely accessible from Belgium. Danswholesaleplants cannot guarantee uninterrupted availability."
        },
        s4: {
          title: "4. Intellectual property",
          text: "Published texts, diagrams and visuals are protected. Any reproduction requires prior written authorisation."
        },
        s5: {
          title: "5. Third-party content",
          text: "External references are provided for information only. Danswholesaleplants is not responsible for their evolution."
        },
        s6: {
          title: "6. Data usage",
          text: "No personal data is collected without explicit consent. Information submitted via the form is handled per the privacy policy."
        },
        s7: {
          title: "7. Responsibilities",
          text: "Information is provided for guidance. Danswholesaleplants cannot be held liable for decisions made based on published content."
        },
        s8: {
          title: "8. Security",
          text: "Reasonable technical measures protect the site. Users agree not to compromise its integrity."
        },
        s9: {
          title: "9. Incoming links",
          text: "Linking to the site is allowed if the source is clearly mentioned and content is not distorted."
        },
        s10: {
          title: "10. Changes",
          text: "Danswholesaleplants may adjust content and features to keep pace with wayfinding practices."
        },
        s11: {
          title: "11. Suspension",
          text: "The site may be temporarily suspended for maintenance or updates without liability."
        },
        s12: {
          title: "12. Governing law",
          text: "These terms are governed by Belgian law. Disputes fall under the jurisdiction of Brussels courts."
        },
        s13: {
          title: "13. Contact",
          text: "For questions regarding the terms, please use the contact form."
        },
        s14: {
          title: "14. Effective date",
          text: "These terms were last updated on 15 March 2024."
        }
      }
    },
    privacy: {
      meta: {
        title: "Privacy policy",
        description: "Details on data collection, usage, storage and rights managed by danswholesaleplants."
      },
      hero: {
        title: "Privacy policy",
        subtitle: "Transparency regarding data processing on danswholesaleplants.com."
      },
      sections: {
        s1: {
          title: "1. Data controller",
          text: "Danswholesaleplants, Rue de la Loi 200, 1040 Brussels, manages data collected through this site."
        },
        s2: {
          title: "2. Data collected",
          text: "Only information provided via the contact form (name, email, organisation, message) is collected."
        },
        s3: {
          title: "3. Purpose",
          text: "Data is used solely to respond to enquiries and organise exchanges about spatial orientation."
        },
        s4: {
          title: "4. Legal basis",
          text: "Processing is based on the explicit consent given when submitting the form."
        },
        s5: {
          title: "5. Retention",
          text: "Data is retained for up to twelve months unless the data subject requests deletion earlier."
        },
        s6: {
          title: "6. Sharing",
          text: "No data is shared with third parties. Information stays within the danswholesaleplants team."
        },
        s7: {
          title: "7. Security",
          text: "SSL/TLS encryption and internal safeguards limit data access to authorised persons."
        },
        s8: {
          title: "8. Rights",
          text: "You have rights of access, rectification, erasure and restriction by contacting contact@danswholesaleplants.com."
        },
        s9: {
          title: "9. Cookies",
          text: "Cookie preferences are managed via the banner. Details are provided in the cookie policy."
        },
        s10: {
          title: "10. Updates",
          text: "This policy may evolve to reflect data practices. The revision date is provided below."
        },
        s11: {
          title: "11. Contact",
          text: "For privacy questions, use the contact form or email contact@danswholesaleplants.com."
        },
        s12: {
          title: "12. Revision date",
          text: "Last updated: 15 March 2024."
        }
      }
    },
    cookiesPolicy: {
      meta: {
        title: "Cookie policy",
        description: "Details on necessary, preference, analytics and communication cookies used on danswholesaleplants.com."
      },
      hero: {
        title: "Cookie policy",
        subtitle: "Description of cookie categories and their purpose."
      },
      intro: {
        paragraph1: "Danswholesaleplants uses cookies to ensure site operation, remember the selected language and assess page usage.",
        paragraph2: "Non-essential cookies are activated only after your explicit consent. You can adjust your choices via the banner or footer link."
      },
      table: {
        heading: "Cookie overview",
        columns: {
          name: "Name",
          provider: "Provider",
          type: "Type",
          purpose: "Purpose",
          duration: "Duration"
        },
        rows: {
          r1: {
            name: "site_lang",
            provider: "danswholesaleplants.com",
            type: "Necessary",
            purpose: "Stores the language selected on the site.",
            duration: "12 months"
          },
          r2: {
            name: "cookie_consent",
            provider: "danswholesaleplants.com",
            type: "Necessary",
            purpose: "Stores the preferences expressed in the cookie banner.",
            duration: "12 months"
          },
          r3: {
            name: "ux_preferences",
            provider: "danswholesaleplants.com",
            type: "Preferences",
            purpose: "Keeps optional visual modules enabled by the user.",
            duration: "6 months"
          },
          r4: {
            name: "analytics_viewport",
            provider: "danswholesaleplants.com",
            type: "Analytics",
            purpose: "Measures anonymised screen dimensions to adapt content.",
            duration: "1 month"
          },
          r5: {
            name: "outreach_context",
            provider: "danswholesaleplants.com",
            type: "Communication",
            purpose: "Adjusts the frequency of institutional messages displayed on the site.",
            duration: "3 months"
          }
        }
      },
      choices: {
        heading: "Managing your choices",
        paragraph1: "You can revise your decision at any time using the “Manage cookies” button at the bottom of each page.",
        paragraph2: "Withdrawing consent does not affect the lawfulness of processing carried out before the change."
      }
    },
    refund: {
      meta: {
        title: "Refund and correction policy",
        description: "Framework for addressing correction or withdrawal requests regarding published content."
      },
      hero: {
        title: "Refund and rectification policy",
        subtitle: "How we process requests related to published analyses."
      },
      sections: {
        s1: {
          title: "1. Scope",
          text: "This policy applies to correction or withdrawal requests concerning analyses published on the site."
        },
        s2: {
          title: "2. No transaction",
          text: "No paid service is offered. Requests focus solely on information accuracy."
        },
        s3: {
          title: "3. Valid grounds",
          text: "Requests must demonstrate factual inaccuracies or harm linked to published content."
        },
        s4: {
          title: "4. Procedure",
          text: "Requests must be submitted via the contact form with a precise description of the element in question."
        },
        s5: {
          title: "5. Internal review",
          text: "Each request is examined by the editorial team, checking sources and original intent."
        },
        s6: {
          title: "6. Processing time",
          text: "A response is issued within thirty calendar days from receipt of a complete request."
        },
        s7: {
          title: "7. Possible outcomes",
          text: "Outcomes include correction, additional context or partial removal of the concerned content."
        },
        s8: {
          title: "8. Requester information",
          text: "The requester is informed by email of the decision and actions taken."
        },
        s9: {
          title: "9. Record keeping",
          text: "Exchanges related to the request are stored to document decisions and ensure follow-up."
        },
        s10: {
          title: "10. Policy updates",
          text: "This policy may be adjusted to reflect evolving editorial practices."
        }
      }
    },
    disclaimer: {
      meta: {
        title: "Disclaimer",
        description: "Liability limitations and absence of guarantees regarding danswholesaleplants content."
      },
      hero: {
        title: "Disclaimer",
        subtitle: "Content is provided for information without guaranteed outcomes."
      },
      sections: {
        s1: {
          title: "1. Nature of information",
          text: "Analyses describe methodologies and observations related to spatial orientation. They do not form a contractual commitment."
        },
        s2: {
          title: "2. No warranty",
          text: "Danswholesaleplants does not guarantee exhaustive accuracy or ongoing relevance of published information."
        },
        s3: {
          title: "3. Content usage",
          text: "Any use of the content is at the user’s own responsibility, who should run appropriate checks."
        },
        s4: {
          title: "4. External references",
          text: "Links to third-party sites are provided for further reading. Danswholesaleplants declines responsibility for their content."
        },
        s5: {
          title: "5. Changes",
          text: "Content may be modified or removed without notice to reflect research progress."
        },
        s6: {
          title: "6. Contact",
          text: "Questions about this disclaimer can be sent via the contact form."
        }
      }
    },
    thankYou: {
      meta: {
        title: "Submission confirmed",
        description: "Confirmation message following contact form submission."
      },
      hero: {
        title: "Thank you for your message",
        subtitle: "We are reviewing your enquiry and will respond shortly."
      },
      content: {
        paragraph: "A summary has been sent to the provided email address. If you do not receive it, please check your spam folder."
      },
      back: "Return to homepage"
    },
    notFound: {
      meta: {
        title: "Page not found",
        description: "The requested page does not exist or has been moved."
      },
      hero: {
        title: "404",
        subtitle: "The requested resource could not be found."
      },
      content: {
        paragraph: "You can return to the homepage or use the main menu to explore other sections.",
        button: "Back to homepage"
      }
    },
    posts: {
      post1: {
        meta: {
          title: "Tracking pedestrian indicators in multimodal hubs",
          description: "Methodological framework to measure and manage pedestrian journeys in Belgian multimodal hubs."
        },
        heroAlt: "Pedestrian flow crossing a modern multimodal station",
        title: "Tracking pedestrian indicators in Belgian multimodal hubs",
        intro: "Multimodal hubs host intense pedestrian flows where synchronisation between transport and information shapes the overall experience. Building a shared indicator framework qualifies orientation needs and sets priorities for transformation.",
        section1: {
          title: "Building a shared reference",
          paragraph1: "The first step maps intermodality points by isolating nodes where travellers choose between several options. Each node is linked to measurable elements: hourly density, waiting time, landmark visibility and clarity of pictograms. Data comes from observations, anonymised counts and quick interviews across different time slots to reflect usage diversity.",
          paragraph2: "The main indicator aggregates three dimensions: decision time, consistency of cues from one step to the next and the ability to reach the destination without backtracking. Each dimension is scored on a qualitative grid converted into a numeric value. This shared reference lets operators compare site performance and identify priority areas for signage updates."
        },
        section1b: {
          title: "Reading secondary flows",
          paragraph1: "Beyond primary axes, secondary flows reveal avoidance routes or detours triggered by perceived complexity. Analysing them requires discreet tracking and overlaying trajectories on high-resolution plans. The data sheds light on transition spaces often overlooked in master plans.",
          paragraph2: "Resulting maps inform discussions about adding temporary cues or redistributing information. They also feed load simulations that anticipate the effect of extraordinary events such as works, seasonal peaks or schedule changes. Secondary indicators thus become anticipation levers instead of retrospective metrics."
        },
        section2: {
          title: "Orchestrating continuous updates",
          paragraph1: "The timeliness indicator measures the gap between displayed data and actual service changes. To stay relevant, it relies on a coordination protocol among operators: once a change is confirmed, it is timestamped, categorised and shared via a joint dashboard. Each update is audited to ensure physical, digital and audio supports deliver a harmonised message.",
          paragraph2: "Finally, the improvement loop integrates user feedback collected during targeted campaigns. Comments are transformed into metadata that adjust existing indicators. Continuous management keeps orientation fluid even in highly variable contexts—a key condition for pedestrian-centred multimodal hubs."
        }
      },
      post2: {
        meta: {
          title: "Digital signage for complex hospitals",
          description: "Study of digital signage within Belgian hospitals featuring multiple circulation patterns."
        },
        heroAlt: "Hospital corridor with wayfinding screen and visitors",
        title: "Digital signage within complex hospital circulations",
        intro: "Many Belgian hospitals feature labyrinthine layouts, making reliable orientation systems essential. Digital screens complement physical landmarks to guide sensitive audiences, but they require careful governance and strongly contextualised content.",
        section1: {
          title: "Diagnosing sensitive journeys",
          paragraph1: "Diagnosis begins by spotting segments where patients most frequently seek assistance. Observations show that junctions between lifts, technical services and specialised receptions concentrate requests. Mapping these segments highlights priority screen locations in relation to existing fixed signage.",
          paragraph2: "Qualitative analysis also stresses the tone of messages. Patients expect reassuring, precise wording free of ambiguity. Scripts co-written with medical teams secure vocabulary aligned with internal practices while remaining accessible for non-experts."
        },
        section1b: {
          title: "Synchronising screens and static supports",
          paragraph1: "Coexistence of screens and physical panels needs an editorial protocol. Every digital update is paired with a coherence check of nearby static supports. An equivalence table lists destinations, colour codes and reference pictograms to avoid discrepancies that hinder comprehension.",
          paragraph2: "When temporary works modify circulation, screens display contextual messages enriched with simplified maps. Content is validated via a short approval loop involving maintenance, internal communications and medical leads, cutting delays between decision and broadcast. Physical panels simultaneously receive temporary add-ons to maintain a seamless experience."
        },
        section2: {
          title: "Assessing intervention impact",
          paragraph1: "Effectiveness of digital signage is evaluated through short surveys at service exits. Questions cover ease of finding destinations, clarity of screens and complementarity with existing supports. Responses are correlated with travel-time indicators gathered from discreet observations.",
          paragraph2: "The data feeds a prioritisation matrix. Screens with low comprehension scores undergo content audits, while zones with persistent travel times are reassessed architecturally. The integrated approach combines information design, content management and spatial adaptation."
        }
      },
      post3: {
        meta: {
          title: "Narrative mapping for university campuses",
          description: "Narrative mapping methodology applied to open university campuses in Belgium."
        },
        heroAlt: "Students looking at an interactive map on a campus",
        title: "Narrative mapping for open university campuses",
        intro: "Open campuses mix academic spaces, public services and daily-life facilities. Narrative mapping introduces information layers aligned with temporalities and user profiles while emphasising each site’s spatial identity.",
        section1: {
          title: "Decomposing usage temporalities",
          paragraph1: "Campus activity shifts with classes, events and exam periods. Narrative mapping separates these timeframes by crafting usage scenarios. Each scenario receives a dedicated graphic palette and cues reflecting the intended atmosphere: calm during revision, vibrant during forums or welcoming for open days.",
          paragraph2: "This approach helps users project themselves with contextualised cues. Dynamic maps highlight buildings open late or the quietest routes. Information remains filterable to avoid overloading the screen, preserving legibility for varied audiences."
        },
        section1b: {
          title: "Integrating transversal services",
          paragraph1: "Campuses host libraries, eateries, fab labs and civic services. Narrative mapping connects these resources to main routes by creating micro-stories such as “from the lab to the cafeteria in five minutes” or “accessible path between lecture halls.” These narratives encourage exploration of lesser-known places.",
          paragraph2: "The system relies on a central database describing schedules, accessibility levels, capacities and contacts. Each entry aligns with pictograms and concise guidelines repeated on physical supports. Visual coherence strengthens trust in the digital map and reduces divergence."
        },
        section2: {
          title: "Measuring impact on practices",
          paragraph1: "Workshops with students, researchers and visitors gauge how each audience interprets the maps. Feedback feeds a dashboard enriched with digital usage indicators. Suggestions lead to additional scenarios or refined filters.",
          paragraph2: "Results show better flow distribution and fewer orientation questions at reception desks. Data also powers a content maintenance strategy with alerts when information becomes outdated. Narrative mapping thus becomes a living tool aligned with campus dynamics."
        }
      },
      post4: {
        meta: {
          title: "Pedestrian flows in heritage cultural venues",
          description: "Study of pedestrian flows and signage in Belgian museums and heritage centres."
        },
        heroAlt: "Visitors walking through a heritage gallery with discreet signage",
        title: "Pedestrian flows in heritage cultural venues",
        intro: "Heritage buildings welcome diverse audiences while preserving historic elements. Effective orientation reconciles authenticity with legibility, especially when spaces have been repurposed.",
        section1: {
          title: "Working with architectural heritage",
          paragraph1: "Original routes were not designed for today’s visitor volumes. Vertical circulation or long enfilades impose specific rhythms. Analysis starts with a close reading of heritage constraints to spot where signage additions are possible without altering protected decor.",
          paragraph2: "Lightweight devices placed on the floor or suspended away from structures are preferred. They reference simplified plans available on complementary digital supports. The strategy limits visual impact while providing essential positioning cues."
        },
        section1b: {
          title: "Balancing flows with curatorial intent",
          paragraph1: "Journeys must lead visitors to key rooms while avoiding congestion. Heat maps from discreet counting reveal saturation points, guiding adjustments to the hierarchy of cues, including alternate pathways to temporary exhibitions.",
          paragraph2: "Entrance screens highlight visit suggestions tailored to available time. Texts remain concise, translated and paired with visual references echoed on printed plans, helping visitors memorise room sequences."
        },
        section2: {
          title: "Documenting visitor feedback",
          paragraph1: "Qualitative feedback stations at exits invite visitors to describe difficulties, map usefulness and cue relevance. Responses are categorised and linked to priority actions such as adding temporary markers or simplifying text.",
          paragraph2: "Quantitative indicators track visit length and flow distribution. Crossing both datasets refines orientation strategy without compromising the venue’s heritage dimension."
        }
      },
      post5: {
        meta: {
          title: "Visual beacons tested in town halls",
          description: "Analysis of modular visual beacons installed in Belgian town halls to orient visitors."
        },
        heroAlt: "Town hall lobby with coloured directional beacons and pictograms",
        title: "Visual beacons tested in Belgian town halls",
        intro: "Town halls gather numerous services and welcome visitors with varied expectations. Belgian municipalities are testing modular visual beacons integrated into reception areas to streamline orientation.",
        section1: {
          title: "Identifying decision points",
          paragraph1: "Beacons sit at intersections where visitors hesitate or seek assistance. Observation pinpointed these zones: lift exits, junctions between social and administrative services, and access to ceremonial rooms. Each beacon carries a colour linked to a service family.",
          paragraph2: "Pictograms remain legible beyond fifteen metres, follow a shared graphic code and pair with concise text. User tests across age groups refined character size and support height to ensure visibility for everyone."
        },
        section1b: {
          title: "Aligning beacons with existing supports",
          paragraph1: "The experiment supplements rather than replaces existing signage. Updated wall plans recall colour-to-service correspondences. Staff use the same reference when guiding visitors verbally, reinforcing system coherence.",
          paragraph2: "Hand-out mini maps repeat the coloured cues. Printed on erasable stock, they allow temporary annotations, making it easy to personalise information without multiplying devices."
        },
        section2: {
          title: "Measuring impact on reception",
          paragraph1: "After three months, pilot town halls recorded fewer generic orientation questions. Staff can focus on complex cases while visitors gain autonomy. Indicators stem from daily tallies of requests and short exit questionnaires.",
          paragraph2: "Findings also show better corridor flow distribution. Visual beacons were adopted long term, with a maintenance plan including quarterly checks of supports and content. The experiment highlights the value of modular devices in administrative environments."
        }
      }
    }
  }
};

let currentLanguage = DEFAULT_LANG;
const toastQueue = [];

document.addEventListener("DOMContentLoaded", () => {
  const storedLang = localStorage.getItem(LANG_KEY) || DEFAULT_LANG;
  applyLanguage(storedLang);

  initNavigation();
  initLanguageToggle();
  initAnimations();
  initCookieBanner();
  initFormHandling();
  setupFooterCookieLink();
});

function applyLanguage(lang) {
  if (!I18N[lang]) {
    lang = DEFAULT_LANG;
  }
  currentLanguage = lang;
  localStorage.setItem(LANG_KEY, lang);
  document.documentElement.setAttribute("lang", lang);

  translateTextNodes(lang);
  translatePlaceholders(lang);
  translateMeta(lang);
  updateActiveLanguage(lang);
  updateFooterYear();
}

function getTranslation(lang, key) {
  const segments = key.split(".");
  let value = I18N[lang];
  for (const segment of segments) {
    if (value && Object.prototype.hasOwnProperty.call(value, segment)) {
      value = value[segment];
    } else {
      return "";
    }
  }
  return value;
}

function translateTextNodes(lang) {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.textContent = translation;
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach((el) => {
    const key = el.dataset.i18nHtml;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.innerHTML = translation;
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.dataset.i18nAlt;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("alt", translation);
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const key = el.dataset.i18nAriaLabel;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("aria-label", translation);
    }
  });
}

function translatePlaceholders(lang) {
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("placeholder", translation);
    }
  });
}

function translateMeta(lang) {
  document.querySelectorAll("meta[data-i18n-meta]").forEach((el) => {
    const key = el.dataset.i18nMeta;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("content", translation);
    }
  });
  const titleEl = document.querySelector("title[data-i18n]");
  if (titleEl) {
    const translation = getTranslation(lang, titleEl.dataset.i18n);
    if (translation !== undefined) {
      titleEl.textContent = translation;
    }
  }
}

function updateActiveLanguage(lang) {
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    const target = btn.dataset.lang;
    if (target === lang) {
      btn.classList.add("active");
    } else {
      btn.classList.remove("active");
    }
  });
}

function initNavigation() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");

  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!expanded));
    nav.classList.toggle("open");
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      toggle.setAttribute("aria-expanded", "false");
      nav.classList.remove("open");
    });
  });

  highlightActiveNav(nav);
}

function highlightActiveNav(nav) {
  const page = document.body.dataset.page;
  const mapping = {
    home: "index.html",
    services: "services.html",
    about: "about.html",
    blog: "blog.html",
    faq: "faq.html",
    contact: "contact.html"
  };
  const activeHref = mapping[page];
  if (!activeHref) return;

  nav.querySelectorAll("a").forEach((link) => {
    if (link.getAttribute("href") === activeHref) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });
}

function initLanguageToggle() {
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.lang;
      if (lang && lang !== currentLanguage) {
        applyLanguage(lang);
        showToast(getTranslation(lang, "toast.languageSwitched"));
      }
    });
  });
}

function initAnimations() {
  const animated = document.querySelectorAll("[data-animate]");
  if (!("IntersectionObserver" in window) || animated.length === 0) {
    animated.forEach((el) => el.classList.add("is-visible"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  animated.forEach((el) => observer.observe(el));
}

function initCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;

  const manageButton = banner.querySelector("[data-cookie-manage]");
  const acceptAll = banner.querySelector("[data-cookie-accept]");
  const declineAll = banner.querySelector("[data-cookie-decline]");
  const saveBtn = banner.querySelector("[data-cookie-save]");
  const preferencesBlock = banner.querySelector(".cookie-preferences");
  const toggles = banner.querySelectorAll(".cookie-toggle input");

  const storedConsent = getStoredConsent();
  if (storedConsent) {
    applyConsentToUI(storedConsent, toggles);
  } else {
    banner.classList.add("visible");
  }

  manageButton.addEventListener("click", () => {
    preferencesBlock.classList.toggle("visible");
  });

  acceptAll.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      decidedAt: new Date().toISOString()
    };
    storeConsent(consent);
    applyConsentToUI(consent, toggles);
    banner.classList.remove("visible");
    showToast(getTranslation(currentLanguage, "cookies.toast.accepted"));
  });

  declineAll.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      decidedAt: new Date().toISOString()
    };
    storeConsent(consent);
    applyConsentToUI(consent, toggles);
    banner.classList.remove("visible");
    showToast(getTranslation(currentLanguage, "cookies.toast.declined"));
  });

  saveBtn.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: getToggleValue(toggles, "preferences"),
      analytics: getToggleValue(toggles, "analytics"),
      marketing: getToggleValue(toggles, "marketing"),
      decidedAt: new Date().toISOString()
    };
    storeConsent(consent);
    banner.classList.remove("visible");
    showToast(getTranslation(currentLanguage, "cookies.toast.saved"));
  });
}

function getStoredConsent() {
  try {
    const data = localStorage.getItem(COOKIE_KEY);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error("Cookie consent parse error", error);
    return null;
  }
}

function storeConsent(consent) {
  localStorage.setItem(COOKIE_KEY, JSON.stringify(consent));
}

function applyConsentToUI(consent, toggles) {
  toggles.forEach((toggle) => {
    const category = toggle.dataset.cookieCategory;
    if (category === "necessary") {
      toggle.checked = true;
    } else if (consent && Object.prototype.hasOwnProperty.call(consent, category)) {
      toggle.checked = Boolean(consent[category]);
    }
  });
}

function getToggleValue(toggles, category) {
  const toggle = Array.from(toggles).find((input) => input.dataset.cookieCategory === category);
  return toggle ? toggle.checked : false;
}

function setupFooterCookieLink() {
  const footerLink = document.querySelector("[data-open-cookies]");
  const banner = document.getElementById("cookie-banner");
  if (!footerLink || !banner) return;

  footerLink.addEventListener("click", (event) => {
    event.preventDefault();
    banner.classList.add("visible");
    const preferencesBlock = banner.querySelector(".cookie-preferences");
    if (preferencesBlock) {
      preferencesBlock.classList.add("visible");
    }
    showToast(getTranslation(currentLanguage, "toast.reopenCookies"));
  });
}

function initFormHandling() {
  const form = document.querySelector("form[data-contact-form]");
  if (!form) return;

  form.addEventListener("submit", (event) => {
    const lang = currentLanguage;
    if (!form.checkValidity()) {
      event.preventDefault();
      showToast(getTranslation(lang, "common.form.submitError"));
      form.reportValidity();
      return;
    }

    event.preventDefault();
    showToast(getTranslation(lang, "common.form.submitSuccess"));
    setTimeout(() => {
      form.submit();
    }, 600);
  });
}

function showToast(message) {
  if (!message) return;
  const container = getToastContainer();
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.remove();
  }, 5000);
}

function getToastContainer() {
  let container = document.querySelector(".toast-container");
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }
  return container;
}

function updateFooterYear() {
  const nodes = document.querySelectorAll("[data-footer-year]");
  const year = new Date().getFullYear();
  nodes.forEach((node) => {
    const template = getTranslation(currentLanguage, node.dataset.footerYear);
    if (template) {
      node.textContent = template.replace("{year}", String(year));
    }
  });
}