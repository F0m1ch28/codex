document.addEventListener('DOMContentLoaded', function () {
    const banner = document.getElementById('cookie-banner');
    const acceptButton = document.getElementById('cookie-accept');
    const declineButton = document.getElementById('cookie-decline');
    const choice = localStorage.getItem('martinsWorldCookieChoice');

    if (!choice) {
        banner.style.display = 'block';
    }

    function handleChoice(value) {
        localStorage.setItem('martinsWorldCookieChoice', value);
        banner.style.display = 'none';
    }

    if (acceptButton) {
        acceptButton.addEventListener('click', function () {
            handleChoice('accepted');
        });
    }

    if (declineButton) {
        declineButton.addEventListener('click', function () {
            handleChoice('declined');
        });
    }
});