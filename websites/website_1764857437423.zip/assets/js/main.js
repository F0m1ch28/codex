document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  if (navToggle) {
    navToggle.addEventListener("click", () => {
      const isOpen = document.body.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const storedConsent = localStorage.getItem("cds-cookie-consent");
    if (!storedConsent) {
      requestAnimationFrame(() => cookieBanner.classList.add("visible"));
    }
    cookieBanner.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLButtonElement)) return;
      const action = target.dataset.action;
      if (!action) return;
      localStorage.setItem("cds-cookie-consent", action);
      cookieBanner.classList.remove("visible");
      setTimeout(() => cookieBanner.remove(), 400);
    });
  }

  const filterButtons = document.querySelectorAll("[data-filter]");
  const portfolioItems = document.querySelectorAll("[data-category]");
  if (filterButtons.length && portfolioItems.length) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const currentFilter = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove("is-active"));
        button.classList.add("is-active");
        portfolioItems.forEach((item) => {
          const category = item.dataset.category;
          if (currentFilter === "all" || category === currentFilter) {
            item.removeAttribute("hidden");
          } else {
            item.setAttribute("hidden", "true");
          }
        });
      });
    });
  }

  const contactForm = document.querySelector('[data-form="contact"]');
  if (contactForm) {
    const feedback = contactForm.querySelector("[data-feedback]");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!feedback) return;

      const formData = new FormData(contactForm);
      const name = formData.get("name")?.toString().trim();
      const email = formData.get("email")?.toString().trim();
      const service = formData.get("service")?.toString().trim();
      const message = formData.get("message")?.toString().trim();
      const policyAccepted = contactForm.querySelector('input[name="policy"]')?.checked;

      const errors = [];
      if (!name) errors.push("Пожалуйста, укажите ваше имя.");
      if (!email || !/^[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}$/.test(email)) {
        errors.push("Введите корректный адрес электронной почты.");
      }
      if (!service) errors.push("Выберите интересующую услугу.");
      if (!message || message.length < 12) errors.push("Расскажите подробнее о задаче (минимум 12 символов).");
      if (!policyAccepted) errors.push("Необходимо согласиться с политикой конфиденциальности.");

      if (errors.length) {
        feedback.textContent = errors.join(" ");
        feedback.classList.remove("success");
        feedback.classList.add("error");
        return;
      }

      feedback.textContent = "Спасибо! Мы свяжемся с вами в течение рабочего дня.";
      feedback.classList.remove("error");
      feedback.classList.add("success");
      contactForm.reset();
    });
  }

  document.querySelectorAll("[data-year]").forEach((node) => {
    node.textContent = String(new Date().getFullYear());
  });
});