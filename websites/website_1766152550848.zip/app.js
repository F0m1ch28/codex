document.addEventListener("DOMContentLoaded", () => {
  const toggles = document.querySelectorAll("[data-mobile-toggle]");
  const mobileMenu = document.getElementById("mobileMenu");
  const body = document.body;

  const closeMobileMenu = () => {
    if (!mobileMenu) return;
    mobileMenu.classList.add("hidden");
    body.classList.remove("overflow-hidden");
  };

  const openMobileMenu = () => {
    if (!mobileMenu) return;
    mobileMenu.classList.remove("hidden");
    body.classList.add("overflow-hidden");
  };

  toggles.forEach((button) => {
    button.addEventListener("click", () => {
      if (!mobileMenu) return;
      const isHidden = mobileMenu.classList.contains("hidden");
      if (isHidden) {
        openMobileMenu();
      } else {
        closeMobileMenu();
      }
    });
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth >= 1024) {
      closeMobileMenu();
    }
  });

  if (mobileMenu) {
    const mobileLinks = mobileMenu.querySelectorAll("a");
    mobileLinks.forEach((link) => {
      link.addEventListener("click", () => {
        closeMobileMenu();
      });
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.2,
    }
  );

  document.querySelectorAll("[data-animate='fade']").forEach((el) => {
    el.classList.add("fade-in");
    observer.observe(el);
  });

  const isTouch = window.matchMedia("(pointer: coarse)").matches;

  if (!isTouch) {
    document.querySelectorAll("[data-tilt='true']").forEach((tiltCard) => {
      tiltCard.addEventListener("mousemove", (event) => {
        const bounds = tiltCard.getBoundingClientRect();
        const centerX = (event.clientX - bounds.left) / bounds.width;
        const centerY = (event.clientY - bounds.top) / bounds.height;
        const rotateX = (0.5 - centerY) * 10;
        const rotateY = (centerX - 0.5) * 12;
        tiltCard.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
      });

      tiltCard.addEventListener("mouseleave", () => {
        tiltCard.style.transform = "rotateX(0deg) rotateY(0deg)";
      });
    });
  }

  const marquee = document.querySelector("[data-marquee]");
  if (marquee) {
    let offset = 0;
    const speed = parseFloat(marquee.dataset.speed || "0.3");
    const animateMarquee = () => {
      offset -= speed;
      marquee.style.transform = `translateX(${offset}px)`;
      if (Math.abs(offset) > marquee.scrollWidth / 2) {
        offset = 0;
      }
      requestAnimationFrame(animateMarquee);
    };
    animateMarquee();
  }
});