document.addEventListener("DOMContentLoaded", () => {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;

  const acceptAllButton = banner.querySelector("[data-action='accept']");
  const rejectAllButton = banner.querySelector("[data-action='reject']");
  const customizeButton = banner.querySelector("[data-action='customize']");
  const saveButton = banner.querySelector("[data-action='save']");
  const preferencePanel = banner.querySelector("[data-panel='details']");
  const analyticsToggle = banner.querySelector("#analyticsCookies");
  const marketingToggle = banner.querySelector("#marketingCookies");
  const functionalToggle = banner.querySelector("#functionalCookies");
  const preferenceKey = "auroraCookiePreferences";

  const parsePreferences = () => {
    const existing = localStorage.getItem(preferenceKey);
    if (!existing) return null;
    try {
      return JSON.parse(existing);
    } catch (error) {
      console.warn("Failed to parse cookie preferences", error);
      return null;
    }
  };

  const transmitPreferences = async (preferences) => {
    try {
      await fetch("/api/preferences", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(preferences),
      });
    } catch (error) {
      console.warn("Cookie preference transmission failed", error);
    }
  };

  const storePreferences = (preferences) => {
    const payload = {
      ...preferences,
      timestamp: new Date().toISOString(),
    };
    localStorage.setItem(preferenceKey, JSON.stringify(payload));
    transmitPreferences(payload);
  };

  const hideBanner = () => {
    banner.classList.remove("visible");
    setTimeout(() => {
      banner.style.display = "none";
    }, 300);
  };

  const showBanner = () => {
    banner.style.display = "block";
    requestAnimationFrame(() => {
      banner.classList.add("visible");
    });
  };

  const existingPreferences = parsePreferences();

  if (existingPreferences) {
    if (analyticsToggle) analyticsToggle.checked = !!existingPreferences.analytics;
    if (marketingToggle) marketingToggle.checked = !!existingPreferences.marketing;
    if (functionalToggle) functionalToggle.checked = !!existingPreferences.functional;
  } else {
    showBanner();
  }

  if (acceptAllButton) {
    acceptAllButton.addEventListener("click", () => {
      const preferences = {
        necessary: true,
        analytics: true,
        marketing: true,
        functional: true,
      };
      storePreferences(preferences);
      hideBanner();
    });
  }

  if (rejectAllButton) {
    rejectAllButton.addEventListener("click", () => {
      const preferences = {
        necessary: true,
        analytics: false,
        marketing: false,
        functional: false,
      };
      if (analyticsToggle) analyticsToggle.checked = false;
      if (marketingToggle) marketingToggle.checked = false;
      if (functionalToggle) functionalToggle.checked = false;
      storePreferences(preferences);
      hideBanner();
    });
  }

  if (customizeButton && preferencePanel) {
    customizeButton.addEventListener("click", () => {
      preferencePanel.classList.toggle("hidden");
    });
  }

  if (saveButton) {
    saveButton.addEventListener("click", () => {
      const preferences = {
        necessary: true,
        analytics: analyticsToggle ? analyticsToggle.checked : false,
        marketing: marketingToggle ? marketingToggle.checked : false,
        functional: functionalToggle ? functionalToggle.checked : false,
      };
      storePreferences(preferences);
      hideBanner();
    });
  }
});