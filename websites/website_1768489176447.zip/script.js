document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".nav-menu a");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isExpanded));
            siteNav.classList.toggle("is-open");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("is-open")) {
                    siteNav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const storedChoice = localStorage.getItem("ichneufmkeCookieChoice");
        if (storedChoice) {
            cookieBanner.classList.add("is-hidden");
        } else {
            const buttons = cookieBanner.querySelectorAll(".cookie-btn");
            buttons.forEach((button) => {
                button.addEventListener("click", (event) => {
                    event.preventDefault();
                    const choice = button.dataset.choice || "dismissed";
                    localStorage.setItem("ichneufmkeCookieChoice", choice);
                    cookieBanner.classList.add("is-hidden");
                    const targetLink = button.getAttribute("href");
                    if (targetLink) {
                        window.location.href = targetLink;
                    }
                });
            });
        }
    }
});