document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieDecline = document.getElementById('cookieDecline');
    const consentKey = 'destabfowrCookieConsent';

    if (cookieBanner && cookieAccept && cookieDecline) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            setTimeout(() => {
                cookieBanner.classList.add('active');
            }, 500);
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.remove('active');
        });

        cookieDecline.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'managed');
            window.location.href = 'cookies.html';
        });
    }
});