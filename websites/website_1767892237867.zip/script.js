document.addEventListener('DOMContentLoaded', () => {
    const currentYear = new Date().getFullYear();
    document.querySelectorAll('.current-year').forEach((el) => {
        el.textContent = currentYear;
    });

    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            primaryNav.classList.toggle('open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storageKey = 'powersectoruk-cookie-choice';
        const storedChoice = localStorage.getItem(storageKey);
        if (storedChoice) {
            cookieBanner.setAttribute('hidden', '');
        } else {
            const buttons = cookieBanner.querySelectorAll('[data-cookie-action]');
            buttons.forEach((btn) => {
                btn.addEventListener('click', () => {
                    localStorage.setItem(storageKey, btn.dataset.cookieAction);
                    cookieBanner.setAttribute('hidden', '');
                });
            });
        }
    }

    const postsGrid = document.querySelector('.posts-grid');
    const filterButtons = document.querySelectorAll('.filter-buttons button');
    const searchInput = document.querySelector('.search-control input');
    const resultsCount = document.querySelector('.results-count');
    const paginationControls = document.querySelector('.pagination');
    const postsPerPage = 6;
    let currentPage = 1;
    let activeCategory = 'all';
    let searchTerm = '';

    if (postsGrid) {
        const cards = Array.from(postsGrid.querySelectorAll('.article-card'));
        const totalPages = () => Math.max(1, Math.ceil(filteredCards().length / postsPerPage));

        const filteredCards = () => {
            return cards.filter((card) => {
                const category = card.dataset.category;
                const title = card.querySelector('h3').textContent.toLowerCase();
                const excerpt = card.querySelector('.article-excerpt').textContent.toLowerCase();
                const matchesCategory = activeCategory === 'all' || category === activeCategory;
                const matchesSearch =
                    !searchTerm ||
                    title.includes(searchTerm) ||
                    excerpt.includes(searchTerm);
                return matchesCategory && matchesSearch;
            });
        };

        const updateResultsCount = () => {
            const count = filteredCards().length;
            if (resultsCount) {
                const noun = count === 1 ? 'article' : 'articles';
                resultsCount.textContent = `${count} ${noun} available`;
            }
        };

        const renderCards = () => {
            cards.forEach((card) => {
                card.style.display = 'none';
            });
            const visibleCards = filteredCards();
            const start = (currentPage - 1) * postsPerPage;
            const end = start + postsPerPage;
            visibleCards.slice(start, end).forEach((card) => {
                card.style.display = '';
            });
        };

        const renderPagination = () => {
            if (!paginationControls) return;
            paginationControls.innerHTML = '';
            const total = totalPages();

            const prevButton = document.createElement('button');
            prevButton.type = 'button';
            prevButton.textContent = 'Previous';
            prevButton.disabled = currentPage === 1;
            prevButton.addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage -= 1;
                    renderCards();
                    renderPagination();
                }
            });
            paginationControls.appendChild(prevButton);

            for (let page = 1; page <= total; page += 1) {
                const pageButton = document.createElement('button');
                pageButton.type = 'button';
                pageButton.textContent = page;
                if (page === currentPage) {
                    pageButton.classList.add('active');
                }
                pageButton.addEventListener('click', () => {
                    currentPage = page;
                    renderCards();
                    renderPagination();
                });
                paginationControls.appendChild(pageButton);
            }

            const nextButton = document.createElement('button');
            nextButton.type = 'button';
            nextButton.textContent = 'Next';
            nextButton.disabled = currentPage === total;
            nextButton.addEventListener('click', () => {
                if (currentPage < total) {
                    currentPage += 1;
                    renderCards();
                    renderPagination();
                }
            });
            paginationControls.appendChild(nextButton);
        };

        filterButtons.forEach((button) => {
            button.addEventListener('click', () => {
                filterButtons.forEach((btn) => btn.classList.remove('active'));
                button.classList.add('active');
                activeCategory = button.dataset.filter;
                currentPage = 1;
                updateResultsCount();
                renderCards();
                renderPagination();
            });
        });

        if (searchInput) {
            searchInput.addEventListener('input', (event) => {
                searchTerm = event.target.value.trim().toLowerCase();
                currentPage = 1;
                updateResultsCount();
                renderCards();
                renderPagination();
            });
        }

        updateResultsCount();
        renderCards();
        renderPagination();
    }
});