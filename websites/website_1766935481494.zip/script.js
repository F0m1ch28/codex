document.addEventListener("DOMContentLoaded", function () {
  const mobileToggle = document.querySelector("[data-mobile-toggle]");
  const mobileNav = document.querySelector("[data-mobile-nav]");
  if (mobileToggle && mobileNav) {
    mobileToggle.addEventListener("click", () => {
      mobileNav.classList.toggle("open");
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieAccept = document.getElementById("cookie-accept");
  const cookieDecline = document.getElementById("cookie-decline");
  const cookieChoice = localStorage.getItem("cookie-choice");

  if (cookieBanner) {
    if (cookieChoice === "accepted" || cookieChoice === "declined") {
      cookieBanner.style.display = "none";
    } else {
      cookieBanner.style.display = "grid";
    }

    if (cookieAccept) {
      cookieAccept.addEventListener("click", () => {
        localStorage.setItem("cookie-choice", "accepted");
        cookieBanner.style.display = "none";
      });
    }

    if (cookieDecline) {
      cookieDecline.addEventListener("click", () => {
        localStorage.setItem("cookie-choice", "declined");
        cookieBanner.style.display = "none";
      });
    }
  }

  const sliderTracks = document.querySelectorAll("[data-slider]");
  sliderTracks.forEach((slider) => {
    const track = slider.querySelector(".slider-track");
    const slides = slider.querySelectorAll(".slider-slide");
    const prevButton = slider.querySelector("[data-prev]");
    const nextButton = slider.querySelector("[data-next]");
    let currentIndex = 0;
    let intervalId;

    const updateSlider = () => {
      if (!track) return;
      track.style.transform = `translateX(-${currentIndex * 100}%)`;
    };

    const goToNext = () => {
      currentIndex = (currentIndex + 1) % slides.length;
      updateSlider();
    };

    const goToPrev = () => {
      currentIndex = (currentIndex - 1 + slides.length) % slides.length;
      updateSlider();
    };

    if (nextButton) {
      nextButton.addEventListener("click", goToNext);
    }

    if (prevButton) {
      prevButton.addEventListener("click", goToPrev);
    }

    const startAutoSlide = () => {
      intervalId = setInterval(goToNext, 5000);
    };

    const stopAutoSlide = () => {
      clearInterval(intervalId);
    };

    slider.addEventListener("mouseenter", stopAutoSlide);
    slider.addEventListener("mouseleave", startAutoSlide);

    if (slides.length > 1) {
      startAutoSlide();
    }
  });

  const filterButtons = document.querySelectorAll("[data-filter]");
  const filterItems = document.querySelectorAll("[data-category]");
  if (filterButtons.length > 0 && filterItems.length > 0) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const filter = button.getAttribute("data-filter");
        filterButtons.forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");

        filterItems.forEach((item) => {
          const category = item.getAttribute("data-category");
          if (filter === "all" || category.includes(filter)) {
            item.classList.remove("is-hidden");
          } else {
            item.classList.add("is-hidden");
          }
        });
      });
    });
  }

  const customizationForm = document.getElementById("customization-form");
  if (customizationForm) {
    const themeInputs = customizationForm.querySelectorAll("input[name='theme']");
    const sizeSelect = customizationForm.querySelector("#box-size");
    const extrasInputs = customizationForm.querySelectorAll("input[name='extras']");
    const totalElement = document.getElementById("custom-total");
    const summaryList = document.getElementById("custom-summary");

    const themePrices = {
      "festive-wonder": 0,
      "birthday-bliss": 5,
      "winter-luxe": 12,
    };
    const sizePrices = {
      petite: 0,
      signature: 15,
      grand: 28,
    };
    const extraPrices = {
      "handwritten-card": 6,
      "artisan-chocolates": 12,
      "sparkling-toast": 18,
      "personalized-ornament": 10,
      "gourmet-snacks": 14,
    };

    const updatePrice = () => {
      let total = 45;
      let selections = [];

      themeInputs.forEach((input) => {
        if (input.checked) {
          total += themePrices[input.value] || 0;
          selections.push(`Theme: ${input.dataset.label}`);
        }
      });

      if (sizeSelect && sizeSelect.value) {
        total += sizePrices[sizeSelect.value] || 0;
        selections.push(`Size: ${sizeSelect.selectedOptions[0].textContent.trim()}`);
      }

      let extrasSelected = [];
      extrasInputs.forEach((input) => {
        if (input.checked) {
          total += extraPrices[input.value] || 0;
          extrasSelected.push(input.dataset.label);
        }
      });

      if (extrasSelected.length) {
        selections.push(`Extras: ${extrasSelected.join(", ")}`);
      }

      if (summaryList) {
        summaryList.innerHTML = "";
        selections.forEach((item) => {
          const li = document.createElement("li");
          li.textContent = item;
          summaryList.appendChild(li);
        });
      }

      if (totalElement) {
        totalElement.textContent = `$${total.toFixed(2)}`;
      }
    };

    customizationForm.addEventListener("change", updatePrice);
    updatePrice();
  }

  const contactForm = document.getElementById("contact-form");
  const contactAlert = document.getElementById("contact-alert");
  if (contactForm && contactAlert) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const name = formData.get("name").trim();
      const email = formData.get("email").trim();
      const order = formData.get("order").trim();
      const message = formData.get("message").trim();

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!name || !email || !message) {
        contactAlert.textContent = "Please complete all required fields before sending your message.";
        contactAlert.className = "form-alert error";
        contactAlert.style.display = "block";
        return;
      }

      if (!emailPattern.test(email)) {
        contactAlert.textContent = "Please enter a valid email address so we can get in touch.";
        contactAlert.className = "form-alert error";
        contactAlert.style.display = "block";
        return;
      }

      if (message.length < 20) {
        contactAlert.textContent = "Your message should include at least 20 characters to help our team assist you.";
        contactAlert.className = "form-alert error";
        contactAlert.style.display = "block";
        return;
      }

      contactAlert.textContent = "Thank you! Our concierge team will respond within 24 hours.";
      contactAlert.className = "form-alert success";
      contactAlert.style.display = "block";
      contactForm.reset();
    });
  }
});