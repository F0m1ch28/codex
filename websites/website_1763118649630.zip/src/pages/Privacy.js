import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Privacy Policy | TechSolutions</title>
        <meta
          name="description"
          content="Review TechSolutions' privacy practices regarding data collection, usage, and your rights."
        />
        <meta
          name="keywords"
          content="TechSolutions privacy policy, data protection, privacy practices"
        />
      </Helmet>
      <h1>Privacy Policy</h1>
      <p className={styles.updated}>Effective date: January 2024</p>

      <h2>Introduction</h2>
      <p>
        TechSolutions is committed to protecting your privacy. This policy describes how we collect,
        use, and safeguard information when you visit our website or engage with our services.
      </p>

      <h2>Information we collect</h2>
      <p>
        We may collect personal information such as your name, email address, company details,
        and any other data you provide via contact forms or consultations. We also gather
        anonymized analytics data to improve our website.
      </p>

      <h2>How we use information</h2>
      <ul>
        <li>Respond to inquiries and provide requested services</li>
        <li>Improve our website, offerings, and client experience</li>
        <li>Communicate updates, insights, or events aligned with your interests</li>
        <li>Comply with legal and regulatory obligations</li>
      </ul>

      <h2>Data security</h2>
      <p>
        We implement administrative, technical, and physical safeguards to protect personal data.
        While we strive to protect your information, no method of transmission or storage is
        completely secure.
      </p>

      <h2>Your rights</h2>
      <p>
        Depending on your location, you may have rights to access, correct, or delete personal data.
        To exercise these rights, contact us at info@techsolutions.com.
      </p>

      <h2>Third-party services</h2>
      <p>
        We may use trusted third-party providers for analytics, hosting, or communication tools.
        These providers only access data necessary to deliver their services and must protect it.
      </p>

      <h2>Changes to this policy</h2>
      <p>
        We may update this policy periodically. The updated version will be posted on this page with
        a revised effective date.
      </p>

      <h2>Contact us</h2>
      <p>
        For questions about this policy, email info@techsolutions.com or call +1 (555) 123-4567.
      </p>
    </div>
  );
};

export default Privacy;