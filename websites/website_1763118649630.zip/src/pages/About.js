import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About TechSolutions | Digital Transformation Experts</title>
        <meta
          name="description"
          content="Learn about TechSolutions, our mission, values, and team experience in delivering cloud solutions and digital transformation initiatives."
        />
        <meta
          name="keywords"
          content="TechSolutions mission, IT consulting team, cloud transformation experts"
        />
      </Helmet>

      <section className={styles.intro}>
        <div>
          <span>Who we are</span>
          <h1>Empowering organizations to thrive in the digital era</h1>
          <p>
            TechSolutions is an IT consulting firm specializing in cloud solutions and digital
            transformation. We bring together experienced strategists, architects, and engineers
            who are passionate about helping clients build resilient, future-ready operations.
          </p>
        </div>
        <img
          src="https://picsum.photos/seed/techsolutions-office/680/460"
          alt="TechSolutions office environment"
        />
      </section>

      <section className={styles.values}>
        <h2>Our mission & values</h2>
        <div className={styles.valueGrid}>
          <article>
            <h3>Mission</h3>
            <p>
              To empower organizations with cloud-first strategies, enabling them to innovate,
              optimize, and deliver exceptional customer experiences with confidence.
            </p>
          </article>
          <article>
            <h3>Integrity</h3>
            <p>
              We operate with transparency and accountability, offering unbiased guidance grounded
              in industry best practices and measurable results.
            </p>
          </article>
          <article>
            <h3>Collaboration</h3>
            <p>
              Our teams embed alongside client stakeholders, ensuring that knowledge transfer and
              capability building are core parts of every engagement.
            </p>
          </article>
          <article>
            <h3>Innovation</h3>
            <p>
              We continuously invest in research, training, and emerging technologies so that our
              clients benefit from cutting-edge insights and solutions.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.teamIntro}>
          <h2>Experienced specialists who understand enterprise complexity</h2>
          <p>
            Our consultants draw from backgrounds in Fortune 500 organizations, high-growth startups,
            and global technology providers. With multi-cloud certifications, industry expertise,
            and proven transformation methodologies, we help organizations move from concept to value.
          </p>
        </div>
        <div className={styles.stats}>
          <div>
            <strong>12+</strong>
            <span>Years delivering cloud initiatives</span>
          </div>
          <div>
            <strong>150+</strong>
            <span>Successful enterprise engagements</span>
          </div>
          <div>
            <strong>35</strong>
            <span>Certified architects & engineers</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;