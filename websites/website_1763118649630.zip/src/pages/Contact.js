import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact TechSolutions | Connect with Our Consultants</title>
        <meta
          name="description"
          content="Reach out to TechSolutions for cloud consulting, digital transformation, and IT strategy support. Contact our team to start your journey."
        />
        <meta
          name="keywords"
          content="contact TechSolutions, cloud consulting contact, IT consulting inquiry"
        />
      </Helmet>

      <section className={styles.header}>
        <h1>Let’s build your next chapter in digital transformation</h1>
        <p>
          Share your goals and challenges, and our consultants will respond within one business day
          to plan a conversation tailored to your needs.
        </p>
      </section>

      <section className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit}>
          <h2>Send us a message</h2>
          <label>
            Full name
            <input
              type="text"
              name="name"
              value={formState.name}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Business email
            <input
              type="email"
              name="email"
              value={formState.email}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Company
            <input
              type="text"
              name="company"
              value={formState.company}
              onChange={handleChange}
            />
          </label>
          <label>
            How can we help?
            <textarea
              name="message"
              rows="5"
              value={formState.message}
              onChange={handleChange}
              required
            />
          </label>
          <button type="submit">Submit message</button>
          {submitted && (
            <p className={styles.success}>
              Thank you for contacting TechSolutions. We will reach out shortly.
            </p>
          )}
        </form>

        <div className={styles.info}>
          <div className={styles.card}>
            <h3>Contact details</h3>
            <p>Address: 123 Innovation Street, Tech City, TC 10101</p>
            <p>Phone: +1 (555) 123-4567</p>
            <p>Email: info@techsolutions.com</p>
            <p>Business hours: Monday – Friday, 9:00 AM – 6:00 PM (TC)</p>
          </div>
          <div className={styles.mapWrapper}>
            <iframe
              title="TechSolutions office location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.879430145197!2d144.95373531564574!3d-37.81627974201298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzfCsDQ5JzAzLjYiUyAxNDTCsDU3JzE5LjQiRQ!5e0!3m2!1sen!2s!4v1616586723007!5m2!1sen!2s"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;