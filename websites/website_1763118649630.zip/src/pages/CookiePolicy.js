import React from "react";
import { Helmet } from "react-helmet";
import styles from "./CookiePolicy.module.css";

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie Policy | TechSolutions</title>
        <meta
          name="description"
          content="Understand how TechSolutions uses cookies and similar technologies to enhance user experience on our website."
        />
        <meta
          name="keywords"
          content="cookie policy, TechSolutions cookies, website tracking"
        />
      </Helmet>
      <h1>Cookie Policy</h1>
      <p className={styles.updated}>Effective date: January 2024</p>

      <h2>What are cookies?</h2>
      <p>
        Cookies are small text files stored on your device when you visit websites. They help improve
        your browsing experience by remembering preferences and enabling certain functionality.
      </p>

      <h2>How we use cookies</h2>
      <ul>
        <li>
          <strong>Essential cookies:</strong> Required for basic site functionality, such as page navigation.
        </li>
        <li>
          <strong>Analytics cookies:</strong> Help us understand how visitors interact with the site to improve usability.
        </li>
        <li>
          <strong>Preference cookies:</strong> Store your choices, such as cookie consent status.
        </li>
      </ul>

      <h2>Managing cookies</h2>
      <p>
        Most browsers automatically accept cookies, but you can modify browser settings to decline
        or delete cookies. Disabling cookies may impact certain site features.
      </p>

      <h2>Third-party cookies</h2>
      <p>
        We may use third-party analytics tools that set their own cookies. These cookies are governed
        by the providers’ privacy policies.
      </p>

      <h2>Updates</h2>
      <p>
        We may update this Cookie Policy to reflect changes in technology or regulatory requirements.
        Please review it periodically.
      </p>

      <h2>Contact</h2>
      <p>
        For questions about our cookie practices, email info@techsolutions.com or call +1 (555) 123-4567.
      </p>
    </div>
  );
};

export default CookiePolicy;