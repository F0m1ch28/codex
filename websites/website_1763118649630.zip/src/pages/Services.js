import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | TechSolutions Cloud & IT Consulting</title>
        <meta
          name="description"
          content="TechSolutions delivers end-to-end cloud migration, DevOps consulting, and solution architecture services tailored to your business goals."
        />
        <meta
          name="keywords"
          content="cloud migration, DevOps consulting, solution architecture, IT consulting services"
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Services designed to accelerate cloud-driven business value</h1>
        <p>
          We partner with technology and business leaders to design pragmatic strategies, deploy
          modern platforms, and embed continuous improvement across the organization.
        </p>
      </header>

      <section className={styles.serviceSection}>
        <article>
          <h2>Cloud Migration & Modernization</h2>
          <p>
            Transition critical workloads to the cloud with confidence. Our team assesses your
            application portfolio, defines a target operating model, and orchestrates the migration
            with minimal disruption. We modernize architectures to leverage cloud-native services,
            implement governance frameworks, and optimize cost and performance.
          </p>
          <ul>
            <li>Cloud readiness assessments and strategy roadmaps</li>
            <li>Landing zone design, security, and compliance alignment</li>
            <li>Application refactoring, containerization, and modernization</li>
            <li>Operational excellence through FinOps and continuous optimization</li>
          </ul>
        </article>

        <article>
          <h2>DevOps & Platform Engineering</h2>
          <p>
            Enable high-velocity delivery with reliable, automated workflows. TechSolutions
            establishes collaborative DevOps cultures supported by integrated toolchains, secure
            infrastructure-as-code, and observability practices that empower engineering teams.
          </p>
          <ul>
            <li>Enterprise DevOps strategy and operating model design</li>
            <li>CI/CD pipeline implementation with automated testing</li>
            <li>Cloud-native infrastructure provisioning and policy enforcement</li>
            <li>Site reliability engineering and real-time monitoring frameworks</li>
          </ul>
        </article>

        <article>
          <h2>Solution & Enterprise Architecture</h2>
          <p>
            Create technology ecosystems that align with long-term business objectives. We design
            modular, resilient architectures that support innovation, integrate legacy systems,
            and provide a clear roadmap for scalable growth across data, applications, and platforms.
          </p>
          <ul>
            <li>Architecture assessments with actionable modernization plans</li>
            <li>Reference architectures for multi-cloud and hybrid scenarios</li>
            <li>API strategies, integration patterns, and data governance models</li>
            <li>Architecture governance, tooling, and knowledge transfer</li>
          </ul>
        </article>
      </section>

      <section className={styles.process}>
        <div>
          <h2>A collaborative approach to measurable outcomes</h2>
          <p>
            Our consulting engagements are anchored in co-creation with stakeholders,
            evidence-based decision making, and transparent delivery. From discovery to scale,
            we ensure knowledge transfer and sustainable operations.
          </p>
        </div>
        <div className={styles.steps}>
          <div>
            <span>01</span>
            <h3>Discover & Align</h3>
            <p>
              Assess business objectives, technology landscape, and success metrics to establish a
              shared vision for transformation.
            </p>
          </div>
          <div>
            <span>02</span>
            <h3>Design & Validate</h3>
            <p>
              Prototype architectures, validate assumptions, and craft detailed implementation plans
              focused on risk mitigation and value realization.
            </p>
          </div>
          <div>
            <span>03</span>
            <h3>Deliver & Optimize</h3>
            <p>
              Execute with agile governance, embed feedback loops, and provide continuous optimization
              to ensure enduring impact.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;