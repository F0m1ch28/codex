import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const Home = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>TechSolutions | Cloud Solutions & Digital Transformation</title>
        <meta
          name="description"
          content="TechSolutions provides tailored cloud solutions, DevOps consulting, and digital transformation strategies that accelerate business innovation."
        />
        <meta
          name="keywords"
          content="cloud solutions, digital transformation, IT consulting, business optimization, TechSolutions"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.tagline}>Cloud-first. People-focused.</span>
          <h1>
            Unlock the full power of <span>cloud innovation</span> for your business.
          </h1>
          <p>
            TechSolutions partners with forward-thinking organizations to design, implement,
            and optimize secure cloud ecosystems that drive measurable outcomes across the enterprise.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryBtn}>
              Schedule a consultation
            </Link>
            <Link to="/services" className={styles.secondaryBtn}>
              Explore our services
            </Link>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/seed/techsolutions-hero/640/420"
            alt="Consultants collaborating on cloud architecture"
          />
        </div>
      </section>

      <section className={styles.trust}>
        <h2>Strategic expertise for resilient, scalable IT foundations</h2>
        <p>
          From cloud migrations to continuous delivery pipelines, we help leaders align technology
          investments with business objectives while maintaining operational excellence.
        </p>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <span>Capabilities</span>
          <h2>Comprehensive consulting for every stage of transformation</h2>
        </div>
        <div className={styles.serviceGrid}>
          <article>
            <h3>Cloud Migration & Modernization</h3>
            <p>
              Build a cloud-native backbone that enables rapid scaling, cost efficiency,
              and agility. Our architects de-risk migrations while modernizing legacy workloads.
            </p>
            <Link to="/services">Discover how</Link>
          </article>
          <article>
            <h3>DevOps Enablement</h3>
            <p>
              Create a culture of collaboration powered by automated delivery pipelines,
              observability, and scalable infrastructure-as-code practices for sustained innovation.
            </p>
            <Link to="/services">See our approach</Link>
          </article>
          <article>
            <h3>Solution Architecture</h3>
            <p>
              Align enterprise architecture with strategic goals through secure, high-performing
              designs that future-proof your technology landscape and empower teams.
            </p>
            <Link to="/services">Learn more</Link>
          </article>
        </div>
      </section>

      <section className={styles.about}>
        <div className={styles.aboutImage}>
          <img
            src="https://picsum.photos/seed/techsolutions-team/620/420"
            alt="TechSolutions consultants discussing project roadmap"
          />
        </div>
        <div className={styles.aboutContent}>
          <h2>Experience that delivers measurable transformation</h2>
          <p>
            For over a decade, TechSolutions has guided enterprises through complex technology
            transitions, blending strategy, engineering, and change management to achieve
            business optimization at scale.
          </p>
          <ul>
            <li>Certified cloud professionals across AWS, Azure, and Google Cloud</li>
            <li>Proven frameworks for governance, risk mitigation, and compliance</li>
            <li>Customer-centric engagements with transparent communication</li>
          </ul>
          <Link to="/about" className={styles.aboutLink}>
            More about TechSolutions
          </Link>
        </div>
      </section>

      <section className={styles.cta}>
        <h2>Ready to accelerate your digital transformation journey?</h2>
        <p>
          Partner with TechSolutions to establish a roadmap that aligns cloud capabilities
          with long-term business value.
        </p>
        <Link to="/contact" className={styles.ctaButton}>
          Talk to our experts
        </Link>
      </section>
    </div>
  );
};

export default Home;