import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Terms of Use | TechSolutions</title>
        <meta
          name="description"
          content="Read the TechSolutions Terms of Use outlining guidelines for accessing our website and services."
        />
        <meta
          name="keywords"
          content="TechSolutions terms of use, website terms, consulting terms"
        />
      </Helmet>
      <h1>Terms of Use</h1>
      <p className={styles.updated}>Last updated: January 2024</p>
      <h2>Acceptance of terms</h2>
      <p>
        By accessing or using this website, you agree to comply with these Terms of Use.
        If you do not agree, do not use the site. TechSolutions reserves the right to update
        these terms at any time without notice.
      </p>
      <h2>Use of content</h2>
      <p>
        All content on this site is owned by or licensed to TechSolutions. You may not reproduce,
        distribute, or create derivative works without prior written consent. Unauthorized use
        may violate intellectual property laws.
      </p>
      <h2>Disclaimer</h2>
      <p>
        The information provided on this site is for general informational purposes. We make no
        representations or warranties about completeness, reliability, or accuracy.
      </p>
      <h2>Limitation of liability</h2>
      <p>
        TechSolutions is not liable for any damages arising from your use of the site or any linked
        content. This limitation applies to all damages, including direct and indirect losses.
      </p>
      <h2>Governing law</h2>
      <p>
        These terms are governed by the laws of the jurisdiction in which TechSolutions operates.
        Any disputes will be handled exclusively in the applicable courts.
      </p>
      <h2>Contact</h2>
      <p>
        For questions regarding these terms, please contact us at info@techsolutions.com or
        +1 (555) 123-4567.
      </p>
    </div>
  );
};

export default Terms;