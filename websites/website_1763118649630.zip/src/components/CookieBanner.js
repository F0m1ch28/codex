import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("ts_cookie_consent");
    if (!consent) {
      setTimeout(() => setVisible(true), 800);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem("ts_cookie_consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner}>
      <div className={styles.content}>
        <p>
          We use cookies to enhance site navigation, analyze usage, and support your experience.
          Read our <Link to="/cookie-policy">Cookie Policy</Link> for details.
        </p>
        <button onClick={acceptCookies}>Accept</button>
      </div>
    </div>
  );
};

export default CookieBanner;