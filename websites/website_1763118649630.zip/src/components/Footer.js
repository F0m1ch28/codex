import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <h2>TechSolutions</h2>
          <p>
            Strategic IT consulting that empowers organizations to navigate cloud adoption,
            modernize operations, and unlock sustainable business growth.
          </p>
        </div>
        <div className={styles.links}>
          <h3>Explore</h3>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div className={styles.legal}>
          <h3>Compliance</h3>
          <ul>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Use</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Cookie Policy</Link>
            </li>
          </ul>
        </div>
        <div className={styles.contact}>
          <h3>Contact</h3>
          <p>123 Innovation Street</p>
          <p>Tech City, TC 10101</p>
          <p>Phone: +1 (555) 123-4567</p>
          <p>Email: info@techsolutions.com</p>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>&copy; {new Date().getFullYear()} TechSolutions. All rights reserved.</span>
      </div>
    </footer>
  );
};

export default Footer;