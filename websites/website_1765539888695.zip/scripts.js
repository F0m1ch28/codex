document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.getElementById('primaryNav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      navToggle.classList.toggle('is-open', isOpen);
      if (isOpen) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    });

    primaryNav.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 992 && primaryNav.classList.contains('is-open')) {
          primaryNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        }
      });
    });
  }

  const currentPage = document.body.dataset.page;
  if (currentPage) {
    document.querySelectorAll('.nav-link').forEach(link => {
      if (link.dataset.nav === currentPage) {
        link.classList.add('active');
      }
    });
  }

  const currentYearEl = document.getElementById('currentYear');
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const storageKey = 'qnm_cookie_consent';

  if (cookieBanner) {
    const savedConsent = localStorage.getItem(storageKey);
    if (!savedConsent) {
      setTimeout(() => {
        cookieBanner.classList.add('is-visible');
      }, 600);
    }

    const hideBanner = () => cookieBanner.classList.remove('is-visible');

    acceptBtn?.addEventListener('click', () => {
      localStorage.setItem(storageKey, 'accepted');
      hideBanner();
    });

    declineBtn?.addEventListener('click', () => {
      localStorage.setItem(storageKey, 'declined');
      hideBanner();
    });
  }

  const accordions = document.querySelectorAll('.accordion-item button');
  accordions.forEach(button => {
    const content = button.nextElementSibling;
    button.setAttribute('aria-expanded', 'false');
    if (content) {
      content.style.maxHeight = null;
    }
    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', !expanded);
      button.parentElement.classList.toggle('is-open', !expanded);
      if (!expanded) {
        content.style.maxHeight = content.scrollHeight + 'px';
      } else {
        content.style.maxHeight = null;
      }
    });
  });
});