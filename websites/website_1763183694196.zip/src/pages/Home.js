import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

function Home() {
  return (
    <>
      <Helmet>
        <title>TechSolutions | Cloud Consulting & Digital Transformation Partner</title>
        <meta
          name="description"
          content="TechSolutions empowers enterprises with strategic cloud consulting, modernization, and digital transformation services delivered by seasoned experts."
        />
      </Helmet>
      <div className={styles.hero}>
        <div className="layout">
          <div className={styles.heroContent}>
            <div className={styles.badge}>Trusted Cloud Consultants</div>
            <h1 className={styles.title}>
              Accelerate cloud innovation and transform with confidence.
            </h1>
            <p className={styles.subtitle}>
              TechSolutions helps enterprises modernize, migrate, and optimize their technology ecosystems with future-ready cloud architectures and human-centered digital strategies.
            </p>
            <div className={styles.actions}>
              <Link to="/contact" className={styles.primaryAction}>
                Schedule a Consultation
              </Link>
              <Link to="/services" className={styles.secondaryAction}>
                Explore Services
              </Link>
            </div>
            <div className={styles.metrics}>
              <div>
                <span className={styles.metricValue}>250+</span>
                <span className={styles.metricLabel}>Cloud engagements delivered</span>
              </div>
              <div>
                <span className={styles.metricValue}>40%</span>
                <span className={styles.metricLabel}>Average time-to-value acceleration</span>
              </div>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/seed/cloudteam/640/700"
              alt="Tech consultants collaborating on cloud strategy"
            />
          </div>
        </div>
      </div>

      <section className={styles.servicesPreview}>
        <div className="layout">
          <div className={styles.sectionHeader}>
            <h2>Strategic services for every stage of your cloud journey</h2>
            <p>
              From initial discovery to operational excellence, we provide holistic support so you can unlock measurable business outcomes with modern, secure infrastructure.
            </p>
          </div>
          <div className={styles.serviceGrid}>
            <article className={styles.serviceCard}>
              <div className={styles.icon}>
                <svg viewBox="0 0 24 24">
                  <path d="M4 17V7a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v8" />
                  <path d="M4 17a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2" />
                </svg>
              </div>
              <h3>Cloud Strategy & Roadmaps</h3>
              <p>
                Define a strategic blueprint aligned to business priorities. We assess readiness, architect the target state, and plan phased execution.
              </p>
            </article>
            <article className={styles.serviceCard}>
              <div className={styles.icon}>
                <svg viewBox="0 0 24 24">
                  <path d="M12 3v18" />
                  <path d="M16 7H8a2 2 0 0 0-2 2v10" />
                  <path d="M20 17V9a2 2 0 0 0-2-2h-6" />
                </svg>
              </div>
              <h3>Migration & Modernization</h3>
              <p>
                Migrate workloads with minimal disruption. We modernize applications, optimize data flows, and apply DevOps automation.
              </p>
            </article>
            <article className={styles.serviceCard}>
              <div className={styles.icon}>
                <svg viewBox="0 0 24 24">
                  <path d="M4 12h16" />
                  <path d="M12 4v16" />
                  <circle cx="12" cy="12" r="9" />
                </svg>
              </div>
              <h3>Cloud Security & Governance</h3>
              <p>
                Strengthen resilience with proactive security architectures, IAM, compliance automation, and continuous monitoring frameworks.
              </p>
            </article>
            <article className={styles.serviceCard}>
              <div className={styles.icon}>
                <svg viewBox="0 0 24 24">
                  <path d="M3 6h18" />
                  <path d="M3 12h12" />
                  <path d="M3 18h6" />
                </svg>
              </div>
              <h3>Analytics & Automation</h3>
              <p>
                Build intelligent experiences with data platforms, AI-driven insights, and automation that unlock new efficiencies and value.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.whyUs}>
        <div className="layout">
          <div className={styles.sectionHeaderAlt}>
            <h2>Why organizations partner with TechSolutions</h2>
            <p>
              We blend proven methodologies, certified expertise, and collaborative delivery models to deliver tangible impact across industries.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <div className={styles.whyItem}>
              <h3>Outcome-focused delivery</h3>
              <p>
                We measure success through business results. Every engagement includes clear KPIs, governance structures, and iterative value delivery.
              </p>
            </div>
            <div className={styles.whyItem}>
              <h3>Certified specialists</h3>
              <p>
                Our consultants maintain leading certifications across AWS, Azure, GCP, and security disciplines to keep your initiatives ahead of the curve.
              </p>
            </div>
            <div className={styles.whyItem}>
              <h3>Collaborative partnerships</h3>
              <p>
                We embed with your teams, co-design solutions, and provide transparent communication from discovery to run-state support.
              </p>
            </div>
            <div className={styles.whyItem}>
              <h3>Secure by design</h3>
              <p>
                Built-in controls and governance frameworks ensure that security, compliance, and reliability are foundational to every architecture.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="layout">
          <div className={styles.sectionHeaderAlt}>
            <h2>Client perspectives</h2>
            <p>
              Hear from digital leaders who partnered with TechSolutions to modernize their operations and deliver new customer value.
            </p>
          </div>
          <div className={styles.testimonialGrid}>
            <blockquote className={styles.quoteCard}>
              <p>
                “TechSolutions helped us design a scalable multi-cloud architecture that reduced deployment times by weeks. Their partnership mindset was invaluable.”
              </p>
              <footer>
                <span className={styles.quoteName}>Sara Jenkins</span>
                <span className={styles.quoteRole}>VP of Technology, Horizon Retail</span>
              </footer>
            </blockquote>
            <blockquote className={styles.quoteCard}>
              <p>
                “From discovery to launch, the team brought deep expertise and rigorous execution. We now have governance and automation frameworks that accelerate innovation.”
              </p>
              <footer>
                <span className={styles.quoteName}>Michael Chen</span>
                <span className={styles.quoteRole}>Head of Digital Platforms, FinEdge</span>
              </footer>
            </blockquote>
            <blockquote className={styles.quoteCard}>
              <p>
                “Their tailored approach to modernization delivered measurable performance gains and enabled our teams to adopt DevOps best practices confidently.”
              </p>
              <footer>
                <span className={styles.quoteName}>Ava Romero</span>
                <span className={styles.quoteRole}>Director of Engineering, Nova Health</span>
              </footer>
            </blockquote>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="layout">
          <div className={styles.ctaCard}>
            <div>
              <h2>Ready to design your next advantage?</h2>
              <p>
                Connect with our consultants to accelerate your cloud roadmap, modernize critical systems, and create resilient digital experiences.
              </p>
            </div>
            <Link to="/contact" className={styles.ctaButton}>
              Talk to our experts
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;