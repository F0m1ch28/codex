const body = document.body;
const navToggle = document.querySelector(".nav-toggle");
const primaryNav = document.querySelector(".primary-nav");
const cookieBanner = document.getElementById("cookie-banner");
const toast = document.getElementById("global-toast");
const forms = document.querySelectorAll("form[data-handler='contact']");
const revealEls = document.querySelectorAll(".reveal");

if (navToggle && primaryNav) {
  navToggle.addEventListener("click", () => {
    const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", String(!isExpanded));
    body.classList.toggle("nav-open");
  });

  primaryNav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      if (window.innerWidth <= 1024) {
        body.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });
}

const cookieStorageKey = "jtpayCookieChoice";

function showCookieBanner() {
  if (!cookieBanner) return;
  const storedChoice = window.localStorage.getItem(cookieStorageKey);
  if (!storedChoice) {
    cookieBanner.classList.add("show");
  }
}

function handleCookieChoice(choice) {
  window.localStorage.setItem(cookieStorageKey, choice);
  cookieBanner.classList.remove("show");
}

if (cookieBanner) {
  const acceptBtn = cookieBanner.querySelector("button.accept");
  const declineBtn = cookieBanner.querySelector("button.decline");

  acceptBtn?.addEventListener("click", () => handleCookieChoice("accepted"));
  declineBtn?.addEventListener("click", () => handleCookieChoice("declined"));

  showCookieBanner();
}

function displayToast(message) {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => {
    toast.classList.remove("show");
  }, 2500);
}

forms.forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    displayToast("Bericht ontvangen / Message received");
    setTimeout(() => {
      window.location.href = form.getAttribute("action") || "thank-you.html";
    }, 1800);
  });
});

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18 }
  );

  revealEls.forEach((el) => observer.observe(el));
} else {
  revealEls.forEach((el) => el.classList.add("visible"));
}

window.addEventListener("resize", () => {
  if (window.innerWidth > 1024) {
    body.classList.remove("nav-open");
    navToggle?.setAttribute("aria-expanded", "false");
  }
});