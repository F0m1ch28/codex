document.addEventListener("DOMContentLoaded", function () {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".site-nav");
    const cookieBanner = document.getElementById("cookie-banner");
    const cookieButtons = document.querySelectorAll("[data-cookie-action]");
    const yearSpan = document.getElementById("current-year");
    const filterChips = document.querySelectorAll(".filter-chip");
    const postSearch = document.getElementById("post-search");
    const postCards = document.querySelectorAll(".post-card");

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && header && nav) {
        navToggle.addEventListener("click", function () {
            header.classList.toggle("nav-active");
        });
        nav.addEventListener("click", function (event) {
            if (event.target.tagName === "A") {
                header.classList.remove("nav-active");
            }
        });
    }

    const consentKey = "nphCookieConsent";
    const consentValue = localStorage.getItem(consentKey);
    if (!consentValue && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    cookieButtons.forEach(function (btn) {
        btn.addEventListener("click", function (event) {
            localStorage.setItem(consentKey, btn.getAttribute("data-cookie-action"));
            cookieBanner.classList.remove("active");
            window.location.href = btn.getAttribute("href");
            event.preventDefault();
        });
    });

    function filterPosts() {
        const activeChip = document.querySelector(".filter-chip.active");
        const selectedCategory = activeChip ? activeChip.getAttribute("data-filter") : "all";
        const searchTerm = postSearch ? postSearch.value.trim().toLowerCase() : "";

        postCards.forEach(function (card) {
            const category = card.getAttribute("data-category");
            const title = card.getAttribute("data-title").toLowerCase();
            const matchesCategory = selectedCategory === "all" || category === selectedCategory;
            const matchesSearch = !searchTerm || title.includes(searchTerm);
            if (matchesCategory && matchesSearch) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }
        });
    }

    filterChips.forEach(function (chip) {
        chip.addEventListener("click", function () {
            filterChips.forEach(function (c) {
                c.classList.remove("active");
            });
            chip.classList.add("active");
            filterPosts();
        });
    });

    if (postSearch) {
        postSearch.addEventListener("input", filterPosts);
    }

    const forms = document.querySelectorAll("form");
    forms.forEach(function (form) {
        form.addEventListener("submit", function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.classList.add("form-invalid");
            }
        });
    });
});