document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('nav-open');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptButton = document.getElementById('cookie-accept');
  const declineButton = document.getElementById('cookie-decline');
  const storageKey = 'pn-cookie-choice';

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove('active');
    }
  }

  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add('active');
    }
  }

  if (cookieBanner && acceptButton && declineButton) {
    const storedChoice = localStorage.getItem(storageKey);
    if (!storedChoice) {
      showCookieBanner();
    }

    acceptButton.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'accepted');
      hideCookieBanner();
    });

    declineButton.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'declined');
      hideCookieBanner();
    });
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    const alertBox = document.getElementById('form-alert');

    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const fields = [
        { id: 'contact-name', name: 'Name' },
        { id: 'contact-email', name: 'Email', type: 'email' },
        { id: 'contact-organization', name: 'Organization' },
        { id: 'contact-topic', name: 'Topic' },
        { id: 'contact-message', name: 'Message' }
      ];

      let hasError = false;
      if (alertBox) {
        alertBox.classList.remove('visible');
        alertBox.textContent = '';
      }

      fields.forEach(function (field) {
        const control = document.getElementById(field.id);
        const wrapper = control ? control.closest('.form-control') : null;
        if (wrapper) {
          wrapper.classList.remove('invalid');
        }

        if (control) {
          const value = control.value.trim();
          if (!value) {
            hasError = true;
            if (wrapper) {
              wrapper.classList.add('invalid');
              const error = wrapper.querySelector('.error-message');
              if (error) {
                error.textContent = field.name + ' is required.';
              }
            }
          } else if (field.type === 'email') {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(value)) {
              hasError = true;
              if (wrapper) {
                wrapper.classList.add('invalid');
                const error = wrapper.querySelector('.error-message');
                if (error) {
                  error.textContent = 'Provide a valid email address.';
                }
              }
            }
          }
        }
      });

      if (hasError) {
        if (alertBox) {
          alertBox.textContent = 'Review the highlighted fields to continue.';
          alertBox.classList.add('visible');
        }
        return;
      }

      contactForm.reset();
      window.location.href = 'thanks.html';
    });
  }
});