document.addEventListener('DOMContentLoaded', () => {
  const menuToggle = document.querySelector('.menu-toggle');
  const siteNav = document.querySelector('.site-nav');
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie="accept"]');
  const declineBtn = document.querySelector('[data-cookie="decline"]');
  const yearSpan = document.querySelector('[data-year]');
  const consentKey = 'qazaqnews_cookie_consent';

  if (menuToggle && siteNav) {
    menuToggle.addEventListener('click', () => {
      const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!isExpanded));
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          siteNav.classList.remove('is-open');
          menuToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      cookieBanner.classList.add('show');
    }

    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.classList.remove('show');
    });

    declineBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'declined');
      cookieBanner.classList.remove('show');
    });
  }
});