document.addEventListener('DOMContentLoaded', () => {
  const banner = document.getElementById('cookie-banner');
  if (!banner) return;

  const acceptBtn = banner.querySelector('[data-consent="accept"]');
  const declineBtn = banner.querySelector('[data-consent="decline"]');
  const storageKey = 'hsfr-cookie-consent';

  const stored = localStorage.getItem(storageKey);
  if (!stored) {
    requestAnimationFrame(() => {
      banner.classList.remove('hidden');
    });
  }

  const handleConsent = (value) => {
    localStorage.setItem(storageKey, value);
    banner.classList.add('hidden');
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handleConsent('accepted'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => handleConsent('declined'));
  }
});