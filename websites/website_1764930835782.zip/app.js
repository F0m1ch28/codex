document.addEventListener("DOMContentLoaded", () => {
    const banner = document.getElementById("cookieBanner");
    const acceptBtn = document.getElementById("acceptCookies");
    const declineBtn = document.getElementById("declineCookies");
    const stored = localStorage.getItem("magCookieConsent");

    const showBanner = () => {
        banner?.classList.add("visible");
    };

    if (!stored) {
        setTimeout(showBanner, 600);
    }

    acceptBtn?.addEventListener("click", () => {
        localStorage.setItem("magCookieConsent", "accepted");
        banner.classList.remove("visible");
    });

    declineBtn?.addEventListener("click", () => {
        localStorage.setItem("magCookieConsent", "declined");
        banner.classList.remove("visible");
    });

    const yearSpan = document.getElementById("year");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});