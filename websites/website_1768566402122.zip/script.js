document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".site-nav a");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = siteNav.classList.toggle("open");
            navToggle.classList.toggle("active");
            navToggle.setAttribute("aria-expanded", String(isOpen));
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768 && siteNav.classList.contains("open")) {
                    siteNav.classList.remove("open");
                    navToggle.classList.remove("active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });

        window.addEventListener("resize", () => {
            if (window.innerWidth >= 768) {
                siteNav.classList.remove("open");
                navToggle.classList.remove("active");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptButton = document.getElementById("cookie-accept");
    const declineButton = document.getElementById("cookie-decline");

    const hideCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove("visible");
        }
    };

    const showCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add("visible");
        }
    };

    const storedPreference = localStorage.getItem("cookiePreference");
    if (!storedPreference) {
        setTimeout(showCookieBanner, 600);
    }

    if (acceptButton) {
        acceptButton.addEventListener("click", () => {
            localStorage.setItem("cookiePreference", "accepted");
            hideCookieBanner();
        });
    }

    if (declineButton) {
        declineButton.addEventListener("click", () => {
            localStorage.setItem("cookiePreference", "declined");
            hideCookieBanner();
        });
    }
});