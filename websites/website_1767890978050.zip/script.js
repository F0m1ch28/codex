document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-link');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('open');
        });
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('open')) {
                    siteNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('discmmss-cookie-choice');
        if (storedChoice) {
            cookieBanner.classList.add('hidden');
        }
        const cookieChoices = document.querySelectorAll('.cookie-choice');
        cookieChoices.forEach(choice => {
            choice.addEventListener('click', (event) => {
                event.preventDefault();
                const value = choice.dataset.choice || 'unknown';
                localStorage.setItem('discmmss-cookie-choice', value);
                cookieBanner.classList.add('hidden');
                const targetUrl = choice.getAttribute('href');
                if (targetUrl) {
                    window.open(targetUrl, '_blank');
                }
            });
        });
    }
});