import React from 'react';
import { Helmet } from 'react-helmet';
import { FiLinkedin, FiMail } from 'react-icons/fi';
import useRevealOnScroll from '../hooks/useRevealOnScroll';
import styles from './Team.module.css';

const teamMembers = [
  {
    name: 'Mara Hoffmann',
    role: 'Leitung Somatic & Breathwork',
    bio: 'Somatic Practitioner, Trauma-sensitive Yoga-Lehrerin und Breathwork Coach mit Fokus auf Nervensystem-Regulation und Embodiment.',
    image: 'https://picsum.photos/400/400?random=601',
    specialty: 'Somatische Regulation'
  },
  {
    name: 'Jonas Berger',
    role: 'Mindful Coaching & Ritual Design',
    bio: 'Systemischer Coach und Ritualdesigner. Übersetzt Erkenntnisse aus Psychologie und Kreativarbeit in achtsame Praktiken.',
    image: 'https://picsum.photos/400/400?random=602',
    specialty: 'Mindful Coaching'
  },
  {
    name: 'Sofia Nguyen',
    role: 'Sound & Resonance Artist',
    bio: 'Musikerin und Klangtherapeutin. Kreiert immersive Klanglandschaften mit Kristall-Klangschalen, Stimme und Modular Synth.',
    image: 'https://picsum.photos/400/400?random=603',
    specialty: 'Sound Immersions'
  },
  {
    name: 'Leonard Alves',
    role: 'Corporate Resilience Facilitator',
    bio: 'Leadership-Coach und Organisationsentwickler. Begleitet Teams mit Fokus auf Resilienz, Empathie und Co-Creation.',
    image: 'https://picsum.photos/400/400?random=604',
    specialty: 'Corporate Resilience'
  },
  {
    name: 'Nora Etes',
    role: 'Mindfulness & Creative Journaling',
    bio: 'Achtsamkeitslehrerin, Journal-Coach und Autorin. Entwickelt Schreibrituale, die Klarheit und Selbstmitgefühl fördern.',
    image: 'https://picsum.photos/400/400?random=605',
    specialty: 'Creative Journaling'
  },
  {
    name: 'Pia Santoro',
    role: 'Community & Retreats',
    bio: 'Kuratiert Retreats und Community-Events. Schafft Räume für Begegnung, kulturelle Vielfalt und sanfte Integration.',
    image: 'https://picsum.photos/400/400?random=606',
    specialty: 'Retreat Design'
  }
];

const Team = () => {
  useRevealOnScroll();

  return (
    <>
      <Helmet>
        <title>Unser Team | GreenLeaf Wellness Center Berlin</title>
        <meta
          name="description"
          content="Lernen Sie das Team des GreenLeaf Wellness Center kennen: Expert*innen für Somatik, Mindfulness, Sound Immersions und Corporate Resilience."
        />
        <meta property="og:title" content="Team des GreenLeaf Wellness Center" />
        <meta
          property="og:description"
          content="Interdisziplinäre Expert*innen, die Sie achtsam auf Ihrem holistischen Wellness-Weg begleiten."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={styles.hero} data-animate>
          <div className="container">
            <h1>Menschen, die Räume für Ihr Wohlbefinden kreieren.</h1>
            <p>
              Unser Team vereint Expertise aus somatischer Arbeit, Coaching, Klangkunst und Community Building.
              Interdisziplinär, empathisch und stets mit einem offenen Ohr für Ihre Bedürfnisse.
            </p>
          </div>
        </section>

        <section className={styles.gridSection} data-animate>
          <div className="container">
            <div className={styles.grid}>
              {teamMembers.map((member) => (
                <article key={member.name} className={styles.card}>
                  <div className={styles.imageWrap}>
                    <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                  </div>
                  <div className={styles.cardBody}>
                    <span className={styles.specialty}>{member.specialty}</span>
                    <h3>{member.name}</h3>
                    <p className={styles.role}>{member.role}</p>
                    <p className={styles.bio}>{member.bio}</p>
                    <div className={styles.actions}>
                      <a href="mailto:info@greenleaf-wellness.de" aria-label={`E-Mail an ${member.name}`}>
                        <FiMail />
                      </a>
                      <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                        <FiLinkedin />
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.values} data-animate>
          <div className="container">
            <h2>Wie wir zusammenarbeiten.</h2>
            <ul>
              <li><strong>Kollaborativ:</strong> Jede Session wird im Team reflektiert, um ganzheitlich zu begleiten.</li>
              <li><strong>Traumasensibel:</strong> Sicherheit, Freiwilligkeit und Ressourcenorientierung stehen an erster Stelle.</li>
              <li><strong>Wertschätzend:</strong> Vielfalt an Hintergründen, Perspektiven und Erfahrungen bereichert unsere Räume.</li>
              <li><strong>Lernend:</strong> Fortbildungen und Supervision sind fester Bestandteil unserer Kultur.</li>
            </ul>
          </div>
        </section>
      </div>
    </>
  );
};

export default Team;