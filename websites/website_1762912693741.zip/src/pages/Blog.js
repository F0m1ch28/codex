import React from 'react';
import { Helmet } from 'react-helmet';
import useRevealOnScroll from '../hooks/useRevealOnScroll';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Achtsame Morgenrituale für Stabilität im Alltag',
    excerpt:
      'Mit sanften Bewegungen, bewusster Atmung und einem Sinnesanker starten Sie grounded in Ihren Tag.',
    image: 'https://picsum.photos/900/600?random=701',
    date: '15. März 2024'
  },
  {
    title: 'Integratives Journaling – Fragen, die tiefer gehen',
    excerpt:
      'Fünf Reflexionsfragen, die Selbstmitgefühl stärken und Sie mit Ihren Ressourcen verbinden.',
    image: 'https://picsum.photos/900/600?random=702',
    date: '02. März 2024'
  },
  {
    title: 'Sound Immersions: Warum Frequenzen uns regulieren',
    excerpt:
      'Ein Blick hinter unsere Klangräume und wie Resonanzen das vegetative Nervensystem harmonisieren.',
    image: 'https://picsum.photos/900/600?random=703',
    date: '19. Februar 2024'
  },
  {
    title: 'Mindful Collaboration für Teams',
    excerpt:
      'Wie Teams mit achtsamer Kommunikation, Check-ins und Co-Regulation resilienter zusammenarbeiten.',
    image: 'https://picsum.photos/900/600?random=704',
    date: '05. Februar 2024'
  }
];

const Blog = () => {
  useRevealOnScroll();

  return (
    <>
      <Helmet>
        <title>Wellness Blog | GreenLeaf Wellness Center Berlin</title>
        <meta
          name="description"
          content="Der GreenLeaf Blog bietet Inspiration für tägliche Achtsamkeit, resiliente Routinen und holistische Wellness in Berlin."
        />
        <meta property="og:title" content="GreenLeaf Wellness Blog" />
        <meta
          property="og:description"
          content="Insights zu Mindfulness, Sound Immersions, Journaling und Ritualdesign – kuratiert vom GreenLeaf Team."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={styles.hero} data-animate>
          <div className="container">
            <h1>GreenLeaf Wellness Blog</h1>
            <p>
              Aktuelle Inspirationen, achtsame Routinen und Gedanken unseres Teams. Für Menschen, die Balance und
              Leichtigkeit in ihren Alltag integrieren möchten.
            </p>
          </div>
        </section>

        <section className={styles.gridSection} data-animate>
          <div className="container">
            <div className={styles.grid}>
              {posts.map((post) => (
                <article key={post.title} className={styles.card}>
                  <div className={styles.imageWrap}>
                    <img src={post.image} alt={post.title} loading="lazy" />
                  </div>
                  <div className={styles.body}>
                    <span className={styles.date}>{post.date}</span>
                    <h3>{post.title}</h3>
                    <p>{post.excerpt}</p>
                    <button type="button" className={styles.readMore}>
                      Beitrag demnächst verfügbar
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Blog;