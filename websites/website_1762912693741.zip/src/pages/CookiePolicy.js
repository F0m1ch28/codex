import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './SimplePage.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie | GreenLeaf Wellness Center Berlin</title>
      <meta
        name="description"
        content="Cookie-Richtlinie des GreenLeaf Wellness Center Berlin. Informationen zu verwendeten Cookies und Einstellungsmöglichkeiten."
      />
    </Helmet>

    <div className={styles.page}>
      <div className="container">
        <header className={styles.header}>
          <h1>Cookie-Richtlinie</h1>
          <p>Stand: März 2024</p>
        </header>

        <section className={styles.section}>
          <h2>1. Allgemeines</h2>
          <p>
            Unsere Website verwendet Cookies, um Funktionen bereitzustellen, Statistiken zu analysieren und Inhalte zu
            optimieren. Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Arten von Cookies</h2>
          <ul>
            <li><strong>Essenzielle Cookies:</strong> Erforderlich für grundlegende Funktionen der Website.</li>
            <li><strong>Funktionale Cookies:</strong> Ermöglichen erweiterte Funktionen wie das Speichern von Formularinhalten.</li>
            <li><strong>Analyse-Cookies:</strong> Helfen uns zu verstehen, wie Besucher*innen unsere Website nutzen.</li>
          </ul>
        </section>

        <section className={styles.section}>
          <h2>3. Verwaltung von Cookies</h2>
          <p>
            Sie können Cookies in Ihrem Browser deaktivieren oder löschen. Bitte beachten Sie, dass bestimmte Funktionen
            der Website dadurch eingeschränkt sein können.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Einwilligung</h2>
          <p>
            Durch die Nutzung unserer Website stimmen Sie der Verwendung essenzieller Cookies zu. Optional können Sie der
            Verwendung zusätzlicher Cookies zustimmen.
          </p>
        </section>

        <section className={styles.section}>
          <h2>5. Kontakt</h2>
          <p>
            Bei Fragen zur Cookie-Richtlinie kontaktieren Sie uns unter{' '}
            <a href="mailto:info@greenleaf-wellness.de">info@greenleaf-wellness.de</a>.
          </p>
        </section>
      </div>
    </div>
  </>
);

export default CookiePolicy;