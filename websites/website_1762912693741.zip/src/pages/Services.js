import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { FiFeather, FiFramer, FiAnchor, FiHeadphones, FiSun, FiCompass } from 'react-icons/fi';
import useRevealOnScroll from '../hooks/useRevealOnScroll';
import styles from './Services.module.css';

const offerings = [
  {
    title: 'Somatische Präsenz Sessions',
    description:
      'Feinfühlige Körperarbeit, Atemintegration und sanfte Mobilisation, die Ihr Nervensystem balanciert und Präsenz stärkt.',
    focus: ['Somatic Flow', 'Body Awareness', 'Resonanzräume'],
    icon: <FiFeather />
  },
  {
    title: 'Mindful Coaching Journeys',
    description:
      'Coaching in Einzel- oder Duo-Settings mit Journey-Mapping, Journaling-Impulsen und integrativen Reflektionen.',
    focus: ['Mindful Communication', 'Clarity Mapping', 'Self Leadership'],
    icon: <FiCompass />
  },
  {
    title: 'Sound Immersion Experiences',
    description:
      'Klangräume mit Kristall-Klangschalen, Handpans und Stimme schaffen ein tiefes Reset für Emotion und Geist.',
    focus: ['Soundbaths', 'Breath Flow', 'Kohärenz'],
    icon: <FiHeadphones />
  },
  {
    title: 'Seasonal Ritual Design',
    description:
      'Naturverbundene Rituale im Rhythmus der Jahreszeiten: Journaling, Kakao-Zeremonien und mindful Movement.',
    focus: ['Community', 'Slow Living', 'Creative Rituals'],
    icon: <FiSun />
  },
  {
    title: 'Corporate Resilience Labs',
    description:
      'Module für Teams: Nervensystem-Wissen, mindful Collaboration, Resilienz-Trainings und integrative Auszeiten.',
    focus: ['Team Alignment', 'Hybrid Balance', 'Wellbeing Culture'],
    icon: <FiAnchor />
  },
  {
    title: 'Retreat & Pop-up Konzepte',
    description:
      'Wir gestalten immersive Retreats, Pop-ups und Festival-Oasen mit Fokus auf Ruhe, Begegnung und Co-Regulation.',
    focus: ['Experience Design', 'Community', 'Embodiment'],
    icon: <FiFramer />
  }
];

const Services = () => {
  useRevealOnScroll();
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>Holistische Angebote | GreenLeaf Wellness Center Berlin</title>
        <meta
          name="description"
          content="Entdecken Sie holistische Angebote des GreenLeaf Wellness Center: Somatische Sessions, Sound Immersions, Coaching Journeys und Corporate Resilience Labs."
        />
        <meta property="og:title" content="Holistische Angebote im GreenLeaf Wellness Center" />
        <meta
          property="og:description"
          content="Individuelle Sessions, Retreats und Programme für achtsames Wohlbefinden, mentale Stärke und Resilienz."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={styles.hero} data-animate>
          <div className="container">
            <div className={styles.heroInner}>
              <div>
                <p className={styles.eyebrow}>Angebote</p>
                <h1>Holistische Therapien & Experiences – individuell und modular.</h1>
                <p>
                  Unsere Angebote lassen sich flexibel kombinieren. Ob Einzelperson, Team oder Community – wir kreieren
                  Räume, die sich stimmig anfühlen und nachhaltige Wirkung entfalten.
                </p>
              </div>
              <div className={styles.heroVisual}>
                <img
                  src="https://picsum.photos/1000/650?random=301"
                  alt="Meditationsstudio mit warmem Licht"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        <section className={styles.offerings} data-animate>
          <div className="container">
            <div className={styles.offeringsGrid}>
              {offerings.map((item, index) => (
                <article
                  key={item.title}
                  className={`${styles.card} ${activeIndex === index ? styles.active : ''}`}
                  onMouseEnter={() => setActiveIndex(index)}
                >
                  <div className={styles.cardHead}>
                    <span className={styles.icon}>{item.icon}</span>
                    <h3>{item.title}</h3>
                  </div>
                  <p>{item.description}</p>
                  <ul>
                    {item.focus.map((focus) => (
                      <li key={focus}>{focus}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.flow} data-animate>
          <div className="container">
            <div className={styles.flowInner}>
              <div className={styles.flowContent}>
                <p className={styles.eyebrow}>Integration</p>
                <h2>Ein Ablauf, der Ihre Reise trägt.</h2>
                <p>
                  Jede Begleitung folgt einem sanften Rhythmus. Wir schaffen Klarheit, integrieren Rituale und reflektieren
                  Fortschritte – mit Raum für Intuition und Anpassung.
                </p>
                <div className={styles.flowSteps}>
                  <div>
                    <span>1</span>
                    <h4>Kennenlernen & Intention</h4>
                    <p>Wir definieren Ihre Ziele, Ressourcen und gewünschten Räume.</p>
                  </div>
                  <div>
                    <span>2</span>
                    <h4>Co-Kreation des Programms</h4>
                    <p>Module, Frequenz und Übergänge werden individuell abgestimmt.</p>
                  </div>
                  <div>
                    <span>3</span>
                    <h4>Session Experience</h4>
                    <p>Somatische Begleitung, Klangräume und mindful Dialoge.</p>
                  </div>
                  <div>
                    <span>4</span>
                    <h4>Integration & Momentum</h4>
                    <p>Alltagstaugliche Tools, Reflexion und sanfte Check-ins.</p>
                  </div>
                </div>
              </div>
              <div className={styles.flowVisual}>
                <img
                  src="https://picsum.photos/900/650?random=302"
                  alt="Therapeutische Session mit Klangschalen"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        <section className={styles.cta} data-animate>
          <div className="container">
            <div className={styles.ctaInner}>
              <div>
                <p className={styles.eyebrow}>Jetzt starten</p>
                <h2>Vereinbaren Sie Ihr unverbindliches Discovery-Gespräch.</h2>
                <p>
                  Wir hören zu, stellen Fragen und skizzieren gemeinsam Ihr individuelles Programm.
                </p>
              </div>
              <a className={styles.ctaButton} href="/get-in-touch">
                Anfragen
              </a>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Services;