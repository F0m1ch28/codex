import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import {
  FiArrowRight,
  FiCheckCircle,
  FiFeather,
  FiHeart,
  FiSun,
  FiTarget,
  FiPlayCircle,
  FiUsers,
  FiBookOpen
} from 'react-icons/fi';
import useRevealOnScroll from '../hooks/useRevealOnScroll';
import styles from './Home.module.css';

const stats = [
  { label: 'Jahre ganzheitliche Begleitung', value: 12 },
  { label: 'Individuelle Wellness-Programme', value: 150 },
  { label: 'Zufriedene Mitglieder', value: 980 },
  { label: 'Zertifizierte Expert*innen', value: 8 }
];

const services = [
  {
    title: 'Achtsamkeitsbasierte Körperarbeit',
    description:
      'Sanfte, tiefgehende Körperarbeit mit bewusster Atmung unterstützt Sie dabei, Spannungen zu lösen und Präsenz zu kultivieren.',
    icon: <FiFeather />
  },
  {
    title: 'Naturnahe Resilienz-Rituale',
    description:
      'Rituale im Rhythmus der Jahreszeiten bringen Erdung und helfen, persönliche Ressourcen nachhaltig zu stärken.',
    icon: <FiSun />
  },
  {
    title: 'Ganzheitliche Mind-Body-Coachings',
    description:
      'Individuelle Sessions mit Fokus auf mentaler Klarheit, emotionaler Balance und alltagstauglichen Achtsamkeitsstrategien.',
    icon: <FiHeart />
  },
  {
    title: 'Sound & Breath Immersions',
    description:
      'Klangbäder und geführte Atemreisen für tiefe Entspannung, die Nervensystem und Bewusstsein harmonisieren.',
    icon: <FiPlayCircle />
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Erstes Kennenlernen',
    text: 'Wir hören zu, verstehen Ziele und Ressourcen und formulieren gemeinsam eine stimmige Intention.',
    highlight: 'Vertrauensvolle Basis & klare Ausrichtung'
  },
  {
    step: '02',
    title: 'Individuelle Gestaltung',
    text: 'Wir entwickeln ein holistisches Programm aus Ritualen, Körperarbeit, Mindfulness und Integration.',
    highlight: 'Persönlicher Flow & modulare Elemente'
  },
  {
    step: '03',
    title: 'Begleitete Umsetzung',
    text: 'Mit empathischer Begleitung und verständlichen Impulsen erleben Sie spürbare Transformation.',
    highlight: 'Resonanz, Feedback & Integration'
  },
  {
    step: '04',
    title: 'Reflexion & Momentum',
    text: 'Wir feiern Fortschritte, adapten Tools für den Alltag und verankern nachhaltige Routinen.',
    highlight: 'Langfristige Stabilität & Selbstwirksamkeit'
  }
];

const testimonials = [
  {
    quote:
      'Schon nach den ersten Sessions fühlte ich mich geerdet und klar. GreenLeaf hat mir beigebracht, wie ich mitten in Berlin mein inneres Zuhause pflegen kann.',
    name: 'Sophie M.',
    role: 'Creative Director, Berlin'
  },
  {
    quote:
      'Die Kombination aus Breathwork, Sound und bewusster Reflexion hat mein Nervensystem nachhaltig reguliert. Das Team ist unglaublich achtsam.',
    name: 'Daniel K.',
    role: 'Product Lead, Kreuzberg'
  },
  {
    quote:
      'Das Programm hat mich durch eine intensive Lebensphase getragen. Ich habe gelernt, meinen Körper wieder als Verbündeten wahrzunehmen.',
    name: 'Lena F.',
    role: 'Unternehmerin'
  }
];

const projectEntries = [
  {
    id: 1,
    title: 'Urban Retreat Series',
    categories: ['Ritualdesign', 'Mindfulness'],
    description:
      'Modulare Retreat-Erlebnisse mit Fokus auf Slow Living und regenerierende Soundscapes.',
    image: 'https://picsum.photos/1200/800?random=401',
    alt: 'Atmosphärische Retreat-Serie mit meditativem Setting'
  },
  {
    id: 2,
    title: 'Corporate Resilience Weeks',
    categories: ['Corporate Wellness', 'Co-Creation'],
    description:
      'Begleitete Wochenformate für Teams mit Resilienz-Impulsen, mindful Communication und regenerativer Bewegung.',
    image: 'https://picsum.photos/1200/800?random=402',
    alt: 'Team in einem hellen Raum während einer achtsamen Übung'
  },
  {
    id: 3,
    title: 'Moon Cycle Gatherings',
    categories: ['Community', 'Ritualdesign'],
    description:
      'Intuitive Abendformate mit Journaling, Breath Flow und Klang, abgestimmt auf lunare Rhythmen.',
    image: 'https://picsum.photos/1200/800?random=403',
    alt: 'Kerzenlicht und Gathering für achtsame Rituale'
  },
  {
    id: 4,
    title: 'Mindful Mobility Pods',
    categories: ['Mindfulness', 'Innovation'],
    description:
      'Mobile Pop-up Lounges für Festivals und Firmen, die achtsame Pausenräume mitten im Geschehen schaffen.',
    image: 'https://picsum.photos/1200/800?random=404',
    alt: 'Modernes Pop-up Studio für Achtsamkeit'
  }
];

const faqItems = [
  {
    question: 'Wie gestaltet sich der erste Termin?',
    answer:
      'Wir beginnen mit einem empathischen Gespräch, definieren Ihre Bedürfnisse und setzen eine klare Intention. Gemeinsam wählen wir passende Module wie Breathwork, Klangräume oder Mindfulness-Coachings.'
  },
  {
    question: 'Kann ich einzelne Sessions besuchen oder braucht es Programme?',
    answer:
      'Beides ist möglich. Viele Gäste starten mit Einzel-Sessions und entwickeln anschließend ein maßgeschneidertes Programm. Wir passen den Rhythmus an Alltag und Bedürfnisse an.'
  },
  {
    question: 'Sind die Angebote auch für Teams geeignet?',
    answer:
      'Ja. Wir kuratieren Formate für Teams, Leadership Circles und kreative Communities. Dabei achten wir auf sichere Räume, bewusste Kommunikation und nachhaltige Integration.'
  },
  {
    question: 'Welche Sprachen bietet ihr an?',
    answer:
      'Unsere Sessions sind auf Deutsch und Englisch verfügbar. Wir kreieren eine Atmosphäre, die kulturelle Vielfalt respektiert und individuelle Ausdrucksformen einbezieht.'
  }
];

const blogPosts = [
  {
    title: 'Fünf Rituale für einen achtsamen Start in den Tag',
    excerpt:
      'Mit bewusster Atmung, sanfter Mobilisation und einem Sinnesankern gelingt Ihnen ein kraftvoller Start in den Morgen.',
    date: '05. März 2024',
    image: 'https://picsum.photos/800/600?random=501',
    alt: 'Lichtdurchfluteter Raum mit Yoga-Matte und Pflanzen',
    link: '/wellness-blog'
  },
  {
    title: 'Micro-Routinen für mehr mentale Klarheit',
    excerpt:
      'Kleine, regelmäßige Achtsamkeitsmomente stärken Fokus, Resilienz und Selbstwahrnehmung in einem fordernden Alltag.',
    date: '18. Februar 2024',
    image: 'https://picsum.photos/800/600?random=502',
    alt: 'Notizbuch und Tee für eine achtsame Schreibpraxis',
    link: '/wellness-blog'
  },
  {
    title: 'Soundbäder als Reset für das Nervensystem',
    excerpt:
      'Erfahren Sie, wie Frequenzen und Resonanzen Ihr autonomes Nervensystem beruhigen und tiefe Entspannung fördern.',
    date: '29. Januar 2024',
    image: 'https://picsum.photos/800/600?random=503',
    alt: 'Klangschalen im warmen Kerzenlicht aufgestellt',
    link: '/wellness-blog'
  }
];

const Home = () => {
  useRevealOnScroll();
  const [counters, setCounters] = useState(stats.map(() => 0));
  const [activeProjectFilter, setActiveProjectFilter] = useState('Alle');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [formStatus, setFormStatus] = useState('');

  useEffect(() => {
    const duration = 2000;
    const frameRate = 30;
    const totalFrames = Math.round(duration / frameRate);
    const countersStart = stats.map(() => 0);
    let frame = 0;

    const interval = setInterval(() => {
      frame += 1;
      const progress = Math.min(frame / totalFrames, 1);
      const updated = stats.map((stat, idx) =>
        Math.floor(progress * (stat.value - countersStart[idx]) + countersStart[idx])
      );
      setCounters(updated);

      if (progress === 1) {
        clearInterval(interval);
      }
    }, frameRate);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const autoplay = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(autoplay);
  }, []);

  const projectFilters = ['Alle', 'Ritualdesign', 'Mindfulness', 'Corporate Wellness', 'Innovation', 'Community'];

  const filteredProjects =
    activeProjectFilter === 'Alle'
      ? projectEntries
      : projectEntries.filter((entry) => entry.categories.includes(activeProjectFilter));

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Bitte geben Sie Ihren Namen ein.';
    }
    if (!formData.email.trim()) {
      errors.email = 'Bitte geben Sie eine E-Mail-Adresse an.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email.trim())) {
      errors.email = 'Bitte prüfen Sie die E-Mail-Adresse.';
    }
    if (!formData.message.trim()) {
      errors.message = 'Bitte formulieren Sie kurz Ihr Anliegen.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (!validateForm()) return;
    setFormStatus('Vielen Dank! Wir melden uns innerhalb von 24 Stunden.');
    setFormData({ name: '', email: '', message: '' });
    setTimeout(() => setFormStatus(''), 5000);
  };

  return (
    <>
      <Helmet>
        <title>GreenLeaf Wellness Center | Ganzheitliche Wellness in Berlin</title>
        <meta
          name="description"
          content="Ganzheitliche Achtsamkeit, erdende Rituale und moderne Wellness-Angebote in Berlin. GreenLeaf begleitet Sie mit Mind-Body-Coachings, Sound Immersions und Resilienz-Räumen."
        />
        <meta property="og:title" content="GreenLeaf Wellness Center | Ganzheitliches Wohlbefinden" />
        <meta
          property="og:description"
          content="Erleben Sie holistische Programme für mentale Stärke, Körperbalance und achtsame Lebensgestaltung in Berlin."
        />
      </Helmet>

      <div className={styles.page}>

        <section className={styles.hero}>
          <div className={styles.heroOverlay} />
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <p className={styles.heroEyebrow}>Holistische Wellness in Berlin</p>
              <h1 className={styles.heroTitle}>
                Räume für Klarheit, Erdung und achtsame Transformation schaffen.
              </h1>
              <p className={styles.heroText}>
                Im GreenLeaf Wellness Center verbinden wir wissenschaftliches Mind-Body-Wissen mit
                bewährten Ritualen. Für Menschen, die sich nach Ruhe, Präsenz und einem resilienten Nervensystem
                sehnen.
              </p>
              <div className={styles.heroActions}>
                <Link to="/get-in-touch" className={styles.primaryButton}>
                  Kostenloses Kennenlernen
                  <FiArrowRight />
                </Link>
                <Link to="/about" className={styles.secondaryButton}>
                  Unser Ansatz entdecken
                </Link>
              </div>
              <div className={styles.heroHighlights}>
                <span><FiCheckCircle /> Individuelle Begleitung</span>
                <span><FiCheckCircle /> Sanfte Integration</span>
                <span><FiCheckCircle /> Urbane Oase</span>
              </div>
            </div>
            <div className={styles.heroVisual} aria-hidden="true">
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Lichtdurchfluteter Wellness-Raum mit Pflanzen"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.statsSection}`} data-animate>
          <div className="container">
            <div className={styles.statsGrid}>
              {stats.map((stat, index) => (
                <article key={stat.label} className={styles.statCard}>
                  <span className={styles.statValue}>{counters[index]}+</span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.zigzag}`} data-animate>
          <div className="container">
            <div className={styles.sectionInner}>
              <div className={styles.sectionContent}>
                <p className={styles.eyebrow}>Unser Verständnis von Wellness</p>
                <h2 className={styles.sectionTitle}>Ganzheitlichkeit bedeutet Verbindung von Körper, Geist und Natur.</h2>
                <p className={styles.sectionText}>
                  Jeder Mensch bringt eine eigene Geschichte, Sensibilität und Rhythmus mit. Wir hören zu, schaffen einen
                  achtsamen Raum und begleiten Sie dabei, Ihre innere Landschaft bewusst wahrzunehmen. Mit Ritualen, die
                  Resilienz kultivieren und zugleich leicht in den Alltag integrierbar sind.
                </p>
                <ul className={styles.bulletList}>
                  <li>
                    <FiCheckCircle />
                    Somatische Achtsamkeit zur Regulation Ihres Nervensystems
                  </li>
                  <li>
                    <FiCheckCircle />
                    Natur-inspirierte Rituale für Balance in urbanen Kontexten
                  </li>
                  <li>
                    <FiCheckCircle />
                    Ressourcenorientierte Begleitung ohne Dogmen
                  </li>
                </ul>
                <Link to="/about" className={styles.linkButton}>
                  Mehr zu unserem Ansatz
                </Link>
              </div>
              <div className={styles.sectionVisual}>
                <img
                  src="https://picsum.photos/800/600?random=102"
                  alt="Person in einem entspannten Meditationsraum"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.servicesSection}`} data-animate>
          <div className="container">
            <div className={styles.sectionHeader}>
              <p className={styles.eyebrow}>Unsere Angebote</p>
              <h2 className={styles.sectionTitle}>Modulare Sessions & Programme für Ihr holistisches Wohlbefinden.</h2>
              <p className={styles.sectionText}>
                Wir kombinieren Mindfulness, Körperarbeit und Klang in individuellen Programmen, Retreats und
                Corporate-Erlebnissen.
              </p>
            </div>
            <div className={styles.servicesGrid}>
              {services.map((service) => (
                <article key={service.title} className={styles.serviceCard}>
                  <div className={styles.iconWrap}>{service.icon}</div>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <Link to="/holistic-therapies" className={styles.cardLink}>
                    Details ansehen
                    <FiArrowRight />
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.zigzag} ${styles.tinted}`} data-animate>
          <div className="container">
            <div className={`${styles.sectionInner} ${styles.reverse}`}>
              <div className={styles.sectionVisual}>
                <img
                  src="https://picsum.photos/800/600?random=103"
                  alt="Beraterin im Gespräch mit einer Klientin"
                  loading="lazy"
                />
              </div>
              <div className={styles.sectionContent}>
                <p className={styles.eyebrow}>Unser Prozess</p>
                <h2 className={styles.sectionTitle}>Begleitung, die Schritt für Schritt Stabilität schafft.</h2>
                <div className={styles.timeline}>
                  {processSteps.map((item) => (
                    <div key={item.step} className={styles.timelineItem}>
                      <span className={styles.timelineStep}>{item.step}</span>
                      <div className={styles.timelineBody}>
                        <h3>{item.title}</h3>
                        <p>{item.text}</p>
                        <span className={styles.timelineHighlight}>{item.highlight}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <Link to="/get-in-touch" className={styles.linkButton}>
                  Prozess starten
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.projectsSection}`} data-animate>
          <div className="container">
            <div className={styles.sectionHeader}>
              <p className={styles.eyebrow}>Signature Experiences</p>
              <h2 className={styles.sectionTitle}>Individuelle Konzepte für Menschen & Teams.</h2>
              <p className={styles.sectionText}>
                Unsere Projekte entstehen in Co-Kreation mit der Community, Organisationen und kreativen Partner*innen.
              </p>
            </div>
            <div className={styles.projectFilters}>
              {projectFilters.map((filter) => (
                <button
                  key={filter}
                  type="button"
                  className={`${styles.filterButton} ${
                    activeProjectFilter === filter ? styles.filterActive : ''
                  }`}
                  onClick={() => setActiveProjectFilter(filter)}
                >
                  {filter}
                </button>
              ))}
            </div>
            <div className={styles.projectGrid}>
              {filteredProjects.map((project) => (
                <article key={project.id} className={styles.projectCard}>
                  <div className={styles.projectImage}>
                    <img src={project.image} alt={project.alt} loading="lazy" />
                  </div>
                  <div className={styles.projectBody}>
                    <h3>{project.title}</h3>
                    <p>{project.description}</p>
                    <div className={styles.projectTags}>
                      {project.categories.map((category) => (
                        <span key={category}>{category}</span>
                      ))}
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.testimonialSection}`} data-animate>
          <div className="container">
            <div className={styles.sectionHeader}>
              <p className={styles.eyebrow}>Feedback aus der Community</p>
              <h2 className={styles.sectionTitle}>Menschen, die ihren inneren Flow gefunden haben.</h2>
            </div>
            <div className={styles.testimonialCarousel}>
              <button
                type="button"
                className={styles.carouselControl}
                onClick={() =>
                  setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
                }
                aria-label="Vorheriges Testimonial"
              >
                ‹
              </button>
              {testimonials.map((testimonial, index) => (
                <article
                  key={testimonial.name}
                  className={`${styles.testimonialCard} ${
                    index === testimonialIndex ? styles.testimonialActive : ''
                  }`}
                  aria-hidden={index !== testimonialIndex}
                >
                  <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
                  <div className={styles.testimonialMeta}>
                    <span className={styles.testimonialName}>{testimonial.name}</span>
                    <span className={styles.testimonialRole}>{testimonial.role}</span>
                  </div>
                </article>
              ))}
              <button
                type="button"
                className={styles.carouselControl}
                onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonials.length)}
                aria-label="Nächstes Testimonial"
              >
                ›
              </button>
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.zigzag}`} data-animate>
          <div className="container">
            <div className={styles.sectionInner}>
              <div className={styles.sectionContent}>
                <p className={styles.eyebrow}>Unser Team</p>
                <h2 className={styles.sectionTitle}>Zertifizierte Spezialist*innen mit Herz und Klarheit.</h2>
                <p className={styles.sectionText}>
                  Von Atemarbeit über somatische Achtsamkeit bis hin zu Sound Therapie – unser interdisziplinäres Team
                  vereint Expertise mit spürbarer Empathie. Wir schaffen Räume, in denen Sie sich gesehen, begleitet und
                  motiviert fühlen.
                </p>
                <Link to="/our-team" className={styles.linkButton}>
                  Team kennenlernen
                </Link>
              </div>
              <div className={styles.sectionVisual}>
                <img
                  src="https://picsum.photos/800/600?random=104"
                  alt="Teammitglied des GreenLeaf Wellness Centers"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.faqSection}`} data-animate>
          <div className="container">
            <div className={styles.sectionHeader}>
              <p className={styles.eyebrow}>FAQ</p>
              <h2 className={styles.sectionTitle}>Antworten auf häufige Fragen.</h2>
            </div>
            <div className={styles.faqGrid}>
              {faqItems.map((item) => (
                <details key={item.question} className={styles.faqItem}>
                  <summary>
                    <FiBookOpen />
                    {item.question}
                  </summary>
                  <p>{item.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.blogSection}`} data-animate>
          <div className="container">
            <div className={styles.sectionHeader}>
              <p className={styles.eyebrow}>Wellness Blog</p>
              <h2 className={styles.sectionTitle}>Inspirationen für Ihr tägliches Wohlbefinden.</h2>
            </div>
            <div className={styles.blogGrid}>
              {blogPosts.map((post) => (
                <article key={post.title} className={styles.blogCard}>
                  <div className={styles.blogImage}>
                    <img src={post.image} alt={post.alt} loading="lazy" />
                  </div>
                  <div className={styles.blogBody}>
                    <span className={styles.blogDate}>{post.date}</span>
                    <h3>{post.title}</h3>
                    <p>{post.excerpt}</p>
                    <Link to={post.link} className={styles.cardLink}>
                      Beitrag lesen
                      <FiArrowRight />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.ctaSection}`} data-animate>
          <div className="container">
            <div className={styles.ctaContent}>
              <div>
                <p className={styles.eyebrow}>Bereit für Veränderung?</p>
                <h2 className={styles.sectionTitle}>
                  Lassen Sie uns gemeinsam einen Raum für Ihr inneres Gleichgewicht gestalten.
                </h2>
                <p className={styles.sectionText}>
                  Vereinbaren Sie ein unverbindliches Kennenlernen – digital oder vor Ort am Kurfürstendamm.
                </p>
              </div>
              <Link to="/get-in-touch" className={styles.primaryButton}>
                Gespräch buchen
                <FiTarget />
              </Link>
            </div>
          </div>
        </section>

        <section className={`${styles.section} ${styles.contactSection}`} data-animate>
          <div className="container">
            <div className={styles.sectionInner}>
              <div className={styles.sectionContent}>
                <p className={styles.eyebrow}>Kontakt</p>
                <h2 className={styles.sectionTitle}>Wir sind für Sie da.</h2>
                <p className={styles.sectionText}>
                  Schreiben Sie uns Ihr Anliegen. Wir melden uns zeitnah mit einer achtsamen Empfehlung.
                </p>
                <div className={styles.contactDetails}>
                  <p><strong>Adresse:</strong> Kurfürstendamm 185, 10707 Berlin, Germany</p>
                  <p><strong>Telefon:</strong> <a href="tel:+493012345678">+49 30 12345678</a></p>
                  <p><strong>E-Mail:</strong> <a href="mailto:info@greenleaf-wellness.de">info@greenleaf-wellness.de</a></p>
                </div>
              </div>
              <form className={styles.contactForm} onSubmit={handleFormSubmit} noValidate>
                <div className={styles.formGroup}>
                  <label htmlFor="home-name">Name *</label>
                  <input
                    id="home-name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={(event) => setFormData((prev) => ({ ...prev, name: event.target.value }))}
                    required
                  />
                  {formErrors.name && <span className={styles.formError}>{formErrors.name}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="home-email">E-Mail *</label>
                  <input
                    id="home-email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={(event) => setFormData((prev) => ({ ...prev, email: event.target.value }))}
                    required
                  />
                  {formErrors.email && <span className={styles.formError}>{formErrors.email}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="home-message">Nachricht *</label>
                  <textarea
                    id="home-message"
                    name="message"
                    rows="4"
                    value={formData.message}
                    onChange={(event) => setFormData((prev) => ({ ...prev, message: event.target.value }))}
                    required
                  />
                  {formErrors.message && <span className={styles.formError}>{formErrors.message}</span>}
                </div>
                <button type="submit" className={styles.primaryButton}>
                  Anfrage senden
                  <FiArrowRight />
                </button>
                <div className={styles.formFeedback} aria-live="polite">
                  {formStatus}
                </div>
              </form>
            </div>
          </div>
        </section>

      </div>
    </>
  );
};

export default Home;