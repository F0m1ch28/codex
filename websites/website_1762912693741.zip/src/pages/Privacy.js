import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './SimplePage.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutz | GreenLeaf Wellness Center Berlin</title>
      <meta
        name="description"
        content="Datenschutzerklärung des GreenLeaf Wellness Center Berlin. Informationen zu Datenverarbeitung, Cookies und Kontakt."
      />
    </Helmet>

    <div className={styles.page}>
      <div className="container">
        <header className={styles.header}>
          <h1>Datenschutzerklärung</h1>
          <p>Stand: März 2024</p>
        </header>

        <section className={styles.section}>
          <h2>1. Verantwortliche Stelle</h2>
          <p>
            GreenLeaf Wellness Center, Kurfürstendamm 185, 10707 Berlin, Germany. Kontakt: <a href="mailto:info@greenleaf-wellness.de">info@greenleaf-wellness.de</a>
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Erhebung und Verarbeitung personenbezogener Daten</h2>
          <p>
            Wir verarbeiten personenbezogene Daten (z. B. Name, E-Mail-Adresse, Telefonnummer) ausschließlich zur
            Bearbeitung von Anfragen, Terminabsprachen und Vertragsabwicklung. Rechtsgrundlage ist Art. 6 Abs. 1 lit. b
            DSGVO.
          </p>
        </section>

        <section className={styles.section}>
          <h2>3. Cookies</h2>
          <p>
            Unsere Website verwendet Cookies, um Funktionen zur Verfügung zu stellen und Inhalte zu verbessern. Details
            finden Sie in unserer <a href="/cookie-policy">Cookie-Richtlinie</a>. Sie können Cookies im Browser deaktivieren, wodurch Funktionen eingeschränkt sein können.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Drittanbieter</h2>
          <p>
            Zur Bereitstellung unserer Website nutzen wir Hosting-Anbieter innerhalb der EU. Eine Weitergabe an sonstige
            Dritte erfolgt nicht, außer es besteht eine gesetzliche Verpflichtung.
          </p>
        </section>

        <section className={styles.section}>
          <h2>5. Speicherdauer</h2>
          <p>
            Daten werden gelöscht, sobald der Zweck entfallen ist und keine gesetzlichen Aufbewahrungspflichten
            entgegenstehen.
          </p>
        </section>

        <section className={styles.section}>
          <h2>6. Ihre Rechte</h2>
          <ul>
            <li>Auskunft über gespeicherte Daten</li>
            <li>Berichtigung unrichtiger Daten</li>
            <li>Löschung oder Einschränkung der Verarbeitung</li>
            <li>Widerspruch gegen die Verarbeitung</li>
            <li>Datenübertragbarkeit</li>
          </ul>
          <p>
            Bitte richten Sie Ihre Anfrage an <a href="mailto:info@greenleaf-wellness.de">info@greenleaf-wellness.de</a>.
          </p>
        </section>

        <section className={styles.section}>
          <h2>7. Kontakt Datenschutz</h2>
          <p>
            Für Fragen zum Datenschutz kontaktieren Sie uns per E-Mail oder telefonisch unter{' '}
            <a href="tel:+493012345678">+49 30 12345678</a>.
          </p>
        </section>
      </div>
    </div>
  </>
);

export default Privacy;