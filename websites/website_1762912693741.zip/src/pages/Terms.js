import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './SimplePage.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Nutzungsbedingungen | GreenLeaf Wellness Center Berlin</title>
      <meta
        name="description"
        content="Nutzungsbedingungen des GreenLeaf Wellness Center Berlin. Informationen zu Nutzung, Verantwortlichkeiten und Haftung."
      />
    </Helmet>

    <div className={styles.page}>
      <div className="container">
        <header className={styles.header}>
          <h1>Nutzungsbedingungen</h1>
          <p>Stand: März 2024</p>
        </header>

        <section className={styles.section}>
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Nutzungsbedingungen regeln die Nutzung der Online-Angebote und Räumlichkeiten des GreenLeaf Wellness
            Center, Kurfürstendamm 185, 10707 Berlin. Mit der Nutzung unserer Website oder der Buchung unserer Angebote
            erkennen Sie diese Bedingungen an.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Leistungen</h2>
          <p>
            Wir bieten holistische Wellness-Leistungen, Sessions, Workshops und Retreat-Formate an. Alle Inhalte dienen
            der Gesundheitsförderung, Prävention und Persönlichkeitsentwicklung. Unsere Leistungen ersetzen keine
            medizinische oder therapeutische Behandlung.
          </p>
        </section>

        <section className={styles.section}>
          <h2>3. Buchungen & Teilnahme</h2>
          <ul>
            <li>Buchungen erfolgen online, telefonisch oder per E-Mail.</li>
            <li>
              Teilnehmer*innen verpflichten sich, relevante Informationen zu Wohlbefinden und individuellen Bedürfnissen
              vorab mitzuteilen.
            </li>
            <li>
              Die Teilnahme setzt selbstverantwortliches Handeln voraus. Wir empfehlen, individuelle Belastungsgrenzen zu
              respektieren und bei Unsicherheiten Rücksprache zu halten.
            </li>
          </ul>
        </section>

        <section className={styles.section}>
          <h2>4. Haftung</h2>
          <p>
            Wir übernehmen keine Haftung für Schäden, die aus unsachgemäßer Anwendung von Übungen oder Nichtbeachtung
            persönlicher Grenzen entstehen. Für persönliche Gegenstände wird keine Haftung übernommen.
          </p>
        </section>

        <section className={styles.section}>
          <h2>5. Urheberrechte</h2>
          <p>
            Inhalte, Texte, Bilder und Konzepte sind urheberrechtlich geschützt. Eine Nutzung oder Vervielfältigung bedarf
            unserer schriftlichen Zustimmung.
          </p>
        </section>

        <section className={styles.section}>
          <h2>6. Änderungen</h2>
          <p>
            Wir behalten uns vor, diese Nutzungsbedingungen jederzeit anzupassen. Maßgeblich ist die jeweils aktuelle
            Version auf unserer Website.
          </p>
        </section>

        <section className={styles.section}>
          <h2>7. Kontakt</h2>
          <p>
            Bei Fragen zu diesen Bedingungen kontaktieren Sie uns bitte unter{' '}
            <a href="mailto:info@greenleaf-wellness.de">info@greenleaf-wellness.de</a> oder telefonisch via{' '}
            <a href="tel:+493012345678">+49 30 12345678</a>.
          </p>
        </section>
      </div>
    </div>
  </>
);

export default Terms;