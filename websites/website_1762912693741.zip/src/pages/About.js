import React from 'react';
import { Helmet } from 'react-helmet';
import { FiCompass, FiLeaf, FiWind, FiTrendingUp } from 'react-icons/fi';
import useRevealOnScroll from '../hooks/useRevealOnScroll';
import styles from './About.module.css';

const About = () => {
  useRevealOnScroll();

  return (
    <>
      <Helmet>
        <title>Über uns | GreenLeaf Wellness Center Berlin</title>
        <meta
          name="description"
          content="Lernen Sie das GreenLeaf Wellness Center kennen – unser holistischer Ansatz, unsere Philosophie und die Werte, die uns in Berlin leiten."
        />
        <meta property="og:title" content="Über GreenLeaf Wellness Center" />
        <meta
          property="og:description"
          content="Holistische Wellness, achtsame Räume und empathische Begleitung für Menschen, die Balance suchen."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={styles.hero} data-animate>
          <div className="container">
            <div className={styles.heroInner}>
              <div className={styles.heroContent}>
                <p className={styles.eyebrow}>Unsere Geschichte</p>
                <h1>Ein urbanes Refugium für ganzheitliches Wohlbefinden in Berlin.</h1>
                <p>
                  GreenLeaf entstand aus der Vision, mitten in der Stadt einen lebendigen Raum für Erdung, Klarheit und
                  nachhaltige Transformation zu schaffen. Wir vereinen interdisziplinäre Expertise aus Mindfulness,
                  Körperarbeit und kreativer Ritualgestaltung. Unser Team begleitet Menschen und Organisationen
                  achtsam, empathisch und stets auf Augenhöhe.
                </p>
              </div>
              <div className={styles.heroVisual}>
                <img
                  src="https://picsum.photos/1000/700?random=201"
                  alt="Inspirierender Wellness-Raum mit gedämpftem Licht"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        <section className={styles.values} data-animate>
          <div className="container">
            <div className={styles.sectionHeader}>
              <p className={styles.eyebrow}>Werte</p>
              <h2>Was unsere Arbeit trägt.</h2>
              <p>
                Wir glauben, dass persönliches Wachstum dort beginnt, wo sich Sicherheit, Vertrauen und kreative
                Entfaltung begegnen. Darum gestalten wir Räume, die gleichzeitig geerdet und inspirierend sind.
              </p>
            </div>
            <div className={styles.valueGrid}>
              <article>
                <FiCompass />
                <h3>Intuitive Orientierung</h3>
                <p>
                  Wir begleiten Sie mit Klarheit und Empathie durch Veränderungsprozesse. Ihre Bedürfnisse sind der
                  Kompass, an dem wir unsere Angebote ausrichten.
                </p>
              </article>
              <article>
                <FiLeaf />
                <h3>Verwurzelfte Natürlichkeit</h3>
                <p>
                  Natur und urbaner Raum müssen kein Widerspruch sein. Wir bringen organische Rituale und Pflanzenmedien
                  in den Alltag Berlins.
                </p>
              </article>
              <article>
                <FiWind />
                <h3>Leichtigkeit & Flow</h3>
                <p>
                  Veränderung darf leicht sein. Wir schaffen Strukturen, die Beweglichkeit erlauben und in Ihren
                  Lebensrhythmus passen.
                </p>
              </article>
              <article>
                <FiTrendingUp />
                <h3>Evolution & Integration</h3>
                <p>
                  Nachhaltiges Wachstum entsteht durch Integration. Gemeinsam reflektieren wir Fortschritte und passen
                  Programme dynamisch an.
                </p>
              </article>
            </div>
          </div>
        </section>

        <section className={styles.approach} data-animate>
          <div className="container">
            <div className={styles.approachInner}>
              <div className={styles.approachContent}>
                <p className={styles.eyebrow}>Unser Ansatz</p>
                <h2>Holistische Methoden, zeitgemäß interpretiert.</h2>
                <p>
                  GreenLeaf steht für die Verbindung von Körper, Geist und Umgebung. Wir kombinieren wissenschaftlich
                  fundierte Mind-Body-Tools mit Ritualen, die sich intuitiv anfühlen. Unser Ansatz ist ressourcenbasiert,
                  traumasensibel und respektiert Ihre individuelle Geschichte.
                </p>
                <ul>
                  <li>Somatische Achtsamkeit und Breathwork für Nervensystem-Regulation</li>
                  <li>Mindful Communication & Journaling zur mentalen Klarheit</li>
                  <li>Klang- und Resonanzräume für emotionale Integration</li>
                  <li>Creative Ritual Design für Teams & Communities</li>
                </ul>
              </div>
              <div className={styles.approachVisual}>
                <img
                  src="https://picsum.photos/900/600?random=202"
                  alt="Menschen bei einer achtsamen Atemübung"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        <section className={styles.timeline} data-animate>
          <div className="container">
            <div className={styles.sectionHeader}>
              <p className={styles.eyebrow}>Meilensteine</p>
              <h2>Unser Weg seit der Gründung.</h2>
            </div>
            <div className={styles.timelineGrid}>
              <article>
                <span>2012</span>
                <h3>Gründung in Berlin-Charlottenburg</h3>
                <p>
                  Start mit kleinen Achtsamkeitsklassen und integrativer Körperarbeit für kreative Freelancer*innen.
                </p>
              </article>
              <article>
                <span>2016</span>
                <h3>Aufbau des Ritualdesign-Studios</h3>
                <p>
                  Entwicklung einzigartiger Retreat-Formate und Pop-up-Wellness-Erlebnisse in Zusammenarbeit mit
                  Kulturorten.
                </p>
              </article>
              <article>
                <span>2019</span>
                <h3>Corporate Resilience Programme</h3>
                <p>
                  Einführung maßgeschneiderter Resilienz-Wochen für Teams, die mentale Gesundheit und Co-Kreation
                  vereinen.
                </p>
              </article>
              <article>
                <span>2023</span>
                <h3>Neuer Standort am Kurfürstendamm</h3>
                <p>
                  Ein erweiterter, lichtdurchfluteter Raum für Sound Immersions, Breathwork Sessions und Co-Regulation.
                </p>
              </article>
            </div>
          </div>
        </section>

        <section className={styles.statement} data-animate>
          <div className="container">
            <blockquote>
              „Wir gestalten Räume, in denen Wandel nicht überfordernd wirkt, sondern als Einladung wahrgenommen wird,
              dem eigenen Rhythmus zu folgen.“
            </blockquote>
            <cite>— Das Team des GreenLeaf Wellness Center</cite>
          </div>
        </section>

        <section className={styles.invite} data-animate>
          <div className="container">
            <div className={styles.inviteInner}>
              <div>
                <p className={styles.eyebrow}>Ihre Reise</p>
                <h2>Bereit, Ihren Weg mit uns zu gehen?</h2>
                <p>
                  Wir freuen uns auf ein Kennenlernen – digital oder vor Ort in Berlin. Gemeinsam kreieren wir eine
                  Praxis, die Sinn, Ruhe und Kraft in Ihr Leben bringt.
                </p>
              </div>
              <Link to="/get-in-touch" className={styles.cta}>
                Kontakt aufnehmen
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default About;