import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { FiMapPin, FiPhone, FiMail, FiClock } from 'react-icons/fi';
import useRevealOnScroll from '../hooks/useRevealOnScroll';
import styles from './Contact.module.css';

const Contact = () => {
  useRevealOnScroll();
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});
  const [feedback, setFeedback] = useState('');

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) currentErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    if (!formData.email.trim()) {
      currentErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email.trim())) {
      currentErrors.email = 'Bitte prüfen Sie die E-Mail-Adresse.';
    }
    if (!formData.message.trim()) currentErrors.message = 'Bitte beschreiben Sie Ihr Anliegen.';
    setErrors(currentErrors);
    return Object.keys(currentErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setFeedback('Danke für Ihre Nachricht! Wir antworten innerhalb eines Werktages.');
    setFormData({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setFeedback(''), 5000);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | GreenLeaf Wellness Center Berlin</title>
        <meta
          name="description"
          content="Kontaktieren Sie das GreenLeaf Wellness Center in Berlin für ein unverbindliches Kennenlernen oder individuelle Wellness-Anfragen."
        />
        <meta property="og:title" content="Kontakt GreenLeaf Wellness Center" />
        <meta
          property="og:description"
          content="Kurfürstendamm 185, 10707 Berlin. Holistische Wellness-Begleitung in der Hauptstadt."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={styles.hero} data-animate>
          <div className="container">
            <div className={styles.heroInner}>
              <div>
                <p className={styles.eyebrow}>Kontakt</p>
                <h1>Wir freuen uns darauf, Sie kennenzulernen.</h1>
                <p>
                  Schreiben Sie uns Ihr Anliegen. Ob persönliches Programm, Team-Event oder Retreat – wir melden uns mit
                  einer achtsamen Empfehlung.
                </p>
              </div>
              <div className={styles.contactInfo}>
                <div>
                  <FiMapPin />
                  <span>Kurfürstendamm 185, 10707 Berlin, Germany</span>
                </div>
                <div>
                  <FiPhone />
                  <a href="tel:+493012345678">+49 30 12345678</a>
                </div>
                <div>
                  <FiMail />
                  <a href="mailto:info@greenleaf-wellness.de">info@greenleaf-wellness.de</a>
                </div>
                <div>
                  <FiClock />
                  <span>Montag – Freitag, 9:00 – 19:00 Uhr</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className={styles.formSection} data-animate>
          <div className="container">
            <div className={styles.formGrid}>
              <form onSubmit={handleSubmit} noValidate>
                <div className={styles.field}>
                  <label htmlFor="contact-name">Name *</label>
                  <input
                    id="contact-name"
                    type="text"
                    value={formData.name}
                    onChange={(event) => setFormData((prev) => ({ ...prev, name: event.target.value }))}
                    required
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="contact-email">E-Mail *</label>
                  <input
                    id="contact-email"
                    type="email"
                    value={formData.email}
                    onChange={(event) => setFormData((prev) => ({ ...prev, email: event.target.value }))}
                    required
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="contact-subject">Worum geht es?</label>
                  <input
                    id="contact-subject"
                    type="text"
                    value={formData.subject}
                    onChange={(event) => setFormData((prev) => ({ ...prev, subject: event.target.value }))}
                    placeholder="z. B. Einzelprogramm, Team Retreat, Event"
                  />
                </div>

                <div className={styles.field}>
                  <label htmlFor="contact-message">Nachricht *</label>
                  <textarea
                    id="contact-message"
                    rows="6"
                    value={formData.message}
                    onChange={(event) => setFormData((prev) => ({ ...prev, message: event.target.value }))}
                    required
                  />
                  {errors.message && <span className={styles.error}>{errors.message}</span>}
                </div>

                <button type="submit">Nachricht senden</button>
                <div className={styles.feedback} aria-live="polite">
                  {feedback}
                </div>
              </form>

              <div className={styles.panel}>
                <h2>Achtsame Räume im Westen Berlins.</h2>
                <p>
                  Unser Studio liegt in der Nähe der U-Bahn-Station Adenauerplatz. Die lichtdurchfluteten Räume bieten
                  Platz für Einzel- und Gruppenformate, Sound Immersions und kreative Workshops.
                </p>
                <div className={styles.mapPlaceholder} aria-hidden="true">
                  <span>Map Placeholder</span>
                </div>
                <p>
                  Wir bieten Sessions vor Ort sowie virtuell an. Fragen Sie uns gerne nach hybriden Möglichkeiten für
                  Ihr Team.
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Contact;