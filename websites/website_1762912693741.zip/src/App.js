import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Team from './pages/Team';
import Blog from './pages/Blog';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/about" element={<About />} />
    <Route path="/holistic-therapies" element={<Services />} />
    <Route path="/our-team" element={<Team />} />
    <Route path="/wellness-blog" element={<Blog />} />
    <Route path="/get-in-touch" element={<Contact />} />
    <Route path="/terms-of-service" element={<Terms />} />
    <Route path="/privacy-policy" element={<Privacy />} />
    <Route path="/cookie-policy" element={<CookiePolicy />} />
  </Routes>
);

const App = () => (
  <Router>
    <Helmet>
      <title>GreenLeaf Wellness Center</title>
      <meta
        name="description"
        content="GreenLeaf Wellness Center in Berlin begleitet Sie auf Ihrem Weg zu mentaler Stärke, Balance und nachhaltigem Wohlbefinden."
      />
      <link rel="canonical" href="https://www.greenleaf-wellness.de" />
    </Helmet>
    <ScrollToTopOnRouteChange />
    <Header />
    <main className="mainContent" role="main">
      <AppRoutes />
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </Router>
);

export default App;