import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiPhone, FiMail, FiMapPin, FiArrowRight, FiInstagram, FiFacebook, FiLinkedin } from 'react-icons/fi';
import styles from './Footer.module.css';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email) return;
    setSubmitted(true);
    setEmail('');
  };

  return (
    <footer className={styles.footer}>
      <div className={styles.top}>
        <div className={styles.brandColumn}>
          <h3 className={styles.brandTitle}>GreenLeaf Wellness Center</h3>
          <p className={styles.brandText}>
            Holistische Wellness-Erlebnisse für Menschen, die Balance, Klarheit und Vitalität inmitten der
            Berliner Urbanität suchen.
          </p>
          <div className={styles.socials} aria-label="Social Media">
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
            >
              <FiInstagram />
            </a>
            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
              <FiFacebook />
            </a>
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              <FiLinkedin />
            </a>
          </div>
        </div>

        <div className={styles.column}>
          <h4 className={styles.heading}>Kontakt</h4>
          <ul className={styles.list}>
            <li>
              <FiMapPin />
              <span>Kurfürstendamm 185, 10707 Berlin, Germany</span>
            </li>
            <li>
              <FiPhone />
              <a href="tel:+493012345678">+49 30 12345678</a>
            </li>
            <li>
              <FiMail />
              <a href="mailto:info@greenleaf-wellness.de">info@greenleaf-wellness.de</a>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4 className={styles.heading}>Navigation</h4>
          <ul className={styles.linkList}>
            <li>
              <Link to="/about">Über uns</Link>
            </li>
            <li>
              <Link to="/holistic-therapies">Holistische Therapien</Link>
            </li>
            <li>
              <Link to="/our-team">Team</Link>
            </li>
            <li>
              <Link to="/wellness-blog">Blog</Link>
            </li>
            <li>
              <Link to="/get-in-touch">Kontakt</Link>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4 className={styles.heading}>Newsletter</h4>
          <p className={styles.brandText}>
            Inspirationen für achtsame Routinen, Event-Updates und erdende Rituale direkt in Ihrem Postfach.
          </p>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <label htmlFor="newsletter-email" className="sr-only">
              E-Mail-Adresse
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              placeholder="Ihre E-Mail-Adresse"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
            />
            <button type="submit" aria-label="Newsletter abonnieren">
              <FiArrowRight />
            </button>
          </form>
          <div className={styles.feedback} aria-live="polite">
            {submitted && 'Vielen Dank! Bitte bestätigen Sie Ihre Anmeldung im Postfach.'}
          </div>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} GreenLeaf Wellness Center. Alle Rechte vorbehalten.</p>
        <div className={styles.bottomLinks}>
          <Link to="/privacy-policy">Datenschutz</Link>
          <Link to="/terms-of-service">Nutzungsbedingungen</Link>
          <Link to="/cookie-policy">Cookie-Richtlinie</Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;