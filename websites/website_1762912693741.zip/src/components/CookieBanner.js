import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('greenleaf_cookie_consent');
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('greenleaf_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um Ihr Erlebnis zu verfeinern und nachhaltige Wellness-Inhalte für Sie zu
          kuratieren. Erfahren Sie mehr in unserer{' '}
          <Link to="/cookie-policy">Cookie-Richtlinie</Link>.
        </p>
      </div>
      <button type="button" onClick={handleAccept}>
        Einverstanden
      </button>
    </div>
  );
};

export default CookieBanner;