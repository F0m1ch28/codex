import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { FiMenu, FiX } from 'react-icons/fi';
import { FaLeaf } from 'react-icons/fa';
import styles from './Header.module.css';

const NAV_LINKS = [
  { path: '/about', label: 'Über uns' },
  { path: '/holistic-therapies', label: 'Angebote' },
  { path: '/our-team', label: 'Team' },
  { path: '/wellness-blog', label: 'Blog' },
  { path: '/get-in-touch', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="Zur Startseite">
          <FaLeaf className={styles.logoIcon} />
          <span className={styles.logoText}>GreenLeaf Wellness Center</span>
        </Link>
        <button
          className={styles.menuButton}
          aria-label={menuOpen ? 'Navigation schließen' : 'Navigation öffnen'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          {menuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Hauptnavigation">
          <ul className={styles.navList}>
            {NAV_LINKS.map((link) => (
              <li key={link.path} className={styles.navItem}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/get-in-touch" className={styles.ctaLink}>
            Kennenlernen
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;