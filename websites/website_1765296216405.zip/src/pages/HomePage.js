import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { articles } from '../data/articlesData';
import { interviews } from '../data/interviewsData';
import styles from './HomePage.module.css';

const topics = [
  'French Classical Equitation',
  'Equestrian Pedagogy',
  'Club Hippique de France',
  'Social Role of Clubs',
  'Eventing Landscapes',
  'Veterinary Protocols',
  'Rural-Urban Dialogue',
  'FFE Governance'
];

const HomePage = () => {
  const featuredArticles = articles.slice(0, 3);
  const featuredInterviews = interviews.slice(0, 2);

  return (
    <>
      <Seo
        title="French Equestrian Clubs Review | Heritage, Culture, and Training"
        description="French Equestrian Clubs Review examines the culture, governance, and pedagogy of equestrian clubs across France through neutral reporting."
        keywords="French equestrian clubs, dressage, eventing, interviews, training methods, rural clubs, urban riding schools"
      />
      <section className={styles.hero} role="banner">
        <div className={styles.heroOverlay} />
        <div className={`${styles.heroContent} container`}>
          <span className={styles.heroLabel}>French Equestrian Clubs Review</span>
          <h1>Examining the Heritage and Culture of French Equestrian Clubs</h1>
          <p>
            An editorial initiative documenting how riding schools across France sustain tradition, develop pedagogy, and
            collaborate with their communities. The project analyses training arenas, governance models, veterinary practice,
            and cultural outreach with a neutral, research-oriented voice.
          </p>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div className={styles.missionText}>
              <h2>Mission Statement</h2>
              <p>
                French Equestrian Clubs Review investigates how equestrian clubs shape cultural heritage, education, and social
                cohesion. Reporting blends field observation, archival research, and interviews with instructors, veterinarians,
                administrators, and cultural partners. The editorial team documents everyday routines, program governance, and the
                evolving relationship between horses and communities.
              </p>
            </div>
            <div className={styles.statsPanel} aria-label="Observational indicators">
              <div className={styles.statItem}>
                <span className={styles.statNumber}>24</span>
                <span className={styles.statLabel}>Clubs Observed</span>
              </div>
              <div className={styles.statItem}>
                <span className={styles.statNumber}>12</span>
                <span className={styles.statLabel}>Regions Covered</span>
              </div>
              <div className={styles.statItem}>
                <span className={styles.statNumber}>86</span>
                <span className={styles.statLabel}>Expert Interviews</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.featured}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Featured Articles</h2>
            <p>Analytical features exploring regional practices, historical continuity, and contemporary governance.</p>
          </header>
          <div className={styles.articleGrid}>
            {featuredArticles.map((article) => (
              <article key={article.slug} className={styles.articleCard}>
                <div className={styles.articleImageWrapper}>
                  <img src={article.coverImage} alt={article.imageAlt} loading="lazy" />
                </div>
                <div className={styles.articleContent}>
                  <span className={styles.tag}>{article.category}</span>
                  <h3>{article.title}</h3>
                  <p>{article.summary}</p>
                  <div className={styles.cardMeta}>
                    <span>{article.region}</span>
                    <span>{article.readingTime}</span>
                  </div>
                  <Link to={`/articles/${article.slug}`} className={styles.cardLink}>
                    Read Analysis
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.interviewsSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Latest Interviews</h2>
            <p>Perspectives from directors, veterinarians, and coordinators shaping equestrian culture in France.</p>
          </header>
          <div className={styles.interviewGrid}>
            {featuredInterviews.map((interview) => (
              <article key={interview.slug} className={styles.interviewCard}>
                <div className={styles.portraitWrapper}>
                  <img src={interview.portrait} alt={interview.imageAlt} loading="lazy" />
                </div>
                <div className={styles.interviewContent}>
                  <span className={styles.tag}>{interview.role}</span>
                  <h3>{interview.title}</h3>
                  <p>{interview.summary}</p>
                  <Link to={`/interviews/${interview.slug}`} className={styles.cardLink}>
                    Read Interview
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.topics}>
        <div className="container">
          <header className={styles.sectionHeaderCentered}>
            <h2>Research Topics</h2>
            <p>Key themes examined across field visits, archives, and conversations.</p>
          </header>
          <div className={styles.topicCloud}>
            {topics.map((topic) => (
              <span key={topic} className={styles.topic}>
                {topic}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.editorialApproach}>
        <div className="container">
          <div className={styles.editorialCard}>
            <h2>Editorial Approach</h2>
            <ul>
              <li>
                <strong>Documented Observation:</strong> Field notes from training sessions, competitions, and governance
                meetings underpin descriptive passages and contextual analysis.
              </li>
              <li>
                <strong>Expert Testimony:</strong> Interviews with instructors, veterinarians, sociologists, and historians
                provide multi-disciplinary insight.
              </li>
              <li>
                <strong>Archival Context:</strong> Municipal and club archives inform interpretations of contemporary practices
                with historical depth.
              </li>
              <li>
                <strong>Neutral Voice:</strong> Narratives avoid speculation and respect the complexity of each club’s ecosystem,
                reinforcing ethical reporting standards.
              </li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;