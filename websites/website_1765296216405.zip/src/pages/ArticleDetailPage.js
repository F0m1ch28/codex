import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { articles } from '../data/articlesData';
import styles from './ArticleDetailPage.module.css';

const ArticleDetailPage = () => {
  const { slug } = useParams();
  const article = articles.find((item) => item.slug === slug);

  if (!article) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Article not found</h1>
          <p>The requested analysis is unavailable. Please explore the article archive to continue reading.</p>
          <Link to="/articles" className={styles.backLink}>
            Return to Articles
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Seo
        title={`${article.title} | French Equestrian Clubs Review`}
        description={article.summary}
        keywords={article.keywords.join(', ')}
      />
      <article className={styles.article}>
        <header className={styles.header}>
          <div className="container">
            <p className={styles.category}>{article.category}</p>
            <h1>{article.title}</h1>
            {article.subtitle && <p className={styles.subtitle}>{article.subtitle}</p>}
            <div className={styles.meta}>
              <span>{article.region}</span>
              <span>{article.readingTime}</span>
              <span>{new Date(article.publishedOn).toLocaleDateString('en-GB', { dateStyle: 'long' })}</span>
            </div>
          </div>
          <div className={styles.heroImage}>
            <img src={article.coverImage} alt={article.imageAlt} />
          </div>
        </header>
        <div className={`${styles.body} container`}>
          {article.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>
        <footer className={styles.footer}>
          <div className="container">
            <Link to="/articles">View more analyses</Link>
          </div>
        </footer>
      </article>
    </>
  );
};

export default ArticleDetailPage;