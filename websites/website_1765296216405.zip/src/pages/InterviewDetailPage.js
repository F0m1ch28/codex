import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { interviews } from '../data/interviewsData';
import styles from './InterviewDetailPage.module.css';

const InterviewDetailPage = () => {
  const { slug } = useParams();
  const interview = interviews.find((item) => item.slug === slug);

  if (!interview) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Interview not found</h1>
          <p>The requested conversation is unavailable. Consult the interview archive for additional profiles.</p>
          <Link to="/interviews" className={styles.backLink}>
            Return to Interviews
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Seo
        title={`${interview.title} | French Equestrian Clubs Review`}
        description={interview.summary}
        keywords={`${interview.name}, ${interview.role}, French equestrian interview`}
      />
      <article className={styles.article}>
        <header className={styles.header}>
          <div className="container">
            <div className={styles.headerInner}>
              <div className={styles.portrait}>
                <img src={interview.portrait} alt={interview.imageAlt} />
              </div>
              <div>
                <p className={styles.role}>{interview.role}</p>
                <h1>{interview.title}</h1>
                {interview.subtitle && <p className={styles.subtitle}>{interview.subtitle}</p>}
                <div className={styles.meta}>
                  <span>{interview.specialization}</span>
                  <span>{interview.readingTime}</span>
                  <span>{new Date(interview.publishedOn).toLocaleDateString('en-GB', { dateStyle: 'long' })}</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className={`${styles.body} container`}>
          {interview.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>

        <footer className={styles.footer}>
          <div className="container">
            <Link to="/interviews">Explore more interviews</Link>
          </div>
        </footer>
      </article>
    </>
  );
};

export default InterviewDetailPage;