import React from 'react';
import Seo from '../components/Seo';
import styles from './PolicyPage.module.css';

const TermsPage = () => (
  <>
    <Seo
      title="Terms of Use | French Equestrian Clubs Review"
      description="Terms governing access to French Equestrian Clubs Review content."
      keywords="terms of use, French equestrian review"
    />
    <section className={styles.policy}>
      <div className="container">
        <h1>Terms of Use</h1>
        <p>Last updated: 15 April 2024</p>

        <h2>1. Purpose</h2>
        <p>
          French Equestrian Clubs Review provides cultural and analytical journalism about equestrian clubs in France. Accessing
          this site implies acceptance of these terms. Users agree to consult the content responsibly and to respect the rights of
          individuals and organisations described herein.
        </p>

        <h2>2. Intellectual Property</h2>
        <p>
          All original text, graphics, and design elements are protected by applicable intellectual property laws. Reproduction or
          redistribution requires prior written authorisation from the editorial coordination team. Quotations may be used for
          academic or journalistic purposes with appropriate citation.
        </p>

        <h2>3. Fair Use of Content</h2>
        <p>
          Excerpts may be referenced for research, educational, or press coverage provided that attribution is clear and links
          direct readers to the original article. Misrepresentation of the content or selective quoting that alters meaning is
          prohibited.
        </p>

        <h2>4. External Links</h2>
        <p>
          Links to third-party sites appear for contextual information. The review does not control those resources and bears no
          responsibility for their accuracy or policies. Users should consult external terms independently.
        </p>

        <h2>5. User Conduct</h2>
        <p>
          Users must refrain from actions that could disrupt site operations, including attempts to bypass security, introduce
          malicious code, or engage in unauthorised data extraction. Correspondence submitted through the contact form should
          remain courteous and relevant to the publication’s research scope.
        </p>

        <h2>6. Updates</h2>
        <p>
          The editorial team may update these terms to reflect regulatory changes or editorial policy adjustments. The revision
          date at the top of the page indicates the most recent update.
        </p>

        <h2>7. Contact</h2>
        <p>
          Questions regarding these terms may be addressed to{' '}
          <a href="mailto:research@frenchequestrianreview.com">research@frenchequestrianreview.com</a>.
        </p>
      </div>
    </section>
  </>
);

export default TermsPage;