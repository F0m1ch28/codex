import React from 'react';
import Seo from '../components/Seo';
import styles from './PolicyPage.module.css';

const PrivacyPage = () => (
  <>
    <Seo
      title="Privacy Policy | French Equestrian Clubs Review"
      description="Privacy guidelines for French Equestrian Clubs Review, detailing data handling and storage."
      keywords="privacy policy, French equestrian review"
    />
    <section className={styles.policy}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>Last updated: 15 April 2024</p>

        <h2>1. Data Controller</h2>
        <p>
          French Equestrian Clubs Review acts as the data controller for information collected through this site. Queries regarding
          data management can be directed to <a href="mailto:research@frenchequestrianreview.com">research@frenchequestrianreview.com</a>.
        </p>

        <h2>2. Data Collection</h2>
        <p>
          The site collects limited personal data when users submit the contact form. The information includes name, organisation,
          email address, and message content. This data is used solely to reply to inquiries and is not shared with third parties.
        </p>

        <h2>3. Analytics</h2>
        <p>
          Basic analytics may record aggregated metrics such as page views and device type to evaluate readership trends. The data
          remains anonymised and is used to improve editorial planning and accessibility.
        </p>

        <h2>4. Data Retention</h2>
        <p>
          Contact form submissions are retained for the duration necessary to address the inquiry and for archival reference. Users
          may request deletion by emailing the address above.
        </p>

        <h2>5. Security</h2>
        <p>
          Reasonable technical measures protect stored data, including restricted access and encrypted storage where appropriate.
          Despite these safeguards, no online transmission is entirely risk-free; users accept this inherent limitation.
        </p>

        <h2>6. Rights</h2>
        <p>
          Individuals can request access, correction, or deletion of their personal data. Requests will be processed in accordance
          with applicable data protection regulations.
        </p>

        <h2>7. Updates</h2>
        <p>
          This policy may be updated to reflect legal requirements or editorial practices. The revision date indicates the latest
          version.
        </p>
      </div>
    </section>
  </>
);

export default PrivacyPage;