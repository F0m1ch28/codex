import React from 'react';
import Seo from '../components/Seo';
import styles from './AboutPage.module.css';

const teamMembers = [
  {
    name: 'Élodie Garnier',
    role: 'Editorial Coordinator',
    bio: 'Oversees research planning, fact-checking, and narrative structure. Coordinates archival access and ensures that each feature aligns with the review’s ethical guidelines.',
    portrait: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=500&q=80',
    alt: 'Editorial coordinator smiling gently.'
  },
  {
    name: 'Thomas Leclerc',
    role: 'Field Research Lead',
    bio: 'Conducts on-site observations, gathers photographic references, and records interviews across rural and urban clubs. Collaborates with local historians and cultural mediators.',
    portrait: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=500&q=80',
    alt: 'Field researcher standing outdoors in a jacket.'
  },
  {
    name: 'Nadia Rahmani',
    role: 'Data and Documentation Analyst',
    bio: 'Maintains the interview archive, cross-references regulatory frameworks, and prepares data visualisations summarising regional trends within French equestrian networks.',
    portrait: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=500&q=80',
    alt: 'Analyst seated with a laptop and notes.'
  }
];

const AboutPage = () => {
  return (
    <>
      <Seo
        title="About The Review | French Equestrian Clubs Review"
        description="Learn about the editorial standards, methodology, and team behind French Equestrian Clubs Review."
        keywords="About French Equestrian Clubs Review, editorial standards, research methodology"
      />
      <section className={styles.intro}>
        <div className="container">
          <h1>About The Review</h1>
          <p>
            French Equestrian Clubs Review is a cultural and analytical publication examining how equestrian clubs across
            France sustain heritage, pedagogy, and community engagement. The project combines fieldwork with historical research
            to document the relationships between horses, riders, administrators, and surrounding communities.
          </p>
        </div>
      </section>

      <section className={styles.method}>
        <div className="container">
          <div className={styles.methodGrid}>
            <div>
              <h2>Methodology</h2>
              <p>
                The editorial team conducts repeated visits to clubs, observing lessons, governance meetings, veterinary
                consultations, and cultural events. Each observation is triangulated with archival records, regulatory documents,
                and expert commentary. Interviews are recorded, transcribed, and reviewed with contributors to ensure accuracy.
              </p>
              <p>
                Analysis prioritises clarity and balance. Articles acknowledge historic lineages while documenting contemporary
                adaptations in management, pedagogy, and welfare. Photographs, when included, serve as contextual references and
                respect privacy agreements established with clubs.
              </p>
            </div>
            <div className={styles.approachCard}>
              <h3>Editorial Principles</h3>
              <ul>
                <li>Neutral, third-person narrative free from marketing language.</li>
                <li>Verification through multiple sources, including archival material and expert review.</li>
                <li>Respect for equine welfare and human dignity in all reporting contexts.</li>
                <li>Transparency about methodology, including site visits and interview processes.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2>Editorial Team</h2>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <div key={member.name} className={styles.memberCard}>
                <div className={styles.memberPortrait}>
                  <img src={member.portrait} alt={member.alt} />
                </div>
                <div className={styles.memberInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <h2>Project Milestones</h2>
          <div className={styles.timeline}>
            <div className={styles.timelineItem}>
              <div className={styles.timelineDot} aria-hidden="true" />
              <div>
                <h3>2021 – Initial Field Surveys</h3>
                <p>
                  Pilot visits to Normandy and Île-de-France established the need for a neutral platform documenting how clubs
                  combine heritage with contemporary governance.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelineDot} aria-hidden="true" />
              <div>
                <h3>2022 – Archival Collaborations</h3>
                <p>
                  Partnerships with municipal archives in Saumur, Saint-Lô, and Paris added historical depth to ongoing features
                  and interviews.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelineDot} aria-hidden="true" />
              <div>
                <h3>2023 – Expanded Interview Series</h3>
                <p>
                  Conversations with veterinarians, cultural mediators, and instructors broadened coverage to include welfare,
                  outreach, and educational innovation.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelineDot} aria-hidden="true" />
              <div>
                <h3>2024 – National Network Mapping</h3>
                <p>
                  Data visualisations charting club governance models and regional specialisations enhanced comparative analysis
                  across the French equestrian landscape.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;