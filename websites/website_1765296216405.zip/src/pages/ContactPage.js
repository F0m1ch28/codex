import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    organisation: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [formStatus, setFormStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please provide a name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide an email address.';
    } else if (!/^[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.message.trim()) newErrors.message = 'Please include a message.';
    return newErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);

    if (Object.keys(validation).length === 0) {
      setFormStatus(
        'Thank you for your message. The editorial coordination team will review the request during the next research planning session.'
      );
      setFormData({ name: '', organisation: '', email: '', message: '' });
    }
  };

  return (
    <>
      <Seo
        title="Contact & Research Inquiries | French Equestrian Clubs Review"
        description="Contact French Equestrian Clubs Review for research inquiries, collaboration proposals, and archival information."
        keywords="contact French equestrian review, research inquiries, equestrian documentation"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact &amp; Research Inquiries</h1>
          <p>
            Correspondence regarding research collaborations, archival materials, or interview proposals may be directed to the
            editorial team using the form below or via email.
          </p>
          <div className={styles.contactCard}>
            <h2>Editorial Contact</h2>
            <p>
              For correspondence: French Equestrian Clubs Review, Normandy Region, France<br />
              <a href="mailto:research@frenchequestrianreview.com">research@frenchequestrianreview.com</a>
            </p>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <div className={styles.formWrapper}>
            <h2>Send a Message</h2>
            <p>Fields marked with an asterisk are required to ensure an informed response.</p>
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.fieldGroup}>
                <label htmlFor="name">
                  Name <span aria-hidden="true">*</span>
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className="error">{errors.name}</span>}
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="organisation">Organisation</label>
                <input
                  id="organisation"
                  name="organisation"
                  type="text"
                  value={formData.organisation}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="email">
                  Email <span aria-hidden="true">*</span>
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className="error">{errors.email}</span>}
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="message">
                  Message <span aria-hidden="true">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className="error">{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submitButton}>
                Submit Message
              </button>
              {formStatus && <div className="success-message">{formStatus}</div>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;