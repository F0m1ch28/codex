import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { articles } from '../data/articlesData';
import styles from './ArticlesPage.module.css';

const ArticlesPage = () => {
  const [selectedTheme, setSelectedTheme] = useState('all');

  const themes = useMemo(() => {
    const allThemes = new Set(articles.map((article) => article.theme));
    return ['all', ...Array.from(allThemes)];
  }, []);

  const filteredArticles = useMemo(() => {
    if (selectedTheme === 'all') return articles;
    return articles.filter((article) => article.theme === selectedTheme);
  }, [selectedTheme]);

  return (
    <>
      <Seo
        title="Articles | French Equestrian Clubs Review"
        description="In-depth analyses covering French dressage, eventing, urban riding schools, and cultural outreach across equestrian clubs."
        keywords="French equestrian articles, dressage analysis, eventing culture, urban riding schools"
      />
      <section className={styles.banner}>
        <div className="container">
          <h1>Articles</h1>
          <p>
            Analytical features examining regional practices, training methodologies, veterinary collaboration, and the cultural
            heritage of French equestrian clubs.
          </p>
          <div className={styles.filterBar} role="toolbar" aria-label="Article filters">
            <label htmlFor="theme-select">Filter by theme:</label>
            <select
              id="theme-select"
              value={selectedTheme}
              onChange={(event) => setSelectedTheme(event.target.value)}
            >
              {themes.map((theme) => (
                <option key={theme} value={theme}>
                  {theme === 'all' ? 'All themes' : theme}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <section className={styles.listSection}>
        <div className="container">
          <div className={styles.grid}>
            {filteredArticles.map((article) => (
              <article key={article.slug} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={article.coverImage} alt={article.imageAlt} />
                </div>
                <div className={styles.body}>
                  <span className={styles.tag}>{article.theme}</span>
                  <h2>{article.title}</h2>
                  <p>{article.summary}</p>
                  <div className={styles.meta}>
                    <span>{article.region}</span>
                    <span>{article.readingTime}</span>
                    <span>{new Date(article.publishedOn).toLocaleDateString('en-GB', { dateStyle: 'medium' })}</span>
                  </div>
                  <Link to={`/articles/${article.slug}`} className={styles.link}>
                    Read Analysis
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default ArticlesPage;