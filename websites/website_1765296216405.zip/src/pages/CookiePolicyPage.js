import React from 'react';
import Seo from '../components/Seo';
import styles from './PolicyPage.module.css';

const CookiePolicyPage = () => (
  <>
    <Seo
      title="Cookie Policy | French Equestrian Clubs Review"
      description="Cookie usage policy for French Equestrian Clubs Review."
      keywords="cookie policy, French equestrian review"
    />
    <section className={styles.policy}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Last updated: 15 April 2024</p>

        <h2>1. Overview</h2>
        <p>
          Cookies are small text files stored on a device to support functionality and analytics. French Equestrian Clubs Review
          uses minimal cookies to understand readership patterns and maintain site performance.
        </p>

        <h2>2. Types of Cookies</h2>
        <ul>
          <li>
            <strong>Essential cookies:</strong> Ensure basic site operations such as navigation and accessibility preferences.
          </li>
          <li>
            <strong>Analytics cookies:</strong> Collect aggregated data about page visits, device type, and navigation paths to
            inform editorial planning.
          </li>
        </ul>

        <h2>3. Consent</h2>
        <p>
          Visitors are informed about analytics cookies via the on-site banner. Users can accept or decline. A declined choice
          prevents analytics cookies from being stored.
        </p>

        <h2>4. Management</h2>
        <p>
          Users may adjust browser settings to delete or block cookies. Instructions are available through browser support
          resources. Blocking essential cookies may impact site performance.
        </p>

        <h2>5. Contact</h2>
        <p>
          Questions about cookie usage may be sent to{' '}
          <a href="mailto:research@frenchequestrianreview.com">research@frenchequestrianreview.com</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;