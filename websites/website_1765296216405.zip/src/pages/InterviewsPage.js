import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { interviews } from '../data/interviewsData';
import styles from './InterviewsPage.module.css';

const InterviewsPage = () => {
  return (
    <>
      <Seo
        title="Interviews | French Equestrian Clubs Review"
        description="Interviews with directors, veterinarians, and cultural coordinators from French equestrian clubs, highlighting pedagogy, welfare, and community work."
        keywords="equestrian interviews, French club directors, veterinary leadership, community engagement"
      />
      <section className={styles.intro}>
        <div className="container">
          <h1>Interviews</h1>
          <p>
            Conversations with professionals shaping equestrian practice in France. Each interview documents pedagogical choices,
            governance structures, community work, and veterinary strategies.
          </p>
        </div>
      </section>

      <section className={styles.list}>
        <div className="container">
          <div className={styles.grid}>
            {interviews.map((interview) => (
              <article key={interview.slug} className={styles.card}>
                <div className={styles.portrait}>
                  <img src={interview.portrait} alt={interview.imageAlt} />
                </div>
                <div className={styles.content}>
                  <h2>{interview.title}</h2>
                  <span className={styles.role}>{interview.role}</span>
                  <p>{interview.summary}</p>
                  <div className={styles.meta}>
                    <span>{interview.specialization}</span>
                    <span>{interview.readingTime}</span>
                    <span>{new Date(interview.publishedOn).toLocaleDateString('en-GB', { dateStyle: 'medium' })}</span>
                  </div>
                  <Link to={`/interviews/${interview.slug}`} className={styles.link}>
                    Read Interview
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default InterviewsPage;