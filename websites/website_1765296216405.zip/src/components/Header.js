import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <div className={styles.logo} aria-label="French Equestrian Clubs Review">
          French Equestrian Clubs Review
        </div>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Primary navigation">
          <NavLink
            to="/"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Home
          </NavLink>
          <NavLink
            to="/articles"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Articles
          </NavLink>
          <NavLink
            to="/interviews"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Interviews
          </NavLink>
          <NavLink
            to="/about"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            About
          </NavLink>
          <NavLink
            to="/contact"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Contact
          </NavLink>
        </nav>
        <div className={styles.actions}>
          <button type="button" className={styles.languageButton} aria-label="Language selector">
            EN
          </button>
          <button
            type="button"
            className={`${styles.menuButton} ${menuOpen ? styles.menuOpen : ''}`}
            onClick={toggleMenu}
            aria-expanded={menuOpen}
            aria-controls="mobile-navigation"
            aria-label="Toggle navigation menu"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
      {menuOpen && <div className={styles.backdrop} onClick={closeMenu} aria-hidden="true" />}
    </header>
  );
};

export default Header;