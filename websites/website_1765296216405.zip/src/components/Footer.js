import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`${styles.section} ${styles.brand}`}>
        <h4>French Equestrian Clubs Review</h4>
        <p>
          Neutral editorial project documenting the heritage, governance, and cultural significance of equestrian clubs
          throughout France.
        </p>
        <p className={styles.contact}>
          For correspondence: French Equestrian Clubs Review, Normandy Region, France<br />
          <a href="mailto:research@frenchequestrianreview.com">research@frenchequestrianreview.com</a>
        </p>
      </div>

      <div className={styles.section}>
        <h5>Navigation</h5>
        <nav className={styles.nav} aria-label="Footer navigation">
          <Link to="/">Home</Link>
          <Link to="/articles">Articles</Link>
          <Link to="/interviews">Interviews</Link>
          <Link to="/about">About The Review</Link>
          <Link to="/contact">Contact &amp; Research Inquiries</Link>
        </nav>
      </div>

      <div className={styles.section}>
        <h5>Policies</h5>
        <nav className={styles.nav} aria-label="Policy navigation">
          <Link to="/terms">Terms of Use</Link>
          <Link to="/privacy">Privacy Policy</Link>
          <Link to="/cookie-policy">Cookie Policy</Link>
        </nav>
      </div>

      <div className={styles.bottom}>
        <span>&copy; {currentYear} French Equestrian Clubs Review. All rights reserved.</span>
      </div>
    </footer>
  );
};

export default Footer;