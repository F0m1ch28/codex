import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'fecReviewCookieConsent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleChoice = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie preference">
      <div className={styles.content}>
        <p>
          French Equestrian Clubs Review uses analytical cookies to understand readership patterns and refine editorial
          planning. Details appear in the{' '}
          <Link to="/cookie-policy" onClick={() => handleChoice('viewed')}>
            Cookie Policy
          </Link>
          .
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleChoice('declined')}>
            Decline
          </button>
          <button type="button" className={styles.primary} onClick={() => handleChoice('accepted')}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;