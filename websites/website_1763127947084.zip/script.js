document.addEventListener('DOMContentLoaded', () => {
    window.scrollTo(0, 0);

    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('.main-nav');
    const scrollBtn = document.getElementById('scroll-to-top');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const contactForm = document.getElementById('contact-form');
    const formFeedback = document.getElementById('form-feedback');
    const STORAGE_KEY = 'innovstart_cookie_consent';

    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', String(!expanded));
            nav.classList.toggle('open');
        });
    }

    document.querySelectorAll('.main-nav a').forEach(link => {
        link.addEventListener('click', () => {
            if (nav.classList.contains('open')) {
                nav.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });

    window.addEventListener('scroll', () => {
        if (window.scrollY > 250) {
            scrollBtn.classList.add('visible');
        } else {
            scrollBtn.classList.remove('visible');
        }
    });

    scrollBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const consent = localStorage.getItem(STORAGE_KEY);
    if (consent === 'accepted') {
        cookieBanner.style.display = 'none';
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(STORAGE_KEY, 'accepted');
            cookieBanner.style.display = 'none';
        });
    }

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', evt => {
            const targetId = anchor.getAttribute('href').substring(1);
            const target = document.getElementById(targetId);
            if (target) {
                evt.preventDefault();
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    if (contactForm) {
        contactForm.addEventListener('submit', evt => {
            evt.preventDefault();
            if (!contactForm.checkValidity()) {
                formFeedback.textContent = 'Merci de vérifier les champs obligatoires.';
                formFeedback.style.color = '#FF5A5F';
                return;
            }

            formFeedback.textContent = 'Merci ! Votre message a bien été envoyé. Nous revenons vers vous très rapidement.';
            formFeedback.style.color = '#7CE7B7';
            contactForm.reset();
        });
    }
});