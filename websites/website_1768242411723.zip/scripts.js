document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");
    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            primaryNav.classList.toggle("open");
        });
    }

    const filterButtons = document.querySelectorAll(".filter-btn");
    const destinationCards = document.querySelectorAll(".destination-card");
    if (filterButtons.length && destinationCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener("click", () => {
                const category = button.dataset.filter;
                filterButtons.forEach(btn => btn.classList.remove("active"));
                button.classList.add("active");
                destinationCards.forEach(card => {
                    const match = category === "all" || card.dataset.category === category;
                    card.style.display = match ? "flex" : "none";
                });
            });
        });
    }

    const storyTrack = document.querySelector(".story-track");
    const storySlides = document.querySelectorAll(".story-slide");
    const storyButtons = document.querySelectorAll(".story-controls button");
    if (storyTrack && storySlides.length && storyButtons.length) {
        let currentIndex = 0;
        const updateCarousel = () => {
            storyTrack.style.transform = `translateX(-${currentIndex * 100}%)`;
        };
        storyButtons.forEach(btn => {
            btn.addEventListener("click", () => {
                const direction = btn.dataset.direction;
                if (direction === "next") {
                    currentIndex = (currentIndex + 1) % storySlides.length;
                } else {
                    currentIndex = (currentIndex - 1 + storySlides.length) % storySlides.length;
                }
                updateCarousel();
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-btn");
    if (cookieBanner && cookieButtons.length) {
        const storedChoice = localStorage.getItem("scapholctvCookieChoice");
        if (storedChoice) {
            cookieBanner.classList.add("hidden");
        }
        cookieButtons.forEach(button => {
            button.addEventListener("click", () => {
                const choice = button.dataset.choice;
                const link = button.dataset.link;
                if (choice) {
                    localStorage.setItem("scapholctvCookieChoice", choice);
                }
                cookieBanner.classList.add("hidden");
                if (link) {
                    window.open(link, "_blank", "noopener");
                }
            });
        });
    }
});