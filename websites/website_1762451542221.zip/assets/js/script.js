document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-navigation');
    const scrollTopBtn = document.querySelector('.scroll-to-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAcceptBtn = document.querySelector('.accept-cookies');
    const contactForm = document.getElementById('contact-form');
    const currentYearEl = document.getElementById('current-year');
    const header = document.querySelector('.site-header');

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            primaryNav.classList.toggle('open');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                primaryNav.classList.remove('open');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    const handleScroll = () => {
        if (window.scrollY > 320) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }

        if (header) {
            if (window.scrollY > 10) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    };

    window.addEventListener('scroll', handleScroll);

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAcceptBtn) {
        const cookieConsent = localStorage.getItem('eh_cookie_consent');
        if (!cookieConsent) {
            cookieBanner.classList.add('show');
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem('eh_cookie_consent', 'accepted');
            cookieBanner.classList.remove('show');
        });
    }

    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();

            const fields = contactForm.querySelectorAll('.form-group');
            let isValid = true;

            fields.forEach(field => {
                const input = field.querySelector('input, textarea');
                const error = field.querySelector('.form-error');
                if (input && !input.checkValidity()) {
                    isValid = false;
                    if (error) {
                        error.textContent = 'Please fill out this field.';
                    }
                } else if (error) {
                    error.textContent = '';
                }
            });

            if (isValid) {
                const successMessage = contactForm.querySelector('.form-success');
                if (successMessage) {
                    successMessage.textContent = 'Thank you for reaching out. We will respond within two business days.';
                }
                contactForm.reset();
            }
        });

        contactForm.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('input', () => {
                const error = input.closest('.form-group').querySelector('.form-error');
                if (error) {
                    error.textContent = '';
                }
            });
        });
    }

    handleScroll();
});