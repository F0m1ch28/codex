document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.primary-navigation');
    const navLinks = document.querySelectorAll('.primary-navigation a');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const cookieStorageKey = 'tcdCookieConsent';

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navMenu.classList.toggle('open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('open')) {
                    navMenu.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (scrollTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollTopBtn.classList.add('visible');
            } else {
                scrollTopBtn.classList.remove('visible');
            }
        });

        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    if (cookieBanner) {
        if (localStorage.getItem(cookieStorageKey) === 'accepted') {
            cookieBanner.classList.remove('show');
        } else {
            cookieBanner.classList.add('show');
        }
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(cookieStorageKey, 'accepted');
            cookieBanner.classList.remove('show');
        });
    }

    const contactForms = document.querySelectorAll('form[data-form-type="contact"]');
    contactForms.forEach(form => {
        const successMessage = form.querySelector('.form-success');
        form.addEventListener('submit', event => {
            event.preventDefault();
            if (successMessage) {
                successMessage.textContent = 'Thank you. Our team will reach out within one business day.';
                successMessage.classList.add('visible');
            }
            form.reset();
        });
    });

    const yearSpan = document.getElementById('currentYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});