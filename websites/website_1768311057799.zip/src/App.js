import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import BreedsPage from './pages/About';
import ArticlesPage from './pages/Services';
import ArticleDetailPage from './pages/ArticleDetail';
import GalleryPage from './pages/Gallery';
import ContactPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsPage from './pages/TermsOfService';
import PrivacyPage, { CookiePolicyPage } from './pages/PrivacyPolicy';
import styles from './App.module.css';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className={styles.appWrapper}>
        <Header />
        <main className={styles.mainContent} id="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/breeds" element={<BreedsPage />} />
            <Route path="/articles" element={<ArticlesPage />} />
            <Route path="/articles/:slug" element={<ArticleDetailPage />} />
            <Route path="/gallery" element={<GalleryPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/thank-you" element={<ThankYouPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
            <Route path="*" element={<HomePage />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </Router>
  );
}

export default App;