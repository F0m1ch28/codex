import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import articles from '../data/articles';
import styles from './ArticleDetail.module.css';

const ArticleDetailPage = () => {
  const { slug } = useParams();

  const article = useMemo(() => {
    return articles.find((item) => item.slug === slug);
  }, [slug]);

  if (!article) {
    return (
      <section className={styles.wrapper}>
        <Helmet>
          <title>Статья не найдена | Мир Кошек</title>
          <meta name="robots" content="noindex" />
        </Helmet>
        <div className={styles.notFound}>
          <h1 className={styles.title}>Упс! Статья не найдена.</h1>
          <p className={styles.text}>Возможно, материал был перемещён или временно недоступен.</p>
          <Link to="/articles" className={styles.linkBack}>Вернуться к статьям</Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{article.title} | Мир Кошек</title>
        <meta name="description" content={article.excerpt} />
        <meta name="keywords" content={"кошки, ${article.category.toLowerCase()}, ${article.slug.replace(/-/g, ' ')}"} />
      </Helmet>
      <article className={styles.wrapper}>
        <header className={styles.header}>
          <p className={styles.category}>{article.category}</p>
          <h1 className={styles.title}>{article.title}</h1>
          <p className={styles.excerpt}>{article.excerpt}</p>
        </header>
        <div className={styles.imageWrapper}>
          <img src={article.image} alt={article.title} className={styles.image} />
        </div>
        <div className={styles.content}>
          {article.content.split('

').map((paragraph) => (
            <p key={paragraph.slice(0, 16)} className={styles.paragraph}>{paragraph}</p>
          ))}
        </div>
        <footer className={styles.footer}>
          <Link to="/articles" className={styles.linkBack}>← Вернуться к списку статей</Link>
        </footer>
      </article>
    </>
  );
};

export default ArticleDetailPage;