import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const ContactPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const sanitize = (value) => value.replace(/[<>]/g, '');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: sanitize(value) }));
  };

  const validate = () => {
    const newErrors = {};
    if (formData.name.trim().length < 2) {
      newErrors.name = 'Пожалуйста, укажите имя не короче двух символов.';
    }
    if (!emailPattern.test(formData.email.trim())) {
      newErrors.email = 'Введите корректный адрес электронной почты.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Сообщение должно содержать минимум 10 символов.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      navigate('/thank-you');
    }, 600);
  };

  return (
    <>
      <Helmet>
        <title>Контакты — Мир Кошек</title>
        <meta
          name="description"
          content="Свяжитесь с редакцией Мир Кошек: адрес, телефон, электронная почта и форма обратной связи для ваших идей и вопросов."
        />
        <meta
          name="keywords"
          content="контакты Мир Кошек, связаться, форма обратной связи, адрес Мир Кошек"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <h1 className={styles.title}>Свяжитесь с нами</h1>
          <p className={styles.subtitle}>
            Мы открыты к предложениям, вопросам и историям о ваших пушистых друзьях.
          </p>
        </div>
      </section>

      <section className={styles.contentSection}>
        <div className={styles.info}>
          <h2 className={styles.infoTitle}>Контактные данные</h2>
          <ul className={styles.infoList}>
            <li>
              <span className={styles.infoLabel}>Адрес:</span>
              <span className={styles.infoValue}>г. Москва, ул. Кошачья, д. 15</span>
            </li>
            <li>
              <span className={styles.infoLabel}>Телефон:</span>
              <span className={styles.infoValue}>+7 (495) 123-45-67</span>
            </li>
            <li>
              <span className={styles.infoLabel}>Email:</span>
              <span className={styles.infoValue}>info@cat-world.ru</span>
            </li>
          </ul>
          <p className={styles.highlight}>
            Напишите нам — и мы ответим в течение двух рабочих дней.
          </p>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formGroup}>
            <label htmlFor="name" className={styles.label}>Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              className={"${styles.input} ${errors.name ? styles.inputError : ''}"}
              required
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'error-name' : undefined}
            />
            {errors.name && <span id="error-name" className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="email" className={styles.label}>Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              className={"${styles.input} ${errors.email ? styles.inputError : ''}"}
              required
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'error-email' : undefined}
            />
            {errors.email && <span id="error-email" className={styles.error}>{errors.email}</span>}
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="message" className={styles.label}>Сообщение</label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              className={"${styles.textarea} ${errors.message ? styles.inputError : ''}"}
              rows="5"
              required
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'error-message' : undefined}
            />
            {errors.message && <span id="error-message" className={styles.error}>{errors.message}</span>}
          </div>

          <button type="submit" className={styles.submitButton} disabled={isSubmitting}>
            {isSubmitting ? 'Отправка...' : 'Отправить сообщение'}
          </button>
        </form>
      </section>
    </>
  );
};

export default ContactPage;