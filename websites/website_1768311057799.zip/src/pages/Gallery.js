import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import images from '../data/gallery';
import styles from './Gallery.module.css';

const GalleryPage = () => {
  const [loadedMap, setLoadedMap] = useState({});

  const handleLoad = (index) => {
    setLoadedMap((prev) => ({ ...prev, [index]: true }));
  };

  return (
    <>
      <Helmet>
        <title>Галерея вдохновения | Мир Кошек</title>
        <meta
          name="description"
          content="Подборка вдохновляющих фотографий кошек со всего мира: улыбки, игры, моменты нежности. Галерея от Мир Кошек."
        />
        <meta name="keywords" content="галерея, фото кошек, красивые кошки, вдохновение" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <h1 className={styles.title}>Галерея вдохновения</h1>
          <p className={styles.subtitle}>
            Фотографии, передающие характер, настроение и красоту кошек. Делитесь любимыми кадрами с друзьями.
          </p>
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className={styles.grid}>
          {images.map((item, index) => (
            <figure key={item.src} className={styles.card}>
              <div className={"${styles.imageWrapper} ${loadedMap[index] ? styles.imageLoaded : ''}"}>
                <img
                  src={"${item.src}&w=900&q=80"}
                  alt={item.alt}
                  className={styles.image}
                  onLoad={() => handleLoad(index)}
                />
              </div>
              <figcaption className={styles.caption}>{item.caption}</figcaption>
            </figure>
          ))}
        </div>
      </section>
    </>
  );
};

export default GalleryPage;