import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import articles from '../data/articles';
import styles from './Articles.module.css';

const ArticlesPage = () => {
  const [category, setCategory] = useState('Все');

  const categories = useMemo(() => ['Все', ...new Set(articles.map((article) => article.category))], []);

  const filteredArticles = useMemo(() => {
    if (category === 'Все') return articles;
    return articles.filter((article) => article.category === category);
  }, [category]);

  return (
    <>
      <Helmet>
        <title>Статьи и советы о кошках | Мир Кошек</title>
        <meta
          name="description"
          content="Читать статьи о здоровье, поведении и уходе за кошками. Практичные рекомендации от экспертов портала Мир Кошек."
        />
        <meta
          name="keywords"
          content="советы о кошках, здоровье кошек, уход за котами, воспитание котят, Мир Кошек статьи"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <h1 className={styles.title}>Статьи и советы</h1>
          <p className={styles.subtitle}>
            Экспертные материалы о здоровье, воспитании, питании и эмоциональном комфорте кошек.
          </p>
        </div>
      </section>

      <section className={styles.filterSection}>
        <div className={styles.filterWrapper} role="tablist" aria-label="Фильтр по темам статей">
          {categories.map((item) => (
            <button
              key={item}
              type="button"
              className={"${styles.filterButton} ${category === item ? styles.filterButtonActive : ''}"}
              onClick={() => setCategory(item)}
              role="tab"
              aria-selected={category === item}
            >
              {item}
            </button>
          ))}
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className={styles.grid} role="list">
          {filteredArticles.map((article) => (
            <article key={article.slug} className={styles.card} role="listitem">
              <div className={styles.imageWrapper}>
                <img src={article.image} alt={article.title} className={styles.image} />
              </div>
              <div className={styles.cardBody}>
                <p className={styles.cardCategory}>{article.category}</p>
                <h2 className={styles.cardTitle}>{article.title}</h2>
                <p className={styles.cardText}>{article.excerpt}</p>
                <Link to={"/articles/${article.slug}"} className={styles.cardLink}>Читать статью →</Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default ArticlesPage;