import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const HomePage = () => {
  const [heroLoaded, setHeroLoaded] = useState(false);

  const popularBreeds = [
    {
      name: 'Мейн-кун',
      description: 'Величественный гигант с человеческим характером и роскошной шерстью.',
      image: 'https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Британская короткошёрстная',
      description: 'Спокойная и уравновешенная кошка, идеально подходит для семей.',
      image: 'https://images.unsplash.com/photo-1612257754093-e87d97f5984c?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Сфинкс',
      description: 'Умный и общительный компаньон, обожающий теплоту и внимание.',
      image: 'https://images.unsplash.com/photo-1608848461950-0fe51dfc41cb?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Сибирская',
      description: 'Сильная и ласковая кошка с гипоаллергенной шерстью.',
      image: 'https://images.unsplash.com/photo-1619983081607-686e5d5a45fc?auto=format&fit=crop&w=900&q=80'
    }
  ];

  const facts = [
    'Кошки проводят до 70% жизни во сне, сохраняя энергию для игр и охоты.',
    'Мурлыканье помогает кошкам успокаиваться и даже заживлять микротравмы.',
    'Сердце кошки бьётся в два раза быстрее, чем человеческое — до 140 ударов в минуту.',
    'Усы кошек чрезвычайно чувствительны и помогают оценивать ширину проходов.',
    'Домашние кошки могут развивать словарный запас из более чем 100 "слов" для общения.',
    'Кошки видят лучше людей при слабом освещении благодаря особой структуре глаз.'
  ];

  const tips = [
    {
      title: 'Забота о здоровье',
      description: 'Регулярные визиты к ветеринару, вакцинация и профилактика паразитов помогают продлить жизнь питомца.',
      icon: '🩺'
    },
    {
      title: 'Полезное питание',
      description: 'Подбирайте рацион с учётом возраста, активности и особенностей породы, избегайте избытка лакомств.',
      icon: '🥣'
    },
    {
      title: 'Игры и развитие',
      description: 'Ежедневные игры поддерживают физическую форму и предотвращают скуку, укрепляя связь с хозяином.',
      icon: '🎲'
    },
    {
      title: 'Интеллектуальные игрушки',
      description: 'Пазлы и интерактивные кормушки развивают мышление и помогают контролировать вес.',
      icon: '🧠'
    }
  ];

  const testimonials = [
    {
      name: 'Екатерина, Санкт-Петербург',
      quote: 'Благодаря материалам Мир Кошек мы нашли идеальную породу для нашей семьи и научились грамотно заботиться о питомце.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80'
    },
    {
      name: 'Алексей, Москва',
      quote: 'Советы по здоровью и питанию помогли привести кота в форму. Очень ценю структурированность и заботу о деталях.',
      image: 'https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?auto=format&fit=crop&w=300&q=80'
    }
  ];

  const authors = [
    {
      name: 'Мария Иванова',
      role: 'Фелинолог и редактор',
      description: 'Авторитетный эксперт по породам и поведению, исследует новые подходы к воспитанию котят.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Дмитрий Петров',
      role: 'Ветеринарный врач',
      description: 'Специализируется на профилактике заболеваний, делится практическими советами без сложных терминов.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=401&q=80'
    },
    {
      name: 'Анна Соколова',
      role: 'Фотограф и куратор галереи',
      description: 'Создаёт вдохновляющие визуальные истории о дружбе человека и кошки.',
      image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Мир Кошек — портал о котах, породах и заботе</title>
        <meta
          name="description"
          content="Мир Кошек — современный портал о котах: популярные породы, интересные факты, советы по уходу, истории авторов и вдохновляющие фотографии."
        />
        <meta
          name="keywords"
          content="кошки, породы кошек, уход за кошками, советы по кошкам, факты о кошках, Мир Кошек"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>#живемскероскошно</p>
          <h1 className={styles.heroTitle}>Добро пожаловать в мир кошек!</h1>
          <p className={styles.heroSubtitle}>
            Мы собрали лучшие советы, обзоры пород и вдохновение для тех, кто хочет сделать жизнь своего питомца счастливой.
          </p>
          <div className={styles.heroActions}>
            <Link to="/breeds" className={styles.primaryButton}>
              Исследовать породы
            </Link>
            <Link to="/articles" className={styles.secondaryButton}>
              Читать статьи
            </Link>
          </div>
        </div>
        <div className={"${styles.heroImageWrapper} ${heroLoaded ? styles.heroImageLoaded : ''}"}>
          <img
            src="https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop&w=1100&q=80"
            alt="Ласковый рыжий кот, лежащий на подушке"
            className={styles.heroImage}
            onLoad={() => setHeroLoaded(true)}
          />
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Популярные породы</h2>
          <p className={styles.sectionSubtitle}>Выберите питомца, который идеально впишется в ваш образ жизни.</p>
        </div>
        <div className={styles.cardGrid}>
          {popularBreeds.map((breed) => (
            <article key={breed.name} className={styles.card} aria-label={"Порода ${breed.name}"}>
              <div className={styles.cardImageWrapper}>
                <img src={breed.image} alt={breed.name} className={styles.cardImage} />
              </div>
              <div className={styles.cardBody}>
                <h3 className={styles.cardTitle}>{breed.name}</h3>
                <p className={styles.cardText}>{breed.description}</p>
                <Link to="/breeds" className={styles.cardLink}>Узнать подробнее →</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={"${styles.section} ${styles.sectionAlt}"}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Интересные факты о кошках</h2>
          <p className={styles.sectionSubtitle}>Даже опытные владельцы узнают что-то новое.</p>
        </div>
        <ul className={styles.factList}>
          {facts.map((fact, index) => (
            <li key={fact} className={styles.factItem}>
              <span className={styles.factNumber}>0{index + 1}</span>
              <p className={styles.factText}>{fact}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Полезные советы</h2>
          <p className={styles.sectionSubtitle}>Рекомендации от экспертов, которые можно применять уже сегодня.</p>
        </div>
        <div className={styles.tipGrid}>
          {tips.map((tip) => (
            <article key={tip.title} className={styles.tipCard}>
              <span className={styles.tipIcon} aria-hidden="true">{tip.icon}</span>
              <h3 className={styles.tipTitle}>{tip.title}</h3>
              <p className={styles.tipText}>{tip.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={"${styles.section} ${styles.sectionAlt}"}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Отзывы читателей</h2>
          <p className={styles.sectionSubtitle}>Истории тех, кто уже сделал жизнь своего питомца ярче.</p>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial) => (
            <figure key={testimonial.name} className={styles.testimonial}>
              <img src={testimonial.image} alt={testimonial.name} className={styles.testimonialImage} />
              <blockquote className={styles.testimonialQuote}>“{testimonial.quote}”</blockquote>
              <figcaption className={styles.testimonialName}>{testimonial.name}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>О проекте и авторах</h2>
          <p className={styles.sectionSubtitle}>Мы объединяем экспертов, чтобы делиться знаниями и вдохновением.</p>
        </div>
        <div className={styles.authorGrid}>
          {authors.map((author) => (
            <article key={author.name} className={styles.authorCard}>
              <img src={author.image} alt={author.name} className={styles.authorImage} />
              <div>
                <h3 className={styles.authorName}>{author.name}</h3>
                <p className={styles.authorRole}>{author.role}</p>
                <p className={styles.authorText}>{author.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default HomePage;