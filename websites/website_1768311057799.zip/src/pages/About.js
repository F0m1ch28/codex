import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import breeds from '../data/breeds';
import styles from './Breeds.module.css';

const BreedsPage = () => {
  const [search, setSearch] = useState('');
  const [sizeFilter, setSizeFilter] = useState('all');

  const filteredBreeds = useMemo(() => {
    return breeds.filter((breed) => {
      const matchesSearch = breed.name.toLowerCase().includes(search.toLowerCase());
      const matchesSize = sizeFilter === 'all' || breed.size === sizeFilter;
      return matchesSearch && matchesSize;
    });
  }, [search, sizeFilter]);

  return (
    <>
      <Helmet>
        <title>Породы кошек — каталог и характеристики | Мир Кошек</title>
        <meta
          name="description"
          content="Изучите каталог популярных и редких пород кошек: происхождение, характер, уход, уникальные особенности. Удобный поиск и фильтрация."
        />
        <meta
          name="keywords"
          content="породы кошек, каталог пород, характер кошек, уход за породами, особенности породы"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <h1 className={styles.title}>Каталог пород</h1>
          <p className={styles.subtitle}>
            Сравнивайте характер, размеры и особенности ухода, чтобы выбрать идеального пушистого друга.
          </p>
        </div>
      </section>

      <section className={styles.controls}>
        <label className={styles.control} htmlFor="breed-search">
          <span className={styles.controlLabel}>Поиск по названию</span>
          <input
            id="breed-search"
            type="search"
            placeholder="Например, Невская маскарадная"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            className={styles.input}
          />
        </label>
        <label className={styles.control} htmlFor="size-filter">
          <span className={styles.controlLabel}>Размер</span>
          <select
            id="size-filter"
            value={sizeFilter}
            onChange={(event) => setSizeFilter(event.target.value)}
            className={styles.select}
          >
            <option value="all">Все</option>
            <option value="small">Компактные</option>
            <option value="medium">Средние</option>
            <option value="large">Крупные</option>
          </select>
        </label>
      </section>

      <section className={styles.gridSection}>
        {filteredBreeds.length === 0 ? (
          <p className={styles.emptyState}>Породы не найдены. Попробуйте изменить запрос.</p>
        ) : (
          <div className={styles.grid} role="list">
            {filteredBreeds.map((breed) => (
              <article key={breed.slug} className={styles.card} role="listitem">
                <div className={styles.imageWrapper}>
                  <img src={breed.image} alt={"Кошка породы ${breed.name}"} className={styles.image} />
                </div>
                <div className={styles.cardBody}>
                  <h2 className={styles.cardTitle}>{breed.name}</h2>
                  <p className={styles.cardText}>{breed.description}</p>
                  <ul className={styles.metaList}>
                    <li>
                      <span className={styles.metaLabel}>Размер:</span>
                      <span className={styles.metaValue}>{breed.sizeLabel}</span>
                    </li>
                    <li>
                      <span className={styles.metaLabel}>Характер:</span>
                      <span className={styles.metaValue}>{breed.temperament}</span>
                    </li>
                    <li>
                      <span className={styles.metaLabel}>Происхождение:</span>
                      <span className={styles.metaValue}>{breed.origin}</span>
                    </li>
                  </ul>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </>
  );
};

export default BreedsPage;