import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYouPage = () => (
  <>
    <Helmet>
      <title>Спасибо за ваше сообщение | Мир Кошек</title>
      <meta
        name="description"
        content="Благодарим за обращение к нам. Команда Мир Кошек свяжется с вами в ближайшее время."
      />
      <meta name="keywords" content="спасибо, обратная связь, Мир Кошек" />
    </Helmet>
    <section className={styles.wrapper}>
      <div className={styles.card}>
        <span className={styles.icon} aria-hidden="true">💛</span>
        <h1 className={styles.title}>Спасибо!</h1>
        <p className={styles.text}>
          Мы получили ваше сообщение и обязательно ответим в течение двух рабочих дней.
        </p>
        <Link to="/" className={styles.button}>Вернуться на главную</Link>
      </div>
    </section>
  </>
);

export default ThankYouPage;