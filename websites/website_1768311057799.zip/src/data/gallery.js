const images = [
  {
    src: 'https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop',
    alt: 'Пушистый котёнок сидит на пледе',
    caption: 'Уютно дома'
  },
  {
    src: 'https://images.unsplash.com/photo-1533749047139-189de3cf06d3?auto=format&fit=crop',
    alt: 'Белый кот с разноцветными глазами',
    caption: 'Волшебный взгляд'
  },
  {
    src: 'https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop',
    alt: 'Котёнок играет с клубком пряжи',
    caption: 'Игры и приключения'
  },
  {
    src: 'https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop',
    alt: 'Кот нежно прижимается к хозяйке',
    caption: 'Сила объятий'
  },
  {
    src: 'https://images.unsplash.com/photo-1509043759401-136742328bb3?auto=format&fit=crop',
    alt: 'Кот выглядывает из окна',
    caption: 'В ожидании весны'
  },
  {
    src: 'https://images.unsplash.com/photo-1444212477490-ca407925329e?auto=format&fit=crop',
    alt: 'Два кота лежат на диване вместе',
    caption: 'Лучшие друзья'
  },
  {
    src: 'https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?auto=format&fit=crop',
    alt: 'Кот смотрит в камеру крупным планом',
    caption: 'Серьёзный взгляд'
  },
  {
    src: 'https://images.unsplash.com/photo-1472491235688-bdc81a63246e?auto=format&fit=crop',
    alt: 'Кот играет с перышком',
    caption: 'Охота за перышком'
  },
  {
    src: 'https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?auto=format&fit=crop',
    alt: 'Сонный кот лёжа на диване',
    caption: 'Мирный сон'
  }
];

export default images;