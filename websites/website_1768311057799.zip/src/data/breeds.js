const breeds = [
  {
    slug: 'maine-coon',
    name: 'Мейн-кун',
    size: 'large',
    sizeLabel: 'Крупный',
    temperament: 'Спокойный, дружелюбный, ориентирован на хозяина',
    origin: 'США',
    description: 'Одна из крупнейших домашних кошек с развитым интеллектом. Любит активные игры и внимание, но сохраняет независимость.',
    image: 'https://images.unsplash.com/photo-1510331168081-1c2f9fb0b8c3?auto=format&fit=crop&w=1000&q=80'
  },
  {
    slug: 'british-shorthair',
    name: 'Британская короткошёрстная',
    size: 'medium',
    sizeLabel: 'Средний',
    temperament: 'Уравновешенный, нежный, терпеливый',
    origin: 'Великобритания',
    description: 'Порода с плюшевой шерстью и спокойным характером. Легко адаптируется к ритму семьи и ценит личное пространство.',
    image: 'https://images.unsplash.com/photo-1619983081607-686e5d5a45fc?auto=format&fit=crop&w=1000&q=80'
  },
  {
    slug: 'sphynx',
    name: 'Сфинкс',
    size: 'medium',
    sizeLabel: 'Средний',
    temperament: 'Общительный, любознательный, игривый',
    origin: 'Канада',
    description: 'Лысая порода, требующая тепла и бережного ухода за кожей. Очень привязана к человеку, любит совместный отдых.',
    image: 'https://images.unsplash.com/photo-1608848461950-0fe51dfc41cb?auto=format&fit=crop&w=1000&q=80'
  },
  {
    slug: 'sibirskiy',
    name: 'Сибирская кошка',
    size: 'large',
    sizeLabel: 'Крупный',
    temperament: 'Выносливая, ласковая, спокойная',
    origin: 'Россия',
    description: 'Северная порода с густой шерстью, хорошо переносит холода. Славится гипоаллергенностью и дружелюбием.',
    image: 'https://images.unsplash.com/photo-1619983081607-686e5d5a45fc?auto=format&fit=crop&w=1001&q=80'
  },
  {
    slug: 'russian-blue',
    name: 'Русская голубая',
    size: 'small',
    sizeLabel: 'Компактный',
    temperament: 'Нежная, интеллигентная, скромная',
    origin: 'Россия',
    description: 'Элегантная кошка с серебристой шерстью и зелёными глазами. Отличается мягким голосом и аккуратными манерами.',
    image: 'https://images.unsplash.com/photo-1501820488136-72669149e0d4?auto=format&fit=crop&w=1000&q=80'
  },
  {
    slug: 'bengal',
    name: 'Бенгальская кошка',
    size: 'medium',
    sizeLabel: 'Средний',
    temperament: 'Энергичная, смелая, общительная',
    origin: 'США',
    description: 'Порода с леопардовым окрасом и активным нравом. Любит лазать, играть и участвовать во всех делах семьи.',
    image: 'https://images.unsplash.com/photo-1552410260-0fd9bcec06f6?auto=format&fit=crop&w=1000&q=80'
  }
];

export default breeds;