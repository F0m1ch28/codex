import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'cat_world_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookies">
      <p className={styles.text}>
        Мы используем cookies, чтобы сделать сайт удобнее и безопаснее. Продолжая пользоваться сайтом, вы соглашаетесь с нашей{' '}
        <Link to="/cookie-policy" className={styles.link}>политикой использования cookies</Link>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Понятно
      </button>
    </aside>
  );
};

export default CookieBanner;