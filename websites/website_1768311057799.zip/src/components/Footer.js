import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.container}>
        <div className={styles.column}>
          <h2 id="footer-heading" className={styles.title}>Мир Кошек</h2>
          <p className={styles.text}>
            Информационный портал о гармоничной жизни с котами: породы, уход, здоровье и вдохновение каждый день.
          </p>
          <div className={styles.socials} aria-label="Социальные сети">
            <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram Мир Кошек">IG</a>
            <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube Мир Кошек">YT</a>
            <a href="https://www.telegram.org" target="_blank" rel="noopener noreferrer" aria-label="Telegram Мир Кошек">TG</a>
          </div>
        </div>
        <div className={styles.column}>
          <h3 className={styles.subtitle}>Навигация</h3>
          <ul className={styles.list}>
            <li><Link to="/" className={styles.link}>Главная</Link></li>
            <li><Link to="/breeds" className={styles.link}>Породы</Link></li>
            <li><Link to="/articles" className={styles.link}>Статьи</Link></li>
            <li><Link to="/gallery" className={styles.link}>Галерея</Link></li>
            <li><Link to="/terms" className={styles.link}>Условия использования</Link></li>
            <li><Link to="/privacy" className={styles.link}>Политика конфиденциальности</Link></li>
            <li><Link to="/cookie-policy" className={styles.link}>Политика использования cookies</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.subtitle}>Контакты</h3>
          <ul className={styles.list}>
            <li className={styles.text}>г. Москва, ул. Кошачья, д. 15</li>
            <li><Link to="/contact" className={styles.link}>+7 (495) 123-45-67</Link></li>
            <li><Link to="/contact" className={styles.link}>info@cat-world.ru</Link></li>
            <li><Link to="/contact" className={styles.link}>Форма обратной связи</Link></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <span className={styles.bottomText}>© {year} Мир Кошек. Все права защищены.</span>
      </div>
    </footer>
  );
};

export default Footer;