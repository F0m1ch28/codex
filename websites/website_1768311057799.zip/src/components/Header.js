import React, { useState, useEffect } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={"${styles.header} ${isScrolled ? styles.headerScrolled : ''}"} aria-label="Основная навигация">
      <div className={styles.container}>
        <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="На главную">
          <span className={styles.logoIcon} aria-hidden="true">🐾</span>
          <span className={styles.logoText}>Мир Кошек</span>
        </Link>
        <button
          type="button"
          className={styles.menuButton}
          aria-label="Переключатель меню"
          aria-expanded={isMenuOpen}
          onClick={toggleMenu}
        >
          <span className={styles.menuIcon} />
        </button>
        <nav className={"${styles.nav} ${isMenuOpen ? styles.navOpen : ''}"}>
          <NavLink to="/" className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"} onClick={closeMenu}>
            Главная
          </NavLink>
          <NavLink to="/breeds" className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"} onClick={closeMenu}>
            Породы
          </NavLink>
          <NavLink to="/articles" className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"} onClick={closeMenu}>
            Статьи
          </NavLink>
          <NavLink to="/gallery" className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"} onClick={closeMenu}>
            Галерея
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"} onClick={closeMenu}>
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;