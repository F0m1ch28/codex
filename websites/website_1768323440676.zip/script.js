document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            primaryNav.classList.toggle('open');
        });
    }

    const banner = document.querySelector('.cookie-banner');
    const consentButtons = document.querySelectorAll('.cookie-button');

    if (banner) {
        const storedConsent = localStorage.getItem('friaryCookieConsent');
        if (!storedConsent) {
            banner.classList.add('show');
        }

        consentButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const consentValue = button.dataset.consent || 'view';
                localStorage.setItem('friaryCookieConsent', consentValue);
                banner.classList.remove('show');
                const targetLink = button.getAttribute('href');
                if (targetLink) {
                    window.location.href = targetLink;
                }
            });
        });
    }

    const postsContainer = document.querySelector('.posts-list');
    if (postsContainer) {
        const searchInput = document.querySelector('[data-search]');
        const filterButtons = document.querySelectorAll('.filter-button');
        const paginationContainer = document.querySelector('.pagination-controls');
        const postCards = Array.from(postsContainer.querySelectorAll('.post-card'));
        const postsPerPage = 6;

        let activeCategory = 'all';
        let searchQuery = '';
        let currentPage = 1;

        const renderPosts = () => {
            const filtered = postCards.filter(card => {
                const matchesCategory =
                    activeCategory === 'all' || card.dataset.category === activeCategory;
                const textMatch = card.textContent.toLowerCase().includes(searchQuery);
                return matchesCategory && textMatch;
            });

            const totalPages = Math.max(1, Math.ceil(filtered.length / postsPerPage));
            if (currentPage > totalPages) currentPage = totalPages;

            postCards.forEach(card => card.classList.add('is-hidden'));
            filtered.forEach((card, index) => {
                const pageIndex = Math.floor(index / postsPerPage) + 1;
                if (pageIndex === currentPage) {
                    card.classList.remove('is-hidden');
                }
            });

            if (paginationContainer) {
                paginationContainer.innerHTML = '';
                for (let page = 1; page <= totalPages; page += 1) {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.className = 'pagination-button' + (page === currentPage ? ' active' : '');
                    button.textContent = page;
                    button.addEventListener('click', () => {
                        currentPage = page;
                        renderPosts();
                        postsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    });
                    paginationContainer.appendChild(button);
                }
            }
        };

        if (searchInput) {
            searchInput.addEventListener('input', event => {
                searchQuery = event.target.value.trim().toLowerCase();
                currentPage = 1;
                renderPosts();
            });
        }

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                activeCategory = button.dataset.filter;
                currentPage = 1;
                renderPosts();
            });
        });

        renderPosts();
    }
});