document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.mobile-toggle');
  const mainNav = document.querySelector('.main-nav');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth <= 820) {
          mainNav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const storedChoice = localStorage.getItem('puenteiaCookieChoice');
    if (!storedChoice) {
      setTimeout(() => {
        cookieBanner.classList.add('show');
      }, 600);
    }
    cookieBanner.querySelectorAll('button[data-cookie-choice]').forEach(button => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-cookie-choice');
        localStorage.setItem('puenteiaCookieChoice', choice);
        cookieBanner.classList.remove('show');
      });
    });
  }

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('.fade-section').forEach(section => observer.observe(section));

  const forms = document.querySelectorAll('form[data-form="contact"]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      showToast('Mensaje registrado. Redirigiendo...');
      setTimeout(() => {
        window.location.href = form.getAttribute('action');
      }, 1500);
    });
  });

  function showToast(message) {
    let toast = document.getElementById('form-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'form-toast';
      toast.className = 'form-toast';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'polite');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('visible');
    setTimeout(() => {
      toast.classList.remove('visible');
    }, 2000);
  }
});