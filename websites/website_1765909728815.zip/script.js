document.addEventListener('DOMContentLoaded', () => {
  const currentYear = new Date().getFullYear();
  const yearTargets = document.querySelectorAll('#renewexa-year');
  yearTargets.forEach((el) => (el.textContent = currentYear));

  const navToggle = document.querySelector('.renewexa-nav-toggle');
  const navMenu = document.querySelector('.renewexa-navigation');
  const navLinks = document.querySelectorAll('.renewexa-navigation a');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('renewexa-nav-open');
    });

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        navMenu.classList.remove('renewexa-nav-open');
      });
    });
  }

  const bodyPage = document.body.getAttribute('data-page');
  if (bodyPage) {
    navLinks.forEach((link) => {
      if (link.dataset.page === bodyPage) {
        link.classList.add('renewexa-active-link');
      }
    });
  }

  document.querySelectorAll('form[data-js="redirect"]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      window.location.href = 'thanks.html';
    });
  });
});