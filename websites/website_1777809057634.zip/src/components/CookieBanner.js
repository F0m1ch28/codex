import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const storageKey = 'gr_cookie_consent';
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(storageKey);
    setVisible(!consent);
  }, []);

  const handleAccept = () => {
    localStorage.setItem(storageKey, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookieBanner" role="dialog" aria-live="polite">
      <div className="cookieContent">
        <p>
          Мы используем файлы cookies для улучшения работы сайта, аналитики и персонализации
          контента. Продолжая пользоваться сайтом, вы подтверждаете согласие с{' '}
          <a href="/cookie-policy">Политикой cookies</a>.
        </p>
        <button type="button" className="btn btnPrimary" onClick={handleAccept} aria-label="Принять использование cookies">
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;