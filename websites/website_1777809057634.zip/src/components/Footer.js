import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container footerGrid">
        <div className="footerCol">
          <div className="footerLogo">
            <span className="logoBadge">GR</span>
            <span className="logoText">Gambling Review</span>
          </div>
          <p>
            Независимый обзорный проект для ответственного выбора онлайн-казино. Мы проверяем
            лицензии, условия бонусов и скорость выплат, чтобы вы могли играть осознанно.
          </p>
          <p className="footerNote">
            Внимание: азартные игры могут вызвать зависимость. Играйте ответственно и соблюдайте
            законодательство вашей страны.
          </p>
        </div>
        <div className="footerCol">
          <h4>Навигация</h4>
          <ul className="footerList">
            <li>
              <NavLink to="/">Главная</NavLink>
            </li>
            <li>
              <NavLink to="/obzory-kazino">Обзоры казино</NavLink>
            </li>
            <li>
              <NavLink to="/sravnenie-uslovij">Сравнение условий</NavLink>
            </li>
            <li>
              <NavLink to="/about">О нас</NavLink>
            </li>
            <li>
              <NavLink to="/services">Услуги</NavLink>
            </li>
            <li>
              <NavLink to="/kontakty">Контакты</NavLink>
            </li>
          </ul>
        </div>
        <div className="footerCol">
          <h4>Юридическая информация</h4>
          <ul className="footerList">
            <li>
              <NavLink to="/terms">Термины и условия</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Политика конфиденциальности</NavLink>
            </li>
            <li>
              <NavLink to="/cookie-policy">Политика Cookies</NavLink>
            </li>
          </ul>
          <div className="footerContact">
            <p>Адрес: ул. Примерная, д. 1</p>
            <p>Телефон: +7 (800) 123-45-67</p>
            <p>Email: info@gamblingreview.com</p>
          </div>
        </div>
      </div>
      <div className="footerBottom">
        <p>© {new Date().getFullYear()} Gambling Review. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;