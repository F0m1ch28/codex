import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className="header">
      <div className="container headerContainer">
        <NavLink to="/" className="logo" aria-label="На главную">
          <span className="logoBadge">GR</span>
          <span className="logoText">Gambling Review</span>
        </NavLink>
        <button
          type="button"
          className={`burger ${menuOpen ? 'active' : ''}`}
          aria-label="Переключить меню"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`nav ${menuOpen ? 'open' : ''}`} aria-label="Основная навигация">
          <NavLink to="/" className={({ isActive }) => `navLink ${isActive ? 'active' : ''}`}>
            Главная
          </NavLink>
          <NavLink
            to="/obzory-kazino"
            className={({ isActive }) => `navLink ${isActive ? 'active' : ''}`}
          >
            Обзоры казино
          </NavLink>
          <NavLink
            to="/sravnenie-uslovij"
            className={({ isActive }) => `navLink ${isActive ? 'active' : ''}`}
          >
            Сравнение условий
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => `navLink ${isActive ? 'active' : ''}`}>
            О нас
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) => `navLink ${isActive ? 'active' : ''}`}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) => `navLink ${isActive ? 'active' : ''}`}
          >
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;