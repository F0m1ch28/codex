import React from 'react';

const StarRating = ({ value }) => {
  const fullStars = Math.floor(value);
  const hasHalfStar = value - fullStars >= 0.5;

  return (
    <div className="starRating" aria-label={`Рейтинг ${value.toFixed(1)} из 5`}>
      {Array.from({ length: 5 }).map((_, index) => {
        const isFilled = index < fullStars;
        const isHalf = index === fullStars && hasHalfStar;
        return (
          <span
            key={index}
            className={`starIcon ${isFilled ? 'filled' : ''} ${isHalf ? 'half' : ''}`}
          >
            ★
          </span>
        );
      })}
      <span className="starValue">{value.toFixed(1)}</span>
    </div>
  );
};

export default StarRating;