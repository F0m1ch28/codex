import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import CasinoReviews from './pages/CasinoReviews';
import CasinoComparison from './pages/CasinoComparison';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import CasinoDetail from './pages/CasinoDetail';
import Contact from './pages/Contact';
import About from './pages/About';
import Services from './pages/Services';

function App() {
  return (
    <div className="app">
      <Header />
      <main className="mainContent">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/obzory-kazino" element={<CasinoReviews />} />
          <Route path="/obzory-kazino/:slug" element={<CasinoDetail />} />
          <Route path="/sravnenie-uslovij" element={<CasinoComparison />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;