import { useEffect } from 'react';

const usePageMeta = (title, description) => {
  useEffect(() => {
    const previousTitle = document.title;
    const previousDescription = document
      .querySelector('meta[name="description"]')
      ?.getAttribute('content');

    if (title) {
      document.title = title;
    }

    let descriptionTag = document.querySelector('meta[name="description"]');
    if (!descriptionTag) {
      descriptionTag = document.createElement('meta');
      descriptionTag.setAttribute('name', 'description');
      document.head.appendChild(descriptionTag);
    }

    if (description) {
      descriptionTag.setAttribute('content', description);
    }

    return () => {
      if (previousTitle) {
        document.title = previousTitle;
      }
      if (previousDescription && descriptionTag) {
        descriptionTag.setAttribute('content', previousDescription);
      }
    };
  }, [title, description]);
};

export default usePageMeta;