import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const CookiePolicy = () => {
  usePageMeta(
    'Политика Cookies — Gambling Review',
    'Политика использования файлов cookies на сайте Gambling Review.'
  );

  return (
    <div className="page legalPage">
      <section className="pageHeader">
        <div className="container narrow">
          <h1>Политика Cookies</h1>
          <p>Последнее обновление: 10 марта 2024 года.</p>
        </div>
      </section>
      <section className="pageSection">
        <div className="container narrow">
          <h2>1. Что такое cookies</h2>
          <p>
            Cookies — небольшие текстовые файлы, которые сохраняются на вашем устройстве, чтобы
            обеспечить корректную работу сайта и анализ посещаемости.
          </p>

          <h2>2. Какие cookies мы используем</h2>
          <p>
            Технические (обязательные), аналитические (анонимная статистика), функциональные
            (запоминают ваши настройки).
          </p>

          <h2>3. Как управлять cookies</h2>
          <p>
            Вы можете изменить настройки браузера, чтобы блокировать или удалять cookies. Учтите, что
            некоторые функции сайта могут работать некорректно.
          </p>

          <h2>4. Сторонние сервисы</h2>
          <p>
            Мы используем инструменты аналитики (например, Google Analytics) для понимания поведения
            пользователей. Эти сервисы также могут использовать свои cookies.
          </p>

          <h2>5. Контакты</h2>
          <p>
            Вопросы по политике cookies направляйте на адрес info@gamblingreview.com с темой
            «Cookies».
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;