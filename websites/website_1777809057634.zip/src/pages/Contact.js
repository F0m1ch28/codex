import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Contact = () => {
  usePageMeta(
    'Контакты — Gambling Review',
    'Свяжитесь с командой Gambling Review: email, телефон и форма обратной связи.'
  );

  const initialState = { name: '', email: '', message: '' };
  const [formValues, setFormValues] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) {
      newErrors.name = 'Введите имя.';
    }
    if (!formValues.email.trim()) {
      newErrors.email = 'Введите email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formValues.email)) {
      newErrors.email = 'Введите корректный email.';
    }
    if (!formValues.message.trim()) {
      newErrors.message = 'Введите сообщение.';
    } else if (formValues.message.trim().length < 20) {
      newErrors.message = 'Сообщение должно содержать не менее 20 символов.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setStatus('Спасибо! Мы свяжемся с вами в течение одного рабочего дня.');
      setFormValues(initialState);
    } else {
      setStatus('');
    }
  };

  return (
    <div className="page">
      <section className="pageHeader">
        <div className="container narrow">
          <h1>Связаться с командой</h1>
          <p>
            У вас есть вопрос по обзорам или хотите предложить сотрудничество? Напишите нам —
            ответим максимально оперативно.
          </p>
        </div>
      </section>
      <section className="pageSection">
        <div className="container contactGrid">
          <div className="contactInfo">
            <h2>Контактные данные</h2>
            <p>Адрес: ул. Примерная, д. 1</p>
            <p>Телефон: +7 (800) 123-45-67</p>
            <p>Email: info@gamblingreview.com</p>
            <p className="infoNote">
              Пожалуйста, не отправляйте документы, содержащие персональные данные, пока мы не
              запросим их в рамках проверки.
            </p>
          </div>
          <form className="contactForm" onSubmit={handleSubmit} noValidate>
            <div className="formGroup">
              <label htmlFor="name">Имя</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formValues.name}
                onChange={(e) => setFormValues({ ...formValues, name: e.target.value })}
                placeholder="Как к вам обращаться?"
                aria-required="true"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className="errorText">{errors.name}</span>}
            </div>
            <div className="formGroup">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formValues.email}
                onChange={(e) => setFormValues({ ...formValues, email: e.target.value })}
                placeholder="example@mail.com"
                aria-required="true"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className="errorText">{errors.email}</span>}
            </div>
            <div className="formGroup">
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formValues.message}
                onChange={(e) => setFormValues({ ...formValues, message: e.target.value })}
                placeholder="Расскажите, что вас интересует"
                aria-required="true"
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className="errorText">{errors.message}</span>}
            </div>
            <button type="submit" className="btn btnPrimary" aria-label="Отправить сообщение">
              Отправить
            </button>
            {status && <p className="successText">{status}</p>}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;