import React from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import StarRating from '../components/StarRating';
import usePageMeta from '../hooks/usePageMeta';

const CasinoReviews = () => {
  usePageMeta(
    'Обзоры казино — Gambling Review',
    'Подробные обзоры онлайн-казино: лицензии, бонусы, платежи и отзывы игроков.'
  );

  return (
    <div className="page">
      <section className="pageHeader">
        <div className="container narrow">
          <h1>Обзоры казино</h1>
          <p>
            Ниже собраны актуальные обзоры казино с указанием бонусов, вейджеров, лимитов вывода и
            реальных отзывов. Мы не даём гарантий выигрыша — наша задача предоставить достоверную
            информацию для ответственного выбора.
          </p>
        </div>
      </section>
      <section className="pageSection">
        <div className="container">
          <div className="casinoList">
            {casinos.map((casino) => (
              <article className="casinoListCard" key={casino.slug}>
                <div className="casinoListLogo">
                  <img src={casino.logo} alt={`Логотип ${casino.name}`} />
                </div>
                <div className="casinoListBody">
                  <div className="casinoListHeader">
                    <h2>{casino.name}</h2>
                    <StarRating value={casino.rating} />
                  </div>
                  <p className="casinoListDesc">{casino.shortDescription}</p>
                  <div className="casinoListMeta">
                    <div>
                      <strong>Бонус:</strong> {casino.bonus}
                    </div>
                    <div>
                      <strong>Вейджер:</strong> {casino.wager}
                    </div>
                    <div>
                      <strong>Срок вывода:</strong> {casino.withdrawal}
                    </div>
                    <div>
                      <strong>Лицензия:</strong> {casino.license}
                    </div>
                  </div>
                  <div className="casinoTags">
                    {casino.features.slice(0, 3).map((feature) => (
                      <span className="tag" key={feature}>
                        {feature}
                      </span>
                    ))}
                  </div>
                  <Link
                    to={`/obzory-kazino/${casino.slug}`}
                    className="btn btnSecondary"
                    aria-label={`Перейти к обзору ${casino.name}`}
                  >
                    Перейти к обзору
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default CasinoReviews;