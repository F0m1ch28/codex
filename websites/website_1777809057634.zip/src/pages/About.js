import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const About = () => {
  usePageMeta(
    'О нас — Gambling Review',
    'Узнайте о команде Gambling Review, которая исследует онлайн-казино и публикует независимые обзоры.'
  );

  const milestones = [
    {
      year: '2017',
      title: 'Старт проекта',
      text: 'Мы объединили журналистов и бывших сотрудников операторов, чтобы создавать честные обзоры.',
    },
    {
      year: '2019',
      title: 'Первые партнерства',
      text: 'Запустили сотрудничество с аффилиатами и получили доступ к закрытым офферам для тестирования.',
    },
    {
      year: '2021',
      title: 'Международная аудитория',
      text: 'Расширили географию на Европу и СНГ, добавили проверки выплат в криптовалютах.',
    },
    {
      year: '2023',
      title: 'Ответственная игра',
      text: 'Запустили образовательный раздел и гайды по контролю банкролла.',
    },
  ];

  const values = [
    {
      title: 'Честность',
      text: 'Не публикуем скрытую рекламу и не обещаем гарантии выигрыша.',
    },
    {
      title: 'Компетентность',
      text: 'Каждый обзор пишет эксперт с опытом работы в гемблинге или платежных сервисах.',
    },
    {
      title: 'Ответственность',
      text: 'Разделяем философию ответственной игры и поддерживаем информирование о рисках.',
    },
    {
      title: 'Актуальность',
      text: 'Проверяем данные каждые 14 дней и отслеживаем обновления бонусов.',
    },
  ];

  return (
    <div className="page">
      <section className="pageHeader">
        <div className="container narrow">
          <h1>О проекте Gambling Review</h1>
          <p>
            Мы — независимая команда аналитиков, журналистов и специалистов по платежам. Наша цель —
            предоставить русскоязычной аудитории проверенную информацию о лицензионных онлайн-казино
            и условиях бонусов без обещаний выиграть.
          </p>
        </div>
      </section>

      <section className="pageSection">
        <div className="container">
          <div className="aboutIntro">
            <img
              src="https://picsum.photos/800/600?random=52"
              alt="Команда Gambling Review на рабочей встрече"
            />
            <div>
              <h2>Мы проверяем, вы выбираете</h2>
              <p>
                Ежемесячно наша команда тестирует десятки площадок. Мы оцениваем лицензии, сроки
                выплат, качество саппорта и условия бонусов. Для каждой площадки создаём чек-лист,
                который затем публикуем в обзоре.
              </p>
              <p>
                Мы не призываем к игре и не стимулируем азарт — наша миссия информировать, чтобы вы
                принимали осознанные решения. Если вы чувствуете, что азарт выходит из-под контроля,
                обратитесь за помощью к специальным организациям.
              </p>
            </div>
          </div>

          <div className="milestones">
            {milestones.map((item) => (
              <div className="milestoneCard" key={item.year}>
                <span className="milestoneYear">{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>

          <div className="valuesGrid">
            {values.map((value) => (
              <div className="valueCard" key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </div>
            ))}
          </div>

          <div className="infoCard">
            <h2>Ответственная игра</h2>
            <p>
              Наши обзоры всегда содержат ссылки на службы поддержки, инструменты самоограничения и
              советы по контролю банкролла. Если вам необходима помощь, обратитесь в службы{' '}
              <a href="https://www.begambleaware.org" target="_blank" rel="noreferrer">
                BeGambleAware
              </a>{' '}
              или{' '}
              <a href="https://www.gamcare.org.uk" target="_blank" rel="noreferrer">
                GamCare
              </a>.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;