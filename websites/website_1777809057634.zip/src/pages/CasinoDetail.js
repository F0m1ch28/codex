import React from 'react';
import { Link, useParams } from 'react-router-dom';
import casinos from '../data/casinos';
import StarRating from '../components/StarRating';
import usePageMeta from '../hooks/usePageMeta';

const CasinoDetail = () => {
  const { slug } = useParams();
  const casino = casinos.find((item) => item.slug === slug);

  usePageMeta(
    casino ? `${casino.name} — обзор казино` : 'Казино не найдено',
    casino
      ? `Обзор ${casino.name}: бонусы, вейджеры, платежи, рейтинг и отзывы игроков.`
      : 'Казино не найдено.'
  );

  if (!casino) {
    return (
      <div className="page">
        <section className="pageHeader">
          <div className="container narrow">
            <h1>Казино не найдено</h1>
            <p>Проверьте корректность ссылки или вернитесь к списку обзоров.</p>
            <Link to="/obzory-kazino" className="btn btnSecondary">
              Вернуться к обзорам
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page">
      <section className="pageHeader">
        <div className="container">
          <div className="detailHeader">
            <div>
              <h1>{casino.name}</h1>
              <StarRating value={casino.rating} />
              <p>{casino.reviewSummary}</p>
            </div>
            <img src={casino.banner} alt={`Баннер ${casino.name}`} className="detailBanner" />
          </div>
        </div>
      </section>

      <section className="pageSection">
        <div className="container">
          <div className="detailGrid">
            <div className="detailCard">
              <h2>Ключевые факты</h2>
              <ul className="detailList">
                <li>
                  <strong>Бонус:</strong> {casino.bonus}
                </li>
                <li>
                  <strong>Бонус-код:</strong> {casino.bonusCode}
                </li>
                <li>
                  <strong>Вейджер:</strong> {casino.wager}
                </li>
                <li>
                  <strong>Минимальный депозит:</strong> {casino.minDeposit}
                </li>
                <li>
                  <strong>Лицензия:</strong> {casino.license}
                </li>
                <li>
                  <strong>Год основания:</strong> {casino.established}
                </li>
              </ul>
            </div>
            <div className="detailCard">
              <h2>Платежи и методы</h2>
              <p>
                <strong>Срок вывода:</strong> {casino.withdrawal}
              </p>
              <p>
                <strong>Методы оплаты:</strong> {casino.paymentMethods.join(', ')}
              </p>
              <p>
                <strong>Доступные валюты:</strong> {casino.currencies.join(', ')}
              </p>
              <p>
                <strong>Поддерживаемые страны:</strong> {casino.countries.join(', ')}
              </p>
            </div>
            <div className="detailCard">
              <h2>Игры и провайдеры</h2>
              <p>
                <strong>Доступные направления:</strong> {casino.games.join(', ')}
              </p>
              <p>
                <strong>Особенности:</strong> {casino.features.join(', ')}
              </p>
            </div>
            <div className="detailCard">
              <h2>Безопасность и ответственность</h2>
              <p>
                <strong>Безопасность:</strong> {casino.security}
              </p>
              <p>
                <strong>Ответственная игра:</strong> {casino.responsibleGaming.join(', ')}
              </p>
              <p>
                <strong>Поддержка:</strong> {casino.support}
              </p>
            </div>
          </div>

          <div className="detailProsCons">
            <div className="detailCard">
              <h2>Преимущества</h2>
              <ul>
                {casino.pros.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className="detailCard">
              <h2>Особенности</h2>
              <ul>
                {casino.cons.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="detailReviews">
            <h2>Отзывы игроков</h2>
            <div className="reviewGrid">
              {casino.reviews.map((review, index) => (
                <div className="reviewCard" key={`${review.author}-${index}`}>
                  <div className="reviewHeader">
                    <strong>{review.author}</strong>
                    <span>{review.date}</span>
                  </div>
                  <StarRating value={review.rating} />
                  <p>{review.text}</p>
                </div>
              ))}
            </div>
            <p className="reviewDisclaimer">
              Мнение игроков субъективно. Gambling Review не гарантирует выигрыш и рекомендует
              придерживаться лимитов, установленных законодательством вашей страны.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CasinoDetail;