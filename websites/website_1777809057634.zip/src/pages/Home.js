import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import StarRating from '../components/StarRating';
import usePageMeta from '../hooks/usePageMeta';

const Home = () => {
  usePageMeta(
    'Топ казино 2024 — Gambling Review',
    'Подробные обзоры онлайн-казино, честный рейтинг бонусов и сравнение условий для осознанной игры.'
  );

  const stats = useMemo(
    () => [
      { label: 'Проверенных казино', value: 68 },
      { label: 'Изученных бонусов', value: 142 },
      { label: 'Читателей ежемесячно', value: 25000 },
    ],
    []
  );

  const [animatedStats, setAnimatedStats] = useState(stats.map(() => 0));

  useEffect(() => {
    const intervalId = setInterval(() => {
      setAnimatedStats((prev) => {
        const updated = prev.map((val, index) => {
          const target = stats[index].value;
          if (val >= target) {
            return target;
          }
          const increment = Math.ceil(target / 35);
          return Math.min(target, val + increment);
        });
        if (updated.every((val, index) => val >= stats[index].value)) {
          clearInterval(intervalId);
        }
        return updated;
      });
    }, 60);
    return () => clearInterval(intervalId);
  }, [stats]);

  const topCasinos = useMemo(
    () => [...casinos].sort((a, b) => b.rating - a.rating).slice(0, 3),
    []
  );
  const tableCasinos = useMemo(
    () => [...casinos].sort((a, b) => b.rating - a.rating).slice(0, 5),
    []
  );
  const latestCasinos = useMemo(() => casinos.slice(0, 4), []);

  const advantages = [
    {
      title: 'Экспертиза команды',
      description: 'Аналитики с опытом работы в лицензированных казино и провайдерах игр.',
    },
    {
      title: 'Прозрачность данных',
      description:
        'Каждый обзор содержит проверенные факты: лицензии, лимиты, сроки выплат и вейджеры.',
    },
    {
      title: 'Актуальность сведений',
      description:
        'Обновляем карточки офферов каждые 14 дней и проверяем бонусы вручную.',
    },
    {
      title: 'Фокус на ответственности',
      description: 'Публикуем советы по контролю банкролла и контакты служб помощи.',
    },
  ];

  const evaluationCriteria = [
    {
      title: 'Лицензия и репутация',
      detail: 'Проверяем регулятора, дату основания и жалобы игроков.',
    },
    {
      title: 'Бонусы и вейджеры',
      detail: 'Сравниваем условия отыгрыша, ограниченные игры и сроки.',
    },
    {
      title: 'Платежи и лимиты',
      detail: 'Оцениваем скорость вывода, комиссии, поддержку криптовалют.',
    },
    {
      title: 'Поддержка и локализация',
      detail: 'Тестируем русскоязычный саппорт и наличие адаптированного интерфейса.',
    },
  ];

  const processSteps = [
    {
      step: '01',
      title: 'Первичный аудит',
      text: 'Собираем сведения о лицензии, поставщиках игр и владельце бренда.',
    },
    {
      step: '02',
      title: 'Тестирование бонусов',
      text: 'Регистрируемся, активируем бонусы и проверяем соответствие условиям.',
    },
    {
      step: '03',
      title: 'Платёжная проверка',
      text: 'Делаем депозиты и выводы, фиксируем скорость и возможные комиссии.',
    },
    {
      step: '04',
      title: 'Публикация обзора',
      text: 'Готовим структурированный отчёт с плюсами, минусами и рекомендациями.',
    },
  ];

  const testimonials = [
    {
      name: 'Светлана М.',
      company: 'Редактор блога о финансах',
      quote:
        'Gambling Review помог быстро подобрать казино с адекватным вейджером и поддержкой на русском языке.',
    },
    {
      name: 'Антон К.',
      company: 'Контент-менеджер',
      quote:
        'Ребята из команды тестировали выводы вместе со мной и подсказали, как избежать задержек при верификации.',
    },
    {
      name: 'Алексей Ж.',
      company: 'Партнёр аффилиат-сети',
      quote:
        'Используем их аналитические отчёты в нашей воронке. Экономит время и повышает конверсию.',
    },
  ];
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const handlePrevTestimonial = () => {
    setTestimonialIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };
  const handleNextTestimonial = () => {
    setTestimonialIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  const faqItems = [
    {
      question: 'Как вы проверяете честность казино?',
      answer:
        'Мы анализируем историю бренда, отзывы игроков, наличие лицензии, даты её обновления и проводим тестовые выплаты на разные методы.',
    },
    {
      question: 'Что означает вейджер bonus x35?',
      answer:
        'Это количество оборотов, которое необходимо сделать, чтобы отыграть бонус. Например, при бонусе 100$ и вейджере x35 нужно сделать ставок на 3500$.',
    },
    {
      question: 'Почему некоторые офферы недоступны?',
      answer:
        'Ограничения могут зависеть от страны проживания, возраста или выбранного метода оплаты. Мы всегда указываем гео-ограничения в карточке казино.',
    },
    {
      question: 'Вы даёте гарантии выигрыша?',
      answer:
        'Нет. Мы предоставляем информацию об условиях и бонусах, но не гарантируем выигрыши. Азартные игры всегда сопряжены с риском.',
    },
    {
      question: 'Как связаться с вашей командой?',
      answer:
        'На странице контактов есть форма обратной связи и адрес электронной почты. Мы ответим в течение одного рабочего дня.',
    },
  ];
  const [activeFaq, setActiveFaq] = useState(null);

  const services = [
    {
      title: 'Обзор офферов',
      description: 'Готовим развёрнутые обзоры казино с фокусом на бонусы и платежи.',
    },
    {
      title: 'Консультации игрокам',
      description: 'Помогаем подобрать площадку под ваш банкролл и предпочитаемые игры.',
    },
    {
      title: 'Аналитика аффилиатам',
      description: 'Собираем конверсии, EPC и lifetime value для партнерских программ.',
    },
  ];

  const team = [
    {
      name: 'Кирилл Захаров',
      role: 'Главный редактор',
      bio: '8 лет опыта в лицензированных казино и игорном комплаенсе.',
      photo: 'https://picsum.photos/400/400?random=31',
    },
    {
      name: 'Алина Трофимова',
      role: 'Аналитик по бонусам',
      bio: 'Управляла VIP-программой в крупном операторе, специалист по вейджерам.',
      photo: 'https://picsum.photos/400/400?random=32',
    },
    {
      name: 'Марк Белый',
      role: 'Эксперт по платежам',
      bio: 'Отвечал за платежный шлюз в fintech-стартапе, знает тонкости AML.',
      photo: 'https://picsum.photos/400/400?random=33',
    },
  ];

  const projects = [
    {
      id: 1,
      title: 'Мультиреализация Royal Crown',
      category: 'Лицензии ЕС',
      image: 'https://picsum.photos/1200/800?random=41',
      description: 'Проверили выплаты, создали чек-лист по лицензии MGA и обновили обзор.',
    },
    {
      id: 2,
      title: 'Крипто-гайд для Crypto Spin',
      category: 'Криптоказино',
      image: 'https://picsum.photos/1200/800?random=42',
      description: 'Сравнили криптовалютные методы и подготовили рекомендации по лимитам.',
    },
    {
      id: 3,
      title: 'Аналитика турниров Vegas Lux',
      category: 'Турниры',
      image: 'https://picsum.photos/1200/800?random=43',
      description: 'Проанализировали динамику призовых фондов и влияние на retention.',
    },
    {
      id: 4,
      title: 'Гайд по responsible gaming',
      category: 'Ответственная игра',
      image: 'https://picsum.photos/1200/800?random=44',
      description: 'Собрали лучшие практики ограничений и собрали наглядные инструкции.',
    },
  ];
  const [activeProjectFilter, setActiveProjectFilter] = useState('Все');
  const filteredProjects = useMemo(() => {
    if (activeProjectFilter === 'Все') {
      return projects;
    }
    return projects.filter((project) => project.category === activeProjectFilter);
  }, [projects, activeProjectFilter]);

  const blogPosts = [
    {
      title: 'Как читать условия бонусов и не ошибаться',
      excerpt:
        'Разбираем, что такое отыгрыш, какие ставки засчитываются и как не упустить сроки вейджера.',
      link: '/obzory-kazino/royal-crown-casino',
      date: '10 марта 2024',
    },
    {
      title: 'Криптовалютные платежи: чем отличаются BTC и USDT',
      excerpt:
        'Сравниваем комиссии, скорость подтверждения и лимиты для популярных криптовалют в казино.',
      link: '/obzory-kazino/crypto-spin-club',
      date: '1 марта 2024',
    },
    {
      title: 'Ответственная игра: инструменты, которые работают',
      excerpt:
        'Рассказываем о лимитах депозитов, реалити-чеке и полезных ресурсах для контроля.',
      link: '/privacy',
      date: '20 февраля 2024',
    },
  ];

  return (
    <div className="home">
      <section className="heroSection">
        <div className="container heroContent">
          <div className="heroText">
            <span className="heroBadge">Обновлено март 2024</span>
            <h1>Топ казино 2024</h1>
            <p>
              Честные обзоры, лучшие бонусы и сравнение условий для игроков, которые ценят
              безопасность и прозрачность.
            </p>
            <div className="heroActions">
              <Link to="/obzory-kazino" className="btn btnPrimary glow" aria-label="Перейти к обзорам казино">
                Смотреть обзоры
              </Link>
              <Link to="/sravnenie-uslovij" className="btn btnSecondary" aria-label="Перейти к сравнению условий">
                Сравнить условия
              </Link>
            </div>
          </div>
          <div className="heroVisual" aria-hidden="true">
            <div className="heroImage" />
            <div className="heroOverlayCard">
              <p>Выплаты проверены вручную</p>
              <strong>68 казино</strong>
            </div>
          </div>
        </div>
      </section>

      <section className="statsSection">
        <div className="container statsGrid">
          {stats.map((item, index) => (
            <div className="statCard" key={item.label}>
              <span className="statValue">
                {animatedStats[index] >= 1000
                  ? `${Math.round(animatedStats[index] / 100) / 10}k`
                  : animatedStats[index]}
              </span>
              <span className="statLabel">{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="advantagesSection">
        <div className="container">
          <h2>Почему нам доверяют</h2>
          <div className="advantagesGrid">
            {advantages.map((advantage) => (
              <div className="advantageCard" key={advantage.title}>
                <h3>{advantage.title}</h3>
                <p>{advantage.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="servicesSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Что мы делаем для игроков и партнёров</h2>
            <p>
              Применяем экспертный опыт, чтобы собрать для вас актуальные данные о рынке
              онлайн-казино и построить честную коммуникацию с операторами.
            </p>
          </div>
          <div className="servicesGrid">
            {services.map((service) => (
              <div className="serviceCard" key={service.title}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className="serviceLink">
                  Узнать больше →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="topCasinosSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Топ-3 казино месяца</h2>
            <p>Выбор редакции с проверенными выплатами и самыми выгодными бонусами.</p>
          </div>
          <div className="topCasinosGrid">
            {topCasinos.map((casino) => (
              <article className="casinoCard" key={casino.slug}>
                <img src={casino.logo} alt={`Логотип ${casino.name}`} />
                <div className="casinoCardContent">
                  <h3>{casino.name}</h3>
                  <StarRating value={casino.rating} />
                  <ul className="casinoInfo">
                    <li>
                      <strong>Бонус:</strong> {casino.bonus}
                    </li>
                    <li>
                      <strong>Вейджер:</strong> {casino.wager}
                    </li>
                    <li>
                      <strong>Вывод:</strong> {casino.withdrawal}
                    </li>
                  </ul>
                  <Link
                    to={`/obzory-kazino/${casino.slug}`}
                    className="btn btnPrimary"
                    aria-label={`Перейти к обзору ${casino.name}`}
                  >
                    Читать обзор
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="comparisonPreviewSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Сравнение условий</h2>
            <p>Сводная таблица бонусов, вейджеров и сроков выплат для топовых казино.</p>
          </div>
          <div className="tableWrapper">
            <table>
              <thead>
                <tr>
                  <th>Название</th>
                  <th>Бонус</th>
                  <th>Вейджер</th>
                  <th>Вывод</th>
                  <th>Рейтинг</th>
                </tr>
              </thead>
              <tbody>
                {tableCasinos.map((casino) => (
                  <tr key={casino.slug}>
                    <td>{casino.name}</td>
                    <td>{casino.bonus}</td>
                    <td>{casino.wager}</td>
                    <td>{casino.withdrawal}</td>
                    <td>
                      <StarRating value={casino.rating} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Link to="/sravnenie-uslovij" className="btn btnSecondary center" aria-label="Перейти к полной таблице сравнения">
            Перейти к полной таблице
          </Link>
        </div>
      </section>

      <section className="latestReviewsSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Последние обзоры</h2>
            <p>Краткие выдержки из новых материалов команды Gambling Review.</p>
          </div>
          <div className="latestGrid">
            {latestCasinos.map((casino) => (
              <article className="latestCard" key={casino.slug}>
                <img src={casino.logo} alt={`Превью казино ${casino.name}`} />
                <div>
                  <h3>{casino.name}</h3>
                  <p>{casino.reviewSummary}</p>
                  <Link to={`/obzory-kazino/${casino.slug}`} className="textLink">
                    Читать подробнее →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="processSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Как мы оцениваем казино</h2>
            <p>Чёткий алгоритм оценки каждого бренда перед публикацией обзора.</p>
          </div>
          <div className="processTimeline">
            {processSteps.map((step) => (
              <div className="processStep" key={step.step}>
                <span className="processNumber">{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="criteriaSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Ключевые критерии оценки</h2>
            <p>Факторы, которые влияют на итоговый рейтинг казино в нашем списке.</p>
          </div>
          <div className="criteriaGrid">
            {evaluationCriteria.map((item) => (
              <div className="criteriaCard" key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonialSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Что говорят читатели и партнёры</h2>
          </div>
          <div className="testimonialCarousel">
            <button
              type="button"
              className="carouselControl"
              aria-label="Предыдущий отзыв"
              onClick={handlePrevTestimonial}
            >
              ‹
            </button>
            <div className="testimonialCard">
              <p className="testimonialQuote">“{testimonials[testimonialIndex].quote}”</p>
              <div className="testimonialMeta">
                <strong>{testimonials[testimonialIndex].name}</strong>
                <span>{testimonials[testimonialIndex].company}</span>
              </div>
            </div>
            <button
              type="button"
              className="carouselControl"
              aria-label="Следующий отзыв"
              onClick={handleNextTestimonial}
            >
              ›
            </button>
          </div>
        </div>
      </section>

      <section className="teamSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Команда Gambling Review</h2>
            <p>Эксперты, которые стоят за исследованиями и аналитикой.</p>
          </div>
          <div className="teamGrid">
            {team.map((member) => (
              <div className="teamCard" key={member.name}>
                <div className="teamPhotoWrapper">
                  <img src={member.photo} alt={`Фото: ${member.name}`} />
                </div>
                <div className="teamInfo">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="projectsSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Кейсы и исследования</h2>
            <div className="projectFilters">
              {['Все', 'Лицензии ЕС', 'Криптоказино', 'Турниры', 'Ответственная игра'].map(
                (filter) => (
                  <button
                    type="button"
                    key={filter}
                    className={`filterBtn ${filter === activeProjectFilter ? 'active' : ''}`}
                    onClick={() => setActiveProjectFilter(filter)}
                    aria-label={`Фильтр: ${filter}`}
                  >
                    {filter}
                  </button>
                )
              )}
            </div>
          </div>
          <div className="projectsGrid">
            {filteredProjects.map((project) => (
              <article className="projectCard" key={project.id}>
                <img src={project.image} alt={`Кейс: ${project.title}`} />
                <div className="projectContent">
                  <span className="projectCategory">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faqSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Часто задаваемые вопросы</h2>
            <p>Ответы на вопросы о нашей методологии и выборе казино.</p>
          </div>
          <div className="faqAccordion">
            {faqItems.map((item, index) => (
              <div className={`faqItem ${activeFaq === index ? 'open' : ''}`} key={item.question}>
                <button
                  type="button"
                  className="faqQuestion"
                  onClick={() => setActiveFaq((prev) => (prev === index ? null : index))}
                  aria-expanded={activeFaq === index}
                  aria-label={`Переключить вопрос: ${item.question}`}
                >
                  {item.question}
                </button>
                <div className="faqAnswer">
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blogSection">
        <div className="container">
          <div className="sectionHeader">
            <h2>Свежие материалы в блоге</h2>
            <p>Инсайты о бонусах, платежах и ответственной игре.</p>
          </div>
          <div className="blogGrid">
            {blogPosts.map((post) => (
              <article className="blogCard" key={post.title}>
                <span className="blogDate">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className="textLink">
                  Читать →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="ctaSection">
        <div className="container ctaContainer">
          <div className="ctaText">
            <h2>Начните сравнивать казино сегодня</h2>
            <p>
              Используйте проверенные данные, чтобы выбрать площадку с честными условиями и
              комфортными лимитами. Играйте ответственно.
            </p>
          </div>
          <Link to="/obzory-kazino" className="btn btnPrimary glow" aria-label="Перейти к обзорам казино">
            Перейти к обзорам
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;