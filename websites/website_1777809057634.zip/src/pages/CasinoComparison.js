import React, { useMemo, useState } from 'react';
import casinos from '../data/casinos';
import StarRating from '../components/StarRating';
import usePageMeta from '../hooks/usePageMeta';

const CasinoComparison = () => {
  usePageMeta(
    'Сравнение условий казино — Gambling Review',
    'Таблица сравнения бонусов, вейджеров, сроков выплат и рейтингов топовых онлайн-казино.'
  );

  const [sortConfig, setSortConfig] = useState({ key: 'rating', direction: 'desc' });

  const sortedCasinos = useMemo(() => {
    const sortable = [...casinos];
    sortable.sort((a, b) => {
      const { key, direction } = sortConfig;
      let result = 0;
      if (key === 'rating') {
        result = a.rating - b.rating;
      } else if (key === 'name') {
        result = a.name.localeCompare(b.name);
      } else if (key === 'bonus') {
        result = a.bonus.localeCompare(b.bonus);
      } else if (key === 'wager') {
        const parseWager = (value) => parseInt(value.replace(/\D/g, ''), 10) || 0;
        result = parseWager(a.wager) - parseWager(b.wager);
      } else if (key === 'withdrawal') {
        const parseWithdrawal = (value) => parseInt(value.replace(/\D/g, ''), 10) || 0;
        result = parseWithdrawal(a.withdrawal) - parseWithdrawal(b.withdrawal);
      }
      return direction === 'asc' ? result : -result;
    });
    return sortable;
  }, [sortConfig]);

  const handleSort = (key) => {
    setSortConfig((prev) => {
      if (prev.key === key) {
        return { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { key, direction: 'asc' };
    });
  };

  return (
    <div className="page">
      <section className="pageHeader">
        <div className="container narrow">
          <h1>Сравнение условий</h1>
          <p>
            Сводная таблица по ключевым параметрам: бонусы, вейджеры, лимиты и средний рейтинг по
            результатам тестирования. Выбирайте казино, учитывая законодательство вашей страны и
            собственные лимиты.
          </p>
        </div>
      </section>
      <section className="pageSection">
        <div className="container">
          <div className="tableWrapper interactive">
            <table>
              <thead>
                <tr>
                  <th>
                    <button type="button" onClick={() => handleSort('name')} aria-label="Сортировать по названию">
                      Название
                    </button>
                  </th>
                  <th>
                    <button type="button" onClick={() => handleSort('bonus')} aria-label="Сортировать по бонусам">
                      Бонус
                    </button>
                  </th>
                  <th>
                    <button type="button" onClick={() => handleSort('wager')} aria-label="Сортировать по вейджеру">
                      Вейджер
                    </button>
                  </th>
                  <th>
                    <button type="button" onClick={() => handleSort('withdrawal')} aria-label="Сортировать по выводу">
                      Вывод
                    </button>
                  </th>
                  <th>
                    <button type="button" onClick={() => handleSort('rating')} aria-label="Сортировать по рейтингу">
                      Рейтинг
                    </button>
                  </th>
                  <th>Методы оплаты</th>
                  <th>Игры</th>
                </tr>
              </thead>
              <tbody>
                {sortedCasinos.map((casino) => (
                  <tr key={casino.slug}>
                    <td>{casino.name}</td>
                    <td>{casino.bonus}</td>
                    <td>{casino.wager}</td>
                    <td>{casino.withdrawal}</td>
                    <td>
                      <StarRating value={casino.rating} />
                    </td>
                    <td>{casino.paymentMethods.join(', ')}</td>
                    <td>{casino.games.join(', ')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="infoCard">
            <h3>Как читать таблицу сравнения</h3>
            <ul>
              <li>
                <strong>Бонус:</strong> основной приветственный оффер. Всегда уточняйте лимиты ставок и сроки.
              </li>
              <li>
                <strong>Вейджер:</strong> чем ниже, тем проще отыграть бонус. Значение x25-x35 считается рыночным.
              </li>
              <li>
                <strong>Вывод:</strong> включает минимальный порог и среднее время, подтверждённое тестовыми выводами.
              </li>
              <li>
                <strong>Рейтинг:</strong> учитывает лицензии, поддержку, лимиты и отзывы игроков.
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CasinoComparison;