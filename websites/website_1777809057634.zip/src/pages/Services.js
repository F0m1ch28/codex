import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Services = () => {
  usePageMeta(
    'Услуги — Gambling Review',
    'Услуги Gambling Review для игроков и партнёров: аналитика, обзоры, консультации.'
  );

  const [activeService, setActiveService] = useState(0);

  const services = [
    {
      title: 'Глубокие обзоры казино',
      description:
        'Составляем структурированные обзоры: лицензии, бонусные условия, лимиты и скорость выплат. Проверяем данные вручную.',
      details: [
        'Тестовые депозиты и выводы',
        'Верификация условий бонусов',
        'Сравнительные таблицы конкурентов',
      ],
    },
    {
      title: 'Аналитика для партнёров',
      description:
        'Собираем и анализируем показатели EPC, CR и retention по аффилиатным офферам. Помогаем оптимизировать трафик.',
      details: ['Бенчмарки по гео', 'А/B-тесты лендингов', 'Кастомные отчёты в Data Studio'],
    },
    {
      title: 'Экспресс-консультации игрокам',
      description:
        'Помогаем подобрать площадку под ваш банкролл и предпочитаемые методы выводов. Объясняем условия бонусов простым языком.',
      details: ['Подбор казино по гео', 'Разбор бонусных правил', 'Рекомендации по лимитам'],
    },
    {
      title: 'Контент для медиа',
      description:
        'Готовим экспертные комментарии, интервью и аналитические материалы для профильных СМИ и блогов.',
      details: ['Колонки на тему responsible gaming', 'Инфографика и чек-листы', 'Подготовка гайдлайнов'],
    },
  ];

  return (
    <div className="page">
      <section className="pageHeader">
        <div className="container narrow">
          <h1>Наши услуги</h1>
          <p>
            Мы делимся экспертизой с игроками, аффилиатами и медиа. Все консультации основаны на
            проверенных фактах, без обещаний выиграть.
          </p>
        </div>
      </section>
      <section className="pageSection">
        <div className="container">
          <div className="servicesTabs">
            <div className="servicesMenu">
              {services.map((service, index) => (
                <button
                  type="button"
                  key={service.title}
                  className={`servicesTab ${activeService === index ? 'active' : ''}`}
                  onClick={() => setActiveService(index)}
                  aria-label={`Подробнее о услуге ${service.title}`}
                >
                  {service.title}
                </button>
              ))}
            </div>
            <div className="servicesDetails">
              <h2>{services[activeService].title}</h2>
              <p>{services[activeService].description}</p>
              <ul>
                {services[activeService].details.map((detail) => (
                  <li key={detail}>{detail}</li>
                ))}
              </ul>
              <p className="infoNote">
                Чтобы узнать стоимость или уточнить детали, напишите на{' '}
                <a href="mailto:info@gamblingreview.com">info@gamblingreview.com</a>.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;