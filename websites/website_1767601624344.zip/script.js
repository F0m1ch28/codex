document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = siteNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const cookieKey = 'optFlowersCookieConsent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(cookieKey);
        if (!storedConsent) {
            cookieBanner.classList.remove('is-hidden');
        }

        const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
        const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');

        const hideBanner = () => cookieBanner.classList.add('is-hidden');

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                localStorage.setItem(cookieKey, 'accepted');
                hideBanner();
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                localStorage.setItem(cookieKey, 'declined');
                hideBanner();
            });
        }
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        const feedback = document.getElementById('form-feedback');

        contactForm.addEventListener('submit', function (event) {
            const errors = [];
            const nameField = contactForm.elements['client-name'];
            const companyField = contactForm.elements['company-name'];
            const emailField = contactForm.elements['client-email'];
            const phoneField = contactForm.elements['client-phone'];
            const messageField = contactForm.elements['client-message'];

            if (nameField && nameField.value.trim().length < 2) {
                errors.push('Вкажіть, будь ласка, імʼя (мінімум 2 символи).');
            }

            if (companyField && companyField.value.trim().length < 2) {
                errors.push('Назва компанії має містити щонайменше 2 символи.');
            }

            if (emailField) {
                const emailValue = emailField.value.trim();
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailValue)) {
                    errors.push('Перевірте правильність електронної пошти.');
                }
            }

            if (phoneField) {
                const phoneDigits = phoneField.value.replace(/\D/g, '');
                if (phoneDigits.length < 9) {
                    errors.push('Будь ласка, вкажіть дійсний номер телефону.');
                }
            }

            if (messageField && messageField.value.trim().length < 10) {
                errors.push('Повідомлення має містити щонайменше 10 символів.');
            }

            if (errors.length > 0) {
                event.preventDefault();
                if (feedback) {
                    feedback.textContent = errors.join(' ');
                    feedback.classList.remove('success');
                    feedback.classList.add('error');
                }
            } else if (feedback) {
                feedback.textContent = '';
                feedback.classList.remove('error');
            }
        });
    }
});