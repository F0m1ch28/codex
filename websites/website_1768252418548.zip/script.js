document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookieBanner");
    const acceptBtn = document.getElementById("cookieAccept");
    const declineBtn = document.getElementById("cookieDecline");
    const storageKey = "asleepudzoCookieChoice";

    if (!banner || !acceptBtn || !declineBtn) {
        return;
    }

    const savedChoice = localStorage.getItem(storageKey);
    if (!savedChoice) {
        banner.classList.add("active");
    }

    acceptBtn.addEventListener("click", function () {
        localStorage.setItem(storageKey, "accepted");
        banner.classList.remove("active");
    });

    declineBtn.addEventListener("click", function () {
        localStorage.setItem(storageKey, "declined");
        banner.classList.remove("active");
    });
});