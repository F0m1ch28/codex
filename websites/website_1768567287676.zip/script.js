document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (primaryNav.classList.contains('is-open')) {
                    primaryNav.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('nipaunxj_cookie_preference');
        if (storedPreference) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieBanner.addEventListener('click', function (event) {
            const action = event.target?.getAttribute('data-cookie-action');
            if (!action) return;

            if (action === 'accept') {
                localStorage.setItem('nipaunxj_cookie_preference', 'accepted');
            }

            if (action === 'decline') {
                localStorage.setItem('nipaunxj_cookie_preference', 'declined');
            }

            cookieBanner.classList.add('is-hidden');
        });
    }
});