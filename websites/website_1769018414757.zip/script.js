document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      siteNav.classList.toggle("is-open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute("aria-expanded", "false");
          siteNav.classList.remove("is-open");
        }
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
    const storageKey = "ott-cookie-consent";
    const storedValue = localStorage.getItem(storageKey);

    if (storedValue === "accepted" || storedValue === "declined") {
      cookieBanner.classList.add("hidden");
    }

    const handleChoice = (value) => {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.add("hidden");
    };

    acceptBtn?.addEventListener("click", () => handleChoice("accepted"));
    declineBtn?.addEventListener("click", () => handleChoice("declined"));
  }
});