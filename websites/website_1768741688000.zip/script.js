document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.getElementById('navToggle');
    const primaryNav = document.getElementById('primaryNav');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieDecline = document.getElementById('cookieDecline');
    const rangeInput = document.getElementById('variantRange');
    const rangeOutput = document.getElementById('variantOutput');
    const consentKey = 'gdCookieConsent';

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            primaryNav.classList.toggle('open');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                primaryNav.classList.remove('open');
            });
        });
    }

    if (rangeInput && rangeOutput) {
        const updateRangeLabel = () => {
            rangeOutput.textContent = rangeInput.value;
        };
        rangeInput.addEventListener('input', updateRangeLabel);
        updateRangeLabel();
    }

    if (cookieBanner && cookieAccept && cookieDecline) {
        const savedConsent = localStorage.getItem(consentKey);
        if (!savedConsent) {
            cookieBanner.classList.add('active');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.remove('active');
        });

        cookieDecline.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});