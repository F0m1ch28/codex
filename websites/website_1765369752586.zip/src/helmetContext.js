import React, { useEffect } from 'react';

const helmetAsync = typeof window !== 'undefined' ? window.ReactHelmetAsync : null;

const FallbackHelmetProvider = ({ children }) => <>{children}</>;

const parseMetaChildren = (children) => {
  const metaInfo = {
    title: '',
    metas: [],
  };

  React.Children.forEach(children, (child) => {
    if (!React.isValidElement(child)) return;
    if (child.type === 'title') {
      metaInfo.title = child.props.children;
    }
    if (child.type === 'meta') {
      metaInfo.metas.push(child.props);
    }
  });

  return metaInfo;
};

const FallbackHelmet = ({ children }) => {
  useEffect(() => {
    const metaInfo = parseMetaChildren(children);
    if (metaInfo.title && typeof document !== 'undefined') {
      document.title = metaInfo.title;
    }
    if (typeof document !== 'undefined') {
      metaInfo.metas.forEach((metaProps) => {
        if (!metaProps || !metaProps.name) return;
        let element = document.querySelector(`meta[name="${metaProps.name}"]`);
        if (!element) {
          element = document.createElement('meta');
          element.setAttribute('name', metaProps.name);
          document.head.appendChild(element);
        }
        if (metaProps.content) {
          element.setAttribute('content', metaProps.content);
        }
      });
    }
  }, [children]);

  return null;
};

export const HelmetProvider = helmetAsync?.HelmetProvider ?? FallbackHelmetProvider;
export const Helmet = helmetAsync?.Helmet ?? FallbackHelmet;