import React from 'react';
import { Helmet } from '../helmetContext';
import styles from './About.module.css';

const traits = [
  {
    title: 'Ориентация на результат',
    description: 'Фокусируемся на эффекте, измеряем прогресс и находим решения, которые приживаются в компании.',
    icon: '🎯',
  },
  {
    title: 'Партнёрство и доверие',
    description: 'Работаем в тесной связке с командами заказчика, строим открытый диалог и честно говорим о рисках.',
    icon: '🤝',
  },
  {
    title: 'Мультидисциплинарная экспертиза',
    description: 'Соединяем стратегию, ИТ-архитектуру, аналитику и управление изменениями в единый подход.',
    icon: '🔬',
  },
];

const teamMembers = [
  {
    name: 'Екатерина Смирнова',
    role: 'Руководитель практики трансформации',
    bio: '15 лет в стратегическом консалтинге, запускала масштабные программы изменений в промышленности и ТЭК.',
    image: 'https://picsum.photos/400/400?random=71',
  },
  {
    name: 'Дмитрий Гордеев',
    role: 'Директор по технологиям',
    bio: 'Эксперт по архитектуре корпоративных систем и внедрению цифровых платформ в распределённых компаниях.',
    image: 'https://picsum.photos/400/400?random=72',
  },
  {
    name: 'Алина Исаева',
    role: 'Партнёр по управлению данными',
    bio: 'Специализируется на развитии дата-офисов, BI-решений и инициатив по качеству данных.',
    image: 'https://picsum.photos/400/400?random=73',
  },
  {
    name: 'Максим Кузьмин',
    role: 'Руководитель практики клиентского опыта',
    bio: 'Свыше 10 лет выстраивает сервисные модели и внедряет омниканальные решения.',
    image: 'https://picsum.photos/400/400?random=74',
  },
];

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>О компании — Лабмьсдсост ось б</title>
      <meta
        name="description"
        content="Узнайте больше о компании Лабмьсдсост ось б: наша миссия, ценности, команда и подход к построению устойчивого роста бизнеса."
      />
      <meta
        name="keywords"
        content="Лабмьсдсост ось б, команда, ценности, корпоративная культура"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>О компании</h1>
        <p>
          Лабмьсдсост ось б объединяет экспертов, которые помогают крупным компаниям уверенно проходить через
          трансформацию. Наша миссия — создавать устойчивые системы, в которых технологии и люди работают в одном
          ритме.
        </p>
      </div>
      <div className={styles.heroImage}>
        <img
          src="https://picsum.photos/1200/800?random=13"
          alt="Совместная работа команды Лабмьсдсост ось б"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.values}>
      <div className={styles.sectionIntro}>
        <h2>Наши принципы</h2>
        <p>
          Мы вырабатываем решения вместе с заказчиками, опираемся на открытость и ставим людей в центр изменений. Такие
          принципы позволяют строить доверие и достигать целей быстрее.
        </p>
      </div>
      <div className={styles.traitsGrid}>
        {traits.map((trait) => (
          <article key={trait.title} className={styles.traitCard}>
            <span aria-hidden="true" className={styles.traitIcon}>
              {trait.icon}
            </span>
            <h3>{trait.title}</h3>
            <p>{trait.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.story}>
      <div className={styles.storyContent}>
        <h2>Как мы развиваемся</h2>
        <p>
          Компания выросла из инициативы экспертов, которые помогали крупным промышленным предприятиям трансформировать
          ключевые процессы. Со временем мы расширили портфель компетенций, привлекли специалистов по данным,
          автоматизации и управлению клиентским опытом. Сегодня команда работает в нескольких странах, поддерживая
          клиентов в сферах промышленности, финансов, логистики, энергетики и телеком.
        </p>
        <p>
          Мы инвестируем в развитие людей, строим внутренние академии, культуру наставничества и обмена знаниями. Для
          нас важно, чтобы каждый проект оставлял позитивный след в компании заказчика и создавал пространство для
          дальнейших улучшений.
        </p>
      </div>
      <div className={styles.storyImage}>
        <img
          src="https://picsum.photos/800/600?random=14"
          alt="Совместная работа над проектом по цифровой трансформации"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.team}>
      <div className={styles.sectionIntro}>
        <h2>Команда Лабмьсдсост ось б</h2>
        <p>
          Мы ценим разнообразие опыта и поддерживаем культуру сотрудничества. Каждая команда проекта формируется с
          учётом задач клиента и сочетает стратегов, аналитиков, инженеров и фасилитаторов.
        </p>
      </div>
      <div className={styles.teamGrid}>
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.teamCard}>
            <div className={styles.teamImageWrapper}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div className={styles.teamOverlay}>
                <p>{member.bio}</p>
              </div>
            </div>
            <div className={styles.teamInfo}>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.perspective}>
      <div className={styles.perspectiveCard}>
        <div>
          <h2>Смотрим вперёд</h2>
          <p>
            Мы продолжаем расширять сеть партнёров, развиваем экспериментальные лаборатории и инвестируем в исследование
            новых технологий. Наша цель — помогать компаниям строить цифровые экосистемы и создавать ценность для людей.
          </p>
        </div>
      </div>
    </section>
  </div>
);

export default AboutPage;