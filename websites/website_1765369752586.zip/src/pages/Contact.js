import React, { useState } from 'react';
import { Helmet } from '../helmetContext';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: '',
};

const ContactPage = () => {
  const [formValues, setFormValues] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите ваше имя.';
    }
    if (!formValues.email.trim()) {
      newErrors.email = 'Введите рабочий адрес электронной почты.';
    } else if (!/^\S+@\S+\.\S+$/.test(formValues.email)) {
      newErrors.email = 'Пожалуйста, проверьте корректность адреса электронной почты.';
    }
    if (!formValues.message.trim()) {
      newErrors.message = 'Опишите ваш запрос или задачу.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormValues(initialFormState);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты — Лабмьсдсост ось б</title>
        <meta
          name="description"
          content="Свяжитесь с командой Лабмьсдсост ось б. Адрес: г. Москва, ул. Примерная, д. 1. Телефон: +7 (XXX) XXX-XX-XX. Email: info@labmsdsost-example.ru."
        />
        <meta
          name="keywords"
          content="контакты, Лабмьсдсост ось б, связь, консультация"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Свяжитесь с нами</h1>
          <p>
            Расскажите нам о своей задаче, и мы предложим формат сотрудничества, подходящий вашей команде. Мы открыты к
            новым идеям, партнёрствам и совместным проектам.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1200/800?random=16"
            alt="Контактный центр Лабмьсдсост ось б"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.infoCard}>
          <h2>Контактные данные</h2>
          <ul>
            <li>
              <strong>Адрес:</strong> г. Москва, ул. Примерная, д. 1
            </li>
            <li>
              <strong>Телефон:</strong>{' '}
              <a href="tel:+7XXXXXXXXXX" className={styles.link}>
                +7 (XXX) XXX-XX-XX
              </a>
            </li>
            <li>
              <strong>Email:</strong>{' '}
              <a href="mailto:info@labmsdsost-example.ru" className={styles.link}>
                info@labmsdsost-example.ru
              </a>
            </li>
          </ul>
          <p>
            Мы ответим на ваше письмо в течение одного рабочего дня. При необходимости организуем встречу в офисе или
            онлайн, чтобы обсудить детали проекта.
          </p>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Напишите нам</h2>
          <div className={styles.fieldGroup}>
            <label htmlFor="name">Имя *</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Ваше имя"
              value={formValues.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && (
              <span className={styles.errorMessage} id="name-error">
                {errors.name}
              </span>
            )}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="email">Email *</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@company.ru"
              value={formValues.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && (
              <span className={styles.errorMessage} id="email-error">
                {errors.email}
              </span>
            )}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="company">Компания</label>
            <input
              id="company"
              name="company"
              type="text"
              placeholder="Название вашей компании"
              value={formValues.company}
              onChange={handleChange}
            />
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="message">Сообщение *</label>
            <textarea
              id="message"
              name="message"
              placeholder="Опишите ваш запрос, задачу или идею проекта"
              value={formValues.message}
              onChange={handleChange}
              rows={6}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && (
              <span className={styles.errorMessage} id="message-error">
                {errors.message}
              </span>
            )}
          </div>

          <button type="submit" className={styles.submitButton}>
            Отправить сообщение
          </button>
          {submitted && <p className={styles.successMessage}>Спасибо! Мы свяжемся с вами в ближайшее время.</p>}
        </form>
      </section>
    </div>
  );
};

export default ContactPage;