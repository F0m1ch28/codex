import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '../helmetContext';
import styles from './Home.module.css';

const statsData = [
  { label: 'Успешных проектов', value: 128 },
  { label: 'Экспертов в штате', value: 47 },
  { label: 'Стран присутствия', value: 6 },
  { label: 'Партнёров экосистемы', value: 32 },
];

const servicesHighlight = [
  {
    title: 'Консалтинг трансформации',
    description: 'Диагностика процессов, разработка стратегий и сопровождение изменений.',
    icon: '🧭',
  },
  {
    title: 'Цифровые решения',
    description: 'Проектирование и внедрение современных цифровых платформ под ваши задачи.',
    icon: '💡',
  },
  {
    title: 'Аналитика данных',
    description: 'Единая модель данных, BI-платформы и прогнозная аналитика для бизнеса.',
    icon: '📊',
  },
  {
    title: 'Поддержка роста',
    description: 'Управление изменениями, обучение команд и технологическая поддержка.',
    icon: '🤝',
  },
];

const processSteps = [
  {
    title: 'Диагностика и цель',
    description: 'Погружаемся в контекст компании, определяем ключевые задачи и требования.',
    icon: '🔍',
  },
  {
    title: 'Создание решения',
    description: 'Формируем дорожную карту, пилоты и прототипы для проверки гипотез.',
    icon: '🛠️',
  },
  {
    title: 'Внедрение',
    description: 'Настраиваем процессы, интегрируем инструменты и сопровождаем изменения.',
    icon: '🚀',
  },
  {
    title: 'Масштабирование',
    description: 'Расширяем решение по всей организации, фиксируем результаты и метрики.',
    icon: '📈',
  },
];

const projectsData = [
  {
    title: 'Цифровая платформа управления цепочкой поставок',
    description: 'Создание единой экосистемы данных и процессов для крупного промышленного холдинга.',
    category: 'цифровизация',
    image: 'https://picsum.photos/1200/800?random=41',
  },
  {
    title: 'Прогнозная аналитика продаж',
    description: 'Модель прогнозирования спроса и визуализация KPI для федеральной розничной сети.',
    category: 'аналитика',
    image: 'https://picsum.photos/1200/800?random=42',
  },
  {
    title: 'Центр компетенций по Agile',
    description: 'Обучение команд и настройка гибких процессов в финансовой организации.',
    category: 'консалтинг',
    image: 'https://picsum.photos/1200/800?random=43',
  },
  {
    title: 'Автоматизация клиентского сервиса',
    description: 'Внедрение омниканальной платформы обслуживания и чат-бота поддержки.',
    category: 'технологии',
    image: 'https://picsum.photos/1200/800?random=44',
  },
];

const testimonialsData = [
  {
    quote:
      'Команда Лабмьсдсост ось б помогла нам создать прозрачную систему аналитики и управлять изменениями без сбоев. Мы получили кратный рост эффективности.',
    name: 'Александр Ковалёв',
    role: 'Генеральный директор, «СеверИнжиниринг»',
    avatar: 'https://picsum.photos/200/200?random=51',
  },
  {
    quote:
      'Отлаженный подход, внимание к деталям и сильная экспертиза. Внедрение цифровой платформы прошло в срок и без сюрпризов.',
    name: 'Мария Соколова',
    role: 'Руководитель цифровой трансформации, «ФинПульс»',
    avatar: 'https://picsum.photos/200/200?random=52',
  },
  {
    quote:
      'Совместно мы выстроили единую архитектуру данных и запустили аналитическую витрину. Команда действует как партнёр, а не подрядчик.',
    name: 'Иван Лебедев',
    role: 'Операционный директор, «ЛогТех»',
    avatar: 'https://picsum.photos/200/200?random=53',
  },
];

const faqItems = [
  {
    question: 'С чего начинается сотрудничество?',
    answer:
      'Мы проводим установочную встречу, фиксируем цели, оцениваем текущую ситуацию и предлагаем формат работы. После согласования целей формируем план и команду.',
  },
  {
    question: 'Работаете ли вы с распределёнными командами?',
    answer:
      'Да, у нас выстроены удалённые процессы, мы используем защищённые цифровые каналы и проводим регулярные сессии для синхронизации.',
  },
  {
    question: 'Как вы измеряете успех проектов?',
    answer:
      'На старте определяем KPI совместно с заказчиком: показатели эффективности, скорость процессов, удовлетворённость сотрудников и клиентов. После внедрения анализируем достигнутые результаты.',
  },
  {
    question: 'Предоставляете ли вы поддержку после внедрения?',
    answer:
      'Обязательная часть наших проектов — сопровождение и поддержка на этапе стабилизации. Мы обучаем команду заказчика и остаёмся рядом до достижения целевых показателей.',
  },
];

const blogPosts = [
  {
    title: 'Как построить экосистему данных вокруг клиента',
    excerpt:
      'Объясняем, почему единой модели данных недостаточно и какие шаги помогут компании услышать клиента в цифровой среде.',
    date: '12 февраля 2024',
    image: 'https://picsum.photos/800/600?random=61',
  },
  {
    title: 'Четыре сценария внедрения ИИ в корпоративных процессах',
    excerpt:
      'Рассказываем о практических кейсах из промышленности, логистики и финансов, делимся рекомендациями по старту.',
    date: '28 января 2024',
    image: 'https://picsum.photos/800/600?random=62',
  },
  {
    title: 'Роль лидерства в устойчивой трансформации бизнеса',
    excerpt:
      'Разбираем, как сформировать культуру изменений, поддержать команды и избежать выгорания на длинных проектах.',
    date: '15 января 2024',
    image: 'https://picsum.photos/800/600?random=63',
  },
];

const HomePage = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [faqOpenIndex, setFaqOpenIndex] = useState(0);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('all');
  const statsRef = useRef(null);
  const [statsAnimated, setStatsAnimated] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setStatsAnimated(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsAnimated) return;

    const intervals = statsData.map((stat, index) => {
      return setInterval(() => {
        setCounters((prev) => {
          const updated = [...prev];
          const increment = Math.ceil(stat.value / 60);
          if (updated[index] < stat.value) {
            updated[index] = Math.min(updated[index] + increment, stat.value);
          }
          return updated;
        });
      }, 30);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsAnimated]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 8000);

    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'all') {
      return projectsData;
    }
    return projectsData.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  const handleFaqToggle = (index) => {
    setFaqOpenIndex((prev) => (prev === index ? -1 : index));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Лабмьсдсост ось б — Профессиональные решения для бизнеса</title>
        <meta
          name="description"
          content="Лабмьсдсост ось б предлагает консалтинг, цифровые решения и аналитические инструменты, чтобы ваш бизнес развивался уверенно и устойчиво."
        />
        <meta
          name="keywords"
          content="корпоративный консалтинг, цифровая трансформация, аналитика данных, Лабмьсдсост ось б"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroLabel}>Корпоративные решения нового уровня</p>
          <h1 className={styles.heroTitle}>Лабмьсдсост ось б</h1>
          <p className={styles.heroSubtitle}>
            Профессиональные решения для вашего бизнеса. Мы соединяем стратегию, технологию и вовлечённые команды,
            чтобы вы видели результат уже сегодня.
          </p>
          <div className={styles.heroActions}>
            <Link to="/uslugi" className={styles.primaryButton}>
              Наши услуги
            </Link>
            <Link to="/o-kompanii" className={styles.secondaryButton}>
              Узнать о нас больше
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper} aria-hidden="true">
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Команда, обсуждающая стратегию цифровой трансформации"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.aboutIntro}>
        <div className={styles.sectionHeader}>
          <h2>Наша компания</h2>
          <p>
            Лабмьсдсост ось б — это команда экспертов по трансформации и развитию бизнеса. Мы работаем с компаниями,
            которые осознают важность изменений и стремятся опережать рынок. Наш подход строится на глубоком понимании
            процессов, чёткой стратегии и уважении к людям.
          </p>
        </div>
        <div className={styles.aboutContent}>
          <div className={styles.aboutText}>
            <p>
              Мы создаём решения, которые дают измеримый эффект: ускоряют процессы, повышают прозрачность, позволяют
              гибко управлять ресурсами и принимать взвешенные решения. В центре внимания для нас всегда остаются люди —
              команды, которые создают ценность для ваших клиентов.
            </p>
            <p>
              Благодаря междисциплинарному подходу и надёжной партнёрской сети мы сопровождаем организации от идеи до
              устойчивой операционной модели.
            </p>
            <Link to="/o-kompanii" className={styles.linkButton}>
              Подробнее
            </Link>
          </div>
          <div className={styles.aboutVisual}>
            <img
              src="https://picsum.photos/800/600?random=12"
              alt="Совещание команды и планирование этапов проекта"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Что мы предлагаем</h2>
          <p>
            Мы помогаем организациям составлять стратегию, внедрять цифровые решения и управлять изменениями. Наши
            направления работы формируют цельный цикл трансформации и роста.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {servicesHighlight.map((service) => (
            <Link key={service.title} to="/uslugi" className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <span className={styles.cardArrow} aria-hidden="true">
                →
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.advantages} ref={statsRef}>
        <div className={styles.sectionHeader}>
          <h2>Почему выбирают нас</h2>
          <p>
            Мы фокусируемся на измеримом результате, прозрачной коммуникации и поддержке команд на каждом этапе. Наша
            экспертиза подтверждена большим количеством реализованных инициатив.
          </p>
        </div>
        <div className={styles.statsRow}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>{counters[index]}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
        <ul className={styles.advantagesList}>
          <li>
            <strong>Глубокая экспертиза.</strong> В команду входят аналитики, консультанты, архитекторы и
            фасилитаторы, которые умеют работать сообща.
          </li>
          <li>
            <strong>Прозрачная коммуникация.</strong> Открываем данные, визуализируем прогресс, обсуждаем риски и
            принимаем решения вместе с заказчиком.
          </li>
          <li>
            <strong>Технологии с практической ценностью.</strong> Внедряем инструменты, которые поддерживают
            сотрудников и повышают качество сервиса.
          </li>
          <li>
            <strong>Устойчивый результат.</strong> Проводим обучение, настраиваем управление знаниями,
            формируем культуру постоянного развития.
          </li>
        </ul>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Как мы работаем и какие проекты реализуем</h2>
          <p>
            Системный подход сочетает диагностику, проектирование, внедрение и масштабирование. Мы берём на себя
            ответственность за результат и делимся экспертизой на каждом шаге.
          </p>
        </div>
        <div className={styles.processTimeline}>
          {processSteps.map((step) => (
            <div key={step.title} className={styles.processStep}>
              <span className={styles.processIcon} aria-hidden="true">
                {step.icon}
              </span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
        <div className={styles.projects}>
          <div className={styles.filterBar}>
            <button
              type="button"
              className={`${styles.filterButton} ${activeFilter === 'all' ? styles.filterActive : ''}`}
              onClick={() => setActiveFilter('all')}
            >
              Все
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${activeFilter === 'цифровизация' ? styles.filterActive : ''}`}
              onClick={() => setActiveFilter('цифровизация')}
            >
              Цифровизация
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${activeFilter === 'аналитика' ? styles.filterActive : ''}`}
              onClick={() => setActiveFilter('аналитика')}
            >
              Аналитика
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${activeFilter === 'консалтинг' ? styles.filterActive : ''}`}
              onClick={() => setActiveFilter('консалтинг')}
            >
              Консалтинг
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${activeFilter === 'технологии' ? styles.filterActive : ''}`}
              onClick={() => setActiveFilter('технологии')}
            >
              Технологии
            </button>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/uslugi" className={styles.projectLink} aria-label={`Подробнее о проекте ${project.title}`}>
                    Подробнее о подходе
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.insights}>
        <div className={styles.testimonials}>
          <div className={styles.sectionHeader}>
            <h2>Отзывы партнёров</h2>
            <p>
              Мы строим долгосрочные отношения и ценим доверие, которое нам оказывают лидеры отраслей. Их обратная
              связь помогает становиться лучше.
            </p>
          </div>
          <div className={styles.testimonialCard}>
            <button
              type="button"
              className={styles.testimonialControl}
              onClick={() =>
                setCurrentTestimonial((prev) => (prev - 1 + testimonialsData.length) % testimonialsData.length)
              }
              aria-label="Предыдущий отзыв"
            >
              ‹
            </button>
            <div className={styles.testimonialContent}>
              <img
                src={testimonialsData[currentTestimonial].avatar}
                alt={`Фото клиента ${testimonialsData[currentTestimonial].name}`}
                loading="lazy"
              />
              <blockquote>“{testimonialsData[currentTestimonial].quote}”</blockquote>
              <p className={styles.testimonialName}>{testimonialsData[currentTestimonial].name}</p>
              <p className={styles.testimonialRole}>{testimonialsData[currentTestimonial].role}</p>
            </div>
            <button
              type="button"
              className={styles.testimonialControl}
              onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length)}
              aria-label="Следующий отзыв"
            >
              ›
            </button>
          </div>
          <div className={styles.testimonialDots} role="tablist" aria-label="Индикаторы отзывов">
            {testimonialsData.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                className={`${styles.dot} ${currentTestimonial === index ? styles.dotActive : ''}`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Показать отзыв ${testimonial.name}`}
                aria-selected={currentTestimonial === index}
                role="tab"
              />
            ))}
          </div>
        </div>
        <div className={styles.faq}>
          <div className={styles.sectionHeader}>
            <h2>Частые вопросы</h2>
            <p>
              Ответы на основные вопросы о подходе Лабмьсдсост ось б к трансформации и поддержке клиентов.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={faqOpenIndex === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{faqOpenIndex === index ? '−' : '+'}</span>
                </button>
                {faqOpenIndex === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHeader}>
          <h2>Актуальные материалы</h2>
          <p>
            Делимся аналитикой, лучшими практиками и подходами, которые помогают принимать управленческие решения и
            выстраивать устойчивую трансформацию.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImageWrapper}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/o-kompanii" className={styles.blogLink}>
                  Читать статью
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaCard}>
          <div>
            <h2>Готовы начать сотрудничество?</h2>
            <p>
              Давайте обсудим вашу задачу и подберём команду, которая поможет достигнуть стратегических результатов.
              Свяжитесь с нами, чтобы запланировать консультацию.
            </p>
          </div>
          <Link to="/kontakty" className={styles.ctaButton}>
            Связаться с нами
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;