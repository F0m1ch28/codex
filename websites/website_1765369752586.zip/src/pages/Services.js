import React, { useState } from 'react';
import { Helmet } from '../helmetContext';
import styles from './Services.module.css';

const serviceCategories = [
  {
    name: 'Стратегический консалтинг',
    description:
      'Разрабатываем стратегические инициативы, помогаем сформировать целевую модель операционной деятельности, оцениваем потенциал трансформации и экономический эффект.',
    highlights: [
      'Диагностика процессов и организационной структуры',
      'Построение целевых бизнес-моделей',
      'Планирование дорожных карт трансформации',
    ],
    image: 'https://picsum.photos/600/400?random=81',
  },
  {
    name: 'Цифровая архитектура',
    description:
      'Проектируем и внедряем цифровые решения: корпоративные платформы, интеграции, автоматизацию ключевых процессов и гибкие инструменты для команд.',
    highlights: [
      'Архитектурный аудит и разработка решений',
      'Внедрение платформ и интеграция систем',
      'Управление качеством данных и API',
    ],
    image: 'https://picsum.photos/600/400?random=82',
  },
  {
    name: 'Аналитика и данные',
    description:
      'Создаём единую экосистему данных, внедряем BI-решения, развиваем компетенции дата-аналитики и настраиваем мониторинг показателей в реальном времени.',
    highlights: [
      'Разработка моделей данных и витрин',
      'Построение BI-панелей и прогнозной аналитики',
      'Запуск дата-офиса и процессы Data Governance',
    ],
    image: 'https://picsum.photos/600/400?random=83',
  },
  {
    name: 'Организационные изменения',
    description:
      'Поддерживаем команды на пути преобразований: формируем культуру сотрудничества, развиваем лидерские команды, запускаем программы обучения и наставничества.',
    highlights: [
      'Программы управления изменениями',
      'Обучение сотрудников и развитие компетенций',
      'Коммуникация и вовлечение команд',
    ],
    image: 'https://picsum.photos/600/400?random=84',
  },
];

const ServicesPage = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Услуги — Лабмьсдсост ось б</title>
        <meta
          name="description"
          content="Комплексные услуги Лабмьсдсост ось б: стратегический консалтинг, цифровая архитектура, аналитика данных и управление изменениями."
        />
        <meta
          name="keywords"
          content="услуги, консалтинг, цифровая архитектура, аналитика, управление изменениями"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Наши услуги</h1>
          <p>
            Мы выстраиваем комплексные программы трансформации: от стратегии и архитектуры до внедрения и поддержки
            людей в процессе изменений. Основа подхода — измеримость, гибкость и практическая ценность.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1200/800?random=15"
            alt="Презентация дорожной карты проекта"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.catalog}>
        <div className={styles.sidebar} role="tablist" aria-label="Категории услуг">
          {serviceCategories.map((category, index) => (
            <button
              key={category.name}
              type="button"
              role="tab"
              aria-selected={activeIndex === index}
              className={`${styles.tabButton} ${activeIndex === index ? styles.tabButtonActive : ''}`}
              onClick={() => setActiveIndex(index)}
            >
              {category.name}
            </button>
          ))}
        </div>
        <div className={styles.details} role="tabpanel">
          <article className={styles.serviceCard}>
            <span className={styles.serviceLabel}>Направление</span>
            <h2>{serviceCategories[activeIndex].name}</h2>
            <p>{serviceCategories[activeIndex].description}</p>
            <ul>
              {serviceCategories[activeIndex].highlights.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <div className={styles.imageWrapper}>
              <img
                src={serviceCategories[activeIndex].image}
                alt={serviceCategories[activeIndex].name}
                loading="lazy"
              />
            </div>
          </article>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;