import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'labmsdsost-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Информация об использовании файлов cookie">
      <div className={styles.content}>
        <p>
          Мы используем файлы cookie, чтобы сайт работал корректно и помогал вам быстрее находить нужную информацию.
          Продолжая пользоваться сайтом, вы соглашаетесь с нашей{' '}
          <a href="/politika-cookie">политикой использования cookie</a>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;