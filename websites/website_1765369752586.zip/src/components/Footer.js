import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.brand}>
        <div className={styles.logo}>
          <span className={styles.logoMark}>Л</span>
          <span className={styles.logoText}>Лабмьсдсост ось б</span>
        </div>
        <p className={styles.description}>
          Мы объединяем экспертизу в области консалтинга, технологий и данных, помогая компаниям уверенно
          двигаться вперёд и раскрывать потенциал трансформации.
        </p>
      </div>
      <div className={styles.columns}>
        <div className={styles.column}>
          <h3 className={styles.heading}>Навигация</h3>
          <ul className={styles.list}>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/uslugi">Услуги</Link></li>
            <li><Link to="/o-kompanii">О компании</Link></li>
            <li><Link to="/kontakty">Контакты</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Правовая информация</h3>
          <ul className={styles.list}>
            <li><Link to="/usloviya-ispolzovaniya">Условия использования</Link></li>
            <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
            <li><Link to="/politika-cookie">Политика cookie</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Контакты</h3>
          <ul className={styles.list}>
            <li>г. Москва, ул. Примерная, д. 1</li>
            <li><a href="tel:+7XXXXXXXXXX">+7 (XXX) XXX-XX-XX</a></li>
            <li><a href="mailto:info@labmsdsost-example.ru">info@labmsdsost-example.ru</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Лабмьсдсост ось б. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;