import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import ContactsPage from './pages/Contact';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import { Helmet } from './helmetContext';

const App = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  }, [location.pathname]);

  return (
    <>
      <Helmet>
        <title>Лабмьсдсост ось б — корпоративные решения</title>
        <meta
          name="description"
          content="Лабмьсдсост ось б — корпоративные консалтинговые и технологические решения, которые помогают компаниям трансформировать процессы и развивать бизнес."
        />
        <meta
          name="keywords"
          content="Лабмьсдсост ось б, корпоративные решения, консалтинг, цифровая трансформация, аналитика"
        />
      </Helmet>
      <div className="app-shell">
        <a href="#main-content" className="skip-link">
          Перейти к основному содержимому
        </a>
        <Header />
        <main id="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/uslugi" element={<ServicesPage />} />
            <Route path="/o-kompanii" element={<AboutPage />} />
            <Route path="/kontakty" element={<ContactsPage />} />
            <Route path="/usloviya-ispolzovaniya" element={<TermsPage />} />
            <Route path="/politika-konfidencialnosti" element={<PrivacyPage />} />
            <Route path="/politika-cookie" element={<CookiePolicyPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
      <CookieBanner />
      <ScrollToTopButton />
    </>
  );
};

export default App;