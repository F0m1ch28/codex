document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            siteNav.classList.toggle("open");
        });

        document.addEventListener("click", (event) => {
            if (!siteNav.contains(event.target) && !navToggle.contains(event.target)) {
                siteNav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", false);
            }
        });
    }

    const dominoItems = document.querySelectorAll(".domino");
    if (dominoItems.length) {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        const index = entry.target.dataset.dominoIndex || 0;
                        entry.target.style.setProperty("--delay", `${index * 120}ms`);
                        entry.target.classList.add("is-visible");
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.18, rootMargin: "0px 0px -60px 0px" }
        );

        dominoItems.forEach((item, index) => {
            item.dataset.dominoIndex = index;
            observer.observe(item);
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAccept = document.querySelector(".cookie-btn.primary");
    const cookieDecline = document.querySelector(".cookie-btn.secondary");
    const storageKey = "pillbogavnCookieChoice";

    if (cookieBanner && cookieAccept && cookieDecline) {
        const preference = localStorage.getItem(storageKey);
        if (!preference) {
            requestAnimationFrame(() => cookieBanner.classList.add("visible"));
        }

        cookieAccept.addEventListener("click", () => {
            localStorage.setItem(storageKey, "accepted");
            cookieBanner.classList.remove("visible");
        });

        cookieDecline.addEventListener("click", () => {
            localStorage.setItem(storageKey, "declined");
            cookieBanner.classList.remove("visible");
        });
    }
});