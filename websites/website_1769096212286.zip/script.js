document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("open");
    });
  }

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  document.querySelectorAll(".observe").forEach(section => observer.observe(section));

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.setAttribute("role", "status");
  toast.textContent = "Message received. Redirecting…";
  document.body.appendChild(toast);

  document.querySelectorAll("form[data-form]").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      toast.classList.add("visible");
      setTimeout(() => {
        toast.classList.remove("visible");
        window.location.href = form.getAttribute("action");
      }, 1800);
    });
  });

  const banner = document.querySelector(".cookie-banner");
  if (banner) {
    const storedChoice = localStorage.getItem("antskas_cookie_choice");
    if (!storedChoice) {
      banner.classList.add("show");
    }
    banner.querySelectorAll("[data-cookie-choice]").forEach(button => {
      button.addEventListener("click", () => {
        const choice = button.dataset.cookieChoice;
        localStorage.setItem("antskas_cookie_choice", choice);
        banner.classList.remove("show");
      });
    });
  }

  const yearSpan = document.getElementById("current-year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
});