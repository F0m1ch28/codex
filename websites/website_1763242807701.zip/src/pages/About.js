import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Anna Müller',
    role: 'Geschäftsführerin & Energieberaterin',
    bio: 'Verantwortet Strategie, Beratung und die Entwicklung maßgeschneiderter Energiekonzepte.',
    focus: 'Strategie & Beratung',
    image: 'https://picsum.photos/400/400?random=201'
  },
  {
    name: 'Lukas Schneider',
    role: 'Leiter Technik & Projektmanagement',
    bio: 'Koordiniert Planung, Baustellenlogistik und die Qualitätssicherung unserer Installationen.',
    focus: 'Projektsteuerung',
    image: 'https://picsum.photos/400/400?random=202'
  },
  {
    name: 'Miriam Becker',
    role: 'Head of Sustainability',
    bio: 'Entwickelt nachhaltige Konzepte, analysiert CO₂-Einsparungen und begleitet ESG-Reporting.',
    focus: 'Nachhaltigkeit',
    image: 'https://picsum.photos/400/400?random=203'
  },
  {
    name: 'Jonas Keller',
    role: 'Leiter Service & Monitoring',
    bio: 'Sorgt für störungsfreie Anlagen, optimiert Leistung und betreut unsere Wartungsverträge.',
    focus: 'Service & Monitoring',
    image: 'https://picsum.photos/400/400?random=204'
  }
];

const certifications = [
  'DIN EN ISO 9001:2015 Qualitätsmanagement',
  'Zertifizierter Installationsbetrieb nach VDE-AR-N 4105',
  'Mitglied im Bundesverband Solarwirtschaft (BSW-Solar)',
  'Zulassung als eingetragener Elektrofachbetrieb der Stadtwerke München',
  'KfW-Fördermittelberater (Energieeffizienz)'
];

const About = () => (
  <>
    <Helmet>
      <title>Über GreenTech Solutions | Ihr Solarprofi aus München</title>
      <meta
        name="description"
        content="Erfahren Sie mehr über die Geschichte, Mission und das Expertenteam von GreenTech Solutions – Solartechnik aus Bayern."
      />
      <link rel="canonical" href="https://www.greentech-solutions.de/ueber-uns" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Über uns</span>
          <h1>GreenTech Solutions – seit 2009 Ihr Solarpartner in Bayern</h1>
          <p>
            Wir sind ein inhabergeführtes Unternehmen aus München und liefern hochwertige Photovoltaik- und
            Speicherlösungen für private, gewerbliche und kommunale Kund:innen. Unser Anspruch: Projekte, die überzeugen,
            weil sie wirtschaftlich sinnvoll, technisch ausgereift und nachhaltig sind.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.story}>
      <div className="container">
        <div className={styles.storyGrid}>
          <article className={styles.storyCard}>
            <h2>Unsere Geschichte</h2>
            <p>
              Gestartet als kleines Ingenieurbüro, sind wir heute eines der führenden PV-Systemhäuser in Süddeutschland.
              Von Beginn an setzen wir auf praxisnahe Beratung, deutsche Qualitätsprodukte und ein eingespieltes
              Expertenteam aus Planung, Elektrotechnik und Dachhandwerk.
            </p>
            <p>
              Mit jedem abgeschlossenen Projekt stärken wir die dezentrale Energieversorgung Bayerns – ob Einfamilienhaus,
              Gewerbepark oder landwirtschaftlicher Betrieb.
            </p>
          </article>
          <article className={styles.storyCard}>
            <h2>Unsere Mission</h2>
            <p>
              Wir gestalten die Energiewende vor Ort. Unser Ziel ist es, die Nutzung von Solarenergie so einfach und
              rentabel wie möglich zu machen. Dafür kombinieren wir technisch hochwertige Komponenten mit klarem Service
              und persönlicher Beratung.
            </p>
            <ul className={styles.storyList}>
              <li>Transparente Kommunikation auf Augenhöhe</li>
              <li>Ganzheitliche Planung inklusive Fördermittelberatung</li>
              <li>Regionale Teams für schnelle Reaktionszeiten</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Was uns antreibt</h2>
          <p>
            Wir glauben daran, dass nachhaltige Energieversorgung nur mit Verantwortung, Präzision und echter
            Partnerschaft funktioniert.
          </p>
        </div>
        <div className={styles.valuesGrid}>
          <article className={styles.valueCard}>
            <span className={styles.valueIcon} aria-hidden="true">
              🤝
            </span>
            <h3>Partnerschaftlichkeit</h3>
            <p>Wir begleiten unsere Kund:innen langfristig und setzen auf Vertrauen statt kurzfristige Abschlüsse.</p>
          </article>
          <article className={styles.valueCard}>
            <span className={styles.valueIcon} aria-hidden="true">
              🧠
            </span>
            <h3>Technische Exzellenz</h3>
            <p>Unser Team verbindet Ingenieurwissen mit Handwerkserfahrung – und liefert Lösungen ohne Kompromisse.</p>
          </article>
          <article className={styles.valueCard}>
            <span className={styles.valueIcon} aria-hidden="true">
              🌱
            </span>
            <h3>Nachhaltiger Impact</h3>
            <p>Wir denken ganzheitlich und behalten die ökologische Wirkung jedes Projekts im Blick.</p>
          </article>
          <article className={styles.valueCard}>
            <span className={styles.valueIcon} aria-hidden="true">
              📈
            </span>
            <h3>Wirtschaftlichkeit</h3>
            <p>Jede Anlage wird individuell kalkuliert – mit realistischen Erträgen und transparenten Einsparungen.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Unser Führungsteam</h2>
          <p>
            Über 60 Spezialist:innen planen, montieren und überwachen Ihre Anlage. Lernen Sie das Kernteam kennen, das
            GreenTech Solutions jeden Tag voranbringt.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`Portrait von ${member.name}`} loading="lazy" />
              <div className={styles.teamDetails}>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.role}</p>
                <p className={styles.teamBio}>{member.bio}</p>
                <span className={styles.teamFocus}>{member.focus}</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.certificates}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Qualität, auf die Sie bauen können</h2>
          <p>
            Unsere Zertifizierungen, Mitgliedschaften und Lizenzen stehen für geprüfte Qualität und absolute
            Sicherheit bei Planung und Umsetzung.
          </p>
        </div>
        <ul className={styles.certificateList}>
          {certifications.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </div>
    </section>

    <section className={styles.callout}>
      <div className="container">
        <div className={styles.calloutBox}>
          <h2>Von München in die ganze Region</h2>
          <p>
            Ob Oberbayern, Franken oder Allgäu – unsere Projektteams sind in ganz Bayern aktiv. Wir kennen die
            regionalen Besonderheiten, Netzbetreiber und Förderprogramme und begleiten Sie mit kurzen Wegen.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default About;