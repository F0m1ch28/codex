document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".nav-links a");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const contactForm = document.querySelector("#contact-form");
  const currentYearEl = document.querySelectorAll("#current-year");
  const storageKey = "nm-cookie-consent";

  // Current year in footer
  const now = new Date().getFullYear();
  currentYearEl.forEach((el) => (el.textContent = now));

  // Mobile navigation toggle
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen.toString());
      navToggle.classList.toggle("active", isOpen);
      navToggle.querySelectorAll("span").forEach((bar, index) => {
        if (isOpen) {
          switch (index) {
            case 0:
              bar.style.transform = "translateY(6px) rotate(45deg)";
              break;
            case 1:
              bar.style.opacity = "0";
              break;
            case 2:
              bar.style.transform = "translateY(-6px) rotate(-45deg)";
              break;
          }
        } else {
          bar.style.transform = "";
          bar.style.opacity = "1";
        }
      });
    });

    navLinks.forEach((link) =>
      link.addEventListener("click", () => {
        if (nav.classList.contains("open")) {
          nav.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
          navToggle.classList.remove("active");
          navToggle.querySelectorAll("span").forEach((bar) => {
            bar.style.transform = "";
            bar.style.opacity = "1";
          });
        }
      })
    );
  }

  // Active navigation highlighting
  const currentPath = window.location.pathname.split("/").pop() || "index.html";
  navLinks.forEach((link) => {
    const linkPath = link.getAttribute("href");
    if (linkPath === currentPath || (currentPath === "" && linkPath === "index.html")) {
      link.classList.add("active");
    }
  });

  // Smooth scroll for on-page anchors
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const targetId = anchor.getAttribute("href").slice(1);
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        event.preventDefault();
        targetEl.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  // Cookie banner logic
  if (cookieBanner) {
    const stored = localStorage.getItem(storageKey);
    if (!stored) {
      setTimeout(() => cookieBanner.classList.add("visible"), 600);
    }

    const handleConsent = (value) => {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.remove("visible");
    };

    acceptBtn?.addEventListener("click", () => handleConsent("accepted"));
    declineBtn?.addEventListener("click", () => handleConsent("declined"));
  }

  // Contact form validation
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const name = formData.get("name")?.trim();
      const email = formData.get("email")?.trim();
      const message = formData.get("message")?.trim();
      const consent = formData.get("consent");
      const messageEl = contactForm.querySelector(".form-message");

      const emailValid = email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

      if (!name || !emailValid || !message || !consent) {
        messageEl.textContent = "Please complete all required fields with valid information.";
        messageEl.style.color = "#dc2626";
        return;
      }

      messageEl.textContent = "Thank you! Your message has been sent. Our team will respond shortly.";
      messageEl.style.color = "#16a34a";
      contactForm.reset();
    });
  }
});