document.addEventListener("DOMContentLoaded", () => {
  const header = document.querySelector(".site-header");
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".nav-link");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const consentKey = "cookieConsentChoice";

  if (header) {
    const handleScroll = () => {
      if (window.scrollY > 24) {
        header.classList.add("scrolled");
      } else {
        header.classList.remove("scrolled");
      }
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
  }

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("nav-open", !expanded);
    });

    document.addEventListener("keyup", (event) => {
      if (event.key === "Escape") {
        navToggle.setAttribute("aria-expanded", "false");
        nav.classList.remove("nav-open");
      }
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        nav.classList.remove("nav-open");
      });
    });
  }

  const hideCookieBanner = () => {
    if (!cookieBanner) return;
    cookieBanner.classList.add("banner-hidden");
    window.setTimeout(() => {
      cookieBanner.setAttribute("hidden", "");
    }, 320);
  };

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(consentKey);

    if (storedChoice) {
      hideCookieBanner();
    } else {
      cookieBanner.removeAttribute("hidden");
    }

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => {
        localStorage.setItem(consentKey, "accepted");
        hideCookieBanner();
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener("click", () => {
        localStorage.setItem(consentKey, "declined");
        hideCookieBanner();
      });
    }
  }
});