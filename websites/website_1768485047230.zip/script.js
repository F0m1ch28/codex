document.addEventListener('DOMContentLoaded', () => {
    const mobileToggle = document.querySelector('.mobile-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (mobileToggle && navLinks) {
        mobileToggle.addEventListener('click', () => {
            const isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
            mobileToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navLinks.classList.toggle('is-open');
            document.body.classList.toggle('menu-open', !isExpanded);
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mobileToggle.setAttribute('aria-expanded', 'false');
                navLinks.classList.remove('is-open');
                document.body.classList.remove('menu-open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('genusCookieChoice');
        if (storedChoice) {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.remove('hidden');
        }

        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(button => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const action = button.getAttribute('data-cookie-action');
                localStorage.setItem('genusCookieChoice', action);
                cookieBanner.classList.add('hidden');
            });
        });
    }
});