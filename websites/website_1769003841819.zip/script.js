document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");
    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            primaryNav.classList.toggle("nav-open");
        });
        primaryNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute("aria-expanded", "false");
                    primaryNav.classList.remove("nav-open");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const storageKey = "ns95_cookie_consent";
    if (cookieBanner) {
        const storedConsent = localStorage.getItem(storageKey);
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
        }
        cookieBanner.querySelectorAll("button[data-consent]").forEach((button) => {
            button.addEventListener("click", () => {
                const value = button.getAttribute("data-consent");
                localStorage.setItem(storageKey, value);
                cookieBanner.classList.add("hidden");
            });
        });
    }
});