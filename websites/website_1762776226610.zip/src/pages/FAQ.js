import React from "react";
import { Helmet } from "react-helmet";

const faqData = [
  {
    question: "Gibt es eine mobile App?",
    answer:
      "Unsere Tools sind responsive Webanwendungen und funktionieren auf Smartphone, Tablet und Desktop. Für Notion und Google Sheets kannst du native Apps nutzen.",
  },
  {
    question: "Welche Zahlungsmethoden unterstützt ihr?",
    answer:
      "SparWerk stellt aktuell kostenlose Vorlagen und Workflows zur Verfügung. Sollten zukünftig kostenpflichtige Workshops starten, informieren wir rechtzeitig.",
  },
  {
    question: "Kann ich meine Daten exportieren?",
    answer:
      "Ja. Alle Daten lassen sich als CSV, PDF oder JSON exportieren. Du kannst jederzeit entscheiden, welche Daten du speicherst.",
  },
  {
    question: "Wie funktioniert das Thema Datenschutz?",
    answer:
      "Wir arbeiten nach DSGVO-Standards, hosten unsere Daten in der EU und nutzen nur notwendige Cookies. Unser Download-Tracking funktioniert anonym ohne Cookies.",
  },
];

const FAQ = () => (
  <>
    <Helmet>
      <title>FAQ | SparWerk</title>
      <meta
        name="description"
        content="Antworten auf häufige Fragen zu SparWerk: Mobile Nutzung, Datenschutz, Datenexport und weitere Themen."
      />
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-5xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Hilfe &amp; FAQ</h1>
        <p className="mt-4 text-lg text-slate-300">
          Hier findest du Antworten auf häufig gestellte Fragen. Dein Thema fehlt? Kontaktiere uns gerne.
        </p>
      </div>
    </section>
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-4xl px-6 space-y-4">
        {faqData.map((item) => (
          <details key={item.question} className="faq-item">
            <summary className="faq-question">{item.question}</summary>
            <p className="faq-answer">{item.answer}</p>
          </details>
        ))}
      </div>
    </section>
  </>
);

export default FAQ;