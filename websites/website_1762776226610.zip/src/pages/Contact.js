import React, { useState } from "react";
import { Helmet } from "react-helmet";

const Contact = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: "",
    topic: "Beratung",
  });
  const [feedback, setFeedback] = useState({ message: "", type: "" });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setFeedback({ message: "Bitte alle Pflichtfelder ausfüllen.", type: "error" });
      return;
    }
    const emailRegex =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\\.,;:\s@"]+\.)+[^<>()[\]\\.,;:\s@"]{2,})$/i;
    if (!emailRegex.test(form.email)) {
      setFeedback({ message: "Bitte eine gültige E-Mail Adresse verwenden.", type: "error" });
      return;
    }
    setFeedback({
      message:
        "Danke für deine Nachricht! Wir melden uns in der Regel innerhalb von zwei Werktagen.",
      type: "success",
    });
    setForm({ name: "", email: "", message: "", topic: "Beratung" });
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | SparWerk</title>
        <meta
          name="description"
          content="Kontaktiere SparWerk für Workshops, Projektbegleitung oder Support rund um dein Haushaltsbudget. Wir melden uns innerhalb von zwei Werktagen."
        />
      </Helmet>
      <section className="bg-[#0B1020] py-20 text-white">
        <div className="mx-auto max-w-4xl px-6">
          <h1 className="font-display text-4xl font-bold tracking-tight">Kontakt</h1>
          <p className="mt-4 text-lg text-slate-300">
            Du hast Fragen zu unseren Vorlagen, möchtest eine Workshop-Anfrage stellen oder benötigst Support? Wir sind für dich da.
          </p>
        </div>
      </section>
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-4xl px-6">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-xl">
            <form className="space-y-6" onSubmit={handleSubmit} noValidate>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label htmlFor="name" className="form-label">
                    Name *
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={form.name}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="Vor- und Nachname"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className="form-label">
                    E-Mail *
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="dein.mail@example.de"
                    required
                  />
                </div>
              </div>
              <div>
                <label htmlFor="topic" className="form-label">
                  Anliegen
                </label>
                <select
                  id="topic"
                  name="topic"
                  value={form.topic}
                  onChange={handleChange}
                  className="form-input"
                >
                  <option value="Beratung">Beratung</option>
                  <option value="Vorlagen">Vorlagen</option>
                  <option value="Workshop">Workshop</option>
                  <option value="Community">Community</option>
                </select>
              </div>
              <div>
                <label htmlFor="message" className="form-label">
                  Nachricht *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  className="form-input"
                  placeholder="Womit können wir dich unterstützen?"
                  rows="5"
                  required
                />
              </div>
              <button
                type="submit"
                className="rounded-full bg-[#14B8A6] px-6 py-3 text-sm font-semibold uppercase tracking-[0.25em] text-white transition hover:bg-[#0d9488]"
              >
                Nachricht senden
              </button>
              {feedback.message && (
                <p
                  className={`text-sm ${
                    feedback.type === "success" ? "text-[#14B8A6]" : "text-[#F43F5E]"
                  }`}
                  role="status"
                >
                  {feedback.message}
                </p>
              )}
            </form>
            <div className="mt-10 text-sm text-slate-600">
              <h2 className="text-base font-semibold text-[#0B1020]">Kontaktinformationen</h2>
              <p className="mt-3">
                Sobald uns vom Auftraggeber konkrete Kontaktangaben vorliegen, werden sie hier veröffentlicht.
              </p>
              <p className="mt-3">
                Hinweis: Wir setzen keine telefonische Hotline ein, um nachhaltige Antworten mit hoher Qualität zu gewährleisten.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;