import React from "react";
import { Helmet } from "react-helmet";

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum | SparWerk</title>
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-5xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Impressum</h1>
        <p className="mt-4 text-lg text-slate-300">
          Rechtliche Angaben zur Anbieterkennzeichnung gemäß § 5 TMG. Sobald uns vollständige Daten vorliegen, werden sie ergänzt.
        </p>
      </div>
    </section>
    <section className="mx-auto max-w-5xl px-6 py-16 text-sm leading-relaxed text-slate-700">
      <h2 className="text-2xl font-semibold text-[#0B1020]">Angaben gemäß § 5 TMG</h2>
      <p className="mt-3">
        Die vollständige Anschrift, Kontaktmöglichkeiten und vertretungsberechtigte Personen werden nachgereicht, sobald sie vom Auftraggeber zur Verfügung gestellt werden.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">Haftung für Inhalte</h2>
      <p className="mt-3">
        Wir prüfen unsere Inhalte sorgfältig, übernehmen jedoch keine Haftung für Richtigkeit, Vollständigkeit und Aktualität. Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen bleiben hiervon unberührt.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">Urheberrecht</h2>
      <p className="mt-3">
        Die durch SparWerk erstellten Inhalte und Werke unterliegen dem deutschen Urheberrecht. Eine Vervielfältigung bedarf unserer schriftlichen Zustimmung.
      </p>
    </section>
  </>
);

export default Impressum;