import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import { Download } from "lucide-react";

const templates = [
  {
    title: "Zero-Based Monatsplan (PDF)",
    type: "PDF",
    goal: "Monatsbudget",
    complexity: "Mittel",
    duration: "45 Minuten Setup",
  },
  {
    title: "Studentenbudget Notion Board",
    type: "Notion",
    goal: "Studierendenbudget",
    complexity: "Einfach",
    duration: "30 Minuten",
  },
  {
    title: "Familien Haushaltsbuch (Excel)",
    type: "Excel",
    goal: "Familie",
    complexity: "Fortgeschritten",
    duration: "60 Minuten",
  },
  {
    title: "Abo-Checkliste & Kündigungsplan",
    type: "PDF",
    goal: "Fixkosten senken",
    complexity: "Einfach",
    duration: "20 Minuten",
  },
  {
    title: "Cashflow Tracker (CSV + Google Sheet)",
    type: "CSV",
    goal: "Selbstständigkeit",
    complexity: "Mittel",
    duration: "40 Minuten",
  },
  {
    title: "Spar-Challenge Karten (Print)",
    type: "PDF",
    goal: "Spar-Challenge",
    complexity: "Einfach",
    duration: "10 Minuten",
  },
];

const filters = ["Alle", "PDF", "Excel", "Notion", "CSV"];

const Vorlagen = () => {
  const [activeFilter, setActiveFilter] = useState("Alle");

  const filteredTemplates = useMemo(() => {
    if (activeFilter === "Alle") return templates;
    return templates.filter((item) => item.type === activeFilter);
  }, [activeFilter]);

  const handleDownload = (templateTitle) => {
    console.log("Download Template:", templateTitle);
  };

  return (
    <>
      <Helmet>
        <title>Vorlagen | SparWerk</title>
        <meta
          name="description"
          content="Kostenlose und modulare Vorlagen von SparWerk: PDF, Excel, Notion und CSV Templates für Zero-Based Budgeting, Umschläge, Abo-Checklisten und Spar-Challenges."
        />
      </Helmet>
      <section className="bg-[#0B1020] py-20 text-white">
        <div className="mx-auto max-w-6xl px-6">
          <h1 className="font-display text-4xl font-bold tracking-tight">Vorlagen</h1>
          <p className="mt-4 text-lg text-slate-300">
            Unsere Vorlagen sind modular aufgebaut. Wähle Medium, Ziel und Komplexität aus. Jeder Download ist DSGVO-konform und wird anonym gezählt.
          </p>
        </div>
      </section>
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="flex flex-wrap gap-3">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`rounded-full border px-4 py-2 text-sm transition ${
                  activeFilter === filter
                    ? "border-[#14B8A6] bg-[#14B8A6]/10 text-[#0B1020]"
                    : "border-slate-200 text-slate-600 hover:border-[#14B8A6]"
                }`}
                aria-pressed={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className="mt-10 grid gap-8 md:grid-cols-2">
            {filteredTemplates.map((template) => (
              <article key={template.title} className="card-template">
                <div>
                  <span className="inline-block rounded-full bg-[#14B8A6]/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-[#14B8A6]">
                    {template.type}
                  </span>
                  <h2 className="mt-3 text-2xl font-semibold text-[#0B1020]">
                    {template.title}
                  </h2>
                  <div className="mt-3 grid gap-2 text-sm text-slate-600 sm:grid-cols-3">
                    <p>Ziel: {template.goal}</p>
                    <p>Komplexität: {template.complexity}</p>
                    <p>Setup: {template.duration}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleDownload(template.title)}
                  className="inline-flex items-center justify-center rounded-full bg-[#F43F5E] px-5 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-white transition hover:bg-[#e11d48]"
                >
                  Download <Download className="ml-2 h-4 w-4" />
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Vorlagen;