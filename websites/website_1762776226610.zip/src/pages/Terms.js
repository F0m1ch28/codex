import React from "react";
import { Helmet } from "react-helmet";

const Terms = () => (
  <>
    <Helmet>
      <title>Nutzungsbedingungen | SparWerk</title>
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-5xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Allgemeine Nutzungsbedingungen</h1>
        <p className="mt-4 text-lg text-slate-300">
          Transparente Rahmenbedingungen für die Nutzung der SparWerk Plattform, Tools und Vorlagen.
        </p>
      </div>
    </section>
    <section className="mx-auto max-w-5xl px-6 py-16 text-sm leading-relaxed text-slate-700">
      <h2 className="text-2xl font-semibold text-[#0B1020]">1. Geltungsbereich</h2>
      <p className="mt-3">
        Diese Nutzungsbedingungen regeln die Bereitstellung und Nutzung der SparWerk Services. Sobald uns konkrete Anbieterinformationen vorliegen, werden sie ergänzt.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">2. Nutzung der Inhalte</h2>
      <p className="mt-3">
        Vorlagen, Tools und Texte dürfen für private Budgetplanung verwendet werden. Eine Weitergabe oder kommerzielle Nutzung bedarf unserer vorherigen Zustimmung.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">3. Haftung</h2>
      <p className="mt-3">
        SparWerk bietet Hilfestellungen und Werkzeuge, übernimmt jedoch keine Gewähr für finanzielle Ergebnisse. Wir fördern eigenverantwortliche Entscheidungen.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">4. Änderung der Bedingungen</h2>
      <p className="mt-3">
        Wir behalten uns vor, die Nutzungsbedingungen anzupassen. Änderungen werden transparent auf dieser Seite kommuniziert.
      </p>
    </section>
  </>
);

export default Terms;