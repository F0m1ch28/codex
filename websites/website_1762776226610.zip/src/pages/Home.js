import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import {
  ArrowRight,
  CheckCircle2,
  Download,
  Layers,
  LineChart,
  Sparkles,
  Target,
} from "lucide-react";

const statsTargets = [
  { label: "Haushalte unterstützt", value: 12500 },
  { label: "Vorlagen Downloads", value: 8600 },
  { label: "Workflows dokumentiert", value: 290 },
  { label: "Community Feedbacks", value: 970 },
];

const testimonials = [
  {
    name: "Lena F.",
    role: "Freelancerin & Mama",
    quote:
      "Mit der Zero-Based Vorlage von SparWerk habe ich endlich einen klaren Blick auf unsere Familienausgaben. Der Umschlag-Workflow ist in Notion perfekt dokumentiert.",
  },
  {
    name: "Omar H.",
    role: "Student & Werkstudent",
    quote:
      "Die Spar-Challenge Karten motivieren mich, dranzubleiben. Besonders der Abo-Scanner hat mir geholfen, unnötige Abbuchungen zu beenden.",
  },
  {
    name: "Katharina S.",
    role: "Produktmanagerin",
    quote:
      "Mir gefallen die modularen Templates. Ich kombiniere den Ziel-Tracker mit dem Pay-Yourself-First Planer und habe endlich Routine in meiner Budgetplanung.",
  },
];

const projects = [
  {
    id: 1,
    title: "Budget-Setup für Studierende",
    category: "Studierende",
    description:
      "Wöchentlicher Ausgaben-Tracker + Semesterziele + Reminder für Rücklagen. Ideal für BAföG und Nebenjob-Mix.",
    image: "https://picsum.photos/1200/800?random=41",
  },
  {
    id: 2,
    title: "Familien-Haushaltsbuch 2+1",
    category: "Familie",
    description:
      "Haushaltsboard mit Kategorien-Editor, Gemeinschaftskonto-Ansichten und Wochenplänen für variable Kosten.",
    image: "https://picsum.photos/1200/800?random=42",
  },
  {
    id: 3,
    title: "Minimalistisches Budget-Set",
    category: "Minimalismus",
    description:
      "Monatsübersicht, 12 Envelopes Template und Fokus-Tracker für Konsumfreie Tage. Für alle, die Klarheit lieben.",
    image: "https://picsum.photos/1200/800?random=43",
  },
  {
    id: 4,
    title: "Freelance Cashflow Checking",
    category: "Selbstständige",
    description:
      "Kombination aus Einnahmenkalender, Steuer-Rücklage und Ziel-Tracking für unregelmäßige Einkommen.",
    image: "https://picsum.photos/1200/800?random=44",
  },
];

const faqItems = [
  {
    question: "Wie starte ich mit Zero-Based Budgeting bei SparWerk?",
    answer:
      "Starte mit unserem Quick-Check im Hero-Bereich und wähle die Zero-Based Vorlage in PDF oder Notion. Im How-To Abschnitt erhältst du Schritt-für-Schritt Anleitungen inklusive Video-Link.",
  },
  {
    question: "Brauche ich spezielle Software für die Vorlagen?",
    answer:
      "Nein. Wir bieten Vorlagen für PDF, Excel, Google Sheets, Notion und CSV. Du wählst das System, das in deinen Alltag passt. Alle Tools sind DSGVO-konform nutzbar.",
  },
  {
    question: "Kann ich SparWerk im Team oder mit meinem Partner nutzen?",
    answer:
      "Ja. Viele Vorlagen besitzen kollaborative Ansichten. Unsere Workflows beschreiben, wie du Transparenz schaffst und Rollen verteilst—ideal für Paare, WG oder Familien.",
  },
  {
    question: "Wie funktioniert das Download-Tracking ohne Cookies?",
    answer:
      "Downloads werden anonym gezählt, indem wir serverseitig die Anzahl erhöhen. Es werden keine Nutzerprofile erstellt und keine Cookies gesetzt.",
  },
];

const teamMembers = [
  {
    name: "Franziska Müller",
    role: "Head of Budget Design",
    bio: "Finanzcoach mit Fokus auf Haushaltsplanung und minimalistische Workflows. Entwickelt bei SparWerk modulare Templates.",
    image: "https://picsum.photos/400/400?random=31",
  },
  {
    name: "Jonas Becker",
    role: "Product Engineer",
    bio: "Verantwortlich für Tool-Integrationen und DSGVO-konforme Tracking-Lösungen. Liebt nachvollziehbare Datenflüsse.",
    image: "https://picsum.photos/400/400?random=32",
  },
  {
    name: "Mira Schneider",
    role: "Community & Methoden",
    bio: "Leitet Workshops, sammelt Community-Feedback und übersetzt Methoden wie 50/30/20 in praktische Leitfäden.",
    image: "https://picsum.photos/400/400?random=33",
  },
];

const processSteps = [
  {
    title: "Check-In",
    description:
      "Kurztest zu Lebensphase & Prioritäten. Du erhältst eine persönliche Auswahl an Vorlagen und Methoden.",
    icon: <Sparkles className="h-6 w-6 text-[#14B8A6]" />,
  },
  {
    title: "Methoden anwenden",
    description:
      "Zero-Based, Umschlag oder Pay-Yourself-First: Wir führen dich Schritt für Schritt durch die Umsetzung.",
    icon: <Layers className="h-6 w-6 text-[#14B8A6]" />,
  },
  {
    title: "Tools verknüpfen",
    description:
      "Verbinde Tracker, Kategorien und Ziele in deinem bevorzugten Workspace. Alles modular und DSGVO-konform.",
    icon: <LineChart className="h-6 w-6 text-[#14B8A6]" />,
  },
  {
    title: "Review & Fokus",
    description:
      "Setze Review-Reminder, tracke Fortschritte und feiere Spar-Erfolge mit der Community.",
    icon: <Target className="h-6 w-6 text-[#14B8A6]" />,
  },
];

const Home = () => {
  const [stats, setStats] = useState(statsTargets.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("Alle");

  useEffect(() => {
    let animationFrame;
    const start = performance.now();

    const duration = 1400;
    const animate = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      const updated = statsTargets.map((item, index) =>
        Math.floor(progress * item.value)
      );
      setStats(updated);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };
    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === "Alle"
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  const schemaData = useMemo(
    () => ({
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "HowTo",
          "name": "Zero-Based Budgeting mit SparWerk",
          "description":
            "Schritt-für-Schritt-Anleitung, um dein Zero-Based-Budget digital mit SparWerk zu strukturieren.",
          "image": "https://picsum.photos/1600/900?random=1",
          "totalTime": "PT45M",
          "supply": [
            { "@type": "HowToSupply", "name": "SparWerk Zero-Based Vorlage" },
            { "@type": "HowToSupply", "name": "Aktuelle Kontoauszüge" }
          ],
          "tool": [
            { "@type": "HowToTool", "name": "SparWerk Kategorien-Editor" },
            { "@type": "HowToTool", "name": "SparWerk Ausgaben-Tracker" }
          ],
          "step": [
            {
              "@type": "HowToStep",
              "name": "Budgetrahmen analysieren",
              "text": "Liste deine Einnahmen und fixe Ausgaben auf."
            },
            {
              "@type": "HowToStep",
              "name": "Jeden Euro verplanen",
              "text": "Ordne jedem Euro eine Aufgabe zu – nach Priorität."
            },
            {
              "@type": "HowToStep",
              "name": "Review & Anpassung",
              "text": "Tracke Ausgaben mit dem SparWerk Tracker und passe wöchentlich an."
            }
          ]
        },
        {
          "@type": "SoftwareApplication",
          "name": "SparWerk Budget Studio",
          "operatingSystem": "Web",
          "applicationCategory": "FinanceApplication",
          "offers": { "@type": "Offer", "price": "0", "priceCurrency": "EUR" },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "reviewCount": "187"
          }
        }
      ]
    }),
    []
  );

  return (
    <>
      <Helmet>
        <title>SparWerk | Digitale Budget-Werkstatt für deinen Alltag</title>
        <meta
          name="description"
          content="SparWerk begleitet dich mit Zero-Based Budgeting, Umschlagmethode und smarten Tools. Hol dir modulare Vorlagen, Tracker und Schritt-für-Schritt-Anleitungen für dein Haushaltsbudget."
        />
        <meta
          name="keywords"
          content="Zero-Based-Budget, Umschlagmethode, Budget-App, Haushaltsbuch-Vorlage, Spar-Challenge, Ausgaben-Tracking, Minimalismus, Studentenbudget, SparWerk"
        />
        <script type="application/ld+json">{JSON.stringify(schemaData)}</script>
      </Helmet>

      <section className="relative overflow-hidden bg-[#0B1020] text-white">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Moderne Werkbank für Budgetplanung"
            className="h-full w-full object-cover opacity-30"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0B1020]/85 via-[#0B1020]/90 to-[#0B1020]/70" />
        </div>
        <div className="relative mx-auto flex max-w-7xl flex-col gap-12 px-6 py-20 lg:flex-row lg:items-center lg:justify-between lg:px-10">
          <div className="max-w-2xl space-y-6">
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/40 bg-[#0B1020]/80 px-4 py-2 text-xs uppercase tracking-[0.25em]">
              Finanzwerkstatt für deinen Alltag
            </span>
            <h1 className="font-display text-4xl font-bold leading-tight tracking-tight sm:text-5xl">
              Baue dein Budget-Set in weniger als 45 Minuten.
            </h1>
            <p className="text-lg text-slate-300 sm:text-xl">
              Kombiniere Methoden, Tools und Vorlagen, die zu deiner Lebensphase passen. SparWerk führt dich von der ersten Analyse bis zur Revue.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Link
                to="/vorlagen"
                className="inline-flex items-center justify-center rounded-full bg-[#F43F5E] px-6 py-3 text-sm font-semibold uppercase tracking-[0.25em] text-white transition hover:-translate-y-1 hover:bg-[#e11d48]"
              >
                Vorlagen auswählen <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
              <Link
                to="/methoden"
                className="inline-flex items-center justify-center rounded-full border border-slate-500 px-6 py-3 text-sm font-semibold uppercase tracking-[0.25em] text-slate-200 transition hover:border-emerald-400 hover:text-emerald-300"
              >
                Methoden entdecken
              </Link>
            </div>
            <div className="flex flex-wrap gap-6 pt-2 text-sm text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                DSGVO-konform
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                Download-Tracking ohne Cookies
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                Community Feedback integriert
              </div>
            </div>
          </div>
          <div className="group relative max-w-xl">
            <div className="relative overflow-hidden rounded-3xl border border-emerald-100/30 bg-white/5 p-6 backdrop-blur">
              <div className="space-y-6">
                <div>
                  <h2 className="font-display text-xl text-white">
                    Schnellstart: dein Budget-Profil
                  </h2>
                  <p className="text-sm text-slate-300">
                    Welche Priorität steht im Fokus? Wähle deinen Bereich – wir empfehlen dir passende Templates.
                  </p>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {["Studium", "Familie", "Minimalismus", "Selbstständigkeit"].map(
                    (item) => (
                      <button
                        key={item}
                        type="button"
                        className="card-option"
                        aria-label={`Budget-Fokus ${item}`}
                      >
                        <span>{item}</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    )
                  )}
                </div>
                <div className="rounded-2xl bg-slate-900/40 p-4">
                  <h3 className="font-mono text-xs uppercase tracking-[0.3em] text-emerald-300">
                    Ergebnis-Vorschau
                  </h3>
                  <ul className="mt-3 space-y-2 text-sm text-slate-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-400" />
                      Zero-Based Setup &amp; Kategorien-Editor
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-400" />
                      Automatische Spar-Challenge Vorlage
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-400" />
                      Check-in Reminder für Reviews
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="pointer-events-none absolute -bottom-8 -right-8 h-40 w-40 rounded-full bg-[#14B8A6]/30 blur-3xl transition group-hover:bg-[#F43F5E]/40" />
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat, index) => (
              <div
                key={statsTargets[index].label}
                className="rounded-3xl border border-slate-100 bg-slate-50 p-6 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <p className="text-3xl font-bold text-[#0B1020]">
                  {stat.toLocaleString("de-DE")}
                </p>
                <p className="mt-2 text-sm uppercase tracking-[0.2em] text-slate-600">
                  {statsTargets[index].label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#F8FAFC] py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="max-w-2xl">
            <h2 className="section-title">Was SparWerk besonders macht</h2>
            <p className="section-description">
              Wir verbinden Finanzmethoden mit einer Werkstatt-Ästhetik: klare Flächen, nachvollziehbare Workflows und modulare Bausteine, die du kombinieren kannst.
            </p>
          </div>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {[
              {
                title: "Methoden, die funktionieren",
                description:
                  "Zero-Based, 50/30/20, Umschlag oder Pay-Yourself-First – wir liefern dir Anleitungen und Vergleichstabellen für sinnvolle Entscheidungen.",
              },
              {
                title: "Tools mit Fokus",
                description:
                  "Tracker, Kategorien-Editor, Abo-Screening und Ziel-Board: verknüpfe deine Budgets nahtlos mit Notion, Excel oder PDFs.",
              },
              {
                title: "Community Feedback",
                description:
                  "Wir verbessern Vorlagen laufend mit Rückmeldungen aus der SparWerk Community. Du profitierst direkt von praxiserprobten Setups.",
              },
            ].map((service) => (
              <div key={service.title} className="card-feature">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#14B8A6]/10 text-[#14B8A6]">
                  <Sparkles className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold text-[#0B1020]">{service.title}</h3>
                <p className="text-sm text-slate-600">{service.description}</p>
                <Link
                  to="/services"
                  className="inline-flex items-center text-sm font-medium text-[#14B8A6] transition hover:text-[#0d9488]"
                >
                  Mehr erfahren <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="max-w-2xl">
            <h2 className="section-title">Dein Workflow in vier Schritten</h2>
            <p className="section-description">
              Unsere Prozesse sind transparent dokumentiert: Du siehst jederzeit, warum welcher Schritt folgt.
            </p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {processSteps.map((step, index) => (
              <div key={step.title} className="card-process">
                <div className="flex items-center justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#14B8A6]/10">
                    {step.icon}
                  </div>
                  <span className="text-sm font-semibold text-slate-500">
                    Schritt {index + 1}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-[#0B1020]">{step.title}</h3>
                <p className="text-sm text-slate-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#0B1020] py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6 text-white">
          <div className="flex flex-col gap-10 lg:flex-row lg:items-center">
            <div className="lg:w-1/2">
              <h2 className="section-title text-white">Stimmen aus der Community</h2>
              <p className="section-description text-slate-300">
                Echtes Feedback aus Workshops, Remote-Challenges und Beta-Tests. Kein Marketingversprechen, sondern nachvollziehbare Ergebnisse.
              </p>
              <div className="mt-6 flex items-center gap-4 text-sm text-slate-300">
                <div className="flex -space-x-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#14B8A6]/30 text-sm font-semibold text-white">
                    F
                  </span>
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#14B8A6]/30 text-sm font-semibold text-white">
                    O
                  </span>
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#14B8A6]/30 text-sm font-semibold text-white">
                    K
                  </span>
                </div>
                <span>4,8 ★ auf Basis von 187 Bewertungen</span>
              </div>
            </div>
            <div className="lg:w-1/2">
              <div className="relative overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/60 p-8 shadow-xl">
                <blockquote className="text-lg leading-relaxed text-slate-100">
                  “{testimonials[currentTestimonial].quote}”
                </blockquote>
                <div className="mt-6 text-sm text-slate-300">
                  <p className="font-semibold">
                    {testimonials[currentTestimonial].name}
                  </p>
                  <p>{testimonials[currentTestimonial].role}</p>
                </div>
                <div className="mt-8 flex items-center justify-center gap-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      type="button"
                      className={`h-2.5 w-2.5 rounded-full transition ${
                        index === currentTestimonial
                          ? "w-6 bg-[#14B8A6]"
                          : "bg-slate-600 hover:bg-slate-400"
                      }`}
                      aria-label={`Testimonial ${index + 1}`}
                      onClick={() => setCurrentTestimonial(index)}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="max-w-2xl">
            <h2 className="section-title">SparWerk Projekte &amp; Sets</h2>
            <p className="section-description">
              Entdecke Budget-Setups für unterschiedliche Lebenslagen. Filtere nach Lebensphase oder Fokus und aktiviere dein persönliches Paket.
            </p>
          </div>
          <div className="mt-10 flex flex-wrap gap-3">
            {["Alle", "Studierende", "Familie", "Minimalismus", "Selbstständige"].map(
              (filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setProjectFilter(filter)}
                  className={`rounded-full border px-4 py-2 text-sm transition ${
                    projectFilter === filter
                      ? "border-[#14B8A6] bg-[#14B8A6]/10 text-[#0B1020]"
                      : "border-slate-200 text-slate-600 hover:border-[#14B8A6]"
                  }`}
                  aria-pressed={projectFilter === filter}
                >
                  {filter}
                </button>
              )
            )}
          </div>
          <div className="mt-10 grid gap-8 lg:grid-cols-2">
            {filteredProjects.map((project) => (
              <article key={project.id} className="card-project">
                <div className="overflow-hidden rounded-2xl">
                  <img
                    src={project.image}
                    alt={`Budget-Projekt: ${project.title}`}
                    className="h-56 w-full object-cover transition duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                </div>
                <div className="space-y-3">
                  <span className="inline-flex items-center rounded-full bg-[#14B8A6]/10 px-3 py-1 text-xs font-medium uppercase tracking-[0.2em] text-[#14B8A6]">
                    {project.category}
                  </span>
                  <h3 className="text-2xl font-semibold text-[#0B1020]">{project.title}</h3>
                  <p className="text-sm text-slate-600">{project.description}</p>
                  <Link
                    to="/vorlagen"
                    className="inline-flex items-center text-sm font-semibold text-[#14B8A6] transition hover:text-[#0d9488]"
                  >
                    Vorlagen ansehen <Download className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="max-w-2xl">
            <h2 className="section-title">People @ SparWerk</h2>
            <p className="section-description">
              Wir sind ein interdisziplinäres Team aus Finanzcoaches, Product Engineers und Community Manager:innen, die Budget-Design lieben.
            </p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {teamMembers.map((member) => (
              <div key={member.name} className="card-team">
                <img
                  src={member.image}
                  alt={`Portrait von ${member.name}`}
                  className="h-56 w-full rounded-2xl object-cover"
                  loading="lazy"
                />
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-[#0B1020]">{member.name}</h3>
                  <p className="text-sm font-medium text-[#14B8A6]">{member.role}</p>
                  <p className="text-sm text-slate-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8">
            <Link
              to="/about"
              className="inline-flex items-center text-sm font-semibold text-[#14B8A6] transition hover:text-[#0d9488]"
            >
              Team kennenlernen <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="bg-[#F8FAFC] py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="max-w-2xl">
            <h2 className="section-title">FAQ: Antworten aus der Werkstatt</h2>
            <p className="section-description">
              Wir sammeln jede häufige Frage und pflegen sie hier – transparent, nachvollziehbar, ohne Buzzwords.
            </p>
          </div>
          <div className="mt-10 space-y-4">
            {faqItems.map((item) => (
              <details key={item.question} className="faq-item">
                <summary className="faq-question">{item.question}</summary>
                <p className="faq-answer">{item.answer}</p>
              </details>
            ))}
          </div>
          <div className="mt-8">
            <Link
              to="/faq"
              className="inline-flex items-center text-sm font-semibold text-[#14B8A6] transition hover:text-[#0d9488]"
            >
              Weitere Fragen <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="flex flex-col gap-12 lg:flex-row lg:items-center lg:justify-between">
            <div className="lg:w-1/2">
              <h2 className="section-title">Insights &amp; Blog</h2>
              <p className="section-description">
                Wir dokumentieren Tests, Methoden und Analysen – mit Fokus auf den deutschen Markt und reale Erfahrungswerte.
              </p>
              <Link
                to="/blog"
                className="inline-flex items-center rounded-full border border-[#14B8A6] px-5 py-2 text-sm font-semibold text-[#14B8A6] transition hover:bg-[#14B8A6] hover:text-white"
              >
                Zum Blog
              </Link>
            </div>
            <div className="grid gap-6 lg:w-1/2">
              {[
                {
                  title: "Zero-Based Budgeting: So klappt die Umsetzung im Alltag",
                  link: "/blog/zero-based-budget-de",
                },
                {
                  title: "Umschlagmethode digital: Envelopes in Notion &amp; Excel nachbilden",
                  link: "/blog/umschlagmethode-digital",
                },
                {
                  title: "Abos kündigen: Checkliste &amp; Reminder für wiederkehrende Kosten",
                  link: "/blog/abos-kuendigen-check",
                },
              ].map((post) => (
                <Link key={post.link} to={post.link} className="card-blog">
                  <h3 className="text-lg font-semibold text-[#0B1020]">{post.title}</h3>
                  <span className="inline-flex items-center text-sm font-medium text-[#14B8A6]">
                    Weiterlesen <ArrowRight className="ml-2 h-4 w-4" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="mx-auto max-w-6xl px-6">
          <div className="rounded-3xl border border-emerald-200/40 bg-gradient-to-br from-[#14B8A6] via-[#0B1020] to-[#0B1020] p-10 text-white shadow-xl">
            <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
              <div className="max-w-2xl space-y-4">
                <span className="inline-flex items-center gap-2 rounded-full border border-white/20 px-3 py-1 text-xs uppercase tracking-[0.25em]">
                  Ready, Set, Budget
                </span>
                <h2 className="font-display text-3xl font-bold leading-tight">
                  Starte deine Budget-Werkstatt heute. Gratis Vorlagen, klare Methoden – ohne versteckte Versprechen.
                </h2>
                <p className="text-sm text-slate-200">
                  Wähle ein Starter-Set, das zu dir passt. Vollständig auf Deutsch, supportet von unserer Community und kontinuierlich verbessert.
                </p>
              </div>
              <div className="flex flex-col gap-4 sm:flex-row">
                <Link
                  to="/vorlagen"
                  className="inline-flex items-center justify-center rounded-full bg-white px-6 py-3 text-sm font-semibold uppercase tracking-[0.25em] text-[#0B1020] transition hover:-translate-y-1 hover:bg-slate-100"
                >
                  Vorlagen entdecken
                </Link>
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center rounded-full border border-white/40 px-6 py-3 text-sm font-semibold uppercase tracking-[0.25em] text-white transition hover:border-white hover:bg-white/10"
                >
                  Beratung anfragen
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-[#F8FAFC] py-16 sm:py-24">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <h2 className="section-title">Newsletter Werkstattfunk</h2>
          <p className="section-description">
            Jeden Monat liefern wir inspirierende Spar-Challenges, Budget-Hacks für Deutschland und Checklisten zum Ausgaben-Tracking.
          </p>
          <div className="mx-auto mt-8 max-w-xl">
            <figure className="overflow-hidden rounded-3xl border border-slate-100">
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Arbeitsfläche mit Budget-Planungsunterlagen"
                className="h-64 w-full object-cover"
                loading="lazy"
              />
            </figure>
            <div className="mt-8">
              <Link
                to="/services"
                className="inline-flex items-center justify-center rounded-full bg-[#F43F5E] px-6 py-3 text-sm font-semibold uppercase tracking-[0.25em] text-white transition hover:bg-[#e11d48]"
              >
                Werkstatt entdecken
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;