import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";

const posts = [
  {
    title: "Zero-Based Budgeting: Einstieg mit deutscher Kontostruktur",
    excerpt:
      "So passt du die Methode an Gehaltszahlungen, variable Einnahmen und Haushaltskonten an.",
    to: "/blog/zero-based-budget-de",
  },
  {
    title: "Digitale Umschlagmethode in Notion &amp; Excel",
    excerpt:
      "Wir zeigen dir, wie du Envelopes digital planst und trotzdem den physischen Überblick behältst.",
    to: "/blog/umschlagmethode-digital",
  },
  {
    title: "Abo-Kosten im Griff: Kündigungsfristen, Tools &amp; Musterbriefe",
    excerpt:
      "Identifiziere Daueraufträge, Abos und wiederkehrende Kosten in drei Schritten.",
    to: "/blog/abos-kuendigen-check",
  },
];

const Blog = () => (
  <>
    <Helmet>
      <title>Blog | SparWerk</title>
      <meta
        name="description"
        content="Aktuelle Insights von SparWerk: Zero-Based Budgeting, Umschlagmethode, Abos kündigen und mehr. Praxisnahe Tipps für Haushaltsbuch &amp; Ausgaben-Tracking."
      />
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-6xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Blog</h1>
        <p className="mt-4 text-lg text-slate-300">
          Wir schreiben über Budget-Methoden, Minimalismus, Studentenbudget, Ausgaben-Tracking und Spar-Challenges – ohne Hype, mit viel Praxis.
        </p>
      </div>
    </section>
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-6 space-y-6">
        {posts.map((post) => (
          <article key={post.to} className="card-blog-post">
            <h2 className="text-2xl font-semibold text-[#0B1020]">{post.title}</h2>
            <p className="mt-2 text-sm text-slate-600">{post.excerpt}</p>
            <Link
              to={post.to}
              className="inline-flex items-center text-sm font-semibold text-[#14B8A6] transition hover:text-[#0d9488]"
            >
              Weiterlesen
            </Link>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;