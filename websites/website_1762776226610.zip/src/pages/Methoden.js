import React from "react";
import { Helmet } from "react-helmet";

const methods = [
  {
    title: "Zero-Based Budgeting",
    description:
      "Jeder Euro erhält eine Aufgabe. Wir kombinieren eine Einnahmen/Ausgaben-Matrix mit Kategorie-Grenzen und Review-Routinen.",
    steps: [
      "Einnahmen erfassen &amp; fixe Kosten abziehen",
      "Variable Kategorien definieren und Deckel vergeben",
      "Monatliche Planung mit Wochen-Check-ins abgleichen",
    ],
  },
  {
    title: "50/30/20 Methode",
    description:
      "Ein klarer Split zwischen Needs, Wants und Sparen. Wir liefern dir Templates für verschiedene Gehaltsniveaus.",
    steps: [
      "Nettoeinkommen bestimmen",
      "Needs (50 %) &amp; Wants (30 %) verknüpfen",
      "Sparen &amp; Schuldenabbau (20 %) automatisieren",
    ],
  },
  {
    title: "Umschlagmethode",
    description:
      "Klassische Envelopes als physische oder digitale Lösung. Mit QR-Etiketten und Notion-Galerie abbildbar.",
    steps: [
      "Kategorien &amp; Limits definieren",
      "Envelopes (physisch oder digital) anlegen",
      "Transaktionen direkt den Umschlägen zuordnen",
    ],
  },
  {
    title: "Pay-Yourself-First",
    description:
      "Spare und investiere, bevor du Ausgaben tätigst. Besonders sinnvoll für Selbstständige mit variablem Einkommen.",
    steps: [
      "Zielquote für Rücklagen festlegen",
      "Automatisierte Überweisungen einrichten",
      "Restbudget nach Priorität verteilen",
    ],
  },
];

const Methoden = () => (
  <>
    <Helmet>
      <title>Methoden | SparWerk</title>
      <meta
        name="description"
        content="Lerne Zero-Based Budgeting, 50/30/20, Umschlagmethode und Pay-Yourself-First mit SparWerk kennen. Schritt-für-Schritt-Anleitungen und Vergleiche."
      />
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-6xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Methoden</h1>
        <p className="mt-4 text-lg text-slate-300">
          Unsere Methodensammlung hilft dir, die richtige Strategie für dein Haushaltsbudget zu finden – inkl. Checklisten, Vergleichen und Workflow-Tipps.
        </p>
      </div>
    </section>
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-6 grid gap-8 lg:grid-cols-2">
        {methods.map((method) => (
          <article key={method.title} className="card-method">
            <h2 className="text-2xl font-semibold text-[#0B1020]">{method.title}</h2>
            <p className="mt-3 text-sm text-slate-600">{method.description}</p>
            <ul className="mt-4 space-y-2 text-sm text-slate-600">
              {method.steps.map((step) => (
                <li key={step} className="flex items-start gap-2">
                  <span className="mt-1 h-2 w-2 rounded-full bg-[#14B8A6]"></span>
                  <span dangerouslySetInnerHTML={{ __html: step }} />
                </li>
              ))}
            </ul>
            <p className="mt-4 text-xs uppercase tracking-[0.2em] text-slate-500">
              Anleitung + Vorlage im Download-Bereich
            </p>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Methoden;