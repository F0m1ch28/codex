import React from "react";
import { Helmet } from "react-helmet";

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutzerklärung | SparWerk</title>
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-5xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Datenschutzerklärung</h1>
        <p className="mt-4 text-lg text-slate-300">
          Wir legen großen Wert auf den Schutz deiner Daten und halten uns an die Vorgaben der DSGVO.
        </p>
      </div>
    </section>
    <section className="mx-auto max-w-5xl px-6 py-16 text-sm leading-relaxed text-slate-700">
      <h2 className="text-2xl font-semibold text-[#0B1020]">1. Verantwortlicher</h2>
      <p className="mt-3">
        Die konkreten Angaben zum Verantwortlichen werden ergänzt, sobald sie vom Auftraggeber bereitgestellt werden.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">2. Datenerhebung</h2>
      <p className="mt-3">
        Wir verarbeiten personenbezogene Daten nur, wenn dies zur Bereitstellung unserer Services notwendig ist. Dazu gehören Kontaktinformationen und freiwillige Angaben in Formularen.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">3. Cookies &amp; Tracking</h2>
      <p className="mt-3">
        SparWerk setzt ausschließlich technisch notwendige Cookies ein. Download-Tracking erfolgt anonym ohne personenbezogene Daten oder Cookies.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">4. Betroffenenrechte</h2>
      <p className="mt-3">
        Du hast das Recht auf Auskunft, Berichtigung, Löschung und Widerspruch. Kontaktiere uns über die im Impressum hinterlegten Kontaktdaten.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">5. Sicherheit</h2>
      <p className="mt-3">
        Wir treffen technische und organisatorische Maßnahmen, um deine Daten gegen Verlust, Missbrauch oder unbefugten Zugriff zu schützen.
      </p>
    </section>
  </>
);

export default Privacy;