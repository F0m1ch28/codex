import React from "react";
import { Helmet } from "react-helmet";

const BlogZeroBased = () => (
  <>
    <Helmet>
      <title>Zero-Based Budgeting für Einsteiger | SparWerk</title>
      <meta
        name="description"
        content="Wie du Zero-Based Budgeting mit SparWerk startest: Schritt-für-Schritt Anleitung, Kategorien und Review-Regeln für Deutschland."
      />
    </Helmet>
    <article className="mx-auto max-w-3xl px-6 py-16">
      <header className="mb-8">
        <p className="text-xs uppercase tracking-[0.3em] text-[#14B8A6]">Zero-Based Budget</p>
        <h1 className="mt-2 text-3xl font-bold text-[#0B1020]">
          Zero-Based Budgeting für Einsteiger:innen
        </h1>
        <p className="mt-3 text-sm text-slate-600">
          Zero-Based Budgeting bedeutet, dass jeder Euro eine Aufgabe erhält. Wir zeigen dir, wie du diese Methode in Deutschland – mit Girokonto, Nebenjob und variablen Ausgaben – konkret umsetzt.
        </p>
      </header>
      <img
        src="https://picsum.photos/1200/800?random=51"
        alt="Budgetplanung auf einem digitalen Dashboard"
        className="mt-6 w-full rounded-3xl"
        loading="lazy"
      />
      <section className="mt-8 space-y-6 text-sm leading-relaxed text-slate-700">
        <p>
          Starte mit einer Bestandsaufnahme: Welche Einnahmen fließen im Monat? Berücksichtige Gehalt, Nebenjob, Kindergeld oder BAföG. Trage sie in den SparWerk Einnahmen-Tracker ein.
        </p>
        <p>
          Schritt zwei: Definiere fixe Ausgaben wie Miete, Versicherungen, Mobilität und Abos. Mit unserem Abo-Scanner bekommst du Reminder für Kündigungsfristen und findest Einsparpotenzial.
        </p>
        <p>
          Jetzt verteilst du jeden Euro auf Kategorien wie Lebensmittel, Freizeit, Gesundheit oder Bildung. Plane Puffer ein und nutze die Review-Reminder, um wöchentlich zu checken, ob die Grenzen passen.
        </p>
        <p>
          Tipp: Kombiniere Zero-Based Budgeting mit Pay-Yourself-First. Richte Daueraufträge ein, die Rücklagen und Sparziele zuerst bedienen. Was übrig bleibt, bekommt seine Kategorien.
        </p>
      </section>
    </article>
  </>
);

export default BlogZeroBased;