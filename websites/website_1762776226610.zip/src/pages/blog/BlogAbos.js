import React from "react";
import { Helmet } from "react-helmet";

const BlogAbos = () => (
  <>
    <Helmet>
      <title>Abos kündigen &amp; Kosten prüfen | SparWerk</title>
      <meta
        name="description"
        content="Unsere Checkliste zeigt dir, wie du Abos findest, Kündigungsfristen einhältst und wiederkehrende Kosten senkst. Mit SparWerk Abo-Scanner Hinweisen."
      />
    </Helmet>
    <article className="mx-auto max-w-3xl px-6 py-16">
      <header className="mb-8">
        <p className="text-xs uppercase tracking-[0.3em] text-[#14B8A6]">Fixkosten senken</p>
        <h1 className="mt-2 text-3xl font-bold text-[#0B1020]">
          Abos kündigen: Checkliste &amp; Reminder
        </h1>
        <p className="mt-3 text-sm text-slate-600">
          Viele Konten werden von wiederkehrenden Kosten belastet. Mit unserer Checkliste findest du Abos, bewertest ihren Nutzen und setzt Kündigungsfristen clever um.
        </p>
      </header>
      <img
        src="https://picsum.photos/1200/800?random=53"
        alt="Checkliste für Abonnements"
        className="mt-6 w-full rounded-3xl"
        loading="lazy"
      />
      <section className="mt-8 space-y-6 text-sm leading-relaxed text-slate-700">
        <p>
          Beginne mit einem Blick auf deine Kontoauszüge der letzten 90 Tage. Markiere alle wiederkehrenden Positionen. Unser CSV-Template hilft beim Filtern nach Namen, IBAN oder Verwendungszweck.
        </p>
        <p>
          Bewertung: Stelle dir bei jedem Abo drei Fragen: Nutze ich es wirklich? Gibt es günstigere Alternativen? Passt es zu meinen aktuellen Zielen?
        </p>
        <p>
          Kündigungsfristen: Trage Fristen direkt in den Ziel-Tracker ein. Wir liefern Mustertexte für Kündigungen und Erinnerungs-Mails, damit du keine Frist verpasst.
        </p>
        <p>
          Bonus: Richte ein separates Konto für variable Abos ein. So behältst du den Überblick und verhinderst Überraschungen auf deinem Hauptkonto.
        </p>
      </section>
    </article>
  </>
);

export default BlogAbos;