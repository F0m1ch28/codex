import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";

const tools = [
  {
    title: "Ausgaben-Tracker",
    description:
      "Mobile-optimiert, offline-fähiger Export, mit Kategorien-Farbcodes und automatisierten Warnhinweisen.",
    features: ["Eintrag in unter 30 Sekunden", "Flexible Kategorisierung", "CSV &amp; Notion Sync"],
  },
  {
    title: "Kategorien-Editor",
    description:
      "Baue dir deine Budgetkategorien und Zuweisungen. Ideal für Familien und WGs mit geteilten Konten.",
    features: ["Drag &amp; Drop", "Gemeinsame Boards", "Review-Reminder"],
  },
  {
    title: "Abo-Scanner Hinweise",
    description:
      "Checkliste zum Sichten von Daueraufträgen &amp; Abos inkl. Kündigungsfristen und Ansprechpartner.",
    features: ["Benachrichtigung für Kündigungsfristen", "Vorformulierte Schreiben", "Übersichtliche Timeline"],
  },
  {
    title: "Ziel-Tracker",
    description:
      "Setze Sparziele und tracke Fortschritte mit Visualisierungen. Für Minimalismus-Challenges oder langfristige Projekte.",
    features: ["Progress Bars &amp; Forecast", "Spar-Challenge Cards", "Automatische Erinnerungen"],
  },
];

const Tools = () => (
  <>
    <Helmet>
      <title>Tools | SparWerk</title>
      <meta
        name="description"
        content="Die SparWerk Toolbox: Ausgaben-Tracker, Kategorien-Editor, Abo-Scanner-Hinweise und Ziel-Tracker. DSGVO-konforme Werkzeuge für dein Haushaltsbudget."
      />
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-6xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Tools</h1>
        <p className="mt-4 text-lg text-slate-300">
          Alle Tools lassen sich modular kombinieren und sind für Deutschland optimiert. Keine undurchsichtigen Algorithmen, sondern klare Funktionen.
        </p>
      </div>
    </section>
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-6 grid gap-8 lg:grid-cols-2">
        {tools.map((tool) => (
          <article key={tool.title} className="card-tool">
            <h2 className="text-2xl font-semibold text-[#0B1020]">{tool.title}</h2>
            <p className="mt-3 text-sm text-slate-600">{tool.description}</p>
            <ul className="mt-4 space-y-2 text-sm text-slate-600">
              {tool.features.map((feature) => (
                <li key={feature} className="flex items-start gap-2">
                  <span className="mt-1 h-2 w-2 rounded-full bg-[#14B8A6]" />
                  <span dangerouslySetInnerHTML={{ __html: feature }} />
                </li>
              ))}
            </ul>
            <Link
              to="/vorlagen"
              className="mt-6 inline-flex items-center text-sm font-semibold text-[#14B8A6] transition hover:text-[#0d9488]"
            >
              Vorlagen ansehen
            </Link>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Tools;