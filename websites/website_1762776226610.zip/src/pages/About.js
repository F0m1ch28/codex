import React from "react";
import { Helmet } from "react-helmet";

const cultureHighlights = [
  {
    title: "Werkstatt trifft Datenkompetenz",
    description:
      "Wir kombinieren eine Hands-on-Mentalität mit einer klaren Datenbasis. Jede Vorlage wird getestet und dokumentiert.",
  },
  {
    title: "Transparent & ehrlich",
    description:
      "Keine Heilsversprechen, keine schnellen Tricks. Wir liefern solides Handwerk, das nachhaltig wirkt.",
  },
  {
    title: "Community-getriebene Roadmap",
    description:
      "Features entstehen aus echten Rückmeldungen. Wir arbeiten eng mit Studierenden, Familien und Solopreneur:innen.",
  },
];

const About = () => (
  <>
    <Helmet>
      <title>Über SparWerk | Team, Kultur &amp; Mission</title>
      <meta
        name="description"
        content="Lerne das SparWerk Team kennen: Finanzcoaches, Product Engineers und Community-Expert:innen, die dein Haushaltsbudget mit modernen Werkzeugen unterstützen."
      />
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-6xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Über SparWerk</h1>
        <p className="mt-4 max-w-2xl text-lg text-slate-300">
          Wir glauben an nachvollziehbare Budgets, klare Entscheidungen und gemeinschaftliche Finanzkompetenz. Unsere Werkstatt in Deutschland verbindet Methodenwissen mit modernen Tools.
        </p>
      </div>
    </section>

    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-5xl px-6">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <h2 className="section-title">Unsere Mission</h2>
            <p className="text-sm text-slate-600">
              SparWerk unterstützt Menschen in Deutschland dabei, ihre Finanzen selbstbewusst zu organisieren. Wir analysieren bewährte Budgetmethoden und adaptieren sie auf den digitalen Alltag. Jede Vorlage ist in deutscher Sprache, DSGVO-konform und startet ohne Marketing-Blabla.
            </p>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-lg">
            <h3 className="text-2xl font-semibold text-[#0B1020]">
              Was uns antreibt
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li>✔ Finanzkompetenz stärken – unabhängig von Herkunft oder Einkommen.</li>
              <li>✔ Methoden verständlich erklären und konkret anwendbar machen.</li>
              <li>✔ Transparente Tools, die du ohne Hürden in deinen Alltag integrierst.</li>
              <li>✔ Eine Community, die Erfahrungen teilt und sich gegenseitig motiviert.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className="bg-[#F8FAFC] py-16 sm:py-24">
      <div className="mx-auto max-w-5xl px-6">
        <h2 className="section-title">Kultur &amp; Arbeitsweise</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {cultureHighlights.map((item) => (
            <div key={item.title} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-xl font-semibold text-[#0B1020]">{item.title}</h3>
              <p className="mt-3 text-sm text-slate-600">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-5xl px-6">
        <h2 className="section-title">Wie wir arbeiten</h2>
        <div className="mt-8 grid gap-8 lg:grid-cols-2">
          <div className="space-y-4 text-sm text-slate-600">
            <p>
              SparWerk ist remote-first mit regelmäßigem Austausch in Berlin und Hamburg. Unsere Formate: wöchentliche Budget-Clinics, Fokus-Sessions und offene Feedback Loops.
            </p>
            <p>
              Wir dokumentieren jede Entscheidung transparent. Tools werden erst veröffentlicht, wenn wir klare Anwendungsbeispiele mit Anwender:innen getestet haben.
            </p>
            <p>
              Unser Anspruch: respektvoller Umgang mit Zeit und Daten. Alle Integrationen, die wir empfehlen, erfüllen deutsche Datenschutzstandards.
            </p>
          </div>
          <div>
            <div className="rounded-3xl border border-slate-100 bg-white/60 p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-[#0B1020]">
                Zusammenarbeit
              </h3>
              <ul className="mt-4 space-y-3 text-sm text-slate-600">
                <li>• SparWerk Community Forum &amp; Live-Formate</li>
                <li>• Beta-Testing mit Studierenden und Familien</li>
                <li>• Partner:innen aus Beratungen und Finanzbildung</li>
                <li>• Transparente Roadmap mit Feedback-Gates</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;