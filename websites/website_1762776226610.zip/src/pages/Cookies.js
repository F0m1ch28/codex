import React from "react";
import { Helmet } from "react-helmet";

const Cookies = () => (
  <>
    <Helmet>
      <title>Cookie Richtlinie | SparWerk</title>
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-5xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">Cookie Richtlinie</h1>
        <p className="mt-4 text-lg text-slate-300">
          Wir setzen nur notwendige Cookies ein, um grundlegende Funktionen sicherzustellen. Analyse- oder Marketing-Cookies nutzen wir nicht.
        </p>
      </div>
    </section>
    <section className="mx-auto max-w-5xl px-6 py-16 text-sm leading-relaxed text-slate-700">
      <h2 className="text-2xl font-semibold text-[#0B1020]">Technisch notwendige Cookies</h2>
      <p className="mt-3">
        Diese Cookies sorgen dafür, dass du dich auf der Seite bewegen und grundlegende Funktionen nutzen kannst. Ohne diese Cookies kann SparWerk nicht korrekt funktionieren.
      </p>
      <h2 className="mt-8 text-2xl font-semibold text-[#0B1020]">Cookie-Einstellungen</h2>
      <p className="mt-3">
        Du kannst jederzeit in deinem Browser Cookies deaktivieren oder löschen. Beachte, dass dadurch eventuell bestimmte Funktionen nicht mehr bereitstehen.
      </p>
    </section>
  </>
);

export default Cookies;