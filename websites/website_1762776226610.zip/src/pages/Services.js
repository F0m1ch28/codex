import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import { ArrowRight, Check, ClipboardList, FileSpreadsheet, NotebookPen } from "lucide-react";

const serviceCards = [
  {
    title: "Budget-Methoden Coaching",
    description:
      "Vergleiche Zero-Based, 50/30/20, Umschlag und Pay-Yourself-First und wähle den passenden Mix. Inklusive Entscheidungsdiagrammen.",
    icon: <ClipboardList className="h-6 w-6 text-[#14B8A6]" />,
    link: "/methoden",
  },
  {
    title: "Digitale Tool-Stacks",
    description:
      "Verbinde Ausgaben-Tracker mit deinem Lieblingssystem: Excel, Google Sheets, Notion oder papierbasiert mit QR-Etiketten.",
    icon: <FileSpreadsheet className="h-6 w-6 text-[#14B8A6]" />,
    link: "/tools",
  },
  {
    title: "Vorlagen & Workflows",
    description:
      "Modulare PDFs, CSVs und Notion-Templates mit konkreten Anwendungsfällen. Inklusive Download-Tracking ohne Cookies.",
    icon: <NotebookPen className="h-6 w-6 text-[#14B8A6]" />,
    link: "/vorlagen",
  },
];

const Services = () => (
  <>
    <Helmet>
      <title>Services | Methoden, Tools &amp; Vorlagen von SparWerk</title>
      <meta
        name="description"
        content="Überblick über alle Services von SparWerk: Budget-Methoden Coaching, digitale Tool-Stacks und modulare Vorlagen für dein Haushaltsbuch."
      />
    </Helmet>
    <section className="bg-[#0B1020] py-20 text-white">
      <div className="mx-auto max-w-6xl px-6">
        <h1 className="font-display text-4xl font-bold tracking-tight">
          Services &amp; Angebote
        </h1>
        <p className="mt-4 max-w-2xl text-lg text-slate-300">
          Von der Auswahl der richtigen Methode bis zum finalen Review-Workflow: Wir bieten dir strukturierte Prozesse und Templates, die du direkt einsetzen kannst.
        </p>
      </div>
    </section>

    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid gap-8 md:grid-cols-3">
          {serviceCards.map((service) => (
            <article key={service.title} className="card-service">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#14B8A6]/10">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-[#0B1020]">{service.title}</h3>
              <p className="text-sm text-slate-600">{service.description}</p>
              <Link
                to={service.link}
                className="inline-flex items-center text-sm font-semibold text-[#14B8A6] transition hover:text-[#0d9488]"
              >
                Mehr erfahren <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </article>
          ))}
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-lg">
            <h2 className="text-2xl font-semibold text-[#0B1020]">
              Projektbegleitung
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              Du möchtest dein Haushaltsbuch komplett neu strukturieren? Wir begleiten dich vom Audit bis zum Roll-out. Transparent, Schritt für Schritt, ohne überzogene Versprechen.
            </p>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li className="flex items-start gap-2">
                <Check className="mt-1 h-4 w-4 text-[#14B8A6]" />
                Analyse bestehender Budgets &amp; Kontenstruktur
              </li>
              <li className="flex items-start gap-2">
                <Check className="mt-1 h-4 w-4 text-[#14B8A6]" />
                Auswahl passender Methoden &amp; Tools
              </li>
              <li className="flex items-start gap-2">
                <Check className="mt-1 h-4 w-4 text-[#14B8A6]" />
                Dokumentation deiner Workflows für spätere Reviews
              </li>
              <li className="flex items-start gap-2">
                <Check className="mt-1 h-4 w-4 text-[#14B8A6]" />
                Onboarding von Partner:innen oder Teammitgliedern
              </li>
            </ul>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-lg">
            <h2 className="text-2xl font-semibold text-[#0B1020]">
              Workshops &amp; Clinics
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              Regelmäßige Online-Workshops und Budget-Clinics für Studierende, Familien oder Selbstständige. Wir arbeiten live an deinen Zahlen und liefern klare To-dos.
            </p>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li>• Überblick: Zero-Based &amp; Umschlagmethoden im Vergleich</li>
              <li>• Spezial: Abonnements identifizieren und kündigen</li>
              <li>• Fokus: Spar-Challenges für Minimalismus &amp; Konsumfasten</li>
              <li>• Deep Dive: Ziel-Tracking &amp; Automatisierung</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Services;