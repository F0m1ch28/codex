import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("sparwerk_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem("sparwerk_cookie_consent", "accepted");
    setVisible(false);
  };

  const declineCookies = () => {
    window.localStorage.setItem("sparwerk_cookie_consent", "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      className="fixed bottom-4 left-4 right-4 z-[70] rounded-2xl border border-slate-200 bg-white p-4 shadow-2xl shadow-slate-500/10 md:left-auto md:right-8 md:max-w-lg"
      role="dialog"
      aria-modal="true"
      aria-label="Cookie Hinweis"
    >
      <div className="space-y-3 text-sm text-slate-700">
        <h2 className="font-display text-lg font-semibold text-[#0B1020]">Cookies &amp; Datenschutz</h2>
        <p>
          Wir setzen ausschließlich funktionale Cookies ein, um die grundlegenden Dienste bereitzustellen.
          Analyse- oder Werbe-Tracking findet nicht statt. Details erhältst du in unserer{" "}
          <a href="/cookies" className="font-medium text-[#14B8A6] hover:underline">
            Cookie Richtlinie
          </a>
          .
        </p>
      </div>
      <div className="mt-4 flex flex-col gap-3 md:flex-row md:justify-end">
        <button
          type="button"
          onClick={declineCookies}
          className="rounded-full border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:border-slate-400"
        >
          Nur funktional
        </button>
        <button
          type="button"
          onClick={acceptCookies}
          className="rounded-full bg-[#14B8A6] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#0d9488]"
        >
          Akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;