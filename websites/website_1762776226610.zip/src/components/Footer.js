import React from "react";
import { Link } from "react-router-dom";
import NewsletterForm from "./NewsletterForm";

const Footer = () => {
  return (
    <footer className="border-t border-slate-200 bg-[#0B1020] text-slate-100" aria-label="Fußbereich">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-emerald-500/60 bg-[#0B1020]">
              <span className="font-mono text-lg font-semibold text-emerald-400">SW</span>
            </div>
            <div>
              <h3 className="font-display text-xl font-semibold">SparWerk</h3>
              <p className="text-xs uppercase tracking-[0.22em] text-slate-400">
                Budget Studio
              </p>
            </div>
          </div>
          <p className="max-w-xs text-sm text-slate-300">
            Digitale Werkbank für Haushaltsbudgets: Methoden, Tools und Vorlagen, die zu deinem Alltag passen.
          </p>
          <div className="mt-6 flex items-center gap-4">
            <a
              href="https://www.linkedin.com"
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-600 text-slate-200 transition hover:border-emerald-400 hover:text-emerald-300"
              aria-label="LinkedIn"
            >
              in
            </a>
            <a
              href="https://www.instagram.com"
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-600 text-slate-200 transition hover:border-emerald-400 hover:text-emerald-300"
              aria-label="Instagram"
            >
              IG
            </a>
            <a
              href="https://www.youtube.com"
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-600 text-slate-200 transition hover:border-emerald-400 hover:text-emerald-300"
              aria-label="YouTube"
            >
              ▶
            </a>
          </div>
        </div>

        <div>
          <h4 className="mb-4 font-display text-lg font-semibold text-white">Navigation</h4>
          <ul className="space-y-3 text-sm">
            <li><Link to="/" className="transition hover:text-emerald-300">Start</Link></li>
            <li><Link to="/methoden" className="transition hover:text-emerald-300">Methoden</Link></li>
            <li><Link to="/tools" className="transition hover:text-emerald-300">Tools</Link></li>
            <li><Link to="/vorlagen" className="transition hover:text-emerald-300">Vorlagen</Link></li>
            <li><Link to="/blog" className="transition hover:text-emerald-300">Blog</Link></li>
            <li><Link to="/faq" className="transition hover:text-emerald-300">Hilfe &amp; FAQ</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-display text-lg font-semibold text-white">Rechtliches</h4>
          <ul className="space-y-3 text-sm">
            <li><Link to="/impressum" className="transition hover:text-emerald-300">Impressum</Link></li>
            <li><Link to="/policy" className="transition hover:text-emerald-300">Datenschutzerklärung</Link></li>
            <li><Link to="/cookies" className="transition hover:text-emerald-300">Cookie Richtlinie</Link></li>
            <li><Link to="/terms" className="transition hover:text-emerald-300">Allgemeine Nutzungsbedingungen</Link></li>
            <li><Link to="/contact" className="transition hover:text-emerald-300">Kontakt</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-display text-lg font-semibold text-white">Newsletter</h4>
          <p className="mb-4 text-sm text-slate-300">
            Einmal im Monat: praxisnahe Budget-Ideen, Checklisten und Fokus-Tools für deinen Finanzalltag.
          </p>
          <NewsletterForm />
        </div>
      </div>
      <div className="border-t border-slate-800 py-6 text-center text-xs uppercase tracking-[0.28em] text-slate-500">
        © {new Date().getFullYear()} SparWerk. Alle Rechte vorbehalten.
      </div>
    </footer>
  );
};

export default Footer;