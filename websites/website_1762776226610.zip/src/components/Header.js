import React, { useState, useEffect } from "react";
import { NavLink, Link } from "react-router-dom";
import { Menu, X } from "lucide-react";

const navItems = [
  { label: "Start", path: "/" },
  { label: "Methoden", path: "/methoden" },
  { label: "Tools", path: "/tools" },
  { label: "Vorlagen", path: "/vorlagen" },
  { label: "Blog", path: "/blog" },
  { label: "Hilfe", path: "/faq" },
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 16);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header
      className={`sticky top-0 z-50 transition-shadow duration-300 ${
        isScrolled ? "shadow-xl shadow-slate-900/5 backdrop-blur bg-[#0B1020]/90" : "bg-transparent"
      }`}
      aria-label="Hauptnavigation SparWerk"
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 lg:px-8">
        <Link
          to="/"
          className="flex items-center gap-3 text-white"
          aria-label="SparWerk Startseite"
          onClick={closeMenu}
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-emerald-500/60 bg-[#0B1020]">
            <span className="font-mono text-lg font-semibold text-emerald-400">SW</span>
          </div>
          <div className="flex flex-col">
            <span className="font-display text-xl font-semibold tracking-tight">
              SparWerk
            </span>
            <span className="text-xs uppercase tracking-[0.18em] text-slate-300">
              Budget Studio
            </span>
          </div>
        </Link>

        <nav className="hidden items-center gap-8 text-sm font-medium text-slate-200 lg:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `relative transition-colors duration-200 hover:text-emerald-300 ${
                  isActive ? "text-emerald-300" : ""
                }`
              }
            >
              {item.label}
              <span className="absolute bottom-[-6px] left-0 h-0.5 w-full rounded-full bg-emerald-400 opacity-0 transition-opacity duration-200 group-hover:opacity-100" />
            </NavLink>
          ))}
          <Link
            to="/contact"
            className="rounded-full bg-[#F43F5E] px-5 py-2.5 text-xs uppercase tracking-widest text-white transition-transform duration-200 hover:-translate-y-0.5 hover:bg-[#e11d48] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F43F5E]"
          >
            Kontakt aufnehmen
          </Link>
        </nav>

        <button
          type="button"
          className="inline-flex items-center justify-center rounded-md border border-slate-700 p-2 text-slate-200 transition duration-200 hover:bg-slate-800 lg:hidden"
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          aria-label="Navigation öffnen"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      <div
        id="mobile-menu"
        className={`lg:hidden ${
          menuOpen ? "max-h-screen opacity-100" : "max-h-0 opacity-0"
        } origin-top overflow-hidden border-t border-slate-800 bg-[#0B1020] transition-all duration-300`}
      >
        <div className="space-y-2 px-6 py-6">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `block rounded-lg px-4 py-3 text-base font-medium text-slate-200 transition hover:bg-slate-800/60 ${
                  isActive ? "bg-slate-800/80 text-emerald-300" : ""
                }`
              }
              onClick={closeMenu}
            >
              {item.label}
            </NavLink>
          ))}
          <Link
            to="/contact"
            className="flex w-full items-center justify-center rounded-full bg-[#F43F5E] px-5 py-3 text-sm font-semibold uppercase tracking-[0.2em] text-white transition hover:bg-[#e11d48]"
            onClick={closeMenu}
          >
            Kontakt aufnehmen
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;