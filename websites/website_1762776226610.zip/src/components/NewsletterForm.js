import React, { useState } from "react";

const NewsletterForm = () => {
  const [email, setEmail] = useState("");
  const [feedback, setFeedback] = useState({ message: "", type: "" });

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email) {
      setFeedback({ message: "Bitte E-Mail Adresse eintragen.", type: "error" });
      return;
    }
    const emailRegex =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\\.,;:\s@"]+\.)+[^<>()[\]\\.,;:\s@"]{2,})$/i;
    if (!emailRegex.test(email)) {
      setFeedback({ message: "Bitte eine gültige E-Mail Adresse nutzen.", type: "error" });
      return;
    }
    setFeedback({
      message: "Danke! Bitte bestätige deine Anmeldung über den Link in deinem Postfach.",
      type: "success",
    });
    setEmail("");
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3" noValidate>
      <label htmlFor="newsletter-email" className="sr-only">
        E-Mail Adresse
      </label>
      <input
        id="newsletter-email"
        type="email"
        value={email}
        onChange={(event) => setEmail(event.target.value)}
        placeholder="dein.mail@example.de"
        className="w-full rounded-xl border border-slate-600 bg-[#0B1020] px-4 py-3 text-sm text-slate-100 placeholder:text-slate-400 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        required
      />
      <button
        type="submit"
        className="w-full rounded-full bg-[#14B8A6] px-4 py-3 text-sm font-semibold uppercase tracking-[0.2em] text-white transition hover:bg-[#0d9488]"
      >
        Abonnieren
      </button>
      {feedback.message && (
        <p
          className={`text-sm ${
            feedback.type === "success" ? "text-emerald-300" : "text-[#F43F5E]"
          }`}
        >
          {feedback.message}
        </p>
      )}
      <p className="text-xs text-slate-400">
        Abmeldung jederzeit möglich. Wir respektieren deine Privatsphäre und versenden keinen Spam.
      </p>
    </form>
  );
};

export default NewsletterForm;