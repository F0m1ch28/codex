import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";

import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import Methoden from "./pages/Methoden";
import Tools from "./pages/Tools";
import Vorlagen from "./pages/Vorlagen";
import Blog from "./pages/Blog";
import BlogZeroBased from "./pages/blog/BlogZeroBased";
import BlogUmschlag from "./pages/blog/BlogUmschlag";
import BlogAbos from "./pages/blog/BlogAbos";
import FAQ from "./pages/FAQ";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Cookies from "./pages/Cookies";
import Impressum from "./pages/Impressum";

const App = () => {
  return (
    <Router>
      <ScrollToTop />
      <div className="flex min-h-screen flex-col bg-[#F8FAFC] text-slate-900">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/methoden" element={<Methoden />} />
            <Route path="/tools" element={<Tools />} />
            <Route path="/vorlagen" element={<Vorlagen />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/zero-based-budget-de" element={<BlogZeroBased />} />
            <Route path="/blog/umschlagmethode-digital" element={<BlogUmschlag />} />
            <Route path="/blog/abos-kuendigen-check" element={<BlogAbos />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/policy" element={<Privacy />} />
            <Route path="/cookies" element={<Cookies />} />
            <Route path="/impressum" element={<Impressum />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </Router>
  );
};

export default App;