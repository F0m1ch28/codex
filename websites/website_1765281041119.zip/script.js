document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      navToggle.classList.toggle('is-active');
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('is-open')) {
          siteNav.classList.remove('is-open');
          navToggle.classList.remove('is-active');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const storageKey = 'nas_cookie_consent';

  if (cookieBanner) {
    const stored = localStorage.getItem(storageKey);
    if (!stored) {
      setTimeout(() => {
        cookieBanner.classList.add('visible');
      }, 600);
    } else {
      cookieBanner.setAttribute('data-hidden', 'true');
    }

    const acceptBtn = cookieBanner.querySelector('.js-accept-cookies');
    const declineBtn = cookieBanner.querySelector('.js-decline-cookies');

    const closeBanner = (status) => {
      localStorage.setItem(storageKey, status);
      cookieBanner.classList.remove('visible');
      cookieBanner.setAttribute('data-hidden', 'true');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => closeBanner('accepted'));
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', () => closeBanner('declined'));
    }
  }
});