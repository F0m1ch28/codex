(function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navList.classList.toggle('is-open');
        });

        document.addEventListener('click', (event) => {
            if (!navList.contains(event.target) && !navToggle.contains(event.target)) {
                navList.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const banner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('[data-cookie-accept]');
    const declineBtn = document.querySelector('[data-cookie-decline]');
    const cookieKey = 'luxefest_cookie_consent';

    if (banner && acceptBtn && declineBtn) {
        const storedConsent = localStorage.getItem(cookieKey);
        if (!storedConsent) {
            banner.classList.add('active');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            banner.classList.remove('active');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'declined');
            banner.classList.remove('active');
        });
    }

    const builder = document.querySelector('[data-builder]');
    if (builder) {
        const themeSelect = builder.querySelector('#box-theme');
        const checkboxes = builder.querySelectorAll('input[type="checkbox"][data-price]');
        const totalElement = document.querySelector('[data-total]');
        const summaryList = document.querySelector('[data-summary]');
        const messageInput = builder.querySelector('[data-message]');
        const messagePreview = document.querySelector('[data-message-preview]');
        const quoteButton = builder.querySelector('[data-request-quote]');

        const updateBuilder = () => {
            let total = 0;
            const selections = [];

            if (themeSelect) {
                const selectedOption = themeSelect.selectedOptions[0];
                const themePrice = parseFloat(selectedOption.dataset.price || '0');
                total += themePrice;
                selections.push(selectedOption.value);
            }

            checkboxes.forEach((checkbox) => {
                if (checkbox.checked) {
                    const price = parseFloat(checkbox.dataset.price || '0');
                    total += price;
                    selections.push(checkbox.value);
                }
            });

            if (summaryList) {
                summaryList.innerHTML = '';
                selections.forEach((item) => {
                    const li = document.createElement('li');
                    li.textContent = item;
                    summaryList.appendChild(li);
                });
            }

            if (totalElement) {
                totalElement.textContent = `$${total.toFixed(2)}`;
            }

            if (messagePreview && messageInput) {
                const message = messageInput.value.trim();
                messagePreview.textContent = message ? `Message preview: “${message}”` : '';
            }
        };

        if (themeSelect) {
            themeSelect.addEventListener('change', updateBuilder);
        }

        checkboxes.forEach((checkbox) => {
            checkbox.addEventListener('change', updateBuilder);
        });

        if (messageInput) {
            messageInput.addEventListener('input', updateBuilder);
        }

        if (quoteButton) {
            quoteButton.addEventListener('click', () => {
                alert('Thank you! Our gifting concierge will reach out shortly with a personalized consultation.');
            });
        }

        updateBuilder();
    }
})();