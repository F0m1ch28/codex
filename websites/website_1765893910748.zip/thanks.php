<?php $pageTitle = "Gracias"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo $pageTitle; ?> | Aqua Hydro Control España</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Gracias por contactar con Aqua Hydro Control España. Coordinaremos la evaluación solicitada.">
    <link rel="canonical" href="https://www.aquahydrocontrol.com/thanks.php">
    <meta property="og:title" content="Solicitud recibida - Aqua Hydro Control España">
    <meta property="og:description" content="Hemos recibido tu solicitud, un especialista te contactará pronto.">
    <meta property="og:url" content="https://www.aquahydrocontrol.com/thanks.php">
    <meta property="og:type" content="website">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/png" href="https://picsum.photos/64/64?water">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <a href="index.html" class="branding" aria-label="Aqua Hydro Control España inicio">
                <img src="https://picsum.photos/88/88?energy" alt="Logotipo simplificado de Aqua Hydro Control España">
                <div class="brand-meta">
                    <span>AquaHydroControl.com</span>
                    <strong>Aqua Hydro Control España</strong>
                </div>
            </a>
            <button class="nav-toggle" aria-label="Abrir menú de navegación" aria-expanded="false">
                <span class="sr-only">Abrir menú</span>
                ☰
            </button>
            <nav class="site-nav" aria-label="Navegación principal">
                <a href="index.html">Inicio</a>
                <a href="about.html">Empresa</a>
                <a href="solutions.html">Soluciones</a>
                <a href="technology.html">Tecnología</a>
                <a href="performance.html">Rendimiento</a>
                <a href="projects.html">Proyectos</a>
                <a href="contact.php">Contacto</a>
            </nav>
        </div>
    </header>
    <main>
        <section class="page-hero">
            <div class="container">
                <div>
                    <h1>Gracias por tu solicitud</h1>
                    <p>Hemos recibido tu mensaje. Un especialista de Aqua Hydro Control España se pondrá en contacto contigo para coordinar la evaluación hidráulica.</p>
                    <div class="hero-actions">
                        <a class="cta-button primary" href="index.html">Volver al inicio</a>
                        <a class="cta-button secondary" href="projects.html">Ver proyectos destacados</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="section alt">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title">¿Qué sigue?</h2>
                    <p class="section-subtitle">Nuestro equipo revisará la información y se comunicará contigo en menos de 24 horas hábiles.</p>
                </div>
                <div class="grid">
                    <article class="card">
                        <div class="feature-icon">🗓️</div>
                        <h3>Agenda coordinada</h3>
                        <p>Recibirás una propuesta de fecha para un diagnóstico remoto o visita a tu central.</p>
                    </article>
                    <article class="card">
                        <div class="feature-icon">📂</div>
                        <h3>Revisión de datos</h3>
                        <p>Solicitaremos datos iniciales para preparar el análisis y personalizar el plan de trabajo.</p>
                    </article>
                    <article class="card">
                        <div class="feature-icon">🤝</div>
                        <h3>Sesión técnica</h3>
                        <p>Reunión con especialistas en ingeniería hidráulica, analítica y ciberseguridad energética.</p>
                    </article>
                </div>
            </div>
        </section>
    </main>
    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <strong>Aqua Hydro Control España</strong>
                    <p>Gestión inteligente, monitorización en tiempo real y mantenimiento predictivo para centrales hidroeléctricas en todo el territorio español.</p>
                </div>
                <div class="footer-nav">
                    <a href="about.html">Historia y visión</a>
                    <a href="solutions.html">Portafolio de soluciones</a>
                    <a href="technology.html">Infraestructura tecnológica</a>
                    <a href="projects.html">Casos de éxito</a>
                    <a href="performance.html">Indicadores de rendimiento</a>
                </div>
                <div class="footer-contact">
                    <span>Torre Mapfre, Carrer de la Marina 16-18, 08005 Barcelona, España</span>
                    <a href="tel:+34932123456">+34 932 123 456</a>
                    <a href="mailto:contacto@aquahydrocontrol.com">contacto@aquahydrocontrol.com</a>
                </div>
                <div class="footer-nav">
                    <a href="privacy.html">Privacidad</a>
                    <a href="cookies.html">Cookies</a>
                    <a href="terms.html">Términos legales</a>
                    <a href="sitemap.xml">Mapa del sitio</a>
                </div>
            </div>
            <div class="footer-bottom">
                <span>© <?php echo date("Y"); ?> Aqua Hydro Control España. Todos los derechos reservados.</span>
                <span>Dominio principal: <a href="https://www.aquahydrocontrol.com">AquaHydroControl.com</a></span>
            </div>
        </div>
    </footer>
    <div class="cookie-banner" role="region" aria-live="polite" aria-label="Aviso de cookies">
        <h4>Preferencias de cookies</h4>
        <p>Utilizamos cookies para analizar el rendimiento hidráulico y mejorar la experiencia de supervisión. Puedes aceptar o rechazar, mantendremos tu elección.</p>
        <div class="cookie-actions">
            <button class="cookie-button reject" type="button">Rechazar</button>
            <button class="cookie-button accept" type="button">Aceptar</button>
        </div>
        <a href="cookies.html">Configurar detalles</a>
    </div>
    <script src="script.js" defer></script>
</body>
</html>