const navToggle = document.querySelector(".nav-toggle");
const siteNav = document.querySelector(".site-nav");
const cookieBanner = document.querySelector(".cookie-banner");
const acceptCookies = document.querySelector(".cookie-button.accept");
const rejectCookies = document.querySelector(".cookie-button.reject");

if (navToggle && siteNav) {
  navToggle.addEventListener("click", () => {
    const expanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", String(!expanded));
    siteNav.classList.toggle("active");
  });

  siteNav.addEventListener("click", (event) => {
    if (event.target.matches("a")) {
      siteNav.classList.remove("active");
      navToggle.setAttribute("aria-expanded", "false");
    }
  });
}

const manageCookieBanner = () => {
  if (!cookieBanner) {
    return;
  }
  const consent = localStorage.getItem("ahcCookieConsent");
  if (!consent) {
    cookieBanner.classList.add("active");
    cookieBanner.setAttribute("role", "dialog");
    cookieBanner.setAttribute("aria-live", "polite");
  }
};

const storeConsent = (value) => {
  localStorage.setItem("ahcCookieConsent", value);
  cookieBanner.classList.remove("active");
};

if (cookieBanner && acceptCookies && rejectCookies) {
  acceptCookies.addEventListener("click", () => storeConsent("accepted"));
  rejectCookies.addEventListener("click", () => storeConsent("rejected"));
  manageCookieBanner();
}

document.querySelectorAll("a[href^='#']").forEach((anchor) => {
  anchor.addEventListener("click", (event) => {
    const targetId = anchor.getAttribute("href").substring(1);
    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      event.preventDefault();
      targetElement.scrollIntoView({ behavior: "smooth" });
    }
  });
});