<?php $pageTitle = "Contacto"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo $pageTitle; ?> | Aqua Hydro Control España</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Contacta con Aqua Hydro Control España para solicitar una evaluación hidráulica y conocer nuestras soluciones.">
    <link rel="canonical" href="https://www.aquahydrocontrol.com/contact.php">
    <meta property="og:title" content="Contacto Aqua Hydro Control España">
    <meta property="og:description" content="Solicita evaluación hidráulica y recibe asesoría técnica especializada.">
    <meta property="og:url" content="https://www.aquahydrocontrol.com/contact.php">
    <meta property="og:type" content="website">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/png" href="https://picsum.photos/64/64?water">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <a href="index.html" class="branding" aria-label="Aqua Hydro Control España inicio">
                <img src="https://picsum.photos/88/88?energy" alt="Logotipo simplificado de Aqua Hydro Control España">
                <div class="brand-meta">
                    <span>AquaHydroControl.com</span>
                    <strong>Aqua Hydro Control España</strong>
                </div>
            </a>
            <button class="nav-toggle" aria-label="Abrir menú de navegación" aria-expanded="false">
                <span class="sr-only">Abrir menú</span>
                ☰
            </button>
            <nav class="site-nav" aria-label="Navegación principal">
                <a href="index.html">Inicio</a>
                <a href="about.html">Empresa</a>
                <a href="solutions.html">Soluciones</a>
                <a href="technology.html">Tecnología</a>
                <a href="performance.html">Rendimiento</a>
                <a href="projects.html">Proyectos</a>
                <a href="contact.php" class="active-link">Contacto</a>
            </nav>
        </div>
    </header>
    <main>
        <section class="page-hero">
            <div class="container">
                <div>
                    <h1>Contacto y solicitud de evaluación hidráulica</h1>
                    <p>Coordina una sesión técnica con nuestros especialistas en ingeniería hidroeléctrica y analítica de datos.</p>
                </div>
            </div>
        </section>
        <section class="section">
            <div class="container">
                <div class="two-column-layout">
                    <form class="hero-mini-form" action="thanks.php" method="post" aria-label="Formulario de contacto">
                        <h3>Solicita tu evaluación</h3>
                        <div class="form-grid two-columns">
                            <div class="form-field">
                                <label for="nombre-contacto">Nombre y apellidos</label>
                                <input id="nombre-contacto" name="nombre" type="text" required autocomplete="name">
                            </div>
                            <div class="form-field">
                                <label for="email-contacto">Correo corporativo</label>
                                <input id="email-contacto" name="correo" type="email" required autocomplete="email">
                            </div>
                        </div>
                        <div class="form-field">
                            <label for="telefono-contacto">Teléfono</label>
                            <input id="telefono-contacto" name="telefono" type="tel" required autocomplete="tel">
                        </div>
                        <div class="form-field">
                            <label for="central-contacto">Central o proyecto</label>
                            <input id="central-contacto" name="central" type="text" required>
                        </div>
                        <div class="form-field">
                            <label for="mensaje-contacto">Descripción del objetivo</label>
                            <textarea id="mensaje-contacto" name="mensaje" required></textarea>
                        </div>
                        <button class="cta-button primary" type="submit">Enviar formulario</button>
                    </form>
                    <div>
                        <h2 class="section-title">Información de contacto</h2>
                        <p>Estamos disponibles para visitas en planta, auditorías y sesiones remotas de control y análisis.</p>
                        <ul class="highlight-list">
                            <li>
                                <strong>Dirección</strong>
                                <p>Torre Mapfre, Carrer de la Marina 16-18, 08005 Barcelona, España</p>
                            </li>
                            <li>
                                <strong>Teléfono</strong>
                                <p><a href="tel:+34932123456">+34 932 123 456</a></p>
                            </li>
                            <li>
                                <strong>Correo</strong>
                                <p><a href="mailto:contacto@aquahydrocontrol.com">contacto@aquahydrocontrol.com</a></p>
                            </li>
                        </ul>
                        <div class="map-embed">
                            <iframe title="Ubicación Aqua Hydro Control España" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2994.769846145343!2d2.193383115427001!3d41.38791617926483!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4a3e40dea03f1%3A0x7fc0a9b994ed245b!2sTorre%20Mapfre!5e0!3m2!1ses!2ses!4v1700000000000" width="100%" height="320" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <strong>Aqua Hydro Control España</strong>
                    <p>Gestión inteligente, monitorización en tiempo real y mantenimiento predictivo para centrales hidroeléctricas en todo el territorio español.</p>
                </div>
                <div class="footer-nav">
                    <a href="about.html">Historia y visión</a>
                    <a href="solutions.html">Portafolio de soluciones</a>
                    <a href="technology.html">Infraestructura tecnológica</a>
                    <a href="projects.html">Casos de éxito</a>
                    <a href="performance.html">Indicadores de rendimiento</a>
                </div>
                <div class="footer-contact">
                    <span>Torre Mapfre, Carrer de la Marina 16-18, 08005 Barcelona, España</span>
                    <a href="tel:+34932123456">+34 932 123 456</a>
                    <a href="mailto:contacto@aquahydrocontrol.com">contacto@aquahydrocontrol.com</a>
                </div>
                <div class="footer-nav">
                    <a href="privacy.html">Privacidad</a>
                    <a href="cookies.html">Cookies</a>
                    <a href="terms.html">Términos legales</a>
                    <a href="sitemap.xml">Mapa del sitio</a>
                </div>
            </div>
            <div class="footer-bottom">
                <span>© <?php echo date("Y"); ?> Aqua Hydro Control España. Todos los derechos reservados.</span>
                <span>Dominio principal: <a href="https://www.aquahydrocontrol.com">AquaHydroControl.com</a></span>
            </div>
        </div>
    </footer>
    <div class="cookie-banner" role="region" aria-live="polite" aria-label="Aviso de cookies">
        <h4>Preferencias de cookies</h4>
        <p>Utilizamos cookies para analizar el rendimiento hidráulico y mejorar la experiencia de supervisión. Puedes aceptar o rechazar, mantendremos tu elección.</p>
        <div class="cookie-actions">
            <button class="cookie-button reject" type="button">Rechazar</button>
            <button class="cookie-button accept" type="button">Aceptar</button>
        </div>
        <a href="cookies.html">Configurar detalles</a>
    </div>
    <script src="script.js" defer></script>
</body>
</html>