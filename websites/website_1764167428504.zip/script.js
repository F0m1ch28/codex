document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    const toggleNav = () => {
      const isOpen = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isOpen));
      navToggle.classList.toggle('is-open');
      mainNav.classList.toggle('is-open');
      document.body.classList.toggle('no-scroll');
    };

    navToggle.addEventListener('click', toggleNav);
    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.classList.remove('is-open');
        mainNav.classList.remove('is-open');
        document.body.classList.remove('no-scroll');
      });
    });
  }

  /* Cookie banner */
  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    try {
      const consent = localStorage.getItem('kalmorielle-cookie-consent');
      if (!consent) {
        cookieBanner.classList.add('show');
      }
      const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
      const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
      const handleConsent = value => {
        localStorage.setItem('kalmorielle-cookie-consent', value);
        cookieBanner.classList.remove('show');
      };
      if (acceptBtn) acceptBtn.addEventListener('click', () => handleConsent('accepted'));
      if (declineBtn) declineBtn.addEventListener('click', () => handleConsent('declined'));
    } catch (error) {
      console.warn('No es posible guardar la preferencia de cookies:', error);
    }
  }

  /* Planner slider */
  const microSlider = document.querySelector('#micro-slider');
  const minuteOutputs = document.querySelectorAll('[data-micro-minutes]');
  const impactOutputs = document.querySelectorAll('[data-micro-impact]');
  const progressBar = document.querySelector('[data-progress-bar]');

  const updatePlanner = () => {
    const value = microSlider ? parseInt(microSlider.value, 10) : 0;
    minuteOutputs.forEach(el => { el.textContent = value; });
    const impactValue = Math.round(value * 3.2);
    impactOutputs.forEach(el => { el.textContent = impactValue; });
    if (progressBar) {
      const percentage = Math.round((value / 60) * 100);
      progressBar.style.width = `${percentage}%`;
    }
  };

  if (microSlider) {
    updatePlanner();
    microSlider.addEventListener('input', updatePlanner);
  }

  /* FAQ accordion */
  const faqItems = document.querySelectorAll('[data-faq]');
  faqItems.forEach(item => {
    const button = item.querySelector('button');
    const content = item.querySelector('.faq-content');
    if (!button || !content) return;
    button.addEventListener('click', () => {
      const isOpen = item.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(isOpen));
    });
  });

  /* Intersection animations */
  const animatedElements = document.querySelectorAll('[data-animate]');
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!prefersReducedMotion && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    animatedElements.forEach(el => observer.observe(el));
  } else {
    animatedElements.forEach(el => el.classList.add('is-visible'));
  }
});