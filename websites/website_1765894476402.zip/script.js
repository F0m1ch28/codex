document.addEventListener('DOMContentLoaded', function () {
  var animateBlocks = document.querySelectorAll('.animate-up');
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    animateBlocks.forEach(function (block) {
      observer.observe(block);
    });
  } else {
    animateBlocks.forEach(function (block) {
      block.classList.add('is-visible');
    });
  }

  var banner = document.querySelector('.cookie-banner');
  if (!banner) {
    return;
  }
  var acceptBtn = banner.querySelector('.cookie-accept');
  var declineBtn = banner.querySelector('.cookie-decline');
  var consent = localStorage.getItem('cookieConsent');

  if (consent === 'accepted' || consent === 'declined') {
    banner.classList.remove('show');
  } else {
    setTimeout(function () {
      banner.classList.add('show');
    }, 800);
  }

  var hideBanner = function () {
    banner.classList.remove('show');
    banner.setAttribute('aria-hidden', 'true');
  };

  acceptBtn.addEventListener('click', function () {
    localStorage.setItem('cookieConsent', 'accepted');
    hideBanner();
  });

  declineBtn.addEventListener('click', function () {
    localStorage.setItem('cookieConsent', 'declined');
    hideBanner();
  });
});