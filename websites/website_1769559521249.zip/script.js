const I18N = {
  fr: {
    meta: {
      title: {
        home: "danswholesaleplants — Orientation spatiale et signalétique numérique",
        services: "Services d’orientation spatiale | danswholesaleplants",
        about: "À propos de danswholesaleplants",
        blog: "Carnet d’analyses — danswholesaleplants",
        contact: "Contact | danswholesaleplants",
        faq: "Questions fréquentes | danswholesaleplants",
        terms: "Conditions d’utilisation | danswholesaleplants",
        privacy: "Politique de confidentialité | danswholesaleplants",
        cookies: "Politique relative aux cookies | danswholesaleplants",
        refund: "Politique de révision | danswholesaleplants",
        disclaimer: "Clause de non-responsabilité | danswholesaleplants",
        thankyou: "Merci pour votre message | danswholesaleplants",
        post1: "Cartographie cognitive des pôles multimodaux",
        post2: "Mesurer la lisibilité de la signalétique numérique",
        post3: "Données sensibles pour la navigation intérieure",
        post4: "Cartographie participative des campus inclusifs",
        post5: "Simulations de parcours pour sites patrimoniaux"
      },
      description: {
        home: "Observatoire expert des systèmes d’orientation spatiale et de la signalétique numérique pour bâtiments publics et environnements urbains complexes.",
        services: "Aperçu des services analytiques de danswholesaleplants en matière de cartographie des espaces, de guidage visuel et d’expérience utilisateur spatiale.",
        about: "Informations sur la méthodologie, les valeurs et la trajectoire de danswholesaleplants, spécialiste belge de la navigation intérieure.",
        blog: "Analyses techniques dédiées à l’UX spatiale, aux plans interactifs et à la mobilité piétonne dans les infrastructures publiques.",
        contact: "Coordonnées et formulaire de contact pour joindre danswholesaleplants à Bruxelles concernant l’orientation spatiale.",
        faq: "Réponses aux principales questions sur les démarches d’analyse et de signalétique numérique proposées par danswholesaleplants.",
        terms: "Conditions d’utilisation du site danswholesaleplants décrivant responsabilités, droits et modalités de consultation.",
        privacy: "Politique de confidentialité détaillant la gestion des données collectées par danswholesaleplants.",
        cookies: "Informations complètes sur l’usage des cookies et la gestion des préférences sur danswholesaleplants.",
        refund: "Procédure de révision et de correction des livrables éditorialisés par danswholesaleplants.",
        disclaimer: "Clause de non-responsabilité précisant les limites d’usage des informations publiées par danswholesaleplants.",
        thankyou: "Confirmation de réception et prochaine étape après un message envoyé à danswholesaleplants.",
        post1: "Analyse approfondie de la cartographie cognitive dans les pôles multimodaux pour optimiser la navigation intérieure.",
        post2: "Étude des indicateurs de lisibilité pour la signalétique numérique et leur impact sur la compréhension des usagers.",
        post3: "Synthèse sur la mobilisation des données sensibles et contextuelles dans la conception de parcours intérieurs.",
        post4: "Dossier sur la cartographie participative appliquée aux campus inclusifs et à la mobilité douce.",
        post5: "Exploration des simulations de parcours dans les sites patrimoniaux et exigences de conservation."
      }
    },
    header: {
      logo: "danswholesaleplants",
      nav: {
        home: "Accueil",
        services: "Services",
        about: "À propos",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      menuToggleLabel: "Basculer la navigation principale"
    },
    language: {
      fr: "FR",
      en: "EN"
    },
    footer: {
      logo: "danswholesaleplants",
      description: "Études et prototypes de signalétique numérique, de navigation intérieure et d’UX spatiale pour infrastructures publiques et environnements bâtis complexes.",
      address: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
      phone: "+32 2 123 45 67",
      email: "contact@danswholesaleplants.com",
      legal: {
        terms: "Conditions d’utilisation",
        privacy: "Confidentialité",
        cookies: "Cookies",
        refund: "Politique de révision",
        disclaimer: "Clause de non-responsabilité"
      },
      footnote: "Observatoire indépendant dédié à l’orientation spatiale et à la signalétique numérique.",
      rights: "© {year} danswholesaleplants. Tous droits réservés."
    },
    home: {
      hero: {
        eyebrow: "Infrastructure publique",
        title: "Cartographier les parcours qui structurent les espaces civiques",
        subtitle: "danswholesaleplants étudie l’orientation spatiale, les systèmes de signalétique numérique et la mobilité piétonne pour renforcer la lisibilité des bâtiments publics et des environnements urbains complexes.",
        primary: "Explorer les services",
        secondary: "Lire les analyses récentes",
        imageAlt: "Plan numérique interactif visualisant un hall public"
      },
      pillars: {
        title: "Trois axes pour rendre les parcours compréhensibles",
        intro: "Nos missions associent cartographie des espaces, scénarisation des flux et design informationnel afin d’accompagner chaque projet avec une lecture systémique.",
        card1: {
          title: "Diagnostics de perception spatiale",
          text: "Analyse des obstacles cognitifs, audit des repères et mesure des seuils de lisibilité dans les environnements bâtis.",
          point1: "Cartographie des points de décision critiques",
          point2: "Observation in situ des trajectoires piétonnes",
          point3: "Indicateurs visuels d’encombrement informationnel"
        },
        card2: {
          title: "Signalétique numérique et cartographie",
          text: "Co-conception de plans interactifs, scénarisation des contenus en temps réel et hiérarchisation des messages de guidage.",
          point1: "Matrices de contenus multilingues",
          point2: "Prototypage de vues 2D et 3D",
          point3: "Gestion des flux saisonniers et événementiels"
        },
        card3: {
          title: "Expérience utilisateur spatiale",
          text: "Modélisation des parcours, simulation des temps de transfert et évaluation des points d’effort pour des déplacements fluides.",
          point1: "Segments de personas piétonnes",
          point2: "Chronométrage des micro-transitions",
          point3: "Lecture inclusive des infrastructures"
        }
      },
      metrics: {
        title: "Repères méthodologiques et terrain",
        intro: "Nos indicateurs combinent observation directe, cartographie numérique et retours qualifiés pour situer les évolutions d’usage.",
        item1: { value: "68", label: "Parcours usagers cartographiés sur trois régions" },
        item2: { value: "24", label: "Matrices de signalétique numérique harmonisées" },
        item3: { value: "325", label: "Entretiens qualitatifs menés auprès de publics variés" }
      },
      analysis: {
        title: "Analyser la densité informationnelle pour guider les flux",
        paragraph1: "Nous superposons données d’affluence et repères physiques pour qualifier la perception des espaces. Cette approche identifie les ruptures de continuité visuelle et les zones de forte sollicitation cognitive.",
        paragraph2: "Les visualisations géospatiales permettent de hiérarchiser les interventions : insertion d’écrans directionnels, repositionnement des plans fixes, ou requalification des repères lumineux.",
        point1: "Cartographie des gradients lumineux et sonores",
        point2: "Matrices de visibilité selon les angles de circulation",
        point3: "Modèles de priorisation basés sur l’intensité de flux",
        imageAlt: "Analyse graphique des flux piétons et de la signalétique"
      },
      recommendations: {
        title: "Recommandations récentes",
        intro: "Chaque livrable s’appuie sur des preuves de terrain, des données spatiales et une rédaction accessible aux gestionnaires comme aux équipes techniques.",
        card1: {
          title: "Plan directeur de navigation",
          text: "Définition d’une structure unique pour les messages directionnels, intégrant niveaux, zones et destinations prioritaires.",
          point1: "Regroupement des terminologies par familles d’espaces",
          point2: "Progression harmonisée des repères iconographiques"
        },
        card2: {
          title: "Tableau de bord de lisibilité",
          text: "Indicateurs partagés pour suivre la performance des dispositifs numériques et analogiques au fil des saisons.",
          point1: "Benchmarks croisés avec les temps de parcours",
          point2: "Alertes en cas de surcharge informationnelle"
        },
        card3: {
          title: "Guide d’usage des médias dynamiques",
          text: "Cadre de diffusion des contenus en fonction des typologies d’usagers, des horaires et des contraintes d’accessibilité.",
          point1: "Séquençage des messages contextuels",
          point2: "Protocoles de mise à jour multilingue"
        }
      },
      testimonials: {
        title: "Retours d’acteurs publics",
        intro: "Les partenaires témoignent des bénéfices obtenus en matière de lisibilité, de maîtrise des flux et de concertation.",
        quote1: {
          text: "La synthèse produite sur notre campus a permis d’articuler signalétique historique et écrans interactifs sans confusion pour les visiteurs.",
          author: "Charlotte Meyers",
          role: "Responsable accessibilité, réseau universitaire"
        },
        quote2: {
          text: "Les parcours simulés dans la gare ont mis en évidence des angles morts que nous n’avions jamais objectivés, ce qui a orienté nos priorités.",
          author: "Léonard De Keyser",
          role: "Coordinateur intermodalité, autorité de transport"
        },
        quote3: {
          text: "La matrice de contenus nous sert désormais de référentiel pour toutes les instances du bâtiment, de l’accueil au musée.",
          author: "Amina Laurent",
          role: "Responsable médiation, institution culturelle"
        }
      },
      blog: {
        title: "Notes d’analyse",
        intro: "Lectures approfondies consacrées aux systèmes de signalétique, aux usages hybrides et aux enjeux d’accessibilité.",
        card1: { imageAlt: "Signalétique immersive dans un pôle multimodal" },
        card2: { imageAlt: "Interface de plan interactif affichée sur un mur" },
        card3: { imageAlt: "Vue axonométrique d’un bâtiment avec parcours" }
      }
    },
    services: {
      hero: {
        eyebrow: "Méthodes",
        title: "Des services d’analyse pour clarifier les parcours",
        subtitle: "Nous intervenons en amont des projets pour documenter les besoins d’orientation spatiale et structurer les dispositifs numériques ou physiques.",
        imageAlt: "Collaborateurs commentant un schéma de navigation intérieure"
      },
      overview: {
        title: "Cartographie complète des besoins",
        text: "Chaque service combine études terrain, lectures cartographiques et ateliers de convergence pour consolider une vision partagée."
      },
      items: {
        item1: {
          title: "Analyse des besoins spatiaux",
          text: "Repérage des obstacles, relevés photographiques et synthèse des points de décision dans les bâtiments complexes.",
          point1: "Inventaire des dispositifs existants",
          point2: "Cartes thermiques des flux piétonniers",
          point3: "Matrices des besoins selon les publics"
        },
        item2: {
          title: "Design de signalétique numérique",
          text: "Structuration des contenus et scénarisation des supports digitaux pour une intégration harmonieuse avec la signalétique fixe.",
          point1: "Charte de contenus multicanal",
          point2: "Prototypage d’interfaces interactives",
          point3: "Tests d’usage iteratifs"
        },
        item3: {
          title: "Modèles de parcours utilisateurs",
          text: "Construction de scénarios pour aligner les flux sur les objectifs de service et anticiper les situations particulières.",
          point1: "Personas de mobilité piétonne",
          point2: "Chronologies des parcours typiques",
          point3: "Cartographie des points de friction"
        },
        item4: {
          title: "Conseil en guidage visuel",
          text: "Audit des langages graphiques, distances de lecture et contrastes afin de garantir une lecture universelle.",
          point1: "Mesure de la lisibilité à différentes échelles",
          point2: "Recommandations typographiques",
          point3: "Architecture des panneaux et écrans"
        },
        item5: {
          title: "Recherche sur l’accessibilité",
          text: "Études spécifiques sur l’usage par publics à besoins divers, du repérage tactile aux aides sonores.",
          point1: "Ateliers avec associations spécialisées",
          point2: "Évaluation des dispositifs complémentaires",
          point3: "Intégration des normes d’accessibilité"
        }
      },
      process: {
        title: "Processus collaboratif et itératif",
        paragraph1: "Nous coordonnons données quantitatives, observations qualitatives et co-création pour produire des livrables opérationnels.",
        paragraph2: "Chaque étape est documentée pour faciliter la prise de décision et la diffusion auprès des équipes gestionnaires.",
        step1: "Phase exploratoire : collecte de données et repérages",
        step2: "Phase de modélisation : scénarisation des flux et prototypes",
        step3: "Phase de convergence : recommandations et feuille de route",
        imageAlt: "Tableau dynamique présentant un processus en plusieurs étapes"
      },
      outcomes: {
        title: "Livrables structurants",
        intro: "Les sorties de mission facilitent l’appropriation par les équipes internes et partenaires institutionnels.",
        card1: {
          title: "Atlas spatial",
          text: "Compilation cartographique géoréférencée décrivant trajectoires, points d’intérêt et hiérarchie des repères."
        },
        card2: {
          title: "Guide de gouvernance",
          text: "Organisation des responsabilités et protocoles de maintenance pour assurer la cohérence des contenus."
        },
        card3: {
          title: "Tableau de pilotage",
          text: "Indicateurs de suivi pour mesurer l’effet des ajustements et orchestrer les futures extensions."
        }
      }
    },
    about: {
      hero: {
        eyebrow: "Vision",
        title: "Comprendre les espaces publics pour fluidifier les déplacements",
        subtitle: "danswholesaleplants crée des cadres d’analyse qui relient données, usages et architecture pour renforcer la compréhension des lieux.",
        imageAlt: "Réunion autour d’une maquette de bâtiment public"
      },
      mission: {
        title: "Mission",
        paragraph1: "Nous aidons les organisations publiques à transformer les espaces complexes en trajectoires intuitives en rendant visibles les logiques cachées.",
        paragraph2: "Notre approche associe ethnographie des usages, compilation cartographique et design d’information pour aboutir à des recommandations précises.",
        imageAlt: "Observations sur site dans un hall municipal"
      },
      values: {
        title: "Principes directeurs",
        intro: "Trois valeurs structurent nos interventions, de l’étude initiale jusqu’au transfert documentaire.",
        card1: {
          title: "Evidence first",
          text: "Chaque recommandation repose sur des preuves observables, des mesures ou des récits situés."
        },
        card2: {
          title: "Accessibilité active",
          text: "Les solutions intègrent systématiquement les besoins de publics diversifiés dès la conception."
        },
        card3: {
          title: "Transparence documentaire",
          text: "Les données, cartes et décisions sont traçables, partageables et prêtes à être mises à jour."
        }
      },
      timeline: {
        title: "Étapes clés",
        intro: "Une progression continue vers des outils toujours plus intégrés et interopérables.",
        stage1: {
          title: "2016 — Premiers audits",
          text: "Évaluations qualitatives des cheminements dans les gares belges et constitution de référentiels de lisibilité."
        },
        stage2: {
          title: "2019 — Plateforme cartographique",
          text: "Déploiement d’une base de données géospatiale pour croiser flux observés et retours d’usagers."
        },
        stage3: {
          title: "2022 — Laboratoire d’UX spatiale",
          text: "Création d’un cadre de tests multi-sensoriels dédié aux environnements hybrides physique-numérique."
        }
      },
      research: {
        title: "Recherche continue",
        paragraph1: "Nous produisons veilles, prototypes et évaluations comparatives afin d’anticiper les évolutions d’usage.",
        paragraph2: "Les travaux sont partagés avec les collectivités pour nourrir les politiques d’accessibilité et de mobilité.",
        point1: "Veille sur les standards de cartographie interactive",
        point2: "Comparaison internationale des codes de signalétique",
        point3: "Analyse des effets de densité sur les repères",
        imageAlt: "Graphiques de recherche et modèles de données"
      }
    },
    blog: {
      hero: {
        eyebrow: "Analyses",
        title: "Études de terrain et modélisations",
        subtitle: "Articles détaillés consacrés aux trajectoires, à la signalétique numérique et aux méthodologies de navigation intérieure.",
        imageAlt: "Equipe analysant un mur de cartes et de données"
      },
      listing: {
        readMore: "Consulter l’analyse",
        posts: {
          post1: {
            date: "10 mars 2024",
            reading: "Lecture : 7 min",
            title: "Cartographie cognitive des pôles multimodaux",
            excerpt: "Repérer les nœuds décisionnels dans les pôles multimodaux impose de croiser données de flux, récits d’usagers et observations fines des repères physiques.",
            imageAlt: "Correspondances multimodales avec cartes lumineuses"
          },
          post2: {
            date: "28 février 2024",
            reading: "Lecture : 8 min",
            title: "Mesurer la lisibilité de la signalétique numérique",
            excerpt: "La lisibilité des supports numériques dépend de la cohérence des contenus, du contraste et de la synchronisation avec la signalétique fixe.",
            imageAlt: "Signalétique numérique affichant directions et horaires"
          },
          post3: {
            date: "12 février 2024",
            reading: "Lecture : 7 min",
            title: "Données contextuelles pour la navigation intérieure",
            excerpt: "Les données contextuelles enrichissent les parcours intérieurs lorsqu’elles respectent les règles d’usage, de pertinence temporelle et de sobriété.",
            imageAlt: "Plan interactif affiché dans un bâtiment public"
          },
          post4: {
            date: "29 janvier 2024",
            reading: "Lecture : 9 min",
            title: "Cartographie participative pour campus inclusifs",
            excerpt: "Impliquer les communautés estudiantines permet de rechiffrer les parcours sensibles et de corriger les repères manquants.",
            imageAlt: "Atelier participatif de cartographie sur campus"
          },
          post5: {
            date: "15 janvier 2024",
            reading: "Lecture : 8 min",
            title: "Simulations pour sites patrimoniaux",
            excerpt: "Les simulations éclairent les contraintes de conservation tout en favorisant l’accueil des visiteurs et la fluidité des déplacements.",
            imageAlt: "Parcours simulé dans un site patrimonial"
          }
        }
      },
      post1: {
        eyebrow: "Étude",
        title: "Cartographie cognitive des pôles multimodaux",
        subtitle: "Comment modéliser l’orientation dans des interconnexions ferroviaires denses sans perdre la lisibilité des repères ?",
        imageAlt: "Voyageurs observant un plan numérique dans une gare",
        content: `
          <section>
            <p>Les pôles multimodaux constituent des environnements où la densité informationnelle dépasse largement celle des bâtiments publics classiques. Les usagers doivent filtrer des messages contradictoires, anticiper des croisements de flux et composer avec des temporalités strictes. Pour éclairer ces situations, la cartographie cognitive combine relevés qualitatifs et mesures quantitatives, offrant un panorama fiable des difficultés d’orientation.</p>
            <h2>Segmenter les parcours plutôt que les destinations</h2>
            <p>La première étape consiste à décomposer les trajets en segments décisionnels. Chaque segment est défini par une intention claire — rejoindre un quai, atteindre une sortie, accéder à un service — et par une séquence de repères. Nous analysons la cohérence des codes visuels, la stabilité des terminologies et la présence de redondances. Lorsque les segments se superposent, la cartographie met en évidence les points de surcharge cognitive qui réclament une rationalisation.</p>
            <p>Cette segmentation révèle également la manière dont les voyageurs hiérarchisent les signaux. Les panneaux suspendus sont perçus comme des sources à forte priorité, tandis que les écrans secondaires jouent un rôle d’arbitrage pour confirmer un choix. Nous notons que la confiance accordée aux dispositifs numériques dépend de leur synchronisation avec les annonces vocales et les panneaux statiques.</p>
            <h3>Identifier les nœuds critiques et les angles morts</h3>
            <p>Les nœuds critiques regroupent plusieurs flux qui convergent dans un laps de temps réduit. Les études menées à Bruxelles-Midi montrent que trois nœuds concentrent 40 % des hésitations observées. Ces zones possèdent souvent des géométries complexes, des hauteurs sous plafond variables et des ouvertures latérales multiples. La cartographie cognitive s’attache à retracer les trajectoires alternatives pour vérifier si des itinéraires plus fluides existent.</p>
            <p>Les angles morts, eux, se manifestent lorsque la signalétique ne couvre pas un champ visuel essentiel au moment d’une décision. Nous avons documenté des cas où des escalators masquent un panneau principal ou où des écrans sont orientés vers des flux sortants plutôt qu’entrants. L’analyse se traduit alors par des propositions concrètes : inverser un écran, déplacer un panneau de quelques mètres ou introduire un repère lumineux dans la ligne de mire.</p>
            <p>Nous utilisons également des observations nocturnes pour examiner la lisibilité lorsque la lumière naturelle disparaît. Les contrastes évoqués en journée perdent leur efficacité, ce qui invite à renforcer certains repères et à synchroniser la luminosité des écrans avec les niveaux d’éclairage ambiant.</p>
            <p>Au total, la cartographie cognitive d’un pôle multimodal vise à restituer l’expérience vécue avec suffisamment de précision pour que chaque ajustement soit mesurable. Les cartes dynamiques et les journaux de bord des usagers servent de matériau partagé entre opérateurs, architectes et spécialistes de la mobilité.</p>
          </section>
        `
      },
      post2: {
        eyebrow: "Recherche",
        title: "Mesurer la lisibilité de la signalétique numérique",
        subtitle: "Quels indicateurs adopter pour évaluer la clarté des supports digitaux dans les bâtiments publics ?",
        imageAlt: "Écran numérique affichant une carte interactive dans un hall",
        content: `
          <section>
            <p>La signalétique numérique devient un pivot des stratégies d’orientation dans les espaces complexes. Pourtant, la lisibilité de ces supports reste difficile à mesurer sans protocoles précis. Nous avons élaboré un cadre d’évaluation qui combine des tests utilisateurs, des mesures optiques et des indicateurs de cohérence informationnelle.</p>
            <h2>Structurer un corpus de contenus contrôlé</h2>
            <p>Avant toute mesure, il est essentiel de stabiliser la structure des contenus diffusés. Nous définissons des gabarits avec un nombre limité de niveaux hiérarchiques, une palette chromatique normée et des terminologies validées par les gestionnaires. Ce corpus permet de tester la compréhension sans bruit parasite lié à des variations de vocabulaire ou de graphisme.</p>
            <p>Les tests se déroulent en situation réelle : chaque participant reçoit un itinéraire et doit s’appuyer sur les supports numériques pour progresser. Nous enregistrons les temps de lecture, les hésitations, les retours en arrière et la mémorisation des informations clés. L’objectif est de déterminer le seuil au-delà duquel le contenu devient trop dense.</p>
            <h3>Mesures optiques et corroboration qualitative</h3>
            <p>Les études s’accompagnent de mesures de luminance et de contraste. Nous évaluons la lisibilité relative selon les distances usuelles : 2 mètres pour un écran d’orientation, 5 mètres pour une annonce générale. Les résultats sont confrontés aux retours des participants afin d’identifier l’impact réel des réglages optiques sur la compréhension.</p>
            <p>Un autre indicateur clé concerne la synchronisation entre supports numériques et signalétique fixe. Lorsque les deux systèmes emploient des terminologies divergentes, les usagers perdent confiance et cherchent une confirmation externe, ce qui ralentit le flux. Nous préconisons d’aligner les contenus via une matrice commune, alimentée par un référentiel partagé.</p>
            <p>Les essais montrent enfin que la lisibilité repose sur une mise à jour maîtrisée : trop de variations en temps réel fatiguent les usagers. Nous recommandons des cycles de rafraîchissement adaptés à chaque message, en conservant des repères constants tout au long du parcours.</p>
          </section>
        `
      },
      post3: {
        eyebrow: "Analyse",
        title: "Données contextuelles pour la navigation intérieure",
        subtitle: "Comment intégrer des données sensibles sans perturber l’expérience de guidage dans les bâtiments ?",
        imageAlt: "Interface cartographique affichant des capteurs de présence",
        content: `
          <section>
            <p>Les données contextuelles enrichissent la navigation intérieure lorsqu’elles sont pertinentes, parcimonieuses et correctement synchronisées. L’enjeu consiste à traduire des signaux souvent techniques en repères compréhensibles par tous les publics. Notre approche privilégie l’intégration progressive, en commençant par des informations essentielles au parcours.</p>
            <h2>Qualifier les données avant de les afficher</h2>
            <p>La phase de qualification sert à déterminer si une donnée apporte une aide concrète à l’orientation. Un capteur de densité peut indiquer une saturation temporaire d’un couloir, mais il devient intrusif s’il change de couleur toutes les dix secondes. Nous établissons des seuils de publication pour éviter l’effet stroboscopique et maintenir un message stable le temps d’une décision.</p>
            <p>Cette qualification passe également par un contrôle de provenance : seules les sources vérifiées et résilientes sont retenues. En cas de panne, des valeurs par défaut sont prévues pour ne pas désorienter les usagers. Le glossaire qui accompagne les données garantit une compréhension uniforme des pictogrammes et des termes.</p>
            <h3>Mettre en scène les informations avec parcimonie</h3>
            <p>La scénarisation consiste à sélectionner les moments propices et le support adéquat pour afficher une donnée contextuelle. Dans un bâtiment administratif, un message sur l’affluence d’un service est pertinent à l’entrée du hall, mais inutile à proximité immédiate du guichet. Les plans interactifs peuvent intégrer des couches additionnelles que l’usager active volontairement, limitant la surcharge visuelle.</p>
            <p>Nous privilégions une hiérarchie claire : information essentielle, conseils contextuels, contenus exploratoires. Cette gradation favorise l’appropriation progressive et respecte la charge cognitive des visiteurs occasionnels.</p>
            <p>Enfin, la gouvernance joue un rôle majeur. Les responsables doivent pouvoir modérer les données, suspendre un flux ou ajuster la fréquence de publication. La documentation fournit des procédures de contrôle pour assurer la cohérence à long terme.</p>
          </section>
        `
      },
      post4: {
        eyebrow: "Cas d’étude",
        title: "Cartographie participative pour campus inclusifs",
        subtitle: "Impliquer les communautés pour revisiter les trajectoires étudiantes et les services essentiels.",
        imageAlt: "Groupe participant à un atelier cartographique sur campus",
        content: `
          <section>
            <p>Un campus universitaire représente une mosaïque d’espaces aux usages variés, fréquemment modifiés par des travaux ou des événements temporaires. Pour maintenir une navigation intuitive, nous avons co-construit une cartographie participative avec les communautés étudiantes, les services administratifs et les équipes techniques.</p>
            <h2>Récolter les parcours vécus</h2>
            <p>La première phase a consisté à collecter des parcours vécus via des ateliers et des journaux de déplacement. Les participants décrivent les repères utilisés, les obstacles rencontrés et les stratégies d’orientation adoptées. Ces récits sont géolocalisés afin de repérer les points de rupture dans la continuité des cheminements.</p>
            <p>Les cartes révélent des divergences notables entre étudiants résidents et visiteurs occasionnels. Les premiers se fient à des raccourcis non signalés, tandis que les seconds privilégient les axes principaux mais se heurtent à des carrefours peu lisibles. La cartographie met en lumière des besoins d’éclairage supplémentaire, de signalétique tactile et de guides temporaires durant les travaux.</p>
            <h3>Co-concevoir les supports</h3>
            <p>À partir des données collectées, nous co-concevons des supports numériques et analogiques. Les plans interactifs proposent des filtres par profil : mobilité réduite, priorité aux espaces d’étude, orientation vers les services sociaux. Les panneaux physiques sont réorganisés pour renforcer la cohérence terminologique et intégrer des repères sensibles aux personnes neurodivergentes.</p>
            <p>Un comité de suivi, composé d’étudiants volontaires et de professionnels, supervise la mise à jour des contenus. Les retours sont intégrés via une plateforme ouverte, ce qui maintient l’engagement collectif et garantit la pertinence des informations.</p>
            <p>Ce travail participatif démontre que la confiance envers la signalétique augmente lorsque les usagers contribuent à sa conception. Le campus devient plus lisible, les parcours se diversifient et les services critiques gagnent en visibilité.</p>
          </section>
        `
      },
      post5: {
        eyebrow: "Perspective",
        title: "Simulations pour sites patrimoniaux",
        subtitle: "Articuler conservation et fluidité des parcours dans des bâtiments historiques exigeants.",
        imageAlt: "Simulation numérique de visiteurs dans un site patrimonial",
        content: `
          <section>
            <p>Les sites patrimoniaux cumulent contraintes : conservation des matériaux, respect de l’esthétique, gestion de flux touristiques variables. Les simulations de parcours constituent un outil précieux pour anticiper les ajustements nécessaires sans altérer l’intégrité du lieu.</p>
            <h2>Composer avec la fragilité des espaces</h2>
            <p>Nous analysons d’abord les zones sensibles — sols, ornements, structures fragiles — afin de limiter les interventions physiques. Les simulations intègrent ces contraintes en proposant des solutions réversibles, telles que des repères projetés, des dispositifs lumineux temporaires ou des supports autoportants.</p>
            <p>Les parcours sont modélisés selon différents profils : groupes accompagnés, visiteurs individuels, personnes à mobilité réduite. Chaque scénario teste la capacité des espaces à absorber les flux et identifie les zones où la densité doit être modulée par des messages préventifs ou des systèmes de réservation.</p>
            <h3>Rendre la médiation lisible sans surcharge</h3>
            <p>La médiation culturelle doit coexister avec les indications directionnelles sans saturer l’attention. Nous recommandons de dissocier les niveaux d’information, en réservant la signalétique directionnelle à des supports sobres et en exploitant des parcours audio ou numériques pour les contenus enrichis.</p>
            <p>Les simulations permettent également d’estimer l’impact des saisons touristiques et des événements ponctuels. Les plans interactifs peuvent être mis à jour pour refléter les changements temporaires tout en conservant une ossature stable, gage de confiance pour les équipes de conservation.</p>
            <p>En conciliant patrimoine et expérience usager, les sites historiques gagnent en clarté sans compromettre leur identité. Les simulations offrent un langage commun entre conservateurs, médiateurs et gestionnaires des flux.</p>
          </section>
        `
      }
    },
    contact: {
      hero: {
        eyebrow: "Coordonnées",
        title: "Dialoguer avec les acteurs de l’espace public",
        subtitle: "Discutons de vos projets d’orientation, de signalétique numérique ou d’accessibilité.",
        imageAlt: "Réunion de travail avec cartes et maquettes"
      },
      details: {
        title: "Entrer en relation",
        paragraph: "Nous répondons aux institutions publiques, aux opérateurs de mobilité et aux collectifs travaillant sur les environnements bâtis.",
        block1: {
          title: "Contact direct",
          phone: "+32 2 123 45 67",
          email: "contact@danswholesaleplants.com",
          address: "Rue de la Loi 155, 1040 Bruxelles"
        },
        block2: {
          title: "Disponibilités",
          text1: "Réunions exploratoires à distance ou sur site selon les contraintes logistiques.",
          text2: "Documentation de cadrage transmise avant tout déplacement."
        }
      },
      form: {
        title: "Formulaire de contact",
        intro: "Exposez votre contexte, les espaces concernés et vos objectifs. Nous revenons vers vous sous cinq jours ouvrables.",
        nameLabel: "Nom complet",
        namePlaceholder: "Votre nom",
        emailLabel: "Adresse électronique",
        emailPlaceholder: "vous@exemple.be",
        orgLabel: "Organisation",
        orgPlaceholder: "Nom de votre structure",
        messageLabel: "Message",
        messagePlaceholder: "Décrivez le contexte spatial ou la problématique",
        submit: "Envoyer"
      },
      map: {
        title: "Localisation bruxelloise",
        caption: "Nos travaux de terrain s’articulent autour de Bruxelles et des principales villes belges.",
        iframeTitle: "Carte de Bruxelles localisant danswholesaleplants"
      }
    },
    faq: {
      hero: {
        eyebrow: "Comprendre notre approche",
        title: "Questions fréquentes",
        subtitle: "Réponses aux interrogations liées à nos méthodes, nos livrables et notre périmètre.",
        imageAlt: "Plan schématique avec annotations techniques"
      },
      intro: {
        title: "Synthèse",
        text: "Si votre question ne figure pas ici, contactez-nous pour approfondir la démarche adaptée à votre contexte."
      },
      items: {
        item1: {
          question: "Quels environnements analysez-vous prioritairement ?",
          answer: "Nous travaillons sur les bâtiments publics, équipements culturels, campus, gares et réseaux intermodaux nécessitant une harmonisation de la signalétique."
        },
        item2: {
          question: "Intervenez-vous sur des projets existants ou en conception ?",
          answer: "Les deux. Nous auditons des dispositifs déjà en place et accompagnons les équipes de conception pour orienter les futurs déploiements."
        },
        item3: {
          question: "Comment intégrez-vous les publics à besoins spécifiques ?",
          answer: "Des ateliers dédiés et des tests avec des associations partenaires garantissent la prise en compte des critères d’accessibilité universelle."
        },
        item4: {
          question: "Livrez-vous des plans d’exécution ?",
          answer: "Nous fournissons des recommandations détaillées, des gabarits et des référentiels permettant aux prestataires spécialisés de produire les plans d’exécution."
        },
        item5: {
          question: "Quelle est la durée moyenne d’une mission ?",
          answer: "Selon l’étendue du site, une mission dure entre six et douze semaines, incluant terrain, modélisation et restitution.",
        },
        item6: {
          question: "Proposez-vous un suivi après la mission ?",
          answer: "Oui, nous proposons des sessions de suivi pour vérifier l’implémentation des recommandations et ajuster les priorités."
        }
      }
    },
    terms: {
      hero: {
        eyebrow: "Cadre d’usage",
        title: "Conditions d’utilisation",
        subtitle: "Dispositions applicables à la consultation du site danswholesaleplants.com."
      },
      content: `
        <section>
          <h2>1. Objet du document</h2>
          <p>Les présentes conditions encadrent l’accès et l’utilisation du site danswholesaleplants.com. Elles précisent les responsabilités respectives de l’éditeur et des visiteurs.</p>
        </section>
        <section>
          <h2>2. Acceptation des conditions</h2>
          <p>En consultant ce site, vous acceptez sans réserve ces conditions. Toute utilisation contraire à ces dispositions est interdite.</p>
        </section>
        <section>
          <h2>3. Public concerné</h2>
          <p>Le site s’adresse aux institutions publiques, aux opérateurs de mobilité, aux professionnels de l’architecture et aux citoyens intéressés par l’orientation spatiale.</p>
        </section>
        <section>
          <h2>4. Contenus publiés</h2>
          <p>Les contenus éditoriaux, analyses et visuels sont fournis à titre informatif. Ils reflètent un état de recherche à la date de publication.</p>
        </section>
        <section>
          <h2>5. Exactitude des informations</h2>
          <p>Nous veillons à la fiabilité des informations. Toutefois, des évolutions peuvent intervenir sans notification préalable. Aucune garantie d’exhaustivité n’est accordée.</p>
        </section>
        <section>
          <h2>6. Propriété intellectuelle</h2>
          <p>Les textes, graphiques, logos et bases de données sont protégés. Toute reproduction nécessite une autorisation écrite.</p>
        </section>
        <section>
          <h2>7. Hyperliens</h2>
          <p>Le site peut contenir des liens vers des ressources externes. Nous n’assumons aucune responsabilité concernant leur contenu ou leur disponibilité.</p>
        </section>
        <section>
          <h2>8. Utilisation conforme</h2>
          <p>Les visiteurs s’engagent à ne pas altérer le bon fonctionnement du site, ni à introduire de contenu malveillant.</p>
        </section>
        <section>
          <h2>9. Comptes utilisateurs</h2>
          <p>Aucun compte n’est requis pour consulter le site. Si un accès restreint est proposé, les identifiants fournis restent confidentiels.</p>
        </section>
        <section>
          <h2>10. Données collectées</h2>
          <p>Les données traitées sont décrites dans la politique de confidentialité. Elles sont utilisées dans le respect du cadre légal applicable en Belgique.</p>
        </section>
        <section>
          <h2>11. Responsabilité</h2>
          <p>L’éditeur ne peut être tenu responsable des dommages résultant d’une mauvaise interprétation des contenus ou d’une indisponibilité temporaire.</p>
        </section>
        <section>
          <h2>12. Maintenance</h2>
          <p>Des opérations techniques peuvent entraîner une interruption du service. Nous mettons tout en œuvre pour les limiter.</p>
        </section>
        <section>
          <h2>13. Modifications</h2>
          <p>Les conditions peuvent être modifiées à tout moment. La version en ligne fait foi.</p>
        </section>
        <section>
          <h2>14. Droit applicable</h2>
          <p>Les présentes conditions sont soumises au droit belge. Tout litige relève des juridictions compétentes de Bruxelles.</p>
        </section>
      `
    },
    privacy: {
      hero: {
        eyebrow: "Protection des données",
        title: "Politique de confidentialité",
        subtitle: "Informations sur la collecte, l’usage et la protection des données personnelles."
      },
      content: `
        <section>
          <h2>1. Responsable du traitement</h2>
          <p>Le site danswholesaleplants.com est édité par danswholesaleplants, basé Rue de la Loi 155, 1040 Bruxelles. Pour toute question concernant les données, contactez contact@danswholesaleplants.com.</p>
        </section>
        <section>
          <h2>2. Données collectées</h2>
          <p>Nous collectons les informations volontairement transmises via le formulaire de contact : nom, adresse électronique, organisation, description du projet.</p>
        </section>
        <section>
          <h2>3. Finalités</h2>
          <p>Ces données servent à répondre aux demandes, préparer des échanges et envoyer les documents nécessaires à la mission.</p>
        </section>
        <section>
          <h2>4. Base légale</h2>
          <p>Le traitement s’appuie sur l’intérêt légitime de répondre aux sollicitations professionnelles et sur le consentement explicite lors de l’envoi du formulaire.</p>
        </section>
        <section>
          <h2>5. Durée de conservation</h2>
          <p>Les données sont conservées le temps nécessaire au suivi de la demande et au maximum douze mois après le dernier contact sans suite.</p>
        </section>
        <section>
          <h2>6. Destinataires</h2>
          <p>Les informations ne sont pas transmises à des tiers, sauf obligation légale ou accord explicite de la personne concernée.</p>
        </section>
        <section>
          <h2>7. Sécurité</h2>
          <p>Nous mettons en œuvre des mesures organisationnelles et techniques pour protéger les données contre toute divulgation ou accès non autorisé.</p>
        </section>
        <section>
          <h2>8. Droits des personnes</h2>
          <p>Vous disposez de droits d’accès, de rectification, de limitation et d’effacement. Pour les exercer, écrivez à contact@danswholesaleplants.com.</p>
        </section>
        <section>
          <h2>9. Cookies</h2>
          <p>Le détail des cookies utilisés est présenté dans la politique dédiée. Vous pouvez modifier vos préférences à tout moment.</p>
        </section>
        <section>
          <h2>10. Modifications</h2>
          <p>La présente politique peut être adaptée pour refléter l’évolution de nos pratiques. La date de mise à jour est indiquée au bas de la page.</p>
        </section>
      `
    },
    cookies: {
      hero: {
        eyebrow: "Paramétrage",
        title: "Politique relative aux cookies",
        subtitle: "Comprendre les cookies utilisés et gérer vos préférences."
      },
      content: {
        intro: `
          <section>
            <h2>Usage des cookies</h2>
            <p>Les cookies sont de petits fichiers enregistrés sur votre appareil afin de mémoriser vos préférences ou de faciliter l’analyse d’usage du site. Nous privilégions une approche sobre : seuls les cookies nécessaires sont activés par défaut.</p>
          </section>
        `,
        preferences: `
          <section>
            <h2>Gestion des préférences</h2>
            <p>Vous pouvez ajuster vos choix à tout moment via le bandeau de consentement. Le refus des cookies optionnels n’altère pas l’accès aux contenus principaux.</p>
          </section>
        `
      },
      table: {
        name: "Nom du cookie",
        provider: "Fournisseur",
        type: "Type",
        purpose: "Finalité",
        duration: "Durée",
        rows: `
          <tr>
            <td>site_lang</td>
            <td>danswholesaleplants</td>
            <td>Préférence</td>
            <td>Mémoriser la langue sélectionnée pour les visites ultérieures.</td>
            <td>12 mois</td>
          </tr>
          <tr>
            <td>cookie_consent</td>
            <td>danswholesaleplants</td>
            <td>Nécessaire</td>
            <td>Enregistrer les choix de consentement afin de ne pas réafficher le bandeau.</td>
            <td>12 mois</td>
          </tr>
        `
      },
      banner: {
        title: "Gestion des cookies",
        description: "Nous utilisons des cookies pour sécuriser le site et personnaliser votre navigation. Vous pouvez choisir les catégories que vous acceptez.",
        link: "Lire la politique complète",
        manage: "Ajuster les préférences",
        accept: "Tout accepter",
        decline: "Tout refuser",
        save: "Enregistrer les choix",
        necessary: {
          title: "Nécessaires",
          text: "Assurent le fonctionnement du site et la conservation de vos paramètres essentiels."
        },
        preferences: {
          title: "Préférences",
          text: "Retiennent vos choix de langue et personnalisent certaines vues."
        },
        analytics: {
          title: "Analyses",
          text: "Mesurent l’audience pour améliorer le contenu. Aucun traceur n’est actif sans votre accord."
        },
        marketing: {
          title: "Communication",
          text: "Coordonnent des affichages contextuels. Non actifs par défaut."
        }
      }
    },
    refund: {
      hero: {
        eyebrow: "Révisions",
        title: "Politique de révision",
        subtitle: "Procédures applicables lorsque des ajustements sont demandés sur nos livrables."
      },
      content: `
        <section>
          <h2>1. Champ d’application</h2>
          <p>La présente politique concerne les livrables rédactionnels, cartographiques ou méthodologiques fournis par danswholesaleplants.</p>
        </section>
        <section>
          <h2>2. Signalement</h2>
          <p>Toute demande de révision doit être formulée par écrit dans les dix jours ouvrables suivant la livraison.</p>
        </section>
        <section>
          <h2>3. Analyse de la demande</h2>
          <p>Nous analysons la nature des ajustements et confirmons leur faisabilité dans un délai de trois jours ouvrables.</p>
        </section>
        <section>
          <h2>4. Corrections incluses</h2>
          <p>Les corrections liées à l’exactitude des données, à la cohérence terminologique ou à la structure des livrables sont prises en charge.</p>
        </section>
        <section>
          <h2>5. Ajustements hors périmètre</h2>
          <p>Les demandes introduisant de nouvelles problématiques ou élargissant le champ initial nécessitent une nouvelle planification.</p>
        </section>
        <section>
          <h2>6. Modalités de livraison</h2>
          <p>Les corrections validées sont livrées sous forme électronique avec les versions antérieures pour comparaison.</p>
        </section>
        <section>
          <h2>7. Délais</h2>
          <p>Les délais de révision sont définis en fonction de l’ampleur des ajustements et communiqués au demandeur.</p>
        </section>
        <section>
          <h2>8. Documentation</h2>
          <p>Chaque révision est accompagnée d’une note détaillant les modifications apportées et leurs impacts.</p>
        </section>
        <section>
          <h2>9. Clôture</h2>
          <p>La révision est considérée comme clôturée après validation écrite du demandeur.</p>
        </section>
        <section>
          <h2>10. Contact</h2>
          <p>Pour toute question, écrivez à contact@danswholesaleplants.com en précisant le livrable concerné.</p>
        </section>
      `
    },
    disclaimer: {
      hero: {
        eyebrow: "Limites d’usage",
        title: "Clause de non-responsabilité",
        subtitle: "Les informations publiées sont fournies à titre indicatif et ne constituent pas un engagement contractuel."
      },
      content: `
        <section>
          <h2>Nature des informations</h2>
          <p>Les analyses publiées sont basées sur des observations à un instant donné. Elles ne remplacent pas un audit personnalisé.</p>
        </section>
        <section>
          <h2>Absence de garantie</h2>
          <p>Nous ne garantissons pas que l’ensemble des contenus demeure exact ou complet après leur publication.</p>
        </section>
        <section>
          <h2>Utilisation professionnelle</h2>
          <p>Les informations ne constituent pas une instruction réglementaire. Les organisations doivent vérifier leur pertinence pour leur contexte.</p>
        </section>
        <section>
          <h2>Responsabilité</h2>
          <p>danswholesaleplants n’est pas responsable des décisions prises sur la base exclusive des contenus du site.</p>
        </section>
        <section>
          <h2>Évolutions</h2>
          <p>Nous pouvons modifier les contenus sans préavis. Les utilisateurs sont invités à consulter régulièrement cette page.</p>
        </section>
      `
    },
    thankyou: {
      hero: {
        eyebrow: "Confirmation",
        title: "Merci pour votre message",
        subtitle: "Votre demande a été transmise. Nous revenons vers vous avec des éléments de cadrage.",
        primary: "Retourner à l’accueil",
        secondary: "Explorer les analyses"
      },
      followup: {
        title: "Prochaine étape",
        text1: "Un membre de l’équipe vous contactera pour préciser le contexte et confirmer les informations fournies.",
        text2: "Si vous n’avez pas de nouvelles sous cinq jours ouvrables, n’hésitez pas à nous relancer."
      }
    },
    forms: {
      contact: {
        success: "Votre message a été envoyé. Nous vous répondrons prochainement.",
        errorMissing: "Merci de renseigner les champs requis.",
        errorEmail: "L’adresse électronique semble invalide."
      }
    },
    cookies: {
      banner: {
        title: "Gestion des cookies",
        description: "Nous utilisons des cookies pour sécuriser le site et mémoriser vos préférences. Vous pouvez adapter vos choix.",
        link: "Lire la politique complète",
        manage: "Ajuster les préférences",
        accept: "Tout accepter",
        decline: "Tout refuser",
        save: "Enregistrer les choix",
        necessary: {
          title: "Nécessaires",
          text: "Ces cookies garantissent le fonctionnement de base du site."
        },
        preferences: {
          title: "Préférences",
          text: "Ils retiennent votre langue et certaines configurations."
        },
        analytics: {
          title: "Analyses",
          text: "Ils mesurent l’audience de façon agrégée."
        },
        marketing: {
          title: "Communication",
          text: "Ils adaptent les contenus externes. Inactifs sans consentement."
        }
      }
    }
  },
  en: {
    meta: {
      title: {
        home: "danswholesaleplants — Spatial orientation and digital wayfinding",
        services: "Spatial orientation services | danswholesaleplants",
        about: "About danswholesaleplants",
        blog: "Insights notebook — danswholesaleplants",
        contact: "Contact | danswholesaleplants",
        faq: "Frequently asked questions | danswholesaleplants",
        terms: "Terms of use | danswholesaleplants",
        privacy: "Privacy policy | danswholesaleplants",
        cookies: "Cookie policy | danswholesaleplants",
        refund: "Revision policy | danswholesaleplants",
        disclaimer: "Disclaimer | danswholesaleplants",
        thankyou: "Thank you for reaching out | danswholesaleplants",
        post1: "Cognitive mapping of multimodal hubs",
        post2: "Measuring digital signage legibility",
        post3: "Contextual data for interior navigation",
        post4: "Participatory mapping for inclusive campuses",
        post5: "Wayfinding simulations for heritage sites"
      },
      description: {
        home: "Expert observatory dedicated to spatial orientation systems and digital wayfinding for public buildings and complex urban environments.",
        services: "Overview of danswholesaleplants analytical services covering mapping, visual guidance and spatial user experience.",
        about: "Methodology, values and background of danswholesaleplants, the Belgian specialist in interior navigation.",
        blog: "Technical insights on spatial UX, interactive plans and pedestrian mobility in public infrastructures.",
        contact: "Details and contact form to reach danswholesaleplants in Brussels regarding spatial orientation topics.",
        faq: "Answers to recurring questions about the analytical and digital signage work carried out by danswholesaleplants.",
        terms: "Terms of use describing responsibilities and rules for browsing danswholesaleplants.com.",
        privacy: "Privacy policy explaining how danswholesaleplants manages collected data.",
        cookies: "Complete information about cookies and preference management on danswholesaleplants.",
        refund: "Revision and amendment procedures for deliverables produced by danswholesaleplants.",
        disclaimer: "Disclaimer outlining the usage limits of content published by danswholesaleplants.",
        thankyou: "Confirmation and next steps after sending a message to danswholesaleplants.",
        post1: "In-depth analysis of cognitive mapping within multimodal hubs to optimise interior navigation.",
        post2: "Study of legibility indicators for digital signage and their impact on user comprehension.",
        post3: "Summary on how contextual data supports interior journeys when handled responsibly.",
        post4: "Report on participatory mapping applied to inclusive campuses and soft mobility.",
        post5: "Exploration of wayfinding simulations in heritage sites and conservation requirements."
      }
    },
    header: {
      logo: "danswholesaleplants",
      nav: {
        home: "Home",
        services: "Services",
        about: "About",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      menuToggleLabel: "Toggle main navigation"
    },
    language: {
      fr: "FR",
      en: "EN"
    },
    footer: {
      logo: "danswholesaleplants",
      description: "Studies and prototypes in digital wayfinding, interior navigation and spatial UX for public infrastructures and complex built environments.",
      address: "Rue de la Loi 155, 1040 Brussels, Belgium",
      phone: "+32 2 123 45 67",
      email: "contact@danswholesaleplants.com",
      legal: {
        terms: "Terms of use",
        privacy: "Privacy",
        cookies: "Cookies",
        refund: "Revision policy",
        disclaimer: "Disclaimer"
      },
      footnote: "Independent observatory dedicated to spatial orientation and digital signage.",
      rights: "© {year} danswholesaleplants. All rights reserved."
    },
    home: {
      hero: {
        eyebrow: "Public infrastructure",
        title: "Mapping journeys that structure civic spaces",
        subtitle: "danswholesaleplants studies spatial orientation, digital signage systems and pedestrian mobility to reinforce the legibility of public buildings and complex urban settings.",
        primary: "Discover the services",
        secondary: "Read recent insights",
        imageAlt: "Interactive digital map showing a public hall"
      },
      pillars: {
        title: "Three pillars for intelligible journeys",
        intro: "Our assignments combine spatial mapping, flow scripting and information design to deliver systemic, actionable results.",
        card1: {
          title: "Spatial perception diagnostics",
          text: "Analyse cognitive obstacles, audit landmarks and measure legibility thresholds across built environments.",
          point1: "Mapping of critical decision points",
          point2: "On-site observation of pedestrian trajectories",
          point3: "Visual indicators of informational overload"
        },
        card2: {
          title: "Digital signage and mapping",
          text: "Co-design interactive plans, orchestrate real-time content and prioritise guidance messages.",
          point1: "Multilingual content matrices",
          point2: "Prototyping in 2D and 3D views",
          point3: "Seasonal and event-driven flow management"
        },
        card3: {
          title: "Spatial user experience",
          text: "Model journeys, simulate transfer times and evaluate effort points to sustain fluid movements.",
          point1: "Pedestrian persona segments",
          point2: "Timing of micro-transitions",
          point3: "Inclusive reading of infrastructures"
        }
      },
      metrics: {
        title: "Methodological markers",
        intro: "Indicators combine field observation, digital mapping and qualified feedback to capture usage evolution.",
        item1: { value: "68", label: "User journeys mapped across three regions" },
        item2: { value: "24", label: "Digital signage matrices harmonised" },
        item3: { value: "325", label: "Qualitative interviews with diverse audiences" }
      },
      analysis: {
        title: "Assessing informational density to guide flows",
        paragraph1: "We layer footfall data and physical cues to qualify space perception. The approach spots breaks in visual continuity and high cognitive load areas.",
        paragraph2: "Geo-visualisations help prioritise interventions: adding directional screens, repositioning static plans or reconfiguring light markers.",
        point1: "Mapping light and sound gradients",
        point2: "Visibility matrices based on circulation angles",
        point3: "Prioritisation models led by flow intensity",
        imageAlt: "Graphic analysis of pedestrian flows and signage items"
      },
      recommendations: {
        title: "Recent recommendations",
        intro: "Deliverables rely on field evidence, spatial data and accessible writing for both managers and technical teams.",
        card1: {
          title: "Navigation master plan",
          text: "Single structure for directional messages integrating levels, zones and priority destinations.",
          point1: "Terminology clusters by space families",
          point2: "Harmonised progression of iconographic cues"
        },
        card2: {
          title: "Legibility dashboard",
          text: "Shared metrics to monitor digital and analogue devices throughout the seasons.",
          point1: "Benchmarks cross-checked with journey durations",
          point2: "Alerts triggered by informational overload"
        },
        card3: {
          title: "Dynamic media usage guide",
          text: "Diffusion framework aligned with user profiles, schedules and accessibility constraints.",
          point1: "Sequencing of contextual messages",
          point2: "Multilingual update protocols"
        }
      },
      testimonials: {
        title: "Feedback from public actors",
        intro: "Partners highlight gains in legibility, flow management and stakeholder alignment.",
        quote1: {
          text: "The campus synthesis allowed us to reconcile historical signage with interactive screens without confusing our visitors.",
          author: "Charlotte Meyers",
          role: "Accessibility manager, university network"
        },
        quote2: {
          text: "Simulated journeys in the station uncovered blind spots we had never objectified, reshaping our priorities.",
          author: "Léonard De Keyser",
          role: "Intermodality coordinator, transport authority"
        },
        quote3: {
          text: "The content matrix now acts as a shared reference for every unit of the building, from reception to the museum.",
          author: "Amina Laurent",
          role: "Mediation manager, cultural institution"
        }
      },
      blog: {
        title: "Insight notebook",
        intro: "Deep dives into signage systems, hybrid uses and accessibility requirements.",
        card1: { imageAlt: "Immersive signage inside a multimodal station" },
        card2: { imageAlt: "Interactive plan interface projected on a wall" },
        card3: { imageAlt: "Axonometric view highlighting building routes" }
      }
    },
    services: {
      hero: {
        eyebrow: "Methods",
        title: "Analytical services for clear journeys",
        subtitle: "We operate upstream to document orientation needs and structure digital or physical guidance systems.",
        imageAlt: "Team discussing an interior navigation diagram"
      },
      overview: {
        title: "Comprehensive needs mapping",
        text: "Each service combines field studies, cartographic readings and alignment workshops to build a shared vision."
      },
      items: {
        item1: {
          title: "Spatial needs analysis",
          text: "Capture obstacles, produce photographic surveys and synthesise decision points inside complex buildings.",
          point1: "Inventory of existing devices",
          point2: "Pedestrian heatmaps",
          point3: "Needs matrices per audience"
        },
        item2: {
          title: "Digital signage design",
          text: "Structure content and choreograph digital supports for seamless integration with fixed signage.",
          point1: "Multichannel content charters",
          point2: "Interactive interface prototyping",
          point3: "Iterative user testing"
        },
        item3: {
          title: "User journey modelling",
          text: "Build scenarios aligning flows with service goals while anticipating specific situations.",
          point1: "Pedestrian persona framework",
          point2: "Timelines for key journeys",
          point3: "Mapping of friction points"
        },
        item4: {
          title: "Visual guidance consulting",
          text: "Audit graphic languages, reading distances and contrasts to secure universal comprehension.",
          point1: "Legibility measurements at multiple scales",
          point2: "Typographic recommendations",
          point3: "Panel and screen architecture"
        },
        item5: {
          title: "Accessibility research",
          text: "Dedicated studies on diverse needs, from tactile cues to auditory guidance.",
          point1: "Workshops with specialised associations",
          point2: "Assessment of complementary devices",
          point3: "Integration of accessibility standards"
        }
      },
      process: {
        title: "Collaborative and iterative process",
        paragraph1: "We coordinate quantitative data, qualitative insights and co-creation sessions to deliver operational outputs.",
        paragraph2: "Each stage is documented for informed decision-making and smooth dissemination within teams.",
        step1: "Exploratory phase: data collection and scouting",
        step2: "Modelling phase: flow scripting and prototypes",
        step3: "Convergence phase: recommendations and roadmap",
        imageAlt: "Dynamic workflow board describing several steps"
      },
      outcomes: {
        title: "Structuring deliverables",
        intro: "Outcomes support adoption by internal teams and institutional partners.",
        card1: {
          title: "Spatial atlas",
          text: "Geo-referenced compilation describing trajectories, points of interest and landmark hierarchy."
        },
        card2: {
          title: "Governance guide",
          text: "Responsibilities and maintenance protocols ensuring content consistency."
        },
        card3: {
          title: "Monitoring board",
          text: "Follow-up indicators to assess adjustments and plan future extensions."
        }
      }
    },
    about: {
      hero: {
        eyebrow: "Vision",
        title: "Understanding public spaces to ease movement",
        subtitle: "danswholesaleplants builds analysis frameworks linking data, uses and architecture to strengthen spatial comprehension.",
        imageAlt: "Team meeting around a public building model"
      },
      mission: {
        title: "Mission",
        paragraph1: "We help public organisations transform complex venues into intuitive journeys by revealing hidden spatial logics.",
        paragraph2: "Our method blends user ethnography, cartographic compilation and information design to produce precise recommendations.",
        imageAlt: "On-site observations inside a municipal hall"
      },
      values: {
        title: "Guiding principles",
        intro: "Three values anchor our work from initial study to documentation transfer.",
        card1: {
          title: "Evidence first",
          text: "Every recommendation relies on observable proof, metrics or situated accounts."
        },
        card2: {
          title: "Active accessibility",
          text: "Solutions weave diverse user needs into the process from the outset."
        },
        card3: {
          title: "Documented transparency",
          text: "Data, maps and decisions remain traceable, shareable and ready for updates."
        }
      },
      timeline: {
        title: "Key milestones",
        intro: "A steady progression towards integrated, interoperable tools.",
        stage1: {
          title: "2016 — First audits",
          text: "Qualitative assessments of Belgian stations and creation of legibility references."
        },
        stage2: {
          title: "2019 — Mapping platform",
          text: "Deployment of a geospatial database crosslinking observed flows and user feedback."
        },
        stage3: {
          title: "2022 — Spatial UX lab",
          text: "Launch of a multi-sensory test framework dedicated to hybrid physical-digital environments."
        }
      },
      research: {
        title: "Ongoing research",
        paragraph1: "We produce watch notes, prototypes and comparative evaluations to anticipate usage shifts.",
        paragraph2: "Findings are shared with public authorities to feed accessibility and mobility policies.",
        point1: "Monitoring interactive mapping standards",
        point2: "International comparison of signage codes",
        point3: "Analysis of density effects on landmarks",
        imageAlt: "Research charts and data models"
      }
    },
    blog: {
      hero: {
        eyebrow: "Insights",
        title: "Field studies and models",
        subtitle: "In-depth articles on journeys, digital signage and interior navigation methodologies.",
        imageAlt: "Team reviewing maps and data on a wall"
      },
      listing: {
        readMore: "Read the analysis",
        posts: {
          post1: {
            date: "10 March 2024",
            reading: "Reading time: 7 min",
            title: "Cognitive mapping of multimodal hubs",
            excerpt: "Identifying decision nodes in multimodal hubs requires cross-checking flow data, user accounts and meticulous landmark observations.",
            imageAlt: "Multimodal concourse with luminous maps"
          },
          post2: {
            date: "28 February 2024",
            reading: "Reading time: 8 min",
            title: "Measuring digital signage legibility",
            excerpt: "Digital supports remain legible when content, contrast and synchronisation with static signage are carefully aligned.",
            imageAlt: "Digital signage screen displaying directions and schedules"
          },
          post3: {
            date: "12 February 2024",
            reading: "Reading time: 7 min",
            title: "Contextual data for interior navigation",
            excerpt: "Contextual data enrich interior journeys when they honour purpose, timing and sobriety principles.",
            imageAlt: "Interactive plan displayed in a public building"
          },
          post4: {
            date: "29 January 2024",
            reading: "Reading time: 9 min",
            title: "Participatory mapping for inclusive campuses",
            excerpt: "Engaging campus communities helps recalibrate sensitive routes and highlight missing cues.",
            imageAlt: "Participatory mapping workshop on campus"
          },
          post5: {
            date: "15 January 2024",
            reading: "Reading time: 8 min",
            title: "Simulations for heritage sites",
            excerpt: "Simulations outline conservation constraints while welcoming visitors and smoothing flows.",
            imageAlt: "Simulated itinerary in a heritage site"
          }
        }
      },
      post1: {
        eyebrow: "Study",
        title: "Cognitive mapping of multimodal hubs",
        subtitle: "How can dense rail interchanges remain legible without overwhelming travellers?",
        imageAlt: "Travellers looking at a digital plan inside a station",
        content: `
          <section>
            <p>Multimodal hubs are environments where informational density far exceeds that of classical public buildings. Travellers must filter contradictory messages, anticipate intersecting flows and cope with strict timings. Cognitive mapping merges qualitative accounts and quantitative measures to portray orientation issues with accuracy.</p>
            <h2>Segment journeys rather than destinations</h2>
            <p>The first step splits trips into decision segments. Each segment holds a clear intention—reach a platform, find an exit, access a service—and a sequence of cues. We analyse visual codes, terminology consistency and redundancy. When segments overlap, mapping highlights the cognitive overload that calls for rationalisation.</p>
            <p>The segmentation also reveals how travellers prioritise signals. Overhead signs rank as high-priority sources, while secondary screens act as confirmation devices. Trust in digital signage depends on synchronisation with audio announcements and static panels.</p>
            <h3>Spot critical nodes and blind angles</h3>
            <p>Critical nodes gather multiple flows within a short timeframe. At Brussels-Midi three nodes concentrate 40% of observed hesitations. These zones feature complex geometries, varying ceiling heights and numerous lateral openings. Cognitive mapping retraces alternate paths to see whether smoother itineraries exist.</p>
            <p>Blind angles emerge when signage fails to cover a vital visual field during decision-making. We documented screens oriented towards departing flows instead of incoming ones, or panels hidden by escalators. Recommendations include rotating a screen, shifting a panel or adding a light landmark into sightlines.</p>
            <p>Night-time observations complete the picture by assessing legibility without natural light. Daytime contrasts often fade, prompting reinforcement of specific cues and alignment of screen brightness with ambient lighting.</p>
            <p>Ultimately cognitive mapping brings lived experience to life with sufficient detail so every adjustment becomes measurable. Dynamic maps and user travel diaries form a shared language between operators, architects and mobility specialists.</p>
          </section>
        `
      },
      post2: {
        eyebrow: "Research",
        title: "Measuring digital signage legibility",
        subtitle: "Which indicators should be used to evaluate the clarity of digital supports in public buildings?",
        imageAlt: "Digital screen showing an interactive map inside a hall",
        content: `
          <section>
            <p>Digital signage is now a cornerstone of orientation strategies in complex spaces. Yet legibility remains hard to evaluate without a tailored protocol. We devised an assessment framework combining user tests, optical readings and information consistency indicators.</p>
            <h2>Build a controlled content corpus</h2>
            <p>The structure of published content must be stabilised before measuring. We define templates with limited hierarchy levels, standard colour palettes and validated terminology. This ensures comprehension tests are not biased by graphic variations.</p>
            <p>Field tests assign participants a route and require them to rely on digital supports. We track reading times, hesitations, backtracking and retention of key information. The objective is to determine when content density starts becoming counterproductive.</p>
            <h3>Optical readings with qualitative inputs</h3>
            <p>Studies also rely on luminance and contrast measurements. Legibility is evaluated at common distances: 2 metres for orientation screens, 5 metres for general announcements. Results are confronted with participant feedback to grasp the impact of optical settings.</p>
            <p>Synchronisation between digital supports and static signage is crucial. Divergent terminology erodes trust and slows flows. We recommend aligning content through a shared matrix fed by a common glossary.</p>
            <p>Finally legibility depends on controlled updates. Excessive real-time variation exhausts travellers. Refresh cycles should be tailored to each message while holding onto constant cues across the journey.</p>
          </section>
        `
      },
      post3: {
        eyebrow: "Analysis",
        title: "Contextual data for interior navigation",
        subtitle: "How can sensitive data be integrated without disrupting guidance inside buildings?",
        imageAlt: "Interface showing presence sensors on a map",
        content: `
          <section>
            <p>Contextual data enrich interior navigation when relevant, measured and well synchronised. The challenge lies in translating technical signals into cues everyone understands. We advocate progressive integration, starting with information essential to the journey.</p>
            <h2>Qualify data before displaying it</h2>
            <p>The qualification stage determines whether a data point truly aids orientation. A density sensor may warn about a saturated corridor but becomes intrusive if it changes colour every ten seconds. Publication thresholds avoid stroboscopic effects and keep messages stable.</p>
            <p>Qualification extends to source reliability. Only verified, resilient sources remain. Fallback values are planned to avoid disorientation when a feed is down. A glossary accompanies data layers to align icon interpretation and wording.</p>
            <h3>Stage information sparingly</h3>
            <p>Staging selects the right moment and medium for contextual data. In an administrative building, a message about service crowding works near entrances, not next to the counter itself. Interactive plans can host optional layers activated voluntarily to limit visual overload.</p>
            <p>A clear hierarchy—essential information, contextual advice, exploratory content—supports gradual adoption while respecting cognitive load, especially for occasional visitors.</p>
            <p>Governance weighs heavily. Managers must moderate data, pause a stream or adjust publication frequency. Documentation delivers control procedures to ensure long-term coherence.</p>
          </section>
        `
      },
      post4: {
        eyebrow: "Case study",
        title: "Participatory mapping for inclusive campuses",
        subtitle: "Engaging communities to revisit student journeys and essential services.",
        imageAlt: "Group taking part in a campus mapping workshop",
        content: `
          <section>
            <p>University campuses are mosaics of evolving spaces, often reshaped by works or temporary events. To keep navigation intuitive, we co-built a participatory mapping exercise with students, administrative services and technical teams.</p>
            <h2>Capture lived journeys</h2>
            <p>We first collected journey narratives through workshops and mobility diaries. Participants detailed the cues they rely on, the obstacles they face and their orientation strategies. Stories were geo-referenced to highlight breaks in continuity.</p>
            <p>Maps revealed notable differences between residents and occasional visitors. Residents rely on unsigned shortcuts, while newcomers stick to main axes yet struggle at poorly marked crossroads. Mapping pointed to needs such as extra lighting, tactile signage and temporary guides during works.</p>
            <h3>Co-design the supports</h3>
            <p>With the dataset in hand we co-designed digital and analogue supports. Interactive plans offer filters by profile—reduced mobility, study-focused, access to social services. Physical signage was reorganised to strengthen terminology consistency and integrate cues for neurodivergent users.</p>
            <p>A steering committee of student volunteers and staff oversees updates. Feedback flows through an open platform sustaining community involvement and information relevance.</p>
            <p>Participatory work ultimately increases trust in signage. The campus becomes more legible, journeys diversify and critical services gain visibility.</p>
          </section>
        `
      },
      post5: {
        eyebrow: "Outlook",
        title: "Simulations for heritage sites",
        subtitle: "Balancing preservation and smooth journeys in demanding historical buildings.",
        imageAlt: "Digital simulation of visitors moving within a heritage site",
        content: `
          <section>
            <p>Heritage sites combine constraints: material conservation, aesthetic coherence and variable tourist flows. Journey simulations are invaluable to plan adjustments without compromising integrity.</p>
            <h2>Deal with fragile spaces</h2>
            <p>We first identify sensitive areas—floors, ornaments, fragile structures—to minimise physical interventions. Simulations integrate reversible solutions such as projected cues, temporary lights or freestanding supports.</p>
            <p>Journeys are modelled for multiple profiles: guided groups, solo visitors, people with reduced mobility. Each scenario measures how spaces absorb flows and pinpoints areas where density should be modulated through preventive messages or booking systems.</p>
            <h3>Deliver legible mediation without overload</h3>
            <p>Cultural interpretation must coexist with directional cues without saturating attention. We recommend separating layers: sober supports for direction, audio or digital paths for enriched content.</p>
            <p>Simulations also gauge seasonal pressure and special events. Interactive plans can be updated to reflect temporary changes while preserving a stable backbone trusted by conservation teams.</p>
            <p>By reconciling heritage goals and user experience, historic sites remain clear without sacrificing identity. Simulations create common ground for curators, mediators and flow managers.</p>
          </section>
        `
      }
    },
    contact: {
      hero: {
        eyebrow: "Reach out",
        title: "Working with public space stakeholders",
        subtitle: "Let’s discuss your orientation, digital signage or accessibility initiatives.",
        imageAlt: "Workshop session featuring maps and models"
      },
      details: {
        title: "Get in touch",
        paragraph: "We answer public institutions, transport operators and collectives focused on built environments.",
        block1: {
          title: "Direct contact",
          phone: "+32 2 123 45 67",
          email: "contact@danswholesaleplants.com",
          address: "Rue de la Loi 155, 1040 Brussels"
        },
        block2: {
          title: "Availability",
          text1: "Exploratory meetings can take place remotely or on-site depending on logistics.",
          text2: "A briefing pack is shared before any visit."
        }
      },
      form: {
        title: "Contact form",
        intro: "Describe your context, spaces involved and goals. We reply within five working days.",
        nameLabel: "Full name",
        namePlaceholder: "Your name",
        emailLabel: "Email address",
        emailPlaceholder: "you@example.be",
        orgLabel: "Organisation",
        orgPlaceholder: "Name of your entity",
        messageLabel: "Message",
        messagePlaceholder: "Outline the spatial context or issue",
        submit: "Send"
      },
      map: {
        title: "Brussels location",
        caption: "Our fieldwork primarily covers Brussels and major Belgian cities.",
        iframeTitle: "Map of Brussels showing danswholesaleplants location"
      }
    },
    faq: {
      hero: {
        eyebrow: "Understanding our scope",
        title: "Frequently asked questions",
        subtitle: "Answers about our methods, deliverables and focus areas.",
        imageAlt: "Schematic plan with technical annotations"
      },
      intro: {
        title: "Overview",
        text: "If you cannot find your question here, feel free to contact us for a tailored explanation."
      },
      items: {
        item1: {
          question: "Which environments do you analyse first?",
          answer: "We focus on public buildings, cultural venues, campuses, stations and intermodal networks requiring harmonised signage."
        },
        item2: {
          question: "Do you work on existing projects or new builds?",
          answer: "Both. We audit existing systems and support design teams shaping forthcoming deployments."
        },
        item3: {
          question: "How do you involve people with specific needs?",
          answer: "Dedicated workshops and tests with partner associations ensure universal accessibility criteria are embedded."
        },
        item4: {
          question: "Do you deliver execution drawings?",
          answer: "We provide detailed recommendations, templates and references so specialised suppliers can produce execution documents."
        },
        item5: {
          question: "What is the average mission duration?",
          answer: "Depending on site scale, a mission lasts six to twelve weeks including fieldwork, modelling and delivery."
        },
        item6: {
          question: "Do you offer follow-up after delivery?",
          answer: "Yes, we arrange follow-up sessions to review implementation and adjust priorities when needed."
        }
      }
    },
    terms: {
      hero: {
        eyebrow: "Usage framework",
        title: "Terms of use",
        subtitle: "Rules applying to the consultation of danswholesaleplants.com."
      },
      content: `
        <section>
          <h2>1. Purpose of this document</h2>
          <p>These terms govern access to danswholesaleplants.com and define responsibilities for both publisher and visitors.</p>
        </section>
        <section>
          <h2>2. Acceptance</h2>
          <p>Browsing the site implies full acceptance of these terms. Any use conflicting with them is prohibited.</p>
        </section>
        <section>
          <h2>3. Intended audience</h2>
          <p>The site targets public institutions, mobility operators, architecture professionals and citizens interested in spatial orientation.</p>
        </section>
        <section>
          <h2>4. Published content</h2>
          <p>Editorial materials, analyses and visuals are informative. They reflect the state of research at publication date.</p>
        </section>
        <section>
          <h2>5. Information accuracy</h2>
          <p>We strive for reliability yet updates may occur without notice. No guarantee of completeness is provided.</p>
        </section>
        <section>
          <h2>6. Intellectual property</h2>
          <p>Texts, graphics, logos and databases are protected. Reproduction requires written permission.</p>
        </section>
        <section>
          <h2>7. Hyperlinks</h2>
          <p>Links to external resources may appear. We are not liable for their content or availability.</p>
        </section>
        <section>
          <h2>8. Proper use</h2>
          <p>Visitors shall not disrupt the site or introduce malicious content.</p>
        </section>
        <section>
          <h2>9. User accounts</h2>
          <p>No account is needed to browse. Should a restricted access exist, provided credentials remain confidential.</p>
        </section>
        <section>
          <h2>10. Data handling</h2>
          <p>Data processing is described in the privacy policy and follows Belgian regulations.</p>
        </section>
        <section>
          <h2>11. Liability</h2>
          <p>The publisher cannot be held responsible for misinterpretation of content or temporary unavailability.</p>
        </section>
        <section>
          <h2>12. Maintenance</h2>
          <p>Technical operations may interrupt service, which we aim to keep minimal.</p>
        </section>
        <section>
          <h2>13. Updates</h2>
          <p>Terms may change at any time. The online version prevails.</p>
        </section>
        <section>
          <h2>14. Governing law</h2>
          <p>These terms are governed by Belgian law. Any dispute falls under the jurisdiction of Brussels courts.</p>
        </section>
      `
    },
    privacy: {
      hero: {
        eyebrow: "Data protection",
        title: "Privacy policy",
        subtitle: "Information about the collection, usage and safeguarding of personal data."
      },
      content: `
        <section>
          <h2>1. Data controller</h2>
          <p>danswholesaleplants, Rue de la Loi 155, 1040 Brussels, operates danswholesaleplants.com. Contact contact@danswholesaleplants.com for data matters.</p>
        </section>
        <section>
          <h2>2. Data collected</h2>
          <p>We collect details voluntarily provided through the contact form: name, email address, organisation, project description.</p>
        </section>
        <section>
          <h2>3. Purpose</h2>
          <p>Data is used to answer requests, prepare exchanges and share documents related to missions.</p>
        </section>
        <section>
          <h2>4. Legal basis</h2>
          <p>Processing relies on our legitimate interest to respond to professional enquiries and on explicit consent.</p>
        </section>
        <section>
          <h2>5. Retention period</h2>
          <p>Information is kept until the request is fulfilled and for no longer than twelve months without follow-up.</p>
        </section>
        <section>
          <h2>6. Recipients</h2>
          <p>Data is not shared with third parties unless legally required or explicitly authorised by the individual.</p>
        </section>
        <section>
          <h2>7. Security</h2>
          <p>Organisational and technical measures protect data against unauthorised access or disclosure.</p>
        </section>
        <section>
          <h2>8. Individual rights</h2>
          <p>You may access, rectify, limit or erase your data by writing to contact@danswholesaleplants.com.</p>
        </section>
        <section>
          <h2>9. Cookies</h2>
          <p>Cookie usage is detailed in the dedicated policy. Preferences can be updated at any time.</p>
        </section>
        <section>
          <h2>10. Updates</h2>
          <p>This policy may evolve. The update date is displayed at the bottom of the page.</p>
        </section>
      `
    },
    cookies: {
      hero: {
        eyebrow: "Settings",
        title: "Cookie policy",
        subtitle: "Understand the cookies in use and manage your preferences."
      },
      content: {
        intro: `
          <section>
            <h2>Cookie usage</h2>
            <p>Cookies are small files stored on your device to remember preferences or facilitate usage analysis. Our approach is minimal: only necessary cookies are active by default.</p>
          </section>
        `,
        preferences: `
          <section>
            <h2>Preference management</h2>
            <p>You can adjust choices at any time using the consent banner. Refusing optional cookies does not restrict access to main content.</p>
          </section>
        `
      },
      table: {
        name: "Cookie name",
        provider: "Provider",
        type: "Type",
        purpose: "Purpose",
        duration: "Duration",
        rows: `
          <tr>
            <td>site_lang</td>
            <td>danswholesaleplants</td>
            <td>Preference</td>
            <td>Remember the language selected for future visits.</td>
            <td>12 months</td>
          </tr>
          <tr>
            <td>cookie_consent</td>
            <td>danswholesaleplants</td>
            <td>Necessary</td>
            <td>Store consent decisions to avoid displaying the banner repeatedly.</td>
            <td>12 months</td>
          </tr>
        `
      },
      banner: {
        title: "Cookie management",
        description: "We use cookies to secure the site and remember your preferences. Adjust the categories at any time.",
        link: "Read the full policy",
        manage: "Adjust preferences",
        accept: "Accept all",
        decline: "Decline all",
        save: "Save choices",
        necessary: {
          title: "Necessary",
          text: "Ensure the site operates correctly and keeps your essential settings."
        },
        preferences: {
          title: "Preferences",
          text: "Store your language selection and certain configurations."
        },
        analytics: {
          title: "Analytics",
          text: "Measure aggregated audience metrics to improve content."
        },
        marketing: {
          title: "Communication",
          text: "Coordinate contextual displays. Disabled by default."
        }
      }
    },
    refund: {
      hero: {
        eyebrow: "Revisions",
        title: "Revision policy",
        subtitle: "Procedures applied when adjustments are requested on our deliverables."
      },
      content: `
        <section>
          <h2>1. Scope</h2>
          <p>This policy covers editorial, cartographic or methodological deliverables provided by danswholesaleplants.</p>
        </section>
        <section>
          <h2>2. Notification</h2>
          <p>Revision requests must be sent in writing within ten working days after delivery.</p>
        </section>
        <section>
          <h2>3. Request review</h2>
          <p>We examine the adjustments needed and confirm feasibility within three working days.</p>
        </section>
        <section>
          <h2>4. Included corrections</h2>
          <p>Corrections covering data accuracy, terminology consistency or structure are included.</p>
        </section>
        <section>
          <h2>5. Out-of-scope adjustments</h2>
          <p>Requests introducing new topics or broadening the initial scope require a new planning round.</p>
        </section>
        <section>
          <h2>6. Delivery mode</h2>
          <p>Validated corrections are delivered digitally with previous versions for comparison.</p>
        </section>
        <section>
          <h2>7. Timelines</h2>
          <p>Revision deadlines depend on workload and are communicated to the requester.</p>
        </section>
        <section>
          <h2>8. Documentation</h2>
          <p>Each revision includes a note detailing changes and their impact.</p>
        </section>
        <section>
          <h2>9. Closure</h2>
          <p>A revision closes after written validation from the requester.</p>
        </section>
        <section>
          <h2>10. Contact</h2>
          <p>For questions, email contact@danswholesaleplants.com mentioning the relevant deliverable.</p>
        </section>
      `
    },
    disclaimer: {
      hero: {
        eyebrow: "Use limits",
        title: "Disclaimer",
        subtitle: "Information is provided for guidance only and does not constitute a contractual commitment."
      },
      content: `
        <section>
          <h2>Nature of information</h2>
          <p>Published analyses capture observations at a given time. They do not replace a tailored audit.</p>
        </section>
        <section>
          <h2>No guarantee</h2>
          <p>We cannot guarantee content remains accurate or complete after publication.</p>
        </section>
        <section>
          <h2>Professional usage</h2>
          <p>Information does not qualify as regulatory advice. Organisations must assess relevance to their context.</p>
        </section>
        <section>
          <h2>Responsibility</h2>
          <p>danswholesaleplants is not liable for decisions based solely on the site’s content.</p>
        </section>
        <section>
          <h2>Changes</h2>
          <p>Content may change without notice. Users should consult this page regularly.</p>
        </section>
      `
    },
    thankyou: {
      hero: {
        eyebrow: "Confirmation",
        title: "Thank you for your message",
        subtitle: "Your request has been received. We will get back to you with a framing proposal.",
        primary: "Back to home",
        secondary: "Explore insights"
      },
      followup: {
        title: "Next steps",
        text1: "Someone from the team will reach out to clarify context and confirm the information provided.",
        text2: "If you have no news within five working days, please follow up with us."
      }
    },
    forms: {
      contact: {
        success: "Your message has been sent. We will reply shortly.",
        errorMissing: "Please complete the required fields.",
        errorEmail: "The email address appears invalid."
      }
    },
    cookies: {
      banner: {
        title: "Cookie management",
        description: "We use cookies to secure the site and remember your preferences. Adjust the categories as you wish.",
        link: "Read the cookie policy",
        manage: "Adjust preferences",
        accept: "Accept all",
        decline: "Decline all",
        save: "Save choices",
        necessary: {
          title: "Necessary",
          text: "These cookies keep the site running properly."
        },
        preferences: {
          title: "Preferences",
          text: "They store your language choice and certain settings."
        },
        analytics: {
          title: "Analytics",
          text: "They measure aggregated visits to improve content."
        },
        marketing: {
          title: "Communication",
          text: "They coordinate contextual displays. Disabled until you consent."
        }
      }
    }
  }
};

const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const CONSENT_STORAGE_KEY = "cookie_consent";

document.addEventListener("DOMContentLoaded", () => {
  const siteNav = document.getElementById("siteNav");
  const navToggle = document.getElementById("navToggle");
  const toastContainer = document.getElementById("toastContainer");
  const cookieBanner = document.getElementById("cookieBanner");
  const cookiePreferences = document.getElementById("cookiePreferences");
  const manageCookiesBtn = document.getElementById("manageCookies");
  const acceptCookiesBtn = document.getElementById("acceptCookies");
  const declineCookiesBtn = document.getElementById("declineCookies");
  const saveCookiesBtn = document.getElementById("saveCookies");

  let currentLang = localStorage.getItem(LANG_STORAGE_KEY) || DEFAULT_LANG;

  function getLangData() {
    return I18N[currentLang] || I18N[DEFAULT_LANG];
  }

  function resolveKey(path, data) {
    return path.split(".").reduce((acc, part) => (acc && acc[part] !== undefined ? acc[part] : undefined), data);
  }

  function formatString(str) {
    if (!str) return "";
    return str.replace("{year}", new Date().getFullYear());
  }

  function applyTranslations() {
    const data = getLangData();
    document.documentElement.lang = currentLang;

    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.dataset.i18n;
      const value = resolveKey(key, data);
      if (value !== undefined) {
        el.innerHTML = formatString(value);
      }
    });

    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      const key = el.dataset.i18nPlaceholder;
      const value = resolveKey(key, data);
      if (value !== undefined) {
        el.setAttribute("placeholder", value);
      }
    });

    document.querySelectorAll("[data-i18n-title]").forEach((el) => {
      const key = el.dataset.i18nTitle;
      const value = resolveKey(key, data);
      if (value !== undefined) {
        el.setAttribute("title", value);
      }
    });

    document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
      const key = el.dataset.i18nAlt;
      const value = resolveKey(key, data);
      if (value !== undefined) {
        el.setAttribute("alt", value);
      }
    });

    document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
      const key = el.dataset.i18nAria;
      const value = resolveKey(key, data);
      if (value !== undefined) {
        el.setAttribute("aria-label", value);
      }
    });

    document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
      const key = el.dataset.i18nMeta;
      const value = resolveKey(key, data);
      if (value !== undefined) {
        el.setAttribute("content", value);
      }
    });

    const titleEl = document.querySelector("title[data-i18n]");
    if (titleEl) {
      const key = titleEl.dataset.i18n;
      const value = resolveKey(key, data);
      if (value !== undefined) {
        titleEl.textContent = value;
      }
    }

    updateLanguageButtons();
  }

  function setLanguage(lang) {
    currentLang = I18N[lang] ? lang : DEFAULT_LANG;
    localStorage.setItem(LANG_STORAGE_KEY, currentLang);
    applyTranslations();
  }

  function updateLanguageButtons() {
    document.querySelectorAll(".lang-btn").forEach((btn) => {
      const lang = btn.dataset.setLang;
      if (lang === currentLang) {
        btn.classList.add("active");
        btn.setAttribute("aria-pressed", "true");
      } else {
        btn.classList.remove("active");
        btn.setAttribute("aria-pressed", "false");
      }
    });
  }

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.setLang;
      setLanguage(lang);
      showToast(resolveKey("forms.contact.success", getLangData()), false);
    });
  });

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", expanded ? "false" : "true");
      siteNav.classList.toggle("open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        siteNav.classList.remove("open");
      });
    });
  }

  function highlightActiveNav() {
    const page = document.body.dataset.page;
    document.querySelectorAll(".nav-link").forEach((link) => {
      if (link.dataset.nav === page) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });
  }

  function showToast(message, isError = false) {
    if (!toastContainer || !message) return;
    const toast = document.createElement("div");
    toast.className = "toast";
    if (isError) toast.classList.add("error");
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(10px)";
      setTimeout(() => {
        toast.remove();
      }, 180);
    }, 3200);
  }

  function initForm() {
    const form = document.querySelector("form[data-contact-form]");
    if (!form) return;
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = getLangData();
      const name = form.querySelector('input[name="name"]');
      const email = form.querySelector('input[name="email"]');
      const message = form.querySelector('textarea[name="message"]');
      if (!name.value.trim() || !email.value.trim() || !message.value.trim()) {
        showToast(resolveKey("forms.contact.errorMissing", data), true);
        return;
      }
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email.value.trim())) {
        showToast(resolveKey("forms.contact.errorEmail", data), true);
        return;
      }
      showToast(resolveKey("forms.contact.success", data));
      setTimeout(() => {
        form.submit();
      }, 600);
    });
  }

  function initFadeIn() {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    document.querySelectorAll(".fade-in").forEach((el) => observer.observe(el));
  }

  function getStoredConsent() {
    const stored = localStorage.getItem(CONSENT_STORAGE_KEY);
    if (!stored) return null;
    try {
      return JSON.parse(stored);
    } catch {
      return null;
    }
  }

  function setStoredConsent(consent) {
    localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(consent));
  }

  function updateConsentUI(consent) {
    if (!cookiePreferences || !consent) return;
    cookiePreferences.querySelectorAll("[data-cookie-toggle]").forEach((toggle) => {
      const key = toggle.dataset.cookieToggle;
      toggle.checked = !!consent[key];
    });
  }

  function toggleCookieBanner(show) {
    if (!cookieBanner) return;
    if (show) {
      cookieBanner.classList.add("visible");
    } else {
      cookieBanner.classList.remove("visible");
    }
  }

  function ensureCookieBanner() {
    const consent = getStoredConsent();
    if (!consent) {
      toggleCookieBanner(true);
    } else {
      updateConsentUI(consent);
    }
  }

  function acceptAllCookies() {
    const consent = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      decidedAt: new Date().toISOString()
    };
    setStoredConsent(consent);
    updateConsentUI(consent);
    toggleCookieBanner(false);
  }

  function declineAllCookies() {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      decidedAt: new Date().toISOString()
    };
    setStoredConsent(consent);
    updateConsentUI(consent);
    toggleCookieBanner(false);
  }

  function saveCookiePreferences() {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      decidedAt: new Date().toISOString()
    };
    cookiePreferences.querySelectorAll("[data-cookie-toggle]").forEach((toggle) => {
      consent[toggle.dataset.cookieToggle] = toggle.checked;
    });
    setStoredConsent(consent);
    toggleCookieBanner(false);
  }

  function initCookieBanner() {
    if (!cookieBanner) return;
    ensureCookieBanner();
    const stored = getStoredConsent();
    if (stored) updateConsentUI(stored);

    if (manageCookiesBtn) {
      manageCookiesBtn.addEventListener("click", () => {
        cookiePreferences.classList.toggle("visible");
      });
    }
    if (acceptCookiesBtn) {
      acceptCookiesBtn.addEventListener("click", acceptAllCookies);
    }
    if (declineCookiesBtn) {
      declineCookiesBtn.addEventListener("click", declineAllCookies);
    }
    if (saveCookiesBtn) {
      saveCookiesBtn.addEventListener("click", saveCookiePreferences);
    }
  }

  function initLanguageFromStorage() {
    setLanguage(currentLang);
  }

  function setActiveYear() {
    const data = getLangData();
    const rightsEl = document.querySelector("[data-i18n='footer.rights']");
    if (rightsEl) rightsEl.innerHTML = formatString(resolveKey("footer.rights", data));
  }

  highlightActiveNav();
  initLanguageFromStorage();
  initForm();
  initFadeIn();
  initCookieBanner();
  setActiveYear();
});