document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const status = localStorage.getItem('cookie-consent-status');
  if (!status) {
    requestAnimationFrame(() => {
      banner.classList.add('visible');
    });
  }

  const acceptBtn = banner.querySelector('[data-action="accept"]');
  const declineBtn = banner.querySelector('[data-action="decline"]');

  const setConsent = (value) => {
    localStorage.setItem('cookie-consent-status', value);
    banner.classList.remove('visible');
  };

  acceptBtn?.addEventListener('click', () => setConsent('accepted'));
  declineBtn?.addEventListener('click', () => setConsent('declined'));
});