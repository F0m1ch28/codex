document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            siteNav.classList.toggle('open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                siteNav.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const consent = localStorage.getItem('ybqt-cookie-consent');
        if (!consent) {
            cookieBanner.classList.add('active');
        }

        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(button => {
            button.addEventListener('click', (event) => {
                const action = event.currentTarget.getAttribute('data-cookie-action');
                if (action === 'accept') {
                    localStorage.setItem('ybqt-cookie-consent', 'accepted');
                    cookieBanner.classList.remove('active');
                } else if (action === 'decline') {
                    localStorage.setItem('ybqt-cookie-consent', 'declined');
                    cookieBanner.classList.remove('active');
                } else if (action === 'customize') {
                    window.location.href = 'cookies.html';
                }
            });
        });
    }
});