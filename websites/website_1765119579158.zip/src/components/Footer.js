import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`container ${styles.footerContainer}`}>
        <div className={styles.brand}>
          <h3>Професійна дресирування німецьких вівчарок</h3>
          <p>
            Професійна команда кінологів у Варшаві та Кракові. Працюємо з німецькими вівчарками, створюємо
            індивідуальні програми навчання, щоб кожна родина жила в гармонії зі своїм улюбленцем.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h4>Навігація</h4>
            <nav className={styles.footerNav}>
              <Link to="/">Головна</Link>
              <Link to="/posluhy">Послуги</Link>
              <Link to="/pro-nas">Про нас</Link>
              <Link to="/nashi-uspikhy">Наші успіхи</Link>
              <Link to="/kontakty">Контакти</Link>
            </nav>
          </div>
          <div>
            <h4>Правова інформація</h4>
            <nav className={styles.footerNav}>
              <Link to="/umovy-vykorystannya">Умови використання</Link>
              <Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link>
              <Link to="/polityka-cookies">Політика cookies</Link>
            </nav>
          </div>
          <div>
            <h4>Контакти</h4>
            <address className={styles.address}>
              <span>Варшава, вул. Собача, 15</span>
              <span>Краков, вул. Песя, 8</span>
              <a href="tel:+48123456789">+48 123 456 789</a>
              <a href="mailto:info@dresyruvannya-psiv.pl">info@dresyruvannya-psiv.pl</a>
            </address>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {new Date().getFullYear()} Професійна дресирування німецьких вівчарок. Усі права захищено.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;