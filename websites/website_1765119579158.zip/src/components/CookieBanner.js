import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('cookie-consent');
    if (!consent) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('cookie-consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem('cookie-consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Сповіщення щодо cookies">
      <div className={styles.content}>
        <h4>Ми дбаємо про вашу приватність</h4>
        <p>
          Ми використовуємо файли cookies, щоб зробити взаємодію із сайтом максимально зручною та безпечною. Продовжуючи
          користування, ви погоджуєтеся з нашою{' '}
          <a href="/polityka-cookies">політикою використання cookies</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button className="secondaryButton" onClick={handleDecline}>
          Лише необхідні
        </button>
        <button className="primaryButton" onClick={handleAccept}>
          Погоджуюсь
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;