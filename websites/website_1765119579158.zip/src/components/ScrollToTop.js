import React, { useEffect, useState } from 'react';
import styles from './ScrollToTopButton.module.css';

function ScrollToTopButton() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setVisible(window.scrollY > 360);
    };
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  if (!visible) return null;

  return (
    <button
      className={styles.scrollButton}
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      aria-label="Повернутися вгору"
    >
      ↑
    </button>
  );
}

export default ScrollToTopButton;