import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Successes from './pages/Successes';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  return (
    <div className="appWrapper">
      <Header />
      <main className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/posluhy" element={<Services />} />
          <Route path="/pro-nas" element={<About />} />
          <Route path="/nashi-uspikhy" element={<Successes />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/umovy-vykorystannya" element={<Terms />} />
          <Route path="/polityka-konfidentsiinosti" element={<Privacy />} />
          <Route path="/polityka-cookies" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;