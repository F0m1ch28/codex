import React from 'react';
import Seo from '../components/Seo';
import styles from './Successes.module.css';

const successStories = [
  {
    title: 'Кейс Робочої собаки «Грета»',
    location: 'Варшава',
    challenge:
      'Молода собака проявляла надмірне збудження під час служби та важко переключалася між завданнями.',
    solution:
      'Впровадили програму самоконтролю, вправи на фокус і систематичні перерви. Працювали разом із кінологом-партнером із поліції.',
    result:
      'Через 10 тижнів Грета стабільно виконує вказівки, зберігаючи витримку навіть у напружених ситуаціях. Команда відзначає її як приклад службової собаки з високою мотивацією.',
    image: 'https://picsum.photos/800/600?random=31',
  },
  {
    title: 'Сімейна програма для «Ліри»',
    location: 'Краков',
    challenge:
      'Пес реагував гавкотом на гостей і тягнув повідок, що ускладнювало прогулянки з дітьми.',
    solution:
      'Розділили тренування на роботу у дворі й у місті, додали вправи на спокій у домі, врахували особливості взаємодії з дітьми.',
    result:
      'Через 6 тижнів Ліра зустрічає гостей спокійно, а прогулянки стали комфортними. Родина продовжує додаткові заняття з nosework.',
    image: 'https://picsum.photos/800/600?random=32',
  },
  {
    title: 'Програма реабілітації «Ріка»',
    location: 'Варшава',
    challenge:
      'Собака з притулку боялася незнайомих людей та відмовлялася від роботи на вулиці.',
    solution:
      'Почали з коротких вправ у тихому місці, додали позитивні асоціації, поступово збільшували навантаження. Працювали з родиною над читанням сигналів собаки.',
    result:
      'За 4 місяці Ріка впевнено гуляє в парках і приймає ласощі від нових людей. Родина планує подальші заняття зі слухняності.',
    image: 'https://picsum.photos/800/600?random=33',
  },
];

function Successes() {
  return (
    <>
      <Seo
        title="Наші успіхи | Професійна дресирування німецьких вівчарок"
        description="Ознайомтесь із прикладами успішних програм дресирування німецьких вівчарок у Варшаві та Кракові."
        keywords="успішне дресирування, результати тренувань, німецька вівчарка"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Реальні історії прогресу наших підопічних</h1>
          <p>
            Кожен кейс — це співпраця кінологів і родини. Ми ділимося прикладами, які демонструють, як систематичне
            навчання змінює спільне життя з німецькою вівчаркою.
          </p>
        </div>
      </section>

      <section className={styles.stories}>
        <div className="container">
          {successStories.map((story) => (
            <article key={story.title} className={`${styles.storyCard} card`}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.storyContent}>
                <span className={styles.location}>{story.location}</span>
                <h2>{story.title}</h2>
                <div className={styles.textBlock}>
                  <h3>Виклик</h3>
                  <p>{story.challenge}</p>
                </div>
                <div className={styles.textBlock}>
                  <h3>Рішення</h3>
                  <p>{story.solution}</p>
                </div>
                <div className={styles.textBlock}>
                  <h3>Результат</h3>
                  <p>{story.result}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default Successes;