import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

function CookiePolicy() {
  return (
    <>
      <Seo
        title="Політика cookies | Професійна дресирування німецьких вівчарок"
        description="Правила використання файлів cookies на сайті Професійна дресирування німецьких вівчарок."
        keywords="політика cookies, файли cookie"
      />
      <section className={styles.legal}>
        <div className="container">
          <h1>Політика використання cookies</h1>
          <p>Останнє оновлення: 1 квітня 2024 року</p>
          <h2>1. Що таке cookies</h2>
          <p>
            Cookies — це невеликі текстові файли, які зберігаються у вашому браузері для покращення роботи сайту. Ми
            використовуємо лише необхідні та аналітичні cookies.
          </p>
          <h2>2. Типи cookies</h2>
          <p>
            Необхідні cookies забезпечують роботу основних функцій сайту. Аналітичні cookies допомагають нам розуміти
            поведінку користувачів, щоб покращувати сервіс.
          </p>
          <h2>3. Керування cookies</h2>
          <p>
            Ви можете змінити налаштування cookies у банері згоди або у налаштуваннях браузера. Відключення деяких
            cookies може обмежити функціональність сайту.
          </p>
          <h2>4. Контакт</h2>
          <p>
            З питаннями щодо cookies звертайтеся на <a href="mailto:info@dresyruvannya-psiv.pl">info@dresyruvannya-psiv.pl</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;