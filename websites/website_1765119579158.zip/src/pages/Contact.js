import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

function Contact() {
  const [status, setStatus] = useState({ sending: false, sent: false });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (status.sending) return;
    setStatus({ sending: true, sent: false });
    setTimeout(() => {
      setStatus({ sending: false, sent: true });
      e.target.reset();
    }, 1400);
  };

  return (
    <>
      <Seo
        title="Контакти | Професійна дресирування німецьких вівчарок"
        description="Зв’яжіться з нами у Варшаві чи Кракові, щоб розпочати програму дресирування німецької вівчарки."
        keywords="контакти кінолога, дресирування Варшава, дресирування Краков"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Зв’яжіться з нашими кінологами</h1>
          <p>
            Ми раді познайомитися з вами та вашим улюбленцем. Заплануйте дзвінок або зустріч, щоб обговорити цілі
            тренувань і створити індивідуальний план.
          </p>
        </div>
      </section>

      <section className={styles.contactDetails}>
        <div className="container grid gridTwo">
          <div className={styles.infoCard}>
            <h2>Контактна інформація</h2>
            <ul>
              <li>
                <strong>Телефон:</strong> <a href="tel:+48123456789">+48 123 456 789</a>
              </li>
              <li>
                <strong>Email:</strong>{' '}
                <a href="mailto:info@dresyruvannya-psiv.pl">info@dresyruvannya-psiv.pl</a>
              </li>
              <li>
                <strong>Варшава:</strong> вул. Собача, 15
              </li>
              <li>
                <strong>Краков:</strong> вул. Песя, 8
              </li>
            </ul>
            <p>
              Працюємо щодня з 9:00 до 20:00. Попередній запис обов’язковий, щоб ми могли виділити час для вашого
              запиту.
            </p>
          </div>
          <form className={styles.form} onSubmit={handleSubmit}>
            <label>
              Ім’я та прізвище*
              <input type="text" name="name" placeholder="Ірина Коваль" required />
            </label>
            <label>
              Email*
              <input type="email" name="email" placeholder="name@email.com" required />
            </label>
            <label>
              Телефон
              <input type="tel" name="phone" placeholder="+48..." />
            </label>
            <label>
              Місце тренувань*
              <select name="location" required defaultValue="">
                <option value="" disabled>
                  Оберіть локацію
                </option>
                <option value="Варшава">Варшава, вул. Собача, 15</option>
                <option value="Краков">Краков, вул. Песя, 8</option>
                <option value="Виїзд">Виїзне заняття</option>
              </select>
            </label>
            <label>
              Опишіть ваш запит
              <textarea name="message" rows="5" placeholder="Розкажіть про собаку та бажані результати" />
            </label>
            <button type="submit" className="primaryButton" disabled={status.sending}>
              {status.sending ? 'Надсилаємо...' : 'Надіслати повідомлення'}
            </button>
            {status.sent && <p className={styles.success}>Дякуємо! Ми відповімо вам найближчим часом.</p>}
          </form>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className="container">
          <h2>Наші майданчики</h2>
          <div className={styles.mapPlaceholder}>
            <p>
              Варшава: вул. Собача, 15 · Краков: вул. Песя, 8. Після запису ви отримаєте детальні інструкції щодо
              розташування майданчика та умов паркування.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;