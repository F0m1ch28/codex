import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const testimonials = [
  {
    name: 'Анна, Варшава',
    role: 'господарка вівчарки Рокі',
    quote:
      'Команда зробила неможливе: наш енергійний Рокі став керованим, і ми знову із задоволенням гуляємо містом. Чудові, гуманні підходи!',
  },
  {
    name: 'Марек, Краков',
    role: 'власник Бруно',
    quote:
      'Кінологи вміють слухати і працюють з мотивацією собаки. Результати видно вже після перших занять, дякую за підтримку!',
  },
  {
    name: 'Олена, Варшава',
    role: 'родина з двома дітьми',
    quote:
      'Пояснили, як взаємодіяти з нашою Елою, щоб вона відчувала себе спокійно поруч з дітьми. Професіонали з великої літери.',
  },
];

const faqItems = [
  {
    question: 'З якого віку варто починати дресирування німецької вівчарки?',
    answer:
      'Ми працюємо зі щенятами вже з 10-12 тижнів, поступово привчаючи до базових команд і навичок соціалізації. Також беремо дорослих собак і адаптуємо програму під їхній досвід.',
  },
  {
    question: 'Чи можна відвідувати заняття всією родиною?',
    answer:
      'Так, ми заохочуємо участь усіх членів родини. Це допомагає сформувати єдині правила взаємодії з собакою у повсякденному житті.',
  },
  {
    question: 'Які методи ви використовуєте?',
    answer:
      'Ми практикуємо виключно позитивні методи підкріплення, що базуються на мотивації, іграх та поступовому закріпленні навичок без примусу.',
  },
  {
    question: 'Скільки триває курс?',
    answer:
      'Стандартна програма складається з 12-16 занять. Тривалість залежить від цілей, характеру собаки та очікувань родини.',
  },
];

function Home() {
  const [counterValues, setCounterValues] = useState({
    dogs: 0,
    years: 0,
    trainers: 0,
  });
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [openFaq, setOpenFaq] = useState(0);
  const [formStatus, setFormStatus] = useState({ sending: false, sent: false });

  useEffect(() => {
    const targetValues = { dogs: 280, years: 12, trainers: 6 };
    const animationDuration = 1600;
    const startTime = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - startTime) / animationDuration, 1);
      setCounterValues({
        dogs: Math.floor(progress * targetValues.dogs),
        years: Math.floor(progress * targetValues.years),
        trainers: Math.floor(progress * targetValues.trainers),
      });
      if (progress < 1) requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handleFaqToggle = (index) => {
    setOpenFaq((prev) => (prev === index ? -1 : index));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formStatus.sending) return;
    setFormStatus({ sending: true, sent: false });
    setTimeout(() => {
      setFormStatus({ sending: false, sent: true });
      e.target.reset();
    }, 1500);
  };

  return (
    <>
      <Seo
        title="Професійна дресирування німецьких вівчарок | Варшава та Краков"
        description="Індивідуальні програми дресирування німецьких вівчарок у Варшаві та Кракові. Професійні кінологи, гуманні методи, підтримка родин."
        keywords="дресирування собак Варшава, дресирування німецьких вівчарок, кінолог Краков, навчання собак"
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className="badge fadeInUp">Кінологічний центр у Польщі</div>
            <h1 className="fadeInUp">
              Дресирування німецьких вівчарок з повагою, експертизою та любов&apos;ю
            </h1>
            <p className="fadeInUp">
              Ми створюємо індивідуальні програми навчання, що розкривають потенціал улюбленця, формують слухняну
              поведінку та укріплюють зв’язок із сім’єю. Працюємо у Варшаві та Кракові.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className="primaryButton">
                Записатися на консультацію
              </Link>
              <Link to="/posluhy" className="secondaryButton">
                Переглянути послуги
              </Link>
            </div>
            <div className={styles.heroStats}>
              <div>
                <span>{counterValues.dogs}+</span>
                <p>навчених вівчарок</p>
              </div>
              <div>
                <span>{counterValues.years}</span>
                <p>років досвіду</p>
              </div>
              <div>
                <span>{counterValues.trainers}</span>
                <p>сертифікованих кінологів</p>
              </div>
            </div>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://picsum.photos/1600/900?random=11"
              alt="Кінолог тренує німецьку вівчарку на майданчику"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className="container grid gridTwo">
          <div>
            <h2 className="sectionTitle">Про команду</h2>
            <p className="sectionSubtitle">
              Наші кінологи поєднують практику в робочих і сімейних лініях породи. Ми працюємо з мотивацією собаки і
              навчаємо власників залишатися послідовними та терплячими.
            </p>
            <ul className={styles.list}>
              <li>Індивідуальні програми для цуценят, дорослих та службових вівчарок</li>
              <li>Гуманні методи без примусу та агресії</li>
              <li>Постійна комунікація та домашні завдання між сесіями</li>
            </ul>
            <Link to="/pro-nas" className={styles.linkArrow}>
              Детальніше про нас →
            </Link>
          </div>
          <div className={styles.videoCard}>
            <img
              src="https://picsum.photos/800/600?random=12"
              alt="Німецька вівчарка виконує команду поруч з кінологом"
              loading="lazy"
            />
            <div className={styles.videoOverlay}>
              <p>Спостерігайте за прогресом у реальному часі з онлайн-звітами після кожного тренування.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesPreview} id="services">
        <div className="container">
          <h2 className="sectionTitle">Наші ключові послуги</h2>
          <p className="sectionSubtitle">
            Підбираємо комплексний план дій з урахуванням темпераменту, віку та цілей вашої німецької вівчарки.
          </p>
          <div className={`grid ${styles.serviceGrid}`}>
            <article className="card">
              <h3>Базова слухняність</h3>
              <p>
                Формуємо чітке розуміння базових команд, роботу на повідку, контроль імпульсів та адаптацію до міського
                середовища.
              </p>
              <Link to="/posluhy" className={styles.linkArrow}>
                Деталі →
              </Link>
            </article>
            <article className="card">
              <h3>Поглиблені програми</h3>
              <p>
                Готуємо собак до службових завдань, спортивних змагань або специфічних навичок охорони без використання
                агресивних методів.
              </p>
              <Link to="/posluhy" className={styles.linkArrow}>
                Що входить →
              </Link>
            </article>
            <article className="card">
              <h3>Корекція поведінки</h3>
              <p>
                Допомагаємо впоратися зі страхами, надмірною збудженістю, неконтрольованим гавкотом та руйнівною
                поведінкою вдома.
              </p>
              <Link to="/posluhy" className={styles.linkArrow}>
                План роботи →
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <h2 className="sectionTitle">Як ми працюємо</h2>
          <div className={`grid ${styles.processGrid}`}>
            <div className={`${styles.processStep} card`}>
              <span>01</span>
              <h3>Огляд потреб</h3>
              <p>Проводимо консультацію, вивчаємо характер собаки та очікування родини.</p>
            </div>
            <div className={`${styles.processStep} card`}>
              <span>02</span>
              <h3>Індивідуальний план</h3>
              <p>Формуємо програму занять, графік та домашні рекомендації.</p>
            </div>
            <div className={`${styles.processStep} card`}>
              <span>03</span>
              <h3>Тренування та підтримка</h3>
              <p>Працюємо з собакою й власниками, супроводжуємо між зустрічами.</p>
            </div>
            <div className={`${styles.processStep} card`}>
              <span>04</span>
              <h3>Аналіз результатів</h3>
              <p>Оцінюємо прогрес, закріплюємо навички й надаємо рекомендації на майбутнє.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.workingAreas}>
        <div className="container">
          <h2 className="sectionTitle">Географія нашої роботи</h2>
          <p className="sectionSubtitle">
            Проводимо заняття на базах у Варшаві та Кракові, а також організовуємо виїзні тренування у передмістях.
          </p>
          <div className={`grid gridTwo ${styles.locations}`}>
            <div className="card">
              <h3>Варшава</h3>
              <p>Вул. Собача, 15. Зручний майданчик із закритою зоною для занять, кімнати для групових сесій.</p>
              <ul className={styles.list}>
                <li>Групи для щенят та дорослих собак</li>
                <li>Індивідуальні програми для службових ліній</li>
                <li>Підготовка до виставок та obedience</li>
              </ul>
            </div>
            <div className="card">
              <h3>Краков</h3>
              <p>Вул. Песя, 8. Просторий тренувальний майданчик із можливістю виїзду до клієнта.</p>
              <ul className={styles.list}>
                <li>Домашні візити для корекції поведінки</li>
                <li>Майстер-класи для власників</li>
                <li>Підтримка собак з притулків</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <h2 className="sectionTitle">Приклади успішних історій</h2>
          <div className={`grid gridTwo ${styles.projectGrid}`}>
            <div className={styles.projectCard}>
              <img
                src="https://picsum.photos/1200/800?random=13"
                alt="Німецька вівчарка під час вправи на витримку"
                loading="lazy"
              />
              <div className={styles.projectContent}>
                <h3>Робоча вівчарка Аста</h3>
                <p>
                  За три місяці підготували до служби у кінологічному підрозділі. Основний акцент — витривалість,
                  концентрація та безпечна робота поруч з людьми.
                </p>
                <Link to="/nashi-uspikhy" className={styles.linkArrow}>
                  Читати більше →
                </Link>
              </div>
            </div>
            <div className={styles.projectCard}>
              <img
                src="https://picsum.photos/1200/800?random=14"
                alt="Собака виконує команду лежати поруч з власницею"
                loading="lazy"
              />
              <div className={styles.projectContent}>
                <h3>Сімейна вівчарка Еля</h3>
                <p>
                  Дитина з аутизмом відчула себе впевненіше поруч із собакою. Ми навчали Елю м&apos;яким командам та
                  стабілізували її реакції на шум.
                </p>
                <Link to="/nashi-uspikhy" className={styles.linkArrow}>
                  Дізнатись історію →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <h2 className="sectionTitle">Відгуки родин</h2>
          <div className={styles.testimonialSlider}>
            <button
              className={styles.sliderButton}
              onClick={() =>
                setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
              }
              aria-label="Попередній відгук"
            >
              ←
            </button>
            <div className={`${styles.testimonialCard} card`}>
              <p>“{testimonials[currentTestimonial].quote}”</p>
              <h4>{testimonials[currentTestimonial].name}</h4>
              <span>{testimonials[currentTestimonial].role}</span>
            </div>
            <button
              className={styles.sliderButton}
              onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)}
              aria-label="Наступний відгук"
            >
              →
            </button>
          </div>
          <div className={styles.dots}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={index === currentTestimonial ? styles.dotActive : ''}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Переглянути відгук ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <h2 className="sectionTitle">Поширені запитання</h2>
          <div className={styles.accordion}>
            {faqItems.map((item, index) => (
              <div className={styles.accordionItem} key={item.question}>
                <button
                  className={styles.accordionHeader}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={openFaq === index}
                >
                  <span>{item.question}</span>
                  <span>{openFaq === index ? '−' : '+'}</span>
                </button>
                {openFaq === index && <div className={styles.accordionContent}>{item.answer}</div>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <h2 className="sectionTitle">Блог та корисні матеріали</h2>
          <div className={`grid gridThree ${styles.blogGrid}`}>
            <article className="card">
              <img
                src="https://picsum.photos/600/400?random=15"
                alt="Щеня німецької вівчарки під час тренування"
                loading="lazy"
              />
              <h3>Перші 6 команд для щеняти</h3>
              <p>Які навички допоможуть закласти базу слухняності для активної вівчарки з перших тижнів життя.</p>
              <a href="#blog" className={styles.linkArrow}>
                Читати →
              </a>
            </article>
            <article className="card">
              <img
                src="https://picsum.photos/600/400?random=16"
                alt="Кінолог демонструє, як нагороджувати собаку"
                loading="lazy"
              />
              <h3>Мотивація без примусу</h3>
              <p>Секрети використання позитивного підкріплення у роботі з дорослими німецькими вівчарками.</p>
              <a href="#blog" className={styles.linkArrow}>
                Читати →
              </a>
            </article>
            <article className="card">
              <img
                src="https://picsum.photos/600/400?random=17"
                alt="Собака знаходиться поруч з господарем у місті"
                loading="lazy"
              />
              <h3>Життя в місті</h3>
              <p>Як навчити собаку залишатися сконцентрованою в шумному середовищі та реагувати на команди миттєво.</p>
              <a href="#blog" className={styles.linkArrow}>
                Читати →
              </a>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.contactFormSection}>
        <div className="container grid gridTwo">
          <div>
            <h2 className="sectionTitle">Готові розпочати навчання?</h2>
            <p className="sectionSubtitle">
              Заповніть форму, і наш координатор зв’яжеться з вами протягом одного робочого дня, щоб узгодити
              безкоштовну вступну консультацію.
            </p>
            <ul className={styles.list}>
              <li>Підтримка у Варшаві та Кракові</li>
              <li>Індивідуальні та групові формати</li>
              <li>Доступ до закритої спільноти власників</li>
            </ul>
          </div>
          <form className={styles.form} onSubmit={handleSubmit}>
            <label>
              Ім’я*
              <input type="text" name="name" required placeholder="Ваше ім’я" />
            </label>
            <label>
              Email*
              <input type="email" name="email" required placeholder="name@email.com" />
            </label>
            <label>
              Місто*
              <select name="city" defaultValue="Варшава" required>
                <option value="Варшава">Варшава</option>
                <option value="Краков">Краков</option>
                <option value="Інше">Інше (виїзні заняття)</option>
              </select>
            </label>
            <label>
              Ваш запит
              <textarea name="message" rows="4" placeholder="Розкажіть про собаку та бажаний результат" />
            </label>
            <button type="submit" className="primaryButton" disabled={formStatus.sending}>
              {formStatus.sending ? 'Надсилаємо...' : 'Надіслати заявку'}
            </button>
            {formStatus.sent && <p className={styles.formSuccess}>Дякуємо! Ми зв’яжемося з вами найближчим часом.</p>}
          </form>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Ваш вірний партнер заслуговує на професійний підхід</h2>
            <p>
              Запишіться на знайомство з кінологом і дізнайтеся, як зробити співжиття з німецькою вівчаркою гармонійним.
            </p>
            <Link to="/kontakty" className="primaryButton">
              Замовити консультацію
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;