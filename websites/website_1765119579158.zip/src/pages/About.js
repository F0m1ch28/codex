import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Катерина Сіла',
    role: 'Головна тренерка, кінолог-журналіст',
    image: 'https://picsum.photos/400/400?random=21',
    bio: '12 років досвіду в підготовці робочих ліній німецьких вівчарок. Сертифікована спеціалістка FCI.',
  },
  {
    name: 'Рафал Новак',
    role: 'Координатор програм у Варшаві',
    image: 'https://picsum.photos/400/400?random=22',
    bio: 'Експерт із корекції поведінки, працює з собаками, які пережили стрес або травматичний досвід.',
  },
  {
    name: 'Світлана Коваль',
    role: 'Сімейна кінологиня, Краков',
    image: 'https://picsum.photos/400/400?random=23',
    bio: 'Допомагає родинам з дітьми вибудувати комфортну комунікацію з улюбленцем та створити безпечний простір.',
  },
];

function About() {
  return (
    <>
      <Seo
        title="Про нас | Професійна дресирування німецьких вівчарок"
        description="Познайомтеся з командою кінологів у Варшаві та Кракові, які професійно займаються дресируванням німецьких вівчарок."
        keywords="кінолог Варшава, тренер собак Краков, команда кінологів"
      />
      <section className={styles.intro}>
        <div className="container">
          <span className="badge">Про команду</span>
          <h1>Професіонали, які знають породу зсередини</h1>
          <p>
            Ми створили центр, де пропагуємо відповідальне ставлення до німецьких вівчарок та пропонуємо індивідуальні
            програми для кожної родини. Кожен тренер має практичний досвід у роботі з різними лініями породи — від
            спортивних до сімейних.
          </p>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container grid gridThree">
          <div className="card">
            <h3>Гуманність</h3>
            <p>Розвиваємо довіру та взаєморозуміння, виключаючи будь-які агресивні методи.</p>
          </div>
          <div className="card">
            <h3>Експертиза</h3>
            <p>Постійно проходимо навчання, беремо участь у семінарах та обмінюємося досвідом із колегами.</p>
          </div>
          <div className="card">
            <h3>Партнерство</h3>
            <p>Розробляємо програму разом з власниками, даємо підтримку та супровід після завершення курсу.</p>
          </div>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container grid gridTwo">
          <div>
            <h2 className="sectionTitle">Наша історія</h2>
            <p>
              Центр «Професійна дресирування німецьких вівчарок» виник як ініціатива групи кінологів, які прагнули
              створити місце, де власники отримують компетентну допомогу та системні знання. Ми об’єднали польських і
              українських спеціалістів, щоб обслуговувати клієнтів двома мовами та ділитися багатонаціональним досвідом.
            </p>
            <p>
              Сьогодні ми проводимо групові та індивідуальні заняття, семінари для ветеринарів та консультативні сесії
              для притулків, що працюють з німецькими вівчарками.
            </p>
          </div>
          <div className={styles.imageBlock}>
            <img
              src="https://picsum.photos/800/600?random=24"
              alt="Команда тренерів під час заняття з німецькою вівчаркою"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <h2 className="sectionTitle">Наша команда</h2>
          <div className={`grid gridThree ${styles.teamGrid}`}>
            {teamMembers.map((member) => (
              <div key={member.name} className={`${styles.member} card`}>
                <img src={member.image} alt={`${member.name} - ${member.role}`} loading="lazy" />
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.approach}>
        <div className="container">
          <h2 className="sectionTitle">Наш підхід до навчання</h2>
          <div className={`grid gridTwo ${styles.approachGrid}`}>
            <div className="card">
              <h3>Створюємо баланс</h3>
              <p>
                Забезпечуємо рівновагу між фізичними вправами, інтелектуальним навантаженням і соціальною взаємодією,
                необхідними для цієї породи.
              </p>
            </div>
            <div className="card">
              <h3>Підтримуємо власників</h3>
              <p>
                Пояснюємо, як працює собача мотивація, супроводжуємо між заняттями, надаємо відео та письмові матеріали.
              </p>
            </div>
            <div className="card">
              <h3>Враховуємо здоров’я</h3>
              <p>
                Працюємо в партнерстві з ветеринарними фахівцями, щоб адаптувати тренування до фізичних можливостей
                собаки (без втручання в медичні процедури).
              </p>
            </div>
            <div className="card">
              <h3>Розвиваємо софт-навыки</h3>
              <p>
                Навчаємо власників розпізнавати сигнали собаки, будувати контакт і уникати поширених помилок у щоденній
                взаємодії.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;