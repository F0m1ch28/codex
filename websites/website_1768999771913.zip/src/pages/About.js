import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const About = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Cum funcționează verificările digitale | captchaverify.org</title>
      <meta
        name="description"
        content="Explicație structurată și neutră a principiilor, fluxurilor și componentelor din verificările digitale moderne."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Cum funcționează verificările digitale</h1>
      <p>
        Această pagină oferă o perspectivă de ansamblu asupra etapelor și
        elementelor care compun procesele de verificare online. Nu este un ghid
        procedural, ci un material de înțelegere conceptuală.
      </p>
    </header>

    <section className={styles.section}>
      <h2>Principii de bază</h2>
      <p>
        Verificările digitale urmăresc trei obiective principale: confirmarea
        identității, validarea intenției și evaluarea contextului. Pentru a
        atinge aceste obiective, sistemele combină metode tradiționale (parole,
        întrebări de securitate) cu mecanisme avansate bazate pe date și
        comportament. Important este echilibrul între securitate și experiența
        utilizatorului: o verificare eficientă trebuie să fie robustă, dar și
        intuitivă.
      </p>
      <p>
        În practică, procesele sunt susținute de algoritmi care analizează
        tiparele de utilizare. De exemplu, un comportament neobișnuit poate
        declanșa verificări suplimentare, în timp ce un profil constant poate
        beneficia de o experiență fluidă.
      </p>
    </section>

    <section className={styles.section}>
      <h2>Fluxul unei verificări</h2>
      <div className={styles.flowCard}>
        <ol className={styles.flowList}>
          <li>
            <strong>Inițierea cererii:</strong> Utilizatorul începe o acțiune ce
            necesită confirmare suplimentară (autentificare, tranzacție,
            modificare de date).
          </li>
          <li>
            <strong>Colectarea datelor contextuale:</strong> Sistemul evaluează
            factori precum locația, reputația dispozitivului și istoricul de
            conectare.
          </li>
          <li>
            <strong>Aplicarea verificărilor:</strong> Se generează un test
            (CAPTCHA, cod trimis pe alt canal, mesaj de confirmare).
          </li>
          <li>
            <strong>Validarea răspunsului:</strong> Răspunsul este analizat în
            timp real și comparat cu parametrii acceptați.
          </li>
          <li>
            <strong>Audit și logare:</strong> Rezultatul este înregistrat pentru
            audit și pentru adaptarea ulterioară a regulilor.
          </li>
        </ol>
      </div>
      <p>
        Această structură poate fi simplificată sau extinsă în funcție de
        sensibilitatea acțiunii. Platformele financiare, de exemplu, aplică
        straturi suplimentare comparativ cu un serviciu de divertisment.
      </p>
    </section>

    <section className={styles.section}>
      <h2>Componentele sistemului</h2>
      <div className={styles.componentsGrid}>
        <article className={styles.componentCard}>
          <h3>Interfața cu utilizatorul</h3>
          <p>
            Locul în care are loc interacțiunea efectivă. Designul trebuie să
            transmită claritate, iar mesajele să fie lipsite de ambiguitate pentru
            a evita confuziile.
          </p>
        </article>
        <article className={styles.componentCard}>
          <h3>Motorul de reguli</h3>
          <p>
            Segmentul care decide ce verificare este declanșată, pe baza datelor
            colectate și a politicilor de securitate. Poate fi actualizat frecvent
            în funcție de amenințări.
          </p>
        </article>
        <article className={styles.componentCard}>
          <h3>Serviciile auxiliare</h3>
          <p>
            Include serviciile de e-mail, SMS, autentificare biometrică sau
            integrarea cu furnizori externi pentru verificări suplimentare.
          </p>
        </article>
        <article className={styles.componentCard}>
          <h3>Monitorizare și analiză</h3>
          <p>
            Componente dedicate colectării logurilor și analizei post-eveniment,
            pentru ajustări și pentru detectarea tentativelor de fraudă.
          </p>
        </article>
      </div>
      <p>
        Colaborarea dintre aceste componente asigură o experiență coerentă.
        Fiecare element contribuie la reducerea riscurilor, fără a transforma
        verificarea într-un obstacol inutil.
      </p>
    </section>
  </div>
);

export default About;