import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Politica de cookie-uri | captchaverify.org</title>
      <meta
        name="description"
        content="Politica captchaverify.org privind utilizarea cookie-urilor și opțiunile vizitatorilor."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Politica de cookie-uri</h1>
      <p>
        Această politică descrie tipurile de cookie-uri utilizate pe
        captchaverify.org, scopurile lor și modul în care le puteți gestiona.
        Ultima actualizare: 15 aprilie 2024.
      </p>
    </header>

    <section className={styles.section}>
      <h2>1. Ce sunt cookie-urile?</h2>
      <p>
        Cookie-urile reprezintă fișiere text stocate temporar pe dispozitivul
        dvs., care ajută site-ul să ofere o experiență coerentă. Ele pot
        conține identificatori tehnici, preferințe sau date statistice
        anonimizate.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Cookie-uri utilizate</h2>
      <div className={styles.table}>
        <div className={styles.row}>
          <div className={styles.cellTitle}>Cookie-uri esențiale</div>
          <div>
            Necesare pentru funcționarea de bază a site-ului (menținerea
            sesiunii, consimțământul pentru cookie-uri). Nu pot fi dezactivate.
          </div>
        </div>
        <div className={styles.row}>
          <div className={styles.cellTitle}>Cookie-uri analitice</div>
          <div>
            Folosite într-un mod agregat pentru a înțelege modul de utilizare al
            site-ului. Nu colectăm date personale și nu profilăm utilizatorii.
          </div>
        </div>
      </div>
    </section>

    <section className={styles.section}>
      <h2>3. Gestionarea cookie-urilor</h2>
      <p>
        Puteți controla cookie-urile din setările browserului. Majoritatea
        browserelor permit ștergerea sau blocarea cookie-urilor. Rețineți că
        dezactivarea cookie-urilor esențiale poate afecta funcționalitatea
        site-ului.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Durata stocării</h2>
      <p>
        Cookie-urile esențiale sunt păstrate atât timp cât este necesar pentru a
        menține sesiunea activă. Cookie-urile analitice sunt stocate pentru
        perioade cuprinse între 24 de ore și 12 luni.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Modificări</h2>
      <p>
        Politica de cookie-uri poate fi actualizată. Orice modificare va fi
        publicată pe această pagină împreună cu data ultimei actualizări.
      </p>
    </section>
  </div>
);

export default CookiePolicy;