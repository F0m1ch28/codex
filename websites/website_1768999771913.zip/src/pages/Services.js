import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import articles from '../data/articles';
import styles from './Services.module.css';

const Services = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Articole explicative | captchaverify.org</title>
      <meta
        name="description"
        content="Lista articolelor captchaverify.org despre verificarea digitală, securitate și evoluția autentificării."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Articole explicative</h1>
      <p>
        Materialele de mai jos oferă clarificări tematice despre tipuri de
        CAPTCHA, securitatea datelor și trendurile viitoare în autentificare.
        Sunt texte informative, fără instrucțiuni operaționale.
      </p>
    </header>

    <section className={styles.articlesSection}>
      <div className={styles.grid}>
        {articles.map((article) => (
          <article key={article.slug} className={styles.card}>
            <p className={styles.category}>{article.category}</p>
            <h2 className={styles.title}>{article.title}</h2>
            <p className={styles.summary}>{article.summary}</p>
            <div className={styles.meta}>
              <span>{article.readingTime}</span>
              <span> — </span>
              <span>{article.date.replace(/-/g, '.')}</span>
            </div>
            <Link
              to={"/articol/${article.slug}"}
              className={styles.link}
              aria-label={"Deschide articolul ${article.title}"}
            >
              Citește mai mult
            </Link>
          </article>
        ))}
      </div>
    </section>
  </div>
);

export default Services;