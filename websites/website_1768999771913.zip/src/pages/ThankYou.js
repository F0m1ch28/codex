import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './ThankYou.module.css';

const ThankYou = () => {
  const location = useLocation();
  const submittedName =
    typeof location.state?.name === 'string' && location.state.name.trim().length
      ? location.state.name.trim()
      : null;

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Mulțumim pentru mesaj | captchaverify.org</title>
        <meta
          name="description"
          content="Confirmare de primire pentru mesajele trimise către captchaverify.org."
        />
      </Helmet>

      <section className={styles.section}>
        <h1>Mesaj primit</h1>
        <p>
          {submittedName ? (
            <>
              Mulțumim, <span className={styles.highlight}>{submittedName}</span>,
              pentru că ne-ați contactat. Vom analiza mesajul și vom reveni doar
              dacă este necesară o clarificare.
            </>
          ) : (
            'Mulțumim pentru mesaj. Îl vom analiza în cel mai scurt timp posibil.'
          )}
        </p>
        <p>
          Ne propunem să răspundem în intervalul orar menționat pe pagina de
          contact, pentru solicitările care se încadrează în scopul informativ al
          site-ului.
        </p>
        <div className={styles.actions}>
          <Link to="/" className={styles.link}>
            Înapoi la pagina principală
          </Link>
          <Link to="/articole" className={styles.secondaryLink}>
            Explorează articolele
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ThankYou;