import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import articles from '../data/articles';
import styles from './ArticleDetail.module.css';

const ArticleDetail = () => {
  const { slug } = useParams();
  const article = articles.find((item) => item.slug === slug);

  if (!article) {
    return (
      <div className={styles.wrapper}>
        <Helmet>
          <title>Articol indisponibil | captchaverify.org</title>
        </Helmet>
        <section className={styles.section}>
          <h1>Articolul nu a fost găsit</h1>
          <p>
            Ne pare rău, nu am identificat materialul căutat. Vă invităm să
            reveniți la lista completă de articole.
          </p>
          <Link to="/articole" className={styles.link}>
            Înapoi la articole
          </Link>
        </section>
      </div>
    );
  }

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>{"${article.title} | captchaverify.org"}</title>
        <meta name="description" content={article.summary} />
        <meta name="keywords" content={article.keywords.join(', ')} />
        <meta name="author" content="captchaverify.org" />
      </Helmet>

      <article className={styles.article}>
        <header className={styles.header}>
          <p className={styles.meta}>
            {article.date.replace(/-/g, '.')} · {article.readingTime}
          </p>
          <h1 className={styles.title}>{article.title}</h1>
          <p className={styles.summary}>{article.summary}</p>
        </header>

        {article.sections.map((section) => (
          <section key={section.heading} className={styles.section}>
            <h2>{section.heading}</h2>
            {section.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </section>
        ))}

        <section className={styles.section}>
          <h2>În concluzie</h2>
          <p>{article.conclusion}</p>
        </section>

        <footer className={styles.footer}>
          <Link to="/articole" className={styles.link}>
            Înapoi la articole
          </Link>
        </footer>
      </article>
    </div>
  );
};

export default ArticleDetail;