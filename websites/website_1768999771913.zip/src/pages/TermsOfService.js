import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsOfService.module.css';

const TermsOfService = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Termeni și condiții | captchaverify.org</title>
      <meta
        name="description"
        content="Termenii și condițiile de utilizare pentru portalul informativ captchaverify.org."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Termeni și condiții de utilizare</h1>
      <p>
        Ultima actualizare: 15 aprilie 2024. Utilizarea site-ului
        captchaverify.org implică acceptarea termenilor prezentați în această
        pagină.
      </p>
    </header>

    <section className={styles.section}>
      <h2>1. Scopul site-ului</h2>
      <p>
        captchaverify.org este un portal informativ. Informațiile publicate au
        caracter general și nu constituie servicii comerciale, consultanță
        tehnică sau recomandări personalizate. Utilizatorii sunt responsabili
        pentru modul în care interpretează și utilizează informațiile prezentate.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Limitarea responsabilității</h2>
      <p>
        Deși depunem eforturi pentru menținerea exactității informațiilor, nu
        oferim garanții explicite sau implicite privind completitudinea,
        actualitatea sau adecvarea conținutului. Nu suntem responsabili pentru
        prejudicii directe sau indirecte rezultate din utilizarea informațiilor
        de pe site.
      </p>
    </section>

    <section className={styles.section}>
      <h2>3. Drepturi de proprietate intelectuală</h2>
      <p>
        Conținutul site-ului (texte, grafice, elemente vizuale) este protejat de
        legislația privind drepturile de autor. Reproducerea, distribuirea sau
        adaptarea materialelor este permisă doar cu menționarea sursei și fără a
        altera mesajul inițial.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Utilizare corectă</h2>
      <p>
        Utilizatorii se angajează să nu utilizeze site-ul pentru acțiuni de
        natură ilegală, frauduloasă sau care ar putea afecta funcționarea
        platformei. Ne rezervăm dreptul de a restricționa accesul în cazul
        identificării unor încercări de abuz.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Link-uri către terți</h2>
      <p>
        Site-ul poate include referințe către resurse externe. captchaverify.org
        nu controlează și nu își asumă responsabilitatea pentru conținutul acelor
        site-uri. Vizitarea lor se face pe propria răspundere.
      </p>
    </section>

    <section className={styles.section}>
      <h2>6. Modificări</h2>
      <p>
        Termenii pot fi actualizați fără notificare prealabilă. Versiunea
        actualizată va fi disponibilă întotdeauna pe această pagină. Continuarea
        utilizării site-ului reprezintă acceptarea modificărilor.
      </p>
    </section>

    <section className={styles.section}>
      <h2>7. Contact</h2>
      <p>
        Pentru întrebări referitoare la acești termeni, ne puteți contacta la
        adresa contact@captchaverify.org.
      </p>
    </section>
  </div>
);

export default TermsOfService;