import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';
import articles from '../data/articles';

const Home = () => {
  const latestArticles = articles.slice(0, 3);

  return (
    <div className={styles.home}>
      <Helmet>
        <title>captchaverify.org | Portal informativ despre verificarea digitală</title>
        <meta
          name="description"
          content="Portal informativ în limba română despre verificarea digitală, CAPTCHA, autentificare și bune practici online."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>
            Explicăm verificarea online într-un limbaj accesibil
          </h1>
          <p className={styles.heroText}>
            captchaverify.org este o inițiativă informativă care clarifică
            mecanismele din spatele sistemelor de verificare digitală, fără
            abordări comerciale sau instrucțiuni pas-cu-pas.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Ce este verificarea online?</h2>
          <p>
            Verificarea online include procesele prin care platformele digitale
            confirmă autenticitatea utilizatorilor, a tranzacțiilor sau a
            conținutului. Fie că vorbim despre CAPTCHA, autentificare cu doi
            factori sau verificarea documentelor, scopul este același:
            protejarea sistemelor și a utilizatorilor împotriva abuzurilor.
          </p>
        </div>
        <div className={styles.grid}>
          <article className={styles.card}>
            <h3>Verificarea identității</h3>
            <p>
              Include metode de confirmare a identității utilizatorilor, de la
              parole unice până la validare biometrică în scopuri de securitate.
            </p>
          </article>
          <article className={styles.card}>
            <h3>Validarea conținutului</h3>
            <p>
              Motoarele și platformele digitale evaluează conținutul pentru a
              preveni distribuirea de informații dăunătoare sau automate.
            </p>
          </article>
          <article className={styles.card}>
            <h3>Monitorizare continuă</h3>
            <p>
              Sistemele moderne urmăresc comportamentul în timp real pentru a
              identifica activități suspecte și pentru a reduce riscurile.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Tehnologii comune</h2>
          <p>
            Principalele mecanisme de verificare utilizează combinații de
            algoritmi, date istorice și interacțiunea directă cu utilizatorul.
          </p>
        </div>
        <div className={styles.techGrid}>
          <div className={styles.techItem}>
            <h3>CAPTCHA</h3>
            <p>
              Teste automate concepute pentru a diferenția utilizatorii reali de
              programe. Variantele moderne se bazează pe analiză comportamentală
              și învățare automată.
            </p>
          </div>
          <div className={styles.techItem}>
            <h3>Autentificare multifactor (MFA)</h3>
            <p>
              Necesită cel puțin doi factori de confirmare: ceva ce știi, ceva
              ce deții sau ceva ce ești (biometrie).
            </p>
          </div>
          <div className={styles.techItem}>
            <h3>Verificări contextuale</h3>
            <p>
              Analizează locația, dispozitivul și istoricul acțiunilor pentru a
              adapta nivelul de securitate la contextul utilizatorului.
            </p>
          </div>
          <div className={styles.techItem}>
            <h3>Semnături digitale</h3>
            <p>
              Asigură integritatea documentelor și confirmă sursa acestora prin
              criptografie avansată.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Importanța securității digitale</h2>
          <p>
            Într-un ecosistem digital intens conectat, securitatea este o
            responsabilitate comună. Practicile corecte de verificare limitează
            accesul neautorizat, reduc fraudele și mențin încrederea în
            interacțiunile online. Informarea corectă ajută utilizatorii să
            recunoască procese legitime și să evite abuzurile.
          </p>
        </div>
        <ul className={styles.list}>
          <li>
            Evaluarea atentă a mesajelor și notificărilor primite de la
            platforme.
          </li>
          <li>
            Utilizarea unor parole unice și activarea autentificării suplimentare
            acolo unde este posibil.
          </li>
          <li>
            Revizuirea periodică a permisiunilor aplicațiilor și serviciilor
            conectate.
          </li>
        </ul>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Portalul nostru de resurse</h2>
          <p>
            Explorați materialele structurate pentru a înțelege rolul și
            funcționarea proceselor digitale actuale.
          </p>
        </div>
        <div className={styles.resources}>
          <Link to="/cum-functioneaza" className={styles.resourceCard}>
            <span className={styles.resourceTitle}>Cum funcționează</span>
            <p>
              Un overview clar al etapelor din verificările digitale, fără a
              deveni un ghid operativ.
            </p>
          </Link>
          <Link to="/articole" className={styles.resourceCard}>
            <span className={styles.resourceTitle}>Articole explicative</span>
            <p>
              Analize ample despre tehnologiile utilizate curent și trendurile
              emergente.
            </p>
          </Link>
          <Link to="/contact" className={styles.resourceCard}>
            <span className={styles.resourceTitle}>Date de contact</span>
            <p>
              Informații de corespondență și clarificări despre scopul
              non-comercial al platformei.
            </p>
          </Link>
        </div>
      </section>

      <section className={styles.disclaimerSection}>
        <div className={styles.disclaimerBox} role="note">
          <h2>Important</h2>
          <p>
            captchaverify.org oferă informații independente și neutre despre
            procesele de verificare digitală. Nu solicităm date personale, nu
            realizăm intervenții tehnice și nu furnizăm servicii comerciale.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Ultimele clarificări</h2>
          <p>
            Articole recente care explică în profunzime teme frecvent întâlnite
            în verificarea digitală.
          </p>
        </div>
        <div className={styles.latestGrid}>
          {latestArticles.map((article) => (
            <article key={article.slug} className={styles.latestCard}>
              <p className={styles.date}>
                Publicat la {article.date.replace(/-/g, '.')}
              </p>
              <h3 className={styles.latestTitle}>{article.title}</h3>
              <p className={styles.latestSummary}>{article.summary}</p>
              <Link
                to={"/articol/${article.slug}"}
                className={styles.readMore}
                aria-label={"Citește articolul ${article.title}"}
              >
                Citește detalii
              </Link>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;