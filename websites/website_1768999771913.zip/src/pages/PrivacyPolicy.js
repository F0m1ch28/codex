import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicy = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Politica de confidențialitate | captchaverify.org</title>
      <meta
        name="description"
        content="Politica de confidențialitate a portalului captchaverify.org, care descrie modul de prelucrare a datelor."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Politica de confidențialitate</h1>
      <p>
        Această politică detaliază modul în care captchaverify.org gestionează
        datele personale ale vizitatorilor. Ultima actualizare: 15 aprilie 2024.
      </p>
    </header>

    <section className={styles.section}>
      <h2>1. Operatorul datelor</h2>
      <p>
        captchaverify.org este administrat de un grup editorial independent cu
        sediul la Viru väljak 4, Tallinn, 10111, Estonia. Pentru întrebări,
        scrieți la contact@captchaverify.org.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Date colectate</h2>
      <ul className={styles.list}>
        <li>
          Date tehnice anonimizate (adresă IP trunchiată, tipul dispozitivului,
          versiunea browserului) pentru statistici agregate.
        </li>
        <li>
          Date transmise voluntar prin formularul de contact (nume, e-mail,
          mesaj).
        </li>
      </ul>
      <p>
        Nu solicităm documente de identitate, parole sau informații sensibile.
        Mesajele sunt destinate exclusiv clarificărilor privind conținutul.
      </p>
    </section>

    <section className={styles.section}>
      <h2>3. Temeiul legal</h2>
      <p>
        Prelucrarea datelor are loc în baza interesului legitim de a asigura
        funcționarea site-ului și de a răspunde solicitărilor legitime ale
        vizitatorilor. Când transmiteți un mesaj, vă exprimați consimțământul
        pentru utilizarea datelor în scopul răspunsului.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Durata stocării</h2>
      <p>
        Datele tehnice anonimizate sunt păstrate maximum 12 luni. Mesajele din
        formularul de contact sunt arhivate timp de 6 luni, după care sunt
        șterse.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Partajarea datelor</h2>
      <p>
        Nu vindem și nu cedăm date personale către terți. Datele pot fi
        partajate doar dacă suntem obligați prin lege sau pentru apărarea
        drepturilor noastre legitime.
      </p>
    </section>

    <section className={styles.section}>
      <h2>6. Drepturile persoanelor vizate</h2>
      <ul className={styles.list}>
        <li>Dreptul de acces la datele personale proprii.</li>
        <li>Dreptul de rectificare sau ștergere a datelor.</li>
        <li>Dreptul de restricționare a prelucrării, în condițiile legii.</li>
        <li>Dreptul de opoziție la prelucrare.</li>
        <li>Dreptul de portabilitate, acolo unde este aplicabil.</li>
      </ul>
      <p>
        Pentru exercitarea acestor drepturi, ne puteți contacta la
        contact@captchaverify.org. Vom răspunde în maximum 30 de zile.
      </p>
    </section>

    <section className={styles.section}>
      <h2>7. Securitatea datelor</h2>
      <p>
        Implementăm măsuri rezonabile pentru a preveni accesul neautorizat,
        pierderea sau alterarea datelor. Totuși, niciun sistem nu poate garanta
        securitate absolută; recomandăm prudență în transmiterea informațiilor.
      </p>
    </section>

    <section className={styles.section}>
      <h2>8. Cookie-uri</h2>
      <p>
        Site-ul utilizează cookie-uri esențiale și analitice limitate. Detalii
        complete sunt disponibile în{' '}
        <a href="/politica-de-cookie-uri" className={styles.inlineLink}>
          politica de cookie-uri
        </a>
        .
      </p>
    </section>

    <section className={styles.section}>
      <h2>9. Modificări ale politicii</h2>
      <p>
        Putem actualiza această politică pentru a reflecta evoluții legislative
        sau operaționale. Versiunea curentă este publicată permanent pe această
        pagină.
      </p>
    </section>

    <section className={styles.section}>
      <h2>10. Reclamații</h2>
      <p>
        Dacă considerați că drepturile v-au fost încălcate, puteți contacta
        Autoritatea Estoniană pentru Protecția Datelor. Încurajăm rezolvarea
        amiabilă prin contact direct cu noi.
      </p>
    </section>
  </div>
);

export default PrivacyPolicy;