import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Introduceți un nume valid.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Introduceți o adresă de e-mail.';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email.trim())) {
        newErrors.email = 'Formatul adresei de e-mail nu este valid.';
      }
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Completați mesajul cu solicitarea dvs.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      navigate('/multumim', {
        state: { name: formData.name.trim() },
      });
      setFormData(initialFormState);
    }
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Contact | captchaverify.org</title>
        <meta
          name="description"
          content="Date oficiale de contact pentru captchaverify.org și formularul de transmitere a solicitărilor generale."
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Contact captchaverify.org</h1>
        <p>
          Site-ul are un rol informativ. Dacă aveți întrebări generale despre
          conținutul prezentat, ne puteți scrie folosind detaliile de mai jos.
          Nu procesăm cereri tehnice sau comerciale.
        </p>
      </header>

      <section className={styles.contactInfo}>
        <div className={styles.infoCard}>
          <h2>Coordonate</h2>
          <address>
            Viru väljak 4,
            <br />
            Tallinn, 10111,
            <br />
            Estonia
          </address>
          <a
            href="mailto:contact@captchaverify.org"
            className={styles.inlineLink}
          >
            contact@captchaverify.org
          </a>
          <a href="tel:+3725124586" className={styles.inlineLink}>
            +372 512 4586
          </a>
          <p className={styles.note}>
            Program orientativ: Luni - Vineri, 09:00 - 16:00 (EET).
          </p>
        </div>
        <div className={styles.mapCard}>
          <img
            src="https://picsum.photos/seed/tallinnmap/800/400"
            alt="Hartă ilustrativă Tallinn"
            loading="lazy"
          />
          <p className={styles.mapNote}>
            Ilustrație generică. Nu reprezintă o hartă precisă a locației.
          </p>
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Formular de contact general</h2>
        <p className={styles.formIntro}>
          Mesajele transmise prin acest formular sunt destinate clarificărilor
          referitoare la materialele publicate. Nu colectăm date suplimentare și
          nu oferim suport tehnic personalizat.
        </p>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Nume complet</label>
            <input
              type="text"
              id="name"
              name="name"
              autoComplete="name"
              value={formData.name}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Adresă de e-mail</label>
            <input
              type="email"
              id="email"
              name="email"
              autoComplete="email"
              value={formData.email}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && (
              <span className={styles.error}>{errors.email}</span>
            )}
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Mesaj</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && (
              <span className={styles.error}>{errors.message}</span>
            )}
          </div>
          <button type="submit" className={styles.submitButton}>
            Trimite mesajul
          </button>
        </form>
        <p className={styles.disclaimer}>
          Disclaimer: Formularul este oferit exclusiv pentru comunicare
          informativă. Nu este destinat solicitarilor urgente, intervențiilor
          tehnice sau serviciilor comerciale.
        </p>
      </section>
    </div>
  );
};

export default Contact;