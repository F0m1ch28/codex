const articles = [
  {
    slug: 'tipuri-captcha-aplicatii',
    title: 'Tipuri de CAPTCHA și aplicațiile lor',
    summary:
      'O privire structurată asupra principalelor tipuri de CAPTCHA utilizate astăzi și a scenariilor în care sunt potrivite.',
    category: 'Sisteme de verificare',
    readingTime: '6 minute',
    date: '2024-03-18',
    keywords: [
      'captcha',
      'verificare automatizată',
      'validare utilizatori',
      'securitate online',
    ],
    sections: [
      {
        heading: 'CAPTCHA textuale clasice',
        content: [
          'Primele versiuni CAPTCHA presupuneau recunoașterea unor caractere distorsionate. Simplitatea lor le-a făcut ușor de implementat, dar și vulnerabile în fața algoritmilor de recunoaștere optică a caracterelor.',
          'Astăzi sunt folosite mai ales în scenarii cu risc scăzut sau combinate cu alte metode. Din perspectiva accesibilității, au devenit limitate, motiv pentru care multe platforme le-au înlocuit cu alternative mai intuitive.',
        ],
      },
      {
        heading: 'CAPTCHA bazate pe imagini',
        content: [
          'Testele care solicită selectarea unor obiecte în imagini sunt mai rezistente la automatizare datorită complexității recunoașterii vizuale. În plus, pot integra elemente contextuale, cum ar fi indicarea unui anumit tip de obiect.',
          'Dezavantajul lor constă în necesitatea unei interfețe bine optimizate pentru dispozitive mobile și posibile dificultăți pentru utilizatorii cu deficiențe de vedere.',
        ],
      },
      {
        heading: 'reCAPTCHA invizibil și analize comportamentale',
        content: [
          'Soluțiile invizibile elimină interacțiunile evidente cu utilizatorul și se bazează pe analiză comportamentală, istoricul browserului și semnale de risc. Utilizatorii legitimi rar văd un test manual.',
          'Aceste metode ridică însă întrebări legate de confidențialitate și necesită informare transparentă despre datele colectate.',
        ],
      },
    ],
    conclusion:
      'CAPTCHA rămâne un instrument util atunci când este calibrat corect. Alegerea unei variante trebuie să țină cont de experiența utilizatorului, accesibilitate și obiectivele de securitate ale platformei.',
  },
  {
    slug: 'securitatea-datelor-verificare',
    title: 'Securitatea datelor în procesele de verificare',
    summary:
      'Explicăm cum sunt protejate datele colectate în timpul verificărilor și ce responsabilități au operatorii.',
    category: 'Protecția datelor',
    readingTime: '7 minute',
    date: '2024-02-27',
    keywords: [
      'protecția datelor',
      'gdpr',
      'verificare identitate',
      'securitate digitală',
    ],
    sections: [
      {
        heading: 'Colectarea minimă de date',
        content: [
          'Principiul minimizării impune colectarea doar a datelor absolut necesare pentru verificare. De exemplu, o confirmare prin SMS nu justifică stocarea altor informații personale.',
          'Operatorii trebuie să documenteze motivul pentru care fiecare categorie de date este colectată și să îl comunice clar utilizatorului.',
        ],
      },
      {
        heading: 'Transmiterea și stocarea în siguranță',
        content: [
          'Datele trebuie criptate atât în tranzit, cât și în repaus. Protocoale precum TLS 1.2+ sunt standard pentru comunicațiile web, iar stocarea trebuie să includă controale stricte de acces.',
          'Jurnalele de acces sunt esențiale pentru audit și pentru identificarea eventualelor breșe.',
        ],
      },
      {
        heading: 'Retenția și ștergerea',
        content: [
          'Perioadele de păstrare trebuie stabilite în funcție de scop. Odată încheiată verificarea, datele ar trebui fie anonimizate, fie șterse.',
          'Metodele sigure de ștergere previn recuperarea neautorizată, mai ales când sunt utilizate servicii cloud.',
        ],
      },
    ],
    conclusion:
      'Securitatea datelor în verificări presupune politici clare, infrastructură robustă și transparență față de utilizatori. Respectarea principiilor legale consolidează încrederea și reduce riscurile.',
  },
  {
    slug: 'trenduri-viitoare-autentificare',
    title: 'Trenduri viitoare în autentificarea digitală',
    summary:
      'Analizăm direcțiile în care evoluează autentificarea digitală și ce impact au asupra utilizatorilor.',
    category: 'Perspective',
    readingTime: '8 minute',
    date: '2024-01-15',
    keywords: [
      'autentificare',
      'trenduri',
      'biometrie',
      'identity proofing',
      'ux securitate',
    ],
    sections: [
      {
        heading: 'Autentificare fără parole',
        content: [
          'Standardele FIDO2 și WebAuthn permit autentificarea bazată pe chei criptografice stocate în dispozitive. Utilizatorii beneficiază de simplitate, iar riscul de phishing scade considerabil.',
          'Adopția depinde de suportul hardware și de disponibilitatea platformelor de a investi în integrare.',
        ],
      },
      {
        heading: 'Biometrie adaptivă',
        content: [
          'Dincolo de amprente și recunoaștere facială, sistemele avansate analizează modul în care utilizatorii țin dispozitivul sau ritmul de tastare. Aceste semnale subtile pot confirma identitatea fără pași suplimentari.',
          'Respectarea confidențialității rămâne esențială: datele biometrice sunt dificil de revocat dacă ajung în posesia greșită.',
        ],
      },
      {
        heading: 'Identități digitale suverane',
        content: [
          'Conceptul de identitate suverană (SSI) propune ca utilizatorii să controleze stocarea și partajarea propriilor acreditări, folosind portofele digitale.',
          'Implementarea necesită standardizare și colaborare între instituții, însă poate transforma modul în care ne autentificăm în serviciile publice și private.',
        ],
      },
    ],
    conclusion:
      'Autentificarea se îndreaptă către soluții mai fluide și mai sigure. Cheia succesului o reprezintă interoperabilitatea și comunicarea clară cu utilizatorii privind modul de procesare a datelor.',
  },
];

export default articles;