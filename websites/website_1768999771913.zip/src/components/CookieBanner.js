import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'captchaverify_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem(STORAGE_KEY);
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div
      className={styles.banner}
      role="dialog"
      aria-live="polite"
      aria-label="Informații cookie-uri"
    >
      <p className={styles.message}>
        Folosim cookie-uri esențiale pentru îmbunătățirea experienței. Pentru
        detalii, consultați{' '}
        <Link to="/politica-de-cookie-uri" className={styles.link}>
          politica de cookie-uri
        </Link>
        .
      </p>
      <button
        type="button"
        className={styles.button}
        onClick={handleAccept}
        aria-label="Acceptă utilizarea cookie-urilor"
      >
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;