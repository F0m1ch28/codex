import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="captchaverify.org">
          captchaverify<span className={styles.domain}>.org</span>
        </Link>
        <button
          type="button"
          className={styles.menuToggle}
          aria-label={menuOpen ? 'Închide meniul' : 'Deschide meniul'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className={styles.menuIcon} />
        </button>
        <nav
          className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"}
          aria-label="Navigare principală"
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              isActive ? "${styles.link} ${styles.active}" : styles.link
            }
          >
            Acasă
          </NavLink>
          <NavLink
            to="/cum-functioneaza"
            className={({ isActive }) =>
              isActive ? "${styles.link} ${styles.active}" : styles.link
            }
          >
            Cum funcționează
          </NavLink>
          <NavLink
            to="/articole"
            className={({ isActive }) =>
              isActive ? "${styles.link} ${styles.active}" : styles.link
            }
          >
            Articole
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) =>
              isActive ? "${styles.link} ${styles.active}" : styles.link
            }
          >
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;