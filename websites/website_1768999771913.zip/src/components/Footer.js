import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.topSection}>
        <div className={styles.column}>
          <h3 className={styles.title}>captchaverify.org</h3>
          <p className={styles.text}>
            Portal informativ dedicat explicării proceselor de verificare
            digitală și responsabilităților asociate interacțiunilor online.
          </p>
          <p className={styles.disclaimer}>
            Disclaimer: Informațiile prezentate au caracter strict informativ și
            nu reprezintă servicii comerciale sau consultanță personalizată.
          </p>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subtitle}>Legături utile</h4>
          <ul className={styles.list}>
            <li>
              <Link to="/cum-functioneaza" className={styles.navLink}>
                Cum funcționează verificările
              </Link>
            </li>
            <li>
              <Link to="/articole" className={styles.navLink}>
                Bibliotecă articole
              </Link>
            </li>
            <li>
              <Link to="/termeni-si-conditii" className={styles.navLink}>
                Termeni și condiții
              </Link>
            </li>
            <li>
              <Link
                to="/politica-de-confidentialitate"
                className={styles.navLink}
              >
                Politica de confidențialitate
              </Link>
            </li>
            <li>
              <Link to="/politica-de-cookie-uri" className={styles.navLink}>
                Politica de cookie-uri
              </Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subtitle}>Contact</h4>
          <address className={styles.address}>
            Viru väljak 4,
            <br />
            Tallinn, 10111,
            <br />
            Estonia
          </address>
          <Link to="/contact" className={styles.contactLink}>
            contact@captchaverify.org
          </Link>
          <Link to="/contact" className={styles.contactLink}>
            +372 512 4586
          </Link>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p className={styles.bottomText}>
          © {currentYear} captchaverify.org · Toate drepturile rezervate · Site
          neutru și informativ
        </p>
      </div>
    </footer>
  );
};

export default Footer;