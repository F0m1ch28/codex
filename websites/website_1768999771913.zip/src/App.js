import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';
import ArticleDetail from './pages/ArticleDetail';
import styles from './App.module.css';

const App = () => (
  <div className={styles.app}>
    <Header />
    <main className={styles.main} id="main-content" role="main">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cum-functioneaza" element={<About />} />
        <Route path="/articole" element={<Services />} />
        <Route path="/articol/:slug" element={<ArticleDetail />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/multumim" element={<ThankYou />} />
        <Route path="/termeni-si-conditii" element={<TermsOfService />} />
        <Route
          path="/politica-de-confidentialitate"
          element={<PrivacyPolicy />}
        />
        <Route path="/politica-de-cookie-uri" element={<CookiePolicy />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

export default App;