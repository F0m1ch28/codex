document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptCookieBtn = document.getElementById("cookie-accept");
    const declineCookieBtn = document.getElementById("cookie-decline");
    const contactForm = document.getElementById("contact-form");
    const formMessage = document.getElementById("form-message");
    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightbox-image");
    const lightboxCaption = document.getElementById("lightbox-caption");
    const lightboxClose = document.getElementById("lightbox-close");
    const lightboxBackdrop = document.getElementById("lightbox");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", function () {
            const isOpen = siteNav.classList.toggle("is-open");
            navToggle.classList.toggle("is-active", isOpen);
            if (isOpen) {
                navToggle.setAttribute("aria-expanded", "true");
                siteNav.setAttribute("aria-hidden", "false");
            } else {
                navToggle.setAttribute("aria-expanded", "false");
                siteNav.setAttribute("aria-hidden", "true");
            }
        });

        siteNav.querySelectorAll(".nav-link").forEach(function (link) {
            link.addEventListener("click", function () {
                if (siteNav.classList.contains("is-open")) {
                    siteNav.classList.remove("is-open");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                    siteNav.setAttribute("aria-hidden", "true");
                }
            });
        });
    }

    const cookiePreference = localStorage.getItem("ston_cookie_preference");
    if (!cookiePreference && cookieBanner) {
        cookieBanner.classList.add("is-visible");
    }

    if (acceptCookieBtn && declineCookieBtn) {
        acceptCookieBtn.addEventListener("click", function () {
            localStorage.setItem("ston_cookie_preference", "accepted");
            cookieBanner.classList.remove("is-visible");
        });

        declineCookieBtn.addEventListener("click", function () {
            localStorage.setItem("ston_cookie_preference", "declined");
            cookieBanner.classList.remove("is-visible");
        });
    }

    if (contactForm && formMessage) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get("name").trim();
            const phone = formData.get("phone").trim();
            const email = formData.get("email").trim();
            const message = formData.get("message").trim();
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!name || !phone || !email || !message) {
                showFormMessage("Пожалуйста, заполните все обязательные поля.", true);
                return;
            }

            if (!emailPattern.test(email)) {
                showFormMessage("Проверьте корректность адреса электронной почты.", true);
                return;
            }

            showFormMessage("Спасибо! Ваша заявка отправлена, специалисты «Стон» свяжутся с вами в ближайшее время.", false);
            contactForm.reset();
        });
    }

    function showFormMessage(text, isError) {
        formMessage.textContent = text;
        formMessage.classList.add("is-visible");
        formMessage.classList.toggle("is-error", isError);
        formMessage.classList.toggle("is-success", !isError);
    }

    if (lightbox && lightboxImage && lightboxCaption) {
        const galleryItems = document.querySelectorAll("[data-lightbox]");
        galleryItems.forEach(function (item) {
            item.addEventListener("click", function (event) {
                event.preventDefault();
                const largeImage = item.getAttribute("data-lightbox");
                const caption = item.getAttribute("data-caption") || "";
                lightboxImage.src = largeImage;
                lightboxCaption.textContent = caption;
                lightbox.classList.add("is-active");
                lightbox.setAttribute("aria-hidden", "false");
            });
        });

        function closeLightbox() {
            lightbox.classList.remove("is-active");
            lightbox.setAttribute("aria-hidden", "true");
            lightboxImage.src = "";
            lightboxCaption.textContent = "";
        }

        if (lightboxClose) {
            lightboxClose.addEventListener("click", closeLightbox);
        }

        if (lightboxBackdrop) {
            lightboxBackdrop.addEventListener("click", function (event) {
                if (event.target === lightboxBackdrop) {
                    closeLightbox();
                }
            });
        }

        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape" && lightbox.classList.contains("is-active")) {
                closeLightbox();
            }
        });
    }
});