document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    siteNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        siteNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieButtons = document.querySelectorAll('[data-cookie-consent]');

  if (cookieBanner) {
    const storedConsent = localStorage.getItem('financialwiseCookieConsent');
    if (storedConsent === 'accepted' || storedConsent === 'declined') {
      cookieBanner.classList.add('is-hidden');
    }

    cookieButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-cookie-consent');
        localStorage.setItem('financialwiseCookieConsent', choice);
        cookieBanner.classList.add('is-hidden');
      });
    });
  }
});