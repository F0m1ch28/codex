document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    function syncNavigation() {
        if (!siteNav) return;
        if (window.innerWidth >= 768) {
            siteNav.setAttribute("data-open", "true");
            if (navToggle) {
                navToggle.setAttribute("aria-expanded", "true");
            }
        } else {
            siteNav.setAttribute("data-open", "false");
            if (navToggle) {
                navToggle.setAttribute("aria-expanded", "false");
            }
        }
    }

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", function () {
            const isOpen = siteNav.getAttribute("data-open") === "true";
            siteNav.setAttribute("data-open", String(!isOpen));
            navToggle.setAttribute("aria-expanded", String(!isOpen));
        });

        window.addEventListener("resize", function () {
            window.requestAnimationFrame(syncNavigation);
        });

        syncNavigation();
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedConsent = localStorage.getItem("ljubljbhliCookieConsent");
        if (!storedConsent) {
            cookieBanner.classList.add("active");
        }

        cookieBanner.addEventListener("click", function (event) {
            const target = event.target;
            if (!(target instanceof HTMLElement)) return;

            if (target.dataset.action === "accept") {
                localStorage.setItem("ljubljbhliCookieConsent", "accepted");
                cookieBanner.classList.remove("active");
                cookieBanner.classList.add("hide");
                setTimeout(() => cookieBanner.remove(), 400);
            }

            if (target.dataset.action === "decline") {
                localStorage.setItem("ljubljbhliCookieConsent", "declined");
                cookieBanner.classList.remove("active");
                cookieBanner.classList.add("hide");
                setTimeout(() => cookieBanner.remove(), 400);
            }
        });
    }
});