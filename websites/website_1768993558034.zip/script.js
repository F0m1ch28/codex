document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".hamburger");
  const primaryNav = document.querySelector(".primary-nav");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      primaryNav.classList.toggle("active");
      navToggle.setAttribute("aria-expanded", primaryNav.classList.contains("active"));
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptButton = document.querySelector("[data-cookie-accept]");
  const declineButton = document.querySelector("[data-cookie-decline]");
  const cookieStorageKey = "csl_cookie_consent";

  if (cookieBanner) {
    const storedDecision = localStorage.getItem(cookieStorageKey);
    if (!storedDecision) {
      cookieBanner.classList.add("active");
    }
    const handleDecision = (value) => {
      localStorage.setItem(cookieStorageKey, value);
      cookieBanner.classList.remove("active");
    };
    if (acceptButton) {
      acceptButton.addEventListener("click", () => handleDecision("accepted"));
    }
    if (declineButton) {
      declineButton.addEventListener("click", () => handleDecision("declined"));
    }
  }

  const redirectMap = {
    "/history": "/case-studies.html",
    "/history/": "/case-studies.html",
    "/infrastructure": "/diagnostics.html",
    "/infrastructure/": "/diagnostics.html",
    "/systems": "/frameworks.html",
    "/systems/": "/frameworks.html",
    "/resilience": "/patterns.html",
    "/resilience/": "/patterns.html"
  };
  const currentPath = window.location.pathname.replace(/index\.html$/, "");
  if (redirectMap[currentPath]) {
    window.location.replace(redirectMap[currentPath]);
  }
});