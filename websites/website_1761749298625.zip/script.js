document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navList = document.querySelector(".nav-list");
  const navLinks = document.querySelectorAll(".nav-list a");
  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptCookieBtn = document.querySelector("[data-cookie-accept]");
  const declineCookieBtn = document.querySelector("[data-cookie-decline]");
  const contactForms = document.querySelectorAll("[data-contact-form]");
  const newsletterForm = document.querySelector("[data-newsletter-form]");
  const revealEls = document.querySelectorAll(".reveal");
  const filterButtons = document.querySelectorAll(".chip");
  const posts = document.querySelectorAll(".posts-grid .card");
  const faqItems = document.querySelectorAll("[data-faq]");
  const yearEl = document.querySelector("#current-year");

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  /* Mobile navigation */
  if (navToggle && navList) {
    navToggle.addEventListener("click", () => {
      const isOpen = navList.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    navLinks.forEach((link) =>
      link.addEventListener("click", () => {
        if (navList.classList.contains("nav-open")) {
          navList.classList.remove("nav-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      })
    );

    document.addEventListener("click", (e) => {
      if (!navList.contains(e.target) && !navToggle.contains(e.target)) {
        navList.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* Cookie banner */
  const COOKIE_KEY = "apex-cookie-consent";
  if (cookieBanner) {
    const consentValue = localStorage.getItem(COOKIE_KEY);
    if (!consentValue) {
      window.setTimeout(() => cookieBanner.classList.add("active"), 1200);
    }

    acceptCookieBtn?.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "accepted");
      cookieBanner.classList.remove("active");
    });

    declineCookieBtn?.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "declined");
      cookieBanner.classList.remove("active");
    });
  }

  /* Intersection observer for reveal animations */
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    revealEls.forEach((el) => observer.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add("visible"));
  }

  /* Contact form handler */
  contactForms.forEach((form) => {
    const feedback = form.querySelector(".form-feedback");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const name = formData.get("name") || "there";
      feedback.textContent = "Sending...";
      feedback.style.color = "var(--color-muted)";

      setTimeout(() => {
        feedback.textContent = `Thanks, ${name}! Our team will reach out shortly.`;
        feedback.style.color = "var(--color-success)";
        form.reset();
      }, 1200);
    });
  });

  /* Newsletter form */
  if (newsletterForm) {
    const feedback = document.querySelector(".newsletter-card .form-feedback");
    newsletterForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const emailInput = newsletterForm.querySelector("input[type='email']");
      const email = emailInput.value.trim();

      if (!email) {
        feedback.textContent = "Please provide a valid email address.";
        feedback.style.color = "rgba(255, 255, 255, 0.8)";
        return;
      }

      feedback.textContent = "Subscribing...";
      feedback.style.color = "rgba(255, 255, 255, 0.8)";
      setTimeout(() => {
        feedback.textContent = "Success! Please check your inbox to confirm.";
        feedback.style.color = "#c3f7d1";
        newsletterForm.reset();
      }, 1000);
    });
  }

  /* Blog filtering */
  if (filterButtons.length && posts.length) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const category = button.dataset.filter;

        filterButtons.forEach((btn) => btn.classList.remove("chip-active"));
        button.classList.add("chip-active");

        posts.forEach((post) => {
          if (category === "all" || post.dataset.category === category) {
            post.style.display = "";
            setTimeout(() => post.classList.add("visible"), 20);
          } else {
            post.style.display = "none";
          }
        });
      });
    });
  }

  /* FAQ accordion */
  faqItems.forEach((item) => {
    const question = item.querySelector(".faq-question");
    question.addEventListener("click", () => {
      const isActive = item.classList.contains("active");
      faqItems.forEach((i) => i.classList.remove("active"));
      if (!isActive) {
        item.classList.add("active");
      }
    });
  });
});