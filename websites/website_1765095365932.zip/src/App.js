import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import ContactsPage from './pages/Contact';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';
import styles from './App.module.css';

const App = () => (
  <div className={styles.appWrapper}>
    <Header />
    <main className={styles.mainContent}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/o-kompanii" element={<AboutPage />} />
        <Route path="/uslugi" element={<ServicesPage />} />
        <Route path="/kontakty" element={<ContactsPage />} />
        <Route path="/usloviya" element={<TermsPage />} />
        <Route
          path="/politika-konfidencialnosti"
          element={<PrivacyPage />}
        />
        <Route path="/politika-cookie" element={<CookiePolicyPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

export default App;