import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './Home.module.css';

const statsConfig = [
  { id: 1, label: 'Лет на рынке', value: 12, suffix: '+' },
  { id: 2, label: 'Реализованных проектов', value: 340, suffix: '+' },
  { id: 3, label: 'Экспертов в команде', value: 58, suffix: '' },
  { id: 4, label: 'Рост выручки клиентов', value: 48, suffix: '%' },
];

const coreServices = [
  {
    id: 1,
    title: 'Цифровая трансформация',
    description:
      'Проектируем цифровые экосистемы, внедряем продукты и создаем культуру данных во всей организации.',
    icon: '🚀',
    url: '/uslugi',
  },
  {
    id: 2,
    title: 'Стратегический консалтинг',
    description:
      'Анализируем рынок, формируем стратегию роста и управляем портфелем инициатив с прозрачными KPI.',
    icon: '📊',
    url: '/uslugi',
  },
  {
    id: 3,
    title: 'Операционная эффективность',
    description:
      'Оптимизируем процессы, внедряем гибкие методологии и строим системы непрерывных улучшений.',
    icon: '⚙️',
    url: '/uslugi',
  },
  {
    id: 4,
    title: 'Гибридные команды',
    description:
      'Собираем и развиваем кросс-функциональные команды, усиливая ваши компетенции под ключевой проект.',
    icon: '🤝',
    url: '/uslugi',
  },
];

const benefits = [
  {
    id: 1,
    title: 'Экспертиза в ключевых индустриях',
    description:
      'Работаем в сферах банков, ритейла, производственного и технологического бизнеса, говоря на одном языке с командами заказчика.',
  },
  {
    id: 2,
    title: 'Измеримый результат',
    description:
      'Каждый проект сопровождаем системой метрик, прозрачной отчетностью и регулярными сессиями обратной связи.',
  },
  {
    id: 3,
    title: 'Команда профессионалов',
    description:
      'Сертифицированные менеджеры проектов, бизнес-аналитики, product- и data-специалисты с опытом международных проектов.',
  },
  {
    id: 4,
    title: 'Скорость и гибкость',
    description:
      'Комбинируем стратегическое планирование и гибкие подходы, чтобы быстро адаптироваться к изменениям рынка.',
  },
  {
    id: 5,
    title: 'Партнерский подход',
    description:
      'Работаем как единая команда: вместе тестируем гипотезы, принимаем решения и масштабируем успешные практики.',
  },
];

const processSteps = [
  {
    id: 1,
    title: 'Диагностика и цель',
    description:
      'Проводим стратегические интервью, анализируем данные и формируем четкие критерии успеха проекта.',
  },
  {
    id: 2,
    title: 'Дизайн решения',
    description:
      'Прорабатываем дорожную карту, создаем прототипы и проводим совместные рабочие сессии с вашей командой.',
  },
  {
    id: 3,
    title: 'Внедрение и обучение',
    description:
      'Настраиваем процессы, обучаем сотрудников, запускаем пилоты и собираем обратную связь для оптимизации.',
  },
  {
    id: 4,
    title: 'Масштабирование и поддержка',
    description:
      'Сопровождаем масштабирование, мониторим метрики и обеспечиваем устойчивый эффект изменений.',
  },
];

const projects = [
  {
    id: 1,
    title: 'Цифровая платформа для B2B-продаж',
    category: 'Цифровая трансформация',
    description:
      'Создали единое окно для внутренних и внешних клиентов, обеспечив рост конверсии на 23%.',
    image: 'https://picsum.photos/1200/800?random=201',
  },
  {
    id: 2,
    title: 'Стратегия развития сети',
    category: 'Стратегия и рост',
    description:
      'Сформировали долгосрочную стратегию, внедрили систему OKR и запустили аналитический центр.',
    image: 'https://picsum.photos/1200/800?random=202',
  },
  {
    id: 3,
    title: 'Оптимизация логистики',
    category: 'Операционная эффективность',
    description:
      'Перестроили цепочку поставок, сократили операционные расходы на 17% за полгода.',
    image: 'https://picsum.photos/1200/800?random=203',
  },
  {
    id: 4,
    title: 'Data-платформа и BI',
    category: 'Цифровая трансформация',
    description:
      'Внедрили корпоративное хранилище данных и панели мониторинга для топ-менеджмента.',
    image: 'https://picsum.photos/1200/800?random=204',
  },
];

const testimonials = [
  {
    id: 1,
    name: 'Анна Мельникова',
    role: 'директор по развитию, Retail Group',
    quote:
      'Команда «Компании» помогла нам построить управляемую модель роста и выстроить аналитику. Мы видим результат в цифрах уже спустя три месяца.',
    avatar: 'https://picsum.photos/200/200?random=210',
  },
  {
    id: 2,
    name: 'Константин Рябцев',
    role: 'CEO, FinTech Solutions',
    quote:
      'Благодаря гибкому управлению проектом мы запустили новую платформу в рекордные сроки. Особенно ценим прозрачность и вовлеченность экспертов.',
    avatar: 'https://picsum.photos/200/200?random=211',
  },
  {
    id: 3,
    name: 'Ольга Владимировна',
    role: 'директор по операционной эффективности, Логистическая компания',
    quote:
      'Коллеги помогли нам переосмыслить процессы, внедрить автоматизацию и сформировать команду внутренних лидеров изменений.',
    avatar: 'https://picsum.photos/200/200?random=212',
  },
];

const teamMembers = [
  {
    id: 1,
    name: 'Дмитрий Соколов',
    role: 'Партнёр, руководитель практики Strategy & Growth',
    description:
      '15 лет в стратегическом консалтинге, управлял проектами в Европе и Азии, акцент на масштабирование бизнеса.',
    photo: 'https://picsum.photos/400/400?random=221',
  },
  {
    id: 2,
    name: 'Алена Погодина',
    role: 'Директор по цифровым продуктам',
    description:
      'Создает продуктовые команды, внедряет agile и развивает культуру экспериментов в крупных компаниях.',
    photo: 'https://picsum.photos/400/400?random=222',
  },
  {
    id: 3,
    name: 'Илья Громов',
    role: 'Руководитель центра аналитики',
    description:
      'Data strategist с опытом внедрения BI и AI-решений, соединяет бизнес-задачи и технологические возможности.',
    photo: 'https://picsum.photos/400/400?random=223',
  },
];

const faqItems = [
  {
    id: 1,
    question: 'Как начать проект и сколько времени занимает подготовка?',
    answer:
      'Обычно подготовка занимает 2–4 недели. Мы проводим серию интервью, анализируем текущую ситуацию и согласуем цели. После этого формируем дорожную карту и стартуем совместные воркшопы.',
  },
  {
    id: 2,
    question: 'Вы работаете только с крупным бизнесом?',
    answer:
      'Мы сотрудничаем как с крупными корпорациями, так и с быстрорастущими компаниями среднего сегмента. Важно наличие амбициозной задачи и готовность к трансформации процессов.',
  },
  {
    id: 3,
    question: 'Кто входит в проектную команду с вашей стороны?',
    answer:
      'Подбираем мультидисциплинарную команду: стратеги, аналитики, product-менеджеры, дизайнеры и эксперты по изменениям. При необходимости усиливаем команду отраслевыми специалистами.',
  },
  {
    id: 4,
    question: 'Как вы измеряете результат?',
    answer:
      'Еще на этапе диагностики формируем набор метрик, которые фиксируем в единой панели. Еженедельно сверяем ход работ, ежемесячно оцениваем эффект и корректируем план.',
  },
];

const blogPosts = [
  {
    id: 1,
    title: 'Как перестроить клиентский путь за 90 дней',
    description:
      'Разбираем практики, инструментарий и командную структуру для быстрой модернизации customer journey.',
    image: 'https://picsum.photos/800/600?random=231',
    link: '/o-kompanii',
  },
  {
    id: 2,
    title: '7 метрик эффективности для трансформации',
    description:
      'Какие показатели отслеживать, чтобы видеть реальную отдачу от программы изменений.',
    image: 'https://picsum.photos/800/600?random=232',
    link: '/uslugi',
  },
  {
    id: 3,
    title: 'Как построить культуру экспериментов',
    description:
      'Опыт наших команд: от освещения стратегии до внедрения фреймов для A/B-тестов и измерения гипотез.',
    image: 'https://picsum.photos/800/600?random=233',
    link: '/o-kompanii',
  },
];

const HomePage = () => {
  const [statValues, setStatValues] = useState(() =>
    statsConfig.map(() => 0)
  );
  const [activeCategory, setActiveCategory] = useState('Все');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeMember, setActiveMember] = useState(null);
  const categories = useMemo(
    () => ['Все', ...new Set(projects.map((item) => item.category))],
    []
  );

  useEffect(() => {
    const intervals = statsConfig.map((item, index) => {
      const step = Math.ceil(item.value / 40);
      return setInterval(() => {
        setStatValues((prev) => {
          const updated = [...prev];
          updated[index] = Math.min(item.value, updated[index] + step);
          return updated;
        });
      }, 30);
    });
    return () => intervals.forEach((id) => clearInterval(id));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Все') {
      return projects;
    }
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Meta
        title="Компания — стратегический партнер для роста бизнеса"
        description="Мы помогаем компаниям трансформировать процессы, запускать продукты и достигать стратегических целей. Экспертиза в цифровой трансформации, стратегии и операционной эффективности."
        keywords="бизнес консалтинг, цифровая трансформация, стратегия развития, управление изменениями, Компания"
        ogImage="https://picsum.photos/1200/630?random=305"
      />

      <section className={`${styles.hero} container`}>
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Партнерство для результата</span>
          <h1 className={styles.heroTitle}>
            Современные решения для ускорения роста вашего бизнеса
          </h1>
          <p className={styles.heroText}>
            Объединяем стратегию, технологии и экспертизу. Помогаем компаниям
            создавать новые продукты, оптимизировать процессы и формировать
            команды, готовые к переменам.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.heroPrimaryBtn}>
              Обсудить проект
            </Link>
            <Link to="/o-kompanii" className={styles.heroSecondaryBtn}>
              Узнать больше
            </Link>
          </div>
          <div className={styles.heroStats}>
            {statsConfig.slice(0, 2).map((item, index) => (
              <div key={item.id} className={styles.heroStat}>
                <span className={styles.heroStatNumber}>
                  {statValues[index]}
                  {item.suffix}
                </span>
                <span className={styles.heroStatLabel}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroMedia}>
          <div className={styles.heroImageWrapper}>
            <img
              src="https://picsum.photos/1600/900?random=301"
              alt="Команда компании обсуждает стратегию развития"
              className={styles.heroImage}
              loading="lazy"
            />
            <div className={styles.heroCard}>
              <span className={styles.heroCardTitle}>Совместные решения</span>
              <p className={styles.heroCardText}>
                Работаем в тесной связке с вашими командами, чтобы изменения
                закреплялись и давали устойчивый эффект.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.statsSection} container`}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>
            О компании в цифрах
          </h2>
          <p className={styles.sectionSubtitle}>
            Мы прошли сотни проектов и знаем, как превратить амбициозные цели в
            понятный план действий и результат в цифрах.
          </p>
        </div>
        <div className={styles.statsGrid}>
          {statsConfig.map((item, index) => (
            <article key={item.id} className={styles.statCard}>
              <span className={styles.statValue}>
                {statValues[index]}
                {item.suffix}
              </span>
              <span className={styles.statLabel}>{item.label}</span>
            </article>
          ))}
        </div>
        <div className={styles.aboutPreview}>
          <div className={styles.aboutText}>
            <h3>Стратегия, технологии и люди на одной волне</h3>
            <p>
              Команда «Компании» объединяет стратегов, аналитиков, product- и
              data-экспертов. Вместе с вами мы строим устойчивые системы развития
              бизнеса и доводим изменения до результата.
            </p>
            <Link to="/o-kompanii" className={styles.inlineLink}>
              Подробнее о нас →
            </Link>
          </div>
          <img
            src="https://picsum.photos/800/600?random=302"
            alt="Команда Компании во время стратегической сессии"
            className={styles.aboutImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${styles.servicesSection} container`}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Наши ключевые направления</h2>
          <p className={styles.sectionSubtitle}>
            Трансформируем бизнес, выстраиваем стратегию и формируем команды,
            которые поддерживают изменения.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {coreServices.map((service) => (
            <article key={service.id} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {service.icon}
              </span>
              <h3 className={styles.serviceTitle}>{service.title}</h3>
              <p className={styles.serviceDescription}>{service.description}</p>
              <Link to={service.url} className={styles.serviceLink}>
                Узнать подробнее
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.benefitsSection} container`}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Почему выбирают нас</h2>
          <p className={styles.sectionSubtitle}>
            Мы вникаем в задачи бизнеса и строим долгосрочные партнерские
            отношения, фокусируясь на измеримом эффекте.
          </p>
        </div>
        <div className={styles.benefitsGrid}>
          {benefits.map((benefit, index) => (
            <article key={benefit.id} className={styles.benefitCard}>
              <span className={styles.benefitNumber}>
                {(index + 1).toString().padStart(2, '0')}
              </span>
              <div className={styles.benefitContent}>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.processProjectsSection} container`}>
        <div className={styles.process}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Как мы работаем</h2>
            <p className={styles.sectionSubtitle}>
              Погружаемся в контекст, строим стратегию, внедряем изменения и
              закрепляем результат вместе с вашей командой.
            </p>
          </div>
          <ol className={styles.processList}>
            {processSteps.map((step) => (
              <li key={step.id} className={styles.processItem}>
                <div className={styles.processBadge}>{step.id}</div>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div className={styles.projects}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Недавние проекты</h2>
            <p className={styles.sectionSubtitle}>
              От цифровых платформ до перестройки операционных процессов —
              создаем решения, которые помогают бизнесу масштабироваться.
            </p>
          </div>
          <div className={styles.projectsFilter}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={project.title}
                  className={styles.projectImage}
                  loading="lazy"
                />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>
                    {project.category}
                  </span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonialsSection} container`}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Что говорят клиенты</h2>
          <p className={styles.sectionSubtitle}>
            Работая с нами, команды клиентов получают прозрачность, поддержку и
            надежного партнера на всех этапах изменений.
          </p>
        </div>
        <div className={styles.testimonialWrapper}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.id}
              className={`${styles.testimonialCard} ${
                index === currentTestimonial ? styles.testimonialActive : ''
              }`}
            >
              <div className={styles.testimonialAvatar}>
                <img
                  src={testimonial.avatar}
                  alt={`Фото клиента — ${testimonial.name}`}
                  loading="lazy"
                />
              </div>
              <blockquote className={styles.testimonialQuote}>
                “{testimonial.quote}”
              </blockquote>
              <div className={styles.testimonialAuthor}>
                <span>{testimonial.name}</span>
                <span className={styles.testimonialRole}>
                  {testimonial.role}
                </span>
              </div>
            </article>
          ))}
        </div>
        <div className={styles.testimonialControls}>
          <button
            type="button"
            aria-label="Предыдущий отзыв"
            onClick={() =>
              setCurrentTestimonial((prev) =>
                prev === 0 ? testimonials.length - 1 : prev - 1
              )
            }
          >
            ←
          </button>
          <button
            type="button"
            aria-label="Следующий отзыв"
            onClick={() =>
              setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
            }
          >
            →
          </button>
        </div>
      </section>

      <section className={`${styles.teamSection} container`}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Команда лидеров изменений</h2>
          <p className={styles.sectionSubtitle}>
            Каждый эксперт берет на себя ответственность за результат, а мы
            сохраняем партнёрский подход на всех этапах работы.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article
              key={member.id}
              className={`${styles.teamCard} ${
                activeMember === member.id ? styles.teamCardActive : ''
              }`}
              onMouseEnter={() => setActiveMember(member.id)}
              onMouseLeave={() => setActiveMember(null)}
              onFocus={() => setActiveMember(member.id)}
              onBlur={() => setActiveMember(null)}
              tabIndex={0}
            >
              <img
                src={member.photo}
                alt={member.name}
                className={styles.teamPhoto}
                loading="lazy"
              />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span className={styles.teamRole}>{member.role}</span>
                <p>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.faqBlogSection} container`}>
        <div className={styles.faq}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Частые вопросы</h2>
            <p className={styles.sectionSubtitle}>
              Если не нашли ответ, напишите нам — мы с радостью обсудим вашу
              задачу и предложим формат взаимодействия.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item) => (
              <details
                key={item.id}
                className={styles.faqItem}
                open={item.id === 1}
              >
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>

        <div className={styles.blog}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Идеи и практики</h2>
            <p className={styles.sectionSubtitle}>
              Делимся реальными кейсами и инструментами, которые помогаю нашим
              клиентам расти быстрее.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img
                  src={post.image}
                  alt={post.title}
                  className={styles.blogImage}
                  loading="lazy"
                />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.description}</p>
                  <Link to={post.link} className={styles.blogLink}>
                    Читать →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} container`}>
        <div className={styles.ctaContent}>
          <h2>Готовы обсудить новые возможности?</h2>
          <p>
            Давайте обсудим, как мы можем ускорить развитие вашей компании.
            Напишите нам — и уже в ближайшие дни мы подготовим предложение.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/kontakty" className={styles.ctaPrimary}>
              Связаться с нами
            </Link>
            <Link to="/uslugi" className={styles.ctaSecondary}>
              Каталог услуг
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;