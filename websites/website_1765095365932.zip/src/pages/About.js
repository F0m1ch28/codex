import React from 'react';
import Meta from '../components/Meta';
import styles from './About.module.css';

const values = [
  {
    id: 1,
    title: 'Ориентация на результат',
    description:
      'Фокусируемся на измеримых эффектах: рост выручки, эффективность процессов, удовлетворенность клиентов.',
  },
  {
    id: 2,
    title: 'Партнерство и доверие',
    description:
      'Работаем как единая команда с клиентами, выстраиваем отношения на прозрачности и уважении.',
  },
  {
    id: 3,
    title: 'Командная экспертиза',
    description:
      'Объединяем стратегов, аналитиков, продуктовых и технологических экспертов для комплексных решений.',
  },
  {
    id: 4,
    title: 'Смелые идеи, проверенные практикой',
    description:
      'Концентрируемся на гипотезах, быстрых экспериментах и масштабировании успешных решений.',
  },
];

const milestones = [
  {
    year: '2012',
    title: 'Основание компании',
    description:
      'Собрали ядро команды консультантов, которые специализируются на стратегии и трансформации бизнеса.',
  },
  {
    year: '2016',
    title: 'Центр цифровых решений',
    description:
      'Запустили направление разработки цифровых продуктов, сформировали экспертизу по agile и data.',
  },
  {
    year: '2019',
    title: 'Международные проекты',
    description:
      'Вышли на международный рынок, реализовав комплексные программы трансформации в Европе.',
  },
  {
    year: '2022',
    title: 'Экосистема услуг',
    description:
      'Объединили консалтинг, продуктовую разработку и обучение в единую экосистему сервисов.',
  },
];

const leadership = [
  {
    id: 1,
    name: 'Ольга Сорокина',
    role: 'Генеральный директор',
    description:
      '10+ лет управляет комплексными трансформациями в финансовом и телеком-сегментах. Проводит стратегические сессии для топ-менеджмента.',
    image: 'https://picsum.photos/800/600?random=321',
  },
  {
    id: 2,
    name: 'Иван Тимофеев',
    role: 'Операционный директор',
    description:
      'Отвечает за операционные процессы, внедрение lean-практик и масштабирование продуктовых команд.',
    image: 'https://picsum.photos/800/600?random=322',
  },
];

const AboutPage = () => (
  <>
    <Meta
      title="О компании — эксперты по трансформации бизнеса"
      description="Компания — команда стратегов, аналитиков и продуктовых экспертов. Мы создаем устойчивые изменения, строим цифровые решения и раскрываем потенциал команд."
      keywords="о компании, команда экспертов, трансформация бизнеса, консультанты, лидерство"
      ogImage="https://picsum.photos/1200/630?random=401"
    />

    <section className={`${styles.intro} container`}>
      <div className={styles.text}>
        <span className={styles.badge}>О нас</span>
        <h1>Мы создаем изменения, которые приносят результат</h1>
        <p>
          «Компания» — стратегический партнер для бизнеса. Мы помогаем
          организациям проектировать цифровые продукты, перестраивать процессы и
          развивать команды, которые готовы к новым вызовам. Наша миссия —
          превращать амбициозные цели в реальные достижения.
        </p>
      </div>
      <img
        src="https://picsum.photos/1000/700?random=323"
        alt="Команда Компании работает над проектом"
        className={styles.image}
        loading="lazy"
      />
    </section>

    <section className={`${styles.values} container`}>
      <div className={styles.sectionHeader}>
        <h2>Наши ценности</h2>
        <p>
          Все проекты строятся вокруг доверия, ответственности и стремления к
          развитию — эти принципы определяют решения в ежедневной работе.
        </p>
      </div>
      <div className={styles.valuesGrid}>
        {values.map((value) => (
          <article key={value.id} className={styles.valueCard}>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.milestones} container`}>
      <div className={styles.sectionHeader}>
        <h2>Ключевые этапы развития</h2>
        <p>
          Мы росли вместе с нашими клиентами, расширяя экспертизу и развивая
          новые направления, чтобы поддерживать компании на всех этапах
          трансформации.
        </p>
      </div>
      <div className={styles.timeline}>
        {milestones.map((milestone) => (
          <article key={milestone.year} className={styles.timelineItem}>
            <div className={styles.year}>{milestone.year}</div>
            <div className={styles.timelineContent}>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.leadership} container`}>
      <div className={styles.sectionHeader}>
        <h2>Лидеры компании</h2>
        <p>
          Руководящая команда «Компании» — это эксперты, которые соединяют
          стратегию, технологии и человеческий капитал.
        </p>
      </div>
      <div className={styles.leadershipGrid}>
        {leadership.map((leader) => (
          <article key={leader.id} className={styles.leaderCard}>
            <img
              src={leader.image}
              alt={leader.name}
              className={styles.leaderImage}
              loading="lazy"
            />
            <div className={styles.leaderInfo}>
              <h3>{leader.name}</h3>
              <span className={styles.leaderRole}>{leader.role}</span>
              <p>{leader.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.approach} container`}>
      <div className={styles.sectionHeader}>
        <h2>Наш подход к проектам</h2>
        <p>
          Каждое партнерство строится на глубоком понимании контекста и
          совместном управлении изменениями. Мы создаем устойчивые трансформации,
          основанные на данных и вовлеченности команд.
        </p>
      </div>
      <div className={styles.approachGrid}>
        <article className={styles.approachCard}>
          <h3>Погружение в бизнес</h3>
          <p>
            Анализируем стратегию, операционные процессы и культуру, чтобы
            сформировать целостную картину и выбрать точку приложения усилий.
          </p>
        </article>
        <article className={styles.approachCard}>
          <h3>Работа с командами</h3>
          <p>
            Формируем общую картину, проводим воркшопы, обучаем и поддерживаем
            внутренние команды в принятии решений и развитии навыков.
          </p>
        </article>
        <article className={styles.approachCard}>
          <h3>Фокус на результатах</h3>
          <p>
            Фиксируем цели и ключевые метрики, строим систему регулярной
            отчетности и управляем рисками, чтобы обеспечить устойчивый эффект.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default AboutPage;