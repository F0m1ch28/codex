import React, { useState } from 'react';
import Meta from '../components/Meta';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  company: '',
  message: '',
};

const ContactsPage = () => {
  const [formState, setFormState] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const validationErrors = {};
    if (!formState.name.trim()) {
      validationErrors.name = 'Укажите ваше имя';
    }
    if (!formState.email.trim()) {
      validationErrors.email = 'Введите email';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(formState.email)) {
      validationErrors.email = 'Введите корректный email';
    }
    if (formState.phone && formState.phone.length < 6) {
      validationErrors.phone = 'Введите корректный телефон';
    }
    if (!formState.message.trim()) {
      validationErrors.message = 'Расскажите о задаче';
    }
    return validationErrors;
  };

  const handleChange = (field) => (event) => {
    setFormState((prev) => ({ ...prev, [field]: event.target.value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setIsSubmitted(true);
    setFormState(initialFormState);
  };

  return (
    <>
      <Meta
        title="Контакты — свяжитесь с командой «Компании»"
        description="Оставьте заявку и команда «Компании» свяжется с вами в течение одного рабочего дня. Обсудим вашу задачу и предложим оптимальное решение."
        keywords="контакты, обратная связь, консультация, связаться, Компания"
        ogImage="https://picsum.photos/1200/630?random=403"
      />

      <section className={`${styles.contactSection} container`}>
        <div className={styles.intro}>
          <span className={styles.badge}>Контакты</span>
          <h1>Давайте обсудим вашу задачу</h1>
          <p>
            Оставьте контактные данные и коротко опишите запрос. Мы свяжемся с
            вами в течение одного рабочего дня и предложим формат сотрудничества.
          </p>
          <div className={styles.contactInfo}>
            <div>
              <h2>Адрес</h2>
              <p>Адрес: [Адрес компании будет указан позже]</p>
            </div>
            <div>
              <h2>Телефон</h2>
              <p>Телефон: [Телефон компании будет указан позже]</p>
            </div>
            <div>
              <h2>Email</h2>
              <p>Email: [Email компании будет указан позже]</p>
            </div>
          </div>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Заявка на консультацию</h2>
          <div className={styles.fieldGroup}>
            <label htmlFor="name">Ваше имя*</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Ирина Смирнова"
              value={formState.name}
              onChange={handleChange('name')}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && (
              <span className={styles.error} id="name-error">
                {errors.name}
              </span>
            )}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="email">Email*</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@company.ru"
              value={formState.email}
              onChange={handleChange('email')}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && (
              <span className={styles.error} id="email-error">
                {errors.email}
              </span>
            )}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="phone">Телефон</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              placeholder="+7 (___) ___-__-__"
              value={formState.phone}
              onChange={handleChange('phone')}
              aria-invalid={Boolean(errors.phone)}
              aria-describedby={errors.phone ? 'phone-error' : undefined}
            />
            {errors.phone && (
              <span className={styles.error} id="phone-error">
                {errors.phone}
              </span>
            )}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="company">Компания</label>
            <input
              id="company"
              name="company"
              type="text"
              placeholder="Название вашей компании"
              value={formState.company}
              onChange={handleChange('company')}
            />
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="message">Задача*</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Опишите кратко ваш проект, текущий вызов или желаемый результат"
              value={formState.message}
              onChange={handleChange('message')}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && (
              <span className={styles.error} id="message-error">
                {errors.message}
              </span>
            )}
          </div>

          <p className={styles.notice}>
            Нажимая «Отправить», вы согласны с{' '}
            <a href="/politika-konfidencialnosti">политикой конфиденциальности</a>.
          </p>

          <button type="submit" className={styles.submit}>
            Отправить заявку
          </button>
          {isSubmitted && (
            <div className={styles.success} role="status">
              Спасибо! Мы получили вашу заявку и свяжемся с вами в ближайшее время.
            </div>
          )}
        </form>
      </section>
    </>
  );
};

export default ContactsPage;