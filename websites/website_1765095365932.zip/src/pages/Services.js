import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './Services.module.css';

const services = [
  {
    id: 'strategy',
    title: 'Strategy & Growth',
    description:
      'Создаем стратегию роста, управляем портфелем инициатив, выстраиваем систему целей и метрик.',
    benefits: [
      'Диагностика бизнеса и моделирование сценариев',
      'Разработка стратегии на 3–5 лет и карта инициатив',
      'Внедрение системы OKR и управление изменениями',
      'Сопровождение реализации и коучинг лидеров',
    ],
    image: 'https://picsum.photos/900/600?random=341',
  },
  {
    id: 'digital',
    title: 'Digital Transformation',
    description:
      'Проектируем цифровые продукты и платформы, внедряем современные технологии и культуру данных.',
    benefits: [
      'Продуктовая стратегия и дизайн UX',
      'Сбор и анализ требований, customer journey',
      'Внедрение agile-процессов и DevOps практик',
      'Создание data-платформ и BI-решений',
    ],
    image: 'https://picsum.photos/900/600?random=342',
  },
  {
    id: 'operations',
    title: 'Operational Excellence',
    description:
      'Оптимизируем процессы, сокращаем затраты и повышаем эффективность команд на всех уровнях.',
    benefits: [
      'Анализ процессов и узких мест',
      'Внедрение lean, kanban и system thinking',
      'Цифровизация операционной деятельности',
      'Создание центра непрерывных улучшений',
    ],
    image: 'https://picsum.photos/900/600?random=343',
  },
  {
    id: 'people',
    title: 'People & Culture',
    description:
      'Развиваем лидерство, создаем культуру экспериментов и поддерживаем команду в период изменений.',
    benefits: [
      'Диагностика корпоративной культуры',
      'Программы развития лидеров и экспертов',
      'Коммуникация изменений и вовлеченность',
      'Наставничество и корпоративные академии',
    ],
    image: 'https://picsum.photos/900/600?random=344',
  },
];

const accelerators = [
  {
    id: 1,
    title: 'Product Discovery Sprint',
    description:
      'Пяти-недельный интенсив, на котором формируем видение продукта, создаем прототип и план внедрения.',
  },
  {
    id: 2,
    title: 'Data Strategy Lab',
    description:
      'Работаем с данными: определяем источники, выстраиваем governance и запускаем первые дашборды.',
  },
  {
    id: 3,
    title: 'CX Transformation',
    description:
      'Оптимизируем опыт клиентов: исследуем journey, внедряем дизайн-систему и метрики удовлетворенности.',
  },
];

const ServicesPage = () => {
  const [activeService, setActiveService] = useState(services[0]);

  return (
    <>
      <Meta
        title="Услуги — стратегия, цифровая трансформация и операционная эффективность"
        description="Компания предлагает комплексные услуги: разработка стратегии, цифровая трансформация, оптимизация процессов и развитие команд. Узнайте, как мы помогаем бизнесу расти."
        keywords="услуги, стратегия, цифровая трансформация, операционная эффективность, развитие команд, консалтинг"
        ogImage="https://picsum.photos/1200/630?random=402"
      />

      <section className={`${styles.intro} container`}>
        <div className={styles.text}>
          <span className={styles.badge}>Наши услуги</span>
          <h1>Комплексная поддержка бизнеса на каждом этапе развития</h1>
          <p>
            Мы объединяем стратегию, технологии и людей, чтобы реализовать
            трансформацию с измеримым эффектом. Выберите направление, которое
            поможет вашему бизнесу сделать следующий шаг.
          </p>
        </div>
      </section>

      <section className={`${styles.services} container`}>
        <div className={styles.tabs} role="tablist">
          {services.map((service) => (
            <button
              key={service.id}
              type="button"
              role="tab"
              aria-selected={activeService.id === service.id}
              className={`${styles.tab} ${
                activeService.id === service.id ? styles.tabActive : ''
              }`}
              onClick={() => setActiveService(service)}
            >
              {service.title}
            </button>
          ))}
        </div>

        <div className={styles.serviceCard} role="tabpanel">
          <div className={styles.serviceContent}>
            <h2>{activeService.title}</h2>
            <p>{activeService.description}</p>
            <ul className={styles.benefitsList}>
              {activeService.benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
            <Link to="/kontakty" className={styles.cta}>
              Обсудить задачу
            </Link>
          </div>
          <img
            src={activeService.image}
            alt={activeService.title}
            className={styles.serviceImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${styles.accelerators} container`}>
        <div className={styles.sectionHeader}>
          <h2>Экспресс-программы и акселераторы</h2>
          <p>
            Для компаний, которые хотят быстро протестировать гипотезы или
            запустить изменения, мы подготовили готовые форматы работы.
          </p>
        </div>
        <div className={styles.acceleratorGrid}>
          {accelerators.map((item) => (
            <article key={item.id} className={styles.acceleratorCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.ctaSection} container`}>
        <div className={styles.ctaContent}>
          <h2>Не нашли подходящий формат?</h2>
          <p>
            Расскажите о своей задаче — мы соберем индивидуальную команду и
            предложим решение в течение 5 рабочих дней.
          </p>
          <Link to="/kontakty" className={styles.ctaButton}>
            Оставить заявку
          </Link>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;