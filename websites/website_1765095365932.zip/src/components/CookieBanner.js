import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const LOCAL_STORAGE_KEY = 'company-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(LOCAL_STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem(LOCAL_STORAGE_KEY, 'declined');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <section className={styles.banner} aria-live="polite">
      <div className={styles.content}>
        <h2 className={styles.title}>Мы используем файлы Cookie</h2>
        <p className={styles.text}>
          Cookie помогают нам анализировать работу сайта и адаптировать его под
          ваши задачи. Продолжая пользоваться сайтом, вы соглашаетесь с
          использованием файлов Cookie. Подробнее читайте в{' '}
          <a className={styles.link} href="/politika-cookie">
            политике Cookie
          </a>
          .
        </p>
      </div>
      <div className={styles.actions}>
        <button
          type="button"
          className={styles.primaryBtn}
          onClick={acceptCookies}
        >
          Принять
        </button>
        <button
          type="button"
          className={styles.secondaryBtn}
          onClick={declineCookies}
        >
          Отклонить
        </button>
      </div>
    </section>
  );
};

export default CookieBanner;