import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Подвал сайта">
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.branding}>
          <span className={styles.logo}>Компания</span>
          <p className={styles.tagline}>
            Создаем стратегии, технологии и команды, которые раскрывают потенциал бизнеса.
          </p>
          <div className={styles.copy}>
            © {new Date().getFullYear()} Компания. Все права защищены.
          </div>
        </div>

        <div className={styles.column}>
          <h3 className={styles.heading}>Навигация</h3>
          <ul className={styles.links}>
            <li>
              <NavLink to="/" className={styles.link}>
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink to="/o-kompanii" className={styles.link}>
                О компании
              </NavLink>
            </li>
            <li>
              <NavLink to="/uslugi" className={styles.link}>
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink to="/kontakty" className={styles.link}>
                Контакты
              </NavLink>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.heading}>Правовая информация</h3>
          <ul className={styles.links}>
            <li>
              <NavLink to="/usloviya" className={styles.link}>
                Условия использования
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/politika-konfidencialnosti"
                className={styles.link}
              >
                Политика конфиденциальности
              </NavLink>
            </li>
            <li>
              <NavLink to="/politika-cookie" className={styles.link}>
                Политика Cookie
              </NavLink>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.heading}>Контакты</h3>
          <ul className={styles.contacts}>
            <li>Адрес: [Адрес компании будет указан позже]</li>
            <li>Телефон: [Телефон компании будет указан позже]</li>
            <li>Email: [Email компании будет указан позже]</li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;