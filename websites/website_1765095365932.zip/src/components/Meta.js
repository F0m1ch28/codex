import { useEffect } from 'react';

const ensureMetaTag = (selector, attributes) => {
  let tag = document.querySelector(selector);
  if (!tag) {
    tag = document.createElement('meta');
    Object.entries(attributes).forEach(([key, value]) => {
      if (key !== 'content') {
        tag.setAttribute(key, value);
      }
    });
    document.head.appendChild(tag);
  }
  return tag;
};

const Meta = ({ title, description, keywords, ogImage }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
      const ogTitle = ensureMetaTag('meta[property="og:title"]', {
        property: 'og:title',
      });
      ogTitle.setAttribute('content', title);
      const twitterTitle = ensureMetaTag('meta[name="twitter:title"]', {
        name: 'twitter:title',
      });
      twitterTitle.setAttribute('content', title);
    }

    if (description) {
      const descriptionTag = ensureMetaTag('meta[name="description"]', {
        name: 'description',
      });
      descriptionTag.setAttribute('content', description);

      const ogDescription = ensureMetaTag('meta[property="og:description"]', {
        property: 'og:description',
      });
      ogDescription.setAttribute('content', description);

      const twitterDescription = ensureMetaTag(
        'meta[name="twitter:description"]',
        { name: 'twitter:description' }
      );
      twitterDescription.setAttribute('content', description);
    }

    if (keywords) {
      const keywordsTag = ensureMetaTag('meta[name="keywords"]', {
        name: 'keywords',
      });
      keywordsTag.setAttribute('content', keywords);
    }

    if (ogImage) {
      const ogImageTag = ensureMetaTag('meta[property="og:image"]', {
        property: 'og:image',
      });
      ogImageTag.setAttribute('content', ogImage);

      const twitterImageTag = ensureMetaTag('meta[name="twitter:image"]', {
        name: 'twitter:image',
      });
      twitterImageTag.setAttribute('content', ogImage);
    }
  }, [title, description, keywords, ogImage]);

  return null;
};

export default Meta;