import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!isMenuOpen) return undefined;
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') {
        setIsMenuOpen(false);
      }
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown, closeOnEscape');
  }, [isMenuOpen]);

  const handleLinkClick = () => setIsMenuOpen(false);

  const navClass = ({ isActive }) =>
    `${styles.navLink} ${isActive ? styles.activeLink : ''}`;

  return (
    <header
      className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`}
    >
      <div className="container">
        <div className={styles.inner}>
          <NavLink
            to="/"
            className={styles.brand}
            onClick={handleLinkClick}
            aria-label="На главную страницу компании"
          >
            <span className={styles.logo}>Компания</span>
          </NavLink>

          <button
            type="button"
            className={styles.menuToggle}
            onClick={toggleMenu}
            aria-expanded={isMenuOpen}
            aria-controls="primary-navigation"
            aria-label="Переключить меню"
          >
            <span className={styles.menuIcon} />
          </button>

          <nav
            id="primary-navigation"
            className={`${styles.navigation} ${
              isMenuOpen ? styles.navigationOpen : ''
            }`}
          >
            <ul className={styles.navList}>
              <li>
                <NavLink to="/" className={navClass} onClick={handleLinkClick}>
                  Главная
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/o-kompanii"
                  className={navClass}
                  onClick={handleLinkClick}
                >
                  О компании
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/uslugi"
                  className={navClass}
                  onClick={handleLinkClick}
                >
                  Услуги
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/kontakty"
                  className={navClass}
                  onClick={handleLinkClick}
                >
                  Контакты
                </NavLink>
              </li>
            </ul>
            <NavLink
              to="/kontakty"
              className={styles.navCta}
              onClick={handleLinkClick}
            >
              Связаться
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;