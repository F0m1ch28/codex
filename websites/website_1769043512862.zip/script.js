document.addEventListener("DOMContentLoaded", () => {
  const header = document.querySelector(".site-header");
  const navToggle = document.querySelector(".nav-toggle");
  if (navToggle && header) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      header.classList.toggle("nav-open", !expanded);
    });
  }

  document.querySelectorAll(".site-nav a").forEach(link => {
    link.addEventListener("click", () => {
      if (header && header.classList.contains("nav-open")) {
        header.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  const yearTargets = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearTargets.forEach(el => {
    el.textContent = String(currentYear);
  });

  const banner = document.getElementById("cookie-banner");
  if (banner) {
    const choice = localStorage.getItem("crbt_cookie_choice");
    if (!choice) {
      banner.classList.add("visible");
    }
    banner.addEventListener("click", event => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const action = target.getAttribute("data-cookie");
      if (!action) return;
      localStorage.setItem("crbt_cookie_choice", action);
      banner.classList.remove("visible");
      setTimeout(() => {
        if (banner.parentElement) {
          banner.parentElement.removeChild(banner);
        }
      }, 500);
    });
  }

  const toast = document.getElementById("form-toast");
  const forms = document.querySelectorAll("form[data-redirect='true']");
  forms.forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      if (toast) {
        const message = form.getAttribute("data-success") || "Submitted successfully.";
        toast.textContent = message;
        toast.classList.add("visible");
      }
      const action = form.getAttribute("action") || "thank-you.html";
      setTimeout(() => {
        if (toast) {
          toast.classList.remove("visible");
        }
        window.location.href = action;
      }, 1700);
    });
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  document.querySelectorAll(".reveal-item").forEach(item => {
    observer.observe(item);
  });
});