(function () {
    const banner = document.getElementById("cookieBanner");
    if (!banner) return;
    const acceptBtn = document.getElementById("cookieAccept");
    const declineBtn = document.getElementById("cookieDecline");
    const preference = localStorage.getItem("packeddiqk-cookie-preference");

    if (!preference) {
        banner.classList.add("active");
    }

    function setPreference(value) {
        localStorage.setItem("packeddiqk-cookie-preference", value);
        banner.classList.remove("active");
    }

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => setPreference("accepted"));
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => setPreference("declined"));
    }
})();