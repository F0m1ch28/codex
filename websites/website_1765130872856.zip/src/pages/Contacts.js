import React, { useState } from 'react';
import styles from './Contacts.module.css';
import PageHelmet from '../components/PageHelmet';

const ContactsPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    city: 'Варшава',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const validationErrors = {};
    if (!formData.name.trim()) validationErrors.name = "Вкажіть ваше ім'я.";
    if (!formData.phone.trim()) {
      validationErrors.phone = 'Телефон обов’язковий для зворотного зв’язку.';
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      validationErrors.email = 'Вкажіть коректну адресу електронної пошти.';
    }
    if (!formData.message.trim()) {
      validationErrors.message = 'Опишіть ваш запит або ціль тренувань.';
    }
    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSent(true);
    setFormData({
      name: '',
      phone: '',
      email: '',
      city: 'Варшава',
      message: ''
    });
  };

  return (
    <div className={styles.page}>
      <PageHelmet
        title="Контакти — Професійне дресирування собак"
        description="Зв’яжіться з командою кінологів у Варшаві та Кракові. Адреси локацій, телефон, email і форма зворотного зв’язку."
      />
      <section className={styles.hero}>
        <h1>Контакти та розклад запису</h1>
        <p>
          Працюємо з понеділка по суботу, організовуємо інтенсиви у вихідні. Залиште звернення —
          підберемо дату першої зустрічі.
        </p>
      </section>

      <section className={styles.info}>
        <div className={styles.card}>
          <h2>Офіси</h2>
          <ul>
            <li>
              <strong>Варшава:</strong> вул. Собача, 15
            </li>
            <li>
              <strong>Краків:</strong> вул. Пастівська, 8
            </li>
          </ul>
        </div>
        <div className={styles.card}>
          <h2>Контакти</h2>
          <p>
            Телефон:{' '}
            <a href="tel:+48123456789">+48 123 456 789</a>
          </p>
          <p>
            Email:{' '}
            <a href="mailto:info@dogs-training.pl">info@dogs-training.pl</a>
          </p>
          <p>Ми відповідаємо протягом одного робочого дня.</p>
        </div>
        <div className={styles.card}>
          <h2>Години</h2>
          <p>Пн–Пт: 08:00 – 20:00</p>
          <p>Сб: 09:00 – 16:00</p>
          <p>Нд: за попереднім записом (семінари, збори)</p>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className={styles.formIntro}>
          <h2>Запишіться на консультацію</h2>
          <p>
            Розкажіть про вашого вихованця, мету тренувань та очікування. Ми підготуємо індивідуальну
            пропозицію для Варшави або Кракова.
          </p>
        </div>
        <form onSubmit={handleSubmit} className={styles.form} noValidate>
          <div className={styles.field}>
            <label htmlFor="contact-name">Ім’я</label>
            <input
              id="contact-name"
              name="name"
              type="text"
              placeholder="Ваше ім’я"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={!!errors.name}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-phone">Телефон</label>
            <input
              id="contact-phone"
              name="phone"
              type="tel"
              placeholder="+48 ..."
              value={formData.phone}
              onChange={handleChange}
              aria-invalid={!!errors.phone}
            />
            {errors.phone && <span className={styles.error}>{errors.phone}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-email">Email</label>
            <input
              id="contact-email"
              name="email"
              type="email"
              placeholder="info@example.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={!!errors.email}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-city">Місто</label>
            <select
              id="contact-city"
              name="city"
              value={formData.city}
              onChange={handleChange}
            >
              <option value="Варшава">Варшава</option>
              <option value="Краків">Краків</option>
            </select>
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-message">Повідомлення</label>
            <textarea
              id="contact-message"
              name="message"
              rows="5"
              placeholder="Опишіть вік собаки, попередній досвід та мету тренувань."
              value={formData.message}
              onChange={handleChange}
              aria-invalid={!!errors.message}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit">Надіслати</button>
          {sent && (
            <div className={styles.success} role="status">
              Дякуємо! Ми зв’яжемося з вами найближчим часом.
            </div>
          )}
        </form>
      </section>

      <section className={styles.mapSection}>
        <div className={styles.mapCard}>
          <h2>Як нас знайти</h2>
          <p>Мапа Варшава</p>
          <iframe
            title="Офіс Варшава"
            src="https://maps.google.com/maps?q=Warsaw&t=&z=13&ie=UTF8&iwloc=&output=embed"
            loading="lazy"
          />
        </div>
        <div className={styles.mapCard}>
          <h2>Тренувальна локація</h2>
          <p>Мапа Краків</p>
          <iframe
            title="Офіс Краків"
            src="https://maps.google.com/maps?q=Krakow&t=&z=13&ie=UTF8&iwloc=&output=embed"
            loading="lazy"
          />
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;