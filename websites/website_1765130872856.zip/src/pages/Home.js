import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import PageHelmet from '../components/PageHelmet';

const statsData = [
  { label: 'Років у кінології', value: 12 },
  { label: 'Випускників ОКД', value: 340 },
  { label: 'Робочих пар «кінолог-собака»', value: 85 },
  { label: 'Подовжень контрактів', value: 94 }
];

const advantages = [
  {
    title: 'Спеціалізація на вівчарках',
    text: 'Працюємо з лініями робочих та шоу-класу, добираючи методики під характер кожної німецької вівчарки.'
  },
  {
    title: 'Міжнародні сертифікації',
    text: 'Наші тренери проходять щорічні стажування у провідних школах Німеччини та Чехії.'
  },
  {
    title: 'Комплексний супровід',
    text: 'Від соціалізації цуценяти до захищено-караульної служби й підготовки до чемпіонатів.'
  }
];

const servicesData = [
  {
    title: 'ОКД та ІПО під ключ',
    description:
      'Готуємо собак до базових та міжнародних випробувань. Формуємо чітку послідовність дій, контроль емоцій та витримку.',
    link: '/posluhy'
  },
  {
    title: 'Корекція поведінки',
    description:
      'Опрацьовуємо реактивність, агресію, страхи та надмірну збудженість. Повертаємо власнику впевненість в управлінні.',
    link: '/posluhy'
  },
  {
    title: 'Захищено-караульна служба',
    description:
      'Навчаємо точному реагуванню на команди, побудові захоплення та відпуску, працюємо з елементами маневреності.',
    link: '/posluhy'
  },
  {
    title: 'Супровід кінолога',
    description:
      'Персональні тренування у Варшаві й Кракові, виїзди на полігони, підготовка до іспитів та змагань.',
    link: '/posluhy'
  }
];

const steps = [
  {
    title: 'Діагностика та тестування',
    text: 'Оцінюємо темперамент, закріплені навички, стан здоров’я й мотивацію німецької вівчарки.',
    icon: '🧭'
  },
  {
    title: 'План тренувань',
    text: 'Фіксуємо цілі, обираємо техніки позитивного підкріплення та дисципліни, прописуємо домашні завдання.',
    icon: '📝'
  },
  {
    title: 'Польові заняття',
    text: 'Проводимо тренування у Варшаві та Кракові: манежі, відкриті локації, полігони для захисної роботи.',
    icon: '🏟️'
  },
  {
    title: 'Фініш і супровід',
    text: 'Готуємо до іспитів, аналізуємо відео, надаємо підтримку кінологу-власнику після завершення курсу.',
    icon: '🏆'
  }
];

const testimonials = [
  {
    quote:
      'Після курсу у «Професійне дресирування собак» моя вівчарка Лексі здала BH-VT з першої спроби. Команда детально розбирала кожен наш елемент, роблячи акцент на витримці.',
    name: 'Анна, Варшава',
    role: 'Спортивний хендлер'
  },
  {
    quote:
      'Завдяки комплексній програмі від корекції до ОКД ми вийшли на службу об’єкту без стресу. Кінологи завжди на зв’язку та дають чіткі інструкції.',
    name: 'Марцін, Краків',
    role: 'Керівник служби безпеки'
  },
  {
    quote:
      'Фокус на психології собаки, системність та людяність — це те, що виділяє команду. Тепер ми тренуємося з задоволенням.',
    name: 'Олена, Варшава',
    role: 'Власниця молодої вівчарки'
  }
];

const projects = [
  {
    id: 1,
    title: 'Підготовка до IGP-1',
    category: 'sport',
    image: 'https://picsum.photos/1200/800?random=11',
    description: 'Програма для спортивної пари у Варшаві з акцентом на ідеальний апорт.'
  },
  {
    id: 2,
    title: 'Охоронна служба складу',
    category: 'service',
    image: 'https://picsum.photos/1200/800?random=12',
    description: 'Захисна підготовка трьох вівчарок для об’єкта у Кракові.'
  },
  {
    id: 3,
    title: 'Корекція реактивності',
    category: 'behavior',
    image: 'https://picsum.photos/1200/800?random=13',
    description: 'Робота з собакою-рятувальником, яка уникала контакту з людьми.'
  },
  {
    id: 4,
    title: 'Соціалізація цуценяти',
    category: 'behavior',
    image: 'https://picsum.photos/1200/800?random=14',
    description: 'Перші кроки для майбутнього чемпіона шоу-рингу.'
  }
];

const faqData = [
  {
    question: 'Скільки часу триває базовий курс для німецької вівчарки?',
    answer:
      'Середній курс триває 10–12 тижнів, включаючи щотижневі очні тренування та дистанційний супровід. Тривалість залежить від віку, мети та стартового рівня собаки.'
  },
  {
    question: 'Чи працюєте ви з агресивними собаками?',
    answer:
      'Так, наша команда має сертифікацію з роботи з поведінковими проблемами. Перед стартом проводимо оцінку ризиків та пропонуємо безпечний план корекції.'
  },
  {
    question: 'Де проходять заняття у Варшаві та Кракові?',
    answer:
      'Ми тренуємо на закритих майданчиках, у міських умовах та виїжджаємо на спеціалізовані полігони. Локацію обираємо залежно від завдань та погодних умов.'
  },
  {
    question: 'Чи можливі онлайн-консультації?',
    answer:
      'Так, ми проводимо онлайн-сесії для розбору відео, планування тренувань і контролю домашніх завдань між очними зустрічами.'
  }
];

const blogPosts = [
  {
    title: '5 ключових етапів підготовки до іспиту BH-VT',
    date: '18 січня 2024',
    image: 'https://picsum.photos/800/600?random=21',
    excerpt:
      'Розглядаємо структуру іспиту, оцінку суддів, типові помилки та способи закріпити витримку німецької вівчарки.'
  },
  {
    title: 'Мотивація у захисній роботі: що працює?',
    date: '2 лютого 2024',
    image: 'https://picsum.photos/800/600?random=22',
    excerpt:
      'Пояснюємо, як поєднати драйв, контроль і безпеку при відпрацюванні захоплення та відпуску.'
  },
  {
    title: 'Розуміння сигналів стресу',
    date: '9 березня 2024',
    image: 'https://picsum.photos/800/600?random=23',
    excerpt:
      'Збираємо головні індикатори, на які має звертати увагу кінолог під час інтенсивних тренувань.'
  }
];

const HomePage = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('all');
  const [expandedFaq, setExpandedFaq] = useState(null);
  const [formData, setFormData] = useState({ name: '', phone: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const animationDuration = 1600;
    const frameRate = 30;
    const increments = statsData.map(
      (stat) => stat.value / (animationDuration / frameRate)
    );

    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, index) => {
          const nextValue = value + increments[index];
          return nextValue >= statsData[index].value
            ? statsData[index].value
            : nextValue;
        })
      );
    }, frameRate);

    const timeout = setTimeout(() => {
      clearInterval(interval);
      setCounters(statsData.map((item) => item.value));
    }, animationDuration + frameRate);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(rotation);
  }, []);

  const handleFilterChange = (category) => {
    setActiveFilter(category);
  };

  const filteredProjects =
    activeFilter === 'all'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  const toggleFaq = (index) => {
    setExpandedFaq((prev) => (prev === index ? null : index));
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setFormErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = "Будь ласка, вкажіть ім'я.";
    }
    if (!formData.phone.trim()) {
      errors.phone = 'Нам потрібен ваш телефон для зв\'язку.';
    } else if (!/^[\d\s()+-]{6,}$/.test(formData.phone.trim())) {
      errors.phone = 'Вкажіть коректний номер телефону.';
    }
    if (!formData.message.trim()) {
      errors.message = 'Опишіть мету звернення або питання.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validateForm()) return;
    setSubmitted(true);
    setFormData({ name: '', phone: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <PageHelmet
        title="Професійне дресирування собак — Варшава та Краків"
        description="Спеціалізоване дресирування німецьких вівчарок: ОКД, захисна служба, корекція поведінки. Працюємо у Варшаві та Кракові."
      />
      <section className={styles.hero}>
        <div className={styles.overlay} />
        <div className={styles.heroContent}>
          <p className={styles.heroPreTitle}>Кінологічна студія | Варшава · Краків</p>
          <h1>
            Вивільняємо потенціал німецьких вівчарок через системне дресирування
          </h1>
          <p className={styles.heroText}>
            Працюємо з цуценятами та дорослими собаками, готуємо до ОКД, IGP, захисної служби та
            надаємо супровід кінолога. Кожна програма персоналізована під пару «людина-собака».
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.ctaPrimary}>
              Записатися
            </Link>
            <Link to="/posluhy" className={styles.ctaSecondary}>
              Дізнатися про програми
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.aboutSection} id="about">
        <div className={styles.aboutIntro}>
          <h2>Про команду та підхід</h2>
          <p>
            «Професійне дресирування собак» об’єднує сертифікованих кінологів з Варшави та Кракова.
            Ми працюємо з робочими лініями німецьких вівчарок і супроводжуємо пари від перших
            контактів до міжнародних змагань і служби.
          </p>
        </div>
        <div className={styles.statsGrid}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>{Math.round(counters[index])}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.advantagesSection}>
        <h2>Чому власники вівчарок обирають нас</h2>
        <div className={styles.advantagesGrid}>
          {advantages.map((advantage) => (
            <article key={advantage.title} className={styles.advantageCard}>
              <h3>{advantage.title}</h3>
              <p>{advantage.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.servicesSection} id="services">
        <div className={styles.servicesHeader}>
          <h2>Основні напрямки тренувань</h2>
          <p>
            Від базової слухняності до спеціалізованої підготовки для служби й спорту. Перегляньте
            усі пропозиції на сторінці послуг.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {servicesData.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </div>
              <Link to={service.link} className={styles.serviceLink}>
                Детальніше
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection} id="process">
        <div className={styles.processIntro}>
          <h2>Як проходить співпраця у Варшаві та Кракові</h2>
          <p>
            Ми поєднуємо домашні завдання, польові заняття та підтримку кінолога. Тренуємо у
            комфортних умовах столиці та Малопольщі, обираючи локації під ваші задачі.
          </p>
        </div>
        <div className={styles.steps}>
          {steps.map((step) => (
            <div key={step.title} className={styles.stepCard}>
              <span className={styles.stepIcon} aria-hidden="true">
                {step.icon}
              </span>
              <div>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            </div>
          ))}
        </div>
        <div className={styles.locationInfo}>
          <h3>Географія роботи</h3>
          <p>
            Варшава, вул. Собача, 15 — головний тренувальний центр із закритим манежем та зонами
            соціалізації. Краків, вул. Пастівська, 8 — майданчик для польових занять та тренінгів
            захисної служби. Виїжджаємо до клієнтів у межах Мазовії та Малопольщі.
          </p>
        </div>
      </section>

      <section className={styles.successSection} id="success">
        <div className={styles.testimonialBlock}>
          <h2>Відгуки та історії успіху</h2>
          <div className={styles.testimonial}>
            <p>“{testimonials[activeTestimonial].quote}”</p>
            <div className={styles.testimonialMeta}>
              <span>{testimonials[activeTestimonial].name}</span>
              <span>{testimonials[activeTestimonial].role}</span>
            </div>
          </div>
          <div className={styles.testimonialDots} role="tablist" aria-label="Відгуки клієнтів">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                className={`${styles.dot} ${
                  index === activeTestimonial ? styles.dotActive : ''
                }`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Показати відгук ${testimonial.name}`}
              />
            ))}
          </div>
          <Link to="/nashi-uspikhy" className={styles.successLink}>
            Переглянути більше історій
          </Link>
        </div>
        <div className={styles.projectsBlock}>
          <div className={styles.projectsHeader}>
            <h3>Проєкти тренувань</h3>
            <div className={styles.filters} role="group" aria-label="Фільтр проєктів">
              <button
                type="button"
                className={activeFilter === 'all' ? styles.filterActive : ''}
                onClick={() => handleFilterChange('all')}
              >
                Усі
              </button>
              <button
                type="button"
                className={activeFilter === 'sport' ? styles.filterActive : ''}
                onClick={() => handleFilterChange('sport')}
              >
                Спорт
              </button>
              <button
                type="button"
                className={activeFilter === 'service' ? styles.filterActive : ''}
                onClick={() => handleFilterChange('service')}
              >
                Служба
              </button>
              <button
                type="button"
                className={activeFilter === 'behavior' ? styles.filterActive : ''}
                onClick={() => handleFilterChange('behavior')}
              >
                Поведінка
              </button>
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <figure>
                  <img
                    src={project.image}
                    alt={`${project.title} — результати тренування`}
                    loading="lazy"
                  />
                </figure>
                <div className={styles.projectContent}>
                  <span className={styles.projectTag}>
                    {project.category === 'sport' && 'Спорт'}
                    {project.category === 'service' && 'Служба'}
                    {project.category === 'behavior' && 'Поведінка'}
                  </span>
                  <h4>{project.title}</h4>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamFaqSection} id="team">
        <div className={styles.teamBlock}>
          <h2>Команда кінологів</h2>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=31"
                alt="Марія Новак — головний тренер з ОКД"
                loading="lazy"
              />
              <div>
                <h3>Марія Новак</h3>
                <p>Головний тренер з ОКД та IGP, суддя міжнародної категорії. Випускниця Європейської академії кінологів.</p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=32"
                alt="Якуб Ковальський — інструктор захисної служби"
                loading="lazy"
              />
              <div>
                <h3>Якуб Ковальський</h3>
                <p>Інструктор захищено-караульної служби, експерт з корекції агресивної поведінки та ментор молодих кінологів.</p>
              </div>
            </article>
          </div>
          <Link to="/pro-nas" className={styles.teamLink}>
            Дізнатися більше про команду
          </Link>
        </div>
        <div className={styles.faqBlock}>
          <h2>Питання та відповіді</h2>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <div
                key={item.question}
                className={`${styles.faqItem} ${
                  expandedFaq === index ? styles.faqOpen : ''
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={expandedFaq === index}
                >
                  <span>{item.question}</span>
                  <span>{expandedFaq === index ? '−' : '+'}</span>
                </button>
                <div className={styles.faqContent}>
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} id="blog">
        <div className={styles.blogHeader}>
          <h2>Останні нотатки з тренувань</h2>
          <p>
            Практичні рекомендації та аналітика з наших майданчиків у Варшаві та Кракові. Читайте,
            щоб вивести тренування на новий рівень.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img
                src={post.image}
                alt={`${post.title} — блог`}
                loading="lazy"
              />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <span className={styles.blogMore}>Читати далі</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection} id="contact">
        <div className={styles.ctaIntro}>
          <h2>Готові зробити крок до слухняної та впевненої вівчарки?</h2>
          <p>
            Залиште контакти — наш кінолог зв’яжеться, розповість про формат занять у вашому місті
            та запропонує індивідуальний план тренувань.
          </p>
        </div>
        <form className={styles.ctaForm} onSubmit={handleSubmit} noValidate>
          <div className={styles.formField}>
            <label htmlFor="home-name">Ім’я</label>
            <input
              id="home-name"
              name="name"
              type="text"
              placeholder="Ваше ім’я"
              value={formData.name}
              onChange={handleInputChange}
              aria-invalid={!!formErrors.name}
            />
            {formErrors.name && <span className={styles.error}>{formErrors.name}</span>}
          </div>
          <div className={styles.formField}>
            <label htmlFor="home-phone">Телефон</label>
            <input
              id="home-phone"
              name="phone"
              type="tel"
              placeholder="+48 ..."
              value={formData.phone}
              onChange={handleInputChange}
              aria-invalid={!!formErrors.phone}
            />
            {formErrors.phone && <span className={styles.error}>{formErrors.phone}</span>}
          </div>
          <div className={styles.formField}>
            <label htmlFor="home-message">Повідомлення</label>
            <textarea
              id="home-message"
              name="message"
              rows="4"
              placeholder="Опишіть мету тренувань, вік та характер собаки."
              value={formData.message}
              onChange={handleInputChange}
              aria-invalid={!!formErrors.message}
            />
            {formErrors.message && <span className={styles.error}>{formErrors.message}</span>}
          </div>
          <button type="submit" className={styles.submitButton}>
            Надіслати запит
          </button>
          {submitted && (
            <div className={styles.successMessage} role="status">
              Дякуємо! Ми зв’яжемося з вами протягом одного робочого дня.
            </div>
          )}
        </form>
      </section>
    </div>
  );
};

export default HomePage;