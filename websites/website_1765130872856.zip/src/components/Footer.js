import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Футер">
      <div className={styles.container}>
        <div className={styles.brand}>
          <h3>Професійне дресирування собак</h3>
          <p>
            Супроводжуємо німецьких вівчарок та їх власників у Варшаві й Кракові, створюючи
            гармонійні команди «людина-собака» для спорту, служби та сім'ї.
          </p>
        </div>
        <div className={styles.grid}>
          <div>
            <h4>Швидкі посилання</h4>
            <ul>
              <li>
                <Link to="/posluhy">Послуги</Link>
              </li>
              <li>
                <Link to="/pro-nas">Про нас</Link>
              </li>
              <li>
                <Link to="/nashi-uspikhy">Наші успіхи</Link>
              </li>
              <li>
                <Link to="/kontakty">Контакти</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>Юридична інформація</h4>
            <ul>
              <li>
                <Link to="/umovy-vykorystannia">Умови використання</Link>
              </li>
              <li>
                <Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link>
              </li>
              <li>
                <Link to="/polityka-cookie">Політика щодо cookie</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>Контакти</h4>
            <ul className={styles.contacts}>
              <li>Варшава, вул. Собача, 15</li>
              <li>Краків, вул. Пастівська, 8</li>
              <li>
                Телефон: <a href="tel:+48123456789">+48 123 456 789</a>
              </li>
              <li>
                Email:{' '}
                <a href="mailto:info@dogs-training.pl">info@dogs-training.pl</a>
              </li>
            </ul>
            <div className={styles.socials} aria-label="Соціальні мережі">
              <a
                href="https://www.facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
              >
                Facebook
              </a>
              <a
                href="https://www.instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
              >
                Instagram
              </a>
              <a
                href="https://www.youtube.com"
                target="_blank"
                rel="noreferrer"
                aria-label="YouTube"
              >
                YouTube
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Професійне дресирування собак. Всі права захищено.</p>
      </div>
    </footer>
  );
};

export default Footer;