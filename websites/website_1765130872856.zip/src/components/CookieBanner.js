import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('dogTrainingCookieConsent');
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('dogTrainingCookieConsent', 'accepted');
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem('dogTrainingCookieConsent', 'declined');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Ми використовуємо cookie, щоб вдосконалювати роботу сайту та аналізувати взаємодію з
          контентом. Продовжуючи перегляд, ви погоджуєтеся з{' '}
          <a href="/polityka-cookie">Політикою щодо cookie</a>.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={acceptCookies}>
            Погоджуюсь
          </button>
          <button type="button" onClick={declineCookies} className={styles.secondary}>
            Відхилити
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;