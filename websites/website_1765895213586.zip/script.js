document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".nav");
  const cookieBanner = document.getElementById("cookie-banner");
  const acceptButton = document.getElementById("cookie-accept");
  const declineButton = document.getElementById("cookie-decline");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", function () {
      const isOpen = navMenu.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    navMenu.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        if (navMenu.classList.contains("is-open")) {
          navMenu.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });

    document.addEventListener("click", function (event) {
      if (navMenu.classList.contains("is-open")) {
        const clickInsideNav = navMenu.contains(event.target) || navToggle.contains(event.target);
        if (!clickInsideNav) {
          navMenu.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      }
    });
  }

  if (cookieBanner && acceptButton && declineButton) {
    const consentValue = localStorage.getItem("cookieConsent");
    if (!consentValue) {
      requestAnimationFrame(function () {
        cookieBanner.classList.add("is-visible");
      });
    }

    acceptButton.addEventListener("click", function () {
      localStorage.setItem("cookieConsent", "accepted");
      cookieBanner.classList.remove("is-visible");
    });

    declineButton.addEventListener("click", function () {
      localStorage.setItem("cookieConsent", "declined");
      cookieBanner.classList.remove("is-visible");
    });
  }
});