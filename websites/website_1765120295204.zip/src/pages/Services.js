import SEO from '../components/SEO';
import styles from './Services.module.css';

const services = [
  {
    title: 'Стратегический консалтинг',
    description:
      'Создаем цифровые стратегии, проводим аудит процессов и формируем дорожные карты внедрения изменений с прогнозируемым эффектом.',
    deliverables: [
      'Цифровая стратегия и целевая модель',
      'План трансформации с KPI',
      'Оценка зрелости процессов и команды',
    ],
  },
  {
    title: 'Дизайн и продуктовая разработка',
    description:
      'Исследуем пользователей, проектируем цифровые продукты, управляем бэклогом и сопровождаем разработку до релиза.',
    deliverables: [
      'Customer journey и UX-исследования',
      'Прототипы и дизайн-системы',
      'Управление продуктовым бэклогом',
    ],
  },
  {
    title: 'Инжиниринг и внедрение',
    description:
      'Разрабатываем веб- и мобильные решения, внедряем современные архитектуры и интегрируем продукты с ИТ-экосистемой клиента.',
    deliverables: [
      'Full-stack разработка',
      'Системная интеграция',
      'DevOps и управление релизами',
    ],
  },
  {
    title: 'Аналитика и управление данными',
    description:
      'Выстраиваем архитектуру данных, создаем BI-дашборды и внедряем ML-модели для поддержки управленческих решений.',
    deliverables: [
      'Стратегия и архитектура данных',
      'BI-панели и аналитические витрины',
      'ML-модели и прогнозная аналитика',
    ],
  },
  {
    title: 'Сопровождение и развитие',
    description:
      'Обеспечиваем непрерывную поддержку, измеряем метрики, управляем изменениями и развиваем продукты после запуска.',
    deliverables: [
      '24/7 поддержка и SLO',
      'Аналитика и развитие функционала',
      'Наставничество и обучение команд',
    ],
  },
];

const expertise = [
  'Ритейл и e-commerce',
  'Финансовый сектор и финтех',
  'Промышленность и логистика',
  'Телеком и медиа',
  'Госсектор и смарт-сити',
  'Healthcare и фарма',
];

const Services = () => (
  <>
    <SEO
      title="Услуги компании — консалтинг, продукты, аналитика"
      description="Комплекс услуг: стратегия, дизайн и разработка цифровых продуктов, интеграция, аналитика и сопровождение."
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Комплексные услуги, которые поддерживают трансформацию на всех этапах</h1>
        <p>
          Мы строим долгосрочные отношения с клиентами, сопровождая проекты от идеи до масштабирования. Включаемся в
          команду заказчика, выстраиваем процессы и доводим инициативы до измеримых результатов.
        </p>
      </div>
    </section>

    <section className={styles.services}>
      <div className="container">
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.card}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.deliverables.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.expertise}>
      <div className="container">
        <div className={styles.expertiseCard}>
          <h2>Отраслевые компетенции</h2>
          <p>
            Мы работаем с компаниями различного масштаба — от стартапов до крупных корпораций, адаптируя решения под
            конкретные требования отраслей.
          </p>
          <div className={styles.expertiseGrid}>
            {expertise.map((item) => (
              <span key={item}>{item}</span>
            ))}
          </div>
        </div>
      </div>
    </section>

    <section className={styles.methodology}>
      <div className="container">
        <div className={styles.methodologyGrid}>
          <div>
            <h2>Методологии и стандарты</h2>
            <p>
              Мы используем гибридный подход: комбинируем Agile, Design Thinking и классические управленческие практики.
              Все процессы документируем, что позволяет масштабировать решения и легко передавать их внутренним
              командам.
            </p>
            <ul>
              <li>Certified Scrum Master & Product Owner</li>
              <li>Lean, Six Sigma и продуктовые метрики</li>
              <li>ISO 27001, ISO 9001 и ITIL v4</li>
            </ul>
          </div>
          <img
            src="https://picsum.photos/1200/800?random=41"
            alt="Команда обсуждает методологии и стандарты проекта"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  </>
);

export default Services;