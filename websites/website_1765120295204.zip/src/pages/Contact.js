import { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  phone: '',
  message: '',
};

const Contact = () => {
  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const nextErrors = {};
    if (!form.name.trim()) {
      nextErrors.name = 'Укажите ваше имя';
    }
    if (!form.email.trim()) {
      nextErrors.email = 'Укажите email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      nextErrors.email = 'Введите корректный email';
    }
    if (!form.phone.trim()) {
      nextErrors.phone = 'Укажите телефон';
    }
    if (!form.message.trim()) {
      nextErrors.message = 'Опишите ваш запрос';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
    setSubmitted(false);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setSubmitted(true);
      setForm(initialState);
    }
  };

  return (
    <>
      <SEO
        title="Контакты компании — обсудить проект"
        description="Свяжитесь с командой компании: адрес, телефон, email и форма обратной связи для новых проектов."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Давайте обсудим вашу задачу</h1>
          <p>
            Заполните форму, чтобы мы подготовили предложение. Мы ответим в течение одного рабочего дня и договоримся о
            звонке или встрече.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Форма связи</h2>
              <div className={styles.field}>
                <label htmlFor="name">Имя</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Введите ваше имя"
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  required
                />
                {errors.name && (
                  <span id="name-error" className={styles.error}>
                    {errors.name}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="name@company.ru"
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  required
                />
                {errors.email && (
                  <span id="email-error" className={styles.error}>
                    {errors.email}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="phone">Телефон</label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={form.phone}
                  onChange={handleChange}
                  placeholder="+7 (___) ___-__-__"
                  aria-invalid={Boolean(errors.phone)}
                  aria-describedby={errors.phone ? 'phone-error' : undefined}
                  required
                />
                {errors.phone && (
                  <span id="phone-error" className={styles.error}>
                    {errors.phone}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Сообщение</label>
                <textarea
                  id="message"
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  placeholder="Кратко опишите ваш проект или вопрос"
                  rows="5"
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  required
                />
                {errors.message && (
                  <span id="message-error" className={styles.error}>
                    {errors.message}
                  </span>
                )}
              </div>
              <button type="submit" className={styles.submit}>
                Отправить
              </button>
              {submitted && (
                <p className={styles.success} role="status">
                  Спасибо! Мы получили ваш запрос и свяжемся в течение рабочего дня.
                </p>
              )}
            </form>

            <div className={styles.info}>
              <h2>Контакты</h2>
              <div className={styles.infoBlock}>
                <span>Адрес</span>
                <p>г. Москва, наб. Пресненская, д. 12</p>
              </div>
              <div className={styles.infoBlock}>
                <span>Телефон</span>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </div>
              <div className={styles.infoBlock}>
                <span>Email</span>
                <a href="mailto:info@kompaniya.ru">info@kompaniya.ru</a>
              </div>
              <div className={styles.infoBlock}>
                <span>Режим работы</span>
                <p>Пн–Пт: 09:00–19:00 (MSK)</p>
              </div>
              <div className={styles.mapWrapper} aria-label="Карта расположения офиса">
                <iframe
                  title="Офис компании на карте"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.2068928306047!2d37.534382!3d55.749792!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a5ee7da1fbb%3A0x55a49963cf343577!2z0JzQvtC70YzRiNC-0Lkg0KHQvtCx0LjQu9C4INCc0L7Qu9GP!5e0!3m2!1sru!2sru!4v1700000000000!5m2!1sru!2sru"
                  loading="lazy"
                  allowFullScreen
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;