import SEO from '../components/SEO';
import styles from './About.module.css';

const coreValues = [
  {
    title: 'Стратегическое партнерство',
    description:
      'Мы вникаем в бизнес клиентов, разделяя ответственность за результат. Вместе планируем рост и измеряем эффект.',
  },
  {
    title: 'Открытость и доверие',
    description:
      'Работаем прозрачно, даем доступ к артефактам и данным, приглашаем клиента в процесс принятия решений.',
  },
  {
    title: 'Инновации с реальной пользой',
    description:
      'Внедряем технологии не ради моды, а ради пользы. Отбираем решения, которые создают измеримую ценность.',
  },
];

const timeline = [
  {
    year: '2015',
    event: 'Компания основана с миссией помогать бизнесу адаптироваться к цифровой среде.',
  },
  {
    year: '2017',
    event: 'Запуск продуктового офиса и первых проектов полного цикла для крупных ритейл-партнеров.',
  },
  {
    year: '2019',
    event: 'Выход на международный рынок, создание аналитического Р&D направления и развитие экспертной команды данных.',
  },
  {
    year: '2023',
    event: 'Сертификация ISO, расширение портфеля отраслей и запуск программы акселерации для корпоративных клиентов.',
  },
];

const team = [
  {
    name: 'Сергей Волков',
    role: 'Управляющий партнер, стратегический консалтинг',
    image: 'https://picsum.photos/400/400?random=31',
    bio: '15 лет помогает предприятиям перестраивать операционные модели и внедрять цифровые инициативы.',
  },
  {
    name: 'Ольга Андреева',
    role: 'Директор по продуктам',
    image: 'https://picsum.photos/400/400?random=32',
    bio: 'Отвечает за продуктовую стратегию, дизайн-исследования и customer development.',
  },
  {
    name: 'Алексей Никитин',
    role: 'Руководитель направления данных',
    image: 'https://picsum.photos/400/400?random=33',
    bio: 'Строит архитектуры данных и внедряет ML-решения в крупных корпоративных экосистемах.',
  },
  {
    name: 'Екатерина Миронова',
    role: 'Head of Delivery',
    image: 'https://picsum.photos/400/400?random=34',
    bio: 'Обеспечивает организацию процессов, контроль качества и вовлеченность команд.',
  },
];

const About = () => (
  <>
    <SEO
      title="О компании — экспертиза и команда"
      description="История компании, миссия, ценности и команда экспертов, которые помогают клиентам проходить путь цифровой трансформации."
    />
    <section className={styles.intro}>
      <div className="container">
        <div className={styles.introGrid}>
          <div>
            <span className={styles.badge}>О компании</span>
            <h1>Мы создаем цифровые решения, которые влияют на бизнес-результаты</h1>
            <p>
              Компания — это объединение стратегов, бизнес-аналитиков, дизайнеров и инженеров. Мы помогаем лидерам рынка
              уверенно проходить путь трансформации, выстраивать цифровые экосистемы и воплощать амбициозные идеи в
              продукты, которыми удобно пользоваться.
            </p>
          </div>
          <div className={styles.highlight}>
            <p>
              <strong>Наша миссия</strong> — ускорять развитие бизнеса наших клиентов, делая технологии понятными,
              управляемыми и приносить заметную пользу людям.
            </p>
            <p>
              Мы верим, что устойчивость бизнеса строится на сочетании стратегии, процессов и культуры. Именно поэтому
              всегда работаем бок о бок с командами заказчиков.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <h2 className="sectionTitle">Наши ценности</h2>
        <p className="sectionLead">
          То, что делает нас командой, и то, что клиенты ценят в партнерстве с нами.
        </p>
        <div className={styles.valuesGrid}>
          {coreValues.map((value) => (
            <div key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.timeline}>
      <div className="container">
        <h2 className="sectionTitle">Путь развития</h2>
        <div className={styles.timelineGrid}>
          {timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span>{item.year}</span>
              <p>{item.event}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <h2 className="sectionTitle">Команда руководителей</h2>
        <p className="sectionLead">
          Мы собрали людей, умеющих запускать и масштабировать сложные проекты в разных отраслях и странах.
        </p>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.office}>
      <div className="container">
        <div className={styles.officeGrid}>
          <div>
            <h2>Наши офисы и форматы работы</h2>
            <p>
              Головной офис расположен в Москве, рядом с ММДЦ «Москва-Сити». Мы работаем в гибридном формате:
              распределенная команда объединена общими процессами и синхронизирована через современные инструменты
              управления.
            </p>
            <ul>
              <li>Цифровое пространство для совместной работы с клиентами.</li>
              <li>Собственный тренинг-центр для обучения продуктовых и внедренческих команд.</li>
              <li>Лаборатория rapid prototyping для быстрых экспериментов и тестирования гипотез.</li>
            </ul>
          </div>
          <img
            src="https://picsum.photos/1200/800?random=35"
            alt="Современный офис компании с зоной совместной работы"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  </>
);

export default About;