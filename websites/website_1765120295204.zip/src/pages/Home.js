import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const statsSource = [
  { label: 'лет на рынке', value: 12, suffix: '+' },
  { label: 'вовлеченных экспертов', value: 140, suffix: '+' },
  { label: 'завершенных проектов', value: 280, suffix: '+' },
  { label: 'средний рост эффективности', value: 37, suffix: '%' },
];

const services = [
  {
    title: 'Стратегический консалтинг',
    description:
      'Проводим диагностику процессов, определяем точки роста и формируем дорожные карты трансформации бизнеса.',
    icon: '🧭',
  },
  {
    title: 'Цифровые продукты',
    description:
      'Проектируем и разрабатываем платформы, мобильные приложения и корпоративные порталы с акцентом на UX.',
    icon: '💡',
  },
  {
    title: 'Аналитика и данные',
    description:
      'Создаем надежные архитектуры данных, BI-дэшборды и внедряем ML-модели для принятия управленческих решений.',
    icon: '📊',
  },
  {
    title: 'Интеграция и поддержка',
    description:
      'Интегрируем решения с текущей ИТ-инфраструктурой и берем на себя непрерывное сопровождение и развитие.',
    icon: '🔗',
  },
];

const processSteps = [
  {
    title: 'Диагностика и гипотезы',
    description: 'Погружаемся в контекст, собираем данные, формируем гипотезы по трансформации и ожидаемый эффект.',
  },
  {
    title: 'Дизайн решения',
    description: 'Создаем концепты и customer journey, рассчитываем экономику, формируем MVP и бэклог задач.',
  },
  {
    title: 'Внедрение и обучение',
    description: 'Запускаем пилот, обучаем команды заказчика, масштабируем решение на ключевые бизнес-направления.',
  },
  {
    title: 'Сопровождение и рост',
    description: 'Отслеживаем метрики, корректируем стратегию, помогая клиенту укреплять позиции на рынке.',
  },
];

const projects = [
  {
    title: 'Платформа лояльности для ритейла',
    category: 'Ритейл',
    result: 'Рост повторных покупок на 42%',
    image: 'https://picsum.photos/1200/800?random=11',
  },
  {
    title: 'HR-экосистема для холдинга',
    category: 'Корпоративный сектор',
    result: 'Сокращение time-to-hire на 28%',
    image: 'https://picsum.photos/1200/800?random=12',
  },
  {
    title: 'Аналитическая BI-панель',
    category: 'Финансы',
    result: 'Единый источник данных для 17 подразделений',
    image: 'https://picsum.photos/1200/800?random=13',
  },
  {
    title: 'Мобильный сервис для клиентов',
    category: 'Ритейл',
    result: 'NPS вырос с 32 до 58 за 3 месяца',
    image: 'https://picsum.photos/1200/800?random=14',
  },
];

const testimonials = [
  {
    quote:
      'Команда помогла нам перестроить клиентские процессы и внедрить новую цифровую экосистему. Мы получили не просто проект, а устойчивую модель управления изменениями.',
    name: 'Анна Петрова',
    role: 'Директор по развитию сети магазинов «Портал»',
  },
  {
    quote:
      'За счет продуманной аналитики и динамических дэшбордов мы стали принимать решения быстрее и точнее. Отдельное спасибо за поддержку на каждом этапе.',
    name: 'Илья Ковалев',
    role: 'CFO, холдинг «Сфера»',
  },
  {
    quote:
      'Компания помогла сформировать стратегию цифровой трансформации и запустить несколько MVP. Мы значительно ускорили вывод новых сервисов на рынок.',
    name: 'Мария Лебедева',
    role: 'CEO, стартап «NovaTech»',
  },
];

const faqData = [
  {
    question: 'С чего начинается сотрудничество?',
    answer:
      'Мы проводим бесплатный экспресс-аудит, выявляем ключевые запросы и предлагаем целевую модель сотрудничества. После согласования рамок работ формируем подробный план.',
  },
  {
    question: 'Вы работаете по гибким методологиям?',
    answer:
      'Да, мы адаптируем Agile, Scrum или Kanban под задачу и специфику клиента. Основной упор делаем на прозрачную коммуникацию и короткие циклы обратной связи.',
  },
  {
    question: 'Можно ли подключиться только на отдельный этап?',
    answer:
      'Мы гибко подходим к формату: можем взять проект под ключ или подключиться на этапе стратегии, разработки или внедрения, усилив внутреннюю команду заказчика.',
  },
];

const blogPosts = [
  {
    title: 'Как построить устойчивую цифровую стратегию на 3 года',
    date: '12 марта 2024',
    image: 'https://picsum.photos/800/600?random=21',
  },
  {
    title: 'От MVP до масштабирования: кейс промышленного холдинга',
    date: '26 февраля 2024',
    image: 'https://picsum.photos/800/600?random=22',
  },
  {
    title: 'Пять метрик, которые показывают эффективность трансформации',
    date: '8 февраля 2024',
    image: 'https://picsum.photos/800/600?random=23',
  },
];

const Home = () => {
  const [statValues, setStatValues] = useState(statsSource.map(() => 0));
  const [activeCategory, setActiveCategory] = useState('Все');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    let start = null;
    const duration = 1400;

    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);

      setStatValues(
        statsSource.map((stat) => {
          const eased = progress < 1 ? Math.floor(stat.value * progress) : stat.value;
          return eased;
        })
      );

      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };

    requestAnimationFrame(step);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);

    return () => clearInterval(interval);
  }, []);

  const categories = useMemo(() => ['Все', ...new Set(projects.map((project) => project.category))], []);

  const filteredProjects =
    activeCategory === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  return (
    <>
      <SEO
        title="Компания — партнер по цифровой трансформации бизнеса"
        description="Мы помогаем компаниям создавать цифровые продукты, выстраивать стратегии роста и внедрять аналитику, которая работает на результат."
      />
      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <span className={styles.heroTag}>Партнер по развитию</span>
            <h1>
              Компания — проводник в цифровую трансформацию и устойчивый рост вашего бизнеса
            </h1>
            <p>
              Создаем стратегию, проекты и процессы, которые укрепляют позиции на рынке, ускоряют вывод продуктов и
              создают измеримую ценность для клиентов и внутренних команд.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryBtn}>
                Обсудить задачу
              </Link>
              <Link to="/o-kompanii" className={styles.secondaryBtn}>
                Узнать о подходе
              </Link>
            </div>
            <div className={styles.heroMetrics}>
              <div>
                <strong>ISO 27001</strong>
                <span>Сертифицированная информационная безопасность</span>
              </div>
              <div>
                <strong>4.9/5</strong>
                <span>Средняя оценка клиентов и партнеров</span>
              </div>
            </div>
          </div>
          <div className={styles.heroImageWrapper}>
            <img
              src="https://picsum.photos/1200/800?random=10"
              alt="Команда компании обсуждает цифровую стратегию клиента"
              className={styles.heroImage}
            />
            <div className={styles.heroCard}>
              <p>«Мы получили не просто продукт, а культуру цифровых изменений»</p>
              <span>— Клиент из отрасли ритейла</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div className={styles.aboutText}>
              <h2 className="sectionTitle">Мы превращаем стратегии в осязаемые результаты</h2>
              <p className="sectionLead">
                Компания объединяет консалтинг, дизайн и разработку. Мы погружаемся в задачи клиентов, формируем
                четкую дорожную карту и доводим изменения до практического эффекта: от повышения выручки до оптимизации
                процессов.
              </p>
              <ul className={styles.valuesList}>
                <li>
                  <strong>Фокус на людях.</strong> Строим решения вокруг пользователей и команд заказчика.
                </li>
                <li>
                  <strong>Проверенные процессы.</strong> Комбинируем Agile и продуктовый подход с управленческой
                  дисциплиной.
                </li>
                <li>
                  <strong>Измеримый результат.</strong> Работаем с KPI, которые можно увидеть в отчетах и операционных
                  данных.
                </li>
              </ul>
              <Link to="/o-kompanii" className={styles.aboutLink}>
                Подробнее о компании →
              </Link>
            </div>
            <div className={styles.teamCard}>
              <img
                src="https://picsum.photos/800/600?random=24"
                alt="Команда компании на стратегической сессии"
              />
              <div className={styles.teamInfo}>
                <h3>Экспертное ядро</h3>
                <p>80% ключевой команды с опытом внедрения проектов уровня enterprise и международных инициатив.</p>
                <div className={styles.teamHighlights}>
                  <div>
                    <strong>15</strong>
                    <span>Стран присутствия проектов</span>
                  </div>
                  <div>
                    <strong>6</strong>
                    <span>Отраслевых акселераторов в портфеле</span>
                  </div>
                  <div>
                    <strong>24/7</strong>
                    <span>Поддержка критичных сервисов</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Ключевые направления работы</h2>
            <p className="sectionLead">
              Мы закрываем потребности от проектирования цифровых продуктов до настройки аналитики и поддержки операций.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/uslugi" className={styles.serviceLink}>
                  Подробнее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsSource.map((stat, idx) => (
              <div key={stat.label} className={styles.statCard}>
                <strong>
                  {statValues[idx]}
                  {stat.suffix}
                </strong>
                <span>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Как мы запускаем трансформации</h2>
            <p className="sectionLead">
              Используем опробованные сотнями проектов процессы, гибко адаптируя их под культуру и цели вашей компании.
            </p>
          </div>
          <div className={styles.processSteps}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processStep}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsHead}>
            <div>
              <h2 className="sectionTitle">Проекты и кейсы</h2>
              <p className="sectionLead">
                Мы берем ответственность за результат на каждом этапе — от стратегии до операционного сопровождения.
              </p>
            </div>
            <div className={styles.filters} role="tablist" aria-label="Категории проектов">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={activeCategory === category}
                  className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.result}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialWrapper}>
            <div className={styles.testimonialContent}>
              <h2 className="sectionTitle">Отзывы клиентов</h2>
              <p className="sectionLead">
                Мы строим долгосрочные партнерства, в которых важна прозрачность, доверие и осязаемый бизнес-эффект.
              </p>
              <div className={styles.testimonial}>
                <p>“{testimonials[currentTestimonial].quote}”</p>
                <div>
                  <strong>{testimonials[currentTestimonial].name}</strong>
                  <span>{testimonials[currentTestimonial].role}</span>
                </div>
              </div>
              <div className={styles.testimonialControls}>
                <button
                  type="button"
                  onClick={() =>
                    setCurrentTestimonial((prev) =>
                      prev === 0 ? testimonials.length - 1 : prev - 1
                    )
                  }
                  aria-label="Предыдущий отзыв"
                >
                  ←
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
                  }
                  aria-label="Следующий отзыв"
                >
                  →
                </button>
              </div>
            </div>
            <div className={styles.faq}>
              <h3>Частые вопросы</h3>
              <ul>
                {faqData.map((item, index) => (
                  <li key={item.question} className={styles.faqItem}>
                    <button
                      type="button"
                      onClick={() => setOpenFaq((prev) => (prev === index ? null : index))}
                      aria-expanded={openFaq === index}
                      aria-controls={`faq-panel-${index}`}
                    >
                      {item.question}
                      <span>{openFaq === index ? '−' : '+'}</span>
                    </button>
                    {openFaq === index && (
                      <p id={`faq-panel-${index}`} className={styles.faqAnswer}>
                        {item.answer}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Свежие мысли и исследования</h2>
            <p className="sectionLead">
              Публикуем заметки о трансформации бизнеса, продуктовой разработке и аналитике данных.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <span>{post.date}</span>
                  <h3>{post.title}</h3>
                  <Link to="/o-kompanii" className={styles.blogLink}>
                    Читать →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={`container ${styles.ctaInner}`}>
          <div>
            <h2>Готовы перейти от идей к измеримым результатам?</h2>
            <p>
              Расскажите о вашей задаче, и мы подготовим предложение с прогнозируемым эффектом и дорожной картой
              внедрения.
            </p>
          </div>
          <Link to="/kontakty" className={styles.ctaButton}>
            Назначить встречу
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;