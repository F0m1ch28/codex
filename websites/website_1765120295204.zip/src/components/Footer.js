import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <h3>Компания</h3>
          <p>
            Мы объединяем стратегию, дизайн и технологии, чтобы помогать бизнесу расти и создавать устойчивые цифровые
            экосистемы.
          </p>
        </div>
        <div className={styles.column}>
          <h4>Навигация</h4>
          <ul>
            <li>
              <Link to="/">Главная</Link>
            </li>
            <li>
              <Link to="/o-kompanii">О компании</Link>
            </li>
            <li>
              <Link to="/uslugi">Услуги</Link>
            </li>
            <li>
              <Link to="/kontakty">Контакты</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Правовая информация</h4>
          <ul>
            <li>
              <Link to="/usloviya-ispolzovaniya">Условия использования</Link>
            </li>
            <li>
              <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/politika-cookie">Политика Cookie</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Контакты</h4>
          <p>г. Москва, наб. Пресненская, д. 12</p>
          <a href="tel:+74951234567" className={styles.contactLink}>
            +7 (495) 123-45-67
          </a>
          <a href="mailto:info@kompaniya.ru" className={styles.contactLink}>
            info@kompaniya.ru
          </a>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Компания. Все права защищены.</span>
        <div className={styles.socials} aria-label="Социальные сети">
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
            LI
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
            YT
          </a>
          <a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Telegram">
            TG
          </a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;