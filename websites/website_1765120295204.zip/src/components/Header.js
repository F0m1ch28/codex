import { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [menuOpen]);

  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} role="banner">
      <div className={`container ${styles.inner}`}>
        <Link to="/" className={styles.logo} aria-label="На главную">
          Компания
        </Link>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Основная навигация">
          <NavLink
            to="/"
            end
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={handleLinkClick}
          >
            Главная
          </NavLink>
          <NavLink
            to="/o-kompanii"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={handleLinkClick}
          >
            О компании
          </NavLink>
          <NavLink
            to="/uslugi"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={handleLinkClick}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={handleLinkClick}
          >
            Контакты
          </NavLink>
          <NavLink
            to="/usloviya-ispolzovaniya"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={handleLinkClick}
          >
            Условия
          </NavLink>
        </nav>
        <div className={styles.cta}>
          <Link to="/kontakty" className={styles.ctaButton}>
            Связаться
          </Link>
          <button
            className={styles.menuToggle}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-controls="primary-navigation"
            aria-label="Меню"
          >
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;