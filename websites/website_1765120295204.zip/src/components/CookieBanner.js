import { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Мы используем файлы cookie</h4>
        <p>
          Cookie помогают нам улучшать персонализацию и анализировать эффективность продуктов. Продолжая пользоваться
          сайтом, вы соглашаетесь с нашей политикой использования cookie.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.primary} onClick={handleAccept}>
            Принять
          </button>
          <a className={styles.secondary} href="/politika-cookie">
            Подробнее
          </a>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;