const palettes={
  sunrise:["#ff9a44","#fc6076","#00d4ff"],
  aurora:["#0f3443","#34e89e","#30cfd0"],
  fusion:["#654ea3","#eaafc8","#1d2b64"],
  default:["#1a2238","#243b55","#141e30"]
};
document.querySelectorAll(".dynamic-img").forEach((el,i)=>{
  const key=el.dataset.tone in palettes?el.dataset.tone:"default";
  const colors=[...palettes[key]];
  const angle=(i*47+130)%360;
  el.style.background=`linear-gradient(${angle}deg,${colors.join(",")})`;
  el.style.setProperty("--spark",colors[0]);
  el.dataset.tone=key;
});