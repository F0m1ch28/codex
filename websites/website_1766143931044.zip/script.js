document.addEventListener("DOMContentLoaded", function () {
  var banner = document.querySelector(".cookie-banner");
  if (!banner) {
    return;
  }
  var storedPreference = localStorage.getItem("userCookiePreference");
  if (!storedPreference) {
    banner.classList.add("visible");
  }
  var buttons = banner.querySelectorAll(".cookie-button");
  buttons.forEach(function (button) {
    button.addEventListener("click", function () {
      var action = button.getAttribute("data-cookie-action");
      if (!action) {
        return;
      }
      localStorage.setItem("userCookiePreference", action);
      banner.classList.remove("visible");
    });
  });
});