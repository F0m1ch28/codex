document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      mainNav.classList.toggle("open");
    });
    document.addEventListener("click", function (event) {
      if (!mainNav.contains(event.target) && !navToggle.contains(event.target)) {
        mainNav.classList.remove("open");
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptCookies = document.querySelector(".cookie-accept");
  const declineCookies = document.querySelector(".cookie-decline");

  if (cookieBanner) {
    const cookieConsent = localStorage.getItem("ges-cookie-consent");
    if (!cookieConsent) {
      cookieBanner.style.display = "block";
    }
    const setCookiePreference = (value) => {
      localStorage.setItem("ges-cookie-consent", value);
      cookieBanner.style.display = "none";
    };
    if (acceptCookies) {
      acceptCookies.addEventListener("click", function () {
        setCookiePreference("accepted");
      });
    }
    if (declineCookies) {
      declineCookies.addEventListener("click", function () {
        setCookiePreference("declined");
      });
    }
  }

  const postsSearch = document.querySelector("#posts-search");
  const postsCategory = document.querySelector("#posts-category");
  const postItems = document.querySelectorAll(".post-item");

  const filterPosts = () => {
    const searchTerm = postsSearch ? postsSearch.value.trim().toLowerCase() : "";
    const categoryValue = postsCategory ? postsCategory.value : "all";

    postItems.forEach((item) => {
      const title = item.querySelector(".post-title") ? item.querySelector(".post-title").textContent.toLowerCase() : "";
      const excerpt = item.querySelector(".post-excerpt") ? item.querySelector(".post-excerpt").textContent.toLowerCase() : "";
      const category = item.getAttribute("data-category");
      const matchesSearch = !searchTerm || title.includes(searchTerm) || excerpt.includes(searchTerm);
      const matchesCategory = categoryValue === "all" || category === categoryValue;
      if (matchesSearch && matchesCategory) {
        item.style.display = "";
      } else {
        item.style.display = "none";
      }
    });
  };

  if (postsSearch) {
    postsSearch.addEventListener("input", filterPosts);
  }
  if (postsCategory) {
    postsCategory.addEventListener("change", filterPosts);
  }

  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const nameField = contactForm.querySelector('input[name="name"]');
      const emailField = contactForm.querySelector('input[name="email"]');
      const messageField = contactForm.querySelector('textarea[name="message"]');
      const statusEl = contactForm.querySelector(".status-message");

      if (!nameField.value.trim() || !emailField.value.trim() || !messageField.value.trim()) {
        statusEl.textContent = "Please complete all required fields.";
        statusEl.style.color = "#f0a202";
        return;
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(emailField.value.trim())) {
        statusEl.textContent = "Please provide a valid email address.";
        statusEl.style.color = "#f0a202";
        return;
      }

      statusEl.textContent = "Sending...";
      statusEl.style.color = "#1fa38a";

      setTimeout(function () {
        window.location.href = "thanks.html";
      }, 700);
    });
  }
});