import React, { useEffect, useMemo, useState } from "react";
import { NavLink } from "react-router-dom";

const statsData = [
  { id: 1, label: "Projects Delivered", value: 240 },
  { id: 2, label: "Client Satisfaction", value: 98 },
  { id: 3, label: "Countries Served", value: 14 },
  { id: 4, label: "Expert Consultants", value: 36 },
];

const servicesData = [
  {
    id: 1,
    title: "Digital Transformation",
    description:
      "Modernize core operations with cloud-first initiatives, automation, and intelligent workflows.",
    icon: "🚀",
  },
  {
    id: 2,
    title: "Experience Design",
    description:
      "Craft human-centered products and services that elevate engagement across channels.",
    icon: "🎨",
  },
  {
    id: 3,
    title: "Data Intelligence",
    description:
      "Unlock actionable insights through advanced analytics, data engineering, and AI integration.",
    icon: "📊",
  },
];

const processSteps = [
  {
    step: "01",
    title: "Discover",
    text: "Align on goals, capture insights, and model opportunities with stakeholders.",
  },
  {
    step: "02",
    title: "Design",
    text: "Prototype bold solutions rooted in user needs and validate at speed.",
  },
  {
    step: "03",
    title: "Deliver",
    text: "Engineer scalable platforms blending agility, security, and performance.",
  },
  {
    step: "04",
    title: "Evolve",
    text: "Continuously optimize and expand value through data-led decisioning.",
  },
];

const testimonials = [
  {
    id: 1,
    quote:
      "The team translated complexity into clarity, delivering a platform that transformed customer experiences overnight.",
    name: "Sophia Martinez",
    role: "Chief Customer Officer, FutureBank",
  },
  {
    id: 2,
    quote:
      "Their hybrid delivery model accelerated our roadmap by 6 months while reducing risk and cost.",
    name: "Liam Chen",
    role: "VP of Product, NovaTech",
  },
  {
    id: 3,
    quote:
      "Incredible partnership. They brought strategic foresight coupled with highly skilled execution.",
    name: "Amelia Johnson",
    role: "CEO, Horizon Retail Group",
  },
];

const teamMembers = [
  {
    id: 1,
    name: "Ava Reynolds",
    role: "Managing Partner",
    expertise: "Transformation Strategy",
    image: "https://picsum.photos/400/400?random=31",
  },
  {
    id: 2,
    name: "Noah Patel",
    role: "Chief Technology Officer",
    expertise: "Cloud & Automation",
    image: "https://picsum.photos/400/400?random=32",
  },
  {
    id: 3,
    name: "Isabella Gomez",
    role: "Head of Design",
    expertise: "Human-Centered Experiences",
    image: "https://picsum.photos/400/400?random=33",
  },
];

const projectData = [
  {
    id: 1,
    title: "Global Loyalty Platform",
    category: "Experience",
    image: "https://picsum.photos/1200/800?random=41",
  },
  {
    id: 2,
    title: "Intelligent Supply Chain",
    category: "Transformation",
    image: "https://picsum.photos/1200/800?random=42",
  },
  {
    id: 3,
    title: "Insight Command Center",
    category: "Data",
    image: "https://picsum.photos/1200/800?random=43",
  },
  {
    id: 4,
    title: "Digital Operations Hub",
    category: "Transformation",
    image: "https://picsum.photos/1200/800?random=44",
  },
  {
    id: 5,
    title: "Omnichannel Experience",
    category: "Experience",
    image: "https://picsum.photos/1200/800?random=45",
  },
];

const faqItems = [
  {
    question: "How do you typically engage with new clients?",
    answer:
      "We begin with a collaborative discovery sprint to align on business objectives, success metrics, delivery constraints, and user analysis. This forms the foundation of a bespoke engagement roadmap.",
  },
  {
    question: "What industries do you specialize in?",
    answer:
      "Our cross-functional teams have deep expertise in financial services, technology, healthcare, retail, and energy. Multi-industry insights help us deliver differentiated solutions.",
  },
  {
    question: "How is success measured?",
    answer:
      "We define performance indicators jointly with stakeholders, ensuring each initiative is tracked through operational dashboards, user satisfaction metrics, and ROI outcomes.",
  },
];

const blogPosts = [
  {
    id: 1,
    title: "The Future of Data-Driven Decisioning",
    date: "July 10, 2024",
    description:
      "Explore how AI and real-time analytics reshape enterprise decisions and unlock new customer value.",
  },
  {
    id: 2,
    title: "Reimagining Service Design for Hybrid Experiences",
    date: "June 28, 2024",
    description:
      "Designing adaptive, inclusive experiences that bridge the digital and physical worlds seamlessly.",
  },
  {
    id: 3,
    title: "Modernizing Legacy Systems Without Disruption",
    date: "June 12, 2024",
    description:
      "A pragmatic approach to evolve critical infrastructure while maintaining resilience and uptime.",
  },
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState("All");
  const [expandedFAQ, setExpandedFAQ] = useState(null);
  const [stats, setStats] = useState(statsData.map(() => 0));

  const filteredProjects = useMemo(() => {
    if (activeCategory === "All") return projectData;
    return projectData.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) =>
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let frame: number;
    const duration = 1600;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      setStats(
        statsData.map(({ value }) => Math.floor(value * progress))
      );
      if (progress < 1) {
        frame = requestAnimationFrame(animate);
      }
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  return (
    <div className="home">
      <section className="hero">
        <div className="container hero__inner">
          <div className="hero__content">
            <span className="hero__eyebrow">Strategic Digital Consultancy</span>
            <h1>
              Igniting the next era of{" "}
              <span className="highlight">business growth</span>
            </h1>
            <p>
              We partner with visionary leaders to design transformative
              strategies, craft remarkable experiences, and deploy technology
              that moves markets.
            </p>
            <div className="hero__actions">
              <NavLink to="/contact" className="btn btn--primary">
                Book a Consultation
              </NavLink>
              <a href="#projects" className="btn btn--ghost">
                View our portfolio
              </a>
            </div>
            <div className="hero__stats">
              {statsData.map((stat, index) => (
                <div key={stat.id} className="hero__stat">
                  <span className="hero__stat-value">
                    {stats[index]}
                    {stat.label === "Client Satisfaction" ? "%" : "+"}
                  </span>
                  <span className="hero__stat-label">{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="hero__media">
            <div className="hero__image-wrapper">
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Business leaders collaborating in a modern office."
                className="hero__image"
                loading="lazy"
              />
              <div className="hero__badge">
                <span>Top 1% Consultancy</span>
                <small>Rated by Global Innovation Index</small>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="services" id="services">
        <div className="container">
          <div className="section-header">
            <span className="section-eyebrow">Our Specialism</span>
            <h2>Integrated services that accelerate transformation</h2>
            <p>
              Tailored-to-fit approaches designed to orchestrate meaningful
              change at every stage of the customer and enterprise journey.
            </p>
          </div>
          <div className="services__grid">
            {servicesData.map((service) => (
              <article key={service.id} className="service-card">
                <div className="service-card__icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <NavLink to="/services" className="service-card__link">
                  Discover more →
                </NavLink>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process">
        <div className="container process__grid">
          <div className="process__intro">
            <span className="section-eyebrow">How We Work</span>
            <h2>Our approach delivers value from day one</h2>
            <p>
              A proven, collaborative framework engineered to balance creative
              ambition with operational excellence and measurable outcomes.
            </p>
            <NavLink to="/about" className="btn btn--primary">
              Learn about our methodology
            </NavLink>
          </div>
          <div className="process__steps">
            {processSteps.map((step) => (
              <div key={step.step} className="process-step">
                <span className="process-step__number">{step.step}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container">
          <div className="section-header">
            <span className="section-eyebrow">Client Success</span>
            <h2>Trusted by ambitious leaders worldwide</h2>
          </div>
          <div className="testimonial-card">
            <p className="testimonial-card__quote">
              “{testimonials[activeTestimonial].quote}”
            </p>
            <div className="testimonial-card__author">
              <h4>{testimonials[activeTestimonial].name}</h4>
              <span>{testimonials[activeTestimonial].role}</span>
            </div>
            <div className="testimonial-card__dots">
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.id}
                  className={`dot ${
                    index === activeTestimonial ? "active" : ""
                  }`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`View testimonial from ${testimonial.name}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team">
        <div className="container">
          <div className="section-header">
            <span className="section-eyebrow">Leadership</span>
            <h2>Multi-disciplinary experts guiding every engagement</h2>
            <p>
              Our team blends strategic consulting, design innovation, and
              engineering mastery to ensure holistic impact.
            </p>
          </div>
          <div className="team__grid">
            {teamMembers.map((member) => (
              <article key={member.id} className="team-card">
                <div className="team-card__media">
                  <img
                    src={member.image}
                    alt={`${member.name}, ${member.role}`}
                    loading="lazy"
                  />
                </div>
                <div className="team-card__content">
                  <h3>{member.name}</h3>
                  <span className="team-card__role">{member.role}</span>
                  <p>{member.expertise}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container">
          <div className="section-header">
            <span className="section-eyebrow">Recent Work</span>
            <h2>Signature projects redefining their industries</h2>
          </div>
          <div className="projects__filters">
            {["All", "Transformation", "Experience", "Data"].map((category) => (
              <button
                key={category}
                className={`btn btn--filter ${
                  activeCategory === category ? "is-active" : ""
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects__grid">
            {filteredProjects.map((project) => (
              <article key={project.id} className="project-card">
                <div className="project-card__image-wrapper">
                  <img
                    src={project.image}
                    alt={`Project case study: ${project.title}`}
                    loading="lazy"
                  />
                </div>
                <div className="project-card__content">
                  <span className="project-card__category">
                    {project.category}
                  </span>
                  <h3>{project.title}</h3>
                  <NavLink to="/services" className="project-card__link">
                    Explore case study →
                  </NavLink>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-blog">
        <div className="container faq-blog__grid">
          <div className="faq">
            <span className="section-eyebrow">FAQ</span>
            <h2>Answers that help you get started faster</h2>
            <div className="faq__list">
              {faqItems.map((item, index) => (
                <div key={item.question} className="faq__item">
                  <button
                    className="faq__question"
                    onClick={() =>
                      setExpandedFAQ(expandedFAQ === index ? null : index)
                    }
                    aria-expanded={expandedFAQ === index}
                  >
                    {item.question}
                    <span>{expandedFAQ === index ? "−" : "+"}</span>
                  </button>
                  {expandedFAQ === index && (
                    <p className="faq__answer">{item.answer}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="blog">
            <span className="section-eyebrow">Insights</span>
            <h2>Latest thinking from our experts</h2>
            <div className="blog__list">
              {blogPosts.map((post) => (
                <article key={post.id} className="blog-card">
                  <h3>{post.title}</h3>
                  <span className="blog-card__date">{post.date}</span>
                  <p>{post.description}</p>
                  <a href="#!" className="blog-card__link">
                    Read article →
                  </a>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container cta__content">
          <div>
            <span className="section-eyebrow">Ready to Accelerate?</span>
            <h2>
              Let’s co-create the next chapter of your organization’s growth.
            </h2>
            <p>
              Partner with us to unlock new value, reinvent experiences, and
              build resilient, future-proof capabilities.
            </p>
          </div>
          <NavLink to="/contact" className="btn btn--light">
            Schedule discovery call
          </NavLink>
        </div>
      </section>
    </div>
  );
};

export default Home;