import React from "react";

const serviceOfferings = [
  {
    title: "Strategy & Operating Model",
    description:
      "End-to-end advisory across market positioning, capability design, and organizational alignment to unlock long-term value.",
    points: [
      "Growth blueprint creation",
      "Enterprise architecture & roadmap",
      "Change management & enablement",
    ],
  },
  {
    title: "Experience Innovation",
    description:
      "Design and prototype future-state experiences that elevate customer journeys across digital and physical touchpoints.",
    points: [
      "Customer research & insights",
      "Service & product design sprints",
      "Design systems & prototyping",
    ],
  },
  {
    title: "Technology Platforms",
    description:
      "Build and integrate cloud-native ecosystems, microservices, and automations that scale with evolving business needs.",
    points: [
      "Cloud migration & modernization",
      "API & integration strategy",
      "DevOps & continuous delivery",
    ],
  },
  {
    title: "Data, AI & Analytics",
    description:
      "Leverage data as a competitive asset with robust pipelines, governance, and advanced analytics powered by AI.",
    points: [
      "Data platform engineering",
      "Predictive & prescriptive analytics",
      "Responsible AI implementation",
    ],
  },
];

const Services = () => {
  return (
    <div className="page services">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Services</span>
          <h1>Designed to reinvent, engineered to deliver</h1>
          <p>
            We integrate strategy, design, and technology within an adaptive
            delivery model. Our teams move with precision, unlocking value from
            discovery through continuous optimization.
          </p>
        </div>
      </section>

      <section className="service-offerings">
        <div className="container">
          <div className="service-offerings__grid">
            {serviceOfferings.map((service) => (
              <article key={service.title} className="offering-card">
                <div className="offering-card__head">
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                </div>
                <ul>
                  {service.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
                <button className="offering-card__cta">
                  Schedule a capabilities deep-dive →
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="service-highlight">
        <div className="container service-highlight__grid">
          <div>
            <h2>Integrated delivery pods</h2>
            <p>
              Our cross-disciplinary pods unite strategists, designers,
              engineers, and data scientists into a cohesive unit aligned with
              client objectives. We operate with transparent governance,
              measurable KPIs, and iterative delivery to maximize velocity and
              minimize risk.
            </p>
            <ul className="service-highlight__list">
              <li>Embedded product owners</li>
              <li>Continuous discovery & validation</li>
              <li>Outcome-based contracting options</li>
            </ul>
          </div>
          <div className="service-highlight__card">
            <h3>Engagement models</h3>
            <p>
              Whether you need targeted expertise or full-scale transformation,
              we tailor engagement models for optimal impact.
            </p>
            <ul>
              <li>Strategic advisory retainers</li>
              <li>Delivery acceleration squads</li>
              <li>Managed product services</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;