import React from "react";

const Terms = () => {
  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Legal</span>
          <h1>Terms & Conditions</h1>
          <p>Effective date: May 1, 2024</p>
        </div>
      </section>
      <section className="legal__content container narrow">
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing or using the CompanyName website, services, or digital
          products, you agree to comply with and be bound by these Terms of
          Use. If you do not agree to these terms, please refrain from using our
          services.
        </p>

        <h2>2. Use of Services</h2>
        <p>
          You agree to use our services only for lawful purposes. You are
          prohibited from violating or attempting to violate the security of the
          site or using it to infringe upon the rights of others.
        </p>

        <h2>3. Intellectual Property</h2>
        <p>
          All content, features, and functionality available through the site
          are owned by CompanyName and are protected by international copyright,
          trademark, patent, and other intellectual property laws.
        </p>

        <h2>4. Limitation of Liability</h2>
        <p>
          CompanyName shall not be liable for any indirect, incidental,
          consequential, or punitive damages arising from your use of our
          services.
        </p>

        <h2>5. Changes to Terms</h2>
        <p>
          We reserve the right to modify these Terms at any time. Material
          changes will be communicated through the website with an updated
          effective date.
        </p>

        <h2>6. Contact</h2>
        <p>
          For questions regarding these Terms, contact us at legal@companyname.co.
        </p>
      </section>
    </div>
  );
};

export default Terms;