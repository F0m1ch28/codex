import React from "react";

const Privacy = () => {
  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Legal</span>
          <h1>Privacy Policy</h1>
          <p>Effective date: May 1, 2024</p>
        </div>
      </section>
      <section className="legal__content container narrow">
        <h2>1. Overview</h2>
        <p>
          This Privacy Policy describes how CompanyName collects, uses, and
          shares your personal information when you interact with our services.
        </p>

        <h2>2. Information We Collect</h2>
        <p>
          We collect personal information you provide directly (such as contact
          details) and data gathered automatically (such as usage statistics)
          through cookies and analytics.
        </p>

        <h2>3. Use of Information</h2>
        <p>
          We use your information to deliver services, respond to inquiries,
          improve experiences, and communicate updates or marketing materials
          aligned with preferences.
        </p>

        <h2>4. Data Protection</h2>
        <p>
          We implement physical, technical, and administrative safeguards to
          protect your data against unauthorized access, alteration, or
          disclosure.
        </p>

        <h2>5. Your Rights</h2>
        <p>
          Depending on your jurisdiction, you may have the right to access,
          correct, or delete personal data. Submit requests to privacy@companyname.co.
        </p>

        <h2>6. Cookies</h2>
        <p>
          Cookies enhance site performance and personalize experiences. You can
          control cookies through browser settings. Declining cookies may limit
          certain site functionality.
        </p>

        <h2>7. Changes to Policy</h2>
        <p>
          We may update this policy periodically. Material changes will be
          communicated via the website with an updated effective date.
        </p>

        <h2>8. Contact</h2>
        <p>
          For privacy-related inquiries, please contact privacy@companyname.co.
        </p>
      </section>
    </div>
  );
};

export default Privacy;