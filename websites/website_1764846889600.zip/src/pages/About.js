import React from "react";

const About = () => {
  return (
    <div className="page about">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">About Us</span>
          <h1>We build bold strategies for a complex world</h1>
          <p>
            CompanyName is a global collective of strategists, designers,
            engineers, and data scientists dedicated to powering growth for
            progressive organizations. Since our founding, we’ve led change for
            clients across 14 countries, reimagining their operations with
            precision and creativity.
          </p>
        </div>
      </section>

      <section className="mission">
        <div className="container narrow">
          <h2>Our Mission</h2>
          <p>
            To help leaders harness disruption as a catalyst for progress. We
            translate ambition into actionable roadmaps, align people around a
            shared vision, and deliver measurable business outcomes through
            technology and design that scale.
          </p>
        </div>
      </section>

      <section className="values">
        <div className="container">
          <h2>Values that shape every engagement</h2>
          <div className="values__grid">
            <article>
              <h3>Integrity & Trust</h3>
              <p>
                We build transparent partnerships, grounded in clarity,
                candor, and shared accountability.
              </p>
            </article>
            <article>
              <h3>Inventive Thinking</h3>
              <p>
                Our curiosity drives breakthrough ideas. We experiment, learn,
                iterate, and deliver original solutions.
              </p>
            </article>
            <article>
              <h3>Inclusive Collaboration</h3>
              <p>
                Diversity of thought is our superpower. We unite global talent
                to co-create with clients as one team.
              </p>
            </article>
            <article>
              <h3>Measured Impact</h3>
              <p>
                We obsess over outcomes. Each initiative is anchored in data,
                ROI, and sustainable change.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="about-media">
        <div className="container about-media__grid">
          <div className="about-media__text">
            <h2>Global reach with boutique precision</h2>
            <p>
              With hubs in San Francisco, London, Singapore, and Toronto, we
              deliver on-the-ground expertise while tapping into a global
              network of specialists. Clients trust us to navigate complex
              regulations, scale across markets, and localize experiences with
              empathy and cultural fluency.
            </p>
            <p>
              We embed with teams, break silos, and bring clarity to the most
              complex challenges. Our hybrid delivery model ensures momentum,
              transparency, and agility from strategy through to execution.
            </p>
          </div>
          <div className="about-media__image">
            <img
              src="https://picsum.photos/800/600?random=21"
              alt="Team strategy workshop in a modern workspace."
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="about-impact">
        <div className="container narrow">
          <h2>Impact highlights</h2>
          <ul className="about-impact__list">
            <li>
              Catalyzed a Fortune 100 transformation that yielded $400M in
              incremental revenue within 18 months.
            </li>
            <li>
              Built an AI-driven insights hub for a healthcare network,
              reducing administrative load by 37%.
            </li>
            <li>
              Designed customer journeys that improved retention by 22% for a
              global fintech leader.
            </li>
            <li>
              Stabilized and modernized mission-critical infrastructure for a
              multinational energy provider.
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default About;