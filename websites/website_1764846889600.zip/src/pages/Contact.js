import React, { useState } from "react";

const initialFormState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Please enter your name.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email.";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)
    ) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!formData.company.trim()) {
      newErrors.company = "Please provide your company.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Please tell us about your initiative.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validateForm()) {
      setSubmitted(true);
      setFormData(initialFormState);
    }
  };

  return (
    <div className="page contact">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Contact</span>
          <h1>Let’s build the future of your business together</h1>
          <p>
            Share your ambitions and challenges. Our team will return your
            message within one business day to explore alignment.
          </p>
        </div>
      </section>

      <section className="contact-form">
        <div className="container contact-form__grid">
          <form className="form" onSubmit={handleSubmit} noValidate>
            <div className="form__group">
              <label htmlFor="name">Name*</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className="form__error">{errors.name}</span>}
            </div>
            <div className="form__group">
              <label htmlFor="email">Email*</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && (
                <span className="form__error">{errors.email}</span>
              )}
            </div>
            <div className="form__group">
              <label htmlFor="company">Company*</label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                aria-invalid={Boolean(errors.company)}
              />
              {errors.company && (
                <span className="form__error">{errors.company}</span>
              )}
            </div>
            <div className="form__group">
              <label htmlFor="message">Project Details*</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && (
                <span className="form__error">{errors.message}</span>
              )}
            </div>
            <button type="submit" className="btn btn--primary">
              Submit inquiry
            </button>
            {submitted && (
              <p className="form__success">
                Thank you for reaching out. We’ll connect with you shortly.
              </p>
            )}
          </form>
          <aside className="contact-info">
            <h2>Direct contact</h2>
            <p>Prefer a direct conversation? Reach out to our engagement team.</p>
            <ul>
              <li>
                <strong>Email:</strong> hello@companyname.co
              </li>
              <li>
                <strong>Phone:</strong> +1 (555) 123-4567
              </li>
              <li>
                <strong>Office:</strong> 500 Innovation Drive, Suite 120, San
                Francisco, CA 94107
              </li>
            </ul>
            <h3>Office hours</h3>
            <p>Monday – Friday, 8:30AM – 6:30PM PST</p>
          </aside>
        </div>
      </section>
    </div>
  );
};

export default Contact;