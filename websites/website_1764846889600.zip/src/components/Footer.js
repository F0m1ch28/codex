import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__column">
          <div className="footer__logo">
            <span className="footer__logo-mark">[C]</span>
            <span className="footer__logo-text">CompanyName</span>
          </div>
          <p className="footer__description">
            Transforming visions into measurable outcomes through strategic
            consultation, human-centered design, and advanced technology
            delivery.
          </p>
        </div>
        <div className="footer__column">
          <h4 className="footer__title">Company</h4>
          <ul className="footer__list">
            <li>
              <NavLink to="/about">About</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Contact</NavLink>
            </li>
            <li>
              <NavLink to="/terms">Terms</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Privacy</NavLink>
            </li>
          </ul>
        </div>
        <div className="footer__column">
          <h4 className="footer__title">Contact</h4>
          <ul className="footer__list footer__list--contact">
            <li>hello@companyname.co</li>
            <li>+1 (555) 123-4567</li>
            <li>500 Innovation Drive, Suite 120</li>
            <li>San Francisco, CA 94107</li>
          </ul>
        </div>
        <div className="footer__column">
          <h4 className="footer__title">Newsletter</h4>
          <p>Stay ahead with curated insights and exclusive updates.</p>
          <form className="footer__form">
            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              aria-label="Newsletter email"
              required
            />
            <button type="submit">Subscribe</button>
          </form>
        </div>
      </div>
      <div className="footer__bottom">
        <p>© {currentYear} CompanyName. All rights reserved.</p>
        <div className="footer__socials">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
            LinkedIn
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
            Twitter
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noreferrer">
            Instagram
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;