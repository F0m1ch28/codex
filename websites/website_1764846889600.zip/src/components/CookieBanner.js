import React, { useState, useEffect } from "react";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("cookie-consent", "accepted");
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem("cookie-consent", "declined");
    setIsVisible(false);
  };

  if (!isVisible) return null;
  return (
    <div className="cookie-banner">
      <div className="cookie-banner__content">
        <p>
          We use cookies to personalize content, enhance experiences, and
          analyse traffic. Read our{" "}
          <a href="/privacy" className="cookie-banner__link">
            privacy policy
          </a>{" "}
          for details.
        </p>
        <div className="cookie-banner__actions">
          <button onClick={handleDecline} className="btn btn--ghost">
            Decline
          </button>
          <button onClick={handleAccept} className="btn btn--primary">
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;