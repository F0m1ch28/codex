import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={`header ${scrolled ? "header--scrolled" : ""}`}>
      <div className="container header__inner">
        <div className="header__brand">
          <NavLink to="/" className="header__logo">
            <span className="header__logo-mark">[C]</span>
            <span className="header__logo-text">CompanyName</span>
          </NavLink>
        </div>
        <nav className={`header__nav ${isMenuOpen ? "is-open" : ""}`}>
          <NavLink to="/" end className="header__link">
            Home
          </NavLink>
          <NavLink to="/about" className="header__link">
            About
          </NavLink>
          <NavLink to="/services" className="header__link">
            Services
          </NavLink>
          <NavLink to="/contact" className="header__link">
            Contact
          </NavLink>
        </nav>
        <button
          className={`header__burger ${isMenuOpen ? "is-active" : ""}`}
          onClick={() => setIsMenuOpen((prev) => !prev)}
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;