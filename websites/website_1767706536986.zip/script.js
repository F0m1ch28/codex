document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navList = document.querySelector(".nav-list");
    if (navToggle && navList) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navList.classList.toggle("open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");
    const consentKey = "lotlboCookieConsent";

    function hideBanner(value) {
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
        localStorage.setItem(consentKey, value);
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.add("active");
        }
        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => hideBanner("accepted"));
        }
        if (declineBtn) {
            declineBtn.addEventListener("click", () => hideBanner("declined"));
        }
    }

    const contactForm = document.querySelector("#contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            const requiredFields = contactForm.querySelectorAll("[data-required]");
            let hasError = false;

            requiredFields.forEach((field) => {
                const errorEl = field.parentElement.querySelector(".form-error");
                if (errorEl) {
                    errorEl.textContent = "";
                }
                if (!field.value.trim()) {
                    hasError = true;
                    if (errorEl) {
                        errorEl.textContent = "This field is required.";
                    }
                } else if (field.type === "email") {
                    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailPattern.test(field.value.trim())) {
                        hasError = true;
                        if (errorEl) {
                            errorEl.textContent = "Enter a valid email address.";
                        }
                    }
                }
            });

            if (hasError) {
                event.preventDefault();
            }
        });
    }
});