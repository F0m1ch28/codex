const navToggle = document.querySelector('.nav-toggle');
const navbar = document.querySelector('.navbar');
const cookieBanner = document.querySelector('.cookie-banner');
const acceptBtn = document.querySelector('.cookie-accept');
const declineBtn = document.querySelector('.cookie-decline');

if (navToggle && navbar) {
    navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navbar.classList.toggle('open');
    });

    navbar.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navToggle.classList.remove('active');
            navbar.classList.remove('open');
        });
    });
}

const COOKIE_STORAGE_KEY = 'insidenzgr_cookie_consent';

function showCookieBanner() {
    if (!cookieBanner) return;
    const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!stored) {
        cookieBanner.classList.add('active');
    }
}

function setCookiePreference(choice) {
    localStorage.setItem(COOKIE_STORAGE_KEY, choice);
    cookieBanner.classList.remove('active');
}

if (cookieBanner) {
    acceptBtn?.addEventListener('click', () => {
        setCookiePreference('accepted');
        window.open('cookies.html', '_blank');
    });

    declineBtn?.addEventListener('click', () => {
        setCookiePreference('declined');
        window.open('cookies.html#declined', '_blank');
    });

    document.addEventListener('DOMContentLoaded', showCookieBanner);
}