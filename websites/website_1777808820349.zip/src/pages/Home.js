import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Hero from "../components/Hero";
import Card from "../components/Card";
import ComparisonTable from "../components/ComparisonTable";
import FAQ from "../components/FAQ";
import ReviewCard from "../components/ReviewCard";
import {
  casinos,
  faqItems,
  testimonials,
  teamMembers,
  projects,
  blogPosts,
  processSteps,
  statsData
} from "../data/casinos";
import styles from "./Home.module.css";

const Home = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const statsRef = useRef(null);
  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("Все");

  useEffect(() => {
    const target =
      location.state?.scrollTo ||
      (location.hash ? location.hash.replace("#", "") : null);
    if (target) {
      const element = document.getElementById(target);
      if (element) {
        setTimeout(
          () => element.scrollIntoView({ behavior: "smooth", block: "start" }),
          200
        );
      }
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location, navigate]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !statsAnimated) {
          setStatsAnimated(true);
        }
      },
      { threshold: 0.4 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, [statsAnimated]);

  useEffect(() => {
    if (!statsAnimated) return;
    const duration = 1400;
    const steps = 50;
    const interval = duration / steps;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep += 1;
      setStatValues(
        statsData.map((item) =>
          Math.round((item.value * currentStep) / steps)
        )
      );
      if (currentStep >= steps) {
        clearInterval(timer);
        setStatValues(statsData.map((item) => item.value));
      }
    }, interval);

    return () => clearInterval(timer);
  }, [statsAnimated]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === "Все") return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  return (
    <div className={styles.page}>
      <Hero
        title="Экспертные обзоры международных казино"
        subtitle="Сравниваем бонусы, анализируем условия, оцениваем скорость выплат и инструменты ответственной игры. Помогаем выбрать честное казино с прозрачными правилами."
        ctaText="Перейти к сравнению"
        highlight="Премиальная аналитика"
        onCtaClick={() => navigate("/compare")}
      />

      <section className={styles.statsSection} ref={statsRef}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Цифры TopGambling</span>
          <h2>Данные, которым доверяют профессионалы</h2>
          <p>
            Мы постоянно расширяем базу проверенных казино и публикуем свежие
            аналитические обзоры для игроков и индустриальных экспертов.
          </p>
        </div>
        <div className={styles.statsGrid}>
          {statsData.map((item, index) => (
            <div className={styles.statCard} key={item.label}>
              <span className={styles.statValue}>
                {statValues[index]}
                {item.suffix}
              </span>
              <span className={styles.statLabel}>{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.reviewsSection} id="reviews">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Выбор редакции</span>
          <h2>Топовые казино недели</h2>
          <p>
            Подборка площадок с лучшим балансом бонусов, лицензирования и
            программы ответственного гэмблинга. Обновляется каждую неделю.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          {casinos.slice(0, 6).map((casino) => (
            <Card key={casino.id} casino={casino} />
          ))}
        </div>
      </section>

      <section className={styles.comparisonSection} id="comparison">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Сравнение условий</span>
          <h2>Сводная таблица ключевых параметров</h2>
          <p>
            Быстро сравните бонусы, вейджер, платежные методы и типы игр.
            Подробный инструмент сортировки доступен на странице сравнения.
          </p>
        </div>
        <ComparisonTable data={casinos.slice(0, 4)} />
        <button
          className={styles.moreButton}
          onClick={() => navigate("/compare")}
        >
          Смотреть полное сравнение
        </button>
      </section>

      <section className={styles.processSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Методология</span>
          <h2>Как мы готовим обзоры казино</h2>
          <p>
            Стандартизированный процесс проверки помогает сохранять объективность
            и выявлять сильные и слабые стороны каждого бренда.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <div className={styles.processCard} key={step.title}>
              <span className={styles.stepNumber}>
                {String(index + 1).padStart(2, "0")}
              </span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonialSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Мнения специалистов</span>
          <h2>Почему индустрия доверяет TopGambling</h2>
          <p>
            Эксперты рынка отмечают глубину аналитики, прозрачность оценок и
            акцент на ответственное отношение к игре.
          </p>
        </div>
        <div className={styles.testimonialCarousel}>
          {testimonials.map((review, index) => (
            <ReviewCard
              key={review.name}
              review={review}
              active={index === currentTestimonial}
            />
          ))}
        </div>
        <div className={styles.carouselDots} role="tablist">
          {testimonials.map((_, index) => (
            <button
              key={index}
              className={`${styles.carouselDot} ${
                currentTestimonial === index ? styles.dotActive : ""
              }`}
              onClick={() => setCurrentTestimonial(index)}
              aria-label={`Перейти к отзыву ${index + 1}`}
            />
          ))}
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Команда</span>
          <h2>Эксперты TopGambling</h2>
          <p>
            Международная команда аналитиков, консультантов по ответственному
            гэмблингу и контент-редакторов.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article className={styles.teamCard} key={member.name}>
              <div className={styles.teamImage}>
                <img src={member.image} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
                <div className={styles.expertise}>
                  {member.expertise.map((item) => (
                    <span key={item}>{item}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Проекты</span>
          <h2>Исследования и аналитические отчёты</h2>
          <p>
            Углублённые исследования рынка, которые помогают брендам и игрокам
            принимать стратегические решения.
          </p>
        </div>
        <div className={styles.projectFilters}>
          {["Все", "Аналитика", "Мобильный рынок", "VIP", "Крипто"].map(
            (category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${
                  projectFilter === category ? styles.filterActive : ""
                }`}
                onClick={() => setProjectFilter(category)}
              >
                {category}
              </button>
            )
          )}
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article className={styles.projectCard} key={project.id}>
              <div className={styles.projectImage}>
                <img
                  src={project.image}
                  alt={project.title}
                  loading="lazy"
                />
              </div>
              <div className={styles.projectBody}>
                <span className={styles.projectCategory}>
                  {project.category}
                </span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>FAQ</span>
          <h2>Часто задаваемые вопросы</h2>
          <p>
            Ответы на ключевые вопросы об аналитике казино, бонусах и
            инструментах ответственной игры.
          </p>
        </div>
        <FAQ items={faqItems} />
      </section>

      <section className={styles.blogSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Блог</span>
          <h2>Последние публикации</h2>
          <p>
            Авторские материалы и гайды по выбору казино, бонусным стратегиям и
            ответственному подходу.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article className={styles.blogCard} key={post.id}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogBody}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <button
                  className={styles.blogButton}
                  onClick={() => navigate("/services")}
                >
                  Читать далее
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Нужна персональная консультация?</h2>
          <p>
            Подготовим сравнение под вашу целевую аудиторию, выстроим стратегию
            бонусов или поможем внедрить инструменты ответственной игры.
          </p>
          <button
            className={styles.ctaButton}
            onClick={() => navigate("/contact")}
          >
            Связаться с командой
          </button>
        </div>
      </section>
    </div>
  );
};

export default Home;