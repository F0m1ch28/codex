import { useMemo } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { casinos } from "../data/casinos";
import styles from "./CasinoReview.module.css";

const CasinoReview = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const casino = useMemo(
    () => casinos.find((item) => item.id === id),
    [id]
  );

  if (!casino) {
    return (
      <div className={styles.notFound}>
        <h1>Обзор не найден</h1>
        <p>Мы не нашли казино с таким идентификатором.</p>
        <button onClick={() => navigate("/")} className={styles.backButton}>
          На главную
        </button>
      </div>
    );
  }

  return (
    <article className={styles.page}>
      <header className={styles.hero}>
        <img src={casino.heroImage} alt={casino.name} />
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <span className={styles.badge}>Рейтинг {casino.rating.toFixed(1)} / 5</span>
          <h1>{casino.name}</h1>
          <p>{casino.description}</p>
          <div className={styles.heroMeta}>
            <span>Лицензия: {casino.license}</span>
            <span>Основано: {casino.established}</span>
            <span>Поддержка: {casino.support}</span>
          </div>
        </div>
      </header>

      <section className={styles.section}>
        <h2>Бонус и условия</h2>
        <div className={styles.bonusBox}>
          <div>
            <h3>Приветственный бонус</h3>
            <p>{casino.bonus}</p>
            <span className={styles.bonusSummary}>{casino.bonusSummary}</span>
          </div>
          <ul>
            <li>
              <strong>Вейджер:</strong> {casino.wagering}
            </li>
            <li>
              <strong>Мин. депозит:</strong> {casino.minDeposit}
            </li>
            <li>
              <strong>Макс. вывод:</strong> {casino.maxCashout}
            </li>
            <li>
              <strong>Методы:</strong> {casino.paymentMethods.join(", ")}
            </li>
          </ul>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Преимущества и ограничения</h2>
        <div className={styles.flexGrid}>
          <div className={styles.listCard}>
            <h3>Плюсы</h3>
            <ul>
              {casino.pros.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div className={styles.listCard}>
            <h3>Минусы</h3>
            <ul>
              {casino.cons.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Игровой портфель и провайдеры</h2>
        <div className={styles.gridTwo}>
          <div className={styles.infoCard}>
            <h3>Основные категории</h3>
            <p>{casino.games.join(", ")}</p>
          </div>
          <div className={styles.infoCard}>
            <h3>Поддерживаемые валюты</h3>
            <p>{casino.currencies.join(", ")}</p>
          </div>
          <div className={styles.infoCard}>
            <h3>Интерфейсы</h3>
            <p>{casino.languages.join(", ")}</p>
          </div>
          <div className={styles.infoCard}>
            <h3>Ответственная игра</h3>
            <p>
              Лимиты депозитов, охлаждение, самоисключение, контроль времени.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Ключевые особенности</h2>
        <div className={styles.featuresGrid}>
          {casino.features.map((feature) => (
            <div className={styles.featureCard} key={feature.title}>
              <h3>{feature.title}</h3>
              <p>{feature.detail}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2>Доступность и ограничения</h2>
        <div className={styles.restrictions}>
          <div>
            <h3>Запрещённые страны</h3>
            <p>{casino.restricted.join(", ") || "Нет ограничений"}</p>
          </div>
          <div>
            <h3>Регистрация и KYC</h3>
            <p>
              Проверка документов обязательна перед выводом средств. Казино
              поддерживает верификацию в течение 24-48 часов.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Быстрые ссылки</h2>
        <div className={styles.links}>
          <Link to="/compare">Сравнить с другими казино</Link>
          <Link to="/">Вернуться на главную</Link>
          <Link to="/contact">Связаться с командой TopGambling</Link>
        </div>
      </section>
    </article>
  );
};

export default CasinoReview;