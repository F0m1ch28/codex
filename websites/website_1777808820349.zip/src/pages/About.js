import { teamMembers, projects } from "../data/casinos";
import styles from "./About.module.css";

const About = () => (
  <section className={styles.page}>
    <header className={styles.header}>
      <h1>О компании TopGambling</h1>
      <p>
        Мы объединяем экспертов, аналитиков и консультантов по ответственному
        гэмблингу, чтобы создавать объективные обзоры и сравнения онлайн-казино.
        Наша миссия — помогать игрокам делать осознанный выбор.
      </p>
    </header>

    <section className={styles.section}>
      <h2>Наш подход</h2>
      <div className={styles.grid}>
        <article>
          <h3>Аналитика и прозрачность</h3>
          <p>
            Каждое казино проходит 70+ параметров проверки: лицензии, бонусные
            условия, выплаты, поддержка, инструменты Responsible Gaming и
            репутация среди игроков.
          </p>
        </article>
        <article>
          <h3>Фокус на ответственную игру</h3>
          <p>
            Мы выделяем наличия лимитов, таймеров, самоисключения, оцениваем
            прозрачность верификации и скорость обработки запросов на вывод.
          </p>
        </article>
        <article>
          <h3>Международная команда</h3>
          <p>
            Эксперты TopGambling работают в Великобритании, Европе и Канаде,
            что позволяет учитывать требования разных регуляторов.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Команда</h2>
      <div className={styles.teamGrid}>
        {teamMembers.map((member) => (
          <article className={styles.teamCard} key={member.name}>
            <img src={member.image} alt={member.name} loading="lazy" />
            <div className={styles.info}>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.section}>
      <h2>Ключевые проекты</h2>
      <div className={styles.projects}>
        {projects.map((project) => (
          <article key={project.id} className={styles.projectCard}>
            <div className={styles.projectImage}>
              <img src={project.image} alt={project.title} loading="lazy" />
            </div>
            <div className={styles.projectInfo}>
              <span>{project.category}</span>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </section>
);

export default About;