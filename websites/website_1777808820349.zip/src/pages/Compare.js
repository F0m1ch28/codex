import { useMemo, useState } from "react";
import ComparisonTable from "../components/ComparisonTable";
import { casinos } from "../data/casinos";
import styles from "./Compare.module.css";

const Compare = () => {
  const [paymentFilter, setPaymentFilter] = useState("Все");
  const [sortKey, setSortKey] = useState("rating");
  const [sortOrder, setSortOrder] = useState("desc");

  const paymentOptions = useMemo(() => {
    const methods = new Set();
    casinos.forEach((casino) =>
      casino.paymentMethods.forEach((method) => methods.add(method))
    );
    return ["Все", ...Array.from(methods)];
  }, []);

  const sortedCasinos = useMemo(() => {
    let filtered = casinos;
    if (paymentFilter !== "Все") {
      filtered = casinos.filter((casino) =>
        casino.paymentMethods.includes(paymentFilter)
      );
    }
    const sorted = [...filtered].sort((a, b) => {
      if (sortKey === "rating") {
        return sortOrder === "asc"
          ? a.rating - b.rating
          : b.rating - a.rating;
      }
      if (sortKey === "wagering") {
        const parseMultiplier = (value) =>
          Number(value.replace(/[^\d]/g, "")) || 0;
        return sortOrder === "asc"
          ? parseMultiplier(a.wagering) - parseMultiplier(b.wagering)
          : parseMultiplier(b.wagering) - parseMultiplier(a.wagering);
      }
      if (sortKey === "minDeposit") {
        const parseAmount = (value) =>
          Number(value.replace(/[^\d.]/g, "")) || 0;
        return sortOrder === "asc"
          ? parseAmount(a.minDeposit) - parseAmount(b.minDeposit)
          : parseAmount(b.minDeposit) - parseAmount(a.minDeposit);
      }
      return 0;
    });
    return sorted;
  }, [paymentFilter, sortKey, sortOrder]);

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <h1>Сравнение онлайн-казино</h1>
        <p>
          Фильтруйте и сортируйте казино по ключевым критериям: рейтингам,
          вейджеру и минимальному депозиту. Все данные обновляются вручную
          командой TopGambling.
        </p>
      </header>

      <div className={styles.controls}>
        <div className={styles.controlGroup}>
          <label htmlFor="payment">Методы оплаты</label>
          <select
            id="payment"
            value={paymentFilter}
            onChange={(event) => setPaymentFilter(event.target.value)}
          >
            {paymentOptions.map((method) => (
              <option value={method} key={method}>
                {method}
              </option>
            ))}
          </select>
        </div>

        <div className={styles.controlGroup}>
          <label htmlFor="sortKey">Сортировка по</label>
          <select
            id="sortKey"
            value={sortKey}
            onChange={(event) => setSortKey(event.target.value)}
          >
            <option value="rating">Рейтинг</option>
            <option value="wagering">Вейджер</option>
            <option value="minDeposit">Мин. депозит</option>
          </select>
        </div>

        <div className={styles.controlGroup}>
          <label htmlFor="sortOrder">Порядок</label>
          <select
            id="sortOrder"
            value={sortOrder}
            onChange={(event) => setSortOrder(event.target.value)}
          >
            <option value="desc">По убыванию</option>
            <option value="asc">По возрастанию</option>
          </select>
        </div>
      </div>

      <ComparisonTable data={sortedCasinos} />
    </section>
  );
};

export default Compare;