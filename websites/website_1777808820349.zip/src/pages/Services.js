import styles from "./Services.module.css";

const services = [
  {
    title: "Комплексный аудит казино",
    description:
      "Полный аудит условий, UX, программы лояльности и инструментов ответственной игры с детальными рекомендациями.",
    deliverables: [
      "Checklist из 70 пунктов проверки",
      "Бенчмарк по рынку",
      "Роудмап улучшений"
    ],
    image: "https://picsum.photos/seed/service1/800/600"
  },
  {
    title: "Сравнение офферов под аудиторию",
    description:
      "Подбираем казино под конкретный профиль игрока или медиабайера, учитывая географию, методы оплаты и бонусы.",
    deliverables: [
      "Фильтрованные списки казино",
      "Матрица сравнений",
      "Рекомендации по старту"
    ],
    image: "https://picsum.photos/seed/service2/800/600"
  },
  {
    title: "Стратегия ответственного гэмблинга",
    description:
      "Помогаем казино внедрять инструменты Responsible Gaming, обучаем команды саппорта и создаём регламенты.",
    deliverables: [
      "Политики и гайды",
      "Обучение персонала",
      "Метрики мониторинга"
    ],
    image: "https://picsum.photos/seed/service3/800/600"
  }
];

const Services = () => (
  <section className={styles.page}>
    <header className={styles.header}>
      <h1>Услуги TopGambling</h1>
      <p>
        Мы работаем с операторами, affiliate-командами и игроками, которым
        требуется независимая аналитика и стратегические рекомендации.
      </p>
    </header>

    <div className={styles.servicesGrid}>
      {services.map((service) => (
        <article className={styles.serviceCard} key={service.title}>
          <div className={styles.imageWrapper}>
            <img src={service.image} alt={service.title} loading="lazy" />
          </div>
          <div className={styles.content}>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <div className={styles.deliverables}>
              <span>Что входит:</span>
              <ul>
                {service.deliverables.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
        </article>
      ))}
    </div>

    <section className={styles.cta}>
      <h2>Готовы обсудить ваш проект?</h2>
      <p>
        Напишите нам, и мы предложим формат сотрудничества, подходящий именно
        вам.
      </p>
      <a href="/contact">Перейти к контактам</a>
    </section>
  </section>
);

export default Services;