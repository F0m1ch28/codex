import { useState } from "react";
import styles from "./Contact.module.css";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    topic: "",
    message: "",
    consent: false
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Введите имя.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = "Укажите корректный email.";
    if (!formData.topic.trim()) newErrors.topic = "Выберите тему обращения.";
    if (formData.message.trim().length < 20)
      newErrors.message = "Сообщение должно содержать минимум 20 символов.";
    if (!formData.consent)
      newErrors.consent = "Подтвердите согласие на обработку данных.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData({
        name: "",
        email: "",
        topic: "",
        message: "",
        consent: false
      });
    }
  };

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <h1>Свяжитесь с TopGambling</h1>
        <p>
          Готовы обсудить сотрудничество, аудит или составление индивидуального
          списка казино? Оставьте заявку, и мы ответим в течение одного рабочего дня.
        </p>
      </header>

      <div className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              placeholder="Введите ваше имя"
              value={formData.name}
              onChange={handleChange}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@example.com"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="topic">Тема обращения</label>
            <select
              id="topic"
              name="topic"
              value={formData.topic}
              onChange={handleChange}
            >
              <option value="">Выберите тему</option>
              <option value="audit">Аудит казино</option>
              <option value="comparison">Сравнение офферов</option>
              <option value="responsible">Ответственная игра</option>
              <option value="media">Медиакит</option>
              <option value="other">Другое</option>
            </select>
            {errors.topic && <span className={styles.error}>{errors.topic}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              placeholder="Опишите задачу или задайте вопрос..."
              value={formData.message}
              onChange={handleChange}
            />
            {errors.message && (
              <span className={styles.error}>{errors.message}</span>
            )}
          </div>

          <label className={styles.checkbox}>
            <input
              type="checkbox"
              name="consent"
              checked={formData.consent}
              onChange={handleChange}
            />
            <span>
              Согласен на обработку персональных данных в соответствии с{" "}
              <a href="/privacy">Политикой конфиденциальности</a>.
            </span>
          </label>
          {errors.consent && (
            <span className={styles.error}>{errors.consent}</span>
          )}

          <button type="submit" className={styles.submit}>
            Отправить заявку
          </button>
          {submitted && (
            <div className={styles.success}>
              Спасибо! Мы связались с вами по указанному адресу электронной почты.
            </div>
          )}
        </form>

        <aside className={styles.sidebar}>
          <div className={styles.card}>
            <h3>Контактные данные</h3>
            <ul>
              <li>
                <strong>Адрес:</strong> 123 Gambling Street, London, UK
              </li>
              <li>
                <strong>Телефон:</strong> +44 20 1234 5678
              </li>
              <li>
                <strong>Email:</strong> support@topgambling.com
              </li>
            </ul>
          </div>
          <div className={styles.card}>
            <h3>Часы работы</h3>
            <p>Понедельник — пятница, 09:00–18:00 (GMT)</p>
            <p>Саппорт для клиентов: 24/7</p>
          </div>
        </aside>
      </div>
    </section>
  );
};

export default Contact;