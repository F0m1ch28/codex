import { useNavigate } from "react-router-dom";
import styles from "./NotFound.module.css";

const NotFound = () => {
  const navigate = useNavigate();
  return (
    <section className={styles.page}>
      <h1>404 — страница не найдена</h1>
      <p>
        Похоже, вы оказались в несуществующей зоне. Вернитесь на главную или
        посмотрите наши обзоры казино.
      </p>
      <div className={styles.actions}>
        <button onClick={() => navigate("/")} className={styles.buttonPrimary}>
          На главную
        </button>
        <button
          onClick={() => navigate("/compare")}
          className={styles.buttonSecondary}
        >
          К сравнению казино
        </button>
      </div>
    </section>
  );
};

export default NotFound;