export const casinos = [
  {
    id: "aurora-spin",
    name: "Aurora Spin Casino",
    rating: 4.7,
    bonus: "150% до €500 + 120 FS",
    bonusSummary: "Первый депозит с повышенным коэффициентом и 40x вейджером.",
    wagering: "40x",
    minDeposit: "€20",
    maxCashout: "€5 000 в неделю",
    paymentMethods: ["Visa", "Mastercard", "Skrill", "Bitcoin", "Neteller"],
    games: ["Слоты", "Живые дилеры", "Джекпоты"],
    description:
      "Aurora Spin — казино с обширной библиотекой слотов и live-игр, акцентом на быстрые выплаты и прозрачные условия бонусов.",
    pros: [
      "Моментальные выплаты на электронные кошельки",
      "Разнообразие провайдеров (NetEnt, Evolution)",
      "Еженедельный кешбек до 10%"
    ],
    cons: [
      "Ограничения для некоторых стран ЕС",
      "Максимальная ставка с бонусом €5"
    ],
    license: "Curacao eGaming",
    established: "2020",
    support: "24/7 чат и email",
    currencies: ["EUR", "USD", "BTC", "USDT"],
    languages: ["EN", "DE", "RU", "PL"],
    image: "https://picsum.photos/seed/aurora/800/600",
    heroImage: "https://picsum.photos/seed/aurorahero/1600/900",
    features: [
      { title: "Кешбек 10%", detail: "Возврат на чистые потери каждую пятницу." },
      {
        title: "VIP-клуб",
        detail: "Персональные менеджеры, повышенные лимиты и эксклюзивные турниры."
      },
      {
        title: "Мультивалютные счета",
        detail: "Поддержка фиатных и криптовалют без комиссий со стороны казино."
      }
    ],
    restricted: ["США", "Франция", "Испания"]
  },
  {
    id: "zenith-palace",
    name: "Zenith Palace",
    rating: 4.5,
    bonus: "100% до $600 + 80 FS",
    bonusSummary: "Сбалансированный бонус с прозрачным 35x вейджером.",
    wagering: "35x",
    minDeposit: "$15",
    maxCashout: "$7 500 в неделю",
    paymentMethods: ["Visa", "Paysafecard", "Skrill", "Neteller"],
    games: ["Слоты", "Live казино", "Шоу-игры"],
    description:
      "Zenith Palace предлагает гибкую программу лояльности и регулярные live-турниры с крупными призовыми фондами.",
    pros: [
      "Программа лояльности с уровневой системой",
      "Служба поддержки с отделом ответственной игры",
      "Отдельный каталог провайдеров live-контента"
    ],
    cons: [
      "Нет криптовалютных депозитов",
      "Фриспины активны 48 часов"
    ],
    license: "Malta Gaming Authority",
    established: "2018",
    support: "Чат, email, телефон",
    currencies: ["USD", "CAD", "NZD", "EUR"],
    languages: ["EN", "FR", "ES"],
    image: "https://picsum.photos/seed/zenith/800/600",
    heroImage: "https://picsum.photos/seed/zenithhero/1600/900",
    features: [
      { title: "Live турнирные серии", detail: "Ежемесячные чемпионаты по live-играм." },
      {
        title: "Защита игрока",
        detail: "Комплексные лимиты депозитов, сессий и самоисключение."
      },
      {
        title: "Ранний доступ",
        detail: "Эксклюзивные релизы слотов от топ-провайдеров."
      }
    ],
    restricted: ["Италия", "Нидерланды"]
  },
  {
    id: "nebula-club",
    name: "Nebula Club",
    rating: 4.3,
    bonus: "200% до 1 BTC + 150 FS",
    bonusSummary: "Криптодружелюбный оффер с гибридным вейджером 45x.",
    wagering: "45x",
    minDeposit: "0.001 BTC",
    maxCashout: "5 BTC в месяц",
    paymentMethods: ["Bitcoin", "Ethereum", "Litecoin", "USDT"],
    games: ["Крипто-слоты", "Live", "Crash-игры"],
    description:
      "Nebula Club ориентирован на криптоаудиторию и предлагает мгновенные блокчейн-транзакции без комиссий.",
    pros: [
      "Молниеносные крипто-выплаты",
      "Регулярные бонусы на пополнение в криптовалютах",
      "Интеграция с Provably Fair играми"
    ],
    cons: [
      "Нет поддержки фиатных валют",
      "КYC обязателен перед первым выводом"
    ],
    license: "Curacao eGaming",
    established: "2021",
    support: "24/7 чат, Telegram",
    currencies: ["BTC", "ETH", "LTC", "USDT"],
    languages: ["EN", "RU", "PT"],
    image: "https://picsum.photos/seed/nebula/800/600",
    heroImage: "https://picsum.photos/seed/nebulahero/1600/900",
    features: [
      { title: "Zero Fee", detail: "Без комиссий за депозиты и выводы." },
      {
        title: "Provably Fair",
        detail: "Проверяемые алгоритмы честности для crash-игр."
      },
      {
        title: "Крипто-кешбек",
        detail: "До 12% возврата на еженедельные чистые потери."
      }
    ],
    restricted: ["США", "Сингапур", "Китай"]
  },
  {
    id: "crimson-ace",
    name: "Crimson Ace Casino",
    rating: 4.6,
    bonus: "125% до €700 + 50 FS",
    bonusSummary: "Комбинированный бонус с сегментацией по лимитам ставок.",
    wagering: "38x",
    minDeposit: "€25",
    maxCashout: "€4 500 в неделю",
    paymentMethods: ["Visa", "Mastercard", "Trustly", "PayPal"],
    games: ["Слоты", "Карточные игры", "Live шоу"],
    description:
      "Crimson Ace сочетает продвинутую аналитику RTP со встроенными гайдами по ответственному гемблингу.",
    pros: [
      "Обзор RTP по каждому слоту в режиме реального времени",
      "Еженедельные турниры с призовым фондом €20,000",
      "Глубокие обзоры стратегий в блоге"
    ],
    cons: [
      "Верификация до 48 часов",
      "Бонус недоступен для high-roller аккаунтов"
    ],
    license: "UK Gambling Commission",
    established: "2016",
    support: "Чат, email, телефон",
    currencies: ["EUR", "GBP", "SEK"],
    languages: ["EN", "DE", "SV", "RU"],
    image: "https://picsum.photos/seed/crimson/800/600",
    heroImage: "https://picsum.photos/seed/crimsonhero/1600/900",
    features: [
      { title: "RTP-аналитика", detail: "Прозрачные данные по каждой игре." },
      {
        title: "Обучение игроков",
        detail: "Серия гайд-материалов по управлению банкроллом."
      },
      {
        title: "Экспертная поддержка",
        detail: "Специалисты по ответственному гэмблингу 24/7."
      }
    ],
    restricted: ["США", "Австралия"]
  },
  {
    id: "nova-lounge",
    name: "Nova Lounge",
    rating: 4.4,
    bonus: "100% до €400 + 200 FS",
    bonusSummary: "Гибкая серия бонусов на первые три депозита.",
    wagering: "30x",
    minDeposit: "€10",
    maxCashout: "€6 000 в месяц",
    paymentMethods: ["Visa", "Skrill", "Apple Pay", "Google Pay"],
    games: ["Слоты", "Live казино", "Настольные игры"],
    description:
      "Nova Lounge — нишевой бренд с акцентом на мобильный опыт и геймификацию профиля игрока.",
    pros: [
      "Мобильные ивенты с призами",
      "Прозрачная программа статусов",
      "Большой выбор инновационных слотов"
    ],
    cons: [
      "Ограниченный выбор live-провайдеров",
      "Минимальный вывод €50"
    ],
    license: "Antillephone",
    established: "2019",
    support: "Чат, email",
    currencies: ["EUR", "USD", "PLN"],
    languages: ["EN", "PL", "RU"],
    image: "https://picsum.photos/seed/novalounge/800/600",
    heroImage: "https://picsum.photos/seed/novaloungehero/1600/900",
    features: [
      { title: "Геймификация", detail: "Достижения и сезонные миссии." },
      {
        title: "Мобильные турниры",
        detail: "Оптимизация под смартфоны и планшеты."
      },
      {
        title: "Персонализация",
        detail: "Индивидуальные подборки игр на основе активности."
      }
    ],
    restricted: ["США", "Германия"]
  },
  {
    id: "royal-horizon",
    name: "Royal Horizon",
    rating: 4.8,
    bonus: "170% до $800 + 100 FS",
    bonusSummary: "Высокий лимит бонуса с сегментацией по провайдерам.",
    wagering: "37x",
    minDeposit: "$25",
    maxCashout: "$10 000 в месяц",
    paymentMethods: ["Visa", "Mastercard", "Interac", "Bank Transfer"],
    games: ["Live казино", "Слоты", "Спорт-мини-игры"],
    description:
      "Royal Horizon позиционируется как премиум-платформа с персональными менеджерами и расширенными VIP-привилегиями.",
    pros: [
      "Персонализированные бонусные предложения",
      "Круглосуточная поддержка VIP-наставника",
      "Широкий выбор live-столов высокого лимита"
    ],
    cons: [
      "Высокий минимальный депозит",
      "Верификация обязательна до пополнения"
    ],
    license: "Isle of Man Gambling Supervision",
    established: "2015",
    support: "Телефон, чат, email",
    currencies: ["USD", "CAD", "AUD", "EUR"],
    languages: ["EN", "DE", "RU"],
    image: "https://picsum.photos/seed/royalhorizon/800/600",
    heroImage: "https://picsum.photos/seed/royalhero/1600/900",
    features: [
      { title: "VIP-наставник", detail: "Персональные лимиты и бонусы." },
      {
        title: "Ответственный гэмблинг",
        detail: "Глубокие отчёты по активности и лимитам."
      },
      {
        title: "High Roller столы",
        detail: "Эксклюзивные live-комнаты с крупными лимитами."
      }
    ],
    restricted: ["США", "Турция", "Греция"]
  }
];

export const faqItems = [
  {
    question: "Как формируется рейтинг казино на TopGambling?",
    answer:
      "Мы оцениваем лицензирование, прозрачность условий, скорость выплат, качество поддержки, портфель игр и инструменты ответственной игры. Каждое казино проходит многоуровневую проверку и получает итоговый балл."
  },
  {
    question: "Можно ли играть из любой страны?",
    answer:
      "Мы освещаем международные казино, но каждое заведение имеет ограничения по юрисдикциям. Перед регистрацией убедитесь, что казино принимает игроков из вашей страны."
  },
  {
    question: "Какие методы оплаты считаются наиболее надёжными?",
    answer:
      "Мы рекомендуем использовать проверенные платёжные решения: банковские карты, лицензированные э-кошельки или криптовалюты с двухфакторной аутентификацией. В обзорах указаны доступные методы и лимиты."
  },
  {
    question: "Какой вейджер считается приемлемым?",
    answer:
      "Сбалансированным считается вейджер 30-40x для бонусов на депозит и 45x для пакетов с фриспинами. Мы всегда подчёркиваем, когда условия выше среднего."
  },
  {
    question: "Где найти информацию о программах лояльности?",
    answer:
      "Каждый обзор содержит блок с VIP-привилегиями, статусами и частотой бонусов. В сравнительной таблице отображается, есть ли у казино посвящённая программа лояльности."
  },
  {
    question: "Как TopGambling поддерживает ответственную игру?",
    answer:
      "Мы выделяем инструменты контроля времени и лимитов, публикуем образовательные материалы и отмечаем казино с активной политикой Responsible Gaming."
  }
];

export const testimonials = [
  {
    name: "Марина Г.",
    role: "Аналитик гэмблинг-рынка",
    quote:
      "TopGambling помогает оперативно сравнивать офферы и находить честные условия без скрытых требований.",
    score: 4.8,
    avatar: "https://picsum.photos/seed/testimonial1/200/200"
  },
  {
    name: "Илья С.",
    role: "Менеджер по VIP-игрокам",
    quote:
      "Детальные обзоры и разбор VIP-привилегий позволяют правильно выстраивать стратегию работы с хайроллерами.",
    score: 4.9,
    avatar: "https://picsum.photos/seed/testimonial2/200/200"
  },
  {
    name: "Дарья К.",
    role: "Консультант по ответственной игре",
    quote:
      "Мне импонирует акцент на защиту игроков: в обзорах выделены лимиты, KYC и инструменты самоконтроля.",
    score: 5.0,
    avatar: "https://picsum.photos/seed/testimonial3/200/200"
  }
];

export const teamMembers = [
  {
    name: "Алексей Нестеров",
    role: "Главный редактор",
    bio: "12 лет в индустрии, автор аналитических отчётов по европейскому рынку онлайн-казино.",
    image: "https://picsum.photos/seed/team1/400/400",
    expertise: ["Аналитика", "Лицензирование", "Переговоры"]
  },
  {
    name: "Ксения Романова",
    role: "Эксперт по ответственному гэмблингу",
    bio: "Сертифицированный специалист Responsible Gaming, консультирует казино по внедрению инструментов защиты.",
    image: "https://picsum.photos/seed/team2/400/400",
    expertise: ["Responsible Gaming", "Обучение", "Комплаенс"]
  },
  {
    name: "Марк Вильсон",
    role: "Дата-аналитик",
    bio: "Разрабатывает модели оценки рейтингов и мониторит изменения коэффициентов в реальном времени.",
    image: "https://picsum.photos/seed/team3/400/400",
    expertise: ["Data Science", "Мониторинг", "Автоматизация"]
  },
  {
    name: "Елена Пак",
    role: "Контент-стратег",
    bio: "Создаёт контент-планы, отвечает за стандарты обзоров и редакторскую политику.",
    image: "https://picsum.photos/seed/team4/400/400",
    expertise: ["Контент", "UX-подход", "Методологии"]
  }
];

export const projects = [
  {
    id: "project-1",
    title: "Глобальный индекс казино 2024",
    category: "Аналитика",
    description:
      "Исследование 120 международных брендов с фокусом на вейджер, выплаты и Responsible Gaming.",
    image: "https://picsum.photos/seed/project1/1200/800"
  },
  {
    id: "project-2",
    title: "Мобильное сравнение live-казино",
    category: "Мобильный рынок",
    description:
      "Обзор приложений и веб-клиентов с UX-аудитом и рекомендациями по улучшению потоков.",
    image: "https://picsum.photos/seed/project2/1200/800"
  },
  {
    id: "project-3",
    title: "VIP Benchmark",
    category: "VIP",
    description:
      "Сравнение VIP-программ: лимиты, кешбек, эксклюзивные офферы и условия обслуживания.",
    image: "https://picsum.photos/seed/project3/1200/800"
  },
  {
    id: "project-4",
    title: "Крипто-гэмблинг 2.0",
    category: "Крипто",
    description:
      "Отчёт по крипто-казино: AML-практики, скорость транзакций и прозрачность провайдеров.",
    image: "https://picsum.photos/seed/project4/1200/800"
  }
];

export const blogPosts = [
  {
    id: "blog-1",
    title: "Как выбрать международное казино с честными условиями",
    excerpt:
      "Пошаговая методика оценки лицензии, прозрачности бонусов и скорости выплат.",
    date: "12 марта 2024",
    image: "https://picsum.photos/seed/blog1/800/600"
  },
  {
    id: "blog-2",
    title: "Ответственная игра: инструменты, которые должны быть в каждом казино",
    excerpt:
      "Разбираем лимиты, таймеры, самоисключение и поддержку Responsible Gaming.",
    date: "02 апреля 2024",
    image: "https://picsum.photos/seed/blog2/800/600"
  },
  {
    id: "blog-3",
    title: "Сравниваем live-казино: что влияет на качество стрима",
    excerpt:
      "Камеры, студийное оборудование, провайдеры и опыт крупье — ключевые параметры выбора.",
    date: "25 апреля 2024",
    image: "https://picsum.photos/seed/blog3/800/600"
  }
];

export const processSteps = [
  {
    title: "Сбор данных",
    description:
      "Анализируем лицензию, условия бонусов, платёжные методы, лимиты и скорость выплат."
  },
  {
    title: "Тестирование",
    description:
      "Создаём тестовые аккаунты, проверяем навигацию, геймплей, верификацию и службу поддержки."
  },
  {
    title: "Сравнение условий",
    description:
      "Сопоставляем предложения с конкурентами, выделяем сильные и слабые стороны."
  },
  {
    title: "Публикация обзора",
    description:
      "Готовим структурированный обзор с чек-листами, лайфхаками и рекомендациями по ответственному подходу."
  }
];

export const statsData = [
  { label: "Проверенных казино", value: 180, suffix: "+" },
  { label: "Глубоких аналитик", value: 320, suffix: "" },
  { label: "Экспертов в команде", value: 12, suffix: "" },
  { label: "Экспресс-проверок выплат", value: 540, suffix: "+" }
];