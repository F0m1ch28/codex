import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.column}>
        <h3 className={styles.logo}>TopGambling</h3>
        <p className={styles.description}>
          Глубокая аналитика международных казино, честные сравнения условий и
          стратегические рекомендации для ответственной игры.
        </p>
        <p className={styles.disclaimer}>
          TopGambling выступает обзорным медиа и не принимает ставки. Убедитесь,
          что играете ответственно и в соответствии с законами вашей
          юрисдикции.
        </p>
      </div>

      <div className={styles.column}>
        <h4>Быстрые ссылки</h4>
        <ul className={styles.list}>
          <li>
            <NavLink to="/compare">Сравнение казино</NavLink>
          </li>
          <li>
            <NavLink to="/services">Наши услуги</NavLink>
          </li>
          <li>
            <NavLink to="/about">О компании</NavLink>
          </li>
          <li>
            <NavLink to="/contact">Контакты</NavLink>
          </li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4>Правовая информация</h4>
        <ul className={styles.list}>
          <li>
            <NavLink to="/terms">Условия использования</NavLink>
          </li>
          <li>
            <NavLink to="/privacy">Политика конфиденциальности</NavLink>
          </li>
          <li>
            <NavLink to="/cookie-policy">Cookie политика</NavLink>
          </li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4>Контакты</h4>
        <ul className={styles.contacts}>
          <li>Адрес: 123 Gambling Street, London, UK</li>
          <li>Телефон: +44 20 1234 5678</li>
          <li>Email: support@topgambling.com</li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} TopGambling. Все права защищены.</span>
    </div>
  </footer>
);

export default Footer;