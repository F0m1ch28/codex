import styles from "./ComparisonTable.module.css";

const ComparisonTable = ({ data }) => (
  <div className={styles.wrapper}>
    <table className={styles.table}>
      <thead>
        <tr>
          <th>Казино</th>
          <th>Приветственный бонус</th>
          <th>Вейджер</th>
          <th>Мин. депозит</th>
          <th>Методы оплаты</th>
          <th>Типы игр</th>
        </tr>
      </thead>
      <tbody>
        {data.map((casino) => (
          <tr key={casino.id}>
            <td>
              <div className={styles.nameCell}>
                <img
                  src={casino.image}
                  alt={`Логотип ${casino.name}`}
                  loading="lazy"
                />
                <div>
                  <strong>{casino.name}</strong>
                  <span>Рейтинг: {casino.rating.toFixed(1)} / 5</span>
                </div>
              </div>
            </td>
            <td>{casino.bonus}</td>
            <td>{casino.wagering}</td>
            <td>{casino.minDeposit}</td>
            <td>{casino.paymentMethods.join(", ")}</td>
            <td>{casino.games.join(", ")}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

export default ComparisonTable;