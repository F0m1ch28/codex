import styles from "./ReviewCard.module.css";

const ReviewCard = ({ review, active }) => (
  <article className={`${styles.card} ${active ? styles.active : ""}`}>
    <div className={styles.header}>
      <img src={review.avatar} alt={review.name} loading="lazy" />
      <div>
        <h4>{review.name}</h4>
        <span>{review.role}</span>
      </div>
    </div>
    <p className={styles.quote}>"{review.quote}"</p>
    <div className={styles.footer}>
      <span>Оценка эксперта:</span>
      <strong>{review.score} / 5</strong>
    </div>
  </article>
);

export default ReviewCard;