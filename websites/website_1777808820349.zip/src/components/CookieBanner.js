import { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

const STORAGE_KEY = "topGamblingCookieConsent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Cookie файлы</h4>
        <p>
          Мы используем cookie для улучшения пользовательского опыта и аналитики
          посещений. Продолжая пользоваться сайтом, вы соглашаетесь с нашей
          политикой обработки данных.
        </p>
      </div>
      <button className={styles.button} onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;