import { Link } from "react-router-dom";
import styles from "./Card.module.css";

const Card = ({ casino }) => (
  <article className={styles.card}>
    <div
      className={styles.media}
      style={{ backgroundImage: `url(${casino.image})` }}
      role="img"
      aria-label={`Изображение казино ${casino.name}`}
    >
      <span className={styles.rating}>
        {casino.rating.toFixed(1)}
        <small>/5</small>
      </span>
    </div>
    <div className={styles.body}>
      <h3>{casino.name}</h3>
      <p className={styles.bonus}>{casino.bonus}</p>
      <ul className={styles.meta}>
        <li>
          <strong>Вейджер:</strong> {casino.wagering}
        </li>
        <li>
          <strong>Мин. депозит:</strong> {casino.minDeposit}
        </li>
        <li>
          <strong>Игры:</strong> {casino.games.join(", ")}
        </li>
      </ul>
      <div className={styles.tags}>
        {casino.paymentMethods.slice(0, 3).map((method) => (
          <span key={method}>{method}</span>
        ))}
      </div>
    </div>
    <div className={styles.footer}>
      <Link to={`/casino/${casino.id}`} className={styles.link}>
        Читать обзор
      </Link>
    </div>
  </article>
);

export default Card;