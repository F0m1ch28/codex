import { useState } from "react";
import styles from "./FAQ.module.css";

const FAQ = ({ items }) => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggle = (index) => {
    setActiveIndex((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.faq} id="faq">
      {items.map((item, index) => (
        <article
          key={item.question}
          className={`${styles.item} ${
            activeIndex === index ? styles.open : ""
          }`}
        >
          <button
            className={styles.question}
            onClick={() => toggle(index)}
            aria-expanded={activeIndex === index}
          >
            <span>{item.question}</span>
            <span className={styles.icon}>{activeIndex === index ? "−" : "+"}</span>
          </button>
          <div className={styles.answer}>
            <p>{item.answer}</p>
          </div>
        </article>
      ))}
    </div>
  );
};

export default FAQ;