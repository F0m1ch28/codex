import styles from "./Hero.module.css";

const Hero = ({ title, subtitle, ctaText, onCtaClick, highlight }) => (
  <section className={styles.hero} id="hero" aria-labelledby="hero-heading">
    <div className={styles.overlay} />
    <div className={styles.content}>
      <span className={styles.badge}>{highlight}</span>
      <h1 id="hero-heading">{title}</h1>
      <p>{subtitle}</p>
      <div className={styles.actions}>
        <button className={styles.primary} onClick={onCtaClick}>
          {ctaText}
        </button>
        <a className={styles.secondary} href="#reviews">
          Смотреть обзоры
        </a>
      </div>
    </div>
  </section>
);

export default Hero;