document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.getElementById("primary-navigation");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const expanded = this.getAttribute("aria-expanded") === "true";
            this.setAttribute("aria-expanded", String(!expanded));
            navMenu.dataset.visible = expanded ? "false" : "true";
        });

        navMenu.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                navToggle.setAttribute("aria-expanded", "false");
                navMenu.dataset.visible = "false";
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const cookieStorageKey = "syntaxbwgqCookieConsent";

    function hideBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove("show");
        }
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(cookieStorageKey);
        if (!storedConsent) {
            cookieBanner.classList.add("show");
        }

        cookieBanner.querySelectorAll("[data-cookie-choice]").forEach(function (button) {
            button.addEventListener("click", function (event) {
                event.preventDefault();
                const choice = this.getAttribute("data-cookie-choice");
                localStorage.setItem(cookieStorageKey, choice);
                hideBanner();
            });
        });
    }
});