document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const scrollButton = document.querySelector('.scroll-top');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAcceptButton = cookieBanner ? cookieBanner.querySelector('.cookie-accept') : null;
    const contactForm = document.getElementById('contact-form');
    const formResponse = document.getElementById('form-response');
    const yearPlaceholder = document.getElementById('current-year');

    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
    window.scrollTo({ top: 0, behavior: 'instant' });

    if (yearPlaceholder) {
        yearPlaceholder.textContent = new Date().getFullYear();
    }

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen.toString());
        });
    }

    const navLinks = document.querySelectorAll('.nav-menu a, .footer-sitemap a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu && navMenu.classList.contains('is-open')) {
                navMenu.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            if (link.getAttribute('href') && link.getAttribute('href').includes('.html')) {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });

    if (scrollButton) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollButton.classList.add('is-visible');
            } else {
                scrollButton.classList.remove('is-visible');
            }
        });

        scrollButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const COOKIE_KEY = 'awc_cookie_consent';

    if (cookieBanner && cookieAcceptButton) {
        const consentGiven = localStorage.getItem(COOKIE_KEY);
        if (!consentGiven) {
            cookieBanner.hidden = false;
        }

        cookieAcceptButton.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'accepted');
            cookieBanner.hidden = true;
        });
    }

    if (contactForm && formResponse) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name')?.toString().trim();
            const email = formData.get('email')?.toString().trim();
            const message = formData.get('message')?.toString().trim();

            if (!name || !email || !message) {
                formResponse.textContent = 'Please complete the required fields before sending.';
                formResponse.style.color = '#d9534f';
                return;
            }

            formResponse.textContent = 'Sending your message...';
            formResponse.style.color = '#2F8F83';

            setTimeout(() => {
                formResponse.textContent = 'Thank you for reaching out. Our care coordinator will be in touch within one business day.';
                formResponse.style.color = '#2F8F83';
                contactForm.reset();
            }, 900);
        });
    }
});