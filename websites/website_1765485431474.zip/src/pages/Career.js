import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Career.module.css';

const Career = () => {
  const steps = [
    {
      title: 'Career diagnostics',
      description: 'Assess your strengths and interests through reflective exercises and mentor conversations.'
    },
    {
      title: 'Portfolio storytelling',
      description: 'Curate projects, articulate problem-solving approaches, and write compelling case studies.'
    },
    {
      title: 'Interview simulation',
      description: 'Participate in mock interviews, pair programming, and product critiques with hiring managers.'
    },
    {
      title: 'Offer readiness',
      description: 'Negotiate offers with confidence, plan onboarding, and set measurable goals for your first 90 days.'
    }
  ];

  const faqs = [
    {
      question: 'How does career support integrate with the courses?',
      answer:
        'Career programming runs in parallel with your technical sprints. You attend live workshops, 1:1 mentor sessions, and receive feedback on your portfolio, CV, and communication style.'
    },
    {
      question: 'Do you collaborate with Belgian employers?',
      answer:
        'Yes, we partner with startups and established organisations across Belgium to host challenge sprints, recruitment showcases, and live briefings that mirror real-world hiring processes.'
    },
    {
      question: 'Can career changers participate?',
      answer:
        'Absolutely. We tailor your roadmap to highlight transferable skills, spotlight project outcomes, and build confidence through targeted coaching.'
    }
  ];

  const [openFaq, setOpenFaq] = useState(0);

  return (
    <>
      <Seo
        title="Career Support"
        description="IT Learning Hub provides tailored career services including portfolio coaching, interview simulations, and Belgian tech employer connections."
        keywords="tech career support Belgium, portfolio coaching, interview practice"
        canonical="https://www.itlearninghub.be/career"
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <h1>Career support that champions your goals</h1>
              <p>
                We combine coaching, employer partnerships, and practical simulations to help you translate skills into
                meaningful roles. Our career team stays by your side from onboarding through alumni milestones.
              </p>
            </div>
            <img src="https://picsum.photos/900/650?random=601" alt="Career coaching session" />
          </div>
        </div>
      </section>
      <section className={styles.steps}>
        <div className="container">
          <h2>Journey to your next role</h2>
          <div className={styles.stepGrid}>
            {steps.map((step, index) => (
              <article key={step.title} className={styles.stepCard}>
                <span>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className={styles.faq}>
        <div className="container">
          <h2>Career support FAQ</h2>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => (
              <div key={faq.question} className={styles.faqItem}>
                <button
                  type="button"
                  onClick={() => setOpenFaq((prev) => (prev === index ? null : index))}
                  aria-expanded={openFaq === index}
                >
                  {faq.question}
                  <span>{openFaq === index ? '−' : '+'}</span>
                </button>
                {openFaq === index && <p>{faq.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Career;