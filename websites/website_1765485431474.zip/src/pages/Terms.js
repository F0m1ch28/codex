import React from 'react';
import Seo from '../components/Seo';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Seo
      title="Terms of Service"
      description="Review the IT Learning Hub Terms of Service covering platform usage, intellectual property, and learner responsibilities."
      canonical="https://www.itlearninghub.be/terms"
    />
    <section className={styles.page}>
      <div className="container">
        <h1>Terms of Service</h1>
        <p>Last updated: January 2024</p>
        <h2>1. Overview</h2>
        <p>
          IT Learning Hub operates educational programs and digital learning resources. These Terms of Service govern
          access to our website, courses, mentoring sessions, and related services. By using our platforms, you agree to
          comply with these terms and applicable Belgian and EU legislation.
        </p>
        <h2>2. Intellectual property</h2>
        <p>
          All course materials, recorded sessions, and platform content are proprietary to IT Learning Hub or our
          partners. Learners receive a personal, non-transferable license to use materials for educational purposes.
          Reproducing or distributing content without consent is prohibited.
        </p>
        <h2>3. Learner responsibilities</h2>
        <ul>
          <li>Maintain accurate profile information and respect community guidelines.</li>
          <li>Complete assignments honestly and acknowledge collaboration transparently.</li>
          <li>Respect confidentiality of employer projects or partner data used in learning activities.</li>
        </ul>
        <h2>4. Platform availability</h2>
        <p>
          We strive to ensure continuous platform availability. Scheduled maintenance and unforeseen outages may occur.
          We will communicate updates via email and in-platform notifications.
        </p>
        <h2>5. Contact</h2>
        <p>
          For questions regarding these terms, please email <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>.
        </p>
      </div>
    </section>
  </>
);

export default Terms;