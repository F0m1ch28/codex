import React from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const Services = () => {
  const services = [
    {
      title: 'Upskilling programs',
      description:
        'Tailored curricula for product squads, marketing technologists, and operations teams to expand their digital capabilities.',
      image: 'https://picsum.photos/820/600?random=701'
    },
    {
      title: 'Leadership bootcamps',
      description:
        'Immersive bootcamps for managers covering tech strategy, agile governance, and stakeholder communication.',
      image: 'https://picsum.photos/820/600?random=702'
    },
    {
      title: 'Innovation labs',
      description:
        'Facilitated labs to experiment with emerging technologies, prototype ideas, and validate concepts with end users.',
      image: 'https://picsum.photos/820/600?random=703'
    }
  ];

  return (
    <>
      <Seo
        title="Services"
        description="Explore IT Learning Hub services including team upskilling, leadership bootcamps, and innovation labs across Belgium."
        canonical="https://www.itlearninghub.be/services"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Services for teams and organisations</h1>
          <p>
            Beyond individual learning, we design programs that help organisations build high-performing teams, embrace
            innovation, and future-proof their digital strategy.
          </p>
        </div>
      </section>
      <section className={styles.services}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <img src={service.image} alt={`${service.title} service`} />
                <div>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;