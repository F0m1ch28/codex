import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const About = () => {
  const milestones = [
    {
      year: '2015',
      title: 'Foundation in Brussels',
      description: 'IT Learning Hub launched as a grassroots initiative connecting developers and aspiring technologists.'
    },
    {
      year: '2018',
      title: 'Corporate partnerships',
      description: 'Collaborations with Belgian scale-ups enabled tailored upskilling programs for cross-functional teams.'
    },
    {
      year: '2021',
      title: 'Hybrid learning labs',
      description: 'Introduced hybrid campus and remote labs with multilingual instruction to reach learners across Belgium.'
    },
    {
      year: '2023',
      title: 'Innovation studios',
      description: 'Opened innovation studios focused on cybersecurity resilience, ethical AI, and sustainable cloud practices.'
    }
  ];

  const values = [
    {
      title: 'Human-centred mentorship',
      description:
        'We pair every learner with expert mentors who provide actionable feedback and career guidance rooted in empathy.'
    },
    {
      title: 'Deliver real impact',
      description:
        'Programs revolve around production-grade projects in partnership with Belgian companies, ensuring tangible outcomes.'
    },
    {
      title: 'Inclusive community',
      description:
        'We celebrate diversity across languages, backgrounds, and learning styles, creating a safe environment for exploration.'
    }
  ];

  return (
    <>
      <Seo
        title="About Our IT Education Mission"
        description="Learn how IT Learning Hub empowers Belgium with inclusive, industry-aligned technology education and lifelong digital skills."
        keywords="IT Learning Hub about, Belgium tech education, digital skills mission"
        canonical="https://www.itlearninghub.be/about"
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <h1>We nurture Belgium&apos;s next generation of tech leaders</h1>
              <p>
                IT Learning Hub was born in Brussels with a simple promise: connect ambitious learners to practicing
                technologists, and create a space where skills translate into careers. Our multilingual faculty and
                cross-sector partnerships keep us aligned with the demands of Europe&apos;s digital frontier.
              </p>
            </div>
            <img src="https://picsum.photos/900/700?random=201" alt="IT Learning Hub collaborative workspace" />
          </div>
        </div>
      </section>
      <section className={styles.missionSection}>
        <div className="container">
          <div className={styles.missionIntro}>
            <h2>Mission &amp; vision</h2>
            <p>
              We believe that technology education should be hands-on, human, and future-facing. From classroom to board
              room, we equip people to think like makers, solve meaningful problems, and champion responsible
              innovation.
            </p>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className={styles.milestones}>
        <div className="container">
          <h2>Milestones that shaped our journey</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <div key={milestone.year} className={styles.timelineCard}>
                <div className={styles.year}>{milestone.year}</div>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className={styles.impact}>
        <div className="container">
          <div className={styles.impactGrid}>
            <img src="https://picsum.photos/850/650?random=202" alt="Learners collaborating on laptops" />
            <div>
              <h2>Community impact across Belgium</h2>
              <p>
                From Leuven to Liège, our alumni network supports hackathons, mentorship circles, and open-source
                contributions. We regularly host inclusive meetups, lightning talks, and talent showcases connecting
                learners with industry leaders.
              </p>
              <ul className={styles.impactList}>
                <li>Bi-monthly tech meetups featuring Belgian founders and engineers.</li>
                <li>Scholarships prioritising career changers and underrepresented groups.</li>
                <li>Career labs that simulate interviews, code reviews, and strategic retrospectives.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;