import React from 'react';
import Seo from '../components/Seo';
import styles from './Methodology.module.css';

const Methodology = () => {
  const pillars = [
    {
      title: 'Adaptive learning journeys',
      description:
        'We use diagnostics to tailor sprints, resources, and mentor check-ins so each learner progresses with confidence.'
    },
    {
      title: 'Studio-based collaboration',
      description:
        'Learners work in studios that mirror real teams, using agile rituals, code reviews, and retrospectives to refine delivery.'
    },
    {
      title: 'Impact measurement',
      description:
        'Every project is evaluated against business outcomes, with clear metrics tied to quality, performance, and team readiness.'
    }
  ];

  const process = [
    {
      stage: 'Discover',
      detail:
        'Kick off with a discovery workshop to map objectives, skills, and organisational context. Align on success criteria and learning cadences.'
    },
    {
      stage: 'Design',
      detail:
        'Co-create a skills blueprint, integrate short-form modules, and schedule live labs around your team’s availability.'
    },
    {
      stage: 'Build',
      detail:
        'Learners build in public with mentors. They log decisions, capture learnings, and present prototypes to stakeholder panels.'
    },
    {
      stage: 'Launch',
      detail:
        'Translate learnings into operational improvements. We deliver insights, capability reports, and next-step recommendations.'
    }
  ];

  return (
    <>
      <Seo
        title="Learning Methodology"
        description="Discover IT Learning Hub's adaptive methodology combining diagnostics, studio collaboration, and measurable outcomes."
        keywords="learning methodology, IT Learning Hub approach, adaptive learning Belgium"
        canonical="https://www.itlearninghub.be/methodology"
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <h1>A methodology built on purpose, progress, and practice</h1>
              <p>
                Our learning methodology is a living system informed by neuroscience, design thinking, and agile
                delivery. It empowers professionals to move from awareness to mastery with the support of mentors,
                peers, and data.
              </p>
            </div>
            <img src="https://picsum.photos/850/650?random=401" alt="Interactive workshop at IT Learning Hub" />
          </div>
        </div>
      </section>

      <section className={styles.pillars}>
        <div className="container">
          <h2>The pillars that guide every cohort</h2>
          <div className={styles.pillarGrid}>
            {pillars.map((pillar) => (
              <article key={pillar.title} className={styles.pillarCard}>
                <h3>{pillar.title}</h3>
                <p>{pillar.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <h2>The IT Learning Hub cycle</h2>
          <div className={styles.processGrid}>
            {process.map((step, index) => (
              <div key={step.stage} className={styles.processCard}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.stage}</h3>
                <p>{step.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Methodology;