import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Instructors.module.css';

const instructors = [
  {
    name: 'Sophie Laurent',
    title: 'Lead Full-Stack Mentor',
    image: 'https://picsum.photos/500/500?random=501',
    bio: 'Former head of engineering at a Brussels SaaS scale-up. Specialises in design systems, accessibility, and rapid prototyping.',
    specialties: ['React & Next.js', 'Design systems', 'Accessibility']
  },
  {
    name: 'Milan Verbeek',
    title: 'Senior Data Scientist',
    image: 'https://picsum.photos/500/500?random=502',
    bio: 'Analytics leader with a decade of experience in financial services and mobility tech. Advocates for responsible AI.',
    specialties: ['Machine learning', 'Data storytelling', 'MLOps']
  },
  {
    name: 'Nora Petrovic',
    title: 'Cybersecurity Architect',
    image: 'https://picsum.photos/500/500?random=503',
    bio: 'Works on EU-wide cyber resilience programs. Passionate about zero trust architecture and incident response playbooks.',
    specialties: ['Zero trust', 'Incident response', 'Cloud security']
  },
  {
    name: 'Alexandre Dubois',
    title: 'DevOps Coach',
    image: 'https://picsum.photos/500/500?random=504',
    bio: 'Helps Belgian teams modernise delivery pipelines using cloud-native tooling and observability-first mindsets.',
    specialties: ['Kubernetes', 'Infrastructure as code', 'SRE practices']
  }
];

const Instructors = () => {
  const [highlight, setHighlight] = useState(instructors[0]);

  return (
    <>
      <Seo
        title="Our Instructor Team"
        description="Meet IT Learning Hub's instructors, mentors, and industry experts guiding learners through web development, data science, and cybersecurity."
        keywords="IT Learning Hub instructors, mentor team, Belgium tech mentors"
        canonical="https://www.itlearninghub.be/instructors"
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.layout}>
            <div>
              <h1>Mentors who practice what they teach</h1>
              <p>
                Every instructor is an active practitioner, bringing real briefs, codebases, and product challenges from
                Belgian and international teams. They coach learners through technical decision-making, collaboration,
                and delivery.
              </p>
            </div>
            <div className={styles.highlightCard}>
              <img src={highlight.image} alt={`${highlight.name} portrait`} />
              <div>
                <h2>{highlight.name}</h2>
                <span>{highlight.title}</span>
                <p>{highlight.bio}</p>
                <ul>
                  {highlight.specialties.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            {instructors.map((mentor) => (
              <button
                key={mentor.name}
                type="button"
                className={`${styles.card} ${highlight.name === mentor.name ? styles.active : ''}`}
                onClick={() => setHighlight(mentor)}
                aria-pressed={highlight.name === mentor.name}
              >
                <img src={mentor.image} alt={`${mentor.name} profile`} />
                <div>
                  <h3>{mentor.name}</h3>
                  <span>{mentor.title}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Instructors;