import React from 'react';
import Seo from '../components/Seo';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Seo
      title="Privacy Policy"
      description="Understand how IT Learning Hub collects, stores, and processes personal data in compliance with GDPR."
      canonical="https://www.itlearninghub.be/privacy"
    />
    <section className={styles.page}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>Effective date: January 2024</p>
        <h2>Personal data we collect</h2>
        <p>
          We collect personal data that you provide when registering for courses, subscribing to updates, or
          contacting our team. This includes identification details, communication preferences, and learning progress.
        </p>
        <h2>How we use personal data</h2>
        <ul>
          <li>Deliver and improve educational services and learner support.</li>
          <li>Facilitate mentor assignments, assessments, and certification records.</li>
          <li>Communicate program updates, events, and community opportunities.</li>
        </ul>
        <h2>Legal basis</h2>
        <p>
          Processing is grounded in contractual necessity, legitimate interest, and consent where applicable. We comply
          with the EU General Data Protection Regulation (GDPR).
        </p>
        <h2>Data retention</h2>
        <p>
          We retain personal data for the duration of your engagement and as required for legal and reporting
          obligations. You may request deletion subject to regulatory requirements.
        </p>
        <h2>Your rights</h2>
        <p>
          You may request access, rectification, deletion, or restriction of your personal data. Contact{' '}
          <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a> to exercise these rights.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;