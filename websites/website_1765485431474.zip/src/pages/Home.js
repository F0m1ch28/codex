import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: 'Learners empowered', value: 5400, suffix: '+' },
      { label: 'Industry mentors', value: 48, suffix: '' },
      { label: 'Career transitions', value: 320, suffix: '+' },
      { label: 'Live labs each year', value: 180, suffix: '+' }
    ],
    []
  );

  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('All');

  const featuredCourses = [
    {
      title: 'Full-Stack Web Development',
      description: 'Build production-ready digital experiences with modern JavaScript frameworks, cloud deployment, and agile collaboration.',
      tag: 'Web Development',
      image: 'https://picsum.photos/600/400?random=101',
      link: '/courses'
    },
    {
      title: 'Data Science & Analytics',
      description: 'Master data storytelling with Python, feature engineering, and business-first analytics to drive decisions.',
      tag: 'Data Science',
      image: 'https://picsum.photos/600/400?random=102',
      link: '/courses'
    },
    {
      title: 'Cybersecurity Foundations',
      description: 'Hands-on labs covering threat modelling, incident response, and security automation tailored to EU requirements.',
      tag: 'Cybersecurity',
      image: 'https://picsum.photos/600/400?random=103',
      link: '/courses'
    },
    {
      title: 'Cloud & DevOps Engineering',
      description: 'Accelerate delivery pipelines with container orchestration, IaC, and observability best practices.',
      tag: 'DevOps',
      image: 'https://picsum.photos/600/400?random=104',
      link: '/courses'
    }
  ];

  const capstoneProjects = [
    {
      title: 'Smart Mobility Dashboard',
      category: 'Web Development',
      image: 'https://picsum.photos/640/420?random=105',
      description: 'An interactive suite for Brussels commuters combining data visualisation and progressive web app features.'
    },
    {
      title: 'Predictive Maintenance AI',
      category: 'Data Science',
      image: 'https://picsum.photos/640/420?random=106',
      description: 'Machine learning pipeline reducing downtime for a Belgian manufacturing partner by 24%.'
    },
    {
      title: 'Zero Trust Architecture Lab',
      category: 'Cybersecurity',
      image: 'https://picsum.photos/640/420?random=107',
      description: 'Simulation of zero trust policies across hybrid infrastructure with continuous compliance checks.'
    },
    {
      title: 'Sustainable Cloud Footprint',
      category: 'DevOps',
      image: 'https://picsum.photos/640/420?random=108',
      description: 'Automated FinOps dashboards and carbon-aware workload scheduling for green operations.'
    }
  ];

  const testimonials = [
    {
      name: 'Emma Janssens',
      role: 'Junior Software Engineer, Ghent',
      message:
        'The mentors at IT Learning Hub helped me transform a passion project into a professional-grade portfolio. The career coaching was tailored and impactful.',
      image: 'https://picsum.photos/200/200?random=109'
    },
    {
      name: 'Luca Moretti',
      role: 'Security Analyst, Brussels',
      message:
        'I appreciated the balance between theory and critical incident simulations. The cybersecurity track mirrored real SOC workflows.',
      image: 'https://picsum.photos/200/200?random=110'
    },
    {
      name: 'Anouk De Wilde',
      role: 'Data Analyst, Antwerp',
      message:
        'Collaborative labs and peer reviews boosted my confidence. I secured a data analytics role two weeks after graduation.',
      image: 'https://picsum.photos/200/200?random=111'
    }
  ];

  const blogPreview = [
    {
      title: 'Why Belgium Needs Ethical AI Champions',
      image: 'https://picsum.photos/800/600?random=112',
      link: '/services',
      description: 'Explore how multidisciplinary teams can embed ethical guardrails into machine learning pipelines.'
    },
    {
      title: 'Web Accessibility Playbook 2024',
      image: 'https://picsum.photos/800/600?random=113',
      link: '/courses',
      description: 'Our instructors share practical techniques for inclusive interfaces aligned with European directives.'
    },
    {
      title: 'From Ops to DevOps: Bridging the Gap',
      image: 'https://picsum.photos/800/600?random=114',
      link: '/methodology',
      description: 'Discover the cultural and technical pillars that accelerate DevOps adoption in midsize teams.'
    }
  ];

  const instructorsPreview = [
    {
      name: 'Sophie Laurent',
      expertise: 'Lead Full-Stack Mentor',
      image: 'https://picsum.photos/400/400?random=115',
      bio: 'Drives the Brussels front-end community, specialising in React, accessibility, and design systems.'
    },
    {
      name: 'Milan Verbeek',
      expertise: 'Senior Data Scientist',
      image: 'https://picsum.photos/400/400?random=116',
      bio: 'Former analytics lead at a Belgian fintech, passionate about explainable AI and data ethics.'
    },
    {
      name: 'Nora Petrovic',
      expertise: 'Cybersecurity Architect',
      image: 'https://picsum.photos/400/400?random=117',
      bio: 'Certified CISSP with hands-on experience across EU critical infrastructure resilience programs.'
    }
  ];

  useEffect(() => {
    const timers = statsData.map((stat, index) => {
      let current = 0;
      const increment = Math.ceil(stat.value / 60);
      return setInterval(() => {
        current += increment;
        setAnimatedStats((prev) => {
          const next = [...prev];
          next[index] = current >= stat.value ? stat.value : current;
          return next;
        });
        if (current >= stat.value) {
          clearInterval(timers[index]);
        }
      }, 30);
    });
    return () => timers.forEach((timer) => clearInterval(timer));
  }, [statsData]);

  useEffect(() => {
    const slider = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(slider);
  }, [testimonials.length]);

  const filteredProjects =
    projectFilter === 'All'
      ? capstoneProjects
      : capstoneProjects.filter((project) => project.category === projectFilter);

  return (
    <>
      <Seo
        title="Future-Ready Tech Education in Belgium"
        description="IT Learning Hub delivers hands-on IT education with expert mentors, real-world projects, and career support for professionals across Belgium."
        keywords="IT education Belgium, programming courses, web development bootcamp, cybersecurity training, data science Brussels"
        canonical="https://www.itlearninghub.be/"
        jsonLd={{
          '@context': 'https://schema.org',
          '@type': 'EducationalOrganization',
          name: 'IT Learning Hub',
          url: 'https://www.itlearninghub.be/',
          address: {
            '@type': 'PostalAddress',
            streetAddress: 'Tech Campus 200',
            addressLocality: 'Brussels',
            postalCode: '1000',
            addressCountry: 'BE'
          },
          contactPoint: {
            '@type': 'ContactPoint',
            telephone: '+32 2 123 45 67',
            contactType: 'admissions'
          }
        }}
      />
      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={styles.heroOverlay} />
        <img
          src="https://picsum.photos/1600/900?random=100"
          alt="Technology education team collaborating"
          className={styles.heroImage}
        />
        <div className="container">
          <div className={styles.heroContent}>
            <h1 id="hero-title">Advance your digital career with mentor-led learning in Belgium</h1>
            <p>
              IT Learning Hub blends rigorous instruction, collaborative labs, and personalised coaching so you can build
              in-demand web, data, and security expertise that Belgian employers trust.
            </p>
            <div className={styles.ctaGroup}>
              <Link to="/courses" className="btn">
                Explore Courses
              </Link>
              <Link to="/methodology" className="btn btnSecondary">
                Discover Our Approach
              </Link>
            </div>
            <div className={styles.heroMeta}>
              <span>Live sessions in English &amp; Dutch</span>
              <span>Flexible evening cohorts</span>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.aboutPreview}`} aria-labelledby="about-preview-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="about-preview-title">Learning tailored for Belgium&apos;s tech ambitions</h2>
            <p>
              We partner with startups, scale-ups, and enterprise teams to co-design learning journeys rooted in real
              product challenges. From Brussels to Antwerp, our learners accelerate innovation while building rewarding
              careers.
            </p>
          </div>
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {animatedStats[index]}
                  {stat.suffix}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.coursesSection}`} aria-labelledby="featured-courses-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="featured-courses-title">Featured learning paths</h2>
            <p>
              Choose immersive programs built with industry mentors. Every pathway combines live instruction, project
              sprints, and collaborative reviews so you can deliver value from day one.
            </p>
          </div>
          <div className={styles.courseGrid}>
            {featuredCourses.map((course) => (
              <article key={course.title} className={styles.courseCard}>
                <img src={course.image} alt={`${course.title} visual`} />
                <div className={styles.courseContent}>
                  <span className={styles.courseTag}>{course.tag}</span>
                  <h3>{course.title}</h3>
                  <p>{course.description}</p>
                  <Link to={course.link} className={styles.courseLink}>
                    View course outline →
                  </Link>
                </div>
              </article>
            ))}
          </div>

          <div className={styles.projects}>
            <div className={styles.projectsHeader}>
              <h3>Capstone project showcase</h3>
              <div className={styles.projectFilters} role="tablist" aria-label="Project filters">
                {['All', 'Web Development', 'Data Science', 'Cybersecurity', 'DevOps'].map((category) => (
                  <button
                    key={category}
                    type="button"
                    role="tab"
                    className={projectFilter === category ? styles.activeFilter : ''}
                    onClick={() => setProjectFilter(category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.projectGrid}>
              {filteredProjects.map((project) => (
                <article key={project.title} className={styles.projectCard}>
                  <img src={project.image} alt={`${project.title} project`} />
                  <div>
                    <span className={styles.projectCategory}>{project.category}</span>
                    <h4>{project.title}</h4>
                    <p>{project.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>

          <div className={styles.blogPreview} aria-labelledby="blog-preview-title">
            <h3 id="blog-preview-title">Latest insights from our faculty</h3>
            <div className={styles.blogGrid}>
              {blogPreview.map((post) => (
                <article key={post.title} className={styles.blogCard}>
                  <img src={post.image} alt={`${post.title} illustration`} />
                  <div>
                    <h4>{post.title}</h4>
                    <p>{post.description}</p>
                    <Link to={post.link} className={styles.blogLink}>
                      Continue reading →
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.methodologySection}`} aria-labelledby="methodology-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="methodology-title">Learning methodology grounded in practice</h2>
            <p>
              Our methodology combines design thinking, agile delivery, and reflective coaching. Each sprint unites
              theory with application, ensuring you build resilient skills that stand up in the workplace.
            </p>
          </div>
          <div className={styles.processGrid}>
            {[
              {
                title: 'Discover & Define',
                description: 'Start with diagnostics to map your existing skills and gather business requirements.'
              },
              {
                title: 'Experience & Build',
                description: 'Iterate through labs, pair programming, and sandbox environments with mentor support.'
              },
              {
                title: 'Launch & Iterate',
                description: 'Ship production-grade deliverables and review with stakeholders for actionable feedback.'
              },
              {
                title: 'Reflect & Grow',
                description: 'Capture learning outcomes, build your portfolio narrative, and plan the next career sprint.'
              }
            ].map((step, index) => (
              <div key={step.title} className={styles.processCard}>
                <span className={styles.processStep}>0{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.instructorsSection}`} aria-labelledby="instructors-preview-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="instructors-preview-title">Meet a few of our lead mentors</h2>
            <p>
              Our instructors are active technologists. They bring current frameworks, Belgian market insights, and
              coaching expertise to every session.
            </p>
          </div>
          <div className={styles.instructorGrid}>
            {instructorsPreview.map((mentor) => (
              <article key={mentor.name} className={styles.instructorCard}>
                <img src={mentor.image} alt={`${mentor.name} portrait`} />
                <div>
                  <h3>{mentor.name}</h3>
                  <span>{mentor.expertise}</span>
                  <p>{mentor.bio}</p>
                </div>
              </article>
            ))}
          </div>
          <Link to="/instructors" className="btn btnSecondary">
            Meet the full instructor team
          </Link>
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialsSection}`} aria-labelledby="testimonials-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="testimonials-title">Learners building momentum</h2>
            <p>Hear how our community transforms ideas into professional outcomes across Belgium.</p>
          </div>
          <div className={styles.testimonialSlider}>
            <button
              type="button"
              className={styles.sliderControl}
              onClick={() =>
                setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
              }
              aria-label="Previous testimonial"
            >
              ‹
            </button>
            <div className={styles.testimonialCard}>
              <img
                src={testimonials[currentTestimonial].image}
                alt={`${testimonials[currentTestimonial].name} headshot`}
              />
              <blockquote>
                “{testimonials[currentTestimonial].message}”
                <footer>
                  <strong>{testimonials[currentTestimonial].name}</strong>
                  <span>{testimonials[currentTestimonial].role}</span>
                </footer>
              </blockquote>
            </div>
            <button
              type="button"
              className={styles.sliderControl}
              onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)}
              aria-label="Next testimonial"
            >
              ›
            </button>
          </div>
          <div className={styles.sliderDots} role="tablist" aria-label="Testimonials navigation">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                role="tab"
                aria-selected={currentTestimonial === index}
                onClick={() => setCurrentTestimonial(index)}
                className={currentTestimonial === index ? styles.activeDot : ''}
              >
                <span className="sr-only">Show testimonial from {testimonial.name}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.contactSection}`} aria-labelledby="contact-cta-title">
        <div className="container">
          <div className={styles.contactCard}>
            <div>
              <h2 id="contact-cta-title">Let’s design your learning journey</h2>
              <p>
                Whether you&apos;re upskilling your team or pivoting your career, our advisors will help you build a
                personalised roadmap to digital excellence.
              </p>
              <ul className={styles.contactDetails}>
                <li>
                  <strong>Visit us:</strong> Tech Campus 200, 1000 Brussels, Belgium
                </li>
                <li>
                  <strong>Call:</strong> +32 2 123 45 67
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
                </li>
              </ul>
              <div className={styles.ctaGroup}>
                <Link to="/contact" className="btn">
                  Connect with our team
                </Link>
                <Link to="/career" className="btn btnSecondary">
                  Explore career support
                </Link>
              </div>
            </div>
            <img
              src="https://picsum.photos/700/600?random=118"
              alt="Advisors supporting learners"
              className={styles.contactImage}
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;