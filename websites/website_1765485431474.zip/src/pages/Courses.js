import React, { useMemo, useState } from 'react';
import Seo from '../components/Seo';
import styles from './Courses.module.css';

const Courses = () => {
  const courseTracks = [
    {
      category: 'Web Development',
      title: 'Modern Frontend Engineering',
      image: 'https://picsum.photos/820/600?random=301',
      description:
        'Focus on component-driven architecture, performance optimisation, and scalable design systems with React and TypeScript.',
      outcomes: ['Accessible UI development', 'Design token systems', 'CI pipelines for UI quality']
    },
    {
      category: 'Web Development',
      title: 'Full-Stack Node.js & API Design',
      image: 'https://picsum.photos/820/600?random=302',
      description:
        'Craft secure APIs, integrate databases, and deploy cloud-native services using Node.js, PostgreSQL, and serverless patterns.',
      outcomes: ['API-first architecture', 'Security-first coding', 'Observability practices']
    },
    {
      category: 'Data Science',
      title: 'Applied Data Analytics with Python',
      image: 'https://picsum.photos/820/600?random=303',
      description:
        'Translate business questions into analytical workflows, build machine learning pipelines, and deploy dashboards.',
      outcomes: ['Data storytelling', 'ML lifecycle management', 'Responsible AI principles']
    },
    {
      category: 'Cybersecurity',
      title: 'Blue Team Operations',
      image: 'https://picsum.photos/820/600?random=304',
      description:
        'Operate within simulated SOC environments, perform threat hunting, and refine incident response strategies.',
      outcomes: ['SIEM configuration', 'Threat intelligence', 'Crisis communication playbooks']
    },
    {
      category: 'Cybersecurity',
      title: 'Secure Architecture Bootcamp',
      image: 'https://picsum.photos/820/600?random=305',
      description:
        'Architect zero trust networks, manage identity, and embed security-by-design into product delivery lifecycles.',
      outcomes: ['Zero trust frameworks', 'Cloud security automation', 'Compliance readiness']
    },
    {
      category: 'DevOps',
      title: 'Cloud Native DevOps',
      image: 'httpsum.photos/820/600?random=306',
      description:
        'Accelerate delivery with container orchestration, infrastructure as code, and progressive delivery pipelines.',
      outcomes: ['GitOps workflows', 'Kubernetes operations', 'Reliability metrics']
    }
  ];

  // Fix the typo in image link (should be picsum not httpsum)
  courseTracks[5].image = 'https://picsum.photos/820/600?random=306';

  const categories = ['All', ...new Set(courseTracks.map((track) => track.category))];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredCourses = useMemo(() => {
    if (activeCategory === 'All') return courseTracks;
    return courseTracks.filter((track) => track.category === activeCategory);
  }, [activeCategory, courseTracks]);

  return (
    <>
      <Seo
        title="Programming Courses and Tech Pathways"
        description="Browse immersive programming, data science, cybersecurity, and DevOps courses offered by IT Learning Hub in Belgium."
        keywords="programming courses Belgium, web development training, data science bootcamp"
        canonical="https://www.itlearninghub.be/courses"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Learning pathways designed for impact</h1>
          <p>
            Our course architecture blends live instruction, async learning, and project coaching. Choose a pathway to
            sharpen your expertise and deliver measurable value to your organisation.
          </p>
          <div className={styles.filters} role="tablist" aria-label="Course categories">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                onClick={() => setActiveCategory(category)}
                className={activeCategory === category ? styles.active : ''}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.courses}>
        <div className="container">
          <div className={styles.grid}>
            {filteredCourses.map((track) => (
              <article key={track.title} className={styles.card}>
                <img src={track.image} alt={`${track.title} course`} />
                <div className={styles.cardContent}>
                  <span className={styles.category}>{track.category}</span>
                  <h2>{track.title}</h2>
                  <p>{track.description}</p>
                  <ul>
                    {track.outcomes.map((outcome) => (
                      <li key={outcome}>{outcome}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Courses;