import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Seo
      title="Cookie Policy"
      description="Learn how IT Learning Hub uses cookies for analytics, personalisation, and essential functionality."
      canonical="https://www.itlearninghub.be/cookie-policy"
    />
    <section className={styles.page}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Updated: January 2024</p>
        <h2>What are cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit our website. They help us remember your
          preferences, analyse traffic, and deliver personalised experiences.
        </p>
        <h2>Types of cookies we use</h2>
        <ul>
          <li>
            <strong>Essential cookies:</strong> Required for site functionality such as authentication and security.
          </li>
          <li>
            <strong>Analytics cookies:</strong> Help us understand how visitors interact with our content.
          </li>
          <li>
            <strong>Preference cookies:</strong> Store language, theme, and accessibility settings.
          </li>
        </ul>
        <h2>Managing cookies</h2>
        <p>
          You can adjust cookie preferences through your browser settings or by using the controls in our cookie banner.
          Some features may be limited if you disable certain cookies.
        </p>
        <h2>Contact</h2>
        <p>
          For questions, email <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;