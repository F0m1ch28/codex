import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const nextErrors = {};
    if (!formData.name.trim()) nextErrors.name = 'Please share your name.';
    if (!formData.email.trim()) {
      nextErrors.email = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      nextErrors.email = 'Please provide a valid email.';
    }
    if (!formData.message.trim()) nextErrors.message = 'Let us know how we can support you.';
    return nextErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setStatus('Thank you for reaching out. Our advisory team will respond within one business day.');
      setFormData(initialState);
    }
  };

  return (
    <>
      <Seo
        title="Contact Us"
        description="Contact IT Learning Hub in Brussels for course advice, partnership enquiries, or customised technology training."
        keywords="contact IT Learning Hub, Brussels tech education contact"
        canonical="https://www.itlearninghub.be/contact"
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.grid}>
            <div>
              <h1>Connect with our advisory team</h1>
              <p>
                Ready to accelerate your digital capabilities? Share your goals, and we will align you with the right
                mentors, programs, and resources.
              </p>
              <ul className={styles.contactList}>
                <li>
                  <strong>Address:</strong> Tech Campus 200, 1000 Brussels, Belgium
                </li>
                <li>
                  <strong>Phone:</strong> +32 2 123 45 67
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
                </li>
              </ul>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Full name*</label>
                <input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(event) => setFormData({ ...formData, name: event.target.value })}
                  aria-invalid={!!errors.name}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Work email*</label>
                <input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(event) => setFormData({ ...formData, email: event.target.value })}
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="company">Company or organisation</label>
                <input
                  id="company"
                  type="text"
                  value={formData.company}
                  onChange={(event) => setFormData({ ...formData, company: event.target.value })}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">How can we help?*</label>
                <textarea
                  id="message"
                  rows="5"
                  value={formData.message}
                  onChange={(event) => setFormData({ ...formData, message: event.target.value })}
                  aria-invalid={!!errors.message}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className="btn">
                Submit message
              </button>
              {status && <p className={styles.status}>{status}</p>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;