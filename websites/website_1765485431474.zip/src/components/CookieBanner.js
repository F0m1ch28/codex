import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'itLearningHubCookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem(STORAGE_KEY);
    if (!storedConsent) {
      setTimeout(() => setIsVisible(true), 1200);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h4>Cookies for a smarter experience</h4>
        <p>
          We use cookies to improve site functionality, personalise learning recommendations, and understand how our
          community uses IT Learning Hub. Manage your preferences at any time in our Cookie Policy.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className="btn btnSecondary" onClick={() => handleConsent('declined')}>
          Decline
        </button>
        <button type="button" className="btn" onClick={() => handleConsent('accepted')}>
          Accept cookies
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;