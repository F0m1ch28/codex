import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <span className={styles.logo}>IT Learning Hub</span>
            <p>
              Empowering Belgium&apos;s tech community with immersive, mentor-led learning experiences across software
              engineering, data, and cybersecurity disciplines.
            </p>
            <p className={styles.address}>
              Tech Campus 200, 1000 Brussels, Belgium
              <br />
              +32 2 123 45 67
              <br />
              <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
            </p>
          </div>
          <div className={styles.links}>
            <h4>Explore</h4>
            <nav aria-label="Footer navigation">
              <NavLink to="/about">About Us</NavLink>
              <NavLink to="/courses">Our Courses</NavLink>
              <NavLink to="/methodology">Learning Methodology</NavLink>
              <NavLink to="/instructors">Our Instructors</NavLink>
              <NavLink to="/career">Career Support</NavLink>
              <NavLink to="/services">Services</NavLink>
            </nav>
          </div>
          <div className={styles.resources}>
            <h4>Resources</h4>
            <ul>
              <li>
                <NavLink to="/terms">Terms of Service</NavLink>
              </li>
              <li>
                <NavLink to="/privacy">Privacy Policy</NavLink>
              </li>
              <li>
                <NavLink to="/cookie-policy">Cookie Policy</NavLink>
              </li>
              <li>
                <a href="https://www.linkedin.com/company/it-learning-hub" target="_blank" rel="noreferrer">
                  LinkedIn Community
                </a>
              </li>
              <li>
                <a href="https://twitter.com/itlearninghub" target="_blank" rel="noreferrer">
                  Twitter Updates
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>&copy; {currentYear} IT Learning Hub. All rights reserved.</p>
          <p>Building future-ready digital skills across Belgium&apos;s tech ecosystem.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;