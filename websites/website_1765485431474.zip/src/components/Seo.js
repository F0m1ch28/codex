import { useEffect } from 'react';

const Seo = ({ title, description, keywords, canonical, jsonLd }) => {
  useEffect(() => {
    if (title) {
      document.title = `${title} | IT Learning Hub`;
    }

    const setMetaTag = (name, content) => {
      if (!content) return;
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    setMetaTag('description', description);
    setMetaTag('keywords', keywords);

    if (canonical) {
      let linkTag = document.querySelector('link[rel="canonical"]');
      if (!linkTag) {
        linkTag = document.createElement('link');
        linkTag.setAttribute('rel', 'canonical');
        document.head.appendChild(linkTag);
      }
      linkTag.setAttribute('href', canonical);
    }

    if (jsonLd) {
      const existing = document.getElementById('ld-json');
      if (existing) {
        existing.remove();
      }
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.id = 'ld-json';
      script.text = JSON.stringify(jsonLd);
      document.head.appendChild(script);
    }

    return () => {
      if (jsonLd) {
        const script = document.getElementById('ld-json');
        if (script) {
          script.remove();
        }
      }
    };
  }, [title, description, keywords, canonical, jsonLd]);

  return null;
};

export default Seo;