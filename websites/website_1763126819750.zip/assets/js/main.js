document.addEventListener('DOMContentLoaded', () => {
    // Mobile navigation
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.main-navigation');
    const navLinks = document.querySelectorAll('.main-navigation a');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navigation.classList.toggle('open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navigation.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    // Scroll to top button
    const scrollBtn = document.getElementById('scrollTop');
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                scrollBtn.style.display = 'flex';
            } else {
                scrollBtn.style.display = 'none';
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const consentKey = 'nc_cookie_consent';

    if (cookieBanner && acceptCookiesBtn) {
        const hasConsent = localStorage.getItem(consentKey);
        if (!hasConsent) {
            cookieBanner.classList.add('active');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.remove('active');
        });
    }
});