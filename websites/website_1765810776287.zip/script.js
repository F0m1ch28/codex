document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        siteNav.classList.remove('is-open');
      });
    });
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    const consent = localStorage.getItem('csm-cookie-consent');

    if (!consent) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }

    const closeBanner = (value) => {
      localStorage.setItem('csm-cookie-consent', value);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', () => closeBanner('accepted'));
    declineBtn?.addEventListener('click', () => closeBanner('declined'));
  }
});