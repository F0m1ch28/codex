document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      const isVisible = mainNav.getAttribute("data-visible") === "true";
      mainNav.setAttribute("data-visible", !isVisible);
      navToggle.setAttribute("aria-expanded", String(!isVisible));
    });
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("cc_cookie_choice");
    if (!storedChoice) {
      cookieBanner.classList.add("is-visible");
    }
    const acceptButton = cookieBanner.querySelector("[data-accept]");
    const declineButton = cookieBanner.querySelector("[data-decline]");

    const setChoice = (value) => {
      localStorage.setItem("cc_cookie_choice", value);
      cookieBanner.classList.remove("is-visible");
    };

    acceptButton?.addEventListener("click", () => setChoice("accepted"));
    declineButton?.addEventListener("click", () => setChoice("declined"));
  }

  const planForm = document.querySelector("[data-plan-form]");
  if (planForm) {
    const radios = planForm.querySelectorAll('input[name="plan"]');
    const summary = {
      name: document.querySelector("[data-plan-name]"),
      price: document.querySelector("[data-plan-price]"),
      speed: document.querySelector("[data-plan-speed]"),
      hash: document.querySelector("[data-plan-hash]")
    };
    const customGroup = planForm.querySelector("[data-custom-input]");
    const customAmount = planForm.querySelector("[data-custom-amount]");

    const updateSummary = (input) => {
      if (!input) return;
      if (input.value === "custom") {
        customGroup?.classList.add("is-visible");
        const amount = Number(customAmount?.value || 0);
        summary.name.textContent = `Custom Velocity Hash`;
        summary.price.textContent = amount ? `${amount.toFixed(2)} USDT` : "Enter amount";
        const customSpeed = amount ? Math.min(400, Math.round(amount * 0.9)) : 0;
        summary.speed.textContent = customSpeed ? `${customSpeed}% acceleration` : "Awaiting input";
        const hashVolume = amount ? (amount / 10).toFixed(2) : "0.00";
        summary.hash.textContent = `${hashVolume} GH/s committed`;
      } else {
        customGroup?.classList.remove("is-visible");
        summary.name.textContent = input.dataset.name;
        summary.price.textContent = `${input.dataset.price} USDT`;
        summary.speed.textContent = `${input.dataset.speed}% acceleration`;
        summary.hash.textContent = `${input.dataset.hash} GH/s committed`;
      }
    };

    radios.forEach((radio) => {
      radio.addEventListener("change", () => updateSummary(radio));
    });

    customAmount?.addEventListener("input", () => {
      const customRadio = planForm.querySelector('input[value="custom"]');
      if (customRadio?.checked) {
        updateSummary(customRadio);
      }
    });

    updateSummary(planForm.querySelector('input[name="plan"]:checked'));
  }

  document.querySelectorAll("[data-form-demo]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const statusField = form.querySelector("[data-form-status]");
      if (statusField) {
        statusField.textContent = "Submitted securely. An operations steward will verify and respond shortly.";
      }
      form.reset();
    });
  });
});