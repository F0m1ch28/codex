```javascript
import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Magazine.module.css';

const articles = [
  {
    slug: 'estabilizacion-frecuencia',
    title: 'Estabilización de frecuencia en redes con alta penetración renovable',
    category: 'Integración solar/eólica',
    date: '2024-03-02',
    summary:
      'Estudio de algoritmos de respuesta rápida que sincronizan BESS con eventos de frecuencia en redes de baja inercia.',
  },
  {
    slug: 'gestion-termica-bess',
    title: 'Gestión térmica en sistemas BESS de gran escala',
    category: 'Química',
    date: '2024-01-18',
    summary:
      'Comparativa entre refrigeración líquida y evaporativa para limitar gradientes de temperatura en celdas LFP.',
  },
  {
    slug: 'segunda-vida-baterias',
    title: 'Segunda vida de baterías: modelos y aplicaciones',
    category: 'Normativas',
    date: '2023-12-12',
    summary:
      'Criterios de clasificación para reutilizar módulos en almacenamiento estacionario y marcos regulatorios vigentes.',
  },
];

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'TerraWatt Storage Solutions',
  'url': 'https://www.terrawattstore.com',
  'telephone': '+34 917 53 94 28',
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259D',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  }
};

const itemListSchema = {
  '@context': 'https://schema.org',
  '@type': 'ItemList',
  'itemListElement': articles.map((article, index) => ({
    '@type': 'Article',
    'position': index + 1,
    'headline': article.title,
    'datePublished': article.date,
    'url': `https://www.terrawattstore.com/revista/${article.slug}`
  }))
};

const Magazine = () => {
  const [filter, setFilter] = useState('Todos');

  const filteredArticles = useMemo(() => {
    if (filter === 'Todos') {
      return articles;
    }
    return articles.filter((article) => article.category === filter);
  }, [filter]);

  return (
    <>
      <SEO
        title="Análisis sobre Tecnología de Almacenamiento | TerraWatt"
        description="Artículos técnicos sobre estabilización de frecuencia, gestión térmica en BESS y segunda vida de baterías."
        canonical="https://www.terrawattstore.com/revista"
        openGraph={{
          'og:title': 'Revista TerraWatt',
          'og:description': 'Publicaciones técnicas sobre almacenamiento energético y estabilidad de red.',
          'og:type': 'website',
          'og:url': 'https://www.terrawattstore.com/revista'
        }}
        structuredData={[organizationSchema, itemListSchema]}
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Análisis sobre Tecnología de Almacenamiento</h1>
          <p>
            Publicamos investigaciones aplicadas, casos de uso y perspectivas regulatorias para sistemas BESS y plantas híbridas.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.filters}>
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'Todos' ? styles.filterActive : ''}`}
            onClick={() => setFilter('Todos')}
          >
            Todos
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'Química' ? styles.filterActive : ''}`}
            onClick={() => setFilter('Química')}
          >
            Química
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'Integración solar/eólica' ? styles.filterActive : ''}`}
            onClick={() => setFilter('Integración solar/eólica')}
          >
            Integración solar/eólica
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'Normativas' ? styles.filterActive : ''}`}
            onClick={() => setFilter('Normativas')}
          >
            Normativas
          </button>
        </div>

        <div className={styles.list}>
          {filteredArticles.map((article) => (
            <article key={article.slug} className={styles.articleCard}>
              <header>
                <p className={styles.category}>{article.category}</p>
                <h2>{article.title}</h2>
                <time dateTime={article.date}>
                  {new Date(article.date).toLocaleDateString('es-ES', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </time>
              </header>
              <p className={styles.summary}>{article.summary}</p>
              <Link to={`/revista/${article.slug}`} className={styles.readMore}>
                Leer artículo →
              </Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Magazine;
```