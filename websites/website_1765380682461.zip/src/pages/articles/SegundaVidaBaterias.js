```javascript
import React from 'react';
import SEO from '../../components/SEO';
import styles from './Article.module.css';

const articleSchema = {
  '@context': 'https://schema.org',
  '@type': 'Article',
  'headline': 'Segunda vida de baterías: modelos y aplicaciones',
  'description': 'Criterios de clasificación para reutilizar módulos en almacenamiento estacionario y marcos regulatorios vigentes en España.',
  'author': {
    '@type': 'Organization',
    'name': 'TerraWatt Storage Solutions'
  },
  'publisher': {
    '@type': 'Organization',
    'name': 'TerraWatt Storage Solutions'
  },
  'datePublished': '2023-12-12',
  'mainEntityOfPage': {
    '@type': 'WebPage',
    '@id': 'https://www.terrawattstore.com/revista/segunda-vida-baterias'
  }
};

const SegundaVidaBaterias = () => (
  <>
    <SEO
      title="Segunda vida de baterías: modelos y aplicaciones | TerraWatt"
      description="Modelos de clasificación para segunda vida de baterías y marcos regulatorios para su integración en proyectos estacionarios."
      canonical="https://www.terrawattstore.com/revista/segunda-vida-baterias"
      openGraph={{
        'og:title': 'Segunda vida de baterías',
        'og:description': 'Modelos y aplicaciones para reutilizar baterías en almacenamiento estacionario.',
        'og:type': 'article',
        'og:url': 'https://www.terrawattstore.com/revista/segunda-vida-baterias'
      }}
      structuredData={[articleSchema]}
    />
    <article className={styles.article}>
      <header className={styles.header}>
        <p className={styles.category}>Normativas</p>
        <h1>Segunda vida de baterías: modelos y aplicaciones</h1>
        <time dateTime="2023-12-12">12 de diciembre de 2023</time>
      </header>
      <section className={styles.content}>
        <p>
          La reutilización de módulos favorece proyectos estacionarios que requieren potencias moderadas y densidades energéticas altas. Presentamos criterios de clasificación y normativa aplicable.
        </p>
        <h2>Modelos de clasificación</h2>
        <p>
          Evaluamos el estado de salud mediante ensayos de capacidad, resistencia interna y análisis de historial de uso. Definimos clases A, B y C con distintos ámbitos de aplicación.
        </p>
        <h2>Aplicaciones recomendadas</h2>
        <ul>
          <li>Clases A: microrredes, respaldo industrial con alta exigencia.</li>
          <li>Clases B: integración en comunidades energéticas y aplicaciones de peak shaving.</li>
          <li>Clases C: proyectos de baja potencia y soporte a telecomunicaciones.</li>
        </ul>
        <h2>Marco regulatorio</h2>
        <p>
          En España, el Real Decreto 646/2020 y las directrices europeas promueven la trazabilidad y certificación del proceso. Trabajamos con laboratorios acreditados para certificar cada lote reutilizado.
        </p>
      </section>
    </article>
  </>
);

export default SegundaVidaBaterias;
```