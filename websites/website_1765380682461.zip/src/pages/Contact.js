```javascript
import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contact.module.css';

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'TerraWatt Storage Solutions',
  'url': 'https://www.terrawattstore.com',
  'telephone': '+34 917 53 94 28',
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259D',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  },
  'contactPoint': {
    '@type': 'ContactPoint',
    'telephone': '+34 917 53 94 28',
    'email': 'info@terrawattstore.com',
    'contactType': 'Servicio técnico'
  }
};

const Contact = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    empresa: '',
    mensaje: ''
  });
  const [feedback, setFeedback] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.nombre || !formData.email || !formData.mensaje) {
      setFeedback('Por favor, completa los campos requeridos.');
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      setFeedback('El correo electrónico no tiene el formato correcto.');
      return;
    }
    setFeedback('Tu mensaje ha sido registrado. Nos pondremos en contacto contigo.');
    setFormData({
      nombre: '',
      email: '',
      empresa: '',
      mensaje: ''
    });
  };

  return (
    <>
      <SEO
        title="Conecta con TerraWatt | TerraWatt Storage Solutions"
        description="Contacta con TerraWatt Storage Solutions para proyectos BESS, investigación y plataformas power-to-grid."
        canonical="https://www.terrawattstore.com/contacto"
        openGraph={{
          'og:title': 'Contacto TerraWatt',
          'og:description': 'Conecta con el equipo de TerraWatt Storage Solutions en Madrid.',
          'og:type': 'website',
          'og:url': 'https://www.terrawattstore.com/contacto'
        }}
        structuredData={[organizationSchema]}
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Conecta con TerraWatt</h1>
          <p>Compártenos los detalles de tu proyecto de almacenamiento y te acompañaremos con un enfoque sólido.</p>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="nombre">Nombre *</label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={formData.nombre}
                onChange={handleChange}
                placeholder="Nombre y apellidos"
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="email">Correo electrónico *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="persona@empresa.com"
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="empresa">Empresa</label>
              <input
                id="empresa"
                name="empresa"
                type="text"
                value={formData.empresa}
                onChange={handleChange}
                placeholder="Nombre de la organización"
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="mensaje">Mensaje *</label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows="5"
                value={formData.mensaje}
                onChange={handleChange}
                placeholder="Describe objetivos, potencia requerida, plazos..."
              />
            </div>
            <button type="submit" className={styles.submitButton}>
              Enviar mensaje
            </button>
            {feedback && <p className={styles.feedback}>{feedback}</p>}
          </form>

          <div className={styles.contactInfo}>
            <div className={styles.infoCard}>
              <h2>Datos de contacto</h2>
              <p>Torre Emperador Castellana</p>
              <p>Paseo de la Castellana 259D</p>
              <p>28046 Madrid, Spain</p>
              <a href="tel:+34917539428">+34 917 53 94 28</a>
              <a href="mailto:info@terrawattstore.com">info@terrawattstore.com</a>
            </div>
            <div className={styles.mapContainer}>
              <iframe
                title="Ubicación TerraWatt Storage Solutions"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.611183981096!2d-3.6870695234005508!3d40.4795846537097!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd422fdc92d0d1ab%3A0x41f775888b859f6e!2sTorre%20Emperador%20Castellana!5e0!3m2!1ses!2ses!4v1712133333333!5m2!1ses!2ses"
                width="100%"
                height="320"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
```