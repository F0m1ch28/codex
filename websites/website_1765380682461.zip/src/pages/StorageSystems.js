```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './StorageSystems.module.css';

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'TerraWatt Storage Solutions',
  'url': 'https://www.terrawattstore.com',
  'telephone': '+34 917 53 94 28',
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259D',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  }
};

const StorageSystems = () => (
  <>
    <SEO
      title="Tecnologías & Arquitecturas Avanzadas | TerraWatt Storage Solutions"
      description="Soluciones BESS con baterías de litio, BMS inteligente, refrigeración líquida y VPP para estabilidad de la red."
      canonical="https://www.terrawattstore.com/sistemas-almacenamiento"
      openGraph={{
        'og:title': 'Sistemas de almacenamiento TerraWatt',
        'og:description': 'Arquitecturas BESS, inversores bidireccionales y virtual power plant para España.',
        'og:type': 'website',
        'og:url': 'https://www.terrawattstore.com/sistemas-almacenamiento'
      }}
      structuredData={[organizationSchema]}
    />
    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Tecnologías & Arquitecturas Avanzadas</h1>
        <p>
          Diseñamos sistemas BESS modulares que combinan baterías de litio con controladores de potencia bidireccionales y refrigeración líquida de alta precisión.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.grid}>
        <article className={styles.card}>
          <h2>Baterías de litio</h2>
          <p>
            Matrices LFP y NMC seleccionadas para respuesta rápida, densidad energética equilibrada y compatibilidad con ciclos profundos.
          </p>
        </article>
        <article className={styles.card}>
          <h2>BMS inteligente</h2>
          <p>
            Supervisión por celdas con algoritmos de balanceo activo, estimación de estado de carga y protocolos seguros IEC 62619.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Refrigeración líquida</h2>
          <p>
            Circuitos redundantes con glicol y control PID, asegurando gradientes térmicos inferiores a 5°C en cada rack.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Inversores bidireccionales</h2>
          <p>
            Conversión DC/AC de alta eficiencia con control vectorial, respuesta en menos de 150 ms y cumplimiento del código de red español.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Virtual Power Plant</h2>
          <p>
            Plataforma VPP propia que agrega BESS, generación distribuida y cargas flexibles para ofrecer servicios de ajuste.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Seguridad integral</h2>
          <p>
            Detección temprana de gases, supresión inerte y compartimentación para minimizar impactos ante cualquier incidencia.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.panelSection}>
      <div className={styles.panel}>
        <div className={styles.panelInfo}>
          <h2>Panel de control unificado</h2>
          <p>
            Panel digital con dashboards configurables: estados de celdas, flujos de energía, eventos de frecuencia y alarmas OT.
          </p>
          <ul>
            <li>Diagramas de flujo para seguimiento SOC / SOH.</li>
            <li>Integración EMS con APIs REST y protocolos Modbus TCP.</li>
            <li>Analítica predictiva utilizando gemelos digitales.</li>
          </ul>
        </div>
        <div className={styles.panelImage}>
          <img
            src="https://images.unsplash.com/photo-1581090700227-1e37b190418e?auto=format&fit=crop&w=1200&q=80"
            alt="Interfaz de panel de control para sistemas BESS"
          />
        </div>
      </div>
    </section>
  </>
);

export default StorageSystems;
```