```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './About.module.css';

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'TerraWatt Storage Solutions',
  'url': 'https://www.terrawattstore.com',
  'telephone': '+34 917 53 94 28',
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259D',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  }
};

const teamMembers = [
  {
    name: 'Irene Serrano',
    role: 'Directora de Ingeniería BESS',
    bio: 'Diseña arquitecturas BESS para integración en subestaciones y microrredes.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Manuel Ortega',
    role: 'Líder de Modelado Electroquímico',
    bio: 'Especialista en degradación de celdas LFP y modelado térmico.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'María Vidal',
    role: 'Responsable de Ciberseguridad Industrial',
    bio: 'Protege la capa OT del VPP con marcos IEC 62443.',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Javier Martín',
    role: 'Coordinador de Análisis de Red',
    bio: 'Evaluaciones de estabilidad y estudios EMT dentro de REE y TSOs europeos.',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=600&q=80'
  }
];

const About = () => (
  <>
    <SEO
      title="Ingeniería para la Era Renovable | TerraWatt Storage Solutions"
      description="Conoce la misión, metodología BESS y red colaborativa de TerraWatt Storage Solutions en España."
      canonical="https://www.terrawattstore.com/sobre-nosotros"
      openGraph={{
        'og:title': 'Ingeniería BESS en TerraWatt',
        'og:description': 'Metodologías avanzadas de almacenamiento energético y equipo multidisciplinar en Madrid.',
        'og:type': 'website',
        'og:url': 'https://www.terrawattstore.com/sobre-nosotros'
      }}
      structuredData={[organizationSchema]}
    />
    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Ingeniería para la Era Renovable</h1>
        <p>
          TerraWatt Storage Solutions impulsa plataformas BESS que permiten incorporar energía eólica y solar sin comprometer la estabilidad del sistema eléctrico.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <article className={styles.card}>
          <h2>Misión</h2>
          <p>
            Acelerar la transición energética mediante proyectos de almacenamiento que combinan precisión técnica, mantenimiento predictivo y una operación alineada con los códigos de red europeos.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Metodología BESS</h2>
          <ul className={styles.list}>
            <li>Estudios de red (load flow, cortocircuito, EMT) previos a cada despliegue.</li>
            <li>Dimensionamiento modular con análisis de degradación y ciclo de vida.</li>
            <li>Integración SCADA y EMS con protocolos IEC 61850 y SunSpec.</li>
          </ul>
        </article>
        <article className={styles.card}>
          <h2>Red colaborativa</h2>
          <p>
            Cooperamos con universidades, operadores de red, integradores EPC y laboratorios de ensayos para validar cada arquitectura BESS bajo escenarios de alta penetración renovable.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Equipo multidisciplinar</h2>
          <p>
            Nuestros especialistas combinan ingeniería eléctrica, química, software industrial y ciencia de datos, lo que permite desarrollar soluciones power-to-grid con visión integral.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Seguridad y sostenibilidad</h2>
          <p>
            Implantamos sistemas contra incendios adaptados a litio, análisis HAZOP y planes de circularidad para reutilizar módulos en su segunda vida operativa.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className={styles.sectionHeader}>
        <h2>Mentes detrás de TerraWatt</h2>
        <p>
          Coordinación ágil entre disciplinas para asegurar proyectos robustos y escalables en toda la geografía española.
        </p>
      </div>
      <div className={styles.teamGrid}>
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.teamCard}>
            <img src={member.image} alt={`${member.name}, ${member.role}`} />
            <div className={styles.teamInfo}>
              <h3>{member.name}</h3>
              <p className={styles.role}>{member.role}</p>
              <p className={styles.bio}>{member.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default About;
```