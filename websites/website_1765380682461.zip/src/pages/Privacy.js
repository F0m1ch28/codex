```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <SEO
      title="Política de privacidad | TerraWatt Storage Solutions"
      description="Política de privacidad y tratamiento de datos personales según RGPD para TerraWatt Storage Solutions."
      canonical="https://www.terrawattstore.com/privacidad"
      openGraph={{
        'og:title': 'Política de privacidad',
        'og:description': 'Información sobre la gestión de datos personales en TerraWatt Storage Solutions.',
        'og:type': 'website',
        'og:url': 'https://www.terrawattstore.com/privacidad'
      }}
    />
    <section className={styles.legal}>
      <h1>Política de privacidad</h1>
      <p>
        TerraWatt Storage Solutions trata los datos personales conforme al Reglamento (UE) 2016/679 y la Ley Orgánica 3/2018. El responsable del tratamiento es TerraWatt Storage Solutions, con domicilio en Paseo de la Castellana 259D, 28046 Madrid.
      </p>
      <h2>Finalidades</h2>
      <p>
        Los datos se usan para responder consultas técnicas, enviar comunicaciones relacionadas con almacenamiento energético y gestionar solicitudes de colaboración.
      </p>
      <h2>Legitimación</h2>
      <p>
        La base jurídica es el consentimiento otorgado por el usuario mediante los formularios del sitio web.
      </p>
      <h2>Destinatarios</h2>
      <p>
        No se ceden datos a terceros, salvo obligación legal o colaboradores necesarios para la prestación del servicio.
      </p>
      <h2>Derechos</h2>
      <p>
        Puedes ejercer los derechos de acceso, rectificación, supresión, limitación, oposición y portabilidad enviando un correo a info@terrawattstore.com.
      </p>
      <h2>Conservación</h2>
      <p>
        Los datos se conservarán durante el tiempo necesario para cumplir con la finalidad para la que fueron recabados y las obligaciones legales pertinentes.
      </p>
    </section>
  </>
);

export default Privacy;
```