```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <SEO
      title="Términos de uso | TerraWatt Storage Solutions"
      description="Condiciones de uso del sitio web de TerraWatt Storage Solutions."
      canonical="https://www.terrawattstore.com/terminos"
      openGraph={{
        'og:title': 'Términos de uso',
        'og:description': 'Condiciones de uso de TerraWatt Storage Solutions.',
        'og:type': 'website',
        'og:url': 'https://www.terrawattstore.com/terminos'
      }}
    />
    <section className={styles.legal}>
      <h1>Términos de uso</h1>
      <p>
        El acceso a este sitio implica la aceptación de las presentes condiciones. TerraWatt Storage Solutions mantiene este portal para difundir información técnica sobre almacenamiento energético.
      </p>
      <h2>Uso permitido</h2>
      <p>
        El contenido se destina a profesionales e instituciones interesadas en sistemas BESS, estabilidad de red y soluciones power-to-grid. No se permite su reproducción sin autorización previa.
      </p>
      <h2>Responsabilidad</h2>
      <p>
        TerraWatt Storage Solutions procura que la información sea precisa y actualizada, aunque se reserva el derecho a modificarla sin previo aviso. El usuario asumirá el uso que realice del material publicado.
      </p>
      <h2>Propiedad intelectual</h2>
      <p>
        Los textos, gráficos y elementos son titularidad de TerraWatt Storage Solutions o de terceros que han autorizado su uso. Queda prohibida su utilización fuera de las licencias concedidas.
      </p>
      <h2>Legislación aplicable</h2>
      <p>
        Estas condiciones se rigen por la normativa española. Para cualquier controversia se establece como jurisdicción los juzgados de Madrid capital.
      </p>
    </section>
  </>
);

export default Terms;
```