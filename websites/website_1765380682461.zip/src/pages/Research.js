```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Research.module.css';

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'TerraWatt Storage Solutions',
  'url': 'https://www.terrawattstore.com',
  'telephone': '+34 917 53 94 28',
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259D',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  }
};

const Research = () => (
  <>
    <SEO
      title="Investigación en Almacenamiento | TerraWatt Storage Solutions"
      description="Ensayos de ciclo de vida, modelado electroquímico, colaboraciones científicas y biblioteca técnica de TerraWatt."
      canonical="https://www.terrawattstore.com/investigacion"
      openGraph={{
        'og:title': 'Investigación TerraWatt',
        'og:description': 'Laboratorios, pruebas de estrés y colaboraciones científicas para almacenamiento energético.',
        'og:type': 'website',
        'og:url': 'https://www.terrawattstore.com/investigacion'
      }}
      structuredData={[organizationSchema]}
    />
    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Investigación en Almacenamiento</h1>
        <p>
          Validamos tecnologías BESS mediante ensayos de ciclo de vida, modelado electroquímico, colaboraciones científicas y una biblioteca técnica siempre activa.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.grid}>
        <article className={styles.card}>
          <h2>Ensayos de ciclo de vida</h2>
          <p>
            Cámaras climáticas y bancos de 1C para evaluar degradación, resistencia interna y eficiencia coulómbica en múltiples perfiles de carga.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Modelado electroquímico</h2>
          <p>
            Modelos pseudo-2D y ECM parametrizados, capaces de simular la evolución del estado de salud con ciclos parciales y estrés térmico.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Colaboraciones científicas</h2>
          <p>
            Trabajo conjunto con CSIC, universidades españolas y laboratorios europeos para compartir resultados y validar algoritmos propios.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Investigaciones técnicas</h2>
          <p>
            Estudios sobre estabilidad de frecuencia, control de inercia sintética y algoritmos de despacho para microrredes con alta penetración renovable.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Biblioteca y diagramas</h2>
          <p>
            Repositorio digital con esquemas eléctricos, diagramas unifilares, curvas de degradación y documentación de pruebas certificadas.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.labSection}>
      <div className={styles.labContent}>
        <h2>Laboratorio TerraWatt</h2>
        <p>
          Contamos con instrumentación para análisis de impedancia, cromatografía de gases liberados y sistemas HIL que replican escenarios de la red.
        </p>
        <div className={styles.labHighlights}>
          <div>
            <h3>Herramientas avanzadas</h3>
            <ul>
              <li>Analizadores de espectro y osciloscopios de 1 GHz.</li>
              <li>Simuladores de red trifásica de hasta 5 MVA.</li>
              <li>Plataforma HIL para probar controladores en lazo cerrado.</li>
            </ul>
          </div>
          <div>
            <h3>Datos compartidos</h3>
            <ul>
              <li>Protocolos de prueba normalizados para proyectos EPC.</li>
              <li>Informes comparativos de celdas LFP vs NMC.</li>
              <li>Tablas de rendimiento a distintas profundidades de descarga.</li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.labImage}>
        <img
          src="https://images.unsplash.com/photo-1583947215259-38e31be875a8?auto=format&fit=crop&w=1200&q=80"
          alt="Laboratorio de pruebas electroquímicas"
        />
      </div>
    </section>
  </>
);

export default Research;
```