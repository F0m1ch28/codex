```javascript
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const initialMetrics = [
  { label: 'Capacidad desplegada', value: 0, target: 820, unit: 'MWh' },
  { label: 'Proyectos activos', value: 0, target: 27, unit: '' },
  { label: 'Horas de operación monitorizadas', value: 0, target: 540000, unit: '+' },
];

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'TerraWatt Storage Solutions',
  'url': 'https://www.terrawattstore.com',
  'telephone': '+34 917 53 94 28',
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259D',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  }
};

const Home = () => {
  const [metrics, setMetrics] = useState(initialMetrics);
  const [email, setEmail] = useState('');
  const [newsletterFeedback, setNewsletterFeedback] = useState('');

  useEffect(() => {
    const animation = setTimeout(() => {
      setMetrics((prev) =>
        prev.map((metric) => ({
          ...metric,
          value: metric.target
        }))
      );
    }, 300);
    return () => clearTimeout(animation);
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email.trim()) {
      setNewsletterFeedback('Introduce tu correo electrónico para unirte al boletín.');
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) {
      setNewsletterFeedback('El formato del correo no es válido.');
      return;
    }
    setNewsletterFeedback('Gracias por suscribirte al Boletín Tecnológico de TerraWatt.');
    setEmail('');
  };

  return (
    <>
      <SEO
        title="TerraWatt Storage Solutions | Almacenamiento energético avanzado en España"
        description="Integración de sistemas BESS, ingeniería de baterías grid-scale y laboratorio de investigación para la estabilidad de red en España."
        canonical="https://www.terrawattstore.com/"
        openGraph={{
          'og:title': 'TerraWatt Storage Solutions',
          'og:description': 'Plataforma integral de almacenamiento energético y centro de investigación en Madrid.',
          'og:type': 'website',
          'og:url': 'https://www.terrawattstore.com/'
        }}
        structuredData={[organizationSchema]}
      />
      <div className={styles.hero}>
        <div className={styles.heroOverlay}>
          <p className={styles.heroKicker}>BESS • Litio • Power-to-Grid</p>
          <h1 className={styles.heroTitle}>Almacenando el Futuro</h1>
          <p className={styles.heroSubtitle}>
            TerraWatt Storage Solutions asegura la estabilidad de la red española mediante sistemas de almacenamiento energético de gran escala con control térmico preciso y gestión digital avanzada.
          </p>
          <div className={styles.heroActions}>
            <Link to="/sistemas-almacenamiento" className={styles.primaryButton}>
              Explora Nuestras Soluciones
            </Link>
            <Link to="/investigacion" className={styles.secondaryButton}>
              Investigación activa
            </Link>
          </div>
        </div>
      </div>

      <section className={styles.introSection}>
        <div className={styles.introContent}>
          <article className={styles.introText}>
            <h2>Integración inteligente de almacenamiento energético</h2>
            <p>
              Desde Madrid diseñamos, modelamos y desplegamos sistemas BESS que conectan generación renovable con la demanda, equilibrando frecuencia y aportando capacidad de regulación primaria y secundaria.
            </p>
            <p>
              Nuestro equipo combina ingeniería eléctrica, software industrial y análisis de datos para alinear litio, electrónica de potencia y estrategias power-to-grid adaptadas a la península ibérica.
            </p>
          </article>
          <div className={styles.statsGrid} aria-label="Indicadores principales">
            {metrics.map((metric) => (
              <div key={metric.label} className={styles.statCard}>
                <span className={styles.statLabel}>{metric.label}</span>
                <strong className={styles.statValue}>
                  {metric.value.toLocaleString('es-ES')}
                  <span className={styles.statUnit}>{metric.unit}</span>
                </strong>
                <div className={styles.progressTrack}>
                  <div
                    className={styles.progressFill}
                    style={{ width: `${Math.min(100, (metric.value / metric.target) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className={styles.sectionHeader}>
          <h2>Cobertura BESS en España</h2>
          <p>
            Monitorizamos nodos clave en la red de transporte para garantizar que cada instalación aporta potencia firme y respuesta dinámica ante desbalances.
          </p>
        </div>
        <div className={styles.mapWrapper}>
          <iframe
            title="Mapa de proyectos BESS TerraWatt"
            src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d973421.9980602829!2d-3.708645!3d40.416775!3m2!1i1024!2i768!4f13.1!2m1!1senergy%20storage%20spain!5e0!3m2!1ses!2ses!4v1712132132132!5m2!1ses!2ses"
            width="100%"
            height="360"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
          <ul className={styles.mapLegend}>
            <li>
              <span className={styles.legendDot} aria-hidden="true" />
              Plataforma híbrida solar+BESS — Sevilla 150 MW / 300 MWh
            </li>
            <li>
              <span className={styles.legendDot} aria-hidden="true" />
              Nodo de regulación primaria — Zamora 90 MW / 180 MWh
            </li>
            <li>
              <span className={styles.legendDot} aria-hidden="true" />
              Centro de pruebas VPP — Madrid 42 MW / 84 MWh
            </li>
          </ul>
        </div>
      </section>

      <section className={styles.monitorSection}>
        <div className={styles.sectionHeader}>
          <h2>Monitor de capacidad y estabilidad</h2>
          <p>
            Datos agregados en tiempo real para validar rendimiento térmico, disponibilidad y respuesta a eventos de frecuencia.
          </p>
        </div>
        <div className={styles.dashboard}>
          <div className={styles.metricPanel}>
            <h3>Capacidad desplegada</h3>
            <p className={styles.metricValue}>820 MWh</p>
            <p className={styles.metricDescription}>
              Baterías de litio-ferrofosfato con arquitectura modular y redundancia N+1.
            </p>
          </div>
          <div className={styles.metricPanel}>
            <h3>Proyectos activos</h3>
            <p className={styles.metricValue}>27</p>
            <p className={styles.metricDescription}>
              Integraciones en subestaciones, hubs industriales y comunidades energéticas.
            </p>
          </div>
          <div className={styles.metricPanel}>
            <h3>Índice de respuesta</h3>
            <p className={styles.metricValue}>98,6%</p>
            <p className={styles.metricDescription}>
              Tiempo medio de entrega <span className={styles.inlineCode}>t ≤ 200 ms</span> ante eventos de frecuencia.
            </p>
          </div>
          <div className={styles.chartCard}>
            <h3>Perfil térmico controlado</h3>
            <div className={styles.chartBars}>
              {['Norte', 'Centro', 'Sur'].map((region, index) => (
                <div key={region} className={styles.barGroup}>
                  <span className={styles.barLabel}>{region}</span>
                  <div className={styles.barTrack}>
                    <div
                      className={styles.barFill}
                      style={{ height: `${60 + index * 10}%` }}
                    />
                  </div>
                  <span className={styles.barValue}>ΔT {4 + index}°C</span>
                </div>
              ))}
            </div>
            <p className={styles.chartNote}>
              Control de climatización líquida con coeficiente de transferencia optimizado para evitar gradientes térmicos.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.gallerySection}>
        <div className={styles.sectionHeader}>
          <h2>Galería tecnológica</h2>
          <p>
            Arquitecturas de almacenamiento, electrónica de potencia y salas de control diseñadas para la operación continua.
          </p>
        </div>
        <div className={styles.galleryGrid}>
          <figure className={styles.galleryItem}>
            <img
              src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80"
              alt="Contenedores BESS modulares conectados a la red"
            />
            <figcaption>
              Módulos BESS refrigerados con envolventes IP55 y racks configurables para litio-ferrofosfato.
            </figcaption>
          </figure>
          <figure className={styles.galleryItem}>
            <img
              src="https://images.unsplash.com/photo-1580894732444-8ecded7900cd?auto=format&fit=crop&w=1200&q=80"
              alt="Sala de control con pantallas de monitoreo energético"
            />
            <figcaption>
              Sala de control con SCADA, analítica de frecuencia y simulaciones EMT en tiempo real.
            </figcaption>
          </figure>
          <figure className={styles.galleryItem}>
            <img
              src="https://images.unsplash.com/photo-1584036533827-45bce166ad86?auto=format&fit=crop&w=1200&q=80"
              alt="Detalle de celdas de batería conectadas en serie"
            />
            <figcaption>
              Celdas prismáticas de litio con sensores de tensión y temperatura integrados en cada string.
            </figcaption>
          </figure>
          <figure className={styles.galleryItem}>
            <img
              src="https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1200&q=80"
              alt="Sistema de refrigeración líquida para baterías industriales"
            />
            <figcaption>
              Circuitos de refrigeración líquida con control PID y diagnóstico de bomba redundante.
            </figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.innovationSection}>
        <div className={styles.sectionHeader}>
          <h2>Innovación electroquímica</h2>
          <p>
            Laboratorios de análisis y modelado electroquímico para alargar la vida útil de las baterías y garantizar seguridad operacional.
          </p>
        </div>
        <div className={styles.innovationGrid}>
          <div className={styles.innovationCard}>
            <h3>Pipeline de experimentación</h3>
            <ol className={styles.processList}>
              <li>
                <strong>Caracterización inicial:</strong> ciclos C/3 con espectroscopía de impedancia y mapeo térmico.
              </li>
              <li>
                <strong>Modelado digital:</strong> algoritmos en <span className={styles.inlineCode}>Modelica</span> y <span className={styles.inlineCode}>Python</span> para simular degradación calendarizada.
              </li>
              <li>
                <strong>Validación:</strong> banco de pruebas de 2 MW con perfiles dinámicos ENTSO-E.
              </li>
            </ol>
          </div>
          <div className={styles.innovationCard}>
            <h3>Preguntas frecuentes</h3>
            <div className={styles.faqItem}>
              <button type="button" className={styles.faqQuestion}>
                ¿Cómo gestionamos el envejecimiento de celdas?
              </button>
              <p className={styles.faqAnswer}>
                Aplicamos balanceo activo y estimadores de estado de salud basados en machine learning para redistribuir corrientes y evitar estrés localizado.
              </p>
            </div>
            <div className={styles.faqItem}>
              <button type="button" className={styles.faqQuestion}>
                ¿Qué estrategias térmicas utilizamos?
              </button>
              <p className={styles.faqAnswer}>
                Controlamos la temperatura mediante loop líquido independiente por rack, combinado con ventilación cruzada y sensores redundantes tipo PT100.
              </p>
            </div>
            <div className={styles.faqItem}>
              <button type="button" className={styles.faqQuestion}>
                ¿Cómo se integra el VPP?
              </button>
              <p className={styles.faqAnswer}>
                Nuestras plataformas VPP agregan varios BESS con algoritmos de despacho predictivo para servicios de ajuste, black start y soporte a renovables intermitentes.
              </p>
            </div>
          </div>
          <div className={styles.innovationCard}>
            <h3>Testimonios técnicos</h3>
            <div className={styles.testimonial}>
              <p>
                “Los modelos de TerraWatt permitieron ajustar la respuesta de nuestra planta solar, estabilizando la frecuencia en episodios de baja inercia.”
              </p>
              <span className={styles.testimonialAuthor}>Responsable Operaciones — Red regional Norte</span>
            </div>
            <div className={styles.testimonial}>
              <p>
                “La supervisión térmica integrada redujo el gradiente entre celdas y habilitó mayores ventanas de operación.”
              </p>
              <span className={styles.testimonialAuthor}>Director Técnico — Parque eólico Levante</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.sectionHeader}>
          <h2>Boletín Tecnológico TerraWatt</h2>
          <p>
            Recibe análisis mensuales sobre BESS, estrategias power-to-grid y avances en estabilidad de red dentro del laboratorio TerraWatt.
          </p>
        </div>
        <form className={styles.ctaForm} onSubmit={handleSubmit}>
          <label htmlFor="newsletter-email" className={styles.srOnly}>
            Correo electrónico
          </label>
          <input
            id="newsletter-email"
            type="email"
            placeholder="tu.email@empresa.com"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className={styles.input}
            aria-describedby="newsletter-feedback"
          />
          <button type="submit" className={styles.primaryButton}>
            Suscribirse
          </button>
        </form>
        {newsletterFeedback && (
          <p id="newsletter-feedback" className={styles.feedback}>
            {newsletterFeedback}
          </p>
        )}
      </section>
    </>
  );
};

export default Home;
```