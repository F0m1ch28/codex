```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

const CookiesPolicy = () => (
  <>
    <SEO
      title="Política de cookies | TerraWatt Storage Solutions"
      description="Información sobre el uso de cookies técnicas y analíticas en TerraWatt Storage Solutions."
      canonical="https://www.terrawattstore.com/politica-cookies"
      openGraph={{
        'og:title': 'Política de cookies',
        'og:description': 'Uso de cookies técnicas y analíticas en TerraWatt Storage Solutions.',
        'og:type': 'website',
        'og:url': 'https://www.terrawattstore.com/politica-cookies'
      }}
    />
    <section className={styles.legal}>
      <h1>Política de cookies</h1>
      <p>
        Utilizamos cookies técnicas esenciales para el funcionamiento del sitio y analíticas para medir el rendimiento y uso de la plataforma.
      </p>
      <h2>¿Qué son las cookies?</h2>
      <p>
        Son pequeños archivos almacenados en el dispositivo del usuario que permiten recordar preferencias o reconocer la navegación.
      </p>
      <h2>Tipos de cookies</h2>
      <ul>
        <li><strong>Técnicas:</strong> permiten el funcionamiento básico del sitio.</li>
        <li><strong>Analíticas:</strong> recopilan datos de uso agregados para mejorar la experiencia.</li>
      </ul>
      <h2>Gestión</h2>
      <p>
        Puedes configurar o rechazar las cookies desde la configuración de tu navegador. El uso continuado del sitio implica aceptación de la política.
      </p>
      <h2>Actualizaciones</h2>
      <p>
        Esta política puede actualizarse para reflejar cambios en la normativa o en los servicios ofrecidos. Se recomienda revisarla periódicamente.
      </p>
    </section>
  </>
);

export default CookiesPolicy;
```