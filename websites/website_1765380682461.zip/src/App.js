```javascript
import React from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import Home from './pages/Home';
import About from './pages/About';
import StorageSystems from './pages/StorageSystems';
import Research from './pages/Research';
import Magazine from './pages/Magazine';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiesPolicy from './pages/CookiesPolicy';
import EstabilizacionFrecuencia from './pages/articles/EstabilizacionFrecuencia';
import GestionTermicaBess from './pages/articles/GestionTermicaBess';
import SegundaVidaBaterias from './pages/articles/SegundaVidaBaterias';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

const AppLayout = () => (
  <div className="app-shell">
    <Header />
    <main className="app-main">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/sobre-nosotros" element={<About />} />
        <Route path="/sistemas-almacenamiento" element={<StorageSystems />} />
        <Route path="/investigacion" element={<Research />} />
        <Route path="/revista" element={<Magazine />} />
        <Route path="/revista/estabilizacion-frecuencia" element={<EstabilizacionFrecuencia />} />
        <Route path="/revista/gestion-termica-bess" element={<GestionTermicaBess />} />
        <Route path="/revista/segunda-vida-baterias" element={<SegundaVidaBaterias />} />
        <Route path="/contacto" element={<Contact />} />
        <Route path="/terminos" element={<Terms />} />
        <Route path="/privacidad" element={<Privacy />} />
        <Route path="/politica-cookies" element={<CookiesPolicy />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

function App() {
  return (
    <BrowserRouter>
      <ScrollToTopOnRouteChange />
      <AppLayout />
    </BrowserRouter>
  );
}

export default App;
```