```javascript
import { useEffect } from 'react';

const ensureMetaTag = (attrName, attrValue, content) => {
  if (!attrValue) return null;
  let metaTag = document.querySelector(`meta[${attrName}='${attrValue}']`);
  if (!metaTag) {
    metaTag = document.createElement('meta');
    metaTag.setAttribute(attrName, attrValue);
    document.head.appendChild(metaTag);
  }
  metaTag.setAttribute('content', content);
  return metaTag;
};

const SEO = ({ title, description, canonical, openGraph = {}, structuredData = [] }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      ensureMetaTag('name', 'description', description);
    }
    if (canonical) {
      let link = document.querySelector("link[rel='canonical']");
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      link.setAttribute('href', canonical);
    }

    const ogEntries = Object.entries(openGraph || {});
    ogEntries.forEach(([property, content]) => {
      if (content) {
        ensureMetaTag('property', property, content);
      }
    });

    const existingStructured = document.querySelectorAll('script[data-structured="true"]');
    existingStructured.forEach((node) => node.remove());

    structuredData.forEach((dataObj, index) => {
      if (dataObj) {
        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.dataset.structured = 'true';
        script.dataset.index = `sd-${index}`;
        script.text = JSON.stringify(dataObj);
        document.head.appendChild(script);
      }
    });

    return () => {
      ogEntries.forEach(([property]) => {
        const tag = document.querySelector(`meta[property='${property}']`);
        if (tag) {
          tag.removeAttribute('content');
        }
      });
    };
  }, [title, description, canonical, openGraph, structuredData]);

  return null;
};

export default SEO;
```