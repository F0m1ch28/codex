```javascript
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen((prev) => !prev);
  const closeMenu = () => setOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Ir a inicio">
          TerraWatt<span className={styles.logoAccent}> Storage Solutions</span>
        </NavLink>
        <button
          className={styles.burger}
          onClick={toggleMenu}
          aria-expanded={open}
          aria-controls="primary-navigation"
          aria-label="Abrir menú de navegación"
        >
          <span className={styles.burgerLine} />
          <span className={styles.burgerLine} />
          <span className={styles.burgerLine} />
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${open ? styles.navOpen : ''}`}
          aria-label="Menú principal"
        >
          <NavLink
            to="/"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Inicio
          </NavLink>
          <NavLink
            to="/sobre-nosotros"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Sobre nosotros
          </NavLink>
          <NavLink
            to="/sistemas-almacenamiento"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Sistemas de almacenamiento
          </NavLink>
          <NavLink
            to="/investigacion"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Investigación
          </NavLink>
          <NavLink
            to="/revista"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Revista
          </NavLink>
          <NavLink
            to="/contacto"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
          >
            Contacto
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;
```