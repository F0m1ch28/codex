```javascript
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'terrawatt_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.message}>
          Usamos cookies técnicas y analíticas para mejorar la experiencia y comprender el rendimiento energético de nuestras plataformas.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={acceptCookies} className={styles.acceptButton}>
            Aceptar
          </button>
          <Link to="/politica-cookies" className={styles.moreButton}>
            Más información
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
```