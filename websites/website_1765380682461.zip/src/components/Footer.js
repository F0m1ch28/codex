```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.container}>
      <div className={styles.brandColumn}>
        <p className={styles.brandTitle}>TerraWatt Storage Solutions</p>
        <p className={styles.brandText}>
          Plataforma de ingeniería y centro de investigación especializado en almacenamiento energético de gran escala.
        </p>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Navegación</h3>
        <ul className={styles.list}>
          <li><NavLink to="/" className={styles.link}>Inicio</NavLink></li>
          <li><NavLink to="/sobre-nosotros" className={styles.link}>Sobre nosotros</NavLink></li>
          <li><NavLink to="/sistemas-almacenamiento" className={styles.link}>Sistemas de almacenamiento</NavLink></li>
          <li><NavLink to="/investigacion" className={styles.link}>Investigación</NavLink></li>
          <li><NavLink to="/revista" className={styles.link}>Revista</NavLink></li>
          <li><NavLink to="/contacto" className={styles.link}>Contacto</NavLink></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Contacto</h3>
        <address className={styles.address}>
          <span>Torre Emperador Castellana</span>
          <span>Paseo de la Castellana 259D</span>
          <span>28046 Madrid, Spain</span>
          <a className={styles.link} href="tel:+34917539428">+34 917 53 94 28</a>
          <a className={styles.link} href="mailto:info@terrawattstore.com">info@terrawattstore.com</a>
        </address>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Legal</h3>
        <ul className={styles.list}>
          <li><NavLink to="/terminos" className={styles.link}>Términos de uso</NavLink></li>
          <li><NavLink to="/privacidad" className={styles.link}>Política de privacidad</NavLink></li>
          <li><NavLink to="/politica-cookies" className={styles.link}>Política de cookies</NavLink></li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} TerraWatt Storage Solutions. Todos los derechos reservados.</p>
    </div>
  </footer>
);

export default Footer;
```