document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            primaryNav.classList.toggle("nav-open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".btn-accept");
    const declineBtn = document.querySelector(".btn-decline");
    const cookieChoice = localStorage.getItem("nucleaoojtCookiesChoice");

    if (!cookieChoice && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    const handleChoice = (choice) => {
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
        localStorage.setItem("nucleaoojtCookiesChoice", choice);
    };

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => handleChoice("declined"));
    }
});