import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Inflation.module.css";

const cpiData = [
  { month: "Jan", value: 5.6 },
  { month: "Feb", value: 6.1 },
  { month: "Mar", value: 7.3 },
  { month: "Apr", value: 6.8 },
  { month: "May", value: 5.9 },
  { month: "Jun", value: 6.5 }
];

const fxData = [
  { month: "Jan", value: 198 },
  { month: "Feb", value: 205 },
  { month: "Mar", value: 215 },
  { month: "Apr", value: 225 },
  { month: "May", value: 240 },
  { month: "Jun", value: 250 }
];

function Inflation() {
  const [highlightIndex, setHighlightIndex] = useState(null);

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Inflation Analytics | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Dive into Tu Progreso Hoy inflation methodology, CPI charts, FX analytics, and frequently asked questions."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Inflation methodology & analytics</h1>
        <p>
          Our observatory combines official CPI releases, provincial surveys,
          retail panels, and FX benchmarks to illuminate price dynamics across
          Argentina.
        </p>
      </header>

      <section className={styles.methodology}>
        <h2>Methodology pillars</h2>
        <div className={styles.pillars}>
          <article>
            <h3>Data aggregation</h3>
            <p>
              Official IPC (INDEC), subnational statistics, wholesale exchange
              boards, and private price monitors form our weekly dataset.
            </p>
          </article>
          <article>
            <h3>Normalization</h3>
            <p>
              Values are seasonally adjusted and reweighted with household
              expenditure patterns, enabling cross-category comparisons.
            </p>
          </article>
          <article>
            <h3>Interpretation</h3>
            <p>
              Insights are produced with contextual commentary, focusing on
              household budgets and SME cash-flow implications.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.charts}>
        <div className={styles.chartCard}>
          <h2>Monthly CPI Trend</h2>
          <svg viewBox="0 0 300 180" role="img" aria-label="CPI chart">
            <polyline
              fill="none"
              stroke="#2563eb"
              strokeWidth="3"
              points={cpiData
                .map(
                  (point, index) =>
                    `${(index / (cpiData.length - 1)) * 280 + 10}, ${
                      160 - point.value * 12
                    }`
                )
                .join(" ")}
            />
            {cpiData.map((point, index) => (
              <circle
                key={point.month}
                cx={(index / (cpiData.length - 1)) * 280 + 10}
                cy={160 - point.value * 12}
                r={highlightIndex === index ? 6 : 4}
                fill="#1f3a6f"
                onMouseEnter={() => setHighlightIndex(index)}
                onMouseLeave={() => setHighlightIndex(null)}
              >
                <title>{`${point.month}: ${point.value}%`}</title>
              </circle>
            ))}
          </svg>
          {highlightIndex !== null && (
            <p className={styles.tooltip}>
              {cpiData[highlightIndex].month}: {cpiData[highlightIndex].value}% m/m
            </p>
          )}
        </div>
        <div className={styles.chartCard}>
          <h2>ARS→USD FX Reference</h2>
          <svg viewBox="0 0 300 180" role="img" aria-label="FX chart">
            <polyline
              fill="none"
              stroke="#1f3a6f"
              strokeWidth="3"
              points={fxData
                .map(
                  (point, index) =>
                    `${(index / (fxData.length - 1)) * 280 + 10}, ${
                      160 - point.value
                    }`
                )
                .join(" ")}
            />
            {fxData.map((point, index) => (
              <circle
                key={point.month}
                cx={(index / (fxData.length - 1)) * 280 + 10}
                cy={160 - point.value}
                r={4}
                fill="#2563eb"
              >
                <title>{`${point.month}: ${point.value} ARS`}</title>
              </circle>
            ))}
          </svg>
          <p className={styles.note}>
            Reference series combines official and market-implied rates, adjusted
            for household accessibility.
          </p>
        </div>
      </section>

      <section className={styles.faq}>
        <h2>FAQ</h2>
        <details>
          <summary>How often are CPI datasets refreshed?</summary>
          <p>
            We update headline CPI monthly following INDEC releases and integrate
            private weekly surveys to detect early shifts in core categories.
          </p>
        </details>
        <details>
          <summary>
            What FX benchmarks do you monitor for Argentine households?
          </summary>
          <p>
            We incorporate official, MEP, and blended retail rates, with notes on
            accessibility, transaction limits, and policy adjustments.
          </p>
        </details>
        <details>
          <summary>
            Can I download historical data for personal analyses?
          </summary>
          <p>
            Subscribers can export CSV datasets with up to three years of history
            and apply our smoothing filters in their own spreadsheets.
          </p>
        </details>
      </section>
    </div>
  );
}

export default Inflation;