import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

function About() {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>About Tu Progreso Hoy | Mission & Values</title>
        <meta
          name="description"
          content="Learn about Tu Progreso Hoy, the educational SaaS platform empowering Argentina with inflation-aware personal finance learning."
        />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href="https://tuprogresohoy.com/about"
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Guiding Argentina toward confident financial futures</h1>
        <p>
          Tu Progreso Hoy nació en Buenos Aires con una misión clara: brindar
          educación financiera contextualizada, con datos oportunos y una
          comunidad de apoyo constante.
        </p>
      </section>
      <section className={styles.values}>
        <article>
          <h2>Our philosophy</h2>
          <p>
            We unite economists, designers, and educators to transform complex
            inflation narratives into everyday action. Every insight aligns with
            our promise: decisiones responsables, planes claros.
          </p>
        </article>
        <article>
          <h2>Community-centered learning</h2>
          <p>
            We co-create with learners across Argentina. Workshops, podcasts, and
            bilingual guides ensure every household can apply data-driven
            strategies seamlessly.
          </p>
        </article>
      </section>
      <section className={styles.timeline}>
        <h2>Milestones</h2>
        <div className={styles.timelineGrid}>
          <div>
            <span>2019</span>
            <h3>Initial research collective</h3>
            <p>
              Began aggregating CPI and FX data to support educators and
              journalists covering inflation stories.
            </p>
          </div>
          <div>
            <span>2021</span>
            <h3>Platform launch</h3>
            <p>
              Released the first SaaS modules with interactive dashboards and
              budgeting templates for Argentine households.
            </p>
          </div>
          <div>
            <span>2023</span>
            <h3>Community expansion</h3>
            <p>
              Introduced mentorship circles, community surveys, and open data
              collaborations with universities across Argentina.
            </p>
          </div>
        </div>
      </section>
      <section className={styles.impact}>
        <h2>Impact highlights</h2>
        <ul>
          <li>
            12,000+ learners complete monthly clinics on ARS to USD planning.
          </li>
          <li>
            45 partner schools integrate our micro-lessons in civic education
            programs.
          </li>
          <li>
            Weekly newsletters reach 28 provinces with actionable financial
            updates.
          </li>
        </ul>
      </section>
    </div>
  );
}

export default About;