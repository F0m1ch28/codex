import React from "react";
import { Helmet } from "react-helmet";
import styles from "./CookiePolicy.module.css";

function CookiePolicy() {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Cookie Policy | Tu Progreso Hoy</title>
      </Helmet>
      <h1>Cookie Policy</h1>
      <section>
        <h2>Types of cookies</h2>
        <p>
          We use essential cookies for authentication and analytics cookies to
          measure feature adoption. No advertising cookies are used.
        </p>
      </section>
      <section>
        <h2>Consent management</h2>
        <p>
          Users can accept or decline non-essential cookies in the banner. Choices
          are stored locally and can be updated anytime via our preferences page.
        </p>
      </section>
      <section>
        <h2>Retention</h2>
        <p>
          Cookie data is retained for up to 12 months unless you clear your
          browser storage earlier.
        </p>
      </section>
    </div>
  );
}

export default CookiePolicy;