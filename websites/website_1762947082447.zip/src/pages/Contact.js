import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

function Contact() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    message: "",
    optIn: false
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Please add your name.";
    }
    if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Provide a valid email.";
    }
    if (formData.message.trim().length < 20) {
      newErrors.message = "Message should contain at least 20 characters.";
    }
    if (!formData.optIn) {
      newErrors.optIn =
        "Confirm you agree to receive our confirmation email (double opt-in).";
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Contact Tu Progreso Hoy | Buenos Aires HQ</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy for inquiries about inflation analytics, courses, and partnerships. Located in Buenos Aires, Argentina."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Connect with Tu Progreso Hoy</h1>
        <p>
          We are based in Buenos Aires and support learners across Argentina.
          Let&apos;s explore how we can help your financial journey.
        </p>
      </section>
      <section className={styles.grid}>
        <div className={styles.info}>
          <h2>Contact details</h2>
          <p>
            Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            <br />
            Phone: <a href="tel:+541155551234">+54 11 5555-1234</a>
            <br />
            Email:{" "}
            <a href="mailto:info@tuprogresohoy.com">
              info@tuprogresohoy.com
            </a>
          </p>
          <iframe
            title="Tu Progreso Hoy Buenos Aires location"
            src="https://www.google.com/maps?q=Av.+9+de+Julio+1000,+C1043+Buenos+Aires,+Argentina&output=embed"
            loading="lazy"
          />
        </div>
        <form
          className={styles.form}
          onSubmit={handleSubmit}
          noValidate
          aria-label="Contact form"
        >
          <div className={styles.formGroup}>
            <label htmlFor="fullName">Name</label>
            <input
              id="fullName"
              name="fullName"
              type="text"
              value={formData.fullName}
              onChange={handleChange}
              aria-invalid={Boolean(errors.fullName)}
              required
            />
            {errors.fullName && (
              <span className={styles.error}>{errors.fullName}</span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              required
            />
            {errors.email && (
              <span className={styles.error}>{errors.email}</span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="message">How can we help?</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              required
            />
            {errors.message && (
              <span className={styles.error}>{errors.message}</span>
            )}
          </div>
          <div className={styles.checkbox}>
            <input
              id="optIn"
              name="optIn"
              type="checkbox"
              checked={formData.optIn}
              onChange={handleChange}
              aria-invalid={Boolean(errors.optIn)}
              required
            />
            <label htmlFor="optIn">
              I agree to receive a confirmation email and validate my request
              (double opt-in).
            </label>
          </div>
          {errors.optIn && <span className={styles.error}>{errors.optIn}</span>}
          <button type="submit">Send message</button>
          {submitted && (
            <p className={styles.success}>
              Thank you. Please check your inbox to confirm your request.
            </p>
          )}
        </form>
      </section>
    </div>
  );
}

export default Contact;