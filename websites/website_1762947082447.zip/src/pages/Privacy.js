import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

function Privacy() {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
      </Helmet>
      <h1>Privacy Policy</h1>
      <p>Effective date: May 2024</p>
      <section>
        <h2>Information we collect</h2>
        <p>
          We collect contact details, account credentials, and usage analytics to
          deliver our educational services and maintain platform security.
        </p>
      </section>
      <section>
        <h2>How we use data</h2>
        <p>
          Data supports personalization, service delivery, troubleshooting, and
          compliance with applicable regulations in Argentina.
        </p>
      </section>
      <section>
        <h2>Double opt-in communications</h2>
        <p>
          Email subscriptions require confirmation via double opt-in before
          messages are sent. Users may update communication preferences at any
          time.
        </p>
      </section>
      <section>
        <h2>Your rights</h2>
        <p>
          Users can request access, correction, or deletion of personal data by
          contacting info@tuprogresohoy.com.
        </p>
      </section>
    </div>
  );
}

export default Privacy;