import React from "react";
import { Helmet } from "react-helmet";
import styles from "./ThankYou.module.css";

function ThankYou() {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Thank You | Tu Progreso Hoy</title>
      </Helmet>
      <section className={styles.message}>
        <h1>Thank you for joining Tu Progreso Hoy</h1>
        <p>
          Please check your inbox and confirm your email address to complete the
          double opt-in process. Your trial lesson will be delivered upon
          confirmation.
        </p>
      </section>
    </div>
  );
}

export default ThankYou;