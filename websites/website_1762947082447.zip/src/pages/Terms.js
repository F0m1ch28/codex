import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

function Terms() {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Terms of Use | Tu Progreso Hoy</title>
      </Helmet>
      <h1>Terms of Use</h1>
      <p>Last updated: May 2024</p>
      <section>
        <h2>1. Overview</h2>
        <p>
          These Terms govern access and use of the Tu Progreso Hoy educational
          platform. By using our services you agree to comply with these Terms
          and applicable regulations in Argentina.
        </p>
      </section>
      <section>
        <h2>2. Educational content</h2>
        <p>
          Content is provided for educational purposes only. We share
          data-driven insights and financial literacy guidance but do not offer
          personalized financial services or investment products.
        </p>
      </section>
      <section>
        <h2>3. User responsibilities</h2>
        <p>
          Users must keep credentials secure, respect intellectual property, and
          follow all laws relating to financial education in their jurisdiction.
        </p>
      </section>
      <section>
        <h2>4. Liability</h2>
        <p>
          Tu Progreso Hoy is not liable for losses resulting from decisions made
          based on course materials or analytics. Users should seek professional
          advice when required.
        </p>
      </section>
    </div>
  );
}

export default Terms;