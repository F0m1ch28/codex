import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const services = [
  {
    title: "Inflation Intelligence Suite",
    description:
      "Real-time dashboards, CPI layer comparisons, and actionable alerts to protect your ARS cash flow.",
    benefits: ["Hourly FX signals", "CPI micro-segmentation", "Action prompts"],
    icon: "📊"
  },
  {
    title: "Personal Finance Coaching",
    description:
      "One-on-one and group clinics aligning income, expenses, and currency strategies with your goals.",
    benefits: ["Scenario coaching", "Savings rituals", "Debt planning"],
    icon: "🧭"
  },
  {
    title: "Institutional Partnerships",
    description:
      "Curriculum design, research collaborations, and bespoke reporting for schools and NGOs.",
    benefits: ["Custom data feeds", "Teacher training", "Community analytics"],
    icon: "🤝"
  }
];

function Services() {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Services | Tu Progreso Hoy Solutions</title>
        <meta
          name="description"
          content="Explore Tu Progreso Hoy services: inflation analytics, personal finance coaching, and educational partnerships across Argentina."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Solutions that keep pace with Argentina&apos;s economy</h1>
        <p>
          From dynamic dashboards to guided coaching, our services help
          households, educators, and organizations stay ahead of inflation and
          currency shifts.
        </p>
      </section>
      <section className={styles.cards} aria-label="Service offerings">
        {services.map((service, index) => (
          <article
            key={service.title}
            className={`${styles.card} ${
              activeIndex === index ? styles.cardActive : ""
            }`}
            onMouseEnter={() => setActiveIndex(index)}
            onFocus={() => setActiveIndex(index)}
            tabIndex={0}
          >
            <span className={styles.icon} aria-hidden="true">
              {service.icon}
            </span>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <ul>
              {service.benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>
    </div>
  );
}

export default Services;