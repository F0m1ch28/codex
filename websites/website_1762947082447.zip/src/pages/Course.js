import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Course.module.css";

const modules = [
  {
    title: "Module 1: Inflation decoding",
    details:
      "Understand price indices, official vs. alternative data, and how to translate them into weekly spending insights."
  },
  {
    title: "Module 2: Cash flow strategy",
    details:
      "Craft resilient budgets, prioritize expenses, and manage debt in a volatile rate environment."
  },
  {
    title: "Module 3: Savings architecture",
    details:
      "Design emergency funds, evaluate peso vs. dollar allocations, and align them with life goals."
  },
  {
    title: "Module 4: Planning rituals",
    details:
      "Create rituals for reviews and accountability, enabling long-term discipline with community support."
  }
];

function Course() {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Course Syllabus | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore the Tu Progreso Hoy personal finance course syllabus with modules on inflation, budgeting, savings, and planning rituals."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Course syllabus & learner pathways</h1>
        <p>
          Strong foundations for every stage: from inflation literacy to advanced
          ARS/USD planning scenarios.
        </p>
      </section>
      <section className={styles.modules} aria-label="Course modules">
        {modules.map((module) => (
          <article key={module.title}>
            <h2>{module.title}</h2>
            <p>{module.details}</p>
          </article>
        ))}
      </section>
      <section className={styles.audience}>
        <h2>Who should join?</h2>
        <ul>
          <li>Households building resilience against rising prices.</li>
          <li>Freelancers juggling ARS income and USD expenses.</li>
          <li>Educators guiding students through financial literacy.</li>
        </ul>
      </section>
    </div>
  );
}

export default Course;