import React, { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const statsData = [
  { label: "Learner retention", target: 94 },
  { label: "Data points tracked", target: 132 },
  { label: "Weekly insights", target: 16 },
  { label: "Personalized scenarios", target: 48 }
];

const testimonials = [
  {
    quote:
      "Tu Progreso Hoy me ofreció análisis claros y datos de mercado para decisiones financieras seguras. La plataforma es impecable.",
    name: "Lucía Fernández",
    role: "Project Analyst, Córdoba"
  },
  {
    quote:
      "Sigue tendencias, detecta oportunidades y planifica tu futuro financiero con herramientas prácticas. Ideal para familias argentinas.",
    name: "Marcos Beltrán",
    role: "Teacher & Parent, Buenos Aires"
  },
  {
    quote:
      "Mejores pasos, mejor porvenir. Las simulaciones del curso me ayudaron a proteger mis ahorros frente a la inflación.",
    name: "Valeria González",
    role: "Freelance Designer, Mendoza"
  }
];

const projects = [
  { id: 1, category: "Budgeting", title: "Household ARS Scenario Planner" },
  { id: 2, category: "Forecasting", title: "Inflation Alert Dashboard" },
  { id: 3, category: "Education", title: "Personal Finance Micro Lessons" },
  { id: 4, category: "Budgeting", title: "Community Workshop Toolkit" },
  { id: 5, category: "Forecasting", title: "FX Sensitivity Report" },
  { id: 6, category: "Education", title: "Campus Ambassadors Kit" }
];

const blogPosts = [
  {
    title: "Inflation lenses: compare ARS metrics with USD targets",
    date: "2024-05-12",
    excerpt:
      "Discover how our CPI tracker contrasts official and shadow indicators, empowering resilient planning choices.",
    link: "/resources"
  },
  {
    title: "Five practical steps to rebalance your peso budget",
    date: "2024-04-29",
    excerpt:
      "We review monthly adjustments to protect essentials while responding to new currency pressures in Argentina.",
    link: "/resources"
  },
  {
    title: "How double-entry habits de-risk family finances",
    date: "2024-04-07",
    excerpt:
      "Habits and rituals sustain your future. Learn how to turn data dashboards into weekly financial clarity."
  }
];

function Home() {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [arsUsd, setArsUsd] = useState({ rate: "...", timestamp: "" });
  const [projectsFilter, setProjectsFilter] = useState("All");
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    confirmEmail: "",
    consent: false
  });
  const [formErrors, setFormErrors] = useState({});
  const [disclaimerOpen, setDisclaimerOpen] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const increment = Math.ceil(stat.target / 60);
      return setInterval(() => {
        setStats((prev) => {
          const newValue = [...prev];
          newValue[index] = Math.min(
            stat.target,
            newValue[index] + increment
          );
          return newValue;
        });
      }, 30);
    });
    return () => intervals.forEach(clearInterval);
  }, []);

  useEffect(() => {
    const cycle = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(cycle);
  }, []);

  useEffect(() => {
    async function fetchRate() {
      try {
        const response = await fetch(
          "https://api.exchangerate.host/latest?base=ARS&symbols=USD"
        );
        const data = await response.json();
        if (data && data.rates && data.rates.USD) {
          setArsUsd({
            rate: (1 / data.rates.USD).toFixed(4),
            timestamp: new Date(data.date).toLocaleString()
          });
        }
      } catch (error) {
        setArsUsd({
          rate: "Unavailable",
          timestamp: "Check connection"
        });
      }
    }
    fetchRate();
    const interval = setInterval(fetchRate, 60000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectsFilter === "All") return projects;
    return projects.filter((item) => item.category === projectsFilter);
  }, [projectsFilter]);

  const handleInputChange = (event) => {
    const { name, type, checked, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.fullName.trim()) {
      errors.fullName = "Please enter your full name.";
    }
    if (!formData.email.trim()) {
      errors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Enter a valid email.";
    }
    if (formData.confirmEmail !== formData.email) {
      errors.confirmEmail = "Emails must match for opt-in verification.";
    }
    if (!formData.consent) {
      errors.consent =
        "Please confirm you agree to receive the double opt-in email.";
    }
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    setFormErrors({});
    navigate("/thank-you");
  };

  return (
    <>
      <Helmet>
        <html lang="en" />
        <title>
          Tu Progreso Hoy | ARS to USD Inflation Intelligence & Finance Course
        </title>
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas"
        />
        <link rel="alternate" hrefLang="es-AR" href="https://tuprogresohoy.com" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Sabiduría financiera con tendencias</p>
          <h1>
            Navigate ARS→USD inflation dynamics with clarity and plan resilient
            personal finances for Argentina.
          </h1>
          <p className={styles.heroSubtitle}>
            Análisis claros y datos de mercado para decisiones financieras
            seguras. Harness live indicators, scenario tools, and in-depth
            education for every stage of your journey.
          </p>
          <div className={styles.heroActions}>
            <button
              type="button"
              className={styles.primaryCta}
              onClick={() => navigate("/course")}
            >
              Explore the Course
            </button>
            <button
              type="button"
              className={styles.secondaryCta}
              onClick={() => navigate("/inflation")}
            >
              View Inflation Analytics
            </button>
          </div>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img
            src="https://picsum.photos/1600/900?random=101"
            alt="Financial planning workspace"
            loading="lazy"
          />
          <div className={styles.flagOverlay} />
        </div>
      </section>

      <section className={styles.stats} aria-label="Key achievements">
        {statsData.map((stat, index) => (
          <div key={stat.label} className={styles.statCard}>
            <span className={styles.statValue}>
              {stats[index]}
              <span className={styles.plus}>+</span>
            </span>
            <p>{stat.label}</p>
          </div>
        ))}
      </section>

      <section className={styles.promises} aria-label="Value promises">
        <div className={styles.promiseCard}>
          <h3>Finanzas inteligentes para tu futuro</h3>
          <p>
            Diseñamos guías y dashboards que conectan tu realidad de ingresos con
            objetivos alcanzables, alineados a la evolución diaria del ARS.
          </p>
        </div>
        <div className={styles.promiseCard}>
          <h3>Datos confiables para tu presupuesto</h3>
          <p>
            Combinamos series oficiales, relevamientos privados y estimaciones
            comunitarias para sostener tus decisiones.
          </p>
        </div>
        <div className={styles.promiseCard}>
          <h3>Decisiones responsables, planes claros</h3>
          <p>
            Recomendaciones aplicables, modelos de cashflow y rutinas que
            acompañan cada mes financiero de tu familia o emprendimiento.
          </p>
        </div>
      </section>

      <section className={styles.tracker} aria-label="ARS to USD tracker">
        <div className={styles.trackerHeader}>
          <h2>ARS → USD Live Tracker</h2>
          <span className={styles.trackerBadge}>Real-time pulse</span>
        </div>
        <div className={styles.trackerBody}>
          <p className={styles.trackerRate}>
            1 USD ≈ <strong>{arsUsd.rate}</strong> ARS
          </p>
          <p className={styles.trackerTimestamp}>
            Updated: <span>{arsUsd.timestamp}</span>
          </p>
          <p className={styles.trackerNote}>
            Sources blend official exchange boards, financial market composites,
            and monitored wholesale spreads relevant to households.
          </p>
        </div>
      </section>

      <section className={styles.analytics}>
        <div className={styles.analyticsIntro}>
          <h2>Inflation insights you can trust</h2>
          <p>
            Our inflation observatory layers CPI releases with retail price
            trackers, enabling you to detect momentum early and respond with
            confidence.
          </p>
        </div>
        <div className={styles.analyticsGrid}>
          <article>
            <h3>Monthly CPI Heatmap</h3>
            <p>
              Compare core, headline, and food basket segments to capture where
              your wallet feels the most pressure.
            </p>
          </article>
          <article>
            <h3>FX Sentiment Dashboard</h3>
            <p>
              Visualize ARS volatility against USD and blue-chip references, so
              you align purchase timing and savings strategies.
            </p>
          </article>
          <article>
            <h3>Household Cost Index</h3>
            <p>
              Measure essential expenses with our Buenos Aires digital basket and
              adapt your budget right away.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.courseOverview} aria-labelledby="course-heading">
        <div className={styles.courseHeader}>
          <h2 id="course-heading">Personal Finance Course Overview</h2>
          <p>
            Build a resilient money plan for Argentina: tax basics, inflation
            adjustments, emergency buffers, and mindful investments tailored to
            your rhythm.
          </p>
        </div>
        <div className={styles.courseModules}>
          <div>
            <h3>Module Highlights</h3>
            <ul>
              <li>Inflation literacy and ARS→USD benchmarking</li>
              <li>Zero-based and envelope budgeting templates</li>
              <li>Debt prioritization with real rate comparisons</li>
              <li>Goal-based savings with bi-currency projections</li>
            </ul>
          </div>
          <div>
            <h3>Why learners choose us</h3>
            <p>
              Mejores pasos, mejor porvenir. Every module pairs actionable steps
              with shared stories from Argentine families and professionals who
              have implemented them.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <h2>Your path to confident finances</h2>
        <div className={styles.processSteps}>
          <div>
            <span className={styles.stepNumber}>01</span>
            <h3>Assess & Align</h3>
            <p>
              Capture your monthly inflows, cost anchors, and FX sensitivities.
            </p>
          </div>
          <div>
            <span className={styles.stepNumber}>02</span>
            <h3>Plan & Simulate</h3>
            <p>
              Run scenarios using inflation and FX dashboards to map strategic
              responses.
            </p>
          </div>
          <div>
            <span className={styles.stepNumber}>03</span>
            <h3>Execute & Review</h3>
            <p>
              Implement new rituals, track progress weekly, and refine with
              community guidance.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Testimonials">
        <div className={styles.testimonial}>
          <p className={styles.quote}>
            “{testimonials[currentTestimonial].quote}”
          </p>
          <p className={styles.person}>
            {testimonials[currentTestimonial].name} —{" "}
            {testimonials[currentTestimonial].role}
          </p>
          <div className={styles.indicators}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                aria-label={`View testimonial ${index + 1}`}
                onClick={() => setCurrentTestimonial(index)}
                className={
                  index === currentTestimonial ? styles.activeDot : styles.dot
                }
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <h2>Meet the team guiding your progress</h2>
        <div className={styles.teamGrid}>
          {[
            {
              name: "Ana Sofía Ramos",
              role: "Lead Economist",
              focus: "CPI & FX modeling",
              img: "https://picsum.photos/400/400?random=201"
            },
            {
              name: "Julián Medina",
              role: "Experience Designer",
              focus: "Learner journeys",
              img: "https://picsum.photos/400/400?random=202"
            },
            {
              name: "Carolina Díaz",
              role: "Community Coach",
              focus: "Household mentoring",
              img: "https://picsum.photos/400/400?random=203"
            }
          ].map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.img} alt={`${member.name} portrait`} />
              <div>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <span>{member.focus}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.projectsHeader}>
          <h2>Recent initiatives</h2>
          <div className={styles.filterGroup}>
            {["All", "Budgeting", "Forecasting", "Education"].map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setProjectsFilter(category)}
                className={
                  projectsFilter === category
                    ? styles.filterActive
                    : styles.filterButton
                }
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((item) => (
            <figure key={item.id} className={styles.projectCard}>
              <img
                src={`https://picsum.photos/1200/800?random=${300 + item.id}`}
                alt={`${item.title} visual`}
                loading="lazy"
              />
              <figcaption>
                <span>{item.category}</span>
                <h3>{item.title}</h3>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.faqIntro}>
          <h2>FAQ: preparing your next financial decision</h2>
          <p>
            Answers to common questions about inflation analysis, ARS exposure,
            and how to engage with our educational platform.
          </p>
        </div>
        <div className={styles.faqList}>
          {[
            {
              question: "How frequently do you update ARS→USD insights?",
              answer:
                "We track market and blended rates in real time, refreshing dashboards every hour with commentary during macro events."
            },
            {
              question: "Can families and entrepreneurs learn together?",
              answer:
                "Yes. Modules are structured with parallel tracks for households, freelancers, and micro-businesses, encouraging collaborative planning."
            },
            {
              question: "Is the course available in Spanish?",
              answer:
                "All course videos and templates offer bilingual options (English and Spanish) so you can choose the language that fits your context."
            },
            {
              question: "How does the double opt-in protect my privacy?",
              answer:
                "After submitting your email, you receive a confirmation message. Only after you verify that email do we activate communications."
            }
          ].map((item, index) => (
            <details key={item.question} open={index === 0}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <h2>Latest insights from Tu Progreso Hoy</h2>
        <div className={styles.blogGrid}>
          {blogPosts.map((post, index) => (
            <article key={post.title} className={styles.blogCard}>
              <img
                src={`https://picsum.photos/800/600?random=${401 + index}`}
                alt="Financial insights illustration"
                loading="lazy"
              />
              <div>
                <time dateTime={post.date}>
                  {new Date(post.date).toLocaleDateString("en-GB", {
                    day: "numeric",
                    month: "short",
                    year: "numeric"
                  })}
                </time>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href={post.link ?? "/resources"}>Read more →</a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Start your free trial lesson</h2>
          <p>
            Join our learning community and receive a double opt-in email with
            your first lesson, plus guidance on upcoming inflation trends.
          </p>
          <form
            className={styles.trialForm}
            onSubmit={handleSubmit}
            noValidate
            aria-label="Free trial form"
          >
            <div className={styles.formGroup}>
              <label htmlFor="fullName">Full name</label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                value={formData.fullName}
                onChange={handleInputChange}
                placeholder="María López"
                aria-invalid={Boolean(formErrors.fullName)}
                required
              />
              {formErrors.fullName && (
                <span className={styles.error}>{formErrors.fullName}</span>
              )}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="email">Email address</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="maria@email.com"
                aria-invalid={Boolean(formErrors.email)}
                required
              />
              {formErrors.email && (
                <span className={styles.error}>{formErrors.email}</span>
              )}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="confirmEmail">Confirm email</label>
              <input
                id="confirmEmail"
                name="confirmEmail"
                type="email"
                value={formData.confirmEmail}
                onChange={handleInputChange}
                placeholder="Repeat your email"
                aria-invalid={Boolean(formErrors.confirmEmail)}
                required
              />
              {formErrors.confirmEmail && (
                <span className={styles.error}>{formErrors.confirmEmail}</span>
              )}
            </div>
            <div className={styles.checkboxGroup}>
              <input
                id="consent"
                name="consent"
                type="checkbox"
                checked={formData.consent}
                onChange={handleInputChange}
                aria-invalid={Boolean(formErrors.consent)}
                required
              />
              <label htmlFor="consent">
                I agree to receive a double opt-in email and confirm my
                subscription.
              </label>
            </div>
            {formErrors.consent && (
              <span className={styles.error}>{formErrors.consent}</span>
            )}
            <button type="submit" className={styles.submitBtn}>
              Get the trial lesson
            </button>
          </form>
        </div>
      </section>

      {disclaimerOpen && (
        <div className={styles.disclaimerBackdrop} role="alertdialog">
          <div className={styles.disclaimer}>
            <h3>Important information</h3>
            <p>Мы не предоставляем финансовые услуги.</p>
            <button type="button" onClick={() => setDisclaimerOpen(false)}>
              Understood
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export default Home;