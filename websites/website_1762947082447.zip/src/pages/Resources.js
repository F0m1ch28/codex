import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Resources.module.css";

const resources = [
  {
    title: "Glosario de inflación en Argentina",
    language: "Español",
    summary:
      "Definiciones claras de términos clave: IPC, núcleo, crawling peg y más.",
    link: "#"
  },
  {
    title: "Argentina inflation primer",
    language: "English",
    summary:
      "A deep dive into CPI dynamics, FX volatility, and household planning techniques.",
    link: "#"
  },
  {
    title: "Budget checklist for peso earners",
    language: "English",
    summary:
      "Monthly to-do list ensuring your ARS and USD exposures stay balanced.",
    link: "#"
  },
  {
    title: "Guía rápida sobre ahorro en dólares",
    language: "Español",
    summary:
      "Buenas prácticas para documentar tus ahorros y cumplir con regulaciones locales.",
    link: "#"
  }
];

function Resources() {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Resources | Tu Progreso Hoy Library</title>
        <meta
          name="description"
          content="Access bilingual resources, articles, and glossaries on inflation and personal finance in Argentina."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Resources & glossaries</h1>
        <p>
          Articles, worksheets, and explainers available in English and Spanish
          to strengthen your financial literacy in Argentina.
        </p>
      </section>
      <section className={styles.grid} aria-label="Resource list">
        {resources.map((resource) => (
          <article key={resource.title}>
            <h2>{resource.title}</h2>
            <span>{resource.language}</span>
            <p>{resource.summary}</p>
            <a href={resource.link}>Download</a>
          </article>
        ))}
      </section>
    </div>
  );
}

export default Resources;