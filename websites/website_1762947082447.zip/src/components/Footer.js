import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.grid}>
        <div>
          <div className={styles.brand}>
            <span className={styles.brandMark}>TPH</span>
            <p className={styles.brandText}>
              Tu Progreso Hoy — Sabiduría financiera con tendencias.
            </p>
          </div>
          <p className={styles.mission}>
            Mejores pasos, mejor porvenir. Información confiable que respalda
            tus elecciones responsables de dinero.
          </p>
        </div>
        <div>
          <h4>Explore</h4>
          <ul>
            <li>
              <Link to="/inflation">Inflation Insights</Link>
            </li>
            <li>
              <Link to="/course">Finance Course</Link>
            </li>
            <li>
              <Link to="/resources">Resources</Link>
            </li>
            <li>
              <Link to="/services">Solutions</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Legal</h4>
          <ul>
            <li>
              <Link to="/terms">Terms of Use</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Cookie Policy</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Contact</h4>
          <address className={styles.address}>
            Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
          </address>
          <a href="tel:+541155551234" className={styles.contactLink}>
            +54 11 5555-1234
          </a>
          <a href="mailto:info@tuprogresohoy.com" className={styles.contactLink}>
            info@tuprogresohoy.com
          </a>
          <div className={styles.social}>
            <a href="https://www.linkedin.com" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="https://twitter.com" aria-label="Twitter">
              Twitter
            </a>
            <a href="https://www.youtube.com" aria-label="YouTube">
              YouTube
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;