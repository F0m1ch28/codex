import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import styles from "./ScrollToTop.module.css";

function ScrollToTop() {
  const { pathname } = useLocation();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);

  useEffect(() => {
    function handleScroll() {
      setIsVisible(window.scrollY > 240);
    }
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className={`${styles.button} ${isVisible ? styles.visible : ""}`}
      aria-label="Scroll to top"
    >
      ↑
    </button>
  );
}

export default ScrollToTop;