import React, { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("tph_cookie_consent");
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem("tph_cookie_consent", value ? "accepted" : "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h2>Cookies & Settings</h2>
        <p>
          We use functional and analytical cookies to improve your experience.
          Manage your preferences anytime in our{" "}
          <a href="/cookie-policy">Cookie Policy</a>.
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            onClick={() => handleConsent(false)}
            className={styles.secondary}
          >
            Decline
          </button>
          <button
            type="button"
            onClick={() => handleConsent(true)}
            className={styles.primary}
          >
            Accept
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;