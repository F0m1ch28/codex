document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navMenu.classList.toggle("is-open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const customizeLink = document.getElementById("cookie-customize");

    if (cookieBanner) {
        const existingConsent = localStorage.getItem("federamzixConsent");
        if (existingConsent) {
            cookieBanner.classList.add("hidden");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", function () {
                localStorage.setItem("federamzixConsent", "accepted");
                cookieBanner.classList.add("hidden");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", function () {
                localStorage.setItem("federamzixConsent", "declined");
                cookieBanner.classList.add("hidden");
            });
        }

        if (customizeLink) {
            customizeLink.addEventListener("click", function (event) {
                event.preventDefault();
                window.location.href = "cookies.html#management";
            });
        }
    }
});