document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;

  const themeToggle = document.getElementById("themeToggle");
  const storedTheme = localStorage.getItem("assistaao-theme");
  if (storedTheme === "dark") {
    body.classList.add("theme-dark");
  }
  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      body.classList.toggle("theme-dark");
      const theme = body.classList.contains("theme-dark") ? "dark" : "light";
      localStorage.setItem("assistaao-theme", theme);
      themeToggle.innerHTML = theme === "dark" ? "☀️" : "🌙";
    });
    themeToggle.innerHTML = body.classList.contains("theme-dark") ? "☀️" : "🌙";
  }

  const navToggle = document.getElementById("menuToggle");
  const mainNav = document.getElementById("mainNav");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      mainNav.classList.toggle("show");
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const acceptCookies = document.getElementById("acceptCookies");
  const declineCookies = document.getElementById("declineCookies");
  const cookieConsent = localStorage.getItem("assistaao-cookie-consent");
  if (cookieBanner && !cookieConsent) {
    setTimeout(() => cookieBanner.classList.add("show"), 800);
  }
  const closeBanner = (status) => {
    if (cookieBanner) cookieBanner.classList.remove("show");
    localStorage.setItem("assistaao-cookie-consent", status);
  };
  if (acceptCookies) {
    acceptCookies.addEventListener("click", () => closeBanner("accepted"));
  }
  if (declineCookies) {
    declineCookies.addEventListener("click", () => closeBanner("declined"));
  }

  const toast = document.getElementById("notificationToast");
  const notificationBell = document.getElementById("notificationBell");
  if (notificationBell && toast) {
    notificationBell.addEventListener("click", () => {
      toast.classList.add("show");
      setTimeout(() => toast.classList.remove("show"), 4000);
    });
  }

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    const items = document.querySelectorAll('[data-searchable="video"]');
    searchInput.addEventListener("input", (event) => {
      const term = event.target.value.toLowerCase();
      items.forEach((el) => {
        const haystack = `${el.dataset.title} ${el.dataset.category} ${el.dataset.channel}`.toLowerCase();
        el.style.display = haystack.includes(term) ? "" : "none";
      });
    });
  }

  const filterButtons = document.querySelectorAll(".filter-button");
  if (filterButtons.length) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const category = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");
        const cards = document.querySelectorAll('[data-searchable="video"]');
        cards.forEach((card) => {
          const cardCategory = card.dataset.category;
          card.style.display = category === "all" || cardCategory === category ? "" : "none";
        });
      });
    });
  }

  const setStars = (container, rating) => {
    const stars = container.querySelectorAll("button");
    stars.forEach((star) => {
      star.classList.toggle("active", Number(star.dataset.value) <= rating);
    });
  };

  document.querySelectorAll(".rating-stars").forEach((container) => {
    const videoId = container.dataset.videoId;
    const saved = Number(localStorage.getItem(`assistaao-rating-${videoId}`)) || 0;
    if (saved) setStars(container, saved);
    container.querySelectorAll("button").forEach((button) => {
      button.addEventListener("click", () => {
        const value = Number(button.dataset.value);
        localStorage.setItem(`assistaao-rating-${videoId}`, value);
        setStars(container, value);
        const display = container.closest(".rating-block")?.querySelector(".rating-value");
        if (display) display.textContent = `${value.toFixed(1)} / 5`;
      });
    });
  });

  document.querySelectorAll(".comment-form").forEach((form) => {
    const list = form.parentElement.querySelector(".comment-list");
    const videoId = form.dataset.videoId;
    const storedComments = JSON.parse(localStorage.getItem(`assistaao-comments-${videoId}`) || "[]");
    const renderComment = (comment) => {
      const item = document.createElement("div");
      item.className = "comment";
      item.innerHTML = `
        <div class="comment-meta"><strong>${comment.name}</strong> <span>${comment.date}</span></div>
        <p>${comment.message}</p>
      `;
      list.prepend(item);
    };
    storedComments.forEach(renderComment);
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const comment = {
        name: formData.get("name") || "Convidado",
        message: formData.get("message"),
        date: new Date().toLocaleString("pt-BR"),
      };
      if (!comment.message.trim()) return;
      storedComments.push(comment);
      localStorage.setItem(`assistaao-comments-${videoId}`, JSON.stringify(storedComments));
      renderComment(comment);
      form.reset();
    });
  });

  const playlistForm = document.getElementById("playlistForm");
  const playlistList = document.getElementById("playlistList");
  if (playlistForm && playlistList) {
    const storedPlaylists = JSON.parse(localStorage.getItem("assistaao-playlists") || "[]");
    const renderPlaylist = (playlist) => {
      const item = document.createElement("div");
      item.className = "playlist-item";
      item.innerHTML = `
        <span><strong>${playlist.name}</strong> <span class="tag">${playlist.privacy}</span></span>
        <span class="muted">${playlist.description}</span>
      `;
      playlistList.appendChild(item);
    };
    storedPlaylists.forEach(renderPlaylist);
    playlistForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(playlistForm);
      const playlist = {
        name: formData.get("playlist-name"),
        privacy: formData.get("playlist-privacy"),
        description: formData.get("playlist-description"),
      };
      if (!playlist.name.trim()) return;
      storedPlaylists.push(playlist);
      localStorage.setItem("assistaao-playlists", JSON.stringify(storedPlaylists));
      renderPlaylist(playlist);
      playlistForm.reset();
    });
  }

  document.querySelectorAll(".quality-selector").forEach((select) => {
    const videoId = select.dataset.video;
    const video = document.getElementById(videoId);
    if (!video) return;
    select.addEventListener("change", (event) => {
      const quality = event.target.value;
      const source = video.dataset[`src${quality}`];
      if (source) {
        const currentTime = video.currentTime;
        const isPlaying = !video.paused && !video.ended;
        video.src = source;
        video.load();
        video.currentTime = currentTime;
        if (isPlaying) video.play();
      }
    });
  });

  document.querySelectorAll(".speed-selector").forEach((select) => {
    const videoId = select.dataset.video;
    const video = document.getElementById(videoId);
    if (!video) return;
    const storedSpeed = localStorage.getItem(`assistaao-speed-${videoId}`);
    if (storedSpeed) {
      video.playbackRate = Number(storedSpeed);
      select.value = storedSpeed;
    }
    select.addEventListener("change", (event) => {
      const speed = Number(event.target.value);
      video.playbackRate = speed;
      localStorage.setItem(`assistaao-speed-${videoId}`, speed);
    });
  });

  document.querySelectorAll(".autoplay-toggle").forEach((toggle) => {
    const videoId = toggle.dataset.video;
    const video = document.getElementById(videoId);
    if (!video) return;
    const pref = localStorage.getItem(`assistaao-autoplay-${videoId}`);
    if (pref) {
      const shouldAutoplay = pref === "true";
      toggle.checked = shouldAutoplay;
      video.autoplay = shouldAutoplay;
    }
    toggle.addEventListener("change", (event) => {
      const enabled = event.target.checked;
      video.autoplay = enabled;
      localStorage.setItem(`assistaao-autoplay-${videoId}`, String(enabled));
    });
  });

  document.querySelectorAll(".mini-toggle").forEach((button) => {
    const targetId = button.dataset.target;
    const container = document.getElementById(targetId);
    if (!container) return;
    button.addEventListener("click", () => {
      container.classList.toggle("mini-player");
      button.textContent = container.classList.contains("mini-player") ? "Fechar Mini Player" : "Mini Player";
    });
  });

  document.querySelectorAll("video[data-video-id]").forEach((video) => {
    const id = video.dataset.videoId;
    const progressBar = document.querySelector(`[data-progress="${id}"]`);
    const storedTime = Number(localStorage.getItem(`assistaao-progress-${id}`));
    if (storedTime) {
      video.currentTime = storedTime;
      if (progressBar && video.duration) {
        progressBar.value = storedTime;
      }
    }
    video.addEventListener("timeupdate", () => {
      localStorage.setItem(`assistaao-progress-${id}`, video.currentTime);
      if (progressBar) {
        progressBar.max = video.duration;
        progressBar.value = video.currentTime;
      }
    });
    const endScreenId = video.dataset.endScreen;
    const endScreen = endScreenId ? document.getElementById(endScreenId) : null;
    if (endScreen) {
      video.addEventListener("ended", () => {
        endScreen.classList.add("visible");
      });
      endScreen.querySelectorAll("[data-close]").forEach((btn) => {
        btn.addEventListener("click", () => {
          endScreen.classList.remove("visible");
          video.currentTime = 0;
        });
      });
    }
  });

  document.querySelectorAll(".transcript-toggle").forEach((button) => {
    const target = document.getElementById(button.dataset.target);
    if (!target) return;
    button.addEventListener("click", () => {
      target.classList.toggle("show");
      button.textContent = target.classList.contains("show") ? "Ocultar transcrição" : "Mostrar transcrição";
    });
  });

  document.querySelectorAll("[data-chapter]").forEach((button) => {
    button.addEventListener("click", () => {
      const video = document.getElementById(button.dataset.chapter);
      if (!video) return;
      const time = Number(button.dataset.time);
      video.currentTime = time;
      video.play();
    });
  });

  document.querySelectorAll(".report-form").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      alert("Obrigado por nos ajudar a manter a comunidade segura. Revisaremos o conteúdo reportado.");
      form.reset();
    });
  });

  document.querySelectorAll(".share-button").forEach((button) => {
    button.addEventListener("click", () => {
      const data = {
        title: button.dataset.title || "Assista ao vídeo",
        text: button.dataset.text || "Confira este vídeo incrível na plataforma Assista ao Vídeo!",
        url: button.dataset.url || window.location.href,
      };
      if (navigator.share) {
        navigator.share(data);
      } else {
        navigator.clipboard.writeText(data.url).then(() => {
          alert("Link copiado para a área de transferência!");
        });
      }
    });
  });

  document.querySelectorAll(".subscribe-button").forEach((button) => {
    const channelId = button.dataset.channel;
    const subscribed = localStorage.getItem(`assistaao-sub-${channelId}`) === "true";
    if (subscribed) {
      button.textContent = "Inscrito";
      button.classList.add("btn-secondary");
    }
    button.addEventListener("click", () => {
      const isSubscribed = button.textContent === "Inscrito";
      if (isSubscribed) {
        button.textContent = "Inscrever-se";
        button.classList.remove("btn-secondary");
        localStorage.setItem(`assistaao-sub-${channelId}`, "false");
      } else {
        button.textContent = "Inscrito";
        button.classList.add("btn-secondary");
        localStorage.setItem(`assistaao-sub-${channelId}`, "true");
      }
    });
  });

  document.querySelectorAll(".download-button").forEach((button) => {
    button.addEventListener("click", () => {
      alert("Download disponível apenas para assinantes premium. Faça upgrade para continuar.");
    });
  });

  document.querySelectorAll(".autoplay-next-toggle").forEach((toggle) => {
    const key = "assistaao-autoplay-next";
    const stored = localStorage.getItem(key);
    if (stored) toggle.checked = stored === "true";
    toggle.addEventListener("change", (event) => {
      localStorage.setItem(key, String(event.target.checked));
    });
  });

  document.querySelectorAll("[data-age-warning]").forEach((element) => {
    const age = element.dataset.ageWarning;
    element.addEventListener("click", () => {
      alert(`Este conteúdo é recomendado para maiores de ${age} anos.`);
    });
  });

  document.querySelectorAll(".vr-notice").forEach((notice) => {
    notice.addEventListener("click", () => {
      alert("Para aproveitar vídeos em VR, utilize um dispositivo compatível e certifique-se de ativar o modo VR no player.");
    });
  });

  const keyboardToggle = document.getElementById("keyboardToggle");
  const keyboardList = document.getElementById("keyboardList");
  if (keyboardToggle && keyboardList) {
    keyboardToggle.addEventListener("click", () => {
      keyboardList.classList.toggle("show");
    });
  }
});