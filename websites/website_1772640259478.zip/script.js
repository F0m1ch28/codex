document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('is-open');
      body.classList.toggle('no-scroll', !expanded);
    });

    navLinks.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        if (navLinks.classList.contains('is-open')) {
          navLinks.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
          body.classList.remove('no-scroll');
        }
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const consentKey = 'website_cookie_consent';

  if (cookieBanner && acceptBtn && declineBtn) {
    const consent = localStorage.getItem(consentKey);
    if (!consent) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }

    const handleConsent = value => {
      localStorage.setItem(consentKey, value);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn.addEventListener('click', () => handleConsent('accepted'));
    declineBtn.addEventListener('click', () => handleConsent('declined'));
  }

  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    const fields = contactForm.querySelectorAll('[data-required]');
    const messageBox = contactForm.querySelector('.form-message');

    contactForm.addEventListener('submit', event => {
      let isValid = true;
      fields.forEach(field => {
        const group = field.closest('.input-group');
        if (!group) return;
        const error = group.querySelector('.error-message');
        if (error) error.textContent = '';

        if (!field.value.trim()) {
          isValid = false;
          if (error) {
            error.textContent = 'Пожалуйста, заполните это поле.';
          }
        } else if (field.type === 'email') {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(field.value.trim())) {
            isValid = false;
            if (error) {
              error.textContent = 'Введите корректный адрес электронной почты.';
            }
          }
        }
      });

      if (!isValid) {
        event.preventDefault();
        return;
      }

      event.preventDefault();
      if (messageBox) {
        messageBox.textContent = 'Спасибо! Мы получили вашу заявку и свяжемся с вами в ближайшее время.';
      }
      contactForm.reset();
    });
  }
});