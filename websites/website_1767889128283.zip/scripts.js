document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.getElementById("nav-toggle");
    const primaryNav = document.getElementById("primary-navigation");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            primaryNav.classList.toggle("is-open");
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptButton = document.getElementById("cookie-accept");
    const declineButton = document.getElementById("cookie-decline");
    const storedConsent = localStorage.getItem("bosbanqbyq_cookie_consent");

    if (storedConsent && cookieBanner) {
        cookieBanner.classList.add("hidden");
    }

    function handleConsent(status) {
        localStorage.setItem("bosbanqbyq_cookie_consent", status);
        if (cookieBanner) {
            cookieBanner.classList.add("hidden");
        }
    }

    if (acceptButton) {
        acceptButton.addEventListener("click", function (event) {
            event.preventDefault();
            handleConsent("accepted");
        });
    }

    if (declineButton) {
        declineButton.addEventListener("click", function (event) {
            event.preventDefault();
            handleConsent("declined");
            window.location.href = "cookies.html";
        });
    }
});