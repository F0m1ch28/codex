document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navMenu.classList.toggle("open");
        });

        navMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                navMenu.classList.remove("open");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-button");

    if (cookieBanner && cookieButtons.length) {
        const consent = localStorage.getItem("lockawwhul_cookie_consent");
        if (consent) {
            cookieBanner.classList.add("hidden");
        }

        cookieButtons.forEach(button => {
            button.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = button.dataset.choice || "accept";
                localStorage.setItem("lockawwhul_cookie_consent", choice);
                cookieBanner.classList.add("hidden");
                window.location.href = "cookies.html";
            });
        });
    }
});