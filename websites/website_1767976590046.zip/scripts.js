document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.getElementById('navToggle');
    const primaryNav = document.getElementById('primaryNav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            primaryNav.classList.toggle('open');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => primaryNav.classList.remove('open'));
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const consent = localStorage.getItem('cdrCookieConsent');
        if (consent) {
            cookieBanner.classList.add('hidden');
        }

        cookieBanner.querySelectorAll('[data-consent-action]').forEach(control => {
            control.addEventListener('click', function (event) {
                event.preventDefault();
                localStorage.setItem('cdrCookieConsent', this.dataset.consentAction);
                cookieBanner.classList.add('hidden');
            });
        });
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function (event) {
            event.preventDefault();
            window.location.href = this.dataset.redirect || 'thanks.html';
        });
    }

    const searchInput = document.getElementById('searchPosts');
    const filterButtons = document.querySelectorAll('[data-filter]');
    const postCards = document.querySelectorAll('[data-post]');

    function applyFilters() {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
        const activeButton = document.querySelector('[data-filter].active');
        const category = activeButton ? activeButton.dataset.filter : 'all';

        postCards.forEach(card => {
            const title = card.querySelector('h3') ? card.querySelector('h3').textContent.toLowerCase() : '';
            const summary = card.querySelector('p') ? card.querySelector('p').textContent.toLowerCase() : '';
            const cardCategory = card.dataset.category;

            const matchesQuery = !query || title.includes(query) || summary.includes(query);
            const matchesCategory = category === 'all' || cardCategory === category;

            if (matchesQuery && matchesCategory) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }

    if (filterButtons.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function () {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                applyFilters();
            });
        });
    }
});