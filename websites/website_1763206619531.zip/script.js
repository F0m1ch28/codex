document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    const navLinks = document.querySelectorAll('.nav-link');
    const scrollBtn = document.querySelector('.scroll-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButton = document.querySelector('#acceptCookies');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (primaryNav && primaryNav.classList.contains('open')) {
                primaryNav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
    window.scrollTo(0, 0);

    window.addEventListener('scroll', () => {
        if (!scrollBtn) return;
        if (window.scrollY > 240) {
            scrollBtn.classList.add('visible');
        } else {
            scrollBtn.classList.remove('visible');
        }
    });

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner) {
        const consentGiven = localStorage.getItem('cdsCookieConsent');
        if (consentGiven === 'accepted') {
            cookieBanner.classList.add('dismissed');
        }
        if (cookieButton) {
            cookieButton.addEventListener('click', () => {
                localStorage.setItem('cdsCookieConsent', 'accepted');
                cookieBanner.classList.add('dismissed');
            });
        }
    }

    const forms = document.querySelectorAll('form[data-form="contact"]');
    forms.forEach(form => {
        const messageEl = form.querySelector('.form-message');
        form.addEventListener('submit', event => {
            event.preventDefault();
            if (messageEl) {
                messageEl.textContent = 'Thank you for contacting Canada Data Studio. Our consultants will reach out shortly.';
            }
            form.reset();
        });
    });

    const yearEl = document.getElementById('current-year');
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }
});