document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.mobile-nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      primaryNav.classList.toggle('open');
    });
    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (primaryNav.classList.contains('open')) {
          primaryNav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storageKey = 'cansystech_cookie_choice';
    const savedChoice = localStorage.getItem(storageKey);
    if (!savedChoice) {
      cookieBanner.classList.add('active');
    }
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
    const closeBanner = decision => {
      localStorage.setItem(storageKey, decision);
      cookieBanner.classList.remove('active');
    };
    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => closeBanner('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => closeBanner('declined'));
    }
  }

  const redirects = {
    '/history': 'field-notes.html',
    '/history/': 'field-notes.html',
    '/infrastructure': 'systems.html',
    '/infrastructure/': 'systems.html',
    '/resilience': 'analysis.html',
    '/resilience/': 'analysis.html',
    '/technology': 'monitoring.html',
    '/technology/': 'monitoring.html'
  };
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  if (redirects[path]) {
    window.location.replace(redirects[path]);
  }
});