document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.getElementById("nav-toggle");
    const siteNav = document.getElementById("site-nav");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("open");
            navToggle.classList.toggle("open");
        });

        siteNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                siteNav.classList.remove("open");
                navToggle.classList.remove("open");
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const consentKey = "cordedjbjcCookieConsent";
    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.remove("hidden");
        }

        cookieBanner.querySelectorAll(".cookie-btn").forEach(button => {
            button.addEventListener("click", event => {
                event.preventDefault();
                const choice = button.dataset.choice || "dismissed";
                localStorage.setItem(consentKey, choice);
                cookieBanner.classList.add("hidden");
                const policyLink = button.getAttribute("href");
                if (policyLink) {
                    window.open(policyLink, "_blank", "noopener");
                }
            });
        });
    }
});