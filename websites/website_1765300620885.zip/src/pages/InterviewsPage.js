import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './InterviewsPage.module.css';

const interviews = [
  {
    id: 1,
    name: 'Claire Besson',
    role: 'Responsable de cycle, école élémentaire du 5e arrondissement',
    topic: 'Accompagnement des élèves plurilingues',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80',
    summary:
      'Claire Besson décrit les dispositifs mis en place pour soutenir les élèves récemment arrivés à Paris, en combinant ateliers linguistiques et partenariats familiaux.',
  },
  {
    id: 2,
    name: 'Idriss Hamadi',
    role: 'Chercheur associé en sociologie de l’éducation, EHESS',
    topic: 'Effets de la sectorisation sur la mobilité scolaire',
    image: 'https://images.unsplash.com/photo-1544723795-432537c5468d?auto=format&fit=crop&w=400&q=80',
    summary:
      'Idriss Hamadi analyse les stratégies familiales face aux procédures d’affectation et les réponses institutionnelles visant à favoriser la mixité.',
  },
  {
    id: 3,
    name: 'Mélanie Rousset',
    role: 'Coordinatrice numérique, académie de Paris',
    topic: 'Déploiement des environnements numériques d’apprentissage',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
    summary:
      'Mélanie Rousset revient sur les étapes de déploiement des outils numériques, la formation des personnels et les indicateurs de suivi utilisés.',
  },
  {
    id: 4,
    name: 'Thierry Nguyen',
    role: 'Proviseur adjoint, lycée polyvalent du 13e arrondissement',
    topic: 'Relations école-familles et réussite post-bac',
    image: 'https://images.unsplash.com/photo-1531891437562-4301cf35b7e4?auto=format&fit=crop&w=400&q=80',
    summary:
      'Thierry Nguyen présente les leviers mis en œuvre pour faciliter l’orientation, en soulignant l’importance des entretiens individualisés et des partenariats territoriaux.',
  },
];

const InterviewsPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Interviews &amp; Témoignages d&rsquo;Experts | Education in Paris Review</title>
        <meta
          name="description"
          content="Entretiens avec des professionnels de l’éducation, des chercheurs et des responsables institutionnels pour éclairer les réalités éducatives parisiennes."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>Interviews &amp; témoignages d’experts</h1>
          <p>
            Les entretiens donnent la parole à des professionnel·les et à des chercheur·es observant au quotidien les évolutions du système éducatif parisien.
          </p>
        </header>

        <div className={styles.grid}>
          {interviews.map((interview) => (
            <article key={interview.id} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={interview.image} alt={`Portrait de ${interview.name}`} loading="lazy" />
              </div>
              <div className={styles.content}>
                <span className="tag">{interview.topic}</span>
                <h2>{interview.name}</h2>
                <p className={styles.role}>{interview.role}</p>
                <p className={styles.summary}>{interview.summary}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default InterviewsPage;