import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './RessourcesPage.module.css';

const resources = [
  {
    category: 'Rapports officiels',
    items: [
      {
        title: 'Rectorat de Paris — Bilan académique 2022-2023',
        description:
          'Synthèse annuelle des indicateurs académiques : réussite aux examens, évolution des effectifs, dispositifs d’accompagnement spécialisés.',
        link: 'https://www.ac-paris.fr/',
      },
      {
        title: 'Ville de Paris — Observatoire parisien de l’éducation',
        description:
          'Tableaux de bord sur la scolarisation, la carte scolaire, les équipements éducatifs et les indices socio-économiques par arrondissement.',
        link: 'https://www.paris.fr/',
      },
    ],
  },
  {
    category: 'Données statistiques',
    items: [
      {
        title: 'INSEE — Dossiers locaux Paris',
        description:
          'Données démographiques, sociales et économiques détaillées par quartier administratif et aire d’attraction de Paris.',
        link: 'https://www.insee.fr/fr/statistiques/2011101?geo=COM-75056',
      },
      {
        title: 'Ministère de l’Éducation nationale — Open data',
        description:
          'Bases de données ouvertes sur les établissements, les résultats aux examens et les indicateurs de suivi des académies.',
        link: 'https://data.education.gouv.fr/',
      },
    ],
  },
  {
    category: 'Études et recherches',
    items: [
      {
        title: 'Institut des politiques publiques — Note sur la mixité scolaire',
        description:
          'Analyse des mécanismes de sectorisation et des expérimentations menées pour renforcer la mixité sociale dans les collèges parisiens.',
        link: 'https://www.ipp.eu/',
      },
      {
        title: 'Observatoire des inégalités — Rapport jeunesse et éducation',
        description:
          'Éclairage sur les écarts territoriaux, les parcours scolaires différenciés et les modalités de soutien éducatif.',
        link: 'https://www.inegalites.fr/',
      },
    ],
  },
  {
    category: 'Ressources pédagogiques',
    items: [
      {
        title: 'Canopé Île-de-France — Ateliers et ressources pédagogiques',
        description:
          'Catalogue d’ateliers, webinaires et ressources pédagogiques destinés aux enseignants du premier et du second degré.',
        link: 'https://www.reseau-canope.fr/',
      },
      {
        title: 'Bibliothèque de la Sorbonne — Fonds éducation',
        description:
          'Accès aux collections spécialisées en sciences de l’éducation, histoire de l’enseignement et politiques scolaires.',
        link: 'https://www.bibliotheque.sorbonne.fr/',
      },
    ],
  },
];

const RessourcesPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Ressources pédagogiques et documentaires | Education in Paris Review</title>
        <meta
          name="description"
          content="Références officielles, bases de données et ressources pédagogiques pour documenter l’éducation à Paris."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>Ressources pédagogiques et documentaires</h1>
          <p>
            Cette sélection de ressources rassemble des rapports institutionnels, des jeux de données et des études académiques consacrés à l’éducation parisienne.
            Chaque mention renvoie vers une source ouverte ou institutionnelle régulièrement actualisée.
          </p>
        </header>

        <div className={styles.grid}>
          {resources.map((block) => (
            <section key={block.category} className={styles.card} aria-labelledby={`heading-${block.category}`}>
              <h2 id={`heading-${block.category}`} className={styles.category}>
                {block.category}
              </h2>
              <ul className={styles.list}>
                {block.items.map((item) => (
                  <li key={item.title} className={styles.item}>
                    <div>
                      <p className={styles.title}>{item.title}</p>
                      <p className={styles.description}>{item.description}</p>
                    </div>
                    <a href={item.link} className={styles.externalLink} target="_blank" rel="noopener noreferrer">
                      Accéder à la ressource
                    </a>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      </section>
    </div>
  );
};

export default RessourcesPage;