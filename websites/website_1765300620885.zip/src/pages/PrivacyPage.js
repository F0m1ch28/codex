import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Politique de confidentialité | Education in Paris Review</title>
        <meta
          name="description"
          content="Politique de confidentialité d’Education in Paris Review concernant la collecte et l’usage des données."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>Politique de confidentialité</h1>
        </header>
        <article className={styles.content}>
          <h2>Cadre général</h2>
          <p>
            Education in Paris Review attache une importance particulière à la protection des données personnelles. Les informations recueillies via le site
            sont limitées au strict nécessaire pour assurer le suivi des interactions éditoriales.
          </p>

          <h2>Données collectées</h2>
          <p>
            Aucun formulaire interactif n’est proposé. Les échanges se font exclusivement par courrier électronique ou postal.
            Les messages reçus sont conservés le temps de traiter la demande puis archivés de manière sécurisée.
          </p>

          <h2>Cookies</h2>
          <p>
            Les cookies essentiels garantissent le bon fonctionnement du site. Les cookies analytiques ne sont déposés qu’avec le consentement explicite de l’utilisateur.
            Ces données statistiques sont anonymisées et servent uniquement à mesurer l’audience globale.
          </p>

          <h2>Droits des personnes</h2>
          <p>
            Conformément au RGPD, chaque personne dispose d’un droit d’accès, de rectification et de suppression des données la concernant. Les demandes peuvent être adressées par courrier électronique à l’adresse redaction@education-paris-review.fr.
          </p>
        </article>
      </section>
    </div>
  );
};

export default PrivacyPage;