document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const scrollTopBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const form = document.getElementById('contactForm');
    const feedback = document.getElementById('formFeedback');
    const navLinks = document.querySelectorAll('.nav-link');
    const yearSpan = document.getElementById('currentYear');

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            siteNav.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'instant' });
        });
    });

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollTopBtn.style.display = 'flex';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const cookieConsent = localStorage.getItem('tuc_cookie_consent');
    if (!cookieConsent && cookieBanner) {
        cookieBanner.classList.remove('hide');
    } else if (cookieBanner) {
        cookieBanner.classList.add('hide');
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('tuc_cookie_consent', 'accepted');
            cookieBanner.classList.add('hide');
        });
    }

    if (form && feedback) {
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            feedback.textContent = "Thanks for reaching out. We’ll respond within one business day.";
            form.reset();
        });
    }

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});