document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.menu-toggle');
  const siteNav = document.querySelector('.site-nav');
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-btn.accept');
  const declineBtn = document.querySelector('.cookie-btn.decline');
  const consentKey = 'gtc_cookie_consent';

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
      if (siteNav.classList.contains('is-open')) {
        siteNav.querySelector('a')?.focus();
      }
    });
  }

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      setTimeout(() => {
        cookieBanner.classList.add('is-visible');
      }, 600);
    }

    const handleConsent = (status) => {
      localStorage.setItem(consentKey, status);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', function () {
      handleConsent('accepted');
    });

    declineBtn?.addEventListener('click', function () {
      handleConsent('declined');
    });
  }
});