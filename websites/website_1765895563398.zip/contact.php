<?php
$prefillNombre = isset($_GET['nombre']) ? htmlspecialchars($_GET['nombre'], ENT_QUOTES, 'UTF-8') : '';
$prefillCorreo = isset($_GET['correo']) ? htmlspecialchars($_GET['correo'], ENT_QUOTES, 'UTF-8') : '';
$prefillRegion = isset($_GET['region']) ? htmlspecialchars($_GET['region'], ENT_QUOTES, 'UTF-8') : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Contacte con Geo Thermal Control España para solicitar una evaluación geotérmica, soporte o información sobre nuestras soluciones.">
  <meta name="keywords" content="contacto geotérmico, evaluación geotérmica, soporte geotérmico, Geo Thermal Control">
  <meta name="robots" content="index,follow">
  <link rel="canonical" href="https://www.geothermalcontrol.com/contact.php">
  <meta property="og:type" content="article">
  <meta property="og:title" content="Contacto | Geo Thermal Control España">
  <meta property="og:description" content="Envíe su consulta y coordine una evaluación geotérmica con nuestro equipo en Madrid.">
  <meta property="og:url" content="https://www.geothermalcontrol.com/contact.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?image=940">
  <link rel="icon" type="image/png" href="https://picsum.photos/64/64?image=1011">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
  <title>Contacto | Geo Thermal Control España</title>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": ["LocalBusiness", "EnergyService"],
    "name": "Geo Thermal Control España",
    "url": "https://www.geothermalcontrol.com/contact.php",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+34 915 678 432",
      "contactType": "Servicio al cliente",
      "areaServed": "ES"
    },
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Plaza Pablo Ruiz Picasso 1",
      "addressLocality": "Madrid",
      "postalCode": "28020",
      "addressCountry": "ES"
    }
  }
  </script>
</head>
<body>
  <a class="skip-link" href="#contenido-principal">Saltar al contenido</a>
  <header class="site-header">
    <div class="top-bar">
      <div class="container top-bar-inner">
        <span>Operamos en toda España | Especialistas en control geotérmico de misión crítica</span>
        <a href="tel:+34915678432">Teléfono: +34 915 678 432</a>
      </div>
    </div>
    <div class="header-main">
      <div class="container header-inner">
        <a href="index.html" class="brand" aria-label="Geo Thermal Control España inicio">
          <div class="brand-logo">GT</div>
          <div class="brand-text">
            <span>Geo Thermal Control</span>
            <span>Gestión geotérmica de precisión</span>
          </div>
        </a>
        <button class="menu-toggle" type="button" aria-label="Abrir menú" aria-expanded="false" aria-controls="site-navigation">
          Menú
          <span></span>
        </button>
        <div class="site-nav" id="site-navigation">
          <nav aria-label="Navegación principal">
            <ul>
              <li><a href="index.html">Inicio</a></li>
              <li><a href="about.html">Nosotros</a></li>
              <li><a href="solutions.html">Soluciones</a></li>
              <li><a href="technology.html">Tecnología</a></li>
              <li><a href="performance.html">Desempeño</a></li>
              <li><a href="projects.html">Proyectos</a></li>
              <li><a class="is-active" href="contact.php">Contacto</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>

  <main id="contenido-principal">
    <section class="page-hero inner-hero">
      <div class="container hero-inner">
        <div>
          <span class="badge"><i>📞</i> Estamos disponibles</span>
          <h1>Solicitar evaluación geotérmica</h1>
          <p>Complete el formulario o contáctenos directamente para coordinar una reunión con nuestros especialistas. Responderemos desde Madrid en menos de 24 horas laborables.</p>
        </div>
        <div class="hero-media">
          <img src="https://picsum.photos/720/520?image=902" alt="Equipo de atención geotérmica" loading="lazy">
        </div>
      </div>
    </section>

    <section class="page-section" aria-labelledby="formulario-contacto">
      <div class="container">
        <div class="form-wrapper">
          <h2 id="formulario-contacto">Comparta los detalles de su proyecto geotérmico</h2>
          <form action="thanks.php" method="post" class="form-grid" aria-describedby="mensaje-contacto">
            <div class="form-grid two-columns">
              <div class="form-field">
                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo $prefillNombre; ?>" required>
              </div>
              <div class="form-field">
                <label for="apellidos">Apellidos</label>
                <input type="text" id="apellidos" name="apellidos" required>
              </div>
              <div class="form-field">
                <label for="correo">Correo profesional</label>
                <input type="email" id="correo" name="correo" value="<?php echo $prefillCorreo; ?>" required>
              </div>
              <div class="form-field">
                <label for="telefono">Teléfono</label>
                <input type="tel" id="telefono" name="telefono" required>
              </div>
              <div class="form-field">
                <label for="empresa">Empresa/Entidad</label>
                <input type="text" id="empresa" name="empresa" required>
              </div>
              <div class="form-field">
                <label for="cargo">Cargo</label>
                <input type="text" id="cargo" name="cargo" required>
              </div>
              <div class="form-field">
                <label for="region">Comunidad autónoma</label>
                <select id="region" name="region" required>
                  <option value="">Seleccione</option>
                  <?php
                  $regiones = ["Andalucía","Aragón","Asturias","Illes Balears","Canarias","Cantabria","Castilla-La Mancha","Castilla y León","Catalunya","Comunidad de Madrid","Comunidad Valenciana","Extremadura","Galicia","La Rioja","Región de Murcia","Navarra","País Vasco"];
                  foreach ($regiones as $region) {
                    $selected = ($prefillRegion === $region) ? ' selected' : '';
                    echo "<option value=\"{$region}\"{$selected}>{$region}</option>";
                  }
                  ?>
                </select>
              </div>
              <div class="form-field">
                <label for="tipo-instalacion">Tipo de instalación</label>
                <select id="tipo-instalacion" name="tipo_instalacion" required>
                  <option value="">Seleccione</option>
                  <option value="Ciclo binario">Ciclo binario</option>
                  <option value="Red de calor geotérmica">Red de calor geotérmica</option>
                  <option value="Climatización geotérmica">Climatización geotérmica</option>
                  <option value="Exploración y perforación">Exploración y perforación</option>
                  <option value="Otras aplicaciones">Otras aplicaciones</option>
                </select>
              </div>
            </div>
            <div class="form-field">
              <label for="capacidades">Estado actual de la planta</label>
              <select id="capacidades" name="estado_planta" required>
                <option value="">Seleccione</option>
                <option value="En diseño">En diseño</option>
                <option value="En construcción">En construcción</option>
                <option value="Operativa">Operativa</option>
                <option value="En modernización">En modernización</option>
              </select>
            </div>
            <div class="form-field">
              <label for="mensaje">Mensaje</label>
              <textarea id="mensaje" name="mensaje" placeholder="Describa objetivos operativos, retos actuales y horizontes temporales." required></textarea>
            </div>
            <div class="checkbox-field">
              <input type="checkbox" id="consentimiento" name="consentimiento" value="aceptado" required>
              <label for="consentimiento">Autorizo a Geo Thermal Control España a utilizar mis datos para responder a esta solicitud conforme a la <a href="privacy.html">política de privacidad</a>.</label>
            </div>
            <div class="form-field">
              <button type="submit" class="btn btn-primary">Enviar solicitud</button>
            </div>
          </form>
          <p id="mensaje-contacto" class="alert-box">Nuestra oficina central se encuentra en Torre Picasso, Madrid. Coordinamos visitas técnicas y sesiones remotas según su preferencia.</p>
        </div>
      </div>
    </section>

    <section class="page-section" aria-labelledby="contacto-directo">
      <div class="container media-block">
        <div class="media-content">
          <span class="badge"><i>📍</i> Oficina central</span>
          <h2 id="contacto-directo">Contacto directo</h2>
          <p>Torre Picasso, Plaza Pablo Ruiz Picasso 1<br>28020 Madrid, España</p>
          <p>Teléfono: <a href="tel:+34915678432">+34 915 678 432</a><br>Correo: <a href="mailto:contacto@geothermalcontrol.com">contacto@geothermalcontrol.com</a></p>
        </div>
        <div class="media-visual map-container">
          <iframe title="Ubicación de Geo Thermal Control España" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.4417396306105!2d-3.694469284604824!3d40.44827297936101!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4228fd826ff1a1%3A0x32956543d4d6acdf!2sTorre%20Picasso!5e0!3m2!1ses!2ses!4v1700000000000!5m2!1ses!2ses" loading="lazy"></iframe>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-top">
      <div class="footer-brand">
        <a href="index.html" class="brand" aria-label="Geo Thermal Control España inicio">
          <div class="brand-logo">GT</div>
          <div class="brand-text">
            <span>Geo Thermal Control</span>
            <span>Excelencia geotérmica nacional</span>
          </div>
        </a>
        <p>Geo Thermal Control España desarrolla sistemas de control, análisis y supervisión que garantizan la estabilidad térmica y la continuidad operacional de plantas geotérmicas en todo el territorio español.</p>
      </div>
      <div class="footer-grid">
        <div class="footer-list">
          <h4>Compañía</h4>
          <ul>
            <li><a href="about.html">Quiénes somos</a></li>
            <li><a href="solutions.html">Soluciones</a></li>
            <li><a href="technology.html">Tecnología</a></li>
            <li><a href="projects.html">Proyectos</a></li>
          </ul>
        </div>
        <div class="footer-list">
          <h4>Recursos</h4>
          <ul>
            <li><a href="performance.html">Desempeño</a></li>
            <li><a href="privacy.html">Privacidad</a></li>
            <li><a href="cookies.html">Cookies</a></li>
            <li><a href="terms.html">Aviso legal</a></li>
          </ul>
        </div>
        <div class="footer-list">
          <h4>Contacto</h4>
          <ul>
            <li>Geo Thermal Control España</li>
            <li>Torre Picasso, Plaza Pablo Ruiz Picasso 1</li>
            <li>28020 Madrid, España</li>
            <li><a href="tel:+34915678432">+34 915 678 432</a></li>
            <li><a href="mailto:contacto@geothermalcontrol.com">contacto@geothermalcontrol.com</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>© <?php echo date('Y'); ?> Geo Thermal Control España. Todos los derechos reservados.</span>
      <span>Dominio oficial: <a href="https://www.geothermalcontrol.com/">www.geothermalcontrol.com</a></span>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <strong>Control de cookies</strong>
    <p>Utilizamos cookies esenciales para asegurar el correcto funcionamiento del sitio y recopilar métricas anónimas. Puedes aceptar o rechazar su uso en cualquier momento. Para más información revisa nuestra <a href="cookies.html">política de cookies</a>.</p>
    <div class="cookie-actions">
      <button type="button" class="cookie-btn decline">Rechazar</button>
      <button type="button" class="cookie-btn accept">Aceptar</button>
    </div>
  </div>
</body>
</html>