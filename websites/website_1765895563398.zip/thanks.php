<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: contact.php');
  exit;
}

function limpiar($dato) {
  return htmlspecialchars(trim($dato), ENT_QUOTES, 'UTF-8');
}

$nombre = limpiar($_POST['nombre'] ?? '');
$apellidos = limpiar($_POST['apellidos'] ?? '');
$correo = limpiar($_POST['correo'] ?? '');
$telefono = limpiar($_POST['telefono'] ?? '');
$empresa = limpiar($_POST['empresa'] ?? '');
$cargo = limpiar($_POST['cargo'] ?? '');
$region = limpiar($_POST['region'] ?? '');
$tipo = limpiar($_POST['tipo_instalacion'] ?? '');
$estado = limpiar($_POST['estado_planta'] ?? '');
$mensaje = limpiar($_POST['mensaje'] ?? '');
$consentimiento = isset($_POST['consentimiento']) ? 'Sí' : 'No';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Confirmación de solicitud enviada a Geo Thermal Control España.">
  <meta name="robots" content="noindex,nofollow">
  <link rel="canonical" href="https://www.geothermalcontrol.com/thanks.php">
  <meta property="og:type" content="article">
  <meta property="og:title" content="Solicitud recibida | Geo Thermal Control España">
  <meta property="og:description" content="Hemos recibido tu mensaje y responderemos a la mayor brevedad.">
  <meta property="og:url" content="https://www.geothermalcontrol.com/thanks.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?image=916">
  <link rel="icon" type="image/png" href="https://picsum.photos/64/64?image=1011">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
  <title>Solicitud recibida | Geo Thermal Control España</title>
</head>
<body>
  <a class="skip-link" href="#contenido-principal">Saltar al contenido</a>
  <header class="site-header">
    <div class="top-bar">
      <div class="container top-bar-inner">
        <span>Operamos en toda España | Especialistas en control geotérmico de misión crítica</span>
        <a href="tel:+34915678432">Teléfono: +34 915 678 432</a>
      </div>
    </div>
    <div class="header-main">
      <div class="container header-inner">
        <a href="index.html" class="brand" aria-label="Geo Thermal Control España inicio">
          <div class="brand-logo">GT</div>
          <div class="brand-text">
            <span>Geo Thermal Control</span>
            <span>Gestión geotérmica de precisión</span>
          </div>
        </a>
        <button class="menu-toggle" type="button" aria-label="Abrir menú" aria-expanded="false" aria-controls="site-navigation">
          Menú
          <span></span>
        </button>
        <div class="site-nav" id="site-navigation">
          <nav aria-label="Navegación principal">
            <ul>
              <li><a href="index.html">Inicio</a></li>
              <li><a href="about.html">Nosotros</a></li>
              <li><a href="solutions.html">Soluciones</a></li>
              <li><a href="technology.html">Tecnología</a></li>
              <li><a href="performance.html">Desempeño</a></li>
              <li><a href="projects.html">Proyectos</a></li>
              <li><a href="contact.php">Contacto</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>

  <main id="contenido-principal">
    <section class="page-hero inner-hero">
      <div class="container hero-inner">
        <div>
          <span class="badge"><i>✅</i> Confirmación enviada</span>
          <h1>Gracias por contactar con Geo Thermal Control España</h1>
          <p>Su solicitud ha sido recibida. Nuestro equipo analizará la información y se pondrá en contacto con usted a la mayor brevedad para coordinar los siguientes pasos.</p>
        </div>
        <div class="hero-media">
          <img src="https://picsum.photos/720/520?image=919" alt="Confirmación de contacto geotérmico" loading="lazy">
        </div>
      </div>
    </section>

    <section class="page-section" aria-labelledby="resumen">
      <div class="container">
        <h2 id="resumen">Resumen de datos enviados</h2>
        <div class="grid four-grid">
          <div class="card">
            <h3>Contacto</h3>
            <p><?php echo "{$nombre} {$apellidos}"; ?><br><?php echo $correo; ?><br><?php echo $telefono; ?></p>
          </div>
          <div class="card">
            <h3>Empresa</h3>
            <p><?php echo $empresa; ?><br><?php echo $cargo; ?><br><?php echo $region; ?></p>
          </div>
          <div class="card">
            <h3>Instalación</h3>
            <p>Tipo: <?php echo $tipo; ?><br>Estado: <?php echo $estado; ?></p>
          </div>
          <div class="card">
            <h3>Preferencias</h3>
            <p>Consentimiento: <?php echo $consentimiento; ?></p>
          </div>
        </div>
        <div class="highlight-quote">
          <p><?php echo nl2br($mensaje); ?></p>
          <span>Mensaje recibido</span>
        </div>
        <a class="btn btn-primary" href="index.html">Volver al inicio</a>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-top">
      <div class="footer-brand">
        <a href="index.html" class="brand" aria-label="Geo Thermal Control España inicio">
          <div class="brand-logo">GT</div>
          <div class="brand-text">
            <span>Geo Thermal Control</span>
            <span>Excelencia geotérmica nacional</span>
          </div>
        </a>
        <p>Geo Thermal Control España desarrolla sistemas de control, análisis y supervisión que garantizan la estabilidad térmica y la continuidad operacional de plantas geotérmicas en todo el territorio español.</p>
      </div>
      <div class="footer-grid">
        <div class="footer-list">
          <h4>Compañía</h4>
          <ul>
            <li><a href="about.html">Quiénes somos</a></li>
            <li><a href="solutions.html">Soluciones</a></li>
            <li><a href="technology.html">Tecnología</a></li>
            <li><a href="projects.html">Proyectos</a></li>
          </ul>
        </div>
        <div class="footer-list">
          <h4>Recursos</h4>
          <ul>
            <li><a href="performance.html">Desempeño</a></li>
            <li><a href="privacy.html">Privacidad</a></li>
            <li><a href="cookies.html">Cookies</a></li>
            <li><a href="terms.html">Aviso legal</a></li>
          </ul>
        </div>
        <div class="footer-list">
          <h4>Contacto</h4>
          <ul>
            <li>Geo Thermal Control España</li>
            <li>Torre Picasso, Plaza Pablo Ruiz Picasso 1</li>
            <li>28020 Madrid, España</li>
            <li><a href="tel:+34915678432">+34 915 678 432</a></li>
            <li><a href="mailto:contacto@geothermalcontrol.com">contacto@geothermalcontrol.com</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>© <?php echo date('Y'); ?> Geo Thermal Control España. Todos los derechos reservados.</span>
      <span>Dominio oficial: <a href="https://www.geothermalcontrol.com/">www.geothermalcontrol.com</a></span>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <strong>Control de cookies</strong>
    <p>Utilizamos cookies esenciales para asegurar el correcto funcionamiento del sitio y recopilar métricas anónimas. Puedes aceptar o rechazar su uso en cualquier momento. Para más información revisa nuestra <a href="cookies.html">política de cookies</a>.</p>
    <div class="cookie-actions">
      <button type="button" class="cookie-btn decline">Rechazar</button>
      <button type="button" class="cookie-btn accept">Aceptar</button>
    </div>
  </div>
</body>
</html>