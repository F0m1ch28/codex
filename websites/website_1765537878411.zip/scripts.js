'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      navToggle.classList.toggle('is-active');
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('.nav-link').forEach((link) => {
      link.addEventListener('click', () => {
        siteNav.classList.remove('is-open');
        navToggle.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedConsent = localStorage.getItem('qb-cookie-consent');
    if (storedConsent) {
      cookieBanner.classList.add('is-hidden');
    } else {
      setTimeout(() => cookieBanner.classList.add('is-visible'), 500);
    }

    const acceptButton = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineButton = cookieBanner.querySelector('[data-cookie="decline"]');

    const handleDecision = (value) => {
      localStorage.setItem('qb-cookie-consent', value);
      cookieBanner.classList.remove('is-visible');
      setTimeout(() => cookieBanner.classList.add('is-hidden'), 350);
    };

    acceptButton?.addEventListener('click', () => handleDecision('accepted'));
    declineButton?.addEventListener('click', () => handleDecision('declined'));
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const blogCards = document.querySelectorAll('[data-category]');
  if (filterButtons.length && blogCards.length) {
    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const target = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove('is-active'));
        button.classList.add('is-active');

        blogCards.forEach((card) => {
          const categories = card.dataset.category.split(',');
          if (target === 'all' || categories.includes(target)) {
            card.classList.remove('is-hidden');
          } else {
            card.classList.add('is-hidden');
          }
        });
      });
    });
  }

  const faqButtons = document.querySelectorAll('.faq-item button');
  faqButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', (!expanded).toString());
      const item = button.closest('.faq-item');
      item?.classList.toggle('is-open');
      const icon = button.querySelector('.faq-icon');
      if (icon) {
        icon.textContent = expanded ? '+' : '−';
      }
      const answer = item?.querySelector('.faq-answer');
      if (answer) {
        answer.style.maxHeight = expanded ? null : `${answer.scrollHeight}px`;
      }
    });
  });

  document.querySelectorAll('[data-form="contact"]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const feedback = form.querySelector('.form-feedback');
      if (feedback) {
        feedback.textContent = 'Рахмет! Өтінішіңіз қабылданды, менеджеріміз жақын уақытта хабарласады.';
      }
      form.reset();
    });
  });

  document.querySelectorAll('[data-form="newsletter"]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const feedback = form.querySelector('.form-feedback');
      if (feedback) {
        feedback.textContent = 'Жазылуыңыз үшін рахмет! Біз жаңалықтарды email арқылы жібереміз.';
      }
      form.reset();
    });
  });
});