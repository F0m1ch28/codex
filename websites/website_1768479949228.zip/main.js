document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            siteNav.classList.toggle('open');
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('open')) {
                    siteNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-button.accept');
    const declineBtn = document.querySelector('.cookie-button.decline');
    const consentKey = 'seculagbjsCookieConsent';

    if (cookieBanner && acceptBtn && declineBtn) {
        const consent = localStorage.getItem(consentKey);
        if (!consent) {
            cookieBanner.classList.add('active');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});