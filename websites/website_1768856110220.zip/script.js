document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.primary-navigation');
    const navLinks = document.querySelectorAll('.primary-navigation a');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navigation.classList.toggle('open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navigation.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 768) {
                navigation.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
        const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
        const preference = localStorage.getItem('rm-cookie-consent');

        if (preference) {
            cookieBanner.classList.add('hidden');
        }

        const handleConsent = (value) => {
            localStorage.setItem('rm-cookie-consent', value);
            cookieBanner.classList.add('hidden');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleConsent('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleConsent('declined'));
        }
    }
});