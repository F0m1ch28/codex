const blogPosts = [
  {
    slug: 'tiefer-fokus-in-15-minuten',
    title: 'Tiefer Fokus in 15 Minuten: So startest Du Deinen Tag',
    excerpt: 'Ein klarer Start bringt Dich schneller in die Tiefe. Diese Rituale schaffen Fokus, noch bevor das erste Meeting beginnt.',
    category: 'Fokus',
    author: 'Lena Krüger',
    date: '2024-02-12',
    readTime: '6 Min',
    cover: 'https://picsum.photos/800/600?random=12',
    tags: ['Morgenroutine', 'Mindset', 'Deep Work'],
    content: [
      'Der Übergang vom Aufwachen zum produktiven Arbeiten entscheidet darüber, wie klar Dein Tag wird. Statt das Handy zu greifen, beginne mit einer zweiminütigen Atemübung. Dein Nervensystem reguliert sich, bevor die Informationsflut startet.',
      'Plane anschließend maximal drei Schwerpunkte. Niedrige Prioritäten wandern bewusst auf eine Später-Liste. So schützt Du Deine kognitiven Ressourcen vor unnötigem Kontextwechsel.',
      'Beende Deine 15 Minuten mit einem Fokus-Trigger. Das kann ein bestimmter Song, ein Duft oder eine Routine-Handlung sein. Wiederholung macht Deinen Einstieg verlässlich.'
    ]
  },
  {
    slug: 'achtsamer-umgang-mit-benachrichtigungen',
    title: 'Achtsamer Umgang mit Benachrichtigungen im Team-Alltag',
    excerpt: 'Notifications verschwinden nicht – aber Du kannst sie gestalten. Drei Schritte, mit denen Teams störungsfrei zusammenarbeiten.',
    category: 'Kommunikation',
    author: 'Marco Lindner',
    date: '2024-03-02',
    readTime: '7 Min',
    cover: 'https://picsum.photos/800/600?random=18',
    tags: ['Teamarbeit', 'Kollaboration', 'Digital Balance'],
    content: [
      'Push-Mitteilungen sind nicht per se schlecht, aber sie brauchen Regeln. Lege Verbindlichkeiten fest: Welche Kanäle sind für schnelle Antworten, welche für Dokumentation?',
      'Arbeite mit Batch-Fenstern. Teams, die zweimal am Tag gemeinsam Nachrichten bearbeiten, berichten von klarerer Kommunikation und weniger Stress.',
      'Verankere Fokuszeiten im Kalender. Wenn alle wissen, dass zwischen 9 und 11 Uhr keine Antwort erwartet wird, lassen sich tiefe Arbeiten besser planen.'
    ]
  },
  {
    slug: 'multitasking-entlarvt',
    title: 'Multitasking entlarvt: Wie Du aus Mustern aussteigst',
    excerpt: 'Multitasking ist ein Mythos. Lerne, Deine Energie gezielt zu lenken und mentale Streuverluste zu reduzieren.',
    category: 'Mindset',
    author: 'Sarah Albrecht',
    date: '2024-01-24',
    readTime: '8 Min',
    cover: 'https://picsum.photos/800/600?random=26',
    tags: ['Aufmerksamkeit', 'Gewohnheiten', 'Neurohygiene'],
    content: [
      'Das Gehirn kann nicht wirklich parallel arbeiten. Es springt – und verliert dabei Informationen. Multitasking kostet im Schnitt 40 % Produktivität.',
      'Der erste Schritt raus aus dem Muster: Erkenne Deine Trigger. Welche Aufgaben lösen das Bedürfnis aus, mehrere Dinge gleichzeitig zu tun?',
      'Nutze stattdessen Mikromomente. Eine Aufgabe abschließen, eine Pause zur Regulation, dann die nächste starten. So entsteht Flow – nicht durch Verzettelung.'
    ]
  }
];

export default blogPosts;