import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Notification Canvas',
    description: 'Eine interaktive Vorlage, mit der Du Benachrichtigungen kategorisierst und neue Regeln festlegst.',
    format: 'Miro + PDF',
    linkText: 'Canvas laden'
  },
  {
    title: 'Digital Detox Checkliste',
    description: '30 kleine Schritte, mit denen Du Deinen Alltag entschleunigst – ohne radikale Verbote.',
    format: 'Notion Template',
    linkText: 'Checkliste nutzen'
  },
  {
    title: 'Fokus-Session Timer',
    description: 'Audio-unterstützte Fokusblöcke mit Atem-Prompts und sanften Pausensignalen.',
    format: 'Audio + Timer',
    linkText: 'Session starten'
  },
  {
    title: 'Team Communication Playbook',
    description: 'Best Practices für asynchrone Zusammenarbeit, Statusupdates und Meeting-Kultur.',
    format: 'Playbook PDF',
    linkText: 'Playbook öffnen'
  }
];

const Tools = () => (
  <>
    <Helmet>
      <title>Tivarenso – Tools & Ressourcen</title>
      <meta
        name="description"
        content="Praktische Tools von Tivarenso: Checklisten, Playbooks und Timer, die Deinen Fokusalltag unterstützen."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Tools für Deinen Alltag</h1>
        <p>Hol Dir Vorlagen, Checklisten und Timer, die Fokus greifbar machen. Sofort nutzbar, überall verfügbar.</p>
      </div>
    </section>

    <section className={styles.toolGrid}>
      <div className="container">
        {tools.map((tool) => (
          <article key={tool.title} className={styles.card}>
            <h2>{tool.title}</h2>
            <p>{tool.description}</p>
            <div className={styles.meta}>
              <span>{tool.format}</span>
            </div>
            <button type="button" className={styles.linkButton}>
              {tool.linkText}
            </button>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Tools;