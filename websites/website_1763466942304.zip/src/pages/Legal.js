import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Legal = () => (
  <>
    <Helmet>
      <title>Tivarenso – Rechtliches</title>
      <meta
        name="description"
        content="Rechtliche Hinweise von Tivarenso. Transparenz und verantwortungsbewusster Umgang mit Daten."
      />
    </Helmet>
    <section className={styles.legal}>
      <div className="container">
        <h1>Rechtliche Hinweise</h1>
        <p>
          Transparenz ist uns wichtig. Hier findest Du alle Informationen zu Haftung, Inhalten und Verantwortlichkeiten von
          Tivarenso.
        </p>
        <section>
          <h2>Haftung für Inhalte</h2>
          <p>
            Die Inhalte unserer Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und
            Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen. Als Diensteanbieter sind wir gemäß § 7 Abs. 1
            TMG für eigene Inhalte verantwortlich.
          </p>
        </section>
        <section>
          <h2>Haftung für Links</h2>
          <p>
            Unser Angebot enthält Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb
            können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist
            stets der jeweilige Anbieter verantwortlich.
          </p>
        </section>
        <section>
          <h2>Urheberrecht</h2>
          <p>
            Die durch Tivarenso erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht.
            Beiträge Dritter sind als solche gekennzeichnet. Die Vervielfältigung oder Verbreitung bedarf der schriftlichen
            Zustimmung.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Legal;