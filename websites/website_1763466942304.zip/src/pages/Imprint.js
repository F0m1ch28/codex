import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Imprint.module.css';

const Imprint = () => (
  <>
    <Helmet>
      <title>Tivarenso – Impressum</title>
      <meta
        name="description"
        content="Impressum von Tivarenso. Ansprechpartner und Kontaktdaten entsprechend deutscher Gesetzgebung."
      />
    </Helmet>
    <section className={styles.imprint}>
      <div className="container">
        <h1>Impressum</h1>
        <p>Tivarenso</p>
        <p>Platzhalter-Adresse in Deutschland</p>
        <p>E-Mail: kontakt@tivarenso.de</p>

        <section>
          <h2>Vertreten durch</h2>
          <p>Lena Krüger & Marco Lindner</p>
        </section>

        <section>
          <h2>Kontakt</h2>
          <p>E-Mail: kontakt@tivarenso.de</p>
        </section>

        <section>
          <h2>Haftungshinweis</h2>
          <p>
            Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links. Für den
            Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Imprint;