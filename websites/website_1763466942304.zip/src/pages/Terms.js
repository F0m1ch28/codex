import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Tivarenso – Allgemeine Geschäftsbedingungen</title>
      <meta
        name="description"
        content="AGB von Tivarenso. Erfahre die Vertragsbedingungen für Programme, Workshops und Tools."
      />
    </Helmet>
    <section className={styles.terms}>
      <div className="container">
        <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
        <section>
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Allgemeinen Geschäftsbedingungen gelten für sämtliche Leistungen von Tivarenso gegenüber Verbraucher:innen
            und Unternehmer:innen. Abweichende Bedingungen erkennen wir nur an, wenn wir sie ausdrücklich schriftlich bestätigen.
          </p>
        </section>
        <section>
          <h2>2. Leistungen</h2>
          <p>
            Wir bieten Programme, Workshops und digitale Tools rund um Fokus und digitale Balance an. Umfang, Dauer und Inhalte
            ergeben sich aus der jeweiligen Leistungsbeschreibung.
          </p>
        </section>
        <section>
          <h2>3. Teilnahme & Stornierung</h2>
          <p>
            Termine können bis 7 Tage vor Beginn kostenfrei verschoben werden. Danach behalten wir uns vor, eine Bearbeitungspauschale
            zu erheben. Bei Gruppenangeboten gelten separate Vereinbarungen.
          </p>
        </section>
        <section>
          <h2>4. Haftung</h2>
          <p>
            Wir übernehmen keine Garantie für den Eintritt bestimmter Ergebnisse. Unsere Angebote ersetzen keine Therapie.
            Für leichte Fahrlässigkeit haften wir nur bei Verletzung wesentlicher Vertragspflichten.
          </p>
        </section>
        <section>
          <h2>5. Schlussbestimmungen</h2>
          <p>
            Es gilt deutsches Recht. Gerichtsstand ist, soweit gesetzlich zulässig, der Sitz von Tivarenso. Sollten einzelne
            Bestimmungen unwirksam sein, bleibt die Wirksamkeit der übrigen Bestimmungen unberührt.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Terms;