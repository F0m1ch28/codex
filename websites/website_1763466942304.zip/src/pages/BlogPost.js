import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import blogPosts from '../data/blogPosts';
import styles from './BlogPost.module.css';

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Artikel nicht gefunden</h1>
          <p>Der gesuchte Beitrag existiert nicht mehr oder wurde verschoben.</p>
          <Link to="/blog" className={styles.backLink}>
            Zurück zum Blog
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`Tivarenso – ${post.title}`}</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>
      <article className={styles.post}>
        <div className={styles.hero} aria-label="Blog Cover">
          <img src={post.cover} alt={`Beitragsbild: ${post.title}`} />
        </div>
        <div className="container">
          <header className={styles.header}>
            <div className={styles.meta}>
              <span>{new Date(post.date).toLocaleDateString('de-DE')}</span>
              <span>{post.readTime} Lesezeit</span>
              <span>{post.author}</span>
            </div>
            <h1>{post.title}</h1>
            <div className={styles.tags}>
              {post.tags.map((tag) => (
                <span key={tag}>{tag}</span>
              ))}
            </div>
          </header>
          <div className={styles.content}>
            {post.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
          <footer className={styles.footer}>
            <Link to="/blog" className={styles.backLink}>
              Zurück zur Übersicht
            </Link>
          </footer>
        </div>
      </article>
    </>
  );
};

export default BlogPost;