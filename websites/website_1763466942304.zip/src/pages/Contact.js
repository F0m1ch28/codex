import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const contactEmail = 'kontakt@tivarenso.de';

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte gib Deinen Namen ein.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) newErrors.message = 'Bitte schildere kurz Dein Anliegen.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData({ name: '', email: '', topic: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Tivarenso – Kontakt</title>
        <meta
          name="description"
          content="Du möchtest mit Tivarenso arbeiten oder hast Fragen? Schreib uns – wir melden uns zeitnah zurück."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Lass uns über Deinen Fokus sprechen</h1>
          <p>
            Schreib uns, wenn Du Fragen hast oder ein Programm starten möchtest. Wir hören zu und melden uns innerhalb von 48 Stunden.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">
                Name
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby="name-error"
                  placeholder="Wie dürfen wir Dich ansprechen?"
                />
                {errors.name && (
                  <span id="name-error" className={styles.error}>
                    {errors.name}
                  </span>
                )}
              </label>
              <label htmlFor="email">
                E-Mail
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby="email-error"
                  placeholder="dein.name@email.de"
                />
                {errors.email && (
                  <span id="email-error" className={styles.error}>
                    {errors.email}
                  </span>
                )}
              </label>
              <label htmlFor="topic">
                Thema (optional)
                <select id="topic" name="topic" value={formData.topic} onChange={handleChange}>
                  <option value="">Was passt am besten?</option>
                  <option value="Programme">Programme & Sprints</option>
                  <option value="Workshops">Workshops</option>
                  <option value="Kooperation">Kooperation</option>
                  <option value="Sonstiges">Sonstiges</option>
                </select>
              </label>
              <label htmlFor="message">
                Nachricht
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby="message-error"
                  placeholder="Erzähl uns kurz, wobei wir Dich unterstützen dürfen."
                  rows="5"
                />
                {errors.message && (
                  <span id="message-error" className={styles.error}>
                    {errors.message}
                  </span>
                )}
              </label>
              <button type="submit" className={styles.submit}>
                Nachricht senden
              </button>
              {submitted && <p className={styles.success}>Danke für Deine Nachricht! Wir melden uns bald.</p>}
            </form>
            <aside className={styles.info}>
              <div className={styles.contactCard}>
                <h2>Direkter Kontakt</h2>
                <p>Du erreichst uns bevorzugt per E-Mail.</p>
                <a href={`mailto:${contactEmail}`} className={styles.contactEmail}>
                  {contactEmail}
                </a>
              </div>
              <div className={styles.contactCard}>
                <h2>Adresse</h2>
                <p>Platzhalter-Adresse in Deutschland</p>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;