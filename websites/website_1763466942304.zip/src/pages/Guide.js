import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const Guide = () => (
  <>
    <Helmet>
      <title>Tivarenso – Guide</title>
      <meta
        name="description"
        content="Dein Schritt-für-Schritt Guide für mehr Fokus: Gewohnheiten, Check-ins und digitale Routinen, die wirken."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Dein Fokus-Guide in 7 Schritten</h1>
        <p>Ein klarer Fahrplan, mit dem Du Deinen Medienkonsum beruhigst und tiefere Arbeit möglich machst.</p>
      </div>
    </section>
    <section className={styles.steps}>
      <div className="container">
        <ol>
          <li>
            <h2>Inventur: Wo fließt Deine Aufmerksamkeit hin?</h2>
            <ul>
              <li>Notiere für 48 Stunden, welche Apps Du wann und warum öffnest.</li>
              <li>Welche Gefühle tauchen danach auf – Klarheit oder Druck?</li>
              <li>Markiere Momente, in denen Du bewusst entschieden hast.</li>
            </ul>
          </li>
          <li>
            <h2>Micro-Pause etablieren</h2>
            <ul>
              <li>Setze 3× täglich einen 60-Sekunden-Anker (Atmen, Strecken, Augen schließen).</li>
              <li>Verbinde die Pause mit einem festen Ereignis, z. B. Kaffee oder Meeting-Ende.</li>
            </ul>
          </li>
          <li>
            <h2>Device-Zonen definieren</h2>
            <ul>
              <li>Büro, Sofa, Bett – wofür nutzt Du welches Gerät?</li>
              <li>Starte mit einer zone-freien Stunde pro Tag.</li>
            </ul>
          </li>
          <li>
            <h2>Notifications kuratieren</h2>
            <ul>
              <li>Stelle Pushs auf „kritisch“, „bündeln“, „lautlos“.</li>
              <li>Nimm Dir 20 Minuten für einen radikalen App-Check.</li>
            </ul>
          </li>
          <li>
            <h2>Fokusblöcke planen</h2>
            <ul>
              <li>Setze zwei 45-Minuten-Blöcke pro Woche – mit Kalenderblocker.</li>
              <li>Verabrede Dich mit Dir selbst: Zweck, Ergebnis, Belohnung.</li>
            </ul>
          </li>
          <li>
            <h2>Reflexion am Abend</h2>
            <ul>
              <li>Was hat heute Fokus geschenkt? Was hat ihn gezogen?</li>
              <li>Eine Erkenntnis pro Tag reicht, damit Dein Gehirn dazulernt.</li>
            </ul>
          </li>
          <li>
            <h2>Community nutzen</h2>
            <ul>
              <li>Suche Verbündete: Wer im Team will ebenfalls klarer arbeiten?</li>
              <li>Teile Wins & Hürden – Fokus gelingt gemeinsam leichter.</li>
            </ul>
          </li>
        </ol>
      </div>
    </section>
  </>
);

export default Guide;