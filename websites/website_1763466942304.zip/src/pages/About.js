import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Lena Krüger',
    role: 'Co-Founder · Fokus & Habit Design',
    bio: 'Psychologin, zertifizierte Habit-Coach, spezialisiert auf Aufmerksamkeit in digitalen Arbeitswelten.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Marco Lindner',
    role: 'Co-Founder · Collaboration Strategist',
    bio: 'Projektleiter aus der Tech-Szene. Baut Kommunikations-Systeme, die Menschen und Ziele zusammenbringen.',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Sarah Albrecht',
    role: 'Content Lead · Mindful Media',
    bio: 'Freie Journalistin und Content-Strategin. Übersetzt Fokuswissen in greifbare Stories und Tools.',
    image: 'https://picsum.photos/400/400?random=33'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>Tivarenso – Über uns</title>
      <meta
        name="description"
        content="Lerne das Tivarenso Team kennen. Wir verbinden Neurowissenschaft, Team-Coaching und Content-Design für Deinen digitalen Fokus."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Wir glauben an fokussierte Menschen in einer schnellen Welt.</h1>
        <p>
          Tivarenso ist in Deutschland entstanden, weil wir selbst erlebt haben, wie rasch digitale Reize unsere Präsenz
          verschlucken. Heute begleiten wir Menschen und Teams dabei, Aufmerksamkeit bewusst zu lenken – empathisch,
          realistisch und ohne Dogmen.
        </p>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <h2>Unsere Leitlinien</h2>
        <div className={styles.grid}>
          <article>
            <h3>Empathisches Zuhören</h3>
            <p>Wir hören zu, bevor wir beraten – jede digitale Routine hat eine Geschichte.</p>
          </article>
          <article>
            <h3>Wissenschaft & Alltag</h3>
            <p>Neurowissenschaft, Psychologie und Design Thinking verschmelzen in greifbaren Formaten.</p>
          </article>
          <article>
            <h3>Vertrauensvolle Partnerschaft</h3>
            <p>Transparent, datenseriös und in Deutschland gehostet. Du behältst die Kontrolle.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Team Tivarenso</h2>
          <p>Wir vereinen Coaching, Kommunikation und Strategie – für digitale Balance mit Haltung.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.memberCard}>
              <div className={styles.avatar}>
                <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              </div>
              <div className={styles.memberInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.story}>
      <div className="container">
        <h2>Unsere Geschichte</h2>
        <div className={styles.storyGrid}>
          <article>
            <h3>2020: Idee aus Überlastung</h3>
            <p>
              Mitten im Remote-Shift merkten wir: Menschen brauchen konkrete Methoden, um nicht im digitalen Lärm zu
              untergehen. Aus Workshops mit Startups wurde eine Vision.
            </p>
          </article>
          <article>
            <h3>2022: Geburtsstunde Tivarenso</h3>
            <p>
              Wir gründeten Tivarenso als Plattform für digitale Achtsamkeit. Seitdem arbeiten wir mit Freelancern,
              Mittelstand und Corporates in ganz Deutschland.
            </p>
          </article>
          <article>
            <h3>Heute: Fokussiert Netzwerke stärken</h3>
            <p>
              Unser Fokus: Menschen befähigen, selbstbestimmt mit digitalen Tools umzugehen. Wir bauen Partnerschaften mit
              Bildungsinstitutionen und Unternehmen aus.
            </p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default About;