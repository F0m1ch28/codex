import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import blogPosts from '../data/blogPosts';
import styles from './Blog.module.css';

const categories = ['Alle', 'Fokus', 'Kommunikation', 'Mindset'];

const Blog = () => {
  const [activeCategory, setActiveCategory] = useState('Alle');

  const filteredPosts = useMemo(() => {
    if (activeCategory === 'Alle') return blogPosts;
    return blogPosts.filter((post) => post.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>Tivarenso – Blog</title>
        <meta
          name="description"
          content="Frische Impulse für Deinen digitalen Alltag. Fokus, Kommunikation und Mindset – praxisnah und empathisch."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Impulse für Deinen digitalen Fokus</h1>
          <p>Kurze Artikel, tiefgehende Denkanstöße und Übungen, die Du sofort testen kannst.</p>
        </div>
      </section>

      <section className={styles.blogList}>
        <div className="container">
          <div className={styles.filterBar} role="toolbar" aria-label="Blog filtern">
            {categories.map((category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filteredPosts.map((post) => (
              <article key={post.slug} className={styles.card}>
                <img src={post.cover} alt={`Beitragsbild: ${post.title}`} loading="lazy" />
                <div className={styles.cardContent}>
                  <span className={styles.category}>{post.category}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <div className={styles.meta}>
                    <span>{new Date(post.date).toLocaleDateString('de-DE')}</span>
                    <span>{post.readTime}</span>
                  </div>
                  <Link to={`/blog/${post.slug}`} className={styles.readMore}>
                    Weiterlesen
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;