import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Tivarenso – Datenschutz</title>
      <meta
        name="description"
        content="Datenschutzerklärung von Tivarenso. Erfahre, wie wir mit Deinen Daten umgehen und sie schützen."
      />
    </Helmet>
    <section className={styles.privacy}>
      <div className="container">
        <h1>Datenschutz</h1>
        <p>
          Der Schutz Deiner persönlichen Daten ist uns wichtig. Wir behandeln Deine personenbezogenen Daten vertraulich und
          entsprechend der gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung.
        </p>
        <section>
          <h2>Allgemeine Hinweise</h2>
          <p>
            Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Deinen personenbezogenen Daten passiert,
            wenn Du unsere Website besuchst.
          </p>
        </section>
        <section>
          <h2>Verantwortliche Stelle</h2>
          <p>Tivarenso · Platzhalter-Adresse in Deutschland · E-Mail: kontakt@tivarenso.de</p>
        </section>
        <section>
          <h2>Datenerfassung auf unserer Website</h2>
          <p>
            Daten werden automatisch beim Besuch der Website durch unsere IT-Systeme erfasst. Dabei handelt es sich vor allem
            um technische Daten (z. B. Internetbrowser, Betriebssystem oder Uhrzeit des Seitenaufrufs). Die Erfassung erfolgt
            automatisch, sobald Du unsere Website betrittst.
          </p>
        </section>
        <section>
          <h2>Cookies</h2>
          <p>
            Unsere Internetseiten verwenden teilweise Cookies. Cookies richten auf Deinem Rechner keinen Schaden an und
            enthalten keine Viren. Sie dienen dazu, unser Angebot nutzerfreundlicher zu machen. Du kannst der Nutzung von
            Cookies widersprechen.
          </p>
        </section>
        <section>
          <h2>Deine Rechte</h2>
          <p>
            Du hast jederzeit das Recht auf unentgeltliche Auskunft über Herkunft, Empfänger und Zweck Deiner gespeicherten
            personenbezogenen Daten. Außerdem hast Du das Recht auf Berichtigung oder Löschung dieser Daten.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Privacy;