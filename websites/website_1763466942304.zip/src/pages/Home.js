import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import blogPosts from '../data/blogPosts';
import styles from './Home.module.css';

const statsData = [
  { label: 'Fokussessions begleitet', value: 1280, suffix: '+' },
  { label: 'Minuten bewusster Bildschirmzeit', value: 86400, suffix: '' },
  { label: 'Teams in Europa', value: 56, suffix: '' },
  { label: 'Workshops pro Quartal', value: 22, suffix: '' }
];

const testimonials = [
  {
    name: 'Nadia Vogt',
    role: 'Product Lead, SaaS-Scale-up',
    quote:
      '„Tivarenso hat uns gezeigt, wie Fokus als Teamhaltung funktioniert. Unser Meeting-Overload ist um 30 % gesunken – wir fühlen uns wieder verbunden.“'
  },
  {
    name: 'Jonathan Reimer',
    role: 'Freelance Designer',
    quote:
      '„Die kurzen Fokus-Sprints haben mein kreatives Arbeiten geerdet. Kein Drama mehr, wenn Social Media pingen möchte.“'
  },
  {
    name: 'Mareike Scholz',
    role: 'HR Business Partner',
    quote:
      '„Wir nutzen das Dashboard, um bewusst Pausen einzuplanen. Fluktuation gesunken, Energie gestiegen. Genau die Mischung, die wir brauchten.“'
  }
];

const projects = [
  {
    title: 'Digital Detox Week',
    category: 'Privat',
    image: 'https://picsum.photos/1200/800?random=41',
    description: 'Sieben Tage bewusster Medienkonsum mit täglicher Reflexion und Mini-Workshops.'
  },
  {
    title: 'Focus@Work Playbook',
    category: 'Team',
    image: 'https://picsum.photos/1200/800?random=42',
    description: 'Maßgeschneiderte Fokus-Guidelines für hybride Teams inklusive Ritualbibliothek.'
  },
  {
    title: 'Mindful Creator Flow',
    category: 'Kreativ',
    image: 'https://picsum.photos/1200/800?random=43',
    description: 'Begleitung für Content-Profis: Publishing ohne Erschöpfung dank klarer Rhythmen.'
  },
  {
    title: 'Notification Audit',
    category: 'Team',
    image: 'https://picsum.photos/1200/800?random=44',
    description: 'Analyse von Kommunikationskanälen und Benachrichtigungen mit neuem Regelwerk.'
  }
];

const faqItems = [
  {
    question: 'Wie schnell kann ich erste Ergebnisse spüren?',
    answer:
      'Viele spüren nach einer Woche strukturierter Fokuszeiten erste Entlastung. Der Schlüssel liegt in kleinen, konsequenten Anpassungen.'
  },
  {
    question: 'Sind die Programme für Einzelpersonen oder Teams?',
    answer:
      'Beides. Wir bieten persönliche Fokus-Coachings, aber auch modulare Teamprozesse mit Workshops, Check-ins und Toolkits.'
  },
  {
    question: 'Brauche ich spezielle Apps, um mit Tivarenso zu starten?',
    answer:
      'Nein. Wir setzen auf bewährte Tools und helfen Dir, bestehende Apps bewusster zu nutzen. Weniger Tool-Wechsel, mehr Klarheit.'
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [stats, setStats] = useState(statsData.map((item) => ({ ...item, current: 0 })));
  const [hasAnimated, setHasAnimated] = useState(false);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const statsRef = useRef(null);
  const [faqOpenIndex, setFaqOpenIndex] = useState(null);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Alle') return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!statsRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !hasAnimated) {
          animateStats();
          setHasAnimated(true);
        }
      },
      { threshold: 0.4 }
    );
    observer.observe(statsRef.current);
    return () => observer.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statsRef, hasAnimated]);

  const animateStats = () => {
    const duration = 1800;
    const startTime = performance.now();

    const step = (currentTime) => {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      setStats(
        statsData.map((item) => ({
          ...item,
          current: Math.floor(item.value * progress)
        }))
      );
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        setStats(statsData.map((item) => ({ ...item, current: item.value })));
      }
    };

    requestAnimationFrame(step);
  };

  return (
    <>
      <Helmet>
        <title>Tivarenso – Mehr Fokus. Weniger Ablenkung.</title>
        <meta
          name="description"
          content="Tivarenso zeigt Dir, wie Du in einer schnellen digitalen Welt klarer bleibst. Fokusprogramme, Tools und Guides für Deinen Alltag."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroBadge}>Digitale Achtsamkeit · Fokus · Klarheit</p>
          <h1>Mehr Fokus. Weniger Ablenkung im Kopf.</h1>
          <p className={styles.heroSubtitle}>
            Du willst Deinen digitalen Alltag bewusst steuern? Tivarenso begleitet Dich mit Programmen, Tools und Ritualen,
            die achtsame Mediennutzung und tiefe Arbeit verbinden.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryCta}>
              Jetzt Fokus stärken
            </Link>
            <Link to="/guide" className={styles.secondaryCta}>
              Aufmerksamkeit bewusst steuern
            </Link>
          </div>
          <div className={styles.heroMeta}>
            <span>Vertrauensvolle Begleitung aus Deutschland</span>
            <span>Mobile-first Learning · Nachhaltige Routinen</span>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Person arbeitet fokussiert ohne Ablenkungen"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.intro}>
        <div className="container">
          <h2>Aufmerksamkeit navigieren in einer Ära von Clips und Dauerscrollen</h2>
          <p>
            Ständige Streams, kurze Reels, permanente Notifications – unser Gehirn wird sekündlich geflutet.
            Tivarenso hilft Dir, die Kontrolle zurückzugewinnen: mit strukturiertem Fokus, bewussterem Konsum und
            realistischen Routinen, die in Deinen Alltag passen.
          </p>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef} aria-label="Tivarenso in Zahlen">
        <div className="container">
          {stats.map((item) => (
            <article key={item.label} className={styles.statCard}>
              <span className={styles.statValue}>
                {item.current.toLocaleString('de-DE')}
                {item.suffix}
              </span>
              <span className={styles.statLabel}>{item.label}</span>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Was sich spürbar verändert</h2>
            <p>Konzentrierte Arbeit, bewusster Medieneinsatz, weniger mentaler Lärm – greifbar statt theoretisch.</p>
          </div>
          <div className={styles.benefitGrid}>
            <article>
              <h3>Konzentrierte Arbeit</h3>
              <p>Deep-Work-Rituale, die Du wirklich umsetzen kannst – ohne Deinen Kalender zu sprengen.</p>
            </article>
            <article>
              <h3>Bewusstes Medienverhalten</h3>
              <p>Klare Entscheidungsregeln für Social Media, Chats und Newsfeeds, die Dich nicht in den Sog ziehen.</p>
            </article>
            <article>
              <h3>Weniger mentales Rauschen</h3>
              <p>Atemanker, Mikro-Pausen und Reflexion – damit Dein Nervensystem mitzieht, wenn Du fokussierst.</p>
            </article>
            <article>
              <h3>Gemeinsame Teamrituale</h3>
              <p>Transparente Kommunikations-Rhythmen für hybride Teams, damit Fokus kollektive Realität wird.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.teaser}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Deine Themen auf einen Blick</h2>
            <p>Wir packen digitale Herausforderungen an der Wurzel – alltagstauglich, menschlich und evidenzbasiert.</p>
          </div>
          <div className={styles.teaserGrid}>
            <article>
              <h3>Kurzvideos bewusst nutzen</h3>
              <p>Erkenne Trigger, setze Micro-Routinen und entziehe Dich der Sogwirkung im Feed.</p>
            </article>
            <article>
              <h3>Social Media freundlich gestalten</h3>
              <p>Baue Content-Zeiten und Community-Momente so, dass sie Dich nähren statt erschöpfen.</p>
            </article>
            <article>
              <h3>Multitasking entstressen</h3>
              <p>Von Kontextwechseln zu Fokus-Blöcken: So trainierst Du Deine Aufmerksamkeit Schritt für Schritt.</p>
            </article>
            <article>
              <h3>Benachrichtigungen im Griff</h3>
              <p>Ein System aus Regeln, Tools und Erwartungsmanagement, das alle mitgehen können.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.sectionSplit}>
            <div>
              <h2>Warum Tivarenso?</h2>
              <p>
                Weil digitale Balance nicht durch harte Verbote entsteht, sondern durch reflektierte Entscheidungen.
                Wir kombinieren Neurowissenschaft, Design Thinking und echte Team-Erfahrung – damit Du nicht nur
                verstehst, sondern veränderst.
              </p>
              <ul className={styles.whyList}>
                <li>Mobile-first Lernhappen, die in Pausen passen</li>
                <li>Workshops & Sprints – remote oder vor Ort in Deutschland</li>
                <li>Check-ins & Dashboards für nachhaltige Wirkung</li>
              </ul>
            </div>
            <div className={styles.process}>
              <h3>Unser Prozess</h3>
              <ol>
                <li>
                  <span className={styles.stepNumber}>1</span>
                  <div>
                    <h4>Analyse</h4>
                    <p>Wir schauen gemeinsam auf Deine digitalen Routinen und Stresspunkte.</p>
                  </div>
                </li>
                <li>
                  <span className={styles.stepNumber}>2</span>
                  <div>
                    <h4>Fokusplan</h4>
                    <p>Klar strukturierte Fokusblöcke, Pausen, Kommunikationsregeln.</p>
                  </div>
                </li>
                <li>
                  <span className={styles.stepNumber}>3</span>
                  <div>
                    <h4>Training</h4>
                    <p>Impulse, Reflexionsprompts und kleine Experimente über 4–6 Wochen.</p>
                  </div>
                </li>
                <li>
                  <span className={styles.stepNumber}>4</span>
                  <div>
                    <h4>Integration</h4>
                    <p>Retrospektive, Anpassung und Verstetigung der neuen Gewohnheiten.</p>
                  </div>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Stimmen aus der Community</h2>
            <p>Menschen, die Tivarenso nutzen, erleben Fokus als fühlbare Ressource.</p>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((item, index) => (
              <article
                key={item.name}
                className={`${styles.testimonialCard} ${activeTestimonial === index ? styles.testimonialActive : ''}`}
                aria-hidden={activeTestimonial !== index}
              >
                <p className={styles.quote}>{item.quote}</p>
                <div className={styles.person}>
                  <span className={styles.personName}>{item.name}</span>
                  <span className={styles.personRole}>{item.role}</span>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.carouselDots} role="tablist" aria-label="Testimonials auswählen">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`${styles.dot} ${activeTestimonial === index ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Testimonial ${index + 1}`}
                aria-selected={activeTestimonial === index}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Projekte & Sessions</h2>
            <p>Eine Auswahl unserer Begleitungen – filterbar nach Fokus.</p>
          </div>
          <div className={styles.filterBar} role="toolbar" aria-label="Projekte filtern">
            {['Alle', 'Privat', 'Team', 'Kreativ'].map((filter) => (
              <button
                key={filter}
                className={`${styles.filterButton} ${projectFilter === filter ? styles.filterButtonActive : ''}`}
                onClick={() => setProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={`Projekt ${project.title}`} loading="lazy" />
                  <span className={styles.projectCategory}>{project.category}</span>
                </div>
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/programs" className={styles.projectLink}>
                    Mehr erfahren
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>FAQ – Häufige Fragen</h2>
            <p>Du willst wissen, wie Tivarenso Dich begleitet? Hier findest Du erste Antworten.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <article key={item.question} className={styles.faqItem}>
                <button
                  className={styles.faqButton}
                  onClick={() => setFaqOpenIndex((prev) => (prev === index ? null : index))}
                  aria-expanded={faqOpenIndex === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{faqOpenIndex === index ? '–' : '+'}</span>
                </button>
                {faqOpenIndex === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Frische Impulse aus dem Blog</h2>
            <p>Kurze Inspirationen für Deinen Alltag – voller Fokus und Haltung.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.slice(0, 3).map((post) => (
              <article key={post.slug} className={styles.blogCard}>
                <img src={post.cover} alt={`Blogbeitrag: ${post.title}`} loading="lazy" />
                <div className={styles.blogMeta}>
                  <span>{new Date(post.date).toLocaleDateString('de-DE')}</span>
                  <span>{post.readTime}</span>
                </div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                  Weiterlesen
                </Link>
              </article>
            ))}
          </div>
          <div className={styles.blogAction}>
            <Link to="/blog" className={styles.secondaryCta}>
              Alle Artikel entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Bereit für mehr Leichtigkeit im digitalen Alltag?</h2>
            <p>
              Lass uns gemeinsam schauen, welche Routinen, Tools oder Programme Dich wirklich weiterbringen.
              Wir hören zu, bevor wir empfehlen.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className={styles.primaryCta}>
                Gespräch anfragen
              </Link>
              <Link to="/services" className={styles.secondaryCta}>
                Angebote entdecken
              </Link>
            </div>
          </div>
          <div className={styles.ctaImageWrapper}>
            <img
              src="https://picsum.photos/800/600?random=45"
              alt="Zwei Menschen im Fokusgespräch"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;