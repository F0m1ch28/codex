import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programs = [
  {
    name: 'Focus Reset',
    duration: '14 Tage',
    level: 'Einsteiger',
    description:
      'Kurze Audio-Impulse, Check-ins und Mini-Challenges, um Deine Aufmerksamkeit wieder bewusst zu lenken.',
    pillars: ['Atemanker', 'Fokus-Trigger', 'Digitale Inventur']
  },
  {
    name: 'Deep Work Studio',
    duration: '6 Wochen',
    level: 'Fortgeschritten',
    description:
      'Gemeinsame Fokus-Sessions, Rituale und Analysen, wie Du Arbeit in Flow-Zyklen organisierst – für Wissensarbeiter:innen.',
    pillars: ['Kontextwechsel reduzieren', 'Ressourcen-Tracking', 'Peer-Coaching']
  },
  {
    name: 'Team Clarity Sprint',
    duration: '5 Wochen',
    level: 'Teams',
    description:
      'Kommunikations-Regeln, Meeting-Frische, Notification Agreements – damit alle mitziehen und Klarheit spüren.',
    pillars: ['Kommunikationsvertrag', 'Meeting Detox', 'Fokus-Metriken']
  }
];

const Programs = () => (
  <>
    <Helmet>
      <title>Tivarenso – Programme</title>
      <meta
        name="description"
        content="Unsere Programme begleiten Dich Schritt für Schritt zu mehr Fokus. Von 14 Tagen Reset bis 6 Wochen Deep Work Studio."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Programme, die Dich durch den Wandel tragen</h1>
        <p>Wähle das Format, das zu Deinen Routinen passt – flexibel, empathisch und wissenschaftlich fundiert.</p>
      </div>
    </section>
    <section className={styles.programs}>
      <div className="container">
        <div className={styles.grid}>
          {programs.map((program) => (
            <article key={program.name} className={styles.card}>
              <header>
                <span className={styles.duration}>{program.duration}</span>
                <span className={styles.level}>{program.level}</span>
              </header>
              <h2>{program.name}</h2>
              <p>{program.description}</p>
              <ul>
                {program.pillars.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <button type="button" className={styles.cta}>
                Programm anfragen
              </button>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Programs;