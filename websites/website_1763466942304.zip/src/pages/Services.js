import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Fokus-Sprints (4 Wochen)',
    description:
      'Gemeinsame Fokusblöcke, Reflexionsfragen und Mikro-Impulse. Perfekt für Teams, die Deep Work neu etablieren möchten.',
    highlights: ['Wöchentliche Fokuslabore', 'Individuelle Fokuspläne', 'Team-Debriefs'],
    intensity: 'Team & Hybrid'
  },
  {
    title: 'Digital Balance Workshops',
    description:
      'Intensive Sessions für Unternehmen, die Benachrichtigungsfluten und Meeting-Overload nachhaltig reduzieren wollen.',
    highlights: ['Notification Audit', 'Kommunikations-Canvas', 'Vertrauensmatrix'],
    intensity: '4h, remote & vor Ort'
  },
  {
    title: 'Creator Flow Coaching',
    description:
      '1:1-Begleitung für Content-Creators. Struktur für Content, Pausen und Community-Management ohne Dauerstress.',
    highlights: ['Ritualentwicklung', 'Stress-Reflexion', 'Publishing-Rhythmus'],
    intensity: 'Individuell'
  },
  {
    title: 'Mindful Tech Lab',
    description:
      'Experimentierraum für Bildungseinrichtungen: Digitale Medien bewusst einsetzen, ohne Verbote, aber mit klaren Grenzen.',
    highlights: ['Impuls-Vorträge', 'Schul-Toolkits', 'Eltern-Dialog'],
    intensity: 'Für Schulen'
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Tivarenso – Angebote & Services</title>
      <meta
        name="description"
        content="Unsere Programme zeigen Dir, wie fokussierte Routinen entstehen. Von Teamsprints über Workshops bis zum individuellen Coaching."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Angebote, die Fokus fühlbar machen</h1>
        <p>
          Jedes Format verbindet Achtsamkeit, klare Strukturen und digitale Souveränität. Du bekommst keine To-do-Liste,
          sondern Begleitung, die Dich durch den Alltag trägt.
        </p>
      </div>
    </section>

    <section className={styles.services}>
      <div className="container">
        <div className={styles.serviceGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <header>
                <span className={styles.badge}>{service.intensity}</span>
                <h2>{service.title}</h2>
              </header>
              <p>{service.description}</p>
              <ul>
                {service.highlights.map((highlight) => (
                  <li key={highlight}>{highlight}</li>
                ))}
              </ul>
              <button type="button" className={styles.cardAction} aria-label={`${service.title} anfragen`}>
                Interesse anmelden
              </button>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Services;