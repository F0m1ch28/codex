import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Tivarenso Startseite">
          <span className={styles.logoMark}>T</span>
          <span className={styles.logoText}>Tivarenso</span>
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
          <NavLink to="/services" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={closeMenu}>
            Angebote
          </NavLink>
          <NavLink to="/programs" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={closeMenu}>
            Programme
          </NavLink>
          <NavLink to="/tools" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={closeMenu}>
            Tools
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={closeMenu}>
            Blog
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={closeMenu}>
            Über uns
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={closeMenu}>
            Kontakt
          </NavLink>
        </nav>
        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-label="Navigation umschalten"
          aria-expanded={menuOpen}
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
        </button>
      </div>
    </header>
  );
};

export default Header;