import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const contactEmail = 'kontakt@tivarenso.de';

  return (
    <footer className={styles.footer}>
      <div className={styles.top}>
        <div className={styles.brand}>
          <span className={styles.logo}>T</span>
          <div>
            <h3>Tivarenso</h3>
            <p>Digitale Balance für mehr Gelassenheit und Fokus im Alltag.</p>
          </div>
        </div>
        <div className={styles.columns}>
          <div className={styles.column}>
            <h4>Navigation</h4>
            <ul>
              <li>
                <Link to="/services">Angebote</Link>
              </li>
              <li>
                <Link to="/guide">Guide</Link>
              </li>
              <li>
                <Link to="/programs">Programme</Link>
              </li>
              <li>
                <Link to="/tools">Tools</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Unternehmen</h4>
            <ul>
              <li>
                <Link to="/about">Über Tivarenso</Link>
              </li>
              <li>
                <Link to="/blog">Blog</Link>
              </li>
              <li>
                <Link to="/legal">Rechtliches</Link>
              </li>
              <li>
                <Link to="/terms">AGB</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Kontakt</h4>
            <address>
              <span>Platzhalter-Adresse in Deutschland</span>
              <a href={`mailto:${contactEmail}`}>{contactEmail}</a>
              <Link to="/contact" className={styles.contactLink}>
                Schreib uns direkt
              </Link>
            </address>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {currentYear} Tivarenso. Alle Rechte vorbehalten.</span>
        <nav aria-label="Footer Navigation">
          <Link to="/privacy">Datenschutz</Link>
          <Link to="/imprint">Impressum</Link>
        </nav>
      </div>
    </footer>
  );
};

export default Footer;