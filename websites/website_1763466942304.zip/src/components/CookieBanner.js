import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem('tivarenso-cookie-consent');
    if (!storedConsent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('tivarenso-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem('tivarenso-cookie-consent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um Dein Erlebnis zu verbessern und anonyme Nutzungsstatistiken zu erheben.
          Du kannst selbst entscheiden, ob Du zustimmst.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.decline} onClick={handleDecline}>
            Ablehnen
          </button>
          <button type="button" className={styles.accept} onClick={handleAccept}>
            Zustimmen
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;