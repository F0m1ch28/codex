document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.classList.add('js-enabled');

  const navToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('open');
      navToggle.classList.toggle('open', isOpen);
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (navLinks.classList.contains('open')) {
          navLinks.classList.remove('open');
          navToggle.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const consentKey = 'dap_cookie_consent';
  const cookieBanner = document.querySelector('.cookie-banner');

  if (cookieBanner) {
    let storedConsent = null;

    try {
      storedConsent = localStorage.getItem(consentKey);
    } catch (error) {
      storedConsent = null;
    }

    if (!storedConsent) {
      setTimeout(() => {
        cookieBanner.classList.add('show');
      }, 600);
    }

    cookieBanner.querySelectorAll('[data-consent]').forEach(button => {
      button.addEventListener('click', () => {
        const value = button.dataset.consent || 'declined';
        try {
          localStorage.setItem(consentKey, value);
        } catch (error) {
          /* localStorage may be unavailable */
        }
        cookieBanner.classList.remove('show');
      });
    });
  }
});