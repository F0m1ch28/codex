document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("nav-open");
            navToggle.classList.toggle("is-open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const storedConsent = localStorage.getItem("lithodqnhw-cookie-consent");
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
        }
        const acceptBtn = cookieBanner.querySelector(".accept-cookie");
        const declineBtn = cookieBanner.querySelector(".decline-cookie");
        const customizeBtn = cookieBanner.querySelector(".customize-cookie");

        const setConsent = (value) => {
            localStorage.setItem("lithodqnhw-cookie-consent", value);
            cookieBanner.classList.add("hidden");
        };

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => setConsent("accepted"));
        }
        if (declineBtn) {
            declineBtn.addEventListener("click", () => setConsent("declined"));
        }
        if (customizeBtn) {
            customizeBtn.addEventListener("click", () => {
                window.location.href = "cookies.html";
            });
        }
    }
});