document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.menu-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navList.classList.toggle('open');
        });

        navList.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navList.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-button.accept');
    const declineButton = document.querySelector('.cookie-button.decline');
    const consentKey = 'procesqzsyCookieConsent';

    const hideBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove('visible');
        }
    };

    const showBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add('visible');
        }
    };

    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
        setTimeout(showBanner, 500);
    }

    if (acceptButton) {
        acceptButton.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            hideBanner();
        });
    }

    if (declineButton) {
        declineButton.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'declined');
            hideBanner();
        });
    }
});