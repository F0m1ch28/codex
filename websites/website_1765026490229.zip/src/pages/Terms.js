import React from 'react';

const Terms = () => {
  return (
    <div className="legal-page">
      <section className="page-hero compact">
        <div className="container page-hero-container">
          <h1>Terms of Use</h1>
          <p className="lead">Last updated: March 1, 2024</p>
        </div>
      </section>

      <section className="legal-section">
        <div className="container legal-content">
          <h2>1. Acceptance of terms</h2>
          <p>
            By accessing or using the NovaEdge Solutions website, you agree to be bound by these Terms of Use and all
            applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using
            or accessing this site.
          </p>

          <h2>2. Use license</h2>
          <p>
            Permission is granted to temporarily download one copy of the materials (information or software) on
            NovaEdge Solutions&apos; website for personal, non-commercial transitory viewing only. This is the grant of a
            license, not a transfer of title.
          </p>

          <h2>3. Disclaimer</h2>
          <p>
            The materials on NovaEdge Solutions&apos; website are provided on an &quot;as is&quot; basis. NovaEdge Solutions makes
            no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without
            limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or
            non-infringement of intellectual property.
          </p>

          <h2>4. Limitations</h2>
          <p>
            In no event shall NovaEdge Solutions or its suppliers be liable for any damages arising out of the use or
            inability to use the materials on the website, even if NovaEdge Solutions or an authorized representative has
            been notified orally or in writing of the possibility of such damage.
          </p>

          <h2>5. Governing law</h2>
          <p>
            These terms and conditions are governed by and construed in accordance with the laws of the State of New York
            and you irrevocably submit to the exclusive jurisdiction of the courts in that State.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;