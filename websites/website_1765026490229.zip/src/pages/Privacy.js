import React from 'react';

const Privacy = () => {
  return (
    <div className="legal-page">
      <section className="page-hero compact">
        <div className="container page-hero-container">
          <h1>Privacy Policy</h1>
          <p className="lead">Last updated: March 1, 2024</p>
        </div>
      </section>

      <section className="legal-section">
        <div className="container legal-content">
          <h2>Overview</h2>
          <p>
            NovaEdge Solutions is committed to protecting your privacy. This policy outlines how we collect, use, and
            safeguard information when you interact with our website, services, and communications.
          </p>

          <h2>Information we collect</h2>
          <p>
            We collect information that you voluntarily provide, including contact details, company information, and
            project inquiries. We may also collect usage data through cookies and analytics platforms to improve our
            services and website experience.
          </p>

          <h2>How we use information</h2>
          <p>
            Information is used to respond to inquiries, deliver requested services, provide relevant insights, and enhance
            our offerings. We do not sell personal information to third parties and only share data with trusted partners
            when necessary to deliver our services or comply with the law.
          </p>

          <h2>Your choices</h2>
          <p>
            You may request access, correction, or deletion of your personal information at any time by contacting us at
            privacy@novaedgesolutions.com. You can manage cookie preferences through your browser settings.
          </p>

          <h2>Security</h2>
          <p>
            We implement administrative, technical, and physical safeguards to protect personal information. While we work
            to protect your data, no method of transmission or storage is completely secure.
          </p>

          <h2>Policy updates</h2>
          <p>
            We may update this policy periodically to reflect changes to our practices or for operational, legal, or
            regulatory reasons. Updated policies will be posted on this page with revised effective dates.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;