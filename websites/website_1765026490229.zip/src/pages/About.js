import React from 'react';
import ImageWithLoader from '../components/ImageWithLoader';

const values = [
  {
    title: 'Outcome obsessed',
    description:
      'We anchor every initiative in clear KPIs and continuously iterate until we achieve measurable, lasting impact.'
  },
  {
    title: 'Human-centered',
    description:
      'Empathy fuels our work. We design every solution around the needs of your customers, partners, and teams.'
  },
  {
    title: 'Adaptive by design',
    description:
      'Our squads operate with agility, embracing experimentation and rapid learning to keep you ahead of change.'
  },
  {
    title: 'Transparent partnership',
    description:
      'We co-create with your teams, share knowledge openly, and build the capabilities you need to sustain success.'
  }
];

const timeline = [
  {
    year: '2016',
    title: 'NovaEdge Solutions is founded',
    description:
      'A group of consultants, technologists, and designers launch NovaEdge to bridge the gap between strategy and execution.'
  },
  {
    year: '2018',
    title: 'Global delivery network expansion',
    description:
      'We established innovation studios in New York, Toronto, and Lisbon to support clients across time zones.'
  },
  {
    year: '2020',
    title: 'Intelligent automation practice',
    description:
      'NovaEdge launches a center of excellence dedicated to automation, AI, and digital operations modernization.'
  },
  {
    year: '2023',
    title: 'Human experience lab',
    description:
      'We debut a lab focused on inclusive design, behavioral insights, and prototyping immersive customer experiences.'
  }
];

const leadershipTeam = [
  {
    name: 'Olivia Bennett',
    role: 'Founder & CEO',
    bio: 'Olivia leads NovaEdge with a focus on purpose-driven transformation and has guided dozens of Fortune 500 programs.',
    image: 'https://picsum.photos/400/400?random=311'
  },
  {
    name: 'Rahil Desai',
    role: 'Chief Technology Officer',
    bio: 'Rahil architects modern engineering ecosystems, ensuring security, scalability, and innovation readiness.',
    image: 'https://picsum.photos/400/400?random=312'
  },
  {
    name: 'Camille Durand',
    role: 'Chief Experience Officer',
    bio: 'Camille champions customer and employee journeys, blending research, design, and service innovation.',
    image: 'https://picsum.photos/400/400?random=313'
  },
  {
    name: 'Marcus Lee',
    role: 'Managing Director, Transformation',
    bio: 'Marcus partners with C-suites to mobilize transformation roadmaps and embed adaptive operating models.',
    image: 'https://picsum.photos/400/400?random=314'
  }
];

const About = () => {
  return (
    <div className="about-page">
      <section className="page-hero">
        <div className="container page-hero-container">
          <span className="hero-badge">About NovaEdge Solutions</span>
          <h1 className="page-title">We bridge strategy, design, and engineering to build the businesses of tomorrow.</h1>
          <p className="lead">
            NovaEdge Solutions was created to break silos and accelerate transformation. We partner with ambitious
            organizations to co-create the strategies, experiences, and capabilities that unlock lasting value.
          </p>
        </div>
      </section>

      <section className="story-section">
        <div className="container content-with-media">
          <div className="story-text">
            <h2>Our story</h2>
            <p>
              We started NovaEdge Solutions because clients needed a different kind of partner—one that could craft compelling
              strategies, translate them into experiences, and deliver solutions that scale. Our teams bring together senior
              strategists, researchers, designers, engineers, and change experts who operate as one integrated squad.
            </p>
            <p>
              We believe transformation only sticks when it is co-created. That is why we work shoulder-to-shoulder with your
              teams, embedding new capabilities while building the momentum required to adapt quickly to market change.
            </p>
            <p>
              Today, NovaEdge works with global enterprises and fast-scaling innovators across industries. We are driven by
              a shared mission: to help organizations build resilient advantage through human-centered, technology-enabled solutions.
            </p>
          </div>
          <ImageWithLoader
            src="https://picsum.photos/800/600?random=2"
            alt="NovaEdge Solutions team collaborating in the studio"
            wrapperClass="story-image"
            className="cover-image"
          />
        </div>
      </section>

      <section className="values-section">
        <div className="container">
          <h2 className="section-title">Our values</h2>
          <p className="section-subtitle">
            These principles guide how we collaborate, make decisions, and show up for our clients and communities every day.
          </p>
          <div className="value-grid">
            {values.map((value) => (
              <div className="value-card" key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="timeline-section">
        <div className="container">
          <h2 className="section-title">Milestones on our journey</h2>
          <div className="timeline">
            {timeline.map((item) => (
              <div className="timeline-item" key={item.year}>
                <span className="timeline-year">{item.year}</span>
                <div className="timeline-content">
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="team-section">
        <div className="container">
          <h2 className="section-title">Leadership team</h2>
          <p className="section-subtitle">
            Our leaders cultivate high-performing teams that deliver with integrity, curiosity, and relentless focus on outcomes.
          </p>
          <div className="team-grid">
            {leadershipTeam.map((member) => (
              <article className="team-card" key={member.name}>
                <ImageWithLoader
                  src={member.image}
                  alt={`${member.name}, ${member.role} at NovaEdge Solutions`}
                  wrapperClass="team-image"
                  className="cover-image"
                />
                <div className="team-info">
                  <span className="team-role">{member.role}</span>
                  <h3 className="team-name">{member.name}</h3>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-container">
          <div className="cta-content">
            <h2>Let&apos;s build momentum together</h2>
            <p>
              Whether you&apos;re shaping a new vision or accelerating delivery, NovaEdge Solutions is ready to be your partner.
            </p>
          </div>
          <div className="cta-actions">
            <a className="btn btn-primary btn-large" href="/contact">
              Speak with our team
            </a>
            <a className="btn btn-outline btn-large" href="/services">
              Explore our services
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;