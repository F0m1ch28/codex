import React, { useMemo, useState } from 'react';

const servicesData = [
  {
    id: 'strategy',
    title: 'Strategy & Operating Models',
    summary:
      'We craft actionable strategies and adaptive operating models that align leadership vision, investment, and execution.',
    outcomes: ['Future-state roadmaps', 'Business case modeling', 'Change enablement playbooks'],
    focusAreas: ['Enterprise transformation', 'Portfolio prioritization', 'Capability building']
  },
  {
    id: 'experience',
    title: 'Experience Innovation',
    summary:
      'Human-centered design teams create differentiated products and services that elevate customer and employee experiences.',
    outcomes: ['Product innovation', 'Service design', 'Experience measurement'],
    focusAreas: ['Journey orchestration', 'Experience research', 'Design systems']
  },
  {
    id: 'automation',
    title: 'Automation & Intelligent Operations',
    summary:
      'We unlock operational agility with intelligent automation, AI augmentation, and resilient delivery ecosystems.',
    outcomes: ['Automation strategy', 'Hyper-automation programs', 'Managed services'],
    focusAreas: ['Process intelligence', 'AI-enabled workflows', 'Governance and risk']
  },
  {
    id: 'analytics',
    title: 'Data & Decision Intelligence',
    summary:
      'Modern data platforms, analytics, and decision intelligence that empower your teams with actionable insights.',
    outcomes: ['Data strategy', 'Modern data platforms', 'Advanced analytics'],
    focusAreas: ['Data governance', 'Predictive intelligence', 'Visualization & storytelling']
  }
];

const benefits = [
  {
    title: 'Integrated cross-functional squads',
    description: 'Strategy, design, engineering, and change experts embedded together for rapid, aligned delivery.'
  },
  {
    title: 'Accelerators that reduce time to value',
    description: 'Frameworks, component libraries, and automation assets jumpstart progress from day one.'
  },
  {
    title: 'Coaching and capability uplift',
    description: 'We leave behind playbooks and trained teams who can sustain momentum after the engagement.'
  },
  {
    title: 'Outcome-based governance',
    description: 'Transparent measurement, weekly business reviews, and KPI dashboards ensure accountability.'
  }
];

const useCases = [
  {
    industry: 'Financial Services',
    result: 'Modernized wealth advisory experience, lifting NPS by 34 points.',
    detail: 'Implemented a hybrid service model with advanced analytics and personalized client experiences.'
  },
  {
    industry: 'Healthcare',
    result: 'Introduced AI triage, reducing patient wait times by 26%.',
    detail: 'Designed an omnichannel engagement platform integrating AI, self-service, and clinical operations.'
  },
  {
    industry: 'Manufacturing',
    result: 'Enabled predictive maintenance saving $12M annually.',
    detail: 'Deployed IoT telemetry, automation workflows, and a digital control tower connected across plants.'
  }
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicesData[0].id);
  const selectedService = useMemo(
    () => servicesData.find((service) => service.id === activeService),
    [activeService]
  );

  return (
    <div className="services-page">
      <section className="services-hero">
        <div className="container services-hero-container">
          <span className="hero-badge">Services</span>
          <h1>Solutions designed to accelerate your digital advantage</h1>
          <p>
            NovaEdge Solutions delivers end-to-end transformation—from vision and experience design to architecture,
            automation, and analytics. Engage our teams to solve complex challenges and deliver measurable impact.
          </p>
        </div>
      </section>

      <section className="services-showcase" id="strategy">
        <div className="container services-layout">
          <div className="services-list">
            {servicesData.map((service) => (
              <button
                type="button"
                key={service.id}
                className={`service-item ${activeService === service.id ? 'active' : ''}`}
                onClick={() => setActiveService(service.id)}
              >
                <span>{service.title}</span>
                <span className="service-toggle" aria-hidden="true">
                  →
                </span>
              </button>
            ))}
          </div>
          {selectedService && (
            <div className="service-detail">
              <h2>{selectedService.title}</h2>
              <p>{selectedService.summary}</p>
              <div className="detail-grid">
                <div className="detail-card">
                  <h3>Key Outcomes</h3>
                  <ul>
                    {selectedService.outcomes.map((outcome) => (
                      <li key={outcome}>{outcome}</li>
                    ))}
                  </ul>
                </div>
                <div className="detail-card">
                  <h3>Focus Areas</h3>
                  <ul>
                    {selectedService.focusAreas.map((area) => (
                      <li key={area}>{area}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <a className="btn btn-outline" href="/contact">
                Discuss this capability
              </a>
            </div>
          )}
        </div>
      </section>

      <section className="benefits-section">
        <div className="container">
          <h2 className="section-title">Why organizations choose NovaEdge</h2>
          <p className="section-subtitle">
            We bring a partnership mindset, modern delivery practices, and a relentless focus on outcomes.
          </p>
          <div className="benefits-grid">
            {benefits.map((benefit) => (
              <div className="benefit-card" key={benefit.title}>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="use-case-section">
        <div className="container">
          <h2 className="section-title">Recent client impact</h2>
          <div className="use-case-grid">
            {useCases.map((useCase) => (
              <article className="use-case-card" key={useCase.industry}>
                <span className="use-case-industry">{useCase.industry}</span>
                <h3>{useCase.result}</h3>
                <p>{useCase.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-container">
          <div className="cta-content">
            <h2>Let&apos;s co-create your next breakthrough</h2>
            <p>
              Schedule a working session with our experts to explore opportunities, workshop ideas, and define the path forward.
            </p>
          </div>
          <div className="cta-actions">
            <a className="btn btn-primary btn-large" href="/contact">
              Start the conversation
            </a>
            <a className="btn btn-outline btn-large" href="/about">
              Meet our team
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;