import React, { useState } from 'react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const validationErrors = {};
    if (!formData.name.trim()) {
      validationErrors.name = 'Please enter your name.';
    }
    if (!formData.email.trim()) {
      validationErrors.email = 'Please enter your email.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      validationErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.company.trim()) {
      validationErrors.company = 'Please tell us about your organization.';
    }
    if (!formData.message.trim()) {
      validationErrors.message = 'Please let us know how we can help.';
    }

    return validationErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        company: '',
        message: ''
      });
    }
  };

  return (
    <div className="contact-page">
      <section className="page-hero compact">
        <div className="container page-hero-container">
          <span className="hero-badge">Contact</span>
          <h1>Let&apos;s discuss your next big move</h1>
          <p className="lead">
            Share a few details about your goals and a member of the NovaEdge Solutions team will follow up within one
            business day.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <div className="contact-form-card">
            <h2>Tell us about your initiative</h2>
            <p>We&apos;ll craft a tailored response and schedule time to explore how we can collaborate.</p>
            <form onSubmit={handleSubmit} noValidate>
              <div className="input-group">
                <label htmlFor="name">Full name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Dana Mitchell"
                  aria-invalid={!!errors.name}
                />
                {errors.name && <span className="error-message">{errors.name}</span>}
              </div>

              <div className="input-group">
                <label htmlFor="email">Email address</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="dana@company.com"
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className="error-message">{errors.email}</span>}
              </div>

              <div className="input-group">
                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Company name"
                  aria-invalid={!!errors.company}
                />
                {errors.company && <span className="error-message">{errors.company}</span>}
              </div>

              <div className="input-group">
                <label htmlFor="message">How can we help?</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Share a bit about your goals, challenges, or timeline."
                  aria-invalid={!!errors.message}
                />
                {errors.message && <span className="error-message">{errors.message}</span>}
              </div>

              <button type="submit" className="btn btn-primary btn-large">
                Submit inquiry
              </button>

              {submitted && (
                <div className="success-message" role="status" aria-live="polite">
                  Thank you! We&apos;ll be in touch very soon.
                </div>
              )}
            </form>
          </div>

          <div className="contact-info-card">
            <h2>Connect with us</h2>
            <ul className="contact-details">
              <li>
                <strong>HQ</strong>
                <span>New York, NY</span>
              </li>
              <li>
                <strong>Email</strong>
                <a href="mailto:hello@novaedgesolutions.com">hello@novaedgesolutions.com</a>
              </li>
              <li>
                <strong>Phone</strong>
                <a href="tel:+12125551234">+1 (212) 555-1234</a>
              </li>
              <li>
                <strong>Hours</strong>
                <span>Monday – Friday, 8am – 6pm EST</span>
              </li>
            </ul>

            <div
              className="contact-visual"
              role="img"
              aria-label="NovaEdge Solutions office environment"
              style={{ backgroundImage: 'url(https://picsum.photos/800/600?random=612)' }}
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;