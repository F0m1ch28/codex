import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import ImageWithLoader from '../components/ImageWithLoader';

const statsData = [
  {
    label: 'Digital Transformations',
    value: 128,
    suffix: '+',
    description: 'Enterprise-scale projects delivered'
  },
  {
    label: 'Automation ROI',
    value: 212,
    suffix: '%',
    description: 'Average efficiency improvement'
  },
  {
    label: 'Client Satisfaction',
    value: 98,
    suffix: '%',
    description: 'CSAT from post-engagement surveys'
  },
  {
    label: 'Innovation Labs',
    value: 24,
    suffix: '',
    description: 'Prototype products launched'
  }
];

const serviceHighlights = [
  {
    title: 'Strategy & Advisory',
    description: 'Position your organization for sustainable growth with data-backed strategy and digital roadmaps.',
    icon: '🎯',
    link: '/services#strategy'
  },
  {
    title: 'Customer Platforms',
    description: 'Design omnichannel experiences that drive loyalty and measurable business value.',
    icon: '🌐',
    link: '/services#experience'
  },
  {
    title: 'Automation & AI',
    description: 'Unlock intelligent operations with hyper-automation, AI, and machine learning frameworks.',
    icon: '⚙️',
    link: '/services#automation'
  },
  {
    title: 'Data & Analytics',
    description: 'Transform complex data into actionable insights with modern analytics architectures.',
    icon: '📊',
    link: '/services#analytics'
  }
];

const processSteps = [
  {
    title: 'Discover & Align',
    text: 'We conduct immersive discovery workshops, stakeholder interviews, and data audits to align on desired outcomes.'
  },
  {
    title: 'Design the Future State',
    text: 'Our strategists convert insights into blueprints with detailed roadmaps, success metrics, and experience prototypes.'
  },
  {
    title: 'Orchestrate Delivery',
    text: 'Cross-functional squads implement scalable solutions using agile delivery, quality engineering, and change management.'
  },
  {
    title: 'Empower & Transfer',
    text: 'We equip your teams with training, playbooks, and governance structures to own the solution long-term.'
  },
  {
    title: 'Measure & Optimize',
    text: 'Continuous improvement cycles track KPIs, experiment with innovations, and keep the transformation accelerating.'
  }
];

const testimonials = [
  {
    name: 'Avery Chen',
    role: 'COO, Horizon Ventures',
    quote:
      'NovaEdge guided our global transformation with precision. Their hybrid approach of strategy and execution helped us launch new digital services in record time.',
    avatar: 'https://picsum.photos/80/80?random=41'
  },
  {
    name: 'Jordan Michaels',
    role: 'VP Technology, Northwind Logistics',
    quote:
      'The automation programs delivered by NovaEdge saved us over 2,000 hours per month. Their team operates like an extension of our own.',
    avatar: 'https://picsum.photos/80/80?random=42'
  },
  {
    name: 'Priya Sethi',
    role: 'Chief Innovation Officer, Meridian Health',
    quote:
      'From concept to implementation, NovaEdge accelerated our innovation lab and launched a patient engagement platform that exceeded expectations.',
    avatar: 'https://picsum.photos/80/80?random=43'
  }
];

const teamSpotlight = [
  {
    name: 'Morgan Patel',
    role: 'Principal Strategist',
    description: 'Leads enterprise transformation programs with 15+ years in strategy and change acceleration.',
    image: 'https://picsum.photos/400/400?random=303'
  },
  {
    name: 'Isabella Romero',
    role: 'Director of Experience Design',
    description: 'Combines human-centered design with analytics to craft standout digital products.',
    image: 'https://picsum.photos/400/400?random=304'
  },
  {
    name: 'Theo Laurent',
    role: 'Head of Intelligent Automation',
    description: 'Architects AI-enabled operating models that unlock operational efficiency and new capabilities.',
    image: 'https://picsum.photos/400/400?random=305'
  }
];

const projectPortfolio = [
  {
    title: 'Global Supply Chain Control Tower',
    category: 'Automation',
    description: 'Unified logistics data streams into a predictive operations control tower for real-time decisions.',
    image: 'https://picsum.photos/1200/800?random=401'
  },
  {
    title: 'Healthcare Engagement Platform',
    category: 'Experience',
    description: 'Designed an omnichannel patient experience platform with personalized health journeys.',
    image: 'https://picsum.photos/1200/800?random=402'
  },
  {
    title: 'Wealth Advisory Intelligence',
    category: 'Analytics',
    description: 'Implemented AI-driven insights that empowered advisors with proactive portfolio recommendations.',
    image: 'https://picsum.photos/1200/800?random=403'
  },
  {
    title: 'Smart Manufacturing Hub',
    category: 'Automation',
    description: 'Delivered a smart factory ecosystem with IoT, predictive maintenance, and adaptive workflows.',
    image: 'https://picsum.photos/1200/800?random=404'
  },
  {
    title: 'Digital Onboarding Journey',
    category: 'Experience',
    description: 'Optimized onboarding for a fintech leader, reducing churn by 37% within the first quarter.',
    image: 'https://picsum.photos/1200/800?random=405'
  },
  {
    title: 'Real-Time Risk Analytics',
    category: 'Analytics',
    description: 'Built a modern data platform to detect anomalies and mitigate risk for a global insurer.',
    image: 'https://picsum.photos/1200/800?random=406'
  }
];

const faqItems = [
  {
    question: 'What is your typical engagement model?',
    answer:
      'We start with a discovery phase to align on goals, then assemble a blended team that can support strategy, design, engineering, and change enablement. Engagements are customized across retainers, outcome-based models, or co-delivery squads.'
  },
  {
    question: 'Which industries do you specialize in?',
    answer:
      'Our core experience spans financial services, healthcare, logistics, retail, and manufacturing. We draw on a network of subject matter experts to tailor accelerators for each industry.'
  },
  {
    question: 'How do you ensure measurable impact?',
    answer:
      'Every engagement is anchored in a measurement framework with KPIs, baselines, and tracking dashboards. We use experimentation and continuous improvement practices to sustain and amplify results.'
  },
  {
    question: 'Can you work with our existing technology stack?',
    answer:
      'Absolutely. We integrate with your technology ecosystem and collaborate with internal teams to enhance governance, security, and scalability while modernizing critical components.'
  }
];

const blogPosts = [
  {
    title: 'The 5 Dimensions of Sustainable Digital Transformation',
    date: 'April 2, 2024',
    readTime: '7 min read',
    image: 'https://picsum.photos/600/400?random=501'
  },
  {
    title: 'Beyond Automation: Designing Human + AI Collaboration',
    date: 'March 18, 2024',
    readTime: '6 min read',
    image: 'https://picsum.photos/600/400?random=502'
  },
  {
    title: 'Building a Product Mindset Within the Enterprise',
    date: 'February 28, 2024',
    readTime: '8 min read',
    image: 'https://picsum.photos/600/400?random=503'
  }
];

const Home = () => {
  const navigate = useNavigate();
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [statsInView, setStatsInView] = useState(false);
  const statsRef = useRef(null);
  const [activeFilter, setActiveFilter] = useState('All');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [openFaqIndex, setOpenFaqIndex] = useState(null);

  const categories = useMemo(
    () => ['All', ...new Set(projectPortfolio.map((project) => project.category))],
    []
  );

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setStatsInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsInView) return;

    const duration = 1600;
    let startTime = null;

    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const updated = statsData.map((item) => Math.floor(item.value * progress));
      setCounts(updated);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setCounts(statsData.map((item) => item.value));
      }
    };

    const animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [statsInView]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);

    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeFilter === 'All'
      ? projectPortfolio
      : projectPortfolio.filter((project) => project.category === activeFilter);

  const handleFaqToggle = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  return (
    <div className="home-page">
      <section
        className="hero-section"
        style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=1)' }}
      >
        <div className="hero-overlay" />
        <div className="container hero-container">
          <div className="hero-content">
            <span className="hero-badge">Strategic Digital Partners</span>
            <h1 className="hero-title">
              Build a resilient, intelligent enterprise with NovaEdge Solutions.
            </h1>
            <p className="hero-description">
              We architect transformation programs that connect strategy, experience, and technology. Partner with a
              team that amplifies your capabilities, accelerates delivery, and unlocks measurable impact.
            </p>
            <div className="hero-actions">
              <button type="button" className="btn btn-primary btn-large" onClick={() => navigate('/contact')}>
                Book a Discovery Call
              </button>
              <Link to="/services" className="btn btn-light btn-large">
                Explore Our Services
              </Link>
            </div>
            <div className="hero-meta">
              <div>
                <strong>End-to-end delivery</strong>
                <span>From vision to scale</span>
              </div>
              <div>
                <strong>Trusted by leaders</strong>
                <span>Across five industries</span>
              </div>
            </div>
          </div>
          <div className="hero-statements">
            <div className="hero-card">
              <h3>Transformation Outcomes</h3>
              <p>
                NovaEdge integrates executive strategy, human-centered design, and engineering excellence to deliver
                outcomes that compound over time.
              </p>
              <ul>
                <li>Enterprise agility frameworks</li>
                <li>Data-driven decision ecosystems</li>
                <li>Experience-led innovation</li>
              </ul>
            </div>
          </div>
        </div>
        <button
          type="button"
          className="scroll-indicator"
          onClick={() => document.getElementById('stats-section').scrollIntoView({ behavior: 'smooth' })}
        >
          Scroll for more
        </button>
      </section>

      <section className="stats-section" id="stats-section" ref={statsRef}>
        <div className="container stats-container">
          {statsData.map((item, index) => (
            <div className="stat-card" key={item.label}>
              <p className="stat-value">
                {counts[index]}
                {item.suffix}
              </p>
              <p className="stat-label">{item.label}</p>
              <p className="stat-description">{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="services-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Expertise that powers your transformation journey</h2>
            <p className="section-subtitle">
              Our integrated squads blend strategy, experience design, engineering, and analytics to deliver solutions
              that scale across your organization.
            </p>
          </div>
          <div className="services-grid">
            {serviceHighlights.map((service) => (
              <article className="service-card" key={service.title}>
                <span className="service-icon" aria-hidden="true">{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to={service.link} className="service-link">
                  Learn more
                </Link>
              </article>
            ))}
          </div>
          <div className="section-footer">
            <Link to="/services" className="btn btn-outline">
              View the full service catalog
            </Link>
          </div>
        </div>
      </section>

      <section className="process-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Our proven path to sustainable transformation</h2>
            <p className="section-subtitle">
              Every engagement is tailored and iterative, yet anchored in a delivery framework that consistently
              generates measurable results.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title}>
                <span className="process-index">0{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="projects-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Featured programs and portfolio highlights</h2>
            <p className="section-subtitle">
              Explore how NovaEdge Solutions helps clients modernize, innovate, and lead with confidence.
            </p>
          </div>
          <div className="project-filter" role="tablist" aria-label="Project categories">
            {categories.map((category) => (
              <button
                type="button"
                key={category}
                className={`filter-button ${activeFilter === category ? 'active' : ''}`}
                onClick={() => setActiveFilter(category)}
                role="tab"
                aria-selected={activeFilter === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title}>
                <ImageWithLoader
                  src={project.image}
                  alt={`${project.title} by NovaEdge Solutions`}
                  wrapperClass="project-image"
                  className="cover-image"
                />
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/contact" className="project-link">
                    See how we can help
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials-section">
        <div className="container testimonial-container">
          <div className="section-header">
            <h2 className="section-title">Leaders trust NovaEdge to unlock transformation</h2>
            <p className="section-subtitle">
              Hear from clients who partnered with us to architect strategies, modernize capabilities, and deliver
              breakthrough experiences.
            </p>
          </div>
          <div className="testimonial-wrapper">
            {testimonials.map((testimonial, index) => (
              <article
                className={`testimonial-card ${index === currentTestimonial ? 'active' : ''}`}
                key={testimonial.name}
                aria-hidden={index !== currentTestimonial}
              >
                <div className="testimonial-quote">“{testimonial.quote}”</div>
                <div className="testimonial-author">
                  <ImageWithLoader
                    src={testimonial.avatar}
                    alt={`${testimonial.name} portrait`}
                    wrapperClass="testimonial-avatar"
                    className="avatar-image"
                  />
                  <div>
                    <p className="author-name">{testimonial.name}</p>
                    <p className="author-role">{testimonial.role}</p>
                  </div>
                </div>
              </article>
            ))}
          </div>
          <div className="testimonial-controls" role="tablist" aria-label="Testimonials">
            {testimonials.map((_, index) => (
              <button
                type="button"
                key={_.name}
                className={`testimonial-dot ${index === currentTestimonial ? 'active' : ''}`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="team-preview">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Meet the leaders powering your success</h2>
            <p className="section-subtitle">
              NovaEdge Solutions brings together strategists, technologists, designers, and change experts who operate
              as one team around your goals.
            </p>
          </div>
          <div className="team-grid">
            {teamSpotlight.map((member) => (
              <article className="team-card" key={member.name}>
                <ImageWithLoader
                  src={member.image}
                  alt={`${member.name}, ${member.role} at NovaEdge Solutions`}
                  wrapperClass="team-image"
                  className="cover-image"
                />
                <div className="team-info">
                  <span className="team-role">{member.role}</span>
                  <h3 className="team-name">{member.name}</h3>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
          <div className="section-footer">
            <Link to="/about" className="btn btn-outline">
              Explore our culture & team
            </Link>
          </div>
        </div>
      </section>

      <section className="faq-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Frequently asked questions</h2>
            <p className="section-subtitle">
              Find quick answers about how NovaEdge Solutions collaborates, delivers, and creates momentum for your
              organization.
            </p>
          </div>
          <div className="faq-accordion">
            {faqItems.map((item, index) => (
              <div className={`faq-item ${openFaqIndex === index ? 'open' : ''}`} key={item.question}>
                <button
                  className="faq-question"
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={openFaqIndex === index}
                >
                  {item.question}
                  <span className="faq-toggle" aria-hidden="true">
                    {openFaqIndex === index ? '−' : '+'}
                  </span>
                </button>
                <div className="faq-answer">
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Ideas shaping the future of business</h2>
            <p className="section-subtitle">
              Stay ahead with research-backed insights, playbooks, and perspectives from NovaEdge leaders.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <ImageWithLoader
                  src={post.image}
                  alt={`${post.title} cover`}
                  wrapperClass="blog-image"
                  className="cover-image"
                />
                <div className="blog-content">
                  <div className="blog-meta">
                    <span>{post.date}</span>
                    <span>{post.readTime}</span>
                  </div>
                  <h3>{post.title}</h3>
                  <p>
                    Discover practical strategies, frameworks, and insights to accelerate transformation inside your
                    organization.
                  </p>
                  <Link to="/contact" className="blog-link">
                    Discuss this insight
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-container">
          <div className="cta-content">
            <h2>Ready to architect what&apos;s next for your business?</h2>
            <p>
              Bring NovaEdge Solutions into the conversation and we&apos;ll co-create a roadmap to unlock advantage,
              resilience, and measurable growth.
            </p>
          </div>
          <div className="cta-actions">
            <button type="button" className="btn btn-light btn-large" onClick={() => navigate('/contact')}>
              Schedule a Strategy Session
            </button>
            <Link to="/about" className="btn btn-outline btn-large">
              Learn about our culture
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;