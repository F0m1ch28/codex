import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="container footer-container">
        <div className="footer-column wide">
          <h3 className="footer-title">NovaEdge Solutions</h3>
          <p className="footer-text">
            We are a strategic consultancy that combines technology, creativity, and operational excellence to build
            resilient digital enterprises.
          </p>
          <div className="footer-socials" aria-label="Social media links">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer">
              X
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>

        <div className="footer-column">
          <h4 className="footer-heading">Company</h4>
          <ul className="footer-links">
            <li><Link to="/about">About</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/contact">Contact</Link></li>
            <li><Link to="/privacy">Privacy Policy</Link></li>
            <li><Link to="/terms">Terms of Use</Link></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4 className="footer-heading">Solutions</h4>
          <ul className="footer-links">
            <li><Link to="/services#strategy">Digital Strategy</Link></li>
            <li><Link to="/services#innovation">Innovation Labs</Link></li>
            <li><Link to="/services#automation">Intelligent Automation</Link></li>
            <li><Link to="/services#analytics">Advanced Analytics</Link></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4 className="footer-heading">Stay in the loop</h4>
          <p className="footer-text">Subscribe for insights on digital transformation and emerging technologies.</p>
          <form className="footer-form">
            <label htmlFor="footer-email" className="visually-hidden">Email address</label>
            <input id="footer-email" type="email" placeholder="you@company.com" required />
            <button type="submit" className="btn btn-primary btn-small">Subscribe</button>
          </form>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container footer-bottom-container">
          <p>© {year} NovaEdge Solutions. All rights reserved.</p>
          <div className="footer-bottom-links">
            <Link to="/privacy">Privacy</Link>
            <Link to="/terms">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;