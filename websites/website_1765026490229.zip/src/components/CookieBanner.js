import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const showBanner = () => {
      if (typeof window === 'undefined') return;
      const consent = window.localStorage.getItem('novaedge_cookie_consent');
      if (!consent) {
        const timer = setTimeout(() => setVisible(true), 1200);
        return () => clearTimeout(timer);
      }
      return () => {};
    };

    const cleanup = showBanner();
    return () => {
      if (cleanup) cleanup();
    };
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('novaedge_cookie_consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem('novaedge_cookie_consent', 'declined');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent">
      <div className="cookie-content">
        <h4>We value your privacy</h4>
        <p>
          We use cookies to personalize content, enhance site navigation, and analyze our traffic. You can accept or
          decline at any time.
        </p>
      </div>
      <div className="cookie-actions">
        <button type="button" className="btn btn-outline btn-small" onClick={handleDecline}>
          Decline
        </button>
        <button type="button" className="btn btn-primary btn-small" onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;