import React, { useState } from 'react';

const ImageWithLoader = ({ src, alt, className = '', wrapperClass = '' }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`image-loader ${wrapperClass} ${loaded ? 'image-loaded' : 'image-loading'}`}>
      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        className={className}
      />
    </div>
  );
};

export default ImageWithLoader;