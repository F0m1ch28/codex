import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

function Services() {
  return (
    <>
      <Helmet>
        <title>Services | TechSolutions Cloud Consulting & Digital Transformation</title>
        <meta
          name="description"
          content="Discover TechSolutions services including cloud strategy, migration, modernization, security governance, analytics, and managed cloud operations."
        />
      </Helmet>
      <section className={styles.header}>
        <div className="layout">
          <h1>Services tailored to your transformation journey</h1>
          <p>
            TechSolutions provides comprehensive consulting, implementation, and enablement services that evolve with your organization’s needs. Our experts blend strategy, engineering, and change management to accelerate adoption at scale.
          </p>
        </div>
      </section>

      <section className={styles.cardsSection}>
        <div className="layout">
          <div className={styles.grid}>
            <article className={styles.card}>
              <h2>Cloud Strategy & Assessment</h2>
              <p>
                Gain clarity on where to start and how to scale. We assess current-state architectures, build value-driven roadmaps, and prioritize use cases that deliver measurable results.
              </p>
              <ul>
                <li>Cloud readiness and TCO analysis</li>
                <li>Target operating model design</li>
                <li>Migration sequencing and governance</li>
              </ul>
              <img
                src="https://picsum.photos/seed/assessment/600/400"
                alt="Consultants building a cloud strategy roadmap"
              />
            </article>

            <article className={styles.card}>
              <h2>Platform Engineering & Modernization</h2>
              <p>
                Evolve your platforms with modern architectures, automation, and DevOps practices. We modernize legacy workloads and build CI/CD pipelines that deliver consistent releases.
              </p>
              <ul>
                <li>Microservices and container adoption</li>
                <li>Infrastructure as code implementation</li>
                <li>DevSecOps toolchain integration</li>
              </ul>
              <img
                src="https://picsum.photos/seed/platform/600/400"
                alt="Engineers working on modern cloud platform infrastructure"
              />
            </article>

            <article className={styles.card}>
              <h2>Data, Analytics & AI</h2>
              <p>
                Unlock insights and automation with cloud-native data platforms. We design secure data pipelines, deploy analytics tools, and enable advanced AI capabilities.
              </p>
              <ul>
                <li>Data lake and warehouse architectures</li>
                <li>BI modernization and visualization</li>
                <li>Machine learning model deployment</li>
              </ul>
              <img
                src="https://picsum.photos/seed/data-ai/600/400"
                alt="Data specialists reviewing analytics dashboard"
              />
            </article>

            <article className={styles.card}>
              <h2>Cloud Security & Compliance</h2>
              <p>
                Protect your digital estate with comprehensive security frameworks. We establish policies, implement controls, and monitor continuously to ensure compliance requirements are met.
              </p>
              <ul>
                <li>Identity and access management</li>
                <li>Cloud-native security posture management</li>
                <li>Regulatory compliance automation</li>
              </ul>
              <img
                src="https://picsum.photos/seed/security/600/400"
                alt="Security professionals evaluating cloud compliance"
              />
            </article>

            <article className={styles.card}>
              <h2>Managed Cloud Operations</h2>
              <p>
                Maintain reliability, cost efficiency, and continuous improvement with our managed services. We offer proactive monitoring, incident response, and optimization programs.
              </p>
              <ul>
                <li>24/7 monitoring and observability</li>
                <li>FinOps cost governance</li>
                <li>Continuous improvement sprints</li>
              </ul>
              <img
                src="https://picsum.photos/seed/managed/600/400"
                alt="Team managing cloud operations in a control center"
              />
            </article>

            <article className={styles.card}>
              <h2>Change Management & Enablement</h2>
              <p>
                Empower your teams with the skills, processes, and cultural shifts required for sustainable transformation through targeted training and change programs.
              </p>
              <ul>
                <li>Digital adoption frameworks</li>
                <li>Role-based enablement plans</li>
                <li>Executive and stakeholder coaching</li>
              </ul>
              <img
                src="https://picsum.photos/seed/change/600/400"
                alt="Team participating in a transformation workshop"
              />
            </article>
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;