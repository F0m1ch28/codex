document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      siteNav.classList.toggle("open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("open")) {
          siteNav.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  document.querySelectorAll(".reveal").forEach((element) => {
    observer.observe(element);
  });

  const toast = document.querySelector(".toast");
  let toastTimer = null;

  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    if (toastTimer) {
      clearTimeout(toastTimer);
    }
    toastTimer = setTimeout(() => {
      toast.classList.remove("show");
    }, 2400);
  };

  const forms = document.querySelectorAll('form[data-redirect="thank-you"]');
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Message queued for review.");
      setTimeout(() => {
        window.location.href = form.getAttribute("action");
      }, 1200);
    });
  });

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("dts-cookie-choice");
    if (!storedChoice) {
      cookieBanner.classList.add("show");
    }
    cookieBanner
      .querySelectorAll("[data-cookie]")
      .forEach((button) => {
        button.addEventListener("click", () => {
          const choice = button.dataset.cookie === "accept" ? "accepted" : "declined";
          localStorage.setItem("dts-cookie-choice", choice);
          cookieBanner.classList.remove("show");
          showToast(`Cookie preference ${choice}.`);
        });
      });
  }
});