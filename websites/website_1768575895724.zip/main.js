document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector("[data-nav-toggle]");
    const navMenu = document.querySelector("[data-nav-menu]");
    const navLinks = document.querySelectorAll("[data-nav-menu] a");
    const cookieBanner = document.querySelector("[data-cookie-banner]");
    const acceptButton = document.querySelector("[data-cookie-accept]");
    const declineButton = document.querySelector("[data-cookie-decline]");
    const consentKey = "ovismuopsoCookieConsent";

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navToggle.classList.toggle("is-active");
            navMenu.classList.toggle("is-open");
            document.body.classList.toggle("nav-open");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute("aria-expanded", "false");
                    navToggle.classList.remove("is-active");
                    navMenu.classList.remove("is-open");
                    document.body.classList.remove("nav-open");
                }
            });
        });
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.add("is-visible");
        }

        const handleConsent = (choice) => {
            localStorage.setItem(consentKey, choice);
            cookieBanner.classList.remove("is-visible");
        };

        if (acceptButton) {
            acceptButton.addEventListener("click", () => handleConsent("accepted"));
        }

        if (declineButton) {
            declineButton.addEventListener("click", () => handleConsent("declined"));
        }
    }
});