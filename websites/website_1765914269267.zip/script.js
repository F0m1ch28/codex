const consentKey = "cookieConsent";
const scoresKey = "gameScores";

document.addEventListener("DOMContentLoaded", () => {
  setupNav();
  setupCookieBanner();
  setupFaq();
  if (document.body.dataset.page === "game") {
    setupGame();
  }
  if (document.body.dataset.page === "leaderboard") {
    renderLeaderboard();
  }
});

function setupNav() {
  const toggle = document.querySelector(".main-nav-toggle");
  const nav = document.querySelector(".main-nav");
  const navLinks = document.querySelectorAll(".nav-link");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      nav.classList.toggle("is-open");
    });
  }
  const currentPage = document.body.dataset.page;
  navLinks.forEach((link) => {
    if (link.dataset.nav === currentPage) {
      link.classList.add("active");
      link.setAttribute("aria-current", "page");
    }
  });
  window.addEventListener("resize", () => {
    if (nav && window.innerWidth >= 768) {
      nav.classList.remove("is-open");
    }
  });
}

function setupCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  if (!banner || !acceptBtn || !declineBtn) {
    return;
  }
  const consent = getConsentState();
  if (!consent) {
    banner.classList.remove("hidden");
  }
  acceptBtn.addEventListener("click", () => {
    localStorage.setItem(consentKey, "accepted");
    banner.classList.add("hidden");
    document.dispatchEvent(
      new CustomEvent("cookieConsentChanged", { detail: "accepted" })
    );
  });
  declineBtn.addEventListener("click", () => {
    localStorage.setItem(consentKey, "declined");
    banner.classList.add("hidden");
    document.dispatchEvent(
      new CustomEvent("cookieConsentChanged", { detail: "declined" })
    );
  });
}

function getConsentState() {
  try {
    return localStorage.getItem(consentKey);
  } catch (error) {
    return null;
  }
}

function setupFaq() {
  const faqItems = document.querySelectorAll(".faq-item");
  faqItems.forEach((item) => {
    const button = item.querySelector(".faq-question");
    if (!button) {
      return;
    }
    button.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");
      faqItems.forEach((entry) => entry.classList.remove("open"));
      if (!isOpen) {
        item.classList.add("open");
      }
    });
  });
}

function setupGame() {
  const startButton = document.getElementById("game-start");
  const nextButton = document.getElementById("game-next");
  const timerElement = document.getElementById("game-timer");
  const questionElement = document.getElementById("game-question");
  const optionsContainer = document.getElementById("game-options");
  const progressElement = document.getElementById("game-progress");
  const scoreElement = document.getElementById("game-score");
  const statusElement = document.getElementById("game-status-message");
  const feedbackElement = document.getElementById("game-feedback");
  const tipElement = document.getElementById("game-tip");
  const form = document.getElementById("score-form");
  const nameInput = document.getElementById("player-name");
  const scoreStatus = document.getElementById("score-status");
  const recentScoresList = document.getElementById("recent-scores");

  if (
    !startButton ||
    !nextButton ||
    !timerElement ||
    !questionElement ||
    !optionsContainer ||
    !progressElement ||
    !scoreElement ||
    !statusElement ||
    !feedbackElement ||
    !tipElement ||
    !form ||
    !nameInput ||
    !scoreStatus ||
    !recentScoresList
  ) {
    return;
  }

  const gameQuestions = [
    {
      query: "Какой формат промо-карточки лучше привлечёт внимание к новой подписке Яндекс Плюс?",
      options: [
        "Анимированная обложка с подсказкой преимуществ",
        "Текстовый баннер без визуальных элементов",
        "Темный экран с минималистичной кнопкой",
        "Случайный набор изображений из галереи"
      ],
      correct: 0,
      insight: "Яркая анимация и конкретная выгода увеличивают CTR в интерфейсах Яндекса."
    },
    {
      query: "Что повысит удержание в мини-игре внутри Яндекс.Браузера?",
      options: [
        "Скрыть прогресс и сделать игру бесконечной",
        "Добавить тактильные подсказки и динамические уровни",
        "Отключить награды и статистику",
        "Увеличить время ожидания между ходами"
      ],
      correct: 1,
      insight: "Игроки возвращаются, когда видят прогресс и чувствуют рост сложности."
    },
    {
      query: "Какой сценарий onboarding выбрать для новой фичи в Яндекс.Музыке?",
      options: [
        "Одно длинное письмо с инструкциями",
        "Короткий интерактив с персональными подсказками",
        "Видео на 20 минут в отдельной вкладке",
        "Игнорировать объяснение и ждать вопросов"
      ],
      correct: 1,
      insight: "Персональные подсказки в контексте повышают активацию пользователей."
    },
    {
      query: "Как лучше мотивировать игрока поделиться результатом уровня?",
      options: [
        "Показать социальное доказательство и редкий бейдж",
        "Попросить поделиться перед экраном окончания",
        "Отправить автоматическое уведомление без разрешения",
        "Спрятать кнопку поделиться глубоко в меню"
      ],
      correct: 0,
      insight: "Редкие награды и видимость других игроков усиливают желание делиться."
    },
    {
      query: "Оптимальный способ подсветить новый ивент в ленте Яндекс Игр?",
      options: [
        "Добавить промо в выдачу запросов по теме",
        "Оставить событие без меток и карточек",
        "Разместить ивент внизу без уведомлений",
        "Запретить упоминания в пуш-рассылках"
      ],
      correct: 0,
      insight: "Промо в выдаче и релевантные запросы ускоряют старт вовлечения."
    },
    {
      query: "Какое ограничение времени на ход поддерживает драйв в казуальной игре?",
      options: [
        "Таймер на 30 секунд с визуальной шкалой",
        "Полное отсутствие таймера",
        "Таймер на 5 минут без визуала",
        "Случайный таймер от 1 до 120 секунд"
      ],
      correct: 0,
      insight: "Чёткий таймер с визуальной обратной связью держит темп и азарт."
    },
    {
      query: "Что поможет снизить отток на экране поражения?",
      options: [
        "Предложить альтернативный маршрут и подсказку",
        "Сразу закрыть игру без вариантов",
        "Наказать игрока уменьшением очков",
        "Оставить экран пустым"
      ],
      correct: 0,
      insight: "Второй шанс и совет по улучшению растят возврат и вовлечённость."
    },
    {
      query: "Как визуально оформить лидыборд, чтобы мотивировать возвращаться?",
      options: [
        "Выделить топ игроков и личный прогресс пользователя",
        "Скрыть имена и результаты",
        "Сделать таблицу монотонной без акцентов",
        "Не обновлять рейтинг после игры"
      ],
      correct: 0,
      insight: "Персонализация рейтинга создает ощущение движения и цели."
    }
  ];

  let roundScore = 0;
  let totalQuestions = 0;
  let timeLeft = 60;
  let timerId = null;
  let availableQuestions = [];
  let currentQuestion = null;

  startButton.addEventListener("click", startGame);
  nextButton.addEventListener("click", () => {
    showNextQuestion();
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const consent = getConsentState();
    if (consent !== "accepted") {
      scoreStatus.textContent =
        "Чтобы сохранить результат и попасть в рейтинг, примите использование файлов cookie.";
      return;
    }
    if (roundScore <= 0) {
      scoreStatus.textContent = "Сначала сыграйте раунд и наберите очки.";
      return;
    }
    const playerName = nameInput.value.trim();
    if (!playerName) {
      scoreStatus.textContent = "Пожалуйста, укажите имя.";
      return;
    }
    saveScore(playerName, roundScore);
    nameInput.value = "";
    scoreStatus.textContent = "Результат сохранён! Обновите лидерборд, чтобы увидеть себя в рейтинге.";
    renderRecentScores();
  });

  document.addEventListener("cookieConsentChanged", () => {
    updateScoreFormAvailability();
    renderRecentScores();
  });

  updateScoreFormAvailability();
  renderRecentScores();
  resetGameState();

  function startGame() {
    resetGameState();
    availableQuestions = shuffleArray([...gameQuestions]);
    totalQuestions = availableQuestions.length;
    startButton.disabled = true;
    nextButton.disabled = true;
    timerElement.textContent = String(timeLeft);
    scoreElement.textContent = String(roundScore);
    statusElement.textContent = "Раунд начался! Успейте ответить на максимум сценариев.";
    feedbackElement.textContent = "";
    tipElement.textContent = "";
    runTimer();
    showNextQuestion();
  }

  function resetGameState() {
    clearInterval(timerId);
    roundScore = 0;
    timeLeft = 60;
    totalQuestions = gameQuestions.length;
    timerElement.textContent = "60";
    scoreElement.textContent = "0";
    progressElement.textContent = `0 / ${totalQuestions}`;
    statusElement.textContent = "Нажмите «Старт», чтобы начать раунд.";
    feedbackElement.textContent = "";
    tipElement.textContent = "";
    optionsContainer.innerHTML = "";
    startButton.disabled = false;
    nextButton.disabled = true;
  }

  function runTimer() {
    clearInterval(timerId);
    timerId = setInterval(() => {
      timeLeft -= 1;
      timerElement.textContent = String(timeLeft);
      if (timeLeft <= 0) {
        endGame("Время вышло! Попробуйте улучшить результат.");
      }
    }, 1000);
  }

  function showNextQuestion() {
    if (availableQuestions.length === 0) {
      endGame("Раунд завершён! Отличная работа.");
      return;
    }
    currentQuestion = availableQuestions.shift();
    renderQuestion(currentQuestion);
    const answered = totalQuestions - availableQuestions.length - 1;
    progressElement.textContent = `${answered + 1} / ${totalQuestions}`;
    statusElement.textContent = "Выберите лучший сценарий для интерфейса.";
    feedbackElement.textContent = "";
    tipElement.textContent = "";
    nextButton.disabled = true;
  }

  function renderQuestion(question) {
    questionElement.textContent = question.query;
    optionsContainer.innerHTML = "";
    question.options.forEach((option, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "game-option";
      button.textContent = option;
      button.dataset.index = String(index);
      button.addEventListener("click", () => handleAnswer(index, button));
      optionsContainer.appendChild(button);
    });
  }

  function handleAnswer(optionIndex, button) {
    const options = optionsContainer.querySelectorAll(".game-option");
    options.forEach((option) => {
      option.disabled = true;
    });
    if (optionIndex === currentQuestion.correct) {
      button.classList.add("correct");
      feedbackElement.textContent = "Верно! Такой сценарий усилит метрики.";
      roundScore += 15;
    } else {
      button.classList.add("incorrect");
      const correctOption = optionsContainer.querySelector(
        `.game-option[data-index="${currentQuestion.correct}"]`
      );
      if (correctOption) {
        correctOption.classList.add("correct");
      }
      feedbackElement.textContent = "Есть более точное решение. Изучите подсказку и попробуйте снова.";
      if (roundScore > 0) {
        roundScore -= 5;
      }
    }
    scoreElement.textContent = String(roundScore);
    tipElement.textContent = currentQuestion.insight;
    nextButton.disabled = false;
  }

  function endGame(message) {
    clearInterval(timerId);
    nextButton.disabled = true;
    startButton.disabled = false;
    statusElement.textContent = message;
    feedbackElement.textContent = `Итоговый счёт: ${roundScore} баллов.`;
  }

  function renderRecentScores() {
    const consent = getConsentState();
    recentScoresList.innerHTML = "";
    if (consent !== "accepted") {
      const li = document.createElement("li");
      li.textContent = "Разрешите cookie, чтобы видеть историю результатов.";
      recentScoresList.appendChild(li);
      return;
    }
    const scores = getStoredScores();
    if (!scores.length) {
      const li = document.createElement("li");
      li.textContent = "Здесь появятся последние результаты — сыграйте и сохраните прогресс.";
      recentScoresList.appendChild(li);
      return;
    }
    scores.slice(0, 5).forEach((entry, index) => {
      const li = document.createElement("li");
      li.textContent = `${index + 1}. ${entry.name} — ${entry.score} очков (${formatDate(entry.date)})`;
      recentScoresList.appendChild(li);
    });
  }

  function updateScoreFormAvailability() {
    const consent = getConsentState();
    if (consent === "accepted") {
      scoreStatus.textContent = "Сыграйте раунд и сохраните результат, чтобы попасть в таблицу лидеров.";
      form.querySelectorAll("input, button").forEach((element) => {
        element.disabled = false;
      });
    } else {
      scoreStatus.textContent = "Для сохранения результатов и попадания в рейтинг требуется принять использование cookie.";
      form.querySelectorAll("input, button").forEach((element) => {
        if (element !== form.querySelector("button.button-secondary")) {
          element.disabled = true;
        }
      });
    }
  }
}

function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function saveScore(name, score) {
  const currentScores = getStoredScores();
  const newEntry = {
    name,
    score,
    date: new Date().toISOString()
  };
  currentScores.push(newEntry);
  currentScores.sort((a, b) => b.score - a.score);
  const trimmed = currentScores.slice(0, 50);
  try {
    localStorage.setItem(scoresKey, JSON.stringify(trimmed));
  } catch (error) {
    console.error("Не удалось сохранить результат:", error);
  }
}

function getStoredScores() {
  try {
    const raw = localStorage.getItem(scoresKey);
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return [];
    }
    return parsed;
  } catch (error) {
    return [];
  }
}

function renderLeaderboard() {
  const body = document.getElementById("leaderboard-body");
  const emptyState = document.getElementById("leaderboard-empty");
  if (!body || !emptyState) {
    return;
  }
  const consent = getConsentState();
  body.innerHTML = "";
  if (consent !== "accepted") {
    emptyState.textContent =
      "Примите использование cookie, чтобы видеть таблицу лидеров. Мы не сможем показать рейтинг без вашего согласия.";
    return;
  }
  const scores = getStoredScores();
  if (!scores.length) {
    emptyState.textContent = "Рейтинг пока пуст. Сыграйте и станьте первым в таблице лидеров!";
    return;
  }
  emptyState.textContent = "";
  scores.forEach((entry, index) => {
    const row = document.createElement("tr");
    const positionCell = document.createElement("td");
    positionCell.textContent = `${index + 1}`;
    const nameCell = document.createElement("td");
    nameCell.textContent = entry.name;
    const scoreCell = document.createElement("td");
    scoreCell.textContent = `${entry.score}`;
    const dateCell = document.createElement("td");
    dateCell.textContent = formatDate(entry.date);
    row.append(positionCell, nameCell, scoreCell, dateCell);
    body.appendChild(row);
  });
}

function formatDate(value) {
  try {
    const date = new Date(value);
    return date.toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (error) {
    return "";
  }
}