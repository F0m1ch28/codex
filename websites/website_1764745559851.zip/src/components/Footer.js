import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer__container">
        <div className="footer__brand">
          <h3>Elevate Nexus Consulting</h3>
          <p>
            We partner with visionary teams to design strategy, align operations, and accelerate
            sustainable growth across industries.
          </p>
          <a className="footer__cta" href="mailto:hello@elevatenexus.com">
            hello@elevatenexus.com
          </a>
        </div>
        <div className="footer__column">
          <h4>Company</h4>
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link to="/contact">Contact</Link>
        </div>
        <div className="footer__column">
          <h4>Resources</h4>
          <a href="#blog" className="footer__link--anchor">
            Insights
          </a>
          <a href="#faq" className="footer__link--anchor">
            FAQs
          </a>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noreferrer"
            className="footer__external"
          >
            LinkedIn
          </a>
          <a
            href="https://www.twitter.com"
            target="_blank"
            rel="noreferrer"
            className="footer__external"
          >
            Twitter/X
          </a>
        </div>
        <div className="footer__column">
          <h4>Legal</h4>
          <Link to="/privacy">Privacy Policy</Link>
          <Link to="/terms">Terms &amp; Conditions</Link>
        </div>
      </div>
      <div className="footer__bottom">
        <p>© {new Date().getFullYear()} Elevate Nexus Consulting. All rights reserved.</p>
        <div className="footer__credits">
          <span>Designed for excellence.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;