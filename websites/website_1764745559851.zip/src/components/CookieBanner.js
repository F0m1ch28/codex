import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('enc-cookie-consent');
    if (!consent) {
      const timeout = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timeout);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('enc-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="region" aria-label="Cookie consent banner">
      <div className="cookie-banner__content">
        <h4>We respect your privacy</h4>
        <p>
          We utilize cookies to personalize experiences, analyze site traffic, and improve our
          services. You can withdraw your consent at any time.
        </p>
        <div className="cookie-banner__actions">
          <button className="btn btn--ghost" onClick={() => setVisible(false)}>
            Decline
          </button>
          <button className="btn btn--primary" onClick={acceptCookies}>
            Accept Cookies
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;