import React, { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`site-header ${scrolled ? 'site-header--scrolled' : ''}`}>
      <div className="container header__container">
        <Link to="/" className="header__brand" onClick={closeMenu}>
          <span className="header__logo">Elevate Nexus</span>
          <span className="header__tagline">Consulting Group</span>
        </Link>
        <nav className={`header__nav ${isMenuOpen ? 'header__nav--open' : ''}`}>
          <NavLink to="/" className="header__link" onClick={closeMenu} end>
            Home
          </NavLink>
          <NavLink to="/about" className="header__link" onClick={closeMenu}>
            About
          </NavLink>
          <NavLink to="/services" className="header__link" onClick={closeMenu}>
            Services
          </NavLink>
          <NavLink to="/contact" className="header__link" onClick={closeMenu}>
            Contact
          </NavLink>
        </nav>
        <div className="header__cta">
          <Link to="/contact" className="btn btn--primary btn--sm">
            Book Consultation
          </Link>
        </div>
        <button
          className={`header__burger ${isMenuOpen ? 'header__burger--active' : ''}`}
          onClick={toggleMenu}
          aria-label="Toggle navigation menu"
          aria-expanded={isMenuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;