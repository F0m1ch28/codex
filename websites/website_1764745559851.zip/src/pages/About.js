import React from 'react';
import { Link } from 'react-router-dom';

const About = () => {
  const pillars = [
    {
      title: 'Strategic Clarity',
      description:
        'We translate ambition into actionable transformation programs with clear milestones and accountability.',
    },
    {
      title: 'Operational Excellence',
      description:
        'From process redesign to enablement, we build systems that help teams collaborate seamlessly.',
    },
    {
      title: 'Human-Centered Change',
      description:
        'Sustainable change relies on engaged people. We equip your leaders and teams with narratives, rituals, and tools.',
    },
  ];

  const teamValues = [
    {
      title: 'Integrity in action',
      detail: 'We deliver honest assessments, transparent recommendations, and unbiased insights.',
    },
    {
      title: 'Curiosity and rigor',
      detail: 'We pair curiosity with disciplined analysis to navigate complexity confidently.',
    },
    {
      title: 'Momentum with care',
      detail: 'We move fast while honoring the cultures that make every organization unique.',
    },
  ];

  return (
    <div className="about">
      <section className="page-hero">
        <div className="container page-hero__container">
          <div className="page-hero__content">
            <p className="section__eyebrow">About Elevate Nexus</p>
            <h1>We align strategy, operations, and people to create durable growth.</h1>
            <p>
              Founded by seasoned consultants and operators, Elevate Nexus exists to help ambitious
              teams tackle their toughest transformation challenges with clarity and confidence. We
              blend research-backed frameworks with hands-on execution support.
            </p>
          </div>
          <div className="page-hero__image">
            <img src="https://picsum.photos/800/600?random=62" alt="Consultants collaborating during workshop" />
          </div>
        </div>
      </section>

      <section className="pillars">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">Our pillars</p>
            <h2>The foundations of our consulting practice.</h2>
          </div>
        </div>
        <div className="container pillars__grid">
          {pillars.map((pillar) => (
            <div className="pillar-card" key={pillar.title}>
              <h3>{pillar.title}</h3>
              <p>{pillar.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="values">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">Our values</p>
            <h2>Principles that guide every engagement.</h2>
          </div>
        </div>
        <div className="container values__grid">
          {teamValues.map((value) => (
            <div className="value-card" key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.detail}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="page-cta">
        <div className="container page-cta__container">
          <h2>Partner with leaders who understand your ambition.</h2>
          <p>
            Whether you are launching a new market, re-engineering operations, or enabling a high-performing
            culture, we’re ready to collaborate.
          </p>
          <div className="page-cta__actions">
            <Link to="/contact" className="btn btn--primary btn--lg">
              Speak with our team
            </Link>
            <Link to="/services" className="btn btn--ghost btn--lg">
              View services
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;