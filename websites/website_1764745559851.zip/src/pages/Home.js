import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  const stats = useMemo(
    () => [
      { value: 12, suffix: '+', label: 'Years of strategic excellence' },
      { value: 160, suffix: '+', label: 'Growth programs launched' },
      { value: 98, suffix: '%', label: 'Client satisfaction score' },
      { value: 24, suffix: '', label: 'Global partners across sectors' },
    ],
    []
  );

  const [statValues, setStatValues] = useState(stats.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const statsRef = useRef(null);

  useEffect(() => {
    if (!statsRef.current) {
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsAnimated) {
            setStatsAnimated(true);
          }
        });
      },
      { threshold: 0.35 }
    );

    observer.observe(statsRef.current);
    return () => observer.disconnect();
  }, [statsAnimated]);

  useEffect(() => {
    if (!statsAnimated) return;
    const duration = 1800;
    const start = performance.now();

    const animationFrame = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      const newValues = stats.map((stat) => Math.floor(stat.value * progress));
      setStatValues(newValues);
      if (progress < 1) {
        requestAnimationFrame(animationFrame);
      } else {
        setStatValues(stats.map((stat) => stat.value));
      }
    };

    requestAnimationFrame(animationFrame);
  }, [statsAnimated, stats]);

  const services = [
    {
      title: 'Strategic Roadmapping',
      description:
        'Define ambitious yet achievable roadmaps grounded in market intelligence and business readiness.',
      icon: '🧭',
      link: '/services',
    },
    {
      title: 'Operational Transformation',
      description:
        'Optimize processes, tools, and governance to create resilient, scalable operating models.',
      icon: '⚙️',
      link: '/services',
    },
    {
      title: 'Revenue Acceleration',
      description:
        'Design and activate integrated go-to-market engines that keep your flywheel spinning.',
      icon: '🚀',
      link: '/services',
    },
  ];

  const process = [
    {
      step: '01',
      title: 'Discover',
      text: 'Facilitated workshops, stakeholder interviews, and diagnostic analysis to uncover high-impact opportunities.',
    },
    {
      step: '02',
      title: 'Design',
      text: 'Collaboratively build strategy blueprints, measurement frameworks, and change narratives.',
    },
    {
      step: '03',
      title: 'Activate',
      text: 'Deploy interdisciplinary squads to launch pilots, enable teams, and embed operational rhythms.',
    },
    {
      step: '04',
      title: 'Scale',
      text: 'Continuously monitor impact, iterate, and scale winning initiatives across the organization.',
    },
  ];

  const testimonials = [
    {
      quote:
        'Elevate Nexus transformed our go-to-market strategy in record time. The team combines sharp strategic thinking with empathetic leadership.',
      name: 'Isabella Hart',
      role: 'Chief Growth Officer, NovaWorks',
      image: 'https://picsum.photos/120/120?random=21',
    },
    {
      quote:
        'Their structured approach to operational change helped us align global teams and exceed our revenue targets by 38% within six months.',
      name: 'Rahul Mehta',
      role: 'SVP Operations, Helios Systems',
      image: 'https://picsum.photos/120/120?random=22',
    },
    {
      quote:
        'Our innovation pipeline has never been stronger. Elevate Nexus empowered our leaders with clarity, cadence, and confidence.',
      name: 'Lena Förster',
      role: 'Head of Innovation, Axis Collective',
      image: 'https://picsum.photos/120/120?random=23',
    },
  ];

  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const rotate = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(rotate);
  }, [testimonials.length]);

  const team = [
    {
      name: 'Adrien Clarke',
      role: 'Managing Partner',
      bio: 'Former McKinsey strategist orchestrating global transformation programs across fintech and healthcare.',
      image: 'https://picsum.photos/400/400?random=31',
    },
    {
      name: 'Maya Ortiz',
      role: 'Director of Growth Strategy',
      bio: 'Data-driven strategist with a decade of experience scaling SaaS ventures and Fortune 500 GTM teams.',
      image: 'https://picsum.photos/400/400?random=32',
    },
    {
      name: 'Kenji Nakamura',
      role: 'Head of Operations Design',
      bio: 'Specialist in lean operations and adaptive change management with impact across four continents.',
      image: 'https://picsum.photos/400/400?random=33',
    },
  ];

  const projects = [
    {
      title: 'Global Revenue Engine',
      category: 'Revenue',
      image: 'https://picsum.photos/1200/800?random=41',
    },
    {
      title: 'Customer Success Blueprint',
      category: 'Experience',
      image: 'https://picsum.photos/1200/800?random=42',
    },
    {
      title: 'Data-Driven Operations',
      category: 'Operations',
      image: 'https://picsum.photos/1200/800?random=43',
    },
    {
      title: 'Market Entry Playbook',
      category: 'Strategy',
      image: 'https://picsum.photos/1200/800?random=44',
    },
  ];

  const [projectFilter, setProjectFilter] = useState('All');

  const filteredProjects =
    projectFilter === 'All'
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  const faqItems = [
    {
      question: 'How do you tailor engagements to our organization?',
      answer:
        'Every engagement begins with a discovery sprint to understand your goals, people, data, and existing initiatives. We then co-create a roadmap aligned to your culture, capacity, and ambition.',
    },
    {
      question: 'Do you work with both scale-ups and enterprise organizations?',
      answer:
        'Yes. Our modular framework allows us to support venture-backed scale-ups seeking repeatable growth as well as enterprise teams navigating complex transformations.',
    },
    {
      question: 'What outcomes can we expect within the first 90 days?',
      answer:
        'Clients typically see renewed strategic clarity, empowered cross-functional squads, and at least two initiatives operationalized with measurable leading indicators.',
    },
    {
      question: 'Can you support in-house enablement after the engagement?',
      answer:
        'Absolutely. We equip your teams with toolkits, capability playbooks, and coaching plans to sustain momentum long after our experts roll off.',
    },
  ];

  const blogPosts = [
    {
      title: 'Designing Revenue Systems That Scale Intelligently',
      date: 'February 12, 2024',
      excerpt:
        'Discover how modern leaders blend data, design, and human enablement to build resilient revenue engines that adapt in real time.',
      image: 'https://picsum.photos/800/600?random=51',
    },
    {
      title: 'The Anatomy of High-Trust Transformation Teams',
      date: 'January 28, 2024',
      excerpt:
        'Learn the five attributes shared by top-performing transformation squads and how to cultivate them across your organization.',
      image: 'https://picsum.photos/800/600?random=52',
    },
    {
      title: 'Operational Excellence in Hybrid Work Era',
      date: 'January 10, 2024',
      excerpt:
        'Hybrid work isn’t a trend—it’s the new operating norm. Explore how leading companies re-architect operations for agility and inclusion.',
      image: 'https://picsum.photos/800/600?random=53',
    },
  ];

  return (
    <div className="home">
      <section className="hero">
        <div className="hero__image">
          <img src="https://picsum.photos/1600/900?random=101" alt="Business leaders collaborating" />
        </div>
        <div className="container hero__container">
          <div className="hero__content">
            <p className="hero__eyebrow">Strategic Consulting for Visionary Organizations</p>
            <h1>
              Orchestrate bold growth with a partner dedicated to measurable transformation.
            </h1>
            <p className="hero__subtitle">
              Elevate Nexus blends strategy, operations, and enablement to unlock the next chapter of
              your business. We align leaders, teams, and systems to deliver results that matter.
            </p>
            <div className="hero__actions">
              <Link className="btn btn--primary btn--lg" to="/contact">
                Schedule a Strategy Call
              </Link>
              <Link className="btn btn--ghost btn--lg" to="/services">
                Explore Our Services
              </Link>
            </div>
            <div className="hero__meta">
              <span className="hero__meta-item">Trusted by global innovators</span>
              <span className="hero__meta-item hero__meta-item--dot">Impact-first partnerships</span>
              <span className="hero__meta-item hero__meta-item--dot">Hybrid delivery model</span>
            </div>
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats__container">
          {stats.map((stat, index) => (
            <div className="stats__card" key={stat.label}>
              <span className="stats__value">
                {statValues[index]}
                {stat.suffix}
              </span>
              <p className="stats__label">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="services" id="services">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">What we do</p>
            <h2>End-to-end consulting that meets your moment.</h2>
          </div>
          <p className="section__intro">
            We partner with executives and their teams from discovery to scale, bringing clarity and
            momentum to your most critical growth and transformation initiatives.
          </p>
        </div>
        <div className="container services__grid">
          {services.map((service) => (
            <Link to={service.link} className="service-card" key={service.title}>
              <span className="service-card__icon">{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <span className="service-card__cta">Learn more →</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="process">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">How we work</p>
            <h2>A collaborative process focused on clarity, alignment, and execution.</h2>
          </div>
        </div>
        <div className="container process__timeline">
          {process.map((item) => (
            <div className="process__step" key={item.step}>
              <div className="process__marker">
                <span>{item.step}</span>
              </div>
              <div className="process__content">
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="testimonials">
        <div className="container testimonials__container">
          <div className="testimonials__header">
            <p className="section__eyebrow">Client impact</p>
            <h2>Leaders choose Elevate Nexus when outcomes matter most.</h2>
          </div>
          <div className="testimonials__carousel">
            {testimonials.map((testimonial, index) => (
              <article
                className={`testimonial ${currentTestimonial === index ? 'testimonial--active' : ''}`}
                key={testimonial.name}
              >
                <div className="testimonial__avatar">
                  <img src={testimonial.image} alt={`Portrait of ${testimonial.name}`} />
                </div>
                <p className="testimonial__quote">“{testimonial.quote}”</p>
                <div className="testimonial__meta">
                  <span className="testimonial__name">{testimonial.name}</span>
                  <span className="testimonial__role">{testimonial.role}</span>
                </div>
              </article>
            ))}
            <div className="testimonials__controls">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  className={`testimonials__dot ${
                    currentTestimonial === idx ? 'testimonials__dot--active' : ''
                  }`}
                  onClick={() => setCurrentTestimonial(idx)}
                  aria-label={`Show testimonial ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">Leadership</p>
            <h2>A multidisciplinary team built to navigate complexity.</h2>
          </div>
          <p className="section__intro">
            Our partners blend strategy, operations, design thinking, and enablement to deliver
            transformation with empathy and precision.
          </p>
        </div>
        <div className="container team__grid">
          {team.map((member) => (
            <div className="team-card" key={member.name}>
              <div className="team-card__image">
                <img src={member.image} alt={`Portrait of ${member.name}`} />
              </div>
              <div className="team-card__content">
                <h3>{member.name}</h3>
                <span className="team-card__role">{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">Selected work</p>
            <h2>Transformations engineered for momentum and measurable impact.</h2>
          </div>
          <div className="projects__filters">
            {['All', 'Strategy', 'Operations', 'Revenue', 'Experience'].map((filter) => (
              <button
                key={filter}
                className={`projects__filter ${
                  projectFilter === filter ? 'projects__filter--active' : ''
                }`}
                onClick={() => setProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
        <div className="container projects__grid">
          {filteredProjects.map((project) => (
            <div className="project-card" key={project.title}>
              <div className="project-card__image">
                <img src={project.image} alt={`${project.title} project visual`} loading="lazy" />
              </div>
              <div className="project-card__content">
                <span className="project-card__category">{project.category}</span>
                <h3>{project.title}</h3>
                <p>
                  Cross-functional program delivering aligned roadmaps, predictive insights, and
                  empowered teams ready to execute.
                </p>
                <Link to="/contact" className="project-card__link">
                  Discuss similar project →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">FAQs</p>
            <h2>Answers to common questions from executive teams.</h2>
          </div>
          <p className="section__intro">
            Need additional clarity? Our consultants are available to explore your goals in a tailored
            discovery session.
          </p>
        </div>
        <div className="container faq__list">
          {faqItems.map((item, index) => (
            <details key={item.question} className="faq__item" open={index === 0}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="blog" id="blog">
        <div className="container section__header">
          <div>
            <p className="section__eyebrow">Latest insights</p>
            <h2>Perspectives shaping the future of competitive organizations.</h2>
          </div>
        </div>
        <div className="container blog__grid">
          {blogPosts.map((post) => (
            <article className="blog-card" key={post.title}>
              <div className="blog-card__image">
                <img src={post.image} alt={`${post.title} header visual`} loading="lazy" />
              </div>
              <div className="blog-card__content">
                <span className="blog-card__date">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href="#!" className="blog-card__link">
                  Read article →
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="cta">
        <div className="container cta__container">
          <div className="cta__content">
            <p className="section__eyebrow">Ready to accelerate?</p>
            <h2>Let’s design your next wave of growth together.</h2>
            <p>
              Schedule a strategy conversation with our senior consultants to explore bold ideas,
              unpack challenges, and shape a roadmap aligned to your ambition.
            </p>
          </div>
          <div className="cta__actions">
            <Link to="/contact" className="btn btn--primary btn--lg">
              Start the conversation
            </Link>
            <Link to="/about" className="btn btn--ghost btn--lg">
              Meet our team
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;