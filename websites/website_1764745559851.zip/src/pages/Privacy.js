import React from 'react';

const Privacy = () => {
  return (
    <div className="legal">
      <section className="page-hero page-hero--compact">
        <div className="container page-hero__container page-hero__container--center">
          <div className="page-hero__content">
            <p className="section__eyebrow">Privacy</p>
            <h1>Privacy Policy</h1>
            <p>Effective date: January 1, 2024</p>
          </div>
        </div>
      </section>
      <section className="legal__content">
        <div className="container legal__body">
          <h2>1. Overview</h2>
          <p>
            Elevate Nexus Consulting respects your privacy and is committed to protecting personal
            information shared with us.
          </p>

          <h2>2. Information we collect</h2>
          <p>
            We collect contact details and business information voluntarily submitted through forms,
            emails, or events. We also collect analytics data to improve our services.
          </p>

          <h2>3. How we use information</h2>
          <p>
            Information is used to respond to inquiries, deliver consulting services, and share
            relevant updates. We do not sell personal data.
          </p>

          <h2>4. Data security</h2>
          <p>
            We employ technical and organizational measures to safeguard personal data against
            unauthorized access, alteration, or disclosure.
          </p>

          <h2>5. Your rights</h2>
          <p>
            Depending on your jurisdiction, you may request access, correction, or deletion of your
            personal data by contacting{' '}
            <a href="mailto:privacy@elevatenexus.com">privacy@elevatenexus.com</a>.
          </p>

          <h2>6. Updates</h2>
          <p>
            We may update this policy periodically. We encourage you to review this page for the latest
            information on our privacy practices.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;