import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Services = () => {
  const offerings = [
    {
      title: 'Strategic Alignment Lab',
      summary: 'Craft a unified growth strategy with executive teams aligned on ambition and outcomes.',
      details: [
        'Market landscaping & opportunity sizing',
        'Scenario planning and risk mitigation',
        'Executive alignment workshops',
        'North star vision and OKR design',
      ],
    },
    {
      title: 'Revenue Operations Studio',
      summary: 'Engineer a connected revenue engine that enables predictable growth at scale.',
      details: [
        'Lead lifecycle optimization',
        'Attribution modeling & analytics',
        'Sales & marketing enablement sprints',
        'Dashboarding and reporting cadence',
      ],
    },
    {
      title: 'Operational Excellence Sprint',
      summary: 'Redesign processes, governance, and tools to empower teams to move faster with clarity.',
      details: [
        'Process mapping & RACI frameworks',
        'Technology stack evaluation',
        'Change management roadmaps',
        'Capability building and training',
      ],
    },
    {
      title: 'Customer Experience Transformation',
      summary: 'Elevate every customer touchpoint through journey orchestration and service blueprinting.',
      details: [
        'Voice of customer research',
        'Journey analytics and design',
        'Service blueprint development',
        'Experience measurement frameworks',
      ],
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="services-page">
      <section className="page-hero page-hero--alt">
        <div className="container page-hero__container">
          <div className="page-hero__content">
            <p className="section__eyebrow">Our services</p>
            <h1>Modular engagements crafted to deliver strategic outcomes.</h1>
            <p>
              We build bespoke programs anchored in your objectives. Every engagement includes a seasoned
              consulting team, tailored playbooks, and measurable results.
            </p>
          </div>
          <div className="page-hero__image">
            <img src="https://picsum.photos/800/600?random=72" alt="Team leading strategic workshop" />
          </div>
        </div>
      </section>

      <section className="offerings">
        <div className="container offerings__layout">
          <div className="offerings__list">
            {offerings.map((offering, index) => (
              <button
                key={offering.title}
                className={`offerings__item ${activeIndex === index ? 'offerings__item--active' : ''}`}
                onClick={() => setActiveIndex(index)}
              >
                <span>{offering.title}</span>
              </button>
            ))}
          </div>
          <div className="offerings__details">
            <div className="offerings__details-card">
              <h2>{offerings[activeIndex].title}</h2>
              <p>{offerings[activeIndex].summary}</p>
              <ul>
                {offerings[activeIndex].details.map((detail) => (
                  <li key={detail}>{detail}</li>
                ))}
              </ul>
              <Link to="/contact" className="btn btn--primary btn--lg offerings__cta">
                Request proposal
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="services-page__cta">
        <div className="container page-cta__container">
          <h2>Let’s co-create a program that fits your goals.</h2>
          <p>We will assemble the right experts and design an engagement model tailored to your team.</p>
          <div className="page-cta__actions">
            <Link to="/contact" className="btn btn--primary btn--lg">
              Start planning
            </Link>
            <Link to="/about" className="btn btn--ghost btn--lg">
              Meet our leaders
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;