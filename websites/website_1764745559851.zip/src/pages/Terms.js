import React from 'react';

const Terms = () => {
  return (
    <div className="legal">
      <section className="page-hero page-hero--compact">
        <div className="container page-hero__container page-hero__container--center">
          <div className="page-hero__content">
            <p className="section__eyebrow">Legal</p>
            <h1>Terms &amp; Conditions</h1>
            <p>Effective date: January 1, 2024</p>
          </div>
        </div>
      </section>
      <section className="legal__content">
        <div className="container legal__body">
          <h2>1. Acceptance of terms</h2>
          <p>
            By accessing or using the Elevate Nexus Consulting website, you agree to be bound by these
            Terms &amp; Conditions. If you do not agree, please discontinue use of our website.
          </p>

          <h2>2. Services</h2>
          <p>
            All consulting services are outlined in individual engagement agreements. Information on
            this site is provided for general guidance and does not constitute a binding offer.
          </p>

          <h2>3. Intellectual property</h2>
          <p>
            All content, trademarks, and materials provided on this site are owned by Elevate Nexus
            Consulting or its licensors. Unauthorized use is strictly prohibited.
          </p>

          <h2>4. Limitation of liability</h2>
          <p>
            Elevate Nexus Consulting is not liable for any damages arising from the use or inability to
            use this website. Our liability in connection with consulting engagements is limited as set
            forth in each engagement contract.
          </p>

          <h2>5. Governing law</h2>
          <p>
            These Terms &amp; Conditions are governed by the laws of the State of New York, without
            regard to conflict of law principles.
          </p>

          <h2>Contact</h2>
          <p>
            For questions about these terms, contact us at{' '}
            <a href="mailto:legal@elevatenexus.com">legal@elevatenexus.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;