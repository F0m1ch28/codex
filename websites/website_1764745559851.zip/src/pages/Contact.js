import React, { useState } from 'react';

const Contact = () => {
  const [form, setForm] = useState({
    name: '',
    company: '',
    email: '',
    message: '',
  });
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const errors = {};
  if (!form.name.trim()) errors.name = 'Your name is required.';
  if (!form.company.trim()) errors.company = 'Company name is required.';
  if (!form.email.trim()) {
    errors.email = 'Email address is required.';
  } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(form.email)) {
    errors.email = 'Enter a valid email address.';
  }
  if (!form.message.trim()) errors.message = 'Please describe your project or question.';

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    setTouched((prev) => ({
      ...prev,
      [name]: true,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setTouched({
      name: true,
      company: true,
      email: true,
      message: true,
    });
    if (Object.keys(errors).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <div className="contact">
      <section className="page-hero">
        <div className="container page-hero__container">
          <div className="page-hero__content">
            <p className="section__eyebrow">Contact</p>
            <h1>Let’s architect the next phase of your growth.</h1>
            <p>
              Share a few details about your priorities and our senior team will reach out within two
              business days to schedule a discovery conversation.
            </p>
          </div>
          <div className="page-hero__image">
            <img src="https://picsum.photos/800/600?random=82" alt="Team discussing consulting engagement" />
          </div>
        </div>
      </section>

      <section className="contact__form-section">
        <div className="container contact__layout">
          <div className="contact__details">
            <h2>How we can help</h2>
            <p>
              The best transformations begin with a candid conversation. We welcome inquiries related
              to growth strategy, operational excellence, revenue enablement, and executive advisory.
            </p>
            <div className="contact__info">
              <h3>Direct contact</h3>
              <a href="mailto:hello@elevatenexus.com">hello@elevatenexus.com</a>
              <a href="tel:+12145550123">+1 (214) 555-0123</a>
            </div>
            <div className="contact__info">
              <h3>Offices</h3>
              <p>New York · Austin · Amsterdam · Singapore</p>
            </div>
          </div>
          <form className="contact__form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Your name</label>
              <input
                id="name"
                name="name"
                type="text"
                value={form.name}
                onChange={handleChange}
                onBlur={handleBlur}
                className={touched.name && errors.name ? 'input--error' : ''}
                placeholder="Jordan Williams"
              />
              {touched.name && errors.name && <span className="form-error">{errors.name}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                value={form.company}
                onChange={handleChange}
                onBlur={handleBlur}
                className={touched.company && errors.company ? 'input--error' : ''}
                placeholder="Acme Innovations"
              />
              {touched.company && errors.company && (
                <span className="form-error">{errors.company}</span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="email">Business email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                onBlur={handleBlur}
                className={touched.email && errors.email ? 'input--error' : ''}
                placeholder="jordan@acme.com"
              />
              {touched.email && errors.email && <span className="form-error">{errors.email}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="message">How can we help?</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={form.message}
                onChange={handleChange}
                onBlur={handleBlur}
                className={touched.message && errors.message ? 'input--error' : ''}
                placeholder="Share your priorities, challenges, or desired outcomes."
              />
              {touched.message && errors.message && (
                <span className="form-error">{errors.message}</span>
              )}
            </div>
            <button type="submit" className="btn btn--primary btn--lg">
              Submit inquiry
            </button>
            {submitted && (
              <p className="form-success">
                Thank you! Our consultants will reach out within two business days.
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;