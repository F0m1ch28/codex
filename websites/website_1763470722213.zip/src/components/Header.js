import React, { useState, useEffect } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { path: "/ueber-uns", label: "Über uns" },
    { path: "/methoden", label: "Methoden" },
    { path: "/termine", label: "Termine" },
    { path: "/kontakt", label: "Kontakt" }
  ];

  return (
    <header className={styles.header} role="banner">
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="Zur Startseite">
            <span className={styles.logoMark}>M</span>
            <span className={styles.logoText}>Melavertina</span>
            <span className={styles.logoSub}>Selbstwert &amp; innere Stärke</span>
          </Link>
          <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ""}`} aria-label="Hauptnavigation">
            <ul className={styles.navList}>
              {navLinks.map((link) => (
                <li key={link.path} className={styles.navItem}>
                  <NavLink
                    to={link.path}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.active : ""}`
                    }
                  >
                    {link.label}
                  </NavLink>
                </li>
              ))}
            </ul>
            <Link to="/termine" className={styles.navCta}>
              Jetzt beraten lassen
            </Link>
          </nav>
          <button
            type="button"
            className={`${styles.menuButton} ${isMenuOpen ? styles.menuButtonActive : ""}`}
            aria-label="Navigation umschalten"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((prev) => !prev)}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;