import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <h2 className={styles.title}>Melavertina</h2>
            <p className={styles.subtitle}>
              Wir stärken Selbstwertgefühl, Gelassenheit und innere Führung – für Menschen, die neue Wege gehen möchten.
            </p>
            <p className={styles.address}>
              Adresse: [Adresse wird bereitgestellt] <br />
              Telefon: [Telefon wird bereitgestellt] <br />
              E-Mail: <a href="mailto:[Email wird bereitgestellt]">[Email wird bereitgestellt]</a>
            </p>
          </div>
          <div className={styles.column}>
            <h3>Navigation</h3>
            <ul>
              <li>
                <Link to="/">Startseite</Link>
              </li>
              <li>
                <Link to="/ueber-uns">Über uns</Link>
              </li>
              <li>
                <Link to="/methoden">Methoden</Link>
              </li>
              <li>
                <Link to="/termine">Termine</Link>
              </li>
              <li>
                <Link to="/kontakt">Kontakt</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3>Rechtliches</h3>
            <ul>
              <li>
                <Link to="/datenschutz">Datenschutz</Link>
              </li>
              <li>
                <Link to="/impressum">Impressum</Link>
              </li>
              <li>
                <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3>Impulse</h3>
            <ul>
              <li>
                <Link to="/methoden">Selbstwert stärken</Link>
              </li>
              <li>
                <Link to="/ueber-uns">Arbeitsweise</Link>
              </li>
              <li>
                <Link to="/kontakt">Individuelle Anfrage</Link>
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <span>&copy; {new Date().getFullYear()} Melavertina. Alle Rechte vorbehalten.</span>
          <span>Gemeinsam neue innere Räume öffnen.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;