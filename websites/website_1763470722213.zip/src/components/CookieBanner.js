import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("melavertina_cookieConsent");
    if (!consent) {
      const timeout = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timeout);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("melavertina_cookieConsent", "accepted");
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive" aria-label="Cookie Hinweis">
      <div className={styles.content}>
        <h3>Wir respektieren Ihre Privatsphäre</h3>
        <p>
          Um unsere Website für Sie stetig zu verbessern, nutzen wir ausgewählte Cookies. Sie können unser Angebot auch ohne
          Statistik-Cookies verwenden. Details finden Sie in unserer{" "}
          <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={handleAccept}>
          Einverstanden
        </button>
        <Link to="/datenschutz" className={styles.more}>
          Mehr erfahren
        </Link>
      </div>
    </div>
  );
};

export default CookieBanner;