import React from "react";
import { Routes, Route } from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import Termine from "./pages/Termine";
import Datenschutz from "./pages/Datenschutz";
import Impressum from "./pages/Impressum";
import CookiePolicy from "./pages/CookiePolicy";

const App = () => {
  return (
    <>
      <Helmet>
        <title>Melavertina | Selbstwert stärken &amp; inneren Kritiker verwandeln</title>
        <meta
          name="description"
          content="Melavertina begleitet Menschen mit fundiertem Coaching dabei, ihren Selbstwert zu stärken, innere Kritiker zu transformieren und Potenzial nachhaltig zu entfalten."
        />
      </Helmet>
      <div className="app">
        <Header />
        <ScrollToTop />
        <main className="mainContent" id="hauptinhalt">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/ueber-uns" element={<About />} />
            <Route path="/methoden" element={<Services />} />
            <Route path="/kontakt" element={<Contact />} />
            <Route path="/termine" element={<Termine />} />
            <Route path="/datenschutz" element={<Datenschutz />} />
            <Route path="/impressum" element={<Impressum />} />
            <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </>
  );
};

export default App;