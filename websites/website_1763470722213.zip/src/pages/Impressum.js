import React from "react";
import { Helmet } from "react-helmet";
import styles from "./PageLayout.module.css";

const Impressum = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Impressum | Melavertina</title>
        <meta
          name="description"
          content="Impressum von Melavertina – Angaben gemäß § 5 TMG."
        />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <h1>Impressum</h1>
          <h2>Angaben gemäß § 5 TMG</h2>
          <p>
            Melavertina <br />
            Inhaberin: Marina Velertina <br />
            Adresse: [Adresse wird bereitgestellt] <br />
          </p>

          <h2>Kontakt</h2>
          <p>
            Telefon: [Telefon wird bereitgestellt] <br />
            E-Mail: <a href="mailto:[Email wird bereitgestellt]">[Email wird bereitgestellt]</a>
          </p>

          <h2>Umsatzsteuer-ID</h2>
          <p>Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz: [wird ergänzt]</p>

          <h2>Berufsbezeichnung</h2>
          <p>
            Coach (nicht reglementierter Beruf). Zuständige Aufsichtsbehörde: nicht erforderlich. Relevante berufliche Verhaltensregeln ergeben sich aus
            den Ethikrichtlinien systemischer Coachings.
          </p>

          <h2>Haftung für Inhalte</h2>
          <p>
            Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis
            10 TMG sind wir jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die
            auf eine rechtswidrige Tätigkeit hinweisen.
          </p>

          <h2>Haftung für Links</h2>
          <p>
            Unser Angebot enthält ggf. Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden
            Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber verantwortlich.
          </p>

          <h2>Urheberrecht</h2>
          <p>
            Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Beiträge Dritter sind als
            solche gekennzeichnet. Die Vervielfältigung, Bearbeitung und Verbreitung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen
            Zustimmung.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Impressum;