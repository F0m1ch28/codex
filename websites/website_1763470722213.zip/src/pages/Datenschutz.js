import React from "react";
import { Helmet } from "react-helmet";
import styles from "./PageLayout.module.css";

const Datenschutz = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Datenschutz | Melavertina</title>
        <meta
          name="description"
          content="Datenschutzerklärung von Melavertina: Informationen zur Verarbeitung personenbezogener Daten und Ihren Rechten."
        />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <h1>Datenschutzerklärung</h1>
          <p>
            Wir freuen uns über Ihr Interesse an Melavertina. Der Schutz Ihrer personenbezogenen Daten ist uns wichtig. Nachfolgend informieren wir Sie
            über die Verarbeitung personenbezogener Daten beim Besuch unserer Website und im Rahmen unserer Angebote.
          </p>

          <h2>1. Verantwortliche Stelle</h2>
          <p>
            Verantwortlich für die Datenverarbeitung ist Melavertina, vertreten durch die Inhaberin Marina Velertina (
            Kontaktdaten siehe Impressum). Bei Fragen zum Datenschutz wenden Sie sich bitte an: [Email wird bereitgestellt].
          </p>

          <h2>2. Besuch der Website</h2>
          <p>
            Beim Aufrufen unserer Website werden durch den Browser Ihres Endgeräts automatisch Informationen an unseren
            Server gesendet. Diese Informationen werden temporär in einem sogenannten Logfile gespeichert:
          </p>
          <ul>
            <li>IP-Adresse des anfragenden Rechners</li>
            <li>Datum und Uhrzeit des Zugriffs</li>
            <li>Inhalt der Anforderung (konkrete Seite)</li>
            <li>Verwendeter Browser und ggf. Betriebssystem Ihres Rechners</li>
          </ul>
          <p>
            Die Verarbeitung erfolgt, um einen reibungslosen Verbindungsaufbau der Website sicherzustellen (Art. 6 Abs. 1 lit. f DSGVO).
            Eine Zusammenführung dieser Daten mit anderen Datenquellen findet nicht statt.
          </p>

          <h2>3. Kontaktaufnahme</h2>
          <p>
            Wenn Sie uns per E-Mail oder über das Kontaktformular kontaktieren, verarbeiten wir die von Ihnen übermittelten Daten, um Ihre Anfrage zu
            beantworten. Rechtsgrundlage ist Art. 6 Abs. 1 lit. b DSGVO (vorvertragliche Maßnahmen). Die Daten werden gelöscht, sobald sie nicht mehr
            erforderlich sind, sofern keine gesetzlichen Aufbewahrungspflichten entgegenstehen.
          </p>

          <h2>4. Newsletter &amp; Programme</h2>
          <p>
            Sofern wir Newsletter oder digitale Programme anbieten und Sie sich anmelden, verarbeiten wir Ihre Angaben zur Durchführung und
            Dokumentation der Anmeldung. Rechtsgrundlage ist Ihre Einwilligung (Art. 6 Abs. 1 lit. a DSGVO). Sie können Ihre Einwilligung jederzeit mit Wirkung
            für die Zukunft widerrufen.
          </p>

          <h2>5. Cookies &amp; Analyse</h2>
          <p>
            Wir verwenden Cookies, um unsere Website nutzerfreundlich zu gestalten. Notwendige Cookies dienen dem Betrieb der Seite. Optionale
            Statistik-Cookies werden nur mit Ihrer Einwilligung gesetzt (Art. 6 Abs. 1 lit. a DSGVO). Details dazu finden Sie in unserer Cookie-Richtlinie.
          </p>

          <h2>6. Externe Dienstleister</h2>
          <p>
            Wir arbeiten mit Dienstleistern (z. B. für Hosting oder Newsletterversand) zusammen. Diese werden sorgfältig ausgewählt, vertraglich verpflichtet
            und verarbeiten Daten nur in unserem Auftrag.
          </p>

          <h2>7. Speicherdauer</h2>
          <p>
            Wir speichern personenbezogene Daten nur so lange, wie es für die genannten Zwecke erforderlich ist oder gesetzliche Aufbewahrungsfristen bestehen.
            Danach werden die Daten gelöscht oder gesperrt.
          </p>

          <h2>8. Ihre Rechte</h2>
          <p>
            Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie auf Widerspruch gegen die
            Verarbeitung personenbezogener Daten. Außerdem haben Sie das Recht, erteilte Einwilligungen jederzeit zu widerrufen. Bitte wenden Sie sich dazu
            an die oben genannte Kontaktadresse.
          </p>

          <h2>9. Beschwerderecht</h2>
          <p>
            Sie haben das Recht, sich bei einer Datenschutzaufsichtsbehörde zu beschweren, wenn Sie der Ansicht sind, dass die Verarbeitung Ihrer
            personenbezogenen Daten gegen die DSGVO verstößt.
          </p>

          <h2>10. Aktualität</h2>
          <p>
            Diese Datenschutzerklärung ist aktuell gültig und hat den Stand Februar 2024. Durch die Weiterentwicklung unserer Website oder aufgrund
            geänderter gesetzlicher Vorgaben kann eine Anpassung erforderlich werden.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Datenschutz;