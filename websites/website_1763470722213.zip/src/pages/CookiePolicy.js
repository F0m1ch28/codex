import React from "react";
import { Helmet } from "react-helmet";
import styles from "./PageLayout.module.css";

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie-Richtlinie | Melavertina</title>
        <meta
          name="description"
          content="Cookie-Richtlinie von Melavertina – Informationen zu verwendeten Cookies und Ihren Auswahlmöglichkeiten."
        />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <h1>Cookie-Richtlinie</h1>
          <p>
            Diese Richtlinie erläutert, wie Melavertina Cookies und ähnliche Technologien nutzt. Sie erfahren, welche Cookies wir einsetzen, zu welchem
            Zweck und wie Sie Ihre Einstellungen verwalten können.
          </p>

          <h2>Was sind Cookies?</h2>
          <p>
            Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden. Sie helfen, unser Angebot nutzerfreundlicher zu machen und
            statistische Auswertungen zu ermöglichen. Manche Cookies werden nach Ende der Sitzung gelöscht (Session-Cookies), andere bleiben gespeichert,
            um Ihren Browser beim nächsten Besuch wiederzuerkennen (persistente Cookies).
          </p>

          <h2>Eingesetzte Cookies</h2>
          <ul>
            <li>
              <strong>Notwendige Cookies</strong>: erforderlich für die grundlegenden Funktionen der Website (z. B. Navigation, Formularfunktionen).
            </li>
            <li>
              <strong>Statistik-Cookies</strong>: Nur mit Ihrer Einwilligung. Sie helfen uns, das Nutzungsverhalten anonymisiert zu analysieren und die Website zu optimieren.
            </li>
          </ul>

          <h2>Cookie-Einstellungen verwalten</h2>
          <p>
            Sie können Ihre Cookie-Einstellungen jederzeit über den Cookie-Hinweis auf unserer Website ändern oder Ihren Browser so einstellen,
            dass keine Cookies gespeichert werden. Bitte beachten Sie, dass dann unter Umständen nicht alle Funktionen der Website vollumfänglich
            genutzt werden können.
          </p>

          <h2>Rechtsgrundlage</h2>
          <p>
            Die Rechtsgrundlage für den Einsatz notwendiger Cookies ist Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse). Für optionale Cookies
            ist Art. 6 Abs. 1 lit. a DSGVO (Einwilligung) maßgeblich.
          </p>

          <h2>Kontakt</h2>
          <p>
            Bei Fragen zur Cookie-Richtlinie kontaktieren Sie uns bitte unter [Email wird bereitgestellt].
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;