import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const initialForm = {
  name: "",
  email: "",
  topic: "",
  message: ""
};

const Contact = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Bitte geben Sie Ihren Namen an.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Bitte geben Sie Ihre E-Mail-Adresse an.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = "Bitte nutzen Sie eine gültige E-Mail-Adresse.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Bitte schildern Sie Ihr Anliegen.";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitted(true);
      setFormData(initialForm);
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | Melavertina</title>
        <meta
          name="description"
          content="Kontaktieren Sie Melavertina: Vereinbaren Sie ein Orientierungsgespräch, stellen Sie Fragen oder teilen Sie Ihr Anliegen."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt &amp; Anfrage</h1>
          <p>
            Wir freuen uns auf Ihre Nachricht. Beschreiben Sie Ihr Anliegen – wir melden uns innerhalb von zwei Werktagen,
            um den nächsten Schritt zu vereinbaren.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Schreiben Sie uns</h2>
              {isSubmitted && (
                <div className={styles.success} role="status">
                  Vielen Dank für Ihre Nachricht. Wir melden uns zeitnah bei Ihnen.
                </div>
              )}
              <div className={styles.field}>
                <label htmlFor="name">Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? "name-error" : undefined}
                />
                {errors.name && (
                  <span className={styles.error} id="name-error">
                    {errors.name}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">E-Mail *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? "email-error" : undefined}
                />
                {errors.email && (
                  <span className={styles.error} id="email-error">
                    {errors.email}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="topic">Anliegen</label>
                <select id="topic" name="topic" value={formData.topic} onChange={handleChange}>
                  <option value="">Bitte wählen</option>
                  <option value="coaching">Einzelcoaching</option>
                  <option value="workshop">Workshop / Teamformat</option>
                  <option value="programm">Programm / Lernreise</option>
                  <option value="sparring">Mentoring / Sparring</option>
                  <option value="other">Anderes Anliegen</option>
                </select>
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Nachricht *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? "message-error" : undefined}
                />
                {errors.message && (
                  <span className={styles.error} id="message-error">
                    {errors.message}
                  </span>
                )}
              </div>
              <button type="submit" className={styles.submit}>
                Nachricht senden
              </button>
            </form>
            <aside className={styles.info}>
              <h2>Direkter Kontakt</h2>
              <p>
                Adresse: [Adresse wird bereitgestellt] <br />
                Telefon: [Telefon wird bereitgestellt] <br />
                E-Mail: <a href="mailto:[Email wird bereitgestellt]">[Email wird bereitgestellt]</a>
              </p>
              <div className={styles.infoCard}>
                <h3>Worüber wir uns freuen</h3>
                <ul>
                  <li>Kurzbeschreibung Ihrer Situation</li>
                  <li>Wünsche an den Prozess</li>
                  <li>Angaben zu bevorzugten Terminen</li>
                </ul>
              </div>
              <p>
                <strong>Hinweis:</strong> Coachings ersetzen keine therapeutischen oder medizinischen Behandlungen. Bei Bedarf
                vermitteln wir gern passende Stellen.
              </p>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;