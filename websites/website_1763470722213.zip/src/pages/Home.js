import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const statsData = [
  { label: "Jahre Erfahrung", target: 12 },
  { label: "Begleitete Menschen", target: 380 },
  { label: "Workshops pro Jahr", target: 24 },
  { label: "Weiterempfehlungsrate", target: 96, suffix: "%" }
];

const methodCards = [
  {
    title: "Selbstwert-Reflexion",
    description:
      "Wir beleuchten innere Überzeugungen und schaffen Raum, um Beziehung zu sich selbst neu zu gestalten.",
    icon: "🪞"
  },
  {
    title: "Arbeit mit dem inneren Kritiker",
    description:
      "Der innere Kritiker wird erkannt, benannt und in unterstützende Anteile integriert – ohne ihn zu bekämpfen.",
    icon: "🎧"
  },
  {
    title: "Embodied Coaching",
    description:
      "Über den Körper erkannte Muster werden gelöst, innere Sicherheit und Klarheit entstehen Schritt für Schritt.",
    icon: "🌿"
  },
  {
    title: "Transfer in den Alltag",
    description:
      "Konkrete Rituale, Micro-Experimente und Reflexionen sichern nachhaltige Veränderungen im täglichen Handeln.",
    icon: "🧭"
  }
];

const processSteps = [
  {
    title: "Orientierung & Zielbild",
    text: "Gemeinsames Klären des Anliegens, Aufspüren der inneren Dynamiken und Vereinbaren erster Wirkziele."
  },
  {
    title: "Tiefe & Transformation",
    text: "Behutsame Arbeit mit inneren Anteilen, Ressourcensuche und Differenzierung zwischen alten Mustern und Gegenwart."
  },
  {
    title: "Integration & Transfer",
    text: "Neue Handlungsspielräume werden konkret geübt. Begleitende Tools sichern Selbstführung im Alltag."
  },
  {
    title: "Review & Ausblick",
    text: "Gewonnene Erkenntnisse werden gefestigt. Neue Routinen und Unterstützer-Netzwerke werden gestaltet."
  }
];

const testimonials = [
  {
    quote:
      "In wenigen Sitzungen habe ich gelernt, meinen inneren Kritiker zu verstehen, statt ihn zu bekämpfen. Das hat meine Selbstgespräche und Entscheidungen nachhaltig verändert.",
    name: "Claudia W.",
    role: "Coaching-Klientin"
  },
  {
    quote:
      "Besonders wertvoll war die Kombination aus Reflexion und praktischen Experimenten. Ich habe wieder Zugang zu meiner eigenen Stimme gefunden.",
    name: "Patrick M.",
    role: "Teamleiter"
  },
  {
    quote:
      "Die Workshops schaffen eine vertrauensvolle Atmosphäre, in der man neue Perspektiven ausprobieren kann, ohne sich bewertet zu fühlen.",
    name: "Anonymisierte Rückmeldung",
    role: "Teilnehmer:in Workshop"
  }
];

const teamMembers = [
  {
    name: "Marina Velertina",
    role: "Coach & Gründerin",
    bio: "Systemische Coachin, ausgebildet in Inner-Parts-Work, Embodiment & Achtsamkeitsbasierter Stressreduktion. Spezialisiert auf Selbstwert und innere Kritikerinnenarbeit.",
    image: "https://picsum.photos/400/400?random=33"
  },
  {
    name: "Leonie Kramer",
    role: "Facilitatorin",
    bio: "Leitet Gruppenprozesse und gestaltet Lernräume, in denen Sicherheit und Experimentierfreude möglich werden. Schwerpunkt auf Teamresilienz.",
    image: "https://picsum.photos/400/400?random=34"
  },
  {
    name: "Jonas Behr",
    role: "Research & Entwicklung",
    bio: "Verbindet aktuelle Forschung zu Selbstmitgefühl, Psychologie und Neurowissenschaft mit praxisnahen Übungen und Begleitmaterialien.",
    image: "https://picsum.photos/400/400?random=35"
  }
];

const projects = [
  {
    title: "Selbstwert-Kompass",
    category: "Programme",
    description: "12-wöchiges Online-Programm mit Live-Sessions, Reflexionsjournal und Peer-Begleitung.",
    image: "https://picsum.photos/1200/800?random=41"
  },
  {
    title: "Leading with Inner Clarity",
    category: "Workshops",
    description: "Ein Präsenz-Workshop für Führungskräfte, der innere Kritiker transformiert und Empowerment schafft.",
    image: "https://picsum.photos/1200/800?random=42"
  },
  {
    title: "Inner Mentor Sessions",
    category: "Einzelcoaching",
    description: "Individuelle Begleitung für Menschen in Übergangsphasen, die Selbstführung vertiefen möchten.",
    image: "https://picsum.photos/1200/800?random=43"
  },
  {
    title: "Team-Resilienz Canvas",
    category: "Workshops",
    description: "Interaktives Teamformat, das Selbstwert im Miteinander stärkt und Feedbackkultur neu gestaltet.",
    image: "https://picsum.photos/1200/800?random=44"
  }
];

const faqItems = [
  {
    question: "Wie läuft ein Erstgespräch ab?",
    answer:
      "Im Erstgespräch klären wir Ihr Anliegen, Erwartungen und Ziele. Sie erhalten einen Einblick in unsere Arbeitsweise und wir prüfen gemeinsam, ob die Chemie stimmt."
  },
  {
    question: "Wie lange dauert ein Coaching-Prozess?",
    answer:
      "Die Dauer richtet sich nach Ihrem Anliegen. Viele Menschen arbeiten zwischen vier und acht Sitzungen mit uns. Wir gestalten jeden Prozess individuell und transparent."
  },
  {
    question: "Ist die Teilnahme auch online möglich?",
    answer:
      "Ja. Einzelcoachings und ausgewählte Workshops bieten wir sowohl online als auch vor Ort an. Für Gruppenformate stimmen wir passende Rahmenbedingungen vorher ab."
  },
  {
    question: "Welche Materialien erhalte ich zur Nachbereitung?",
    answer:
      "Sie erhalten Reflexionsimpulse, Audioübungen sowie individuelle Transferaufgaben, die wir im Prozess gemeinsam vereinbaren."
  }
];

const blogPosts = [
  {
    title: "Warum der innere Kritiker eigentlich schützen will",
    excerpt: "Statt den inneren Kritiker zum Schweigen zu bringen, lohnt es sich, seine positive Absicht zu verstehen und umzuwandeln.",
    date: "05. Februar 2024",
    link: "/ueber-uns"
  },
  {
    title: "Selbstmitgefühl als Schlüssel für nachhaltige Veränderung",
    excerpt: "Wie Selbstmitgefühl Leistungsfähigkeit und Klarheit fördert – und welche kleinen Routinen sofort anwendbar sind.",
    date: "18. Januar 2024",
    link: "/methoden"
  },
  {
    title: "Rituale für mehr innere Verbundenheit im Team",
    excerpt: "Teamrituale schaffen Sicherheit und stärken das Miteinander. Drei Impulse für Meetings mit Tiefgang.",
    date: "07. Dezember 2023",
    link: "/kontakt"
  }
];

const Home = () => {
  const statsRef = useRef(null);
  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [hasAnimated, setHasAnimated] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState("Alle");
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasAnimated) {
            setHasAnimated(true);
          }
        });
      },
      { threshold: 0.45 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, [hasAnimated]);

  useEffect(() => {
    let animationFrame;
    if (hasAnimated) {
      const start = performance.now();
      const duration = 1600;

      const animate = (time) => {
        const progress = Math.min((time - start) / duration, 1);
        const updated = statsData.map((stat) => Math.round(progress * stat.target));
        setStatValues(updated);
        if (progress < 1) {
          animationFrame = requestAnimationFrame(animate);
        } else {
          setStatValues(statsData.map((stat) => stat.target));
        }
      };

      animationFrame = requestAnimationFrame(animate);
    }
    return () => cancelAnimationFrame(animationFrame);
  }, [hasAnimated]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    activeFilter === "Alle"
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  const handleFaqToggle = (index) => {
    setExpandedFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.home}>
      <Helmet>
        <title>Melavertina | Selbstwert stärken &amp; innere Kritik verwandeln</title>
        <meta
          name="description"
          content="Entdecken Sie, wie Melavertina Menschen begleitet, ihren Selbstwert zu stärken, den inneren Kritiker zu transformieren und neue Handlungsspielräume zu öffnen."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <p className={styles.heroBadge}>Selbstwert &amp; innere Führung</p>
              <h1 className={styles.heroTitle}>
                Innere Kritiker verwandeln, Selbstwert stabilisieren – für mutige Schritte nach vorn.
              </h1>
              <p className={styles.heroSubtitle}>
                Melavertina begleitet Menschen dabei, sich selbst mit Klarheit, Mitgefühl und neuer Stärke zu begegnen.
                Wir schaffen sichere Räume, in denen innere Stimmen gehört und neu ausgerichtet werden.
              </p>
              <div className={styles.heroActions}>
                <Link to="/termine" className={styles.heroCta}>
                  Kostenfreies Orientierungsgespräch
                </Link>
                <Link to="/methoden" className={styles.heroLink}>
                  Mehr über unsere Methoden
                </Link>
              </div>
            </div>
            <div className={styles.heroVisual}>
              <div className={styles.heroImageWrapper}>
                <img
                  src="https://picsum.photos/1600/900?random=11"
                  alt="Professionelles Coachinggespräch in modernem Raum"
                  loading="lazy"
                />
              </div>
              <div className={styles.heroCard}>
                <span>„Selbstwert ist kein Ziel – es ist eine tägliche Beziehung.“</span>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.heroPattern} aria-hidden="true" />
      </section>

      <section className={styles.aboutIntro}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div>
              <h2>Was Melavertina bewegt</h2>
              <p>
                Wir glauben daran, dass Menschen in jedem Moment Zugang zu inneren Ressourcen haben – auch wenn der innere
                Kritiker gerade sehr laut ist. Unsere Arbeit verbindet systemische Methoden, Embodiment und mitfühlende
                Selbstreflexion.
              </p>
            </div>
            <div className={styles.aboutHighlights}>
              <article>
                <h3>Wertschätzende Tiefe</h3>
                <p>
                  Wir gehen behutsam an die Wurzeln, ohne zu überfordern. Transformation entsteht in gut dosierten Schritten.
                </p>
              </article>
              <article>
                <h3>Verbundenheit &amp; Mut</h3>
                <p>
                  Mit uns trainieren Sie einen inneren Dialog, der Mut stärkt und kritische Anteile in Verbündete verwandelt.
                </p>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Woran Sie unsere Erfahrung erkennen</h2>
            <p>
              Unsere Arbeit basiert auf Vielfalt an Prozessen, Branchen und Menschen. Zahlen zeigen Wirkung, Begegnung schafft
              Vertrauen.
            </p>
          </div>
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statLabel}>{stat.label}</span>
                <span className={styles.statValue}>
                  {statValues[index]}
                  {stat.suffix || ""}
                </span>
                <div className={styles.statBar}>
                  <div
                    className={styles.statProgress}
                    style={{ width: `${Math.min((statValues[index] / stat.target) * 100, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.methods}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>So arbeiten wir mit Selbstwert &amp; innerem Kritiker</h2>
            <p>
              Unsere Methoden verbinden Dialog, somatische Intelligenz und mikrofeine Interventionen. Sie sind flexibel und
              passen sich Ihrem Tempo an.
            </p>
          </div>
          <div className={styles.methodGrid}>
            {methodCards.map((method) => (
              <article key={method.title} className={styles.methodCard}>
                <span className={styles.methodIcon} aria-hidden="true">
                  {method.icon}
                </span>
                <h3>{method.title}</h3>
                <p>{method.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Was Melavertina besonders macht</h2>
            <p>Wir verbinden Tiefe mit Leichtigkeit – und begleiten Sie empathisch, klar und professionell.</p>
          </div>
          <div className={styles.benefitsGrid}>
            <article>
              <h3>Systemisch fundiert</h3>
              <p>Wir arbeiten mit anerkannten Modellen und passen sie an Ihre persönliche Situation an.</p>
            </article>
            <article>
              <h3>Sicherer Raum</h3>
              <p>Sie erleben eine wertschätzende Begleitung, in der alle Gefühle und Fragen Platz haben dürfen.</p>
            </article>
            <article>
              <h3>Alltagstauglich</h3>
              <p>Wir entwickeln gemeinsam Rituale und Reflexionen, die in Ihren Alltag passen und wirken.</p>
            </article>
            <article>
              <h3>Messbare Fortschritte</h3>
              <p>Regelmäßige Reviews helfen, Erfolge sichtbar zu machen und nächste Schritte bewusst zu gestalten.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Unser Prozess: klar, transparent, individuell</h2>
            <p>
              Jeder Weg beginnt mit einem ersten Gespräch. Gemeinsam gestalten wir eine Reise, die Ihrem Rhythmus entspricht.
            </p>
          </div>
          <div className={styles.processTimeline}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processStep}>
                <div className={styles.processNumber}>{index + 1}</div>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Stimmen von Menschen, die wir begleiten durften</h2>
            <p>Alle Rückmeldungen sind anonymisiert und mit Einverständnis geteilt.</p>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.quote}>&ldquo;{testimonials[activeTestimonial].quote}&rdquo;</p>
            <div className={styles.testimonialMeta}>
              <span className={styles.name}>{testimonials[activeTestimonial].name}</span>
              <span className={styles.role}>{testimonials[activeTestimonial].role}</span>
            </div>
            <div className={styles.testimonialControls}>
              <button
                type="button"
                onClick={() =>
                  setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
                }
                aria-label="Vorheriges Testimonial anzeigen"
              >
                ←
              </button>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ""}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Testimonial ${index + 1} auswählen`}
                />
              ))}
              <button
                type="button"
                onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
                aria-label="Nächstes Testimonial anzeigen"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Menschen hinter Melavertina</h2>
            <p>Ein interdisziplinäres Team, das tiefe menschliche Entwicklung mit moderner Organisationsarbeit verbindet.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard} tabIndex={0}>
                <div className={styles.teamImage}>
                  <img src={member.image} alt={`${member.name} – ${member.role}`} loading="lazy" />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Aktuelle Projekte &amp; Formate</h2>
            <p>
              Unsere Angebote passen sich an Ihren Kontext an – ob Einzelbegleitung, Teamprozess oder langfristiges Programm.
            </p>
          </div>
          <div className={styles.filterBar} role="toolbar" aria-label="Projekte filtern">
            {["Alle", "Programme", "Workshops", "Einzelcoaching"].map((filter) => (
              <button
                key={filter}
                type="button"
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterButtonActive : ""}`}
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={`${project.title} Projekt-Visual`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/kontakt" className={styles.projectLink}>
                    Austausch vereinbaren
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Häufige Fragen</h2>
            <p>Antworten auf Fragen, die uns besonders oft gestellt werden.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <article key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={expandedFaq === index}
                  aria-controls={`faq-panel-${index}`}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{expandedFaq === index ? "–" : "+"}</span>
                </button>
                <div
                  id={`faq-panel-${index}`}
                  className={`${styles.faqContent} ${expandedFaq === index ? styles.faqContentOpen : ""}`}
                >
                  <p>{item.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Aktuelle Impulse &amp; Ressourcen</h2>
            <p>Frische Gedanken, Reflexionsfragen und Inspiration rund um Selbstwert und innere Führung.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>
                  Weiterlesen
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Bereit für einen neuen inneren Dialog?</h2>
              <p>
                Lassen Sie uns in einem unverbindlichen Gespräch herausfinden, wie wir Sie begleiten können. Wir freuen uns
                auf Ihre Geschichte.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/termine" className={styles.ctaPrimary}>
                Termin anfragen
              </Link>
              <Link to="/kontakt" className={styles.ctaSecondary}>
                Nachricht schreiben
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;