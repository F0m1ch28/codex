import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Termine.module.css";

const Termine = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Termine &amp; Ablauf | Melavertina</title>
        <meta
          name="description"
          content="Vereinbaren Sie einen Termin mit Melavertina. Erfahren Sie, wie der Ablauf aussieht und welche Optionen für Sie bereitstehen."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Termine &amp; Ablauf</h1>
          <p>
            Wir gestalten jeden Prozess individuell. Im kostenlosen Orientierungsgespräch lernen wir uns kennen, klären Rahmen
            und entscheiden gemeinsam über nächste Schritte.
          </p>
        </div>
      </section>

      <section className={styles.steps}>
        <div className="container">
          <div className={styles.stepGrid}>
            <article>
              <h2>1. Orientierungsgespräch</h2>
              <p>
                Ein 30-minütiger Austausch (online oder telefonisch), in dem wir Ihr Anliegen verstehen, Fragen beantworten und
                den passenden Rahmen definieren.
              </p>
            </article>
            <article>
              <h2>2. Prozessdesign</h2>
              <p>
                Basierend auf Ihren Zielen entwickeln wir einen individuellen Fahrplan – transparent, realistisch und flexibel
                anpassbar.
              </p>
            </article>
            <article>
              <h2>3. Begleitung &amp; Transfer</h2>
              <p>
                Die Begleitung orientiert sich an Ihrem Tempo. Zwischen den Terminen erhalten Sie Impulse, Reflexionen und
                Übungen für den Alltag.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.options}>
        <div className="container">
          <h2>Format-Optionen</h2>
          <div className={styles.optionGrid}>
            <article>
              <h3>Einzelcoaching</h3>
              <p>Online oder in Präsenz, Dauer 60–90 Minuten. Abstände nach Bedarf (meist 2–3 Wochen).</p>
            </article>
            <article>
              <h3>Workshops</h3>
              <p>Halb- oder ganztägige Formate für Teams und Gruppen. Vor- und Nachbereitung inklusive.</p>
            </article>
            <article>
              <h3>Programme</h3>
              <p>Mehrmonatige Lernreisen mit Live-Sessions, digitalen Ressourcen und Peer-Dialogen.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.card}>
            <h2>Termin anfragen</h2>
            <p>
              Schreiben Sie uns eine Nachricht mit Ihrem Anliegen und möglichen Zeitfenstern. Wir melden uns mit Vorschlägen
              zurück.
            </p>
            <ul>
              <li>Orientierungsgespräch: kostenlos &amp; unverbindlich</li>
              <li>Durchführung: online oder vor Ort in Absprache</li>
              <li>Sprachen: Deutsch und auf Wunsch Englisch</li>
            </ul>
            <a className={styles.cta} href="mailto:[Email wird bereitgestellt]">
              Anfrage per E-Mail
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Termine;