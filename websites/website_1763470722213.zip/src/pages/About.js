import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import styles from "./About.module.css";

const values = [
  {
    title: "Menschlichkeit zuerst",
    description:
      "Wir arbeiten mit echten Geschichten, Gefühlen und Bedürfnissen. Jeder Prozess wird mit Empathie, Respekt und Klarheit begleitet."
  },
  {
    title: "Selbstführung stärken",
    description:
      "Unser Ziel ist, Menschen in ihre Selbstwirksamkeit zu führen. Wir unterstützen Sie dabei, Ihren inneren Kompass zu schärfen."
  },
  {
    title: "Ganzheitliche Perspektive",
    description:
      "Wir betrachten Muster, die im Körper, im Denken und in Beziehungen sichtbar werden – und nutzen vielfältige Zugänge zur Veränderung."
  }
];

const milestones = [
  {
    year: "2014",
    title: "Gründung von Melavertina",
    text: "Start als Einzelpraxis mit Fokus auf Selbstwert-Coaching für Frauen in beruflichen Übergängen."
  },
  {
    year: "2017",
    title: "Erweiterung um Teamformate",
    text: "Kooperation mit Organisationen, Einführung von Workshops zu inneren Kritiker:innen und Feedbackkultur."
  },
  {
    year: "2020",
    title: "Online-Angebote & Programme",
    text: "Entwicklung des Selbstwert-Kompass-Programms mit Live-Sessions, Audioübungen und Peer-Learning."
  },
  {
    year: "2023",
    title: "Interdisziplinäres Team",
    text: "Einbindung von Embodiment-Expert:innen, Organisationsberater:innen und kreativen Facilitator:innen."
  }
];

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Über Melavertina | Haltung, Team &amp; Geschichte</title>
        <meta
          name="description"
          content="Lernen Sie Melavertina kennen: Unsere Haltung, unser interdisziplinäres Team und die Meilensteine unserer Arbeit mit Selbstwert und inneren Kritikern."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroEyebrow}>Über uns</span>
            <h1>Wir öffnen Räume für innere Dialoge, die stärken.</h1>
            <p>
              Melavertina steht für professionelle Begleitung, wenn es um Selbstwert, Selbstführung und innere Kritiker:innen
              geht. Wir arbeiten mit Menschen, Teams und Organisationen, die innere Klarheit und authentische Präsenz vertiefen
              möchten.
            </p>
            <Link to="/kontakt" className={styles.heroLink}>
              Austausch starten
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Unsere Haltung</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.approach}>
        <div className="container">
          <div className={styles.approachGrid}>
            <div>
              <h2>Wie wir arbeiten</h2>
              <p>
                Wir verbinden systemisches Coaching, innere-Kind- und Parts-Arbeit, Embodiment sowie Methode aus der
                Selbstmitgefühlsforschung. Wichtig ist uns, dass Prozesse individuell angepasst werden – an Tempo, Tiefe,
                Kontext und Zielsetzung.
              </p>
              <p>
                In jedem Setting schaffen wir einen sicheren Rahmen. Wir arbeiten ressourcenorientiert, lösungsfokussiert und
                mit Blick auf die Beziehung zwischen inneren Anteilen. Der innere Kritiker wird nicht bekämpft, sondern neu
                verstanden.
              </p>
              <Link to="/methoden" className={styles.approachLink}>
                Methoden entdecken
              </Link>
            </div>
            <div className={styles.approachImage}>
              <img
                src="https://picsum.photos/800/600?random=22"
                alt="Arbeitssession mit Fokus auf Selbstreflexion"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className="container">
          <h2>Unsere Meilensteine</h2>
          <div className={styles.timeline}>
            {milestones.map((item) => (
              <article key={item.year}>
                <span>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.philosophy}>
        <div className="container">
          <div className={styles.philosophyInner}>
            <h2>Warum wir innere Kritiker:innen lieben</h2>
            <p>
              Innere Kritiker:innen sind Schutzmechanismen. Sie wollen oft verhindern, dass wir verletzt, abgelehnt oder
              enttäuscht werden. Wir hören ihnen aufmerksam zu und entdecken, welche Qualität dahinter steckt. So entstehen
              Anteile, die uns zukünftig ermutigen statt einschränken.
            </p>
            <ul>
              <li>Innere Anteile werden mit Mitgefühl, Neugier und Respekt angesprochen.</li>
              <li>Wir arbeiten mit Sprache, Körperwahrnehmung und Visualisierung.</li>
              <li>Jede Session endet mit einem konkreten Transfer in den Alltag.</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;