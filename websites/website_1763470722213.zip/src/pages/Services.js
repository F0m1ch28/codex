import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const services = [
  {
    id: "coaching",
    title: "Einzelcoaching",
    summary: "Individuelle Begleitung für Menschen, die ihren Selbstwert stärken und innere Kritiker:innen neu ausrichten wollen.",
    details: [
      "Analyse innerer Anteile & Glaubenssätze",
      "Integration von Selbstmitgefühl und Ressourcenarbeit",
      "Embodiment-Impulse zur Verkörperung neuer Muster",
      "Begleitmaterialien und Transfer-Aufgaben zwischen den Sessions"
    ],
    focus: "Ideal für berufliche Neuorientierung, Selbstführungsfragen oder persönliche Übergänge."
  },
  {
    id: "workshops",
    title: "Workshops & Retreats",
    summary: "Intensive Lernerfahrungen für Teams und Gruppen – vor Ort oder online.",
    details: [
      "Erlebnisorientierte Module zu innerer Kommunikation",
      "Psychologische Sicherheit und Feedbackkultur",
      "Teamrituale für Wertschätzung und Verbindung",
      "Co-kreative Entwicklung individueller Werkzeuge"
    ],
    focus: "Geeignet für Teams in Veränderung, Führungskräftetrainings und Lernreisen."
  },
  {
    id: "programme",
    title: "Programme & Lernreisen",
    summary: "Mehrmonatige Programme mit Live-Sessions, Micro-Impulsen und Peer-Learning.",
    details: [
      "Selbstwert-Kompass: 12-wöchige Coachingreise",
      "Hybrid-Formate mit Live-Calls, Audioübungen, Reflexionsjournal",
      "Peer-Gruppen und Buddy-Formate für nachhaltige Verankerung",
      "Messbare Entwicklung durch regelmäßige Resonanzschleifen"
    ],
    focus: "Ideal für Organisationen, die langfristig in Selbstführung investieren."
  },
  {
    id: "sparring",
    title: "Mentorings & Sparring",
    summary: "Kurzformate für Entscheider:innen, die schnellen klaren Input wünschen.",
    details: [
      "Reflexion akuter Situationen",
      "Schnelle Perspektivwechsel und Priorisierung",
      "Handlungsspielräume und nächste Schritte klären",
      "Optional: Shadowing in Meetings"
    ],
    focus: "Für Menschen mit hohem Verantwortungsbereich, die innere Klarheit wünschen."
  }
];

const Services = () => {
  const [activeService, setActiveService] = useState(services[0]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Methoden &amp; Angebote | Melavertina</title>
        <meta
          name="description"
          content="Entdecken Sie die Methoden und Angebote von Melavertina: Einzelcoachings, Workshops, Lernreisen und Sparring rund um Selbstwert & innere Kritiker:innen."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Methoden &amp; Angebote</h1>
          <p>
            Jede Begleitung wird individuell konzipiert. Wir verbinden bewährte Coachingmethoden mit Embodiment, Inner-Parts-Work
            und transferorientierten Tools. Unsere Angebote reichen von Einzelcoachings bis zu Organisationsprogrammen.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.tabList} role="tablist" aria-label="Leistungsbereiche">
            {services.map((service) => (
              <button
                key={service.id}
                type="button"
                role="tab"
                aria-selected={activeService.id === service.id}
                className={`${styles.tabButton} ${
                  activeService.id === service.id ? styles.tabButtonActive : ""
                }`}
                onClick={() => setActiveService(service)}
              >
                {service.title}
              </button>
            ))}
          </div>
          <div className={styles.serviceDetail} role="tabpanel">
            <div>
              <h2>{activeService.title}</h2>
              <p className={styles.summary}>{activeService.summary}</p>
              <ul>
                {activeService.details.map((detail) => (
                  <li key={detail}>{detail}</li>
                ))}
              </ul>
              <div className={styles.focus}>
                <strong>Schwerpunkt:</strong> {activeService.focus}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;