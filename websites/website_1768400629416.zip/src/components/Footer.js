import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const quickLinks = [
    { path: '/', label: 'Головна' },
    { path: '/dogs', label: 'Знайдені собаки' },
    { path: '/adoption', label: 'Шукають дім' },
    { path: '/help', label: 'Як допомогти' },
    { path: '/about', label: 'Про проект' },
    { path: '/contact', label: 'Контакти' }
  ];

  const policies = [
    { path: '/terms', label: 'Умови використання' },
    { path: '/privacy', label: 'Політика конфіденційності' },
    { path: '/cookie-policy', label: 'Політика cookie' }
  ];

  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-column footer-column--brand">
          <Link to="/" className="footer-logo">
            <span className="logo__mark">🐾</span>
            <span className="logo__text">Пес Шукач</span>
          </Link>
          <p className="footer-description">
            Благодійна ініціатива, яка об’єднує волонтерів по всій Індонезії, щоб кожен пес відчув турботу, дім і любов.
          </p>
          <div className="footer-social">
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook Пес Шукач"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M22 12a10 10 0 1 0-11.5 9.9v-7H8v-3h2.5V9.5c0-2.5 1.5-3.9 3.7-3.9 1.1 0 2.2.2 2.2.2v2.4h-1.2c-1.2 0-1.6.8-1.6 1.6V11H16l-.4 3h-2v7A10 10 0 0 0 22 12z" />
              </svg>
            </a>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram Пес Шукач"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M7 2C4.2 2 2 4.2 2 7v10c0 2.8 2.2 5 5 5h10c2.8 0 5-2.2 5-5V7c0-2.8-2.2-5-5-5H7zm13 5v10c0 1.7-1.3 3-3 3H7c-1.7 0-3-1.3-3-3V7c0-1.7 1.3-3 3-3h10c1.7 0 3 1.3 3 3zm-3.8-.9a1.1 1.1 0 1 0 0 2.2 1.1 1.1 0 0 0 0-2.2zM12 8.2A3.8 3.8 0 1 0 12 15.8 3.8 3.8 0 0 0 12 8.2z" />
              </svg>
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube Пес Шукач"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M21.6 7.2s-.2-1.5-.8-2.1c-.7-.8-1.5-.8-1.8-.8C16 4 12 4 12 4h0s-4 0-7 .3c-.3 0-1.1 0-1.8.8-.6.6-.8 2.1-.8 2.1S2 8.9 2 10.6v1.6c0 1.7.2 3.4.2 3.4s.2 1.5.8 2.1c.7.7 1.7.7 2.1.8 1.5.1 7 .3 7 .3s4 0 7-.3c.3 0 1.1 0 1.8-.8.6-.6.8-2.1.8-2.1s.2-1.7.2-3.4v-1.6c0-1.7-.2-3.4-.2-3.4zM10 14.7V8.9l5.2 2.9L10 14.7z" />
              </svg>
            </a>
          </div>
        </div>
        <div className="footer-column">
          <h3 className="footer-heading">Навігація</h3>
          <ul className="footer-links">
            {quickLinks.map((item) => (
              <li key={item.path}>
                <Link to={item.path}>{item.label}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="footer-column">
          <h3 className="footer-heading">Контакти</h3>
          <address className="footer-address">
            <p>Jl. Kebon Sirih No. 123</p>
            <p>Jakarta Pusat, DKI Jakarta, Indonesia</p>
          </address>
          <p>
            Телефон:{' '}
            <Link to="/contact" className="footer-contact-link">
              +62 21 1234 5678
            </Link>
          </p>
          <p>
            Email:{' '}
            <Link to="/contact" className="footer-contact-link">
              help@dogfinder-indonesia.org
            </Link>
          </p>
        </div>
        <div className="footer-column">
          <h3 className="footer-heading">Політики</h3>
          <ul className="footer-links">
            {policies.map((item) => (
              <li key={item.path}>
                <Link to={item.path}>{item.label}</Link>
              </li>
            ))}
          </ul>
          <p className="footer-callout">
            Ми дбаємо про безпеку ваших даних і відкрито ділимося правилами взаємодії.
          </p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Пес Шукач. Разом повертаємо хвости додому.</p>
      </div>
    </footer>
  );
};

export default Footer;