import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      const consent = localStorage.getItem('dogfinder_cookie_consent');
      if (!consent) {
        setVisible(true);
      }
    } catch (error) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem('dogfinder_cookie_consent', 'accepted');
    } catch (error) {
      // Ignore storage errors silently
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <p>
          Ми використовуємо файли cookie, щоб сайт працював стабільно та допомагав швидше знаходити собак. Продовжуючи користування, ви погоджуєтесь із{' '}
          <a href="/cookie-policy">політикою cookie</a>.
        </p>
      </div>
      <button type="button" className="cta-button cookie-banner__button" onClick={handleAccept}>
        Прийняти
      </button>
    </div>
  );
};

export default CookieBanner;