import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 1024) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const navItems = [
    { path: '/', label: 'Головна' },
    { path: '/dogs', label: 'Знайдені собаки' },
    { path: '/adoption', label: 'Шукають дім' },
    { path: '/help', label: 'Як допомогти' },
    { path: '/about', label: 'Про проект' },
    { path: '/contact', label: 'Контакти' }
  ];

  return (
    <header className={"site-header ${menuOpen ? 'site-header--open' : ''}"}>
      <div className="container header-container">
        <Link to="/" className="logo" onClick={closeMenu}>
          <span className="logo__mark">🐾</span>
          <span className="logo__text">Пес Шукач</span>
        </Link>
        <nav
          className={"main-nav ${menuOpen ? 'main-nav--visible' : ''}"}
          aria-label="Головна навігація"
          id="site-navigation"
        >
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                "nav-link ${isActive ? 'nav-link--active' : ''}"
              }
              onClick={closeMenu}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <Link to="/contact" className="cta-button header-cta" onClick={closeMenu}>
          Повідомити про собаку
        </Link>
        <button
          className={"menu-toggle ${menuOpen ? 'menu-toggle--open' : ''}"}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="site-navigation"
          aria-label="Відкрити головне меню"
        >
          <span className="menu-toggle__bar" />
          <span className="menu-toggle__bar" />
          <span className="menu-toggle__bar" />
        </button>
      </div>
    </header>
  );
};

export default Header;