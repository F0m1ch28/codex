import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

const updateMeta = (title, description) => {
  document.title = title;
  let tag = document.querySelector('meta[name="description"]');
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute('name', 'description');
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', description);
};

const ThankYou = () => {
  const location = useLocation();
  const visitorName = location.state?.name || 'друже';

  useEffect(() => {
    updateMeta(
      'Дякуємо за повідомлення | Пес Шукач',
      'Команда Пес Шукач вдячна за вашу небайдужість. Ми вже працюємо над вашим зверненням.'
    );
  }, []);

  return (
    <section className="page thank-you-page">
      <div className="container narrow">
        <h1 className="page-title">Дякуємо, {visitorName}!</h1>
        <p className="page-subtitle">
          Ваше повідомлення надійшло до координаторів. Ми зв’яжемося з вами найближчим часом, щоб уточнити деталі та організувати допомогу.
        </p>
        <div className="thank-you-actions">
          <Link to="/dogs" className="cta-button">
            Переглянути знайдених собак
          </Link>
          <Link to="/" className="cta-inline">
            Повернутися на головну →
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ThankYou;