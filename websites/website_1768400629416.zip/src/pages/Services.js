import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const setMeta = (title, description, keywords) => {
  document.title = title;
  const ensure = (name, content) => {
    if (!content) return;
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensure('description', description);
  ensure('keywords', keywords);
};

const Services = () => {
  useEffect(() => {
    setMeta(
      'Як допомогти | Пес Шукач',
      'Дізнайтеся, як можна долучитися до проекту Пес Шукач: волонтерство, перетримка, пожертви та інформаційна підтримка.',
      'волонтерство, допомога собакам, пожертви, Пес Шукач'
    );
  }, []);

  const helpOptions = [
    {
      title: 'Станьте волонтером-рятувальником',
      text: 'Отримуйте сповіщення про знахідки у вашому районі, допомагайте евакуювати собак у безпечне місце.',
      action: 'Заповнити анкету волонтера'
    },
    {
      title: 'Перетримка в родині',
      text: 'Візьміть собаку на тимчасовий догляд: ми забезпечимо корм, ліки та постійний зв’язок із ветеринаром.',
      action: 'Долучитися до перетримки'
    },
    {
      title: 'Фінансова підтримка',
      text: 'Завдяки пожертвам ми оплачуємо лікування, стерилізацію та транспортування. Будь-яка сума важлива.',
      action: 'Підтримати фінансово'
    },
    {
      title: 'Інформаційна допомога',
      text: 'Поширюйте наші пости, долучайте бізнес-партнерів, організовуйте заходи у своїх громадах.',
      action: 'Стати амбасадором'
    }
  ];

  const processSteps = [
    'Отримуєте від нас короткий тренінг та інструкції безпеки.',
    'Долучаєтесь до чат-групи вашого району й отримуєте завдання.',
    'Звітуєте про кожен крок, щоб команда могла координувати наступні дії.',
    'Отримуєте подяку, нових друзів і найважливіше — врятовані життя.'
  ];

  return (
    <section className="page services-page">
      <div className="container narrow">
        <header className="page-header">
          <h1 className="page-title">Як ви можете допомогти</h1>
          <p className="page-subtitle">
            У нас сотні собак щомісяця, і кожен може зробити свій внесок: час, простір, експертиза або голос у соціальних мережах. Оберіть формат, який відгукується саме вам.
          </p>
        </header>

        <section className="service-showcase">
          <div className="service-grid">
            {helpOptions.map((option) => (
              <article className="service-card service-card--accent" key={option.title}>
                <h2 className="service-card__title">{option.title}</h2>
                <p className="service-card__text">{option.text}</p>
                <span className="service-card__action">{option.action}</span>
              </article>
            ))}
          </div>
        </section>

        <section className="service-process">
          <h2>Ваш шлях волонтера</h2>
          <ol className="process-list">
            {processSteps.map((step, index) => (
              <li key={step}>
                <span className="process-number">{index + 1}</span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </section>

        <section className="service-cta">
          <h2>Готові зробити перший крок?</h2>
          <p>
            Напишіть нам коротко про свій досвід і можливості. Ми зв’яжемося протягом 24 годин і допоможемо обрати найкращий формат підтримки.
          </p>
          <Link to="/contact" className="cta-button">
            Зв’язатися з координатором
          </Link>
        </section>
      </div>
    </section>
  );
};

export default Services;