import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const updateMeta = (title, description, keywords) => {
  document.title = title;
  const applyMeta = (name, content) => {
    if (!content) return;
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  applyMeta('description', description);
  applyMeta('keywords', keywords);
};

const Home = () => {
  useEffect(() => {
    updateMeta(
      'Пес Шукач — Пошук бездомних собак в Індонезії',
      'Платформа волонтерів та небайдужих людей, які допомагають знайти бездомних собак в Індонезії та подарувати їм дім.',
      'Пес Шукач, бездомні собаки Індонезія, знайдені собаки, усиновлення собак, волонтерство, Dog Finder Indonesia'
    );
  }, []);

  const stats = [
    { number: '1 240+', label: 'знайдених собак за останній рік' },
    { number: '530', label: 'щасливих усиновлень' },
    { number: '210', label: 'активних волонтерів по регіонах' },
    { number: '85', label: 'партнерських притулків Індонезії' }
  ];

  const recentDogs = [
    {
      name: 'Ріа',
      region: 'Суракарта, Центральна Ява',
      date: '10 березня 2024',
      note: 'Знайдена біля ринку. Має червоний нашийник.',
      image: 'https://images.unsplash.com/photo-1596492784531-6e6eb5ea9999?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Дені',
      region: 'Джімбаран, Балі',
      date: '8 березня 2024',
      note: 'Доброзичливий пес, реагує на ім’я. Пес у гарному стані.',
      image: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Міра',
      region: 'Бандунг, Західна Ява',
      date: '6 березня 2024',
      note: 'Молода сука, можливо, загубилася під час грози.',
      image: 'https://images.unsplash.com/photo-1505628346881-b72b27e84530?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Арон',
      region: 'Манадо, Північне Сулавесі',
      date: '3 березня 2024',
      note: 'Потребує лікування шкіри, дуже лагідний.',
      image: 'https://images.unsplash.com/photo-1548191265-cc70d3d45ba1?auto=format&fit=crop&w=900&q=80'
    }
  ];

  const urgentDogs = [
    {
      name: 'Соня',
      reason: 'потребує операції після травми',
      location: 'Сурабая, Ява',
      image: 'https://images.unsplash.com/photo-1568571780765-9276ac8b75a1?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Гіланг',
      reason: 'волонтери шукають тимчасовий притулок',
      location: 'Ягякарта, Ява',
      image: 'https://images.unsplash.com/photo-1508948956644-0017e845d797?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Біма',
      reason: 'необхідна термінова вакцинація та харчування',
      location: 'Пеканбару, Суматра',
      image: 'https://images.unsplash.com/photo-1558944351-dae1beaaea1c?auto=format&fit=crop&w=900&q=80'
    }
  ];

  const steps = [
    {
      number: '01',
      title: 'Знаходимо собаку',
      text: 'Отримуємо повідомлення від небайдужих людей або координаторів у громадах.'
    },
    {
      number: '02',
      title: 'Розміщуємо інформацію',
      text: 'Публікуємо опис, фото та геолокацію, щоб прискорити пошук власників.'
    },
    {
      number: '03',
      title: 'Шукаємо тимчасовий дім',
      text: 'Волонтери узгоджують логістику та догляд до повернення власникам або усиновлення.'
    },
    {
      number: '04',
      title: 'Знаходимо родину',
      text: 'Перевіряємо майбутніх опікунів, супроводжуємо адаптацію та медичний догляд.'
    }
  ];

  const stories = [
    {
      id: 1,
      name: 'Люсі',
      before: 'https://images.unsplash.com/photo-1521302080334-4bebac276888?auto=format&fit=crop&w=800&q=80',
      after: 'https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=800&q=80',
      text: 'Її знайшли на околиці Джакарти. Після лікування Люсі оселилася у великій родині з дітьми і зараз охороняє їхній дім.'
    },
    {
      id: 2,
      name: 'Джоя',
      before: 'https://images.unsplash.com/photo-1489084917528-a57e68a79a1e?auto=format&fit=crop&w=800&q=80',
      after: 'https://images.unsplash.com/photo-1477973770766-6228305816df?auto=format&fit=crop&w=800&q=80',
      text: 'Джоя довго боялася людей, але терплячий волонтер у Чанзі повернув їй довіру. Сьогодні вона бігає пляжем разом із новими господарями.'
    },
    {
      id: 3,
      name: 'Таро',
      before: 'https://images.unsplash.com/photo-1417559322007-3a26c5a140d4?auto=format&fit=crop&w=800&q=80',
      after: 'https://images.unsplash.com/photo-1505628346881-b72b27e84530?auto=format&fit=crop&w=800&q=80',
      text: 'Таро потрапив у притулок у Балі весь у колючках. Після відновлення він поїхав жити до серфера з Кути й тепер супроводжує його в усіх подорожах.'
    }
  ];

  const homeSupports = [
    {
      title: 'Пошук та ідентифікація',
      text: 'Використовуємо соціальні мережі, спільноти районів та базу, щоб порівнювати анкети й знахідки.'
    },
    {
      title: 'Медична допомога',
      text: 'Партнерські клініки надають знижки або безкоштовне лікування для невідкладних випадків.'
    },
    {
      title: 'Перетримка в сім’ях',
      text: 'Волонтери забезпечують тимчасовий дім, поки пес шукає свою родину або готується до усиновлення.'
    },
    {
      title: 'Освітні програми',
      text: 'Навчаємо громади гуманного ставлення до тварин, стерилізації та відповідального утримання.'
    }
  ];

  const testimonials = [
    {
      name: 'Аніта, волонтерка з Джакарти',
      quote:
        '“Пес Шукач” дарує відчуття спільноти. Ми завжди знаємо, що робити і як допомогти, а комунікація з командою миттєва.',
      avatar: 'https://images.unsplash.com/photo-1520813792240-56fc4a3765a7?auto=format&fit=crop&w=200&q=80'
    },
    {
      name: 'Ріко, ветеринар з Бандунга',
      quote:
        'Наша клініка співпрацює з проектом вже два роки. Завдяки злагодженій роботі багато тварин повернулися додому здоровими.',
      avatar: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80'
    },
    {
      name: 'Сара і Джулі, нова родина Руми',
      quote:
        'Ми відчули підтримку на кожному етапі усиновлення. Команда пояснила все про догляд і навіть допомогла з адаптацією.',
      avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80'
    }
  ];

  return (
    <div className="home-page">
      <section
        className="hero"
        style={{
          backgroundImage:
            'linear-gradient(rgba(93,64,55,0.65), rgba(93,64,55,0.75)), url(https://images.unsplash.com/photo-1518378188025-22bd89516ee2?auto=format&fit=crop&w=1600&q=80)'
        }}
      >
        <div className="container hero-content">
          <h1 className="hero-title">
            Допоможемо знайти дім кожному бездомному псу в Індонезії
          </h1>
          <p className="hero-subtitle">
            Ми об’єднуємо волонтерів, ветеринарів та людей, які піклуються про тварин, щоб жоден пес не залишився самотнім. Долучайтеся — кожна дія має вагу.
          </p>
          <div className="hero-actions">
            <Link to="/dogs" className="cta-button cta-button--light">
              Знайти собаку
            </Link>
            <Link to="/help" className="cta-button cta-button--outline">
              Як допомогти?
            </Link>
          </div>
        </div>
      </section>

      <section className="stats" aria-label="Статистика проекту">
        <div className="container stats-grid">
          {stats.map((item) => (
            <div className="stat-card" key={item.label}>
              <span className="stat-card__number">{item.number}</span>
              <span className="stat-card__label">{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="recently-found" id="recently-found">
        <div className="container section-heading">
          <h2 className="section-title">Останні знайдені хвостики</h2>
          <p className="section-subtitle">
            Щодня до нас надходять повідомлення з різних куточків країни. Допоможіть розповсюдити інформацію або впізнайте свого друга.
          </p>
        </div>
        <div className="container card-grid">
          {recentDogs.map((dog) => (
            <article className="dog-card" key={dog.name}>
              <div className="dog-card__image-wrapper">
                <img
                  src={dog.image}
                  alt={"Собака ${dog.name} із регіону ${dog.region}"}
                  className="dog-card__image"
                  loading="lazy"
                />
              </div>
              <div className="dog-card__body">
                <h3 className="dog-card__name">{dog.name}</h3>
                <p className="dog-card__region">{dog.region}</p>
                <p className="dog-card__date">
                  <strong>Дата знаходження:</strong> {dog.date}
                </p>
                <p className="dog-card__note">{dog.note}</p>
              </div>
            </article>
          ))}
        </div>
        <div className="container section-footer">
          <Link to="/dogs" className="cta-inline">
            Переглянути всі знайдені →
          </Link>
        </div>
      </section>

      <section className="urgent-adoption">
        <div className="container section-heading">
          <h2 className="section-title section-title--accent">
            Терміново шукають дім
          </h2>
          <p className="section-subtitle">
            Цим собакам потрібна допомога просто зараз — лікування, теплий кут або назавжди любляча родина.
          </p>
        </div>
        <div className="container urgent-grid">
          {urgentDogs.map((dog) => (
            <article className="urgent-card" key={dog.name}>
              <div className="urgent-card__image-wrapper">
                <img
                  src={dog.image}
                  alt={"Собака ${dog.name} потребує допомоги"}
                  className="urgent-card__image"
                  loading="lazy"
                />
              </div>
              <div className="urgent-card__body">
                <h3 className="urgent-card__name">{dog.name}</h3>
                <p className="urgent-card__reason">{dog.reason}</p>
                <p className="urgent-card__location">{dog.location}</p>
                <Link to="/adoption" className="cta-inline">
                  Дізнатися деталі →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="how-it-works" aria-label="Як працює Пес Шукач">
        <div className="container section-heading">
          <h2 className="section-title">Як ми працюємо</h2>
          <p className="section-subtitle">
            Чіткі кроки, прозорі процеси та постійний зв’язок із волонтерами. Кожна хвилина важлива.
          </p>
        </div>
        <div className="container steps-grid">
          {steps.map((step) => (
            <article className="step-card" key={step.number}>
              <span className="step-card__number">{step.number}</span>
              <h3 className="step-card__title">{step.title}</h3>
              <p className="step-card__text">{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="support-services">
        <div className="container section-heading">
          <h2 className="section-title">Що ми забезпечуємо</h2>
          <p className="section-subtitle">
            Наш сервіс охоплює увесь шлях собаки — від першого повідомлення до щасливого хвоста, який махає в новій родині.
          </p>
        </div>
        <div className="container service-grid">
          {homeSupports.map((item) => (
            <article className="service-card" key={item.title}>
              <h3 className="service-card__title">{item.title}</h3>
              <p className="service-card__text">{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="success-stories" aria-label="Історії успіху">
        <div className="container section-heading">
          <h2 className="section-title section-title--accent">Історії, що надихають</h2>
          <p className="section-subtitle">
            Кожна світлина — доказ того, що небайдужість працює. Дякуємо кожному, хто був поруч.
          </p>
        </div>
        <div className="container story-grid">
          {stories.map((story) => (
            <article className="story-card" key={story.id}>
              <div className="story-card__gallery">
                <figure>
                  <img src={story.before} alt={"Собака ${story.name} до допомоги"} loading="lazy" />
                  <figcaption>До</figcaption>
                </figure>
                <figure>
                  <img src={story.after} alt={"Собака ${story.name} після усиновлення"} loading="lazy" />
                  <figcaption>Після</figcaption>
                </figure>
              </div>
              <div className="story-card__body">
                <h3 className="story-card__name">{story.name}</h3>
                <p>{story.text}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="testimonials" aria-label="Відгуки про проект">
        <div className="container section-heading">
          <h2 className="section-title">Волонтери та родини про нас</h2>
          <p className="section-subtitle">
            Ці слова — наша мотивація працювати ще активніше та розвивати спільноту підтримки.
          </p>
        </div>
        <div className="container testimonial-grid">
          {testimonials.map((testimonial) => (
            <figure className="testimonial-card" key={testimonial.name}>
              <img
                src={testimonial.avatar}
                alt={"Портрет ${testimonial.name}"}
                className="testimonial-card__avatar"
                loading="lazy"
              />
              <blockquote className="testimonial-card__quote">{testimonial.quote}</blockquote>
              <figcaption className="testimonial-card__name">{testimonial.name}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="cta-block">
        <div className="container cta-block__content">
          <h2>Бачили собаку, якій потрібна допомога?</h2>
          <p>
            Залиште нам повідомлення, додайте геолокацію та фото. Ми зв’яжемося з найближчими волонтерами вже за кілька хвилин.
          </p>
          <Link to="/contact" className="cta-button cta-button--light">
            Повідомити прямо зараз
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;