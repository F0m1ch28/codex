import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const setMetaInfo = (title, description, keywords) => {
  document.title = title;
  const adjust = (name, content) => {
    if (!content) return;
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  adjust('description', description);
  adjust('keywords', keywords);
};

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    setMetaInfo(
      'Контакти | Пес Шукач',
      'Зв’яжіться з командою проекту Пес Шукач: контакти координаторів, форма для повідомлення про знайдену або загублену собаку.',
      'контакти Пес Шукач, повідомити про собаку, допомога бездомним собакам'
    );
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) {
      currentErrors.name = 'Вкажіть своє ім’я, щоб ми знали, як до вас звертатися.';
    }
    if (!formData.email.trim()) {
      currentErrors.email = 'Будь ласка, залиште email для зворотного зв’язку.';
    } else {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(formData.email.trim())) {
        currentErrors.email = 'Перевірте правильність введення email.';
      }
    }
    if (!formData.message.trim() || formData.message.trim().length < 20) {
      currentErrors.message = 'Опишіть ситуацію детальніше (мінімум 20 символів).';
    }
    return currentErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    navigate('/thank-you', { state: { name: formData.name } });
  };

  return (
    <section className="page contact-page">
      <div className="container contact-grid">
        <div className="contact-info">
          <h1 className="page-title">Зв’яжіться з нами</h1>
          <p className="page-subtitle">
            Повідомте про знайдену собаку, уточніть деталі усиновлення або дізнайтеся, як стати волонтером. Ми відповідаємо протягом робочого дня.
          </p>
          <div className="contact-details">
            <h2>Координаційний центр</h2>
            <p>Jl. Kebon Sirih No. 123</p>
            <p>Jakarta Pusat, DKI Jakarta, Indonesia</p>
            <p>Телефон: +62 21 1234 5678</p>
            <p>Email: help@dogfinder-indonesia.org</p>
          </div>
          <div className="contact-hours">
            <h3>Графік роботи</h3>
            <p>Понеділок — субота: 08:00 – 20:00</p>
            <p>Неділя: черговий координатор у чаті</p>
          </div>
        </div>

        <form className="contact-form" onSubmit={handleSubmit} noValidate>
          <fieldset>
            <legend>Форма повідомлення</legend>
            <label htmlFor="name">Ваше ім’я</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
              placeholder="Напишіть, будь ласка, ваше ім’я"
              required
            />
            {errors.name && (
              <span className="form-error" id="name-error">
                {errors.name}
              </span>
            )}

            <label htmlFor="email">Електронна пошта</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
              placeholder="email@example.com"
              required
            />
            {errors.email && (
              <span className="form-error" id="email-error">
                {errors.email}
              </span>
            )}

            <label htmlFor="message">Повідомлення</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
              placeholder="Де бачили собаку, як вона виглядала, чи потрібна негайна допомога?"
              required
            />
            {errors.message && (
              <span className="form-error" id="message-error">
                {errors.message}
              </span>
            )}

            <button type="submit" className="cta-button contact-submit">
              Надіслати
            </button>
          </fieldset>
        </form>
      </div>

      <div className="container map-wrapper">
        <iframe
          title="Карта офісу Пес Шукач"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.689946570043!2d106.82198797605539!3d-6.208763293779526!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5c4f233d56f%3A0x4ac31fbc0de5e40f!2sJl.%20Kebon%20Sirih%20No.123%2C%20RT.2%2FRW.1%2C%20Kebon%20Sirih%2C%20Kec.%20Menteng%2C%20Kota%20Jakarta%20Pusat%2C%20Daerah%20Khusus%20Ibukota%20Jakarta%2010350%2C%20Indonesia!5e0!3m2!1sen!2sid!4v1710110000000!5m2!1sen!2sid"
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </section>
  );
};

export default Contact;