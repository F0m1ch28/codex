import React, { useEffect } from 'react';

const applyMeta = (title, description, keywords) => {
  document.title = title;
  const ensureMeta = (name, content) => {
    if (!content) return;
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const About = () => {
  useEffect(() => {
    applyMeta(
      'Про проект Пес Шукач | Dog Finder Indonesia',
      'Дізнайтеся про місію, команду та волонтерів проекту Пес Шукач. Разом ми допомагаємо бездомним собакам по всій Індонезії.',
      'місія проекту Пес Шукач, команда волонтерів, допомога бездомним собакам Індонезія'
    );
  }, []);

  const teamMembers = [
    {
      name: 'Надя Прамудья',
      role: 'Засновниця, координаторка волонтерів',
      bio: 'Запустила ініціативу у 2018 році після власного досвіду пошуку загубленого пса. Відповідає за тренінги для кураторів.',
      image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=800&q=80'
    },
    {
      name: 'Йос Батара',
      role: 'Логістика та партнерства',
      bio: 'Будує мережу притулків і клінік, що співпрацюють із проектом. Організовує перевезення та тимчасові сім’ї.',
      image: 'https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?auto=format&fit=crop&w=800&q=80'
    },
    {
      name: 'Марія Лестарі',
      role: 'Комунікації та медіа',
      bio: 'Веде інформаційні кампанії, відповідає за соцмережі, збір історій та прозорі звіти.',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=800&q=80'
    }
  ];

  const values = [
    {
      title: 'Гуманність понад усе',
      text: 'Ми ставимо благополуччя собаки в центр кожного рішення — від евакуації до усиновлення.'
    },
    {
      title: 'Прозорість і довіра',
      text: 'Регулярно звітуємо про витрати та результати, ділимося даними з волонтерами та партнерами.'
    },
    {
      title: 'Освітня місія',
      text: 'Допомога бездомним тваринам починається із просвіти. Ми проводимо семінари у школах, громадах і бізнесі.'
    }
  ];

  return (
    <section className="page about-page">
      <div className="container narrow">
        <header className="page-header">
          <h1 className="page-title">Про проект «Пес Шукач»</h1>
          <p className="page-subtitle">
            Ми народилися як локальна спільнота в Джакарті, але сьогодні нас знають у кожній провінції. Наше завдання — повернути загублених собак додому і створити систему відповідального усиновлення.
          </p>
        </header>

        <section className="about-section">
          <h2>Наша історія</h2>
          <p>
            Все почалося з невеликої групи волонтерів, які домовилися координувати пошук загублених собак в месенджері. Крок за кроком ми створили спільну базу даних, мапу волонтерів та чат-підтримку. Зараз «Пес Шукач» — це десятки локальних координаційних центрів, офлайн-тренінги для волонтерів і розвинена мережа партнерських клінік.
          </p>
          <p>
            Ми віримо у силу співпраці: сусіди, ветеринари, притулки, місцевий бізнес — усі можуть долучитися та врятувати життя. Кожна собака — це історія, і ми хочемо, щоб вона завершилася щасливо.
          </p>
        </section>

        <section className="about-values">
          <h2>Наші принципи</h2>
          <div className="value-grid">
            {values.map((value) => (
              <article className="value-card" key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="about-team">
          <h2>Команда координаторів</h2>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <article className="team-card" key={member.name}>
                <img src={member.image} alt={"Координатор ${member.name}"} loading="lazy" />
                <div className="team-card__body">
                  <h3>{member.name}</h3>
                  <span className="team-card__role">{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="about-impact">
          <h2>Що робимо щодня</h2>
          <ul className="impact-list">
            <li>Створюємо перевірені анкети для пошуку власників та усиновлення.</li>
            <li>Координуємо виїзди волонтерів та партнерських ветеринарів на місце події.</li>
            <li>Організовуємо тимчасову перетримку, забезпечуємо харчування та медикаменти.</li>
            <li>Проводимо інформаційні кампанії про стерилізацію та відповідальне утримання тварин.</li>
          </ul>
        </section>
      </div>
    </section>
  );
};

export default About;