import React, { useEffect } from 'react';

const setMeta = (title, description) => {
  document.title = title;
  let tag = document.querySelector('meta[name="description"]');
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute('name', 'description');
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', description);
};

const PrivacyPolicy = () => {
  useEffect(() => {
    setMeta(
      'Політика конфіденційності | Пес Шукач',
      'Дізнайтеся, як проект Пес Шукач збирає, зберігає та використовує персональні дані користувачів.'
    );
  }, []);

  return (
    <section className="page legal-page">
      <div className="container narrow">
        <h1 className="page-title">Політика конфіденційності</h1>
        <p className="page-subtitle">Останнє оновлення: 15 березня 2024 року</p>

        <h2>1. Які дані ми збираємо</h2>
        <p>
          Ми отримуємо лише ті дані, які ви добровільно надаєте, заповнюючи форми: ім’я, email, опис ситуації. Також зберігаємо технічні дані (IP-адресу, тип пристрою) для безпеки.
        </p>

        <h2>2. Як ми використовуємо дані</h2>
        <ul className="legal-list">
          <li>Щоб координувати волонтерів і швидко реагувати на запити про допомогу.</li>
          <li>Для зв’язку з вами з уточненнями або повідомленням про результати.</li>
          <li>Для аналітики, яка допомагає покращувати роботу платформи.</li>
        </ul>

        <h2>3. Зберігання та захист</h2>
        <p>
          Дані зберігаються в захищених сервісах з обмеженим доступом. Ми регулярно оновлюємо паролі та використовуємо двофакторну автентифікацію.
        </p>

        <h2>4. Права користувачів</h2>
        <p>
          Ви маєте право запитати копію даних, виправити їх або видалити. Напишіть нам на help@dogfinder-indonesia.org із темою «Запит на персональні дані».
        </p>
      </div>
    </section>
  );
};

export default PrivacyPolicy;