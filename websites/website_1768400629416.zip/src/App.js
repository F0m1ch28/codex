import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import TermsOfService, { CookiePolicy } from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';

const updateMetaTag = (name, content) => {
  if (!content) return;
  let element = document.querySelector("meta[name="${name}"]");
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute('name', name);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
};

const DogsPage = () => {
  const [selectedRegion, setSelectedRegion] = useState('Усі регіони');

  useEffect(() => {
    document.title = 'Знайдені собаки | Пес Шукач';
    updateMetaTag(
      'description',
      'Актуальний каталог знайдених бездомних собак по всій Індонезії. Перегляньте, чи не шукає вас ваш чотирилапий друг.'
    );
    updateMetaTag(
      'keywords',
      'знайдені собаки, пошук собак, бездомні собаки Індонезія, волонтерство'
    );
  }, []);

  const dogsData = [
    {
      id: 1,
      name: 'Луна',
      region: 'Джакарта, Ява',
      status: 'шукаємо власників',
      foundDate: '12 березня 2024',
      characteristics: 'Дуже соціальна, реагує на команди англійською.',
      island: 'Ява',
      image: 'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?auto=format&fit=crop&w=900&q=80'
    },
    {
      id: 2,
      name: 'Балі',
      region: 'Убуд, Балі',
      status: 'на перетримці',
      foundDate: '5 березня 2024',
      characteristics: 'Молода сука, потребує лікування лапи.',
      island: 'Балі',
      image: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?auto=format&fit=crop&w=900&q=80'
    },
    {
      id: 3,
      name: 'Джек',
      region: 'Медан, Суматра',
      status: 'волонтери шукають власників',
      foundDate: '1 березня 2024',
      characteristics: 'Спокійний пес середнього розміру, кастрований.',
      island: 'Суматра',
      image: 'https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=900&q=80'
    },
    {
      id: 4,
      name: 'Коко',
      region: 'Макасар, Сулавесі',
      status: 'потрібен тимчасовий дім',
      foundDate: '27 лютого 2024',
      characteristics: 'Енергійний, любить дітей, потребує щеплень.',
      island: 'Сулавесі',
      image: 'https://images.unsplash.com/photo-1562183241-b937e95585b6?auto=format&fit=crop&w=900&q=80'
    },
    {
      id: 5,
      name: 'Рума',
      region: 'Ломбок',
      status: 'очікує зустрічі з родиною',
      foundDate: '21 лютого 2024',
      characteristics: 'Має нашийник з гравіюванням, дуже ласкава.',
      island: 'Малі Зондські острови',
      image: 'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=900&q=80'
    }
  ];

  const regions = ['Усі регіони', 'Ява', 'Балі', 'Суматра', 'Сулавесі', 'Малі Зондські острови'];

  const filteredDogs =
    selectedRegion === 'Усі регіони'
      ? dogsData
      : dogsData.filter((dog) => dog.island === selectedRegion);

  return (
    <section className="page dogs-page">
      <div className="container narrow">
        <header className="page-header">
          <h1 className="page-title">Знайдені собаки</h1>
          <p className="page-subtitle">
            Кожен з цих песиків був знайдений небайдужими людьми. Перевірте, можливо, тут є ваш чотирилапий друг або пес, якому ви можете допомогти.
          </p>
          <div className="filter-bar">
            <label htmlFor="region-select" className="filter-label">
              Оберіть острів
            </label>
            <select
              id="region-select"
              className="filter-select"
              value={selectedRegion}
              onChange={(event) => setSelectedRegion(event.target.value)}
              aria-label="Фільтр за регіоном"
            >
              {regions.map((region) => (
                <option key={region} value={region}>
                  {region}
                </option>
              ))}
            </select>
          </div>
        </header>
        <div className="card-grid">
          {filteredDogs.map((dog) => (
            <article className="dog-card" key={dog.id}>
              <div className="dog-card__image-wrapper">
                <img
                  src={dog.image}
                  alt={"Собака ${dog.name} із регіону ${dog.region}"}
                  className="dog-card__image"
                  loading="lazy"
                />
              </div>
              <div className="dog-card__body">
                <h2 className="dog-card__name">{dog.name}</h2>
                <p className="dog-card__region">{dog.region}</p>
                <p className="dog-card__status">
                  <strong>Статус:</strong> {dog.status}
                </p>
                <p className="dog-card__date">
                  <strong>Дата знаходження:</strong> {dog.foundDate}
                </p>
                <p className="dog-card__note">{dog.characteristics}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const AdoptionPage = () => {
  useEffect(() => {
    document.title = 'Шукають дім | Пес Шукач';
    updateMetaTag(
      'description',
      'Знайомтесь із собаками, які готові до усиновлення в Індонезії. Допоможіть їм знайти люблячу родину.'
    );
    updateMetaTag(
      'keywords',
      'усиновлення собак, шукають дім, притулок для собак Індонезія'
    );
  }, []);

  const adoptionDogs = [
    {
      id: 1,
      name: 'Санті',
      temperament: 'ніжна, любить тривалі прогулянки',
      care: 'потребує регулярного догляду за шерстю',
      location: 'Сурабая, Східна Ява',
      image: 'https://images.unsplash.com/photo-1522276498395-f4ff414d1151?auto=format&fit=crop&w=900&q=80'
    },
    {
      id: 2,
      name: 'Мару',
      temperament: 'жвавий, дружній до інших собак',
      care: 'бажано подвір’я або активні господарі',
      location: 'Денпасар, Балі',
      image: 'https://images.unsplash.com/photo-1601758124044-00d4695c99bf?auto=format&fit=crop&w=900&q=80'
    },
    {
      id: 3,
      name: 'Аю',
      temperament: 'спокійна, слухняна, любить дітей',
      care: 'підійде для квартири, потребує ласки',
      location: 'Бандунг, Західна Ява',
      image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=80'
    }
  ];

  return (
    <section className="page adoption-page">
      <div className="container narrow">
        <header className="page-header">
          <h1 className="page-title">Собаки, які шукають дім</h1>
          <p className="page-subtitle">
            Вони вже готові зустріти своїх людей. Поспілкуйтеся з нашими координаторами, щоб дізнатися більше про кожного з підопічних.
          </p>
        </header>
        <div className="card-grid">
          {adoptionDogs.map((dog) => (
            <article className="adoption-card" key={dog.id}>
              <div className="adoption-card__image-wrapper">
                <img
                  src={dog.image}
                  alt={"Собака ${dog.name}, яка шукає дім"}
                  className="adoption-card__image"
                  loading="lazy"
                />
              </div>
              <div className="adoption-card__body">
                <h2 className="adoption-card__name">{dog.name}</h2>
                <p className="adoption-card__location">{dog.location}</p>
                <p className="adoption-card__item">
                  <strong>Темперамент:</strong> {dog.temperament}
                </p>
                <p className="adoption-card__item">
                  <strong>Особливості догляду:</strong> {dog.care}
                </p>
                <p className="adoption-card__cta">
                  Напишіть нам, щоб домовитися про знайомство.
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const NotFoundPage = () => {
  useEffect(() => {
    document.title = 'Сторінку не знайдено | Пес Шукач';
    updateMetaTag(
      'description',
      'На жаль, сторінку не знайдено. Поверніться на головну, щоб продовжити пошук собак.'
    );
  }, []);

  return (
    <section className="page not-found-page">
      <div className="container narrow">
        <h1 className="page-title">Ой, сторінку не знайдено</h1>
        <p className="page-subtitle">
          Схоже, що сторінка, яку ви шукаєте, більше не існує або була перенесена. Скористайтесь головним меню, щоб знайти потрібну інформацію.
        </p>
      </div>
    </section>
  );
};

const App = () => {
  return (
    <Router>
      <ScrollToTop />
      <Header />
      <main id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dogs" element={<DogsPage />} />
          <Route path="/adoption" element={<AdoptionPage />} />
          <Route path="/help" element={<Services />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/terms" element={<TermsOfService />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </Router>
  );
};

export default App;