<?php
header("Content-Type: text/html; charset=UTF-8");
$nome = htmlspecialchars($_POST['nome'] ?? 'Professionista');
$origine = htmlspecialchars($_POST['origine'] ?? 'Modulo');
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Grazie | Hydro Control Italia</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Grazie per aver contattato Hydro Control Italia.">
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <a class="skip-link" href="#contenuto-principale">Vai al contenuto principale</a>
    <header>
        <div class="container">
            <a class="branding" href="index.html">
                <img src="https://picsum.photos/seed/hydro-logo/96/96" alt="Logo Hydro Control Italia">
                <span class="branding-text">
                    <strong>Hydro Control Italia</strong>
                    <span>Sistemi idroelettrici intelligenti</span>
                </span>
            </a>
            <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="menu-principale">Menu</button>
            <nav id="menu-principale" aria-label="Menu principale">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">Azienda</a></li>
                    <li><a href="solutions.html">Soluzioni</a></li>
                    <li><a href="technology.html">Tecnologia</a></li>
                    <li><a href="performance.html">Prestazioni</a></li>
                    <li><a href="projects.html">Progetti</a></li>
                    <li><a href="contact.php">Contatti</a></li>
                </ul>
            </nav>
            <div class="header-contact">
                <span>Torre Diamante, Via della Liberazione 15</span>
                <span>20124 Milano | Tel: <a href="tel:+390298765432">+39 02 9876 5432</a></span>
            </div>
        </div>
    </header>
    <main id="contenuto-principale">
        <section class="page-hero">
            <div class="container">
                <div>
                    <p class="section-heading">Conferma</p>
                    <h1 class="section-title">Grazie, <?php echo $nome; ?>!</h1>
                    <p class="section-subtitle">Abbiamo ricevuto la tua richiesta (<?php echo $origine; ?>). Ti ricontatteremo al più presto per organizzare la valutazione energetica o fornire le informazioni richieste.</p>
                    <div class="form-actions">
                        <a class="btn btn-primary" href="index.html">Torna alla homepage</a>
                        <a class="btn btn-secondary" href="solutions.html">Consulta le soluzioni</a>
                    </div>
                </div>
                <figure>
                    <img src="https://picsum.photos/seed/hydro-thanks/860/520" alt="Ingegneri che celebrano un progetto completato" loading="lazy">
                </figure>
            </div>
        </section>
    </main>
    <footer>
        <div class="container footer-grid">
            <div class="footer-column">
                <div class="branding">
                    <img src="https://picsum.photos/seed/hydro-logo/96/96" alt="Logo Hydro Control Italia in bianco">
                    <span class="branding-text">
                        <strong>Hydro Control Italia</strong>
                        <span>Monitoraggio idroelettrico</span>
                    </span>
                </div>
                <p style="margin-top: 1rem;">Soluzioni italiane per la digitalizzazione delle centrali idroelettriche.</p>
                <div class="social-links">
                    <a href="https://www.linkedin.com">LinkedIn</a>
                    <a href="contact.php#form-contatti">Email</a>
                </div>
            </div>
            <div class="footer-column">
                <h3>Navigazione</h3>
                <ul class="footer-links">
                    <li><a href="solutions.html">Soluzioni</a></li>
                    <li><a href="technology.html">Tecnologia</a></li>
                    <li><a href="performance.html">Prestazioni</a></li>
                    <li><a href="projects.html">Progetti</a></li>
                    <li><a href="privacy.html">Privacy</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Contatti</h3>
                <div class="contact-details">
                    <span>Torre Diamante, Via della Liberazione 15<br>20124 Milano, Italia</span>
                    <a href="tel:+390298765432">+39 02 9876 5432</a>
                    <a href="mailto:info@hydrocontrolitalia.it">info@hydrocontrolitalia.it</a>
                </div>
            </div>
            <div class="footer-column">
                <h3>Compliance</h3>
                <ul class="footer-links">
                    <li><a href="cookies.html">Cookie</a></li>
                    <li><a href="terms.html">Termini legali</a></li>
                    <li><a href="sitemap.xml">Sitemap</a></li>
                </ul>
            </div>
        </div>
        <div class="container footer-bottom">
            <span>© Hydro Control Italia. Tutti i diritti riservati.</span>
            <span>P.IVA IT12345678901</span>
        </div>
    </footer>
    <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Informativa sui cookie" id="cookie-banner">
        <p>Utilizziamo cookie tecnici e di analisi anonimi per migliorare l’esperienza operativa. Puoi accettare o rifiutare facoltativamente la raccolta di dati analitici.</p>
        <div class="cookie-actions">
            <button class="btn btn-primary" id="cookie-accept" type="button">Accetta</button>
            <button class="btn btn-secondary" id="cookie-decline" type="button">Rifiuta</button>
        </div>
        <a href="cookies.html">Maggiori informazioni</a>
    </div>
    <script src="main.js" defer></script>
</body>
</html>