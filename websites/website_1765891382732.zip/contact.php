<?php
header("Content-Type: text/html; charset=UTF-8");
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Contatti | Hydro Control Italia</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Contatta Hydro Control Italia per richiedere una valutazione energetica: modulo interattivo, indirizzo, telefono, email e mappa.">
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <a class="skip-link" href="#contenuto-principale">Vai al contenuto principale</a>
    <header>
        <div class="container">
            <a class="branding" href="index.html">
                <img src="https://picsum.photos/seed/hydro-logo/96/96" alt="Logo Hydro Control Italia">
                <span class="branding-text">
                    <strong>Hydro Control Italia</strong>
                    <span>Sistemi idroelettrici intelligenti</span>
                </span>
            </a>
            <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="menu-principale">Menu</button>
            <nav id="menu-principale" aria-label="Menu principale">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">Azienda</a></li>
                    <li><a href="solutions.html">Soluzioni</a></li>
                    <li><a href="technology.html">Tecnologia</a></li>
                    <li><a href="performance.html">Prestazioni</a></li>
                    <li><a href="projects.html">Progetti</a></li>
                    <li><a href="contact.php" aria-current="page">Contatti</a></li>
                </ul>
            </nav>
            <div class="header-contact">
                <span>Torre Diamante, Via della Liberazione 15</span>
                <span>20124 Milano | Tel: <a href="tel:+390298765432">+39 02 9876 5432</a></span>
            </div>
        </div>
    </header>
    <main id="contenuto-principale">
        <section class="page-hero">
            <div class="container">
                <div>
                    <p class="section-heading">Contatti</p>
                    <h1 class="section-title">Richiedi la tua valutazione energetica</h1>
                    <p class="section-subtitle">Compila il modulo per organizzare un incontro con i nostri ingegneri. Analizzeremo la tua centrale, identificheremo i punti di miglioramento e definiremo un piano di intervento digitale.</p>
                </div>
                <figure>
                    <img src="https://picsum.photos/seed/hydro-contact/860/520" alt="Incontro tra ingegneri e responsabili di centrale" loading="lazy">
                </figure>
            </div>
        </section>

        <section>
            <div class="container split-layout">
                <div id="form-contatti">
                    <p class="section-heading">Modulo interattivo</p>
                    <h2 class="section-title">Parla con i nostri specialisti</h2>
                    <form action="thanks.php" method="post" aria-label="Modulo di contatto principale">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="nome">Nome e Cognome</label>
                                <input id="nome" name="nome" type="text" required placeholder="Nome e Cognome" autocomplete="name">
                            </div>
                            <div class="form-group">
                                <label for="email">Email aziendale</label>
                                <input id="email" name="email" type="email" required placeholder="nome@azienda.it" autocomplete="email">
                            </div>
                            <div class="form-group">
                                <label for="telefono">Telefono</label>
                                <input id="telefono" name="telefono" type="tel" pattern="[0-9+ ]{6,}" required placeholder="+39 ..." autocomplete="tel">
                            </div>
                            <div class="form-group">
                                <label for="ruolo">Ruolo</label>
                                <input id="ruolo" name="ruolo" type="text" required placeholder="Responsabile impianto, Direttore tecnico, ...">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="impianto">Tipologia impianto</label>
                            <select id="impianto" name="impianto" required>
                                <option value="">Seleziona</option>
                                <option value="bacino">Bacino ad accumulo</option>
                                <option value="filo_acqua">Impianto a filo d’acqua</option>
                                <option value="pompaggio">Sistema di pompaggio</option>
                                <option value="microgrid">Microgrid idroelettrica</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="messaggio">Descrizione della centrale</label>
                            <textarea id="messaggio" name="messaggio" required placeholder="Numero turbine, potenza installata, esigenze specifiche..."></textarea>
                        </div>
                        <input type="hidden" name="origine" value="Modulo contatti principale">
                        <div class="form-actions">
                            <button class="btn btn-primary" type="submit">Invia richiesta</button>
                            <span>Tempo di risposta medio: 24 ore lavorative</span>
                        </div>
                    </form>
                </div>
                <div>
                    <p class="section-heading">Sede centrale</p>
                    <h2 class="section-title">Hydro Control Italia</h2>
                    <div class="contact-details">
                        <span>Torre Diamante<br>Via della Liberazione 15<br>20124 Milano, Italia</span>
                        <a href="tel:+390298765432">+39 02 9876 5432</a>
                        <a href="mailto:info@hydrocontrolitalia.it">info@hydrocontrolitalia.it</a>
                    </div>
                    <div class="map-card" style="margin-top:1.5rem;">
                        <iframe title="Mappa Hydro Control Italia Milano" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2796.6161540033916!2d9.192215576630143!3d45.48367373351812!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4786c6be9cefbf13%3A0x3a2cf4bd9a9fdf37!2sTorre%20Diamante!5e0!3m2!1sit!2sit!4v1700000000000" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="quote-block" style="margin-top:1.5rem;">
                        “Dal primo sopralluogo alla messa in servizio, affianchiamo i gestori con un servizio completo e una presenza continua sul territorio italiano.”
                        <cite>Team Operations Hydro Control Italia</cite>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="container footer-grid">
            <div class="footer-column">
                <div class="branding">
                    <img src="https://picsum.photos/seed/hydro-logo/96/96" alt="Logo Hydro Control Italia in bianco">
                    <span class="branding-text">
                        <strong>Hydro Control Italia</strong>
                        <span>Monitoraggio idroelettrico</span>
                    </span>
                </div>
                <p style="margin-top: 1rem;">Soluzioni italiane per la digitalizzazione delle centrali idroelettriche.</p>
                <div class="social-links">
                    <a href="https://www.linkedin.com">LinkedIn</a>
                    <a href="mailto:info@hydrocontrolitalia.it">Email</a>
                </div>
            </div>
            <div class="footer-column">
                <h3>Navigazione</h3>
                <ul class="footer-links">
                    <li><a href="solutions.html">Soluzioni</a></li>
                    <li><a href="technology.html">Tecnologia</a></li>
                    <li><a href="performance.html">Prestazioni</a></li>
                    <li><a href="projects.html">Progetti</a></li>
                    <li><a href="privacy.html">Privacy</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Contatti</h3>
                <div class="contact-details">
                    <span>Torre Diamante, Via della Liberazione 15<br>20124 Milano, Italia</span>
                    <a href="tel:+390298765432">+39 02 9876 5432</a>
                    <a href="mailto:info@hydrocontrolitalia.it">info@hydrocontrolitalia.it</a>
                </div>
            </div>
            <div class="footer-column">
                <h3>Compliance</h3>
                <ul class="footer-links">
                    <li><a href="cookies.html">Cookie</a></li>
                    <li><a href="terms.html">Termini legali</a></li>
                    <li><a href="sitemap.xml">Sitemap</a></li>
                    <li><a href="robots.txt">Robots</a></li>
                </ul>
            </div>
        </div>
        <div class="container footer-bottom">
            <span>© Hydro Control Italia. Tutti i diritti riservati.</span>
            <span>P.IVA IT12345678901</span>
        </div>
    </footer>
    <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Informativa sui cookie" id="cookie-banner">
        <p>Utilizziamo cookie tecnici e di analisi anonimi per migliorare l’esperienza operativa. Puoi accettare o rifiutare facoltativamente la raccolta di dati analitici.</p>
        <div class="cookie-actions">
            <button class="btn btn-primary" id="cookie-accept" type="button">Accetta</button>
            <button class="btn btn-secondary" id="cookie-decline" type="button">Rifiuta</button>
        </div>
        <a href="cookies.html">Maggiori informazioni</a>
    </div>
    <script src="main.js" defer></script>
</body>
</html>