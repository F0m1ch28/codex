document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("header nav");
  const cookieBanner = document.getElementById("cookie-banner");
  const acceptCookiesBtn = document.getElementById("cookie-accept");
  const declineCookiesBtn = document.getElementById("cookie-decline");
  const storageKey = "hci-cookie-consent";

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (nav.classList.contains("open")) {
          nav.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  function setCookieConsent(value) {
    try {
      localStorage.setItem(storageKey, JSON.stringify({ value, timestamp: Date.now() }));
    } catch (error) {
      console.warn("Impossibile salvare il consenso ai cookie.", error);
    }
  }

  function getCookieConsent() {
    try {
      const data = localStorage.getItem(storageKey);
      if (!data) return null;
      return JSON.parse(data).value;
    } catch (error) {
      console.warn("Impossibile leggere il consenso ai cookie.", error);
      return null;
    }
  }

  if (cookieBanner) {
    const consent = getCookieConsent();
    if (!consent) {
      cookieBanner.classList.add("active");
    }

    acceptCookiesBtn?.addEventListener("click", () => {
      setCookieConsent("accepted");
      cookieBanner.classList.remove("active");
    });

    declineCookiesBtn?.addEventListener("click", () => {
      setCookieConsent("declined");
      cookieBanner.classList.remove("active");
    });
  }
});