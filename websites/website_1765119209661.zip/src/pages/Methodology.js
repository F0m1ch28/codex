import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Methodology.module.css';

const principles = [
  {
    title: 'Позитивне підкріплення',
    description:
      'Мотивація через винагороду, гру та похвалу. Ми формуємо поведінку, яку собака хоче повторювати, та встановлюємо чіткі рамки для стабільної роботи.',
  },
  {
    title: 'Аналіз поведінкових маркерів',
    description:
      'Відстежуємо мову тіла, рівень стресу, драйву і коригуємо програму в режимі реального часу для запобігання вигоранню.',
  },
  {
    title: 'Прозора система команд',
    description:
      'Команди та маркери зрозумілі і для собаки, і для власника. Формуємо єдину систему сигналів, щоб відсутність тренера не знижувала результат.',
  },
];

const dynamics = [
  {
    title: 'Розминка',
    text: 'Починаємо із сенсорної активації, підготовки м’язів і концентрації.',
  },
  {
    title: 'Основний блок',
    text: 'Відпрацьовуємо вправи з поступовою складністю, комбінуючи відомі та нові завдання.',
  },
  {
    title: 'Охолодження',
    text: 'Релаксаційні вправи, відновлення дихання, закріплення позитивних емоцій.',
  },
  {
    title: 'Домашнє завдання',
    text: 'Детальний план дій до наступної зустрічі з акцентом на інтеграцію в побут.',
  },
];

const Methodology = () => {
  usePageMeta({
    title: 'Методика тренувань — Професійне дресирування собак',
    description:
      'Позитивне підкріплення, структуровані заняття, аналіз поведінки та партнерство з власником. Дізнайтеся, як ми дресируємо німецьких вівчарок.',
    keywords:
      'методика дресирування, позитивне підкріплення, програма тренувань, кінологічні принципи, тренування вівчарок',
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Методика тренувань</h1>
          <p>
            Ми створили систему, що поєднує позитивне підкріплення, чітку
            структуру та практику службових тренувань. Наша мета — слухняна,
            впевнена німецька вівчарка, яка зберігає драйв і стабільність поруч
            з власником.
          </p>
        </div>
      </section>

      <section className={styles.principles}>
        <div className="container">
          <h2>Основні принципи</h2>
          <div className={styles.principleGrid}>
            {principles.map((item) => (
              <article key={item.title} className={styles.principleCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.structure}>
        <div className="container">
          <div className={styles.structureGrid}>
            <img
              src="https://picsum.photos/900/600?random=17"
              alt="Тренер демонструє вправу з німецькою вівчаркою"
              loading="lazy"
            />
            <div>
              <h2>Структура заняття</h2>
              <ul className={styles.structureList}>
                {dynamics.map((item) => (
                  <li key={item.title}>
                    <h3>{item.title}</h3>
                    <p>{item.text}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.partnership}>
        <div className="container">
          <h2>Партнерство з власником</h2>
          <div className={styles.partnershipGrid}>
            <div className={styles.partnershipCard}>
              <h3>Освітні блоки</h3>
              <p>
                Пояснюємо, як читати собаку, як реагувати на маркери стресу чи
                надмірне збудження, коли вводити паузи. Власник стає
                співтренером.
              </p>
            </div>
            <div className={styles.partnershipCard}>
              <h3>Домашня підтримка</h3>
              <p>
                Після кожного заняття власник отримує план самостійних вправ,
                відеоматеріали та чеклісти прогресу.
              </p>
            </div>
            <div className={styles.partnershipCard}>
              <h3>Зворотний зв’язок</h3>
              <p>
                Аналізуємо відеозвіти, коригуємо вправи і режим навантажень.
                Допомагаємо уникнути помилок на ранніх етапах.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.ethics}>
        <div className="container">
          <h2>Етичні стандарти</h2>
          <p>
            Ми не використовуємо методи, що завдають болю чи знижують довіру.
            Навіть у програмах захисно-караульної служби пріоритет — контроль,
            безпека та відповідність законодавству. Застосовуємо науково
            обґрунтовані техніки, співпрацюємо з ветеринарними лікарями та
            поведінковими спеціалістами при складних випадках.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Methodology;