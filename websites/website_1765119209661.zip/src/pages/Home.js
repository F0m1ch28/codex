import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Home.module.css';

const statsData = [
  { label: 'Років досвіду', value: 12 },
  { label: 'Навчених вівчарок', value: 480 },
  { label: 'Індивідуальних програм', value: 36 },
  { label: 'Команд тренерів', value: 2 },
];

const testimonials = [
  {
    name: 'Олена, Варшава',
    quote:
      'Після курсу базової слухняності наша вівчарка перестала тягнути повідок і стала впевненою в міських умовах. Особлива подяка за людяність тренера!',
  },
  {
    name: 'Марек, Краків',
    quote:
      'Професіонали з великим серцем. Ми готували собаку до змагань з IPO, результат перевершив очікування. Справжні партнери у тренінгу.',
  },
  {
    name: 'Світлана, Варшава',
    quote:
      'Команда допомогла гармонійно поєднати охоронні навички та безпечне життя у сім’ї. Вівчарка стала керованою навіть поруч з дітьми.',
  },
];

const projects = [
  {
    title: '«Асер» — підготовка до служби безпеки',
    category: 'Професійна підготовка',
    description:
      'Створили індивідуальну програму з акцентом на контрольну агресію та роботу в стресових умовах.',
    image: 'https://picsum.photos/1200/800?random=4',
  },
  {
    title: '«Луна» — адаптація до сім’ї з дітьми',
    category: 'Сімейний комфорт',
    description:
      'Відпрацьовано соціальні реакції, ввічливе спілкування та безпечне проживання у квартирі.',
    image: 'https://picsum.photos/1200/800?random=5',
  },
  {
    title: '«Рекс» — спортивний послух і захист',
    category: 'Спортивне дресирування',
    description:
      'Підготовка до змагань з ОКД, акцент на точності виконання команд та мотивації.',
    image: 'https://picsum.photos/1200/800?random=6',
  },
];

const faqData = [
  {
    question: 'Скільки триває курс базового дресирування?',
    answer:
      'У середньому програму базової слухняності ми формуємо на 8–10 тижнів, з урахуванням інтенсивності та можливостей власника. Кожне заняття триває 60–90 хвилин.',
  },
  {
    question: 'Чи працюєте ви індивідуально з кожною собакою?',
    answer:
      'Так, кожна німецька вівчарка отримує власну програму: ми аналізуємо темперамент, вік, попередній досвід і очікування родини.',
  },
  {
    question: 'Чи проводяться заняття англійською або польською?',
    answer:
      'Залежно від міста та тренера ми можемо провести тренінг українською, польською або англійською. Мову узгоджуємо під час консультації.',
  },
  {
    question: 'Які навички входять у програму захисно-караульної служби?',
    answer:
      'Формуємо навички охорони території, затримання та супроводу, але завжди із чітким контролем, безпекою та юридичними аспектами.',
  },
];

const blogPosts = [
  {
    title: 'Як розвивати стабільність команди «До мене» у місті',
    excerpt:
      'Пояснюємо, як відпрацьовувати складні виклики у парках Варшави та Кракова, щоб команда виконувалася без зволікань.',
    image: 'https://picsum.photos/800/600?random=7',
    date: '15 квітня 2024',
  },
  {
    title: 'Позитивне підкріплення та дисципліна: баланс для вівчарок',
    excerpt:
      'Чому позитивна мотивація не виключає вимогливості й як поєднувати ці підходи у щоденних тренуваннях.',
    image: 'https://picsum.photos/800/600?random=8',
    date: '27 березня 2024',
  },
  {
    title: '10 помилок власників при соціалізації',
    excerpt:
      'Розбираємо типові ситуації, які знижують впевненість собаки, та пропонуємо робочі альтернативи.',
    image: 'https://picsum.photos/800/600?random=9',
    date: '8 березня 2024',
  },
];

const Home = () => {
  usePageMeta({
    title: 'Професійне дресирування німецьких вівчарок — Варшава та Краків',
    description:
      'Індивідуальні програми дресирування німецьких вівчарок у Варшаві та Кракові. Позитивне підкріплення, спортивна та службова підготовка, соціалізація й безпека.',
    keywords:
      'дресирування собак, дресирування німецької вівчарки, кінолог Варшава, кінолог Краків, послуги дресирування, виховання собаки, ОКД, захисно-караульна служба',
  });

  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Усі');
  const [expandedFAQ, setExpandedFAQ] = useState(null);

  useEffect(() => {
    const intervals = statsData.map((stat, index) =>
      setInterval(() => {
        setCounters((prev) => {
          const updated = [...prev];
          const increment = Math.ceil(stat.value / 40);
          if (updated[index] < stat.value) {
            updated[index] = Math.min(updated[index] + increment, stat.value);
          }
          return updated;
        });
      }, 60)
    );
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === 'Усі'
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  const toggleFAQ = (index) => {
    setExpandedFAQ((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.heroBadge}>Варшава • Краків</p>
            <h1 className={styles.heroTitle}>
              Професійне дресирування німецьких вівчарок з акцентом на довіру та
              результат
            </h1>
            <p className={styles.heroSubtitle}>
              Ми працюємо з породою, яка потребує точності, дисципліни та
              любові. Будуємо стабільну поведінку, соціальну впевненість і
              спеціалізовані навички для життя й служби.
            </p>
            <div className={styles.heroActions}>
              <Link className={styles.primaryBtn} to="/contacts">
                Записатися
              </Link>
              <Link className={styles.secondaryBtn} to="/methodology">
                Дізнатися більше
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid} role="list">
            {statsData.map((stat, index) => (
              <div className={styles.statCard} key={stat.label} role="listitem">
                <span className={styles.statValue}>{counters[index]}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Тренування німецької вівчарки на відкритому майданчику"
              className={styles.aboutImage}
              loading="lazy"
            />
            <div>
              <h2>Чому нас обирають професіонали і родини</h2>
              <p>
                Ми поєднуємо академічні знання кінології з практикою службових
                і спортивних тренувань. Кожне заняття — це діалог між тренером,
                собакою та власником. Ми вчимо читати сигнали, правильно
                підкріплювати поведінку та будувати структуру, в якій вівчарка
                розкриває потенціал і зберігає стабільну психіку.
              </p>
              <ul className={styles.aboutList}>
                <li>Індивідуальні програми для щенят, підлітків та дорослих собак.</li>
                <li>Службові комплекси ОКД, IPO, захисно-караульна підготовка.</li>
                <li>Соціалізація у міських умовах Варшави та Кракова.</li>
              </ul>
              <Link className={styles.linkBtn} to="/about">
                Дізнатися про філософію → 
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesPreview} id="services-preview">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Наші ключові напрямки</h2>
            <p>
              Створюємо програми під конкретну задачу — від слухняності до
              спеціальної підготовки.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            <article className={styles.serviceCard}>
              <h3>Базова слухняність</h3>
              <p>
                Формуємо контроль у побуті: стійкі команди «До мене», «Поруч»,
                самоконтроль і роботу на відстані.
              </p>
              <Link to="/services" className={styles.cardLink}>
                Детальніше
              </Link>
            </article>
            <article className={styles.serviceCard}>
              <h3>Соціалізація в місті</h3>
              <p>
                Вчимо витримці, роботі поруч з шумом, громадським транспортом,
                людними місцями та іншими собаками.
              </p>
              <Link to="/services" className={styles.cardLink}>
                Детальніше
              </Link>
            </article>
            <article className={styles.serviceCard}>
              <h3>Захисно-караульна служба</h3>
              <p>
                Розвиваємо охоронні якості, контрольні затримання та впевнену
                роботу з фігурантом, дотримуючись етики й безпеки.
              </p>
              <Link to="/services" className={styles.cardLink}>
                Детальніше
              </Link>
            </article>
            <article className={styles.serviceCard}>
              <h3>Спортивні програми</h3>
              <p>
                Підготовка до змагань з ОКД, IGP, obedience: техніка рухів,
                точність, мотивація та витримка.
              </p>
              <Link to="/services" className={styles.cardLink}>
                Детальніше
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.shepherdFeature}>
        <div className="container">
          <div className={styles.shepherdGrid}>
            <div>
              <h2>Чому німецькі вівчарки — наша спеціалізація</h2>
              <p>
                Вівчарки — універсальні собаки з потужною нервовою системою, але
                їм потрібна структурована робота. Ми знаємо, як не втратити
                драйв, сформувати витримку і розвинути самоконтроль, зберігаючи
                природні інстинкти породи.
              </p>
              <ul className={styles.featureList}>
                <li>Поглиблена адаптація до роботи з високим рівнем енергії.</li>
                <li>Контрольна агресія і робота в «вмиканні-вимиканні» драйву.</li>
                <li>Генетика породи врахована у кожному тренувальному блоці.</li>
              </ul>
            </div>
            <img
              src="https://picsum.photos/800/600?random=10"
              alt="Німецька вівчарка виконує команду поруч із тренером"
              className={styles.shepherdImage}
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.methodologyPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Методика, що будує довіру</h2>
            <p>
              Ми поєднуємо позитивне підкріплення, структуровані правила та
              аналіз поведінкових маркерів, щоби собака уважно працювала й
              залишалась мотивованою.
            </p>
            <Link to="/methodology" className={styles.linkBtn}>
              Детальна методика →
            </Link>
          </div>
          <div className={styles.methodologyGrid}>
            <div className={styles.methodologyCard}>
              <h3>Повага до емоцій</h3>
              <p>Тренування починається з оцінки стану собаки та її ресурсів.</p>
            </div>
            <div className={styles.methodologyCard}>
              <h3>Поступове ускладнення</h3>
              <p>Кожна вправа має рівні складності — від бази до інтенсиву.</p>
            </div>
            <div className={styles.methodologyCard}>
              <h3>Прозора комунікація</h3>
              <p>Власник розуміє логіку кожної дії та продовжує роботу вдома.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Як ми працюємо</h2>
            <p>Покроковий підхід, що гарантує усвідомлений прогрес.</p>
          </div>
          <div className={styles.processGrid}>
            <div className={styles.processStep}>
              <span className={styles.stepNumber}>1</span>
              <h3>Діагностика</h3>
              <p>
                Аналізуємо поведінку, мотивацію та взаємодію з власником.
                Формуємо індивідуальні цілі.
              </p>
            </div>
            <div className={styles.processStep}>
              <span className={styles.stepNumber}>2</span>
              <h3>Програма</h3>
              <p>
                Створюємо план занять, включаючи домашні вправи та контрольні
                сесії.
              </p>
            </div>
            <div className={styles.processStep}>
              <span className={styles.stepNumber}>3</span>
              <h3>Тренінг</h3>
              <p>
                Проводимо заняття на майданчиках у Варшаві та Кракові.
                Відслідковуємо прогрес у реальних умовах.
              </p>
            </div>
            <div className={styles.processStep}>
              <span className={styles.stepNumber}>4</span>
              <h3>Контроль і підтримка</h3>
              <p>
                Узгоджуємо подальші кроки, надаємо рекомендації і корекцію при
                необхідності.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Відгуки клієнтів">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Відгуки власників вівчарок</h2>
            <p>Реальні історії співпраці з родинами та професіоналами.</p>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialQuote}>
              “{testimonials[activeTestimonial].quote}”
            </p>
            <p className={styles.testimonialName}>
              {testimonials[activeTestimonial].name}
            </p>
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={`${styles.dot} ${
                    index === activeTestimonial ? styles.dotActive : ''
                  }`}
                  aria-label={`Показати відгук ${index + 1}`}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Команда кінологів</h2>
            <p>
              Досвідчені фахівці з академічною освітою та практикою в
              кінологічних підрозділах.
            </p>
          </div>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=3"
                alt="Головний тренер Марія Мельник"
                loading="lazy"
              />
              <div className={styles.teamInfo}>
                <h3>Марія Мельник</h3>
                <p>Головний тренер, Варшава</p>
                <p>
                  Сертифікована тренерка FCI, 10+ років досвіду службових
                  тренінгів та підготовки до IGP.
                </p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=11"
                alt="Кінолог Анджей Ковальський"
                loading="lazy"
              />
              <div className={styles.teamInfo}>
                <h3>Анджей Ковальський</h3>
                <p>Кінолог, Краків</p>
                <p>
                  Спеціалізація — соціалізація та поведінкові корекції. Працює з
                  собаками рятувальних підрозділів.
                </p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=12"
                alt="Тренер-методист Олег Гринь"
                loading="lazy"
              />
              <div className={styles.teamInfo}>
                <h3>Олег Гринь</h3>
                <p>Тренер-методист</p>
                <p>
                  Розробляє програми мотивації та відпрацювання витримки. Автор
                  семінарів з позитивного підкріплення.
                </p>
              </div>
            </article>
          </div>
          <Link to="/about" className={styles.linkBtn}>
            Познайомитися з командою →
          </Link>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Наші кейси</h2>
            <p>
              Приклади цілей, які ми досягли разом з власниками та собаками.
            </p>
          </div>
          <div className={styles.filterBar}>
            {['Усі', 'Спортивне дресирування', 'Професійна підготовка', 'Сімейний комфорт'].map(
              (filter) => (
                <button
                  key={filter}
                  type="button"
                  className={`${styles.filterBtn} ${
                    projectFilter === filter ? styles.filterBtnActive : ''
                  }`}
                  onClick={() => setProjectFilter(filter)}
                >
                  {filter}
                </button>
              )
            )}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={project.title}
                  loading="lazy"
                />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>
                    {project.category}
                  </span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq} aria-label="Поширені запитання">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>FAQ: відповіді на ключові питання</h2>
            <p>
              Якщо не знайшли відповідь — напишіть нам, і ми проконсультуємо
              персонально.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => toggleFAQ(index)}
                  aria-expanded={expandedFAQ === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>
                    {expandedFAQ === index ? '−' : '+'}
                  </span>
                </button>
                {expandedFAQ === index && (
                  <div className={styles.faqAnswer}>
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Останні нотатки з тренувань</h2>
            <p>
              Ділимося досвідом, аналітикою і практичними порадами з польських
              майданчиків.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img
                  src={post.image}
                  alt={post.title}
                  loading="lazy"
                />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/methodology" className={styles.cardLink}>
                    Читати далі
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.locations}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Працюємо у двох містах Польщі</h2>
            <p>
              Проводимо тренування на професійних майданчиках та виїзні сесії
              для сімей.
            </p>
          </div>
          <div className={styles.locationGrid}>
            <article className={styles.locationCard}>
              <h3>Варшава</h3>
              <p>
                Виїзні тренування у парках міста, закритий манеж для відпрацювання
                спеціальних навичок, консультації для нових власників.
              </p>
              <p className={styles.locationDetail}>Фокус: рання соціалізація, міський послух, службова підготовка.</p>
            </article>
            <article className={styles.locationCard}>
              <h3>Краків</h3>
              <p>
                Відкриті тренування у природних локаціях, робота з групами,
                підготовка до змагань та спортивних іспитів.
              </p>
              <p className={styles.locationDetail}>Фокус: витривалість, робота з фігурантом, корекційні програми.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaInner}>
            <h2>Готові вдосконалити поведінку своєї вівчарки?</h2>
            <p>
              Заповніть форму з кількома запитаннями — ми підберемо тренера у
              Варшаві або Кракові та зв’яжемося з вами протягом доби.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contacts" className={styles.primaryBtn}>
                Залишити заявку
              </Link>
              <Link to="/about" className={styles.secondaryBtn}>
                Познайомитися з нами
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;