document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  const body = document.body;

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      mainNav.classList.toggle("is-open");
      body.classList.toggle("nav-open");
    });

    mainNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        mainNav.classList.remove("is-open");
        body.classList.remove("nav-open");
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const storageKey = "qazaqMediaCookieConsent";
    const savedState = localStorage.getItem(storageKey);

    if (savedState === "accepted" || savedState === "declined") {
      cookieBanner.classList.add("is-hidden");
    }

    const setConsent = (value) => {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.add("is-hidden");
    };

    acceptBtn?.addEventListener("click", () => setConsent("accepted"));
    declineBtn?.addEventListener("click", () => setConsent("declined"));
  }
});