import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ArticleCard.module.css';

const ArticleCard = ({ study }) => {
  const publicationDate = new Date(study.date).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <article className={styles.card}>
      <Link to={`/etudes/${study.id}`} className={styles.imageWrapper}>
        <img src={study.image} alt={`Illustration de l'étude ${study.title}`} />
      </Link>
      <div className={styles.content}>
        <p className={styles.meta}>{publicationDate} · {study.readingTime}</p>
        <h3 className={styles.title}>
          <Link to={`/etudes/${study.id}`}>{study.title}</Link>
        </h3>
        <p className={styles.excerpt}>{study.excerpt}</p>
        <ul className={styles.tags}>
          {study.tags.map((tag) => (
            <li key={tag}>{tag}</li>
          ))}
        </ul>
        <div className={styles.linkWrapper}>
          <Link to={`/etudes/${study.id}`} className={styles.readLink}>
            Lire l’étude
          </Link>
        </div>
      </div>
    </article>
  );
};

export default ArticleCard;