import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('fec_cookie_consent');
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('fec_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Ce site utilise des cookies techniques pour assurer son bon fonctionnement.
        Pour en savoir plus, consultez la{' '}
        <Link to="/politique-cookies">politique de cookies</Link>.
      </p>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Accepter
      </button>
    </div>
  );
};

export default CookieBanner;