import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = ({ minimal = false }) => {
  const currentYear = new Date().getFullYear();

  if (minimal) {
    return (
      <footer className={styles.minimalFooter}>
        <div className="container">
          <p>© {currentYear} French Equestrian Clubs Review.</p>
          <p>
            Contact rédactionnel :{' '}
            <a href="mailto:recherche@equestrian-clubs-review.fr">
              recherche@equestrian-clubs-review.fr
            </a>
          </p>
        </div>
      </footer>
    );
  }

  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.grid}`}>
        <div>
          <h2 className={styles.title}>French Equestrian Clubs Review</h2>
          <p className={styles.description}>
            Publication d’analyse sur les clubs hippiques français, leurs
            pratiques pédagogiques, leurs infrastructures et leur rôle dans la
            vie sportive et culturelle.
          </p>
          <p className={styles.contact}>
            Contact rédactionnel :{' '}
            <a href="mailto:recherche@equestrian-clubs-review.fr">
              recherche@equestrian-clubs-review.fr
            </a>
          </p>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Navigation</h3>
          <ul className={styles.links}>
            <li>
              <Link to="/etudes">Études</Link>
            </li>
            <li>
              <Link to="/entretiens">Entretiens</Link>
            </li>
            <li>
              <Link to="/a-propos">À propos</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Informations</h3>
          <ul className={styles.links}>
            <li>
              <Link to="/mentions-legales">Mentions légales</Link>
            </li>
            <li>
              <Link to="/confidentialite">Politique de confidentialité</Link>
            </li>
            <li>
              <Link to="/politique-cookies">Politique de cookies</Link>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {currentYear} French Equestrian Clubs Review. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;