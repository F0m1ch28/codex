import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleClose = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}>
          <span className={styles.logo}>
            French Equestrian Clubs Review
          </span>
        </div>
        <button
          className={styles.menuButton}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="navigation-principale"
        >
          <span className={styles.menuLabel}>Menu</span>
          <span className={styles.menuIcon} aria-hidden="true" />
        </button>
        <nav
          id="navigation-principale"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Navigation principale"
        >
          <ul className={styles.navList}>
            <li>
              <NavLink
                to="/"
                className={({ isActive }) =>
                  isActive ? styles.activeLink : styles.navLink
                }
                onClick={handleClose}
              >
                Accueil
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/etudes"
                className={({ isActive }) =>
                  isActive ? styles.activeLink : styles.navLink
                }
                onClick={handleClose}
              >
                Études
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/entretiens"
                className={({ isActive }) =>
                  isActive ? styles.activeLink : styles.navLink
                }
                onClick={handleClose}
              >
                Entretiens
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/a-propos"
                className={({ isActive }) =>
                  isActive ? styles.activeLink : styles.navLink
                }
                onClick={handleClose}
              >
                À propos
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/contact"
                className={({ isActive }) =>
                  isActive ? styles.activeLink : styles.navLink
                }
                onClick={handleClose}
              >
                Contact
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;