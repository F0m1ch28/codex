import React, { useEffect, useRef } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/HomePage';
import StudiesListingPage from './pages/StudiesListingPage';
import StudyDetailPage from './pages/StudyDetailPage';
import InterviewsPage from './pages/InterviewsPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import NotFoundPage from './pages/NotFoundPage';

const App = () => {
  const location = useLocation();
  const mainRef = useRef(null);

  useEffect(() => {
    window.scrollTo(0, 0);
    if (mainRef.current) {
      mainRef.current.focus();
    }
  }, [location.pathname]);

  const legalPaths = ['/mentions-legales', '/confidentialite', '/politique-cookies'];
  const isLegalPage = legalPaths.includes(location.pathname);

  return (
    <>
      <a className="skipLink" href="#contenu-principal">
        Aller au contenu principal
      </a>
      <div className="appShell">
        <Header />
        <main
          id="contenu-principal"
          className="mainContent"
          tabIndex="-1"
          ref={mainRef}
          role="main"
        >
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/etudes" element={<StudiesListingPage />} />
            <Route path="/etudes/:studyId" element={<StudyDetailPage />} />
            <Route path="/entretiens" element={<InterviewsPage />} />
            <Route path="/a-propos" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/mentions-legales" element={<TermsPage />} />
            <Route path="/confidentialite" element={<PrivacyPage />} />
            <Route path="/politique-cookies" element={<CookiePolicyPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer minimal={isLegalPage} />
      </div>
      <CookieBanner />
      <ScrollToTopButton />
    </>
  );
};

export default App;