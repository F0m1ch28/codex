export const interviews = [
  {
    id: 'celine-moreau',
    name: 'Céline Moreau',
    role: 'Directrice technique du Cercle Hippique de Saumur',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
    highlight:
      'Elle revient sur la place du Cadre noir dans la formation continue des moniteurs civils et sur la circulation des savoirs techniques.',
    questions: [
      {
        question:
          'Comment les échanges avec le Cadre noir influencent-ils le travail quotidien de votre club ?',
        answer:
          'Les écuyers du Cadre noir organisent chaque année des sessions de perfectionnement auxquelles nos équipes pédagogiques participent. Ces sessions permettent d’actualiser la lecture des aides, de travailler les transitions avec davantage de finesse et de réfléchir aux manières d’expliquer la légèreté aux jeunes cavaliers. Nous transposons ensuite ces apports dans nos programmations mensuelles, en adaptant la terminologie aux différents publics.'
      },
      {
        question:
          'Quelles sont les priorités pour maintenir une cavalerie disponible tout au long de la saison ?',
        answer:
          'Nous planifions des rotations entre travail sur le plat, sorties en extérieur et séances à pied. Chaque cheval dispose d’un carnet numérique partagé avec le vétérinaire, le maréchal et l’ostéopathe. Ce suivi collectif nous aide à anticiper les moments de récupération et à respecter le rythme physiologique de chaque monture.'
      },
      {
        question:
          'Quel rôle jouent les familles et les partenaires institutionnels ?',
        answer:
          'Les familles participent à des réunions trimestrielles autour des projets pédagogiques. Nous travaillons aussi avec la ville et le département pour accueillir des classes patrimoniales et des publics scolaires éloignés de l’équitation. Ces partenariats garantissent la continuité de nos actions éducatives.'
      }
    ]
  },
  {
    id: 'marc-duval',
    name: 'Marc Duval',
    role: 'Vétérinaire spécialisé en médecine sportive équine',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80&sat=-30',
    highlight:
      'Il décrit les protocoles de suivi sanitaire mis en place avec plusieurs clubs de Normandie et des Pays de la Loire.',
    questions: [
      {
        question:
          'Quels sont les indicateurs que vous surveillez en priorité dans les clubs hippiques ?',
        answer:
          'Nous observons la locomotion lors des échauffements, la récupération cardiaque, la qualité de la ferrure et l’état général des aplombs. Les clubs maintiennent des tableaux de bord hebdomadaires que nous relisons pour anticiper tout signe de fatigue ou d’inconfort. Cette vigilance partagée réduit nettement les arrêts prolongés.'
      },
      {
        question:
          'Comment associez-vous les moniteurs aux décisions de suivi ?',
        answer:
          'Nous organisons des visites communes des écuries. Le moniteur apporte sa connaissance du cheval et de l’élève, tandis que je fournis un diagnostic vétérinaire. Ensemble, nous définissons un protocole évolutif qui inclut ajustements alimentaires, séances de stretching et adaptation du planning de concours.'
      },
      {
        question:
          'Quelles évolutions observez-vous dans la gestion sanitaire des clubs ?',
        answer:
          'Les clubs intègrent désormais des temps de sensibilisation pour les cavaliers, avec des ateliers sur l’observation des signes précoces. Ils adoptent aussi des outils numériques pour centraliser les traitements. Cette organisation favorise une médecine préventive et renforce la culture du bien-être animal.'
      }
    ]
  },
  {
    id: 'ines-lambert',
    name: 'Inès Lambert',
    role: 'Formatrice BPJEPS et responsable pédagogique en Île-de-France',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80',
    highlight:
      'Elle expose sa vision de la formation des moniteurs et des dispositifs d’accompagnement des jeunes cavaliers urbains.',
    questions: [
      {
        question:
          'Comment adaptez-vous la formation des moniteurs aux publics urbains ?',
        answer:
          'Nous travaillons beaucoup sur la médiation, la lecture des attentes des familles et la création de parcours progressifs. Les stagiaires apprennent à scénariser leurs cours en tenant compte du rapport parfois inédit que les jeunes entretiennent avec l’animal. Nous insistons également sur la dimension culturelle de l’équitation, en organisant des visites de musées et de haras.'
      },
      {
        question:
          'Quels outils privilégiez-vous pour évaluer les compétences pédagogiques ?',
        answer:
          'Nous utilisons des grilles d’observation qui croisent posture, capacité d’analyse et communication avec l’élève. Chaque séquence est filmée pour permettre un retour collectif et offrir un regard externe. Les stagiaires formulent eux-mêmes leurs axes de progression, ce qui renforce leur autonomie professionnelle.'
      },
      {
        question:
          'Quels projets développés avec les clubs partenaires vous semblent particulièrement prometteurs ?',
        answer:
          'Des clubs franciliens ont mis en place des laboratoires pédagogiques réunissant moniteurs, enseignants du secondaire et éducateurs sportifs d’autres disciplines. L’objectif est de comparer les démarches, d’échanger sur les méthodes d’inclusion et de construire des ressources communes. Ces espaces de dialogue nourrissent la créativité des équipes et améliorent la continuité éducative.'
      }
    ]
  }
];