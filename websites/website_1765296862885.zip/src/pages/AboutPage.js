import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  const values = [
    {
      title: 'Neutralité éditoriale',
      description:
        'Les contenus sont relus par un comité éditorial indépendant. Chaque étude mentionne ses sources, explicite les limites des enquêtes et privilégie les faits vérifiables.'
    },
    {
      title: 'Ancrage territorial',
      description:
        'Les enquêtes couvrent des clubs situés dans des régions contrastées, mêlant zones rurales, littorales et périurbaines pour restituer la diversité des pratiques équestres françaises.'
    },
    {
      title: 'Dialogue interprofessionnel',
      description:
        'Les moniteurs diplômés, vétérinaires, maréchaux, dirigeants associatifs et acteurs institutionnels sont régulièrement consultés pour confronter les points de vue.'
    }
  ];

  const team = [
    {
      name: 'Aurélie Bernard',
      role: 'Rédactrice en chef',
      bio: 'Historienne de formation et spécialiste des patrimoines équestres, elle coordonne les enquêtes et supervise la relecture scientifique.',
      image:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Théo Martin',
      role: 'Reporter de terrain',
      bio: 'Ancien cavalier de concours complet, il conduit les visites de clubs, réalise les interviews et documente les infrastructures.',
      image:
        'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Lina Caradec',
      role: 'Analyste données',
      bio: 'Chargée de l’exploitation statistique et cartographique, elle traite les inventaires fédéraux et les bases documentaires publiques.',
      image:
        'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80'
    }
  ];

  const timeline = [
    {
      year: '2020',
      title: 'Création de la rédaction',
      description:
        'Lancement d’un programme de veille sur les clubs hippiques, avec la constitution d’un réseau de correspondants régionaux.'
    },
    {
      year: '2021',
      title: 'Premiers dossiers thématiques',
      description:
        'Publication d’un cycle consacré aux poney-clubs et aux parcours pédagogiques des jeunes cavaliers, en partenariat avec des centres franciliens.'
    },
    {
      year: '2023',
      title: 'Extension nationale',
      description:
        'Élargissement des enquêtes à douze régions françaises, avec intégration d’analyses sur la transition écologique des infrastructures.'
    },
    {
      year: '2024',
      title: 'Plateforme éditoriale unifiée',
      description:
        'Mise en ligne de la version actuelle du site, proposant un accès structuré aux études, aux entretiens et aux ressources juridiques.'
    }
  ];

  return (
    <>
      <PageHelmet
        title="À propos | French Equestrian Clubs Review"
        description="Mission, équipe et principes éditoriaux de French Equestrian Clubs Review, publication dédiée à l’étude des clubs hippiques en France."
        keywords="à propos, rédaction équitation, mission publication, clubs hippiques France"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>À propos</h1>
          <p>
            French Equestrian Clubs Review est une publication indépendante
            dédiée à l’analyse des clubs hippiques français. L’équipe associe
            journalistes, historiens, spécialistes du cheval et analystes
            territoriaux pour produire des études rigoureuses et contextualisées.
          </p>
        </div>
      </section>

      <section className={styles.valuesSection}>
        <div className="container">
          <h2>Principes éditoriaux</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2>Équipe rédactionnelle</h2>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} />
                <div>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <h2>Repères</h2>
          <div className={styles.timeline}>
            {timeline.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <span className={styles.year}>{item.year}</span>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;