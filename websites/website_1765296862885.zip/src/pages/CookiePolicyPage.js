import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './LegalPage.module.css';

const CookiePolicyPage = () => (
  <>
    <PageHelmet
      title="Politique de cookies | French Equestrian Clubs Review"
      description="Politique de cookies de French Equestrian Clubs Review."
    />
    <section className={styles.section}>
      <div className="container">
        <h1>Politique de cookies</h1>
        <div className={styles.content}>
          <h2>Cookies utilisés</h2>
          <p>
            Le site utilise uniquement des cookies techniques nécessaires à son
            fonctionnement, notamment pour mémoriser le choix de l’utilisateur
            concernant l’affichage de la bannière d’information.
          </p>

          <h2>Gestion des préférences</h2>
          <p>
            L’utilisateur peut supprimer les cookies via les paramètres de son
            navigateur. Sans cookies techniques, certaines fonctionnalités
            (acceptation de la bannière) pourraient ne pas être prises en
            compte, sans que cela n’empêche la consultation des contenus.
          </p>

          <h2>Aucune finalité publicitaire</h2>
          <p>
            Aucun cookie à visée publicitaire ou de mesure d’audience n’est
            déposé par l’éditeur. Le site n’a recours à aucune solution de
            ciblage ni de profilage.
          </p>

          <h2>Contact</h2>
          <p>
            Pour toute question relative aux cookies, veuillez écrire à
            recherche@equestrian-clubs-review.fr.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;