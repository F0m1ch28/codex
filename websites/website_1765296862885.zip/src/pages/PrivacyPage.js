import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './LegalPage.module.css';

const PrivacyPage = () => (
  <>
    <PageHelmet
      title="Politique de confidentialité | French Equestrian Clubs Review"
      description="Politique de confidentialité de French Equestrian Clubs Review."
    />
    <section className={styles.section}>
      <div className="container">
        <h1>Politique de confidentialité</h1>
        <div className={styles.content}>
          <h2>Données collectées</h2>
          <p>
            Le site ne collecte que les informations fournies volontairement via
            le formulaire de contact, à savoir nom, adresse e-mail, thème de la
            demande et message. Ces données servent exclusivement à répondre aux
            sollicitations reçues.
          </p>

          <h2>Durée de conservation</h2>
          <p>
            Les messages sont conservés pendant la durée nécessaire à leur
            traitement, sans excéder douze mois. Passé ce délai, ils sont
            supprimés de manière sécurisée.
          </p>

          <h2>Destinataires</h2>
          <p>
            Les informations sont accessibles uniquement aux membres de la
            rédaction habilités à traiter les demandes. Aucune donnée n’est
            transmise à des tiers sans consentement préalable.
          </p>

          <h2>Droits des personnes</h2>
          <p>
            Conformément au Règlement général sur la protection des données
            (RGPD), toute personne peut demander l’accès, la rectification ou la
            suppression des informations la concernant en écrivant à
            recherche@equestrian-clubs-review.fr.
          </p>

          <h2>Mesures de sécurité</h2>
          <p>
            Les échanges entre le navigateur et le site sont chiffrés (HTTPS).
            Les boîtes de réception utilisées par la rédaction sont protégées
            par mot de passe et authentification à deux facteurs.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default PrivacyPage;