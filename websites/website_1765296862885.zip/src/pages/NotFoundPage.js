import React from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import styles from './NotFoundPage.module.css';

const NotFoundPage = () => (
  <>
    <PageHelmet
      title="Page introuvable | French Equestrian Clubs Review"
      description="La page recherchée est introuvable."
    />
    <section className={styles.section}>
      <div className="container">
        <h1>Page introuvable</h1>
        <p>
          La ressource demandée n’existe pas ou n’est plus disponible. Retournez
          vers l’accueil ou consultez les dernières études.
        </p>
        <div className={styles.links}>
          <Link to="/">Accueil</Link>
          <Link to="/etudes">Études</Link>
        </div>
      </div>
    </section>
  </>
);

export default NotFoundPage;