import React from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import ArticleCard from '../components/ArticleCard';
import { studies } from '../data/studiesData';
import { interviews } from '../data/interviewsData';
import styles from './HomePage.module.css';

const HomePage = () => {
  const sortedStudies = [...studies].sort(
    (a, b) => new Date(b.date) - new Date(a.date)
  );
  const latestStudies = sortedStudies.slice(0, 3);
  const featuredInterview = interviews[0];

  const stats = [
    { value: '68', label: 'Clubs étudiés en 2023-2024' },
    { value: '42', label: 'Entretiens approfondis' },
    { value: '12', label: 'Régions observées' }
  ];

  const regions = [
    {
      name: 'Normandie',
      description:
        'Haras historiques, pôle sportif de Deauville, filière élevage et concours complet.'
    },
    {
      name: 'Pays de la Loire',
      description:
        'Présence du Cadre noir, écoles de formation et réseaux de dressage reconnus.'
    },
    {
      name: 'Occitanie',
      description:
        'Tradition camarguaise, valorisation des spectacles équestres et du tourisme rural.'
    },
    {
      name: 'Île-de-France',
      description:
        'Centres urbains modernisés, partenariats pédagogiques avec les établissements scolaires.'
    },
    {
      name: 'Nouvelle-Aquitaine',
      description:
        'Diversité des disciplines, accueil d’événements fédéraux et dynamiques associatives rurales.'
    },
    {
      name: 'Bretagne',
      description:
        'Programmes dédiés aux jeunes cavaliers, approche environnementale des infrastructures.'
    }
  ];

  return (
    <>
      <PageHelmet
        title="French Equestrian Clubs Review"
        description="Analyse indépendante des clubs hippiques français : recherches, enquêtes de terrain, entretiens et dossiers thématiques."
        keywords="club hippique, centres équestres, équitation française, recherche équestre, fédération française d’équitation"
      />
      <div className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <p className={styles.heroKicker}>Publication de recherche</p>
          <h1 className={styles.heroTitle}>
            Cartographie raisonnée des clubs hippiques français
          </h1>
          <p className={styles.heroSubtitle}>
            French Equestrian Clubs Review documente les pratiques, les
            pédagogies et les ancrages territoriaux des centres équestres de
            France, en croisant archives, enquêtes de terrain et entretiens
            d’experts.
          </p>
        </div>
      </div>

      <section className={styles.latestStudies}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Dernières études</h2>
            <p className="sectionSubtitle">
              Dossiers récents issus de visites de terrain, d’analyses
              documentaires et d’entretiens avec des écuyers, des moniteurs et
              des responsables de clubs.
            </p>
          </div>
          <div className={styles.studiesGrid}>
            {latestStudies.map((study) => (
              <ArticleCard key={study.id} study={study} />
            ))}
          </div>
          <div className={styles.allStudiesLink}>
            <Link to="/etudes">Consulter toutes les études</Link>
          </div>
        </div>
      </section>

      <section className={styles.focusSection}>
        <div className="container">
          <div className={styles.focusContent}>
            <h2 className={styles.focusTitle}>Focus : équitation classique française</h2>
            <p>
              La tradition de l’équitation classique, héritée des grandes
              écoles françaises, demeure un repère structurant pour les clubs
              contemporains. Les principes de légèreté, de rectitude et de
              dialogue fin avec la monture irriguent encore les progressions
              pédagogiques. Les études récentes mettent en lumière la manière
              dont les instructeurs adaptent cet héritage aux attentes des
              publics actuels, en élaborant des outils d’observation, des
              séquences au sol et des collaborations artistiques.
            </p>
            <p>
              Ce dossier thématique suit les clubs spécialisés en dressage, les
              formations du Cadre noir et les initiatives qui articulent
              patrimoine, innovation scientifique et approche culturelle du
              cheval. Les articles associés présentent des études de cas, des
              analyses d’archives et des entretiens avec des écuyers
              expérimentés.
            </p>
            <Link to="/etudes/dressage-art-equestre-francais" className={styles.focusLink}>
              Découvrir le dossier thématique
            </Link>
          </div>
          <div className={styles.focusImageBox}>
            <img
              src="https://images.unsplash.com/photo-1505764706515-aa95265c5abc?auto=format&fit=crop&w=900&q=80"
              alt="Écuyer travaillant un cheval en dressage"
            />
          </div>
        </div>
      </section>

      <section className={styles.methodSection}>
        <div className="container">
          <h2 className="sectionTitle">Méthodologie</h2>
          <div className={styles.methodGrid}>
            <div>
              <h3>Observation de terrain</h3>
              <p>
                Les reporters se déplacent dans des clubs hippiques de toutes
                tailles afin de documenter les infrastructures, les
                organisations pédagogiques et le fonctionnement des cavaleries.
                Chaque visite donne lieu à des notes d’observation et à des
                captations photographiques autorisées.
              </p>
            </div>
            <div>
              <h3>Analyse documentaire</h3>
              <p>
                Les études s’appuient sur des archives fédérales, des rapports
                publics, des ressources scientifiques et des publications
                régionales. Les données sont croisées pour situer chaque club
                dans son contexte historique, économique et territorial.
              </p>
            </div>
            <div>
              <h3>Entretiens d’experts</h3>
              <p>
                Les moniteurs diplômés, les vétérinaires, les maréchaux et les
                responsables institutionnels sont interrogés pour éclairer les
                choix pédagogiques, l’entretien des chevaux et les enjeux
                réglementaires. Les verbatims sont relus et validés avant
                publication.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((stat) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{stat.value}</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.regionSection}>
        <div className="container">
          <h2 className="sectionTitle">Réseau régional des clubs étudiés</h2>
          <p className="sectionSubtitle">
            Visualisation synthétique des principaux territoires observés et des
            thématiques récurrentes associées aux clubs hippiques.
          </p>
          <div className={styles.mapWrapper} role="list">
            {regions.map((region) => (
              <article key={region.name} className={styles.regionCard} role="listitem">
                <h3>{region.name}</h3>
                <p>{region.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.interviewSection}>
        <div className="container">
          <div className={styles.interviewContent}>
            <div>
              <h2 className="sectionTitle">Archive des entretiens</h2>
              <p className="sectionSubtitle">
                Les échanges avec les entraîneurs, cavaliers professionnels,
                vétérinaires et responsables de clubs nourrissent l’analyse
                qualitative de la publication.
              </p>
            </div>
            <div className={styles.interviewPreview}>
              <img
                src="https://images.unsplash.com/photo-1489980557514-251d61e3eeb6?auto=format&fit=crop&w=900&q=80"
                alt="Portrait d'une professionnelle du secteur équestre"
              />
              <div>
                <p className={styles.interviewName}>{featuredInterview.name}</p>
                <p className={styles.interviewRole}>{featuredInterview.role}</p>
                <p>{featuredInterview.highlight}</p>
                <Link to="/entretiens" className={styles.interviewLink}>
                  Parcourir les entretiens
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;