import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './LegalPage.module.css';

const TermsPage = () => (
  <>
    <PageHelmet
      title="Mentions légales | French Equestrian Clubs Review"
      description="Mentions légales de French Equestrian Clubs Review."
    />
    <section className={styles.section}>
      <div className="container">
        <h1>Mentions légales</h1>
        <div className={styles.content}>
          <h2>Éditeur</h2>
          <p>
            French Equestrian Clubs Review est édité par une association loi
            1901 dédiée à la valorisation des recherches sur l’équitation
            française. Le siège social est situé à Paris (France). Contact :
            <a href="mailto:recherche@equestrian-clubs-review.fr">
              recherche@equestrian-clubs-review.fr
            </a>
            .
          </p>

          <h2>Responsable de publication</h2>
          <p>Aurélie Bernard, rédactrice en chef.</p>

          <h2>Hébergement</h2>
          <p>
            Le site est hébergé auprès d’un prestataire européen répondant aux
            obligations en vigueur en matière de sécurité et de protection des
            données. Les informations techniques sont disponibles sur demande
            auprès de la rédaction.
          </p>

          <h2>Propriété intellectuelle</h2>
          <p>
            Les textes, photographies et éléments graphiques présents sur le
            site sont protégés par le Code de la propriété intellectuelle. Toute
            reproduction ou diffusion nécessite l’accord écrit de l’éditeur.
          </p>

          <h2>Responsabilité</h2>
          <p>
            Les contenus sont fournis à titre informatif. Malgré l’attention
            portée à la vérification des sources, l’éditeur ne saurait être tenu
            responsable des décisions prises sur la base des informations
            publiées. Les liens externes sont indiqués pour faciliter l’accès à
            des ressources complémentaires.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default TermsPage;