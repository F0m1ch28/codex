import React from 'react';
import PageHelmet from '../components/PageHelmet';
import { interviews } from '../data/interviewsData';
import styles from './InterviewsPage.module.css';

const InterviewsPage = () => {
  return (
    <>
      <PageHelmet
        title="Entretiens | French Equestrian Clubs Review"
        description="Entretiens avec des directeurs de clubs hippiques, des vétérinaires, des formateurs et des moniteurs autour des pratiques équestres françaises."
        keywords="entretiens équitation, experts équestres, moniteurs diplômés, vétérinaires équins"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Entretiens</h1>
          <p>
            Cette section rassemble des entretiens menés avec des professionnels
            de la filière cheval. Les échanges sont retranscrits dans un format
            questions-réponses afin de restituer fidèlement l’argumentation des
            intervenants.
          </p>
        </div>
      </section>
      <section className={styles.listSection}>
        <div className="container">
          {interviews.map((interview) => (
            <article key={interview.id} className={styles.card}>
              <div className={styles.portrait}>
                <img src={interview.image} alt={`Portrait de ${interview.name}`} />
              </div>
              <div className={styles.content}>
                <header>
                  <h2>{interview.name}</h2>
                  <p className={styles.role}>{interview.role}</p>
                  <p className={styles.highlight}>{interview.highlight}</p>
                </header>
                <div className={styles.qa}>
                  {interview.questions.map((item, index) => (
                    <div key={index} className={styles.qaItem}>
                      <p className={styles.question}>{item.question}</p>
                      <p className={styles.answer}>{item.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default InterviewsPage;