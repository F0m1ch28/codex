import React, { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './ContactPage.module.css';

const initialState = {
  name: '',
  email: '',
  topic: 'Proposition de sujet',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [feedback, setFeedback] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setFeedback({
        type: 'error',
        message: 'Merci de renseigner les champs obligatoires.'
      });
      return;
    }
    setFeedback({
      type: 'success',
      message: 'Merci, votre demande a été transmise à la rédaction.'
    });
    setFormData(initialState);
  };

  return (
    <>
      <PageHelmet
        title="Contact | French Equestrian Clubs Review"
        description="Coordonnées de la rédaction et formulaire de contact pour les questions de recherche, les propositions de sujets et les demandes d’interview."
        keywords="contact rédaction, recherche équitation, clubs hippiques, interview équitation"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact</h1>
          <p>
            Pour toute question relative aux études, aux sources utilisées ou
            aux collaborations éditoriales, la rédaction répond aux messages
            envoyés via ce formulaire ou par courrier électronique.
          </p>
          <p className={styles.email}>
            Adresse de contact :{' '}
            <a href="mailto:recherche@equestrian-clubs-review.fr">
              recherche@equestrian-clubs-review.fr
            </a>
          </p>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Nom</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="email">Adresse e-mail</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="topic">Objet de la demande</label>
              <select
                id="topic"
                name="topic"
                value={formData.topic}
                onChange={handleChange}
              >
                <option value="Proposition de sujet">Proposition de sujet</option>
                <option value="Demande d'interview">Demande d'interview</option>
                <option value="Information pour la recherche">
                  Information pour la recherche
                </option>
                <option value="Autre">Autre</option>
              </select>
            </div>
            <div className={styles.field}>
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                required
              />
            </div>
            <button type="submit" className={styles.submitButton}>
              Envoyer la demande
            </button>
            {feedback.message && (
              <p
                className={
                  feedback.type === 'error' ? styles.error : styles.success
                }
              >
                {feedback.message}
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default ContactPage;