import React, { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import { studies } from '../data/studiesData';
import styles from './StudyDetailPage.module.css';

const slugify = (text) =>
  text
    .toLowerCase()
    .replace(/[^a-zàâçéèêëîïôûùüÿñæœ0-9]+/gi, '-')
    .replace(/^-+|-+$/g, '');

const StudyDetailPage = () => {
  const { studyId } = useParams();
  const study = useMemo(
    () => studies.find((item) => item.id === studyId),
    [studyId]
  );

  const related = useMemo(() => {
    if (!study) return [];
    return studies.filter(
      (item) => study.relatedIds.includes(item.id) && item.id !== study.id
    );
  }, [study]);

  if (!study) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Étude introuvable</h1>
          <p>
            L’étude demandée n’existe plus ou a été déplacée. Retournez à la
            liste des analyses pour poursuivre la lecture.
          </p>
          <Link to="/etudes" className={styles.backLink}>
            Revenir aux études
          </Link>
        </div>
      </section>
    );
  }

  const publicationDate = new Date(study.date).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <>
      <PageHelmet
        title={`${study.title} | French Equestrian Clubs Review`}
        description={study.excerpt}
        keywords={study.keywords}
      />
      <article className={styles.article}>
        <header className={styles.header}>
          <div className="container">
            <p className={styles.kicker}>Étude approfondie</p>
            <h1 className={styles.title}>{study.title}</h1>
            <p className={styles.meta}>
              Publié le {publicationDate} · {study.readingTime}
            </p>
            <ul className={styles.tags}>
              {study.tags.map((tag) => (
                <li key={tag}>{tag}</li>
              ))}
            </ul>
          </div>
        </header>
        <div className={styles.heroImage}>
          <img src={study.image} alt={`Illustration de ${study.title}`} />
        </div>
        <div className={`container ${styles.body}`}>
          <nav className={styles.toc} aria-label="Plan de l’étude">
            <h2>Plan</h2>
            <ol>
              {study.sections.map((section) => (
                <li key={section.heading}>
                  <a href={`#${slugify(section.heading)}`}>{section.heading}</a>
                </li>
              ))}
            </ol>
          </nav>
          <div className={styles.content}>
            <p className={styles.introduction}>{study.introduction}</p>

            {study.sections.map((section) => (
              <section
                key={section.heading}
                id={slugify(section.heading)}
                className={styles.section}
              >
                <h2>{section.heading}</h2>
                {section.paragraphs.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </section>
            ))}

            <section className={styles.section}>
              <h2>Conclusion</h2>
              <p>{study.conclusion}</p>
            </section>
          </div>
        </div>
      </article>

      {related.length > 0 && (
        <section className={styles.relatedSection}>
          <div className="container">
            <h2 className="sectionTitle">Études associées</h2>
            <div className={styles.relatedGrid}>
              {related.map((item) => (
                <Link key={item.id} to={`/etudes/${item.id}`} className={styles.relatedCard}>
                  <img src={item.image} alt={`Illustration de ${item.title}`} />
                  <div>
                    <h3>{item.title}</h3>
                    <p>{item.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
};

export default StudyDetailPage;