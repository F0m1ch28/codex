import React, { useMemo, useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import ArticleCard from '../components/ArticleCard';
import { studies } from '../data/studiesData';
import styles from './StudiesListingPage.module.css';

const StudiesListingPage = () => {
  const [selectedTag, setSelectedTag] = useState('Toutes');

  const sortedStudies = useMemo(
    () => [...studies].sort((a, b) => new Date(b.date) - new Date(a.date)),
    []
  );

  const tags = useMemo(() => {
    const unique = new Set();
    studies.forEach((study) => {
      study.tags.forEach((tag) => unique.add(tag));
    });
    return ['Toutes', ...Array.from(unique)];
  }, []);

  const filteredStudies =
    selectedTag === 'Toutes'
      ? sortedStudies
      : sortedStudies.filter((study) => study.tags.includes(selectedTag));

  return (
    <>
      <PageHelmet
        title="Études | French Equestrian Clubs Review"
        description="Toutes les études de French Equestrian Clubs Review : transformations historiques, méthodes pédagogiques, dressage, infrastructures et enjeux territoriaux."
        keywords="études équitation, clubs hippiques, analyse centres équestres, dressage, pédagogie équestre"
      />
      <section className={styles.introSection}>
        <div className="container">
          <h1 className={styles.title}>Études et dossiers</h1>
          <p className={styles.lead}>
            Chaque étude associe enquêtes de terrain, analyse documentaire et
            entretiens pour mettre en perspective les évolutions des clubs
            hippiques en France.
          </p>
          <div className={styles.filters} role="tablist" aria-label="Filtrer les études">
            {tags.map((tag) => (
              <button
                type="button"
                key={tag}
                className={`${styles.filterButton} ${
                  selectedTag === tag ? styles.active : ''
                }`}
                onClick={() => setSelectedTag(tag)}
                role="tab"
                aria-selected={selectedTag === tag}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </section>
      <section className={styles.listSection}>
        <div className={`container ${styles.grid}`}>
          {filteredStudies.map((study) => (
            <ArticleCard key={study.id} study={study} />
          ))}
        </div>
      </section>
    </>
  );
};

export default StudiesListingPage;