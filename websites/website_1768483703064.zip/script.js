const navToggle = document.querySelector('.nav-toggle');
const navList = document.querySelector('.nav-list');
const cookieBanner = document.getElementById('cookieBanner');
const acceptCookiesBtn = document.getElementById('acceptCookies');
const declineCookiesBtn = document.getElementById('declineCookies');

if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
        navList.classList.toggle('open');
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', (!expanded).toString());
    });

    navList.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navList.classList.remove('open');
            navToggle.setAttribute('aria-expanded', 'false');
        });
    });
}

const consentKey = 'gcCookieConsent2025';

function hideCookieBanner() {
    if (cookieBanner) {
        cookieBanner.classList.remove('visible');
        setTimeout(() => {
            cookieBanner.style.display = 'none';
        }, 400);
    }
}

if (cookieBanner) {
    const existingConsent = localStorage.getItem(consentKey);
    if (!existingConsent) {
        setTimeout(() => {
            cookieBanner.classList.add('visible');
        }, 800);
    } else {
        hideCookieBanner();
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            hideCookieBanner();
        });
    }

    if (declineCookiesBtn) {
        declineCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'declined');
            hideCookieBanner();
        });
    }
}