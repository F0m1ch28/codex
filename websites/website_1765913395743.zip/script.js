document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const open = navLinks.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(open));
    });
  }

  const forms = document.querySelectorAll("form[data-redirect]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const requiredFields = form.querySelectorAll("[data-required]");
      let valid = true;

      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          valid = false;
          field.classList.add("input-error");
        } else {
          field.classList.remove("input-error");
        }
      });

      const feedback = form.querySelector(".form-feedback");
      if (valid) {
        if (feedback) {
          feedback.textContent = "Submitting...";
          feedback.style.color = "var(--color-secondary)";
        }
        setTimeout(() => {
          window.location.href = form.getAttribute("data-redirect");
        }, 600);
      } else if (feedback) {
        feedback.textContent = "Please complete all required fields before sending.";
        feedback.style.color = "#c12e26";
      }
    });
  });
});