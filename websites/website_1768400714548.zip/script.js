document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && navLinks && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            navLinks.classList.toggle('is-open');
            siteNav.classList.toggle('is-open');
            document.body.classList.toggle('nav-open');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navToggle.classList.contains('is-active')) {
                    navToggle.classList.remove('is-active');
                    navLinks.classList.remove('is-open');
                    siteNav.classList.remove('is-open');
                    document.body.classList.remove('nav-open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
        const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
        const storedConsent = localStorage.getItem('cookieConsent');

        if (!storedConsent) {
            requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
        }

        const handleConsent = (choice) => {
            localStorage.setItem('cookieConsent', choice);
            cookieBanner.classList.remove('is-visible');
        };

        acceptBtn?.addEventListener('click', () => handleConsent('accepted'));
        declineBtn?.addEventListener('click', () => handleConsent('declined'));
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const dogCards = document.querySelectorAll('[data-dog-card]');
    if (filterButtons.length && dogCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const filter = button.dataset.filter;
                filterButtons.forEach(btn => btn.classList.remove('is-active'));
                button.classList.add('is-active');

                dogCards.forEach(card => {
                    const categories = card.dataset.category;
                    const matches = filter === 'all' || categories.includes(filter);
                    card.style.display = matches ? 'flex' : 'none';
                });
            });
        });
    }
});