import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import styles from './App.module.css';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  const [showDisclaimer, setShowDisclaimer] = useState(() => {
    const stored = localStorage.getItem('tphDisclaimer');
    return stored ? JSON.parse(stored) : true;
  });

  useEffect(() => {
    if (!showDisclaimer) {
      localStorage.setItem('tphDisclaimer', 'false');
    }
  }, [showDisclaimer]);

  return (
    <Router>
      <div className={styles.app}>
        <Header />
        <main className={styles.mainContent} role="main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/inflation" element={<Inflation />} />
            <Route path="/course" element={<Course />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<CookiePolicy />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        {showDisclaimer && (
          <div className={styles.disclaimerOverlay} role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
            <div className={styles.disclaimerCard}>
              <h2 id="disclaimer-title">Important Disclaimer</h2>
              <p className={styles.disclaimerText}>
                Мы не предоставляем финансовые услуги.<br />
                We do not provide financial services.<br />
                No brindamos servicios financieros.
              </p>
              <button
                type="button"
                className={styles.disclaimerButton}
                onClick={() => setShowDisclaimer(false)}
              >
                Acknowledge
              </button>
            </div>
          </div>
        )}
        <ScrollToTop />
      </div>
    </Router>
  );
}

export default App;