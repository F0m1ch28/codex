import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [visible, setVisible] = useState(() => {
    const saved = localStorage.getItem('tphCookies');
    return saved ? false : true;
  });

  const [analytics, setAnalytics] = useState(false);

  useEffect(() => {
    if (!visible) {
      const saved = localStorage.getItem('tphCookies');
      if (!saved) {
        localStorage.setItem('tphCookies', JSON.stringify({ necessary: true, analytics }));
      }
    }
  }, [visible, analytics]);

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h2 className={styles.title}>Cookies & Transparency</h2>
        <p className={styles.text}>
          We use necessary cookies to run Tu Progreso Hoy. You may additionally opt-in to analytics cookies that help us understand engagement with our inflation dashboards and learning paths.
        </p>
        <label className={styles.switchLabel}>
          <input
            type="checkbox"
            checked={analytics}
            onChange={(event) => setAnalytics(event.target.checked)}
            aria-label="Enable analytics cookies"
          />
          <span>Enable analytics cookies</span>
        </label>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.accept}
            onClick={() => {
              localStorage.setItem('tphCookies', JSON.stringify({ necessary: true, analytics }));
              setVisible(false);
            }}
          >
            Accept Selection
          </button>
          <button
            type="button"
            className={styles.decline}
            onClick={() => {
              localStorage.setItem('tphCookies', JSON.stringify({ necessary: true, analytics: false }));
              setAnalytics(false);
              setVisible(false);
            }}
          >
            Decline Analytics
          </button>
        </div>
        <a href="/cookies" className={styles.link}>Review Cookie Policy</a>
      </div>
    </div>
  );
}

export default CookieBanner;