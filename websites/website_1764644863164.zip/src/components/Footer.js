import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.overlay} />
      <div className={styles.inner}>
        <div className={styles.brandBlock}>
          <div className={styles.logo}>TPH</div>
          <p className={styles.tagline}>
            Tu Progreso Hoy transforms Argentine inflation indicators into bilingual learning journeys.
          </p>
        </div>
        <div className={styles.grid}>
          <div>
            <h3 className={styles.heading}>Company</h3>
            <ul className={styles.list}>
              <li><NavLink to="/inflation" className={styles.link}>Inflation Insights</NavLink></li>
              <li><NavLink to="/course" className={styles.link}>Course</NavLink></li>
              <li><NavLink to="/resources" className={styles.link}>Resources</NavLink></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Support</h3>
            <ul className={styles.list}>
              <li><NavLink to="/contact" className={styles.link}>Contact</NavLink></li>
              <li><NavLink to="/privacy" className={styles.link}>Privacy Policy</NavLink></li>
              <li><NavLink to="/cookies" className={styles.link}>Cookie Policy</NavLink></li>
              <li><NavLink to="/terms" className={styles.link}>Terms of Use</NavLink></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Contact</h3>
            <div className={styles.contactInfo}>
              <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
              <p><a href="tel:+541155551234" className={styles.link}>+54 11 5555-1234</a></p>
              <p><a href="mailto:hola@tuprogresohoy.com" className={styles.link}>hola@tuprogresohoy.com</a></p>
              <div className={styles.socials}>
                <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn" className={styles.socialIcon}>
                  <i className="fab fa-linkedin-in" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter" className={styles.socialIcon}>
                  <i className="fab fa-twitter" />
                </a>
                <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube" className={styles.socialIcon}>
                  <i className="fab fa-youtube" />
                </a>
              </div>
            </div>
          </div>
        </div>
        <p className={styles.copy}>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;