import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [open, setOpen] = useState(false);

  const handleToggle = () => setOpen((prev) => !prev);
  const handleLinkClick = () => setOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.brand} aria-label="Tu Progreso Hoy Home">
          <div className={styles.logo}>TPH</div>
          <span className={styles.brandText}>Tu Progreso Hoy</span>
        </NavLink>
        <nav className={`${styles.nav} ${open ? styles.navOpen : ''}`} aria-label="Primary">
          <NavLink to="/" onClick={handleLinkClick} className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
            Home
          </NavLink>
          <NavLink to="/inflation" onClick={handleLinkClick} className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
            Inflation
          </NavLink>
          <NavLink to="/course" onClick={handleLinkClick} className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
            Course
          </NavLink>
          <NavLink to="/resources" onClick={handleLinkClick} className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
            Resources
          </NavLink>
          <NavLink to="/contact" onClick={handleLinkClick} className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
            Contact
          </NavLink>
        </nav>
        <button
          type="button"
          className={styles.menuButton}
          onClick={handleToggle}
          aria-expanded={open}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation"
        >
          <span className={styles.menuIcon} />
        </button>
      </div>
    </header>
  );
}

export default Header;