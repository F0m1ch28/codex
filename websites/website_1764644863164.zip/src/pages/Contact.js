import React from 'react';
import styles from './Contact.module.css';

function Contact() {
  return (
    <div className={styles.page}>
      <header className={styles.hero}>
        <div>
          <h1>Connect with Tu Progreso Hoy</h1>
          <p>
            We are based in Buenos Aires and operate across Argentina. Reach out for partnerships, cohort information, or press inquiries.
          </p>
        </div>
      </header>

      <section className={styles.contactGrid} aria-labelledby="contact-info">
        <div className={styles.card} id="contact-info">
          <h2>Contact details</h2>
          <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <p><a href="tel:+541155551234">+54 11 5555-1234</a></p>
          <p><a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a></p>
          <div className={styles.socials}>
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn"><i className="fab fa-linkedin-in" /></a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter"><i className="fab fa-twitter" /></a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube"><i className="fab fa-youtube" /></a>
          </div>
        </div>
        <div className={styles.card}>
          <h2>Send a message</h2>
          <form className={styles.form}>
            <label htmlFor="fullName">
              Full name
              <input id="fullName" type="text" name="fullName" placeholder="Your name" required />
            </label>
            <label htmlFor="email">
              Email
              <input id="email" type="email" name="email" placeholder="you@example.com" required />
            </label>
            <label htmlFor="message">
              Message
              <textarea id="message" name="message" placeholder="How can we support you?" rows="4" required />
            </label>
            <button type="submit">Send message</button>
          </form>
        </div>
      </section>

      <section className={styles.mapSection} aria-labelledby="map-title">
        <div>
          <h2 id="map-title">Visit us in Buenos Aires</h2>
          <p>Our HQ is located near the Obelisco on Avenida 9 de Julio.</p>
        </div>
        <div className={styles.mapWrapper} aria-hidden="true">
          <iframe
            title="Tu Progreso Hoy Buenos Aires map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.5412872471206!2d-58.38414512353012!3d-34.59581187296383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacf15efb867%3A0x6b0496dc392d311b!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>
    </div>
  );
}

export default Contact;