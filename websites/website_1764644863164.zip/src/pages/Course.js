import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Course.module.css';

function Course() {
  return (
    <div className={styles.page}>
      <header className={styles.hero}>
        <div className={styles.heroCopy}>
          <h1>Course syllabus: Personal finance starter kit for Argentina</h1>
          <p>
            This program was designed for analysts, freelancers, graduates, and families who want to interpret inflation data and act with confidence. Content is bilingual (EN/ES) and updated quarterly.
          </p>
          <Link to="/contact" className={styles.cta}>Speak with our team</Link>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img
            src="https://images.pexels.com/photos/3184463/pexels-photo-3184463.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Instructor leading a class"
          />
        </div>
      </header>

      <section className={styles.modules} aria-labelledby="modules-title">
        <h2 id="modules-title">Five modules, one coherent learning experience</h2>
        <div className={styles.moduleGrid}>
          <article className={styles.moduleCard}>
            <h3>Module 1 · Inflation foundations</h3>
            <p>Understand CPI methodology, inflation expectations, and FX dynamics shaping Argentine prices.</p>
            <ul>
              <li>Key monetary policy levers</li>
              <li>FX market glossary</li>
              <li>CPI basket interpretation</li>
            </ul>
          </article>
          <article className={styles.moduleCard}>
            <h3>Module 2 · Budgeting with volatility</h3>
            <p>Design ARS and USD benchmark budgets with realistic buffers and review case studies from Buenos Aires households.</p>
            <ul>
              <li>Scenario planning templates</li>
              <li>Cash flow monitoring toolkit</li>
              <li>Weekly review ritual</li>
            </ul>
          </article>
          <article className={styles.moduleCard}>
            <h3>Module 3 · Savings and protection</h3>
            <p>Learn how to prioritise emergency funds, evaluate local savings products, and communicate plans with loved ones.</p>
            <ul>
              <li>Emergency fund calculator</li>
              <li>Goal prioritisation framework</li>
              <li>Family alignment checklist</li>
            </ul>
          </article>
          <article className={styles.moduleCard}>
            <h3>Module 4 · Planning for milestones</h3>
            <p>From education to housing, we assess how to plan investment-like projects under inflation pressure.</p>
            <ul>
              <li>Milestone scenario board</li>
              <li>FX sensitivity analysis</li>
              <li>Stakeholder communication templates</li>
            </ul>
          </article>
          <article className={styles.moduleCard}>
            <h3>Module 5 · Collaboration & accountability</h3>
            <p>Join live cohorts, share progress, and receive constructive feedback from mentors and peers.</p>
            <ul>
              <li>Weekly cohort stand-ups</li>
              <li>Progress dashboards</li>
              <li>Bilingual resource library</li>
            </ul>
          </article>
        </div>
      </section>

      <section className={styles.audience} aria-labelledby="audience-title">
        <div className={styles.audienceVisual} aria-hidden="true">
          <img
            src="https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Group of learners collaborating"
          />
        </div>
        <div>
          <h2 id="audience-title">Who benefits from this course?</h2>
          <p>
            The Tu Progreso Hoy course equips Argentine professionals, entrepreneurs, and families with practical tools to understand inflation and manage budgets responsibly. It pairs structured lessons with live community sessions to maintain accountability.
          </p>
          <ul className={styles.audienceList}>
            <li>Young professionals building an inflation-aware financial base.</li>
            <li>Freelancers who price services in ARS but reference USD benchmarks.</li>
            <li>Families coordinating monthly budgets under inflation stress.</li>
            <li>Students and graduates entering high-volatility job markets.</li>
          </ul>
        </div>
      </section>

      <section className={styles.ctaSection} aria-labelledby="cta-title">
        <div className={styles.ctaCard}>
          <div>
            <h2 id="cta-title">Ready to start?</h2>
            <p>Join the next bilingual cohort. Submit your details and our team will guide you through the registration process.</p>
            <Link to="/contact" className={styles.ctaButton}>Go to subscription form</Link>
          </div>
          <img
            src="https://images.pexels.com/photos/3184351/pexels-photo-3184351.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Happy learners celebrating progress"
          />
        </div>
      </section>
    </div>
  );
}

export default Course;