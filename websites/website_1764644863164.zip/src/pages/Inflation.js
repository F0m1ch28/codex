import React from 'react';
import styles from './Inflation.module.css';

function Inflation() {
  return (
    <div className={styles.page}>
      <header className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Inflation Methodology & Dashboards</h1>
          <p>
            Our analysts combine official INDEC CPI releases, alternative high-frequency data, and market-based inflation expectations to build contextual dashboards for Argentina-focused learners.
          </p>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img
            src="https://images.pexels.com/photos/669619/pexels-photo-669619.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Chart visualisation"
          />
        </div>
      </header>

      <section className={styles.methodology} aria-labelledby="methodology-title">
        <h2 id="methodology-title">How we build the Tu Progreso Hoy inflation indicators</h2>
        <div className={styles.methodologyGrid}>
          <article className={styles.methodologyCard}>
            <h3>Data Sources</h3>
            <p>We integrate INDEC CPI reports, Banco Central de la República Argentina statements, blue-chip FX observations, and basket-level price samples gathered from Buenos Aires retailers.</p>
          </article>
          <article className={styles.methodologyCard}>
            <h3>Normalisation</h3>
            <p>Each dataset is harmonised to weekly intervals. FX movements (official, MEP, blue) are volatility-adjusted to isolate structural trends. CPI weights follow the latest national household consumption survey.</p>
          </article>
          <article className={styles.methodologyCard}>
            <h3>Cross-Validation</h3>
            <p>We compare our derived inflation indicator against academic references and independent research groups. Divergences trigger manual reviews to maintain methodological integrity.</p>
          </article>
        </div>
      </section>

      <section className={styles.visualisations} aria-labelledby="visualisations-title">
        <div className={styles.visualHeader}>
          <h2 id="visualisations-title">Interactive dashboards</h2>
          <p>Track weekly ARS purchasing power, see CPI category decompositions, and compare inflation to exchange-rate movements.</p>
        </div>
        <div className={styles.chartGrid}>
          <div className={styles.chartCard}>
            <img src="https://images.pexels.com/photos/7567430/pexels-photo-7567430.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Line chart showing inflation trend" />
            <div className={styles.chartBody}>
              <h3>CPI vs FX correlations</h3>
              <p>Understand how tradable goods and services react to FX shocks by exploring our cross-correlation heatmaps.</p>
            </div>
          </div>
          <div className={styles.chartCard}>
            <img src="https://images.pexels.com/photos/6476584/pexels-photo-6476584.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Analyst reviewing data" />
            <div className={styles.chartBody}>
              <h3>Spending basket simulator</h3>
              <p>Adjust household categories and simulate how price changes impact your monthly cash flow in ARS terms.</p>
            </div>
          </div>
          <div className={styles.chartCard}>
            <img src="https://images.pexels.com/photos/5863381/pexels-photo-5863381.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Team discussion with charts" />
            <div className={styles.chartBody}>
              <h3>Policy watch briefings</h3>
              <p>Receive annotations on monetary decisions and fiscal measures that influence short-term inflation dynamics.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.context} aria-labelledby="context-title">
        <div>
          <h2 id="context-title">CPI and FX context explained</h2>
          <p>
            Argentina’s inflation is impacted by fiscal anchors, monetary issuance, commodity exports, and imported inputs. Tu Progreso Hoy summarises complex drivers into bilingual digests, highlighting how each factor affects household budgets and savings plans.
          </p>
          <ul className={styles.contextList}>
            <li>Monthly CPI breakdown: Housing, transport, food, education, and health.</li>
            <li>FX gap tracker: Official vs MEP vs informal market spreads.</li>
            <li>Purchasing power index: Adjusts salaries and freelance rates to inflationary dynamics.</li>
            <li>Scenario narratives: Probabilistic outlooks for the next quarter with actionable checkpoints.</li>
          </ul>
        </div>
        <div className={styles.contextVisual} aria-hidden="true">
          <img src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Buenos Aires financial district" />
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-title">
        <h2 id="faq-title">Frequently asked questions</h2>
        <div className={styles.faqList}>
          <details>
            <summary>Do you provide investment or financial advice?</summary>
            <p>No. Tu Progreso Hoy is strictly educational. Мы не предоставляем финансовые услуги. No brindamos servicios financieros.</p>
          </details>
          <details>
            <summary>How often are inflation dashboards updated?</summary>
            <p>Major datasets refresh weekly, with important releases (e.g., INDEC CPI) highlighted the same day they become public.</p>
          </details>
          <details>
            <summary>Can I download the data?</summary>
            <p>Yes. Subscribers receive CSV and bilingual PDF exports with proper citations and methodology notes.</p>
          </details>
        </div>
      </section>
    </div>
  );
}

export default Inflation;