import React from 'react';
import styles from './CookiePolicy.module.css';

function CookiePolicy() {
  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <h1>Cookie Policy</h1>
        <p>This Cookie Policy explains how Tu Progreso Hoy uses cookies and similar technologies.</p>

        <h2>1. Necessary cookies</h2>
        <p>These cookies support essential functions such as language preferences and secure login areas. They are always active.</p>

        <h2>2. Analytics cookies</h2>
        <p>Analytics cookies track usage to improve educational experiences. They operate only when you opt-in through our banner.</p>

        <h2>3. Managing cookies</h2>
        <p>You can adjust browser settings to control cookies. Declining analytics cookies does not affect access to core resources.</p>

        <h2>4. Updates</h2>
        <p>We may update this policy to reflect new functionality. Changes are effective when posted.</p>

        <h2>5. Contact</h2>
        <p>Questions? Email hola@tuprogresohoy.com.</p>
      </div>
    </div>
  );
}

export default CookiePolicy;