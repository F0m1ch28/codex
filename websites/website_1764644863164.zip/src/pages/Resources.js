import React, { useState } from 'react';
import styles from './Resources.module.css';

const categories = ['All', 'Articles', 'Glossaries', 'Guides'];

const resourcesData = [
  {
    id: 1,
    title: 'Understanding Argentine CPI releases',
    language: 'EN',
    category: 'Articles',
    description: 'Step-by-step guide to interpreting monthly CPI statements and their implications for household planning.',
    link: '#'
  },
  {
    id: 2,
    title: 'Glosario: Tipos de cambio y brecha',
    language: 'ES',
    category: 'Glossaries',
    description: 'Definiciones claras sobre dólar oficial, MEP, CCL y otros términos que influyen en la conversación cotidiana.',
    link: '#'
  },
  {
    id: 3,
    title: 'Weekly ARS budget retro worksheet',
    language: 'EN',
    category: 'Guides',
    description: 'Template for reviewing your spending vs. plan each week, aligned with Tu Progreso Hoy dashboard metrics.',
    link: '#'
  },
  {
    id: 4,
    title: 'Guía práctica: Planificación de ahorros familiares',
    language: 'ES',
    category: 'Guides',
    description: 'Pasos accionables para armar un fondo de emergencia y proteger decisiones clave frente a la inflación.',
    link: '#'
  },
  {
    id: 5,
    title: 'Currency volatility explainer',
    language: 'EN',
    category: 'Articles',
    description: 'A narrative overview of how global events and local policy shifts impact Argentine currency fluctuations.',
    link: '#'
  },
  {
    id: 6,
    title: 'Glosario bilingüe de educación financiera',
    language: 'ES',
    category: 'Glossaries',
    description: 'Lista de términos clave con traducciones y ejemplos para discusiones familiares y laborales.',
    link: '#'
  }
];

function Resources() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredResources = resourcesData.filter((item) => {
    if (activeCategory === 'All') return true;
    return item.category === activeCategory;
  });

  return (
    <div className={styles.page}>
      <header className={styles.hero}>
        <div className={styles.heroCopy}>
          <h1>Bilingual resource library</h1>
          <p>Downloadable templates, glossaries, and articles that translate inflation data into day-to-day actions.</p>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img
            src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Reading financial resources"
          />
        </div>
      </header>

      <section className={styles.filters} aria-label="Resource filters">
        <div className={styles.filterButtons}>
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${activeCategory === category ? styles.active : ''}`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      <section className={styles.grid} aria-labelledby="resources-list">
        <h2 id="resources-list" className={styles.srOnly}>Resource list</h2>
        {filteredResources.map((resource) => (
          <article key={resource.id} className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.language}>{resource.language}</span>
              <span className={styles.category}>{resource.category}</span>
            </div>
            <h3>{resource.title}</h3>
            <p>{resource.description}</p>
            <a href={resource.link} className={styles.downloadLink}>
              View resource <i className="fas fa-arrow-right" aria-hidden="true" />
            </a>
          </article>
        ))}
        {filteredResources.length === 0 && (
          <p className={styles.emptyState}>No resources available in this category yet. Check back soon.</p>
        )}
      </section>
    </div>
  );
}

export default Resources;