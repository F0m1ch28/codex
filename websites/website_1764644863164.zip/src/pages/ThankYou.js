import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

function ThankYou() {
  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.icon}>
          <i className="fas fa-check" aria-hidden="true" />
        </div>
        <h1>Thank you!</h1>
        <p>We received your request. Please confirm your email to activate the free trial lesson invitation. Our team will be in touch shortly.</p>
        <Link to="/" className={styles.button}>Return to homepage</Link>
      </div>
    </div>
  );
}

export default ThankYou;