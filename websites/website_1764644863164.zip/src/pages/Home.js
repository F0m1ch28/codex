import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './Home.module.css';

const fallbackRates = [
  { date: 'Day 1', value: 0.0027 },
  { date: 'Day 2', value: 0.00265 },
  { date: 'Day 3', value: 0.00258 },
  { date: 'Day 4', value: 0.00261 },
  { date: 'Day 5', value: 0.00255 },
  { date: 'Day 6', value: 0.00257 },
  { date: 'Day 7', value: 0.0026 }
];

function Home() {
  const [exchangeRate, setExchangeRate] = useState(null);
  const [chartData, setChartData] = useState(fallbackRates);
  const [statusMessage, setStatusMessage] = useState('Loading latest ARS→USD rate...');
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [step, setStep] = useState('form');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const response = await fetch('https://open.er-api.com/v6/latest/ARS');
        const data = await response.json();
        if (data && data.result === 'success' && data.rates && data.rates.USD) {
          setExchangeRate(data.rates.USD);
          setStatusMessage(`Live rate: 1 ARS ≈ ${data.rates.USD.toFixed(4)} USD`);
          const simulated = chartData.map((point, index) => {
            const variance = (Math.random() - 0.5) * 0.00005;
            return {
              ...point,
              value: data.rates.USD + variance * (index + 1)
            };
          });
          setChartData(simulated);
        } else {
          setStatusMessage('Live rate temporarily unavailable. Showing weekly trend.');
        }
      } catch (error) {
        setStatusMessage('Live rate temporarily unavailable. Showing weekly trend.');
      }
    };
    fetchRate();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setStep('doubleOptIn');
  };

  const handleConfirm = () => {
    setStep('confirmed');
    setTimeout(() => {
      navigate('/thank-you');
    }, 600);
  };

  const svgPoints = chartData
    .map((point, index) => {
      const x = (index / (chartData.length - 1)) * 100;
      const min = Math.min(...chartData.map((p) => p.value));
      const max = Math.max(...chartData.map((p) => p.value));
      const y = 100 - ((point.value - min) / (max - min || 1)) * 100;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <div className={styles.wrapper}>
      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={styles.heroContent}>
          <span className={styles.badge}>Bilingual Insights · Argentina Focused</span>
          <h1 id="hero-title">
            Navigate ARS→USD shifts with clarity and learn the personal finance essentials that matter today.
          </h1>
          <p className={styles.heroSubtitle}>
            Tu Progreso Hoy connects inflation data, FX context, and practical lessons so emerging professionals can make informed, deliberate decisions in a high-volatility environment.
          </p>
          <div className={styles.heroActions}>
            <Link to="/inflation" className={styles.primaryAction}>View Inflation Dashboard</Link>
            <Link to="/course" className={styles.secondaryAction}>Review the Course</Link>
          </div>
          <div className={styles.heroStats}>
            <div className={styles.statCard}>
              <i className="fas fa-chart-line" aria-hidden="true" />
              <div>
                <p className={styles.statLabel}>Daily ARS→USD Signal</p>
                <p className={styles.statValue}>{exchangeRate ? exchangeRate.toFixed(4) : '0.0026'} USD</p>
              </div>
            </div>
            <div className={styles.statCard}>
              <i className="fas fa-graduation-cap" aria-hidden="true" />
              <div>
                <p className={styles.statLabel}>Learning Hours</p>
                <p className={styles.statValue}>24 curated sessions</p>
              </div>
            </div>
            <div className={styles.statCard}>
              <i className="fas fa-map-marker-alt" aria-hidden="true" />
              <div>
                <p className={styles.statLabel}>Buenos Aires Expertise</p>
                <p className={styles.statValue}>Localised guidance</p>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.heroImage} role="presentation" aria-hidden="true" />
      </section>

      <section className={styles.promises} aria-labelledby="promise-title">
        <h2 id="promise-title">What makes Tu Progreso Hoy different?</h2>
        <div className={styles.promiseGrid}>
          <article className={styles.promiseCard}>
            <div className={styles.iconWrapper}>
              <i className="fas fa-database" aria-hidden="true" />
            </div>
            <h3>Contextual Data Stories</h3>
            <p>We blend CPI releases, FX market microstructure, and seasonal trends to provide narratives that resonate with Argentine daily life.</p>
          </article>
          <article className={styles.promiseCard}>
            <div className={styles.iconWrapper}>
              <i className="fas fa-chalkboard-teacher" aria-hidden="true" />
            </div>
            <h3>Live Classroom Sessions</h3>
            <p>Weekly bilingual workshops spotlight real inflation scenarios, budget simulations, and saving strategies anchored in current numbers.</p>
          </article>
          <article className={styles.promiseCard}>
            <div className={styles.iconWrapper}>
              <i className="fas fa-user-shield" aria-hidden="true" />
            </div>
            <h3>Compliance & Integrity</h3>
            <p>Clear disclaimers and responsible communication ensure every insight stays educational, never prescriptive.</p>
          </article>
        </div>
      </section>

      <section className={styles.tracker} aria-labelledby="tracker-title">
        <div className={styles.trackerContent}>
          <h2 id="tracker-title">ARS→USD Daily Tracker</h2>
          <p className={styles.trackerText}>
            Stay ahead with morning updates and contextual commentary that link monetary policy signals to the price you pay at the checkout counter. Each data point is peer-reviewed before publication.
          </p>
          <p className={styles.trackerStatus}>{statusMessage}</p>
          <div className={styles.chartContainer} role="img" aria-label="Seven day ARS to USD trend">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className={styles.chart}>
              <polyline
                fill="none"
                stroke="#2563EB"
                strokeWidth="3"
                points={svgPoints}
              />
              <linearGradient id="gradientFill" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="rgba(37,99,235,0.35)" />
                <stop offset="100%" stopColor="rgba(15,23,42,0.05)" />
              </linearGradient>
              <polygon
                points={`0,100 ${svgPoints} 100,100`}
                fill="url(#gradientFill)"
                stroke="none"
                opacity="0.65"
              />
            </svg>
            <div className={styles.chartLabels}>
              {chartData.map((point) => (
                <span key={point.date}>{point.date}</span>
              ))}
            </div>
          </div>
        </div>
        <div className={styles.trackerVisual} aria-hidden="true">
          <img
            src="https://images.pexels.com/photos/669619/pexels-photo-669619.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Data dashboard preview"
          />
        </div>
      </section>

      <section className={styles.insights} aria-labelledby="insights-title">
        <h2 id="insights-title">Inflation insights anchored in Buenos Aires reality</h2>
        <div className={styles.insightsGrid}>
          <article className={styles.insightCard}>
            <img src="https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Buenos Aires skyline" />
            <div className={styles.insightBody}>
              <h3>Metropolitan Price Watch</h3>
              <p>Compare promedio mensual for key barrios and discover how transport, groceries, and services respond to official CPI releases.</p>
            </div>
          </article>
          <article className={styles.insightCard}>
            <img src="https://images.pexels.com/photos/210607/pexels-photo-210607.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Financial charts and coins" />
            <div className={styles.insightBody}>
              <h3>Scenario Planning Toolkit</h3>
              <p>Model weekly ARS cash flow, set emergency buckets, and draft realistic saving goals aligned with inflation-adjusted benchmarks.</p>
            </div>
          </article>
          <article className={styles.insightCard}>
            <img src="https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Team of professionals collaborating" />
            <div className={styles.insightBody}>
              <h3>Collective Intelligence</h3>
              <p>Collaborate with analysts, educators, and learners who share field notes, curated reading lists, and bilingual templates.</p>
            </div>
          </article>
        </div>
      </section>

      <section className={styles.course} aria-labelledby="course-title">
        <div className={styles.courseVisual} aria-hidden="true">
          <img
            src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Learners participating in a workshop"
          />
        </div>
        <div className={styles.courseContent}>
          <h2 id="course-title">Course overview: Personal finance foundations for Argentina</h2>
          <ul className={styles.courseList}>
            <li><strong>Module 1:</strong> Understanding Argentine inflation mechanics and FX market signals.</li>
            <li><strong>Module 2:</strong> Building an inflation-aware budget in both ARS and USD references.</li>
            <li><strong>Module 3:</strong> Savings strategies, emergency funds, and prioritising short-term needs.</li>
            <li><strong>Module 4:</strong> Planning for education, housing, and long-term milestones amid price volatility.</li>
            <li><strong>Module 5:</strong> Communication tools for family and teams, including bilingual templates.</li>
          </ul>
          <Link to="/course" className={styles.courseButton}>Explore full syllabus</Link>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-title">
        <h2 id="testimonials-title">Learners who trust Tu Progreso Hoy</h2>
        <div className={styles.testimonialGrid}>
          <figure className={styles.testimonialCard}>
            <blockquote>
              “The ARS→USD daily tracker helped my team stay calm when prices spiked. Each lesson translated macro news into practical budget actions.”
            </blockquote>
            <figcaption>
              <img src="https://images.pexels.com/photos/3184451/pexels-photo-3184451.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Learner portrait" />
              <div>
                <span className={styles.clientName}>Valentina G.</span>
                <span className={styles.clientRole}>Strategy Analyst, Palermo</span>
              </div>
            </figcaption>
          </figure>
          <figure className={styles.testimonialCard}>
            <blockquote>
              “Every worksheet is bilingual, which made it easy to bring insights back to my family. The inflation briefings are concise and evidence-based.”
            </blockquote>
            <figcaption>
              <img src="https://images.pexels.com/photos/1181681/pexels-photo-1181681.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Learner portrait" />
              <div>
                <span className={styles.clientName}>Mariano L.</span>
                <span className={styles.clientRole}>Operations Lead, Recoleta</span>
              </div>
            </figcaption>
          </figure>
          <figure className={styles.testimonialCard}>
            <blockquote>
              “I appreciate the careful disclaimers and the focus on informed decision-making. The community forum provides weekly accountability.”
            </blockquote>
            <figcaption>
              <img src="https://images.pexels.com/photos/1181579/pexels-photo-1181579.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="Learner portrait" />
              <div>
                <span className={styles.clientName}>Lucía A.</span>
                <span className={styles.clientRole}>Product Manager, Caballito</span>
              </div>
            </figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.resources} aria-labelledby="resources-title">
        <div className={styles.resourcesContent}>
          <h2 id="resources-title">Resources to sustain your progress</h2>
          <p>
            Access bilingual glossaries, scenario templates, and curated reads that translate complex indicators into actionable routines. Updated weekly with community feedback.
          </p>
          <Link to="/resources" className={styles.resourcesButton}>Browse Resources</Link>
        </div>
        <div className={styles.resourcesVisual} aria-hidden="true">
          <img
            src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Documents and reading materials"
          />
        </div>
      </section>

      <form className={styles.fixedForm} onSubmit={handleSubmit} aria-label="Request a free trial lesson">
        <div className={styles.formContent}>
          <h3 className={styles.formTitle}>Получить бесплатный пробный урок</h3>
          {step === 'form' && (
            <>
              <div className={styles.formFields}>
                <label htmlFor="name">
                  Full name
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="Your name"
                  />
                </label>
                <label htmlFor="email">
                  Email address
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    placeholder="you@example.com"
                  />
                </label>
              </div>
              <button type="submit" className={styles.submitButton}>
                Request Access
              </button>
              <p className={styles.formNote}>
                By submitting you agree to receive educational emails from Tu Progreso Hoy. We will never offer financial products.
              </p>
            </>
          )}
          {step === 'doubleOptIn' && (
            <div className={styles.doubleOptIn}>
              <p>Please check your inbox and confirm your email. For demonstration, you can confirm now.</p>
              <button type="button" className={styles.confirmButton} onClick={handleConfirm}>
                Confirm Opt-In
              </button>
            </div>
          )}
          {step === 'confirmed' && (
            <p className={styles.confirmed}>Thank you! Redirecting to the confirmation page...</p>
          )}
        </div>
      </form>
    </div>
  );
}

export default Home;