import React from 'react';
import styles from './Terms.module.css';

function Terms() {
  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <h1>Terms of Use</h1>
        <p>Welcome to Tu Progreso Hoy. These Terms of Use govern your access to and use of our website, dashboards, and educational materials. By accessing this site, you agree to comply with these terms.</p>

        <h2>1. Educational purpose</h2>
        <p>Tu Progreso Hoy provides educational content focused on inflation, ARS→USD context, and personal finance fundamentals. Мы не предоставляем финансовые услуги. No brindamos servicios financieros.</p>

        <h2>2. User responsibilities</h2>
        <p>You agree to use the site responsibly, respect intellectual property, and refrain from actions that could disrupt our services.</p>

        <h2>3. Intellectual property</h2>
        <p>All text, graphics, and resources are owned by Tu Progreso Hoy or our licensors. You may not reproduce or distribute content without permission.</p>

        <h2>4. Limitations of liability</h2>
        <p>While we strive to ensure accuracy, we do not warrant that the information is exhaustive or error-free. Decisions based on our content are your responsibility.</p>

        <h2>5. Changes to terms</h2>
        <p>We may update these terms to reflect new features or legal requirements. Continued use of the site indicates acceptance of the updated terms.</p>

        <h2>6. Contact</h2>
        <p>Questions about these terms? Email us at hola@tuprogresohoy.com.</p>
      </div>
    </div>
  );
}

export default Terms;