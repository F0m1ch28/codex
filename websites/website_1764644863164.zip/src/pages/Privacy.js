import React from 'react';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <h1>Privacy Policy</h1>
        <p>This policy outlines how Tu Progreso Hoy collects, uses, and protects personal information.</p>

        <h2>1. Information we collect</h2>
        <p>We collect contact details you provide when requesting resources or subscribing to newsletters. We also gather analytics data if you opt-in.</p>

        <h2>2. How we use information</h2>
        <p>Data supports educational communications, cohort coordination, and service improvements. Мы не предоставляем финансовые услуги. No brindamos servicios financieros.</p>

        <h2>3. Cookies</h2>
        <p>Necessary cookies support basic functionality. Analytics cookies operate only with explicit consent. Review our Cookie Policy for details.</p>

        <h2>4. Data security</h2>
        <p>We implement administrative and technical safeguards to protect your data against unauthorised access.</p>

        <h2>5. Your rights</h2>
        <p>You may request access, correction, or deletion of your personal data by contacting hola@tuprogresohoy.com.</p>

        <h2>6. Updates</h2>
        <p>We will update this policy as regulations evolve. Changes take effect upon publication.</p>
      </div>
    </div>
  );
}

export default Privacy;