import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Funktionen.module.css';

function Funktionen() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSegment, setSelectedSegment] = useState('Standorte');
  const [surveyIndex, setSurveyIndex] = useState(0);

  const surveyData = [
    { label: 'Engagement-Score', value: 82 },
    { label: 'Commitment', value: 76 },
    { label: 'Teamzusammenhalt', value: 88 }
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Funktionen | Qorvixium Plattform</title>
        <meta
          name="description"
          content="Entdecken Sie die Funktionen von Qorvixium: Ankündigungen mit Lesebestätigung, Newsletter-Orchestrierung, Puls-Umfragen, Wissensdatenbank, Kalender und Engagement Analytics."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Alle Module für Ihre interne Kommunikation</h1>
        <p>
          Von Ankündigungen bis zu Engagement Analytics – orchestrieren Sie Ihre Kommunikationsprozesse sicher und skalierbar.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Ankündigungs-Feed mit Gelesen-Status</h2>
        <div className={styles.announcement}>
          <div className={styles.feed}>
            <header>
              <span>Aktuelle Bekanntmachungen</span>
              <button
                type="button"
                className={`focus-outline ${styles.quickAction}`}
                onClick={() => setIsModalOpen(true)}
              >
                Lesebestätigung simulieren
              </button>
            </header>
            <ul>
              <li>
                <span className={styles.status} aria-hidden="true">
                  •
                </span>
                <div>
                  <strong>Vorstandsupdates Q3</strong>
                  <p>Segment Führungskräfte · Fälligkeit 18.09 · Lesebestätigung 94%</p>
                </div>
              </li>
              <li>
                <span className={`${styles.status} ${styles.read}`} aria-hidden="true">
                  •
                </span>
                <div>
                  <strong>Sicherheitsrichtlinie 2.1</strong>
                  <p>Segment Produktion · Version 02 · Lesebestätigung 87%</p>
                </div>
              </li>
              <li>
                <span className={`${styles.status} ${styles.pending}`} aria-hidden="true">
                  •
                </span>
                <div>
                  <strong>HR Benefits Update</strong>
                  <p>Segment Verwaltung · Erinnerung geplant · Lesebestätigung 73%</p>
                </div>
              </li>
            </ul>
          </div>
          <div className={styles.feedDetails}>
            <h3>Automatisierte Erinnerungen</h3>
            <p>Definieren Sie Fälligkeiten, eskalieren Sie an Führungskräfte und behalten Sie Nachweise im Audit-Trail.</p>
            <div className={styles.channels}>
              <span>E-Mail</span>
              <span>Teams</span>
              <span>Mobile App</span>
              <span>Intranet</span>
            </div>
          </div>
        </div>
        {isModalOpen && (
          <div className={styles.modalBackdrop} role="dialog" aria-modal="true">
            <div className={styles.modal}>
              <h3>Lesebestätigung</h3>
              <p>„Ich bestätige, dass ich die Richtlinie gelesen habe.“</p>
              <div className={styles.modalActions}>
                <button type="button" onClick={() => setIsModalOpen(false)} className="focus-outline">
                  Abbrechen
                </button>
                <button type="button" className="focus-outline">
                  Bestätigen
                </button>
              </div>
            </div>
          </div>
        )}
      </section>

      <section className={styles.section}>
        <h2>E-Mail &amp; Messenger Newsletter</h2>
        <div className={styles.newsletter}>
          <div>
            <h3>Template Builder</h3>
            <p>Responsive Layouts, Inhaltsblöcke, dynamische Zielgruppen und Versandplanung.</p>
            <ul>
              <li>Drag &amp; Drop Editor</li>
              <li>Double-Opt-In Verwaltung</li>
              <li>Adaptive Rules für Microsoft Teams &amp; Slack</li>
              <li>Analytics: Öffnungen, Klicks, Segmentierung</li>
            </ul>
          </div>
          <div className={styles.newsletterPreview}>
            <header>
              <span>Qorvixium Newsletter</span>
              <span>Segment Führungskräfte</span>
            </header>
            <article>
              <h4>Strategie-Update</h4>
              <p>Kurzer Überblick zur Ausrichtung 2024 mit Key Results.</p>
              <button type="button" className="focus-outline">
                Abschnitt hinzufügen
              </button>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Puls-Umfragen &amp; Engagement Analytics</h2>
        <div className={styles.analytics}>
          <div className={styles.chart}>
            <div className={styles.chartHeader}>
              <button
                type="button"
                className={surveyIndex === 0 ? styles.activeTab : ''}
                onClick={() => setSurveyIndex(0)}
              >
                Gesamt
              </button>
              <button
                type="button"
                className={surveyIndex === 1 ? styles.activeTab : ''}
                onClick={() => setSurveyIndex(1)}
              >
                Führung
              </button>
              <button
                type="button"
                className={surveyIndex === 2 ? styles.activeTab : ''}
                onClick={() => setSurveyIndex(2)}
              >
                Produktion
              </button>
            </div>
            <div className={styles.chartBody}>
              {surveyData.map((item, index) => (
                <div key={item.label} className={styles.bar}>
                  <span>{item.label}</span>
                  <div className={styles.barTrack}>
                    <div style={{ width: `${item.value - surveyIndex * 6}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3>Trend-Analyse</h3>
            <p>
              Beobachten Sie Stimmungs-Verläufe über Wochen und identifizieren Sie präzise Handlungsfelder mit Segmentierung nach Team, Standort oder Rolle.
            </p>
            <ul>
              <li>Heatmaps &amp; Sentiment-Score</li>
              <li>Kommentar-Streams mit Sentiment-Tagging</li>
              <li>Export in BI-Systeme (CSV, API)</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Zielgruppen-Segmentierung</h2>
        <div className={styles.segmentation}>
          <aside>
            {['Standorte', 'Rollen', 'Skills', 'Sprachen'].map((segment) => (
              <button
                key={segment}
                type="button"
                className={selectedSegment === segment ? styles.segmentActive : ''}
                onClick={() => setSelectedSegment(segment)}
              >
                {segment}
              </button>
            ))}
          </aside>
          <div className={styles.segmentContent}>
            <h3>{selectedSegment}</h3>
            <p>
              Erstellen Sie granulare Zielgruppen, synchronisiert über SCIM und SSO. Regeln können gestapelt und mit
              Live-Vorschau geprüft werden.
            </p>
            <div className={styles.segmentTags}>
              <span>Standort: Berlin</span>
              <span>Abteilung: Produktion</span>
              <span>Skill: Lean</span>
              <span>Sprache: DE</span>
            </div>
            <p>Mit Rollenbasierter Kontrolle (RBAC) werden Freigaben und Verantwortlichkeiten nachvollziehbar.</p>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Wissensdatenbank</h2>
        <div className={styles.knowledge}>
          <div className={styles.articleList}>
            <article>
              <h3>COVID-Update (Archiv)</h3>
              <p>Versioniert · Lesestatistik · Feedbackfunktion</p>
            </article>
            <article>
              <h3>Onboarding Toolkit</h3>
              <p>Interaktive Checkliste, Video, Quiz, Feedback</p>
            </article>
            <article>
              <h3>Produktionsrichtlinie 5.0</h3>
              <p>Audit-Trail, mehrsprachig, Freigabe-Kette</p>
            </article>
          </div>
          <div className={styles.articleDetail}>
            <h3>Artikelstruktur</h3>
            <p>
              Inhaltsverzeichnis, Kontextlinks, Dateianhänge und Feedback. Nutzerinnen und Nutzer bewerten Relevanz und schlagen Aktualisierungen vor.
            </p>
            <button type="button" className="focus-outline">
              Wissensartikel erstellen
            </button>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Ereignis-Kalender</h2>
        <div className={styles.calendar}>
          <div className={styles.calendarHeader}>
            <span>September 2024</span>
            <div>
              <button type="button" className="focus-outline">
                ‹
              </button>
              <button type="button" className="focus-outline">
                ›
              </button>
            </div>
          </div>
          <div className={styles.calendarGrid}>
            {['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((day) => (
              <div key={day} className={styles.calendarDayLabel}>
                {day}
              </div>
            ))}
            {Array.from({ length: 30 }).map((_, index) => (
              <div key={index} className={styles.calendarDay}>
                <span>{index + 1}</span>
                {index === 3 && <small>Townhall</small>}
                {index === 12 && <small>Schulung</small>}
                {index === 18 && <small>Audit</small>}
              </div>
            ))}
          </div>
        </div>
        <div className={styles.calendarDetails}>
          <h3>Synchronisation</h3>
          <p>iCal Feeds, Outlook Sync, ICS Export sowie Team-spezifische Kalenderansichten integrieren sich nahtlos.</p>
          <p>Automatische Benachrichtigungen und Erinnerungen sorgen für reibungslose Teilnahme.</p>
        </div>
      </section>
    </div>
  );
}

export default Funktionen;