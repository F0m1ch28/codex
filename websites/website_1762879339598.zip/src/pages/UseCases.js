import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './UseCases.module.css';

const cases = [
  {
    title: 'HR-Kommunikation',
    description:
      'Benefits, People Analytics und Change-Programme werden über Ankündigungen, Newsletter und Puls-Umfragen orchestriert. RBAC sichert sensible Informationen ab.',
    outcomes: ['Benefit Adoption +24%', 'Feedbackquote +36%', 'Onboarding Journeys vollständig digital']
  },
  {
    title: 'Führungskommunikation',
    description:
      'C-Level und Führungskräfte teilen Strategie, Ziele und Krisenupdates. Lesebestätigung, FAQ-Streams und Analytics sorgen für Klarheit.',
    outcomes: ['Lesebestätigung 96%', 'Schnellere Eskalation', 'Transparente Kommunikationspfade']
  },
  {
    title: 'Mitarbeiter-Onboarding',
    description:
      'Guided Journeys mit Wissensartikeln, automatisierten Aufgaben, Kalenderereignissen und Puls-Checks bieten eine strukturierte Lernreise.',
    outcomes: ['Ramp-up schneller', 'Feedbackschleifen integriert', 'Segmentierte Journeys für Rollen']
  },
  {
    title: 'Compliance & Sicherheit',
    description:
      'Richtlinien, Audits und Trainings werden dokumentiert, versioniert und mit Nachweisketten versehen. Analytics zeigt Risikobereiche.',
    outcomes: ['Audit-Quote verbessert', 'Automatisierte Eskalationen', 'Revisionssichere Historie']
  }
];

function UseCases() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Use Cases | Qorvixium in der Praxis</title>
        <meta
          name="description"
          content="Qorvixium adressiert zentrale Use Cases wie HR-Kommunikation, Führungskommunikation, Mitarbeiter-Onboarding und Compliance & Sicherheit."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Use Cases</h1>
        <p>Qorvixium unterstützt Teams in allen Kommunikationsszenarien – flexibel, sicher und messbar.</p>
      </header>
      <div className={styles.caseGrid}>
        {cases.map((useCase) => (
          <article key={useCase.title} className={styles.caseCard}>
            <h2>{useCase.title}</h2>
            <p>{useCase.description}</p>
            <ul>
              {useCase.outcomes.map((outcome) => (
                <li key={outcome}>{outcome}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </div>
  );
}

export default UseCases;