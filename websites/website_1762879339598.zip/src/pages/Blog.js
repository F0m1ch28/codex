import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    id: 1,
    title: '5 Prinzipien für transparente interne Kommunikation',
    category: 'Strategie',
    summary:
      'Klare Strukturen, einheitliche Botschaften und Messbarkeit sind der Schlüssel zu nachhaltiger Kommunikation.',
    date: '08. September 2024'
  },
  {
    id: 2,
    title: 'Mitarbeiter-Newsletter: Architektur für hohe Öffnungsraten',
    category: 'Newsletter',
    summary:
      'Wie Themenplanung, Zielgruppen-Segmentierung und persönliche Ansprache wirken.',
    date: '02. September 2024'
  },
  {
    id: 3,
    title: 'Puls-Umfragen & Engagement Analytics in Echtzeit',
    category: 'Analytics',
    summary:
      'Dashboards, Segmentierung und Alerts geben HR und Führungskräften sofortige Orientierung.',
    date: '29. August 2024'
  },
  {
    id: 4,
    title: 'Wissensdatenbank als Single Source of Truth',
    category: 'Wissen',
    summary:
      'Strukturierte Artikel, Feedback und Versionierung erhöhen Akzeptanz und Vertrauen.',
    date: '23. August 2024'
  }
];

function Blog() {
  const [category, setCategory] = useState('Alle');

  const categories = useMemo(() => ['Alle', ...new Set(posts.map((post) => post.category))], []);
  const filteredPosts = useMemo(
    () => (category === 'Alle' ? posts : posts.filter((post) => post.category === category)),
    [category]
  );

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Blog &amp; Insights | Qorvixium</title>
        <meta
          name="description"
          content="Insights, Tipps und Best Practices rund um interne Kommunikation, Newsletter, Puls-Umfragen, Wissensdatenbank und Engagement Analytics."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Blog &amp; Insights</h1>
        <p>Impulse für Ihre interne Kommunikation, direkt aus der Praxis.</p>
      </header>
      <div className={styles.filterBar}>
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            className={category === cat ? styles.active : ''}
            onClick={() => setCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>
      <div className={styles.postGrid}>
        {filteredPosts.map((post) => (
          <article key={post.id} className={styles.postCard}>
            <h2>{post.title}</h2>
            <span className={styles.meta}>
              {post.category} • {post.date}
            </span>
            <p>{post.summary}</p>
            <button type="button" className="focus-outline">
              Beitrag lesen
            </button>
          </article>
        ))}
      </div>
    </div>
  );
}

export default Blog;