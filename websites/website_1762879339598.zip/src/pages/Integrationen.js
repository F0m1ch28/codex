import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Integrationen.module.css';

const integrations = [
  {
    name: 'Microsoft 365',
    details: 'Synchronisation mit Outlook, SharePoint, Teams sowie Azure Active Directory.',
    capabilities: ['Single Sign-on', 'Kalender Sync', 'SharePoint Wissenshub']
  },
  {
    name: 'Google Workspace',
    details: 'Anbindung von Gmail, Kalender, Drive und Directory Services.',
    capabilities: ['E-Mail Versand', 'Drive-Verknüpfungen', 'User Provisioning']
  },
  {
    name: 'Slack & Teams',
    details: 'Direkte Benachrichtigungen, Zielgruppen-Channels und interaktive Bots.',
    capabilities: ['Adaptive Cards', 'Lesebestätigung', 'Feedback-Streams']
  },
  {
    name: 'Okta & Azure AD',
    details: 'Zentralisierte Identitäten über SSO (SAML) und SCIM Provisioning.',
    capabilities: ['RBAC Synchronisation', 'Multi-Faktor', 'Automatische Deprovisionierung']
  },
  {
    name: 'Webhooks & API',
    details: 'Flexible Webhook-Endpunkte und REST API für individuelle Workflows.',
    capabilities: ['Echtzeit Events', 'Analytics Export', 'Workflow-Automation']
  }
];

function Integrationen() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Integrationen | Qorvixium vernetzt Ihre Systeme</title>
        <meta
          name="description"
          content="Qorvixium verbindet sich mit Microsoft 365, Google Workspace, Slack, Teams, Okta, Azure AD und individuellen Webhooks für ganzheitliche interne Kommunikation."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Integrationen</h1>
        <p>Verbinden Sie Qorvixium mit Ihrer Systemlandschaft für durchgängige Kommunikation.</p>
      </header>
      <div className={styles.grid}>
        {integrations.map((integration) => (
          <article key={integration.name} className={styles.card}>
            <h2>{integration.name}</h2>
            <p>{integration.details}</p>
            <ul>
              {integration.capabilities.map((capability) => (
                <li key={capability}>{capability}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </div>
  );
}

export default Integrationen;