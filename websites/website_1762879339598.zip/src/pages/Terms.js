import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

function Terms() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>AGB | Qorvixium</title>
      </Helmet>
      <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
      <h2>1. Geltungsbereich</h2>
      <p>Diese AGB gelten für sämtliche Verträge zwischen der Qorvixium GmbH und ihren Kundinnen und Kunden.</p>
      <h2>2. Leistungen</h2>
      <p>
        Qorvixium stellt eine SaaS-Lösung für interne Kommunikation, Newsletter, Wissensmanagement und Engagement Analytics
        bereit. Leistungsumfang und Service-Level werden in individuellen Vereinbarungen konkretisiert.
      </p>
      <h2>3. Nutzungsrechte</h2>
      <p>
        Kundinnen und Kunden erhalten ein nicht ausschließliches, nicht übertragbares Recht zur Nutzung der Plattform während
        der Vertragslaufzeit. Reverse Engineering oder unautorisierte Weitergabe sind untersagt.
      </p>
      <h2>4. Verfügbarkeit</h2>
      <p>
        Qorvixium strebt hohe Verfügbarkeiten an. Wartungsfenster und Servicezeiten werden frühzeitig angekündigt. Incident
        Response erfolgt gemäß Service Level Agreement.
      </p>
      <h2>5. Datenschutz &amp; Sicherheit</h2>
      <p>
        Die Verarbeitung personenbezogener Daten erfolgt nach DSGVO. Qorvixium bietet technische und organisatorische
        Maßnahmen sowie Auftragsverarbeitungsverträge.
      </p>
      <h2>6. Haftung</h2>
      <p>
        Qorvixium haftet im Rahmen gesetzlicher Bestimmungen. Für fahrlässige Pflichtverletzungen wird die Haftung auf
        typische, vorhersehbare Schäden begrenzt.
      </p>
      <h2>7. Schlussbestimmungen</h2>
      <p>
        Änderungen dieser AGB werden schriftlich mitgeteilt. Gerichtsstand ist Berlin. Es gilt deutsches Recht unter
        Ausschluss des UN-Kaufrechts.
      </p>
    </div>
  );
}

export default Terms;