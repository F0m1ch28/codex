import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Ressourcen.module.css';

const resources = [
  {
    title: 'Leitfaden interne Kommunikation 2024',
    description: 'Strategien, Templates und Governance-Modelle für hybride Organisationen.',
    type: 'Leitfaden',
    action: 'Herunterladen'
  },
  {
    title: 'Vorlagen für Bekanntmachungen',
    description: 'Standardisierte Ankündigungen mit Lesebestätigung und Zielgruppensteuerung.',
    type: 'Vorlagen',
    action: 'Vorlagen ansehen'
  },
  {
    title: 'Webinar: Puls-Umfragen richtig einsetzen',
    description: 'Live-Demo inklusive Segmentierung und Analytics.',
    type: 'Webinar',
    action: 'Anmeldung sichern'
  }
];

function Ressourcen() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Ressourcen | Qorvixium Leitfäden &amp; Webinare</title>
        <meta
          name="description"
          content="Laden Sie Leitfäden, Vorlagen und Webinare rund um interne Kommunikation, Puls-Umfragen, Wissensdatenbank und Engagement Analytics herunter."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Ressourcen</h1>
        <p>Nutzen Sie Leitfäden, Vorlagen und Webinare für Ihren Kommunikationsalltag.</p>
      </header>
      <div className={styles.resourceList}>
        {resources.map((resource) => (
          <article key={resource.title} className={styles.resourceCard}>
            <span>{resource.type}</span>
            <h2>{resource.title}</h2>
            <p>{resource.description}</p>
            <button type="button" className="focus-outline">
              {resource.action}
            </button>
            {resource.type === 'Leitfaden' && (
              <small>Hinweis: Download mit Double-Opt-In. Sie erhalten eine E-Mail zur Bestätigung.</small>
            )}
          </article>
        ))}
      </div>
    </div>
  );
}

export default Ressourcen;