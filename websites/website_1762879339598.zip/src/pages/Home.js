import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Interne Reichweite', value: 98, suffix: '%' },
  { label: 'Aktive Zielgruppen', value: 42, suffix: '+' },
  { label: 'Automatisierte Prozesse', value: 65, suffix: '' },
  { label: 'Integrationen', value: 25, suffix: '+' }
];

const testimonials = [
  {
    quote:
      'Mit Qorvixium erreichen wir jede Abteilung in Echtzeit. Lesebestätigungen und Analytics geben uns volle Transparenz.',
    name: 'Claudia Reimer',
    title: 'Leitung interne Kommunikation, Nordlicht AG'
  },
  {
    quote:
      'Die Puls-Umfragen liefern innerhalb weniger Minuten Feedback. Unser Engagement Score ist deutlich gestiegen.',
    name: 'David Kühn',
    title: 'HR Director, Glaswerk GmbH'
  },
  {
    quote:
      'Die Kombination aus Wissensdatenbank, Kalender und Zielgruppensteuerung ist in unserem Konzern unverzichtbar geworden.',
    name: 'Sabine Hoffmann',
    title: 'CIO, Vektora Holding'
  }
];

const projectItems = [
  { id: 1, title: 'Führungskräfte-Update', category: 'Führung', image: 'https://picsum.photos/1200/800?random=4', description: 'Signalisiert kritische Unternehmensentscheidungen mit abgestimmter Lesebestätigung.' },
  { id: 2, title: 'Onboarding Journey', category: 'HR', image: 'https://picsum.photos/1200/800?random=5', description: 'Neue Mitarbeitende durchlaufen Wissensmodule und Puls-Checks in den ersten 90 Tagen.' },
  { id: 3, title: 'Compliance Radar', category: 'Compliance', image: 'https://picsum.photos/1200/800?random=6', description: 'Automatisierte Richtlinien-Updates mit versionierter Nachverfolgung.' },
  { id: 4, title: 'Kalender für Produktion', category: 'Operativ', image: 'https://picsum.photos/1200/800?random=7', description: 'Schichtkommunikation und Ereignisse im Werk bleiben synchronisiert.' }
];

const faqItems = [
  {
    question: 'Wie unterstützt Qorvixium die interne Kommunikation?',
    answer:
      'Qorvixium bündelt Ankündigungen, Newsletter, Wissensdatenbank, Kalender und Analytics in einer DSGVO-konformen Plattform. Inhalte werden zielgruppengenau verteilt und mit Lesebestätigung belegt.'
  },
  {
    question: 'Welche Sicherheitsstandards werden eingehalten?',
    answer:
      'Wir bieten RBAC, SSO via SAML/SCIM, rollenbasierte Freigaben, revisionssichere Protokollierung sowie Hosting in deutschen Rechenzentren.'
  },
  {
    question: 'Wie werden Puls-Umfragen visualisiert?',
    answer:
      'Antworten werden in Echtzeit mit Diagrammen, Trendlinien und Segmentierung nach Standort oder Team dargestellt. Exportfunktionen erlauben weitere Analysen.'
  },
  {
    question: 'Ist eine Integration in bestehende Systeme möglich?',
    answer:
      'Ja. Qorvixium integriert sich in Microsoft 365, Google Workspace, Slack, Teams, Okta/Azure AD sowie individuelle Webhooks.'
  }
];

function Home() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [counterValues, setCounterValues] = useState(statsConfig.map(() => 0));
  const [activeFaq, setActiveFaq] = useState(null);

  useEffect(() => {
    const timers = statsConfig.map((stat, index) =>
      setInterval(() => {
        setCounterValues((prev) => {
          const next = [...prev];
          if (next[index] < stat.value) {
            next[index] = Math.min(stat.value, next[index] + Math.ceil(stat.value / 40));
          }
          return next;
        });
      }, 60)
    );
    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Alle') return projectItems;
    return projectItems.filter((item) => item.category === projectFilter);
  }, [projectFilter]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Qorvixium | Interne Kommunikation neu gedacht</title>
        <meta
          name="keywords"
          content="interne kommunikation, bekanntmachungen, mitarbeiter newsletter, puls umfragen, lesebestätigung, wissensdatenbank, sso saml, scim, rbac, engagement analytics, dsgvo"
        />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'SoftwareApplication',
            name: 'Qorvixium',
            operatingSystem: 'Web',
            applicationCategory: 'BusinessApplication',
            offers: {
              '@type': 'Offer',
              availability: 'https://schema.org/InStock'
            },
            aggregateRating: {
              '@type': 'AggregateRating',
              ratingValue: '4.9',
              reviewCount: '128'
            },
            creator: {
              '@type': 'Organization',
              name: 'Qorvixium GmbH',
              address: {
                '@type': 'PostalAddress',
                streetAddress: 'Friedrichstraße 68',
                postalCode: '10117',
                addressLocality: 'Berlin',
                addressCountry: 'DE'
              }
            }
          })}
        </script>
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroTag}>SaaS-Plattform für Enterprise-Kommunikation</p>
          <h1>
            Interne Kommunikation mit Lesebestätigung, Puls-Umfragen und Engagement Analytics in einer Suite.
          </h1>
          <p className={styles.heroDescription}>
            Planen, segmentieren und analysieren Sie Ankündigungen für jede Zielgruppe. Qorvixium orchestriert Newsletter,
            Wissensdatenbank, Kalender und Integrationen zu Microsoft 365, Google Workspace, Slack und Teams – vollständig DSGVO-konform.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={`${styles.primaryButton} focus-outline`}>
              Demo anfordern
            </Link>
            <Link to="/funktionen" className={`${styles.secondaryButton} focus-outline`}>
              Produkt entdecken
            </Link>
          </div>
          <div className={styles.heroStats} aria-label="Kennzahlen zu Qorvixium">
            {statsConfig.map((stat, index) => (
              <div key={stat.label}>
                <strong aria-live="polite">
                  {counterValues[index]}
                  {stat.suffix}
                </strong>
                <span>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Moderner Arbeitsplatz mit digitaler Kommunikationsplattform"
            loading="lazy"
          />
          <div className={styles.heroOverlay}>
            <span>Puls-Umfrage: 84% Teilnahme</span>
            <span>Segment: Produktion Nord</span>
            <span>Lesebestätigung: 92%</span>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="section-heading">
          <h2>Warum Qorvixium?</h2>
          <p>
            Kommunikationskreisläufe werden zentral gesteuert. Von der Idee bis zur Lesebestätigung sorgt Qorvixium für
            Skalierbarkeit, Transparenz und Sicherheit.
          </p>
        </div>
        <div className={styles.benefitGrid}>
          <article>
            <h3>Reichweite steuern</h3>
            <p>Zielgruppen definieren, Segment-Regeln anwenden und Empfängerprofile mit RBAC verwalten.</p>
          </article>
          <article>
            <h3>Inhalte orchestrieren</h3>
            <p>Ankündigungen, Newsletter, Wissensartikel und Kalenderereignisse in einem Workflow zusammenführen.</p>
          </article>
          <article>
            <h3>Engagement messen</h3>
            <p>Engagement Analytics, Heatmaps und Puls-Trends liefern datengestützte Entscheidungen für Führung und HR.</p>
          </article>
        </div>
      </section>

      <section className={styles.features} id="features">
        <div className="section-heading">
          <h2>Funktionen im Überblick</h2>
          <p>Alle Module greifen ineinander und bilden ein skalierbares Kommunikations-OS für Organisationen.</p>
        </div>
        <div className={styles.featureCards}>
          {[
            {
              title: 'Ankündigungen mit Lesebestätigung',
              description:
                'Planung, Zielgruppensteuerung, Versionierung und intelligente Erinnerungen sichern hohe Sichtbarkeit.',
              icon: '📣'
            },
            {
              title: 'Mitarbeiter Newsletter',
              description:
                'E-Mail und Messenger, responsive Templates, Inhaltsblöcke mit Drag & Drop, Double-Opt-In Verwaltung.',
              icon: '✉️'
            },
            {
              title: 'Puls-Umfragen',
              description:
                'Mehrdimensionale Fragen, Echtzeit-Charts, Segmentvergleiche, Export und automatisierte Follow-ups.',
              icon: '📊'
            },
            {
              title: 'Wissensdatenbank',
              description:
                'Kuratiertes Wissensportal mit Tags, Feedback, saisonalen Playbooks und Federated Search.',
              icon: '📚'
            }
          ].map((feature) => (
            <article key={feature.title} className={styles.featureCard}>
              <span className={styles.featureIcon} aria-hidden="true">
                {feature.icon}
              </span>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
              <Link to="/funktionen" className="focus-outline">
                Details ansehen →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className="section-heading">
          <h2>Workflow von der Idee bis zur Messung</h2>
          <p>Qorvixium führt Teams durch strukturierte Prozesse – transparent und auditierbar.</p>
        </div>
        <ol className={styles.processSteps}>
          <li>
            <h3>1. Planen</h3>
            <p>Objekte definieren, Ziele festlegen, Zielgruppen mit RBAC auswählen, Freigaben abbilden.</p>
          </li>
          <li>
            <h3>2. Orchestrieren</h3>
            <p>Ankündigung, Newsletter, Wissensartikel, Kalenderereignisse und Integrationen automatisiert erzeugen.</p>
          </li>
          <li>
            <h3>3. Ausspielen</h3>
            <p>Multi-Channel Versand über E-Mail, Microsoft Teams, Slack und Mitarbeiter-App.</p>
          </li>
          <li>
            <h3>4. Analysieren</h3>
            <p>Lesebestätigung, Engagement, Feedback und Pulsdaten in Echtzeit messen und exportieren.</p>
          </li>
        </ol>
      </section>

      <section className={styles.usecasesPreview}>
        <div className="section-heading">
          <h2>Use Cases</h2>
          <p>Abgestimmte Best Practices für HR, Führung, Onboarding und Compliance.</p>
        </div>
        <div className={styles.usecaseGrid}>
          <Link to="/use-cases" className={`${styles.usecaseCard} focus-outline`}>
            <h3>HR-Kommunikation</h3>
            <p>Roadmaps für Benefits, Puls-Umfragen und People-Analytics kombinieren.</p>
          </Link>
          <Link to="/use-cases" className={`${styles.usecaseCard} focus-outline`}>
            <h3>Führungskommunikation</h3>
            <p>Strategische Botschaften mit Lesebestätigung und Feedbackschleifen absichern.</p>
          </Link>
          <Link to="/use-cases" className={`${styles.usecaseCard} focus-outline`}>
            <h3>Mitarbeiter-Onboarding</h3>
            <p>Guided Journeys mit Wissensartikeln, Kalendern und progressiven Check-ins.</p>
          </Link>
          <Link to="/use-cases" className={`${styles.usecaseCard} focus-outline`}>
            <h3>Compliance &amp; Sicherheit</h3>
            <p>Versionierte Richtlinien, Audit-Trails und Nachweise automatisiert dokumentieren.</p>
          </Link>
        </div>
      </section>

      <section className={styles.integrations}>
        <div className="section-heading">
          <h2>Integrationen</h2>
          <p>Verbinden Sie Qorvixium mit Ihrer bestehenden Systemlandschaft.</p>
        </div>
        <div className={styles.integrationGrid} aria-label="Integrationen anzeigen">
          {['Microsoft 365', 'Google Workspace', 'Slack', 'Microsoft Teams', 'Okta', 'Azure AD', 'Webhooks', 'HRIS'].map(
            (integration) => (
              <div key={integration} className={styles.integrationItem}>
                {integration}
              </div>
            )
          )}
        </div>
      </section>

      <section className={styles.projects}>
        <div className="section-heading">
          <h2>Kommunikationsprojekte</h2>
          <p>Filtern Sie Beispielprojekte, die mit Qorvixium umgesetzt wurden.</p>
        </div>
        <div className={styles.projectFilters}>
          {['Alle', 'HR', 'Führung', 'Compliance', 'Operativ'].map((filter) => (
            <button
              key={filter}
              type="button"
              className={`${styles.filterButton} ${projectFilter === filter ? styles.filterActive : ''}`}
              onClick={() => setProjectFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <img src={`${project.image}&id=${project.id}`} alt={`Projekt ${project.title}`} loading="lazy" />
              <div>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Kundenstimmen">
        <div className={styles.testimonialContent}>
          <h2>Stimmen aus der Praxis</h2>
          <p>Erprobte Erfolge bei Mittelstand und Enterprise.</p>
          <div className={styles.testimonialPanel}>
            <blockquote key={activeTestimonial}>
              <p>„{testimonials[activeTestimonial].quote}“</p>
              <footer>
                <strong>{testimonials[activeTestimonial].name}</strong>
                <span>{testimonials[activeTestimonial].title}</span>
              </footer>
            </blockquote>
          </div>
          <div className={styles.testimonialControls}>
            {testimonials.map((_, index) => (
              <button
                type="button"
                key={index}
                aria-label={`Testimonials ${index + 1}`}
                className={index === activeTestimonial ? styles.controlActive : ''}
                onClick={() => setActiveTestimonial(index)}
              />
            ))}
          </div>
        </div>
        <div className={styles.testimonialVisual} aria-hidden="true">
          <img
            src="https://picsum.photos/800/600?random=2"
            alt="Team arbeitet mit Qorvixium Dashboards"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.team}>
        <div className="section-heading">
          <h2>Leadership Team</h2>
          <p>Erfahrene Köpfe für Kommunikation, Technologie und People Experience.</p>
        </div>
        <div className={styles.teamGrid}>
          {[
            {
              name: 'Dr. Jana Feld',
              role: 'CEO & Mitgründerin',
              focus: 'Strategie und Governance',
              image: 'https://picsum.photos/400/400?random=3'
            },
            {
              name: 'Tobias Lang',
              role: 'CTO',
              focus: 'Plattform-Architektur & Sicherheit',
              image: 'https://picsum.photos/400/400?random=8'
            },
            {
              name: 'Nina Berger',
              role: 'VP Customer Experience',
              focus: 'Change & Enablement',
              image: 'https://picsum.photos/400/400?random=9'
            }
          ].map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={`${member.image}`} alt={`${member.name} - ${member.role}`} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <span>{member.focus}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className="section-heading">
          <h2>FAQ</h2>
          <p>Antworten auf häufige Fragen rund um Qorvixium.</p>
        </div>
        <div className={styles.accordion}>
          {faqItems.map((item, index) => (
            <div key={item.question} className={styles.accordionItem}>
              <button
                type="button"
                className={styles.accordionTrigger}
                aria-expanded={activeFaq === index}
                onClick={() => setActiveFaq(activeFaq === index ? null : index)}
              >
                <span>{item.question}</span>
                <span aria-hidden="true">{activeFaq === index ? '−' : '+'}</span>
              </button>
              {activeFaq === index && <p className={styles.accordionContent}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className="section-heading">
          <h2>Insights &amp; Best Practices</h2>
          <p>Aktuelle Artikel zur internen Kommunikation.</p>
        </div>
        <div className={styles.blogGrid}>
          {[
            {
              title: 'Lesebestätigungen als Steuerungsinstrument',
              excerpt:
                'Wie Qorvixium Führungskräften hilft, kritische Informationen nachzuverfolgen und Compliance-Anforderungen zu erfüllen.',
              path: '/blog'
            },
            {
              title: 'Puls-Umfragen richtig segmentieren',
              excerpt:
                'Von Standort bis Skillset: So nutzen Sie Segmentierung, um Engagement Analytics zu verfeinern.',
              path: '/blog'
            },
            {
              title: 'Onboarding Journeys mit Wissensbausteinen',
              excerpt:
                'Guided Journeys, Kalender und Wissensartikel verbinden, um neue Mitarbeitende strukturiert zu begleiten.',
              path: '/blog'
            }
          ].map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <Link to={post.path} className="focus-outline">
                Weiterlesen →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className={styles.finalCtaContent}>
          <h2>Bereit für spürbar bessere interne Kommunikation?</h2>
          <p>Planen Sie gemeinsam mit uns den nächsten Schritt. Wir begleiten Sie von der Analyse bis zum Go-Live.</p>
        </div>
        <div className={styles.finalCtaActions}>
          <Link to="/kontakt" className={`${styles.primaryButton} focus-outline`}>
            Demo anfordern
          </Link>
          <Link to="/funktionen" className={`${styles.secondaryButton} focus-outline`}>
            Testversion starten
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Home;