import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Datenschutz | Qorvixium</title>
      </Helmet>
      <h1>Datenschutz</h1>
      <p>
        Wir nehmen Datenschutz ernst. Diese Erklärung informiert über Art, Umfang und Zweck der Verarbeitung personenbezogener Daten.
      </p>
      <h2>1. Verantwortliche Stelle</h2>
      <p>
        Qorvixium GmbH<br />
        Friedrichstraße 68, 10117 Berlin<br />
        info@qorvixium.de
      </p>
      <h2>2. Zweck der Datenverarbeitung</h2>
      <p>
        Wir verarbeiten Daten zur Bereitstellung der Plattform, zur Kontaktaufnahme, zur Vertragserfüllung und zur Durchführung
        datenschutzkonformer Analytics in aggregierter Form.
      </p>
      <h2>3. Rechtsgrundlagen</h2>
      <p>Die Verarbeitung erfolgt auf Basis von Art. 6 Abs. 1 lit. b und f DSGVO sowie auf Grundlage von Einwilligungen (lit. a).</p>
      <h2>4. Empfänger</h2>
      <p>Daten werden an Hosting-Provider, Support-Partner und weitere Dienstleister übermittelt, soweit dies erforderlich ist.</p>
      <h2>5. Rechte der betroffenen Personen</h2>
      <p>
        Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie
        Widerspruch. Kontaktieren Sie uns unter datenschutz@qorvixium.de.
      </p>
      <h2>6. Cookies &amp; Tracking</h2>
      <p>
        Wir verwenden essenzielle Cookies sowie optionale Analytics. Über das Cookie-Banner können Sie Ihre Einwilligung verwalten.
      </p>
      <h2>7. Newsletter &amp; Double-Opt-In</h2>
      <p>
        Für den Versand von Newslettern nutzen wir ein Double-Opt-In Verfahren. Sie können die Einwilligung jederzeit widerrufen.
      </p>
      <h2>8. Kontaktformular &amp; reCAPTCHA</h2>
      <p>
        Zur Absicherung gegen Missbrauch verwenden wir reCAPTCHA. Detaillierte Informationen finden Sie in den Datenschutzhinweisen
        von Google. Mit Absenden des Formulars erklären Sie sich mit der Verarbeitung einverstanden.
      </p>
      <h2>9. Aufbewahrung &amp; Löschung</h2>
      <p>
        Daten werden solange aufbewahrt, wie es zur Vertragserfüllung erforderlich ist. Gesetzliche Aufbewahrungspflichten bleiben unberührt.
      </p>
    </div>
  );
}

export default Privacy;