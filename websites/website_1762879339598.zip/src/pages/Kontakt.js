import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Kontakt.module.css';

function Kontakt() {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    message: '',
    newsletter: false
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte Namen angeben.';
    if (!formData.company.trim()) newErrors.company = 'Bitte Unternehmen angeben.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte geschäftliche E-Mail angeben.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'E-Mail Format prüfen.';
    }
    if (!formData.message.trim()) newErrors.message = 'Bitte Nachricht verfassen.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = validate();
    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | Qorvixium anfragen</title>
        <meta
          name="description"
          content="Kontaktieren Sie Qorvixium für eine Demo oder Beratung zur internen Kommunikation. Adresse in Berlin, Telefon +49 30 1234 5678, info@qorvixium.de."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Kontakt</h1>
        <p>Wir freuen uns auf Ihre Nachricht und planen gemeinsam Ihre interne Kommunikationsstrategie.</p>
      </header>
      <div className={styles.layout}>
        <section className={styles.formSection}>
          <h2>Nachricht senden</h2>
          {submitted ? (
            <div className={styles.success}>
              <h3>Vielen Dank!</h3>
              <p>
                Wir haben Ihre Anfrage erhalten. Unser Team meldet sich zeitnah. Falls Sie den Newsletter angefordert haben,
                erhalten Sie eine Double-Opt-In E-Mail zur Bestätigung.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <label>
                Vollständiger Name
                <input
                  type="text"
                  name="name"
                  autoComplete="name"
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  aria-invalid={errors.name ? 'true' : 'false'}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && <span id="name-error">{errors.name}</span>}
              </label>
              <label>
                Unternehmen
                <input
                  type="text"
                  name="company"
                  autoComplete="organization"
                  value={formData.company}
                  onChange={(e) => setFormData((prev) => ({ ...prev, company: e.target.value }))}
                  aria-invalid={errors.company ? 'true' : 'false'}
                  aria-describedby={errors.company ? 'company-error' : undefined}
                />
                {errors.company && <span id="company-error">{errors.company}</span>}
              </label>
              <label>
                Geschäftliche E-Mail
                <input
                  type="email"
                  name="email"
                  autoComplete="email"
                  value={formData.email}
                  onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                  aria-invalid={errors.email ? 'true' : 'false'}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && <span id="email-error">{errors.email}</span>}
              </label>
              <label>
                Anliegen
                <textarea
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
                  aria-invalid={errors.message ? 'true' : 'false'}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                />
                {errors.message && <span id="message-error">{errors.message}</span>}
              </label>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  name="newsletter"
                  checked={formData.newsletter}
                  onChange={(e) => setFormData((prev) => ({ ...prev, newsletter: e.target.checked }))}
                />
                <span>Ich möchte Updates und Newsletter erhalten (Double-Opt-In).</span>
              </label>
              <div className={styles.recaptchaPlaceholder} aria-label="reCAPTCHA">
                <p>reCAPTCHA Implementierung (Site-Key erforderlich)</p>
              </div>
              <button type="submit" className="focus-outline">
                Demo anfordern
              </button>
            </form>
          )}
        </section>
        <aside className={styles.infoSection}>
          <h2>Standort Berlin</h2>
          <p>Qorvixium GmbH</p>
          <p>Friedrichstraße 68<br />10117 Berlin, Deutschland</p>
          <p>
            Telefon: <a href="tel:+493012345678">+49 30 1234 5678</a>
          </p>
          <p>
            E-Mail: <a href="mailto:info@qorvixium.de">info@qorvixium.de</a>
          </p>
          <iframe
            title="Qorvixium Standort Berlin"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.970330950352!2d13.388859315997152!3d52.51391397981356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851cdd6fe7ea7%3A0x9f4b0c9bdfe06306!2sFriedrichstra%C3%9Fe%2068%2C%2010117%20Berlin!5e0!3m2!1sde!2sde!4v1694091258890!5m2!1sde!2sde"
            loading="lazy"
            allowFullScreen
          ></iframe>
          <p className={styles.note}>
            Termine sind nach Vereinbarung möglich. Für Workshops bieten wir hybride und virtuelle Formate.
          </p>
        </aside>
      </div>
    </div>
  );
}

export default Kontakt;