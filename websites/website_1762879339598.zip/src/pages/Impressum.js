import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Impressum.module.css';

function Impressum() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Impressum | Qorvixium</title>
      </Helmet>
      <h1>Impressum</h1>
      <p>Angaben gemäß § 5 TMG:</p>
      <p>
        Qorvixium GmbH<br />
        Friedrichstraße 68<br />
        10117 Berlin, Deutschland
      </p>
      <p>
        Telefon: +49 30 1234 5678<br />
        E-Mail: info@qorvixium.de
      </p>
      <p>
        Geschäftsführung: Dr. Jana Feld<br />
        Registergericht: Amtsgericht Berlin Charlottenburg<br />
        Registernummer: HRB 123456<br />
        Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz: DE123456789
      </p>
      <h2>Haftung für Inhalte</h2>
      <p>
        Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen
        Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht verpflichtet,
        übermittelte oder gespeicherte fremde Informationen zu überwachen.
      </p>
      <h2>Haftung für Links</h2>
      <p>
        Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb
        können wir für diese fremden Inhalte keine Gewähr übernehmen.
      </p>
      <h2>Urheberrecht</h2>
      <p>
        Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen
        Urheberrecht. Beiträge Dritter sind als solche gekennzeichnet.
      </p>
    </div>
  );
}

export default Impressum;