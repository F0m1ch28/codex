import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Über Qorvixium | Unternehmen & Team</title>
        <meta
          name="description"
          content="Erfahren Sie, wie Qorvixium als SaaS-Unternehmen interne Kommunikation, Engagement Analytics und sichere Kollaboration für Organisationen in Deutschland neu definiert."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Über Qorvixium</h1>
        <p>
          Unser Auftrag: Interne Kommunikation transparent, messbar und zielgruppenspezifisch gestalten – mit Technologie,
          die Menschen in den Mittelpunkt stellt.
        </p>
      </header>

      <section className={styles.values}>
        <h2>Unsere Leitlinien</h2>
        <div className={styles.valueGrid}>
          <article>
            <h3>Vertrauen</h3>
            <p>Wir setzen auf Datensouveränität, Compliance-by-Design und klare Verantwortlichkeiten.</p>
          </article>
          <article>
            <h3>Transparenz</h3>
            <p>Alle Kommunikationsschritte werden nachvollziehbar dokumentiert und analysiert.</p>
          </article>
          <article>
            <h3>Enablement</h3>
            <p>Wir begleiten Teams mit Workshops, Change-Management und adaptiven Trainingspfaden.</p>
          </article>
        </div>
      </section>

      <section className={styles.timeline}>
        <h2>Meilensteine</h2>
        <ol>
          <li>
            <span>2019</span>
            <p>Gründung durch Expertinnen und Experten für Kommunikation und IT-Sicherheit in Berlin.</p>
          </li>
          <li>
            <span>2020</span>
            <p>Launch der Module Ankündigungen, Newsletter-Orchestrierung und Lesebestätigung.</p>
          </li>
          <li>
            <span>2021</span>
            <p>Einführung von Puls-Umfragen, Wissensdatenbank sowie Analytics mit Segmentierung.</p>
          </li>
          <li>
            <span>2023</span>
            <p>Ausbau der Integrationen in Microsoft 365, Google Workspace, Slack, Teams und Okta.</p>
          </li>
        </ol>
      </section>

      <section className={styles.commitment}>
        <h2>Engagement &amp; Sicherheit</h2>
        <div className={styles.commitmentGrid}>
          <article>
            <h3>Datenschutz in Deutschland</h3>
            <p>Hosting in deutschen Rechenzentren, ISO 27001 Partner, SOC 2 Berichte und regelmäßige Audits.</p>
          </article>
          <article>
            <h3>DSGVO-konforme Analytics</h3>
            <p>Aggregierte Auswertungen, Pseudonymisierung, Rollen und SSO sorgen für klare Freigabeprozesse.</p>
          </article>
          <article>
            <h3>Ökosystem</h3>
            <p>Partnernetzwerk für Change-Management, Kommunikationsdesign und Mitarbeiter-Apps erweitert unser Angebot.</p>
          </article>
        </div>
      </section>
    </div>
  );
}

export default About;