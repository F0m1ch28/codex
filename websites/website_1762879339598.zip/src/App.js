import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import Funktionen from './pages/Funktionen';
import UseCases from './pages/UseCases';
import Integrationen from './pages/Integrationen';
import Ressourcen from './pages/Ressourcen';
import Blog from './pages/Blog';
import Kontakt from './pages/Kontakt';
import About from './pages/About';
import Impressum from './pages/Impressum';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Header />
      <main id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/funktionen" element={<Funktionen />} />
          <Route path="/use-cases" element={<UseCases />} />
          <Route path="/integrationen" element={<Integrationen />} />
          <Route path="/ressourcen" element={<Ressourcen />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/kontakt" element={<Kontakt />} />
          <Route path="/unternehmen" element={<About />} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/agb" element={<Terms />} />
          <Route path="/datenschutz" element={<Privacy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </Router>
  );
}

export default App;