import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Startseite' },
  { path: '/funktionen', label: 'Funktionen' },
  { path: '/use-cases', label: 'Use Cases' },
  { path: '/integrationen', label: 'Integrationen' },
  { path: '/ressourcen', label: 'Ressourcen' },
  { path: '/blog', label: 'Blog' },
  { path: '/unternehmen', label: 'Unternehmen' },
  { path: '/kontakt', label: 'Kontakt' }
];

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} role="banner">
      <a className={styles.skipLink} href="#main-content">
        Zum Inhalt springen
      </a>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Qorvixium Startseite">
          <span className={styles.logoMark}>QX</span>
          <span className={styles.logoText}>Qorvixium</span>
        </Link>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
          <ul>
            {navLinks.map((link) => (
              <li key={link.path}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/kontakt" className={`${styles.navCta} focus-outline`}>
            Demo anfordern
          </Link>
        </nav>
        <button
          className={styles.burger}
          aria-label="Navigation umschalten"
          aria-expanded={isMenuOpen}
          onClick={() => setIsMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
}

export default Header;