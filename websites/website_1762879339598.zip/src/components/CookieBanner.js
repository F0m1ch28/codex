import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_PREFERENCE_KEY = 'qorvixium-cookie-preferences';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [preferences, setPreferences] = useState({
    essential: true,
    analytics: false,
    marketing: false
  });

  useEffect(() => {
    const savedPreferences = window.localStorage.getItem(COOKIE_PREFERENCE_KEY);
    if (!savedPreferences) {
      setIsVisible(true);
    } else {
      setPreferences(JSON.parse(savedPreferences));
    }
  }, []);

  const handleSave = () => {
    window.localStorage.setItem(COOKIE_PREFERENCE_KEY, JSON.stringify(preferences));
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.wrapper}>
        <div className={styles.text}>
          <h2>Cookie-Einstellungen</h2>
          <p>
            Wir verwenden Cookies für essenzielle Funktionen sowie für datenschutzkonforme Analytics. Sie können der
            Verarbeitung zustimmen oder individuelle Einstellungen vornehmen. Weitere Informationen finden Sie in unserer{' '}
            <a className="focus-outline" href="/datenschutz">
              Datenschutzerklärung
            </a>
            .
          </p>
          {showDetails && (
            <div className={styles.preferences}>
              <label className={styles.checkbox}>
                <input type="checkbox" checked readOnly />
                <span>Essenzielle Cookies (erforderlich)</span>
              </label>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={preferences.analytics}
                  onChange={(e) =>
                    setPreferences((prev) => ({ ...prev, analytics: e.target.checked }))
                  }
                />
                <span>Datenschutzkonforme Analytics</span>
              </label>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={preferences.marketing}
                  onChange={(e) =>
                    setPreferences((prev) => ({ ...prev, marketing: e.target.checked }))
                  }
                />
                <span>Optionale Produktupdates</span>
              </label>
            </div>
          )}
        </div>
        <div className={styles.actions}>
          <button
            className={`${styles.button} ${styles.secondary} focus-outline`}
            type="button"
            onClick={() => setShowDetails((prev) => !prev)}
          >
            {showDetails ? 'Weniger anzeigen' : 'Einstellungen'}
          </button>
          <button
            className={`${styles.button} focus-outline`}
            type="button"
            onClick={() => {
              setPreferences({ essential: true, analytics: true, marketing: false });
              handleSave();
            }}
          >
            Analysen erlauben
          </button>
          <button
            className={`${styles.button} ${styles.primary} focus-outline`}
            type="button"
            onClick={handleSave}
          >
            Auswahl speichern
          </button>
        </div>
      </div>
    </aside>
  );
}

export default CookieBanner;