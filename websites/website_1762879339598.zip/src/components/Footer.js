import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.container}>
        <div className={styles.brand}>
          <span className={styles.brandMark}>QX</span>
          <p className={styles.brandText}>
            Qorvixium vernetzt Teams, Führungskräfte und HR in Echtzeit und stärkt strukturierte interne Kommunikation.
          </p>
          <div className={styles.contact}>
            <a href="tel:+493012345678" className="focus-outline">
              Telefon: +49 30 1234 5678
            </a>
            <a href="mailto:info@qorvixium.de" className="focus-outline">
              info@qorvixium.de
            </a>
            <address>Friedrichstraße 68, 10117 Berlin, Deutschland</address>
          </div>
        </div>
        <div className={styles.column}>
          <h4>Angebot</h4>
          <Link to="/funktionen">Funktionen</Link>
          <Link to="/use-cases">Use Cases</Link>
          <Link to="/integrationen">Integrationen</Link>
          <Link to="/ressourcen">Ressourcen</Link>
        </div>
        <div className={styles.column}>
          <h4>Unternehmen</h4>
          <Link to="/unternehmen">Über Qorvixium</Link>
          <Link to="/blog">Insights</Link>
          <Link to="/kontakt">Kontakt</Link>
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
            LinkedIn
          </a>
        </div>
        <div className={styles.column}>
          <h4>Rechtliches</h4>
          <Link to="/impressum">Impressum</Link>
          <Link to="/datenschutz">Datenschutz</Link>
          <Link to="/agb">AGB</Link>
          <p className={styles.version}>© {new Date().getFullYear()} Qorvixium</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;