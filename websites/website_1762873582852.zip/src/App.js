import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  NavLink,
  useLocation,
} from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import ResourcesPage, { BlogPage } from "./pages/About";
import FunktionenPage, {
  UseCasesPage,
  IntegrationenPage,
} from "./pages/Services";
import Contact from "./pages/Contact";
import TermsPage, {
  ImpressumPage,
  CookiePolicyPage,
} from "./pages/Terms";
import PrivacyPage from "./pages/Privacy";
import "./styles/AppShell.css";

const SkipToContent = () => (
  <a className="skip-link" href="#main-content">
    Zum Inhalt springen
  </a>
);

const Breadcrumbs = () => {
  const location = useLocation();
  const segments = location.pathname.split("/").filter(Boolean);
  if (segments.length === 0) {
    return null;
  }
  return (
    <nav aria-label="Brotkrumen" className="breadcrumbs">
      <ol>
        <li>
          <NavLink to="/">Start</NavLink>
        </li>
        {segments.map((segment, index) => {
          const path = `/${segments.slice(0, index + 1).join("/")}`;
          const label = segment
            .replace(/-/g, " ")
            .replace(/\b\w/g, (char) => char.toUpperCase());
          return (
            <li key={path}>
              {index === segments.length - 1 ? (
                <span aria-current="page">{label}</span>
              ) : (
                <NavLink to={path}>{label}</NavLink>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

const AppLayout = () => (
  <>
    <SkipToContent />
    <Header />
    <Breadcrumbs />
    <main id="main-content" className="main-content" tabIndex="-1">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/funktionen" element={<FunktionenPage />} />
        <Route path="/use-cases" element={<UseCasesPage />} />
        <Route path="/integrationen" element={<IntegrationenPage />} />
        <Route path="/ressourcen" element={<ResourcesPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/kontakt" element={<Contact />} />
        <Route path="/impressum" element={<ImpressumPage />} />
        <Route path="/datenschutz" element={<PrivacyPage />} />
        <Route path="/agb" element={<TermsPage />} />
        <Route path="/cookie-richtlinie" element={<CookiePolicyPage />} />
      </Routes>
    </main>
    <Footer />
    <ScrollToTop />
    <CookieBanner />
  </>
);

const App = () => (
  <Router>
    <Helmet>
      <meta name="theme-color" content="#0F172A" />
      <meta name="robots" content="index, follow" />
    </Helmet>
    <AppLayout />
  </Router>
);

export default App;