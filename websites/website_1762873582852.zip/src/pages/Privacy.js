import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

const PrivacyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Datenschutz | Qorvixium</title>
      <meta
        name="description"
        content="Datenschutzerklärung von Qorvixium mit Informationen zur Datenverarbeitung, DSGVO-Konformität, Consent-Management und Betroffenenrechten."
      />
      <link rel="canonical" href="https://qorvixium.com/datenschutz" />
    </Helmet>
    <header className={styles.header}>
      <h1>Datenschutz</h1>
      <p>Wir legen großen Wert auf den Schutz personenbezogener Daten.</p>
    </header>
    <section className={styles.section}>
      <h2>Verantwortliche Stelle</h2>
      <p>
        Qorvixium<br />
        Friedrichstraße 68<br />
        10117 Berlin, Deutschland<br />
        E-Mail: privacy@qorvixium.com
      </p>
    </section>
    <section className={styles.section}>
      <h2>Verarbeitungstätigkeiten</h2>
      <p>
        Wir verarbeiten personenbezogene Daten zur Bereitstellung der Plattform,
        zur Durchführung von Ankündigungen, Newsletter, Puls Umfragen und
        Wissensdatenbank sowie zur Auswertung von Engagement Analytics.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Rechtsgrundlagen</h2>
      <p>
        Die Verarbeitung erfolgt auf Basis von Art. 6 Abs. 1 lit. b DSGVO (Vertragsdurchführung)
        sowie Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse). Für optionale Kommunikation
        nutzen wir Art. 6 Abs. 1 lit. a DSGVO (Einwilligung).
      </p>
    </section>
    <section className={styles.section}>
      <h2>Auftragsverarbeitung & Subunternehmer</h2>
      <p>
        Wir setzen sorgfältig ausgewählte Subunternehmer in der EU ein. Eine Übersicht
        stellen wir auf Anfrage bereit. Jeder Partner ist vertraglich zur DSGVO-Konformität verpflichtet.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Rechte Betroffener</h2>
      <p>
        Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung,
        Widerspruch und Datenübertragbarkeit. Kontaktieren Sie uns unter privacy@qorvixium.com.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Speicherdauer</h2>
      <p>
        Daten werden nur solange gespeichert, wie es für die Bereitstellung der Services
        erforderlich ist oder gesetzliche Aufbewahrungsfristen dies vorsehen. Löschkonzepte
        sind dokumentiert und auditierbar.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Cookies & Tracking</h2>
      <p>
        Funktionale Cookies sind notwendig für Logins und Consent-Management.
        Analytics Cookies setzen wir nur nach Ihrer Einwilligung ein. Details finden Sie in unserer Cookie-Richtlinie.
      </p>
    </section>
  </div>
);

export default PrivacyPage;