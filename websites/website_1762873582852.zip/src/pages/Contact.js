import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const initialState = {
    name: "",
    email: "",
    company: "",
    phone: "",
    message: "",
    privacy: false,
    optin: false,
  };

  const [formData, setFormData] = useState(initialState);
  const [status, setStatus] = useState("");

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setStatus("");
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const validate = () => {
    if (!formData.name || !formData.email || !formData.message) {
      setStatus("Bitte füllen Sie alle Pflichtfelder aus.");
      return false;
    }
    if (!formData.privacy || !formData.optin) {
      setStatus("Bitte stimmen Sie der Datenverarbeitung und dem Double Opt-In zu.");
      return false;
    }
    return true;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    setStatus(
      "Vielen Dank! Wir melden uns innerhalb von zwei Werktagen. Bitte bestätigen Sie anschließend unsere Double Opt-In E-Mail."
    );
    setFormData(initialState);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | Qorvixium</title>
        <meta
          name="description"
          content="Kontaktieren Sie Qorvixium für eine Demo, Beratung oder Fragen zu interner Kommunikation, Puls Umfragen, Wissensdatenbank und DSGVO-Compliance."
        />
        <link rel="canonical" href="https://qorvixium.com/kontakt" />
      </Helmet>
      <header className={styles.header}>
        <h1>Kontaktieren Sie Qorvixium</h1>
        <p>
          Lassen Sie uns über Ihre Kommunikation sprechen. Unser Team zeigt,
          wie Qorvixium Ankündigungen, Newsletter, Puls Umfragen und Wissensdatenbank
          in Einklang bringt – inklusive Engagement Analytics und DSGVO-Compliance.
        </p>
      </header>
      <div className={styles.grid}>
        <form onSubmit={handleSubmit} className={styles.form}>
          <label htmlFor="name">Name*</label>
          <input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Ihr vollständiger Name"
            required
          />
          <label htmlFor="email">Geschäftliche E-Mail*</label>
          <input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="name@unternehmen.de"
            required
          />
          <label htmlFor="company">Unternehmen</label>
          <input
            id="company"
            name="company"
            value={formData.company}
            onChange={handleChange}
            placeholder="Unternehmensname"
          />
          <label htmlFor="phone">Telefon</label>
          <input
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="+49 ..."
          />
          <label htmlFor="message">Wie können wir unterstützen?*</label>
          <textarea
            id="message"
            name="message"
            rows="5"
            value={formData.message}
            onChange={handleChange}
            placeholder="Beschreiben Sie Ihr Projekt oder Ihre Frage."
            required
          />
          <div className={styles.checkboxes}>
            <label>
              <input
                type="checkbox"
                name="privacy"
                checked={formData.privacy}
                onChange={handleChange}
              />
              Ich stimme der DSGVO-konformen Verarbeitung meiner Angaben zu.
            </label>
            <label>
              <input
                type="checkbox"
                name="optin"
                checked={formData.optin}
                onChange={handleChange}
              />
              Ich akzeptiere den Double Opt-In Prozess.
            </label>
          </div>
          <div
            className="g-recaptcha"
            data-sitekey="your-site-key"
            data-theme="light"
          />
          <button type="submit">Nachricht senden</button>
          <p className={styles.status}>{status}</p>
        </form>
        <div className={styles.info}>
          <div className={styles.contactCard}>
            <h2>Qorvixium</h2>
            <p>Friedrichstraße 68<br />10117 Berlin, Deutschland</p>
            <a href="tel:+493012345678">+49 30 1234 5678</a>
            <a href="mailto:hello@qorvixium.com">hello@qorvixium.com</a>
          </div>
          <div className={styles.mapWrapper} aria-label="Standort Berlin">
            <iframe
              title="Qorvixium Standort Berlin"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.640651675187!2d13.387871677084014!3d52.51132747198351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851d3e0b1f8df%3A0x7d7f6c30f82f1b1f!2sFriedrichstra%C3%9Fe%2068%2C%2010117%20Berlin!5e0!3m2!1sde!2sde!4v1705693800000"
              width="100%"
              height="320"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;