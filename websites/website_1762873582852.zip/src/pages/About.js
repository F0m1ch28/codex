import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const ResourcesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Ressourcen | Qorvixium</title>
      <meta
        name="description"
        content="Guides, Playbooks und Webinare zu interner Kommunikation, Ankündigungen, Puls Umfragen und Wissensdatenbank – entdecken Sie das Qorvixium Ressourcencenter."
      />
      <link rel="canonical" href="https://qorvixium.com/ressourcen" />
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: "Qorvixium Ressourcen",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "Leitfaden Interne Kommunikation 2024",
              url: "https://qorvixium.com/ressourcen",
            },
            {
              "@type": "ListItem",
              position: 2,
              name: "Playbook Puls Umfragen",
              url: "https://qorvixium.com/ressourcen",
            },
          ],
        })}
      </script>
    </Helmet>
    <header className={styles.header}>
      <h1>Ressourcen für Kommunikationsprofis</h1>
      <p>
        Ob Ankündigungen, Mitarbeiter Newsletter, Puls Umfragen oder Wissensdatenbank –
        hier finden Sie Leitfäden, Templates und Webinare für interne Kommunikation
        mit Engagement Analytics.
      </p>
    </header>
    <section className={styles.resources}>
      <article>
        <h2>Leitfaden Interne Kommunikation 2024</h2>
        <p>
          Strategien für segmentierte Bekanntmachungen, Storytelling und Change-Kommunikation.
          Enthält Checklisten für Lesebestätigung und DSGVO-konforme Dokumentation.
        </p>
        <a href="/kontakt">Download anfordern</a>
      </article>
      <article>
        <h2>Playbook Puls Umfragen</h2>
        <p>
          Enthält Taktiken für Puls Umfragen, Follow-up Aktionen und Heatmap-Auswertung
          inklusive Beispielfragen für Kultur, Engagement und Enablement.
        </p>
        <a href="/kontakt">Gespräch vereinbaren</a>
      </article>
      <article>
        <h2>Wissensdatenbank Starter-Set</h2>
        <p>
          Templates für Wissensartikel, Workflow-Empfehlungen mit SSO SAML Absicherung
          und KPI-Vorgaben für Adoption und Suchqualität.
        </p>
        <a href="/kontakt">Inhalt erhalten</a>
      </article>
    </section>
    <section className={styles.webinars}>
      <h2>Live-Webinare & Masterclasses</h2>
      <div className={styles.webinarGrid}>
        <div>
          <span>29. Februar</span>
          <h3>Segmentierte Ankündigungen orchestrieren</h3>
          <p>
            Live-Demo zur Kombination von RBAC, SCIM Gruppen und kanalübergreifender
            Ausspielung. Inklusive Praxisbeispielen aus internationalen Rollouts.
          </p>
          <a href="/kontakt">Platz reservieren</a>
        </div>
        <div>
          <span>14. März</span>
          <h3>Engagement Analytics lesen & handeln</h3>
          <p>
            Vom Dashboard zur Aktion: Wir zeigen, wie Sie Kennzahlen interpretieren
            und Maßnahmen automatisiert anstoßen.
          </p>
          <a href="/kontakt">Teilnahme sichern</a>
        </div>
      </div>
    </section>
    <section className={styles.formSection}>
      <div>
        <h2>Whitepaper abonnieren</h2>
        <p>
          Erhalten Sie vierteljährlich Whitepaper zu interner Kommunikation,
          Wissensmanagement und DSGVO-Compliance. Wir setzen auf Double Opt-In
          und transparente Abmeldung.
        </p>
        <form>
          <label htmlFor="resource-name">Name</label>
          <input id="resource-name" type="text" name="name" placeholder="Ihr Name" />
          <label htmlFor="resource-email">Geschäftliche E-Mail</label>
          <input
            id="resource-email"
            type="email"
            name="email"
            placeholder="name@unternehmen.de"
          />
          <div className={styles.checks}>
            <label>
              <input type="checkbox" name="privacy" required /> Ich stimme der DSGVO-konformen
              Verarbeitung meiner Daten zu.
            </label>
            <label>
              <input type="checkbox" name="optin" required /> Ich bestätige den Double Opt-In Prozess.
            </label>
          </div>
          <button type="submit">Whitepaper abonnieren</button>
        </form>
      </div>
      <img
        src="https://picsum.photos/800/600?random=35"
        alt="Dokumentation und Strategiepapiere"
        loading="lazy"
      />
    </section>
  </div>
);

export const BlogPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Blog | Qorvixium</title>
      <meta
        name="description"
        content="Aktuelle Insights zur internen Kommunikation, Engagement Analytics, Puls Umfragen und Wissensdatenbank. Entdecken Sie Praxisberichte und Thought Leadership."
      />
      <link rel="canonical" href="https://qorvixium.com/blog" />
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Blog",
          name: "Qorvixium Blog",
          url: "https://qorvixium.com/blog",
          blogPost: [
            {
              "@type": "BlogPosting",
              headline: "Puls Umfragen strategisch einsetzen",
              datePublished: "2024-01-08",
              author: {
                "@type": "Person",
                name: "Mira Feld",
              },
            },
          ],
        })}
      </script>
    </Helmet>
    <header className={styles.header}>
      <h1>Insights & Best Practices</h1>
      <p>
        Unser Blog beleuchtet Trends rund um interne Kommunikation, Mitarbeiter Newsletter,
        Puls Umfragen, Wissensdatenbanken und DSGVO-konforme Analytics.
      </p>
    </header>
    <div className={styles.blogList}>
      <article>
        <span>08. Januar 2024</span>
        <h2>Puls Umfragen strategisch einsetzen</h2>
        <p>
          Erfahren Sie, wie Puls Umfragen mithilfe von Segmentierung, Heatmaps und
          Wissensartikeln konkrete Verbesserungen anstoßen.
        </p>
        <a href="/kontakt">Case Study anfordern</a>
      </article>
      <article>
        <span>13. November 2023</span>
        <h2>Wissensdatenbank für globale Teams</h2>
        <p>
          Governance, Übersetzung und Recommendation-Engine: So bleibt Ihre Wissensdatenbank
          relevant und jederzeit auditierbar.
        </p>
        <a href="/kontakt">Beratungsgespräch buchen</a>
      </article>
      <article>
        <span>23. Oktober 2023</span>
        <h2>Engagement Analytics als Steuerung</h2>
        <p>
          KPI-Frameworks und Reporting-Templates, die Kommunikationsprojekte mit Unternehmenszielen
          verbinden.
        </p>
        <a href="/kontakt">Framework erhalten</a>
      </article>
    </div>
  </div>
);

export default ResourcesPage;