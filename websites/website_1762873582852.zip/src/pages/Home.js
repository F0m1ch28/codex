import React, { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const Home = () => {
  const stats = useMemo(
    () => [
      { id: 1, label: "Mitarbeiterreichweite", target: 94 },
      { id: 2, label: "aktive Segmente", target: 48 },
      { id: 3, label: "Puls Umfragen pro Jahr", target: 36 },
      { id: 4, label: "Knowledge Articles", target: 320 },
    ],
    []
  );
  const [statValues, setStatValues] = useState(
    stats.map(() => 0)
  );
  const [activeFeature, setActiveFeature] = useState("ankuendigungen");
  const [modalOpen, setModalOpen] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("Alle");
  const [openedFaq, setOpenedFaq] = useState(null);

  const features = [
    {
      id: "ankuendigungen",
      title: "Ankündigungen mit Lesebestätigung",
      description:
        "Planen, segmentieren und messen Sie Bekanntmachungen mit Audit-Trail und Lesebestätigung in Echtzeit.",
      points: [
        "Drag-and-drop Editor mit Unternehmensrichtlinien",
        "Lesestatus pro Standort oder Team",
        "Announcement Feed mit Zielgruppen-Filtern",
      ],
      image: "https://picsum.photos/800/600?random=2",
    },
    {
      id: "newsletter",
      title: "Mitarbeiter Newsletter im Baukastensystem",
      description:
        "Erstellen Sie zielgruppenspezifische Newsletter mit dynamischen Inhalten und Double Opt-In Workflow.",
      points: [
        "Segmentlogik auf Basis von RBAC und SCIM",
        "Personalisierte Hero-Module nach Funktionsbereich",
        "A/B Testing mit Engagement Analytics",
      ],
      image: "https://picsum.photos/800/600?random=23",
    },
    {
      id: "umfragen",
      title: "Puls Umfragen & Feedback-Loops",
      description:
        "Sammeln Sie kontinuierlich Rückmeldungen durch kurze Puls Umfragen und visualisieren Sie Trends sofort.",
      points: [
        "Frequenz einstellbar zwischen 7 und 60 Tagen",
        "Heatmaps für Stimmung je Team oder Standort",
        "Kalender-Sync für automatisierte Erinnerungen",
      ],
      image: "https://picsum.photos/800/600?random=24",
    },
    {
      id: "wissen",
      title: "Wissensdatenbank & Lernpfade",
      description:
        "Veröffentlichen Sie strukturierte Wissensartikel mit Versionierung, Suchanalyse und Empfehlungslogik.",
      points: [
        "Synchrone Verwaltung mit Microsoft 365 oder Google Workspace",
        "Genehmigungs-Workflows mit SSO SAML Authentifizierung",
        "Kontextsensitive Vorschläge in Chats und Intranet",
      ],
      image: "https://picsum.photos/800/600?random=25",
    },
  ];

  const useCases = [
    {
      department: "HR & People Operations",
      description:
        "Onboarding Journeys, Benefits-Updates und Compliance-Hinweise werden automatisch an relevante Gruppen gesendet. Lesebestätigung sichert Nachweise.",
      segments: ["Neue Kolleg*innen", "Führungsebene", "Befristete Teams"],
      metric: "Engagement Rate +37%",
    },
    {
      department: "Kommunikation & PR",
      description:
        "Globale und lokale Ankündigungen lassen sich mit Zeitplan und Lokalisierung orchestrieren. Redaktionskalender synchronisiert Kampagnen auf Outlook und Google Kalender.",
      segments: ["Corporate", "Standorte", "Partnernetzwerk"],
      metric: "Zeitersparnis 28 Stunden / Monat",
    },
    {
      department: "IT & Security",
      description:
        "SSO SAML, SCIM Provisioning und granulare RBAC Rollen sorgen für gesicherte Zugänge. Change Mitteilungen werden mit Risikoklassen versehen und dokumentiert.",
      segments: ["Admins", "Key User", "Pilotgruppen"],
      metric: "Audit-ready Change Logs",
    },
  ];

  const integrationLogos = [
    { name: "Microsoft 365", acronym: "M365" },
    { name: "Google Workspace", acronym: "GWS" },
    { name: "Slack", acronym: "SL" },
    { name: "Microsoft Teams", acronym: "Teams" },
    { name: "Okta", acronym: "Okta" },
    { name: "Azure AD", acronym: "AAD" },
  ];

  const testimonials = [
    {
      quote:
        "Seit wir Qorvixium nutzen, erreichen unsere Ankündigungen alle Zielgruppen mit dokumentierter Lesebestätigung. Besonders hilfreich sind die automatisierten Reminder auf Basis von Engagement Analytics.",
      name: "Elena Wagner",
      role: "Head of Internal Communications, Nordlicht AG",
    },
    {
      quote:
        "Das Zusammenspiel aus Puls Umfragen und Wissensdatenbank eröffnet völlig neue Insights. Wir erkennen früh, wo Teams Unterstützung benötigen und können gezielt Inhalte ausspielen.",
      name: "Dr. Jonas Stein",
      role: "Director People & Culture, Inovera GmbH",
    },
    {
      quote:
        "RBAC-gestützte Segmente plus SCIM-Integration sparen unserem IT-Team viel Aufwand. Der DSGVO-Report liefert genau die Nachweise, die wir für Audits brauchen.",
      name: "Sabine Krämer",
      role: "CIO, Hansewerk Solutions",
    },
  ];

  const teamMembers = [
    {
      name: "Mira Feld",
      role: "VP Product Experience",
      focus: "Employee Journeys & Analytics",
      image: "https://picsum.photos/400/400?random=3",
    },
    {
      name: "Karim Aydin",
      role: "Director Engineering",
      focus: "SSO, SCIM & Security Architecture",
      image: "https://picsum.photos/400/400?random=31",
    },
    {
      name: "Lena Richter",
      role: "Lead Customer Success",
      focus: "Kommunikationsstrategien & Adoption",
      image: "https://picsum.photos/400/400?random=32",
    },
  ];

  const projects = [
    {
      id: 1,
      title: "Global Townhall Launch",
      category: "Ankündigungen",
      description:
        "Multilinguale Bekanntmachung mit Lesestatus und Videoplayer. Zielgruppensteuerung nach Region und Business Unit.",
      image: "https://picsum.photos/1200/800?random=4",
    },
    {
      id: 2,
      title: "Pulse Feedback Serie",
      category: "Umfragen",
      description:
        "Puls Umfragen mit Heatmap Auswertung, Auslöser für Wissensartikel und Mikro-Learnings.",
      image: "https://picsum.photos/1200/800?random=33",
    },
    {
      id: 3,
      title: "Wissensdatenbank Rollout",
      category: "Wissensdatenbank",
      description:
        "Strukturierter Artikel-Katalog mit SCIM Provisioning, Approval Workflows und Analytics.",
      image: "https://picsum.photos/1200/800?random=34",
    },
  ];

  const faqItems = [
    {
      question: "Wie unterstützt Qorvixium DSGVO-konforme interne Kommunikation?",
      answer:
        "Alle Inhalte werden revisionssicher versioniert. Lesebestätigungen und Umfrageantworten sind pseudonymisiert. Audit-Logs und Löschfristen lassen sich unternehmensweit konfigurieren.",
    },
    {
      question: "Welche Authentifizierungsverfahren werden unterstützt?",
      answer:
        "Wir integrieren SSO SAML, OAuth, SCIM Provisioning sowie Just-in-Time Provisioning. Rollenrechte folgen einem granularem RBAC-Modell inklusive Attribute-Based Rules.",
    },
    {
      question: "Wie funktioniert der Double Opt-In für Newsletter?",
      answer:
        "Jede Anmeldung löst eine Bestätigungsmail aus. Erst nach expliziter Zustimmung erfolgt der Versand. Alle Zustimmungen sind jederzeit einsehbar und lassen sich exportieren.",
    },
    {
      question: "Kann ich Qorvixium in Teams oder Slack einbinden?",
      answer:
        "Ja. Interaktive Cards ermöglichen das Lesen, Bestätigen und Feedback direkt in Microsoft Teams oder Slack. Integrationen lassen sich für jede Zielgruppe und jeden Kanal steuern.",
    },
  ];

  const blogItems = [
    {
      title: "Puls Umfragen strategisch einsetzen",
      excerpt:
        "Wie HR-Teams mit kurzen Puls Umfragen tiefe Insights gewinnen und Feedback direkt in Wissensartikel überführen.",
      link: "/blog",
      date: "08. Januar 2024",
    },
    {
      title: "Segmentierung mit RBAC & SCIM",
      excerpt:
        "Best Practices zur Einrichtung von RBAC-Strukturen, die Kommunikationsprojekte beschleunigen und Sicherheit erhöhen.",
      link: "/blog",
      date: "04. Dezember 2023",
    },
    {
      title: "Engagement Analytics als Steuerungsinstrument",
      excerpt:
        "Welche Kennzahlen interne Kommunikation wirklich voranbringen und wie Qorvixium daraus priorisierte Aufgaben ableitet.",
      link: "/blog",
      date: "23. Oktober 2023",
    },
  ];

  useEffect(() => {
    const duration = 1600;
    const interval = 30;
    const steps = duration / interval;
    let currentStep = 0;
    const timer = setInterval(() => {
      currentStep += 1;
      setStatValues(
        stats.map((stat) =>
          Math.min(
            stat.target,
            Math.round((stat.target / steps) * currentStep)
          )
        )
      );
      if (currentStep >= steps) {
        clearInterval(timer);
      }
    }, interval);
    return () => clearInterval(timer);
  }, [stats]);

  useEffect(() => {
    const rotation = setInterval(() => {
      setCurrentTestimonial((prev) =>
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 6000);
    return () => clearInterval(rotation);
  }, [testimonials.length]);

  const filteredProjects =
    projectFilter === "Alle"
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  return (
    <div className={styles.home}>
      <Helmet>
        <title>Qorvixium – Interne Kommunikation neu gedacht</title>
        <meta
          name="description"
          content="Qorvixium liefert interne Kommunikation mit Ankündigungen, Mitarbeiter Newsletter, Puls Umfragen, Wissensdatenbank und DSGVO-konformer Analytics in einer Plattform."
        />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Qorvixium",
            applicationCategory: "BusinessApplication",
            offers: {
              "@type": "Offer",
              availability: "https://schema.org/InStock",
            },
            operatingSystem: "Web",
            url: "https://qorvixium.com",
            creator: {
              "@type": "Organization",
              name: "Qorvixium",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Friedrichstraße 68",
                addressLocality: "Berlin",
                postalCode: "10117",
                addressCountry: "DE",
              },
            },
            featureList: [
              "Ankündigungen mit Lesebestätigung",
              "Mitarbeiter Newsletter mit Segmentierung",
              "Puls Umfragen und Feedback",
              "Wissensdatenbank mit Analytics",
            ],
          })}
        </script>
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <div className={styles.badge}>Neue Generation Interne Kommunikation</div>
          <h1>
            Interne Kommunikation mit präziser Reichweite,
            <span> Engagement Analytics</span> und DSGVO-Sicherheit.
          </h1>
          <p>
            Qorvixium orchestriert Ankündigungen, Mitarbeiter Newsletter, Puls Umfragen
            und Wissensdatenbank in einer Oberfläche. Zielgruppen werden über RBAC,
            SCIM und SSO SAML automatisch synchronisiert, damit Informationen genau dort
            landen, wo sie gebraucht werden.
          </p>
          <div className={styles.heroActions}>
            <a className={styles.primaryAction} href="/kontakt">
              Demo anfordern
            </a>
            <a className={styles.secondaryAction} href="/funktionen">
              Funktionen entdecken
            </a>
          </div>
          <div className={styles.heroMeta}>
            <span>DSGVO-ready Infrastruktur</span>
            <span>Puls Umfragen mit Echtzeitfeedback</span>
            <span>Lesebestätigung für Audit Trails</span>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Moderner Arbeitsplatz mit Kommunikationstools"
          />
          <div className={styles.heroOverlay}>
            <div className={styles.overlayCard}>
              <h3>Ankündigung</h3>
              <ul>
                <li>Q&A Session Townhall</li>
                <li>Info-Sicherheit Update</li>
                <li>Neuer Leitfaden Wissensdatenbank</li>
              </ul>
            </div>
            <div className={styles.overlayCard}>
              <h3>Puls Umfrage</h3>
              <p>Zufriedenheit mit Remote Collaboration</p>
              <div className={styles.overlayChart}>
                <span style={{ width: "72%" }} />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHeader}>
          <h2>Nutzen, die interne Kommunikation messbar verbessern</h2>
          <p>
            Ein zentraler Hub verbindet Bekanntmachungen, Newsletter, Puls Umfragen
            und Wissensdatenbank. Teams erleben transparente Journeys, während Sie
            Engagement Analytics, Lesebestätigung und DSGVO-konforme Nachweise erhalten.
          </p>
        </div>
        <div className={styles.benefitGrid}>
          <article>
            <h3>Reichweite sichern</h3>
            <p>
              Multi-Channel Ausspielung mit Zielgruppen-Segmentierung liefert präzise
              Reichweite. Automatisierte Reminder berücksichtigen Zeitzonen
              und bevorzugte Kanäle.
            </p>
          </article>
          <article>
            <h3>Feedback in Echtzeit</h3>
            <p>
              Puls Umfragen und Micro-Feedback verdichten Insights.
              Heatmaps zeigen Per Team die Stimmung, damit Maßnahmen schnell greifen.
            </p>
          </article>
          <article>
            <h3>Wissenszugriff beschleunigen</h3>
            <p>
              Intelligente Empfehlungen in der Wissensdatenbank verbinden Artikel,
              Playbooks und Videos. Suchanalyse identifiziert Wissenslücken pro Segment.
            </p>
          </article>
        </div>
        <div className={styles.statsRow} role="group" aria-label="Kennzahlen">
          {stats.map((stat, index) => (
            <div key={stat.id} className={styles.statItem}>
              <span>{statValues[index]}</span>
              <p>{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.features}>
        <div className={styles.sectionHeader}>
          <h2>Hauptfunktionen im Überblick</h2>
          <p>
            Von Ankündigungen über Newsletter bis zu Puls Umfragen – jede Funktion wurde
            entwickelt, um Mitarbeitenden relevante Informationen bereitzustellen und
            gleichzeitig Compliance-Anforderungen zu erfüllen.
          </p>
        </div>
        <div className={styles.featuresLayout}>
          <div className={styles.featureMenu}>
            {features.map((feature) => (
              <button
                key={feature.id}
                type="button"
                onClick={() => setActiveFeature(feature.id)}
                className={
                  activeFeature === feature.id
                    ? styles.featureTabActive
                    : styles.featureTab
                }
              >
                {feature.title}
              </button>
            ))}
            <div className={styles.announcementFeed}>
              <h3>Ankündigungs-Feed</h3>
              <ul>
                <li>
                  <span>HR</span> Neue Remote Policy – Lesestatus 86%
                </li>
                <li>
                  <span>IT</span> Systemwartung 15.02 – Lesestatus 73%
                </li>
                <li>
                  <span>Communications</span> Townhall Q2 – Lesestatus 91%
                </li>
              </ul>
              <button
                type="button"
                className={styles.feedButton}
                onClick={() => setModalOpen(true)}
              >
                Gelesen bestätigen
              </button>
            </div>
          </div>
          <div className={styles.featureDetail}>
            {features
              .filter((feature) => feature.id === activeFeature)
              .map((feature) => (
                <article key={feature.id}>
                  <img src={feature.image} alt={feature.title} loading="lazy" />
                  <div>
                    <h3>{feature.title}</h3>
                    <p>{feature.description}</p>
                    <ul>
                      {feature.points.map((point) => (
                        <li key={point}>{point}</li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            <div className={styles.calendar}>
              <h4>Kalender-Interface</h4>
              <div className={styles.calendarGrid}>
                {["Mo", "Di", "Mi", "Do", "Fr"].map((day) => (
                  <div key={day} className={styles.calendarDay}>
                    <strong>{day}</strong>
                    <span>09:00</span>
                    <span>14:00</span>
                  </div>
                ))}
              </div>
              <p>
                Kampagnen werden automatisch in Outlook und Google Kalender
                synchronisiert – inklusive Follow-up Reminder für offene Lesebestätigungen.
              </p>
            </div>
          </div>
        </div>
        {modalOpen && (
          <div className={styles.modalBackdrop} role="dialog" aria-modal="true">
            <div className={styles.modal}>
              <h3>Lesebestätigung senden</h3>
              <p>
                Durch das Bestätigen wird Ihr Lesestatus dokumentiert und Engagement Analytics
                aktualisiert. Vielen Dank für Ihr Feedback.
              </p>
              <div className={styles.modalActions}>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className={styles.modalPrimary}
                >
                  Bestätigen
                </button>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className={styles.modalSecondary}
                >
                  Später erinnern
                </button>
              </div>
            </div>
          </div>
        )}
      </section>

      <section className={styles.useCases}>
        <div className={styles.sectionHeader}>
          <h2>Use Cases – Segmentiert, datengetrieben, skalierbar</h2>
          <p>
            Qorvixium passt sich jeder Organisationsstruktur an. Zielgruppen-Segmentierung
            visualisiert Beziehungen zwischen Teams, Rollen und Standorten und macht
            Kommunikationswege transparent.
          </p>
        </div>
        <div className={styles.useCaseGrid}>
          {useCases.map((useCase) => (
            <article key={useCase.department} className={styles.useCaseCard}>
              <header>
                <h3>{useCase.department}</h3>
                <span>{useCase.metric}</span>
              </header>
              <p>{useCase.description}</p>
              <div className={styles.segments}>
                {useCase.segments.map((segment) => (
                  <span key={segment}>{segment}</span>
                ))}
              </div>
            </article>
          ))}
        </div>
        <div className={styles.workflow}>
          <h3>Workflow – So läuft interne Kommunikation mit Qorvixium</h3>
          <ol>
            <li>
              <strong>Planung:</strong> Redaktionskalender, Verantwortlichkeiten
              und Eskalationspfade definieren.
            </li>
            <li>
              <strong>Segmentierung:</strong> RBAC-Rollen, SCIM Attribute und individuelle
              Kanäle auswählen.
            </li>
            <li>
              <strong>Ausspielung:</strong> Veröffentlichung auf bevorzugten Kanälen,
              inklusive Microsoft Teams & Slack Cards.
            </li>
            <li>
              <strong>Analyse:</strong> Engagement Analytics, Heatmaps und Feedback
              aus Puls Umfragen für Optimierungen.
            </li>
          </ol>
        </div>
      </section>

      <section className={styles.integrations}>
        <div className={styles.sectionHeader}>
          <h2>Integrationen, die Sicherheit und Produktivität verbinden</h2>
          <p>
            Qorvixium fügt sich nahtlos in Ihre bestehende Landschaft ein.
            SSO SAML, SCIM Provisioning, API Hooks und Events sorgen für
            automatisierte Prozesse ohne Medienbrüche.
          </p>
        </div>
        <div className={styles.logoCloud} role="list">
          {integrationLogos.map((logo) => (
            <div key={logo.name} className={styles.logoItem} role="listitem">
              <span>{logo.acronym}</span>
              <p>{logo.name}</p>
            </div>
          ))}
        </div>
        <div className={styles.integrationDetails}>
          <article>
            <h3>Identitäts-Management</h3>
            <p>
              SSO SAML und OAuth sorgen für einheitliche Authentifizierung.
              SCIM Provisioning automatisiert Nutzer- und Gruppenverwaltung.
            </p>
          </article>
          <article>
            <h3>Collaboration</h3>
            <p>
              Ankündigungen erscheinen als adaptive Cards in Microsoft Teams oder Slack.
              Lesestatus synchronisieren sich in Echtzeit auf allen Kanälen.
            </p>
          </article>
          <article>
            <h3>Analytics & BI</h3>
            <p>
              Engagement Analytics lassen sich via API in Power BI oder Looker Studio
              integrieren. So verbinden Sie Kommunikations-KPIs mit Unternehmenskennzahlen.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.voice}>
        <div className={styles.sectionHeader}>
          <h2>Stimmen unserer Kundschaft & Team Insights</h2>
          <p>
            Kommunikations- und HR-Teams gestalten mit Qorvixium messbare Mitarbeitererlebnisse.
            Unser Team begleitet Sie mit Branchenwissen, Data Insights und operativer Erfahrung.
          </p>
        </div>
        <div className={styles.testimonialCarousel}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={
                currentTestimonial === index
                  ? styles.testimonialActive
                  : styles.testimonial
              }
            >
              <p>“{testimonial.quote}”</p>
              <div>
                <strong>{testimonial.name}</strong>
                <span>{testimonial.role}</span>
              </div>
            </article>
          ))}
          <div className={styles.carouselControls}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                aria-label={`Testimonial ${index + 1} anzeigen`}
                className={
                  currentTestimonial === index
                    ? styles.carouselDotActive
                    : styles.carouselDot
                }
                onClick={() => setCurrentTestimonial(index)}
              />
            ))}
          </div>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <span>{member.focus}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.analytics}>
        <div className={styles.sectionHeader}>
          <h2>Analytics & DSGVO-Compliance im Einklang</h2>
          <p>
            Engagement Analytics visualisieren Trendlinien, während DSGVO-konforme Datenhaltung
            Audit-Anforderungen abbildet. Scorecards kombinieren Lesestatus, Puls Umfragen und
            Wissensdatenbank-Zugriffe.
          </p>
        </div>
        <div className={styles.analyticsGrid}>
          <div className={styles.analyticsCard}>
            <h3>Engagement Heatmap</h3>
            <div className={styles.heatmap}>
              {["HQ", "Berlin", "München", "Remote"].map((location) => (
                <div key={location} className={styles.heatmapRow}>
                  <span>{location}</span>
                  <div>
                    <span style={{ width: `${Math.random() * 30 + 60}%` }} />
                  </div>
                </div>
              ))}
            </div>
            <p>
              Heatmaps kombinieren Lesestatus, Klickpfade in der Wissensdatenbank und
              Teilnahme an Puls Umfragen – segmentiert nach Rollen, Teams und Standorten.
            </p>
          </div>
          <div className={styles.analyticsCard}>
            <h3>Datenschutz-Center</h3>
            <ul>
              <li>Rechtemanagement mit RBAC & granularem Logging</li>
              <li>Data Residency in EU-Rechenzentren</li>
              <li>Automatisierte Aufbewahrungsfristen</li>
              <li>Transparente Audit-Trails für alle Kommunikationskanäle</li>
            </ul>
          </div>
          <div className={styles.analyticsCard}>
            <h3>Projektgalerie</h3>
            <div className={styles.filter}>
              {["Alle", "Ankündigungen", "Umfragen", "Wissensdatenbank"].map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setProjectFilter(category)}
                  className={
                    projectFilter === category ? styles.filterActive : ""
                  }
                >
                  {category}
                </button>
              ))}
            </div>
            <div className={styles.projectGrid}>
              {filteredProjects.map((project) => (
                <article key={project.id}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                  <h4>{project.title}</h4>
                  <span>{project.category}</span>
                  <p>{project.description}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.resourcesSection}>
        <div className={styles.sectionHeader}>
          <h2>Ressourcen, FAQ & aktuelle Einblicke</h2>
          <p>
            Vertiefen Sie Ihre Strategie mit praktischen Leitfäden, Webinaren und
            Best Practices. Unser Ressourcencenter bündelt Know-how für interne Kommunikation.
          </p>
        </div>
        <div className={styles.faqBlog}>
          <div className={styles.faq}>
            <h3>FAQ</h3>
            <ul>
              {faqItems.map((item, index) => (
                <li key={item.question}>
                  <button
                    type="button"
                    aria-expanded={openedFaq === index}
                    onClick={() =>
                      setOpenedFaq((prev) => (prev === index ? null : index))
                    }
                  >
                    {item.question}
                    <span>{openedFaq === index ? "–" : "+"}</span>
                  </button>
                  {openedFaq === index && <p>{item.answer}</p>}
                </li>
              ))}
            </ul>
          </div>
          <div className={styles.blogPreview}>
            <h3>Blog Preview</h3>
            {blogItems.map((item) => (
              <article key={item.title}>
                <span>{item.date}</span>
                <h4>{item.title}</h4>
                <p>{item.excerpt}</p>
                <a href={item.link}>Weiterlesen</a>
              </article>
            ))}
          </div>
        </div>
        <div className={styles.finalCta}>
          <div>
            <h2>Bereit, interne Kommunikation spürbar zu verändern?</h2>
            <p>
              Vereinbaren Sie eine geführte Demo und erleben Sie,
              wie Ankündigungen, Newsletter, Puls Umfragen und Wissensdatenbank zusammenwirken.
            </p>
          </div>
          <a href="/kontakt" className={styles.finalCtaButton}>
            Demo anfordern
          </a>
        </div>
      </section>
    </div>
  );
};

export default Home;