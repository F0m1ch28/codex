import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

const TermsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Allgemeine Geschäftsbedingungen | Qorvixium</title>
      <meta
        name="description"
        content="Allgemeine Geschäftsbedingungen von Qorvixium für die Nutzung der Plattform für interne Kommunikation, Ankündigungen, Newsletter, Puls Umfragen und Wissensdatenbank."
      />
      <link rel="canonical" href="https://qorvixium.com/agb" />
    </Helmet>
    <header className={styles.header}>
      <h1>Allgemeine Geschäftsbedingungen</h1>
      <p>Stand: Januar 2024</p>
    </header>
    <section className={styles.section}>
      <h2>1. Geltungsbereich</h2>
      <p>
        Diese AGB regeln die Nutzung der Software-as-a-Service-Plattform Qorvixium
        (nachfolgend „Plattform“) durch Geschäftskund*innen. Abweichende Bedingungen
        werden nicht anerkannt, sofern Qorvixium nicht schriftlich zustimmt.
      </p>
    </section>
    <section className={styles.section}>
      <h2>2. Leistungsumfang</h2>
      <p>
        Qorvixium stellt Funktionen für Ankündigungen, Mitarbeiter Newsletter, Puls
        Umfragen, Wissensdatenbank, Engagement Analytics sowie Schnittstellen für
        SSO SAML, SCIM und RBAC bereit. Der genaue Umfang ergibt sich aus dem jeweiligen Leistungsnachweis.
      </p>
    </section>
    <section className={styles.section}>
      <h2>3. Pflichten der Nutzenden</h2>
      <p>
        Kund*innen verpflichten sich, Zugangsdaten vertraulich zu behandeln,
        Datenschutzbestimmungen einzuhalten und Inhalte nur im Rahmen geltender Gesetze zu nutzen.
      </p>
    </section>
    <section className={styles.section}>
      <h2>4. Verfügbarkeit & Wartung</h2>
      <p>
        Qorvixium strebt eine hohe Verfügbarkeit an und führt Wartungen nach Vorankündigung
        durch. Sicherheits-Updates können kurzfristig erfolgen, um DSGVO-Konformität zu wahren.
      </p>
    </section>
    <section className={styles.section}>
      <h2>5. Haftung</h2>
      <p>
        Qorvixium haftet unbeschränkt bei Vorsatz und grober Fahrlässigkeit sowie für Schäden
        aus der Verletzung des Lebens, des Körpers oder der Freiheit. Im Übrigen ist die Haftung
        auf den typischerweise vorhersehbaren Schaden begrenzt.
      </p>
    </section>
    <section className={styles.section}>
      <h2>6. Schlussbestimmungen</h2>
      <p>
        Es gilt deutsches Recht. Gerichtsstand ist, soweit zulässig, Berlin.
        Sollten einzelne Bestimmungen unwirksam sein, bleibt die Wirksamkeit der übrigen unberührt.
      </p>
    </section>
  </div>
);

export const ImpressumPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Impressum | Qorvixium</title>
      <meta
        name="description"
        content="Impressum von Qorvixium – Anbieter der Plattform für interne Kommunikation, Ankündigungen, Newsletter, Puls Umfragen und Wissensdatenbank."
      />
      <link rel="canonical" href="https://qorvixium.com/impressum" />
    </Helmet>
    <header className={styles.header}>
      <h1>Impressum</h1>
    </header>
    <section className={styles.section}>
      <h2>Angaben gemäß § 5 TMG</h2>
      <p>
        Qorvixium<br />
        Friedrichstraße 68<br />
        10117 Berlin, Deutschland
      </p>
      <p>Telefon: +49 30 1234 5678<br />E-Mail: hello@qorvixium.com</p>
      <p>
        Vertretungsberechtigt: Lara Schenk<br />
        Registergericht: Amtsgericht Charlottenburg<br />
        Registernummer: HRB 123456 B<br />
        Umsatzsteuer-ID: DE123456789
      </p>
    </section>
    <section className={styles.section}>
      <h2>Verantwortlich für den Inhalt</h2>
      <p>Lara Schenk, Friedrichstraße 68, 10117 Berlin.</p>
    </section>
  </div>
);

export const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie-Richtlinie | Qorvixium</title>
      <meta
        name="description"
        content="Cookie-Richtlinie von Qorvixium: Informationen zu funktionalen Cookies, Analytics und Consent-Management."
      />
      <link rel="canonical" href="https://qorvixium.com/cookie-richtlinie" />
    </Helmet>
    <header className={styles.header}>
      <h1>Cookie-Richtlinie</h1>
    </header>
    <section className={styles.section}>
      <h2>Funktionale Cookies</h2>
      <p>
        Diese Cookies sind erforderlich, damit grundlegende Funktionen wie Logins,
        Formularspeicherungen und Consent-Einstellungen funktionieren.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Analytics Cookies</h2>
      <p>
        Analytics Cookies erfassen pseudonymisierte Daten zum Nutzungsverhalten,
        um Engagement Analytics zu verbessern. Sie werden nur nach aktiver Zustimmung gesetzt.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Cookie Verwaltung</h2>
      <p>
        Im Cookie-Banner können Sie Analytics Cookies aktivieren oder ablehnen. Ihre Auswahl
        wird gespeichert und kann jederzeit im Profil oder über support@qorvixium.com angepasst werden.
      </p>
    </section>
  </div>
);

export default TermsPage;