import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const FunktionenPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Funktionen | Qorvixium</title>
      <meta
        name="description"
        content="Ankündigungen, Mitarbeiter Newsletter, Puls Umfragen und Wissensdatenbank – die Funktionen von Qorvixium für interne Kommunikation."
      />
      <link rel="canonical" href="https://qorvixium.com/funktionen" />
    </Helmet>
    <header className={styles.header}>
      <h1>Funktionen, die Ihre interne Kommunikation verbinden</h1>
      <p>
        Qorvixium bietet modulare Bausteine für Ankündigungen, Newsletter, Puls Umfragen,
        Wissensdatenbank und Analytics. Workflow-Automatisierung, RBAC, SCIM
        und SSO SAML sichern Governance.
      </p>
    </header>
    <section className={styles.modules}>
      <article>
        <h2>Ankündigungen</h2>
        <p>
          Planen und veröffentlichen Sie relevante Bekanntmachungen mit granularer
          Segmentierung, Lesebestätigung und mehrstufigem Freigabeprozess.
        </p>
        <ul>
          <li>Segmentierung nach Rollen, Standorten und Skills</li>
          <li>Freigabeworkflows mit Delegationen</li>
          <li>Lesestatus-Reporting und Reminder</li>
        </ul>
      </article>
      <article>
        <h2>Newsletter Studio</h2>
        <p>
          Gestalten Sie Newsletter mit adaptiven Inhalten und Double Opt-In.
          Integration mit CRM und HRIS ermöglicht gezielte Journeys.
        </p>
        <ul>
          <li>Drag & Drop Templates und Markenrichtlinien</li>
          <li>Dynamische Inhalte pro Zielgruppe</li>
          <li>Engagement Analytics und UTM-Tracking</li>
        </ul>
      </article>
      <article>
        <h2>Puls Umfragen</h2>
        <p>
          Verwalten Sie Puls Umfragen mit Fragebibliothek, Benchmarking
          und Echtzeit-Heatmaps für alle Teams.
        </p>
        <ul>
          <li>Skalen-, Freitext- und Stimmungsfragen</li>
          <li>Automatisierte Reminder und Eskalationen</li>
          <li>Integrationen in Microsoft Teams und Slack</li>
        </ul>
      </article>
      <article>
        <h2>Wissensdatenbank</h2>
        <p>
          Strukturierte Artikel mit Versionierung, Empfehlungen und
          Suchanalyse. Rollenbasierte Zugriffe sorgen für Governance.
        </p>
        <ul>
          <li>Genehmigungs- und Review-Workflows</li>
          <li>Empfehlungs-Engine für Onboarding & Upskilling</li>
          <li>Analytics für Suchbegriffe und Artikelqualität</li>
        </ul>
      </article>
      <article>
        <h2>Engagement Analytics</h2>
        <p>
          Kombinieren Sie Lesestatus, Newsletter-Interaktionen, Umfragewerte
          und Wissensdatenbank-Zugriffe in einem Dashboard.
        </p>
        <ul>
          <li>Heatmaps und Drill-downs bis zur Team-Ebene</li>
          <li>Exports für Audits und Management Reports</li>
          <li>API-Connectors für BI-Tools</li>
        </ul>
      </article>
      <article>
        <h2>Compliance & Sicherheit</h2>
        <p>
          DSGVO-konforme Architektur mit EU-Hosting, Consent-Management
          und ausführlichen Audit-Trails.
        </p>
        <ul>
          <li>Data Residency in deutschen Rechenzentren</li>
          <li>RBAC, SCIM und granulare Rechte</li>
          <li>Consent-Verwaltung und Löschfristen</li>
        </ul>
      </article>
    </section>
  </div>
);

export const UseCasesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Use Cases | Qorvixium</title>
      <meta
        name="description"
        content="Use Cases für interne Kommunikation: HR, IT, Kommunikation und Operations nutzen Qorvixium für Ankündigungen, Puls Umfragen und Wissensmanagement."
      />
      <link rel="canonical" href="https://qorvixium.com/use-cases" />
    </Helmet>
    <header className={styles.header}>
      <h1>Use Cases – Wirkung in jeder Abteilung</h1>
      <p>
        Qorvixium verbindet interne Kommunikation über HR, Kommunikation, IT, Operations
        und Leadership. Zielgruppen werden automatisch synchronisiert, Engagement Analytics
        liefern verwertbare Insights.
      </p>
    </header>
    <section className={styles.useCases}>
      <article>
        <h2>HR & People</h2>
        <p>
          Onboarding Journeys, Recruiting Updates und Kulturprogramme mit präziser
          Segmentierung, Puls Umfragen und Lesebestätigung.
        </p>
      </article>
      <article>
        <h2>Kommunikation</h2>
        <p>
          Globale Kampagnen, Krisenkommunikation und Townhalls mit orchestrierten
          Ankündigungen, Kalender-Sync und Analytics.
        </p>
      </article>
      <article>
        <h2>IT & Security</h2>
        <p>
          Change Mitteilungen, Security Advisories und Plattform-Rollouts mit
          SSO SAML, SCIM Provisioning und Audit-Logs.
        </p>
      </article>
      <article>
        <h2>Operations</h2>
        <p>
          Standortübergreifende Schichtinformationen, Qualitätsupdates und
          Prozessänderungen mit mobilen Kanälen.
        </p>
      </article>
      <article>
        <h2>Leadership</h2>
        <p>
          Strategie-Kommunikation, Feedback-Loops und Wissensartikel, die
          Führungsteams in Echtzeit erreichen.
        </p>
      </article>
    </section>
  </div>
);

export const IntegrationenPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Integrationen | Qorvixium</title>
      <meta
        name="description"
        content="Integrationen von Qorvixium: Microsoft 365, Google Workspace, Slack, Microsoft Teams, Okta, Azure AD sowie API- und Webhook-Anbindungen."
      />
      <link rel="canonical" href="https://qorvixium.com/integrationen" />
    </Helmet>
    <header className={styles.header}>
      <h1>Integrationen für Ihre Systemlandschaft</h1>
      <p>
        Qorvixium integriert sich in Microsoft 365, Google Workspace, Slack, Teams,
        Okta, Azure AD und viele weitere Systeme. SCIM, Webhooks und offene APIs
        ermöglichen automatisierte Workflows.
      </p>
    </header>
    <section className={styles.integrationList}>
      <article>
        <h2>Identität & Zugang</h2>
        <p>
          SSO SAML, OAuth und SCIM Provisioning für automatische Synchronisierung
          von Nutzer*innen, Gruppen und Attributen.
        </p>
      </article>
      <article>
        <h2>Collaboration Kanäle</h2>
        <p>
          Adaptive Cards in Microsoft Teams und Slack, Kalender-Sync mit Outlook,
          Google Calendar und ICS-Feeds.
        </p>
      </article>
      <article>
        <h2>Analytics & BI</h2>
        <p>
          Exportieren Sie Engagement Analytics in Power BI, Tableau oder Looker Studio.
          Webhooks informieren über Lesestatus in Echtzeit.
        </p>
      </article>
      <article>
        <h2>HR & CRM Systeme</h2>
        <p>
          Synchronisieren Sie HRIS-Attribute für Segmentierung und automatische Journeys.
          CRM-Daten speisen personalisierte Newsletter.
        </p>
      </article>
    </section>
  </div>
);

export default FunktionenPage;