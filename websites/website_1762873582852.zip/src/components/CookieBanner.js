import React, { useEffect, useState } from "react";
import styles from "./CookieBanner.module.css";

const COOKIE_KEY = "qorvixium-cookie-consent";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [preference, setPreference] = useState(null);

  useEffect(() => {
    const stored = window.localStorage.getItem(COOKIE_KEY);
    if (stored) {
      setPreference(stored);
    } else {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    window.localStorage.setItem(COOKIE_KEY, choice);
    setPreference(choice);
    setIsVisible(false);
  };

  if (!isVisible || preference) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Qorvixium verwendet funktionale Cookies und optional Analytics, um Engagement
          Trends besser zu verstehen. Wählen Sie bitte, ob wir pseudonymisierte Analytics
          aktivieren dürfen.
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.secondary}
            onClick={() => handleChoice("declined")}
          >
            Ablehnen
          </button>
          <button
            type="button"
            className={styles.primary}
            onClick={() => handleChoice("accepted")}
          >
            Akzeptieren
          </button>
        </div>
        <a href="/cookie-richtlinie" className={styles.link}>
          Details zur Cookie-Nutzung
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;