import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  const [email, setEmail] = useState("");
  const [feedback, setFeedback] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email || !email.includes("@")) {
      setFeedback("Bitte geben Sie eine gültige geschäftliche E-Mail-Adresse ein.");
      return;
    }
    setFeedback(
      "Vielen Dank! Sie erhalten in Kürze eine E-Mail zur Bestätigung Ihrer Anmeldung (Double Opt-In)."
    );
    setEmail("");
  };

  return (
    <footer className={styles.footer}>
      <div className={styles.grid}>
        <div className={styles.brand}>
          <div className={styles.logo}>Q</div>
          <p>
            Qorvixium vereint Ankündigungen, Mitarbeiter Newsletter, Puls Umfragen
            und Wissensmanagement in einer Plattform für fokussierte interne Kommunikation.
          </p>
          <p className={styles.address}>
            Friedrichstraße 68<br />
            10117 Berlin, Deutschland
          </p>
          <a className={styles.phone} href="tel:+493012345678">
            +49 30 1234 5678
          </a>
        </div>
        <div className={styles.links}>
          <h3>Navigation</h3>
          <ul>
            <li>
              <NavLink to="/funktionen">Funktionen</NavLink>
            </li>
            <li>
              <NavLink to="/use-cases">Use Cases</NavLink>
            </li>
            <li>
              <NavLink to="/integrationen">Integrationen</NavLink>
            </li>
            <li>
              <NavLink to="/ressourcen">Ressourcen</NavLink>
            </li>
            <li>
              <NavLink to="/blog">Blog</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.legal}>
          <h3>Rechtliches</h3>
          <ul>
            <li>
              <NavLink to="/impressum">Impressum</NavLink>
            </li>
            <li>
              <NavLink to="/datenschutz">Datenschutz</NavLink>
            </li>
            <li>
              <NavLink to="/agb">AGB</NavLink>
            </li>
            <li>
              <NavLink to="/cookie-richtlinie">Cookie-Richtlinie</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.newsletter}>
          <h3>Newsletter</h3>
          <p>
            Erhalten Sie monatliche Einblicke zu interner Kommunikation, DSGVO Updates
            und Engagement Analytics. Double Opt-In garantiert Transparenz.
          </p>
          <form onSubmit={handleSubmit} className={styles.form}>
            <label htmlFor="newsletter-email" className="sr-only">
              E-Mail-Adresse
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              placeholder="E-Mail-Adresse"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
              aria-describedby="newsletter-feedback"
            />
            <button type="submit">Abonnieren</button>
          </form>
          <p id="newsletter-feedback" className={styles.feedback}>
            {feedback}
          </p>
          <span className={styles.consent}>
            Wir senden zunächst eine Bestätigungsmail. Ohne Ihre Zustimmung erfolgt kein Versand.
          </span>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Qorvixium. Alle Rechte vorbehalten.</p>
        <div className={styles.social}>
          <a href="https://www.linkedin.com" aria-label="LinkedIn">
            LinkedIn
          </a>
          <a href="https://www.twitter.com" aria-label="Twitter">
            Twitter
          </a>
          <a href="https://www.xing.com" aria-label="Xing">
            Xing
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;