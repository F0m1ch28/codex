import React, { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import styles from "./Header.module.css";

const menuItems = [
  { path: "/funktionen", label: "Funktionen" },
  { path: "/use-cases", label: "Use Cases" },
  { path: "/integrationen", label: "Integrationen" },
  { path: "/ressourcen", label: "Ressourcen" },
  { path: "/blog", label: "Blog" },
  { path: "/kontakt", label: "Kontakt" },
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 12);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header
      className={`${styles.header} ${scrolled ? styles.scrolled : ""}`}
      role="banner"
    >
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Qorvixium Startseite">
          <span className={styles.logoMark}>Q</span>
          <span className={styles.logoText}>Qorvixium</span>
        </NavLink>
        <nav
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ""}`}
          aria-label="Hauptnavigation"
        >
          <ul className={styles.navList}>
            {menuItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ""}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            <li className={styles.navCtaWrapper}>
              <NavLink to="/kontakt" className={styles.navCta}>
                Demo anfragen
              </NavLink>
            </li>
          </ul>
        </nav>
        <button
          className={`${styles.mobileToggle} ${
            menuOpen ? styles.mobileToggleOpen : ""
          }`}
          aria-label="Menü umschalten"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;