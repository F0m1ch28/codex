document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  const navLinks = document.querySelectorAll('.nav-menu a');
  const scrollBtn = document.querySelector('.scroll-to-top');
  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieAcceptBtn = document.querySelector('#cookie-accept');
  const cookieStorageKey = 'mapledata_cookie_consent';
  const yearSpan = document.querySelectorAll('#current-year');
  const forms = document.querySelectorAll('form[data-form]');

  if (yearSpan.length > 0) {
    const year = new Date().getFullYear();
    yearSpan.forEach(span => span.textContent = year);
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 780) {
        navMenu.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  if (navLinks) {
    navLinks.forEach(link => {
      if (link.dataset.page === document.body.dataset.page) {
        link.classList.add('active');
      }
      link.addEventListener('click', () => {
        navMenu?.classList.remove('open');
        navToggle?.setAttribute('aria-expanded', 'false');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
  }

  if (scrollBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 320) {
        scrollBtn.classList.add('show');
      } else {
        scrollBtn.classList.remove('show');
      }
    });

    scrollBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (cookieBanner && cookieAcceptBtn) {
    const hasConsent = localStorage.getItem(cookieStorageKey);
    if (!hasConsent) {
      cookieBanner.classList.add('show');
    }

    cookieAcceptBtn.addEventListener('click', () => {
      localStorage.setItem(cookieStorageKey, 'accepted');
      cookieBanner.classList.remove('show');
    });
  }

  if (forms.length > 0) {
    forms.forEach(form => {
      const feedback = form.querySelector('.form-feedback');
      form.addEventListener('submit', event => {
        event.preventDefault();
        const formData = new FormData(form);
        const name = (formData.get('name') || '').toString().trim();
        const email = (formData.get('email') || '').toString().trim();
        if (!name || !email) {
          if (feedback) {
            feedback.textContent = 'Please complete the required fields before submitting.';
            feedback.style.color = '#d9534f';
          }
          return;
        }
        if (feedback) {
          feedback.textContent = 'Thank you. Your message has been received. A member of our team will respond within one business day.';
          feedback.style.color = '#1f3653';
        }
        form.reset();
      });
    });
  }
});