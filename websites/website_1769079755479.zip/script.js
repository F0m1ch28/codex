document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  const navIcon = document.querySelector(".nav-icon");

  if (navToggle && primaryNav && navIcon) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNav.classList.toggle("open");
      navToggle.classList.toggle("active", isOpen);
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      if (isOpen) {
        navIcon.setAttribute("aria-hidden", "true");
      } else {
        navIcon.removeAttribute("aria-hidden");
      }
    });
  }

  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", () => {
      if (primaryNav.classList.contains("open")) {
        primaryNav.classList.remove("open");
        navToggle.classList.remove("active");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18 }
  );

  document.querySelectorAll(".fade-in").forEach((section) => {
    observer.observe(section);
  });

  const cookieBanner = document.getElementById("cookieBanner");
  const acceptCookies = document.getElementById("acceptCookies");
  const declineCookies = document.getElementById("declineCookies");

  if (cookieBanner && acceptCookies && declineCookies) {
    const storedChoice = localStorage.getItem("humanizaCookieChoice");
    if (!storedChoice) {
      requestAnimationFrame(() => cookieBanner.classList.add("visible"));
    }

    const handleChoice = (choice) => {
      localStorage.setItem("humanizaCookieChoice", choice);
      cookieBanner.classList.remove("visible");
    };

    acceptCookies.addEventListener("click", () => handleChoice("accepted"));
    declineCookies.addEventListener("click", () => handleChoice("declined"));
  }

  const toast = document.getElementById("formToast");
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("visible");
    setTimeout(() => {
      toast.classList.remove("visible");
    }, 2400);
  };

  const forms = document.querySelectorAll('form[data-form="contact"]');
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Mensaje enviado. Redirigiendo…");
      setTimeout(() => {
        window.location.href = "thank-you.html";
      }, 1200);
    });
  });
});