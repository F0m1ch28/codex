document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.mobile-nav-toggle');
    const navigation = document.querySelector('.primary-navigation');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAcceptBtn = document.getElementById('cookieAcceptBtn');
    const navLinks = document.querySelectorAll('.nav-link');
    const currentYearEl = document.getElementById('currentYear');

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navigation.classList.toggle('open');
        });
    }

    if (navLinks) {
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollBtn.classList.add('show');
            } else {
                scrollBtn.classList.remove('show');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAcceptBtn) {
        const consent = localStorage.getItem('insightMapleCookieConsent');
        if (consent !== 'accepted') {
            cookieBanner.classList.add('show');
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem('insightMapleCookieConsent', 'accepted');
            cookieBanner.classList.remove('show');
        });
    }

    const forms = document.querySelectorAll('.contact-form');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();
            const responseEl = form.querySelector('.form-response');
            const requiredFields = form.querySelectorAll('[required]');
            let valid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('error');
                    valid = false;
                } else {
                    field.classList.remove('error');
                }
            });

            if (!valid) {
                if (responseEl) {
                    responseEl.textContent = 'Проверьте, что все обязательные поля заполнены корректно.';
                    responseEl.style.color = '#c0392b';
                }
                return;
            }

            if (responseEl) {
                responseEl.textContent = 'Спасибо! Мы получили ваш запрос и свяжемся в ближайшее время.';
                responseEl.style.color = '#1f3d55';
            }

            form.reset();
        });
    });
});