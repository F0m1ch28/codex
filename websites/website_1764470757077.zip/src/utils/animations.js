export const fadeInUp = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: "easeOut" }
  }
};

export const staggerChildren = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.15
    }
  }
};

export const scaleOnHover = {
  rest: { scale: 1, boxShadow: "0px 0px 0px rgba(37,99,235,0)" },
  hover: {
    scale: 1.02,
    boxShadow: "0px 20px 48px rgba(15,23,42,0.18)",
    transition: { duration: 0.35, ease: "easeOut" }
  }
};
```

---

```javascript