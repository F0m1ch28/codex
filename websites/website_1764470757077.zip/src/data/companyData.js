export const promises = [
  {
    title: "Datos verificados para planificar tu presupuesto.",
    detail: "Our analysts curate inflation, CPI, and FX signals grounded in Argentinian realities."
  },
  {
    title: "Decisiones responsables, objetivos nítidos.",
    detail: "Clarity across scenarios so your next purchase or saving move feels anchored."
  },
  {
    title: "Conocimiento financiero impulsado por tendencias.",
    detail: "Blend macro insights with personal budgeting habits designed for emerging earners."
  },
  {
    title: "Pasos acertados hoy, mejor futuro mañana.",
    detail: "Action cards turn information into doable experiments inside your financial life."
  }
];

export const timeline = [
  {
    year: "2018",
    title: "Data heartbeat begins",
    description:
      "University research on peso volatility grows into weekly dashboards for student circles in Córdoba."
  },
  {
    year: "2020",
    title: "Community-first labs",
    description:
      "Tu Progreso Hoy launches open labs amid unprecedented inflation surges, translating CPI into daily choices."
  },
  {
    year: "2022",
    title: "Learning routes expand",
    description:
      "Interactive course content and bilingual glossaries empower learners from Salta to Ushuaia."
  },
  {
    year: "2024",
    title: "Immersive guidance",
    description:
      "We introduce scenario simulators, cohort badges, and double opt-in study paths for every registrant."
  }
];

export const modules = [
  {
    title: "Week 1 — Mapping pesos in motion",
    bullets: [
      "ARS→USD sentiment radar with historical CPI overlays",
      "Personal inflation journal template for Argentine households",
      "Quick wins: restructure expenses with opportunity zones"
    ]
  },
  {
    title: "Week 2 — Systems for resilient budgeting",
    bullets: [
      "Envelope and percentage systems tuned for peso volatility",
      "Emergency buffer strategies in multi-currency contexts",
      "Gamified checklists with sound cues and progress arcs"
    ]
  },
  {
    title: "Week 3 — From insights to criteria",
    bullets: [
      "Scenario planning for tuition, rent, and remittance needs",
      "Mindful spending heuristics validated by national data",
      "Peer discussion pods with real-time ARS dashboards"
    ]
  },
  {
    title: "Week 4 — Sustain the momentum",
    bullets: [
      "Habit tracking, badges, and accountability partners",
      "Evaluation rubric: De la información al aprendizaje: fortalece tu criterio financiero paso a paso.",
      "Capstone reflection with milestone trophies"
    ]
  }
];

export const testimonials = [
  {
    quote:
      "Análisis transparentes y datos de mercado para decidir con seguridad. The live CPI context helped my family plan monthly groceries.",
    author: "María Belén • Rosario"
  },
  {
    quote:
      "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. The course made inflation less abstract and more actionable.",
    author: "Federico • Córdoba"
  },
  {
    quote:
      "Información confiable que respalda elecciones responsables sobre tu dinero. Finally, a space that respects the complexity of pesos.",
    author: "Julieta • Buenos Aires"
  }
];

export const faqs = [
  {
    q: "How do you source ARS→USD exchange insights?",
    a: "We triangulate official BCRA references, blue-chip swap averages, and curated market data providers, clearly labeling each methodology."
  },
  {
    q: "Do you offer personal investment recommendations?",
    a: "No. Plataforma educativa con datos esenciales, sin asesoría financiera directa. Each learner owns their financial decisions."
  },
  {
    q: "Is the course suitable for beginners?",
    a: "Absolutely. We honour beginner questions, bilingual glossaries, and progressive disclosure to support first-time learners."
  },
  {
    q: "How does the double opt-in work?",
    a: "After registration, you receive a confirmation email. Only after confirming will you gain course access details."
  }
];

export const articles = [
  {
    id: "inflation-field-notes",
    title: "Field Notes: Navigating ARS inflation week by week",
    excerpt: "We distill the peso pulse into mindful habits so your budget can breathe.",
    lang: "en",
    readTime: "8 min",
    category: "Inflation Science"
  },
  {
    id: "glosario-cotidiano",
    title: "Glosario cotidiano: términos de inflación explicados",
    excerpt: "Del IPC al crawling peg, traducimos jerga para tus decisiones diarias.",
    lang: "es",
    readTime: "6 min",
    category: "Glosarios"
  },
  {
    id: "saving-rituals-ar",
    title: "Saving rituals that withstand peso volatility",
    excerpt: "Learn three rituals used by learners across Argentina to stay grounded amid FX swings.",
    lang: "en",
    readTime: "10 min",
    category: "Personal Finance"
  },
  {
    id: "hoja-de-ruta-usd",
    title: "Hoja de ruta para entender la brecha ARS→USD",
    excerpt: "Comparaciones, contexto histórico y señales para tu planificación.",
    lang: "es",
    readTime: "7 min",
    category: "Market Context"
  }
];
```

---

```javascript