import React from "react";
import { Helmet } from "react-helmet-async";
import SectionTitle from "../components/SectionTitle";
import { faqs } from "../data/companyData";
import { motion } from "framer-motion";
import { fadeInUp } from "../utils/animations";
import { LanguageContext } from "../context/LanguageContext";

const Inflation = () => {
  const { language } = React.useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Inflation Methodology | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Transparent methodology connecting Argentine CPI, FX data, and macro signals into an educational experience."
        />
      </Helmet>

      <section className="page-hero">
        <div className="page-hero-inner">
          <h1>{language === "es" ? "Metodología de inflación" : "Inflation methodology"}</h1>
          <p>
            {language === "es"
              ? "Análisis transparentes y datos de mercado para decidir con seguridad."
              : "Análisis transparentes y datos de mercado para decidir con seguridad."}
          </p>
        </div>
      </section>

      <section className="methodology">
        <SectionTitle
          eyebrow={language === "es" ? "Enfoque" : "Approach"}
          title={language === "es" ? "Cómo trabajamos los datos" : "How we work with data"}
        />
        <div className="methodology-grid">
          <article>
            <h2>{language === "es" ? "Capas de datos" : "Data layers"}</h2>
            <p>
              {language === "es"
                ? "Cruzamos fuentes oficiales (INDEC, BCRA), series alternativas y datos comunitarios para rastrear el pulso ARS→USD. Cada señal se etiqueta con su origen."
                : "We cross official sources (INDEC, BCRA), alternative series, and community-generated data to trace the ARS→USD pulse. Every signal is source-tagged."}
            </p>
            <ul>
              <li>{language === "es" ? "BCRA: tipo de cambio oficial y crawling peg." : "BCRA: official rate and crawling peg."}</li>
              <li>{language === "es" ? "Mercado paralelo: promedios diarios blue." : "Parallel market: daily blue averages."}</li>
              <li>
                {language === "es"
                  ? "Encuestas semanales a la comunidad: percepciones de precios."
                  : "Weekly community surveys for price perception."}
              </li>
            </ul>
          </article>
          <article>
            <h2>{language === "es" ? "Contexto CPI / FX" : "CPI / FX context"}</h2>
            <p>
              {language === "es"
                ? "Transformamos el IPC nacional en escenarios concretos: alimentos, transporte, educación. Cada módulo del curso compara CPI vs. FX para aterrizar estrategias."
                : "We translate national CPI into concrete scenarios: food, transport, education. Each course module compares CPI vs FX to anchor strategies."}
            </p>
            <div className="mini-chart-container">
              <div className="mini-chart">
                <span>{language === "es" ? "IPC mensual" : "Monthly CPI"}</span>
                <div className="bar" style={{ height: "72%" }} />
                <small>+17.9%</small>
              </div>
              <div className="mini-chart">
                <span>{language === "es" ? "Depreciación ARS" : "ARS depreciation"}</span>
                <div className="bar" style={{ height: "64%" }} />
                <small>+12.3%</small>
              </div>
              <div className="mini-chart">
                <span>{language === "es" ? "Spread oficial/blue" : "Official/blue spread"}</span>
                <div className="bar" style={{ height: "55%" }} />
                <small>+9.1%</small>
              </div>
            </div>
          </article>
          <article>
            <h2>{language === "es" ? "Transparencia" : "Transparency"}</h2>
            <p>
              {language === "es"
                ? "Cada insight incluye metodología, limitaciones y recomendaciones de uso responsable. Información confiable que respalda elecciones responsables sobre tu dinero."
                : "Each insight includes methodology, limitations, and responsible use reminders. Información confiable que respalda elecciones responsables sobre tu dinero."}
            </p>
            <p>
              {language === "es"
                ? "Publicamos changelog semanal, señalando ajustes de ponderaciones y correcciones."
                : "We publish a weekly changelog, highlighting weight adjustments and corrections."}
            </p>
          </article>
        </div>
      </section>

      <section className="faq-section">
        <SectionTitle
          eyebrow={language === "es" ? "FAQ" : "FAQ"}
          title={language === "es" ? "Preguntas frecuentes" : "Frequently asked questions"}
        />
        <div className="faq-grid">
          {faqs.map((item) => (
            <motion.details key={item.q} className="faq-item" variants={fadeInUp} initial="hidden" whileInView="visible">
              <summary>{item.q}</summary>
              <p>{item.a}</p>
            </motion.details>
          ))}
        </div>
      </section>
    </>
  );
};

export default Inflation;
```

---

```javascript