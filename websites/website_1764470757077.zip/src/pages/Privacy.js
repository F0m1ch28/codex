import React from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const Privacy = () => {
  const { language } = React.useContext(LanguageContext);
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
      </Helmet>
      <section className="legal-page">
        <h1>{language === "es" ? "Política de privacidad" : "Privacy Policy"}</h1>
        <p>
          {language === "es"
            ? "Protegemos tu información personal con estándares internacionales y prácticas transparentes."
            : "We protect your personal information with international standards and transparent practices."}
        </p>
        <h2>{language === "es" ? "Datos recolectados" : "Data collected"}</h2>
        <ul>
          <li>{language === "es" ? "Nombre y correo electrónico para doble opt-in." : "Name and email for double opt-in."}</li>
          <li>
            {language === "es"
              ? "Preferencias de idioma y consentimiento de cookies."
              : "Language preferences and cookie consent."}
          </li>
        </ul>
        <h2>{language === "es" ? "Uso de datos" : "Data usage"}</h2>
        <p>
          {language === "es"
            ? "Utilizamos la información para gestionar accesos, comunicar novedades y personalizar recursos."
            : "We use the information to manage access, share updates, and tailor resources."}
        </p>
        <h2>{language === "es" ? "Tus derechos" : "Your rights"}</h2>
        <p>
          {language === "es"
            ? "Puedes solicitar acceso, corrección o eliminación en cualquier momento escribiendo a hola@tuprogresohoy.com."
            : "You may request access, correction, or deletion at any time by writing to hola@tuprogresohoy.com."}
        </p>
      </section>
    </>
  );
};

export default Privacy;
```

---

```javascript