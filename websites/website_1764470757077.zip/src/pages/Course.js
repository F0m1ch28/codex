import React from "react";
import { Helmet } from "react-helmet-async";
import SectionTitle from "../components/SectionTitle";
import { modules } from "../data/companyData";
import { LanguageContext } from "../context/LanguageContext";
import { motion } from "framer-motion";
import { fadeInUp } from "../utils/animations";

const Course = () => {
  const { language } = React.useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Course Overview | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore the Tu Progreso Hoy course syllabus, target audiences, and immersive learning features powered by Argentinian data."
        />
      </Helmet>

      <section className="page-hero course">
        <div className="page-hero-inner">
          <h1>{language === "es" ? "Curso inicial de finanzas personales" : "Personal finance starter course"}</h1>
          <p>
            {language === "es"
              ? "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Hecho en Argentina, con foco en tu ritmo."
              : "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Built in Argentina with your rhythm in mind."}
          </p>
        </div>
      </section>

      <section className="course-syllabus">
        <SectionTitle
          eyebrow={language === "es" ? "Guía detallada" : "Detailed guide"}
          title={language === "es" ? "Sílabo y experiencias" : "Syllabus & experiences"}
        />
        <div className="syllabus-grid">
          {modules.map((module) => (
            <article key={module.title} className="syllabus-item">
              <h2>{module.title}</h2>
              <ul>
                {module.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="course-audience">
        <SectionTitle
          eyebrow={language === "es" ? "¿Para quién?" : "Who is it for?"}
          title={language === "es" ? "Audiencias objetivo" : "Target audiences"}
        />
        <div className="audience-cards">
          <motion.article className="audience-card" variants={fadeInUp} initial="hidden" whileInView="visible">
            <h3>{language === "es" ? "Estudiantes y jóvenes profesionales" : "Students & early professionals"}</h3>
            <p>
              {language === "es"
                ? "Transforman el caos inflacionario en hábitos y comparaciones claras."
                : "Turning inflation chaos into habits and clear comparisons."}
            </p>
          </motion.article>
          <motion.article className="audience-card" variants={fadeInUp} initial="hidden" whileInView="visible">
            <h3>{language === "es" ? "Familias y emprendimientos" : "Families & micro businesses"}</h3>
            <p>
              {language === "es"
                ? "Simplifican registros y se anticipan a picos de precios."
                : "Simplifying records and anticipating price spikes."}
            </p>
          </motion.article>
          <motion.article className="audience-card" variants={fadeInUp} initial="hidden" whileInView="visible">
            <h3>{language === "es" ? "Migrantes recientes" : "Recent migrants"}</h3>
            <p>
              {language === "es"
                ? "Conectan divisas, remesas y presupuestos en dólares con empatía."
                : "Connecting currencies, remittances, and USD budgets with empathy."}
            </p>
          </motion.article>
        </div>
      </section>

      <section className="course-cta" id="enroll">
        <SectionTitle
          eyebrow={language === "es" ? "Inscripción" : "Enrollment"}
          title={language === "es" ? "Experimenta la prueba gratuita" : "Experience the free trial"}
          description={
            language === "es"
              ? "Recuerda: el doble opt-in protege tu seguridad y confirma tu interés genuino."
              : "Remember: double opt-in protects your security and confirms genuine interest."
          }
        />
        <a className="cta-button link-sound" href="/#enroll">
          {language === "es" ? "Ir al formulario" : "Go to form"}
        </a>
      </section>
    </>
  );
};

export default Course;
```

---

```javascript