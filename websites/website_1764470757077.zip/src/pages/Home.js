import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";
import ParallaxLayer from "../components/ParallaxLayer";
import SectionTitle from "../components/SectionTitle";
import { motion } from "framer-motion";
import { fadeInUp, scaleOnHover, staggerChildren } from "../utils/animations";
import { modules, promises, testimonials, timeline } from "../data/companyData";
import useScrollAnimation from "../hooks/useScrollAnimation";
import usePrefersReducedMotion from "../hooks/usePrefersReducedMotion";

const ARS_API = "https://api.exchangerate.host/latest?base=ARS&symbols=USD";

const Home = () => {
  const { language } = React.useContext(LanguageContext);
  const [rate, setRate] = useState({ value: null, lastUpdated: null, source: "api" });
  const [historical, setHistorical] = useState([]);
  const [loadingRate, setLoadingRate] = useState(true);
  const [heroCursor, setHeroCursor] = useState({ x: 0, y: 0 });
  const navigate = useNavigate();
  const [formStep, setFormStep] = useState(1);
  const [formData, setFormData] = useState({ firstName: "", email: "", focus: "" });
  const [formMessage, setFormMessage] = useState("");
  const reducedMotion = usePrefersReducedMotion();

  useEffect(() => {
    const fetchRates = async () => {
      try {
        const response = await fetch(ARS_API);
        const data = await response.json();
        if (data && data.rates && data.rates.USD) {
          const value = 1 / data.rates.USD; // ARS -> USD
          setRate({ value, lastUpdated: new Date().toISOString(), source: "api" });
        } else {
          throw new Error("Invalid response");
        }

        const hist = await fetch(
          "https://api.exchangerate.host/timeseries?base=ARS&symbols=USD&start_date=2024-03-01&end_date=2024-03-07"
        );
        const histData = await hist.json();
        if (histData && histData.rates) {
          const transformed = Object.entries(histData.rates).map(([date, value]) => ({
            date,
            rate: 1 / value.USD
          }));
          setHistorical(transformed);
        }
      } catch (error) {
        setRate({ value: 0.0012, lastUpdated: "2024-03-07T12:00:00Z", source: "fallback" });
        setHistorical([
          { date: "2024-03-01", rate: 0.0011 },
          { date: "2024-03-02", rate: 0.00112 },
          { date: "2024-03-03", rate: 0.00115 },
          { date: "2024-03-04", rate: 0.00114 },
          { date: "2024-03-05", rate: 0.00118 },
          { date: "2024-03-06", rate: 0.00119 },
          { date: "2024-03-07", rate: 0.00121 }
        ]);
      } finally {
        setLoadingRate(false);
      }
    };
    fetchRates();
  }, []);

  const chartPath = useMemo(() => {
    if (!historical.length) return "";
    const max = Math.max(...historical.map((point) => point.rate));
    const min = Math.min(...historical.map((point) => point.rate));
    const range = max - min || 0.0001;
    const width = 420;
    const height = 160;

    return historical
      .map((point, index) => {
        const x = (index / (historical.length - 1 || 1)) * width;
        const y = height - ((point.rate - min) / range) * height;
        return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ");
  }, [historical]);

  const handleHeroMouseMove = (event) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width - 0.5) * 40;
    const y = ((event.clientY - rect.top) / rect.height - 0.5) * 40;
    setHeroCursor({ x, y });
  };

  const handleFormChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (formStep === 1) {
      if (!formData.firstName || !formData.email) {
        setFormMessage(language === "es" ? "Completa tu nombre y email." : "Please provide your name and email.");
        return;
      }
      setFormStep(2);
      setFormMessage(
        language === "es"
          ? "Hemos enviado un correo de confirmación. Revisa tu bandeja y confirma."
          : "We just sent a confirmation email. Please check and confirm."
      );
    } else {
      navigate("/thank-you", { state: { email: formData.email, firstName: formData.firstName } });
    }
  };

  return (
    <>
      <Helmet>
        <title>Tu Progreso Hoy | Argentina Inflation Insights & Course</title>
        <meta
          name="description"
          content="Decisiones responsables, objetivos nítidos. Aprende a navegar la inflación argentina con un curso interactivo y datos ARS→USD verificados."
        />
        <link rel="alternate" href="https://tuprogresohoy.com/" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/es" hrefLang="es-AR" />
      </Helmet>

      <section
        className="hero immersive"
        onMouseMove={handleHeroMouseMove}
        aria-label="Hero section with key promises and ARS to USD tracker"
      >
        <ParallaxLayer speed={0.1} className="hero-layer gradient" />
        <ParallaxLayer speed={0.2} className="hero-layer particles">
          {Array.from({ length: 22 }).map((_, index) => (
            <span
              key={index}
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 8}s`
              }}
            />
          ))}
        </ParallaxLayer>
        <ParallaxLayer speed={0.05} className="hero-layer flag-overlay">
          <div className="flag-overlay-inner" />
        </ParallaxLayer>
        <div className="hero-video">
          <video
            aria-hidden="true"
            className="hero-video-element"
            autoPlay
            loop
            muted
            playsInline
            poster="/media/hero-placeholder.jpg"
          >
            <source src="/media/argentina-market-loop.mp4" type="video/mp4" />
          </video>
        </div>

        <div
          className="hero-content"
          style={{
            transform: `translate3d(${heroCursor.x}px, ${heroCursor.y}px, 0)`
          }}
        >
          <p className="hero-eyebrow">
            {language === "es" ? "Señales financieras para Argentina" : "Financial signals for Argentina"}
          </p>
          <h1>
            {language === "es"
              ? "Tu ruta educativa para leer la inflación y actuar con claridad."
              : "Your educational path to read inflation and act with clarity."}
          </h1>
          <p className="hero-subtitle">
            {language === "es"
              ? "Datos verificados para planificar tu presupuesto. Desde 2018, Tu Progreso Hoy convierte tendencias macroeconómicas en aprendizajes prácticos."
              : "Datos verificados para planificar tu presupuesto. Since 2018, Tu Progreso Hoy turns macro trends into everyday learning."}
          </p>

          <div className="hero-meta">
            <div className="meta-card">
              <span className="meta-label">ARS → USD</span>
              <strong className="meta-value">
                {loadingRate
                  ? language === "es"
                    ? "Actualizando…"
                    : "Updating…"
                  : rate.value
                  ? `${rate.value.toFixed(4)}`
                  : "0.0012"}
              </strong>
              <small>
                {language === "es" ? "Última actualización:" : "Last updated:"}{" "}
                {rate.lastUpdated ? new Date(rate.lastUpdated).toLocaleString(language === "es" ? "es-AR" : "en-US") : "—"}{" "}
                ({rate.source})
              </small>
            </div>

            <div className="meta-card">
              <span className="meta-label">
                {language === "es" ? "Próximo taller" : "Upcoming live lab"}
              </span>
              <strong className="meta-value">21 MAR · 19:00 ART</strong>
              <small>
                {language === "es"
                  ? "Escenarios de inflación y decisiones responsables."
                  : "Inflation scenarios & responsible choices."}
              </small>
            </div>

            <div className="meta-card">
              <span className="meta-label">
                {language === "es" ? "Ruta de aprendizaje" : "Learning route"}
              </span>
              <strong className="meta-value">4 Weeks</strong>
              <small>
                {language === "es"
                  ? "Progreso acompañado con badges y comunidad."
                  : "Guided progress with badges & community."}
              </small>
            </div>
          </div>

          <div className="hero-actions">
            <a className="cta-button link-sound" href="#enroll">
              {language === "es" ? "Reserva tu prueba gratuita" : "Book your free trial"}
            </a>
            <a className="secondary-link" href="#inflation-lab">
              {language === "es" ? "Ver laboratorio de inflación" : "Explore inflation lab"}
            </a>
          </div>
        </div>
      </section>

      <section className="promise-section">
        <SectionTitle
          eyebrow={language === "es" ? "Promesas que cumplimos" : "Promises we uphold"}
          title={language === "es" ? "Claves que guían cada decisión" : "Guiding commitments for every decision"}
          description={
            language === "es"
              ? "Conocimiento financiero impulsado por tendencias y contexto argentino. Comunidad, claridad y responsabilidad."
              : "Conocimiento financiero impulsado por tendencias, rooted in Argentinian reality."
          }
        />
        <motion.div
          className="promise-grid"
          variants={staggerChildren}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {promises.map((card, index) => (
            <motion.article key={card.title} className="promise-card interactive-card" variants={fadeInUp}>
              <h3>{card.title}</h3>
              <p>{card.detail}</p>
              <span className="promise-index">{index + 1}</span>
            </motion.article>
          ))}
        </motion.div>
      </section>

      <section className="ars-dashboard" id="inflation-lab">
        <SectionTitle
          eyebrow={language === "es" ? "Observatorio ARS→USD" : "ARS→USD Observatory"}
          title={language === "es" ? "Panel vivo y narrativa de la brecha" : "Live panel and story of the gap"}
          description={
            language === "es"
              ? "Observamos tasas oficiales, perspectivas alternativas y micro decisiones. Plataforma educativa con datos esenciales, sin asesoría financiera directa."
              : "We monitor official rates, alternative perspectives, and everyday decisions. Plataforma educativa con datos esenciales, sin asesoría financiera directa."
          }
        />
        <div className="dashboard-content">
          <div className="chart-card" role="img" aria-label="Historical ARS to USD trends">
            <svg width="420" height="160" viewBox="0 0 420 160">
              <defs>
                <linearGradient id="lineGradient" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#1F3A6F" stopOpacity="0.2" />
                </linearGradient>
              </defs>
              <path d={chartPath || "M0,80 L420,80"} fill="none" stroke="url(#lineGradient)" strokeWidth="4" strokeLinecap="round" />
            </svg>
            <ul className="chart-legend">
              {historical.map((point) => (
                <li key={point.date}>
                  <span>{new Date(point.date).toLocaleDateString(language === "es" ? "es-AR" : "en-US")}</span>
                  <strong>{point.rate.toFixed(4)}</strong>
                </li>
              ))}
            </ul>
          </div>

          <div className="story-card">
            <h3>{language === "es" ? "Narrativa semanal" : "Weekly narrative"}</h3>
            <p>
              {language === "es"
                ? "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Miramos el IPC, el crawling peg y la dinámica blue para convertir señales en aprendizaje."
                : "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. We track CPI, crawling peg, and the informal market to turn signals into learning."}
            </p>
            <ul>
              <li>
                {language === "es"
                  ? "Indicadores: inflación núcleo, variación mensual, spread oficial-blue."
                  : "Indicators: core inflation, monthly variation, official-blue spread."}
              </li>
              <li>
                {language === "es"
                  ? "Contexto: consumo en supermercados vs. servicios en dólares."
                  : "Context: supermarket spending vs. USD-denominated services."}
              </li>
              <li>
                {language === "es"
                  ? "Acción sugerida: micro-hábito semanal con medición de impacto."
                  : "Action idea: single weekly habit with tracked impact."}
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className="timeline-section">
        <SectionTitle
          eyebrow={language === "es" ? "Nuestra historia" : "Our story"}
          title={language === "es" ? "Pasado, presente y proyección" : "Past, present, projection"}
          description={
            language === "es"
              ? "Anclamos decisiones en comunidad. Decisiones responsables, objetivos nítidos."
              : "Community-first decisions. Decisiones responsables, objetivos nítidos."
          }
        />
        <div className="timeline">
          {timeline.map((item, index) => (
            <motion.article
              key={item.year}
              className="timeline-entry"
              variants={fadeInUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: index * 0.08 }}
            >
              <span className="timeline-year">{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="course-preview" id="course-preview">
        <SectionTitle
          eyebrow={language === "es" ? "De la información al aprendizaje" : "From information to learning"}
          title={language === "es" ? "Recorrido del curso introductorio" : "Introductory course journey"}
          description={
            language === "es"
              ? "De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
              : "De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
          }
        />
        <div className="module-grid">
          {modules.map((module, index) => (
            <motion.div
              key={module.title}
              className="module-card interactive-card"
              initial="rest"
              whileHover="hover"
              animate="rest"
              variants={scaleOnHover}
            >
              <header>
                <span className="module-index">0{index + 1}</span>
                <h3>{module.title}</h3>
              </header>
              <ul>
                {module.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="gamified-section">
        <SectionTitle
          eyebrow={language === "es" ? "Gamificación responsable" : "Responsible gamification"}
          title={language === "es" ? "Seguimiento, logros y acompañamiento" : "Tracking, achievements, and support"}
        />
        <div className="gamified-content">
          <article className="badge-card">
            <h3>{language === "es" ? "Badges de progreso" : "Progress badges"}</h3>
            <p>
              {language === "es"
                ? "Cada módulo libera un badge con audio sutil y refuerzo positivo. Pasos acertados hoy, mejor futuro mañana."
                : "Each module unlocks a badge with subtle audio and positive reinforcement. Pasos acertados hoy, mejor futuro mañana."}
            </p>
            <div className="badges">
              <span className="badge">Inflation Decoder</span>
              <span className="badge">Budget Navigator</span>
              <span className="badge">Trend Tracker</span>
            </div>
          </article>
          <article className="progress-card">
            <h3>{language === "es" ? "Tu progreso" : "Your progress"}</h3>
            <div className="progress-meter">
              <div className="progress-track">
                <div className="progress-fill" style={{ width: "62%" }} />
              </div>
              <span>62% {language === "es" ? "de la cohorte confirma el paso 2 del opt-in" : "of cohort confirmed opt-in step 2"}</span>
            </div>
            <p>
              {language === "es"
                ? "Elige tu ritmo. Recordatorios adaptativos y sesiones en vivo para profundizar."
                : "Move at your pace. Adaptive reminders and live sessions to go deeper."}
            </p>
          </article>
          <article className="community-card">
            <h3>{language === "es" ? "Acompañamiento en comunidad" : "Community companionship"}</h3>
            <p>
              {language === "es"
                ? "Mentores locales, chats moderados y espacios bilingües. Conocimiento financiero impulsado por tendencias y experiencias reales."
                : "Local mentors, moderated chats, bilingual spaces. Conocimiento financiero impulsado por tendencias and real experiences."}
            </p>
            <ul className="community-stats">
              <li>
                <strong>14</strong>
                <span>{language === "es" ? "mentores" : "mentors"}</span>
              </li>
              <li>
                <strong>36</strong>
                <span>{language === "es" ? "laboratorios al año" : "labs per year"}</span>
              </li>
              <li>
                <strong>2k+</strong>
                <span>{language === "es" ? "participantes" : "participants"}</span>
              </li>
            </ul>
          </article>
        </div>
      </section>

      <section className="testimonials">
        <SectionTitle
          eyebrow={language === "es" ? "Testimonios" : "Testimonials"}
          title={language === "es" ? "Historias reales" : "Real stories"}
        />
        <div className="testimonial-grid">
          {testimonials.map((testimonial) => (
            <blockquote key={testimonial.author} className="testimonial-card">
              <p>{testimonial.quote}</p>
              <footer>{testimonial.author}</footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className="call-to-action" id="enroll">
        <SectionTitle
          eyebrow={language === "es" ? "Inscripción doble opt-in" : "Double opt-in registration"}
          title={language === "es" ? "Activa tu prueba gratuita" : "Activate your free trial"}
          description={
            language === "es"
              ? "Completa tus datos para recibir el email de confirmación. Solo accederás al aula cuando confirmes desde tu bandeja."
              : "Fill in your details to receive the confirmation email. Access unlocks after you confirm from your inbox."
          }
        />
        <form className="cta-form" onSubmit={handleFormSubmit}>
          <div className="form-steps">
            <span className={formStep >= 1 ? "active" : ""}>1</span>
            <span className={formStep >= 2 ? "active" : ""}>2</span>
          </div>
          <div className="form-grid">
            <label>
              {language === "es" ? "Nombre" : "First name"}
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleFormChange}
                autoComplete="given-name"
                required
              />
            </label>
            <label>
              Email
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleFormChange}
                autoComplete="email"
                required
              />
            </label>
            <label>
              {language === "es" ? "¿Qué te interesa explorar?" : "What would you like to explore?"}
              <select name="focus" value={formData.focus} onChange={handleFormChange}>
                <option value="">{language === "es" ? "Selecciona una opción" : "Select an option"}</option>
                <option value="inflation-lab">{language === "es" ? "Laboratorio de inflación" : "Inflation lab"}</option>
                <option value="budgeting">{language === "es" ? "Presupuestos" : "Budgeting"}</option>
                <option value="fx">{language === "es" ? "Seguimiento ARS→USD" : "ARS→USD tracking"}</option>
              </select>
            </label>
          </div>
          <p className="form-message" role="status">
            {formMessage}
          </p>
          <button className="btn-primary" type="submit">
            {formStep === 1
              ? "Получить бесплатный пробный урок"
              : language === "es"
              ? "Confirmar y avanzar"
              : "Confirm and continue"}
          </button>
          <p className="form-footnote">
            {language === "es"
              ? "Revisaremos tu registro en menos de 12 horas. Recibirás dos correos: confirmación y acceso."
              : "We review your registration within 12 hours. You’ll receive two emails: confirmation and access."}
          </p>
        </form>
      </section>
    </>
  );
};

export default Home;
```

---

```javascript