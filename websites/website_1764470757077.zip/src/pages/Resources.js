import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import SectionTitle from "../components/SectionTitle";
import { articles } from "../data/companyData";
import { LanguageContext } from "../context/LanguageContext";
import { motion } from "framer-motion";
import { fadeInUp } from "../utils/animations";

const Resources = () => {
  const { language } = React.useContext(LanguageContext);
  const [filter, setFilter] = useState("all");

  const categories = useMemo(() => {
    const base = new Set(["all"]);
    articles.forEach((article) => base.add(article.category));
    return Array.from(base);
  }, []);

  const filtered = useMemo(() => {
    return articles.filter((article) => {
      if (filter === "all") return true;
      return article.category === filter;
    });
  }, [filter]);

  return (
    <>
      <Helmet>
        <title>Resources | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Glossaries, articles, and bilingual resources to understand Argentine inflation and personal finance."
        />
      </Helmet>

      <section className="page-hero">
        <div className="page-hero-inner">
          <h1>{language === "es" ? "Recursos" : "Resources"}</h1>
          <p>
            {language === "es"
              ? "Conocimiento financiero impulsado por tendencias. Explora artículos, glosarios y guías bilingües."
              : "Conocimiento financiero impulsado por tendencias. Explore bilingual articles, glossaries, and guides."}
          </p>
        </div>
      </section>

      <section className="resource-filter">
        <SectionTitle
          eyebrow={language === "es" ? "Explora" : "Explore"}
          title={language === "es" ? "Contenido curado" : "Curated content"}
        />
        <div className="filter-controls" role="radiogroup" aria-label="Resource filter">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={filter === category ? "filter-option active" : "filter-option"}
              onClick={() => setFilter(category)}
              role="radio"
              aria-checked={filter === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="resource-list">
          {filtered.map((article) => (
            <motion.article
              key={article.id}
              className="resource-card interactive-card"
              variants={fadeInUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
            >
              <header>
                <span className="resource-category">{article.category}</span>
                <span className="resource-lang">{article.lang === "es" ? "ES" : "EN"}</span>
              </header>
              <h2>{article.title}</h2>
              <p>{article.excerpt}</p>
              <footer>
                <span>{language === "es" ? "Tiempo de lectura" : "Reading time"}: {article.readTime}</span>
                <a href={`https://tuprogresohoy.com/resources/${article.id}`} className="secondary-link link-sound">
                  {language === "es" ? "Leer" : "Read"}
                </a>
              </footer>
            </motion.article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Resources;
```

---

```javascript