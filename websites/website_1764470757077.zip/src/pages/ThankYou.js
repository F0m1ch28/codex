import React from "react";
import { Helmet } from "react-helmet-async";
import SectionTitle from "../components/SectionTitle";
import { useLocation, Link } from "react-router-dom";
import { LanguageContext } from "../context/LanguageContext";

const ThankYou = () => {
  const { language } = React.useContext(LanguageContext);
  const location = useLocation();
  const state = location.state || {};
  const name = state.firstName || "";

  return (
    <>
      <Helmet>
        <title>Thank you | Tu Progreso Hoy</title>
      </Helmet>
      <section className="page-hero">
        <div className="page-hero-inner">
          <h1>
            {language === "es" ? `¡Gracias${name ? `, ${name}` : ""}!` : `Thank you${name ? `, ${name}` : ""}!`}
          </h1>
          <p>
            {language === "es"
              ? "Revisa tu correo para confirmar tu registro. El acceso llega después de tu confirmación."
              : "Check your inbox to confirm your registration. Access arrives after confirmation."}
          </p>
        </div>
      </section>
      <section className="thankyou-steps">
        <SectionTitle
          eyebrow={language === "es" ? "¿Qué sigue?" : "What’s next?"}
          title={language === "es" ? "Completa tu doble opt-in" : "Complete your double opt-in"}
        />
        <ol className="thankyou-list">
          <li>
            {language === "es"
              ? "Abre el correo con asunto “Confirma tu ruta Tu Progreso Hoy”."
              : "Open the email with subject “Confirm your Tu Progreso Hoy route.”"}
          </li>
          <li>
            {language === "es"
              ? "Haz clic en “Confirmar mi interés”."
              : "Click “Confirm my interest.”"}
          </li>
          <li>
            {language === "es"
              ? "Recibirás un segundo correo con acceso al aula y calendario."
              : "Receive a second email with classroom access and calendar."}
          </li>
        </ol>
        <Link className="secondary-link" to="/">
          {language === "es" ? "Volver al inicio" : "Return home"}
        </Link>
      </section>
    </>
  );
};

export default ThankYou;
```

---

```javascript