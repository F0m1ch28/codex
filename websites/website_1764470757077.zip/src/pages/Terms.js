import React from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const Terms = () => {
  const { language } = React.useContext(LanguageContext);
  return (
    <>
      <Helmet>
        <title>Terms of Use | Tu Progreso Hoy</title>
      </Helmet>
      <section className="legal-page">
        <h1>{language === "es" ? "Términos y condiciones" : "Terms & Conditions"}</h1>
        <p>
          {language === "es"
            ? "Al acceder a Tu Progreso Hoy aceptas emplear los contenidos con fines educativos y sin garantía de resultados financieros."
            : "By accessing Tu Progreso Hoy you agree to use the content for educational purposes without any guarantee of financial outcomes."}
        </p>
        <h2>{language === "es" ? "Responsabilidad" : "Responsibility"}</h2>
        <p>
          {language === "es"
            ? "No proporcionamos asesoría financiera. Las decisiones pertenecen al usuario."
            : "We do not provide financial advice. Decisions belong to the user."}
        </p>
        <h2>{language === "es" ? "Cancelaciones" : "Cancellations"}</h2>
        <p>
          {language === "es"
            ? "Puedes cancelar el acceso en cualquier momento; conservamos registros mínimos para requerimientos legales."
            : "You may cancel access at any time; we retain minimal records to satisfy legal requirements."}
        </p>
      </section>
    </>
  );
};

export default Terms;
```

---

```css