import React from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const Cookies = () => {
  const { language } = React.useContext(LanguageContext);
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Tu Progreso Hoy</title>
      </Helmet>
      <section className="legal-page">
        <h1>{language === "es" ? "Política de cookies" : "Cookie Policy"}</h1>
        <p>
          {language === "es"
            ? "Usamos cookies para recordar tu idioma, medir analíticas y habilitar experiencias enriquecidas."
            : "We use cookies to remember your language, measure analytics, and enable enriched experiences."}
        </p>
        <h2>{language === "es" ? "Categorías" : "Categories"}</h2>
        <ul>
          <li>{language === "es" ? "Esenciales: funcionamiento del sitio." : "Essential: Site functionality."}</li>
          <li>{language === "es" ? "Analíticas: patrones de aprendizaje." : "Analytics: Learning patterns."}</li>
          <li>{language === "es" ? "Experiencia: animaciones, sonido." : "Experience: animations, sound."}</li>
        </ul>
        <p>
          {language === "es"
            ? "Puedes ajustar tus preferencias desde el banner o escribiendo a hola@tuprogresohoy.com."
            : "You can adjust preferences from the banner or by emailing hola@tuprogresohoy.com."}
        </p>
      </section>
    </>
  );
};

export default Cookies;
```

---

```javascript