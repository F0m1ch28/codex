import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import SectionTitle from "../components/SectionTitle";
import { LanguageContext } from "../context/LanguageContext";

const Contact = () => {
  const { language } = React.useContext(LanguageContext);
  const [step, setStep] = useState(1);
  const [details, setDetails] = useState({
    name: "",
    email: "",
    topic: "",
    message: ""
  });
  const [submitted, setSubmitted] = useState(false);

  const handleNext = (event) => {
    event.preventDefault();
    if (step === 1 && details.name && details.email) {
      setStep(2);
    } else if (step === 2 && details.topic) {
      setStep(3);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (details.message) {
      setSubmitted(true);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setDetails((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <Helmet>
        <title>Contact | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Reach the Tu Progreso Hoy team in Buenos Aires. Maps, multi-channel contact form, and community socials."
        />
      </Helmet>

      <section className="page-hero">
        <div className="page-hero-inner">
          <h1>{language === "es" ? "Contacto" : "Contact"}</h1>
          <p>
            {language === "es"
              ? "Estamos en Buenos Aires, listos para acompañarte. Pasos acertados hoy, mejor futuro mañana."
              : "Based in Buenos Aires, ready to support you. Pasos acertados hoy, mejor futuro mañana."}
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="contact-grid">
          <div className="contact-details">
            <SectionTitle
              eyebrow={language === "es" ? "Visítanos" : "Visit us"}
              title="Buenos Aires Lab"
              description="Av. 9 de Julio 1000, C1043"
            />
            <iframe
              title="Tu Progreso Hoy Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.082938881327!2d-58.38159368415941!3d-34.603684480458995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccac9e4b8d8c3%3A0xf7f6dc87f7c9a9c1!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1ses!2sar!4v1709851224812"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
            <dl>
              <div>
                <dt>{language === "es" ? "Teléfono" : "Phone"}</dt>
                <dd>
                  <a href="tel:+541155551234">+54 11 5555-1234</a>
                </dd>
              </div>
              <div>
                <dt>Email</dt>
                <dd>
                  <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
                </dd>
              </div>
              <div>
                <dt>{language === "es" ? "Redes" : "Social"}</dt>
                <dd>
                  <a href="https://www.linkedin.com/company/tu-progreso-hoy" className="secondary-link">
                    LinkedIn
                  </a>{" "}
                  ·{" "}
                  <a href="https://www.instagram.com/tu.progreso.hoy" className="secondary-link">
                    Instagram
                  </a>
                </dd>
              </div>
            </dl>
            <div className="contact-proof">
              <h3>{language === "es" ? "Confianza en vivo" : "Live trust"}</h3>
              <ul>
                <li>{language === "es" ? "Respuestas en menos de 12h (hábiles)." : "Responses within 12h (business)."}</li>
                <li>{language === "es" ? "Canales bilingües disponibles." : "Bilingual channels available."}</li>
                <li>{language === "es" ? "Chat en vivo pronto." : "Live chat coming soon."}</li>
              </ul>
            </div>
          </div>

          <div className="contact-form-wrapper">
            <SectionTitle
              eyebrow={language === "es" ? "Conversemos" : "Let's talk"}
              title={language === "es" ? "Formulario en tres pasos" : "Three-step form"}
            />
            {!submitted ? (
              <form className="multistep-form" onSubmit={step === 3 ? handleSubmit : handleNext}>
                {step === 1 && (
                  <fieldset>
                    <legend>{language === "es" ? "Tus datos" : "Your details"}</legend>
                    <label>
                      {language === "es" ? "Nombre" : "Name"}
                      <input
                        type="text"
                        name="name"
                        value={details.name}
                        onChange={handleChange}
                        required
                        autoComplete="name"
                      />
                    </label>
                    <label>
                      Email
                      <input
                        type="email"
                        name="email"
                        value={details.email}
                        onChange={handleChange}
                        required
                        autoComplete="email"
                      />
                    </label>
                  </fieldset>
                )}

                {step === 2 && (
                  <fieldset>
                    <legend>{language === "es" ? "Tema" : "Topic"}</legend>
                    <label>
                      {language === "es" ? "Selecciona una opción" : "Select a topic"}
                      <select name="topic" value={details.topic} onChange={handleChange} required>
                        <option value="">{language === "es" ? "Selecciona" : "Choose"}</option>
                        <option value="course">{language === "es" ? "Curso" : "Course"}</option>
                        <option value="inflation">{language === "es" ? "Datos de inflación" : "Inflation data"}</option>
                        <option value="media">{language === "es" ? "Prensa" : "Media"}</option>
                      </select>
                    </label>
                  </fieldset>
                )}

                {step === 3 && (
                  <fieldset>
                    <legend>{language === "es" ? "Mensaje" : "Message"}</legend>
                    <label>
                      {language === "es" ? "Cuéntanos más" : "Tell us more"}
                      <textarea
                        name="message"
                        rows="6"
                        value={details.message}
                        onChange={handleChange}
                        required
                      />
                    </label>
                    <p>
                      {language === "es"
                        ? "Recibirás un correo de confirmación para completar el doble opt-in."
                        : "You'll receive a confirmation email to complete the double opt-in."}
                    </p>
                  </fieldset>
                )}

                <div className="form-navigation">
                  {step > 1 && (
                    <button type="button" className="btn-secondary" onClick={() => setStep((prev) => prev - 1)}>
                      {language === "es" ? "Atrás" : "Back"}
                    </button>
                  )}
                  <button className="btn-primary" type="submit">
                    {step === 3 ? (language === "es" ? "Enviar" : "Submit") : language === "es" ? "Siguiente" : "Next"}
                  </button>
                </div>
              </form>
            ) : (
              <div className="form-success">
                <h2>{language === "es" ? "¡Gracias!" : "Thank you!"}</h2>
                <p>
                  {language === "es"
                    ? "Acabamos de enviarte un correo para confirmar tu mensaje. Confirma para que podamos responder."
                    : "We just sent you an email to confirm your message. Please confirm so we can respond."}
                </p>
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
```

---

```javascript