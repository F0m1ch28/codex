import React, { Suspense, lazy, useEffect, useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import PopupDisclaimer from "./components/PopupDisclaimer";
import ScrollToTop from "./components/ScrollToTop";
import { LanguageContext } from "./context/LanguageContext";
import AudioFeedback from "./components/AudioFeedback";
import { AnimatePresence, motion } from "framer-motion";

const Home = lazy(() => import("./pages/Home"));
const Inflation = lazy(() => import("./pages/Inflation"));
const Course = lazy(() => import("./pages/Course"));
const Resources = lazy(() => import("./pages/Resources"));
const Contact = lazy(() => import("./pages/Contact"));
const ThankYou = lazy(() => import("./pages/ThankYou"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Cookies = lazy(() => import("./pages/Cookies"));
const Terms = lazy(() => import("./pages/Terms"));

const pageVariants = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -16 }
};

function App() {
  const location = useLocation();
  const { language } = React.useContext(LanguageContext);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);
    const handler = (event) => setReducedMotion(event.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  return (
    <>
      <AudioFeedback />
      <Header />
      <PopupDisclaimer />
      <main id="main-content" className={`app-shell ${language === "es" ? "lang-es" : "lang-en"}`}>
        <ScrollToTop />
        <Suspense fallback={<div className="loading-state" role="status">Loading Tu Progreso Hoy…</div>}>
          <AnimatePresence mode="wait" initial={false}>
            <RouteWrapper location={location} reducedMotion={reducedMotion}>
              <Routes location={location} key={location.pathname}>
                <Route path="/" element={<Home />} />
                <Route path="/inflation" element={<Inflation />} />
                <Route path="/course" element={<Course />} />
                <Route path="/resources" element={<Resources />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/thank-you" element={<ThankYou />} />
                <Route path="/privacy" element={<Privacy />} />
                <Route path="/cookies" element={<Cookies />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="*" element={<Home />} />
              </Routes>
            </RouteWrapper>
          </AnimatePresence>
        </Suspense>
      </main>
      <Footer />
      <CookieBanner />
    </>
  );
}

const RouteWrapper = ({ children, location, reducedMotion }) => {
  if (reducedMotion) {
    return <div key={location.pathname}>{children}</div>;
  }
  return (
    <motion.div
      key={location.pathname}
      initial="initial"
      animate="animate"
      exit="exit"
      variants={pageVariants}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
};

export default App;
```

---

```javascript