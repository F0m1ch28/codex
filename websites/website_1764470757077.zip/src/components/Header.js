import React from "react";
import { NavLink } from "react-router-dom";
import { LanguageContext } from "../context/LanguageContext";
import usePrefersReducedMotion from "../hooks/usePrefersReducedMotion";
import { motion } from "framer-motion";

const navItems = [
  { path: "/", labelEn: "Home", labelEs: "Inicio" },
  { path: "/inflation", labelEn: "Inflation", labelEs: "Inflación" },
  { path: "/course", labelEn: "Course", labelEs: "Curso" },
  { path: "/resources", labelEn: "Resources", labelEs: "Recursos" },
  { path: "/contact", labelEn: "Contact", labelEs: "Contacto" }
];

const Header = () => {
  const { language, toggleLanguage } = React.useContext(LanguageContext);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const reducedMotion = usePrefersReducedMotion();

  const navAnimation = reducedMotion
    ? {}
    : {
        initial: { y: -24, opacity: 0 },
        animate: { y: 0, opacity: 1 },
        transition: { duration: 0.8, ease: "easeOut" }
      };

  return (
    <header className="tph-header">
      <motion.div className="header-inner" {...navAnimation}>
        <div className="brand">
          <a href="/" aria-label="Tu Progreso Hoy">
            <span className="brand-logo" aria-hidden="true">
              TPH
            </span>
            <div className="brand-text">
              <strong>Tu Progreso Hoy</strong>
              <span>Argentina Financial Learning Platform</span>
            </div>
          </a>
        </div>
        <button
          className="mobile-menu-toggle"
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className="sr-only">Toggle navigation</span>
          <div className={menuOpen ? "bar open" : "bar"} />
        </button>
        <nav className={`primary-navigation ${menuOpen ? "open" : ""}`} id="primary-navigation">
          <ul>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) => (isActive ? "active" : "")}
                  onClick={() => setMenuOpen(false)}
                >
                  {language === "es" ? item.labelEs : item.labelEn}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className="header-actions">
            <button onClick={toggleLanguage} className="language-toggle" type="button">
              {language === "es" ? "ES / EN" : "EN / ES"}
            </button>
            <a className="cta-button" href="/course#enroll">
              {language === "es" ? "Explorar Curso" : "Explore Course"}
            </a>
          </div>
        </nav>
      </motion.div>
    </header>
  );
};

export default Header;
```

---

```javascript