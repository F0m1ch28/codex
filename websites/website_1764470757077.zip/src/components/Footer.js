import React from "react";
import { Link } from "react-router-dom";
import { LanguageContext } from "../context/LanguageContext";

const Footer = () => {
  const { language } = React.useContext(LanguageContext);
  return (
    <footer className="tph-footer">
      <div className="footer-gradient" aria-hidden="true" />
      <div className="footer-inner">
        <section className="footer-brand">
          <h2>Tu Progreso Hoy</h2>
          <p>
            {language === "es"
              ? "Plataforma educativa con datos esenciales, sin asesoría financiera directa."
              : "Educational platform delivering essential data without direct financial advice."}
          </p>
          <div className="footer-contact">
            <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
            <a href="tel:+541155551234">+54 11 5555-1234</a>
            <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          </div>
        </section>

        <section className="footer-links">
          <h3>{language === "es" ? "Navegación" : "Navigation"}</h3>
          <ul>
            <li>
              <Link to="/">{language === "es" ? "Inicio" : "Home"}</Link>
            </li>
            <li>
              <Link to="/inflation">{language === "es" ? "Inflación" : "Inflation"}</Link>
            </li>
            <li>
              <Link to="/course">{language === "es" ? "Curso" : "Course"}</Link>
            </li>
            <li>
              <Link to="/resources">{language === "es" ? "Recursos" : "Resources"}</Link>
            </li>
            <li>
              <Link to="/contact">{language === "es" ? "Contacto" : "Contact"}</Link>
            </li>
          </ul>
        </section>

        <section className="footer-legal">
          <h3>{language === "es" ? "Legal" : "Legal"}</h3>
          <ul>
            <li>
              <Link to="/privacy">{language === "es" ? "Privacidad" : "Privacy"}</Link>
            </li>
            <li>
              <Link to="/cookies">{language === "es" ? "Cookies" : "Cookies"}</Link>
            </li>
            <li>
              <Link to="/terms">{language === "es" ? "Términos" : "Terms"}</Link>
            </li>
          </ul>
          <p className="footer-disclaimer">
            {language === "es"
              ? "Información confiable que respalda elecciones responsables sobre tu dinero."
              : "Reliable information to support responsible decisions about your money."}
          </p>
          <p className="footer-disclaimer">
            {language === "es"
              ? "Мы не предоставляем финансовые услуги"
              : "Мы не предоставляем финансовые услуги"}
          </p>
        </section>

        <section className="footer-social">
          <h3>{language === "es" ? "Conecta" : "Connect"}</h3>
          <ul>
            <li>
              <a href="https://www.linkedin.com/company/tu-progreso-hoy" target="_blank" rel="noreferrer">
                LinkedIn
              </a>
            </li>
            <li>
              <a href="https://www.instagram.com/tu.progreso.hoy" target="_blank" rel="noreferrer">
                Instagram
              </a>
            </li>
            <li>
              <a href="https://x.com/tuprogresohoy" target="_blank" rel="noreferrer">
                X / Twitter
              </a>
            </li>
          </ul>
          <div className="footer-badges">
            <span className="badge">ISO 27001 Ready</span>
            <span className="badge">WCAG AA Mindful</span>
          </div>
        </section>
      </div>
      <div className="footer-bottom">
        <small>© {new Date().getFullYear()} Tu Progreso Hoy — {language === "es" ? "Datos verificados para planificar tu presupuesto." : "Datos verificados para planificar tu presupuesto."}</small>
      </div>
    </footer>
  );
};

export default Footer;
```

---

```javascript