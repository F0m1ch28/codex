import React, { useEffect } from "react";

const AudioFeedback = () => {
  useEffect(() => {
    const handleClick = (event) => {
      if (!(event.target instanceof HTMLElement)) return;
      if (event.target.closest(".cta-button, .btn-primary, .interactive-card, .link-sound")) {
        const context = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = context.createOscillator();
        const gainNode = context.createGain();
        oscillator.type = "sine";
        oscillator.frequency.setValueAtTime(440, context.currentTime);
        gainNode.gain.setValueAtTime(0.0001, context.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.08, context.currentTime + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.15);
        oscillator.connect(gainNode);
        gainNode.connect(context.destination);
        oscillator.start();
        oscillator.stop(context.currentTime + 0.16);
      }
    };

    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, []);
  return null;
};

export default AudioFeedback;
```

---

```javascript