import React, { useEffect, useState } from "react";
import clsx from "clsx";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [preferences, setPreferences] = useState({
    analytics: false,
    experience: false
  });

  useEffect(() => {
    const stored = window.localStorage.getItem("tph-cookie-preferences");
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleSave = () => {
    window.localStorage.setItem("tph-cookie-preferences", JSON.stringify(preferences));
    setVisible(false);
  };

  const handleAcceptAll = () => {
    const all = { analytics: true, experience: true };
    setPreferences(all);
    window.localStorage.setItem("tph-cookie-preferences", JSON.stringify(all));
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <aside className={clsx("cookie-banner")} aria-live="assertive">
      <h2>Cookie Preferences</h2>
      <p>
        We use cookies to enhance learning experiences, understand session analytics, and remember language choices.
        You can adjust consent anytime.
      </p>
      <form>
        <label>
          <input
            type="checkbox"
            checked={preferences.analytics}
            onChange={(e) => setPreferences((prev) => ({ ...prev, analytics: e.target.checked }))}
          />
          Analytics & usage insights
        </label>
        <label>
          <input
            type="checkbox"
            checked={preferences.experience}
            onChange={(e) => setPreferences((prev) => ({ ...prev, experience: e.target.checked }))}
          />
          Enhanced experience (animations, sound cues)
        </label>
      </form>
      <div className="banner-actions">
        <button type="button" className="btn-secondary" onClick={handleSave}>
          Save selections
        </button>
        <button type="button" className="btn-primary" onClick={handleAcceptAll}>
          Accept all
        </button>
      </div>
    </aside>
  );
};

export default CookieBanner;
```

---

```javascript