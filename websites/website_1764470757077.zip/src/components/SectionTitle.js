import React from "react";
import { motion } from "framer-motion";
import usePrefersReducedMotion from "../hooks/usePrefersReducedMotion";

const SectionTitle = ({ eyebrow, title, description }) => {
  const reducedMotion = usePrefersReducedMotion();
  const animationProps = reducedMotion
    ? {}
    : {
        initial: { y: 20, opacity: 0 },
        whileInView: { y: 0, opacity: 1 },
        viewport: { once: true, amount: 0.4 },
        transition: { duration: 0.6, ease: "easeOut" }
      };
  return (
    <motion.header className="section-title" {...animationProps}>
      {eyebrow && <p className="section-eyebrow">{eyebrow}</p>}
      <h2>{title}</h2>
      {description && <p className="section-description">{description}</p>}
    </motion.header>
  );
};

export default SectionTitle;
```

---

```javascript