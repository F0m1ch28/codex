import React, { useEffect, useState } from "react";

const PopupDisclaimer = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const seen = window.localStorage.getItem("tph-disclaimer");
    if (!seen) {
      const timeout = setTimeout(() => setOpen(true), 1800);
      return () => clearTimeout(timeout);
    }
  }, []);

  const handleClose = () => {
    setOpen(false);
    window.localStorage.setItem("tph-disclaimer", "true");
  };

  if (!open) return null;

  return (
    <div className="disclaimer-overlay" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="disclaimer-content">
        <h2 id="disclaimer-title">Мы не предоставляем финансовые услуги</h2>
        <p>
          Tu Progreso Hoy is an educational environment. Información confiable que respalda elecciones responsables sobre tu dinero.
          We focus on learning, self-assessment, and data literacy rather than any investment service.
        </p>
        <button className="btn-primary" type="button" onClick={handleClose}>
          Entendido / Understood
        </button>
      </div>
    </div>
  );
};

export default PopupDisclaimer;
```

---

```javascript