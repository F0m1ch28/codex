import React, { useEffect, useRef } from "react";

const ParallaxLayer = ({ speed = 0.2, className = "", children }) => {
  const ref = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.pageYOffset;
      if (ref.current) {
        ref.current.style.transform = `translate3d(0, ${offset * speed}px, 0)`;
      }
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [speed]);

  return (
    <div className={`parallax-layer ${className}`} ref={ref} aria-hidden="true">
      {children}
    </div>
  );
};

export default ParallaxLayer;
```

---

```javascript