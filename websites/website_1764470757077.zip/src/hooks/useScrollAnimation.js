import { useAnimation } from "framer-motion";
import { useEffect, useRef } from "react";

const useScrollAnimation = (options = {}) => {
  const controls = useAnimation();
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          controls.start("visible");
        }
      },
      {
        threshold: options.threshold || 0.3,
        rootMargin: options.rootMargin || "0px"
      }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [controls, options.threshold, options.rootMargin]);

  return [ref, controls];
};

export default useScrollAnimation;
```

---

```javascript