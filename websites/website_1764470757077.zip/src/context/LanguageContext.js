import React, { createContext, useEffect, useState } from "react";

export const LanguageContext = createContext({
  language: "en",
  toggleLanguage: () => {}
});

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState("en");

  useEffect(() => {
    const stored = window.localStorage.getItem("tph-language");
    if (stored) {
      setLanguage(stored);
    } else {
      const userLang = navigator.language;
      if (userLang && userLang.toLowerCase().startsWith("es")) {
        setLanguage("es");
      }
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem("tph-language", language);
    document.documentElement.setAttribute("lang", language === "es" ? "es-AR" : "en");
  }, [language]);

  const toggleLanguage = () => setLanguage((prev) => (prev === "en" ? "es" : "en"));

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};
```

---

```javascript