document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navMenu.classList.toggle("open");
        });
        document.querySelectorAll(".nav-menu a").forEach(link => {
            link.addEventListener("click", () => {
                if (navMenu.classList.contains("open")) {
                    navMenu.classList.remove("open");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const cookieActions = document.querySelectorAll(".cookie-action");
    const cookieChoice = localStorage.getItem("chickemdacCookieChoice");

    if (cookieBanner) {
        if (!cookieChoice) {
            cookieBanner.classList.remove("hidden");
        }
        cookieActions.forEach(action => {
            action.addEventListener("click", event => {
                const choice = action.dataset.choice || "accepted";
                localStorage.setItem("chickemdacCookieChoice", choice);
                cookieBanner.classList.add("hidden");
                setTimeout(() => {
                    window.location.href = action.getAttribute("href");
                }, 150);
                event.preventDefault();
            });
        });
    }

    const searchInput = document.getElementById("searchInput");
    const filterButtons = document.querySelectorAll(".filter-button");
    const postCards = document.querySelectorAll(".post-card");
    const noResults = document.getElementById("noResults");
    let activeCategory = "all";

    function normalise(text) {
        return text.toLowerCase().trim();
    }

    function filterPosts() {
        const query = normalise(searchInput ? searchInput.value : "");
        let visibleCount = 0;
        postCards.forEach(card => {
            const title = normalise(card.dataset.title || "");
            const keywords = normalise(card.dataset.keywords || "");
            const category = card.dataset.category || "all";
            const matchesCategory = activeCategory === "all" || category === activeCategory;
            const matchesQuery = !query || title.includes(query) || keywords.includes(query);
            if (matchesCategory && matchesQuery) {
                card.style.display = "";
                visibleCount += 1;
            } else {
                card.style.display = "none";
            }
        });
        if (noResults) {
            noResults.style.display = visibleCount === 0 ? "block" : "none";
        }
    }

    if (filterButtons.length) {
        filterButtons.forEach(button => {
            button.addEventListener("click", () => {
                filterButtons.forEach(btn => btn.classList.remove("active"));
                button.classList.add("active");
                activeCategory = button.dataset.category || "all";
                filterPosts();
            });
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", filterPosts);
        filterPosts();
    }
});