import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  return (
    <header className={styles.header} aria-label="Основная навигация">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Мир Кошек — на главную">
          <span className={styles.logoSymbol} aria-hidden="true">
            🐾
          </span>
          <span className={styles.brand}>Мир Кошек</span>
        </Link>
        <button
          type="button"
          className={styles.navToggle}
          aria-controls="main-navigation"
          aria-expanded={isMenuOpen}
          onClick={toggleMenu}
        >
          <span className={styles.navToggleBar} />
          <span className={styles.navToggleBar} />
          <span className={styles.navToggleBar} />
          <span className={styles.navToggleLabel}>Меню</span>
        </button>
        <nav
          id="main-navigation"
          className={"${styles.navLinks} ${isMenuOpen ? styles.navOpen : ''}"}
          aria-label="Основные разделы сайта"
        >
          <NavLink to="/" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)} end>
            Главная
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            О проекте
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Разделы
          </NavLink>
          <NavLink to="/porody" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Породы
          </NavLink>
          <NavLink to="/uhod-i-soderzhanie" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Уход
          </NavLink>
          <NavLink to="/zdorovie-koshki" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Здоровье
          </NavLink>
          <NavLink to="/povedenie-koshek" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Поведение
          </NavLink>
          <Link to="/kontakty" className={"${styles.navLink} ${styles.ctaLink}"}>
            Контакты
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;