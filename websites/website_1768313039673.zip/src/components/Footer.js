import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.column}>
        <Link to="/" className={styles.footerBrand} aria-label="Мир Кошек — на главную">
          Мир Кошек
        </Link>
        <p className={styles.tagline}>
          Надежный источник знаний для владельцев и поклонников кошек. Мы объединяем проверенную информацию, советы экспертов и вдохновляющие истории.
        </p>
      </div>
      <div className={styles.column}>
        <h2 className={styles.heading}>Навигация</h2>
        <ul className={styles.linkList}>
          <li><Link to="/porody" className={styles.link}>Каталог пород</Link></li>
          <li><Link to="/uhod-i-soderzhanie" className={styles.link}>Уход и содержание</Link></li>
          <li><Link to="/zdorovie-koshki" className={styles.link}>Здоровье кошки</Link></li>
          <li><Link to="/povedenie-koshek" className={styles.link}>Поведение</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h2 className={styles.heading}>Правовая информация</h2>
        <ul className={styles.linkList}>
          <li><Link to="/usloviya-ispolzovaniya" className={styles.link}>Условия использования</Link></li>
          <li><Link to="/politika-konfidencialnosti" className={styles.link}>Политика конфиденциальности</Link></li>
          <li><Link to="/politika-cookie" className={styles.link}>Политика cookie</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h2 className={styles.heading}>Контакты</h2>
        <address className={styles.address}>
          <span>г. Москва, ул. Кошачья, д. 15</span>
          <Link to="/kontakty" className={"${styles.link} ${styles.contactLink}"}>+7 (495) 123-45-67</Link>
          <Link to="/kontakty" className={"${styles.link} ${styles.contactLink}"}>info@mir-koshek.ru</Link>
        </address>
        <div className={styles.socials} aria-label="Социальные сети">
          <a href="https://www.youtube.com" className={styles.socialLink} target="_blank" rel="noopener noreferrer" aria-label="YouTube Мир Кошек">
            YouTube
          </a>
          <a href="https://www.instagram.com" className={styles.socialLink} target="_blank" rel="noopener noreferrer" aria-label="Instagram Мир Кошек">
            Instagram
          </a>
          <a href="https://vk.com" className={styles.socialLink} target="_blank" rel="noopener noreferrer" aria-label="VK Мир Кошек">
            VK
          </a>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} «Мир Кошек». Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;