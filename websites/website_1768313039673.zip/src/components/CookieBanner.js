import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'mir-koshek-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(COOKIE_KEY, choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о файлах cookie">
      <div className={styles.text}>
        <p>Этот сайт использует файлы cookie для улучшения работы. Продолжая использовать сайт, вы соглашаетесь с этим.</p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={() => handleChoice('accepted')}>
          Принять
        </button>
        <button type="button" className={styles.decline} onClick={() => handleChoice('declined')}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;