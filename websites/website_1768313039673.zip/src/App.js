import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import BreedsPage from './pages/BreedsPage';
import BreedDetailPage from './pages/BreedDetailPage';
import CarePage from './pages/CarePage';
import HealthPage from './pages/HealthPage';
import BehaviorPage from './pages/BehaviorPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import AppStyles from './App.module.css';

const NotFoundPage = () => (
  <div className={AppStyles.notFound}>
    <h1>Страница не найдена</h1>
    <p>К сожалению, страница, которую вы ищете, не существует или была перемещена.</p>
  </div>
);

const App = () => (
  <div className={AppStyles.app}>
    <a href="#mainContent" className={AppStyles.skipLink}>
      Перейти к содержанию
    </a>
    <Header />
    <main id="mainContent" className={AppStyles.mainContent}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/porody" element={<BreedsPage />} />
        <Route path="/porody/:breedId" element={<BreedDetailPage />} />
        <Route path="/uhod-i-soderzhanie" element={<CarePage />} />
        <Route path="/zdorovie-koshki" element={<HealthPage />} />
        <Route path="/povedenie-koshek" element={<BehaviorPage />} />
        <Route path="/kontakty" element={<Contact />} />
        <Route path="/spasibo" element={<ThankYou />} />
        <Route path="/usloviya-ispolzovaniya" element={<TermsOfService />} />
        <Route path="/politika-konfidencialnosti" element={<PrivacyPolicy />} />
        <Route path="/politika-cookie" element={<CookiePolicyPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

export default App;