import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const sanitizeInput = (value) => value.replace(/[<>]/g, '').trim();

const Contact = () => {
  const navigate = useNavigate();
  const [formValues, setFormValues] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const nextErrors = {};
    if (!formValues.name.trim()) {
      nextErrors.name = 'Введите имя.';
    }
    if (!formValues.email.trim()) {
      nextErrors.email = 'Укажите электронную почту.';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formValues.email.trim())) {
        nextErrors.email = 'Введите корректный адрес электронной почты.';
      }
    }
    if (!formValues.message.trim()) {
      nextErrors.message = 'Добавьте ваше сообщение.';
    } else if (formValues.message.trim().length < 10) {
      nextErrors.message = 'Сообщение должно содержать не менее 10 символов.';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    const sanitized = {
      name: sanitizeInput(formValues.name),
      email: sanitizeInput(formValues.email),
      message: sanitizeInput(formValues.message)
    };
    if (!sanitized.name || !sanitized.email || !sanitized.message) {
      setErrors({ form: 'Пожалуйста, не используйте запрещённые символы.' });
      return;
    }
    navigate('/spasibo');
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты «Мир Кошек» — напишите нам</title>
        <meta
          name="description"
          content="Свяжитесь с командой «Мир Кошек». Адрес, телефон, электронная почта и форма обратной связи для вопросов о кошках."
        />
        <meta
          name="keywords"
          content="контакты Мир Кошек, написать, адрес Мир Кошек, телефон Мир Кошек, форма обратной связи"
        />
      </Helmet>
      <header className={styles.header}>
        <h1>Контакты</h1>
        <p>
          Мы открыты к вопросам и сотрудничеству. Заполните форму или воспользуйтесь любым удобным способом связи — ответим в течение двух рабочих дней.
        </p>
      </header>
      <div className={styles.content}>
        <section className={styles.contactInfo} aria-labelledby="contact-info-heading">
          <h2 id="contact-info-heading">Как с нами связаться</h2>
          <ul className={styles.infoList}>
            <li><strong>Адрес:</strong> г. Москва, ул. Кошачья, д. 15</li>
            <li><strong>Телефон:</strong> +7 (495) 123-45-67</li>
            <li><strong>Email:</strong> info@mir-koshek.ru</li>
          </ul>
          <p>
            Мы также сотрудничаем с приютами и ветеринарными клиниками. Если вы хотите предложить тему для материала, расскажите об этом в сообщении.
          </p>
        </section>
        <section className={styles.formSection} aria-labelledby="contact-form-heading">
          <h2 id="contact-form-heading">Форма обратной связи</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            {errors.form && <p className={styles.formError}>{errors.form}</p>}
            <label htmlFor="name" className={styles.label}>
              Имя
              <input
                id="name"
                name="name"
                type="text"
                value={formValues.name}
                onChange={handleChange}
                className={"${styles.input} ${errors.name ? styles.inputError : ''}"}
                placeholder="Как к вам обращаться?"
                required
              />
              {errors.name && <span className={styles.errorMessage}>{errors.name}</span>}
            </label>
            <label htmlFor="email" className={styles.label}>
              Электронная почта
              <input
                id="email"
                name="email"
                type="email"
                value={formValues.email}
                onChange={handleChange}
                className={"${styles.input} ${errors.email ? styles.inputError : ''}"}
                placeholder="name@example.ru"
                required
              />
              {errors.email && <span className={styles.errorMessage}>{errors.email}</span>}
            </label>
            <label htmlFor="message" className={styles.label}>
              Сообщение
              <textarea
                id="message"
                name="message"
                value={formValues.message}
                onChange={handleChange}
                className={"${styles.textarea} ${errors.message ? styles.inputError : ''}"}
                placeholder="Напишите ваш вопрос или предложение..."
                minLength={10}
                required
              />
              {errors.message && <span className={styles.errorMessage}>{errors.message}</span>}
            </label>
            <button type="submit" className={styles.submitButton}>
              Отправить сообщение
            </button>
          </form>
        </section>
      </div>
    </div>
  );
};

export default Contact;