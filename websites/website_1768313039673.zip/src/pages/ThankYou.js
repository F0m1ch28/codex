import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYou = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Спасибо за ваше сообщение — Мир Кошек</title>
      <meta
        name="description"
        content="Благодарим за обращение в «Мир Кошек». Мы свяжемся с вами в ближайшее время и ответим на все вопросы."
      />
      <meta
        name="keywords"
        content="спасибо, обратная связь, Мир Кошек"
      />
    </Helmet>
    <div className={styles.card}>
      <h1>Спасибо!</h1>
      <p>
        Мы получили ваше сообщение и обязательно свяжемся с вами в ближайшее время. Пока вы ожидаете ответ, загляните в наши свежие материалы.
      </p>
      <div className={styles.actions}>
        <Link to="/" className={styles.linkButton}>На главную</Link>
        <Link to="/porody" className={styles.secondaryLink}>Исследовать породы</Link>
      </div>
    </div>
  </div>
);

export default ThankYou;