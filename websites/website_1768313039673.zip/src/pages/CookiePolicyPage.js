import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/TextPage.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика cookie — Мир Кошек</title>
      <meta
        name="description"
        content="Узнайте, какие файлы cookie использует сайт «Мир Кошек», и как вы можете управлять ими."
      />
      <meta
        name="keywords"
        content="cookie, политика cookie, файлы cookie, настройки cookie"
      />
    </Helmet>
    <h1 className={styles.title}>Политика cookie</h1>
    <p className={styles.intro}>
      Файлы cookie помогают нам анализировать работу сайта и улучшать пользовательский опыт. Ниже описано, какие cookie мы используем и как ими управлять.
    </p>
    <section className={styles.section}>
      <h2>1. Какие cookie используются</h2>
      <ul className={styles.list}>
        <li>Технические cookie — обеспечивают работу навигации и безопасность.</li>
        <li>Аналитические cookie — помогают понимать, какие материалы наиболее востребованы.</li>
      </ul>
    </section>
    <section className={styles.section}>
      <h2>2. Управление cookie</h2>
      <p>Вы можете изменить своё решение в настройках браузера или воспользоваться кнопками в баннере. Отказ от cookie может ограничить некоторые функции сайта.</p>
    </section>
  </div>
);

export default CookiePolicyPage;