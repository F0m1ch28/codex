import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/TextPage.module.css';

const PrivacyPolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика конфиденциальности — Мир Кошек</title>
      <meta
        name="description"
        content="Узнайте, какие данные собирает портал «Мир Кошек» и как они используются. Мы заботимся о конфиденциальности пользователей."
      />
      <meta
        name="keywords"
        content="политика конфиденциальности, персональные данные, Мир Кошек"
      />
    </Helmet>
    <h1 className={styles.title}>Политика конфиденциальности</h1>
    <p className={styles.intro}>
      Мы уважаем личную информацию посетителей и стремимся к прозрачности. В этом документе описано, какие данные собираются и как они защищаются.
    </p>
    <section className={styles.section}>
      <h2>1. Какие данные мы собираем</h2>
      <ul className={styles.list}>
        <li>Технические данные (IP, тип браузера, версия операционной системы) для аналитики и улучшения сайта.</li>
        <li>Контактные данные, указанные в форме обратной связи, чтобы отвечать на запросы.</li>
      </ul>
    </section>
    <section className={styles.section}>
      <h2>2. Как мы используем данные</h2>
      <p>Информация используется исключительно для обратной связи и анализа посещаемости. Мы не передаём данные третьим лицам без вашего согласия.</p>
    </section>
    <section className={styles.section}>
      <h2>3. Хранение и защита</h2>
      <p>Все данные хранятся на защищённых серверах. Доступ к ним имеют только уполномоченные сотрудники.</p>
    </section>
    <section className={styles.section}>
      <h2>4. Ваши права</h2>
      <p>Вы можете запросить удаление или уточнение своих данных, написав на info@mir-koshek.ru. Ответ предоставляется в течение 30 дней.</p>
    </section>
    <section className={styles.section}>
      <h2>5. Обновления политики</h2>
      <p>Изменения политики публикуются на этой странице. Рекомендуем периодически просматривать документ.</p>
    </section>
  </div>
);

export default PrivacyPolicy;