import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/TextPage.module.css';

const CarePage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Уход и содержание кошки — Мир Кошек</title>
      <meta
        name="description"
        content="Практические советы по уходу и содержанию кошки: организация пространства, питание, гигиена и досуг питомца."
      />
      <meta
        name="keywords"
        content="уход за кошкой, содержание кошки, питание кошки, советы по уходу"
      />
    </Helmet>
    <h1 className={styles.title}>Уход и содержание</h1>
    <p className={styles.intro}>
      Забота о кошке строится на понимании её природных потребностей. Организуйте дом так, чтобы питомец чувствовал себя защищённым и свободным.
    </p>
    <section className={styles.section}>
      <h2>Домашняя среда</h2>
      <ul className={styles.list}>
        <li>Создайте укромные места на разной высоте — так кошка сможет наблюдать и отдыхать.</li>
        <li>Обеспечьте когтеточки в нескольких комнатах, чтобы сохранить мебель и здоровье когтей.</li>
        <li>Размещайте миски для еды и воды в тихих зонах вдали от лотка.</li>
      </ul>
    </section>
    <section className={styles.section}>
      <h2>Гигиена и питание</h2>
      <p>Выбирайте качественный корм, соответствующий возрасту и состоянию здоровья. Регулярно чистите лоток и поддерживайте свежесть воды.</p>
    </section>
    <section className={styles.section}>
      <h2>Игры и социализация</h2>
      <p>Игры — не просто развлечение, а важный элемент физического и умственного развития. Используйте интерактивные игрушки и чередуйте их, чтобы сохранять интерес.</p>
    </section>
  </div>
);

export default CarePage;