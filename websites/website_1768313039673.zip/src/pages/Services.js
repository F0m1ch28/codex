import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Разделы портала «Мир Кошек» — ориентир для заботливых владельцев</title>
      <meta
        name="description"
        content="Обзор ключевых разделов портала «Мир Кошек»: породы, лайфхаки по уходу, здоровье и поведение. Найдите полезные материалы для любого этапа жизни кошки."
      />
      <meta
        name="keywords"
        content="разделы сайта, база знаний, породы кошек, советы по уходу, здоровье кошки, поведение кошки"
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Разделы портала</h1>
      <p>
        Мы структурировали информацию так, чтобы вы быстро находили ответы и вдохновение. Каждый раздел создан на основе вопросов, которые чаще всего задают владельцы кошек.
      </p>
    </header>
    <div className={styles.grid}>
      <article className={styles.card}>
        <h2>Каталог пород</h2>
        <p>
          Подробные профили кошек — от характера до особенностей здоровья. Мы сравниваем темперамент и рассказываем, кому подходит каждая порода.
        </p>
        <Link to="/porody" className={styles.cardLink}>
          Перейти в каталог →
        </Link>
      </article>
      <article className={styles.card}>
        <h2>Уход и содержание</h2>
        <p>
          Готовые чек-листы по кормлению, гигиене, организации пространства и адаптации кошки к новым условиям жизни.
        </p>
        <Link to="/uhod-i-soderzhanie" className={styles.cardLink}>
          Читать советы →
        </Link>
      </article>
      <article className={styles.card}>
        <h2>Здоровье кошки</h2>
        <p>
          Профилактика, вакцинация, тревожные симптомы и рекомендации ветеринаров — всё, чтобы ваш питомец чувствовал себя отлично.
        </p>
        <Link to="/zdorovie-koshki" className={styles.cardLink}>
          Узнать больше →
        </Link>
      </article>
      <article className={styles.card}>
        <h2>Поведение и эмоции</h2>
        <p>
          Разбор привычек, причин нежелательных действий и способов мягко скорректировать поведение кошки, сохраняя доверие.
        </p>
        <Link to="/povedenie-koshek" className={styles.cardLink}>
          Разобраться →
        </Link>
      </article>
      <article className={styles.card}>
        <h2>Интервью и истории</h2>
        <p>
          Разговоры с экспертами и читателями, истории спасения и вдохновляющие кейсы ответственного усыновления кошек.
        </p>
        <Link to="/about" className={styles.cardLink}>
          Читать истории →
        </Link>
      </article>
      <article className={styles.card}>
        <h2>Подборка ресурсов</h2>
        <p>
          Проверенные ветклиники, приюты и полезные заметки, которые помогут любому кошачьему родителю ориентироваться в информационном поле.
        </p>
        <Link to="/kontakty" className={styles.cardLink}>
          Связаться с нами →
        </Link>
      </article>
    </div>
  </div>
);

export default Services;