import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const BreedCard = ({ breed }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <Link to={"/porody/${breed.slug}"} className={styles.breedCard}>
      <div className={styles.imageWrapper}>
        {!loaded && <div className={styles.imagePlaceholder} aria-hidden="true" />}
        <img
          src={breed.image}
          alt={"Порода кошек ${breed.name}"}
          className={"${styles.cardImage} ${loaded ? styles.imageVisible : ''}"}
          loading="lazy"
          onLoad={() => setLoaded(true)}
        />
      </div>
      <div className={styles.cardContent}>
        <h3>{breed.name}</h3>
        <p>{breed.description}</p>
      </div>
    </Link>
  );
};

const ArticlePreview = ({ article }) => (
  <Link to={article.link} className={styles.articleCard}>
    <div className={styles.articleContent}>
      <h3>{article.title}</h3>
      <p>{article.excerpt}</p>
    </div>
    <span className={styles.articleLink}>Читать далее →</span>
  </Link>
);

const Home = () => {
  const [openFact, setOpenFact] = useState(null);

  const popularBreeds = [
    {
      name: 'Сиамская кошка',
      slug: 'siamskaya-koshka',
      description: 'Элегантные, разговорчивые и невероятно привязанные к человеку.',
      image: 'https://picsum.photos/id/1025/600/400'
    },
    {
      name: 'Мейн-кун',
      slug: 'meyn-kun',
      description: 'Мягкие великаны с дружелюбным характером и выразительными глазами.',
      image: 'https://picsum.photos/id/593/600/400'
    },
    {
      name: 'Британская короткошёрстная',
      slug: 'britanskaya-korotkosherstnaya',
      description: 'Спокойные, уверенные в себе кошки с плюшевой шерстью.',
      image: 'https://picsum.photos/id/433/600/400'
    },
    {
      name: 'Сфинкс',
      slug: 'sfinks',
      description: 'Ласковые и бесстрашные кошки без шерсти, которым нужен особый уход.',
      image: 'https://picsum.photos/id/593/600/401'
    },
    {
      name: 'Русская голубая',
      slug: 'russkaya-golubaya',
      description: 'Изящные кошки с плотной серебристой шерстью и кротким нравом.',
      image: 'https://picsum.photos/id/582/600/400'
    },
    {
      name: 'Абиссинская кошка',
      slug: 'abissinskaya-koshka',
      description: 'Подвижные исследователи с тёплым окрасом и живым темпераментом.',
      image: 'https://picsum.photos/id/1062/600/400'
    }
  ];

  const articles = [
    {
      title: 'Как организовать идеальный дом для кошки',
      excerpt: 'Создайте безопасное и увлекательное пространство, учитывающее природные инстинкты питомца.',
      link: '/uhod-i-soderzhanie'
    },
    {
      title: 'Профилактика заболеваний у кошек',
      excerpt: 'Прививки, осмотры и ежедневные привычки, которые поддерживают здоровье вашего хвостатого друга.',
      link: '/zdorovie-koshki'
    },
    {
      title: 'Почему кошки мурлыкают?',
      excerpt: 'Разбираем причины мурчания и что ваш питомец пытается сказать.',
      link: '/povedenie-koshek'
    },
    {
      title: 'Список must-have аксессуаров',
      excerpt: 'Все, что нужно для гармоничной жизни кошки и человека в одной квартире.',
      link: '/services'
    }
  ];

  const services = [
    {
      title: 'Каталог пород',
      description: 'Подробные профили популярных и редких пород с рекомендациями по уходу.',
      link: '/porody'
    },
    {
      title: 'Экспертная база знаний',
      description: 'Пошаговые инструкции, советы специалистов и полезные чек-листы.',
      link: '/services'
    },
    {
      title: 'Комьюнити заботливых владельцев',
      description: 'Истории читателей, вдохновение и поддержка единомышленников.',
      link: '/about'
    }
  ];

  const testimonials = [
    {
      name: 'Анна Петрова',
      city: 'Новосибирск',
      quote: '«Нашла на “Мире Кошек” ответы на все вопросы по адаптации котёнка. Сайт очень структурированный и уютный.»',
      image: 'https://picsum.photos/id/1005/120/120'
    },
    {
      name: 'Екатерина Смирнова',
      city: 'Казань',
      quote: '«Материалы помогают мне как волонтёру приюта объяснять будущим хозяевам основы ухода и психологии.»',
      image: 'https://picsum.photos/id/1012/120/120'
    },
    {
      name: 'Максим Орлов',
      city: 'Санкт-Петербург',
      quote: '«Люблю раздел про породы — фотографии, факты и сравнения поданы в живой форме, читать одно удовольствие.»',
      image: 'https://picsum.photos/id/1011/120/120'
    }
  ];

  const funFacts = [
    'У каждого кошачьего носа уникальный рисунок, как отпечатки пальцев у человека.',
    'Кошки могут издавать более ста различных звуков, тогда как собаки — около десяти.',
    'Средний сон кошки занимает 12–16 часов в сутки, но даже во сне она насторожена.',
    'Мурлыканье помогает кошкам успокоиться и даже способствует регенерации тканей.',
    'Кошки не чувствуют сладкий вкус, но отлично распознают умами.',
    'Кошачьи усы работают как высокочувствительные сенсоры и помогают оценить ширину проёмов.',
    'Сердце кошки бьётся почти в два раза быстрее человеческого — около 140 ударов в минуту.'
  ];

  const handleToggleFact = (index) => {
    setOpenFact((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Мир Кошек — всё о породах, уходе и поведении кошек</title>
        <meta
          name="description"
          content="Добро пожаловать в «Мир Кошек» — вдохновляющий портал о породах, здоровье, поведении и уходе за кошками. Советы экспертов и истории владельцев."
        />
        <meta
          name="keywords"
          content="кошки, породы кошек, уход за кошками, здоровье кошек, советы по содержанию, Мир Кошек"
        />
      </Helmet>
      <section className={"${styles.section} ${styles.hero}"} aria-labelledby="hero-heading">
        <div className={styles.container}>
          <h1 id="hero-heading" className={styles.heroTitle}>
            Всё о кошках: от ухода до характера
          </h1>
          <p className={styles.heroSubtitle}>
            Погрузитесь в мир мягких лап и уютного мурчания. Мы собрали проверенную информацию, чтобы помочь вам лучше понимать и заботиться о ваших любимых питомцах.
          </p>
          <div className={styles.heroActions}>
            <Link to="/porody" className={styles.heroButton}>
              Исследовать породы
            </Link>
            <Link to="/kontakty" className={styles.heroSecondary}>
              Задать вопрос
            </Link>
          </div>
        </div>
      </section>

      <section className={"${styles.section} ${styles.services}"} aria-labelledby="services-heading">
        <div className={styles.container}>
          <h2 id="services-heading" className={styles.sectionTitle}>
            Что вы найдёте на «Мире Кошек»
          </h2>
          <p className={styles.sectionIntro}>
            Мы создаём пространство, где полезные знания встречаются с вдохновением. Каждый раздел, карточка породы и статья подготовлены с особой заботой.
          </p>
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <Link key={service.title} to={service.link} className={styles.serviceCard}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <span className={styles.serviceLink}>Узнать подробнее</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={"${styles.section} ${styles.breeds}"} aria-labelledby="breeds-heading">
        <div className={styles.container}>
          <h2 id="breeds-heading" className={styles.sectionTitle}>
            Популярные породы
          </h2>
          <p className={styles.sectionIntro}>
            Узнайте особенности темперамента, ухода и здоровья каждой породы, чтобы выбрать идеального компаньона или глубже понять уже живущего с вами котика.
          </p>
          <div className={styles.breedGrid}>
            {popularBreeds.map((breed) => (
              <BreedCard key={breed.slug} breed={breed} />
            ))}
          </div>
        </div>
      </section>

      <section className={"${styles.section} ${styles.articles}"} aria-labelledby="articles-heading">
        <div className={styles.container}>
          <h2 id="articles-heading" className={styles.sectionTitle}>
            Полезные статьи
          </h2>
          <p className={styles.sectionIntro}>
            Пошаговые инструкции, экспертные советы и вдохновляющие истории, которые помогут выстроить гармоничные отношения с вашей кошкой.
          </p>
          <div className={styles.articleGrid}>
            {articles.map((article) => (
              <ArticlePreview key={article.title} article={article} />
            ))}
          </div>
        </div>
      </section>

      <section className={"${styles.section} ${styles.testimonials}"} aria-labelledby="testimonials-heading">
        <div className={styles.container}>
          <h2 id="testimonials-heading" className={styles.sectionTitle}>
            Голоса наших читателей
          </h2>
          <div className={styles.testimonialGrid}>
            {testimonials.map((testimonial) => (
              <article key={testimonial.name} className={styles.testimonialCard}>
                <img
                  src={testimonial.image}
                  alt={"Фото читателя ${testimonial.name}"}
                  loading="lazy"
                  className={styles.testimonialAvatar}
                />
                <p className={styles.testimonialQuote}>{testimonial.quote}</p>
                <p className={styles.testimonialName}>{testimonial.name}</p>
                <span className={styles.testimonialCity}>{testimonial.city}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={"${styles.section} ${styles.facts}"} aria-labelledby="facts-heading">
        <div className={styles.container}>
          <h2 id="facts-heading" className={styles.sectionTitle}>
            Интересные факты о кошках
          </h2>
          <div className={styles.accordion} role="list">
            {funFacts.map((fact, index) => (
              <div className={styles.accordionItem} key={fact} role="listitem">
                <button
                  type="button"
                  className={styles.accordionButton}
                  aria-expanded={openFact === index}
                  onClick={() => handleToggleFact(index)}
                >
                  <span>Факт №{index + 1}</span>
                  <span aria-hidden="true">{openFact === index ? '−' : '+'}</span>
                </button>
                {openFact === index && <p className={styles.accordionContent}>{fact}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={"${styles.section} ${styles.mission}"} aria-labelledby="mission-heading">
        <div className={styles.container}>
          <h2 id="mission-heading" className={styles.sectionTitle}>
            Наша миссия
          </h2>
          <div className={styles.missionContent}>
            <p>
              «Мир Кошек» — это независимый портал, созданный из любви к кошкам и уважения к ответственному
              отношению к животным. Мы стремимся делиться проверенной информацией, вдохновлять на заботу и помогать владельцам
              находить ответы на ежедневные вопросы. Нам важно, чтобы каждая кошка чувствовала себя в безопасности, а каждый человек
              был уверен в своём выборе и действиях.
            </p>
            <p>
              Авторские статьи, экспертные комментарии, подборки полезных материалов и вдохновляющих историй —
              всё это помогает строить диалог между людьми и их хвостатыми друзьями. Мы открыты к сотрудничеству с ветеринарами, грумерами,
              этологами и волонтёрами, чтобы раскрывать тему ухода за кошками максимально комплексно.
            </p>
            <Link to="/about" className={styles.missionLink}>
              Узнать больше о команде
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;