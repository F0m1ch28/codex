import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './BreedsPage.module.css';

const breeds = [
  {
    name: 'Сиамская кошка',
    slug: 'siamskaya-koshka',
    origin: 'Таиланд',
    temperament: 'Общительная, разговорчивая, преданная',
    image: 'https://picsum.photos/id/1025/520/360'
  },
  {
    name: 'Мейн-кун',
    slug: 'meyn-kun',
    origin: 'США',
    temperament: 'Ласковый гигант, спокойный, дружелюбный',
    image: 'https://picsum.photos/id/593/520/360'
  },
  {
    name: 'Британская короткошёрстная',
    slug: 'britanskaya-korotkosherstnaya',
    origin: 'Великобритания',
    temperament: 'Невозмутимая, уравновешенная, независимая',
    image: 'https://picsum.photos/id/433/520/360'
  },
  {
    name: 'Сфинкс',
    slug: 'sfinks',
    origin: 'Канада',
    temperament: 'Тактильная, активная, дружелюбная',
    image: 'https://picsum.photos/id/593/520/361'
  },
  {
    name: 'Русская голубая',
    slug: 'russkaya-golubaya',
    origin: 'Россия',
    temperament: 'Спокойная, интеллигентная, нежная',
    image: 'https://picsum.photos/id/582/520/360'
  },
  {
    name: 'Абиссинская кошка',
    slug: 'abissinskaya-koshka',
    origin: 'Эфиопия',
    temperament: 'Энергичная, любознательная, ласковая',
    image: 'https://picsum.photos/id/1062/520/360'
  }
];

const BreedsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Каталог пород кошек — Мир Кошек</title>
      <meta
        name="description"
        content="Изучите каталог пород кошек на портале «Мир Кошек»: характер, уход, происхождение и особенности каждой породы."
      />
      <meta
        name="keywords"
        content="породы кошек, каталог пород, характер кошек, уход за породами, Мир Кошек"
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Каталог пород кошек</h1>
      <p>
        Подберите породу по темпераменту, образу жизни и внешнему виду. Мы собрали ключевые особенности и советы по уходу, чтобы помочь вам принять осознанное решение.
      </p>
    </header>
    <div className={styles.grid}>
      {breeds.map((breed) => (
        <article key={breed.slug} className={styles.card}>
          <img src={breed.image} alt={"Порода кошек ${breed.name}"} loading="lazy" className={styles.image} />
          <div className={styles.cardBody}>
            <h2>{breed.name}</h2>
            <p><strong>Происхождение:</strong> {breed.origin}</p>
            <p><strong>Темперамент:</strong> {breed.temperament}</p>
            <Link to={"/porody/${breed.slug}"} className={styles.link}>
              Подробнее →
            </Link>
          </div>
        </article>
      ))}
    </div>
  </div>
);

export default BreedsPage;