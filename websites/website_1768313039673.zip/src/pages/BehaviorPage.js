import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/TextPage.module.css';

const BehaviorPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Поведение кошек и их эмоции — Мир Кошек</title>
      <meta
        name="description"
        content="Расшифровываем поведение кошек: мурчание, царапание, неожиданные шалости. Узнайте, что стоит за привычками питомца."
      />
      <meta
        name="keywords"
        content="поведение кошки, мурлыканье, эмоции кошки, поведенист кошек"
      />
    </Helmet>
    <h1 className={styles.title}>Поведение кошек</h1>
    <p className={styles.intro}>
      Понимание кошачьего поведения помогает укрепить доверие и сделать совместную жизнь комфортной. Наблюдайте за сигналами тела и голосом питомца.
    </p>
    <section className={styles.section}>
      <h2>Язык тела</h2>
      <p>Положение хвоста, ушей и усов — быстрый индикатор настроения. Например, поднятый хвост говорит о дружелюбии, а прижатые уши — о тревоге.</p>
    </section>
    <section className={styles.section}>
      <h2>Почему кошки царапают</h2>
      <p>Царапание — способ пометить территорию и размять мышцы. Правильно расположенные когтеточки и положительное подкрепление помогут защитить мебель.</p>
    </section>
    <section className={styles.section}>
      <h2>Игры и охотничьи инстинкты</h2>
      <p>Игровое поведение связано с врождённым охотничьим инстинктом. Предлагайте интерактивные игрушки, чтобы направить энергию в безопасное русло.</p>
    </section>
  </div>
);

export default BehaviorPage;