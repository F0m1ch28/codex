document.addEventListener("DOMContentLoaded", function () {
    var banner = document.getElementById("cookie-banner");
    if (!banner) return;

    var status = localStorage.getItem("gcqgCookiePreference");
    if (!status) {
        banner.style.display = "block";
    }

    var acceptBtn = document.getElementById("cookie-accept");
    var declineBtn = document.getElementById("cookie-decline");

    if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
            localStorage.setItem("gcqgCookiePreference", "accepted");
            banner.style.display = "none";
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", function () {
            localStorage.setItem("gcqgCookiePreference", "declined");
            banner.style.display = "none";
        });
    }
});