export const categories = [
  {
    id: 'critical-care',
    name: 'Critical & Acute Care',
    description:
      'Evidence-based technology for ICU, HDU, and emergency settings, designed for rapid deployment and continuous uptime.',
    solutions: [
      'Multiparameter monitors & telemetry',
      'Smart infusion and syringe pumps',
      'Advanced ICU therapy beds',
      'Point-of-care ultrasound',
    ],
    image: 'https://cdn.pixabay.com/photo/2017/08/24/23/46/hospital-2672032_1280.jpg',
  },
  {
    id: 'respiratory-care',
    name: 'Respiratory & Sleep Support',
    description:
      'Respiratory equipment tailored for both hospital and home-care environments with caregiver-friendly interfaces.',
    solutions: [
      'Home ventilation and BiPAP systems',
      'High-flow oxygen therapy',
      'Humidifiers and nebulisers',
      'Sleep therapy compliance monitors',
    ],
    image: 'https://cdn.pixabay.com/photo/2016/11/21/14/21/oxygen-1839060_1280.jpg',
  },
  {
    id: 'diagnostics',
    name: 'Diagnostic Imaging & Point-of-Care',
    description:
      'Portable imaging, vital screening, and diagnostics optimised for clinics, ambulatory services, and outreach.',
    solutions: [
      'Ultrasound imaging suites',
      'ECG and Holter monitoring',
      'Telehealth diagnostic kits',
      'Laboratory POCT analyzers',
    ],
    image: 'https://cdn.pixabay.com/photo/2014/12/10/19/00/ultrasound-563777_1280.jpg',
  },
  {
    id: 'mobility',
    name: 'Mobility & Rehabilitation',
    description:
      'Ergonomic solutions to support mobility, post-acute rehabilitation, and dignified care for elderly patients.',
    solutions: [
      'Premium wheelchairs and scooters',
      'Transfer and lifting aids',
      'Therapy and posture support seating',
      'Home modification accessories',
    ],
    image: 'https://cdn.pixabay.com/photo/2015/07/17/13/44/wheelchair-849810_1280.jpg',
  },
  {
    id: 'infection-control',
    name: 'Infection Prevention & CSSD',
    description:
      'Reliable sterilisation and hygiene technologies aligning with UAE infection control mandates.',
    solutions: [
      'UV-C disinfection cabinets',
      'Washer-disinfectors and sterilisers',
      'Hand hygiene monitoring systems',
      'Medical waste segregation solutions',
    ],
    image: 'https://cdn.pixabay.com/photo/2016/11/29/04/17/laboratory-1866460_1280.jpg',
  },
  {
    id: 'home-care',
    name: 'Home & Community Care',
    description:
      'Connected devices empowering families and community nurses to deliver hospital-level care at home.',
    solutions: [
      'Telehealth monitoring kits',
      'Fall detection and safety sensors',
      'Pressure care mattresses',
      'Medication adherence systems',
    ],
    image: 'https://cdn.pixabay.com/photo/2016/11/29/05/25/analysis-1868728_1280.jpg',
  },
];