export const products = [
  {
    id: 'vitalscan-pro',
    name: 'VitalScan Pro Multiparameter Monitor',
    category: 'Patient Monitoring',
    description:
      'Advanced ICU-grade monitor with Arabic/English interface, predictive analytics, and seamless integration with hospital information systems across the UAE.',
    features: [
      '12.1-inch anti-glare touchscreen with night-friendly interface',
      'Modular EtCO₂, IBP, and Masimo SET® SpO₂ options for critical care',
      'Six-hour hot-swappable battery for uninterrupted patient monitoring',
    ],
    regulatory: 'FDA 510(k) | CE MDR | UAE MOHAP registered',
    support: 'Remote diagnostics and on-site calibration within 4 hours (Dubai & Abu Dhabi)',
    image: 'https://cdn.pixabay.com/photo/2017/08/06/01/03/ecg-2585383_1280.jpg',
  },
  {
    id: 'aeroflow-5',
    name: 'AeroFlow 5 Home Ventilation System',
    category: 'Respiratory Care',
    description:
      'Compact, quiet ventilator supporting invasive and non-invasive therapy with data logging for home-care teams.',
    features: [
      'Tailored ventilation profiles for adult and paediatric patients',
      'Integrated humidification and auto-trach compensation',
      'Cloud-based compliance reporting for clinicians and caregivers',
    ],
    regulatory: 'CE MDR | GCC conformity | DOH Abu Dhabi approved',
    support: 'Quarterly preventive maintenance included in service plan',
    image: 'https://cdn.pixabay.com/photo/2016/11/21/14/21/oxygen-1839060_1280.jpg',
  },
  {
    id: 'surestep-infusion',
    name: 'SureStep Smart Infusion Pump',
    category: 'Medication Delivery',
    description:
      'Precision infusion pump with dose error reduction software and MOHAP-compliant drug library support.',
    features: [
      'Wireless drug library updates with bilingual alerts',
      'Auto-detect IV set calibration for reduced setup errors',
      'Integrated occlusion detection and event logging',
    ],
    regulatory: 'FDA 510(k) | CE MDR | DHA Dubai listed',
    support: 'Clinical application specialist training included',
    image: 'https://cdn.pixabay.com/photo/2014/05/02/21/50/blood-pressure-monitor-336262_1280.jpg',
  },
  {
    id: 'novaflex-icu-bed',
    name: 'NovaFlex ICU Therapy Bed',
    category: 'Critical Care Furniture',
    description:
      'Adaptive ICU bed supporting early mobility programmes, safe patient handling, and pressure injury prevention.',
    features: [
      'Automated lateral rotation and percussion therapy',
      '700 kg safe working load with independent hill adjustment',
      'Under-bed lighting and fall prevention alarm suite',
    ],
    regulatory: 'CE MDR | ISO 60601 compliant | MOHAP registration pending',
    support: 'Annual bed safety certification and caregiver training',
    image: 'https://cdn.pixabay.com/photo/2017/08/24/23/46/hospital-2672032_1280.jpg',
  },
  {
    id: 'glidecare-mobility',
    name: 'GlideCare Premium Mobility Wheelchair',
    category: 'Mobility & Rehabilitation',
    description:
      'Lightweight, ergonomically refined wheelchair designed for comfort in hot climates and long-distance travel.',
    features: [
      'Breathable antimicrobial seating optimized for GCC climates',
      'One-touch attendant braking with hill-assist',
      'Customizable armrests and detachable transport kit',
    ],
    regulatory: 'ISO 7176 | CE MDR | UAE customs pre-cleared',
    support: 'On-site fitting and posture assessment for caregivers',
    image: 'https://cdn.pixabay.com/photo/2015/07/17/13/44/wheelchair-849810_1280.jpg',
  },
  {
    id: 'purewave-ultrasound',
    name: 'PureWave Ultrasound Imaging Suite',
    category: 'Diagnostic Imaging',
    description:
      'Portable ultrasound platform with AI-assisted workflow, ideal for clinics, mobile screening, and telemedicine.',
    features: [
      'Crystal-clear imaging with auto-optimisation presets',
      'Tele-ultrasound streaming for remote specialists',
      'Transducers designed for obstetric, cardiac, and MSK use',
    ],
    regulatory: 'FDA 510(k) | CE MDR | DHA Dubai accredited',
    support: 'Bi-lingual sonographer training and extended warranty',
    image: 'https://cdn.pixabay.com/photo/2014/12/10/19/00/ultrasound-563777_1280.jpg',
  },
  {
    id: 'sterisure-uv',
    name: 'Sterisure UV-C Disinfection Cabinet',
    category: 'Infection Control',
    description:
      'High-capacity UV-C cabinet delivering validated disinfection cycles for medical devices and mobile phones.',
    features: [
      '360° UV-C exposure with real-time dosage monitoring',
      'HEPA filtration and ozone-free operation for staff safety',
      'Cycle tracking and audit-ready reporting via secure portal',
    ],
    regulatory: 'CE MDR | ISO 15858 compliant | GCC warranty',
    support: 'Quarterly validation and biological indicator testing',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/04/17/laboratory-1866460_1280.jpg',
  },
  {
    id: 'lifeline-telehealth',
    name: 'LifeLine Telehealth Care Kit',
    category: 'Home Care & Remote Monitoring',
    description:
      'Integrated telehealth kit connecting patients, caregivers, and multidisciplinary teams across the Emirates.',
    features: [
      '4G-enabled hub with secure MOHAP-compliant data storage',
      'Vital signs peripherals calibrated for home use',
      'Arabic and English tutorials for elderly caregivers',
    ],
    regulatory: 'DOH Abu Dhabi pilot certified | CE | HIPAA-aligned platform',
    support: '24/7 virtual support desk and monthly clinical reviews',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/05/25/analysis-1868728_1280.jpg',
  },
];