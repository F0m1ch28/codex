export const faqs = [
  {
    id: 'training',
    question: 'Do you provide installation and training for new equipment in the UAE?',
    answer:
      'Yes. Every delivery includes commissioning by qualified biomedical engineers, user training in English and Arabic, and competency checklists tailored to the facility or home-care environment. Refresher sessions can be scheduled quarterly.',
  },
  {
    id: 'caregiver-support',
    question: 'How do you support elderly caregivers who are not medical professionals?',
    answer: [
      'Our Caregiver Onboarding Programme includes in-person or virtual training with simple language, pictorial guides, and follow-up calls. We also provide laminated quick-reference cards, large-print manuals, and a hotline staffed by clinical educators familiar with the UAE care context.',
    ],
    list: [
      'Step-by-step device demonstrations',
      'Emergency escalation protocols in English and Arabic',
      'WhatsApp video check-ins for troubleshooting',
    ],
  },
  {
    id: 'maintenance',
    question: 'What maintenance packages are available for hospitals and home-care providers?',
    answer:
      'We offer tiered service plans: Essential (annual calibration and safety checks), Enhanced (quarterly preventive maintenance with loaner pool), and Premium (24/7 on-site response within 4 hours in Abu Dhabi and Dubai, plus remote diagnostics). All plans include compliance documentation for MOHAP, DOH, and DHA audits.',
  },
  {
    id: 'regulatory',
    question: 'Are your devices compliant with UAE regulatory authorities?',
    answer:
      'We only distribute equipment with valid international certifications (FDA, CE, ISO) and complete UAE registration under MOHAP, DOH Abu Dhabi, or DHA Dubai. Documentation packs are provided in both digital and print format to support licensing renewals.',
  },
  {
    id: 'rtl-support',
    question: 'Can the user interfaces be localised for Arabic-speaking caregivers?',
    answer:
      'Yes. Many of our flagship devices feature bilingual user interfaces. We configure Arabic display languages and right-to-left documentation where supported, and we supply translated quick guides for caregivers and family members.',
  },
  {
    id: 'demo',
    question: 'How can I arrange a product demonstration or trial?',
    answer:
      'Submit a request via our contact form or call the hotline (placeholder +971 0 000 0000). Our clinical consultants will coordinate an on-site or virtual demo within 3 business days. Trial units can be deployed with signed evaluation agreements.',
  },
  {
    id: 'financing',
    question: 'Do you assist with financing or rental options?',
    answer:
      'We partner with leading UAE financial institutions to offer operating leases, try-before-you-buy programmes, and monthly rental plans for home-care patients. Rental agreements include maintenance, replacements, and training support.',
  },
  {
    id: 'emergency',
    question: 'What should caregivers do if equipment alarms outside working hours?',
    answer:
      'Our 24/7 technical helpline connects caregivers with biomedical specialists who can walk through alarm resolution. If remote troubleshooting is insufficient, we dispatch field engineers or coordinate ambulance services aligned with the patient’s care plan.',
  },
];