import React from 'react';
import { Helmet } from 'react-helmet-async';
import Page from '../components/Page';

const Privacy = () => (
  <Page className="privacy-page">
    <Helmet>
      <title>Privacy Policy | Emirates HealthTech Supplies</title>
      <meta
        name="description"
        content="Read the privacy policy explaining how Emirates HealthTech Supplies protects personal data for healthcare providers and caregivers in the UAE."
      />
    </Helmet>

    <header className="page-header">
      <h1>Privacy Policy</h1>
      <p>Last updated: March 2024</p>
    </header>

    <section className="section" aria-label="Privacy Policy">
      <article className="glass-card">
        <h3>1. Introduction</h3>
        <p>
          Emirates HealthTech Supplies LLC (&quot;we&quot;, &quot;us&quot;, &quot;our&quot;) is committed to protecting
          the privacy of healthcare professionals, caregivers, and patients. This policy explains how we collect, use,
          store, and protect personal data in compliance with UAE Federal Decree-Law No. 45 of 2021 on Personal Data
          Protection and relevant healthcare regulations.
        </p>

        <div className="card-divider" />

        <h3>2. Data we collect</h3>
        <p>We may collect the following data when you interact with us:</p>
        <ul>
          <li>Contact details (name, phone number, email, organisation)</li>
          <li>Caregiver and patient support information provided voluntarily</li>
          <li>Service logs, maintenance reports, and training attendance</li>
          <li>Telehealth and remote monitoring data processed on secure platforms</li>
          <li>Website analytics and cookie data to improve user experience</li>
        </ul>

        <div className="card-divider" />

        <h3>3. How we use personal data</h3>
        <p>We use personal data to:</p>
        <ul>
          <li>Provide equipment, maintenance, and support services</li>
          <li>Schedule training and respond to caregiver inquiries</li>
          <li>Process quotations, rentals, and service agreements</li>
          <li>Comply with regulatory reporting obligations</li>
          <li>Improve our products, training materials, and digital platforms</li>
        </ul>

        <div className="card-divider" />

        <h3>4. Cookies and analytics</h3>
        <p>
          Our website uses essential and analytical cookies to enhance usability and measure performance. You can accept
          or decline cookies through the on-page banner. Declining cookies may limit certain non-essential features, but
          core services remain accessible.
        </p>

        <div className="card-divider" />

        <h3>5. Data sharing</h3>
        <p>
          We do not sell personal data. We may share data with trusted partners such as logistics providers, clinical
          trainers, or telehealth platform providers who are contractually bound to maintain confidentiality and data
          security. Regulatory authorities may request data when legally required.
        </p>

        <div className="card-divider" />

        <h3>6. Data storage and security</h3>
        <p>
          Personal data is stored on secure servers within the UAE or jurisdictions with adequate protection standards.
          We implement encryption, access controls, and regular security audits. Telehealth data is managed on HIPAA-like
          platforms aligned with UAE healthcare regulations.
        </p>

        <div className="card-divider" />

        <h3>7. Data retention</h3>
        <p>
          We retain data only as long as necessary to fulfil contractual obligations, comply with legal requirements, or
          resolve disputes. Service and training records are typically retained for seven years unless regulations require
          longer.
        </p>

        <div className="card-divider" />

        <h3>8. Your rights</h3>
        <p>You have the right to:</p>
        <ul>
          <li>Access and request copies of your personal data</li>
          <li>Request corrections or updates to inaccurate information</li>
          <li>Withdraw consent or request deletion where legally permissible</li>
          <li>Object to certain processing activities</li>
        </ul>
        <p>
          To exercise your rights, contact us at connect@yourdomain.ae or +971 0 000 0000 (placeholders). We will respond
          within the timelines specified by UAE law.
        </p>

        <div className="card-divider" />

        <h3>9. International data transfers</h3>
        <p>
          If data is transferred outside the UAE, we ensure adequate protection through contractual safeguards and
          compliance with applicable data protection regulations.
        </p>

        <div className="card-divider" />

        <h3>10. Updates to this policy</h3>
        <p>
          We may update this Privacy Policy to reflect legal changes or service enhancements. Updates will be posted on
          this page with a revised &quot;Last updated&quot; date.
        </p>

        <div className="card-divider" />

        <h3>11. Contact</h3>
        <p>
          For privacy inquiries or complaints, please contact our Data Protection Officer at connect@yourdomain.ae or
          call +971 0 000 0000 (placeholders). You may also contact the UAE Data Office if concerns remain unresolved.
        </p>
      </article>
    </section>
  </Page>
);

export default Privacy;