import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Page from '../components/Page';
import { products } from '../data/products';

const Products = () => {
  const categories = Array.from(new Set(products.map((product) => product.category)));

  return (
    <Page className="products-page">
      <Helmet>
        <title>Medical Equipment Catalogue | Emirates HealthTech Supplies</title>
        <meta
          name="description"
          content="Browse our UAE-ready medical equipment catalogue covering monitoring, respiratory, telehealth, infection control, and mobility solutions."
        />
      </Helmet>

      <header className="page-header">
        <h1>Medical equipment catalogue</h1>
        <p>
          Explore premium devices for acute care, diagnostics, home-care, and rehabilitative services. Every product is
          backed by regulatory compliance, localized documentation, and UAE-wide servicing.
        </p>
      </header>

      <section className="section" aria-labelledby="category-summary">
        <div className="section-header" id="category-summary">
          <h2>Categories at a glance</h2>
          <p>Select a category tag to focus your consultation request.</p>
        </div>
        <div className="tag-cloud">
          {categories.map((category) => (
            <span className="tag" key={category}>
              {category}
            </span>
          ))}
        </div>
      </section>

      <section className="product-grid" aria-label="Product list">
        {products.map((product) => (
          <motion.article
            key={product.id}
            className="product-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.45 }}
          >
            <div className="product-media">
              <img src={product.image} alt={product.name} loading="lazy" />
              <span className="product-category">{product.category}</span>
            </div>
            <div className="product-content">
              <h3>{product.name}</h3>
              <p>{product.description}</p>
              <ul className="product-features">
                {product.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <div className="product-meta">
                <span>
                  <strong>Regulatory:</strong> {product.regulatory}
                </span>
                <span>
                  <strong>Support:</strong> {product.support}
                </span>
              </div>
              <Link to="/contact" className="btn btn-inline">
                Request quotation or demo
              </Link>
            </div>
          </motion.article>
        ))}
      </section>

      <section className="section" aria-labelledby="product-callout">
        <div className="callout-card">
          <strong>Need help building a compliant equipment roadmap?</strong>
          <p className="small-muted">
            Our biomedical consultants map equipment lifecycle plans, training, and financing tailored to your
            organisation or home-care setting.
          </p>
          <div className="section-footer">
            <Link to="/contact" className="btn btn-primary">
              Schedule a planning session
            </Link>
            <Link to="/faq" className="btn btn-outline">
              Read common procurement FAQs
            </Link>
          </div>
        </div>
      </section>
    </Page>
  );
};

export default Products;