import React from 'react';
import { Helmet } from 'react-helmet-async';
import Page from '../components/Page';

const Terms = () => (
  <Page className="terms-page">
    <Helmet>
      <title>Terms of Service | Emirates HealthTech Supplies</title>
      <meta
        name="description"
        content="Review the terms of service governing the use of Emirates HealthTech Supplies medical equipment and services in the UAE."
      />
    </Helmet>

    <header className="page-header">
      <h1>Terms of Service</h1>
      <p>Last updated: March 2024</p>
    </header>

    <section className="section" aria-label="Terms of Service">
      <article className="glass-card">
        <h3>1. Agreement overview</h3>
        <p>
          These Terms of Service (&quot;Terms&quot;) govern the provision of medical equipment, services, and digital
          resources by Emirates HealthTech Supplies LLC (&quot;we&quot;, &quot;us&quot;, &quot;our&quot;) to clients and
          caregivers within the United Arab Emirates. By accessing our website, requesting a quotation, or purchasing
          equipment, you agree to comply with these Terms.
        </p>

        <div className="card-divider" />

        <h3>2. Services and equipment supply</h3>
        <p>
          Equipment sales, rentals, and servicing are subject to written quotations and acceptance forms. We reserve the
          right to substitute equivalent products if required by regulatory or supply conditions, with prior written
          notice. All equipment remains the property of Emirates HealthTech Supplies until payment is received in full.
        </p>

        <div className="card-divider" />

        <h3>3. Regulatory compliance</h3>
        <p>
          We supply products that comply with applicable UAE regulations (MOHAP, DOH, DHA) and international standards
          (FDA, CE, ISO). Clients are responsible for ensuring local facility licensing requirements are met. We provide
          documentation and product training to support compliance.
        </p>

        <div className="card-divider" />

        <h3>4. Training and usage responsibilities</h3>
        <p>
          Caregivers and clinical staff must complete the provided training before operating equipment. Improper use,
          modification, or unauthorised repair may void warranties and service agreements. We encourage ongoing training
          refreshers, especially for home-care environments caring for elderly patients.
        </p>

        <div className="card-divider" />

        <h3>5. Warranty and maintenance</h3>
        <p>
          Standard manufacturer warranties apply in addition to our service-level agreements. Preventive maintenance
          schedules must be followed to keep warranties valid. Clients should notify us immediately of any malfunction
          or alarm that cannot be resolved following provided procedures.
        </p>

        <div className="card-divider" />

        <h3>6. Liability limitations</h3>
        <p>
          We are not liable for any indirect, incidental, or consequential damages arising from the use or inability to
          use equipment, except where such limitation is prohibited by UAE law. Liability is limited to the total amount
          paid for the equipment or service giving rise to the claim.
        </p>

        <div className="card-divider" />

        <h3>7. Data protection</h3>
        <p>
          We handle personal data in accordance with UAE Federal Decree-Law No. 45 of 2021 on Personal Data Protection.
          Please review our Privacy Policy for details on data handling, telehealth platforms, and caregiver support
          records.
        </p>

        <div className="card-divider" />

        <h3>8. Payment terms</h3>
        <p>
          Payment terms are outlined in each quotation. Late payments may incur service suspension or finance charges.
          Rental equipment must be returned in good condition; damage fees may apply for misuse or loss.
        </p>

        <div className="card-divider" />

        <h3>9. Governing law and dispute resolution</h3>
        <p>
          These Terms are governed by the laws of the United Arab Emirates. Disputes will first be addressed through good
          faith negotiation. If unresolved, disputes shall be referred to the competent courts of Dubai, unless an
          alternative arbitration agreement exists.
        </p>

        <div className="card-divider" />

        <h3>10. Contact</h3>
        <p>
          For any questions regarding these Terms, please contact us at +971 0 000 0000 or connect@yourdomain.ae
          (placeholders). We encourage caregivers and clients to seek clarification before using any medical equipment.
        </p>
      </article>
    </section>
  </Page>
);

export default Terms;