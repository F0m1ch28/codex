import React from 'react';
import { Helmet } from 'react-helmet-async';
import Page from '../components/Page';
import Accordion from '../components/Accordion';
import { faqs } from '../data/faqs';
import { Link } from 'react-router-dom';

const FAQ = () => (
  <Page className="faq-page">
    <Helmet>
      <title>Frequently Asked Questions | Emirates HealthTech Supplies</title>
      <meta
        name="description"
        content="Find answers to common questions about installation, caregiver training, maintenance, and compliance for medical equipment in the UAE."
      />
    </Helmet>

    <header className="page-header">
      <h1>Frequently asked questions</h1>
      <p>
        Answers to the most common questions from facilities and caregivers. If you cannot find what you need, our
        bilingual support team is ready to help.
      </p>
    </header>

    <section className="section" aria-label="Frequently asked questions">
      <Accordion items={faqs} />
      <div className="section-footer">
        <Link to="/contact" className="btn btn-primary">
          Contact our support specialists
        </Link>
        <span className="small-muted">
          24/7 hotline available for active service agreements and home-care plans.
        </span>
      </div>
    </section>
  </Page>
);

export default FAQ;