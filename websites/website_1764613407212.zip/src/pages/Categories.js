import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Page from '../components/Page';
import { categories } from '../data/categories';

const Categories = () => (
  <Page className="categories-page">
    <Helmet>
      <title>Medical Equipment Categories | Emirates HealthTech Supplies</title>
      <meta
        name="description"
        content="Discover medical equipment categories including critical care, respiratory, diagnostics, infection control, mobility, and home-care solutions."
      />
    </Helmet>

    <header className="page-header">
      <h1>Equipment categories engineered for the UAE</h1>
      <p>
        Each category is curated by clinical specialists to meet the requirements of healthcare facilities, community
        organisations, and family caregivers. Interfaces and documentation are available in English and Arabic to suit
        multicultural teams.
      </p>
    </header>

    <section className="section" aria-label="Medical equipment categories">
      <div className="category-grid">
        {categories.map((category) => (
          <motion.article
            key={category.id}
            className="category-card"
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.45 }}
          >
            <img src={category.image} alt={category.name} loading="lazy" />
            <span className="badge">{category.name}</span>
            <h3>{category.name}</h3>
            <p>{category.description}</p>
            <ul>
              {category.solutions.map((solution) => (
                <li key={solution}>{solution}</li>
              ))}
            </ul>
          </motion.article>
        ))}
      </div>
      <div className="section-footer">
        <Link to="/products" className="btn btn-primary">
          View recommended devices
        </Link>
        <Link to="/contact" className="btn btn-outline">
          Consult our biomedical team
        </Link>
      </div>
    </section>

    <section className="section" aria-labelledby="roadmap">
      <div className="callout-card">
        <h3 id="roadmap">Need guidance selecting the right category?</h3>
        <p>
          We provide bespoke technology roadmaps, total cost of ownership analysis, and multilingual training plans for
          both clinical staff and family caregivers.
        </p>
        <div className="section-footer">
          <Link to="/contact" className="btn btn-primary">
            Talk to an advisor
          </Link>
        </div>
      </div>
    </section>
  </Page>
);

export default Categories;