import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import Page from '../components/Page';
import { products } from '../data/products';

const featureCards = [
  {
    title: 'Clinically proven technology',
    description:
      'Curated portfolio of international brands endorsed by UAE physicians, with documented outcomes and MOHAP registration.',
    icon: '🩺',
  },
  {
    title: 'Rapid deployment & servicing',
    description:
      'Strategic stock in Dubai and Abu Dhabi enables same-week delivery and four-hour service response for critical devices.',
    icon: '⚡',
  },
  {
    title: 'Caregiver-first support',
    description:
      'Training designed for elderly caregivers with clear language, large-print guides, and always-on tele-support.',
    icon: '🤝',
  },
  {
    title: 'Compliance you can trust',
    description:
      'Audit-ready documentation, DHA/DOH liaison, and preventive maintenance logs aligned with UAE regulatory standards.',
    icon: '✅',
  },
];

const trustSegments = [
  {
    title: 'Hospitals & Specialty Clinics',
    description:
      'Integrated solutions for ICU, cardiology, oncology, long-term ventilation, and rehabilitative medicine.',
  },
  {
    title: 'Home-care Providers',
    description:
      'Complete care kits, telehealth, and caregiver education ensuring safe hospital-to-home transitions.',
  },
  {
    title: 'Wellness & Corporate Health',
    description:
      'Screening, diagnostics, and rapid-response equipment for corporate clinics, schools, and wellness centers.',
  },
  {
    title: 'Government & Humanitarian Programs',
    description:
      'Robust equipment suites with Arabic/English support for community health initiatives and mobile deployments.',
  },
];

const caregiverHighlights = [
  {
    title: 'Personalised onboarding',
    description:
      'One-to-one device familiarisation with culturally sensitive trainers, tailored for multi-generational households.',
    list: ['Arabic and English materials', 'Emergency procedures', 'Follow-up wellbeing checks'],
  },
  {
    title: 'Home safety evaluation',
    description:
      'Safety risk assessments covering space planning, infection control, and power backup recommendations.',
    list: ['Environmental audit checklist', 'Fall prevention tools', 'CNA-led coaching'],
  },
  {
    title: 'Connected care pathway',
    description:
      'Secure telehealth monitoring with clinician dashboards and caregiver notifications for vital changes.',
    list: ['Encrypted data for MOHAP compliance', 'Custom alerts for caregivers', 'Integration with HIS/EMR'],
  },
];

const stats = [
  { value: '20+ years', label: 'Biomedical expertise in the GCC' },
  { value: '500+', label: 'Healthcare sites equipped across the Emirates' },
  { value: '4 hr', label: 'On-site engineer response in major cities' },
  { value: '100%', label: 'Bilingual documentation availability' },
];

const Home = () => {
  const flagshipProducts = products.slice(0, 3);

  return (
    <Page className="home-page">
      <Helmet>
        <title>Medical Equipment UAE | Emirates HealthTech Supplies</title>
        <meta
          name="description"
          content="Advanced medical equipment, home-care solutions, and caregiver support for healthcare providers across the UAE."
        />
      </Helmet>

      <section className="hero">
        <div className="hero-grid">
          <div className="hero-content">
            <span className="hero-eyebrow">Trusted medical technology for the UAE</span>
            <h1>
              Premium medical equipment and compassionate support for clinicians, families, and caregivers across the
              Emirates.
            </h1>
            <p>
              Delivering end-to-end solutions from specification and procurement to training, telemetry, and lifecycle
              servicing — helping you provide dignified, high-quality care to every patient.
            </p>
            <div className="hero-cta">
              <Link to="/products" className="btn btn-primary">
                Explore equipment catalogue
              </Link>
              <Link to="/contact" className="btn btn-outline">
                Request a consultation
              </Link>
            </div>
            <div className="hero-stats">
              {stats.map((stat) => (
                <motion.div
                  key={stat.label}
                  className="stat-card"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.4 }}
                  transition={{ duration: 0.5 }}
                >
                  <strong>{stat.value}</strong>
                  <span>{stat.label}</span>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="hero-media">
            <div className="hero-image-wrapper">
              <img
                src="https://cdn.pixabay.com/photo/2017/08/06/01/03/ecg-2585383_1280.jpg"
                alt="Clinician monitoring a patient with advanced medical equipment"
                loading="lazy"
              />
              <div className="floating-card">
                <strong>MOHAP-compliant inventory</strong>
                <span>Ready-to-ship stock staged in Dubai and Abu Dhabi with express installation.</span>
              </div>
              <div className="floating-badge" aria-hidden="true">
                24/7 engineer support
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="why-partner">
        <div className="section-header" id="why-partner">
          <h2>Why leading UAE providers partner with us</h2>
          <p>
            From tertiary hospitals to family caregivers, our multidisciplinary team aligns clinical excellence with
            cultural sensitivity and operational reliability.
          </p>
        </div>
        <div className="feature-grid">
          {featureCards.map((card) => (
            <motion.article
              key={card.title}
              className="feature-card"
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.45 }}
            >
              <div className="card-icon" aria-hidden="true">
                {card.icon}
              </div>
              <h3>{card.title}</h3>
              <p>{card.description}</p>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section" aria-labelledby="flagship">
        <div className="section-header" id="flagship">
          <h2>Flagship equipment ready for immediate delivery</h2>
          <p>
            Clinically validated devices spanning monitoring, respiratory care, and telehealth kits — curated for the
            UAE’s diverse patient population.
          </p>
        </div>
        <div className="product-highlight-grid">
          {flagshipProducts.map((product) => (
            <motion.article
              key={product.id}
              className="product-highlight"
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.45 }}
            >
              <span>{product.category}</span>
              <img src={product.image} alt={product.name} loading="lazy" />
              <h3>{product.name}</h3>
              <p>{product.description}</p>
              <ul>
                {product.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <Link to="/products" className="btn btn-inline">
                View product details
              </Link>
            </motion.article>
          ))}
        </div>
        <div className="section-footer">
          <Link to="/products" className="btn btn-ghost">
            Browse the complete catalogue
          </Link>
          <span className="small-muted">Installation, training, and lifecycle maintenance included.</span>
        </div>
      </section>

      <section className="section" aria-labelledby="caregiver-support">
        <div className="section-header" id="caregiver-support">
          <h2>Support tailored for caregivers and families</h2>
          <p>
            We build confidence for caregivers of all experience levels through human-centered training, safety
            planning, and tele-support that respects cultural and linguistic preferences.
          </p>
        </div>
        <div className="caregiver-support-grid">
          {caregiverHighlights.map((item) => (
            <motion.article
              key={item.title}
              className="caregiver-card"
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.45 }}
            >
              <div className="card-icon" aria-hidden="true">
                🤲
              </div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <ul>
                {item.list.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
        <div className="section-footer">
          <Link to="/for-caregivers" className="btn btn-primary">
            Explore caregiver resources
          </Link>
          <Link to="/faq" className="btn btn-outline">
            Read caregiver FAQs
          </Link>
        </div>
      </section>

      <section className="section" aria-labelledby="cta">
        <div className="cta-banner" id="cta">
          <div>
            <h2>Ready to equip your facility or loved one with confidence?</h2>
            <p>
              Our clinical engineers and biomedical specialists provide tailored recommendations, technology roadmaps,
              and training to keep every care environment safe, compliant, and reassuring.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn-primary">
              Book a strategy session
            </Link>
            <a className="btn btn-outline" href="tel:+971000000000">
              Call us (placeholder)
            </a>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="trust">
        <div className="section-header" id="trust">
          <h2>Serving healthcare leaders across the Emirates</h2>
          <p>
            We partner with public and private healthcare providers to deliver continuity of care and culturally aware
            patient experiences.
          </p>
        </div>
        <div className="trust-grid">
          {trustSegments.map((segment) => (
            <motion.article
              key={segment.title}
              className="trust-card"
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.45 }}
            >
              <h3>{segment.title}</h3>
              <p>{segment.description}</p>
            </motion.article>
          ))}
        </div>
      </section>
    </Page>
  );
};

export default Home;