import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import Page from '../components/Page';

const Contact = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <Page className="contact-page">
      <Helmet>
        <title>Contact & Inquiries | Emirates HealthTech Supplies</title>
        <meta
          name="description"
          content="Contact Emirates HealthTech Supplies for medical equipment consultations, service support, and caregiver guidance across the UAE."
        />
      </Helmet>

      <header className="page-header">
        <h1>Contact & inquiries</h1>
        <p>
          Reach our clinical consultants, biomedical engineers, or caregiver support team via the form below. We respond
          within one business day and offer urgent assistance 24/7 for active service agreements.
        </p>
      </header>

      <section className="contact-grid" aria-label="Contact information">
        <div className="contact-card">
          <h3>Direct communication (placeholders)</h3>
          <ul>
            <li>
              <strong>Phone:</strong>
              +971 0 000 0000
            </li>
            <li>
              <strong>Email:</strong>
              connect@yourdomain.ae
            </li>
            <li>
              <strong>WhatsApp (Caregiver hotline):</strong>
              +971 0 000 0001
            </li>
            <li>
              <strong>Head office:</strong>
              Level X, Business Tower, Sheikh Zayed Road, Dubai, UAE
            </li>
            <li>
              <strong>Service hours:</strong>
              Sunday – Thursday, 08:00 to 18:00 GST
            </li>
          </ul>
        </div>

        <div className="contact-card">
          <h3>Submit an inquiry</h3>
          <form className="contact-form" onSubmit={handleSubmit}>
            <label htmlFor="name">Full name</label>
            <input id="name" name="name" type="text" required placeholder="Your name" />

            <label htmlFor="email">Email address</label>
            <input id="email" name="email" type="email" required placeholder="you@example.com" />

            <label htmlFor="phone">Phone number</label>
            <input id="phone" name="phone" type="tel" required placeholder="+971 ..." />

            <label htmlFor="organisation">Organisation (if applicable)</label>
            <input id="organisation" name="organisation" type="text" placeholder="Hospital, clinic, or home-care provider" />

            <label htmlFor="interest">Area of interest</label>
            <select id="interest" name="interest" required>
              <option value="">Select a category</option>
              <option value="critical-care">Critical & Acute Care</option>
              <option value="respiratory">Respiratory & Sleep Support</option>
              <option value="diagnostics">Diagnostics & Telehealth</option>
              <option value="mobility">Mobility & Rehabilitation</option>
              <option value="infection">Infection Prevention</option>
              <option value="caregiver">Caregiver training & support</option>
              <option value="other">Other</option>
            </select>

            <label htmlFor="message">How can we support you?</label>
            <textarea
              id="message"
              name="message"
              required
              placeholder="Provide details so we can tailor our response."
            />

            <button type="submit" className="btn btn-primary">
              Submit inquiry
            </button>

            {submitted && (
              <div className="success-message" role="status">
                Thank you. Our team will contact you within one business day. For urgent matters, please call our hotline
                (placeholder) +971 0 000 0000.
              </div>
            )}
          </form>
        </div>

        <div className="contact-card">
          <h3>Service coverage</h3>
          <p>
            We provide on-site support throughout the UAE. Strategic hubs in Dubai and Abu Dhabi ensure rapid response
            for critical equipment.
          </p>
          <div className="map-placeholder">
            Interactive map placeholder — integrate preferred mapping solution or Google Maps embed.
          </div>
          <ul>
            <li>Same-day engineer dispatch in Dubai and Abu Dhabi</li>
            <li>Next-day service to Sharjah, Ajman, and Ras Al Khaimah</li>
            <li>Scheduled support in Fujairah and Umm Al Quwain</li>
          </ul>
        </div>
      </section>
    </Page>
  );
};

export default Contact;