import React from 'react';
import { Helmet } from 'react-helmet-async';
import Page from '../components/Page';

const values = [
  {
    title: 'Clinical excellence',
    description:
      'We collaborate with physicians, nurses, and biomedical engineers to ensure every solution is clinically effective and audit-ready.',
  },
  {
    title: 'Human-centered care',
    description:
      'We design experiences for caregivers and patients with empathy, accessibility, and cultural respect at the forefront.',
  },
  {
    title: 'Reliability and responsiveness',
    description:
      'Our logistics, service teams, and tele-support operate around the clock to keep equipment performing when lives depend on it.',
  },
  {
    title: 'Sustainable impact',
    description:
      'We pursue energy-efficient technologies, responsible disposal, and carbon-conscious logistics across the Emirates.',
  },
];

const timeline = [
  {
    year: '2004',
    milestone: 'Launched biomedical engineering services for Dubai and Abu Dhabi hospitals.',
  },
  {
    year: '2010',
    milestone: 'Expanded portfolio with respiratory and home-care solutions tailored to elderly patients.',
  },
  {
    year: '2016',
    milestone: 'Introduced bilingual training programmes and tele-support for caregivers in all seven Emirates.',
  },
  {
    year: '2020',
    milestone:
      'Deployed rapid-response telehealth kits during the pandemic, supporting community clinics and humanitarian organisations.',
  },
  {
    year: '2023',
    milestone:
      'Achieved ISO 13485-aligned quality system updates and launched AI-enabled predictive maintenance platform.',
  },
];

const About = () => (
  <Page className="about-page">
    <Helmet>
      <title>About Emirates HealthTech Supplies | Medical Equipment UAE</title>
      <meta
        name="description"
        content="Learn about Emirates HealthTech Supplies, our mission, values, certifications, and commitment to UAE healthcare providers and caregivers."
      />
    </Helmet>

    <header className="page-header">
      <h1>Committed to elevating healthcare technology across the UAE</h1>
      <p>
        Emirates HealthTech Supplies unites biomedical expertise, compassionate training, and regulatory knowledge to
        empower clinicians, patients, and caregivers. Our multidisciplinary team serves public and private providers,
        NGOs, and families with equal dedication.
      </p>
    </header>

    <section className="section" aria-labelledby="mission">
      <div className="section-header" id="mission">
        <h2>Our mission</h2>
        <p>
          To deliver advanced medical technology and empathetic support that improves patient outcomes and caregiver
          confidence throughout the Emirates, ensuring culturally respectful care for every community we serve.
        </p>
      </div>
      <div className="feature-grid">
        {values.map((value) => (
          <article className="feature-card" key={value.title}>
            <div className="card-icon" aria-hidden="true">
              🌟
            </div>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className="section" aria-labelledby="timeline">
      <div className="section-header" id="timeline">
        <h2>Two decades of care innovation</h2>
        <p>
          From single-site service contracts to national telehealth deployments, we have grown with the UAE’s healthcare
          system while staying rooted in reliability and trust.
        </p>
      </div>
      <div className="timeline-grid">
        {timeline.map((item) => (
          <article className="timeline-card" key={item.year}>
            <h3>{item.year}</h3>
            <p>{item.milestone}</p>
          </article>
        ))}
      </div>
    </section>

    <section className="section" aria-labelledby="assurance">
      <div className="callout-card">
        <h3 id="assurance">Certifications & memberships</h3>
        <ul>
          <li>ISO 13485-aligned quality management and ISO 45001 HSE framework</li>
          <li>Registered supplier with MOHAP, DOH Abu Dhabi, and DHA Dubai</li>
          <li>Member of the Association for the Advancement of Medical Instrumentation (AAMI)</li>
          <li>Partner network across GCC for rapid cross-border support</li>
        </ul>
        <div className="section-footer">
          <p className="small-muted">
            Documentation available on request for tender submissions and accreditation audits.
          </p>
        </div>
      </div>
    </section>
  </Page>
);

export default About;