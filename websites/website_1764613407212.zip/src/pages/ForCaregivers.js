import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Page from '../components/Page';

const caregiverServices = [
  {
    title: 'Bilingual onboarding sessions',
    description:
      'In-home or virtual training delivered in English, Arabic, and other requested languages with simple terminology and visual guidance.',
    points: ['Recorded walkthroughs for future reference', 'Cultural sensitivity and privacy awareness', 'Family-inclusive sessions'],
  },
  {
    title: 'Care environment preparation',
    description:
      'Room planning, infection control protocols, power safety checks, and accessibility adjustments aligned with UAE housing layouts.',
    points: ['Electrical load and backup assessments', 'Slip, trip, and fall prevention strategies', 'Telehealth connectivity setup'],
  },
  {
    title: 'Clinical hotline & tele-support',
    description:
      '24/7 access to clinical educators and biomedical engineers for alarm interpretation, device troubleshooting, and reassurance.',
    points: ['WhatsApp and phone support options', 'Escalation protocols to emergency services', 'Loaner equipment coordination'],
  },
];

const wellnessTips = [
  'Designate a calm care space with easy-to-clean surfaces and natural light.',
  'Store medication and consumables in clearly labeled, high-contrast containers.',
  'Document daily observations with our printable logs to share with physicians.',
  'Schedule respite breaks and hydration reminders for caregivers.',
];

const ForCaregivers = () => (
  <Page className="caregivers-page">
    <Helmet>
      <title>Caregiver Resources | Emirates HealthTech Supplies</title>
      <meta
        name="description"
        content="Caregiver-focused resources including training, home safety, tele-support, and wellness guidance for families across the UAE."
      />
    </Helmet>

    <header className="page-header">
      <h1>Caregiver resources for dignified home care</h1>
      <p>
        We understand the emotional and practical responsibilities of caring for loved ones. Our caregiver programme
        provides simple guidance, culturally respectful education, and around-the-clock support to keep everyone safe and
        confident.
      </p>
    </header>

    <section className="section" aria-label="Caregiver services">
      <div className="caregiver-support-grid">
        {caregiverServices.map((service) => (
          <motion.article
            key={service.title}
            className="caregiver-card"
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.35 }}
            transition={{ duration: 0.45 }}
          >
            <div className="card-icon" aria-hidden="true">
              🧡
            </div>
            <h3>{service.title}</h3>
            <p>{service.description}</p>
            <ul>
              {service.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </motion.article>
        ))}
      </div>
    </section>

    <section className="section" aria-labelledby="care-journey">
      <div className="section-header" id="care-journey">
        <h2>A compassionate care journey aligned with your family’s needs</h2>
        <p>
          From hospital discharge planning to long-term rehabilitation, we stay by your side with proactive check-ins,
          safety reviews, and wellness support.
        </p>
      </div>
      <div className="timeline-grid">
        <motion.article
          className="timeline-card"
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.45 }}
        >
          <h3>1. Transition planning</h3>
          <p>
            Collaborate with hospital discharge teams to align equipment, medication, and caregiver readiness. We review
            MOHAP care plans and align them with your home environment.
          </p>
        </motion.article>
        <motion.article
          className="timeline-card"
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.45, delay: 0.1 }}
        >
          <h3>2. Setup & personalisation</h3>
          <p>
            Engineers deliver and calibrate equipment, while educators customise alarm thresholds, care logs, and
            accessibility aids to your preferences.
          </p>
        </motion.article>
        <motion.article
          className="timeline-card"
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.45, delay: 0.2 }}
        >
          <h3>3. Ongoing support</h3>
          <p>
            Routine check-ins, consumable management, and telehealth reviews keep clinicians informed and caregivers
            reassured.
          </p>
        </motion.article>
      </div>
    </section>

    <section className="section" aria-labelledby="wellness">
      <div className="callout-card">
        <h3 id="wellness">Wellness tips for caregivers</h3>
        <p className="small-muted">Practical suggestions to maintain wellbeing while providing attentive care.</p>
        <ul>
          {wellnessTips.map((tip) => (
            <li key={tip}>{tip}</li>
          ))}
        </ul>
        <div className="section-footer">
          <Link to="/faq" className="btn btn-ghost">
            Explore frequently asked questions
          </Link>
          <Link to="/contact" className="btn btn-primary">
            Speak with a caregiver consultant
          </Link>
        </div>
      </div>
    </section>
  </Page>
);

export default ForCaregivers;