import React, { createContext, useContext, useEffect, useMemo } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';

const AccessibilityContext = createContext();

const getSystemTheme = () => {
  if (typeof window === 'undefined') {
    return 'light';
  }
  return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};

export const AccessibilityProvider = ({ children }) => {
  const [mode, setMode] = useLocalStorage('theme-mode', getSystemTheme());
  const [highContrast, setHighContrast] = useLocalStorage('theme-contrast', false);
  const [textScale, setTextScale] = useLocalStorage('theme-text-scale', 1);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', mode);
  }, [mode]);

  useEffect(() => {
    document.documentElement.setAttribute('data-contrast', highContrast ? 'high' : 'normal');
  }, [highContrast]);

  useEffect(() => {
    document.documentElement.style.setProperty('--text-scale', textScale);
  }, [textScale]);

  const value = useMemo(
    () => ({
      mode,
      toggleMode: () => setMode((prev) => (prev === 'light' ? 'dark' : 'light')),
      highContrast,
      toggleHighContrast: () => setHighContrast((prev) => !prev),
      textScale,
      increaseText: () => setTextScale((prev) => Math.min(prev + 0.1, 1.5)),
      decreaseText: () => setTextScale((prev) => Math.max(prev - 0.1, 0.9)),
      resetText: () => setTextScale(1),
    }),
    [mode, setMode, highContrast, setHighContrast, textScale, setTextScale]
  );

  return <AccessibilityContext.Provider value={value}>{children}</AccessibilityContext.Provider>;
};

export const useAccessibility = () => useContext(AccessibilityContext);