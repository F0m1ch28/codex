import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import AccessibilityControls from './AccessibilityControls';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/products', label: 'Products' },
  { to: '/categories', label: 'Categories' },
  { to: '/for-caregivers', label: 'For Caregivers' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
  { to: '/faq', label: 'FAQ' },
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <header className="site-header" role="banner">
      <div className="header-inner">
        <Link to="/" className="logo" aria-label="Emirates HealthTech Supplies home">
          <span className="logo-mark">EHT</span>
          <span className="logo-text">
            <span>Emirates</span>
            <span>HealthTech Supplies</span>
          </span>
        </Link>

        <button
          type="button"
          className="mobile-menu-button"
          aria-label="Toggle navigation menu"
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span>{menuOpen ? 'Close' : 'Menu'}</span>
        </button>

        <nav
          id="primary-navigation"
          className={`primary-nav ${menuOpen ? 'is-open' : ''}`}
          aria-label="Primary navigation"
        >
          <ul>
            {navLinks.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                  end={link.to === '/'}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>

          <div className="mobile-utility">
            <AccessibilityControls variant="stacked" />
            <Link to="/contact" className="btn btn-primary full-width">
              Contact our team
            </Link>
          </div>
        </nav>

        <div className="header-actions">
          <AccessibilityControls />
          <Link to="/contact" className="btn btn-outline btn-small header-contact-btn">
            Contact
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;