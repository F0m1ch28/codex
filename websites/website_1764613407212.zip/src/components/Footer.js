import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer" role="contentinfo">
    <div className="footer-grid">
      <div className="footer-column">
        <h3>Emirates HealthTech Supplies</h3>
        <p>
          Premium, clinically proven medical technology with compassionate support tailored to healthcare providers,
          families, and caregivers across the United Arab Emirates.
        </p>
        <p className="small-muted">
          Serving hospitals, specialty clinics, home-care providers, and wellness centers in Abu Dhabi, Dubai, Sharjah,
          Ajman, Ras Al Khaimah, Fujairah, and Umm Al Quwain.
        </p>
      </div>

      <div className="footer-column">
        <h3>Contact (placeholders)</h3>
        <ul className="footer-contact">
          <li>
            <strong>Phone (placeholder):</strong>
            +971 0 000 0000
          </li>
          <li>
            <strong>Email (placeholder):</strong>
            connect@yourdomain.ae
          </li>
          <li>
            <strong>Head office (placeholder):</strong>
            Level X, Business Tower, Sheikh Zayed Road, Dubai, UAE
          </li>
          <li>
            <strong>Operating hours:</strong>
            Sunday – Thursday, 8:00 – 18:00 GST
          </li>
        </ul>
      </div>

      <div className="footer-column">
        <h3>Quick access</h3>
        <ul>
          <li>
            <Link to="/products">Product catalogue</Link>
          </li>
          <li>
            <Link to="/categories">Equipment categories</Link>
          </li>
          <li>
            <Link to="/for-caregivers">Caregiver guidance</Link>
          </li>
          <li>
            <Link to="/faq">Frequently asked questions</Link>
          </li>
          <li>
            <Link to="/about">About our team</Link>
          </li>
        </ul>
      </div>

      <div className="footer-column">
        <h3>Compliance & assurance</h3>
        <ul>
          <li>ISO 13485 quality management aligned</li>
          <li>UAE MOHAP, DOH, and DHA registration support</li>
          <li>Arabic and English user documentation available</li>
          <li>24/7 technical hotline with clinical engineers</li>
          <li>Net-zero ready service fleet across the Emirates</li>
        </ul>
      </div>
    </div>

    <div className="footer-bottom">
      <span>© {new Date().getFullYear()} Emirates HealthTech Supplies LLC. All rights reserved.</span>
      <div className="footer-links">
        <Link to="/terms">Terms of Service</Link>
        <Link to="/privacy">Privacy Policy</Link>
      </div>
    </div>
  </footer>
);

export default Footer;