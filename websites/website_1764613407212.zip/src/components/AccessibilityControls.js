import React from 'react';
import clsx from 'clsx';
import { useAccessibility } from '../context/AccessibilityContext';

const AccessibilityControls = ({ variant = 'inline' }) => {
  const {
    textScale,
    increaseText,
    decreaseText,
    resetText,
    highContrast,
    toggleHighContrast,
    mode,
    toggleMode,
  } = useAccessibility();

  const scalePercent = Math.round(textScale * 100);

  return (
    <div
      className={clsx('accessibility-controls', {
        stacked: variant === 'stacked',
      })}
      role="group"
      aria-label="Accessibility controls"
    >
      <div className="accessibility-group" role="group" aria-label="Adjust text size">
        <span className="accessibility-label" aria-hidden="true">
          Text size
        </span>
        <div className="control-buttons">
          <button
            type="button"
            onClick={decreaseText}
            aria-label="Reduce text size"
            disabled={textScale <= 0.9}
          >
            A−
          </button>
          <button type="button" onClick={resetText} aria-label="Reset text size">
            A
          </button>
          <button
            type="button"
            onClick={increaseText}
            aria-label="Increase text size"
            disabled={textScale >= 1.5}
          >
            A+
          </button>
        </div>
        <span className="control-indicator" aria-live="polite">
          {scalePercent}%
        </span>
      </div>

      <div className="accessibility-group" role="group" aria-label="Display preferences">
        <button
          type="button"
          className="toggle-button"
          onClick={toggleMode}
          aria-pressed={mode === 'dark'}
          aria-label={`Switch to ${mode === 'light' ? 'dark' : 'light'} mode`}
        >
          {mode === 'light' ? '🌞 Light' : '🌙 Dark'}
        </button>
        <button
          type="button"
          className="toggle-button"
          onClick={toggleHighContrast}
          aria-pressed={highContrast}
          aria-label="Toggle high contrast mode"
        >
          {highContrast ? 'High contrast on' : 'High contrast'}
        </button>
      </div>
    </div>
  );
};

export default AccessibilityControls;