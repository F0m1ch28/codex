import React from 'react';
import { Link } from 'react-router-dom';
import useLocalStorage from '../hooks/useLocalStorage';

const CookieBanner = () => {
  const [consent, setConsent] = useLocalStorage('cookie-consent', null);

  if (consent !== null) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent">
      <p>
        We use cookies to enhance browsing, analyse website performance, and provide personalised support for UAE-based
        healthcare professionals and caregivers. Manage your preferences at any time in our{' '}
        <Link to="/privacy">Privacy Policy</Link>.
      </p>
      <div className="cookie-actions">
        <button type="button" className="btn btn-outline" onClick={() => setConsent('declined')}>
          Decline
        </button>
        <button type="button" className="btn btn-primary" onClick={() => setConsent('accepted')}>
          Accept all cookies
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;