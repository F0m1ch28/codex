import React from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { AnimatePresence } from 'framer-motion';

import Layout from './components/Layout';
import ScrollToTop from './components/ScrollToTop';
import CookieBanner from './components/CookieBanner';
import { AccessibilityProvider } from './context/AccessibilityContext';

import Home from './pages/Home';
import Products from './pages/Products';
import Categories from './pages/Categories';
import ForCaregivers from './pages/ForCaregivers';
import About from './pages/About';
import Contact from './pages/Contact';
import FAQ from './pages/FAQ';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

function AnimatedRoutes() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait" initial={false}>
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/for-caregivers" element={<ForCaregivers />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <HelmetProvider>
      <AccessibilityProvider>
        <BrowserRouter>
          <ScrollToTop />
          <Layout>
            <AnimatedRoutes />
          </Layout>
          <CookieBanner />
        </BrowserRouter>
      </AccessibilityProvider>
    </HelmetProvider>
  );
}