document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!isOpen).toString());
      primaryNav.classList.toggle('is-open', !isOpen);
      body.classList.toggle('nav-open', !isOpen);
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        primaryNav.classList.remove('is-open');
        body.classList.remove('nav-open');
      });
    });
  }

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie="accept"]');
  const declineBtn = document.querySelector('[data-cookie="decline"]');
  const storageKey = 'iteb-cookie-consent';

  if (banner && acceptBtn && declineBtn) {
    let savedChoice = null;
    try {
      savedChoice = localStorage.getItem(storageKey);
    } catch (error) {
      console.warn('Storage unavailable', error);
    }

    if (!savedChoice) {
      banner.style.display = 'block';
      requestAnimationFrame(() => banner.classList.add('is-visible'));
    }

    const handleConsent = choice => {
      try {
        localStorage.setItem(storageKey, choice);
      } catch (error) {
        console.warn('Unable to store consent', error);
      }
      banner.classList.remove('is-visible');
      setTimeout(() => {
        banner.style.display = 'none';
      }, 320);
    };

    acceptBtn.addEventListener('click', () => handleConsent('accepted'));
    declineBtn.addEventListener('click', () => handleConsent('declined'));
  }
});