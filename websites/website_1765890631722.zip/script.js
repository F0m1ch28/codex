document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById("cookie-banner");
  if (!banner) {
    return;
  }

  const acceptButton = banner.querySelector("[data-cookie-accept]");
  const declineButton = banner.querySelector("[data-cookie-decline]");
  const storedChoice = localStorage.getItem("cookieConsent");

  if (storedChoice === "accepted" || storedChoice === "declined") {
    banner.classList.add("is-hidden");
  }

  if (acceptButton) {
    acceptButton.addEventListener("click", function () {
      localStorage.setItem("cookieConsent", "accepted");
      banner.classList.add("is-hidden");
    });
  }

  if (declineButton) {
    declineButton.addEventListener("click", function () {
      localStorage.setItem("cookieConsent", "declined");
      banner.classList.add("is-hidden");
    });
  }
});