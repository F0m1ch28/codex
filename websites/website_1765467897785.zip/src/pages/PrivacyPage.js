import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | TechSkills Belgium</title>
        <meta
          name="description"
          content="Read the TechSkills Belgium privacy policy outlining how we collect, use, and protect personal data from learners and partners."
        />
        <meta
          name="keywords"
          content="privacy policy, data protection, TechSkills Belgium privacy"
        />
      </Helmet>
      <article className={styles.page}>
        <h1>Privacy Policy</h1>
        <p>Effective date: March 15, 2024</p>
        <section>
          <h2>Data we collect</h2>
          <p>
            We collect personal information that you provide when registering interest, enrolling in
            programmes, or communicating with our team. This may include your name, contact details,
            professional background, and learning goals.
          </p>
        </section>
        <section>
          <h2>How we use data</h2>
          <p>
            Your information helps us deliver learning experiences, share updates, and facilitate
            career support activities. We process data in line with EU General Data Protection
            Regulation (GDPR) requirements.
          </p>
        </section>
        <section>
          <h2>Data sharing</h2>
          <p>
            We may share limited information with trusted partners, such as mentors or hiring
            organisations, to coordinate educational services. We never sell personal data.
          </p>
        </section>
        <section>
          <h2>Your rights</h2>
          <p>
            You can request access, correction, or deletion of your data at any time. Contact us at{' '}
            <a href="mailto:info@iteducation.be">info@iteducation.be</a> to exercise these rights.
          </p>
        </section>
        <section>
          <h2>Security</h2>
          <p>
            We implement technical and organisational measures to protect your data from
            unauthorised access, alteration, or disclosure.
          </p>
        </section>
      </article>
    </>
  );
};

export default PrivacyPage;