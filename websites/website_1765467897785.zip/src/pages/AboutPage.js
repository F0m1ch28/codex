import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const teamMembers = [
  {
    name: 'Léa Vermeiren',
    role: 'Director of Learning Strategy',
    image: 'https://picsum.photos/400/400?random=301',
    bio: 'Leads our curriculum development, ensuring every learning path aligns with Belgium’s fast-evolving tech priorities.'
  },
  {
    name: 'Jonas Peeters',
    role: 'Head of Engineering Programmes',
    image: 'https://picsum.photos/400/400?random=302',
    bio: 'Former CTO turned educator who mentors learners through architecture planning, automation, and sustainable coding habits.'
  },
  {
    name: 'Sofia van den Berg',
    role: 'Career Ecosystem Lead',
    image: 'https://picsum.photos/400/400?random=303',
    bio: 'Builds partnerships with employers and connects graduates to opportunities across Brussels, Antwerp, Ghent, and Liège.'
  }
];

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About TechSkills Belgium | Our Mission & Team</title>
        <meta
          name="description"
          content="TechSkills Belgium is dedicated to cultivating IT talent across Belgium through inclusive education, expert mentorship, and meaningful employer partnerships."
        />
        <meta
          name="keywords"
          content="tech education Belgium, coding academy Brussels, IT training mission, tech mentors Belgium"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.intro}>
          <h1>We enable Belgium’s digital talent to thrive.</h1>
          <p>
            TechSkills Belgium was founded to connect dedicated learners with industry mentors who
            understand the realities of modern tech teams. We build programmes that respect every
            learner’s starting point while opening doors to sustainable careers in development,
            data, cybersecurity, and design.
          </p>
        </section>

        <section className={styles.values} aria-labelledby="values-title">
          <h2 id="values-title">Our guiding values</h2>
          <div className={styles.valuesGrid}>
            <article>
              <h3>Collaboration</h3>
              <p>
                We champion teamwork and inclusive communication, reflecting the collaborative
                culture of thriving Belgian digital teams.
              </p>
            </article>
            <article>
              <h3>Curiosity</h3>
              <p>
                We create room for experimentation and continuous learning, empowering learners to
                adapt to new tools and methodologies.
              </p>
            </article>
            <article>
              <h3>Impact</h3>
              <p>
                We design every project to produce tangible outcomes that support communities,
                organisations, and entrepreneurs across Belgium.
              </p>
            </article>
            <article>
              <h3>Integrity</h3>
              <p>
                We uphold ethical practices in technology and education, preparing learners to serve
                responsibly in every professional context.
              </p>
            </article>
          </div>
        </section>

        <section className={styles.story} aria-labelledby="story-title">
          <div className={styles.storyImage} role="presentation" />
          <div className={styles.storyContent}>
            <h2 id="story-title">A diverse learning community anchored in Brussels.</h2>
            <p>
              Our headquarters at Avenue de la Toison d&apos;Or 56 places us at the heart of
              Belgium’s innovation corridor. Learners from across the country join us on campus and
              online to collaborate in English, French, and Dutch—reflecting the multilingual
              reality of Belgian workplaces.
            </p>
            <p>
              Through alliances with universities, accelerators, and technology companies, we co-create
              programmes that respond to real workforce needs. This shared commitment ensures our
              graduates are prepared to make an immediate impact.
            </p>
          </div>
        </section>

        <section className={styles.team} aria-labelledby="team-title">
          <h2 id="team-title">Leadership team</h2>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`${member.name} portrait`} loading="lazy" />
                <div>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default AboutPage;