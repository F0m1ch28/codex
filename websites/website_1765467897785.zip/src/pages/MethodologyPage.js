import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './MethodologyPage.module.css';

const pillars = [
  {
    title: 'Immersive practice',
    description:
      'Learners work on live briefs, rotating roles across scrum master, developer, analyst, and designer to mirror professional sprints.'
  },
  {
    title: 'Mentor-guided feedback',
    description:
      'Weekly code reviews, design critiques, and data storytelling sessions led by experts anchor every learning milestone in actionable feedback.'
  },
  {
    title: 'Inclusive peer learning',
    description:
      'Cohorts are intentionally diverse, creating space to learn with and from peers of different backgrounds, languages, and perspectives.'
  },
  {
    title: 'Career integration',
    description:
      'Talent advisors join classes to connect learning outcomes with job expectations, preparing learners to communicate their value.'
  }
];

const MethodologyPage = () => {
  return (
    <>
      <Helmet>
        <title>Methodology | TechSkills Belgium Learning Approach</title>
        <meta
          name="description"
          content="Discover the TechSkills Belgium methodology combining immersive practice, mentor feedback, inclusive peer learning, and career integration."
        />
        <meta
          name="keywords"
          content="learning methodology, IT education approach, practical tech training, Belgium mentorship"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.hero}>
          <h1>Learning that transforms ambition into professional impact.</h1>
          <p>
            The TechSkills Belgium methodology is grounded in doing. Every session, project, and
            reflection is designed to help learners practice the mindsets and behaviours of
            high-performing tech teams.
          </p>
        </section>

        <section className={styles.pillarSection} aria-labelledby="pillar-title">
          <h2 id="pillar-title">Four pillars of our approach</h2>
          <div className={styles.pillarGrid}>
            {pillars.map((pillar) => (
              <article key={pillar.title}>
                <h3>{pillar.title}</h3>
                <p>{pillar.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.outcomes} aria-labelledby="outcome-title">
          <div className={styles.outcomeImage} role="presentation" />
          <div className={styles.outcomeContent}>
            <h2 id="outcome-title">Measured progress every four weeks.</h2>
            <p>
              Learners receive structured feedback on technical delivery, collaboration, and
              professional communication. These checkpoints guide adjustments to support personal
              growth while highlighting achievements worth sharing with employers.
            </p>
            <ul>
              <li>Portfolio-ready artefacts reviewed by industry specialists</li>
              <li>Skills mapping against in-demand Belgian tech roles</li>
              <li>Wellbeing check-ins to maintain sustainable progress</li>
            </ul>
          </div>
        </section>
      </div>
    </>
  );
};

export default MethodologyPage;