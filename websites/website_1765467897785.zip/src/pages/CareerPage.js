import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CareerPage.module.css';

const supportItems = [
  {
    title: 'Career coaching',
    description:
      'One-to-one career conversations tailor your job search strategy, refine your CV, and help you communicate your strengths to Belgian employers.'
  },
  {
    title: 'Employer partnerships',
    description:
      'We work with technology teams across finance, healthcare, public sector, and startups to connect graduates with meaningful opportunities.'
  },
  {
    title: 'Interview labs',
    description:
      'Experience technical challenges, portfolio walkthroughs, and behavioural interviews with constructive feedback from recruiters and hiring managers.'
  },
  {
    title: 'Alumni network',
    description:
      'TechSkills alumni host monthly meetups, share open roles, and mentor incoming cohorts to keep the community thriving.'
  }
];

const CareerPage = () => {
  return (
    <>
      <Helmet>
        <title>Career Support | TechSkills Belgium</title>
        <meta
          name="description"
          content="TechSkills Belgium provides coaching, partner connections, interview labs, and alumni networking to support successful IT careers in Belgium."
        />
        <meta
          name="keywords"
          content="IT career support, tech jobs Belgium, interview preparation, alumni network"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.hero}>
          <div>
            <h1>Empowering your next chapter in tech.</h1>
            <p>
              Career support is woven into every step of the TechSkills Belgium experience. We help
              you clarify your ambitions, build a compelling portfolio, and connect with teams that
              need your expertise.
            </p>
          </div>
          <div className={styles.heroStats}>
            <article>
              <h3>65+ partner organisations</h3>
              <p>Collaborating with us to identify emerging talent throughout the year.</p>
            </article>
            <article>
              <h3>92% placement success</h3>
              <p>Graduates secure new roles or promotions within six months of completion.</p>
            </article>
          </div>
        </section>

        <section className={styles.support} aria-labelledby="support-title">
          <h2 id="support-title">Support pillars</h2>
          <div className={styles.supportGrid}>
            {supportItems.map((item) => (
              <article key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.success} aria-labelledby="success-title">
          <div className={styles.successImage} role="presentation" />
          <div className={styles.successContent}>
            <h2 id="success-title">Success stories from our community.</h2>
            <blockquote>
              “After joining TechSkills Belgium’s UX/UI track, I transitioned from graphic design to
              product design at a Brussels fintech company. The interview labs simulated exactly what
              I experienced in the hiring process.”
            </blockquote>
            <p className={styles.meta}>— Mateo Rossi, Product Designer</p>
            <blockquote>
              “The career team connected me with a cybersecurity internship in Antwerp that became a
              permanent role. Their mentorship guided every step of my journey.”
            </blockquote>
            <p className={styles.meta}>— Lien Janssens, Security Analyst</p>
          </div>
        </section>
      </div>
    </>
  );
};

export default CareerPage;