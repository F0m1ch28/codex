import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CoursesPage.module.css';

const courseTracks = [
  {
    title: 'Full-Stack Web Development',
    duration: '6 months, part-time or immersive formats',
    modules: ['Modern JavaScript & TypeScript', 'API design & microservices', 'Cloud deployment practices', 'Agile collaboration & DevOps foundations'],
    highlight:
      'Build applications with React, Node.js, and cloud tooling while collaborating with mentors on production-grade sprints.'
  },
  {
    title: 'Data Science & Analytics',
    duration: '5 months, modular learning blocks',
    modules: ['Python for analytics', 'Data storytelling & dashboards', 'Machine learning workflows', 'Ethics & privacy in data'],
    highlight:
      'Partner with Belgian organisations to solve real datasets, translating insights into actionable strategies with stakeholder presentations.'
  },
  {
    title: 'Cybersecurity Operations',
    duration: '4 months, evening and weekend labs',
    modules: ['Threat detection & incident response', 'Network security & monitoring', 'Security governance & risk', 'Hands-on red/blue team labs'],
    highlight:
      'Learn to safeguard infrastructures through simulated incident rooms, preparing for critical roles across Belgium’s public and private sectors.'
  },
  {
    title: 'UX/UI Product Design',
    duration: '5 months, hybrid studio sessions',
    modules: ['Design research & discovery', 'Interaction design & prototyping', 'Design systems & accessibility', 'Product delivery & storytelling'],
    highlight:
      'Design inclusive experiences across languages and platforms, pairing with developers to deliver cohesive digital products.'
  }
];

const CoursesPage = () => {
  return (
    <>
      <Helmet>
        <title>Courses | TechSkills Belgium IT Programmes</title>
        <meta
          name="description"
          content="Explore TechSkills Belgium programmes in web development, data science, cybersecurity, and UX design. Learn through hands-on projects and expert mentorship."
        />
        <meta
          name="keywords"
          content="IT courses Belgium, coding bootcamp Brussels, data science training, cybersecurity course Belgium"
        />
      </Helmet>
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Learning paths designed for measurable progress.</h1>
          <p>
            Each programme blends live instruction, collaborative labs, and mentor feedback.
            Flexible schedules support working professionals and career changers alike, while
            progress checkpoints keep you focused and accountable.
          </p>
        </header>

        <section className={styles.trackSection} aria-labelledby="programme-overview">
          <h2 id="programme-overview" className={styles.sectionTitle}>
            Programme overview
          </h2>
          <div className={styles.trackGrid}>
            {courseTracks.map((track) => (
              <article key={track.title} className={styles.trackCard}>
                <div className={styles.trackHeader}>
                  <h3>{track.title}</h3>
                  <p className={styles.duration}>{track.duration}</p>
                </div>
                <p className={styles.highlight}>{track.highlight}</p>
                <ul>
                  {track.modules.map((module) => (
                    <li key={module}>{module}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.extras} aria-labelledby="extra-title">
          <h2 id="extra-title">What every learner receives</h2>
          <div className={styles.extrasGrid}>
            <article>
              <h3>Mentor clinics</h3>
              <p>
                Weekly small-group clinics designed to dig into code reviews, product decisions, and
                architecture choices with our mentor network.
              </p>
            </article>
            <article>
              <h3>Project showcase weeks</h3>
              <p>
                Present your work to industry guests, receive structured feedback, and iterate like a
                professional product team.
              </p>
            </article>
            <article>
              <h3>Career navigation labs</h3>
              <p>
                Prepare for interviews, build your professional brand, and connect with Belgian
                recruiters through guided labs.
              </p>
            </article>
            <article>
              <h3>Lifelong alumni access</h3>
              <p>
                Continue learning with monthly masterclasses, peer mentoring circles, and exclusive
                job opportunities.
              </p>
            </article>
          </div>
        </section>
      </div>
    </>
  );
};

export default CoursesPage;