import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsPage.module.css';

const TermsPage = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | TechSkills Belgium</title>
        <meta
          name="description"
          content="Review the TechSkills Belgium terms of use governing access to our IT education platform, community, and services."
        />
        <meta
          name="keywords"
          content="terms of use, TechSkills Belgium terms, IT education policies"
        />
      </Helmet>
      <article className={styles.page}>
        <h1>Terms of Use</h1>
        <p>Last updated: March 15, 2024</p>
        <section>
          <h2>1. Acceptance of terms</h2>
          <p>
            By accessing TechSkills Belgium resources, you agree to comply with these Terms of Use.
            If you do not agree, you may not access or use our services.
          </p>
        </section>
        <section>
          <h2>2. Intellectual property</h2>
          <p>
            All content, including curriculum materials, articles, visual assets, and logos, is the
            property of TechSkills Belgium. You may not reproduce or distribute any materials
            without written permission.
          </p>
        </section>
        <section>
          <h2>3. Acceptable use</h2>
          <p>
            You agree not to use our website for unlawful purposes or in a way that disrupts the
            learning experience of others. We reserve the right to suspend access for conduct that
            violates these terms.
          </p>
        </section>
        <section>
          <h2>4. Limitation of liability</h2>
          <p>
            TechSkills Belgium is not liable for any indirect or consequential damages arising from
            the use of our platform or reliance on provided information.
          </p>
        </section>
        <section>
          <h2>5. Modifications</h2>
          <p>
            We may update these terms from time to time. Continued use of our services after changes
            are posted constitutes acceptance of the revised terms.
          </p>
        </section>
        <section>
          <h2>6. Contact</h2>
          <p>
            If you have questions regarding these terms, contact us at{' '}
            <a href="mailto:info@iteducation.be">info@iteducation.be</a>.
          </p>
        </section>
      </article>
    </>
  );
};

export default TermsPage;