import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './BlogPage.module.css';

const posts = [
  {
    title: 'Designing Collaborative Labs for Cross-Functional Teams',
    image: 'https://picsum.photos/800/600?random=701',
    date: 'March 7, 2024',
    category: 'Learning design',
    excerpt:
      'Collaboration thrives when teams share a common language. Discover how our labs help developers, designers, and analysts align around shared outcomes.'
  },
  {
    title: 'Why Ethical AI Matters for Every Belgian Organisation',
    image: 'https://picsum.photos/800/600?random=702',
    date: 'February 19, 2024',
    category: 'Data & AI',
    excerpt:
      'Responsible AI implementation starts with diverse teams and structured reflection. We outline the practices we teach to spark ethical innovation.'
  },
  {
    title: 'Navigating the Cybersecurity Skills Gap in Europe',
    image: 'https://picsum.photos/800/600?random=703',
    date: 'January 30, 2024',
    category: 'Cybersecurity',
    excerpt:
      'As European regulations evolve, cybersecurity talent is in high demand. Learn how learners can stand out in a rapidly growing field.'
  },
  {
    title: 'Crafting Inclusive UX for Multilingual Audiences',
    image: 'https://picsum.photos/800/600?random=704',
    date: 'January 12, 2024',
    category: 'UX/UI',
    excerpt:
      'Belgium’s multilingual context requires thoughtful design decisions. We share frameworks for building accessible, inclusive digital experiences.'
  }
];

const BlogPage = () => {
  return (
    <>
      <Helmet>
        <title>Insights & Articles | TechSkills Belgium Blog</title>
        <meta
          name="description"
          content="Stay updated with TechSkills Belgium insights on IT education, data, cybersecurity, and UX design, written by our mentor community."
        />
        <meta
          name="keywords"
          content="tech blog Belgium, IT education insights, coding articles, data science blog"
        />
      </Helmet>
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Thought leadership from our educator community.</h1>
          <p>
            Explore perspectives on the future of IT, emerging tools, and the human skills needed to
            innovate responsibly across Belgium and Europe.
          </p>
        </header>

        <section className={styles.grid} aria-labelledby="blog-list">
          <h2 id="blog-list" className="visually-hidden">
            Blog articles
          </h2>
          {posts.map((post) => (
            <article key={post.title} className={styles.card}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className={styles.content}>
                <div className={styles.meta}>
                  <span>{post.category}</span>
                  <time dateTime={post.date}>{post.date}</time>
                </div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <button type="button" className={styles.readMore} aria-label={`Read ${post.title}`}>
                  Read article
                </button>
              </div>
            </article>
          ))}
        </section>
      </div>
    </>
  );
};

export default BlogPage;