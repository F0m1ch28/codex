import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | TechSkills Belgium</title>
        <meta
          name="description"
          content="Understand how TechSkills Belgium uses cookies to improve user experience and analyse website usage."
        />
        <meta name="keywords" content="cookie policy, TechSkills Belgium cookies" />
      </Helmet>
      <article className={styles.page}>
        <h1>Cookie Policy</h1>
        <p>Effective date: March 15, 2024</p>
        <section>
          <h2>What are cookies?</h2>
          <p>
            Cookies are small text files stored on your device to help us understand how you use our
            website and to deliver a tailored experience.
          </p>
        </section>
        <section>
          <h2>Types of cookies we use</h2>
          <ul>
            <li>
              <strong>Essential cookies:</strong> Required for core functionality such as navigating
              secure areas.
            </li>
            <li>
              <strong>Analytics cookies:</strong> Help us analyse website traffic and improve our
              content and services.
            </li>
            <li>
              <strong>Preference cookies:</strong> Remember your choices to enhance your experience.
            </li>
          </ul>
        </section>
        <section>
          <h2>Managing cookies</h2>
          <p>
            You can adjust your browser settings to accept or decline cookies. Be aware that
            disabling cookies may impact certain functionalities.
          </p>
        </section>
        <section>
          <h2>Contact us</h2>
          <p>
            For questions about this policy, email{' '}
            <a href="mailto:info@iteducation.be">info@iteducation.be</a>.
          </p>
        </section>
      </article>
    </>
  );
};

export default CookiePolicyPage;