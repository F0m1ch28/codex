import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './HomePage.module.css';

const featuredTracks = [
  {
    title: 'Web Development',
    description:
      'Master front-end and back-end frameworks to build responsive, accessible web applications powered by modern JavaScript ecosystems.',
    image: 'https://picsum.photos/600/400?random=101',
    link: '/courses'
  },
  {
    title: 'Data Science & AI',
    description:
      'Translate data into strategic decisions by combining Python, analytics tooling, and ethical AI practices across Belgian industries.',
    image: 'https://picsum.photos/600/400?random=102',
    link: '/courses'
  },
  {
    title: 'Cybersecurity',
    description:
      'Safeguard digital infrastructures through threat modelling, incident response drills, and compliance readiness for European standards.',
    image: 'https://picsum.photos/600/400?random=103',
    link: '/courses'
  },
  {
    title: 'UX/UI Design',
    description:
      'Craft intuitive digital journeys with user research, design systems, and collaborative prototyping tailored to multilingual audiences.',
    image: 'https://picsum.photos/600/400?random=104',
    link: '/courses'
  }
];

const blogPosts = [
  {
    title: 'How Belgian Tech Teams Build Inclusive Products',
    excerpt:
      'Discover the collaborative practices that help multilingual, cross-functional teams deliver inclusive software for the Belgian market.',
    date: 'March 12, 2024'
  },
  {
    title: 'Mapping Your IT Career Pathway in Brussels',
    excerpt:
      'From first internship to senior leadership, understand the competencies that employers across Belgium expect at each milestone.',
    date: 'February 28, 2024'
  },
  {
    title: 'Hands-on Learning with Industry Mentors',
    excerpt:
      'Explore how TechSkills Belgium integrates mentoring, live sprints, and portfolio building into every course experience.',
    date: 'February 6, 2024'
  }
];

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>TechSkills Belgium | Leading IT Education in Belgium</title>
        <meta
          name="description"
          content="TechSkills Belgium empowers learners with practical IT education, industry mentorship, and career support tailored to Belgium’s digital ecosystem."
        />
        <meta
          name="keywords"
          content="IT education Belgium, coding courses Brussels, tech training, cybersecurity learning, data science Belgium"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.hero}>
          <div className={styles.heroContent}>
            <p className={styles.heroTag}>Future-proof your tech skills</p>
            <h1>Belgium’s collaborative hub for career-ready IT learning.</h1>
            <p className={styles.heroDescription}>
              We connect ambition with expertise through immersive programmes, live project labs,
              and career partnerships that accelerate your journey into the Belgian tech landscape.
            </p>
            <div className={styles.heroActions}>
              <Link to="/courses" className={styles.primaryCta}>
                Explore Courses
              </Link>
              <Link to="/contact" className={styles.secondaryCta}>
                Talk to our team
              </Link>
            </div>
            <dl className={styles.heroStats}>
              <div>
                <dt>4,500+</dt>
                <dd>Hours of hands-on labs delivered annually</dd>
              </div>
              <div>
                <dt>120+</dt>
                <dd>Industry mentors from Belgian tech companies</dd>
              </div>
              <div>
                <dt>92%</dt>
                <dd>Graduates moving into new IT roles within 6 months</dd>
              </div>
            </dl>
          </div>
          <div className={styles.heroImage} role="presentation" />
        </section>

        <section className={styles.mission} aria-labelledby="mission-title">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionTag}>About us</p>
            <h2 id="mission-title">Learning designed for Belgium’s digital future.</h2>
          </div>
          <div className={styles.missionBody}>
            <p>
              TechSkills Belgium bridges the gap between emerging talent and the real pace of
              industry innovation. Our mission is to cultivate confident, job-ready professionals
              equipped to strengthen Belgium’s multilingual, tech-enabled economy.
            </p>
            <Link to="/about" className={styles.inlineLink}>
              Learn more about our story →
            </Link>
          </div>
        </section>

        <section className={styles.tracks} aria-labelledby="tracks-title">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionTag}>Featured tracks</p>
            <h2 id="tracks-title">Choose a pathway that reflects your ambition.</h2>
            <p>
              Each track blends technical mastery with human skills, ensuring you thrive in diverse
              Belgian workplaces and international teams.
            </p>
          </div>
          <div className={styles.trackGrid}>
            {featuredTracks.map((track) => (
              <article key={track.title} className={styles.trackCard}>
                <img src={track.image} alt={`${track.title} learning`} loading="lazy" />
                <div className={styles.trackContent}>
                  <h3>{track.title}</h3>
                  <p>{track.description}</p>
                  <Link to={track.link}>See learning outcomes</Link>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.method} aria-labelledby="method-title">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionTag}>Why choose us</p>
            <h2 id="method-title">A methodology crafted with industry, for industry.</h2>
          </div>
          <div className={styles.methodGrid}>
            <div>
              <h3>Practice-first projects</h3>
              <p>
                Weekly sprints mirror real briefs from Belgian startups, corporates, and government
                digital teams, ensuring every concept is reinforced through application.
              </p>
            </div>
            <div>
              <h3>Expert mentors</h3>
              <p>
                Coaches from Brussels, Antwerp, and Ghent share current best practices, introduce
                tooling stacks, and guide you through code reviews and design critiques.
              </p>
            </div>
            <div>
              <h3>Impactful portfolios</h3>
              <p>
                Build a multilingual, real-world portfolio you can showcase to hiring managers,
                recruiters, and innovation leads throughout Belgium and beyond.
              </p>
            </div>
            <div>
              <h3>Human-centred learning</h3>
              <p>
                Collaborate in inclusive cohorts, sharpen communication skills, and practice agile
                rituals that reflect the culture of forward-looking IT teams.
              </p>
            </div>
          </div>
        </section>

        <section className={styles.journey} aria-labelledby="journey-title">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionTag}>Learning journey</p>
            <h2 id="journey-title">Navigate each step with clarity and confidence.</h2>
          </div>
          <div className={styles.journeySteps}>
            <article>
              <span>01</span>
              <h3>Discover & align</h3>
              <p>
                Assess your goals with our advisors and map a personalised curriculum that suits
                your starting point and career destination.
              </p>
            </article>
            <article>
              <span>02</span>
              <h3>Build in community</h3>
              <p>
                Learn in agile squads, receive mentor feedback, and ship iterative releases that
                mirror professional expectations.
              </p>
            </article>
            <article>
              <span>03</span>
              <h3>Showcase impact</h3>
              <p>
                Present your portfolio to partner organisations, gain peer critique, and refine
                your professional story for Belgian talent markets.
              </p>
            </article>
          </div>
        </section>

        <section className={styles.blog} aria-labelledby="blog-title">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionTag}>From our blog</p>
            <h2 id="blog-title">Insights from our educators and partners.</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/blog">Continue reading</Link>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.career} aria-labelledby="career-title">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionTag}>Career support</p>
            <h2 id="career-title">Your career coach beyond graduation.</h2>
          </div>
          <div className={styles.careerContent}>
            <div>
              <p>
                From mock interviews with Belgian tech recruiters to networking labs with leading
                employers, we help you translate your new skills into meaningful opportunities.
              </p>
              <ul>
                <li>Personalised career roadmaps for every learner</li>
                <li>Direct introductions to hiring partners across Belgium</li>
                <li>Ongoing alumni community with monthly talent events</li>
              </ul>
              <Link to="/career" className={styles.inlineLink}>
                Explore our career services →
              </Link>
            </div>
            <div className={styles.testimonial}>
              <blockquote>
                “The mentorship at TechSkills Belgium helped me transition from hospitality into a
                junior developer role in Brussels. The support went far beyond the classroom.”
              </blockquote>
              <p className={styles.testimonialMeta}>— Amélie Dupont, Web Development Graduate</p>
            </div>
          </div>
        </section>

        <section className={styles.cta} aria-labelledby="cta-title">
          <div>
            <p className={styles.sectionTag}>Ready to begin</p>
            <h2 id="cta-title">Start your IT journey today.</h2>
            <p>
              Let’s identify the learning path that aligns with your strengths and career goals.
              Our advisors are ready to help you get started.
            </p>
          </div>
          <Link to="/contact" className={styles.primaryCta}>
            Contact the team
          </Link>
        </section>
      </div>
    </>
  );
};

export default HomePage;