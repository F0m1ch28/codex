import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactPage.module.css';

const initialState = {
  name: '',
  email: '',
  topic: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.topic.trim()) newErrors.topic = 'Please choose a topic.';
    if (!formData.message.trim()) newErrors.message = 'Please share a brief message.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = validate();
    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      setStatus('Thanks! Our advisors will be in touch soon.');
      setFormData(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact TechSkills Belgium | Get in Touch</title>
        <meta
          name="description"
          content="Contact TechSkills Belgium advisors for details on IT programmes, partnerships, and community events in Brussels and across Belgium."
        />
        <meta
          name="keywords"
          content="contact tech academy, IT education Belgium contact, tech learning Brussels"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.hero}>
          <div>
            <h1>Let’s craft your path into tech.</h1>
            <p>
              Reach out to our advisors to discuss programmes, partnerships, or how we can support
              your team’s upskilling goals. We are here to help you take the next step.
            </p>
          </div>
          <div className={styles.info}>
            <h2>Contact details</h2>
            <ul>
              <li>
                <strong>Address:</strong> IT Education Center, Avenue de la Toison d&apos;Or 56, 1060 Brussels, Belgium
              </li>
              <li>
                <strong>Phone:</strong>{' '}
                <a href="tel:+3221234567" className={styles.link}>
                  +32 2 123 45 67
                </a>
              </li>
              <li>
                <strong>Email:</strong>{' '}
                <a href="mailto:info@iteducation.be" className={styles.link}>
                  info@iteducation.be
                </a>
              </li>
            </ul>
          </div>
        </section>

        <section className={styles.formSection} aria-labelledby="contact-form-title">
          <div className={styles.formCard}>
            <h2 id="contact-form-title">Send us a message</h2>
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && (
                  <p id="name-error" className={styles.error}>
                    {errors.name}
                  </p>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && (
                  <p id="email-error" className={styles.error}>
                    {errors.email}
                  </p>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="topic">Topic</label>
                <select
                  id="topic"
                  name="topic"
                  value={formData.topic}
                  onChange={handleChange}
                  aria-describedby={errors.topic ? 'topic-error' : undefined}
                >
                  <option value="">Select a topic</option>
                  <option value="programmes">Programmes and curriculum</option>
                  <option value="partnerships">Employer or partnership enquiry</option>
                  <option value="events">Community events</option>
                  <option value="other">Other question</option>
                </select>
                {errors.topic && (
                  <p id="topic-error" className={styles.error}>
                    {errors.topic}
                  </p>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                />
                {errors.message && (
                  <p id="message-error" className={styles.error}>
                    {errors.message}
                  </p>
                )}
              </div>

              <button type="submit" className={styles.submit}>
                Submit
              </button>
              {status && <p className={styles.success}>{status}</p>}
            </form>
          </div>
          <div className={styles.map} role="presentation">
            <img
              src="https://maps.googleapis.com/maps/api/staticmap?center=Brussels,Belgium&zoom=13&size=640x640&maptype=roadmap&markers=color:blue%7CBrussels,Belgium&key=AIzaSyD-Placeholder"
              alt="Map of Brussels"
              loading="lazy"
              onError={(event) => {
                event.currentTarget.src = 'https://picsum.photos/640/640?random=705';
              }}
            />
          </div>
        </section>
      </div>
    </>
  );
};

export default ContactPage;