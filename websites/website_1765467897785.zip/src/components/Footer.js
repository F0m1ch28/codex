import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <Link to="/" className={styles.logo}>
            TechSkills<span>Belgium</span>
          </Link>
          <p className={styles.tagline}>
            Elevating digital talent across Belgium through collaborative learning, mentorship,
            and real-world IT practice.
          </p>
          <div className={styles.socials} aria-label="Social media">
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M4.98 3.5a2.5 2.5 0 1 1-.02 5 2.5 2.5 0 0 1 .02-5zM3 8.75h3.96V21H3zM9.75 8.75H13V10h.05c.45-.85 1.55-1.75 3.2-1.75 3.42 0 4.05 2.1 4.05 4.84V21h-3.96v-5.95c0-1.42-.03-3.26-1.99-3.26-1.99 0-2.29 1.55-2.29 3.16V21H9.75z" />
              </svg>
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M21.6 6.2a2.7 2.7 0 0 0-1.91-1.91C17.79 4 12 4 12 4s-5.79 0-7.69.29A2.7 2.7 0 0 0 2.4 6.2 28.7 28.7 0 0 0 2.1 12a28.7 28.7 0 0 0 .29 5.8 2.7 2.7 0 0 0 1.91 1.91C5.21 20 12 20 12 20s5.79 0 7.69-.29a2.7 2.7 0 0 0 1.91-1.91A28.7 28.7 0 0 0 21.9 12a28.7 28.7 0 0 0-.29-5.8zM10.4 15.6V8.4l6.4 3.6-6.4 3.6z" />
              </svg>
            </a>
            <a
              href="https://www.twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Twitter"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M19.46 7.14c.01.17.01.34.01.5 0 5.13-3.9 11.05-11.05 11.05-2.19 0-4.23-.64-5.94-1.75a7.81 7.81 0 0 0 5.76-1.61 3.87 3.87 0 0 1-3.61-2.68c.24.04.48.07.73.07.35 0 .69-.05 1.01-.13a3.86 3.86 0 0 1-3.1-3.79v-.05c.52.29 1.12.47 1.76.49a3.85 3.85 0 0 1-1.73-3.21c0-.71.19-1.38.52-1.95a10.98 10.98 0 0 0 7.98 4.05 3.87 3.87 0 0 1 6.59-3.52 7.73 7.73 0 0 0 2.45-.94 3.86 3.86 0 0 1-1.7 2.13 7.7 7.7 0 0 0 2.22-.61 8.28 8.28 0 0 1-1.93 2z" />
              </svg>
            </a>
          </div>
        </div>
        <div className={styles.grid}>
          <div>
            <h3>Explore</h3>
            <ul>
              <li>
                <Link to="/courses">Courses</Link>
              </li>
              <li>
                <Link to="/methodology">Methodology</Link>
              </li>
              <li>
                <Link to="/career">Career Support</Link>
              </li>
              <li>
                <Link to="/blog">Insights</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3>Resources</h3>
            <ul>
              <li>
                <Link to="/terms">Terms of Use</Link>
              </li>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Cookie Policy</Link>
              </li>
              <li>
                <a href="#main-content">Accessibility</a>
              </li>
            </ul>
          </div>
          <div>
            <h3>Contact</h3>
            <ul className={styles.contactList}>
              <li>
                IT Education Center<br />
                Avenue de la Toison d'Or 56, 1060 Brussels, Belgium
              </li>
              <li>
                <a href="tel:+3221234567">+32 2 123 45 67</a>
              </li>
              <li>
                <a href="mailto:info@iteducation.be">info@iteducation.be</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.meta}>
        <p>© {new Date().getFullYear()} TechSkills Belgium. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;