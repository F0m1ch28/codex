import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { to: '/guide', label: 'Gids' },
    { to: '/over-ons', label: 'Over ons' },
    { to: '/contact', label: 'Contact' },
    { to: '/legal', label: 'Legal' },
  ];

  const socialLinks = [
    { href: '#', label: 'Instagram' },
    { href: '#', label: 'Facebook' },
    { href: '#', label: 'Pinterest' },
  ];

  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.container}`}>
        <div className={styles.brand}>
          <h2>Toy Delights</h2>
          <p>
            Onze missie is om elk kind in België te laten ontdekken, leren en
            stralen met veilig en speels speelgoed.
          </p>
        </div>
        <div className={styles.links}>
          <h3>Snel naar</h3>
          <ul className="list-reset">
            {quickLinks.map((link) => (
              <li key={link.to}>
                <Link to={link.to} className={styles.footerLink}>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div className={styles.social}>
          <h3>Volg ons</h3>
          <ul className="list-reset">
            {socialLinks.map((item) => (
              <li key={item.label}>
                <a
                  href={item.href}
                  className={styles.footerLink}
                  aria-label={`Ga naar ${item.label}`}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {currentYear} Toy Delights. Alle rechten voorbehouden.</p>
      </div>
    </footer>
  );
};

export default Footer;