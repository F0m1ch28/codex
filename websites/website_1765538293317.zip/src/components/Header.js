import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleClose = () => {
    setMenuOpen(false);
  };

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/guide', label: 'Gids' },
    { path: '/programmas', label: 'Programma’s' },
    { path: '/tools', label: 'Tools' },
    { path: '/blog', label: 'Blog' },
    { path: '/over-ons', label: 'Over ons' },
    { path: '/contact', label: 'Contact' },
    { path: '/legal', label: 'Legal' },
  ];

  return (
    <header className={styles.header}>
      <div className={`container ${styles.content}`}>
        <Link to="/" className={styles.logo} onClick={handleClose}>
          <span className={styles.logoIcon} aria-hidden="true">
            🎈
          </span>
          <span className={styles.logoText}>Toy Delights</span>
        </Link>
        <nav
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Hoofdmenu"
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive
                      ? `${styles.navLink} ${styles.navLinkActive}`
                      : styles.navLink
                  }
                  onClick={handleClose}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <button
          type="button"
          className={styles.menuButton}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-label={menuOpen ? 'Sluit menu' : 'Open menu'}
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
        </button>
        <div className={styles.cart}>
          <span className={styles.cartIcon} role="img" aria-label="Winkelwagen">
            🛒
          </span>
          <span className={styles.cartLabel}>Winkelwagen</span>
        </div>
      </div>
    </header>
  );
};

export default Header;