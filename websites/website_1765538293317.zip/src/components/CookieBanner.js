import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'toy-delights-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <h4>Koekjes voor een betere ervaring</h4>
        <p>
          Toy Delights gebruikt analytische cookies om onze speelervaring te verbeteren. Lees meer in ons{' '}
          <Link to="/cookiebeleid" className={styles.link}>
            cookiebeleid
          </Link>
          .
        </p>
      </div>
      <button type="button" className="btn" onClick={handleAccept}>
        Akkoord
      </button>
    </div>
  );
};

export default CookieBanner;