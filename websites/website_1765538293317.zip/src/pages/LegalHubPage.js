import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './LegalHubPage.module.css';

const legalLinks = [
  {
    to: '/algemene-voorwaarden',
    title: 'Algemene voorwaarden',
    description: 'Lees de voorwaarden waaronder Toy Delights diensten en producten aanbiedt.',
  },
  {
    to: '/privacybeleid',
    title: 'Privacybeleid',
    description: 'Zo gaan we om met jouw persoonsgegevens en houden we ze veilig.',
  },
  {
    to: '/cookiebeleid',
    title: 'Cookiebeleid',
    description: 'Ontdek hoe we cookies inzetten voor een prettige gebruikservaring.',
  },
];

const LegalHubPage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Legal documentatie</title>
        <meta
          name="description"
          content="Toegang tot de juridische documenten van Toy Delights: algemene voorwaarden, privacybeleid en cookiebeleid."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Legal informatie</h1>
          <p className="lead">
            Transparantie staat centraal bij Toy Delights. Hier vind je al onze juridische documenten in duidelijke taal.
          </p>
        </div>
      </section>

      <section className={styles.links}>
        <div className="container">
          <div className={styles.linkGrid}>
            {legalLinks.map((link) => (
              <article key={link.to} className="surface-card">
                <h2>{link.title}</h2>
                <p>{link.description}</p>
                <Link to={link.to} className={styles.link}>
                  Bekijk document →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default LegalHubPage;