import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ToolsPage.module.css';

const colorWords = {
  '#ff6b6b': 'Frambozenrood',
  '#ffd45a': 'Zonnestraal',
  '#6edcc4': 'Mintgroen',
  '#66c0ff': 'Luchtblauw',
  '#b19cd9': 'Lavendel',
};

const shapes = [
  {
    name: 'Cirkel',
    description: 'Perfect voor het oefenen van fijne motoriek. Laat kinderen cirkels tekenen en knippen.',
  },
  {
    name: 'Driehoek',
    description: 'Helpt kinderen patronen ontdekken en basiswiskunde begrijpen.',
  },
  {
    name: 'Ster',
    description: 'Ideaal voor verhalen en beloningssystemen. Laat ze hun eigen sterrenhemel maken.',
  },
];

const ToolsPage = () => {
  const [selectedColor, setSelectedColor] = useState('#66c0ff');
  const [selectedShape, setSelectedShape] = useState(shapes[0]);
  const [puzzlePieces, setPuzzlePieces] = useState([false, false, false, false]);

  const colorName = useMemo(() => colorWords[selectedColor] || 'Speelse kleur', [selectedColor]);

  const handleTogglePiece = (index) => {
    setPuzzlePieces((prev) => prev.map((piece, i) => (i === index ? !piece : piece)));
  };

  const solved = puzzlePieces.every(Boolean);

  return (
    <>
      <Helmet>
        <title>Toy Delights | Speelse tools & mini-games</title>
        <meta
          name="description"
          content="Speel en leer online met Toy Delights. Ontdek onze kleurkiezer, vormensorteerder en mini puzzels voor kinderen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Tools voor spelletjes tussendoor</h1>
          <p className="lead">
            Korte, leuke opdrachten voor thuis of in de klas. Ze versterken creativiteit, taal en samenwerking.
          </p>
        </div>
      </section>

      <section className={styles.tools}>
        <div className="container">
          <div className={`${styles.toolGrid} grid`}>
            <article className="surface-card">
              <h2>Kleurenlab</h2>
              <p>Kies een kleur en laat je kind vertellen wat erbij past: geuren, geluiden, herinneringen.</p>
              <div className={styles.colorPreview} style={{ backgroundColor: selectedColor }} aria-hidden="true" />
              <label htmlFor="color-picker" className={styles.visuallyHidden}>
                Selecteer kleur
              </label>
              <input
                id="color-picker"
                type="color"
                value={selectedColor}
                onChange={(event) => setSelectedColor(event.target.value)}
                className={styles.colorInput}
                aria-label="Kies een kleur"
              />
              <p className={styles.colorName}>Huidige selectie: {colorName}</p>
            </article>

            <article className="surface-card">
              <h2>Vormensorteerder</h2>
              <p>Klik op een vorm en bespreek waar je die vorm in huis of in de natuur terugziet.</p>
              <div className={styles.shapeButtons}>
                {shapes.map((shape) => {
                  const active = selectedShape.name === shape.name;
                  return (
                    <button
                      key={shape.name}
                      type="button"
                      className={`${styles.shapeButton} ${active ? styles.shapeButtonActive : ''}`}
                      onClick={() => setSelectedShape(shape)}
                    >
                      {shape.name}
                    </button>
                  );
                })}
              </div>
              <div className={styles.shapeDescription}>
                <h3>{selectedShape.name}</h3>
                <p>{selectedShape.description}</p>
              </div>
            </article>

            <article className="surface-card">
              <h2>Fantasiereis puzzel</h2>
              <p>Activeer alle sterren en bedenk samen een reisverhaal. Elke ster staat voor een tussenstop.</p>
              <div className={styles.puzzleBoard}>
                {puzzlePieces.map((piece, index) => (
                  <button
                    key={`piece-${index}`}
                    type="button"
                    className={`${styles.puzzlePiece} ${piece ? styles.puzzlePieceActive : ''}`}
                    onClick={() => handleTogglePiece(index)}
                    aria-pressed={piece}
                  >
                    {piece ? '⭐' : '☆'}
                  </button>
                ))}
              </div>
              <p className={styles.puzzleStatus}>
                {solved ? 'Hoera! Vertel een extra spannende eindbestemming.' : 'Hint: Welke ster breng je als volgende tot leven?'}
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <h2>Speel verder met onze gids</h2>
            <p>
              Combineer deze mini-games met speelgoedadvies uit onze interactieve gids voor urenlang plezier.
            </p>
            <a className="btn" href="/guide">
              Ga naar de gids
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default ToolsPage;