import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './HomePage.module.css';

const featuredToys = [
  {
    name: 'Houten Regenboog Stapelaar',
    age: '18m+',
    img: 'https://images.unsplash.com/photo-1604881415181-04a3c7c39138?auto=format&fit=crop&w=800&q=80',
    description: 'Stimuleert kleurherkenning en fijne motoriek.',
  },
  {
    name: 'Verhalenprojector Sterrennacht',
    age: '3+',
    img: 'https://images.unsplash.com/photo-1615485290382-84e9b1c0d0c0?auto=format&fit=crop&w=800&q=80',
    description: 'Brengt klassieke verhaaltjes tot leven voor het slapengaan.',
  },
  {
    name: 'Robot Bouwkit Junior',
    age: '6+',
    img: 'https://images.unsplash.com/photo-1502759683299-cdcd6974244f?auto=format&fit=crop&w=800&q=80',
    description: 'Introduceert programmeren via speelse opdrachten.',
  },
  {
    name: 'Zachte Muziekblokken',
    age: '12m+',
    img: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=800&q=80',
    description: 'Elke beweging maakt een verrassing geluid.',
  },
];

const newArrivals = [
  {
    name: 'Mini Chef Kookstudio',
    img: 'https://images.unsplash.com/photo-1550179400-0cf6b3c03761?auto=format&fit=crop&w=800&q=80',
    highlight: 'Roleplay',
  },
  {
    name: 'Eco Blokkenset Bosvriendjes',
    img: 'https://images.unsplash.com/photo-1615485737485-6e0c2279e9b4?auto=format&fit=crop&w=800&q=80',
    highlight: 'Duurzaam',
  },
  {
    name: 'Magnetische Wereldkaart',
    img: 'https://images.unsplash.com/photo-1545239351-ef35f43d514b?auto=format&fit=crop&w=800&q=80',
    highlight: 'Geografie',
  },
];

const testimonials = [
  {
    quote:
      'Onze dochter Lotte is dol op de interactieve gids. Zo handig om snel speelgoed te vinden dat perfect bij haar past.',
    name: 'Sarah, mama van Lotte (4)',
  },
  {
    quote:
      'De kwaliteit is zichtbaar. Speelgoed dat lang meegaat én in huis prachtig staat.',
    name: 'Thomas en Elise, ouders van Vic (6)',
  },
  {
    quote:
      'Ik waardeer de uitgebreide info over veiligheid. Het voelt geruststellend om hier te bestellen.',
    name: 'Mira, mama van Yara (2)',
  },
];

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Speelgoed dat harten laat zingen</title>
        <meta
          name="description"
          content="Toy Delights is dé plek voor kwaliteitsvol kinderspeelgoed in België. Ontdek onze geselecteerde favorieten, nieuwe aanwinsten en educatieve hulpmiddelen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <span className={`${styles.heroBadge} badge`}>Nieuw in België</span>
              <h1>Speelgoed dat kleine harten laat zingen</h1>
              <p className={styles.heroText}>
                Van eerste stapjes tot grote avonturen: Toy Delights biedt een warme selectie speelgoed die ontwikkeling, veiligheid en verwondering combineert.
              </p>
              <div className={styles.heroActions}>
                <Link to="/guide" className="btn">
                  Ontdek speelgoed
                </Link>
                <Link to="/programmas" className="btn btn--outline">
                  Onze belofte
                </Link>
              </div>
              <div className={styles.heroStats}>
                <div>
                  <strong>250+</strong>
                  <span>Speelgoedselecties getest door ouders</span>
                </div>
                <div>
                  <strong>15</strong>
                  <span>Belgische educatieve partners</span>
                </div>
                <div>
                  <strong>100%</strong>
                  <span>Veiligheidscontrole door experts</span>
                </div>
              </div>
            </div>
            <div className={styles.heroVisual} aria-hidden="true">
              <img
                src="https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80"
                alt="Gelukkig kind spelend met speelgoed"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.featured}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Uitgelichte speelgoedhelden</h2>
            <p>Handgekozen favorieten die ouders vertrouwen en kinderen doen glunderen.</p>
          </div>
          <div className={`${styles.featureGrid} grid`}>
            {featuredToys.map((toy, index) => (
              <article key={toy.name} className={`${styles.toyCard} surface-card fade-in`} style={{ animationDelay: `${index * 0.1}s` }}>
                <img src={toy.img} alt={toy.name} className={styles.toyImage} loading="lazy" />
                <div className={styles.toyContent}>
                  <div className={styles.toyHeader}>
                    <h3>{toy.name}</h3>
                    <span className="tag">Leeftijd {toy.age}</span>
                  </div>
                  <p>{toy.description}</p>
                  <button type="button" className={styles.toyButton} aria-label={`Bekijk ${toy.name}`}>
                    Bekijk details →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.newArrivals}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Nieuwe aanwinsten</h2>
            <p>Vers binnen, liefdevol geselecteerd voor inspirerende speelmomenten.</p>
          </div>
          <div className={`${styles.arrivalsGrid} grid`}>
            {newArrivals.map((item, index) => (
              <article key={item.name} className={`${styles.arrivalCard} fade-in`} style={{ animationDelay: `${index * 0.12}s` }}>
                <img src={item.img} alt={item.name} />
                <div className={styles.arrivalContent}>
                  <span className="badge">{item.highlight}</span>
                  <h3>{item.name}</h3>
                  <p>Ontdek speelse details en educatieve tips in onze shop.</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.education}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Educatief spelen, elke dag</h2>
            <p className="lead">
              Spel is de taal van kinderen. Met de juiste materialen ontdekken ze nieuwe werelden en bouwen ze aan zelfvertrouwen.
            </p>
          </div>
          <div className={`${styles.educationGrid} grid`}>
            <div className={styles.educationCard}>
              <h3>Creatieve taalontwikkeling</h3>
              <p>Verhaaltjes, rollenspel en muziek stimuleren woordenschat en empathie.</p>
              <ul>
                <li>Interactieve boeken en poppentheater</li>
                <li>Rollenspel sets voor fantasievol spelen</li>
                <li>Zachte muziekinstrumenten voor ritmegevoel</li>
              </ul>
            </div>
            <div className={styles.educationCard}>
              <h3>STEM voor nieuwsgierige denkers</h3>
              <p>Kleine ontdekkers leren logisch denken met toegankelijke experimenten.</p>
              <ul>
                <li>Robotica kits voor beginners</li>
                <li>Magnetische bouwsystemen</li>
                <li>Wetenschap in een koffer</li>
              </ul>
            </div>
            <div className={styles.educationCard}>
              <h3>Motoriek & mindfulness</h3>
              <p>Beweging, evenwicht en rustmomenten helpen kinderen groeien.</p>
              <ul>
                <li>Balansspellen en loopparcours</li>
                <li>Sensorische materialen</li>
                <li>Adem- en yogakaarten voor kids</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.safety}>
        <div className="container">
          <div className={styles.safetyContent}>
            <h2>Veiligheid & kwaliteit voorop</h2>
            <p>
              Elk product wordt kritisch beoordeeld door ons team van pedagogen, technische experts en ouders. We controleren materialen, duurzaamheid en ethische productie.
            </p>
            <div className={styles.badges}>
              <div className={styles.badgeCard}>
                <span role="img" aria-label="Certificaat">
                  ✅
                </span>
                <strong>Europees CE-gecertificeerd</strong>
                <p>Strenge naleving van alle EU-speelgoednormen.</p>
              </div>
              <div className={styles.badgeCard}>
                <span role="img" aria-label="Blad">
                  🌿
                </span>
                <strong>Eco-partners</strong>
                <p>Materialen uit duurzaam beheerde bossen en gerecycleerde bronnen.</p>
              </div>
              <div className={styles.badgeCard}>
                <span role="img" aria-label="Hand">
                  🤝
                </span>
                <strong>Eerlijke productie</strong>
                <p>Partners met transparante arbeidsvoorwaarden en lokale impact.</p>
              </div>
            </div>
          </div>
          <div className={styles.safetyIllustration} aria-hidden="true">
            <img
              src="https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?auto=format&fit=crop&w=900&q=80"
              alt="Glimlachend kind met veilig speelgoed"
            />
          </div>
        </div>
      </section>

      <section className={styles.guide}>
        <div className="container">
          <div className={styles.guideInner}>
            <div className={styles.guideContent}>
              <h2>Onze interactieve gids</h2>
              <p>
                Geen stress meer over wat je best cadeau doet. De Toy Delights gids vertaalt leeftijd, interesses en ontwikkelingsdoelen naar concrete aanbevelingen.
              </p>
              <ul className={`${styles.guideList} list-reset`}>
                <li>⭐ Persoonlijke selectie in minder dan twee minuten</li>
                <li>🎁 Cadeautips voor verschillende gelegenheden</li>
                <li>🧠 Tips van onze pedagogen voor educatief speelplezier</li>
              </ul>
              <Link to="/guide" className="btn">
                Probeer de gids
              </Link>
            </div>
            <div className={styles.guideCard}>
              <h3>Zo werkt het</h3>
              <ol>
                <li>Kies de leeftijd en interessezone van het kind</li>
                <li>Ontvang een samengestelde selectie</li>
                <li>Lees onze speelsuggesties en veiligheidstips</li>
              </ol>
              <p className={styles.guideNote}>
                Tip: voeg je favoriete selecties toe aan je verlanglijstje om te delen met familie.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Blije ouders vertellen</h2>
          </div>
          <div className={`${styles.testimonialGrid} grid`}>
            {testimonials.map((item, index) => (
              <figure key={item.name} className={`${styles.testimonialCard} fade-in`} style={{ animationDelay: `${index * 0.14}s` }}>
                <blockquote>{item.quote}</blockquote>
                <figcaption>— {item.name}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.newsletter}>
        <div className="container">
          <div className={styles.newsletterBox}>
            <div>
              <h2>Blijf op de hoogte van onze speelse wereld</h2>
              <p>Ontvang inspirerende ideeën voor spel, exclusieve samenwerkingen en tips van onze experts.</p>
            </div>
            <form className={styles.newsletterForm} action="#">
              <label htmlFor="newsletter-email" className="sr-only">
                E-mailadres
              </label>
              <input
                id="newsletter-email"
                type="email"
                name="email"
                placeholder="jouw@e-mail.be"
                required
                aria-label="E-mailadres"
              />
              <button type="submit" className="btn">
                Inschrijven
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;