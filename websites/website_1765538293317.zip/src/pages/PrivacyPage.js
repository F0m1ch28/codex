import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Privacybeleid</title>
        <meta
          name="description"
          content="Lees hoe Toy Delights omgaat met persoonsgegevens en deze zorgvuldig beschermt."
        />
      </Helmet>
      <section className={styles.legal}>
        <div className="container">
          <h1>Privacybeleid</h1>
          <p>Laatste update: 10 april 2024</p>

          <h2>1. Verantwoordelijke</h2>
          <p>
            Toy Delights BV is verantwoordelijk voor de verwerking van persoonsgegevens. Je kan ons bereiken op hallo@toydelights.be.
          </p>

          <h2>2. Welke gegevens verzamelen we?</h2>
          <ul>
            <li>Identificatiegegevens: naam, adres, contactgegevens</li>
            <li>Bestelgegevens: producten, leveringen, betaalstatus</li>
            <li>Communicatie: e-mails, feedback en servicetickets</li>
            <li>Websitegebruik: analytische gegevens voor optimalisatie</li>
          </ul>

          <h2>3. Doeleinden en rechtsgronden</h2>
          <p>
            We gebruiken gegevens om bestellingen uit te voeren, klantenservice te bieden, ons aanbod te verbeteren en wettelijke verplichtingen na te leven. Verwerking gebeurt op basis van overeenkomst, gerechtvaardigd belang of toestemming.
          </p>

          <h2>4. Delen van gegevens</h2>
          <p>
            Gegevens worden enkel gedeeld met logistieke partners, betaalproviders en IT-dienstverleners die dezelfde veiligheidsnormen hanteren. Er vindt geen verkoop van gegevens plaats.
          </p>

          <h2>5. Bewaartermijnen</h2>
          <p>
            We bewaren persoonsgegevens niet langer dan noodzakelijk. Facturatiegegevens bewaren we conform fiscale verplichtingen.
          </p>

          <h2>6. Rechten van betrokkenen</h2>
          <p>
            Je hebt recht op inzage, correctie, verwijdering, beperking en overdraagbaarheid van je gegevens. Neem contact op via hallo@toydelights.be voor een verzoek.
          </p>

          <h2>7. Beveiliging</h2>
          <p>
            Toy Delights neemt passende technische en organisatorische maatregelen, waaronder versleuteling, toegangscontrole en regelmatige audits.
          </p>

          <h2>8. Cookies</h2>
          <p>
            Zie ons cookiebeleid voor details over het gebruik van cookies en voorkeuren.
          </p>

          <h2>9. Wijzigingen</h2>
          <p>
            We kunnen dit beleid bijwerken en informeren je via onze website. Raadpleeg deze pagina regelmatig.
          </p>
        </div>
      </section>
    </>
  );
};

export default PrivacyPage;