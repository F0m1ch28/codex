import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const teamMembers = [
  {
    name: 'Annelies Vandenberg',
    role: 'Oprichtster & Pedagogisch adviseur',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Lise Jacobs',
    role: 'Inkoop & duurzaamheid',
    image: 'https://images.unsplash.com/photo-1544723795-43253798e984?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Samir De Wilde',
    role: 'Veiligheidscoördinator',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
  },
];

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Over ons</title>
        <meta
          name="description"
          content="Maak kennis met Toy Delights: ons verhaal, onze waarden en het team dat zich inzet voor veilig en inspirerend speelgoed in België."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div>
              <span className="badge">Over ons</span>
              <h1>Een familie van speelgoedliefhebbers</h1>
              <p className="lead">
                Toy Delights werd geboren uit de wens om ouders te ontzorgen en kinderen elke dag groeikansen te bieden. We selecteren speelgoed dat duurzaam, mooi en pedagogisch sterk is.
              </p>
            </div>
            <div className={styles.heroImage}>
              <img
                src="https://images.unsplash.com/photo-1525498128493-380d1990a112?auto=format&fit=crop&w=1000&q=80"
                alt="Team dat speelgoed sorteert"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div className="surface-card">
              <h2>Ons verhaal</h2>
              <p>
                Na jaren ervaring in de kinderopvang zag Annelies hoe lastig het was om betrouwbaar speelgoed te vinden. Ze begon Toy Delights in Antwerpen met een kleine selectie houten speelgoed en een grote droom.
              </p>
              <p>
                Vandaag werken we met een team van pedagogen, designers en kwaliteitscontroleurs om gezinnen over heel België te ondersteunen. We organiseren speelsessies, testen nieuwe producten en luisteren naar feedback.
              </p>
            </div>
            <div className="surface-card">
              <h2>Onze waarden</h2>
              <ul>
                <li><strong>Zorgzaamheid:</strong> Elk product wordt persoonlijk geëvalueerd.</li>
                <li><strong>Transparantie:</strong> We delen onze herkomst en testen openlijk.</li>
                <li><strong>Inclusie:</strong> Speelgoed dat elk kind laat schitteren, ongeacht achtergrond of behoefte.</li>
                <li><strong>Duurzaamheid:</strong> Materialen en partners die een betere wereld mee bouwen.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Het Toy Delights team</h2>
            <p>Met veel liefde en expertise brengen wij het beste speelgoed tot bij jou.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} />
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;