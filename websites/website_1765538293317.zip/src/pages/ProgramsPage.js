import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ProgramsPage.module.css';

const ProgramsPage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Veiligheids- en partnerprogramma&apos;s</title>
        <meta
          name="description"
          content="Leer hoe Toy Delights samenwerkt met veiligheidslaboratoria en eco-partners om de hoogste standaard voor kinderspeelgoed in België te garanderen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className="badge">Transparante programma’s</span>
          <h1>Onze programma’s voor veiligheid, duurzaamheid en vertrouwen</h1>
          <p className="lead">
            Elk speelgoedstuk in onze collectie doorloopt een zorgvuldige route: van ethische productie tot onafhankelijke kwaliteitstests in België en Europa.
          </p>
        </div>
      </section>

      <section className={styles.programs}>
        <div className="container">
          <div className={`${styles.grid} grid`}>
            <article className="surface-card fade-in">
              <h2>Veiligheid Lab-traject</h2>
              <p>
                In samenwerking met een onafhankelijk laboratorium in Gent testen we speelgoed op chemische stoffen, scherpe randen en duurzaamheid.
              </p>
              <ul>
                <li>CE en EN-71 certificeringen bevestigd</li>
                <li>Extra testen op kleurstoffen en geurstoffen</li>
                <li>Rapporten beschikbaar op aanvraag voor ouders</li>
              </ul>
            </article>
            <article className="surface-card fade-in" style={{ animationDelay: '0.1s' }}>
              <h2>Eco Makers Collective</h2>
              <p>
                Een netwerk van Europese producenten die inzetten op hernieuwbare materialen, respectvolle arbeid en circulaire verpakkingen.
              </p>
              <ul>
                <li>Gebruik van FSC® en PEFC® gecertificeerd hout</li>
                <li>Verf op waterbasis en gerecycleerd karton</li>
                <li>Compensatie van transport via bosherstelprojecten</li>
              </ul>
            </article>
            <article className="surface-card fade-in" style={{ animationDelay: '0.2s' }}>
              <h2>Pedagogisch Expertpanel</h2>
              <p>
                Leuvense pedagogen, logopedisten en ergotherapeuten beoordelen elk product op ontwikkelingswaarde en speelvariaties.
              </p>
              <ul>
                <li>Tips voor ouder-kind interactie bij elk artikel</li>
                <li>Adviezen voor verschillende leerstijlen</li>
                <li>Inclusieve aanbevelingen voor diverse behoeften</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.partners}>
        <div className="container">
          <div className={styles.partnersContent}>
            <div className={styles.partnersText}>
              <h2>Onze samenwerkingen</h2>
              <p>
                We kiezen voor partners die net als wij geloven in aandacht, zorg en vreugde. Jaarlijks bezoeken we ateliers en fabrieken om de mensen achter het speelgoed te ontmoeten.
              </p>
              <div className={styles.partnerList}>
                <div>
                  <h3>Made in Europe</h3>
                  <p>70% van ons assortiment komt uit België, Nederland, Frankrijk en Duitsland.</p>
                </div>
                <div>
                  <h3>Lokale ateliers</h3>
                  <p>We ondersteunen kleine ateliers met veilige werkplekken en langdurige samenwerking.</p>
                </div>
                <div>
                  <h3>Educatieve partners</h3>
                  <p>Samenwerking met Belgische scholen en bibliotheken voor testmomenten en feedback.</p>
                </div>
              </div>
            </div>
            <div className={styles.partnersImage}>
              <img
                src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=80"
                alt="Ambachtslieden die houten speelgoed afwerken"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.commitment}>
        <div className="container">
          <div className={styles.commitmentBox}>
            <h2>Onze belofte aan Belgische gezinnen</h2>
            <p>
              We verbinden ons ertoe elk kwartaal een transparant rapport te delen met resultaten van veiligheidsinspecties, duurzaamheidsdoelen en toekomstige verbeteringen.
            </p>
            <div className={styles.commitmentStats}>
              <div>
                <strong>93%</strong>
                <span>van onze producten scoorde hoogste veiligheidslabel in 2023</span>
              </div>
              <div>
                <strong>48%</strong>
                <span>reductie van plastic in verpakkingen afgelopen jaar</span>
              </div>
              <div>
                <strong>120+</strong>
                <span>ouderfeedbacksessies georganiseerd in Vlaanderen</span>
              </div>
            </div>
            <button type="button" className="btn btn--outline">
              Lees het laatste rapport
            </button>
          </div>
        </div>
      </section>
    </>
  );
};

export default ProgramsPage;