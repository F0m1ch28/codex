import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!formData.name || !formData.email || !formData.message) {
      setStatus({ type: 'error', message: 'Vul alle velden in zodat we je gericht kunnen helpen.' });
      return;
    }

    setStatus({ type: 'success', message: 'Bedankt voor je bericht! We nemen snel contact op.' });
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Toy Delights | Contact</title>
        <meta
          name="description"
          content="Neem contact op met Toy Delights voor vragen over speelgoed, veiligheid of onze diensten."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>We helpen je graag verder</h1>
          <p className="lead">
            Heb je een vraag over een product, zoek je advies of wil je samenwerken? Laat iets weten en we reageren snel.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <div className="surface-card">
              <h2>Contactgegevens</h2>
              <p>
                <strong>Adres:</strong> Toy Delights, Antwerpen, België
              </p>
              <p>
                <strong>Telefoon:</strong> +32 123 45 67 89
              </p>
              <p>
                <strong>E-mail:</strong> hallo@toydelights.be
              </p>
              <div className={styles.mapWrapper}>
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Belgium_location_map.svg/640px-Belgium_location_map.svg.png"
                  alt="Kaart van België met Antwerpen gemarkeerd"
                />
              </div>
            </div>
            <div className="surface-card">
              <h2>Stuur ons een bericht</h2>
              <form onSubmit={handleSubmit} noValidate>
                <div>
                  <label htmlFor="name">Naam</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Je naam"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email">E-mail</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="jij@voorbeeld.be"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="message">Bericht</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Waarmee kunnen we helpen?"
                    required
                  />
                </div>
                <button type="submit" className="btn">
                  Verstuur
                </button>
                {status.type === 'error' && (
                  <p className="error-message" role="alert">
                    {status.message}
                  </p>
                )}
                {status.type === 'success' && (
                  <p className="success-message" role="status">
                    {status.message}
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;