import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './GuidePage.module.css';

const guideOptions = [
  {
    range: '0-12 maanden',
    focus: ['Zintuiglijke prikkels', 'Veilige bijtspeeltjes', 'Rustgevende muziek'],
    recommendations: ['Sensorische knisperdoeken', 'Babygym met contrastkleuren', 'Zachte muziekdoos'],
  },
  {
    range: '1-2 jaar',
    focus: ['Motorische vaardigheden', 'Eerste puzzels', 'Rollenspel'],
    recommendations: ['Houten duw- en trekdiertjes', 'Eerste puzzels met grote stukken', 'Mini keukenset'],
  },
  {
    range: '3-4 jaar',
    focus: ['Fantasie', 'Taalontwikkeling', 'Probleemoplossend denken'],
    recommendations: ['Verkleedsets', 'Verhalenlimonade spel', 'Educatieve spelletjes met kleuren en vormen'],
  },
  {
    range: '5-6 jaar',
    focus: ['STEM basis', 'Creativiteit', 'Samen spelen'],
    recommendations: ['Magnetische bouwblokken', 'Knutselfabriek', 'Coöperatieve bordspellen'],
  },
  {
    range: '7-8 jaar',
    focus: ['Technologie', 'Logisch denken', 'Zelfvertrouwen'],
    recommendations: ['Codeer-robot', 'Wetenschapskits', 'Toneel- en verhalenwerkplaats'],
  },
  {
    range: '9+ jaar',
    focus: ['Diepgaande projecten', 'Wereldontdekking', 'Actieve spelmomenten'],
    recommendations: ['Architectuursets', 'Wereldpuzzel 3D', 'Outdoor ontdekkit'],
  },
];

const interestTags = ['Creatief', 'Muzikaal', 'Actief', 'STEM', 'Rustig', 'Samen'];

const GuidePage = () => {
  const [selectedRange, setSelectedRange] = useState(guideOptions[2]);
  const [selectedInterests, setSelectedInterests] = useState([]);

  const handleChangeRange = (event) => {
    const option = guideOptions.find((item) => item.range === event.target.value);
    if (option) {
      setSelectedRange(option);
    }
  };

  const toggleInterest = (interest) => {
    setSelectedInterests((prev) =>
      prev.includes(interest)
        ? prev.filter((item) => item !== interest)
        : [...prev, interest]
    );
  };

  const suggestion = useMemo(() => {
    const base = selectedRange.recommendations;
    if (selectedInterests.length === 0) {
      return base;
    }
    const interestText = selectedInterests.join(', ').toLowerCase();
    if (interestText.includes('stem')) {
      return [...base, 'Excursieset voor kleine ingenieurs', 'Junior labkoffer'];
    }
    if (interestText.includes('creatief')) {
      return [...base, 'Illustratie-atelier met storycards', 'Expressief klei-lab'];
    }
    if (interestText.includes('rustig')) {
      return [...base, 'Mindfulness kaarten voor kinderen', 'Zachte licht projector'];
    }
    return base;
  }, [selectedRange, selectedInterests]);

  return (
    <>
      <Helmet>
        <title>Toy Delights | Speelgoed gids</title>
        <meta
          name="description"
          content="Gebruik de interactieve gids van Toy Delights om speelgoed te kiezen dat past bij de leeftijd, interesses en ontwikkeling van jouw kind."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <span className="badge">Interactief hulpmiddel</span>
              <h1>Vind het perfecte speelgoed in drie stappen</h1>
              <p>
                Geef de leeftijd en interesses in en ontdek speelse aanbevelingen samengesteld door onze pedagogische experts.
              </p>
            </div>
            <div className={styles.heroCard}>
              <h2>Stap 1 • Kies de leeftijdscategorie</h2>
              <label htmlFor="age-range">Leeftijd</label>
              <select id="age-range" value={selectedRange.range} onChange={handleChangeRange}>
                {guideOptions.map((option) => (
                  <option key={option.range} value={option.range}>
                    {option.range}
                  </option>
                ))}
              </select>
              <div className={styles.focusArea}>
                <h3>Waarop focussen we?</h3>
                <ul className="list-reset">
                  {selectedRange.focus.map((item) => (
                    <li key={item}>• {item}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.interests}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Stap 2 • Kies interesses</h2>
            <p>Selecteer wat het kind blij maakt. Combineer gerust verschillende interesses.</p>
          </div>
          <div className={styles.tags}>
            {interestTags.map((interest) => {
              const active = selectedInterests.includes(interest);
              return (
                <button
                  key={interest}
                  type="button"
                  className={`${styles.tagButton} ${active ? styles.tagButtonActive : ''}`}
                  onClick={() => toggleInterest(interest)}
                  aria-pressed={active}
                >
                  {interest}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.recommendations}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Stap 3 • Aanbevolen speelgoed</h2>
            <p>
              Onze speelse match voor leeftijd {selectedRange.range}. Klik door naar de shop voor beschikbaarheid en tips.
            </p>
          </div>
          <div className={`${styles.recGrid} grid`}>
            {suggestion.map((item) => (
              <article key={item} className="surface-card fade-in">
                <h3>{item}</h3>
                <p>
                  Inclusief speels advies, veiligheidscontrole en suggesties voor ouder-kindmomenten.
                </p>
                <button type="button" className={styles.recButton}>
                  Bekijk selectie →
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default GuidePage;