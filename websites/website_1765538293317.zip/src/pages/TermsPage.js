import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsPage.module.css';

const TermsPage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Algemene voorwaarden</title>
        <meta
          name="description"
          content="Raadpleeg de algemene voorwaarden van Toy Delights over bestellingen, levering en service."
        />
      </Helmet>
      <section className={styles.legal}>
        <div className="container">
          <h1>Algemene voorwaarden</h1>
          <p>Laatste update: 10 april 2024</p>

          <h2>1. Definities</h2>
          <p>
            In deze algemene voorwaarden verwijst “Toy Delights”, “wij” of “ons” naar Toy Delights BV, gevestigd in Antwerpen, België. “Klant” verwijst naar iedere natuurlijke of rechtspersoon die een bestelling plaatst of een overeenkomst sluit met Toy Delights.
          </p>

          <h2>2. Toepasselijkheid</h2>
          <p>
            Deze voorwaarden zijn van toepassing op elke aanbieding, bestelling en overeenkomst tussen Toy Delights en de klant. Afwijkingen zijn enkel geldig indien schriftelijk overeengekomen.
          </p>

          <h2>3. Aanbod en producten</h2>
          <p>
            We streven naar een accurate weergave van producten, prijzen en beschikbaarheid. Kleuren kunnen afwijken door beeldscherminstellingen. Toy Delights behoudt zich het recht voor het aanbod te wijzigen.
          </p>

          <h2>4. Bestellen en betaling</h2>
          <ul>
            <li>Bestellingen zijn definitief na bevestiging via e-mail.</li>
            <li>Betalingen verlopen via erkende betaalproviders.</li>
            <li>Bij niet-tijdige betaling hebben we het recht de bestelling te annuleren.</li>
          </ul>

          <h2>5. Levering</h2>
          <p>
            Leveringen gebeuren binnen België via geselecteerde bezorgpartners. Levertermijnen zijn indicatief. Vertraging geeft geen recht op schadevergoeding, tenzij anders overeengekomen.
          </p>

          <h2>6. Herroepingsrecht</h2>
          <p>
            Consumenten hebben recht op 14 dagen herroepingsrecht na ontvangst, mits het product ongebruikt en in originele verpakking wordt teruggestuurd. Gepersonaliseerde producten zijn uitgesloten.
          </p>

          <h2>7. Garantie</h2>
          <p>
            We bieden minstens de wettelijke garantie. Bij een defect neem je contact op via hallo@toydelights.be met ordernummer en beschrijving.
          </p>

          <h2>8. Aansprakelijkheid</h2>
          <p>
            Toy Delights is niet aansprakelijk voor gevolgschade. Onze totale aansprakelijkheid is beperkt tot het bedrag van de bestelling.
          </p>

          <h2>9. Overmacht</h2>
          <p>
            In geval van overmacht worden verplichtingen opgeschort. Indien de situatie langer dan 30 dagen duurt, kunnen beide partijen de overeenkomst beëindigen.
          </p>

          <h2>10. Toepasselijk recht</h2>
          <p>Belgisch recht is van toepassing. Geschillen worden beslecht door de bevoegde rechtbank te Antwerpen.</p>
        </div>
      </section>
    </>
  );
};

export default TermsPage;