import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePage.module.css';

const CookiePage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Cookiebeleid</title>
        <meta
          name="description"
          content="Ontdek hoe Toy Delights cookies inzet om de website-ervaring te verbeteren."
        />
      </Helmet>
      <section className={styles.legal}>
        <div className="container">
          <h1>Cookiebeleid</h1>
          <p>Laatste update: 10 april 2024</p>

          <h2>1. Wat zijn cookies?</h2>
          <p>
            Cookies zijn kleine tekstbestanden die op je toestel worden opgeslagen wanneer je onze website bezoekt. Ze helpen de site goed functioneren en geven inzicht in gebruik.
          </p>

          <h2>2. Welke cookies gebruiken we?</h2>
          <ul>
            <li><strong>Functionele cookies:</strong> noodzakelijk voor basisfunctionaliteiten.</li>
            <li><strong>Analytische cookies:</strong> anonieme statistieken om de site te verbeteren.</li>
            <li><strong>Voorkeurscookies:</strong> onthouden je taalkeuze en winkelvoorkeuren.</li>
          </ul>

          <h2>3. Hoe beheer je cookies?</h2>
          <p>
            Bij je eerste bezoek vragen we toestemming voor niet-noodzakelijke cookies. Je kan instellingen altijd wijzigen via de browser of door contact op te nemen met hallo@toydelights.be.
          </p>

          <h2>4. Duur</h2>
          <p>
            Cookies hebben een beperkte levensduur. Analytische cookies bewaren we maximaal 14 maanden.
          </p>

          <h2>5. Vragen</h2>
          <p>
            Vragen over ons cookiebeleid? Mail naar hallo@toydelights.be.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePage;