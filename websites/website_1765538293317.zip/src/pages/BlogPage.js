import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './BlogPage.module.css';

const blogPosts = [
  {
    title: 'Waarom vrij spel essentieel is voor kleuters',
    excerpt:
      'Ontdek hoe vrij spel kinderen helpt om zelfvertrouwen, empathie en creativiteit te ontwikkelen.',
    image: 'https://images.unsplash.com/photo-1495409612731-975c87533f2a?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: '5 speelse STEM-activiteiten voor thuis',
    excerpt:
      'Met eenvoudige materialen en veel plezier kun je wetenschappelijke verwondering wekken bij kinderen.',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Een duurzame speelgoedkast samenstellen',
    excerpt:
      'Kies bewust voor kwaliteit en modulariteit. We delen onze checklist voor gezinnen in België.',
    image: 'https://images.unsplash.com/photo-1589730256271-45a0890bcdde?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Samen spelen, samen groeien',
    excerpt:
      'Kleine rituelen maken het verschil. Ontdek onze tips voor verbindende speelmomenten.',
    image: 'https://images.unsplash.com/photo-1484976063834-7ae3bca9f0de?auto=format&fit=crop&w=900&q=80',
  },
];

const BlogPage = () => {
  return (
    <>
      <Helmet>
        <title>Toy Delights | Blog over spel & ontwikkeling</title>
        <meta
          name="description"
          content="Laat je inspireren door Toy Delights met artikels over spel, leren en kindontwikkeling, speciaal voor Belgische gezinnen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className="badge">Blog</span>
          <h1>Ideeën voor spel, leren en verbondenheid</h1>
          <p className="lead">
            Onze pedagogische experts delen tips en verhalen rechtstreeks uit de speelkamer.
          </p>
        </div>
      </section>

      <section className={styles.articles}>
        <div className="container">
          <div className={styles.articleGrid}>
            {blogPosts.map((post, index) => (
              <article key={post.title} className={`${styles.article} surface-card fade-in`} style={{ animationDelay: `${index * 0.1}s` }}>
                <img src={post.image} alt={post.title} />
                <div className={styles.articleContent}>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <button type="button" className={styles.readMore}>
                    Lees verder →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default BlogPage;