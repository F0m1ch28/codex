document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  const cookieBanner = document.getElementById("cookie-banner");
  const cookieAccept = cookieBanner ? cookieBanner.querySelector("[data-cookie-accept]") : null;
  const cookieDecline = cookieBanner ? cookieBanner.querySelector("[data-cookie-decline]") : null;
  const toast = document.getElementById("global-toast");
  const currentYearSpans = document.querySelectorAll(".js-current-year");

  currentYearSpans.forEach(span => {
    span.textContent = new Date().getFullYear();
  });

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = body.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    primaryNav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        body.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const preferredLanguage = localStorage.getItem("preferredLanguage");
  const currentLanguage = body.dataset.language;
  if (!preferredLanguage) {
    localStorage.setItem("preferredLanguage", currentLanguage || "nl");
  }

  document.querySelectorAll(".language-link[data-language-target]").forEach(link => {
    link.addEventListener("click", event => {
      const targetLang = link.dataset.languageTarget;
      localStorage.setItem("preferredLanguage", targetLang);
      if (body.classList.contains("nav-open")) {
        body.classList.remove("nav-open");
        if (navToggle) {
          navToggle.setAttribute("aria-expanded", "false");
        }
      }
    });
  });

  const consentKey = "jtpayCookieConsent";
  const storedConsent = localStorage.getItem(consentKey);
  if (!storedConsent && cookieBanner) {
    cookieBanner.classList.add("active");
  }

  const handleCookieChoice = choice => {
    localStorage.setItem(consentKey, choice);
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
    showToast(choice === "accepted" ? getCookieMessage("accepted", currentLanguage) : getCookieMessage("declined", currentLanguage));
  };

  if (cookieAccept) {
    cookieAccept.addEventListener("click", () => handleCookieChoice("accepted"));
  }
  if (cookieDecline) {
    cookieDecline.addEventListener("click", () => handleCookieChoice("declined"));
  }

  const forms = document.querySelectorAll("form.js-contact-form");
  forms.forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const redirectTarget = form.dataset.redirect || "thank-you.html";
      showToast(getFormToastMessage(currentLanguage));
      setTimeout(() => {
        window.location.href = redirectTarget;
      }, 1800);
    });
  });

  const animatedBlocks = document.querySelectorAll(".animate-on-scroll");
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.25 });

  animatedBlocks.forEach(block => observer.observe(block));

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 3200);
  }

  function getCookieMessage(lang) {
    if (lang === "en") {
      return {
        accepted: "Cookie preferences saved. Enjoy exploring JT Pay.",
        declined: "Cookie preference stored. Essential features remain active."
      };
    }
    return {
      accepted: "Cookievoorkeur opgeslagen. Veel plezier op JT Pay.",
      declined: "Cookievoorkeur bewaard. Essentiële functies blijven actief."
    };
  }

  function getFormToastMessage(lang) {
    if (lang === "en") {
      return "Message received. Redirecting to confirmation…";
    }
    return "Bericht ontvangen. We leiden je zo door naar de bevestiging…";
  }
});