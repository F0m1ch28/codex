import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Health from './pages/Health';
import Behavior from './pages/Behavior';
import Gallery from './pages/Gallery';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';
import styles from './App.module.css';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className={styles.app}>
      <Helmet>
        <title>Мир Кошек — портал о кошках</title>
        <meta
          name="description"
          content="Мир Кошек — ваш надежный помощник в мире кошек: породы, уход, здоровье, поведение и вдохновляющие истории."
        />
      </Helmet>
      <ScrollToTopOnRouteChange />
      <Header />
      <main className={styles.mainContent}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/porody-koshek" element={<About />} />
          <Route path="/uhod-i-soderzhanie" element={<Services />} />
          <Route path="/zdorove-koshki" element={<Health />} />
          <Route path="/povedenie-koshek" element={<Behavior />} />
          <Route path="/galereya" element={<Gallery />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/spasibo" element={<ThankYou />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsOfService />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPolicy />} />
          <Route path="/politika-cookie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;