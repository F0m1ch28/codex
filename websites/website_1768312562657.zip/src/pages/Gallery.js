import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Gallery.module.css';

const images = [
  { src: 'https://placekitten.com/420/360', alt: 'Фото кошки, лежащей на подоконнике' },
  { src: 'https://placekitten.com/421/360', alt: 'Фото котёнка с игрушкой' },
  { src: 'https://placekitten.com/422/360', alt: 'Фото кота, выглядывающего из коробки' },
  { src: 'https://placekitten.com/423/360', alt: 'Фото пушистой кошки на кресле' },
  { src: 'https://placekitten.com/424/360', alt: 'Фото кошки с большими глазами' },
  { src: 'https://placekitten.com/425/360', alt: 'Фото кота в саду' },
  { src: 'https://placekitten.com/426/360', alt: 'Фото котёнка, играющего с клубком' },
  { src: 'https://placekitten.com/427/360', alt: 'Фото кошки в картонной коробке' },
  { src: 'https://placekitten.com/428/360', alt: 'Фото кота, смотрящего в окно' }
];

const GalleryPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Галерея читателей — Мир Кошек</title>
      <meta
        name="description"
        content="Галерея трогательных фотографий кошек от читателей портала Мир Кошек. Делитесь своими историями и вдохновляйтесь."
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Галерея</h1>
      <p>
        Каждое фото — история дружбы. Делитесь снимками своих питомцев, и мы с радостью опубликуем их в галерее.
      </p>
    </header>

    <section className={styles.section}>
      <div className={styles.grid}>
        {images.map((image) => (
          <figure key={image.src} className={styles.card}>
            <img src={image.src} alt={image.alt} loading="lazy" />
            <figcaption>Добрая история от читателей «Мира Кошек»</figcaption>
          </figure>
        ))}
      </div>
    </section>
  </div>
);

export default GalleryPage;