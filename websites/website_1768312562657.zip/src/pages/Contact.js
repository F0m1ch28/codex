import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите имя.';
    } else if (!/^[A-Za-zА-Яа-яЁё\s'-]{2,}$/.test(formData.name.trim())) {
      newErrors.name = 'Имя должно содержать только буквы и быть длиной от 2 символов.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Введите электронную почту.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Введите корректный адрес электронной почты.';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Напишите ваше сообщение.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Сообщение должно содержать минимум 10 символов.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      const sanitizedData = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        message: formData.message.trim()
      };
      console.log('Передано сообщение:', sanitizedData);
      setFormData(initialState);
      navigate('/spasibo', { state: { name: sanitizedData.name } });
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Связаться с командой — Мир Кошек</title>
        <meta
          name="description"
          content="Контактная информация портала Мир Кошек. Напишите команде, чтобы задать вопросы, поделиться опытом или предложить сотрудничество."
        />
      </Helmet>
      <header className={styles.header}>
        <h1>Свяжитесь с «Миром Кошек»</h1>
        <p>
          Мы открыты для предложений, историй о ваших питомцах и профессиональных консультаций.
          Напишите нам — ответим в течение двух рабочих дней.
        </p>
      </header>

      <div className={styles.contentGrid}>
        <section className={styles.contactInfo} aria-labelledby="contact-info-title">
          <h2 id="contact-info-title">Контактные данные</h2>
          <p><strong>Адрес:</strong> г. Москва, ул. Кошачья, д. 15</p>
          <p><strong>Телефон:</strong> +7 (495) 123-45-67</p>
          <p><strong>Email:</strong> info@mir-koshek.ru</p>
          <div className={styles.infoBlock}>
            <h3>Часы работы</h3>
            <p>Понедельник — Пятница: 10:00–19:00</p>
            <p>Суббота: 11:00–16:00</p>
            <p>Воскресенье: по предварительной записи</p>
          </div>
          <div className={styles.mapWrapper}>
            <iframe
              title="Офис Мир Кошек"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.483090536858!2d37.617494477412616!3d55.75582697313324!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a5a75d8bfa7%3A0xbaa6ed7d4f2f1d2!2z0JzQvtGB0LrQstCw0YAg0KHQvtCx0LjQutC4INCc0LDQvdC40LPRgNC40Y8g0KfQtdGC0LDRgNC40LzQsNC90LjRjw!5e0!3m2!1sru!2sru!4v1700000000000!5m2!1sru!2sru"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </section>

        <section className={styles.formSection} aria-labelledby="contact-form-title">
          <h2 id="contact-form-title">Написать сообщение</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="name">Имя</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
                placeholder="Ваше имя"
                required
              />
              {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
                placeholder="example@mail.ru"
                required
              />
              {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
                placeholder="Например: хочу поделиться историей о своём коте..."
                required
              />
              {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
            </div>
            <button type="submit" className={styles.submitButton}>Отправить</button>
            <p className={styles.formHint}>
              Отправляя сообщение, вы соглашаетесь с{' '}
              <a href="/usloviya-ispolzovaniya" target="_blank" rel="noopener noreferrer">условиями использования</a>.
            </p>
          </form>
        </section>
      </div>
    </div>
  );
};

export default ContactPage;