import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useLocation } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYouPage = () => {
  const location = useLocation();
  const name = location.state?.name;

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Спасибо за обращение — Мир Кошек</title>
        <meta
          name="description"
          content="Спасибо за ваше сообщение. Команда Мир Кошек свяжется с вами в ближайшее время."
        />
      </Helmet>
      <div className={styles.card}>
        <h1>Спасибо за доверие{ name ? ", ${name}" : '' }!</h1>
        <p>
          Мы получили ваше сообщение и ответим как можно скорее. Пока вы ждёте, приглашаем прочитать свежие статьи или заглянуть в галерею.
        </p>
        <div className={styles.actions}>
          <Link to="/" className={styles.primaryButton}>На главную</Link>
          <Link to="/galereya" className={styles.secondaryButton}>Галерея</Link>
        </div>
      </div>
    </div>
  );
};

export default ThankYouPage;