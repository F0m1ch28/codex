import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования cookie — Мир Кошек</title>
      <meta
        name="description"
        content="Информация о том, какие cookie-файлы использует портал Мир Кошек и как управлять настройками."
      />
    </Helmet>
    <h1>Политика использования cookie</h1>
    <p className={styles.updated}>Последнее обновление: 1 марта 2024 года</p>
    <section>
      <h2>1. Что такое cookie</h2>
      <p>
        Cookie — небольшие файлы, которые сохраняются на вашем устройстве и помогают сайту корректно функционировать.
        Благодаря cookie мы запоминаем ваши предпочтения и анализируем, как используется сайт.
      </p>
    </section>
    <section>
      <h2>2. Какие cookie мы используем</h2>
      <ul>
        <li><strong>Функциональные:</strong> обеспечивают работу форм и запоминание предпочтений.</li>
        <li><strong>Аналитические:</strong> помогают понять, какие разделы наиболее популярны. Передаются обезличенные данные.</li>
        <li><strong>Маркетинговые:</strong> используются только при согласии для персонализации рассылок.</li>
      </ul>
    </section>
    <section>
      <h2>3. Управление cookie</h2>
      <p>
        Вы можете изменить настройки браузера, чтобы блокировать или удалять cookie.
        Однако некоторые функции сайта могут работать некорректно без этих файлов.
      </p>
    </section>
    <section>
      <h2>4. Связь с нами</h2>
      <p>
        По вопросам использования cookie свяжитесь с нами по адресу info@mir-koshek.ru.
      </p>
    </section>
  </div>
);

export default CookiePolicy;