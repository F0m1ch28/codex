import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const Home = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Мир Кошек — вдохновение и знания о котах</title>
      <meta
        name="description"
        content="Портал Мир Кошек рассказывает о породах, уходе, здоровье и поведении котов. Советами делятся эксперты и любители. Присоединяйтесь к сообществу!"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <h1>Мир Кошек — портал, где хвостатые друзья становятся ближе</h1>
          <p>
            Мы собираем опыт заводчиков, ветеринаров и владельцев, чтобы вы могли уверенно заботиться
            о своем питомце, понимать его настроение и вдохновляться историями со всего мира.
          </p>
          <div className={styles.heroButtons}>
            <Link to="/porody-koshek" className={styles.primaryButton}>
              Изучить породы
            </Link>
            <Link to="/galereya" className={styles.secondaryButton}>
              Посмотреть галерею
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://placekitten.com/600/480"
            alt="Фото кошки в уютной комнате"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </div>
    </section>

    <section className={styles.featuresSection}>
      <div className="container">
        <h2>Что вы найдёте на портале</h2>
        <p className={styles.sectionIntro}>
          Мы создали пространство, где забота о кошках превращается в удовольствие. Узнайте об особенностях питомцев и найдите союзников среди единомышленников.
        </p>
        <div className={styles.featuresGrid}>
          <article className={styles.featureCard}>
            <h3>Глубокие обзоры пород</h3>
            <p>Подробные профили с историей происхождения, характером и рекомендациями по содержанию каждой породы.</p>
          </article>
          <article className={styles.featureCard}>
            <h3>Советы специалистов</h3>
            <p>Экспертные рекомендации по питанию, гигиене и профилактике заболеваний от практикующих ветеринаров.</p>
          </article>
          <article className={styles.featureCard}>
            <h3>Понимание поведения</h3>
            <p>Учимся читать язык тела кошки, понимать эмоции и строить доверительные отношения с питомцем.</p>
          </article>
          <article className={styles.featureCard}>
            <h3>Сообщество</h3>
            <p>Истории читателей, конкурсы, челленджи и вдохновляющие фотографии в нашей уютной галерее.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.aboutSection}>
      <div className="container">
        <div className={styles.aboutGrid}>
          <div className={styles.aboutContent}>
            <h2>Кто стоит за «Миром Кошек»</h2>
            <p>
              Мы — команда журналистов, фелинологов и дизайнеров, объединённых любовью к котам.
              Каждая статья проходит фактчекинг, а фотографии подбираются с заботой об эстетике и благополучии животных.
            </p>
            <p>
              Мы верим, что гармоничная жизнь с кошкой строится на уважении, внимательности и знании её индивидуальности.
            </p>
            <Link to="/kontakty" className={styles.outlineButton}>
              Познакомиться ближе
            </Link>
          </div>
          <div className={styles.teamGallery}>
            <figure className={styles.teamCard}>
              <img src="https://placekitten.com/300/300" alt="Фото кошки рядом с ноутбуком" loading="lazy" />
              <figcaption>Аня — редактор и куратор рубрик о поведении</figcaption>
            </figure>
            <figure className={styles.teamCard}>
              <img src="https://placekitten.com/301/300" alt="Фото кошки с игрушкой" loading="lazy" />
              <figcaption>Сергей — фелинолог, консультант по породам</figcaption>
            </figure>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.breedsPreview}>
      <div className="container">
        <h2>Популярные породы месяца</h2>
        <div className={styles.breedsGrid}>
          <article className={styles.breedCard}>
            <img src="https://placekitten.com/360/240" alt="Фото кошки породы мейн-кун" loading="lazy" />
            <div className={styles.cardContent}>
              <h3>Мейн-кун</h3>
              <p>Крупный североамериканский гигант с мягким характером и удивительной коммуникабельностью.</p>
              <Link to="/porody-koshek" className={styles.cardLink}>Профиль породы</Link>
            </div>
          </article>
          <article className={styles.breedCard}>
            <img src="https://placekitten.com/361/240" alt="Фото кошки породы сиамская" loading="lazy" />
            <div className={styles.cardContent}>
              <h3>Сиамская</h3>
              <p>Энергичная умница с выразительными глазами и привязанностью к людям.</p>
              <Link to="/porody-koshek" className={styles.cardLink}>Профиль породы</Link>
            </div>
          </article>
          <article className={styles.breedCard}>
            <img src="https://placekitten.com/362/240" alt="Фото кошки породы русская голубая" loading="lazy" />
            <div className={styles.cardContent}>
              <h3>Русская голубая</h3>
              <p>Элегантная порода с бархатной шубкой и спокойным нравом, идеальна для городских квартир.</p>
              <Link to="/porody-koshek" className={styles.cardLink}>Профиль породы</Link>
            </div>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.careSection}>
      <div className="container">
        <h2>Советы по уходу, которые работают</h2>
        <div className={styles.careGrid}>
          <article>
            <h3>Ежедневный комфорт</h3>
            <ul>
              <li>Поддерживайте чистоту мисок и лотка, это снижает стресс кошки.</li>
              <li>Обогащайте пространство: используйте полки, когтеточки, укрытия.</li>
              <li>Играйте минимум 15 минут в день, чередуя типы игрушек.</li>
            </ul>
          </article>
          <article>
            <h3>Здоровое питание</h3>
            <ul>
              <li>Выбирайте корм по возрасту и потребностям под контролем ветеринара.</li>
              <li>Следите за доступом к свежей воде и используйте фонтанчики.</li>
              <li>Избегайте резкой смены рациона, вводите новинки постепенно.</li>
            </ul>
          </article>
          <article>
            <h3>Красота и гигиена</h3>
            <ul>
              <li>Регулярно расчёсывайте шерсть, чтобы предотвратить колтуны.</li>
              <li>Проверяйте глаза, уши и когти еженедельно.</li>
              <li>Используйте мягкие шампуни и кондиционеры для кошек.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.behaviorSection}>
      <div className="container">
        <h2>Понимаем поведение</h2>
        <div className={styles.behaviorGrid}>
          <div>
            <h3>Язык хвоста и ушей</h3>
            <p>Положение хвоста и ушей моментально расскажет о настроении. Мы объясняем, как распознавать сигналы, чтобы не пропустить тревогу или радость.</p>
          </div>
          <div>
            <h3>Игровые ритуалы</h3>
            <p>Сценарии охоты, которые кошка проигрывает в играх, помогают ей чувствовать себя уверенно. Делимся сценариями игр и подборками аксессуаров.</p>
          </div>
          <div>
            <h3>Мягкая адаптация</h3>
            <p>Переезды и знакомство с новыми людьми часто вызывают стресс. Наши гайды помогают сделать перемены безопасными.</p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.testimonials}>
      <div className="container">
        <h2>Отзывы читателей</h2>
        <div className={styles.testimonialGrid}>
          <figure className={styles.testimonialCard}>
            <img src="https://placekitten.com/120/120" alt="Фото кошки рядом с владельцем" loading="lazy" />
            <blockquote>
              «Благодаря рекомендациям Мир Кошек мы помогли нашему коту пережить переезд без стресса. Особенно понравились чек-листы по адаптации!»
            </blockquote>
            <figcaption>Мария и кот Лео</figcaption>
          </figure>
          <figure className={styles.testimonialCard}>
            <img src="https://placekitten.com/121/120" alt="Фото довольной кошки" loading="lazy" />
            <blockquote>
              «Нашли на сайте идеальную породу — теперь дома живёт ласковая бурманская красавица. Люблю ваши обзоры и визуализацию!»
            </blockquote>
            <figcaption>Илья и кошка Луна</figcaption>
          </figure>
          <figure className={styles.testimonialCard}>
            <img src="https://placekitten.com/122/120" alt="Фото кота в корзине" loading="lazy" />
            <blockquote>
              «Регулярно заглядываю за советами по питанию. Удобно, что вся информация структурирована, а материалы обновляются.»
            </blockquote>
            <figcaption>Светлана и кот Барсик</figcaption>
          </figure>
        </div>
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className="container">
        <div className={styles.ctaCard}>
          <h2>Готовы поделиться историей?</h2>
          <p>Присылайте фотографии, рассказывайте о своих любимцах, задавайте вопросы экспертам. Мы ценим участие каждого читателя.</p>
          <Link to="/kontakty" className={styles.primaryButton}>
            Написать команде
          </Link>
        </div>
      </div>
    </section>
  </div>
);

export default Home;