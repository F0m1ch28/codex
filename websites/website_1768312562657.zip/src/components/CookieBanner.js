import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'mirKoshekCookieConsent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Мы используем cookie, чтобы сайт «Мир Кошек» работал корректно и помогал подбирать лучший контент.
        Продолжая пользоваться сайтом, вы соглашаетесь с использованием файлов cookie.
      </p>
      <button type="button" onClick={handleAccept} className={styles.acceptButton}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;