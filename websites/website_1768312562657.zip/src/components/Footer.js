import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.inner}>
      <div className={styles.column}>
        <p className={styles.brandTitle}>Мир Кошек</p>
        <p className={styles.brandDescription}>
          Теплый информационный портал для тех, кто любит кошек и стремится понять их лучше.
          Мы собираем знания, советы и вдохновение, чтобы жизнь с питомцем была гармоничной.
        </p>
        <div className={styles.socials} aria-label="Социальные сети">
          <a href="https://vk.com" target="_blank" rel="noopener noreferrer" aria-label="Мы во ВКонтакте">
            VK
          </a>
          <a href="https://ok.ru" target="_blank" rel="noopener noreferrer" aria-label="Мы в Одноклассниках">
            OK
          </a>
          <a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Мы в Telegram">
            TG
          </a>
        </div>
      </div>
      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Навигация</h3>
        <ul className={styles.linksList}>
          <li><Link to="/">Главная</Link></li>
          <li><Link to="/porody-koshek">Породы кошек</Link></li>
          <li><Link to="/uhod-i-soderzhanie">Уход и содержание</Link></li>
          <li><Link to="/zdorove-koshki">Здоровье</Link></li>
          <li><Link to="/povedenie-koshek">Поведение</Link></li>
          <li><Link to="/galereya">Галерея</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Контакты</h3>
        <address className={styles.address}>
          <p>г. Москва, ул. Кошачья, д. 15</p>
          <Link to="/kontakty" className={styles.contactLink}>+7 (495) 123-45-67</Link>
          <Link to="/kontakty" className={styles.contactLink}>info@mir-koshek.ru</Link>
        </address>
        <p className={styles.supportText}>
          Имеются вопросы? Напишите нам — команда с удовольствием поможет.
        </p>
      </div>
    </div>
    <div className={styles.bottomRow}>
      <p>© {new Date().getFullYear()} Мир Кошек. Все права защищены.</p>
      <div className={styles.legalLinks}>
        <Link to="/usloviya-ispolzovaniya">Условия использования</Link>
        <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
        <Link to="/politika-cookie">Политика cookie</Link>
      </div>
    </div>
  </footer>
);

export default Footer;