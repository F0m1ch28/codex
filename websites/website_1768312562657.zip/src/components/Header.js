import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Главная' },
  { path: '/porody-koshek', label: 'Породы' },
  { path: '/uhod-i-soderzhanie', label: 'Уход' },
  { path: '/zdorove-koshki', label: 'Здоровье' },
  { path: '/povedenie-koshek', label: 'Поведение' },
  { path: '/galereya', label: 'Галерея' },
  { path: '/kontakty', label: 'Контакты' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={styles.navbar}>
        <Link to="/" className={styles.logo} aria-label="На главную страницу Мир Кошек">
          Мир&nbsp;Кошек
        </Link>
        <button
          type="button"
          className={styles.menuButton}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Открыть меню"
        >
          <span className={styles.menuIcon} />
        </button>
        <nav
          id="primary-navigation"
          className={"${styles.navLinks} ${menuOpen ? styles.open : ''}"}
          aria-label="Основная навигация"
        >
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={handleLinkClick}
              className={({ isActive }) =>
                isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <Link to="/kontakty" className={styles.ctaLink} onClick={handleLinkClick}>
          Связаться
        </Link>
      </div>
    </header>
  );
};

export default Header;