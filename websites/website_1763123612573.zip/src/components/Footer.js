import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className="container">
        <div className={styles.grid}>
          <div>
            <div className={styles.logo}>
              <span className={styles.logoMark}>R</span>
              <span>Redshavtjk</span>
            </div>
            <p>
              Redshavtjk is Sweden’s home for industry-powered IT learning, connecting students,
              career changers, and professionals to future-proof skills and opportunities across the EU.
            </p>
          </div>

          <div>
            <h4>Explore</h4>
            <ul>
              <li><Link to="/courses">Browse courses</Link></li>
              <li><Link to="/paths">Learning paths</Link></li>
              <li><Link to="/services">Services</Link></li>
              <li><Link to="/resources">Resources</Link></li>
            </ul>
          </div>

          <div>
            <h4>Support</h4>
            <ul>
              <li><Link to="/contact">Talk to an advisor</Link></li>
              <li><Link to="/terms">Terms of use</Link></li>
              <li><Link to="/privacy">Privacy policy</Link></li>
              <li><Link to="/cookie-policy">Cookie policy</Link></li>
            </ul>
          </div>

          <div>
            <h4>Contact</h4>
            <address>
              Sweden address placeholder<br />
              Email: [to be added]<br />
              Phone: [to be added]
            </address>
            <div className={styles.newsletter}>
              <label htmlFor="footer-email">Stay in the loop</label>
              <div className={styles.newsletterForm}>
                <input id="footer-email" type="email" placeholder="Email address" aria-label="Email address" />
                <button type="button">Subscribe</button>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>&copy; {new Date().getFullYear()} Redshavtjk. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;