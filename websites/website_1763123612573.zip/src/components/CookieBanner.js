import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem('redshavtjk-cookie-consent');
    if (!consent) {
      const timeout = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timeout);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('redshavtjk-cookie-consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('redshavtjk-cookie-consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="region" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h4>We value your privacy</h4>
        <p>
          We use essential cookies to ensure a smooth learning experience and to understand how our platform is used.
          You can learn more in our <a href="/cookie-policy">cookie policy</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={handleDecline} className="btn btnSecondary">
          Decline
        </button>
        <button type="button" onClick={handleAccept} className="btn btnPrimary">
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;