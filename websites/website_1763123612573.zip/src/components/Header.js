import React from 'react';
import { NavLink } from 'react-router-dom';
import { useLocation } from 'react-router';
import styles from './Header.module.css';

const Header = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const location = useLocation();

  React.useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  React.useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : 'auto';
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  return (
    <header className={styles.header}>
      <div className="container">
        <div className={styles.bar}>
          <NavLink to="/" className={styles.brand} aria-label="Redshavtjk home">
            <div className={styles.logo}>
              <span className={styles.logoMark}>R</span>
              <span className={styles.logoText}>Redshavtjk</span>
            </div>
          </NavLink>

          <nav className={`${styles.nav} ${isOpen ? styles.open : ''}`} aria-label="Main navigation">
            <NavLink
              to="/courses"
              className={({ isActive }) => (isActive ? styles.active : undefined)}
            >
              Courses
            </NavLink>
            <NavLink
              to="/paths"
              className={({ isActive }) => (isActive ? styles.active : undefined)}
            >
              Learning paths
            </NavLink>
            <NavLink
              to="/services"
              className={({ isActive }) => (isActive ? styles.active : undefined)}
            >
              Services
            </NavLink>
            <NavLink
              to="/resources"
              className={({ isActive }) => (isActive ? styles.active : undefined)}
            >
              Resources
            </NavLink>
            <NavLink
              to="/about"
              className={({ isActive }) => (isActive ? styles.active : undefined)}
            >
              About
            </NavLink>
            <NavLink
              to="/contact"
              className={({ isActive }) => (isActive ? styles.active : undefined)}
              className={`${styles.ctaLink}`}
            >
              Talk to an advisor
            </NavLink>
          </nav>

          <button
            className={styles.menuButton}
            type="button"
            onClick={() => setIsOpen((prev) => !prev)}
            aria-expanded={isOpen}
            aria-controls="mobile-navigation"
            aria-label="Toggle navigation"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;