import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Paths.module.css';

const paths = [
  {
    title: 'Frontend Developer',
    intro:
      'Craft immersive, accessible digital experiences using modern JavaScript, component-driven design, and collaborative workflows.',
    steps: [
      'Intro to Modern Programming (6 weeks)',
      'Modern JavaScript Foundations (8 weeks)',
      'UX Engineering Studio (8 weeks)',
      'Frontend Mastery Capstone & Career Sprint (4 weeks)'
    ],
    outcomes: ['React + TypeScript proficiency', 'Design system implementation', 'Portfolio-ready interfaces']
  },
  {
    title: 'Backend Developer',
    intro:
      'Design reliable backend services with Python and Node, manage databases, and deliver tested, scalable APIs.',
    steps: [
      'Programming Logic & Patterns (6 weeks)',
      'Python for Services & APIs (7 weeks)',
      'Node.js & Cloud-native Backends (8 weeks)',
      'DevOps Fundamentals & Deployment (4 weeks)'
    ],
    outcomes: ['REST & GraphQL APIs', 'CI/CD pipelines', 'Containerised deployments']
  },
  {
    title: 'Data Analyst',
    intro:
      'Turn data into actionable insights through statistics, visual storytelling, and applied analytics projects for Nordic industries.',
    steps: [
      'Data Literacy Essentials (4 weeks)',
      'Python & SQL for Analytics (8 weeks)',
      'Data Visualisation & Storytelling (6 weeks)',
      'Analytics Capstone & Career Sprint (4 weeks)'
    ],
    outcomes: ['Data storytelling', 'Stakeholder-ready dashboards', 'Analytical problem solving']
  },
  {
    title: 'Cloud Fundamentals',
    intro:
      'Build the core competencies required to operate in hybrid cloud environments with a focus on resilience, security, and sustainability.',
    steps: [
      'Cloud Foundations with AWS & Azure (7 weeks)',
      'Infrastructure as Code with Terraform (5 weeks)',
      'Observability & Site Reliability (6 weeks)',
      'Cloud Architecture Challenge (4 weeks)'
    ],
    outcomes: ['Cloud provider certifications', 'Operational excellence mindset', 'EU-compliant architectures']
  }
];

const Paths = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Learning Paths | Redshavtjk</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Learning paths designed for transformational outcomes</h1>
          <p>
            Follow structured sequences with mentor support, live clinics, and EU-focused career preparation that
            take you from foundational understanding to demonstrable mastery.
          </p>
        </div>
      </section>

      <section className={styles.gridWrapper}>
        <div className="container">
          <div className={styles.grid}>
            {paths.map((path) => (
              <article key={path.title}>
                <div className={styles.header}>
                  <h2>{path.title}</h2>
                  <p>{path.intro}</p>
                </div>
                <div className={styles.body}>
                  <h3>Sequence</h3>
                  <ol>
                    {path.steps.map((step) => (
                      <li key={step}>{step}</li>
                    ))}
                  </ol>
                  <h3>Outcomes</h3>
                  <ul>
                    {path.outcomes.map((outcome) => (
                      <li key={outcome}>{outcome}</li>
                    ))}
                  </ul>
                </div>
                <div className={styles.footer}>
                  <a href="/contact" className="btn btnGhost">
                    Start learning
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Paths;