import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Resources.module.css';

const blogPosts = [
  {
    title: 'Five strategies for balancing study with full-time work',
    summary:
      'Discover proven techniques from alumni who balanced demanding roles and family life while completing Redshavtjk programmes.',
    date: 'April 10, 2024'
  },
  {
    title: 'How Swedish employers evaluate junior portfolios',
    summary:
      'Understand what hiring managers look for in code samples, storytelling, and cultural readiness across the Nordics.',
    date: 'March 25, 2024'
  },
  {
    title: 'Visa pathways and study options for EU career movers',
    summary:
      'A guide to navigating immigration requirements, funding opportunities, and digital nomad frameworks in Sweden.',
    date: 'March 8, 2024'
  }
];

const guides = [
  'Guide to blended learning success',
  'Checklist for transitioning into tech careers',
  'Preparing for your first mentor session',
  'Building an impact-driven portfolio'
];

const faqs = [
  {
    question: 'Can I pause and resume my studies?',
    answer:
      'Yes. We offer study breaks and flexible pacing with support to reintegrate into cohorts or continue self-paced milestones.'
  },
  {
    question: 'Are scholarships available?',
    answer:
      'We partner with organisations to offer scholarships prioritising women in tech, newcomers to Sweden, and career changers.'
  },
  {
    question: 'Do you support corporate training?',
    answer:
      'Our enterprise team delivers bespoke programmes, internal academies, and talent evaluations for organisations.'
  }
];

const Resources = () => {
  const [openFaq, setOpenFaq] = React.useState(null);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Resources | Redshavtjk guides and insights</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Resources to guide every step of your learning journey</h1>
          <p>
            Explore articles, guides, and FAQs designed to support students, professionals, and organisations engaging
            with Redshavtjk programmes.
          </p>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Latest posts</h2>
            <p>Insights from our mentors, advisors, and learners across Sweden and the EU.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.summary}</p>
                <a href="/resources">Read more →</a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.guides}>
        <div className="container">
          <div className={styles.guidesBox}>
            <h2>Practical guides</h2>
            <ul>
              {guides.map((guide) => (
                <li key={guide}>{guide}</li>
              ))}
            </ul>
            <p>Request the full guidebook by connecting with our advisor team.</p>
            <a href="/contact" className="btn btnPrimary">
              Request guide
            </a>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Frequently asked questions</h2>
            <p>Find quick answers or reach out to our team for personalised support.</p>
          </div>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => {
              const open = openFaq === index;
              return (
                <article key={faq.question} className={open ? styles.open : ''}>
                  <button type="button" onClick={() => setOpenFaq(open ? null : index)} aria-expanded={open}>
                    {faq.question}
                    <span>{open ? '−' : '+'}</span>
                  </button>
                  <div className={styles.answer} aria-hidden={!open}>
                    <p>{faq.answer}</p>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Resources;