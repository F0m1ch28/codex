import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Courses.module.css';

const coursesData = [
  {
    title: 'Intro to Modern Programming',
    topic: 'Programming',
    level: 'Beginner',
    duration: '6 weeks',
    format: 'Online',
    tags: ['Evening', 'Online'],
    summary: 'Develop core coding logic through Python projects inspired by Nordic sustainability goals.'
  },
  {
    title: 'Fullstack JavaScript Lab',
    topic: 'Web Development',
    level: 'Intermediate',
    duration: '10 weeks',
    format: 'Blended',
    tags: ['Blended', 'Evening'],
    summary: 'Build React and Node applications with TypeScript, GraphQL, and cloud deployment fundamentals.'
  },
  {
    title: 'UX Engineering Studio',
    topic: 'Web Development',
    level: 'Intermediate',
    duration: '8 weeks',
    format: 'Online',
    tags: ['Online', 'Project'],
    summary: 'Create accessible, human-centred interfaces with design systems and inclusive interaction patterns.'
  },
  {
    title: 'Data Analytics Accelerator',
    topic: 'Data',
    level: 'Intermediate',
    duration: '9 weeks',
    format: 'Blended',
    tags: ['Evening', 'Hybrid'],
    summary: 'Work with Python, SQL, and Tableau to deliver actionable insights for Nordic industries.'
  },
  {
    title: 'Machine Learning Applications',
    topic: 'Data',
    level: 'Advanced',
    duration: '12 weeks',
    format: 'Online',
    tags: ['Online', 'Capstone'],
    summary: 'Design ethical ML pipelines with scikit-learn, MLOps practices, and bias-aware evaluation.'
  },
  {
    title: 'Cloud Foundations with AWS & Azure',
    topic: 'Cloud',
    level: 'Beginner',
    duration: '7 weeks',
    format: 'Online',
    tags: ['Evening', 'Online'],
    summary: 'Explore core cloud services, infrastructure automation, and security basics across leading platforms.'
  },
  {
    title: 'DevOps & Platform Engineering',
    topic: 'Cloud',
    level: 'Advanced',
    duration: '11 weeks',
    format: 'Blended',
    tags: ['Hybrid', 'Career Sprint'],
    summary: 'Master CI/CD, Kubernetes, observability, and resilience with Swedish industry mentors.'
  },
  {
    title: 'Cybersecurity Essentials',
    topic: 'Security',
    level: 'Beginner',
    duration: '8 weeks',
    format: 'Online',
    tags: ['Evening', 'Online'],
    summary: 'Learn threat modelling, incident response, and secure coding practices for EU organisations.'
  }
];

const Courses = () => {
  const [level, setLevel] = React.useState('All');
  const [topic, setTopic] = React.useState('All');
  const [format, setFormat] = React.useState('All');

  const filteredCourses = coursesData.filter((course) => {
    const levelMatch = level === 'All' || course.level === level;
    const topicMatch = topic === 'All' || course.topic === topic;
    const formatMatch = format === 'All' || course.format === format;
    return levelMatch && topicMatch && formatMatch;
  });

  const levels = ['All', 'Beginner', 'Intermediate', 'Advanced'];
  const topics = ['All', 'Programming', 'Web Development', 'Data', 'Cloud', 'Security'];
  const formats = ['All', 'Online', 'Blended'];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Courses | Redshavtjk catalogue</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Browse Redshavtjk courses</h1>
          <p>Flexible programmes designed for students, career changers, and professionals across Sweden and the EU.</p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className="container">
          <div className={styles.filterGrid}>
            <label>
              Level
              <select value={level} onChange={(e) => setLevel(e.target.value)}>
                {levels.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </label>
            <label>
              Topic
              <select value={topic} onChange={(e) => setTopic(e.target.value)}>
                {topics.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </label>
            <label>
              Format
              <select value={format} onChange={(e) => setFormat(e.target.value)}>
                {formats.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </label>
          </div>
        </div>
      </section>

      <section className={styles.catalogue}>
        <div className="container">
          <div className={styles.courseGrid}>
            {filteredCourses.map((course) => (
              <article key={course.title}>
                <div className={styles.header}>
                  <span>{course.topic}</span>
                  <h2>{course.title}</h2>
                </div>
                <p>{course.summary}</p>
                <ul className={styles.meta}>
                  <li><strong>Duration:</strong> {course.duration}</li>
                  <li><strong>Level:</strong> {course.level}</li>
                  <li><strong>Format:</strong> {course.format}</li>
                </ul>
                <div className={styles.tags}>
                  {course.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
                <button type="button" className="btn btnGhost">
                  Talk to an advisor
                </button>
              </article>
            ))}
            {filteredCourses.length === 0 && (
              <div className={styles.empty}>
                <h3>No courses match your filters yet.</h3>
                <p>Adjust your selections or connect with our advisors for personalised recommendations.</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Courses;