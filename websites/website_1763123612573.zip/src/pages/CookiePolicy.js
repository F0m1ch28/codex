import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | Redshavtjk</title>
    </Helmet>
    <div className="container">
      <h1>Cookie Policy</h1>
      <p>Last updated: April 2024</p>
      <p>
        This Cookie Policy explains how Redshavtjk uses cookies and similar technologies when you visit our platform.
        Cookies help us provide essential functionality, analyse engagement, and improve our services.
      </p>
      <h2>Essential cookies</h2>
      <p>Required for secure login, session management, and enabling core platform features.</p>
      <h2>Analytics cookies</h2>
      <p>Used to understand usage trends and improve learning experiences. You can opt out at any time.</p>
      <h2>Managing cookies</h2>
      <p>
        You can update your preferences through your browser settings or disable non-essential cookies via the consent
        banner.
      </p>
      <h2>Contact</h2>
      <p>Questions about our cookie practices can be directed to the Redshavtjk team via the contact page.</p>
    </div>
  </div>
);

export default CookiePolicy;