import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About Redshavtjk | Scandinavian IT learning for all</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <span className={styles.kicker}>Our story</span>
              <h1>Redshavtjk was built to make Swedish tech education accessible, human, and future-ready.</h1>
              <p>
                Founded by a collective of engineers, educators, and career strategists, Redshavtjk supports learners
                across Sweden and the EU with inclusive programmes that emphasise collaboration, real-world impact, and a sustainable tech culture.
              </p>
            </div>
            <div className={styles.heroCard}>
              <img src="https://picsum.photos/800/600?random=201" alt="Modern learning environment in Sweden" loading="lazy" />
              <p>
                Our campus labs in Stockholm and Göteborg host hybrid sessions, meetups, and partner hackdays that keep
                our learning community vibrant and industry-aligned.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>What guides our work</h2>
            <p>We create safe, high-performing environments that celebrate curiosity and empower every learner.</p>
          </div>
          <div className={styles.valuesGrid}>
            <article>
              <h3>People-first design</h3>
              <p>
                Scandinavian pedagogy is grounded in trust, autonomy, and accessibility. We translate this ethos into
                personalised pathways, flexible support, and inclusive storytelling.
              </p>
            </article>
            <article>
              <h3>Industry integration</h3>
              <p>
                Advisory councils with Swedish startups, scale-ups, and public sector innovators ensure our curriculum
                evolves with the technologies and challenges that matter today.
              </p>
            </article>
            <article>
              <h3>Sustainable skills</h3>
              <p>
                Beyond tools, we cultivate collaboration, continuous learning, and ethical decision-making — the skills
                resilient careers are built on.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.partners}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Trusted by organisations shaping the Nordic digital economy</h2>
            <p>Our graduates join teams across energy, public sector, fintech, and design-focused businesses.</p>
          </div>
          <div className={styles.partnerBadges}>
            <span>Stockholm Tech Hub</span>
            <span>Nordic Dev Guild</span>
            <span>Göteborg Innovation Lab</span>
            <span>EU Digital Futures</span>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Milestones on our journey</h2>
          </div>
          <div className={styles.timelineGrid}>
            <div>
              <h3>2017</h3>
              <p>Redshavtjk launches in Stockholm with evening web development programmes for career changers.</p>
            </div>
            <div>
              <h3>2019</h3>
              <p>We expand to blended learning, opening our Göteborg lab and adding cloud operations specialisations.</p>
            </div>
            <div>
              <h3>2021</h3>
              <p>Data and AI pathways debut, with EU mobility support to help international talent thrive in Sweden.</p>
            </div>
            <div>
              <h3>2023</h3>
              <p>Partnership network reaches 100 organisations, launching industry challenge sprints and mentorship guilds.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionBox}>
            <h2>Our mission</h2>
            <p>
              To open doors into meaningful tech careers by combining empowering learning experiences, strong community,
              and equitable access to opportunities.
            </p>
            <ul>
              <li>Support underrepresented talent with scholarships and tailored coaching.</li>
              <li>Align every programme with Swedish and EU industry needs.</li>
              <li>Build lifelong learning communities that foster collaboration and innovation.</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <div>
              <h2>Let’s design the right journey for you</h2>
              <p>Connect with our advisors to map your goals and choose the programme that fits your life.</p>
            </div>
            <a href="/contact" className="btn btnPrimary btnLarge">
              Talk to an advisor
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;