import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Use | Redshavtjk</title>
    </Helmet>
    <div className="container">
      <h1>Terms of Use</h1>
      <p>Last updated: April 2024</p>
      <p>
        These Terms govern your use of the Redshavtjk platform, services, and content. By accessing or using our
        services, you agree to comply with these Terms. If you disagree, please refrain from using the platform.
      </p>
      <h2>1. User accounts</h2>
      <p>
        You must provide accurate information when creating an account. You are responsible for safeguarding your
        credentials and for activities occurring under your account.
      </p>
      <h2>2. Learning content</h2>
      <p>
        Course materials are provided for personal, non-commercial use. You may not reproduce, distribute, or exploit
        content without prior permission from Redshavtjk or the relevant rights holder.
      </p>
      <h2>3. Payments & refunds</h2>
      <p>
        Payment terms are defined during enrolment. Refund eligibility follows programme-specific agreements outlined
        by our advisor team.
      </p>
      <h2>4. Code of conduct</h2>
      <p>
        We maintain inclusive, respectful learning environments. Harassment, discrimination, or disruptive behaviour is
        not tolerated and may lead to suspension or termination.
      </p>
      <h2>5. Limitation of liability</h2>
      <p>
        We provide services &quot;as is&quot; and disclaim liability for indirect, incidental, or consequential damages
        arising from your use of the platform.
      </p>
      <h2>6. Contact</h2>
      <p>
        Questions about these Terms can be sent to our team via the contact page. We may update these Terms periodically
        and will post the latest version on this page.
      </p>
    </div>
  </div>
);

export default Terms;