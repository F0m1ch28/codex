import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const services = [
  {
    title: 'Advisory discovery sessions',
    description:
      'Deep-dive consultations focused on your background, ambitions, and support needs with our learner success team.',
    details: [
      'Skill gap analysis and learning diagnostics',
      'Visa-aware planning for international professionals',
      'Flexible scheduling to match work and family life',
      'Personalised support plan and recommended next steps'
    ]
  },
  {
    title: 'Mentor-led learning studios',
    description:
      'Weekly live sessions in small cohorts, pairing theory with hands-on labs in our digital studio environment.',
    details: [
      'Co-creation of project briefs with mentors',
      'Pair programming and design critiques',
      'Recorded replays with chaptered notes',
      'Continuous feedback loops and skill checkpoints'
    ]
  },
  {
    title: 'Career mobility programmes',
    description:
      'Tailored coaching that connects you to Nordic job markets, from portfolio storytelling to interview labs.',
    details: [
      'Portfolio clinics and code review sprints',
      'Nordic workplace culture briefings',
      'Interview simulations with local recruiters',
      'European mobility and relocation guidance'
    ]
  },
  {
    title: 'Enterprise partnerships',
    description:
      'Co-branded academies and upskilling initiatives that help organisations nurture and retain tech talent.',
    details: [
      'Custom learning pathways for internal teams',
      'Impact reporting and competency mapping',
      'Mentor-as-a-service for employee growth',
      'Co-hosted hackdays and innovation labs'
    ]
  }
];

const Services = () => {
  const [expanded, setExpanded] = React.useState(services[0].title);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | Redshavtjk learning experiences</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Services built for ambitious learners and forward-thinking organisations</h1>
            <p>
              Whether you’re exploring IT for the first time, reskilling, or upskilling your teams, Redshavtjk offers
              modular services anchored in human connection and industry alignment.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.servicesGrid}>
            {services.map((service) => {
              const open = expanded === service.title;
              return (
                <article key={service.title} className={open ? styles.active : ''}>
                  <button type="button" onClick={() => setExpanded(open ? null : service.title)}>
                    <div>
                      <h2>{service.title}</h2>
                      <p>{service.description}</p>
                    </div>
                    <span aria-hidden="true">{open ? '−' : '+'}</span>
                  </button>
                  <div className={styles.panel} aria-hidden={!open}>
                    <ul>
                      {service.details.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.partnerships}>
        <div className="container">
          <div className={styles.partnershipGrid}>
            <div>
              <h2>Co-create a learning partnership</h2>
              <p>
                We design talent pipelines, in-house academies, and innovation challenges with Swedish startups,
                public sector organisations, and multinational teams expanding across the EU.
              </p>
            </div>
            <ul>
              <li>Dedicated programme architect</li>
              <li>Talent scouting and assessment services</li>
              <li>Impact analytics and employer branding support</li>
              <li>Access to our Nordic mentor network</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <h2>Let’s design the right blend for you</h2>
            <p>Book a conversation with our advisors to tailor a plan for your goals, team, or organisation.</p>
            <a href="/contact" className="btn btnPrimary btnLarge">
              Talk to an advisor
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;