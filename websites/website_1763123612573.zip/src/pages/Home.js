import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const statsData = [
  { label: 'Learners empowered', value: 8200 },
  { label: 'Industry mentors', value: 65 },
  { label: 'Hiring partners', value: 110 },
  { label: 'Course satisfaction', value: 97 }
];

const servicesData = [
  {
    title: 'Adaptive learning journeys',
    description:
      'Personalised roadmaps that align Scandinavian pedagogy with your pace, commitments, and reskilling goals.',
    features: ['Skill diagnostics', 'Adaptive milestones', 'Mentor feedback', 'Progress analytics']
  },
  {
    title: 'Project-based mastery',
    description:
      'Scenarios drawn from Swedish tech ecosystems with code reviews and showcase-ready portfolios.',
    features: ['Live briefs', 'Peer collaboration', 'Expert critiques', 'Showcase events']
  },
  {
    title: 'Career mobility coaching',
    description:
      'Guidance for entering or advancing in the Nordic job market, including visa-aware counselling and interview labs.',
    features: ['Career sprints', 'Mock interviews', 'LinkedIn refresh', 'Recruiter connections']
  }
];

const processSteps = [
  {
    title: 'Discover',
    description:
      'Assess your current skills and ambitions with our advisor team. We align on goals, pacing, and support preferences.'
  },
  {
    title: 'Design',
    description:
      'Co-create a blended or online programme plan with curated courses, live labs, and mentorship checkpoints.'
  },
  {
    title: 'Develop',
    description:
      'Build real-world solutions, join industry clinics, and iterate with mentors while tracking progress dashboards.'
  },
  {
    title: 'Deliver',
    description:
      'Graduate with certified skills, career coaching artefacts, and access to hiring partners across Sweden and the EU.'
  }
];

const testimonialsData = [
  {
    quote:
      'Redshavtjk gave me a structured path from customer support to junior developer. The mentors were patient and rooted in Swedish tech culture.',
    name: 'Elsa Vikström',
    role: 'Junior Frontend Developer, Malmö'
  },
  {
    quote:
      'The blended delivery let me balance family, work, and study. I appreciated the multilingual support and practical DevOps labs.',
    name: 'Lukas Ahmed',
    role: 'Cloud Specialist, Stockholm'
  },
  {
    quote:
      'As a recent migrant, I needed guidance on both IT skills and Nordic hiring practices. The career sprint changed everything.',
    name: 'Sara Popović',
    role: 'Data Analyst, Göteborg'
  }
];

const teamMembers = [
  {
    name: 'Freja Larsson',
    role: 'Head of Learning Experience',
    image: 'https://picsum.photos/400/400?random=301',
    bio: 'Former engineer and pedagogical designer crafting inclusive, learner-first journeys.'
  },
  {
    name: 'Mikkel Sørensen',
    role: 'Lead Cloud Instructor',
    image: 'https://picsum.photos/400/400?random=302',
    bio: 'AWS Community Builder with a passion for resilient cloud architectures and mentoring.'
  },
  {
    name: 'Anika Patel',
    role: 'Data Science Mentor',
    image: 'https://picsum.photos/400/400?random=303',
    bio: 'Data storyteller guiding analysts to create ethical, impactful insight products.'
  }
];

const projectsData = [
  {
    title: 'Sustainability analytics dashboard',
    category: 'Data',
    image: 'https://picsum.photos/1200/800?random=401',
    description: 'Learners modelled renewable energy forecasts for a Nordic energy cooperative.'
  },
  {
    title: 'Inclusive banking app redesign',
    category: 'Frontend',
    image: 'https://picsum.photos/1200/800?random=402',
    description: 'Full-stack cohort delivered accessible fintech UX for underserved communities.'
  },
  {
    title: 'Kubernetes migration toolkit',
    category: 'Cloud',
    image: 'https://picsum.photos/1200/800?random=403',
    description: 'DevOps path learners containerised legacy services for a public sector partner.'
  },
  {
    title: 'AI-powered hiring assistant',
    category: 'Backend',
    image: 'https://picsum.photos/1200/800?random=404',
    description: 'Advanced Python learners built ethical automation to support HR teams.'
  }
];

const faqsData = [
  {
    question: 'Do you offer programmes in English and Swedish?',
    answer:
      'Yes. Core materials are available in English with Swedish support sessions. Advisors help you choose the format that suits your language comfort.'
  },
  {
    question: 'Can I mix online and on-campus experiences?',
    answer:
      'Our blended pathways combine self-paced content, live virtual classrooms, and optional on-site labs in Stockholm and Göteborg.'
  },
  {
    question: 'How do mentorship sessions work?',
    answer:
      'Mentors hold bi-weekly sessions, offer code reviews, and provide feedback via our digital studio. You can book additional office hours as needed.'
  },
  {
    question: 'Is career support included?',
    answer:
      'Every learner receives a career sprint including portfolio critique, CV refinement, interview labs, and introductions to hiring partners.'
  }
];

const blogPosts = [
  {
    title: 'Navigating Sweden’s tech hiring landscape in 2024',
    description: 'Understand the skills Swedish employers prioritise and how to position your experience.',
    date: 'April 2024',
    link: '/resources'
  },
  {
    title: 'Choosing the right learning path for cloud careers',
    description: 'Compare AWS, Azure, and multi-cloud journeys tailored to EU compliance needs.',
    date: 'March 2024',
    link: '/paths'
  },
  {
    title: 'Blended learning strategies for working professionals',
    description: 'Practical tips for balancing study with full-time work while staying energised.',
    date: 'February 2024',
    link: '/resources'
  }
];

const learningPathsPreview = [
  {
    title: 'Frontend Developer',
    description: 'Design intuitive interfaces, master modern JavaScript frameworks, and ship production-ready UI.',
    link: '/paths'
  },
  {
    title: 'Cloud Fundamentals',
    description: 'Build resilient cloud-native infrastructure with hands-on labs across AWS and Azure.',
    link: '/paths'
  },
  {
    title: 'Data Analyst',
    description: 'Transform raw data into insights with Python, SQL, and Scandinavian industry datasets.',
    link: '/paths'
  }
];

const Home = () => {
  const [stats, setStats] = React.useState(statsData.map(() => 0));
  const [activeService, setActiveService] = React.useState(servicesData[0].title);
  const [currentTestimonial, setCurrentTestimonial] = React.useState(0);
  const [projectFilter, setProjectFilter] = React.useState('All');
  const [openFaq, setOpenFaq] = React.useState(null);

  React.useEffect(() => {
    const start = performance.now();
    const duration = 1400;
    let animationFrame;

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const updated = statsData.map((stat) => Math.floor(stat.value * progress));
      setStats(updated);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    projectFilter === 'All'
      ? projectsData
      : projectsData.filter((project) => project.category === projectFilter);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Redshavtjk | Scandinavian IT learning for modern careers</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>Powered by Swedish pedagogy</span>
              <h1>
                Build future-proof IT skills with the Nordic learning platform designed for ambitious journeys.
              </h1>
              <p>
                Redshavtjk delivers online and blended programmes in programming, web development, data, and cloud.
                Our adaptive approach connects you to mentors, employers, and real projects across Sweden and the EU.
              </p>
              <div className={styles.heroActions}>
                <Link to="/courses" className="btn btnPrimary btnLarge">
                  Browse courses
                </Link>
                <Link to="/contact" className="btn btnGhost btnLarge">
                  Talk to an advisor
                </Link>
              </div>
              <ul className={styles.heroList}>
                <li>Flexible online & hybrid formats</li>
                <li>Mentors rooted in Nordic tech ecosystems</li>
                <li>Career coaching tailored to EU mobility</li>
              </ul>
            </div>
            <div className={styles.heroVisual}>
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Learners collaborating in a modern workspace"
                loading="lazy"
              />
              <div className={styles.heroCard}>
                <h3>Learning crafted for modern Sweden</h3>
                <p>Experience inclusive teaching, multilingual support, and projects mirroring real briefs.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {stats[index]}
                  {stat.label === 'Course satisfaction' ? '%' : '+'}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Learning reimagined</span>
            <h2>Personalised services that move you forward</h2>
            <p>
              From diagnostics to delivery, our teams orchestrate supportive journeys that maximise impact, resilience,
              and confidence in the fast-moving tech landscape.
            </p>
          </div>

          <div className={styles.servicesGrid}>
            <div className={styles.servicesList}>
              {servicesData.map((service) => (
                <button
                  type="button"
                  key={service.title}
                  className={`${styles.serviceItem} ${
                    activeService === service.title ? styles.serviceActive : ''
                  }`}
                  onClick={() => setActiveService(service.title)}
                  aria-pressed={activeService === service.title}
                >
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                </button>
              ))}
            </div>
            <div className={styles.serviceDetails} aria-live="polite">
              {servicesData
                .filter((service) => service.title === activeService)
                .map((service) => (
                  <div key={service.title}>
                    <h4>What&apos;s inside</h4>
                    <ul>
                      {service.features.map((feature) => (
                        <li key={feature}>{feature}</li>
                      ))}
                    </ul>
                    <Link to="/services" className="btn btnGhost">
                      Explore services
                    </Link>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.coursesPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Curated selection</span>
            <h2>Courses teams love recommending</h2>
            <p>Handpicked programmes blending expert instruction, Swedish industry briefs, and supportive cohorts.</p>
          </div>
          <div className={styles.courseCards}>
            <article className={styles.courseCard}>
              <div>
                <h3>Modern JavaScript Foundations</h3>
                <p>Master ES2023, TypeScript, and component-based thinking with projects built on React and Vite.</p>
              </div>
              <ul>
                <li>8 weeks · Evening sessions</li>
                <li>Level: Beginner to Intermediate</li>
                <li>Format: Online Live + Labs</li>
              </ul>
              <Link to="/courses">View details</Link>
            </article>
            <article className={styles.courseCard}>
              <div>
                <h3>Data Analytics with Python</h3>
                <p>Analyse Nordic datasets, apply statistics, and present insights with storytelling techniques.</p>
              </div>
              <ul>
                <li>10 weeks · Blended</li>
                <li>Level: Intermediate</li>
                <li>Format: Hybrid with campus labs</li>
              </ul>
              <Link to="/courses">View details</Link>
            </article>
            <article className={styles.courseCard}>
              <div>
                <h3>CloudOps on AWS & Azure</h3>
                <p>Deploy cloud infrastructure using IaC, CI/CD pipelines, and operations frameworks used in Sweden.</p>
              </div>
              <ul>
                <li>12 weeks · Evening & weekend</li>
                <li>Level: Advanced</li>
                <li>Format: Online Live</li>
              </ul>
              <Link to="/courses">View details</Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.paths}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Learning paths</span>
            <h2>Structured foundations to advanced expertise</h2>
            <p>Follow curated journeys with stacked certifications, mentorship, and industry case studies.</p>
          </div>
          <div className={styles.pathsGrid}>
            {learningPathsPreview.map((path) => (
              <article key={path.title}>
                <h3>{path.title}</h3>
                <p>{path.description}</p>
                <Link to={path.link} className={styles.pathLink}>
                  Explore path →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <span className={styles.kicker}>Why Redshavtjk</span>
              <h2>Education rooted in Scandinavian excellence</h2>
              <p>
                We combine Sweden’s collaborative learning culture with high-impact digital pedagogy, empowering
                learners from diverse backgrounds to thrive in future-ready tech roles.
              </p>
            </div>
            <ul>
              <li>
                <strong>Inclusive cohorts</strong>
                <span>Multilingual support and community-building that celebrates diverse experiences.</span>
              </li>
              <li>
                <strong>Employer partnerships</strong>
                <span>Connections to startups, scale-ups, and public sector innovators across the EU.</span>
              </li>
              <li>
                <strong>Continuous innovation</strong>
                <span>Curricula refreshed quarterly to align with modern frameworks and tools.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>How it works</span>
            <h2>A grounded process guiding every step</h2>
            <p>We map your ambitions to a clear, supportive plan – from discovery to career activation.</p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Voices of our learners</span>
            <h2>Stories of transformation across Sweden</h2>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonialsData.map((testimonial, index) => (
              <blockquote
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === currentTestimonial ? styles.testimonialActive : ''
                }`}
                aria-hidden={index !== currentTestimonial}
              >
                <p>“{testimonial.quote}”</p>
                <footer>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
            <div className={styles.testimonialControls} role="tablist" aria-label="Testimonial selector">
              {testimonialsData.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={index === currentTestimonial ? styles.dotActive : ''}
                  onClick={() => setCurrentTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                  aria-selected={index === currentTestimonial}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Meet the team</span>
            <h2>Mentors and designers shaping tomorrow’s skills</h2>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name}>
                <div className={styles.teamImage}>
                  <img src={member.image} alt={`${member.name} portrait`} loading="lazy" />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Impact projects</span>
            <h2>Portfolios grounded in real Swedish use-cases</h2>
            <p>Explore how learners apply new skills to industry briefs and public innovation challenges.</p>
          </div>
          <div className={styles.projectFilters} role="group" aria-label="Project filters">
            {['All', 'Frontend', 'Backend', 'Data', 'Cloud'].map((filter) => (
              <button
                key={filter}
                type="button"
                className={projectFilter === filter ? styles.projectFilterActive : ''}
                onClick={() => setProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>FAQ</span>
            <h2>Answers to common questions</h2>
          </div>
          <div className={styles.faqList}>
            {faqsData.map((faq, index) => {
              const open = openFaq === index;
              return (
                <div key={faq.question} className={`${styles.faqItem} ${open ? styles.faqOpen : ''}`}>
                  <button
                    type="button"
                    onClick={() => setOpenFaq(open ? null : index)}
                    aria-expanded={open}
                  >
                    <span>{faq.question}</span>
                    <span className={styles.icon}>{open ? '−' : '+'}</span>
                  </button>
                  <div className={styles.faqAnswer} role="region" aria-hidden={!open}>
                    <p>{faq.answer}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Insights</span>
            <h2>Latest guidance from our learning studio</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.description}</p>
                <Link to={post.link}>Continue reading →</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.finalCtaBox}>
            <div>
              <h2>Ready to start learning?</h2>
              <p>Begin your Redshavtjk journey today and unlock personalised guidance, hands-on projects, and a supportive network.</p>
            </div>
            <div className={styles.finalCtaActions}>
              <Link to="/courses" className="btn btnPrimary btnLarge">
                Start learning
              </Link>
              <Link to="/contact" className="btn btnGhost btnLarge">
                Talk to an advisor
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;