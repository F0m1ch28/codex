import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | Redshavtjk</title>
    </Helmet>
    <div className="container">
      <h1>Privacy Policy</h1>
      <p>Last updated: April 2024</p>
      <p>
        Redshavtjk respects your privacy and complies with EU GDPR regulations. This policy explains how we collect,
        use, and protect your personal data.
      </p>
      <h2>Information we collect</h2>
      <p>
        We collect information you provide during enquiries, enrolment, course participation, and career services. This
        may include contact details, learning preferences, and progress data.
      </p>
      <h2>How we use data</h2>
      <p>
        Data is used to deliver programmes, provide support, improve services, comply with legal obligations, and
        communicate relevant opportunities.
      </p>
      <h2>Data sharing</h2>
      <p>
        We share data only with trusted partners delivering our services (e.g., mentors, credential providers). We never
        sell your personal data. International transfers comply with EU safeguards.
      </p>
      <h2>Your rights</h2>
      <p>
        You can request access, rectification, deletion, or restriction of your data. Contact us to exercise these
        rights or to submit concerns to Swedish authorities.
      </p>
      <h2>Security</h2>
      <p>
        We implement technical and organisational measures to protect your data, including encryption, access controls,
        and regular reviews.
      </p>
      <h2>Contact</h2>
      <p>
        For privacy questions, reach us via the contact page. We may update this policy and will publish revisions here.
      </p>
    </div>
  </div>
);

export default Privacy;