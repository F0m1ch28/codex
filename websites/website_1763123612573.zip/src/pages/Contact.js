import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = React.useState({ name: '', email: '', message: '' });
  const [formStatus, setFormStatus] = React.useState({ success: '', error: '', touched: {} });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setFormStatus((prev) => ({
      ...prev,
      touched: { ...prev.touched, [name]: true },
      error: ''
    }));
  };

  const validate = () => {
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setFormStatus((prev) => ({ ...prev, error: 'Please complete all required fields.' }));
      return false;
    }
    const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);
    if (!emailValid) {
      setFormStatus((prev) => ({ ...prev, error: 'Please enter a valid email address.' }));
      return false;
    }
    return true;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;

    setFormStatus({ success: 'Thank you! Our advisors will contact you soon.', error: '', touched: {} });
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact Redshavtjk | Talk to an advisor</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Ready to design your learning journey?</h1>
          <p>
            Our advisor team is here to help you map your goals, understand programme formats, and find the support
            that fits your life in Sweden or across the EU.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Full name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={!!formStatus.error && !formData.name}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-required="true"
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">How can we help? *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-required="true"
                />
              </div>
              {formStatus.error && <p className={styles.error}>{formStatus.error}</p>}
              {formStatus.success && <p className={styles.success}>{formStatus.success}</p>}
              <button type="submit" className="btn btnPrimary btnLarge">
                Submit message
              </button>
            </form>

            <div className={styles.details}>
              <h2>Visit or connect</h2>
              <ul>
                <li>
                  <strong>Address:</strong> Sweden address placeholder
                </li>
                <li>
                  <strong>Email:</strong> [to be added]
                </li>
                <li>
                  <strong>Phone:</strong> [to be added]
                </li>
              </ul>
              <p>
                We offer in-person advising in Stockholm and Göteborg, with digital sessions for learners across Sweden and the EU.
              </p>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Redshavtjk Sweden location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21630.4134926591!2d18.059196068118516!3d59.329323497719975!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x465f9d55c003b1e7%3A0x4019078290fbe20!2sStockholm%2C%20Sweden!5e0!3m2!1sen!2sse!4v1688154977727!5m2!1sen!2sse"
                  loading="lazy"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;