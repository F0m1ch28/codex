// Скрипт отвечает за мобильное меню и cookie-баннер
document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const COOKIE_KEY = "website-cookie-consent";

  // Мобильное меню
  if (navToggle) {
    navToggle.addEventListener("click", () => {
      body.classList.toggle("is-menu-open");
    });

    document.addEventListener("keyup", (event) => {
      if (event.key === "Escape") {
        body.classList.remove("is-menu-open");
      }
    });
  }

  // Cookie баннер
  const consent = localStorage.getItem(COOKIE_KEY);
  if (!consent && cookieBanner) {
    requestAnimationFrame(() => cookieBanner.classList.add("is-visible"));
  }

  const handleConsent = (value) => {
    localStorage.setItem(COOKIE_KEY, value);
    cookieBanner.classList.remove("is-visible");
  };

  acceptBtn?.addEventListener("click", () => handleConsent("accepted"));
  declineBtn?.addEventListener("click", () => handleConsent("declined"));
});