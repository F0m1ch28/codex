const navToggle = document.getElementById('navToggle');
const primaryNav = document.getElementById('primary-navigation');

if (navToggle && primaryNav) {
  navToggle.addEventListener('click', () => {
    const isOpen = primaryNav.getAttribute('data-open') === 'true';
    primaryNav.setAttribute('data-open', String(!isOpen));
    navToggle.setAttribute('aria-expanded', String(!isOpen));
  });

  primaryNav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      if (window.innerWidth < 768) {
        primaryNav.setAttribute('data-open', 'false');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });
}

const cookieBanner = document.getElementById('cookie-banner');
const cookieAccept = document.getElementById('cookie-accept');
const cookieDecline = document.getElementById('cookie-decline');
const COOKIE_KEY = 'website_cookie_consent';

const showBanner = () => {
  if (cookieBanner) {
    cookieBanner.classList.add('is-visible');
  }
};

const hideBanner = () => {
  if (cookieBanner) {
    cookieBanner.classList.remove('is-visible');
  }
};

const storedConsent = localStorage.getItem(COOKIE_KEY);
if (!storedConsent) {
  window.addEventListener('load', () => {
    setTimeout(showBanner, 600);
  });
}

if (cookieAccept) {
  cookieAccept.addEventListener('click', () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    hideBanner();
  });
}

if (cookieDecline) {
  cookieDecline.addEventListener('click', () => {
    localStorage.setItem(COOKIE_KEY, 'declined');
    hideBanner();
  });
}