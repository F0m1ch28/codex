import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programs = [
  {
    title: '7-Tage-Fokus-Detox',
    description:
      'Sieben kurze Mikro-Experimente, die Deine Scrollgewohnheiten neu justieren – mit Reflexionsfragen für jeden Tag.',
    duration: '7 Tage',
    focus: 'Kurzvideo & Social Media Balance'
  },
  {
    title: 'Benachrichtigungs-Reset',
    description:
      'Ein strukturierter Prozess, der Dir hilft, Pushs, Banner und Badges neu zu ordnen. Du legst fest, was wirklich wichtig ist.',
    duration: '5 Sessions',
    focus: 'Notification Management'
  },
  {
    title: '30-Minuten-Deep-Work-Session',
    description:
      'Geführte Sessions, die Dich sanft in Deep Work bringen. Mit Warm-up, Fokus-Statement und einer reflektierten Abschlussroutine.',
    duration: '30 Minuten',
    focus: 'Deep Work & Routine'
  }
];

const Programs = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Programme & Challenges | Tivarenso</title>
        <meta
          name="description"
          content="Starte mit den Tivarenso Programmen: Fokus-Detox, Benachrichtigungs-Reset und Deep-Work-Sessions für mehr Klarheit."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Programme & Challenges</h1>
          <p>Kurze, intensive Impulse – genau dann, wenn Du sie brauchst.</p>
        </div>
      </section>

      <section className={styles.programList}>
        <div className="container">
          <div className={styles.grid}>
            {programs.map((program) => (
              <article key={program.title} className={styles.card}>
                <h2>{program.title}</h2>
                <p>{program.description}</p>
                <div className={styles.meta}>
                  <span>{program.duration}</span>
                  <span>{program.focus}</span>
                </div>
                <button className={styles.button} type="button">
                  Platz reservieren
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Programs;