import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { blogPosts } from '../data/blogPosts';
import styles from './Blog.module.css';

const Blog = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Blog | Fokus-Impulse von Tivarenso</title>
        <meta
          name="description"
          content="Aktuelle Artikel rund um Aufmerksamkeitsmanagement, Fokus und digitale Balance von Tivarenso."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Tivarenso Blog</h1>
          <p>Regelmäßige Impulse, Experimente und Geschichten aus unserer Community.</p>
        </div>
      </section>

      <section className={styles.list}>
        <div className="container">
          <div className={styles.grid}>
            {blogPosts.map((post) => (
              <article key={post.slug} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={post.heroImage} alt={`Artikelbild: ${post.title}`} />
                </div>
                <div className={styles.content}>
                  <span className={styles.meta}>
                    {new Date(post.date).toLocaleDateString('de-DE', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric'
                    })}{' '}
                    · {post.readingTime}
                  </span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.link}>
                    Weiterlesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;