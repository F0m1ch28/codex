import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { blogPosts } from '../data/blogPosts';
import styles from './BlogPost.module.css';

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find((entry) => entry.slug === slug);

  if (!post) {
    return (
      <div className={styles.page}>
        <div className="container">
          <h1>Artikel nicht gefunden</h1>
          <p>Der gesuchte Beitrag ist gerade nicht verfügbar.</p>
          <Link to="/blog" className="button buttonSecondary">
            Zurück zum Blog
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Helmet>
        <title>{post.title} | Tivarenso Blog</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>

      <article className={styles.article}>
        <div className="container">
          <div className={styles.hero}>
            <p className={styles.meta}>
              {new Date(post.date).toLocaleDateString('de-DE', {
                day: '2-digit',
                month: 'long',
                year: 'numeric'
              })}{' '}
              · {post.readingTime} · {post.author}
            </p>
            <h1>{post.title}</h1>
          </div>
          <div className={styles.imageWrapper}>
            <img src={post.heroImage} alt={`Hero Bild für: ${post.title}`} />
          </div>
          <div className={styles.content}>
            {post.sections.map((section) => (
              <section key={section.heading} className={styles.section}>
                <h2>{section.heading}</h2>
                <p>{section.text}</p>
              </section>
            ))}
          </div>
          <div className={styles.backLink}>
            <Link to="/blog" className="button buttonSecondary">
              Zurück zum Blog
            </Link>
          </div>
        </div>
      </article>
    </div>
  );
};

export default BlogPost;