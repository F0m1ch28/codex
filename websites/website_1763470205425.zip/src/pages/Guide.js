import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const steps = [
  {
    title: '1. Status-Check',
    description:
      'Finde heraus, wann und warum Du auf Dein Handy schaust. Wir arbeiten mit einer ehrlichen Bestandsaufnahme – ganz ohne Schuldgefühle.',
    tips: ['Mini-Tracking über 3 Tage', 'Trigger erkennen', 'Energielevel notieren']
  },
  {
    title: '2. Ablenkungen aufräumen',
    description:
      'Wir sortieren Apps, Feeds und Notifications. Du entscheidest, was bleiben darf und was Dich zu viel kostet.',
    tips: ['Notification Audit', 'Home-Screen neu strukturieren', 'Clips bewusst dosieren']
  },
  {
    title: '3. Fokus-Regeln definieren',
    description:
      'Du entwickelst kleine, klare Regeln, die zu Deinem Alltag passen – etwa Fokusfenster oder bewusstes Scrollen.',
    tips: ['Fokus-Fenster festlegen', 'Kurzvideo-Slots timen', 'Bewusster Start & Abschluss']
  },
  {
    title: '4. Routinen verankern',
    description:
      'Wir verankern neue Gewohnheiten mit Reflexion, freundlichen Remindern und Wochen-Check-ins.',
    tips: ['Wochenreview', 'Micro-Habits', 'Accountability Partner']
  }
];

const Guide = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Leitfaden | Schritt für Schritt zu mehr Fokus</title>
        <meta
          name="description"
          content="Der Tivarenso Leitfaden zeigt Dir in vier Schritten, wie Du Deine Aufmerksamkeit im digitalen Alltag stärkst."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Der einfache Fokus-Leitfaden</h1>
          <p>Vier Schritte, die Dich vom Gefühl des Overloads zu mehr Klarheit bringen.</p>
        </div>
      </section>

      <section className={styles.steps}>
        <div className="container">
          <div className={styles.stepGrid}>
            {steps.map((step) => (
              <article key={step.title} className={styles.stepCard}>
                <h2>{step.title}</h2>
                <p>{step.description}</p>
                <ul>
                  {step.tips.map((tip) => (
                    <li key={tip}>{tip}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Guide;