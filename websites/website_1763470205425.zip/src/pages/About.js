import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const values = [
  {
    title: 'Menschlichkeit vor Produktivität',
    description:
      'Wir glauben, dass Fokus nicht aus Druck entsteht, sondern aus Selbstfreundlichkeit. Unsere Ansätze sind realistisch und respektvoll.'
  },
  {
    title: 'Klarheit statt Chaos',
    description:
      'Wir schaffen Struktur im Informationsrauschen. Kein Overload, sondern fokussierte Impulse zur richtigen Zeit.'
  },
  {
    title: 'Gemeinsames Lernen',
    description:
      'Wir testen, reflektieren, verfeinern. In der Community lernst Du von anderen Menschen, die ebenfalls bewusster leben wollen.'
  }
];

const milestones = [
  {
    year: '2021',
    title: 'Idee & Prototyp',
    description: 'Lea und Jonas entwickeln erste Fokus-Workshops für Freund:innen im Homeoffice.'
  },
  {
    year: '2022',
    title: 'Community Launch',
    description: 'Die ersten 500 Nutzer:innen starten mit den Kurz-Challenges und teilen ihre Erfolge.'
  },
  {
    year: '2023',
    title: 'Tivarenso Toolkit',
    description: 'Release unserer Tool-Sammlung inklusive Fokus-Tagesplan und Notification-Reset.'
  },
  {
    year: '2024',
    title: 'Team Ausbau',
    description: 'Wir wachsen und begleiten Unternehmen, Creator:innen und Studierende in ganz Deutschland.'
  }
];

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Über Tivarenso | Mission & Team</title>
        <meta
          name="description"
          content="Lerne das Team hinter Tivarenso kennen. Wir entwickeln alltagstaugliche Strategien für bewusstes Aufmerksamkeitsmanagement."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Über Tivarenso</h1>
            <p>
              Wir sind ein interdisziplinäres Team aus Psychologie, Produktdesign und Coaching. Unser Ziel:
              Digitale Technologien so nutzen, dass sie Deine Aufmerksamkeit stärken – nicht erschöpfen.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Was uns antreibt</h2>
          <div className={styles.valueGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2>Unsere Geschichte</h2>
              <p>
                Tivarenso entstand aus einer simplen Beobachtung: Wir alle sind kompetent, smart und motiviert –
                doch wir verlieren unsere Aufmerksamkeit zwischen Clips, DMs und Notifications. Statt moralischer
                Appelle wollten wir pragmatische Hilfen entwickeln. Klein genug, um heute zu starten. Subtil genug, 
                um dauerhaft zu bleiben.
              </p>
              <p>
                Wir kombinieren Erkenntnisse aus Aufmerksamkeitstrainings, Neurowissenschaft und agilen Arbeitsweisen.
                So entsteht ein Werkzeugkasten, der Dich stärkt, ohne Dich zu überfordern.
              </p>
            </div>
            <div className={styles.storyImage}>
              <img
                src="https://picsum.photos/seed/tivarenso-about/800/600"
                alt="Team von Tivarenso arbeitet gemeinsam an einer Strategie"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className="container">
          <h2>Meilensteine</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <div key={milestone.year} className={styles.milestone}>
                <span className={styles.milestoneYear}>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.manifesto}>
        <div className="container">
          <div className={styles.manifestoCard}>
            <h2>Unser Manifest</h2>
            <ul>
              <li>Aufmerksamkeit ist eine Ressource, keine Selbstverständlichkeit.</li>
              <li>Fokus bedeutet nicht Verzicht, sondern bewusste Wahl.</li>
              <li>Wir glauben an kleine, sanfte Schritte mit großer Wirkung.</li>
              <li>Digitaler Alltag darf sich leicht anfühlen – ohne Schuldgefühle.</li>
            </ul>
            <p>
              Mit Tivarenso erhältst Du strukturierte Experimente, die Dich wieder mit Deiner eigenen Zeit verbinden.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;