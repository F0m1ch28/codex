import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = React.useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Bitte gib Deinen Namen ein.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse ein.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Schreib uns eine kurze Nachricht.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | Tivarenso</title>
        <meta
          name="description"
          content="Melde Dich bei Tivarenso für Fragen zu Fokus-Programmen, Tools oder individuellen Begleitungen."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt</h1>
          <p>Erzähl uns, was Dich beschäftigt. Wir finden gemeinsam den nächsten Schritt.</p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>So erreichst Du uns</h2>
              <p>Tivarenso GmbH<br />Musterstraße 12<br />10115 Berlin</p>
              <p>
                E-Mail: <a href="mailto:kontakt@tivarenso.site">kontakt@tivarenso.site</a><br />
                Telefon: +49 30 1234 567890
              </p>
              <p>
                Wir antworten in der Regel innerhalb von 48 Stunden. Lass uns wissen, welches Thema
                Dir gerade am meisten hilft.
              </p>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Name*</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={!!errors.name}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  required
                />
                {errors.name && (
                  <span className={styles.error} id="name-error">
                    {errors.name}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">E-Mail*</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={!!errors.email}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  required
                />
                {errors.email && (
                  <span className={styles.error} id="email-error">
                    {errors.email}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Nachricht*</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={!!errors.message}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  required
                />
                {errors.message && (
                  <span className={styles.error} id="message-error">
                    {errors.message}
                  </span>
                )}
              </div>
              <button type="submit" className="button buttonPrimary">
                Nachricht senden
              </button>
              {submitted && (
                <p className={styles.success} role="status">
                  Danke für Deine Nachricht! Wir melden uns bald bei Dir.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;