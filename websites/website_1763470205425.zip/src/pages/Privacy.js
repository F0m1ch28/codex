import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Datenschutz | Tivarenso</title>
        <meta
          name="description"
          content="Datenschutzerklärung von Tivarenso: Erfahre, wie wir mit Deinen Daten umgehen."
        />
      </Helmet>

      <section className={styles.section}>
        <div className="container">
          <h1>Datenschutzerklärung</h1>
          <p>
            Der Schutz Deiner persönlichen Daten ist uns wichtig. Wir verarbeiten Deine Daten
            ausschließlich auf Grundlage der gesetzlichen Bestimmungen (DSGVO, TMG).
          </p>
          <h2>1. Verantwortliche Stelle</h2>
          <p>Tivarenso GmbH, Musterstraße 12, 10115 Berlin, E-Mail: kontakt@tivarenso.site</p>
          <h2>2. Erhebung und Verarbeitung</h2>
          <p>
            Wenn Du unser Kontaktformular nutzt oder Dich zum Newsletter anmeldest, speichern wir
            die von Dir angegebenen Daten, um Deine Anfrage zu bearbeiten. Wir geben keine Daten an
            Dritte weiter, sofern keine gesetzliche Pflicht besteht.
          </p>
          <h2>3. Cookies</h2>
          <p>
            Wir verwenden nur technisch notwendige Cookies, um die Nutzungserfahrung zu verbessern.
            Du kannst Cookies in den Einstellungen Deines Browsers jederzeit deaktivieren.
          </p>
          <h2>4. Deine Rechte</h2>
          <p>
            Dir stehen Auskunfts-, Berichtigungs-, Lösch- und Widerspruchsrechte zu. Schreib uns
            dafür einfach eine E-Mail an kontakt@tivarenso.site.
          </p>
          <h2>5. Änderungen</h2>
          <p>
            Wir aktualisieren diese Erklärung bei Bedarf. Bitte informiere Dich regelmäßig über den
            aktuellen Stand.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;