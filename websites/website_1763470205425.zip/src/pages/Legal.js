import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Legal = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Rechtliche Hinweise | Tivarenso</title>
        <meta
          name="description"
          content="Rechtliche Hinweise und Nutzungsbedingungen der Tivarenso Plattform."
        />
      </Helmet>

      <section className={styles.section}>
        <div className="container">
          <h1>Rechtliche Hinweise</h1>
          <p>
            Durch die Nutzung unserer Webseite erklärst Du Dich mit den folgenden Bedingungen
            einverstanden. Tivarenso stellt Informationen, Programme und Tools rund um
            Aufmerksamkeitsmanagement zur Verfügung. Wir ersetzen keine medizinischen oder
            therapeutischen Beratungen.
          </p>
          <h2>1. Nutzung der Inhalte</h2>
          <p>
            Sämtliche Inhalte sind urheberrechtlich geschützt. Die Nutzung ist ausschließlich für
            private oder interne Zwecke erlaubt. Eine Weitergabe, Vervielfältigung oder
            Veröffentlichung bedarf unserer ausdrücklichen Zustimmung.
          </p>
          <h2>2. Haftungsausschluss</h2>
          <p>
            Wir prüfen alle Inhalte sorgfältig, übernehmen jedoch keine Haftung für Aktualität,
            Vollständigkeit oder externe Links. Entscheidungen triffst Du eigenverantwortlich.
          </p>
          <h2>3. Änderungen</h2>
          <p>
            Wir behalten uns vor, Inhalte sowie Nutzungsbedingungen zu aktualisieren. Bitte prüfe
            diese Seite regelmäßig, um auf dem neuesten Stand zu bleiben.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Legal;