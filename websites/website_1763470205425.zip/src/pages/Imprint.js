import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Imprint.module.css';

const Imprint = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Impressum | Tivarenso</title>
        <meta
          name="description"
          content="Impressum der Tivarenso GmbH mit Kontaktangaben und Verantwortlichkeiten."
        />
      </Helmet>

      <section className={styles.section}>
        <div className="container">
          <h1>Impressum</h1>
          <p>Tivarenso GmbH<br />Musterstraße 12<br />10115 Berlin<br />Deutschland</p>
          <p>
            Vertreten durch: Lea Thomsen<br />
            Kontakt: kontakt@tivarenso.site<br />
            Telefon: +49 30 1234 567890
          </p>
          <p>
            Registergericht: Amtsgericht Berlin Charlottenburg<br />
            Registernummer: HRB 123456 B<br />
            Umsatzsteuer-ID: DE999999999
          </p>
          <h2>Verantwortlich für den Inhalt</h2>
          <p>Lea Thomsen (Anschrift wie oben)</p>
          <h2>Haftung für Inhalte</h2>
          <p>Wir übernehmen keine Gewähr für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte.</p>
          <h2>Streitbeilegung</h2>
          <p>
            Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung bereit:
            https://ec.europa.eu/consumers/odr/. Unsere E-Mail-Adresse findest Du oben im Impressum.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Imprint;