import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import { blogPosts } from '../data/blogPosts';

const statsData = [
  { label: 'Bewusste Minuten pro Nutzer:in', value: 870, suffix: '+' },
  { label: 'Clips weniger pro Woche', value: 36, suffix: '' },
  { label: 'Teams, die Tivarenso nutzen', value: 54, suffix: '' },
  { label: 'Zufriedenheits-Score', value: 94, suffix: '%' }
];

const services = [
  {
    title: 'Attention Audit',
    description: 'Analysiere Deinen digitalen Alltag und entdecke, wo Deine Energie wirklich hinfließt.',
    icon: '🧭',
    to: '/guide'
  },
  {
    title: 'Fokus-Challenges',
    description: 'Starte kurze, alltagstaugliche Challenges, um wenig genutzte Aufmerksamkeit zurückzuholen.',
    icon: '🎯',
    to: '/programs'
  },
  {
    title: 'Toolkits & Checklisten',
    description: 'Nutze praxiserprobte Vorlagen, um Deine Fokusfenster zu planen.',
    icon: '🧰',
    to: '/tools'
  },
  {
    title: 'Community Sessions',
    description: 'Verbinde Dich mit anderen Menschen, die bewusster leben möchten.',
    icon: '🤝',
    to: '/contact'
  }
];

const processSteps = [
  {
    title: 'Status-Check',
    subtitle: 'Wo steht Deine Aufmerksamkeit heute?',
    text: 'Wir starten mit einem klaren Blick darauf, welche digitalen Routinen Dir guttun – und welche Dir Energie ziehen.'
  },
  {
    title: 'Ablenkungen ordnen',
    subtitle: 'Signal vs. Rauschen',
    text: 'Gemeinsam sortieren wir Notifications, Feeds und Apps nach Sinnhaftigkeit. Klarheit statt Dauerbeschallung.'
  },
  {
    title: 'Fokus-Regeln definieren',
    subtitle: 'Deine neuen Leitplanken',
    text: 'Du formulierst persönliche Fokus-Regeln, die Dein Mindset stärken und Raum für Kreativität schaffen.'
  },
  {
    title: 'Routinen verankern',
    subtitle: 'Konsequent dranbleiben',
    text: 'Mit Micro-Habits und Wochen-Reflexionen machst Du Deinen Fortschritt sichtbar und spürbar.'
  }
];

const testimonials = [
  {
    name: 'Svenja, Product Designerin',
    quote:
      '„Ich habe mein Handy nicht verbannt, aber es fühlt sich endlich wieder wie ein Tool an – nicht wie ein Chef.“',
    role: 'Produktdesign, Berlin'
  },
  {
    name: 'Malik, Scrum Master',
    quote:
      '„Die Benachrichtigungs-Reset-Challenge war so simpel – und doch habe ich seitdem 30% weniger Unterbrechungen.“',
    role: 'Agile Coach, Hamburg'
  },
  {
    name: 'Aylin, Gründerin',
    quote:
      '„Tivarenso hilft mir, Deep Work realistischer zu planen. Die Reflexionsfragen sind Gold wert.“',
    role: 'Startup, Köln'
  }
];

const teamMembers = [
  {
    name: 'Lea Thomsen',
    role: 'Head of Focus Programs',
    bio: 'Psychologin (M.Sc.), liebt klare Routinen und warme Teetassen.',
    image: 'https://picsum.photos/seed/tivarenso-team1/400/400'
  },
  {
    name: 'Jonas Feld',
    role: 'Digital Habit Coach',
    bio: 'Baut Strukturen, die Alltag und Ambition zusammenbringen.',
    image: 'https://picsum.photos/seed/tivarenso-team2/400/400'
  },
  {
    name: 'Mara Kessler',
    role: 'Content & Community',
    bio: 'Sorgt dafür, dass jedes Wort leicht verständlich und motivierend bleibt.',
    image: 'https://picsum.photos/seed/tivarenso-team3/400/400'
  }
];

const projects = [
  {
    title: 'Social Media Team Fokus Reset',
    category: 'Unternehmen',
    description: 'Ein Social-Team reduzierte unnötige Notifications um 62% und gewann klare Fokusfenster.',
    image: 'https://picsum.photos/seed/tivarenso-projekt1/1200/800'
  },
  {
    title: 'Creator-Collective Deep Work Sprint',
    category: 'Creators',
    description: '8 Creator:innen etablierten eine 90-Minuten-Deep-Work-Routine mit spürbaren Ergebnissen.',
    image: 'https://picsum.photos/seed/tivarenso-projekt2/1200/800'
  },
  {
    title: 'Startup Attention Playbook',
    category: 'Unternehmen',
    description: 'Ein Hybrid-Team entwickelte klare Meeting-Free-Zonen und checkt E-Mails bewusst.',
    image: 'https://picsum.photos/seed/tivarenso-projekt3/1200/800'
  },
  {
    title: 'Studierenden Fokus Tage',
    category: 'Studierende',
    description: '120 Studierende lernten, Lern-Sprints ohne Multitasking zu gestalten.',
    image: 'https://picsum.photos/seed/tivarenso-projekt4/1200/800'
  }
];

const faqs = [
  {
    question: 'Brauche ich dafür noch eine App?',
    answer:
      'Nein. Wir setzen auf bewusste Routinen, klare Regeln und einfache Tools, die Du mit Deinen bestehenden Geräten umsetzt.'
  },
  {
    question: 'Wie viel Zeit muss ich investieren?',
    answer:
      'Schon 10–15 Minuten Reflexion pro Woche erzeugen Momentum. Unsere Programme sind bewusst kompakt gehalten.'
  },
  {
    question: 'Ist das Ganze auch fürs Team geeignet?',
    answer:
      'Ja! Viele Teams nutzen Tivarenso, um gemeinsame Fokusfenster und gesunde Notification-Regeln zu etablieren.'
  },
  {
    question: 'Was ist, wenn ich mal aus der Routine falle?',
    answer:
      'Total normal. Wir zeigen Dir, wie Du mit Rückfällen freundlich umgehst und zügig wieder in den Fokus findest.'
  }
];

const Home = () => {
  const [counts, setCounts] = React.useState(statsData.map(() => 0));
  const [statsStarted, setStatsStarted] = React.useState(false);
  const statsRef = React.useRef(null);
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);
  const [activeCategory, setActiveCategory] = React.useState('Alle');
  const [faqOpen, setFaqOpen] = React.useState(0);

  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsStarted) {
            setStatsStarted(true);
          }
        });
      },
      { threshold: 0.3 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, [statsStarted]);

  React.useEffect(() => {
    if (!statsStarted) return;
    const intervals = statsData.map((stat, index) => {
      const endValue = stat.value;
      const duration = 1400;
      const step = Math.ceil(endValue / (duration / 16));

      return setInterval(() => {
        setCounts((prev) => {
          const nextValue = prev[index] + step;
          if (nextValue >= endValue) {
            clearInterval(intervals[index]);
            const updated = [...prev];
            updated[index] = endValue;
            return updated;
          }
          const updated = [...prev];
          updated[index] = nextValue;
          return updated;
        });
      }, 16);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsStarted]);

  React.useEffect(() => {
    const autoRotate = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(autoRotate);
  }, []);

  const filteredProjects =
    activeCategory === 'Alle'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Tivarenso | Mehr Fokus, weniger Ablenkung</title>
        <meta
          name="description"
          content="Tivarenso begleitet Dich mit Programmen, Tools und Routinen zu bewussterem Aufmerksamkeitsmanagement in der Clip-Content-Ära."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`container ${styles.heroGrid}`}>
          <div className={styles.heroContent}>
            <p className={styles.heroLabel}>Bewusst durch die Clip-Content-Ära</p>
            <h1 className={styles.heroTitle}>
              Mehr Fokus. Weniger Ablenkung im Kopf.
            </h1>
            <p className={styles.heroDescription}>
              Tivarenso hilft Dir, Deine Aufmerksamkeit zurückzugewinnen – mit klaren Routinen,
              empathischen Leitfäden und alltagstauglichen Challenges. Nicht mehr Hustle, sondern
              bewusste Präsenz.
            </p>
            <div className={styles.heroActions}>
              <Link to="/programs" className="button buttonPrimary">
                Jetzt starten
              </Link>
              <Link to="/guide" className="button buttonSecondary">
                Fokus stärken
              </Link>
            </div>
            <ul className={styles.heroList} aria-label="Fokus Themen">
              <li>Kurzvideos bewusst nutzen</li>
              <li>Social Media Grenzen setzen</li>
              <li>Multitasking entwirren</li>
              <li>Notifications zähmen</li>
            </ul>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/seed/tivarenso-hero/1600/900"
              alt="Person arbeitet konzentriert an einem hellen Arbeitsplatz"
            />
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {counts[index]}
                  {stat.suffix}
                </span>
                <p className={styles.statLabel}>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Tivarenso Essentials</p>
            <h2>Deine Aufmerksamkeit bekommt einen Plan</h2>
            <p className={styles.sectionDescription}>
              Wir kombinieren digitale Hygiene, Neuro-Insights und sanfte Routinen. Alles, was Du
              brauchst, um im Alltag klar zu bleiben.
            </p>
          </div>
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <Link to={service.to} className={styles.serviceCard} key={service.title}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <span className={styles.serviceLink}>Mehr erfahren →</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Unser Leitfaden</p>
            <h2>So wird Fokus wieder Deine Superpower</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <div className={styles.processStep} key={step.title}>
                <div className={styles.stepNumber}>{index + 1}</div>
                <h3>{step.title}</h3>
                <p className={styles.stepSubtitle}>{step.subtitle}</p>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Warum Tivarenso</p>
            <h2>Realistische Strategien für echte Lebensrealitäten</h2>
            <p className={styles.sectionDescription}>
              Kein Dogma, kein Digital Detox Extrem. Stattdessen pragmatische Strategien, die Du
              heute starten und morgen spüren kannst.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <div className={styles.whyItem}>
              <h3>Empathisch & menschlich</h3>
              <p>Wir wissen, wie schwierig es ist, sich vom Scroll-Strudel zu lösen. Deshalb arbeiten wir mit Verständnis statt Druck.</p>
            </div>
            <div className={styles.whyItem}>
              <h3>Daten plus Gefühl</h3>
              <p>Du bekommst klare Messpunkte, ohne Dich zu überfordern. Fakten unterstützen Dein Bauchgefühl.</p>
            </div>
            <div className={styles.whyItem}>
              <h3>Flexibel integrierbar</h3>
              <p>Unsere Routinen passen sich Deinem Alltag an – egal ob Du Creator:in, Studierende:r oder Teamplayer bist.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialWrapper}>
            <div className={styles.testimonialHeader}>
              <p className={styles.sectionEyebrow}>Stimmen aus der Community</p>
              <h2>So fühlt sich mehr Fokus im echten Leben an</h2>
            </div>
            <div className={styles.testimonialContent}>
              <p className={styles.testimonialQuote}>
                {testimonials[testimonialIndex].quote}
              </p>
              <div className={styles.testimonialMeta}>
                <strong>{testimonials[testimonialIndex].name}</strong>
                <span>{testimonials[testimonialIndex].role}</span>
              </div>
            </div>
            <div className={styles.testimonialControls}>
              <button
                onClick={() =>
                  setTestimonialIndex((prev) =>
                    prev === 0 ? testimonials.length - 1 : prev - 1
                  )
                }
                aria-label="Vorheriges Testimonial"
              >
                ←
              </button>
              <button
                onClick={() =>
                  setTestimonialIndex((prev) => (prev + 1) % testimonials.length)
                }
                aria-label="Nächstes Testimonial"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Das Team</p>
            <h2>Wir arbeiten mit Dir, nicht gegen Dich</h2>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <div className={styles.teamCard} key={member.name}>
                <img src={member.image} alt={`Portrait von ${member.name}`} />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <div>
              <p className={styles.sectionEyebrow}>Projekte</p>
              <h2>Fokuserfolge aus unterschiedlichen Lebenswelten</h2>
            </div>
            <div className={styles.filterGroup} role="group" aria-label="Projektfilter">
              {['Alle', 'Unternehmen', 'Creators', 'Studierende'].map((category) => (
                <button
                  key={category}
                  className={`${styles.filterButton} ${
                    activeCategory === category ? styles.filterActive : ''
                  }`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article className={styles.projectCard} key={project.title}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`Projektbeispiel: ${project.title}`} />
                </div>
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>FAQ</p>
            <h2>Antworten auf Deine häufigsten Fragen</h2>
          </div>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => (
              <div className={styles.faqItem} key={faq.question}>
                <button
                  className={styles.faqQuestion}
                  onClick={() => setFaqOpen((prev) => (prev === index ? -1 : index))}
                  aria-expanded={faqOpen === index}
                >
                  {faq.question}
                  <span>{faqOpen === index ? '–' : '+'}</span>
                </button>
                {faqOpen === index && <p className={styles.faqAnswer}>{faq.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Blog</p>
            <h2>Frische Impulse für Deinen Fokus-Alltag</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.slice(0, 3).map((post) => (
              <article className={styles.blogCard} key={post.slug}>
                <div className={styles.blogImage}>
                  <img src={post.heroImage} alt={`Blogartikel: ${post.title}`} />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogMeta}>
                    {new Date(post.date).toLocaleDateString('de-DE', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric'
                    })}{' '}
                    · {post.readingTime}
                  </span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                    Weiterlesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.blogCTA}>
            <Link to="/blog" className="button buttonSecondary">
              Alle Artikel entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Bereit, Deine Aufmerksamkeit zu schützen?</h2>
            <p>
              Lass uns gemeinsam herausfinden, was Dich wirklich fokussiert. Keine Dogmen, sondern
              klare Experimente, die sich lebendig anfühlen.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contact" className="button buttonPrimary">
                Kostenloses Erstgespräch
              </Link>
              <Link to="/programs" className="button buttonGhost">
                Programme ansehen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;