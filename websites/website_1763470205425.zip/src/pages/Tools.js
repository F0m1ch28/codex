import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Ablenkungs-Checkliste',
    description:
      'Prüfe in 10 Minuten, welche Apps, Feeds und Geräte Deine Aufmerksamkeit am häufigsten entführen.',
    items: ['Trigger erkennen', 'Zeitfenster zuordnen', 'Bewusste Alternativen']
  },
  {
    title: 'Fokus-Tagesplan',
    description:
      'Strukturiere Deinen Tag in Fokus-, Maintenance- und Off-Zonen. So weißt Du immer, wann Deep Work möglich ist.',
    items: ['Energielevel tracken', 'Fokusfenster setzen', 'Routinen reviewen']
  },
  {
    title: 'Zeitfenster-Plan',
    description:
      'Ein flexibles Raster, mit dem Du Social Media, Mails und Deep Work harmonisch koordinierst.',
    items: ['Slot-System', 'Notification-Fenster', 'Reflexionsblatt']
  }
];

const Tools = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Tools & Checklisten | Tivarenso</title>
        <meta
          name="description"
          content="Nutze praxiserprobte Checklisten, Tagespläne und Zeitfenster-Vorlagen für Deinen Fokusalltag."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Tools & Checklisten</h1>
          <p>Struktur, die sich leicht anfühlt. Alle Vorlagen sind editierbar und sofort einsatzbereit.</p>
        </div>
      </section>

      <section className={styles.toolList}>
        <div className="container">
          <div className={styles.grid}>
            {tools.map((tool) => (
              <article key={tool.title} className={styles.card}>
                <div>
                  <h2>{tool.title}</h2>
                  <p>{tool.description}</p>
                </div>
                <ul>
                  {tool.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <button type="button" className={styles.downloadButton}>
                  Download anfordern
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Tools;