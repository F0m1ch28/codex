import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const offerings = [
  {
    title: 'Fokus-Sparring für Einzelpersonen',
    description:
      '45-minütige Sessions, in denen wir Deinen Alltag analysieren, Fokus-Regeln festlegen und Dir sanfte Experimente mitgeben.',
    highlights: ['Persönliche Rituale', 'Aufmerksamkeitstagebuch', 'Reflexionsfragen']
  },
  {
    title: 'Fokus-Programm für Teams',
    description:
      'Gemeinsam etablieren wir Meeting-Fenster, Notification-Regeln und Deep-Work-Zonen. Mit spielerischen Check-ins.',
    highlights: ['Kick-off Workshop', 'Team Canvas', 'Sammel-Experimente']
  },
  {
    title: 'Creator Fokus Flow',
    description:
      'Wir helfen Dir, Content-Produktion, Community und Ruhephasen in Balance zu bringen – ohne Burnout.',
    highlights: ['Batching-Strategien', 'Energy Mapping', 'Reminder-Framework']
  }
];

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Angebote | Tivarenso Services</title>
        <meta
          name="description"
          content="Entdecke die Services von Tivarenso: Fokus-Sparring, Team-Programme und Creator-spezifische Routinen."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Unsere Angebote</h1>
          <p>
            Ob Einzelperson, Team oder Creator-Collective – wir gestalten Erlebnisse, die Deine
            Aufmerksamkeit schützen und stärken.
          </p>
        </div>
      </section>

      <section className={styles.offerings}>
        <div className="container">
          <div className={styles.cardGrid}>
            {offerings.map((offering) => (
              <article key={offering.title} className={styles.card}>
                <h2>{offering.title}</h2>
                <p>{offering.description}</p>
                <ul>
                  {offering.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
                <Link to="/contact" className={styles.cardLink}>
                  Lass uns sprechen →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Unsicher, was gerade passt?</h2>
            <p>Buche ein kurzes Kennenlernen. Wir hören zu und empfehlen Dir den nächsten sanften Schritt.</p>
            <Link to="/contact" className="button buttonPrimary">
              Kennenlernen vereinbaren
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;