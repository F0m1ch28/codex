import React from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'tivarenso-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(STORAGE_KEY, 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Cookies für mehr Fokus?</h4>
        <p>
          Wir verwenden minimale Cookies, um Dein Erlebnis zu verbessern. Du entscheidest, ob Du
          zustimmst. Mehr Infos findest Du in unserer{' '}
          <a href="/privacy">Datenschutzerklärung</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button onClick={handleDecline} className={styles.secondary}>
          Ablehnen
        </button>
        <button onClick={handleAccept} className={styles.primary}>
          Zustimmen
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;