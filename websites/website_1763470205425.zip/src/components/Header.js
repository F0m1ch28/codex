import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/services', label: 'Angebote' },
  { to: '/guide', label: 'Leitfaden' },
  { to: '/programs', label: 'Programme' },
  { to: '/tools', label: 'Tools' },
  { to: '/blog', label: 'Blog' },
  { to: '/about', label: 'Über uns' },
  { to: '/contact', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);
  const location = useLocation();

  React.useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.logoArea}>
          <NavLink to="/" className={styles.logo}>
            Tivarenso
          </NavLink>
          <p className={styles.tagline}>Fokus neu gedacht</p>
        </div>
        <button
          className={styles.menuButton}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="hauptnavigation"
          aria-label="Hauptnavigation umschalten"
        >
          <span className={styles.menuIcon} />
          <span className="sr-only">Menü</span>
        </button>
        <nav
          id="hauptnavigation"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Hauptnavigation"
        >
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.to} className={styles.navItem}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <NavLink to="/programs" className={styles.ctaLink}>
            Fokus stärken
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;