import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <h3 className={styles.title}>Tivarenso</h3>
          <p className={styles.subtitle}>
            Dein Kompass für bewusstes Aufmerksamkeitsmanagement in einer Welt voller Clips und
            Pings.
          </p>
          <div className={styles.contact}>
            <p>Adresse: Musterstraße 12, 10115 Berlin</p>
            <p>E-Mail: <a href="mailto:kontakt@tivarenso.site">kontakt@tivarenso.site</a></p>
            <p>Telefon: +49 30 1234 567890</p>
          </div>
        </div>
        <div className={styles.links}>
          <h4 className={styles.columnTitle}>Navigation</h4>
          <ul className={styles.linkList}>
            <li><NavLink to="/services">Angebote</NavLink></li>
            <li><NavLink to="/guide">Leitfaden</NavLink></li>
            <li><NavLink to="/programs">Programme</NavLink></li>
            <li><NavLink to="/tools">Tools</NavLink></li>
            <li><NavLink to="/blog">Blog</NavLink></li>
          </ul>
        </div>
        <div className={styles.links}>
          <h4 className={styles.columnTitle}>Rechtliches</h4>
          <ul className={styles.linkList}>
            <li><NavLink to="/legal">Rechtliche Hinweise</NavLink></li>
            <li><NavLink to="/privacy">Datenschutz</NavLink></li>
            <li><NavLink to="/imprint">Impressum</NavLink></li>
          </ul>
        </div>
        <div className={styles.newsletter}>
          <h4 className={styles.columnTitle}>Fokustipps</h4>
          <p>Erhalte regelmäßig Impulse für mehr Fokus, Klarheit und gelassene Bildschirmzeit.</p>
          <form className={styles.form} aria-label="Newsletter Formular">
            <label htmlFor="newsletter-email" className="sr-only">E-Mail</label>
            <input
              id="newsletter-email"
              type="email"
              placeholder="Deine E-Mail-Adresse"
              required
              aria-required="true"
            />
            <button type="submit">Anmelden</button>
          </form>
          <small>Kein Spam. Du kannst Dich jederzeit abmelden.</small>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className="container">
          <p>© {year} Tivarenso. Bewusst. Klar. Aufmerksam.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;