export const blogPosts = [
  {
    slug: 'mikro-pausen-im-digitalen-alltag',
    title: 'Mikro-Pausen im digitalen Alltag: Wie Du Deine Aufmerksamkeit frisch hältst',
    excerpt:
      'Zwischendurch kurz abschalten – klingt banal, verändert aber Deine mentale Energie. Erfahre, wie Du Mikro-Pausen smart integrierst.',
    date: '2024-05-08',
    readingTime: '6 Minuten',
    author: 'Lea Thomsen',
    heroImage: 'https://picsum.photos/seed/tivarenso-blog1/1200/800',
    sections: [
      {
        heading: 'Warum Mikro-Pausen wirken',
        text: 'Unser Gehirn liebt Zyklen. Nach ca. 25–35 Minuten intensiver Aufmerksamkeit sinkt die neuronale Aktivierung. Kurze Pausen signalisieren Deinem Nervensystem: Hier darf Spannung abgebaut werden, bevor sie sich anstaut. Das Ergebnis? Mehr Fokus, weniger impulsives Scrollen.'
      },
      {
        heading: 'Mikro-Pausen in Deinen Workflow einbauen',
        text: 'Setze Dir klare Stopps — etwa mit einem leisen Timer. Steh‘ kurz auf, schau aus dem Fenster, atme viermal tief ein und aus oder dehne Deinen Rücken. Wichtig ist, dass Du nicht zum Handy greifst. Nach 60 Sekunden darfst Du weitermachen.'
      },
      {
        heading: 'Mini-Reset am Smartphone',
        text: 'Wenn Du viel am Smartphone arbeitest, nutze Widgets, die Dich an Pausen erinnern. Oder verschiebe Lieblings-Apps kurz auf Seite 2. Jedes kleine Hindernis hilft Dir, bewusster zu entscheiden: Möchte ich jetzt wirklich hinein springen?'
      }
    ]
  },
  {
    slug: 'benachrichtigungen-neu-denken',
    title: 'Benachrichtigungen neu denken: Welche Signale verdienen Deine Aufmerksamkeit?',
    excerpt:
      'Notifications sind wie kleine Energiestaubsauger. Wir zeigen Dir, wie Du Prioritäten setzt und Apps neu trainierst.',
    date: '2024-04-18',
    readingTime: '7 Minuten',
    author: 'Mara Kessler',
    heroImage: 'https://picsum.photos/seed/tivarenso-blog2/1200/800',
    sections: [
      {
        heading: 'Signal oder Rauschen?',
        text: 'Frage Dich bei jeder Benachrichtigung: Muss ich jetzt reagieren oder reicht es später? Erstelle zwei Kategorien: Fokusrelevant und nice-to-know. Nur die erste Kategorie darf Töne abspielen.'
      },
      {
        heading: 'Das 1x pro Woche Notification-Reset',
        text: 'Reserviere Dir freitags 10 Minuten, um in den Einstellungen aufzuräumen. Deaktiviere Badges, die Stress erzeugen. Lass Dein Handy für bestimmte Kontakte klingeln, aber blocke Promos.'
      },
      {
        heading: 'Bewusste Notification-Fenster',
        text: 'Plane Slots, in denen Du bewusst in Deine Inbox gehst. Die restliche Zeit bleibt sie geschlossen. So behältst Du die Initiative statt reaktiv zu sein.'
      }
    ]
  },
  {
    slug: 'deep-work-ohne-druck',
    title: 'Deep Work ohne Druck: Sanfte Strategien für konzentrierte Zeitfenster',
    excerpt:
      'Deep Work klingt nach Hochleistung. Wir zeigen Dir, wie Du konzentrierte Phasen entspannt und menschlich gestaltest.',
    date: '2024-03-30',
    readingTime: '8 Minuten',
    author: 'Jonas Feld',
    heroImage: 'https://picsum.photos/seed/tivarenso-blog3/1200/800',
    sections: [
      {
        heading: 'Sich selbst aufwärmen',
        text: 'Starte jede Deep-Work-Session mit einem klaren Fokus-Statement: „Ich widme die nächsten 30 Minuten der Ausarbeitung von XY.“ Schreib es auf, leg Dein Handy außerhalb der Reichweite und gönn Dir zwei tiefe Atemzüge.'
      },
      {
        heading: 'Energiemanagement beachten',
        text: 'Plane Deine Deep-Work-Blöcke zu Zeiten, in denen Dein Energielevel hoch ist. Für viele ist das morgens. Akzeptiere, wenn Du am Nachmittag eher leichte Aufgaben brauchst.'
      },
      {
        heading: 'Reflektieren statt bewerten',
        text: 'Nach jeder Session kurz notieren: Was hat Deinen Fokus unterstützt? Was hat ihn gestört? So wächst Deine Aufmerksamkeitskompetenz Schritt für Schritt.'
      }
    ]
  }
];