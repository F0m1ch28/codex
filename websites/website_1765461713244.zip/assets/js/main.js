document.addEventListener("DOMContentLoaded", () => {
  const yearEls = document.querySelectorAll("#current-year");
  const year = new Date().getFullYear();
  yearEls.forEach(el => (el.textContent = year));

  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("is-open");
    });
  }

  const banner = document.querySelector(".cookie-banner");
  if (!banner) return;

  const acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
  const declineBtn = banner.querySelector('[data-cookie-action="decline"]');
  const storageKey = "cma_cookie_preference";

  const closeBanner = () => {
    banner.classList.add("is-hidden");
    setTimeout(() => {
      banner.remove();
    }, 320);
  };

  const showBanner = () => {
    requestAnimationFrame(() => {
      banner.classList.add("is-visible");
    });
  };

  const storedPreference = localStorage.getItem(storageKey);
  if (!storedPreference) {
    showBanner();
  } else {
    banner.remove();
  }

  acceptBtn?.addEventListener("click", () => {
    localStorage.setItem(storageKey, "accepted");
    closeBanner();
  });

  declineBtn?.addEventListener("click", () => {
    localStorage.setItem(storageKey, "declined");
    closeBanner();
  });
});