document.addEventListener("DOMContentLoaded", function () {
  const banner = document.querySelector(".cookie-banner");
  const acceptButton = document.getElementById("cookie-accept");
  const declineButton = document.getElementById("cookie-decline");
  const consentKey = "heatHarvestCookieConsent";

  if (banner) {
    const existingConsent = localStorage.getItem(consentKey);
    if (!existingConsent) {
      banner.classList.add("is-visible");
    }

    if (acceptButton) {
      acceptButton.addEventListener("click", function () {
        localStorage.setItem(consentKey, "accepted");
        banner.classList.remove("is-visible");
      });
    }

    if (declineButton) {
      declineButton.addEventListener("click", function () {
        localStorage.setItem(consentKey, "declined");
        banner.classList.remove("is-visible");
      });
    }
  }

  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const email = formData.get("email");
      const phone = formData.get("phone");
      const projectScope = formData.get("project-scope");
      const messageArea = document.getElementById("form-feedback");
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const phonePattern = /^[+\d][\d\s\-().]{7,}$/;

      let errors = [];

      if (!emailPattern.test(email)) {
        errors.push("Please provide a valid email address.");
      }

      if (phone && !phonePattern.test(phone)) {
        errors.push("Phone number should include only numbers and standard symbols.");
      }

      if (!projectScope) {
        errors.push("Please let us know your project scope.");
      }

      if (errors.length > 0) {
        messageArea.textContent = errors.join(" ");
        messageArea.classList.add("is-visible");
        messageArea.style.color = "#c0392b";
        return;
      }

      messageArea.textContent = "Thank you. Our team will reach out within one business day.";
      messageArea.classList.add("is-visible");
      messageArea.style.color = "#127c67";
      contactForm.reset();
    });
  }
});