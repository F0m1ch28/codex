import React, { createContext, useContext, useMemo, useState } from 'react';

const CompareContext = createContext();

export const CompareProvider = ({ children }) => {
  const [selectedCasinos, setSelectedCasinos] = useState([]);

  const toggleCasino = (slug) => {
    setSelectedCasinos((prev) => {
      if (prev.includes(slug)) {
        return prev.filter((item) => item !== slug);
      }
      if (prev.length >= 3) {
        const [, ...rest] = [...prev, slug];
        return rest;
      }
      return [...prev, slug];
    });
  };

  const clearCompare = () => {
    setSelectedCasinos([]);
  };

  const value = useMemo(
    () => ({
      selectedCasinos,
      toggleCasino,
      clearCompare,
      isSelected: (slug) => selectedCasinos.includes(slug)
    }),
    [selectedCasinos]
  );

  return <CompareContext.Provider value={value}>{children}</CompareContext.Provider>;
};

export const useCompare = () => useContext(CompareContext);