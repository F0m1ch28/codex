import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import { useCompare } from '../context/CompareContext';
import usePageMetadata from '../hooks/usePageMetadata';
import CompareTable from '../components/CompareTable/CompareTable';
import styles from './ComparePage.module.css';

const ComparePage = () => {
  usePageMetadata(
    'Сравнение казино — GambleReview',
    'Сравните лицензии, бонусы, количество игр и скорость выплат отобранных казино. Гибкий инструмент сравнения от GambleReview.'
  );
  const { selectedCasinos, toggleCasino, clearCompare } = useCompare();

  const casinosToCompare = useMemo(
    () => casinos.filter((casino) => selectedCasinos.includes(casino.slug)),
    [selectedCasinos]
  );

  return (
    <section className="section">
      <div className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1 className="sectionTitle">Инструмент сравнения казино</h1>
          <p className="sectionSubtitle">
            Выберите до трёх казино и сравните ключевые условия: приветственный бонус, лицензия, количество игр, минимальный
            депозит и рейтинг команды GambleReview. Все данные обновляются автоматически при изменении условий площадок.
          </p>
        </header>

        {casinosToCompare.length === 0 ? (
          <div className={styles.empty}>
            <p>Вы ещё не добавили казино для сравнения.</p>
            <Link to="/casino" className="btn btnPrimary">
              Перейти к каталогу
            </Link>
          </div>
        ) : (
          <>
            <CompareTable casinos={casinosToCompare} onRemove={toggleCasino} />
            <div className={styles.actions}>
              <button type="button" className="btn btnSecondary" onClick={clearCompare}>
                Очистить список
              </button>
              <Link to="/casino" className="btn btnPrimary">
                Добавить ещё казино
              </Link>
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default ComparePage;