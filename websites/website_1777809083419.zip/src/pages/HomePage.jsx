import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import HeroSection from '../components/HeroSection/HeroSection';
import casinos from '../data/casinos';
import CasinoCard from '../components/CasinoCard/CasinoCard';
import ReviewCriteria from '../components/ReviewCriteria/ReviewCriteria';
import FAQ from '../components/FAQ/FAQ';
import { useCompare } from '../context/CompareContext';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './HomePage.module.css';

const HomePage = () => {
  usePageMetadata(
    'GambleReview — обзоры и сравнение казино',
    'Подробные обзоры казино, анализ лицензий, сравнение бонусов и честные рекомендации от команды GambleReview.'
  );
  const { toggleCasino, isSelected, selectedCasinos } = useCompare();
  const [stats, setStats] = useState([
    { id: 'reviews', label: 'Подробных обзоров', target: 128, value: 0 },
    { id: 'bonuses', label: 'Проверенных бонусов', target: 86, value: 0 },
    { id: 'countries', label: 'Стран аудитории', target: 14, value: 0 },
    { id: 'experts', label: 'Экспертов в команде', target: 6, value: 0 }
  ]);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('Все');

  useEffect(() => {
    const timers = stats.map((item, index) => {
      const increment = Math.ceil(item.target / 60);
      return setInterval(() => {
        setStats((prev) => {
          const clone = [...prev];
          const current = clone[index];
          if (current.value < current.target) {
            current.value = Math.min(current.value + increment, current.target);
          }
          return clone;
        });
      }, 30);
    });

    return () => {
      timers.forEach((timer) => clearInterval(timer));
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const popularCasinos = useMemo(() => casinos.slice(0, 3), []);
  const latestReviews = useMemo(() => casinos.slice().sort((a, b) => b.rating - a.rating), []);

  const criteria = [
    {
      title: 'Бонусы и отыгрыш',
      description: 'Проверяем прозрачность бонусных условий, ограничения по ставкам и реальные сроки отыгрыша.',
      icon: '🎁'
    },
    {
      title: 'Лицензия и безопасность',
      description: 'Отслеживаем статус лицензий, аудит RTP и сертификацию генераторов случайных чисел.',
      icon: '🛡️'
    },
    {
      title: 'Каталог игр',
      description: 'Считаем количество провайдеров, live-столов, мобильных слотов и эксклюзивных игр.',
      icon: '🎰'
    },
    {
      title: 'Платежи',
      description: 'Измеряем скорость депозитов и выводов, комиссии и поддерживаемые валюты, включая крипто.',
      icon: '💳'
    }
  ];

  const advantages = [
    {
      title: 'Независимая аналитика',
      description: 'Каждый обзор формируется на основе ручного тестирования продукта и публичных данных регуляторов.'
    },
    {
      title: 'Детальные чек-листы',
      description: 'Мы проверяем до 60 параметров: от лимитов по ставкам до SLA службы поддержки.'
    },
    {
      title: 'Удобное сравнение',
      description: 'Выбирайте до трёх казино для прямого сравнения по ключевым метрикам и бонусам.'
    }
  ];

  const services = [
    {
      title: 'Аудит условий бонуса',
      description: 'Мы анализируем отыгрыш, ограничения по ставкам и срок действия промо-акций.',
      image: 'https://picsum.photos/800/600?random=21'
    },
    {
      title: 'Мониторинг платежей',
      description: 'Собираем данные о скорости вывода и успешности транзакций по основным методам.',
      image: 'https://picsum.photos/800/600?random=22'
    },
    {
      title: 'Проверка лицензий',
      description: 'Подтверждаем актуальность лицензий в Curacao eGaming, MGA и других регуляторах.',
      image: 'https://picsum.photos/800/600?random=23'
    }
  ];

  const processSteps = [
    { step: '01', title: 'Исследование платформы', text: 'Тестируем регистрацию, KYC и прозрачность пользовательских соглашений.' },
    { step: '02', title: 'Финансовая проверка', text: 'Проверяем депозиты и выводы, фиксируем среднюю скорость и комиссии.' },
    { step: '03', title: 'Обзор игр', text: 'Сравниваем портфолио провайдеров и качество live-столов с живыми дилерами.' },
    { step: '04', title: 'Оценка поддержки', text: 'Связываемся со службой поддержки через разные каналы и оцениваем SLA.' }
  ];

  const testimonials = [
    {
      quote: 'Благодаря GambleReview мы полностью пересмотрели свой список партнёров. Подробное сравнение помогает принимать обоснованные решения.',
      author: 'Ирина С., партнерский менеджер',
      image: 'https://picsum.photos/400/400?random=31'
    },
    {
      quote: 'Редакция делает акцент на ответственной игре и тщательно проверяет бонусы. Это единственный рейтинг, которому доверяет наша команда.',
      author: 'Максим П., SEO-специалист',
      image: 'https://picsum.photos/400/400?random=32'
    },
    {
      quote: 'Очень нравится подход: нет агрессивных призывов, только факты и аналитика. Удобно сравнивать платформы перед сотрудничеством.',
      author: 'Анна Р., медиабайер',
      image: 'https://picsum.photos/400/400?random=33'
    }
  ];

  const teamMembers = [
    {
      name: 'Алексей Дорин',
      role: 'Главный аналитик',
      description: '10 лет в iGaming и опытом аудита платформ. Специализируется на лицензиях и платежных решениях.',
      image: 'https://picsum.photos/400/400?random=41'
    },
    {
      name: 'Мария Лисенко',
      role: 'Эксперт по ответственной игре',
      description: 'Разрабатывает методологии оценки безопасных инструментов и обучающие материалы.',
      image: 'https://picsum.photos/400/400?random=42'
    },
    {
      name: 'Дмитрий Корнеев',
      role: 'Редактор обзоров',
      description: 'Куратор контента, управляет фактчекингом и взаимодействием с провайдерами игр.',
      image: 'https://picsum.photos/400/400?random=43'
    }
  ];

  const projectCategories = ['Все', 'Бонусы', 'Live', 'Крипто'];
  const projectItems = [
    {
      id: 1,
      title: 'Подборка казино с live-дилерами',
      category: 'Live',
      description: 'Сравнили качество потоков, количество столов и работу русскоязычных дилеров.',
      image: 'https://picsum.photos/1200/800?random=51'
    },
    {
      id: 2,
      title: 'Казино с прозрачным отыгрышем бонусов',
      category: 'Бонусы',
      description: 'Подобрали только те площадки, где требования к отыгрышу не превышают x30.',
      image: 'https://picsum.photos/1200/800?random=52'
    },
    {
      id: 3,
      title: 'Платформы, принимающие криптовалюту',
      category: 'Крипто',
      description: 'Проверили скорость транзакций и поддержку BTC, ETH, LTC кошельков.',
      image: 'https://picsum.photos/1200/800?random=53'
    }
  ];

  const filteredProjects =
    selectedCategory === 'Все'
      ? projectItems
      : projectItems.filter((project) => project.category === selectedCategory);

  const blogPosts = [
    {
      id: 1,
      title: 'Как распознать честный бонус: чек-лист от GambleReview',
      date: '12 апреля 2024',
      excerpt: 'Пошаговая методика проверки бонусных условий и лимитов ставок перед активацией промо.',
      link: '/casino'
    },
    {
      id: 2,
      title: 'Ответственная игра: инструменты самоконтроля у топовых казино',
      date: '04 апреля 2024',
      excerpt: 'Сравнили лимиты, тайм-ауты и self-exclusion в лицензированных казино.',
      link: '/services'
    },
    {
      id: 3,
      title: 'Что нужно знать о лицензии Curacao eGaming в 2024 году',
      date: '26 марта 2024',
      excerpt: 'Анализ изменений в требованиях регулятора и их влияние на игроков.',
      link: '/about'
    }
  ];

  const faqItems = [
    {
      question: 'Почему в обзорах нет прямых ссылок на игру?',
      answer: 'Мы не продвигаем азартную игру и не размещаем ссылки на запуск игр. Наша задача — информировать, сравнивать условия и рассказывать о рисках, чтобы помочь пользователям принимать ответственные решения.'
    },
    {
      question: 'Как формируется рейтинг казино на GambleReview?',
      answer: 'Рейтинг формируется на основе 60 критериев. Среди ключевых: лицензия, прозрачность бонусов, скорость вывода, качество поддержки и инструменты ответственной игры. Финальная оценка — среднее взвешенное между нашими экспертами и пользовательскими отзывами.'
    },
    {
      question: 'Можно ли доверять отзывам пользователей на сайте?',
      answer: 'Мы проверяем каждый отзыв перед публикацией, уточняем детали транзакций и запрашиваем подтверждающие документы. Нереалистичные обещания выигрышей и агрессивная реклама не допускаются.'
    },
    {
      question: 'Что делать, если казино задерживает выплату?',
      answer: 'Мы рекомендуем документировать переписку с поддержкой, проверять условия бонусов и при необходимости обращаться в регулятор. В наших обзорах указаны контакты регулятора и горячих линий ответственной игры.'
    },
    {
      question: 'Можно ли добавить казино в сравнение с мобильного телефона?',
      answer: 'Да, сравнение доступно на всех устройствах. Вы можете выбрать до трёх казино, и выбранные площадки сохранятся при переходе между страницами.'
    }
  ];

  return (
    <>
      <HeroSection />
      <section className={`${styles.stats} section`}>
        <div className="container">
          <h2 className="sectionTitle">Почему нам доверяют партнёры и аудитория</h2>
          <p className="sectionSubtitle">
            Мы публикуем обзоры только после многоступенчатой проверки. Все данные о бонусах и лицензиях актуализируются каждые две недели.
          </p>
          <div className={styles.statsGrid}>
            {stats.map((stat) => (
              <div key={stat.id} className={styles.statsItem}>
                <span className={styles.statsValue}>{stat.value}+</span>
                <span className={styles.statsLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="sectionTitle">Популярные казино недели</h2>
          <p className="sectionSubtitle">
            Выбраны по совокупности показателей: доверие пользователей, скорость выплат и прозрачность приветственного бонуса.
          </p>
          <div className={styles.casinoGrid}>
            {popularCasinos.map((casino) => (
              <CasinoCard
                key={casino.slug}
                casino={casino}
                onToggleCompare={toggleCasino}
                isSelected={isSelected(casino.slug)}
              />
            ))}
          </div>
          <div className={styles.helperText}>
            {selectedCasinos.length > 0 ? (
              <Link to="/compare" className="btn btnSecondary">
                Перейти к сравнению ({selectedCasinos.length})
              </Link>
            ) : (
              <Link to="/casino" className="btn btnSecondary">
                Смотреть полный каталог
              </Link>
            )}
          </div>
        </div>
      </section>

      <section className={`${styles.criteriaSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Как мы оцениваем казино</h2>
          <p className="sectionSubtitle">
            Методология GambleReview основана на международных стандартах Responsible Gambling и опыте аудита более 100 платформ.
          </p>
          <ReviewCriteria criteria={criteria} />
        </div>
      </section>

      <section className={`${styles.advantagesSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Преимущества нашего аналитического подхода</h2>
          <div className={styles.advantagesGrid}>
            {advantages.map((item) => (
              <article key={item.title} className={`${styles.advantageCard} card`}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.servicesSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Что мы делаем для читателей и партнеров</h2>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceImage}>
                  <img src={service.image} alt={service.title} loading="lazy" />
                </div>
                <div className={styles.serviceContent}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.processSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Пошаговый процесс проверки казино</h2>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.step} className={`${styles.processCard} card`}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonialsSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Отзывы специалистов о GambleReview</h2>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.author}
                className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
              >
                <div className={styles.testimonialImage}>
                  <img src={testimonial.image} alt={testimonial.author} loading="lazy" />
                </div>
                <blockquote>
                  <p>“{testimonial.quote}”</p>
                  <footer>— {testimonial.author}</footer>
                </blockquote>
              </article>
            ))}
          </div>
          <div className={styles.testimonialDots}>
            {testimonials.map((_, index) => (
              <button
                type="button"
                key={index}
                className={index === activeTestimonial ? styles.dotActive : styles.dot}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Переключить отзыв ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.teamSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Команда экспертных обозревателей</h2>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={`${styles.teamCard} card`}>
                <div className={styles.teamImage}>
                  <img src={member.image} alt={member.name} loading="lazy" />
                </div>
                <div className={styles.teamMeta}>
                  <span className={styles.teamRole}>{member.role}</span>
                  <h3>{member.name}</h3>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.projectsSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Актуальные подборки казино</h2>
          <div className={styles.projectFilters}>
            {projectCategories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterBtn} ${selectedCategory === category ? styles.filterBtnActive : ''}`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className="tag">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/casino" className={styles.projectLink}>
                    Изучить подборку →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.latestReviewsSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Последние обзоры</h2>
          <div className={styles.latestGrid}>
            {latestReviews.map((casino) => (
              <article key={casino.slug} className={`${styles.latestCard} card`}>
                <span className="tag">Обновлено {casino.reviewDate}</span>
                <h3>{casino.name}</h3>
                <p>{casino.description}</p>
                <Link to={`/casino/${casino.slug}`} className={styles.latestLink}>
                  Читать обзор →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blogSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Блог GambleReview</h2>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={`${styles.blogCard} card`}>
                <span className="tag">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>
                  Читать далее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.faqSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Часто задаваемые вопросы</h2>
          <FAQ items={faqItems} />
        </div>
      </section>

      <section className={`${styles.ctaSection} section`}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Хотите получать обновления по лицензиям и бонусам?</h2>
              <p>
                Подпишитесь на рассылку GambleReview и узнавайте об изменениях в условиях казино без рекламных материалов и спама.
              </p>
            </div>
            <Link to="/contact" className="btn btnPrimary">
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;