import React, { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import casinos from '../data/casinos';
import { useCompare } from '../context/CompareContext';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './CasinoDetailPage.module.css';

const CasinoDetailPage = () => {
  const { slug } = useParams();
  const casino = useMemo(() => casinos.find((item) => item.slug === slug), [slug]);
  const { toggleCasino, isSelected } = useCompare();

  usePageMetadata(
    casino ? `${casino.name} — детальный обзор` : 'Казино не найдено — GambleReview',
    casino
      ? `Развёрнутый обзор ${casino.name}: бонусы, лицензии, способы оплаты, плюсы и минусы, оценки пользователей.`
      : 'Запрошенное казино не найдено.'
  );

  if (!casino) {
    return (
      <section className="section">
        <div className="container">
          <h1 className="sectionTitle">Казино не найдено</h1>
          <p className="sectionSubtitle">Похоже, мы не смогли найти этот обзор. Вернитесь к каталогу казино.</p>
          <Link to="/casino" className="btn btnPrimary">
            Вернуться к каталогу
          </Link>
        </div>
      </section>
    );
  }

  return (
    <article>
      <section className={styles.hero}>
        <img src={casino.image} alt={`Фон ${casino.name}`} className={styles.heroImage} />
        <div className={styles.heroOverlay} />
        <div className={`${styles.heroContent} container`}>
          <div>
            <span className="badge">Обновлено {casino.reviewDate}</span>
            <h1>{casino.name}</h1>
            <p>{casino.description}</p>
            <div className={styles.heroMeta}>
              <div>
                <span>Рейтинг команды</span>
                <strong>★ {casino.rating.toFixed(1)}</strong>
              </div>
              <div>
                <span>Лицензия</span>
                <strong>{casino.license}</strong>
              </div>
              <div>
                <span>Игры</span>
                <strong>{casino.gamesCount}</strong>
              </div>
              <div>
                <span>Мин. депозит</span>
                <strong>{casino.minDeposit}</strong>
              </div>
            </div>
            <div className={styles.heroActions}>
              <button
                type="button"
                className={`btn ${isSelected(casino.slug) ? styles.selectedBtn : 'btnPrimary'}`}
                onClick={() => toggleCasino(casino.slug)}
              >
                {isSelected(casino.slug) ? 'В сравнении' : 'Добавить в сравнение'}
              </button>
              <Link to="/compare" className="btn btnSecondary">
                Перейти к сравнению
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.infoSection} section`}>
        <div className="container">
          <div className={styles.infoGrid}>
            <div className={`${styles.infoCard} card`}>
              <h2>Условия приветственного бонуса</h2>
              <p>{casino.bonusTerms}</p>
              <div className={styles.bonusBox}>
                <span>Предложение</span>
                <strong>{casino.bonus}</strong>
              </div>
            </div>
            <div className={`${styles.infoCard} card`}>
              <h2>Методы оплаты</h2>
              <ul className={styles.paymentList}>
                {casino.paymentMethods.map((method) => (
                  <li key={method}>{method}</li>
                ))}
              </ul>
              <p className={styles.smallText}>Средняя скорость вывода: {casino.payoutSpeed}</p>
            </div>
          </div>

          <div className={styles.splitGrid}>
            <div className={`${styles.splitCard} card`}>
              <h3>Плюсы</h3>
              <ul>
                {casino.pros.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className={`${styles.splitCard} card`}>
              <h3>Минусы</h3>
              <ul>
                {casino.cons.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className={`${styles.gamesSection} card`}>
            <h2>Игры и провайдеры</h2>
            <ul>
              {casino.games.map((game) => (
                <li key={game}>{game}</li>
              ))}
            </ul>
          </div>

          <div className={`${styles.userSection} card`}>
            <h2>Оценка пользователей</h2>
            <div className={styles.userStats}>
              <div>
                <strong>{casino.userScore.average.toFixed(1)}</strong>
                <span>Средний балл</span>
              </div>
              <div>
                <strong>{casino.userScore.votes}</strong>
                <span>Проверенных отзывов</span>
              </div>
            </div>
            <p>
              Мы публикуем отзывы только после модерации. Рейтинги пользователей учитывают опыт верифицированных игроков и
              представителей партнёрских сетей.
            </p>
          </div>

          <div className={`${styles.supportSection} card`}>
            <h2>Каналы поддержки</h2>
            <ul className={styles.supportList}>
              {casino.supportChannels.map((channel) => (
                <li key={channel}>{channel}</li>
              ))}
            </ul>
            <p>
              Время ответа live-чата в среднем составляет 2–4 минуты. Email поддержка отвечает в течение 2 часов. В VIP
              отделе доступен персональный менеджер.
            </p>
          </div>
        </div>
      </section>
    </article>
  );
};

export default CasinoDetailPage;