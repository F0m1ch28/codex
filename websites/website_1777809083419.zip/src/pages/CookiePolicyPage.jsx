import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => {
  usePageMetadata(
    'Cookie Policy — GambleReview',
    'Политика использования файлов cookie на сайте GambleReview.'
  );

  return (
    <section className="section">
      <div className={`container ${styles.wrapper}`}>
        <h1 className="sectionTitle">Cookie Policy</h1>
        <div className={styles.content}>
          <p>
            Cookies используются для хранения пользовательских настроек и проведения обезличенной аналитики посещаемости.
            Мы не применяем маркетинговые cookies. Вы можете отключить их в настройках браузера, однако некоторые функции
            сайта могут работать некорректно.
          </p>
          <p>
            Продолжая использовать сайт, вы соглашаетесь с применением cookies. Вопросы по политике cookies отправляйте на
            info@gamblereview.com.
          </p>
        </div>
      </div>
    </section>
  );
};

export default CookiePolicyPage;