import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  usePageMetadata(
    'О проекте — GambleReview',
    'Узнайте, кто стоит за GambleReview: эксперты с опытом в iGaming, принципы работы и методология анализа казино.'
  );

  const milestones = [
    {
      year: '2018',
      title: 'Старт проекта',
      text: 'Команда аналитиков iGaming сформировала закрытую базу проверок казино для партнёрских сетей.'
    },
    {
      year: '2020',
      title: 'Публичные обзоры',
      text: 'Мы запустили открытый сайт с детальными обзорами и чек-листами для ответственной игры.'
    },
    {
      year: '2022',
      title: 'Методология 2.0',
      text: 'Добавлены метрики по инструментам Responsible Gambling и расширена аналитика платежей.'
    },
    {
      year: '2024',
      title: 'Международное присутствие',
      text: 'Команда выросла до 12 экспертов, мы покрываем рынки СНГ, ЕС и Латинской Америки.'
    }
  ];

  return (
    <section className="section">
      <div className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1 className="sectionTitle">О проекте GambleReview</h1>
          <p className="sectionSubtitle">
            Наша миссия — предоставлять объективную и проверенную информацию о международных казино, поддерживая
            инструменты ответственной игры и помогая аудитории избегать нечестных предложений.
          </p>
        </header>

        <div className={styles.contentGrid}>
          <article className={`${styles.card} card`}>
            <h2>Принципы работы</h2>
            <ul>
              <li>Проверяем данные вручную: бонусы, платежи, службу поддержки.</li>
              <li>Не публикуем агрессивные офферы и нереалистичные обещания выигрыша.</li>
              <li>Фактчекинг и обновления каждые 14 дней или при изменении условий.</li>
              <li>Раздельный учёт редакционной и рекламной информации.</li>
            </ul>
          </article>
          <article className={`${styles.card} card`}>
            <h2>Коммуникация с казино</h2>
            <p>
              Мы напрямую взаимодействуем с лицензированными операторами и регуляторами. Если условия платформы
              изменяются, обзоры обновляются после подтверждения фактов. Пользователи могут сообщать о проблемах через
              форму обратной связи.
            </p>
            <p>
              GambleReview не принимает вознаграждение за положительные оценки. Если площадка предлагает особые условия,
              мы раскрываем это в обзоре.
            </p>
          </article>
        </div>

        <section className={styles.timeline}>
          <h2>Ключевые этапы развития</h2>
          <div className={styles.timelineGrid}>
            {milestones.map((milestone) => (
              <div key={milestone.year} className={styles.timelineItem}>
                <span className={styles.year}>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.text}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </section>
  );
};

export default AboutPage;