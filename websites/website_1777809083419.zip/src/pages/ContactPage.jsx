import React, { useState } from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  usePageMetadata(
    'Контакты — GambleReview',
    'Свяжитесь с командой GambleReview: вопросы по обзорам казино, сотрудничество и сообщения о нарушениях.'
  );

  const [formData, setFormData] = useState({ name: '', email: '', message: '', consent: false });
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');

  const validate = () => {
    const newErrors = {};
    if (formData.name.trim().length < 2) newErrors.name = 'Введите имя не короче двух символов.';
    if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Введите корректный email.';
    if (formData.message.trim().length < 20) newErrors.message = 'Сообщение должно содержать минимум 20 символов.';
    if (!formData.consent) newErrors.consent = 'Необходимо согласие на обработку данных.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSuccessMessage('Спасибо за обращение! Мы ответим на письмо в течение 24 часов.');
    setFormData({ name: '', email: '', message: '', consent: false });
    setErrors({});
  };

  return (
    <section className="section">
      <div className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1 className="sectionTitle">Связаться с GambleReview</h1>
          <p className="sectionSubtitle">
            Используйте форму, чтобы сообщить о неточностях, предложить сотрудничество или запросить аудит казино. Мы отвечаем
            в рабочие часы: 10:00–22:00 (UTC+3).
          </p>
        </header>

        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Имя</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Введите имя"
                value={formData.name}
                onChange={handleChange}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={handleChange}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                placeholder="Опишите ваш запрос или проблему подробно"
                value={formData.message}
                onChange={handleChange}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>

            <label className={styles.checkboxLabel}>
              <input
                type="checkbox"
                name="consent"
                checked={formData.consent}
                onChange={handleChange}
              />
              Соглашаюсь на обработку персональных данных и подтверждаю возраст 18+
            </label>
            {errors.consent && <span className={styles.error}>{errors.consent}</span>}

            <button type="submit" className="btn btnPrimary">
              Отправить сообщение
            </button>
            {successMessage && <p className={styles.success}>{successMessage}</p>}
          </form>

          <aside className={`${styles.info} card`}>
            <h2>Контактные данные</h2>
            <ul>
              <li>Email: info@gamblereview.com</li>
              <li>Telegram: @gamblereview_support</li>
              <li>Часы работы: 10:00–22:00 (UTC+3)</li>
            </ul>
            <p>
              Мы не предоставляем консультации по ставкам и не принимаем запросы на продвижение нелицензированных площадок. Пожалуйста,
              приложите максимум деталей к своему запросу.
            </p>
            <h3>FAQ для партнеров</h3>
            <ul>
              <li>Мы откликаемся на запросы в течение 24 часов.</li>
              <li>Аудит казино занимает 3–5 рабочих дней.</li>
              <li>Все отзывы проходят ручную модерацию.</li>
            </ul>
          </aside>
        </div>
      </div>
    </section>
  );
};

export default ContactPage;