import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './ServicesPage.module.css';

const ServicesPage = () => {
  usePageMetadata(
    'Услуги GambleReview',
    'Профессиональные услуги GambleReview: аудит бонусов, проверка платежей, мониторинг лицензий и внедрение Responsible Gaming.'
  );

  const services = [
    {
      title: 'Комплексный аудит казино',
      description:
        'Проводим полный аудит казино перед интеграцией: проверяем лицензии, договор с провайдером игр, финансовые отчёты и SLA службы поддержки.'
    },
    {
      title: 'Мониторинг VIP-программ',
      description:
        'Собираем данные о VIP-бонусах, лимитах и эксклюзивных предложениях. Анализируем соответствие требований ответственному гемблингу.'
    },
    {
      title: 'Ревизия бонусных условий',
      description:
        'Проверяем отыгрыш, максимальные ставки и ограничения по времени. Будем уведомлять при изменениях условий акций.'
    },
    {
      title: 'Аналитика платёжных решений',
      description:
        'Тестируем платежи различными методами, оцениваем скорость вывода и фиксируем комиссии. Сравниваем с отраслевыми стандартами.'
    }
  ];

  return (
    <section className="section">
      <div className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1 className="sectionTitle">Экспертные услуги GambleReview</h1>
          <p className="sectionSubtitle">
            Мы работаем с партнёрами, медиа и игроками, предоставляя объективные данные и методологии оценки казино. Ни одна услуга не
            включает призывов к азартной игре.
          </p>
        </header>
        <div className={styles.grid}>
          {services.map((service) => (
            <article key={service.title} className={`${styles.card} card`}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesPage;