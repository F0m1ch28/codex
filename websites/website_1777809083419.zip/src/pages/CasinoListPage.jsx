import React, { useMemo, useState } from 'react';
import casinos from '../data/casinos';
import CasinoCard from '../components/CasinoCard/CasinoCard';
import { useCompare } from '../context/CompareContext';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './CasinoListPage.module.css';

const CasinoListPage = () => {
  usePageMetadata(
    'Каталог казино — GambleReview',
    'Полный список проверенных казино: лицензии, бонусы, скорость выплат и методы оплаты. Сравните площадки и выберите подходящую.'
  );
  const { toggleCasino, isSelected } = useCompare();
  const [selectedLicense, setSelectedLicense] = useState('all');

  const licenses = useMemo(() => ['all', ...new Set(casinos.map((casino) => casino.license))], []);

  const filteredCasinos = useMemo(() => {
    if (selectedLicense === 'all') {
      return casinos;
    }
    return casinos.filter((casino) => casino.license === selectedLicense);
  }, [selectedLicense]);

  return (
    <section className="section">
      <div className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1 className="sectionTitle">Все обзоры казино</h1>
          <p className="sectionSubtitle">
            Здесь собрана база лицензированных казино, которые прошли аудит GambleReview. Используйте фильтры, чтобы
            быстрее найти площадку с нужной лицензией и бонусными условиями.
          </p>
          <div className={styles.filters}>
            <label htmlFor="licenseSelect">Фильтр по лицензии</label>
            <select
              id="licenseSelect"
              value={selectedLicense}
              onChange={(event) => setSelectedLicense(event.target.value)}
            >
              {licenses.map((license) => (
                <option key={license} value={license}>
                  {license === 'all' ? 'Все лицензии' : license}
                </option>
              ))}
            </select>
          </div>
        </header>
        <div className={styles.grid}>
          {filteredCasinos.map((casino) => (
            <CasinoCard
              key={casino.slug}
              casino={casino}
              onToggleCompare={toggleCasino}
              isSelected={isSelected(casino.slug)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CasinoListPage;