import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => {
  usePageMetadata(
    'Политика конфиденциальности — GambleReview',
    'Узнайте, как GambleReview обрабатывает и защищает персональные данные посетителей.'
  );

  return (
    <section className="section">
      <div className={`container ${styles.wrapper}`}>
        <h1 className="sectionTitle">Политика конфиденциальности</h1>
        <div className={styles.content}>
          <h2>Сбор данных</h2>
          <p>
            Мы собираем только те данные, которые пользователь добровольно предоставляет через форму обратной связи.
            Данные используются для ответа на запросы. Мы не продаём и не передаём личную информацию третьим лицам.
          </p>

          <h2>Cookies</h2>
          <p>
            Cookies применяются исключительно для аналитики и корректной работы сайта. Пользователь может в любой момент
            отключить cookies в настройках браузера. Подробнее — в разделе Cookie Policy.
          </p>

          <h2>Право на удаление данных</h2>
          <p>
            Пользователь может запросить удаление личных данных, отправив письмо на info@gamblereview.com. Запрос будет
            обработан в течение 30 дней.
          </p>

          <h2>Изменения политики</h2>
          <p>
            Мы можем обновлять политику конфиденциальности при изменении законодательства или методов обработки данных. Дата
            последнего обновления: 18 апреля 2024 года.
          </p>
        </div>
      </div>
    </section>
  );
};

export default PrivacyPage;