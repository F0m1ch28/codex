const casinos = [
  {
    id: 1,
    name: 'Casino X',
    slug: 'casino-x',
    description:
      'Casino X — международная площадка для азартных игроков, которая сочетает продуманную бонусную программу, прозрачную систему выплат и огромный каталог из более чем двух тысяч игр от ведущих студий.',
    bonus: '100% до 5000 RUB + 100 фриспинов',
    license: 'Curacao eGaming',
    gamesCount: '2300+',
    minDeposit: '500 RUB',
    payoutSpeed: '24-48 часов',
    paymentMethods: ['Visa', 'Mastercard', 'Skrill', 'Neteller', 'Bitcoin'],
    rating: 4.6,
    volatility: 'Средняя',
    image: 'https://images.unsplash.com/photo-1520694478166-daaaaec95b69?auto=format&fit=crop&w=1200&q=80',
    pros: [
      'Щедрый приветственный бонус на депозит и фриспины',
      'Быстрая верификация аккаунта и поддержка 24/7 на русском языке',
      'Широкий выбор live-игр с профессиональными дилерами'
    ],
    cons: [
      'Отсутствует отдельное приложение для iOS',
      'Абонентская комиссия при выводе на некоторые электронные кошельки',
      'Высокие требования к отыгрышу бонуса (x35)'
    ],
    games: ['Видеослоты', 'Live-казино', 'Рулетка', 'Блэкджек', 'Турниры'],
    bonusTerms:
      'Приветственный бонус активируется при минимальном депозите 500 RUB, отыгрыш x35, фриспины предоставляются партиями по 20 штук в течение пяти дней.',
    supportChannels: ['Live-chat', 'Email', 'Telegram-бот'],
    userScore: {
      average: 4.5,
      votes: 327
    },
    reviewDate: '2024-03-18'
  },
  {
    id: 2,
    name: 'Lucky Spins',
    slug: 'lucky-spins',
    description:
      'Lucky Spins делает упор на курацию слотов с высоким RTP, прозрачные условия по отыгрышу бонусов и удобные инструменты управления банкроллом для ответственной игры.',
    bonus: '100% до 5000 RUB + 100 фриспинов',
    license: 'Malta Gaming Authority',
    gamesCount: '3100+',
    minDeposit: '1000 RUB',
    payoutSpeed: '12-36 часов',
    paymentMethods: ['Visa', 'Mastercard', 'Skrill', 'Neteller', 'Bitcoin'],
    rating: 4.8,
    volatility: 'Низкая',
    image: 'https://images.unsplash.com/photo-1504274066651-8d31a536b11a?auto=format&fit=crop&w=1200&q=80',
    pros: [
      'Лицензия MGA и сертифицированные генераторы случайных чисел',
      'Подробный раздел ответственной игры и гибкие лимиты',
      'Еженедельные турниры и программа лояльности с кешбэком'
    ],
    cons: [
      'Нет поддержки телефонной линии',
      'Некоторые провайдеры скрыты для определённых регионов',
      'Максимальный вывод ограничен 400 000 RUB в месяц'
    ],
    games: ['Слоты', 'Live-шоу', 'Видео-покер', 'Крэпс', 'Кено'],
    bonusTerms:
      'Бонус активируется на первом депозите, отыгрыш x30, фриспины на автомат Star Odyssey, максимальная ставка при отыгрыше 400 RUB.',
    supportChannels: ['Live-chat', 'Email'],
    userScore: {
      average: 4.7,
      votes: 412
    },
    reviewDate: '2024-02-28'
  },
  {
    id: 3,
    name: 'MegaWin',
    slug: 'megawin',
    description:
      'MegaWin предлагает игрокам высокие лимиты на вывод, продвинутую VIP-программу и разнообразные криптовалютные методы оплаты, сохраняя строгие стандарты честной игры.',
    bonus: '100% до 5000 RUB + 100 фриспинов',
    license: 'Curacao eGaming',
    gamesCount: '2800+',
    minDeposit: '500 RUB',
    payoutSpeed: 'до 24 часов',
    paymentMethods: ['Visa', 'Mastercard', 'Skrill', 'Neteller', 'Bitcoin'],
    rating: 4.5,
    volatility: 'Высокая',
    image: 'https://images.unsplash.com/photo-1506354666786-959d6d497f1a?auto=format&fit=crop&w=1200&q=80',
    pros: [
      'Мгновенные депозиты и быстрые выплаты на криптокошельки',
      'VIP-программа с персональными менеджерами и эксклюзивными бонусами',
      'Регулярные серификации слотов независимыми аудиторами'
    ],
    cons: [
      'Интерфейс переведён не полностью, часть разделов на английском',
      'Минимальная сумма вывода с банковских карт — 2000 RUB',
      'Нет бездепозитных бонусов для новых игроков'
    ],
    games: ['Слоты', 'Прогрессивные джекпоты', 'Live-игры', 'Баккара', 'Лотереи'],
    bonusTerms:
      'Бонус доступен новым игрокам, необходимо отыграть x40 в течение 14 дней. Фриспины по 25 штук ежедневно на четыре различных слота.',
    supportChannels: ['Live-chat', 'Email', 'VIP-консьерж'],
    userScore: {
      average: 4.4,
      votes: 289
    },
    reviewDate: '2024-03-05'
  }
];

export default casinos;