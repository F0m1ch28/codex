import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'gambleReviewCookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Мы используем cookies для улучшения аналитики и работы сайта. Продолжая пользоваться ресурсом, вы соглашаетесь с{' '}
          <Link to="/cookie-policy">Политикой cookies</Link>.
        </p>
      </div>
      <button type="button" className={`${styles.button} btn btnPrimary`} onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;