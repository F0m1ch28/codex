import React from 'react';
import { Link } from 'react-router-dom';
import styles from './HeroSection.module.css';

const HeroSection = () => {
  return (
    <section className={styles.hero}>
      <div className={`${styles.overlay}`} />
      <div className={`${styles.inner} container`}>
        <div className={styles.content}>
          <span className="badge fadeInUp" aria-label="Ответственная аналитика казино">
            Премиальная аналитика казино
          </span>
          <h1 className={`${styles.title} fadeInUp`}>
            Честные обзоры казино и сравнение бонусов без иллюзий и скрытых условий
          </h1>
          <p className="fadeInUp">
            GambleReview помогает выбирать только лицензированные площадки. Мы проверяем бонусы, скорость выплат и
            инструменты ответственной игры, чтобы вы принимали взвешенные решения.
          </p>
          <div className={`${styles.actions} fadeInUp`}>
            <Link to="/casino" className="btn btnPrimary">
              Смотреть рейтинги
            </Link>
            <Link to="/compare" className="btn btnSecondary">
              Сравнить условия
            </Link>
          </div>
        </div>
        <div className={`${styles.statsCard} fadeInUp`} aria-hidden="true">
          <div>
            <strong>24/7</strong>
            <span>Верификация данных</span>
          </div>
          <div>
            <strong>3</strong>
            <span>Тестируемые лицензии</span>
          </div>
          <div>
            <strong>100%</strong>
            <span>Реальные отзывы</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;