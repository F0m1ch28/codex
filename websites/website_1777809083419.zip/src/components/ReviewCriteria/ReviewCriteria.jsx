import React from 'react';
import styles from './ReviewCriteria.module.css';

const ReviewCriteria = ({ criteria }) => {
  return (
    <div className={styles.grid}>
      {criteria.map((item) => (
        <article key={item.title} className={`${styles.item} card`}>
          <div className={styles.icon} aria-hidden="true">
            {item.icon}
          </div>
          <h3>{item.title}</h3>
          <p>{item.description}</p>
        </article>
      ))}
    </div>
  );
};

export default ReviewCriteria;