import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { to: '/casino', label: 'Обзор казино' },
    { to: '/compare', label: 'Сравнение бонусов' },
    { to: '/services', label: 'Экспертные услуги' },
    { to: '/about', label: 'О проекте' }
  ];

  const legalLinks = [
    { to: '/terms', label: 'Terms & Conditions' },
    { to: '/privacy', label: 'Политика конфиденциальности' },
    { to: '/cookie-policy', label: 'Cookie Policy' }
  ];

  const resources = [
    { label: 'Рейтинг казино 2024', to: '/casino' },
    { label: 'Гид по ответственной игре', to: '/services' },
    { label: 'FAQ по бонусам', to: '/contact#faq' }
  ];

  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`${styles.top} container`}>
        <div className={styles.brand}>
          <Link to="/" className={styles.logo}>
            <span>Gamble</span>Review
          </Link>
          <p>
            Экспертные обзоры международных казино, основанные на фактических данных, аудите лицензий и опыте нашей
            аналитической команды. Мы сравниваем условия честно и без призывов к азартной игре.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h4>Навигация</h4>
            <ul>
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <Link to={link.to}>{link.label}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4>Документы</h4>
            <ul>
              {legalLinks.map((link) => (
                <li key={link.to}>
                  <Link to={link.to}>{link.label}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4>Ресурсы</h4>
            <ul>
              {resources.map((item) => (
                <li key={item.to}>
                  <Link to={item.to}>{item.label}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4>Контакты</h4>
            <ul className={styles.contactList}>
              <li>
                Email:{' '}
                <a href="mailto:info@gamblereview.com" rel="noopener noreferrer">
                  info@gamblereview.com
                </a>
              </li>
              <li>Работаем ежедневно: 10:00 — 22:00 (UTC+3)</li>
              <li>Ответственная игра: 18+</li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className="container">
          <p>© {currentYear} GambleReview. Все права защищены. Без призывов к азартным играм.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;