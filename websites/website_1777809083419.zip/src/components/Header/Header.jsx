import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigation = [
    { to: '/', label: 'Главная' },
    { to: '/casino', label: 'Все казино' },
    { to: '/compare', label: 'Сравнение' },
    { to: '/services', label: 'Услуги' },
    { to: '/about', label: 'О проекте' },
    { to: '/contact', label: 'Контакты' }
  ];

  const handleToggleMenu = () => {
    setIsMobileMenuOpen((prev) => !prev);
  };

  const handleLinkClick = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={`${styles.inner} container`}>
        <Link to="/" className={styles.logo} aria-label="GambleReview — главная">
          <span className={styles.logoAccent}>Gamble</span>Review
        </Link>
        <nav className={`${styles.nav} ${isMobileMenuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          {navigation.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `${styles.navLink} ${isActive ? styles.activeLink : ''}`}
              onClick={handleLinkClick}
            >
              {item.label}
            </NavLink>
          ))}
          <div className={styles.navCta}>
            <NavLink to="/compare" className={styles.compareLink} onClick={handleLinkClick}>
              Список сравнения
            </NavLink>
          </div>
        </nav>
        <button
          type="button"
          className={styles.menuButton}
          aria-label={isMobileMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={isMobileMenuOpen}
          onClick={handleToggleMenu}
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
        </button>
      </div>
    </header>
  );
};

export default Header;