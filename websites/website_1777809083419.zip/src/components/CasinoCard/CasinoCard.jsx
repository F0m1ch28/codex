import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CasinoCard.module.css';

const CasinoCard = ({ casino, onToggleCompare, isSelected }) => {
  return (
    <article className={`${styles.card} card`} aria-label={`Обзор ${casino.name}`}>
      <div className={styles.header}>
        <div className={styles.badge}>Лицензия: {casino.license}</div>
        <span className={styles.rating} aria-label={`Рейтинг пользователей ${casino.rating} из 5`}>
          ★ {casino.rating.toFixed(1)}
        </span>
      </div>
      <div className={styles.body}>
        <h3 className={styles.title}>{casino.name}</h3>
        <p className={styles.description}>{casino.description}</p>
        <div className={styles.bonus}>
          <span>Приветственный бонус</span>
          <strong>{casino.bonus}</strong>
        </div>
        <div className={styles.meta}>
          <div>
            <span>Игры</span>
            <strong>{casino.gamesCount}</strong>
          </div>
          <div>
            <span>Мин. депозит</span>
            <strong>{casino.minDeposit}</strong>
          </div>
          <div>
            <span>Скорость вывода</span>
            <strong>{casino.payoutSpeed}</strong>
          </div>
        </div>
      </div>
      <div className={styles.actions}>
        <Link to={`/casino/${casino.slug}`} className="btn btnSecondary">
          Подробнее
        </Link>
        <button
          type="button"
          onClick={() => onToggleCompare(casino.slug)}
          className={`btn ${isSelected ? styles.activeCompare : 'btnPrimary'}`}
        >
          {isSelected ? 'В сравнении' : 'Добавить в сравнение'}
        </button>
      </div>
    </article>
  );
};

export default CasinoCard;