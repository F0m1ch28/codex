import React from 'react';
import styles from './CompareTable.module.css';

const CompareTable = ({ casinos, onRemove }) => {
  return (
    <div className={styles.wrapper}>
      <table className="table" aria-label="Таблица сравнения казино">
        <thead>
          <tr>
            <th>Казино</th>
            <th>Бонус</th>
            <th>Лицензия</th>
            <th>Количество игр</th>
            <th>Мин. депозит</th>
            <th>Рейтинг</th>
            <th aria-label="Действия">Действия</th>
          </tr>
        </thead>
        <tbody>
          {casinos.map((casino) => (
            <tr key={casino.slug}>
              <td>
                <div className={styles.nameCell}>
                  <img src={casino.image} alt={`Превью ${casino.name}`} />
                  <div>
                    <strong>{casino.name}</strong>
                    <span>{casino.payoutSpeed}</span>
                  </div>
                </div>
              </td>
              <td>{casino.bonus}</td>
              <td>{casino.license}</td>
              <td>{casino.gamesCount}</td>
              <td>{casino.minDeposit}</td>
              <td>
                <span className="accentText">★ {casino.rating.toFixed(1)}</span>
              </td>
              <td>
                <button type="button" className={styles.remove} onClick={() => onRemove(casino.slug)}>
                  Удалить
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CompareTable;