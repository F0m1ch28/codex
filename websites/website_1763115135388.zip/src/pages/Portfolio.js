import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Portfolio.module.css';

const portfolioItems = [
  {
    title: 'Omnichannel Commerce Platform',
    category: 'Web Development',
    description:
      'Unified digital storefront across mobile and desktop with composable micro frontends, centralised inventory, and personalisation driven by real-time analytics.',
    technologies: 'React · Next.js · Node.js · Snowflake',
    image: 'https://picsum.photos/1000/700?random=41'
  },
  {
    title: 'Smart Logistics Control Tower',
    category: 'Cloud Solutions',
    description:
      'AWS-based telemetry and automation framework delivering predictive routing, IoT integration, and a control plane for fleet managers.',
    technologies: 'AWS · Lambda · DynamoDB · IoT Core',
    image: 'https://picsum.photos/1000/700?random=42'
  },
  {
    title: 'Digital Patient Services Portal',
    category: 'Software Engineering',
    description:
      'Accessible patient engagement platform integrated with NHS Spine, enabling secure messaging, scheduling, and remote monitoring dashboards.',
    technologies: 'Azure · React · .NET · Azure AD B2C',
    image: 'https://picsum.photos/1000/700?random=43'
  },
  {
    title: 'Financial Compliance Automation',
    category: 'Digital Transformation',
    description:
      'Automated compliance checks, audit-ready documentation, and workflow management reducing manual effort across regulated processes.',
    technologies: 'Node.js · GraphQL · Power Automate',
    image: 'https://picsum.photos/1000/700?random=44'
  },
  {
    title: 'Public Services Accessibility Hub',
    category: 'Web Development',
    description:
      'WCAG-compliant service hub consolidating multiple citizen services with guided flows and content personalisation.',
    technologies: 'Next.js · GOV.UK Design System · Azure',
    image: 'https://picsum.photos/1000/700?random=45'
  },
  {
    title: 'Manufacturing Analytics Platform',
    category: 'Cloud Solutions',
    description:
      'Real-time production monitoring leveraging GCP data pipelines, ML forecasting, and responsive dashboards for plant operators.',
    technologies: 'GCP · BigQuery · Cloud Run · Looker',
    image: 'https://picsum.photos/1000/700?random=46'
  }
];

const filters = ['All', 'Web Development', 'Cloud Solutions', 'Software Engineering', 'Digital Transformation'];

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState('All');

  const filteredProjects =
    activeFilter === 'All'
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === activeFilter);

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Portfolio | AnimalQDKT Tech Solutions Projects &amp; Case Studies</title>
        <meta
          name="description"
          content="Explore AnimalQDKT Tech Solutions portfolio including web development, cloud solutions, software engineering, and digital transformation projects delivered across the UK."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Case studies and delivery highlights</h1>
        <p>
          Each project is shaped by close collaboration, system thinking, and measurable results. Browse a selection of programmes showcasing our impact across industries.
        </p>
      </section>

      <section className={styles.filters} aria-label="Project categories">
        {filters.map((filter) => (
          <button
            key={filter}
            type="button"
            className={`${styles.filterButton} ${activeFilter === filter ? styles.activeFilter : ''}`}
            onClick={() => setActiveFilter(filter)}
            aria-pressed={activeFilter === filter}
          >
            {filter}
          </button>
        ))}
      </section>

      <section className={styles.grid} aria-live="polite">
        {filteredProjects.map((item) => (
          <article key={item.title} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={item.image} alt={`${item.title} preview`} loading="lazy" />
              <span className={styles.category}>{item.category}</span>
            </div>
            <div className={styles.cardContent}>
              <h2>{item.title}</h2>
              <p>{item.description}</p>
              <strong>{item.technologies}</strong>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Portfolio;