import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Services | AnimalQDKT Tech Solutions | Cloud, Web, Software Engineering</title>
        <meta
          name="description"
          content="Discover the full range of IT services from AnimalQDKT Tech Solutions, including web development, cloud solutions, software engineering, and digital transformation consulting."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Advisory, design, and engineering services shaped for evolving businesses</h1>
        <p>
          Our specialists deliver end-to-end programmes for organisations across finance, healthcare, public sector, and ambitious startups. We blend strategy, product thinking, and scalable engineering to help you modernise with confidence.
        </p>
      </section>

      <section className={styles.serviceSection} id="web">
        <div className={styles.serviceCard}>
          <div className={styles.serviceHeader}>
            <span className={styles.serviceBadge}>Web Development</span>
            <h2>React-driven interfaces and modular platforms</h2>
          </div>
          <div className={styles.serviceContent}>
            <p>
              Craft responsive applications with React, Next.js, and TypeScript. We implement component libraries, design systems, and performance optimisation to deliver consistent experiences across every device.
            </p>
            <ul>
              <li>Progressive web applications with offline support</li>
              <li>Headless CMS integrations (Contentful, Sanity, Strapi)</li>
              <li>Accessibility audits and inclusive experience design</li>
              <li>Analytics and experimentation instrumentation</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.serviceSection} id="cloud">
        <div className={styles.serviceCard}>
          <div className={styles.serviceHeader}>
            <span className={styles.serviceBadge}>Cloud Solutions</span>
            <h2>Cloud-native architecture, migration, and optimisation</h2>
          </div>
          <div className={styles.serviceContent}>
            <p>
              Accelerate your cloud journey with certified architects across AWS, Azure, and Google Cloud. We design secure, observable, and cost-aware environments aligned with your compliance obligations.
            </p>
            <ul>
              <li>Cloud migration journeys with zero unplanned downtime</li>
              <li>Infrastructure as code with Terraform, Pulumi, and Bicep</li>
              <li>Hybrid and multi-cloud networking and governance</li>
              <li>Observability stacks with Prometheus, Grafana, Datadog</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.serviceSection} id="software">
        <div className={styles.serviceCard}>
          <div className={styles.serviceHeader}>
            <span className={styles.serviceBadge}>Software Engineering</span>
            <h2>Custom product engineering and API ecosystems</h2>
          </div>
          <div className={styles.serviceContent}>
            <p>
              Build resilient platforms that integrate with your existing systems. From event-driven microservices to bespoke internal tooling, we create modular architectures with automated testing and security baked in.
            </p>
            <ul>
              <li>Domain-driven design and architecture workshops</li>
              <li>API integration, GraphQL, event streaming, and messaging</li>
              <li>Secure authentication, authorisation, and data privacy controls</li>
              <li>Continuous delivery pipelines with automated testing</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.serviceSection} id="transformation">
        <div className={styles.serviceCard}>
          <div className={styles.serviceHeader}>
            <span className={styles.serviceBadge}>Digital Transformation</span>
            <h2>Strategic consulting and capability uplift</h2>
          </div>
          <div className={styles.serviceContent}>
            <p>
              We help leadership teams prioritise initiatives, modernise operations, and instil practices that foster innovation. Our consultants align technology, processes, and people with your service vision.
            </p>
            <ul>
              <li>Technology roadmaps and value stream mapping</li>
              <li>Product discovery workshops and service blueprinting</li>
              <li>DevOps culture enablement and coaching</li>
              <li>Cybersecurity posture assessments and remediation plans</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.capabilities} aria-labelledby="capabilities-heading">
        <div className={styles.sectionHeader}>
          <h2 id="capabilities-heading">Key capabilities across our engagements</h2>
          <p>
            We draw from proven playbooks and adapt them to the specifics of your teams and infrastructure.
          </p>
        </div>
        <div className={styles.capabilityGrid}>
          <article>
            <h3>Discovery &amp; Research</h3>
            <p>
              User and stakeholder interviews, service mapping, and data analysis uncover the opportunities that inform every recommendation.
            </p>
          </article>
          <article>
            <h3>Product Delivery</h3>
            <p>
              Multi-disciplinary squads execute agile sprints with continuous feedback loops and transparent reporting.
            </p>
          </article>
          <article>
            <h3>DevOps Services</h3>
            <p>
              CI/CD pipelines, automated testing, and infrastructure automation that accelerate releases and reduce manual effort.
            </p>
          </article>
          <article>
            <h3>Cybersecurity</h3>
            <p>
              Security by design, threat modelling, vulnerability management, and compliance support for regulated environments.
            </p>
          </article>
          <article>
            <h3>Data &amp; Analytics</h3>
            <p>
              Data platform design, dashboards, machine learning pipelines, and data governance frameworks.
            </p>
          </article>
          <article>
            <h3>Change Management</h3>
            <p>
              Training, documentation, and communities of practice that embed new skills across teams.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Services;