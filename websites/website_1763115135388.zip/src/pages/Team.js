import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Team.module.css';

const teamMembers = [
  {
    name: 'Amelia Grant',
    role: 'Founder & Chief Technology Strategist',
    bio: 'Guides enterprise architecture and digital transformation programmes across finance and public sector clients for over 15 years.',
    certifications: ['AWS Solutions Architect Professional', 'Scrum Master', 'ISO 27001 Lead Implementer'],
    image: 'https://picsum.photos/400/400?random=51'
  },
  {
    name: 'Marcus Ellis',
    role: 'Head of Engineering',
    bio: 'Leads multi-disciplinary squads delivering React, Node.js, and cloud-native solutions with rigorous automation.',
    certifications: ['Microsoft Certified Azure Architect', 'Certified Kubernetes Administrator'],
    image: 'https://picsum.photos/400/400?random=52'
  },
  {
    name: 'Priya Shah',
    role: 'Principal Cloud Architect',
    bio: 'Designs hybrid cloud ecosystems, migration strategies, and governance frameworks that keep organisations future-ready.',
    certifications: ['Google Cloud Professional Cloud Architect', 'TOGAF 9'],
    image: 'https://picsum.photos/400/400?random=53'
  },
  {
    name: 'Leo Mitchell',
    role: 'Lead UX & Service Designer',
    bio: 'Transforms insight into inclusive digital services, leading research and design operations for cross-functional teams.',
    certifications: ['Certified UX Professional', 'DesignOps Specialist'],
    image: 'https://picsum.photos/400/400?random=54'
  },
  {
    name: 'Hannah Clarke',
    role: 'DevOps & Reliability Lead',
    bio: 'Brings automation, observability, and reliability engineering to critical platforms serving millions of users.',
    certifications: ['HashiCorp Terraform Associate', 'AWS DevOps Engineer Professional'],
    image: 'https://picsum.photos/400/400?random=55'
  },
  {
    name: 'Elliot Moore',
    role: 'Cybersecurity Consultant',
    bio: 'Delivers security risk assessments, secure coding practices, and governance frameworks for highly regulated businesses.',
    certifications: ['CISSP', 'Certified Ethical Hacker', 'UK Cyber Essentials Practitioner'],
    image: 'https://picsum.photos/400/400?random=56'
  }
];

const Team = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Team | AnimalQDKT Tech Solutions | London IT Experts</title>
        <meta
          name="description"
          content="Meet the AnimalQDKT Tech Solutions team: London-based experts in software engineering, cloud architecture, DevOps services, cybersecurity, digital transformation, and design."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.eyebrow}>Our people</p>
          <h1>Meet the minds behind AnimalQDKT Tech Solutions</h1>
          <p>
            Diverse perspectives and deep expertise drive every engagement. We invest in our team’s growth and foster a collaborative culture grounded in empathy, precision, and curiosity.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1200/800?random=57"
            alt="AnimalQDKT team discussing architecture diagrams"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.grid} aria-label="Team members">
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.card}>
            <div className={styles.photo}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
            </div>
            <div className={styles.cardContent}>
              <h2>{member.name}</h2>
              <p className={styles.role}>{member.role}</p>
              <p className={styles.bio}>{member.bio}</p>
              <ul className={styles.certifications}>
                {member.certifications.map((cert) => (
                  <li key={cert}>{cert}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.statement}>
        <h2>Careers at AnimalQDKT</h2>
        <p>
          We continually seek engineers, designers, and consultants who value craft and collaboration. If you enjoy solving complex technology challenges and delivering measurable impact for UK organisations, we would love to talk.
        </p>
        <a href="mailto:careers@animalqdktsolutions.co.uk" className={styles.cta}>
          Connect with our talent team
        </a>
      </section>
    </div>
  );
};

export default Team;