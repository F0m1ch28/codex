import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Privacy Policy | AnimalQDKT Tech Solutions</title>
      <meta
        name="description"
        content="Read the GDPR-compliant Privacy Policy of AnimalQDKT Tech Solutions to understand how we collect, use, and protect your personal data."
      />
    </Helmet>
    <article className={styles.article}>
      <h1>Privacy Policy</h1>
      <p className={styles.updated}>Last updated: March 2024</p>

      <h2>1. Purpose</h2>
      <p>
        AnimalQDKT Tech Solutions respects your privacy and is committed to protecting your personal data. This policy explains how we handle personal information collected through our website and during our services, in line with the UK GDPR and the Data Protection Act 2018.
      </p>

      <h2>2. Data we collect</h2>
      <p>
        We may collect personal data such as your name, job title, organisation, email address, phone number, and any details you provide in enquiries or project briefs. We also gather technical information through cookies and analytics to enhance our services.
      </p>

      <h2>3. How we use your data</h2>
      <ul>
        <li>Responding to enquiries and providing requested information.</li>
        <li>Delivering and managing our services and projects.</li>
        <li>Improving our website, services, and communication.</li>
        <li>Complying with legal obligations and industry standards.</li>
      </ul>

      <h2>4. Data sharing</h2>
      <p>
        We do not sell personal data. We may share information with trusted partners and service providers who support our operations, under strict confidentiality agreements. Data may also be disclosed when required by law.
      </p>

      <h2>5. International transfers</h2>
      <p>
        If we transfer personal data outside the UK, we ensure appropriate safeguards are in place, such as standard contractual clauses or adequacy decisions.
      </p>

      <h2>6. Data retention</h2>
      <p>
        Personal data is retained only for as long as necessary to fulfil the purposes outlined in this policy or to comply with legal obligations. We regularly review retention periods to ensure data is not kept longer than needed.
      </p>

      <h2>7. Your rights</h2>
      <p>
        You have the right to request access, rectification, erasure, restriction, or portability of your personal data. You can also object to processing where we rely on legitimate interests. Please contact us to exercise these rights.
      </p>

      <h2>8. Cookies</h2>
      <p>
        We use essential cookies and analytics cookies to improve the performance of our site. You can manage your preferences via the cookie banner or browser settings. For full details, please review our Cookie Policy.
      </p>

      <h2>9. Contact</h2>
      <p>
        For any privacy-related questions or to make a request, contact our Data Protection Officer at{' '}
        <a href="mailto:privacy@animalqdktsolutions.co.uk">privacy@animalqdktsolutions.co.uk</a>.
      </p>
    </article>
  </div>
);

export default Privacy;