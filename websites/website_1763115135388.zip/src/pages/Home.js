import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Enterprise launches', value: 120 },
  { label: 'Cloud migrations', value: 85 },
  { label: 'APIs integrated', value: 340 },
  { label: 'Security workshops', value: 56 }
];

const services = [
  {
    title: 'Full-Stack Development',
    description:
      'Design and engineering of responsive platforms powered by React, Node.js, and TypeScript with reliable CI/CD pipelines.',
    icon: '🧭'
  },
  {
    title: 'Cloud Architecture',
    description:
      'Migration and optimisation across AWS, Azure, and Google Cloud with resilient infrastructure-as-code patterns.',
    icon: '☁️'
  },
  {
    title: 'Software Engineering',
    description:
      'Robust modular systems, event-driven integrations, and automation tailored for mission-critical environments.',
    icon: '🛠️'
  },
  {
    title: 'Digital Transformation',
    description:
      'Strategic consulting that aligns product roadmaps, service design, and governance with measurable business impact.',
    icon: '🚀'
  }
];

const processSteps = [
  {
    title: 'Discovery & Insight',
    description:
      'Stakeholder interviews, domain analysis, and requirements mapping to create a precise blueprint.',
    number: '01'
  },
  {
    title: 'Experience Design',
    description:
      'Wireframes, service journeys, and UI libraries that unite accessibility, brand, and user expectations.',
    number: '02'
  },
  {
    title: 'Engineering Sprints',
    description:
      'Agile delivery with automated testing, secure deployments, and transparent reporting every sprint.',
    number: '03'
  },
  {
    title: 'Scale & Support',
    description:
      'Continuous optimisation, observability enhancements, and data-backed improvements post-launch.',
    number: '04'
  }
];

const testimonials = [
  {
    quote:
      'AnimalQDKT orchestrated our cloud migration without disrupting operations. Their attention to detail and governance expertise changed our delivery velocity.',
    name: 'Clara Matthews',
    role: 'CTO, Northbridge Logistics'
  },
  {
    quote:
      'The team delivered a modular API platform that our partners adopted in record time. Communication was proactive and technical decisions were data-driven.',
    name: 'James O’Connor',
    role: 'Digital Director, Horizon Retail'
  },
  {
    quote:
      'Their DevOps specialists transformed our release pipeline into a predictable, secure workflow that our engineering team now relies on every day.',
    name: 'Sophie Ahmed',
    role: 'Head of Engineering, Lumen Healthcare'
  }
];

const faqs = [
  {
    question: 'How do you tailor solutions for UK-based organisations?',
    answer:
      'We align delivery with regional compliance requirements, industry benchmarks, and the operational realities of UK teams. Each engagement begins with careful discovery to define the roadmap, success metrics, and stakeholder expectations.'
  },
  {
    question: 'Can you support hybrid cloud environments?',
    answer:
      'Absolutely. We frequently orchestrate hybrid and multi-cloud deployments, ensuring secure connectivity, cost observability, and consistent monitoring across platforms.'
  },
  {
    question: 'What technologies underpin your delivery teams?',
    answer:
      'Depending on project context, we work with React, Next.js, Node.js, NestJS, Python, .NET, Terraform, Kubernetes, and a wide spectrum of automation and security tooling.'
  },
  {
    question: 'Do you provide ongoing optimisation after launch?',
    answer:
      'Yes. Our continuous improvement services include observability dashboards, backlog grooming, A/B testing, and periodic resilience audits.'
  }
];

const blogPosts = [
  {
    title: 'Building Composable Digital Platforms for Financial Services',
    excerpt:
      'Discover how modular architectures, reusable design systems, and API-first thinking support rapid innovation in regulated finance environments.',
    date: 'April 3, 2024',
    image: 'https://picsum.photos/800/600?random=12'
  },
  {
    title: 'Navigating Cloud Migration with Zero Downtime Strategies',
    excerpt:
      'Key practices and automation patterns we deploy to migrate workloads to the cloud while maintaining service continuity and governance.',
    date: 'March 12, 2024',
    image: 'https://picsum.photos/800/600?random=13'
  },
  {
    title: 'Embedding Security Into Engineering Sprints',
    excerpt:
      'An approach to collaborative threat modelling, automated testing, and secure code reviews that keeps teams shipping confidently.',
    date: 'February 26, 2024',
    image: 'https://picsum.photos/800/600?random=14'
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [animatedValues, setAnimatedValues] = useState(statsData.map(() => 0));
  const [openFAQ, setOpenFAQ] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timers = statsData.map((stat, index) => {
      let start = 0;
      const increment = Math.ceil(stat.value / 60);
      return setInterval(() => {
        start += increment;
        setAnimatedValues((prev) => {
          const updated = [...prev];
          updated[index] = start >= stat.value ? stat.value : start;
          return updated;
        });
        if (start >= stat.value) {
          clearInterval(timers[index]);
        }
      }, 35);
    });
    return () => timers.forEach((timer) => clearInterval(timer));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleFAQ = (index) => {
    setOpenFAQ((prev) => (prev === index ? -1 : index));
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>AnimalQDKT Tech Solutions | IT Services UK &amp; Cloud Engineering</title>
        <meta
          name="description"
          content="AnimalQDKT Tech Solutions delivers IT services in the UK with expertise in web development, cloud solutions, software engineering, custom software development, digital transformation, DevOps services, and cybersecurity."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className={styles.heroContent}>
          <p className={styles.heroEyebrow}>IT Services UK · London Engineering Studio</p>
          <h1 id="hero-heading">
            Engineering Your Digital Future
          </h1>
          <p className={styles.heroSubtitle}>
            We architect cloud-native products, data-ready platforms, and accessible experiences. Partner with a multi-disciplinary team that understands mission-critical delivery and the pace of modern business.
          </p>
          <div className={styles.heroActions}>
            <NavLink to="/contact" className={styles.primaryAction}>
              Plan a Discovery Call
            </NavLink>
            <NavLink to="/portfolio" className={styles.secondaryAction}>
              Explore our work
            </NavLink>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <div className={styles.heroGlass}>
            <img
              src="https://picsum.photos/1600/900?random=101"
              alt="Modern digital workspace with development team collaborating"
            />
          </div>
          <div className={styles.heroBadge}>
            <span>Trusted delivery partner</span>
            <strong>Across finance, healthcare, and public sector</strong>
          </div>
        </div>
      </section>

      <section className={styles.intro} aria-labelledby="intro-heading">
        <div className={styles.introContent}>
          <h2 id="intro-heading">AnimalQDKT Tech Solutions in Brief</h2>
          <p>
            Based in London, our studio unites senior engineers, service designers, and cloud architects to deliver measurable change. We specialise in complex integrations, data-driven experiences, and secure environments that scale with your organisation.
          </p>
          <p>
            From legacy modernisation to fresh product launches, we focus on clarity, empathy, and technical excellence. Our approach emphasises collaborative workshops, transparent delivery, and shared ownership of outcomes.
          </p>
        </div>
        <div className={styles.statsGrid} aria-label="Company achievements">
          {statsData.map((stat, index) => (
            <article key={stat.label} className={styles.statCard}>
              <h3>{animatedValues[index]}+</h3>
              <p>{stat.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.services} aria-labelledby="services-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionLabel}>What we deliver</p>
          <h2 id="services-heading">Our Services</h2>
          <p>
            Strategy, design, and engineering fused together to craft experiences your teams and customers rely on every day.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <NavLink to="/services" className={styles.serviceLink}>
                Learn more
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-heading">
        <div className={styles.sectionHeaderAlt}>
          <p className={styles.sectionLabel}>How we work</p>
          <h2 id="process-heading">A Proven Delivery Framework</h2>
          <p>
            AnimalQDKT brings together cross-functional squads that adopt a dependable rhythm and deliver tailored outcomes.
          </p>
        </div>
        <div className={styles.processTimeline}>
          {processSteps.map((step) => (
            <article key={step.number} className={styles.processStep}>
              <span className={styles.stepNumber}>{step.number}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.whyChoose} aria-labelledby="why-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionLabel}>Why choose us</p>
          <h2 id="why-heading">Forward-thinking partners for complex initiatives</h2>
          <p>
            Purpose-driven collaboration, engineering rigour, and a culture of measurable progress.
          </p>
        </div>
        <div className={styles.whyGrid}>
          <article className={styles.whyCard}>
            <h3>Integrated expertise</h3>
            <p>
              Senior specialists across strategy, design, engineering, and operations work as a single unit to accelerate delivery and keep stakeholders aligned.
            </p>
          </article>
          <article className={styles.whyCard}>
            <h3>Transparent delivery</h3>
            <p>
              Weekly showcases, open metrics dashboards, and collaborative roadmaps ensure clarity from kick-off to release.
            </p>
          </article>
          <article className={styles.whyCard}>
            <h3>Security-first mindset</h3>
            <p>
              Threat modelling, automated testing, and continuous compliance guardrails keep products resilient and trusted.
            </p>
          </article>
          <article className={styles.whyCard}>
            <h3>Human-centred outcomes</h3>
            <p>
              We pair evidence-based design with inclusive research to build experiences that empower internal teams and customers alike.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Client success stories">
        <div className={styles.testimonialGlass}>
          <div className={styles.testimonialContent}>
            <h2>Client Success Stories</h2>
            <p>
              We partner with leaders across finance, logistics, public sector, and healthcare. Their stories highlight the measurable progress we pursue together.
            </p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialSlide} ${index === activeTestimonial ? styles.activeSlide : ''}`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>&ldquo;{testimonial.quote}&rdquo;</p>
                <p className={styles.testimonialAuthor}>
                  {testimonial.name} · <span>{testimonial.role}</span>
                </p>
              </article>
            ))}
            <div className={styles.carouselDots} role="tablist">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                  aria-pressed={index === activeTestimonial}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projectsPreview} aria-labelledby="projects-heading">
        <div className={styles.projectsHeader}>
          <div>
            <p className={styles.sectionLabel}>Featured delivery</p>
            <h2 id="projects-heading">Selected Projects</h2>
          </div>
          <NavLink to="/portfolio" className={styles.projectsLink}>
            View all projects
          </NavLink>
        </div>
        <div className={styles.projectsGrid}>
          <article className={styles.projectCard}>
            <img
              src="https://picsum.photos/1200/800?random=21"
              alt="Dashboard visualisation for financial client"
              loading="lazy"
            />
            <div className={styles.projectContent}>
              <h3>Financial Intelligence Platform</h3>
              <p>
                Designed and engineered a regulatory-ready analytics suite with Azure-based data pipelines, role-based access, and unified reporting for 18 departments.
              </p>
              <span>Azure · React · PowerBI · Terraform</span>
            </div>
          </article>
          <article className={styles.projectCard}>
            <img
              src="https://picsum.photos/1200/800?random=22"
              alt="Healthcare team collaborating with digital tools"
              loading="lazy"
            />
            <div className={styles.projectContent}>
              <h3>Healthcare Telemetry Platform</h3>
              <p>
                Developed a secure patient monitoring solution with event-driven architecture and cross-platform apps ensuring resilience and clinician productivity.
              </p>
              <span>AWS · Node.js · GraphQL · Kubernetes</span>
            </div>
          </article>
          <article className={styles.projectCard}>
            <img
              src="https://picsum.photos/1200/800?random=23"
              alt="Modern workplace with cloud dashboards"
              loading="lazy"
            />
            <div className={styles.projectContent}>
              <h3>Public Sector Service Portal</h3>
              <p>
                Reimagined citizen services with inclusive design, WCAG 2.2 compliance, and scalable infrastructure that handles seasonal surges seamlessly.
              </p>
              <span>Next.js · Node.js · GOV.UK Design System</span>
            </div>
          </article>
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionLabel}>FAQ</p>
          <h2 id="faq-heading">Questions we solve daily</h2>
          <p>
            We are happy to adapt engagements to align with your teams, governance, and technology landscape.
          </p>
        </div>
        <div className={styles.faqList}>
          {faqs.map((faqItem, index) => (
            <article key={faqItem.question} className={styles.faqItem}>
              <button
                className={styles.faqTrigger}
                onClick={() => toggleFAQ(index)}
                aria-expanded={openFAQ === index}
              >
                <span>{faqItem.question}</span>
                <span aria-hidden="true" className={openFAQ === index ? styles.minus : styles.plus}>
                  {openFAQ === index ? '−' : '+'}
                </span>
              </button>
              <div
                className={`${styles.faqContent} ${openFAQ === index ? styles.faqOpen : ''}`}
                role="region"
              >
                <p>{faqItem.answer}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionLabel}>Latest insights</p>
          <h2 id="blog-heading">From our strategy desk</h2>
          <p>
            Fresh perspectives on web development in London, cloud solutions, DevOps services, cybersecurity, and digital transformation programmes.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={`${post.title} illustration`} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <p className={styles.blogDate}>{post.date}</p>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <NavLink to="/contact" className={styles.blogLink}>
                  Discuss this with us
                </NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-heading">
        <div className={styles.ctaGlass}>
          <div>
            <h2 id="cta-heading">Ready to accelerate your roadmap?</h2>
            <p>
              Let’s co-create a delivery strategy that blends user insight, scalable engineering, and dependable support from the first sprint.
            </p>
          </div>
          <NavLink to="/contact" className={styles.ctaButton}>
            Start your project
          </NavLink>
        </div>
      </section>
    </div>
  );
};

export default Home;