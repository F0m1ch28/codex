import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>About AnimalQDKT Tech Solutions | Technology Consultancy London</title>
        <meta
          name="description"
          content="Discover the history, mission, values, and technology expertise of AnimalQDKT Tech Solutions, an IT services company based in London delivering web development, cloud solutions, and digital transformation."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.eyebrow}>About AnimalQDKT Tech Solutions</p>
          <h1>Committed to resilient, human-centred technology</h1>
          <p>
            We guide businesses and public organisations through complex technology change. Our teams combine forward-thinking strategy, deep engineering experience, and a passion for sustainable delivery.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1000/700?random=31"
            alt="AnimalQDKT team collaborating in a modern London office"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.history} aria-labelledby="history-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionLabel}>Our story</p>
          <h2 id="history-heading">From boutique studio to trusted partner</h2>
        </div>
        <div className={styles.historyContent}>
          <p>
            AnimalQDKT Tech Solutions was founded in 2013 by engineers who had delivered large-scale programmes for finance and public sector clients. They observed that successful projects share three traits: collaborative teams, practical experimentation, and clear communication.
          </p>
          <p>
            We started as a boutique consultancy focused on modernising complex legacy estates. Today, we’ve grown into a multi-disciplinary team supporting clients across the UK. We continue to prioritise close partnerships, measurable outcomes, and continuous learning.
          </p>
        </div>
      </section>

      <section className={styles.mission} aria-labelledby="mission-heading">
        <div className={styles.missionCard}>
          <h2 id="mission-heading">Mission &amp; values</h2>
          <ul>
            <li>
              <strong>Integrity:</strong> We operate transparently and collaboratively, building lasting trust with every team we support.
            </li>
            <li>
              <strong>Excellence:</strong> Every deliverable meets rigorous standards across code quality, accessibility, security, and usability.
            </li>
            <li>
              <strong>Empathy:</strong> We listen first, understanding the context of users and internal teams before proposing technology solutions.
            </li>
            <li>
              <strong>Learning:</strong> Curiosity drives us. We invest in training, community engagement, and knowledge sharing.
            </li>
          </ul>
        </div>
        <div className={styles.valuesImage}>
          <img
            src="https://picsum.photos/900/700?random=32"
            alt="Team workshop with sticky notes and architecture diagrams"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.expertise} aria-labelledby="expertise-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionLabel}>Our expertise</p>
          <h2 id="expertise-heading">Cross-functional specialists delivering value at every stage</h2>
        </div>
        <div className={styles.expertiseGrid}>
          <article>
            <h3>Strategy &amp; Consulting</h3>
            <p>
              Technology roadmaps, service design, and digital transformation programmes grounded in measurable objectives and stakeholder alignment.
            </p>
          </article>
          <article>
            <h3>Product &amp; Experience Design</h3>
            <p>
              Research-led interaction design, inclusive user testing, and design systems that bring brand and accessibility together.
            </p>
          </article>
          <article>
            <h3>Engineering &amp; Integration</h3>
            <p>
              Cloud-native services, micro frontends, API integration, database solutions, and automation supporting rapid changes without friction.
            </p>
          </article>
          <article>
            <h3>Operations &amp; Reliability</h3>
            <p>
              DevOps services, observability, cloud cost optimisation, and proactive support that keeps platforms healthy and responsive.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.techStack} aria-labelledby="tech-stack-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionLabel}>Technology stack</p>
          <h2 id="tech-stack-heading">Platforms and tooling we rely on</h2>
          <p>
            Versatile across enterprise ecosystems, we assemble tooling that balances long-term maintainability with rapid iteration.
          </p>
        </div>
        <div className={styles.techGrid}>
          <div>
            <h3>Frontend</h3>
            <ul>
              <li>React, Next.js, TypeScript</li>
              <li>Storybook, Chakra UI, Tailwind CSS</li>
              <li>Accessibility testing suites (axe, Cypress)</li>
            </ul>
          </div>
          <div>
            <h3>Backend</h3>
            <ul>
              <li>Node.js, NestJS, .NET, Python</li>
              <li>Serverless on AWS Lambda &amp; Azure Functions</li>
              <li>API gateways, GraphQL, REST, gRPC</li>
            </ul>
          </div>
          <div>
            <h3>Cloud &amp; DevOps</h3>
            <ul>
              <li>AWS, Azure, Google Cloud</li>
              <li>Kubernetes, Docker, Terraform</li>
              <li>CI/CD with GitHub Actions, Azure DevOps, GitLab</li>
            </ul>
          </div>
          <div>
            <h3>Data &amp; Security</h3>
            <ul>
              <li>Snowflake, BigQuery, PostgreSQL, MongoDB</li>
              <li>Security scanning, SAST, DAST, threat modelling</li>
              <li>ISO 27001-aligned governance and documentation</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;