import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Cookie Policy | AnimalQDKT Tech Solutions</title>
      <meta
        name="description"
        content="Understand how AnimalQDKT Tech Solutions uses cookies, analytics, and tracking technologies on this website."
      />
    </Helmet>
    <article className={styles.article}>
      <h1>Cookie Policy</h1>
      <p className={styles.updated}>Last updated: March 2024</p>

      <h2>1. What are cookies?</h2>
      <p>
        Cookies are small text files stored on your device when you visit a website. They help enhance your browsing experience and provide aggregated analytics about site usage.
      </p>

      <h2>2. How we use cookies</h2>
      <ul>
        <li>
          <strong>Essential cookies:</strong> Required for the website to function correctly, such as maintaining session security and remembering your cookie preferences.
        </li>
        <li>
          <strong>Analytics cookies:</strong> Help us understand how visitors interact with our site so we can improve content and navigation.
        </li>
      </ul>

      <h2>3. Managing cookies</h2>
      <p>
        You can accept or decline non-essential cookies via our cookie banner. Most web browsers also allow you to control cookies through their settings. Blocking some cookies may impact your experience.
      </p>

      <h2>4. Third-party cookies</h2>
      <p>
        We may use third-party analytics providers. These partners may set cookies to deliver insights on website performance. We review third-party practices to ensure they meet privacy expectations.
      </p>

      <h2>5. Updates</h2>
      <p>
        We may update this Cookie Policy to reflect changes in technology or regulations. Any updates will be posted on this page with a revised date.
      </p>

      <h2>6. Contact</h2>
      <p>
        For questions about our use of cookies, please contact{' '}
        <a href="mailto:privacy@animalqdktsolutions.co.uk">privacy@animalqdktsolutions.co.uk</a>.
      </p>
    </article>
  </div>
);

export default CookiePolicy;