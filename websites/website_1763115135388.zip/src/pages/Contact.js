import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please add your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.message.trim()) newErrors.message = 'Tell us about your project or challenge.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    setSubmitted(true);
    setFormData({ name: '', company: '', email: '', message: '' });
    setErrors({});
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Contact AnimalQDKT Tech Solutions | London IT Services Partner</title>
        <meta
          name="description"
          content="Contact AnimalQDKT Tech Solutions for IT services in the UK including web development, cloud solutions, software engineering, DevOps services, and digital transformation."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Let’s shape your next digital milestone</h1>
          <p>
            Share your objectives, technology landscape, or current challenges. Our consultants will respond within one working day to plan an introductory conversation.
          </p>
          <div className={styles.contactDetails}>
            <p><strong>Address:</strong> 42 Tech Park Avenue, London, E14 5AB, United Kingdom</p>
            <p><strong>Telephone:</strong> <a href="tel:+442079460958">+44 20 7946 0958</a></p>
            <p><strong>Email:</strong> <a href="mailto:contact@animalqdktsolutions.co.uk">contact@animalqdktsolutions.co.uk</a></p>
          </div>
          <div className={styles.socials} aria-label="Social networks">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer">X</a>
            <a href="https://github.com" target="_blank" rel="noreferrer">GitHub</a>
          </div>
        </div>
        <div className={styles.heroMap}>
          <iframe
            title="AnimalQDKT Tech Solutions Office Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d19824.343756832137!2d-0.02355934537947627!3d51.508742532950534!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4876035198ff802f%3A0xcb3f5b34a2b90e6!2sCanary%20Wharf%2C%20London!5e0!3m2!1sen!2suk!4v1700000000000!5m2!1sen!2suk"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>

      <section className={styles.formSection}>
        <div className={styles.formCard}>
          <h2>Tell us about your project</h2>
          <p>
            We work with stakeholders across technology, operations, and product. Provide a summary and we’ll arrange a tailored follow-up.
          </p>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Full name *</label>
              <input
                type="text"
                id="name"
                name="name"
                autoComplete="name"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && <span id="name-error" className={styles.errorText}>{errors.name}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="company">Company or organisation</label>
              <input
                type="text"
                id="company"
                name="company"
                value={formData.company}
                onChange={handleChange}
                autoComplete="organization"
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="email">Work email *</label>
              <input
                type="email"
                id="email"
                name="email"
                autoComplete="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && <span id="email-error" className={styles.errorText}>{errors.email}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="message">Project goals *</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && <span id="message-error" className={styles.errorText}>{errors.message}</span>}
            </div>
            <div className={styles.formFooter}>
              <button type="submit">Submit enquiry</button>
              <p>
                By submitting the form you agree to our{' '}
                <a href="/privacy">Privacy Policy</a> and{' '}
                <a href="/terms">Terms of Use</a>.
              </p>
            </div>
            {submitted && (
              <div className={styles.successMessage} role="status">
                Thank you for reaching out. Our consultants will contact you shortly.
              </div>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;