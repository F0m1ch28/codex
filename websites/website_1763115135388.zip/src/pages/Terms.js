import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Terms of Use | AnimalQDKT Tech Solutions</title>
      <meta
        name="description"
        content="Review the Terms of Use governing the AnimalQDKT Tech Solutions website, services, and content."
      />
    </Helmet>
    <article className={styles.article}>
      <h1>Terms of Use</h1>
      <p className={styles.updated}>Last updated: March 2024</p>

      <h2>1. Introduction</h2>
      <p>
        Welcome to the AnimalQDKT Tech Solutions website. By accessing or using our website, you agree to be bound by these Terms of Use. If you do not agree with these terms, please refrain from using the site.
      </p>

      <h2>2. Use of the website</h2>
      <p>
        You may use this website for lawful purposes and in accordance with these terms. You are responsible for ensuring that all persons who access our site through your internet connection are aware of these terms and comply with them.
      </p>

      <h2>3. Intellectual property</h2>
      <p>
        All content, trademarks, and materials available on this website are the property of AnimalQDKT Tech Solutions or its licensors. You may not reproduce, distribute, or create derivative works without prior written consent.
      </p>

      <h2>4. Limitation of liability</h2>
      <p>
        We strive to provide accurate and up-to-date information, but we do not warrant that the content on the website is complete or error-free. AnimalQDKT Tech Solutions shall not be liable for any damages arising out of the use or inability to use this website.
      </p>

      <h2>5. External links</h2>
      <p>
        Our website may contain links to third-party websites. These links are provided for your convenience only. We do not control or endorse the content or policies of those websites and are not responsible for their practices.
      </p>

      <h2>6. Changes to these terms</h2>
      <p>
        We may revise these Terms of Use from time to time. Any changes will be posted on this page with an updated revision date. Your continued use of the website after the changes have been posted constitutes your acceptance of the updated terms.
      </p>

      <h2>7. Contact information</h2>
      <p>
        If you have any questions about these Terms of Use, please contact us at{' '}
        <a href="mailto:contact@animalqdktsolutions.co.uk">contact@animalqdktsolutions.co.uk</a>.
      </p>
    </article>
  </div>
);

export default Terms;