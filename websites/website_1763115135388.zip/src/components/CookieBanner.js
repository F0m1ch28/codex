import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('aq-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => {
        setVisible(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('aq-cookie-consent', 'accepted');
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem('aq-cookie-consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h4>Cookies &amp; Analytics</h4>
        <p>
          We use essential cookies to power secure experiences and aggregate analytics to refine our IT services. Manage your preferences at any time within our Cookie Policy.
        </p>
      </div>
      <div className={styles.actions}>
        <button onClick={acceptCookies} className={styles.primaryButton}>
          Accept
        </button>
        <button onClick={declineCookies} className={styles.secondaryButton}>
          Decline
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;