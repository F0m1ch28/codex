import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleToggle = () => setMenuOpen((prev) => !prev);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.container}>
        <div className={styles.logoArea}>
          <NavLink to="/" className={styles.logo} aria-label="AnimalQDKT Tech Solutions">
            Animal<span>QDKT</span>
          </NavLink>
          <button
            className={`${styles.menuButton} ${menuOpen ? styles.open : ''}`}
            onClick={handleToggle}
            aria-expanded={menuOpen}
            aria-controls="primary-navigation"
            aria-label="Toggle navigation menu"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Primary navigation"
        >
          <ul className={styles.navList}>
            <li>
              <NavLink to="/" end className={({ isActive }) => (isActive ? styles.activeLink : '')}>
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to="/about" className={({ isActive }) => (isActive ? styles.activeLink : '')}>
                About
              </NavLink>
            </li>
            <li>
              <NavLink to="/services" className={({ isActive }) => (isActive ? styles.activeLink : '')}>
                Services
              </NavLink>
            </li>
            <li>
              <NavLink to="/portfolio" className={({ isActive }) => (isActive ? styles.activeLink : '')}>
                Portfolio
              </NavLink>
            </li>
            <li>
              <NavLink to="/team" className={({ isActive }) => (isActive ? styles.activeLink : '')}>
                Team
              </NavLink>
            </li>
            <li>
              <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.activeLink : '')}>
                Contact
              </NavLink>
            </li>
          </ul>
          <div className={styles.ctaWrapper}>
            <NavLink to="/contact" className={styles.ctaButton}>
              Start a Conversation
            </NavLink>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;