import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.container}>
        <div className={styles.topRow}>
          <div className={styles.brandBlock}>
            <h2 id="footer-heading" className={styles.brandTitle}>
              AnimalQDKT Tech Solutions
            </h2>
            <p className={styles.brandText}>
              London-based technology partner delivering resilient systems, meaningful user experiences, and cloud-first architectures tailored for ambitious organisations across the United Kingdom.
            </p>
            <div className={styles.socialLinks} aria-label="Social media links">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                LinkedIn
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
                X
              </a>
              <a href="https://github.com" target="_blank" rel="noreferrer" aria-label="GitHub">
                GitHub
              </a>
            </div>
          </div>
          <div className={styles.linkColumn}>
            <h3>Company</h3>
            <NavLink to="/about">About</NavLink>
            <NavLink to="/team">Team</NavLink>
            <NavLink to="/portfolio">Portfolio</NavLink>
            <NavLink to="/contact">Contact</NavLink>
          </div>
          <div className={styles.linkColumn}>
            <h3>Services</h3>
            <NavLink to="/services#web">Web Development</NavLink>
            <NavLink to="/services#cloud">Cloud Solutions</NavLink>
            <NavLink to="/services#software">Software Engineering</NavLink>
            <NavLink to="/services#transformation">Digital Transformation</NavLink>
          </div>
          <div className={styles.linkColumn}>
            <h3>Resources</h3>
            <NavLink to="/privacy">Privacy Policy</NavLink>
            <NavLink to="/cookie-policy">Cookie Policy</NavLink>
            <NavLink to="/terms">Terms of Use</NavLink>
            <a href="#mainContent">Accessibility</a>
          </div>
        </div>
        <div className={styles.bottomRow}>
          <p>&copy; {new Date().getFullYear()} AnimalQDKT Tech Solutions. All rights reserved.</p>
          <p>Crafted for forward-thinking digital journeys.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;