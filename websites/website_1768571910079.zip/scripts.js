document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navLinks.classList.toggle("is-open");
        });
        navLinks.addEventListener("click", (event) => {
            if (event.target.tagName === "A" && navLinks.classList.contains("is-open")) {
                navLinks.classList.remove("is-open");
            }
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookies = document.getElementById("acceptCookies");
    const declineCookies = document.getElementById("declineCookies");
    const consentKey = "sadistpfndCookieConsent";

    if (cookieBanner && acceptCookies && declineCookies) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            cookieBanner.style.display = "grid";
        }

        acceptCookies.addEventListener("click", () => {
            localStorage.setItem(consentKey, "accepted");
            cookieBanner.style.display = "none";
        });

        declineCookies.addEventListener("click", () => {
            localStorage.setItem(consentKey, "declined");
            cookieBanner.style.display = "none";
        });
    }
});