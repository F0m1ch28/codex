document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('#primaryNav');
    const cookieBanner = document.querySelector('#cookieBanner');
    const cookieButtons = document.querySelectorAll('[data-cookie-action]');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        document.addEventListener('click', (event) => {
            if (!primaryNav.contains(event.target) && !navToggle.contains(event.target)) {
                primaryNav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (cookieBanner && cookieButtons.length) {
        const cookieStatus = localStorage.getItem('airsledrorCookieChoice');
        if (!cookieStatus) {
            cookieBanner.classList.add('show');
        }

        cookieButtons.forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const action = button.dataset.cookieAction;
                localStorage.setItem('airsledrorCookieChoice', action);
                cookieBanner.classList.remove('show');
                window.open(button.getAttribute('href'), '_blank', 'noopener');
            });
        });
    }
});