document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptButton = document.getElementById('cookie-accept');
  const declineButton = document.getElementById('cookie-decline');
  const storedChoice = localStorage.getItem('qdgCookieChoice');

  if (!storedChoice && cookieBanner) {
    cookieBanner.classList.add('is-visible');
  }

  const handleCookieChoice = (choice) => {
    localStorage.setItem('qdgCookieChoice', choice);
    if (cookieBanner) {
      cookieBanner.classList.remove('is-visible');
    }
  };

  if (acceptButton) {
    acceptButton.addEventListener('click', () => handleCookieChoice('accepted'));
  }

  if (declineButton) {
    declineButton.addEventListener('click', () => handleCookieChoice('declined'));
  }

  const toast = document.getElementById('form-toast');

  const showToast = (message) => {
    if (!toast) {
      return;
    }
    toast.textContent = message;
    toast.classList.add('is-visible');
    setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 2400);
  };

  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Mulțumim pentru mesaj. Veți fi direcționat către confirmare.');
      const actionTarget = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = actionTarget;
      }, 1200);
    });
  });

  const yearSpan = document.getElementById('current-year');
  if (yearSpan) {
    yearSpan.textContent = String(new Date().getFullYear());
  }

  const animatedElements = document.querySelectorAll('[data-animate]');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.2
  });

  animatedElements.forEach(element => observer.observe(element));
});