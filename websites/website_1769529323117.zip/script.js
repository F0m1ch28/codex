const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const COOKIE_KEY = "cookie_consent";

const I18N = {
  fr: {
    meta: {
      title: {
        home: "Comunidad IA Santé-Énergie | Réseau de Professionnels",
        services: "Forums et ressources | Comunidad IA Santé-Énergie",
        about: "À propos du réseau | Comunidad IA Santé-Énergie",
        blog: "Analyses et perspectives IA | Comunidad IA",
        post1: "Synchroniser les données cliniques et énergétiques",
        post2: "Interopérabilité hospitalière orientée IA",
        post3: "Validation clinique des algorithmes hybrides",
        post4: "Développement des compétences IA pour les hôpitaux",
        post5: "Supervision éthique continue des systèmes IA",
        contact: "Contact et coordination | Comunidad IA",
        faq: "Questions fréquentes | Comunidad IA",
        terms: "Conditions d’utilisation | Comunidad IA",
        privacy: "Politique de confidentialité | Comunidad IA",
        cookies: "Politique de cookies | Comunidad IA",
        refund: "Politique de réclamations | Comunidad IA",
        disclaimer: "Avertissement | Comunidad IA",
        thankyou: "Merci pour votre message | Comunidad IA",
        notfound: "Page non trouvée | Comunidad IA"
      },
      description: {
        home: "Réseau professionnel reliant des spécialistes IA pour la santé et l’énergie en Espagne. Forums, projets collaboratifs et bibliothèque partagée.",
        services: "Découvrez les forums thématiques, groupes régionaux et ressources collaboratives proposés par la Comunidad IA Santé-Énergie.",
        about: "Informations sur la mission, la gouvernance et les engagements de la Comunidad IA Santé-Énergie - Red de Profesionales.",
        blog: "Articles techniques bilingues sur l’IA appliquée à la santé et à l’énergie en Espagne.",
        post1: "Analyse sur la synchronisation des données cliniques et énergétiques pour renforcer la fiabilité de l’IA hospitalière.",
        post2: "Étude détaillée des cadres d’interopérabilité pour les hôpitaux travaillant avec l’IA énergétique.",
        post3: "Guide sur la validation clinique des systèmes IA combinant données santé et énergie.",
        post4: "Perspective sur le développement des compétences IA au sein des équipes hospitalières.",
        post5: "Cadres de supervision éthique pour les systèmes d’IA santé-énergie.",
        contact: "Coordonnées, formulaire sécurisé et carte interactive pour joindre Comunidad IA Santé-Énergie.",
        faq: "Réponses détaillées sur la structure, les processus et ressources de Comunidad IA.",
        terms: "Conditions d’utilisation régissant l’accès à la Comunidad IA Santé-Énergie.",
        privacy: "Informations sur la collecte, l’usage et la conservation des données personnelles par Comunidad IA.",
        cookies: "Détails sur l’utilisation des cookies et options de consentement au sein de Comunidad IA.",
        refund: "Procédure de gestion des réclamations et corrections des services informatifs de Comunidad IA.",
        disclaimer: "Limites de responsabilité et portée informationnelle de Comunidad IA.",
        thankyou: "Confirmation de réception de votre message envoyé à Comunidad IA Santé-Énergie.",
        notfound: "Lien brisé ou contenu déplacé pour la Comunidad IA Santé-Énergie."
      }
    },
    header: {
      nav: {
        home: "Accueil",
        services: "Ressources",
        about: "À propos",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      toggleLabel: "Menu",
      lang: {
        fr: "FR",
        en: "EN"
      }
    },
    footer: {
      title: "Comunidad IA Santé-Énergie - Red de Profesionales",
      description: "Réseau collaboratif réunissant médecins, ingénieurs, chercheurs et gestionnaires pour concevoir des solutions IA reliant santé et énergie en Espagne.",
      addressTitle: "Adresse",
      addressValue: "Calle Innovación 1000, 28027 Madrid, Espagne",
      phoneTitle: "Téléphone",
      phoneValue: "+34 91 555 7844",
      emailTitle: "Courriel",
      emailValue: "contact@comunidad-iaenergiahealthspain.com",
      rights: "Tous droits réservés.",
      legalLinks: {
        terms: "Conditions d’utilisation",
        privacy: "Confidentialité",
        cookies: "Cookies",
        refund: "Politique de réclamations",
        disclaimer: "Avertissement"
      }
    },
    home: {
      hero: {
        badge: "Réseau IA santé-énergie",
        heading: "Connecter les professionnels pour accélérer l’intelligence artificielle responsable dans les hôpitaux espagnols.",
        subtitle: "La Comunidad IA rassemble les expertises médicales et énergétiques afin de co-construire des pratiques factuelles, de partager les retours d’expérience et de soutenir la coopération entre régions.",
        primary: "Explorer les forums",
        secondary: "Découvrir nos engagements"
      },
      metrics: {
        item1Label: "Équipes hospitalières associées",
        item1Value: "128 organisations",
        item2Label: "Initiatives IA santé-énergie actives",
        item2Value: "54 projets",
        item3Label: "Études de cas partagées",
        item3Value: "312 cas"
      },
      features: {
        title: "Comment la Comunidad IA structure la collaboration transdisciplinaire",
        intro: "Les dispositifs proposés soutiennent la conception, l’évaluation et la diffusion des solutions IA dans les établissements de santé espagnols.",
        cards: [
          {
            title: "Forums thématiques approfondis",
            body: "Chaque forum modéré rassemble des praticiens pour analyser des cas concrets, publier des synthèses méthodologiques et consolider des guides opérationnels."
          },
          {
            title: "Cartographie régionale",
            body: "Les groupes locaux facilitent la coordination inter-hospitalière, l’identification des infrastructures énergétiques clés et le partage de contraintes contextuelles."
          },
          {
            title: "Tableau de projets collaboratifs",
            body: "Les membres publient leurs besoins, compétences et retours pour catalyser des collaborations équilibrées entre ingénierie, clinique et gestion énergétique."
          }
        ],
        links: {
          learn: "Approfondir la ressource"
        }
      },
      recommendations: {
        badge: "Recommandations",
        title: "Axes prioritaires identifiés par les coordinateurs scientifiques",
        items: [
          {
            title: "Structurer des inventaires de données énergétiques hospitalières",
            body: "Consolider des dictionnaires communs réduit les écarts d’interprétation lors de la formation algorithmiques et fluidifie les audits de performance."
          },
          {
            title: "Évaluer conjointement impact clinique et coût énergétique",
            body: "Les tableaux de bord proposés par la Comunidad IA croisent indicateurs cliniques, énergétiques et organisationnels afin de soutenir des décisions équilibrées."
          },
          {
            title: "Favoriser l’accès aux retours d’expérience terrain",
            body: "La bibliothèque partagée agrège des récits détaillés, identifie les contextes de réussite et éclaire les prérequis techniques et réglementaires."
          }
        ]
      },
      testimonials: {
        badge: "Témoignages",
        title: "Ce que les membres disent de la dynamique communautaire",
        items: [
          {
            quote: "Le forum sur la maintenance prédictive nous a permis de confronter nos indicateurs énergétiques avec des métriques cliniques et d’ajuster notre feuille de route.",
            author: "María Sánchez, ingénieure énergie hospitalière"
          },
          {
            quote: "Les notes méthodologiques partagées par les animateurs aident nos équipes à cadrer l’évaluation éthique sans repartir de zéro.",
            author: "Dr. Antoine Leclerc, radiologue"
          },
          {
            quote: "La cartographie régionale facilite nos échanges avec les fournisseurs et les services techniques pour sécuriser l’intégration des données énergétiques.",
            author: "Lucía Romero, responsable transformation digitale"
          }
        ]
      },
      updates: {
        badge: "Actualités du réseau",
        title: "Ce qui se prépare dans la Comunidad IA",
        cards: [
          {
            title: "Cycle d’ateliers modélisation énergétique",
            body: "Série de sessions hybrides pour outiller les équipes hospitalières dans l’évaluation comparative des modèles de consommation et des prévisions climatiques."
          },
          {
            title: "Publication d’un référentiel de gouvernance",
            body: "Document de référence couvrant la traçabilité des jeux de données, les protocoles de revue éthique et la continuité énergétique des systèmes critiques."
          }
        ]
      }
    },
    services: {
      hero: {
        badge: "Ressources communautaires",
        heading: "Des dispositifs pensés pour les interactions entre santé et énergie.",
        subtitle: "Qu’il s’agisse de déployer une solution IA au bloc opératoire ou d’analyser l’empreinte énergétique des data centers hospitaliers, la Comunidad IA fournit un espace structuré pour la co-construction."
      },
      list: [
        {
          title: "Forums thématiques",
          body: "Modération experte, synthèses mensuelles et invitations ciblées pour relier diagnostics assistés par IA, optimisation énergétique et continuité de soins."
        },
        {
          title: "Groupes régionaux",
          body: "Cartographie des acteurs régionaux, rencontres hybrides et signalement coordonné des besoins en infrastructures numériques et énergétiques."
        },
        {
          title: "Tableau de projets",
          body: "Publication transparente des initiatives, description des compétences recherchées et suivi d’avancement pour favoriser des partenariats responsables."
        },
        {
          title: "Rencontres professionnelles",
          body: "Sessions de co-analyse de cas, ateliers méthodologiques et échanges avec les autorités sanitaires et énergétiques."
        },
        {
          title: "Bibliothèque partagée",
          body: "Études de cas, gabarits de protocoles, grilles d’évaluation et retours d’inspection capitalisés dans une bibliothèque indexée."
        }
      ],
      closing: {
        title: "Processus d’adhésion",
        body: "Les demandes d’intégration sont étudiées par un comité pluridisciplinaire assurant la complémentarité des profils et la cohérence avec les axes de travail du réseau."
      }
    },
    about: {
      hero: {
        badge: "Culture de la Comunidad IA",
        heading: "Une gouvernance partagée entre praticiens, ingénieurs et responsables énergie.",
        subtitle: "Le réseau associe des institutions publiques, des hôpitaux universitaires et des partenaires technologiques pour renforcer l’usage responsable de l’IA."
      },
      timeline: [
        {
          title: "2018 — Lancement du collectif fondateur",
          body: "Première charte collaborative élaborée par douze établissements hospitaliers espagnols et quatre centres de recherche spécialisés en énergie."
        },
        {
          title: "2020 — Création des forums thématiques",
          body: "Structuration de six forums couvrant l’imagerie, les blocs opératoires, la maintenance énergétique et la mobilité intra-hospitalière."
        },
        {
          title: "2022 — Déploiement du tableau de projets",
          body: "Mise en place d’un catalogue dynamique permettant de suivre l’avancement, les ressources mobilisées et les livrables partagés."
        },
        {
          title: "2023 — Extension européenne",
          body: "Ouverture de collaborations pilotes avec des institutions en France, au Portugal et en Allemagne pour comparer les référentiels."
        }
      ],
      commitments: [
        {
          title: "Transparence des modèles",
          body: "Documentation exhaustive des jeux de données, des paramètres énergétiques et des méthodologies d’audit associées aux projets IA."
        },
        {
          title: "Évaluation clinique continue",
          body: "Intégration de boucles de validation clinique et énergétique tout au long du cycle de vie des algorithmes."
        },
        {
          title: "Convergence réglementaire",
          body: "Veille juridique européenne et alignement avec les directives espagnoles pour l’énergie et la santé numérique."
        }
      ]
    },
    blog: {
      hero: {
        badge: "Analyses du réseau",
        heading: "Études et retours d’expérience sur l’IA croisant santé et énergie.",
        subtitle: "Les articles sont co-rédigés par des binômes clinicien-analyste énergie afin de refléter des perspectives complémentaires."
      },
      cards: [
        {
          title: "Synchronisation des données cliniques et énergétiques",
          excerpt: "Méthodes pour relier flux hospitaliers et profils énergétiques afin d’augmenter la fiabilité des modèles IA.",
          link: "Lire l’article"
        },
        {
          title: "Interopérabilité hospitalière orientée IA",
          excerpt: "Cadres techniques pour faire dialoguer systèmes cliniques, plateformes énergétiques et outils d’analyse avancée.",
          link: "Lire l’article"
        },
        {
          title: "Validation clinique d’algorithmes hybrides",
          excerpt: "Protocole d’évaluation croisé entre données patients et capteurs énergétiques pour certifier l’usage clinique.",
          link: "Lire l’article"
        },
        {
          title: "Compétences IA pour les équipes hospitalières",
          excerpt: "Organisation d’itinéraires pédagogiques pour les équipes médicales, techniques et de gestion énergétique.",
          link: "Lire l’article"
        },
        {
          title: "Supervision éthique des systèmes IA",
          excerpt: "Structures de gouvernance continue pour monitorer les impacts sanitaires et énergétiques.",
          link: "Lire l’article"
        }
      ]
    },
    posts: {
      post1: {
        lead: "Les initiatives d’IA hospitalière reposent sur des données cliniques et énergétiques qui évoluent à des rythmes distincts. Harmoniser ces flux devient un enjeu central pour garantir la fiabilité des analyses et la continuité des services critiques.",
        sections: [
          {
            title: "Aligner les référentiels de données",
            subtitle: "Consolidation terminologique et synchronisation temporelle",
            paragraphs: [
              "Les hôpitaux agrègent quotidiennement des données hétérogènes provenant de dossiers patients, de capteurs biomédicaux et d’équipements énergétiques. Ces systèmes appliquent des horodatages, des unités de mesure et des formats variables. Sans alignement, la comparaison des signaux cliniques et énergétiques devient imprécise et compromet les indicateurs fournis par l’IA.",
              "Un premier chantier consiste donc à établir un dictionnaire partagé, qui relie chaque variable clinique à son équivalent énergétique pertinent. La Comunidad IA recommande d’associer à ces variables un identifiant stable, une granularité temporelle et un protocole de vérification automatisé. Cette structuration facilite les croisements ultérieurs et sécurise l’interprétation des tableaux de bord."
            ]
          },
          {
            title: "Coordonner les pipelines d’ingestion",
            subtitle: "Orchestration des flux temps réel",
            paragraphs: [
              "Une fois les référentiels alignés, l’enjeu se déplace sur la synchronisation opérationnelle. Les capteurs énergétiques remontent souvent des informations à une fréquence plus élevée que les systèmes cliniques. Pour éviter les décalages temporels, plusieurs hôpitaux membres du réseau ont adopté des orchestrateurs capables de tamponner les flux et de déclencher des agrégations sur une fenêtre commune.",
              "Cette orchestration doit également inclure des contrôles de qualité intégrés. La mise en place de tests automatiques, vérifiant l’intégrité des trames et la complétude des séries temporelles, permet de détecter rapidement les ruptures d’alimentation ou les dérives de capteurs."
            ]
          },
          {
            title: "Renforcer la gouvernance et les revues croisées",
            subtitle: "Capitaliser sur les retours d’usage",
            paragraphs: [
              "La synchronisation des données ne se limite pas à un travail technique. Elle nécessite une gouvernance partagée entre équipes cliniques, responsables énergie et spécialistes de la donnée. Dans la Comunidad IA, les revues trimestrielles associent ces acteurs afin d’examiner les journaux d’événements, de mettre à jour les référentiels et de prioriser les évolutions.",
              "Ces revues alimentent également la bibliothèque commune du réseau, où sont consignées les fiches de synchronisation. En documentant les incidents rencontrés et les solutions implémentées, les membres accélèrent l’apprentissage collectif et réduisent les risques associés aux projets futurs."
            ]
          }
        ]
      },
      post2: {
        lead: "Construire une interopérabilité robuste entre la sphère clinique et énergétique demeure un prérequis pour déployer des solutions IA fiables. Les architectures doivent intégrer normes médicales, protocoles industriels et exigences de cybersécurité.",
        sections: [
          {
            title: "S’appuyer sur des standards établis",
            subtitle: "HL7 FHIR, OPC-UA et profils combinés",
            paragraphs: [
              "Les hôpitaux espagnols utilisent majoritairement HL7 FHIR pour structurer les données cliniques. Les équipements énergétiques industriels, eux, privilégient des protocoles comme OPC-UA ou Modbus. Pour créer des passerelles durables, plusieurs établissements membres développent des profils d’interopérabilité combinés, reliant ressources FHIR et objets OPC-UA via des mappings documentés.",
              "Cette démarche impose de décrire précisément les attributs exposés, les règles de publication et les mécanismes d’authentification. Les guides produits par la Comunidad IA détaillent ces correspondances et soulignent les points d’attention, notamment la gestion des unités d’énergie et les conversions temporelles."
            ]
          },
          {
            title: "Mettre en place des bus d’intégration sécurisés",
            subtitle: "Segmentation des flux et surveillance",
            paragraphs: [
              "L’interopérabilité ne peut reposer sur des échanges ponctuels. Les membres du réseau ont progressivement implémenté des bus d’intégration ou des plateformes d’API management, capables de filtrer, journaliser et chiffrer les interactions. Ces bus segmentent les flux selon leur sensibilité et s’interfacent avec les systèmes de supervision énergétique.",
              "Une surveillance continue est indispensable pour détecter les anomalies. Les tableaux de bord croisés développés au sein de la Comunidad IA agrègent des métriques de latence, de disponibilité et d’usage, afin de repérer rapidement les dégradations impactant l’IA ou les services hospitaliers."
            ]
          },
          {
            title: "Créer des accords de service concertés",
            subtitle: "Responsabilités partagées et arbitrages",
            paragraphs: [
              "Au-delà de la technique, l’interopérabilité doit être soutenue par des accords clairs entre directions médicales, informatiques et énergie. Les contrats de service définissent la criticité des flux, les délais de résolution incident et les modalités de tests avant mise en production.",
              "La Comunidad IA encourage la co-signature de ces accords par les référents IA. Cela garantit que les besoins des algorithmes, en termes de fraîcheur de données et de qualité, sont intégrés aux arbitrages budgétaires et opérationnels."
            ]
          }
        ]
      },
      post3: {
        lead: "Les systèmes IA combinant données cliniques et énergétiques promettent des recommandations plus fines. Leur validation doit cependant concilier sécurité des patients, continuité énergétique et performance algorithmique.",
        sections: [
          {
            title: "Définir des protocoles d’évaluation multidimensionnels",
            subtitle: "Indicateurs cliniques, énergétiques et organisationnels",
            paragraphs: [
              "Les membres de la Comunidad IA formulent des protocoles intégrant des indicateurs de précision clinique, de régulation énergétique et de charge opérationnelle. Par exemple, les modèles de planification opératoire incluent un suivi du confort thermique, de la consommation électrique et des délais patients.",
              "Chaque indicateur est accompagné d’un seuil d’alerte et d’une procédure de revue. Les équipes cliniques valident la pertinence médicale, tandis que les ingénieurs énergie vérifient la cohérence avec les objectifs de performance globale."
            ]
          },
          {
            title: "Mettre en œuvre des essais pilotes encadrés",
            subtitle: "Phases de test et documentation",
            paragraphs: [
              "Avant un déploiement généralisé, les projets passent par des pilotes encadrés. Ces phases comportent des tests comparatifs avec les procédures existantes, des journaux d’énergie détaillés et des revues hebdomadaires. Les résultats sont capitalisés dans la bibliothèque communautaire.",
              "La documentation inclut les versions de modèles, les paramètres d’entraînement et les configurations énergétiques des zones concernées. Cette transparence facilite la reproductibilité et la décision d’extension."
            ]
          },
          {
            title: "Assurer un suivi continu post-déploiement",
            subtitle: "Tableaux de bord et alertes partagées",
            paragraphs: [
              "Une fois la solution en production, les hôpitaux maintiennent des tableaux de bord combinant retours cliniques et métriques énergétiques. Des alertes automatiques préviennent les équipes en cas de dérive significative ou de rupture de flux de données.",
              "Les retours sont discutés lors de comités conjoints. Les ajustements nécessaires, qu’ils concernent le calibrage énergétique ou les paramètres cliniques, sont consignés et diffusés au sein de la Comunidad IA pour renforcer la maturité collective."
            ]
          }
        ]
      },
      post4: {
        lead: "Le développement des compétences demeure un facteur clé pour réussir les projets d’IA santé-énergie. Les hôpitaux doivent articuler formations techniques, compréhension clinique et culture énergétique.",
        sections: [
          {
            title: "Cartographier les besoins en compétences",
            subtitle: "Approche par rôles et par missions",
            paragraphs: [
              "Les établissements membres du réseau identifient les rôles impliqués dans un projet IA : cliniciens, spécialistes énergie, data scientists, responsables qualité. Pour chacun, un référentiel de compétences cible est défini, incluant les bases de l’IA, la lecture des indicateurs énergétiques et la communication interdisciplinaire.",
              "Cette cartographie sert de base à des plans de formation modulaires. Les sessions sont organisées en formats courts, combinant ateliers pratiques, études de cas et revues de projets communautaires."
            ]
          },
          {
            title: "Créer des parcours hybrides",
            subtitle: "Mentorat croisé et laboratoires partagés",
            paragraphs: [
              "Afin de dépasser les silos, plusieurs hôpitaux ont mis en place des binômes mentorés : un clinicien suit un ingénieur énergie, et inversement, sur un projet concret. Ces duos favorisent une compréhension mutuelle des contraintes et accélèrent la prise de décision.",
              "Des laboratoires partagés permettent de manipuler des jeux de données anonymisés et de simuler des scénarios énergétiques. Les participants expérimentent la configuration des modèles et mesurent l’impact sur les services hospitaliers."
            ]
          },
          {
            title: "Évaluer l’appropriation et capitaliser",
            subtitle: "Tableaux de progression et retours d’expérience",
            paragraphs: [
              "L’évaluation des parcours repose sur des tableaux de progression renseignés par les participants. Les compétences sont validées via des projets concrets ou des revues de cas publiées dans la bibliothèque communautaire.",
              "Les retours d’expérience alimentent des guides de bonnes pratiques. Ils mettent en lumière les obstacles rencontrés, les ressources à mobiliser et les modalités d’accompagnement les plus efficaces pour les équipes hospitalières."
            ]
          }
        ]
      },
      post5: {
        lead: "Les systèmes IA appliqués aux environnements hospitaliers doivent être supervisés en continu pour prévenir les dérives. La dimension énergétique ajoute des exigences supplémentaires en termes de résilience et de sobriété.",
        sections: [
          {
            title: "Structurer des comités de supervision",
            subtitle: "Rôles et responsabilités clarifiés",
            paragraphs: [
              "La Comunidad IA recommande d’établir des comités associant médecine, énergie, cybersécurité et représentants des patients. Chaque comité définit un périmètre de supervision, les critères d’acceptabilité des modèles et les modalités de décision en cas d’incident.",
              "Les membres documentent les scénarios critiques : interruption de capteurs, variations énergétiques extrêmes, modifications de protocoles cliniques. Cette anticipation facilite la réactivité lors des revues."
            ]
          },
          {
            title: "Mettre en place des indicateurs de vigilance",
            subtitle: "Surveillance technique et éthique",
            paragraphs: [
              "Les tableaux de bord de vigilance agrègent des indicateurs techniques (latence, disponibilité des capteurs, consommation) et des indicateurs éthiques (équité, respect des standards de soins). Chaque alerte déclenche une analyse et la mise à jour des plans d’actions.",
              "Les membres consignent ces analyses dans la bibliothèque communautaire. Cela permet de comparer les stratégies de mitigation et d’ajuster collectivement les niveaux d’alerte."
            ]
          },
          {
            title: "Assurer la traçabilité et l’amélioration continue",
            subtitle: "Capitalisation des décisions",
            paragraphs: [
              "Chaque décision de supervision est enregistrée avec son contexte, les données examinées et les orientations adoptées. Cette traçabilité soutient les audits internes et les interactions avec les autorités de santé.",
              "Les enseignements tirés alimentent des guides méthodologiques partagés. Ils renforcent la maturité collective et favorisent une approche proactive de la supervision éthique des systèmes IA santé-énergie."
            ]
          }
        ]
      }
    },
    contact: {
      hero: {
        badge: "Coordination",
        heading: "Entrer en relation avec les animateurs de la Comunidad IA.",
        subtitle: "Nous répondons aux questions relatives aux forums, au tableau de projets et aux contributions à la bibliothèque."
      },
      infoTitle: "Coordonnées directes",
      phoneLabel: "Téléphoner",
      emailLabel: "Écrire un courriel",
      addressLabel: "Rencontrer l’équipe",
      formTitle: "Formulaire de contact",
      formIntro: "Partagez vos besoins : nous orienterons votre demande vers les référents appropriés.",
      form: {
        name: "Nom complet",
        email: "Adresse courriel professionnelle",
        organization: "Organisation",
        topic: "Sujet",
        message: "Message détaillé",
        submit: "Envoyer la demande"
      },
      placeholders: {
        name: "Saisir votre nom",
        email: "Saisir votre adresse",
        organization: "Nom de l’établissement",
        topic: "Sélectionner un thème",
        message: "Décrivez votre question ou votre initiative"
      },
      options: {
        general: "Information générale",
        forum: "Forum thématique",
        project: "Projet collaboratif",
        library: "Bibliothèque partagée",
        events: "Rencontres professionnelles"
      },
      mapLabel: "Localisation du siège communautaire à Madrid."
    },
    faq: {
      hero: {
        badge: "Questions fréquentes",
        heading: "Comprendre la structure et les processus de la Comunidad IA.",
        subtitle: "Les réponses ci-dessous s’appuient sur la charte de fonctionnement mise à jour chaque année."
      },
      items: [
        {
          question: "Comment les forums thématiques sont-ils animés ?",
          answer: "Chaque forum dispose d’un binôme animateur composé d’un clinicien et d’un spécialiste énergie. Ils planifient les discussions, valident les documents partagés et assurent le respect de la charte de confidentialité."
        },
        {
          question: "Qui peut proposer un projet collaboratif ?",
          answer: "Toute institution membre peut publier une fiche projet. Un comité vérifie la cohérence, la description des jeux de données et l’impact sur les infrastructures énergétiques avant publication."
        },
        {
          question: "Comment accéder à la bibliothèque partagée ?",
          answer: "Les membres disposent d’un accès sécurisé. Les documents sont indexés par domaine clinique, technologie IA et composante énergétique pour faciliter la recherche."
        },
        {
          question: "Quels sont les engagements en matière d’éthique ?",
          answer: "La charte intègre des exigences de supervision, de transparence et de participation des patients. Chaque projet doit tenir une revue éthique régulière, dont les conclusions sont partagées dans le réseau."
        },
        {
          question: "Comment sont structurées les rencontres professionnelles ?",
          answer: "Elles alternent sessions virtuelles et rassemblements en présentiel. Les comptes rendus, supports et actions décidées sont mis en ligne dans la bibliothèque communautaire."
        }
      ]
    },
    terms: {
      intro: "Les présentes conditions régissent l’utilisation du site et des ressources communautaires. L’accès implique l’acceptation intégrale des dispositions ci-dessous.",
      sections: [
        {
          title: "1. Objet",
          body: "Le présent document définit les règles d’utilisation du site comunidad-iaenergiahealthspain.com et des espaces collaboratifs associés."
        },
        {
          title: "2. Gestion du réseau",
          body: "Le réseau est coordonné par un comité pluridisciplinaire qui veille à la cohérence des activités, à la qualité des contenus et au respect des obligations légales."
        },
        {
          title: "3. Accès aux ressources",
          body: "L’accès aux forums, bibliothèques et tableaux de projets est réservé aux membres autorisés. Toute tentative d’accès non autorisé est interdite."
        },
        {
          title: "4. Contributions des membres",
          body: "Les membres s’engagent à publier des informations exactes, à citer leurs sources et à respecter les règles de confidentialité applicables à leurs institutions."
        },
        {
          title: "5. Confidentialité",
          body: "Les échanges internes peuvent contenir des données sensibles. Chaque membre doit appliquer les protocoles de confidentialité définis par la charte communautaire."
        },
        {
          title: "6. Propriété intellectuelle",
          body: "Les contenus publiés restent la propriété de leurs auteurs. Le réseau bénéficie d’une licence non exclusive pour les diffuser au sein des membres."
        },
        {
          title: "7. Usage responsable",
          body: "Les ressources doivent être utilisées à des fins d’analyse, d’évaluation ou de coordination. Toute exploitation contraire à l’éthique médicale ou énergétique est prohibée."
        },
        {
          title: "8. Sécurité des systèmes",
          body: "Les utilisateurs doivent protéger leurs identifiants, signaler toute suspicion d’incident et respecter les consignes de cybersécurité communiquées."
        },
        {
          title: "9. Modifications",
          body: "Le comité peut modifier les présentes conditions après consultation des membres. Les modifications sont communiquées via les canaux officiels."
        },
        {
          title: "10. Suspension",
          body: "En cas de non-respect des règles, le comité peut suspendre temporairement ou définitivement l’accès d’un membre aux ressources."
        },
        {
          title: "11. Liens externes",
          body: "Le site peut contenir des liens vers des ressources tierces. Le réseau ne peut être tenu responsable du contenu ou des politiques de ces sites."
        },
        {
          title: "12. Responsabilités",
          body: "Chaque membre reste responsable des décisions prises sur la base des informations consultées. Le réseau fournit un cadre collaboratif sans se substituer aux obligations des institutions."
        },
        {
          title: "13. Droit applicable",
          body: "Les présentes conditions sont régies par le droit espagnol. Les litiges relèvent de la juridiction compétente de Madrid."
        },
        {
          title: "14. Contact",
          body: "Toute question relative aux conditions d’utilisation peut être adressée à contact@comunidad-iaenergiahealthspain.com."
        }
      ]
    },
    privacy: {
      intro: "Cette politique décrit la manière dont Comunidad IA Santé-Énergie collecte, utilise et protège les données personnelles dans le cadre de ses activités collaboratives.",
      sections: [
        {
          title: "1. Responsable du traitement",
          body: "Le comité de coordination de Comunidad IA Santé-Énergie, basé Calle Innovación 1000, 28027 Madrid, est responsable du traitement."
        },
        {
          title: "2. Données collectées",
          body: "Nous collectons les informations d’identification professionnelle, les coordonnées, ainsi que les contributions publiées dans les forums et bibliothèques."
        },
        {
          title: "3. Finalités",
          body: "Les données servent à gérer l’accès aux ressources, animer les forums, suivre les projets collaboratifs et diffuser les communications communautaires."
        },
        {
          title: "4. Fondement juridique",
          body: "Le traitement repose sur l’intérêt légitime du réseau à organiser la coopération et sur les accords contractuels conclus avec les institutions membres."
        },
        {
          title: "5. Conservation",
          body: "Les données sont conservées tant que la participation du membre reste active, puis archivées durant la durée légale nécessaire."
        },
        {
          title: "6. Partage",
          body: "Les informations peuvent être partagées avec les institutions partenaires impliquées dans un projet, dans le respect des obligations de confidentialité."
        },
        {
          title: "7. Sécurité",
          body: "Des mesures techniques et organisationnelles sont mises en place pour préserver la confidentialité, l’intégrité et la disponibilité des données."
        },
        {
          title: "8. Droits",
          body: "Les membres disposent d’un droit d’accès, de rectification, d’effacement, de limitation, d’opposition et de portabilité lorsqu’applicable."
        },
        {
          title: "9. Exercice des droits",
          body: "Les demandes peuvent être envoyées à contact@comunidad-iaenergiahealthspain.com. Une réponse sera apportée dans les délais légaux."
        },
        {
          title: "10. Mise à jour",
          body: "Cette politique peut être actualisée. Les modifications importantes seront communiquées aux membres par les canaux officiels."
        }
      ]
    },
    cookies: {
      intro: "La présente politique explique l’usage des cookies et technologies similaires sur le site comunidad-iaenergiahealthspain.com.",
      sections: [
        {
          title: "Usage des cookies",
          body: "Nous utilisons des cookies nécessaires au fonctionnement du site, ainsi que des cookies de préférences, d’analytique et de communication soumis à votre consentement."
        },
        {
          title: "Gestion du consentement",
          body: "Un bandeau permet de paramétrer vos choix. Vous pouvez modifier ces préférences à tout moment via le lien de gestion présent sur le site."
        }
      ],
      table: {
        headers: ["Nom", "Fournisseur", "Type", "Finalité", "Durée"],
        rows: [
          ["session_core", "Comunidad IA", "Nécessaire", "Maintenir la session des membres connectés.", "Session"],
          ["pref_lang", "Comunidad IA", "Préférences", "Mémoriser la langue sélectionnée.", "12 mois"],
          ["analytics_insight", "Comunidad IA", "Analytique", "Mesurer l’usage des ressources et améliorer l’expérience.", "9 mois"],
          ["outreach_signal", "Comunidad IA", "Marketing", "Identifier les contenus consultés pour les communications ciblées.", "6 mois"]
        ]
      }
    },
    refund: {
      intro: "La politique de réclamations définit les modalités de correction et de médiation appliquées par Comunidad IA Santé-Énergie.",
      sections: [
        {
          title: "1. Objet",
          body: "Encadrer la gestion des réclamations relatives aux contenus, accès ou processus communautaires."
        },
        {
          title: "2. Champ d’application",
          body: "La procédure concerne les membres et partenaires disposant d’un accès autorisé aux ressources."
        },
        {
          title: "3. Dépôt d’une réclamation",
          body: "Les demandes doivent être transmises via le formulaire de contact ou par courriel, en précisant le contexte et les éléments justificatifs."
        },
        {
          title: "4. Accusé de réception",
          body: "Un accusé de réception est envoyé sous cinq jours ouvrés avec le numéro de dossier attribué."
        },
        {
          title: "5. Analyse préliminaire",
          body: "Le comité évalue la recevabilité, identifie les experts concernés et planifie les étapes d’examen."
        },
        {
          title: "6. Instruction",
          body: "Les pièces sont étudiées, les membres éventuellement entendus et des mesures provisoires peuvent être décidées."
        },
        {
          title: "7. Décision",
          body: "Une réponse motivée est communiquée précisant les ajustements retenus ou les motifs de rejet."
        },
        {
          title: "8. Correctifs",
          body: "Lorsque des corrections sont nécessaires, un calendrier est partagé et un suivi est réalisé jusqu’à clôture."
        },
        {
          title: "9. Médiation",
          body: "En cas de désaccord, une médiation interne peut être sollicitée impliquant un panel de membres."
        },
        {
          title: "10. Archivage",
          body: "Chaque dossier est archivé afin d’alimenter les retours d’expérience et l’amélioration continue des processus."
        }
      ]
    },
    disclaimer: {
      intro: "Le contenu du site est fourni à titre informatif. Il reflète l’expérience des membres sans constituer un avis médical, énergétique ou juridique personnalisé.",
      sections: [
        {
          title: "Absence de conseil personnalisé",
          body: "Les informations publiées ne remplacent pas les analyses spécifiques menées par les institutions ou les autorités compétentes."
        },
        {
          title: "Exactitude des contenus",
          body: "Nous veillons à l’exactitude des données mais ne pouvons garantir l’absence d’erreur ou la mise à jour continue de chaque ressource."
        },
        {
          title: "Responsabilité des membres",
          body: "Chaque membre demeure responsable de l’usage des informations et des décisions prises au sein de son organisation."
        },
        {
          title: "Liens externes",
          body: "Les liens vers des sites tiers sont fournis pour convenance. Comunidad IA n’en contrôle pas le contenu."
        },
        {
          title: "Évolutions",
          body: "Le site peut évoluer sans notification préalable. Les utilisateurs sont invités à consulter régulièrement les mises à jour."
        }
      ]
    },
    thankyou: {
      hero: {
        badge: "Message reçu",
        heading: "Merci pour votre prise de contact.",
        subtitle: "Notre équipe analysera votre demande et reviendra vers vous par courriel dès qu’un référent sera identifié."
      },
      action: "Retourner à l’accueil"
    },
    notfound: {
      hero: {
        badge: "Lien indisponible",
        heading: "La page demandée n’est plus accessible.",
        subtitle: "Vérifiez l’URL ou utilisez la navigation principale pour rejoindre une ressource active."
      },
      action: "Revenir à l’accueil"
    },
    cookiesBanner: {
      title: "Gestion des cookies",
      description: "Nous utilisons des cookies pour assurer le fonctionnement du site et analyser l’utilisation de nos ressources. Vous pouvez ajuster vos préférences ci-dessous.",
      acceptAll: "Tout accepter",
      declineAll: "Tout refuser",
      save: "Enregistrer les préférences",
      manage: "Personnaliser les cookies",
      categories: {
        necessary: {
          title: "Nécessaires",
          description: "Indispensables au fonctionnement du site.",
          locked: true
        },
        preferences: {
          title: "Préférences",
          description: "Mémorisent vos choix de navigation."
        },
        analytics: {
          title: "Analytique",
          description: "Mesurent l’audience et la performance."
        },
        marketing: {
          title: "Communication",
          description: "Adaptent nos contenus partagés aux membres."
        }
      }
    },
    toasts: {
      formSubmitted: "Votre demande est en cours d’envoi vers les coordinateurs."
    }
  },
  en: {
    meta: {
      title: {
        home: "Comunidad IA Health-Energy | Professional Network",
        services: "Forums and Resources | Comunidad IA Health-Energy",
        about: "About the Network | Comunidad IA Health-Energy",
        blog: "AI Insights and Field Notes | Comunidad IA",
        post1: "Synchronizing Clinical and Energy Data Pipelines",
        post2: "AI-Oriented Hospital Interoperability Frameworks",
        post3: "Clinical Validation of Hybrid AI Systems",
        post4: "Upskilling Hospital Teams for AI Adoption",
        post5: "Ethical Oversight for Health-Energy AI Systems",
        contact: "Contact and Coordination | Comunidad IA",
        faq: "Frequently Asked Questions | Comunidad IA",
        terms: "Terms of Use | Comunidad IA",
        privacy: "Privacy Policy | Comunidad IA",
        cookies: "Cookie Policy | Comunidad IA",
        refund: "Claims Policy | Comunidad IA",
        disclaimer: "Disclaimer | Comunidad IA",
        thankyou: "Thank You for Your Message | Comunidad IA",
        notfound: "Page Not Found | Comunidad IA"
      },
      description: {
        home: "Professional network connecting AI specialists in health and energy across Spain. Forums, collaborative projects and shared case library.",
        services: "Explore thematic forums, regional groups and collaborative resources offered by Comunidad IA Health-Energy.",
        about: "Learn about the mission, governance and commitments of Comunidad IA Health-Energy - Red de Profesionales.",
        blog: "Bilingual technical articles on AI applied to healthcare and energy in Spain.",
        post1: "Analysis on synchronizing clinical and energy data to strengthen hospital AI reliability.",
        post2: "In-depth look at interoperability frameworks for AI-ready hospital energy systems.",
        post3: "Guidance on clinically validating AI systems combining health and energy data.",
        post4: "Perspectives on developing AI capabilities within hospital teams.",
        post5: "Governance frameworks for ongoing oversight of health-energy AI systems.",
        contact: "Contact details, secure form and interactive map to reach Comunidad IA Health-Energy.",
        faq: "Detailed answers about the structure, processes and resources of Comunidad IA.",
        terms: "Terms governing access to Comunidad IA Health-Energy.",
        privacy: "Information about how Comunidad IA collects, uses and stores personal data.",
        cookies: "Details on cookie usage and consent options within Comunidad IA.",
        refund: "Procedure for handling claims and corrections related to Comunidad IA informational services.",
        disclaimer: "Liability limitations and informational scope of Comunidad IA.",
        thankyou: "Confirmation that your message was received by Comunidad IA Health-Energy.",
        notfound: "Broken link or moved content within Comunidad IA Health-Energy."
      }
    },
    header: {
      nav: {
        home: "Home",
        services: "Resources",
        about: "About",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      toggleLabel: "Menu",
      lang: {
        fr: "FR",
        en: "EN"
      }
    },
    footer: {
      title: "Comunidad IA Health-Energy - Red de Profesionales",
      description: "Collaborative network bringing together physicians, engineers, researchers and managers to design AI solutions bridging health and energy in Spain.",
      addressTitle: "Address",
      addressValue: "Calle Innovación 1000, 28027 Madrid, Spain",
      phoneTitle: "Phone",
      phoneValue: "+34 91 555 7844",
      emailTitle: "Email",
      emailValue: "contact@comunidad-iaenergiahealthspain.com",
      rights: "All rights reserved.",
      legalLinks: {
        terms: "Terms of Use",
        privacy: "Privacy",
        cookies: "Cookies",
        refund: "Claims Policy",
        disclaimer: "Disclaimer"
      }
    },
    home: {
      hero: {
        badge: "Health-energy AI network",
        heading: "Connecting professionals to advance responsible artificial intelligence across Spanish hospitals.",
        subtitle: "Comunidad IA brings together medical and energy expertise to co-create evidence-based practices, share field feedback and support cooperation between regions.",
        primary: "Browse the forums",
        secondary: "Discover our commitments"
      },
      metrics: {
        item1Label: "Partner hospital teams",
        item1Value: "128 organizations",
        item2Label: "Active health-energy AI initiatives",
        item2Value: "54 projects",
        item3Label: "Shared case studies",
        item3Value: "312 cases"
      },
      features: {
        title: "How Comunidad IA structures cross-disciplinary collaboration",
        intro: "The initiatives support the design, assessment and dissemination of AI solutions across Spanish healthcare institutions.",
        cards: [
          {
            title: "In-depth thematic forums",
            body: "Each moderated forum gathers practitioners to analyse concrete cases, publish methodological summaries and consolidate operational guidance."
          },
          {
            title: "Regional mapping",
            body: "Local groups facilitate inter-hospital coordination, identify critical energy infrastructures and exchange contextual constraints."
          },
          {
            title: "Collaborative project board",
            body: "Members share needs, skills and lessons learned to catalyse balanced collaborations between engineering, clinical teams and energy management."
          }
        ],
        links: {
          learn: "Explore this resource"
        }
      },
      recommendations: {
        badge: "Recommendations",
        title: "Priority directions highlighted by the scientific coordinators",
        items: [
          {
            title: "Structure hospital energy data inventories",
            body: "Building shared dictionaries narrows interpretation gaps during model training and streamlines performance audits."
          },
          {
            title: "Evaluate clinical impact alongside energy demand",
            body: "Community dashboards correlate clinical, energy and organisational indicators to support balanced decision-making."
          },
          {
            title: "Promote access to field feedback",
            body: "The shared library aggregates detailed narratives, success contexts and prerequisite checklists for upcoming initiatives."
          }
        ]
      },
      testimonials: {
        badge: "Testimonials",
        title: "What members value in the community dynamic",
        items: [
          {
            quote: "The predictive maintenance forum helped us align energy metrics with clinical indicators and adjust our roadmap.",
            author: "María Sánchez, hospital energy engineer"
          },
          {
            quote: "Methodological briefs shared by facilitators guide our teams through ethical evaluations without starting from scratch.",
            author: "Dr. Antoine Leclerc, radiologist"
          },
          {
            quote: "Regional mapping makes it easier to coordinate with suppliers and technical services when integrating energy datasets.",
            author: "Lucía Romero, digital transformation lead"
          }
        ]
      },
      updates: {
        badge: "Community updates",
        title: "What is happening across Comunidad IA",
        cards: [
          {
            title: "Energy modelling workshop series",
            body: "Hybrid sessions supporting hospital teams in benchmarking consumption models and climate forecasts."
          },
          {
            title: "Release of a governance reference",
            body: "Comprehensive document covering data traceability, ethical review protocols and energy continuity for critical systems."
          }
        ]
      }
    },
    services: {
      hero: {
        badge: "Community resources",
        heading: "Tools designed around health and energy interactions.",
        subtitle: "Whether deploying AI in operating theatres or analysing the energy footprint of hospital data centres, Comunidad IA offers structured collaboration spaces."
      },
      list: [
        {
          title: "Thematic forums",
          body: "Expert moderation, monthly syntheses and targeted invitations linking AI-assisted diagnostics, energy optimisation and continuity of care."
        },
        {
          title: "Regional groups",
          body: "Actor mapping, hybrid meetings and coordinated reporting of digital and energy infrastructure needs."
        },
        {
          title: "Project board",
          body: "Transparent initiative listings, required skill sets and progress tracking to foster responsible partnerships."
        },
        {
          title: "Professional gatherings",
          body: "Case co-analysis sessions, methodological workshops and exchanges with health and energy authorities."
        },
        {
          title: "Shared library",
          body: "Case studies, protocol templates, evaluation grids and inspection feedback indexed in a searchable repository."
        }
      ],
      closing: {
        title: "Membership process",
        body: "Applications are reviewed by a multidisciplinary committee ensuring profile complementarity and alignment with the network’s focus areas."
      }
    },
    about: {
      hero: {
        badge: "Community culture",
        heading: "Shared governance between clinicians, engineers and energy managers.",
        subtitle: "The network brings together public institutions, teaching hospitals and technology partners to strengthen responsible AI usage."
      },
      timeline: [
        {
          title: "2018 — Founding collective launched",
          body: "First collaborative charter drafted by twelve Spanish hospitals and four energy research centres."
        },
        {
          title: "2020 — Thematic forums created",
          body: "Six forums structured around imaging, operating theatres, energy maintenance and intra-hospital mobility."
        },
        {
          title: "2022 — Project board deployed",
          body: "Dynamic catalogue established to track milestones, mobilised resources and shared deliverables."
        },
        {
          title: "2023 — European outreach",
          body: "Pilot collaborations opened with institutions in France, Portugal and Germany to compare frameworks."
        }
      ],
      commitments: [
        {
          title: "Model transparency",
          body: "Exhaustive documentation of datasets, energy parameters and audit methodologies tied to AI projects."
        },
        {
          title: "Ongoing clinical evaluation",
          body: "Embedding clinical and energy validation loops throughout algorithm lifecycles."
        },
        {
          title: "Regulatory convergence",
          body: "European legal monitoring and alignment with Spanish directives for energy and digital health."
        }
      ]
    },
    blog: {
      hero: {
        badge: "Network insights",
        heading: "Field notes on AI at the intersection of health and energy.",
        subtitle: "Articles are co-authored by clinician-energy analyst pairs to reflect complementary viewpoints."
      },
      cards: [
        {
          title: "Synchronizing clinical and energy data",
          excerpt: "Methods to connect hospital workflows and energy profiles to increase AI reliability.",
          link: "Read the article"
        },
        {
          title: "AI-oriented hospital interoperability",
          excerpt: "Technical frameworks to align clinical systems, energy platforms and advanced analytics.",
          link: "Read the article"
        },
        {
          title: "Validating hybrid AI algorithms",
          excerpt: "Cross-evaluation protocol combining patient data and energy sensor streams for clinical approval.",
          link: "Read the article"
        },
        {
          title: "AI skill-building for hospital teams",
          excerpt: "Learning pathways for medical, technical and energy management teams.",
          link: "Read the article"
        },
        {
          title: "Ethical oversight for AI systems",
          excerpt: "Governance structures to monitor healthcare and energy impacts.",
          link: "Read the article"
        }
      ]
    },
    posts: {
      post1: {
        lead: "Hospital AI initiatives rely on clinical and energy data streams that evolve at different paces. Harmonising these flows is essential to secure analytics reliability and protect critical services.",
        sections: [
          {
            title: "Aligning data dictionaries",
            subtitle: "Terminology consolidation and temporal synchronisation",
            paragraphs: [
              "Hospitals aggregate heterogeneous data from patient records, biomedical sensors and energy equipment. These systems apply diverse timestamps, units and formats. Without alignment, comparing clinical and energy signals becomes inaccurate and undermines AI dashboards.",
              "The first milestone therefore consists in building a shared dictionary linking each clinical variable to its relevant energy counterpart. Comunidad IA recommends assigning stable identifiers, temporal granularity and automated verification rules. This structure facilitates cross-analyses and strengthens interpretation."
            ]
          },
          {
            title: "Coordinating ingestion pipelines",
            subtitle: "Real-time flow orchestration",
            paragraphs: [
              "Once dictionaries are aligned, operational synchronisation becomes the focus. Energy sensors often report more frequently than clinical systems. To avoid temporal gaps, member hospitals deploy orchestrators able to buffer streams and trigger aggregations on a common window.",
              "The orchestration layer also embeds quality checks. Automated tests verify frame integrity and time series completeness, ensuring swift detection of outages or sensor drifts."
            ]
          },
          {
            title: "Embedding joint governance reviews",
            subtitle: "Capitalising on usage feedback",
            paragraphs: [
              "Synchronising data requires shared governance between clinical teams, energy managers and data specialists. Within Comunidad IA, quarterly reviews gather these actors to inspect event logs, update dictionaries and prioritise enhancements.",
              "These reviews feed the community library, where synchronisation sheets are stored. Documenting incidents and fixes accelerates collective learning and mitigates project risks."
            ]
          }
        ]
      },
      post2: {
        lead: "Building robust interoperability between clinical and energy domains is a prerequisite for trustworthy AI deployments. Architectures must integrate medical standards, industrial protocols and cybersecurity requirements.",
        sections: [
          {
            title: "Leveraging established standards",
            subtitle: "HL7 FHIR, OPC-UA and combined profiles",
            paragraphs: [
              "Spanish hospitals primarily rely on HL7 FHIR to structure clinical data. Energy equipment often uses industrial protocols such as OPC-UA or Modbus. To sustain durable bridges, institutions develop combined profiles mapping FHIR resources to OPC-UA objects with documented correspondences.",
              "This effort requires precise attribute descriptions, publication rules and authentication mechanisms. Community guidance details these mappings and highlights specific focus areas, including energy units and temporal conversions."
            ]
          },
          {
            title: "Deploying secure integration buses",
            subtitle: "Flow segmentation and monitoring",
            paragraphs: [
              "Interop cannot rely on ad hoc exchanges. Members progressively introduce integration buses or API management platforms able to filter, log and encrypt interactions. Flows are segmented according to sensitivity and connected to energy supervision systems.",
              "Continuous monitoring is essential to catch anomalies. Cross dashboards built within Comunidad IA aggregate latency, availability and usage metrics, enabling rapid response to degradations impacting AI or hospital services."
            ]
          },
          {
            title: "Establishing shared service agreements",
            subtitle: "Responsibilities and arbitration",
            paragraphs: [
              "Beyond technology, interoperability must be backed by clear agreements between medical, IT and energy leadership. Service contracts define flow criticality, resolution timelines and testing protocols prior to production.",
              "Comunidad IA encourages co-signature by AI leads to ensure that requirements around data freshness and quality are integrated into operational and budgetary decisions."
            ]
          }
        ]
      },
      post3: {
        lead: "AI systems combining clinical and energy data promise more precise recommendations. Validation must reconcile patient safety, energy continuity and algorithmic performance.",
        sections: [
          {
            title: "Designing multidimensional evaluation protocols",
            subtitle: "Clinical, energy and organisational indicators",
            paragraphs: [
              "Comunidad IA members formulate protocols that integrate clinical accuracy, energy regulation and operational load indicators. For instance, surgical planning models track thermal comfort, electricity consumption and patient waiting times.",
              "Each indicator is coupled with alert thresholds and review procedures. Clinical teams endorse medical relevance, while energy engineers verify alignment with overall performance objectives."
            ]
          },
          {
            title: "Running supervised pilot phases",
            subtitle: "Testing stages and documentation",
            paragraphs: [
              "Before full rollout, projects undergo supervised pilots. These stages include comparative testing versus existing procedures, detailed energy logs and weekly reviews. Outcomes are captured in the community library.",
              "Documentation covers model versions, training parameters and energy configurations for the concerned areas. Transparency enhances reproducibility and supports scaling decisions."
            ]
          },
          {
            title: "Maintaining continuous post-launch monitoring",
            subtitle: "Dashboards and shared alerts",
            paragraphs: [
              "Once live, hospitals maintain dashboards merging clinical feedback with energy metrics. Automated alerts notify teams about significant drifts or data flow interruptions.",
              "Feedback is discussed during joint committees. Necessary adjustments, whether related to energy calibration or clinical parameters, are logged and shared across Comunidad IA to enhance collective maturity."
            ]
          }
        ]
      },
      post4: {
        lead: "Capability building remains central to successful health-energy AI projects. Hospitals must align technical training, clinical understanding and energy literacy.",
        sections: [
          {
            title: "Mapping competency requirements",
            subtitle: "Role-based and mission-driven approach",
            paragraphs: [
              "Network institutions identify roles involved in AI projects: clinicians, energy specialists, data scientists and quality managers. Each gains a competency map covering AI fundamentals, interpretation of energy indicators and interdisciplinary communication.",
              "This mapping informs modular training plans. Sessions combine short workshops, case studies and reviews of community projects for practical immersion."
            ]
          },
          {
            title: "Creating hybrid learning paths",
            subtitle: "Cross mentoring and shared labs",
            paragraphs: [
              "To break silos, hospitals implement mentored duos pairing clinicians with energy engineers on concrete projects. These tandems foster reciprocal understanding and faster decisions.",
              "Shared labs allow participants to manipulate anonymised datasets and simulate energy scenarios. Teams experiment with model configuration and measure service impacts."
            ]
          },
          {
            title: "Assessing adoption and capitalising",
            subtitle: "Progress dashboards and experience reports",
            paragraphs: [
              "Training evaluation relies on progress dashboards completed by participants. Competencies are validated through concrete projects or case reviews published in the community library.",
              "Feedback fuels practice guides, highlighting obstacles, required resources and the most effective support methods for hospital teams."
            ]
          }
        ]
      },
      post5: {
        lead: "AI systems deployed in hospital environments require continuous oversight to avoid drifts. Energy considerations add requirements around resilience and resource efficiency.",
        sections: [
          {
            title: "Structuring oversight committees",
            subtitle: "Clarified roles and responsibilities",
            paragraphs: [
              "Comunidad IA recommends establishing committees that gather medical staff, energy leads, cybersecurity teams and patient representatives. Each committee defines its supervision perimeter, model acceptability criteria and decision processes for incidents.",
              "Members document critical scenarios such as sensor outages, extreme energy variations or clinical protocol changes. Anticipation improves responsiveness during reviews."
            ]
          },
          {
            title: "Defining vigilance indicators",
            subtitle: "Technical and ethical monitoring",
            paragraphs: [
              "Vigilance dashboards combine technical indicators (latency, sensor availability, consumption) and ethical markers (fairness, adherence to care standards). Each alert triggers an analysis and action plan update.",
              "Members log these analyses in the community library to compare mitigation strategies and adjust alert thresholds collectively."
            ]
          },
          {
            title: "Ensuring traceability and improvement",
            subtitle: "Capturing decisions over time",
            paragraphs: [
              "Every oversight decision is recorded with context, reviewed data and chosen orientations. This traceability supports internal audits and interactions with health authorities.",
              "Insights contribute to shared methodological guides, strengthening collective maturity and encouraging proactive ethical supervision of health-energy AI systems."
            ]
          }
        ]
      }
    },
    contact: {
      hero: {
        badge: "Coordination",
        heading: "Connect with Comunidad IA facilitators.",
        subtitle: "We answer questions about forums, the project board and contributions to the shared library."
      },
      infoTitle: "Direct contact",
      phoneLabel: "Call us",
      emailLabel: "Send an email",
      addressLabel: "Visit the team",
      formTitle: "Contact form",
      formIntro: "Tell us about your needs so we can direct your request to the right coordinators.",
      form: {
        name: "Full name",
        email: "Professional email address",
        organization: "Organization",
        topic: "Topic",
        message: "Detailed message",
        submit: "Send request"
      },
      placeholders: {
        name: "Enter your name",
        email: "Enter your email",
        organization: "Organization name",
        topic: "Select a topic",
        message: "Describe your question or initiative"
      },
      options: {
        general: "General information",
        forum: "Thematic forum",
        project: "Collaborative project",
        library: "Shared library",
        events: "Professional events"
      },
      mapLabel: "Community headquarters located in Madrid."
    },
    faq: {
      hero: {
        badge: "Frequently asked",
        heading: "Understand Comunidad IA structure and processes.",
        subtitle: "Answers are based on the annually updated operating charter."
      },
      items: [
        {
          question: "How are thematic forums facilitated?",
          answer: "Each forum is led by a clinician and an energy specialist. They schedule discussions, validate shared documents and enforce confidentiality rules."
        },
        {
          question: "Who can propose a collaborative project?",
          answer: "Any member institution may publish a project sheet. A committee reviews alignment, dataset description and energy impact before publication."
        },
        {
          question: "How do I access the shared library?",
          answer: "Members receive secure access. Documents are indexed by clinical domain, AI technology and energy component to ease discovery."
        },
        {
          question: "What ethical commitments apply?",
          answer: "The charter embeds supervision, transparency and patient participation requirements. Each project holds regular ethical reviews and shares conclusions within the network."
        },
        {
          question: "How are professional events structured?",
          answer: "Events alternate virtual sessions and in-person gatherings. Minutes, materials and agreed actions are uploaded to the shared library."
        }
      ]
    },
    terms: {
      intro: "These terms govern use of the website and community resources. Access implies full acceptance of the provisions below.",
      sections: [
        {
          title: "1. Purpose",
          body: "This document sets rules for using comunidad-iaenergiahealthspain.com and related collaborative spaces."
        },
        {
          title: "2. Network management",
          body: "The network is coordinated by a multidisciplinary committee ensuring coherence of activities, content quality and legal compliance."
        },
        {
          title: "3. Resource access",
          body: "Access to forums, libraries and project boards is restricted to authorised members. Any attempt at unauthorised access is prohibited."
        },
        {
          title: "4. Member contributions",
          body: "Members commit to publishing accurate information, citing sources and respecting confidentiality rules applicable to their institutions."
        },
        {
          title: "5. Confidentiality",
          body: "Internal exchanges may include sensitive data. Each member must follow the confidentiality protocols defined in the community charter."
        },
        {
          title: "6. Intellectual property",
          body: "Content remains the property of authors. The network receives a non-exclusive licence to share it among members."
        },
        {
          title: "7. Responsible use",
          body: "Resources are to be used for analysis, assessment or coordination purposes. Any use conflicting with medical or energy ethics is forbidden."
        },
        {
          title: "8. System security",
          body: "Users must protect credentials, report suspected incidents and follow communicated cybersecurity guidance."
        },
        {
          title: "9. Changes",
          body: "The committee may amend these terms after consulting members. Updates are communicated through official channels."
        },
        {
          title: "10. Suspension",
          body: "In case of non-compliance, the committee may temporarily or permanently suspend member access."
        },
        {
          title: "11. External links",
          body: "The site may contain links to third-party resources. The network is not responsible for their content or policies."
        },
        {
          title: "12. Responsibilities",
          body: "Each member remains responsible for decisions taken based on the information consulted. The network provides a collaborative framework without replacing institutional obligations."
        },
        {
          title: "13. Governing law",
          body: "These terms are governed by Spanish law. Disputes fall under the competent courts of Madrid."
        },
        {
          title: "14. Contact",
          body: "Questions regarding the terms may be sent to contact@comunidad-iaenergiahealthspain.com."
        }
      ]
    },
    privacy: {
      intro: "This policy explains how Comunidad IA Health-Energy collects, uses and protects personal data within its collaborative activities.",
      sections: [
        {
          title: "1. Controller",
          body: "The coordination committee of Comunidad IA Health-Energy, Calle Innovación 1000, 28027 Madrid, acts as data controller."
        },
        {
          title: "2. Data collected",
          body: "We collect professional identification details, contact information and contributions shared in forums and libraries."
        },
        {
          title: "3. Purposes",
          body: "Data supports resource access management, forum facilitation, collaborative project tracking and community communications."
        },
        {
          title: "4. Legal basis",
          body: "Processing relies on the network’s legitimate interest in organising cooperation and on contractual agreements with member institutions."
        },
        {
          title: "5. Retention",
          body: "Data is stored while membership remains active and then archived for the legally required period."
        },
        {
          title: "6. Sharing",
          body: "Information may be shared with partner institutions involved in a project, subject to confidentiality obligations."
        },
        {
          title: "7. Security",
          body: "Technical and organisational measures protect confidentiality, integrity and availability of data."
        },
        {
          title: "8. Rights",
          body: "Members hold rights of access, rectification, erasure, restriction, objection and portability where applicable."
        },
        {
          title: "9. Exercising rights",
          body: "Requests can be sent to contact@comunidad-iaenergiahealthspain.com. We respond within statutory timeframes."
        },
        {
          title: "10. Updates",
          body: "This policy may be updated. Significant changes will be communicated to members through official channels."
        }
      ]
    },
    cookies: {
      intro: "This policy explains how cookies and similar technologies are used on comunidad-iaenergiahealthspain.com.",
      sections: [
        {
          title: "Cookie usage",
          body: "We use cookies necessary for site operation, as well as preference, analytics and communication cookies subject to your consent."
        },
        {
          title: "Managing consent",
          body: "A banner lets you configure choices. You may adjust preferences at any time via the management link available on the site."
        }
      ],
      table: {
        headers: ["Name", "Provider", "Type", "Purpose", "Duration"],
        rows: [
          ["session_core", "Comunidad IA", "Necessary", "Maintain the session of authenticated members.", "Session"],
          ["pref_lang", "Comunidad IA", "Preferences", "Store the selected language.", "12 months"],
          ["analytics_insight", "Comunidad IA", "Analytics", "Measure resource usage and improve experience.", "9 months"],
          ["outreach_signal", "Comunidad IA", "Marketing", "Identify consulted content for targeted communications.", "6 months"]
        ]
      }
    },
    refund: {
      intro: "This claims policy outlines how Comunidad IA Health-Energy handles correction requests and mediation.",
      sections: [
        {
          title: "1. Purpose",
          body: "Provide a framework for managing claims related to content, access or community processes."
        },
        {
          title: "2. Scope",
          body: "The procedure covers members and partners granted authorised access to resources."
        },
        {
          title: "3. Filing a claim",
          body: "Requests must be submitted through the contact form or email, including context and supporting details."
        },
        {
          title: "4. Acknowledgement",
          body: "An acknowledgement is issued within five business days along with a case reference."
        },
        {
          title: "5. Preliminary review",
          body: "The committee evaluates admissibility, identifies relevant experts and plans review steps."
        },
        {
          title: "6. Investigation",
          body: "Evidence is analysed, members may be interviewed and interim measures can be taken."
        },
        {
          title: "7. Decision",
          body: "A reasoned response is provided outlining agreed adjustments or reasons for rejection."
        },
        {
          title: "8. Corrective actions",
          body: "When corrections are required, a schedule is shared and progress is monitored until closure."
        },
        {
          title: "9. Mediation",
          body: "If disagreement persists, internal mediation involving a member panel may be requested."
        },
        {
          title: "10. Archiving",
          body: "Each case is archived to feed lessons learned and continuous improvement of processes."
        }
      ]
    },
    disclaimer: {
      intro: "Content on this site is provided for informational purposes. It reflects member experience and does not constitute medical, energy or legal advice.",
      sections: [
        {
          title: "No personalised advice",
          body: "Information does not replace specific analyses carried out by institutions or competent authorities."
        },
        {
          title: "Content accuracy",
          body: "We strive for accuracy but cannot ensure absence of errors or continuous updates for every resource."
        },
        {
          title: "Member responsibility",
          body: "Members remain responsible for how they use information and the decisions taken within their organisations."
        },
        {
          title: "External links",
          body: "Links to third-party sites are provided for convenience. Comunidad IA does not control their content."
        },
        {
          title: "Changes",
          body: "The site may evolve without prior notice. Users are invited to review updates regularly."
        }
      ]
    },
    thankyou: {
      hero: {
        badge: "Message received",
        heading: "Thank you for reaching out.",
        subtitle: "Our team will review your request and reply by email once the appropriate coordinator is assigned."
      },
      action: "Return to home"
    },
    notfound: {
      hero: {
        badge: "Unavailable link",
        heading: "The page you requested is no longer accessible.",
        subtitle: "Check the URL or use the main navigation to reach an active resource.",
      },
      action: "Back to home"
    },
    cookiesBanner: {
      title: "Cookie management",
      description: "We use cookies to ensure site functionality and analyse resource usage. Configure your preferences below.",
      acceptAll: "Accept all",
      declineAll: "Decline all",
      save: "Save preferences",
      manage: "Customise cookies",
      categories: {
        necessary: {
          title: "Necessary",
          description: "Essential for site operation.",
          locked: true
        },
        preferences: {
          title: "Preferences",
          description: "Remember your navigation choices."
        },
        analytics: {
          title: "Analytics",
          description: "Measure audience and performance."
        },
        marketing: {
          title: "Communication",
          description: "Adapt shared content to members."
        }
      }
    },
    toasts: {
      formSubmitted: "Your request is being routed to the coordinators."
    }
  }
};

const translate = (key, lang) => {
  const segments = key.split(".");
  let current = I18N[lang];
  for (const segment of segments) {
    if (current && Object.prototype.hasOwnProperty.call(current, segment)) {
      current = current[segment];
    } else {
      return key;
    }
  }
  return current;
};

const setLanguage = lang => {
  const resolvedLang = I18N[lang] ? lang : DEFAULT_LANG;
  localStorage.setItem(LANG_KEY, resolvedLang);
  document.documentElement.lang = resolvedLang;
  applyTranslations(resolvedLang);
  updateLangSwitch(resolvedLang);
};

const applyTranslations = lang => {
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    const value = translate(key, lang);
    if (typeof value === "string") {
      el.textContent = value;
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach(el => {
    const key = el.dataset.i18nHtml;
    const value = translate(key, lang);
    if (typeof value === "string") {
      el.innerHTML = value;
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    const value = translate(key, lang);
    if (typeof value === "string") {
      el.setAttribute("placeholder", value);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach(el => {
    const key = el.dataset.i18nAlt;
    const value = translate(key, lang);
    if (typeof value === "string") {
      el.setAttribute("alt", value);
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach(el => {
    const key = el.dataset.i18nTitle;
    const value = translate(key, lang);
    if (typeof value === "string") {
      el.textContent = value;
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach(el => {
    const key = el.dataset.i18nMeta;
    const value = translate(key, lang);
    if (typeof value === "string") {
      el.setAttribute("content", value);
    }
  });

  document.title = translate(document.title || document.head.querySelector("title").dataset.i18nTitle, lang) || document.title;
};

const updateLangSwitch = lang => {
  document.querySelectorAll(".lang-switch button").forEach(button => {
    button.classList.toggle("is-active", button.dataset.lang === lang);
  });
};

const initLanguage = () => {
  const stored = localStorage.getItem(LANG_KEY);
  const lang = stored && I18N[stored] ? stored : DEFAULT_LANG;
  setLanguage(lang);
  document.querySelectorAll(".lang-switch button").forEach(button => {
    button.addEventListener("click", () => {
      if (button.dataset.lang !== lang) {
        setLanguage(button.dataset.lang);
      } else {
        setLanguage(button.dataset.lang);
      }
    });
  });
};

const initNavigation = () => {
  const toggle = document.querySelector(".mobile-toggle");
  const nav = document.querySelector(".nav-links");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    toggle.classList.toggle("is-active");
    nav.classList.toggle("is-open");
  });
  nav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      toggle.classList.remove("is-active");
      nav.classList.remove("is-open");
    });
  });
};

const initAnimations = () => {
  const animated = document.querySelectorAll("[data-animate]");
  if (!animated.length) return;
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.15
  });
  animated.forEach(el => observer.observe(el));
};

const showToast = key => {
  const lang = localStorage.getItem(LANG_KEY) || DEFAULT_LANG;
  const container = document.getElementById("toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = translate(`toasts.${key}`, lang);
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(12px)";
    setTimeout(() => toast.remove(), 400);
  }, 4000);
};

const initForms = () => {
  document.querySelectorAll("form[data-form]").forEach(form => {
    form.addEventListener("submit", event => {
      if (form.dataset.submitting === "true") return;
      event.preventDefault();
      form.dataset.submitting = "true";
      showToast("formSubmitted");
      setTimeout(() => {
        form.submit();
      }, 600);
    });
  });
};

const getDefaultConsent = () => ({
  necessary: true,
  preferences: false,
  analytics: false,
  marketing: false,
  status: "pending"
});

const saveConsent = consent => {
  localStorage.setItem(COOKIE_KEY, JSON.stringify(consent));
};

const readConsent = () => {
  try {
    const stored = localStorage.getItem(COOKIE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return { ...getDefaultConsent(), ...parsed };
    }
  } catch (error) {
    console.error("Unable to parse consent", error);
  }
  return getDefaultConsent();
};

const applyConsentToUI = consent => {
  document.querySelectorAll("[data-cookie-toggle]").forEach(toggle => {
    const type = toggle.dataset.cookieToggle;
    const locked = toggle.dataset.locked === "true";
    if (locked) {
      toggle.classList.add("is-locked", "is-active");
      toggle.setAttribute("aria-disabled", "true");
    } else {
      toggle.classList.toggle("is-active", Boolean(consent[type]));
    }
  });
};

const initCookieBanner = () => {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;
  const langButtons = document.querySelectorAll(".lang-switch button");
  const consent = readConsent();
  applyConsentToUI(consent);

  const updateTexts = () => {
    const lang = localStorage.getItem(LANG_KEY) || DEFAULT_LANG;
    banner.querySelectorAll("[data-cookie-i18n]").forEach(el => {
      const key = el.dataset.cookieI18n;
      const value = translate(`cookiesBanner.${key}`, lang);
      if (typeof value === "string") {
        el.textContent = value;
      }
    });
    banner.querySelectorAll("[data-cookie-category]").forEach(el => {
      const type = el.dataset.cookieCategory;
      const langObj = translate(`cookiesBanner.categories.${type}`, lang);
      if (!langObj) return;
      el.querySelector("[data-cookie-category-title]").textContent = langObj.title;
      el.querySelector("[data-cookie-category-desc]").textContent = langObj.description;
    });
  };

  updateTexts();
  const langObserver = new MutationObserver(updateTexts);
  langButtons.forEach(button => {
    button.addEventListener("click", () => {
      setTimeout(updateTexts, 50);
    });
  });

  const showBanner = consent.status === "pending";
  if (showBanner) {
    banner.classList.add("is-visible");
  }

  banner.querySelectorAll("[data-cookie-toggle]").forEach(toggle => {
    const type = toggle.dataset.cookieToggle;
    const locked = toggle.dataset.locked === "true";
    if (locked) return;
    toggle.addEventListener("click", () => {
      const current = readConsent();
      current[type] = !current[type];
      saveConsent(current);
      toggle.classList.toggle("is-active");
    });
  });

  const acceptAll = banner.querySelector("[data-cookie-action='accept']");
  const declineAll = banner.querySelector("[data-cookie-action='decline']");
  const save = banner.querySelector("[data-cookie-action='save']");

  acceptAll.addEventListener("click", () => {
    const newConsent = { necessary: true, preferences: true, analytics: true, marketing: true, status: "accepted" };
    saveConsent(newConsent);
    applyConsentToUI(newConsent);
    banner.classList.remove("is-visible");
  });

  declineAll.addEventListener("click", () => {
    const newConsent = { necessary: true, preferences: false, analytics: false, marketing: false, status: "declined" };
    saveConsent(newConsent);
    applyConsentToUI(newConsent);
    banner.classList.remove("is-visible");
  });

  save.addEventListener("click", () => {
    const consentState = readConsent();
    consentState.status = "custom";
    saveConsent(consentState);
    banner.classList.remove("is-visible");
  });

  document.querySelectorAll("[data-cookie-manage]").forEach(link => {
    link.addEventListener("click", event => {
      event.preventDefault();
      const current = readConsent();
      applyConsentToUI(current);
      banner.classList.add("is-visible");
    });
  });
};

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initNavigation();
  initAnimations();
  initForms();
  initCookieBanner();
});