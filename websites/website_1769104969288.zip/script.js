(function () {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  const currentYearEls = document.querySelectorAll('.current-year');
  const langSwitchers = document.querySelectorAll('.language-switcher');
  const body = document.body;
  const storedLangKey = 'JT_PAY_LANG';
  const cookieKey = 'JT_PAY_COOKIE_CHOICE';
  const languagePaths = {
    nl: '/nl/',
    en: '/en/'
  };

  if (currentYearEls.length) {
    const year = new Date().getFullYear();
    currentYearEls.forEach((el) => {
      el.textContent = String(year);
    });
  }

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('is-open');
    });

    primaryNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        primaryNav.classList.remove('is-open');
      });
    });
  }

  if (langSwitchers.length) {
    langSwitchers.forEach((switcher) => {
      switcher.addEventListener('click', (event) => {
        const targetLang = switcher.getAttribute('data-lang');
        const href = switcher.getAttribute('href');
        if (targetLang && href) {
          event.preventDefault();
          localStorage.setItem(storedLangKey, targetLang);
          window.location.href = href;
        }
      });
    });
  }

  const animateTargets = document.querySelectorAll('.animate-on-scroll');
  if (animateTargets.length) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    animateTargets.forEach((target) => observer.observe(target));
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const savedChoice = localStorage.getItem(cookieKey);
    if (!savedChoice) {
      cookieBanner.classList.add('is-visible');
    }
    cookieBanner.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-choice]');
      if (!button) return;
      const choice = button.getAttribute('data-choice');
      localStorage.setItem(cookieKey, choice);
      cookieBanner.classList.remove('is-visible');
    });
  }

  const forms = document.querySelectorAll('form.js-contact-form');
  if (forms.length) {
    forms.forEach((form) => {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const action = form.getAttribute('action') || 'thank-you.html';
        showToast(form.getAttribute('data-toast') || '');
        setTimeout(() => {
          window.location.href = action;
        }, 1600);
      });
    });
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notice';
    toast.textContent = message || 'Submitted successfully.';
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.classList.add('is-visible');
    });
    setTimeout(() => {
      toast.classList.remove('is-visible');
      setTimeout(() => toast.remove(), 400);
    }, 2600);
  }

  if (body.dataset.page === 'root-redirect') {
    const stored = localStorage.getItem(storedLangKey);
    const fallback = body.dataset.defaultLang || 'nl';
    const lang = stored && languagePaths[stored] ? stored : fallback;
    const target = languagePaths[lang] ? languagePaths[lang] + 'index.html' : '/nl/index.html';
    window.location.replace(target);
    return;
  }

  if (!localStorage.getItem(storedLangKey) && body.dataset.lang) {
    localStorage.setItem(storedLangKey, body.dataset.lang);
  }
})();