document.addEventListener("DOMContentLoaded", function () {
    const nav = document.querySelector("nav");
    const navToggle = document.querySelector(".nav-toggle");
    if (nav && navToggle) {
        navToggle.addEventListener("click", function () {
            nav.classList.toggle("open");
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedChoice = localStorage.getItem("ci-cookie-choice");
        if (storedChoice) {
            cookieBanner.classList.add("hidden");
        }
        cookieBanner.querySelectorAll(".cookie-choice").forEach(function (link) {
            link.addEventListener("click", function () {
                const choice = link.getAttribute("data-choice") || "undecided";
                localStorage.setItem("ci-cookie-choice", choice);
                cookieBanner.classList.add("hidden");
            });
        });
    }
});