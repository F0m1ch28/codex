import React, { useEffect, useState } from "react";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("lumina-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("lumina-cookie-consent", "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem("lumina-cookie-consent", "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <h4>We value your privacy</h4>
        <p>
          We use cookies to enhance site navigation, analyze usage, and assist in
          our marketing efforts. Manage your preferences or accept to continue.
        </p>
        <div className="cookie-actions">
          <button onClick={handleDecline} className="btn-outline">
            Decline
          </button>
          <button onClick={handleAccept} className="btn-primary">
            Accept &amp; Continue
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;