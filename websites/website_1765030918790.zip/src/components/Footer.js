import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <div className="footer-brand">
            <span className="brand__logo brand__logo--footer">LC</span>
            <div>
              <p className="footer-title">Lumina Consulting</p>
              <p className="footer-subtitle">
                Navigating transformation with clarity.
              </p>
            </div>
          </div>
          <p className="footer-text">
            We partner with ambitious leaders to architect resilient strategies,
            unlock operational excellence, and power intelligent growth.
          </p>
        </div>

        <div>
          <h4 className="footer-heading">Explore</h4>
          <ul className="footer-links">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="footer-heading">Resources</h4>
          <ul className="footer-links">
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/terms">Terms &amp; Conditions</Link>
            </li>
            <li>
              <a href="#!" aria-label="Visit our insights hub">
                Insights Hub
              </a>
            </li>
            <li>
              <a href="#!" aria-label="Download our latest report">
                Annual Report
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="footer-heading">Contact</h4>
          <ul className="footer-links">
            <li>
              <a href="mailto:hello@luminaconsulting.com">
                hello@luminaconsulting.com
              </a>
            </li>
            <li>
              <a href="tel:+12345678900">+1 (234) 567-8900</a>
            </li>
            <li>120 Innovation Drive, Suite 450</li>
            <li>San Francisco, CA 94107</li>
          </ul>
          <div className="footer-social">
            <a href="#!" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="#!" aria-label="Twitter">
              X / Twitter
            </a>
            <a href="#!" aria-label="YouTube">
              YouTube
            </a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Lumina Consulting. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;