import React from "react";

function Privacy() {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Privacy Policy</h1>
          <p>Effective date: April 24, 2024</p>
        </div>
      </section>
      <section className="container legal-content">
        <h2>1. Overview</h2>
        <p>
          Lumina Consulting respects your privacy. This policy explains how we
          collect, use, and protect personal information.
        </p>

        <h2>2. Information We Collect</h2>
        <p>
          We may collect information you provide through forms, communications,
          or event registrations, as well as analytics data regarding site
          usage.
        </p>

        <h2>3. How We Use Information</h2>
        <p>
          Information is used to deliver services, respond to inquiries, send
          updates, and improve our offerings. We do not sell personal data.
        </p>

        <h2>4. Cookies</h2>
        <p>
          We use cookies to enhance user experience and analyze site
          performance. You can control cookie settings through your browser.
        </p>

        <h2>5. Data Security</h2>
        <p>
          We implement appropriate technical and organizational measures to
          safeguard personal data against unauthorized access or disclosure.
        </p>

        <h2>6. Your Rights</h2>
        <p>
          Depending on your jurisdiction, you may have rights to access, update,
          or delete personal information. Contact us to exercise these rights.
        </p>

        <h2>7. Updates</h2>
        <p>
          We may update this policy periodically. Changes will be posted on this
          page with an updated effective date.
        </p>

        <h2>8. Contact</h2>
        <p>
          For privacy inquiries, email privacy@luminaconsulting.com.
        </p>
      </section>
    </div>
  );
}

export default Privacy;