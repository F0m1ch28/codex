import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

const services = [
  {
    title: "Digital Strategy & Transformation",
    description:
      "Blueprint roadmaps that align emerging technology with commercial objectives, enabling sustainable growth.",
    icon: "🧭",
  },
  {
    title: "Operational Excellence",
    description:
      "Streamline processes, optimize teams, and drive measurable efficiency with data-led decision frameworks.",
    icon: "⚙️",
  },
  {
    title: "Innovation Labs",
    description:
      "Design, prototype, and launch future-ready products with our rapid experimentation playbooks.",
    icon: "🚀",
  },
];

const processSteps = [
  {
    step: "Discover",
    text: "Intensive research sprints to understand your ecosystem, ambitions, and constraints.",
  },
  {
    step: "Design",
    text: "Collaborative design sessions to architect strategies and operating models.",
  },
  {
    step: "Activate",
    text: "Mobilize teams, pilots, and technology to deliver rapid, tangible value.",
  },
  {
    step: "Scale",
    text: "Embed continuous improvement and governance to sustain long-term impact.",
  },
];

const testimonials = [
  {
    quote:
      "Lumina took our transformation vision and made it operational. Their team is the benchmark for strategic partners.",
    name: "Noah Ramirez",
    title: "COO, Vector Dynamics",
  },
  {
    quote:
      "From ideation to market launch, Lumina guided us with rigor and empathy. Our new revenue line exceeded forecasts by 40%.",
    name: "Priya Desai",
    title: "Chief Innovation Officer, Halo Systems",
  },
  {
    quote:
      "The clarity and momentum they brought helped unify our leadership team and accelerate our global expansion.",
    name: "Elena Kovacs",
    title: "CEO, Mondo Logistics",
  },
];

const teamMembers = [
  {
    name: "Maya Chen",
    role: "Founder & Managing Partner",
    image: "https://picsum.photos/400/400?random=31",
    bio: "Architect of transformation programs across Fortune 500 enterprises.",
  },
  {
    name: "Jamal Ortiz",
    role: "Head of Strategy",
    image: "https://picsum.photos/400/400?random=32",
    bio: "Specialist in operating model redesign and cross-functional alignment.",
  },
  {
    name: "Sofia Martins",
    role: "Director, Innovation Labs",
    image: "https://picsum.photos/400/400?random=33",
    bio: "Drives rapid prototyping initiatives that unlock new digital value.",
  },
];

const projects = [
  {
    title: "Global Supply Chain Control Tower",
    category: "Transformation",
    image: "https://picsum.photos/1200/800?random=41",
  },
  {
    title: "AI-Enabled Client Experience",
    category: "Innovation",
    image: "https://picsum.photos/1200/800?random=42",
  },
  {
    title: "Sustainable Operations Framework",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=43",
  },
  {
    title: "Omnichannel Commerce Launch",
    category: "Growth",
    image: "https://picsum.photos/1200/800?random=44",
  },
];

const faqs = [
  {
    question: "What industries does Lumina specialize in?",
    answer:
      "Our consultants bring cross-industry expertise spanning technology, financial services, healthcare, logistics, and consumer products. We tailor every engagement to your specific context.",
  },
  {
    question: "How do you measure project success?",
    answer:
      "We co-create success metrics aligned to business outcomes, such as ROI, time-to-value, operational KPIs, and cultural adoption. Dashboards and retrospectives ensure accountability.",
  },
  {
    question: "What is your typical engagement model?",
    answer:
      "We offer strategic sprints, embedded program leadership, and long-term partnerships. Each combines advisory, implementation, and capability-building components.",
  },
  {
    question: "Can Lumina work with our in-house teams?",
    answer:
      "Absolutely. We thrive in collaborative environments, providing enablement, governance, and coaching so your teams gain lasting capabilities.",
  },
];

const blogPosts = [
  {
    title: "The Operating Model Blueprint for Modern Enterprises",
    date: "April 24, 2024",
    readingTime: "7 min read",
  },
  {
    title: "Designing Innovation Labs that Deliver Commercial Value",
    date: "April 12, 2024",
    readingTime: "5 min read",
  },
  {
    title: "Data-Driven Decisioning: Lessons from High-Performing Teams",
    date: "March 30, 2024",
    readingTime: "8 min read",
  },
];

function Home() {
  const stats = useMemo(
    () => [
      { label: "Projects delivered", value: 320 },
      { label: "Transformation specialists", value: 58 },
      { label: "Client NPS score", value: 72 },
      { label: "Average ROI uplift", value: 168 },
    ],
    []
  );
  const statsRef = useRef(null);
  const [statsActive, setStatsActive] = useState(false);
  const [statValues, setStatValues] = useState(stats.map(() => 0));
  const [activeProjectFilter, setActiveProjectFilter] = useState("All");
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [visibleFaq, setVisibleFaq] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsActive) {
            setStatsActive(true);
          }
        });
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, [statsActive]);

  useEffect(() => {
    if (!statsActive) return;
    const duration = 2000;
    let start = null;
    let animationFrame;

    const animate = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      setStatValues(
        stats.map((stat) => Math.floor(stat.value * progress))
      );
      if (progress < 1) {
        animationFrame = window.requestAnimationFrame(animate);
      }
    };

    animationFrame = window.requestAnimationFrame(animate);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [statsActive, stats]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in");
          }
        });
      },
      { threshold: 0.2 }
    );

    const elements = document.querySelectorAll("[data-animate]");
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    activeProjectFilter === "All"
      ? projects
      : projects.filter(
          (project) => project.category === activeProjectFilter
        );

  return (
    <div className="home-page">
      <section className="hero">
        <div className="hero__content container">
          <p className="eyebrow">Award-winning strategy &amp; innovation firm</p>
          <h1>
            Design the next era of <span>intelligent growth</span>.
          </h1>
          <p className="hero__text">
            Lumina Consulting empowers visionary leaders to reimagine operations,
            activate breakthrough ideas, and scale with confidence. Together, we
            unlock market-leading performance.
          </p>
          <div className="hero__actions">
            <Link to="/contact" className="btn-primary hero__cta">
              Start a Discovery Call
            </Link>
            <Link to="/services" className="btn-outline">
              Explore Our Services
            </Link>
          </div>
        </div>
        <div
          className="hero__image"
          style={{
            backgroundImage:
              "url('https://picsum.photos/1600/900?random=101')",
          }}
          role="img"
          aria-label="Team collaborating in a modern office setting"
        />
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats-grid">
          {stats.map((stat, index) => (
            <div key={stat.label} className="stat-card" data-animate>
              <span className="stat-card__value">
                {statValues[index]}
                {stat.label === "Average ROI uplift" ? "%" : ""}
              </span>
              <span className="stat-card__label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="services container">
        <div className="section-header">
          <p className="eyebrow">What we do</p>
          <h2>Elite strategy services engineered for velocity</h2>
          <p>
            We assemble multidisciplinary teams to orchestrate end-to-end
            transformation programs, aligning technology, people, and process.
          </p>
        </div>
        <div className="services-grid" data-animate>
          {services.map((service) => (
            <article key={service.title} className="service-card">
              <span className="service-card__icon" aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-card__link">
                Learn more
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="process">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Our collaborative approach</p>
            <h2>Designed to deliver momentum at every stage</h2>
          </div>
          <div className="process-grid">
            {processSteps.map((step, index) => (
              <div key={step.step} className="process-step" data-animate>
                <span className="process-step__number">{index + 1}</span>
                <h3>{step.step}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="featured container">
        <div className="featured-grid">
          <div className="featured-text" data-animate>
            <p className="eyebrow">Client spotlight</p>
            <h2>Rewiring global operations for agility</h2>
            <p>
              Lumina partnered with a multinational logistics leader to build a
              digital control tower, harmonize global workflows, and reduce
              operating costs by 23% within nine months.
            </p>
            <ul className="featured-list">
              <li>Unified analytics for 14 markets</li>
              <li>AI-led demand forecasting accuracy increased to 94%</li>
              <li>Change enablement program across 28,000 employees</li>
            </ul>
            <Link to="/about" className="btn-secondary">
              Read the full story
            </Link>
          </div>
          <div className="featured-image" data-animate>
            <img
              src="https://picsum.photos/800/600?random=21"
              alt="Professional meeting discussing strategy"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Voices of partnership</p>
            <h2>Trusted by leaders who shape industries</h2>
          </div>
          <div className="testimonial-slider" data-animate>
            {testimonials.map((item, index) => (
              <article
                key={item.name}
                className={`testimonial-slide ${
                  index === testimonialIndex ? "testimonial-slide--active" : ""
                }`}
              >
                <p className="testimonial-quote">“{item.quote}”</p>
                <p className="testimonial-author">
                  {item.name} <span>{item.title}</span>
                </p>
              </article>
            ))}
            <div className="testimonial-controls">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  className={`testimonial-dot ${
                    idx === testimonialIndex ? "testimonial-dot--active" : ""
                  }`}
                  onClick={() => setTestimonialIndex(idx)}
                  aria-label={`Show testimonial ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team container">
        <div className="section-header">
          <p className="eyebrow">Leadership team</p>
          <h2>Seasoned experts obsessed with client impact</h2>
        </div>
        <div className="team-grid" data-animate>
          {teamMembers.map((member) => (
            <article key={member.name} className="team-card">
              <div className="team-card__image">
                <img
                  src={member.image}
                  alt={`${member.name}, ${member.role}`}
                  loading="lazy"
                />
              </div>
              <div className="team-card__content">
                <h3>{member.name}</h3>
                <p className="team-card__role">{member.role}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="projects container">
        <div className="section-header">
          <p className="eyebrow">Selected work</p>
          <h2>Projects delivering measurable outcomes</h2>
        </div>
        <div className="project-filters">
          {["All", "Transformation", "Innovation", "Strategy", "Growth"].map(
            (category) => (
              <button
                key={category}
                type="button"
                className={`filter-btn ${
                  category === activeProjectFilter ? "filter-btn--active" : ""
                }`}
                onClick={() => setActiveProjectFilter(category)}
              >
                {category}
              </button>
            )
          )}
        </div>
        <div className="projects-grid" data-animate>
          {filteredProjects.map((project) => (
            <article key={project.title} className="project-card">
              <div className="project-card__image">
                <img
                  src={project.image}
                  alt={`${project.title} case study`}
                  loading="lazy"
                />
              </div>
              <div className="project-card__content">
                <span className="project-card__category">
                  {project.category}
                </span>
                <h3>{project.title}</h3>
                <a href="#!" className="project-card__link">
                  View case study
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="faq">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">FAQ</p>
            <h2>Frequently asked questions</h2>
          </div>
          <div className="faq-list" data-animate>
            {faqs.map((faq, index) => (
              <div key={faq.question} className="faq-item">
                <button
                  className="faq-question"
                  onClick={() =>
                    setVisibleFaq((prev) => (prev === index ? null : index))
                  }
                  aria-expanded={visibleFaq === index}
                >
                  {faq.question}
                  <span>{visibleFaq === index ? "-" : "+"}</span>
                </button>
                {visibleFaq === index && (
                  <div className="faq-answer">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog container">
        <div className="section-header">
          <p className="eyebrow">Insights</p>
          <h2>Latest perspectives from our experts</h2>
        </div>
        <div className="blog-grid" data-animate>
          {blogPosts.map((post) => (
            <article key={post.title} className="blog-card">
              <p className="blog-card__meta">
                {post.date} • {post.readingTime}
              </p>
              <h3>{post.title}</h3>
              <a href="#!" className="blog-card__link">
                Read story
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="cta">
        <div className="container cta-box" data-animate>
          <div>
            <p className="eyebrow">Let’s build momentum</p>
            <h2>Ready to activate your next strategic move?</h2>
            <p>
              Partner with Lumina to unlock clarity, accelerate execution, and
              create lasting competitive advantage.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn-primary">
              Schedule a Consultation
            </Link>
            <Link to="/about" className="btn-outline dark-outline">
              Meet the Team
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;