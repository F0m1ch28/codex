import React, { useState } from "react";

function Contact() {
  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) newErrors.name = "Name is required.";
    if (!formValues.email.trim()) {
      newErrors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      newErrors.email = "Enter a valid email address.";
    }
    if (!formValues.message.trim())
      newErrors.message = "Please share how we can help.";
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      // Simulate submission success
      setTimeout(() => {
        setFormValues({ name: "", email: "", company: "", message: "" });
        setSubmitted(false);
      }, 2500);
    }
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>We’d love to hear from you.</h1>
          <p>
            Whether you’re exploring a new initiative or scaling a global
            program, our team is ready to collaborate.
          </p>
        </div>
      </section>

      <section className="container contact-grid">
        <form className="contact-form" onSubmit={handleSubmit} noValidate>
          <h2>Tell us about your goals</h2>
          <div className="form-field">
            <label htmlFor="name">Full name *</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formValues.name}
              onChange={handleChange}
              placeholder="Jane Doe"
            />
            {errors.name && <span className="form-error">{errors.name}</span>}
          </div>
          <div className="form-field">
            <label htmlFor="email">Email *</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formValues.email}
              onChange={handleChange}
              placeholder="jane@company.com"
            />
            {errors.email && <span className="form-error">{errors.email}</span>}
          </div>
          <div className="form-field">
            <label htmlFor="company">Company</label>
            <input
              id="company"
              name="company"
              type="text"
              value={formValues.company}
              onChange={handleChange}
              placeholder="Company name"
            />
          </div>
          <div className="form-field">
            <label htmlFor="message">How can we help? *</label>
            <textarea
              id="message"
              name="message"
              value={formValues.message}
              onChange={handleChange}
              rows="5"
              placeholder="Share your goals, challenges, or ideas."
            />
            {errors.message && (
              <span className="form-error">{errors.message}</span>
            )}
          </div>
          <button type="submit" className="btn-primary" disabled={submitted}>
            {submitted ? "Sending..." : "Submit inquiry"}
          </button>
        </form>

        <div className="contact-info">
          <div className="contact-card">
            <h3>Headquarters</h3>
            <p>120 Innovation Drive, Suite 450</p>
            <p>San Francisco, CA 94107</p>
            <p>
              <a href="tel:+12345678900">+1 (234) 567-8900</a>
            </p>
            <p>
              <a href="mailto:hello@luminaconsulting.com">
                hello@luminaconsulting.com
              </a>
            </p>
          </div>
          <div className="contact-card">
            <h3>Office hours</h3>
            <p>Monday – Friday: 8:30am – 6:00pm PT</p>
            <p>Global support available 24/7 for partner clients.</p>
          </div>
          <div className="contact-card">
            <h3>Stay connected</h3>
            <p>
              Join our newsletter for executive briefings, case studies, and
              innovation insights.
            </p>
            <a href="#!" className="btn-outline dark-outline">
              Subscribe
            </a>
          </div>
        </div>
      </section>

      <section className="map">
        <div className="container">
          <div className="map-embed">
            <img
              src="https://picsum.photos/1200/500?random=61"
              alt="Map view of Lumina Consulting headquarters"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;