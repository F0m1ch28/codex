import React from "react";

const serviceAreas = [
  {
    title: "Transformation Strategy",
    description:
      "From vision to execution, we architect transformation journeys that align leadership, technology, and ways of working.",
    bullets: [
      "Strategy definition and value case modeling",
      "Operating model redesign",
      "Portfolio and roadmap management",
    ],
  },
  {
    title: "Digital & Technology",
    description:
      "Unlock scalable platforms, data ecosystems, and automation programs that accelerate decision-making and performance.",
    bullets: [
      "Cloud modernization & architecture",
      "Data platform strategy & governance",
      "Intelligent automation & AI enablement",
    ],
  },
  {
    title: "Innovation & Growth",
    description:
      "Design and scale innovation capabilities that consistently ship market-ready products and services.",
    bullets: [
      "Innovation labs & venture building",
      "Customer research & product strategy",
      "Go-to-market acceleration",
    ],
  },
  {
    title: "People & Change",
    description:
      "Equip your teams with the mindset, skills, and structures to champion change and sustain impact.",
    bullets: [
      "Change management & adoption",
      "Leadership enablement & coaching",
      "Capability academies & playbooks",
    ],
  },
];

function Services() {
  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Services tailored to your boldest ambitions.</h1>
          <p>
            Lumina Consulting integrates strategy, technology, and people to
            deliver outcomes that matter. Explore how we partner with clients to
            move fast and scale with confidence.
          </p>
        </div>
      </section>

      <section className="container services-detail">
        {serviceAreas.map((service) => (
          <article key={service.title} className="service-detail-card">
            <div>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
            </div>
            <ul className="list-check">
              {service.bullets.map((bullet) => (
                <li key={bullet}>{bullet}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className="cta secondary-cta">
        <div className="container cta-box">
          <div>
            <p className="eyebrow">Let’s co-create impact</p>
            <h2>Co-design a roadmap that accelerates value.</h2>
            <p>
              We’ll assemble a tailored team to address your most critical
              challenges and opportunities.
            </p>
          </div>
          <div className="cta-actions">
            <a href="mailto:hello@luminaconsulting.com" className="btn-primary">
              Email our experts
            </a>
            <a href="tel:+12345678900" className="btn-outline dark-outline">
              Call +1 (234) 567-8900
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Services;