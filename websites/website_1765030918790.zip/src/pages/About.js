import React, { useEffect } from "react";

const teamMembers = [
  {
    name: "Maya Chen",
    role: "Founder & Managing Partner",
    image: "https://picsum.photos/400/400?random=51",
    expertise: "Enterprise transformation, executive alignment, value realization.",
  },
  {
    name: "Jamal Ortiz",
    role: "Head of Strategy",
    image: "https://picsum.photos/400/400?random=52",
    expertise: "Operating model design, M&A integration, strategic roadmapping.",
  },
  {
    name: "Sofia Martins",
    role: "Director, Innovation Labs",
    image: "https://picsum.photos/400/400?random=53",
    expertise: "Product acceleration, experimentation frameworks, customer research.",
  },
  {
    name: "Lucas Reinhardt",
    role: "Chief Technology Officer",
    image: "https://picsum.photos/400/400?random=54",
    expertise: "Cloud modernization, platform engineering, data ecosystems.",
  },
];

function About() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Engineering clarity for leaders who refuse to stand still.</h1>
          <p>
            Lumina Consulting exists to empower ambitious organizations with the
            strategy, operating precision, and innovation capacity required to
            thrive in constantly shifting markets.
          </p>
        </div>
      </section>

      <section className="container split">
        <div>
          <h2>Our mission</h2>
          <p>
            We help organizations orchestrate transformational change that
            delivers measurable value. From the boardroom to the front line, we
            champion inclusive collaboration, bold thinking, and disciplined
            execution.
          </p>
        </div>
        <div>
          <h2>Our principles</h2>
          <ul className="list-check">
            <li>Lead with empathy and evidence.</li>
            <li>Design for resilience and adaptability.</li>
            <li>Champion transparency and shared ownership.</li>
            <li>Deliver results that compound over time.</li>
          </ul>
        </div>
      </section>

      <section className="timeline">
        <div className="container">
          <h2>Our journey</h2>
          <div className="timeline-track">
            <div className="timeline-item">
              <span>2014</span>
              <p>Founded in San Francisco with a vision to reimagine consulting.</p>
            </div>
            <div className="timeline-item">
              <span>2017</span>
              <p>Launched Innovation Labs practice to fuel rapid experimentation.</p>
            </div>
            <div className="timeline-item">
              <span>2020</span>
              <p>
                Expanded globally with offices in London and Singapore to serve
                multinational clients.
              </p>
            </div>
            <div className="timeline-item">
              <span>2023</span>
              <p>
                Recognized as a top boutique strategy firm for delivering
                measurable transformation outcomes.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="team container">
        <div className="section-header">
          <p className="eyebrow">Leadership team</p>
          <h2>Global expertise, unified vision</h2>
        </div>
        <div className="team-grid">
          {teamMembers.map((member) => (
            <article key={member.name} className="team-card">
              <div className="team-card__image">
                <img
                  src={member.image}
                  alt={`${member.name}, ${member.role}`}
                  loading="lazy"
                />
              </div>
              <div className="team-card__content">
                <h3>{member.name}</h3>
                <p className="team-card__role">{member.role}</p>
                <p>{member.expertise}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="container values">
        <div className="section-header">
          <p className="eyebrow">Our values</p>
          <h2>What drives us forward</h2>
        </div>
        <div className="values-grid">
          <div className="value-card">
            <h3>Collective intelligence</h3>
            <p>
              We believe breakthrough ideas emerge when diverse perspectives,
              disciplines, and experiences intersect.
            </p>
          </div>
          <div className="value-card">
            <h3>Relentless curiosity</h3>
            <p>
              Every client challenge is an opportunity to explore, experiment,
              and reimagine how things can work better.
            </p>
          </div>
          <div className="value-card">
            <h3>Integrity in action</h3>
            <p>
              We earn trust by being transparent, accountable, and steadfast in
              our commitments.
            </p>
          </div>
          <div className="value-card">
            <h3>Measured outcomes</h3>
            <p>
              Our success is defined by tangible results that endure long after
              an engagement ends.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;