import React from "react";

function Terms() {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Terms &amp; Conditions</h1>
          <p>Last updated: April 24, 2024</p>
        </div>
      </section>
      <section className="container legal-content">
        <h2>1. Introduction</h2>
        <p>
          These Terms &amp; Conditions govern your use of the Lumina Consulting
          website and services. By accessing this site, you agree to these
          terms.
        </p>

        <h2>2. Services</h2>
        <p>
          All consulting engagements are governed by specific agreements
          executed between Lumina Consulting and our clients. Website content is
          provided for informational purposes only.
        </p>

        <h2>3. Intellectual Property</h2>
        <p>
          All materials, trademarks, and content on this site are owned or
          licensed by Lumina Consulting. Unauthorized use is prohibited.
        </p>

        <h2>4. Confidentiality</h2>
        <p>
          Any confidential information shared with Lumina Consulting will be
          handled in accordance with agreed confidentiality obligations.
        </p>

        <h2>5. Limitation of Liability</h2>
        <p>
          Lumina Consulting is not liable for indirect or consequential damages
          arising from use of this site or our services, to the extent permitted
          by law.
        </p>

        <h2>6. Governing Law</h2>
        <p>
          These terms are governed by the laws of the State of California,
          without regard to conflict of law provisions.
        </p>

        <h2>7. Contact</h2>
        <p>
          For questions regarding these terms, please contact
          hello@luminaconsulting.com.
        </p>
      </section>
    </div>
  );
}

export default Terms;