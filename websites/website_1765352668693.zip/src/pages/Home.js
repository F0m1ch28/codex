import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const HomePage = () => {
  const stats = useMemo(
    () => [
      { label: 'Готовых дизайн-шаблонов', value: 1800, suffix: '+' },
      { label: 'Создателей в каталоге', value: 350, suffix: '+' },
      { label: 'Глобальных площадок', value: 12, suffix: '' },
      { label: 'Среднее время публикации', value: 24, suffix: 'ч' },
    ],
    []
  );

  const [animatedStats, setAnimatedStats] = useState(stats.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const testimonials = [
    {
      quote:
        'DigitalCovers быстро подобрали стиль под мой игровой YouTube. Уже через час после покупки стоит обновленная обложка и шапка.',
      name: 'Артем Савельев',
      role: 'YouTube-автор | 640K подписчиков',
      image: 'https://picsum.photos/200/200?random=31',
    },
    {
      quote:
        'Я сэкономила дни на подготовке визуала для марафона. Понравились пакеты для Instagram Stories и интро для Reels.',
      name: 'Мария Шпак',
      role: 'SMM-стратег',
      image: 'https://picsum.photos/200/200?random=32',
    },
    {
      quote:
        'Как стримеру, важен персональный стиль. Нашёл авторов, которые делают обновления под сезон за считанные часы.',
      name: 'Alex “NightFox”',
      role: 'Twitch-партнёр',
      image: 'https://picsum.photos/200/200?random=33',
    },
  ];

  const categories = [
    {
      title: 'Обложки для YouTube',
      description: 'Выразительные превью для роликов, плейлистов и трансляций с продуманным CTR.',
      image: 'https://picsum.photos/600/400?random=101',
    },
    {
      title: 'TikTok & Shorts',
      description: 'Вертикальные обложки, заставки и элементы брендинга для коротких видео.',
      image: 'https://picsum.photos/600/400?random=102',
    },
    {
      title: 'Баннеры для стримов',
      description: 'Трансляционные сцены, переходы, виджеты и фоллбэки для OBS и Streamlabs.',
      image: 'https://picsum.photos/600/400?random=103',
    },
    {
      title: 'Аватарки и логотипы',
      description: 'Индивидуальный символ или маскот, который считывается на любом устройстве.',
      image: 'https://picsum.photos/600/400?random=104',
    },
  ];

  const popularItems = [
    {
      title: 'Ultimate Creator Pack',
      subtitle: 'Комплект ассетов для YouTube-канала с модульной системой обложек и шапок.',
      image: 'https://picsum.photos/800/600?random=201',
    },
    {
      title: 'Live Stream Neon Kit',
      subtitle: 'Неоновая стилистика для Twitch: сцены, фоллоу-алерты и чат-оверлеи.',
      image: 'https://picsum.photos/800/600?random=202',
    },
    {
      title: 'Podcast Identity System',
      subtitle: 'Арт-дирекшн для подкастов: cover-art, waveform-анимации, карточки гостей.',
      image: 'https://picsum.photos/800/600?random=203',
    },
  ];

  const processSteps = [
    {
      step: '01',
      title: 'Изучите каталог',
      text: 'Отфильтруйте дизайны по платформе, стилю и формату. Каждый шаблон сопровождается превью и рекомендациями.',
    },
    {
      step: '02',
      title: 'Выберите решение',
      text: 'Покупайте отдельные элементы или комплексные наборы. Гибкие лицензии для личного и коммерческого использования.',
    },
    {
      step: '03',
      title: 'Внесите правки',
      text: 'Получите доступ к файлам и инструкциям. При необходимости закажите кастомизацию у автора набора.',
    },
    {
      step: '04',
      title: 'Запускайте контент',
      text: 'Размещайте обновлённую графику и отслеживайте рост вовлечённости. Мы подскажем, как усилить визуальную стратегию.',
    },
  ];

  const projects = [
    {
      title: 'Esports Vision',
      category: 'YouTube',
      description: 'Редизайн киберспортивного канала с акцентом на динамичные обложки и live-интро.',
      image: 'https://picsum.photos/1200/800?random=301',
    },
    {
      title: 'Calm Podcast Stories',
      category: 'Podcasts',
      description: 'Нежная айдентика для mindful-подкаста с анимацией waveform.',
      image: 'https://picsum.photos/1200/800?random=302',
    },
    {
      title: 'Midnight Streams',
      category: 'Twitch',
      description: 'Серия тёмных сцен, alert-окон и чата для вечерних трансляций.',
      image: 'https://picsum.photos/1200/800?random=303',
    },
    {
      title: 'IRL Travel Vlogs',
      category: 'YouTube',
      description: 'Лайфстайл-обложки с живыми кадрами и адаптивной типографикой.',
      image: 'https://picsum.photos/1200/800?random=304',
    },
  ];

  const team = [
    {
      name: 'Наталья Грант',
      role: 'Creative Director',
      bio: '10 лет в креативном продакшене, курирует подбор авторов и визуальные стандарты платформы.',
      image: 'https://picsum.photos/400/400?random=401',
    },
    {
      name: 'Илья Романов',
      role: 'Head of Product',
      bio: 'Отвечает за UX каталога, интеграцию с инструментами стримеров и аналитику тенденций.',
      image: 'https://picsum.photos/400/400?random=402',
    },
    {
      name: 'Lea Martinez',
      role: 'Community Manager',
      bio: 'Поддерживает авторов и покупателей, организует коллаборации и обучающие эфиры.',
      image: 'https://picsum.photos/400/400?random=403',
    },
  ];

  const blogPosts = [
    {
      title: 'Как собрать визуальный стиль канала за выходные',
      description:
        'Пошаговое руководство по работе с шаблонами DigitalCovers и чек-лист для проверки брендинга.',
      image: 'https://picsum.photos/800/600?random=501',
      date: '15 января 2024',
    },
    {
      title: 'Руководство по обложкам YouTube в 2024 году',
      description:
        'Разбираем актуальные тренды типографики, фото и композиции для кликабельных превью.',
      image: 'https://picsum.photos/800/600?random=502',
      date: '05 января 2024',
    },
    {
      title: 'Как стримерам выделиться на Twitch: советы авторов',
      description:
        'Собрали инструменты, которые используют топовые дизайнеры платформы для оформления сцен и виджетов.',
      image: 'https://picsum.photos/800/600?random=503',
      date: '20 декабря 2023',
    },
  ];

  const [projectFilter, setProjectFilter] = useState('Все');

  useEffect(() => {
    const intervals = stats.map((stat, index) => {
      let current = 0;
      const increment = Math.ceil(stat.value / 40);
      return setInterval(() => {
        current += increment;
        if (current >= stat.value) {
          current = stat.value;
          clearInterval(intervals[index]);
        }
        setAnimatedStats((prev) => {
          const updated = [...prev];
          updated[index] = current;
          return updated;
        });
      }, 40);
    });

    return () => {
      intervals.forEach((interval) => clearInterval(interval));
    };
  }, [stats]);

  useEffect(() => {
    const slider = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(slider);
  }, [testimonials.length]);

  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.innerHTML = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'DigitalCovers',
      url: 'https://digitalcovers.ru',
      logo: 'https://picsum.photos/200/200?random=99',
      contactPoint: [
        {
          '@type': 'ContactPoint',
          email: 'support@digitalcovers.ru',
          telephone: '+7 (495) 123-45-67',
          contactType: 'customer support',
          areaServed: 'Worldwide',
        },
      ],
    });
    document.head.appendChild(script);
    return () => {
      document.head.removeChild(script);
    };
  }, []);

  const filteredProjects =
    projectFilter === 'Все'
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  return (
    <>
      <SEO
        title="DigitalCovers — готовые дизайны для YouTube, TikTok и стримов"
        description="Маркетплейс DigitalCovers помогает контент-мейкерам найти обложки, баннеры и дизайн-наборы для YouTube, TikTok, Twitch и других платформ."
      />
      <section
        className={styles.hero}
        style={{
          backgroundImage: 'url(https://picsum.photos/1600/900?random=1)',
        }}
      >
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>Международная площадка дизайна</span>
            <h1>
              Готовые обложки и графика <br /> для роста вашего контента
            </h1>
            <p>
              Мы соединяем создателей и дизайнеров по всему миру. Подберите визуал, который усилит ваш канал,
              подкаст или стрим и поможет аудитории запомнить ваш стиль.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kategorii" className={styles.primaryButton}>
                Смотреть каталог
              </Link>
              <Link to="/dlya-avtorov" className={styles.secondaryButton}>
                Присоединиться как автор
              </Link>
            </div>
            <div className={styles.heroMeta}>
              <span>🔄 Пополнение каталога ежедневно</span>
              <span>🛡️ Проверка качества и лицензий</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {animatedStats[index]}
                  {stat.suffix}
                </span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Категории дизайнов</h2>
            <p>
              Сфокусируйтесь на своей аудитории — мы уже подготовили коллекции для всех ключевых платформ и форматов.
            </p>
          </div>
          <div className={styles.categoryGrid}>
            {categories.map((category) => (
              <article key={category.title} className={styles.categoryCard}>
                <img
                  src={category.image}
                  alt={category.title}
                  loading="lazy"
                />
                <div className={styles.cardBody}>
                  <h3>{category.title}</h3>
                  <p>{category.description}</p>
                  <Link to="/kategorii" aria-label={`Подробнее о категории ${category.title}`}>
                    Перейти в каталог →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className="container">
          <div className={styles.sectionHeaderCenter}>
            <h2>Почему DigitalCovers</h2>
            <p>
              Мы собрали лучшие практики дизайна для видеоконтента и завернули их в удобный сервис.
            </p>
          </div>
          <div className={styles.benefitsGrid}>
            <div className={styles.benefitCard}>
              <h3>Проверенные авторы</h3>
              <p>
                Каждый дизайнер проходит кураторский отбор. Мы проверяем портфолио, уровень исполнения и соответствие стандартам платформ.
              </p>
            </div>
            <div className={styles.benefitCard}>
              <h3>Умная персонализация</h3>
              <p>
                Подбирайте шаблоны по нише, цветовой палитре и динамике. Алгоритм рекомендует решения на основе ваших предыдущих загрузок.
              </p>
            </div>
            <div className={styles.benefitCard}>
              <h3>Инструкции и поддержка</h3>
              <p>
                Каждая покупка сопровождается гайдами по внедрению и адаптации. Команда поддержки поможет с техническими вопросами.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Популярные наборы недели</h2>
            <p>Комплексные решения для тех, кто хочет обновить всю экосистему визуала за один раз.</p>
          </div>
          <div className={styles.popularGrid}>
            {popularItems.map((item) => (
              <article key={item.title} className={styles.popularCard}>
                <img src={item.image} alt={item.title} loading="lazy" />
                <div className={styles.cardBody}>
                  <h3>{item.title}</h3>
                  <p>{item.subtitle}</p>
                  <Link to="/nabori">Подробнее о наборе →</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className="container">
          <div className={styles.sectionHeaderCenter}>
            <h2>Как это работает</h2>
            <p>Простой путь от вдохновения к обновленному каналу.</p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.step} className={styles.processCard}>
                <span className={styles.stepBadge}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Портфолио авторов</h2>
            <p>Посмотрите, как дизайнеры DigitalCovers трансформируют каналы наших клиентов.</p>
          </div>
          <div className={styles.filterBar}>
            {['Все', 'YouTube', 'Twitch', 'Podcasts'].map((filter) => (
              <button
                type="button"
                key={filter}
                className={`${styles.filterButton} ${
                  projectFilter === filter ? styles.filterButtonActive : ''
                }`}
                onClick={() => setProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.cardBody}>
                  <span className={styles.projectTag}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className="container">
          <div className={styles.sectionHeaderCenter}>
            <h2>Отзывы сообществ</h2>
          </div>
          <div className={styles.testimonialSlider}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
              >
                <img src={testimonial.image} alt={testimonial.name} loading="lazy" />
                <blockquote>“{testimonial.quote}”</blockquote>
                <footer>
                  <h4>{testimonial.name}</h4>
                  <span>{testimonial.role}</span>
                </footer>
              </article>
            ))}
            <div className={styles.sliderDots}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  aria-label={`Переключить отзыв ${index + 1}`}
                  className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Команда платформы</h2>
            <p>Эксперты, которые помогают дизайнерам и создателям контента находить общий язык.</p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.cardBody}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Последние заметки блога</h2>
            <p>Подборки инсайтов, кейсы авторов и тренды визуального контента.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.cardBody}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.description}</p>
                  <Link to="/blog">Читать далее →</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Готовы обновить визуал канала?</h2>
              <p>
                Подберите готовый шаблон или соберите набор в пару кликов. DigitalCovers — ваш партнер по дизайну,
                который работает 24/7 и поддерживает контент на всех площадках.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/kategorii" className={styles.primaryButton}>
                Начать подбор
              </Link>
              <Link to="/kontakti" className={styles.secondaryButton}>
                Связаться с нами
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;