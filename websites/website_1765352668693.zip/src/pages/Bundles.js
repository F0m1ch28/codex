import React from 'react';
import SEO from '../components/SEO';
import styles from './Bundles.module.css';

const BundlesPage = () => {
  const bundles = [
    {
      title: 'Creator Launch Suite',
      description:
        'Стартовый пакет для YouTube и TikTok: обложки, интро-шаблоны, кадры для шортов и шапка канала. Включает универсальную палитру и шрифтовой сет.',
      deliverables: ['20 вариантов обложек', '5 анимированных интро', 'Гайд по брендингу'],
      style: 'https://picsum.photos/800/600?random=701',
    },
    {
      title: 'Streamers Studio Pack',
      description:
        'Профессиональная сцена для стримов: экран ожидания, сцены BRB, чат-оверлей, панели донатов и оверлей для новых подписчиков.',
      deliverables: ['7 сцен для OBS', 'Пакет алертов', 'Эмодзи и бейджи'],
      style: 'https://picsum.photos/800/600?random=702',
    },
    {
      title: 'Podcast Visual Identity',
      description:
        'Айдентика для подкастов: cover-art, шаблоны эпизодов, посты для соцсетей и waveform-анимации.',
      deliverables: ['Cover-art серии', 'Шаблоны для гость+тема', 'Анимированный waveform'],
      style: 'httpsum.photos/800/600?random=703',
    },
    {
      title: 'Brand Refresh Reloaded',
      description:
        'Комплексный ребрендинг канала: moodboard, палитра, шапки, превью, lower thirds. Подходит для каналов, которые сменили нишу или формат.',
      deliverables: ['Moodboard', 'UI kit', 'Гайдлайн по использованию'],
      style: 'https://picsum.photos/800/600?random=704',
    },
  ];

  return (
    <>
      <SEO
        title="Готовые дизайн-наборы DigitalCovers"
        description="Подберите готовые наборы DigitalCovers: стартовые комплекты для каналов, пакеты для стримеров и визуальные системы для подкастов."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Готовые наборы для быстрого запуска</h1>
          <p>
            Комплектные решения с инструкциями по внедрению. Выбирайте тему, получайте файлы и обновляйте визуал
            без долгих брифов.
          </p>
        </div>
      </section>
      <section className={styles.collection}>
        <div className="container">
          <div className={styles.grid}>
            {bundles.map((bundle) => (
              <article key={bundle.title} className={styles.card}>
                <img src={bundle.style} alt={bundle.title} loading="lazy" />
                <div className={styles.body}>
                  <h2>{bundle.title}</h2>
                  <p>{bundle.description}</p>
                  <ul>
                    {bundle.deliverables.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                  <button type="button">Запросить детали</button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default BundlesPage;