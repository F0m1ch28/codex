import React from 'react';
import SEO from '../components/SEO';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => (
  <>
    <SEO
      title="Политика использования файлов cookie DigitalCovers"
      description="Узнайте, как DigitalCovers использует файлы cookie и как можно изменить настройки."
    />
    <section className={styles.section}>
      <div className="container">
        <h1>Политика использования файлов cookie</h1>
        <p>Дата обновления: 15 января 2024 года</p>
        <h2>1. Что такое cookie</h2>
        <p>
          Cookie — это небольшие файлы, которые сохраняются на вашем устройстве для обеспечения корректной работы сайта и персонализации.
        </p>
        <h2>2. Какие cookie мы используем</h2>
        <ul>
          <li>Технические — обеспечивают авторизацию и навигацию.</li>
          <li>Аналитические — помогают нам понимать, как используется сайт.</li>
          <li>Функциональные — запоминают ваши выборы и настройки.</li>
        </ul>
        <h2>3. Управление cookie</h2>
        <p>
          Вы можете изменить решение о согласии в любой момент, очистив cookie в браузере или обратившись в поддержку.
          Также доступна опция «Отклонить» в появляющемся баннере.
        </p>
        <h2>4. Контакты</h2>
        <p>
          По вопросам, связанным с cookie, пишите на <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;