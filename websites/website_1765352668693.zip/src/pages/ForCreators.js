import React from 'react';
import SEO from '../components/SEO';
import styles from './ForCreators.module.css';

const ForCreatorsPage = () => {
  const perks = [
    {
      title: 'Глобальная аудитория',
      description: 'Ваши работы увидят авторы из 92 стран. Платформа локализована и поддерживает гибкие лицензии.',
    },
    {
      title: 'Прозрачные условия',
      description: 'Вы получаете доход с каждой продажи и повторной лицензии. Вся статистика доступна в личном кабинете.',
    },
    {
      title: 'Маркетинговая поддержка',
      description: 'Мы выводим лучшие наборы в рассылки, на главную и в подборки блогеров.',
    },
    {
      title: 'Инструменты и аналитика',
      description: 'Загружайте пакеты, добавляйте инструкции, получайте отзывы и статистику конверсий.',
    },
  ];

  const steps = [
    'Подайте заявку и загрузите портфолио.',
    'Получите обратную связь от кураторов и рекомендации по пакетам.',
    'Разместите первые наборы и настройте лицензионные условия.',
    'Отслеживайте результаты в кабинете и участвуйте в акселераторах.',
  ];

  return (
    <>
      <SEO
        title="Для авторов DigitalCovers — присоединяйтесь к платформе"
        description="Присоединяйтесь к DigitalCovers как автор дизайна. Получайте клиентов по всему миру, аналитику продаж и поддержку кураторов."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Продавайте свои дизайн-наборы на DigitalCovers</h1>
          <p>
            Мы создаём пространство, где дизайнеры зарабатывают на аудитории создателей контента, а кураторы помогают
            развиваться и паковать идеи.
          </p>
          <a href="mailto:authors@digitalcovers.ru" className={styles.applyButton}>
            Отправить портфолио → authors@digitalcovers.ru
          </a>
        </div>
      </section>
      <section className={styles.perks}>
        <div className="container">
          <div className={styles.grid}>
            {perks.map((perk) => (
              <article key={perk.title} className={styles.card}>
                <h2>{perk.title}</h2>
                <p>{perk.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className={styles.steps}>
        <div className="container">
          <h2>Как стать автором</h2>
          <ol>
            {steps.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>
        </div>
      </section>
    </>
  );
};

export default ForCreatorsPage;