import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contact.module.css';

const ContactsPage = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    topic: '',
    message: '',
  });
  const [formStatus, setFormStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formState.name || !formState.email || !formState.message) {
      setFormStatus({ type: 'error', message: 'Заполните обязательные поля.' });
      return;
    }
    if (!validateEmail(formState.email)) {
      setFormStatus({ type: 'error', message: 'Укажите корректный email.' });
      return;
    }
    setFormStatus({
      type: 'success',
      message: 'Спасибо! Мы свяжемся с вами в ближайшее время.',
    });
    setFormState({ name: '', email: '', topic: '', message: '' });
  };

  return (
    <>
      <SEO
        title="Контакты DigitalCovers — свяжитесь с нашей командой"
        description="Свяжитесь с DigitalCovers по вопросам сотрудничества, поддержки и авторства. Электронная почта, телефон и адрес офиса."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Контакты DigitalCovers</h1>
          <p>
            Наша команда готова помочь с подбором продуктов, подключением авторов и партнерскими проектами.
            Выберите удобный способ связи.
          </p>
        </div>
      </section>
      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.card}>
              <h2>Связаться напрямую</h2>
              <ul>
                <li>
                  Email поддержки:<br />
                  <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a>
                </li>
                <li>
                  Для авторов:<br />
                  <a href="mailto:authors@digitalcovers.ru">authors@digitalcovers.ru</a>
                </li>
                <li>
                  Телефон:<br />
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  Адрес:<br />
                  123112, г. Москва, Пресненская наб., д. 12, офис 401
                </li>
              </ul>
            </div>
            <form className={styles.form} onSubmit={handleSubmit}>
              <h2>Напишите нам</h2>
              <div className={styles.fieldGroup}>
                <label htmlFor="name">Имя*</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formState.name}
                  onChange={handleChange}
                  placeholder="Как к вам обращаться"
                  required
                />
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="email">Email*</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formState.email}
                  onChange={handleChange}
                  placeholder="example@mail.com"
                  required
                />
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="topic">Тема сообщения</label>
                <select id="topic" name="topic" value={formState.topic} onChange={handleChange}>
                  <option value="">Выберите тему</option>
                  <option value="support">Поддержка</option>
                  <option value="partnership">Партнерство</option>
                  <option value="creators">Авторство</option>
                  <option value="other">Другое</option>
                </select>
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="message">Сообщение*</label>
                <textarea
                  id="message"
                  name="message"
                  rows="4"
                  value={formState.message}
                  onChange={handleChange}
                  placeholder="Опишите ваш запрос"
                  required
                />
              </div>
              <button type="submit">Отправить сообщение</button>
              {formStatus.message && (
                <p className={formStatus.type === 'error' ? styles.error : styles.success}>
                  {formStatus.message}
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactsPage;