import React from 'react';
import SEO from '../components/SEO';
import styles from './Services.module.css';

const CategoriesPage = () => {
  const categories = [
    {
      title: 'Обложки для YouTube',
      description:
        'Подборка статичных и анимированных превью. Наборы включают PSD/FIG и инструкции по адаптации.',
      features: ['CTR-ориентированная типографика', 'Гайды по адаптации под Shorts', 'Цветовые схемы под разные жанры'],
      image: 'https://picsum.photos/800/600?random=601',
    },
    {
      title: 'TikTok, Reels и Shorts',
      description:
        'Вертикальные превью, переходы и титры для клипов. Актуальные размеры и безопасные зоны для каждой платформы.',
      features: ['Стили для челленджей и влогов', 'Моушн-шаблоны After Effects', 'Наборы с вариативными цветами'],
      image: 'https://picsum.photos/800/600?random=602',
    },
    {
      title: 'Twitch и стриминг',
      description:
        'Комплексные пакеты для стримеров: стартовые сцены, экран ожидания, донат панели и виджеты чата.',
      features: ['Совместимость с OBS и Streamlabs', 'Анимации в формате WebM', 'Системы для смены сезонов'],
      image: 'https://picsum.photos/800/600?random=603',
    },
    {
      title: 'Аватарки и логотипы',
      description:
        'Персональная идентичность: маскоты, эмблемы, минималистичные логотипы и авторские иллюстрации.',
      features: ['Лицензия для мерча', 'Версии для темной и светлой темы', 'Сопровождающие гайды по использованию'],
      image: 'https://picsum.photos/800/600?random=604',
    },
    {
      title: 'Баннеры и обложки каналов',
      description:
        'Шапки для YouTube, Discord, Spotify и платформ подкастов. Учитываем зоны отображения на мобильных и ТВ.',
      features: ['Сетки для адаптивности', 'Векторные элементы', 'Оптимизированные файлы для быстрой загрузки'],
      image: 'https://picsum.photos/800/600?random=605',
    },
    {
      title: 'Digital merch и патроны',
      description:
        'Карточки для Patreon, Badges, эмодзи и стикеры для подписчиков, сезонные коллекции для фанатов.',
      features: ['Эксклюзивные варианты подписок', 'Готовые размеры для платформ', 'Коммерческое использование включено'],
      image: 'https://picsum.photos/800/600?random=606',
    },
  ];

  return (
    <>
      <SEO
        title="Категории продуктов DigitalCovers — графика для контент-мейкеров"
        description="Изучите категории маркетплейса DigitalCovers: обложки для YouTube, TikTok, баннеры стримов, логотипы и другие цифровые решения."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Категории дизайнов DigitalCovers</h1>
          <p>
            Мы собрали коллекции под каждую платформу и жанр. Найдите решения, которые поддержат ваш контент
            и сохранят единый визуальный стиль.
          </p>
        </div>
      </section>
      <section className={styles.catalog}>
        <div className="container">
          <div className={styles.grid}>
            {categories.map((category) => (
              <article key={category.title} className={styles.card}>
                <img src={category.image} alt={category.title} loading="lazy" />
                <div className={styles.content}>
                  <h2>{category.title}</h2>
                  <p>{category.description}</p>
                  <ul>
                    {category.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default CategoriesPage;