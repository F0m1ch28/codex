import React from 'react';
import SEO from '../components/SEO';
import styles from './Blog.module.css';

const BlogPage = () => {
  const posts = [
    {
      title: 'Гайд по дизайну заставок для стримов',
      excerpt:
        'Рассказываем, как использовать динамику, переходы и часы обратного отсчёта, чтобы удерживать зрителей перед началом эфира.',
      image: 'https://picsum.photos/900/600?random=801',
      author: 'DigitalCovers Studio',
      date: '2 февраля 2024',
    },
    {
      title: 'Цветовые тренды в обложках игрового контента',
      excerpt:
        'Как яркие градиенты и неон сочетаются с читабельностью: подборка лучших решений с примерами из каталога.',
      image: 'https://picsum.photos/900/600?random=802',
      author: 'Маргарита Осипова',
      date: '28 января 2024',
    },
    {
      title: 'Репозиционирование канала: кейс travel-блогера',
      excerpt:
        'Как автор из travel-ниши обновил визуал, сохранил узнаваемость и увеличил вовлечённость на 37%.',
      image: 'https://picsum.photos/900/600?random=803',
      author: 'Команда DigitalCovers',
      date: '19 января 2024',
    },
  ];

  return (
    <>
      <SEO
        title="Блог DigitalCovers — инсайты для авторов и дизайнеров"
        description="Читайте блог DigitalCovers: кейсы, тренды и практические советы по визуальному оформлению каналов и стримов."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Блог и полезные материалы</h1>
          <p>
            Кураторы DigitalCovers делятся свежими трендами визуала, интервью с авторами и дорожными картами
            для разных площадок. Укрепляйте свою экспертизу и вдохновляйтесь кейсами.
          </p>
        </div>
      </section>
      <section className={styles.feed}>
        <div className="container">
          <div className={styles.grid}>
            {posts.map((post) => (
              <article key={post.title} className={styles.post}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.body}>
                  <span className={styles.meta}>{post.date} · {post.author}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <button type="button">Читать полностью</button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default BlogPage;