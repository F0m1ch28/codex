import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Faq.module.css';

const FaqPage = () => {
  const questions = [
    {
      question: 'Как происходит покупка и получение файлов?',
      answer:
        'После выбора продукта вы переходите к оформлению. Сразу после оплаты в личном кабинете появляются ссылки на скачивание и инструкции авторов.',
    },
    {
      question: 'Можно ли заказать кастомизацию шаблона?',
      answer:
        'Да, большинство авторов предлагают услуги кастомизации. Вы можете оставить запрос прямо со страницы продукта или написать в поддержку.',
    },
    {
      question: 'Какие лицензии доступны?',
      answer:
        'Для каждого набора указаны лицензии: личное использование, коммерческое использование и расширенное использование. Выбирайте пакет, который соответствует вашим задачам.',
    },
    {
      question: 'С какими форматами файлов я буду работать?',
      answer:
        'Основные форматы: PSD, FIG, AI, AE и готовые экспортированные PNG/JPG/WebM. В описании указаны все доступные форматы и рекомендуемые программы.',
    },
    {
      question: 'Можно ли вернуть покупку?',
      answer:
        'Если продукт не соответствует описанию или имеет технические проблемы, напишите в поддержку в течение 7 дней — мы поможем решить ситуацию.',
    },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  const toggleQuestion = (index) => {
    setActiveIndex((prev) => (prev === index ? -1 : index));
  };

  return (
    <>
      <SEO
        title="FAQ DigitalCovers — ответы на популярные вопросы"
        description="Часто задаваемые вопросы о покупке дизайнов, лицензиях и кастомизации на платформе DigitalCovers."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Часто задаваемые вопросы</h1>
          <p>Мы собрали ответы на популярные вопросы о покупках, лицензиях и работе с авторами.</p>
        </div>
      </section>
      <section className={styles.accordionSection}>
        <div className="container">
          <div className={styles.accordion}>
            {questions.map((item, index) => (
              <article key={item.question} className={styles.item}>
                <button
                  type="button"
                  className={styles.trigger}
                  onClick={() => toggleQuestion(index)}
                  aria-expanded={activeIndex === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.icon}>{activeIndex === index ? '−' : '+'}</span>
                </button>
                <div
                  className={`${styles.panel} ${activeIndex === index ? styles.panelOpen : ''}`}
                  role="region"
                >
                  <p>{item.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default FaqPage;