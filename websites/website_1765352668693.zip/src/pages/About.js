import React from 'react';
import SEO from '../components/SEO';
import styles from './About.module.css';

const AboutPage = () => (
  <>
    <SEO
      title="О платформе DigitalCovers"
      description="DigitalCovers — команда дизайнеров и продюсеров, создающая готовые решения для контент-мейкеров по всему миру."
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>О платформе DigitalCovers</h1>
        <p>
          DigitalCovers появилась как ответ на запрос создателей, которым нужен быстрый и качественный дизайн под каждую площадку. 
          Мы объединили дизайнеров, кураторов и заботу о деталях, чтобы помочь авторам выпускать визуально цельный контент.
        </p>
      </div>
    </section>
    <section className={styles.values}>
      <div className="container">
        <div className={styles.grid}>
          <article>
            <h2>Поддержка создателей</h2>
            <p>
              Мы сопровождаем авторов на всех этапах: от первого заказа до стратегии рефреша бренда. 
              Наша команда помогает подобрать наборы, адаптировать шаблоны и анализировать результаты.
            </p>
          </article>
          <article>
            <h2>Сообщество дизайнеров</h2>
            <p>
              DigitalCovers — это curated-площадка. Мы инвестируем время в отбор авторов, устраиваем ревью и сессии,
              укрепляя сообщество и повышая качество каталога.
            </p>
          </article>
          <article>
            <h2>Технологии</h2>
            <p>
              Платформа поддерживает автоматизированные обновления, гибкие фильтры и интеграции с инструментами 
              контент-мейкеров. Мы строим продукт, который экономит время и делает визуал стратегическим активом.
            </p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default AboutPage;