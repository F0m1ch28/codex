import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import CategoriesPage from './pages/Services';
import BundlesPage from './pages/Bundles';
import ForCreatorsPage from './pages/ForCreators';
import BlogPage from './pages/Blog';
import FaqPage from './pages/Faq';
import ContactsPage from './pages/Contact';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';
import AboutPage from './pages/About';

function RouteChangeHandler() {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
}

function App() {
  return (
    <>
      <Header />
      <RouteChangeHandler />
      <main className="app-main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/kategorii" element={<CategoriesPage />} />
          <Route path="/nabori" element={<BundlesPage />} />
          <Route path="/dlya-avtorov" element={<ForCreatorsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/faq" element={<FaqPage />} />
          <Route path="/kontakti" element={<ContactsPage />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsPage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
          <Route path="/o-platforme" element={<AboutPage />} />
          <Route path="/resheniya" element={<CategoriesPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </>
  );
}

export default App;