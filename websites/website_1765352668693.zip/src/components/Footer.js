import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <div className={styles.logo}>
            <span>DC</span>
          </div>
          <p>
            DigitalCovers — международный маркетплейс цифрового дизайна для видеокреаторов, стримеров и брендов.
            Наша миссия — помогать контент-мейкерам выделяться и усиливать свою идентичность.
          </p>
        </div>
        <div className={styles.column}>
          <h4>Навигация</h4>
          <Link to="/kategorii">Категории</Link>
          <Link to="/nabori">Готовые наборы</Link>
          <Link to="/dlya-avtorov">Для авторов</Link>
          <Link to="/faq">FAQ</Link>
          <Link to="/blog">Блог</Link>
        </div>
        <div className={styles.column}>
          <h4>Документы</h4>
          <Link to="/usloviya-ispolzovaniya">Условия использования</Link>
          <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
          <Link to="/politika-cookie">Политика cookie</Link>
          <Link to="/o-platforme">О платформе</Link>
          <Link to="/kontakti">Контакты</Link>
        </div>
        <div className={styles.column}>
          <h4>Связаться с нами</h4>
          <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a>
          <a href="mailto:authors@digitalcovers.ru">authors@digitalcovers.ru</a>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <address className={styles.address}>
            123112, г. Москва,
            <br />
            Пресненская наб., д. 12,
            <br />
            офис 401
          </address>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</span>
        <div className={styles.socials}>
          <a href="https://www.behance.net" target="_blank" rel="noreferrer" aria-label="Behance DigitalCovers">
            Behance
          </a>
          <a href="https://www.dribbble.com" target="_blank" rel="noreferrer" aria-label="Dribbble DigitalCovers">
            Dribbble
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube DigitalCovers">
            YouTube
          </a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;