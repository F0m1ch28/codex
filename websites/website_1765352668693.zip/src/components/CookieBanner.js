import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('digitalcovers_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem('digitalcovers_cookie_consent', value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Мы используем файлы cookie</h4>
        <p>
          DigitalCovers применяет cookie для персонализации рекомендаций и аналитики. Вы можете изменить своё решение в любой момент.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleConsent('accepted')}>
            Принять
          </button>
          <button type="button" className={styles.secondary} onClick={() => handleConsent('declined')}>
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;