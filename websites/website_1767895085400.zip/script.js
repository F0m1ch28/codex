document.addEventListener('DOMContentLoaded', () => {
    const consentKey = 'gcwCookieConsent';
    const banner = document.querySelector('.cookie-banner');
    if (banner && !localStorage.getItem(consentKey)) {
        banner.classList.add('show');
        banner.querySelectorAll('button').forEach(button => {
            button.addEventListener('click', () => {
                const decision = button.classList.contains('button-accept') ? 'accepted' : 'declined';
                localStorage.setItem(consentKey, decision);
                banner.classList.remove('show');
            });
        });
    }

    const ticker = document.querySelector('.milestone-text');
    if (ticker) {
        const milestones = ticker.dataset.items ? JSON.parse(ticker.dataset.items) : [];
        let index = 0;
        if (milestones.length > 0) {
            ticker.textContent = milestones[0];
            setInterval(() => {
                index = (index + 1) % milestones.length;
                ticker.textContent = milestones[index];
            }, 4200);
        }
    }

    const decadeFilter = document.querySelector('#decadeFilter');
    const timelineEvents = document.querySelectorAll('.vertical-event');
    if (decadeFilter) {
        decadeFilter.addEventListener('change', event => {
            const value = event.target.value;
            timelineEvents.forEach(eventItem => {
                if (value === 'all' || eventItem.dataset.decade === value) {
                    eventItem.style.display = '';
                } else {
                    eventItem.style.display = 'none';
                }
            });
        });
    }

    const modalOverlay = document.querySelector('.modal-overlay');
    if (modalOverlay) {
        document.querySelectorAll('[data-modal-target]').forEach(trigger => {
            trigger.addEventListener('click', () => {
                const targetId = trigger.dataset.modalTarget;
                const modalContent = document.getElementById(targetId);
                if (modalContent) {
                    modalOverlay.classList.add('show');
                    modalOverlay.querySelector('.modal-content-area').innerHTML = modalContent.innerHTML;
                }
            });
        });
        const closeModal = () => modalOverlay.classList.remove('show');
        modalOverlay.addEventListener('click', event => {
            if (event.target === modalOverlay || event.target.classList.contains('modal-close')) {
                closeModal();
            }
        });
    }

    const filterControls = document.querySelectorAll('[data-filter-group]');
    filterControls.forEach(control => {
        const groupName = control.dataset.filterGroup;
        const items = document.querySelectorAll(`[data-filter-item="${groupName}"]`);
        control.addEventListener('change', event => {
            const selected = event.target.value;
            items.forEach(item => {
                if (selected === 'all' || item.dataset.filterValue === selected) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        if (question && answer) {
            question.addEventListener('click', () => {
                answer.classList.toggle('show');
            });
        }
    });

    const lightbox = document.querySelector('.lightbox');
    if (lightbox) {
        const lightboxImg = lightbox.querySelector('img');
        const lightboxCaption = lightbox.querySelector('.lightbox-caption');
        document.querySelectorAll('[data-lightbox]').forEach(image => {
            image.addEventListener('click', () => {
                lightbox.classList.add('show');
                lightboxImg.src = image.dataset.lightbox;
                lightboxCaption.textContent = image.alt;
            });
        });
        lightbox.addEventListener('click', () => {
            lightbox.classList.remove('show');
        });
    }

    const backToTop = document.querySelector('.back-to-top');
    if (backToTop) {
        const toggleVisibility = () => {
            if (window.scrollY > 360) {
                backToTop.style.display = 'grid';
            } else {
                backToTop.style.display = 'none';
            }
        };
        toggleVisibility();
        window.addEventListener('scroll', toggleVisibility);
    }

    const timelineTicker = document.querySelector('.timeline-horizontal');
    if (timelineTicker) {
        timelineTicker.addEventListener('wheel', event => {
            if (event.deltaY !== 0) {
                event.preventDefault();
                timelineTicker.scrollLeft += event.deltaY;
            }
        }, { passive: false });
    }
});