document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const scrollTopButton = document.querySelector('.scroll-top');
    const sectionsToAnimate = document.querySelectorAll('[data-animate]');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAcceptButton = document.querySelector('.cookie-accept');
    const COOKIE_KEY = 'nexteraCookieConsent';

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !isExpanded);
            navLinks.classList.toggle('open');
        });
    }

    if (navLinks) {
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('open');
                navToggle?.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    const toggleScrollButton = () => {
        if (window.scrollY > 300) {
            scrollTopButton?.classList.add('show');
        } else {
            scrollTopButton?.classList.remove('show');
        }
    };

    window.addEventListener('scroll', toggleScrollButton);
    toggleScrollButton();

    scrollTopButton?.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });

        sectionsToAnimate.forEach(section => observer.observe(section));
    } else {
        sectionsToAnimate.forEach(section => section.classList.add('is-visible'));
    }

    if (cookieBanner && cookieAcceptButton) {
        const hasConsent = localStorage.getItem(COOKIE_KEY);
        if (hasConsent) {
            cookieBanner.classList.add('hidden');
        }

        cookieAcceptButton.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }
});