document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            var isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navLinks.classList.toggle('is-open');
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navLinks.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    var cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        try {
            var preference = localStorage.getItem('malebonjafCookiePreference');
            if (!preference) {
                cookieBanner.classList.add('show');
            }
        } catch (error) {
            cookieBanner.classList.add('show');
        }

        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(function (button) {
            button.addEventListener('click', function () {
                var action = button.getAttribute('data-cookie-action');
                try {
                    localStorage.setItem('malebonjafCookiePreference', action);
                } catch (e) {
                    // Local storage may be unavailable; ignore
                }
                cookieBanner.classList.remove('show');
            });
        });
    }
});