const DEFAULT_LANG = "fr";
const STORAGE_KEY = "site_lang";

const I18N = {
  fr: {
    meta: {
      titles: {
        home: "danswholesaleplants — Orientation spatiale et signalétique numérique",
        services: "Services analytiques — danswholesaleplants",
        about: "À propos — danswholesaleplants",
        blog: "Analyses et études — danswholesaleplants",
        post1: "Cadres cognitifs pour pôles de transit — danswholesaleplants",
        post2: "Signalétique adaptative pour campus civiques — danswholesaleplants",
        post3: "Mobilité piétonne dans les districts culturels — danswholesaleplants",
        contact: "Contact — danswholesaleplants",
        faq: "FAQ — danswholesaleplants",
        terms: "Conditions d’utilisation — danswholesaleplants",
        privacy: "Politique de confidentialité — danswholesaleplants",
        cookies: "Politique de cookies — danswholesaleplants",
        refund: "Politique de retrait — danswholesaleplants",
        disclaimer: "Clause de non-responsabilité — danswholesaleplants",
        thankyou: "Merci — danswholesaleplants"
      },
      descriptions: {
        home: "Publication technique dédiée à l’orientation spatiale, la signalétique numérique et la navigation intérieure dans les environnements publics complexes.",
        services: "Aperçu des services analytiques consacrés aux parcours usagers, à la signalétique numérique et à la cartographie intérieure pour les bâtiments publics.",
        about: "Méthodologie éditoriale de danswholesaleplants et partenaires spécialisés dans l’orientation spatiale des environnements bâtis.",
        blog: "Articles approfondis sur la signalétique numérique, la cartographie des espaces et l’UX spatiale en Belgique.",
        post1: "Analyse des cadres cognitifs pour structurer l’orientation spatiale dans les pôles de transit multimodaux.",
        post2: "Étude sur la signalétique adaptative et les kiosques interactifs pour campus civiques et infrastructures publiques.",
        post3: "Approche data-driven de la mobilité piétonne et de la narration spatiale dans les districts culturels.",
        contact: "Coordonnées, formulaire et localisation de danswholesaleplants à Bruxelles.",
        faq: "Réponses aux questions fréquentes concernant l’orientation spatiale et la signalétique numérique.",
        terms: "Conditions d’utilisation détaillant responsabilités et cadre de publication de danswholesaleplants.",
        privacy: "Politique de confidentialité décrivant la collecte et l’usage des données sur danswholesaleplants.",
        cookies: "Politique relative aux cookies et technologies similaires sur danswholesaleplants.",
        refund: "Politique de retrait décrivant les modalités d’annulation des contributions éditoriales.",
        disclaimer: "Clause de non-responsabilité précisant les limites d’engagement de danswholesaleplants.",
        thankyou: "Confirmation d’envoi pour le formulaire de contact de danswholesaleplants."
      }
    },
    header: {
      brand: "danswholesaleplants",
      nav: {
        home: "Accueil",
        services: "Services",
        about: "À propos",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      toggle: {
        open: "Ouvrir la navigation",
        close: "Fermer la navigation"
      }
    },
    language: {
      fr: "FR",
      en: "EN"
    },
    footer: {
      title: "danswholesaleplants",
      description: "Publication technique dédiée à l’orientation spatiale, la signalétique numérique et la cartographie des environnements complexes en Belgique.",
      contactTitle: "Coordonnées",
      exploreTitle: "Explorer",
      legalTitle: "Références légales",
      addressLabel: "Adresse",
      phoneLabel: "Téléphone",
      emailLabel: "Courriel",
      phoneValue: "+32 2 702 45 18",
      emailValue: "info@danswholesaleplants.com",
      legal: {
        terms: "Conditions d’utilisation",
        privacy: "Politique de confidentialité",
        cookies: "Politique de cookies",
        refund: "Politique de retrait",
        disclaimer: "Clause de non-responsabilité"
      },
      copyright: "© {year} danswholesaleplants. Tous droits réservés.",
      footerNote: "Basée à Bruxelles, Belgique."
    },
    common: {
      readMore: "Lire l’analyse",
      learnMore: "En savoir plus",
      viewDetails: "Consulter les détails",
      close: "Fermer",
      publishedOn: "Publié le {date}",
      minutes: "{value} min de lecture"
    },
    home: {
      hero: {
        title: "Cartographier les repères cognitifs pour orienter les usagers dans les environnements publics complexes",
        subtitle: "danswholesaleplants produit des analyses approfondies sur la manière dont la signalétique numérique, la cartographie immersive et la conception de flux piétons transforment l’expérience des usagers dans les bâtiments publics et les espaces urbains belges.",
        buttonPrimary: "Explorer nos axes d’analyse",
        buttonSecondary: "Voir les études de cas",
        highlight1: "Études comparatives des systèmes de signalétique multimodale dans les gares et pôles de correspondance.",
        highlight2: "Méthodes de conception pour des plans interactifs intégrés aux kiosques et rapports de mobilité piétonne.",
        highlight3: "Cadres d’évaluation pour l’accessibilité et la lisibilité des parcours dans les infrastructures publiques."
      },
      heroImageAlt: "Signalétique numérique et flux piétons dans un hall public moderne",
      metrics: {
        title: "Indicateurs de recherche",
        description: "Un corpus documentaire nourri d’observations de terrain, de simulations et d’ateliers avec des organisations publiques belges.",
        item1Value: "38 parcours audités",
        item1Label: "Audit de parcours utilisateurs dans les pôles de transport et bâtiments administratifs.",
        item2Value: "24 ateliers",
        item2Label: "Sessions co-créatives menées avec des gestionnaires d’espaces et des urbanistes.",
        item3Value: "11 cadres",
        item3Label: "Référentiels méthodologiques publiés pour mesurer la clarté et la lisibilité."
      },
      featured: {
        title: "Axes thématiques",
        description: "Une sélection de travaux qui interrogent la relation entre infrastructure, narration spatiale et dispositifs informatifs.",
        card1Title: "Orientation spatiale multi-niveaux",
        card1Text: "Analyse des continuités visuelles et sonores dans les pôles à géométrie complexe, avec un focus sur les abords bruxellois.",
        card2Title: "Signalétique numérique adaptive",
        card2Text: "Conception d’interfaces et de flux de contenu capables de refléter en temps réel les changements opérationnels.",
        card3Title: "Cartographie contextuelle",
        card3Text: "Principes cartographiques qui articulent données géospatiales, repères locaux et contraintes de mobilité.",
        card4Title: "Expérience piétonne sensible",
        card4Text: "Études sensorimotrices pour renforcer le confort de navigation dans les espaces intérieurs à forte densité."
      },
      method: {
        title: "Méthodologie d’analyse",
        description: "Nos publications reposent sur des protocoles hybrides combinant observation in situ, modélisation des flux et design informationnel.",
        point1: "Inventaires qualitatifs des points de friction perceptifs, répertoriés par niveaux de complexité.",
        point2: "Matrices décisionnelles impliquant les responsables de lieux publics et les usagers quotidiens.",
        point3: "Prototypage d’interfaces et tests d’itinéraires au sein d’environnements simulés.",
        point4: "Recommandations graphiques et narratives pour harmoniser les systèmes de signalétique."
      },
      recommendations: {
        title: "Recommandations clés",
        description: "Synthèse des orientations publiées par danswholesaleplants pour guider les acteurs publics dans leurs projets.",
        item1Title: "Construire des repères progressifs",
        item1Text: "Maintenir un fil visuel cohérent depuis l’espace public jusqu’aux zones d’attente en intégrant couleurs, typographie et iconographie harmonisées.",
        item2Title: "Accompagner la décision",
        item2Text: "Implanter des supports interactifs dans les zones de changement de direction et fournir des scénarios alternatifs en cas de saturation.",
        item3Title: "Garantir la continuité numérique",
        item3Text: "Synchroniser signalétique physique et plateformes digitales pour éviter les contradictions de parcours.",
        item4Title: "Valoriser les singularités locales",
        item4Text: "Ancrer la narration spatiale dans l’histoire et les usages du lieu afin d’augmenter la confiance des usagers."
      },
      testimonials: {
        title: "Témoignages",
        description: "Retours d’acteurs publics et de partenaires académiques ayant collaboré aux recherches.",
        item1Quote: "Les grilles d’analyse de danswholesaleplants nous ont permis de hiérarchiser les interventions sur notre réseau de signalétique sans perdre la cohérence globale du site.",
        item1Name: "Coordinatrice mobilité, Bruxelles",
        item2Quote: "Le travail sur la cartographie contextuelle a clarifié les points de repère essentiels pour des visiteurs peu familiers avec des architectures imbriquées.",
        item2Name: "Responsable patrimoine, Gand",
        item3Quote: "La démarche sur l’accessibilité combinant observation et design informationnel a renforcé la lisibilité des circulations pour tous les publics.",
        item3Name: "Chargé d’étude, Liège"
      },
      blogPreview: {
        title: "Analyses récentes",
        description: "Articles approfondis pour décrypter la signalétique numérique et l’UX spatiale.",
        post1Title: "Cadres cognitifs pour pôles de transit multimodaux",
        post1Excerpt: "Comment les systèmes de repères visuels et sonores s’articulent pour fluidifier la navigation dans des nœuds complexes.",
        post2Title: "Signalétique adaptative au service des campus civiques",
        post2Excerpt: "Vers des supports numériques capables d’orchestrer les services publics dispersés sur un même site.",
        post3Title: "Mobilité piétonne et narration dans un district culturel",
        post3Excerpt: "Déployer des itinéraires sensibles reliant musées, théâtres et espaces publics ouverts."
      }
    },
    services: {
      heroTitle: "Services analytiques pour des environnements construits intelligibles",
      heroSubtitle: "Nous documentons les mécanismes d’orientation et les conditions de lisibilité de la signalétique à travers une approche centrée sur les usages.",
      introText: "Chaque prestation est menée comme un cycle de recherche : cadrage, collecte de données, modélisation, restitution. Nous travaillons aux côtés d’institutions publiques pour cartographier les parcours, clarifier les points de friction et proposer des cadres opérationnels.",
      listTitle: "Domaines d’expertise",
      item1Title: "Analyse des défis d’orientation",
      item1Text: "Diagnostics multi-échelles, observation des flux et identification des obstacles cognitifs dans les bâtiments publics.",
      item2Title: "Design pour la signalétique numérique",
      item2Text: "Conception de lignes graphiques et de contenus responsives adaptés aux dispositifs interactifs.",
      item3Title: "Recherche UX pour la mobilité piétonne",
      item3Text: "Enquêtes qualitatives, parcours accompagnés et tests utilisateurs dans les environnements complexes.",
      item4Title: "Cadres pour plans interactifs",
      item4Text: "Architecture de l’information pour kiosques, applications et cartographies immersives.",
      item5Title: "Consultation accessibilité",
      item5Text: "Alignement des parcours sur les normes d’accessibilité et recommandations pour une lisibilité renforcée.",
      processTitle: "Processus type",
      step1Title: "Cadrage partagé",
      step1Text: "Inventaire des espaces, objectifs du commanditaire public et attentes des usagers identifiés.",
      step2Title: "Collecte multi-sources",
      step2Text: "Observation in situ, instrumentation légère, entretiens et relevés cartographiques.",
      step3Title: "Modélisation",
      step3Text: "Cartographies de flux, scénarios d’usage et maquettes de signalétique numérique.",
      step4Title: "Restitution",
      step4Text: "Livrables structurés, recommandations et matrices décisionnelles pour prioriser les actions.",
      calloutTitle: "Livrables récurrents",
      calloutItem1: "Atlas de parcours illustré et commenté.",
      calloutItem2: "Scripts de contenu pour kiosques et écrans.",
      calloutItem3: "Tableaux de suivi pour indicateurs de lisibilité.",
      calloutItem4: "Feuilles de route pour aligner dispositifs physiques et numériques."
    },
    about: {
      heroTitle: "Comprendre l’orientation spatiale par des recherches situées",
      heroSubtitle: "danswholesaleplants fédère des spécialistes du design informationnel, de la cartographie et de l’analyse des flux piétons.",
      missionTitle: "Mission éditoriale",
      missionText: "Notre objectif est de documenter et d’éclairer les stratégies d’orientation dans des contextes où les circulations sont denses et les services multiples. Nous produisons des dossiers qui croisent données, récits d’usagers et prototypage.",
      pillarsTitle: "Piliers méthodologiques",
      pillar1Title: "Immersion de terrain",
      pillar1Text: "Observations prolongées et captations de trajectoires pour comprendre les réflexes spatiaux.",
      pillar2Title: "Design informationnel",
      pillar2Text: "Structuration des contenus afin de garantir la lisibilité des messages dans des environnements complexes.",
      pillar3Title: "Évaluation continue",
      pillar3Text: "Itérations à partir de retours utilisateurs pour ajuster les parcours et la signalétique.",
      historyTitle: "Repères chronologiques",
      historyItem1Title: "2017 — Origines",
      historyItem1Text: "Premières études menées dans les gares belges autour de la coexistence des flux touristiques et pendulaires.",
      historyItem2Title: "2019 — Plateforme collaborative",
      historyItem2Text: "Ouverture à des partenaires académiques et lancement d’ateliers de co-analyse.",
      historyItem3Title: "2022 — Transition numérique",
      historyItem3Text: "Déploiement d’un corpus sur les supports interactifs et la synchronisation des données temps réel.",
      teamTitle: "Compétences réunies",
      teamText: "Cartographes, urbanistes, designers d’information et chercheurs en sciences sociales collaborent pour interpréter les environnements bâtis."
    },
    blog: {
      heroTitle: "Analyses et études",
      heroSubtitle: "Explorations détaillées de la signalétique numérique, de la cartographie des espaces et de la mobilité piétonne en Belgique.",
      post1Meta: "Publié le 12 mars 2024",
      post2Meta: "Publié le 4 février 2024",
      post3Meta: "Publié le 12 janvier 2024",
      readArticle: "Lire l’article"
    },
    post1: {
      metaInfo: "{date} · {minutes}",
      date: "12 mars 2024",
      minutes: "14",
      title: "Cadres cognitifs pour orienter les pôles de transit multimodaux",
      intro: "Les pôles de transit contemporains s’apparentent à des paysages polycentriques où convergent trains, bus, tramways et mobilités douces. Leur lisibilité dépend de la capacité à proposer des repères cohérents malgré des flux simultanés et des architectures superposées.",
      section1Title: "Déplier les strates d’un nœud de correspondance",
      section1Paragraph1: "L’analyse débute par une cartographie des seuils qui marquent l’arrivée progressive dans le pôle. Chaque seuil est caractérisé par des ancrages sensoriels distincts : bruit d’arrière-plan, lumière naturelle, densité de la foule. Les voyageurs alignent leurs repères en combinant ces indices et les messages de signalétique. Lorsque l’un des éléments diverge, une dissonance se crée et retarde l’orientation.",
      section1Paragraph2: "Pour mesurer cette dissonance, nous avons instrumenté des parcours types reliant les entrées latérales au plateau central. Des capteurs de pression et des observations filmées ont révélé des ralentissements systématiques dans les zones où la signalétique numérique n’épousait pas les axes naturels du bâtiment.",
      section1SubTitle: "Hiérarchiser la narration spatiale",
      section1Paragraph3: "Une hiérarchie claire des messages est indispensable. Les écrans doivent ancrer une narration qui raccroche chaque micro-décision à une destination macroscopique. Les mentions de lignes et de quais sont associées à des pictogrammes cohérents, tandis que les flèches physiques et numériques se superposent. La suppression de redondances inutiles permet de libérer du temps de lecture et d’augmenter la confiance.",
      section2Title: "Synchroniser les dispositifs physiques et numériques",
      section2Paragraph1: "Les dispositifs numériques fonctionnent comme des médiateurs entre la complexité architecturale et la logique de déplacement. Ils doivent refléter en temps réel l’état des circulations, mais également conserver un socle narratif constant. Les tests d’affordance ont montré que les usagers valident d’abord la cohérence du vocabulaire graphique avant d’intégrer les mises à jour dynamiques.",
      section2Paragraph2: "Nous avons intégré un protocole de cohérence croisée : chaque variation envoyée aux écrans est parallèlement vérifiée sur les plans imprimés et sur les repères directionnels. La moindre divergence provoque un effet domino, en particulier lors des changements de quai de dernière minute.",
      section2SubTitle: "Rendre visibles les alternatives",
      section2Paragraph3: "Dans les situations perturbées, la présence d’itinéraires alternatifs affichés clairement devient un facteur de sérénité. Les cartes interactives offrent la possibilité d’anticiper les goulots d’étranglement en affichant des cheminements bis. Toutefois, ces alternatives doivent rester parcimonieuses afin d’éviter la surcharge cognitive.",
      section3Title: "Recomposer les flux piétons par la simulation",
      section3Paragraph1: "La simulation multi-agent est un outil puissant pour tester différentes configurations de signalétique. Nous avons modélisé les horaires de pointe d’un lundi et d’un samedi pour observer les variations de densité. Les résultats ont mis en évidence l’importance d’un gradient de messages : rapides et synthétiques pour les navetteurs, plus descriptifs pour les visiteurs occasionnels.",
      section3Paragraph2: "Les boucles de rétroaction entre simulation et observation in situ sont essentielles. Chaque cycle a conduit à ajuster la taille des caractères, la position des écrans et les contrastes chromatiques pour maintenir la lisibilité dans des conditions lumineuses variables.",
      section3SubTitle: "Élargir la palette sensorielle",
      section3Paragraph3: "Au-delà de la vision, les vibrations dans les sols ou la diffusion sonore peuvent signaler des orientations. Nous avons expérimenté des nappes sonores discrètes qui accompagnent les couloirs menant aux quais latéraux. Les retours montrent une meilleure anticipation des bifurcations, au prix d’une coordination fine avec les annonces officielles.",
      conclusionTitle: "Vers un référentiel d’alignement",
      conclusionParagraph: "Structurer un pôle de transit revient à orchestrer un ensemble de dispositifs et de signaux qui convergent vers un même cap. Les cadres cognitifs proposés ici s’attachent à alerter sur les points de rupture potentiels et à proposer des solutions graduées. La prochaine étape consiste à mutualiser ces pratiques avec d’autres opérateurs de transport belges afin de stabiliser des repères à l’échelle nationale."
    },
    post2: {
      metaInfo: "{date} · {minutes}",
      date: "4 février 2024",
      minutes: "13",
      title: "Signalétique adaptative pour un campus civique multi-services",
      intro: "Les campus civiques rassemblent des services administratifs, culturels et sociaux sur un périmètre compact. Les usagers alternent entre démarches rapides et parcours exploratoires, ce qui exige une signalétique capable de s’adapter aux rythmes successifs.",
      section1Title: "Comprendre la mosaïque des usages",
      section1Paragraph1: "L’étude a débuté par un inventaire des profils fréquentant le campus : résidents, visiteurs occasionnels, personnels de la ville, associations. Chaque profil possède une granularité d’information spécifique. Les résidents souhaitent optimiser leur temps, tandis que les associations recherchent des informations contextuelles sur les salles et les équipements partagés.",
      section1Paragraph2: "Les observations ont montré que la juxtaposition de panneaux traditionnels et d’écrans dynamiques produisait des zones d’ombre. Certaines entrées étaient sur-signifiées, quand d’autres manquaient de repères basiques. Nous avons cartographié les densités d’information pour équilibrer la distribution des messages.",
      section1SubTitle: "Concevoir un lexique commun",
      section1Paragraph3: "La première étape de rationalisation a consisté à établir un lexique transversal. Les termes employés sur les documents administratifs, les plateformes en ligne et les panneaux physiques sont alignés. Une charte linguistique garantit que chaque service conserve sa singularité tout en respectant une nomenclature commune.",
      section2Title: "Activer les supports numériques selon le contexte",
      section2Paragraph1: "Les kiosques interactifs sont paramétrés pour restituer des scénarios selon l’heure de la journée. Aux heures de pointe, l’interface met en avant les guichets ouverts et les files estimées. En période calme, elle propose des parcours thématiques reliant les espaces culturels.",
      section2Paragraph2: "Cette adaptabilité repose sur un moteur éditorial connecté aux agendas des services. Les gestionnaires peuvent programmer des messages de priorité et déclencher des alertes localisées. L’information reste toutefois circonscrite à l’essentiel afin de préserver la lisibilité.",
      section2SubTitle: "Dessiner une topographie relationnelle",
      section2Paragraph3: "Nous avons modélisé le campus comme un graphe relationnel où chaque nœud représente un service et chaque arête un flux d’usagers. La signalétique physique matérialise cette topographie à travers des totems, des rubans lumineux et des plans superposés. Les visiteurs appréhendent d’un coup d’œil les correspondances entre services.",
      section3Title: "Tester l’accessibilité et la robustesse",
      section3Paragraph1: "Les tests utilisateurs ont été menés avec des personnes aux besoins variés, dont des usagers malvoyants et des personnes âgées. Les parcours ont mis en évidence l’importance de maintenir des contrastes forts et des hauteurs de lecture cohérentes. Les dispositifs tactiles sont doublés de repères sonores activables.",
      section3Paragraph2: "La robustesse du système dépend aussi de sa capacité à rester lisible lorsque certains écrans sont hors service. Nous avons donc défini un mode dégradé où la signalétique physique prend le relais grâce à des inserts magnétiques faciles à mettre à jour.",
      section3SubTitle: "Prendre en compte le climat urbain",
      section3Paragraph3: "Les cheminements extérieurs traversent des espaces végétalisés et des zones couvertes. La signalétique doit résister aux variations météorologiques tout en restant harmonieuse. Des matériaux réfléchissants et des revêtements anti-reflets ont été sélectionnés pour garantir la visibilité par temps de pluie.",
      conclusionTitle: "Un campus lisible et évolutif",
      conclusionParagraph: "La signalétique adaptative n’est efficace que si elle s’inscrit dans un écosystème cohérent. En combinant données, design informationnel et retours d’usage, le campus civique dispose d’un cadre durable qui accompagne les transformations futures, sans jamais perdre de vue la qualité de l’accueil."
    },
    post3: {
      metaInfo: "{date} · {minutes}",
      date: "12 janvier 2024",
      minutes: "15",
      title: "Mobilité piétonne et narration dans un district culturel",
      intro: "Un district culturel rassemble théâtres, musées, archives et espaces publics. L’affluence varie selon les programmations, ce qui impose une lecture souple des lieux et des ambiances. La narration spatiale devient un vecteur d’appropriation collective.",
      section1Title: "Identifier les rythmes du quartier",
      section1Paragraph1: "Nous avons analysé les flux sur trois saisons afin de comprendre l’alternance entre fréquentation touristique et vie de quartier. Les données révèlent des pics au début de soirée et un retour au calme en milieu de journée. Les repères doivent donc s’adapter à ces pulsations.",
      section1Paragraph2: "La cartographie des tempos a mis en lumière des zones sous-exploitées reliant pourtant des points culturels majeurs. Ces interstices constituent des opportunités pour installer des dispositifs narratifs qui prolongent l’expérience entre deux visites.",
      section1SubTitle: "Créer une dramaturgie urbaine",
      section1Paragraph3: "La narration spatiale repose sur une dramaturgie douce : tonalités de lumière, rythme des messages, séquences sonores. Nous avons défini des ambiances par strates pour guider le visiteur sans saturer l’espace. Les transitions sont matérialisées par des micro-installations alliant texte, cartographie et symboles graphiques.",
      section2Title: "Mettre en scène les ressources du territoire",
      section2Paragraph1: "Chaque institution partage ses contenus clés pour alimenter des stations numériques. Les interfaces proposent des extraits d’archives, des repères historiques et des cartes thématiques. Les usagers peuvent composer un parcours personnalisé en fonction de la durée disponible.",
      section2Paragraph2: "Pour éviter la dispersion, nous avons conçu une ligne graphique unifiée, inspirée du patrimoine architectural local. Les couleurs, typographies et icônes rappellent les matériaux du quartier. La cohérence visuelle renforce la crédibilité des messages.",
      section2SubTitle: "Soutenir la mobilité douce",
      section2Paragraph3: "La signalétique valorise les cheminements cyclables et les zones piétonnes apaisées. Des plans superposent les itinéraires accessibles, les temps de marche et les espaces de respiration. Les visiteurs comprennent rapidement comment circuler de manière fluide sans recourir aux transports motorisés.",
      section3Title: "Orchestrer l’expérience nocturne",
      section3Paragraph1: "La vie nocturne d’un district culturel exige une attention particulière. Les dispositifs lumineux servent à la fois de guides et de marqueurs d’ambiance. Nous avons travaillé sur des gradients chromatiques qui signalent les directions principales tout en respectant la tranquillité des riverains.",
      section3Paragraph2: "Les totems interactifs adoptent un mode nuit avec un contraste élevé et des informations synthétiques. Les parcours alternatifs sont proposés en cas de foule à la sortie des représentations. Cette flexibilité garantit une circulation fluide et sûre.",
      section3SubTitle: "Mesurer l’appropriation",
      section3Paragraph3: "Des questionnaires et des capteurs de fréquentation ont été mobilisés pour évaluer l’appropriation des dispositifs. Les résultats montrent une progression de la fréquentation des lieux moins connus et une meilleure répartition des flux aux heures de pointe.",
      conclusionTitle: "Vers une narration partagée",
      conclusionParagraph: "Le district culturel gagne en lisibilité quand les institutions partagent une vision commune de l’accueil. La narration spatiale, soutenue par la signalétique numérique et la cartographie, favorise l’émergence d’une identité collective. Les prochaines phases porteront sur l’intégration de retours en temps réel pour continuer à ajuster l’expérience."
    },
    contact: {
      heroTitle: "Nous contacter",
      heroSubtitle: "Prenez contact pour partager un retour d’expérience, proposer une collaboration ou demander une précision sur nos publications.",
      addressLabel: "Adresse",
      addressValue: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
      phoneLabel: "Téléphone",
      phoneValue: "+32 2 702 45 18",
      emailLabel: "Courriel",
      emailValue: "info@danswholesaleplants.com",
      formTitle: "Formulaire de contact",
      formSubtitle: "Nous répondons aux messages dans un délai de deux jours ouvrables.",
      fieldName: "Votre nom",
      fieldOrganisation: "Organisation",
      fieldEmail: "Adresse courriel",
      fieldTopic: "Sujet",
      fieldMessage: "Message",
      fieldTopicOption1: "Orientation spatiale",
      fieldTopicOption2: "Signalétique numérique",
      fieldTopicOption3: "Cartographie des espaces",
      fieldTopicOption4: "Autre demande",
      submitButton: "Envoyer",
      mapTitle: "Localisation de danswholesaleplants",
      mapCaption: "Plan interactif centré sur Bruxelles et Rue de la Loi.",
      infoTitle: "Informations pratiques"
    },
    faq: {
      heroTitle: "Questions fréquentes",
      heroSubtitle: "Réponses aux interrogations récurrentes concernant nos approches et publications.",
      item1Question: "Comment sélectionnez-vous les sites étudiés ?",
      item1Answer: "Nous travaillons principalement avec des institutions publiques en Belgique. La sélection se fait selon la complexité des parcours et la diversité des usages.",
      item2Question: "Publiez-vous des plans opérationnels ?",
      item2Answer: "Nous diffusons des cadres d’analyse, des recommandations et des maquettes. L’opérationnalisation finale est réalisée par les gestionnaires d’espaces.",
      item3Question: "Comment sont menés les tests utilisateurs ?",
      item3Answer: "Les tests mêlent observations in situ, interviews et simulations. Les volontaires sont recrutés parmi les usagers réguliers et occasionnels.",
      item4Question: "Proposez-vous un accompagnement long terme ?",
      item4Answer: "Nous réalisons des cycles de recherche modulables. Chaque institution peut choisir des phases ponctuelles ou des suivis prolongés.",
      item5Question: "Les contenus sont-ils disponibles en licence libre ?",
      item5Answer: "Les synthèses sont librement consultables. Certaines données sensibles restent accessibles sous accord avec les partenaires."
    },
    terms: {
      title: "Conditions d’utilisation",
      intro: "Les présentes conditions encadrent l’usage du site danswholesaleplants.com. En accédant au site, vous acceptez ces dispositions.",
      section1Title: "1. Objet",
      section1Text: "Le site diffuse des contenus analytiques sur l’orientation spatiale et la signalétique numérique. Aucun service commercial n’y est proposé directement.",
      section2Title: "2. Accès au site",
      section2Text: "L’accès est libre et gratuit. L’éditeur peut suspendre tout ou partie du site pour maintenance ou mise à jour.",
      section3Title: "3. Propriété intellectuelle",
      section3Text: "Les textes, visuels et données publiés sont protégés par le droit d’auteur. Toute réutilisation nécessite une autorisation préalable.",
      section4Title: "4. Contributions externes",
      section4Text: "Les partenaires peuvent proposer des contributions. L’éditeur se réserve le droit de sélectionner, modifier ou retirer ces contenus.",
      section5Title: "5. Responsabilité",
      section5Text: "L’éditeur veille à l’exactitude des informations mais ne garantit pas l’absence d’erreurs ou d’omissions involontaires.",
      section6Title: "6. Liens hypertextes",
      section6Text: "Le site peut contenir des liens vers des ressources externes. L’éditeur n’est pas responsable de leur contenu ni de leur disponibilité.",
      section7Title: "7. Données personnelles",
      section7Text: "Le traitement des données est décrit dans la politique de confidentialité. Aucune donnée n’est cédée à des tiers à des fins commerciales.",
      section8Title: "8. Cookies",
      section8Text: "La gestion des cookies et technologies similaires est précisée dans la politique de cookies.",
      section9Title: "9. Modifications",
      section9Text: "L’éditeur peut adapter les présentes conditions pour suivre l’évolution des publications et des obligations légales.",
      section10Title: "10. Indépendance des clauses",
      section10Text: "Si une disposition est déclarée invalide, les autres clauses conservent leur pleine effectivité.",
      section11Title: "11. Usage autorisé",
      section11Text: "L’utilisation des contenus est limitée à des fins d’information, de recherche ou d’étude interne.",
      section12Title: "12. Sécurité",
      section12Text: "Les utilisateurs s’engagent à ne pas altérer le fonctionnement du site ni à tenter d’accéder à des espaces non autorisés.",
      section13Title: "13. Droit applicable",
      section13Text: "Les présentes conditions sont régies par le droit belge. Tout différend relève des juridictions compétentes de Bruxelles.",
      section14Title: "14. Contact",
      section14Text: "Pour toute question relative aux conditions, contactez info@danswholesaleplants.com."
    },
    privacy: {
      title: "Politique de confidentialité",
      intro: "Cette politique décrit la manière dont danswholesaleplants traite les données collectées via le site.",
      section1Title: "1. Responsable de traitement",
      section1Text: "Le responsable de traitement est danswholesaleplants, Rue de la Loi 155, 1040 Bruxelles, Belgique.",
      section2Title: "2. Données collectées",
      section2Text: "Nous recueillons les informations fournies via le formulaire de contact : nom, organisation, adresse courriel, sujet et message.",
      section3Title: "3. Finalités",
      section3Text: "Les données servent à répondre aux demandes, organiser des échanges et envoyer des informations pertinentes sur nos publications.",
      section4Title: "4. Base légale",
      section4Text: "Le traitement repose sur l’intérêt légitime à répondre aux sollicitations et sur le consentement lorsque requis.",
      section5Title: "5. Durée de conservation",
      section5Text: "Les données sont conservées pendant trois ans à compter du dernier échange, sauf obligation légale contraire.",
      section6Title: "6. Destinataires",
      section6Text: "Les données sont accessibles aux membres éditoriaux en charge du suivi des demandes. Aucun transfert commercial n’est réalisé.",
      section7Title: "7. Hébergement",
      section7Text: "Le site est hébergé sur des serveurs situés dans l’Union européenne, offrant des garanties de sécurité conformes aux standards du secteur.",
      section8Title: "8. Droits des personnes",
      section8Text: "Vous disposez d’un droit d’accès, de rectification, d’effacement, de limitation, d’opposition et de portabilité.",
      section9Title: "9. Exercice des droits",
      section9Text: "Pour exercer vos droits, contactez info@danswholesaleplants.com en précisant votre demande. Une réponse sera apportée sous un mois.",
      section10Title: "10. Mise à jour",
      section10Text: "Cette politique peut évoluer. La dernière mise à jour est signalée en tête de document."
    },
    cookies: {
      title: "Politique de cookies",
      intro: "Cette politique présente les cookies utilisés sur danswholesaleplants.com.",
      section1Title: "Usage des cookies",
      section1Text: "Les cookies sont employés pour mesurer l’audience, mémoriser la langue choisie et sécuriser les formulaires.",
      tableCaption: "Tableau des cookies utilisés",
      nameHeader: "Nom",
      providerHeader: "Fournisseur",
      typeHeader: "Type",
      purposeHeader: "Finalité",
      durationHeader: "Durée",
      row1Name: "site_lang",
      row1Provider: "danswholesaleplants",
      row1Type: "Fonctionnel",
      row1Purpose: "Sauvegarder la langue d’affichage sélectionnée.",
      row1Duration: "12 mois",
      row2Name: "cookie_consent",
      row2Provider: "danswholesaleplants",
      row2Type: "Fonctionnel",
      row2Purpose: "Enregistrer le choix relatif aux cookies.",
      row2Duration: "12 mois",
      row3Name: "analytics_session",
      row3Provider: "danswholesaleplants",
      row3Type: "Mesure d’audience",
      row3Purpose: "Analyser les pages consultées pour améliorer les contenus.",
      row3Duration: "24 heures",
      managementTitle: "Gestion des cookies",
      managementText: "Vous pouvez refuser les cookies non essentiels via la bannière dédiée ou paramétrer votre navigateur."
    },
    refund: {
      title: "Politique de retrait",
      intro: "Cette politique décrit la manière de demander le retrait d’une contribution ou d’une mention sur danswholesaleplants.",
      section1Title: "1. Champ d’application",
      section1Text: "S’applique aux textes, visuels et citations publiés avec l’accord des partenaires ou contributeurs.",
      section2Title: "2. Demande initiale",
      section2Text: "Envoyez une demande écrite en précisant l’élément concerné et la raison du retrait.",
      section3Title: "3. Accusé de réception",
      section3Text: "Une confirmation vous est adressée dans les sept jours ouvrables suivant la demande.",
      section4Title: "4. Analyse",
      section4Text: "L’équipe éditoriale vérifie la conformité de la demande avec les engagements pris.",
      section5Title: "5. Décision",
      section5Text: "La décision définitive est communiquée dans un délai de trente jours calendaires.",
      section6Title: "6. Modalités de retrait",
      section6Text: "Le retrait peut prendre la forme d’une suppression, d’une anonymisation ou d’une mise à jour contextuelle.",
      section7Title: "7. Traçabilité",
      section7Text: "Chaque modification est documentée pour assurer un suivi transparent.",
      section8Title: "8. Contenus co-produits",
      section8Text: "Pour les contenus produits avec plusieurs partenaires, une concertation collective est organisée.",
      section9Title: "9. Limites",
      section9Text: "Le retrait n’est pas garanti si l’information est nécessaire à la compréhension d’un dossier public.",
      section10Title: "10. Contact",
      section10Text: "Les demandes sont à adresser à info@danswholesaleplants.com."
    },
    disclaimer: {
      title: "Clause de non-responsabilité",
      intro: "Le présent site fournit des analyses et orientations à titre informatif.",
      point1: "Les contenus ne remplacent jamais une expertise réglementaire, juridique ou architecturale spécifique.",
      point2: "Les études publiées reposent sur des observations datées. Les situations peuvent évoluer sans préavis.",
      point3: "danswholesaleplants décline toute responsabilité quant aux décisions prises sur la base des informations diffusées.",
      point4: "Les liens externes sont fournis pour contextualiser les analyses ; leur contenu ne relève pas de la responsabilité de l’éditeur.",
      point5: "Pour des décisions opérationnelles, rapprochez-vous des autorités compétentes ou de professionnels qualifiés."
    },
    thankyou: {
      title: "Merci pour votre message",
      message: "Votre demande a bien été transmise. Nous vous répondrons dans un délai de deux jours ouvrables.",
      backLink: "Retour à l’accueil"
    },
    cookieBanner: {
      title: "Gestion des cookies",
      text: "Nous utilisons des cookies pour mémoriser votre langue et mesurer l’audience. Vous pouvez accepter ou refuser les cookies non essentiels.",
      accept: "Accepter",
      decline: "Refuser"
    },
    toast: {
      languageChanged: "Langue mise à jour.",
      formSubmitting: "Envoi en cours…",
      formSubmitted: "Message transmis, redirection en cours."
    }
  },
  en: {
    meta: {
      titles: {
        home: "danswholesaleplants — Spatial orientation and digital signage insights",
        services: "Analytical services — danswholesaleplants",
        about: "About — danswholesaleplants",
        blog: "Analysis and studies — danswholesaleplants",
        post1: "Cognitive frameworks for multimodal transit hubs — danswholesaleplants",
        post2: "Adaptive signage for civic campuses — danswholesaleplants",
        post3: "Pedestrian mobility in cultural districts — danswholesaleplants",
        contact: "Contact — danswholesaleplants",
        faq: "FAQ — danswholesaleplants",
        terms: "Terms of use — danswholesaleplants",
        privacy: "Privacy policy — danswholesaleplants",
        cookies: "Cookie policy — danswholesaleplants",
        refund: "Withdrawal policy — danswholesaleplants",
        disclaimer: "Disclaimer — danswholesaleplants",
        thankyou: "Thank you — danswholesaleplants"
      },
      descriptions: {
        home: "Technical publication dedicated to spatial orientation, digital wayfinding and indoor navigation within complex public environments in Belgium.",
        services: "Overview of analytical services focused on user journeys, digital signage and interior mapping for public buildings.",
        about: "Editorial methodology of danswholesaleplants and partners specialized in spatial orientation for built environments.",
        blog: "In-depth articles on digital signage, spatial mapping and spatial UX in Belgium.",
        post1: "Analysis of cognitive frameworks that structure spatial orientation in multimodal transit hubs.",
        post2: "Study on adaptive signage and interactive kiosks for civic campuses and public infrastructure.",
        post3: "Data-informed approach to pedestrian mobility and spatial storytelling in cultural districts.",
        contact: "Contact details, form and location for danswholesaleplants in Brussels.",
        faq: "Answers to frequently asked questions about spatial orientation and digital signage.",
        terms: "Terms of use detailing responsibilities and editorial framework of danswholesaleplants.",
        privacy: "Privacy policy describing data collection and usage on danswholesaleplants.",
        cookies: "Policy regarding cookies and similar technologies on danswholesaleplants.",
        refund: "Withdrawal policy describing how to request the removal of contributions.",
        disclaimer: "Disclaimer outlining the limits of danswholesaleplants’ responsibility.",
        thankyou: "Submission confirmation for the danswholesaleplants contact form."
      }
    },
    header: {
      brand: "danswholesaleplants",
      nav: {
        home: "Home",
        services: "Services",
        about: "About",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      toggle: {
        open: "Open navigation",
        close: "Close navigation"
      }
    },
    language: {
      fr: "FR",
      en: "EN"
    },
    footer: {
      title: "danswholesaleplants",
      description: "Technical publication focusing on spatial orientation, digital signage and mapping for complex environments across Belgium.",
      contactTitle: "Contact",
      exploreTitle: "Explore",
      legalTitle: "Legal",
      addressLabel: "Address",
      phoneLabel: "Phone",
      emailLabel: "Email",
      phoneValue: "+32 2 702 45 18",
      emailValue: "info@danswholesaleplants.com",
      legal: {
        terms: "Terms of use",
        privacy: "Privacy policy",
        cookies: "Cookie policy",
        refund: "Withdrawal policy",
        disclaimer: "Disclaimer"
      },
      copyright: "© {year} danswholesaleplants. All rights reserved.",
      footerNote: "Based in Brussels, Belgium."
    },
    common: {
      readMore: "Read analysis",
      learnMore: "Learn more",
      viewDetails: "View details",
      close: "Close",
      publishedOn: "Published on {date}",
      minutes: "{value} min read"
    },
    home: {
      hero: {
        title: "Mapping cognitive anchors for public orientation in complex environments",
        subtitle: "danswholesaleplants delivers deep research on how digital signage, immersive mapping and pedestrian flow design transform wayfinding across Belgian public buildings and urban spaces.",
        buttonPrimary: "Explore our analytical paths",
        buttonSecondary: "Review case studies",
        highlight1: "Comparative studies of multimodal signage systems within stations and interchange hubs.",
        highlight2: "Design methods for interactive plans embedded in kiosks and pedestrian mobility reports.",
        highlight3: "Evaluation frameworks for accessibility and legibility inside large public infrastructures."
      },
      heroImageAlt: "Digital signage guiding pedestrian flows inside a contemporary public hall",
      metrics: {
        title: "Research indicators",
        description: "A documentation body nourished by field observations, simulations and workshops with Belgian public organisations.",
        item1Value: "38 audited journeys",
        item1Label: "User journey audits across transport hubs and administrative buildings.",
        item2Value: "24 workshops",
        item2Label: "Co-creative sessions with facility managers and urban planners.",
        item3Value: "11 frameworks",
        item3Label: "Methodological references to measure clarity and legibility."
      },
      featured: {
        title: "Thematic focus",
        description: "Selected investigations that question the relationship between infrastructure, spatial storytelling and informational devices.",
        card1Title: "Multi-level spatial orientation",
        card1Text: "Analysis of visual and sonic continuities in complex hubs with a spotlight on Brussels gateways.",
        card2Title: "Adaptive digital signage",
        card2Text: "Designing interface flows able to mirror operational changes in real time.",
        card3Title: "Contextual mapping",
        card3Text: "Cartographic principles combining geospatial data, local anchors and mobility constraints.",
        card4Title: "Sensitive pedestrian experience",
        card4Text: "Sensorimotor studies enhancing indoor comfort within high-density spaces."
      },
      method: {
        title: "Analytical methodology",
        description: "Our publications rely on hybrid protocols blending on-site observation, flow modelling and information design.",
        point1: "Qualitative inventories of perceptual friction points, ranked by complexity levels.",
        point2: "Decision matrices involving public space managers and daily users.",
        point3: "Interface prototyping and route testing within simulated environments.",
        point4: "Graphic and narrative recommendations to align signage ecosystems."
      },
      recommendations: {
        title: "Key recommendations",
        description: "Summary of the guidelines published by danswholesaleplants to support public stakeholders.",
        item1Title: "Build progressive anchors",
        item1Text: "Maintain a coherent visual thread from the street to waiting areas through harmonised colours, typography and iconography.",
        item2Title: "Support decision making",
        item2Text: "Deploy interactive supports at decision points and provide alternative scenarios during saturation.",
        item3Title: "Ensure digital continuity",
        item3Text: "Synchronise physical signage and digital platforms to avoid contradictory routes.",
        item4Title: "Highlight local singularities",
        item4Text: "Ground spatial storytelling in the site’s history and uses to reinforce user confidence."
      },
      testimonials: {
        title: "Testimonials",
        description: "Feedback from public actors and academic partners involved in the research.",
        item1Quote: "The analytical grids by danswholesaleplants helped us prioritise signage interventions without breaking the site-wide coherence.",
        item1Name: "Mobility coordinator, Brussels",
        item2Quote: "The contextual mapping work clarified the essential anchors for visitors unfamiliar with nested architectures.",
        item2Name: "Heritage manager, Ghent",
        item3Quote: "The accessibility approach blending observation and information design improved circulation legibility for every audience.",
        item3Name: "Research officer, Liège"
      },
      blogPreview: {
        title: "Recent analyses",
        description: "In-depth articles decoding digital signage and spatial UX.",
        post1Title: "Cognitive frameworks for multimodal transit hubs",
        post1Excerpt: "Examining how visual and sonic beacons cooperate to streamline navigation inside complex nodes.",
        post2Title: "Adaptive signage supporting civic campuses",
        post2Excerpt: "Towards digital supports orchestrating dispersed public services within a single site.",
        post3Title: "Pedestrian mobility and storytelling in a cultural district",
        post3Excerpt: "Deploying sensitive routes linking museums, theatres and open public spaces."
      }
    },
    services: {
      heroTitle: "Analytical services for intelligible built environments",
      heroSubtitle: "We document orientation mechanisms and signage legibility through a user-driven lens.",
      introText: "Each engagement unfolds as a research cycle: scoping, data capture, modelling, restitution. We partner with public institutions to map journeys, clarify friction points and propose operational frameworks.",
      listTitle: "Fields of expertise",
      item1Title: "Spatial orientation audits",
      item1Text: "Multi-scale diagnostics, flow observation and detection of cognitive obstacles across public buildings.",
      item2Title: "Digital signage design principles",
      item2Text: "Crafting responsive visual systems tailored to interactive devices.",
      item3Title: "UX research for pedestrian mobility",
      item3Text: "Qualitative surveys, accompanied walks and user testing inside complex environments.",
      item4Title: "Frameworks for interactive maps",
      item4Text: "Information architecture for kiosks, applications and immersive mapping tools.",
      item5Title: "Accessibility consulting",
      item5Text: "Aligning journeys with accessibility standards and delivering enhanced legibility guidance.",
      processTitle: "Typical process",
      step1Title: "Shared framing",
      step1Text: "Inventory of spaces, public stakeholder objectives and identified user expectations.",
      step2Title: "Multi-source capture",
      step2Text: "On-site observation, light instrumentation, interviews and spatial surveys.",
      step3Title: "Modelling",
      step3Text: "Flow maps, usage scenarios and prototypes of digital signage content.",
      step4Title: "Restitution",
      step4Text: "Structured deliverables, recommendations and decision matrices to rank actions.",
      calloutTitle: "Recurrent deliverables",
      calloutItem1: "Illustrated journey atlas with commentary.",
      calloutItem2: "Content scripts for kiosks and displays.",
      calloutItem3: "Monitoring sheets for legibility indicators.",
      calloutItem4: "Roadmaps aligning physical and digital devices."
    },
    about: {
      heroTitle: "Understanding spatial orientation through situated research",
      heroSubtitle: "danswholesaleplants brings together specialists in information design, mapping and pedestrian flow analysis.",
      missionTitle: "Editorial mission",
      missionText: "We aim to document and clarify orientation strategies where circulations are dense and services numerous. We produce dossiers combining data, user narratives and prototyping.",
      pillarsTitle: "Methodological pillars",
      pillar1Title: "Field immersion",
      pillar1Text: "Extended observations and trajectory capture to grasp spatial reflexes.",
      pillar2Title: "Information design",
      pillar2Text: "Structuring content to guarantee message legibility in complex environments.",
      pillar3Title: "Continuous evaluation",
      pillar3Text: "Iterative loops based on user feedback to adjust routes and signage.",
      historyTitle: "Timeline",
      historyItem1Title: "2017 — Origins",
      historyItem1Text: "First studies in Belgian stations addressing the coexistence of tourist and commuter flows.",
      historyItem2Title: "2019 — Collaborative platform",
      historyItem2Text: "Opening to academic partners and launch of co-analysis workshops.",
      historyItem3Title: "2022 — Digital transition",
      historyItem3Text: "Deployment of a corpus on interactive supports and real-time data synchronisation.",
      teamTitle: "Combined skills",
      teamText: "Cartographers, urban planners, information designers and social scientists collaborate to interpret built environments."
    },
    blog: {
      heroTitle: "Analysis and studies",
      heroSubtitle: "Detailed explorations of digital signage, spatial mapping and pedestrian mobility in Belgium.",
      post1Meta: "Published on 12 March 2024",
      post2Meta: "Published on 4 February 2024",
      post3Meta: "Published on 12 January 2024",
      readArticle: "Read article"
    },
    post1: {
      metaInfo: "{date} · {minutes}",
      date: "12 March 2024",
      minutes: "14",
      title: "Cognitive frameworks for orienting multimodal transit hubs",
      intro: "Contemporary transit hubs behave like polycentric landscapes where trains, buses, trams and soft mobility converge. Their readability depends on coherent anchors despite simultaneous flows and layered architectures.",
      section1Title: "Unfolding the layers of an interchange node",
      section1Paragraph1: "The analysis starts with mapping the thresholds marking progressive entry into the hub. Each threshold carries distinct sensory anchors: background noise, natural light, crowd density. Travellers align these cues with signage messages. When one element diverges, dissonance appears and orientation slows down.",
      section1Paragraph2: "To measure this dissonance, we instrumented sample routes linking side entrances to the central platform. Pressure sensors and filmed observations revealed systematic slowdowns where digital signage failed to mirror the building’s natural axes.",
      section1SubTitle: "Hierarchising spatial storytelling",
      section1Paragraph3: "A clear message hierarchy is essential. Screens must anchor a narrative that ties each micro-decision to a macro destination. Line and platform references pair with coherent pictograms while physical and digital arrows overlap. Removing unnecessary redundancies frees reading time and builds trust.",
      section2Title: "Synchronising physical and digital devices",
      section2Paragraph1: "Digital devices mediate between architectural complexity and movement logic. They must reflect real-time circulation conditions while maintaining a constant narrative base. Affordance tests showed users first validate the consistency of graphic vocabulary before integrating dynamic updates.",
      section2Paragraph2: "We introduced a cross-coherence protocol: every variation sent to screens is simultaneously checked against printed maps and directional beacons. Minor divergence triggers domino effects, especially during last-minute platform changes.",
      section2SubTitle: "Making alternatives visible",
      section2Paragraph3: "During disruptions, clearly displayed alternate routes become a serenity factor. Interactive maps let travellers anticipate bottlenecks by showing secondary paths. However, alternatives must remain selective to avoid cognitive overload.",
      section3Title: "Recomposing pedestrian flows through simulation",
      section3Paragraph1: "Multi-agent simulation is a powerful tool to test signage configurations. We modelled Monday and Saturday peak hours to observe density variations. Results highlighted the importance of a message gradient: rapid and synthetic for commuters, more descriptive for occasional visitors.",
      section3Paragraph2: "Feedback loops between simulation and on-site observation proved essential. Each cycle led to adjustments in font size, screen positioning and chromatic contrast to ensure legibility under varying light conditions.",
      section3SubTitle: "Expanding the sensory palette",
      section3Paragraph3: "Beyond vision, floor vibrations and soundscapes can signal orientation. We experimented with subtle sound layers guiding corridors leading to side platforms. Feedback indicates better anticipation of bifurcations, requiring fine coordination with official announcements.",
      conclusionTitle: "Towards an alignment framework",
      conclusionParagraph: "Structuring a transit hub means orchestrating a mesh of devices and signals converging towards a shared heading. The frameworks presented here spotlight potential breakpoints and propose graduated responses. Next steps involve sharing these practices with other Belgian transport operators to stabilise nationwide anchors."
    },
    post2: {
      metaInfo: "{date} · {minutes}",
      date: "4 February 2024",
      minutes: "13",
      title: "Adaptive signage for a multi-service civic campus",
      intro: "Civic campuses cluster administrative, cultural and social services within a compact perimeter. Users alternate between quick errands and exploratory journeys, requiring signage that adapts to changing rhythms.",
      section1Title: "Understanding the mosaic of uses",
      section1Paragraph1: "The study began by inventorying the campus audiences: residents, occasional visitors, city staff, associations. Each profile demands specific information granularity. Residents optimise time, while associations seek context about shared rooms and equipment.",
      section1Paragraph2: "Observations showed that juxtaposing traditional panels and dynamic displays created blind spots. Some entrances were over-signalled while others lacked basic cues. We mapped information densities to redistribute messages evenly.",
      section1SubTitle: "Building a common lexicon",
      section1Paragraph3: "Rationalisation started with a transversal lexicon. Terms used in administrative documents, online platforms and physical panels now align. A linguistic charter preserves each service’s identity while respecting shared naming conventions.",
      section2Title: "Activating digital supports contextually",
      section2Paragraph1: "Interactive kiosks are tuned to deliver scenarios depending on time of day. At peak hours, the interface highlights open counters and estimated queues. During calmer periods, it proposes thematic routes linking cultural spaces.",
      section2Paragraph2: "This adaptability relies on an editorial engine connected to service calendars. Managers schedule priority messages and trigger local alerts. Information remains concise to preserve legibility.",
      section2SubTitle: "Drawing a relational topography",
      section2Paragraph3: "We modelled the campus as a relational graph where each node is a service and edges represent user flows. Physical signage materialises this topography via totems, light ribbons and layered maps. Visitors grasp service connections at a glance.",
      section3Title: "Testing accessibility and robustness",
      section3Paragraph1: "User tests involved people with varied needs, including low-vision visitors and seniors. Journey assessments confirmed the importance of strong contrast and consistent reading heights. Tactile devices are paired with optional sound cues.",
      section3Paragraph2: "System robustness also depends on legibility when screens go offline. We defined a degraded mode where physical signage takes over via magnetic inserts easily updated by staff.",
      section3SubTitle: "Considering the urban climate",
      section3Paragraph3: "Outdoor paths cross planted areas and sheltered zones. Signage must resist weather variations while staying harmonious. Reflective materials and anti-glare coatings preserve visibility in rainy conditions.",
      conclusionTitle: "A readable and evolutive campus",
      conclusionParagraph: "Adaptive signage succeeds only when embedded within a coherent ecosystem. By combining data, information design and user feedback, the civic campus now holds a sustainable framework that will accompany future transformations while preserving the quality of reception."
    },
    post3: {
      metaInfo: "{date} · {minutes}",
      date: "12 January 2024",
      minutes: "15",
      title: "Pedestrian mobility and storytelling within a cultural district",
      intro: "A cultural district assembles theatres, museums, archives and public squares. Attendance fluctuates with programmes, demanding flexible readings of spaces and atmospheres. Spatial storytelling becomes a driver of collective appropriation.",
      section1Title: "Identifying the district rhythms",
      section1Paragraph1: "We analysed flows across three seasons to capture the alternation between tourist attendance and neighbourhood life. Data reveals peaks in early evening and quieter midday periods. Anchors must adapt to these pulses.",
      section1Paragraph2: "Mapping tempos exposed underused corridors that nevertheless connect major cultural venues. These interstices offer opportunities for narrative devices extending experiences between visits.",
      section1SubTitle: "Creating an urban dramaturgy",
      section1Paragraph3: "Spatial storytelling relies on gentle dramaturgy: light tones, message rhythm, sound sequences. We defined layered atmospheres guiding visitors without saturating space. Transitions appear through micro-installations blending text, cartography and graphic symbols.",
      section2Title: "Showcasing territorial resources",
      section2Paragraph1: "Each institution shares key content feeding digital stations. Interfaces deliver archival excerpts, historical markers and thematic maps. Users compose personal routes according to available time.",
      section2Paragraph2: "To avoid dispersion, we designed a unified graphic line inspired by local architecture. Colours, typefaces and icons echo district materials. Visual coherence strengthens message credibility.",
      section2SubTitle: "Supporting gentle mobility",
      section2Paragraph3: "Signage promotes cycling routes and calm pedestrian areas. Maps overlay accessible paths, walking times and breathing spots. Visitors quickly understand how to move smoothly without motorised transport.",
      section3Title: "Orchestrating the night experience",
      section3Paragraph1: "Nightlife requires special attention. Light devices act as guides and ambience markers. We developed chromatic gradients signalling main directions while respecting residents’ tranquillity.",
      section3Paragraph2: "Interactive totems adopt a night mode with high contrast and concise information. Alternative routes appear when crowds exit performances. Flexibility secures fluid and safe circulation.",
      section3SubTitle: "Measuring appropriation",
      section3Paragraph3: "Surveys and footfall sensors assessed appropriation. Results show increased attendance of lesser-known spots and better flow distribution at peak hours.",
      conclusionTitle: "Towards shared storytelling",
      conclusionParagraph: "The cultural district gains readability when institutions share a common vision of hospitality. Spatial storytelling supported by digital signage and mapping nurtures a collective identity. Upcoming phases will integrate real-time feedback to keep refining the experience."
    },
    contact: {
      heroTitle: "Get in touch",
      heroSubtitle: "Reach out to share feedback, propose collaborations or request additional information about our publications.",
      addressLabel: "Address",
      addressValue: "Rue de la Loi 155, 1040 Brussels, Belgium",
      phoneLabel: "Phone",
      phoneValue: "+32 2 702 45 18",
      emailLabel: "Email",
      emailValue: "info@danswholesaleplants.com",
      formTitle: "Contact form",
      formSubtitle: "We reply within two business days.",
      fieldName: "Your name",
      fieldOrganisation: "Organisation",
      fieldEmail: "Email address",
      fieldTopic: "Topic",
      fieldMessage: "Message",
      fieldTopicOption1: "Spatial orientation",
      fieldTopicOption2: "Digital signage",
      fieldTopicOption3: "Spatial mapping",
      fieldTopicOption4: "Other request",
      submitButton: "Send",
      mapTitle: "danswholesaleplants location",
      mapCaption: "Interactive map centered on Brussels and Rue de la Loi.",
      infoTitle: "Practical information"
    },
    faq: {
      heroTitle: "Frequently asked questions",
      heroSubtitle: "Answers to recurring questions about our approaches and publications.",
      item1Question: "How do you select study sites?",
      item1Answer: "We primarily collaborate with Belgian public institutions. Selection depends on journey complexity and diversity of uses.",
      item2Question: "Do you publish operational plans?",
      item2Answer: "We release analytical frameworks, recommendations and prototypes. Final implementation remains with facility managers.",
      item3Question: "How are user tests conducted?",
      item3Answer: "Tests combine on-site observation, interviews and simulations. Volunteers include regular and occasional users.",
      item4Question: "Do you offer long-term support?",
      item4Answer: "We deliver modular research cycles. Each institution can opt for punctual phases or extended monitoring.",
      item5Question: "Are contents released under an open licence?",
      item5Answer: "Summaries are accessible freely. Sensitive datasets remain shared under agreements with partners."
    },
    terms: {
      title: "Terms of use",
      intro: "These terms govern the use of danswholesaleplants.com. Accessing the site means you accept them.",
      section1Title: "1. Purpose",
      section1Text: "The site shares analytical content on spatial orientation and digital signage. No commercial service is directly offered.",
      section2Title: "2. Site access",
      section2Text: "Access is free. The publisher may suspend sections of the site for maintenance or updates.",
      section3Title: "3. Intellectual property",
      section3Text: "Texts, visuals and data are protected by copyright. Reuse requires prior authorisation.",
      section4Title: "4. External contributions",
      section4Text: "Partners may submit contributions. The publisher may select, edit or remove them.",
      section5Title: "5. Liability",
      section5Text: "The publisher strives for accuracy but cannot guarantee the absence of unintentional errors or omissions.",
      section6Title: "6. Hyperlinks",
      section6Text: "The site may link to external resources. The publisher is not responsible for their content or availability.",
      section7Title: "7. Personal data",
      section7Text: "Data processing is described in the privacy policy. No data is transferred to third parties for commercial purposes.",
      section8Title: "8. Cookies",
      section8Text: "Cookie management is detailed in the cookie policy.",
      section9Title: "9. Changes",
      section9Text: "The publisher may adapt these terms to follow editorial or legal developments.",
      section10Title: "10. Severability",
      section10Text: "If any clause is deemed invalid, the remaining provisions remain fully effective.",
      section11Title: "11. Permitted use",
      section11Text: "Content may be used for information, research or internal study purposes only.",
      section12Title: "12. Security",
      section12Text: "Users must not interfere with site operation or attempt to access unauthorised areas.",
      section13Title: "13. Governing law",
      section13Text: "These terms are governed by Belgian law. Disputes fall under Brussels courts.",
      section14Title: "14. Contact",
      section14Text: "Questions regarding these terms can be sent to info@danswholesaleplants.com."
    },
    privacy: {
      title: "Privacy policy",
      intro: "This policy explains how danswholesaleplants processes data collected through the site.",
      section1Title: "1. Data controller",
      section1Text: "The controller is danswholesaleplants, Rue de la Loi 155, 1040 Brussels, Belgium.",
      section2Title: "2. Data collected",
      section2Text: "We collect information submitted via the contact form: name, organisation, email, topic and message.",
      section3Title: "3. Purposes",
      section3Text: "Data is used to answer requests, organise follow-up conversations and provide relevant information about our publications.",
      section4Title: "4. Legal basis",
      section4Text: "Processing relies on legitimate interest to respond to queries and on consent where required.",
      section5Title: "5. Retention",
      section5Text: "Data is stored for three years from the last interaction, unless legal obligations require longer retention.",
      section6Title: "6. Recipients",
      section6Text: "Data is available to editorial members handling enquiries. No commercial transfer occurs.",
      section7Title: "7. Hosting",
      section7Text: "The site is hosted on servers located within the European Union with industry-standard security.",
      section8Title: "8. Rights",
      section8Text: "You may access, rectify, erase, restrict, object to or port your data.",
      section9Title: "9. Exercising rights",
      section9Text: "To exercise rights, email info@danswholesaleplants.com specifying your request. A response is provided within one month.",
      section10Title: "10. Updates",
      section10Text: "This policy may evolve. The latest update is indicated at the top of the document."
    },
    cookies: {
      title: "Cookie policy",
      intro: "This policy covers cookies used on danswholesaleplants.com.",
      section1Title: "Cookie usage",
      section1Text: "Cookies help measure audience, remember language preferences and secure forms.",
      tableCaption: "Table of cookies in use",
      nameHeader: "Name",
      providerHeader: "Provider",
      typeHeader: "Type",
      purposeHeader: "Purpose",
      durationHeader: "Duration",
      row1Name: "site_lang",
      row1Provider: "danswholesaleplants",
      row1Type: "Functional",
      row1Purpose: "Stores the selected display language.",
      row1Duration: "12 months",
      row2Name: "cookie_consent",
      row2Provider: "danswholesaleplants",
      row2Type: "Functional",
      row2Purpose: "Records cookie consent choice.",
      row2Duration: "12 months",
      row3Name: "analytics_session",
      row3Provider: "danswholesaleplants",
      row3Type: "Audience measurement",
      row3Purpose: "Analyses visited pages to improve content.",
      row3Duration: "24 hours",
      managementTitle: "Managing cookies",
      managementText: "You can refuse non-essential cookies through the banner or configure your browser preferences."
    },
    refund: {
      title: "Withdrawal policy",
      intro: "This policy explains how to request the removal of a contribution or mention on danswholesaleplants.",
      section1Title: "1. Scope",
      section1Text: "Applies to texts, visuals and quotes published with partner or contributor consent.",
      section2Title: "2. Initial request",
      section2Text: "Send a written request specifying the element concerned and the reason for withdrawal.",
      section3Title: "3. Acknowledgement",
      section3Text: "A confirmation is sent within seven business days after receiving the request.",
      section4Title: "4. Review",
      section4Text: "The editorial team checks compliance with existing agreements.",
      section5Title: "5. Decision",
      section5Text: "Final decision is communicated within thirty calendar days.",
      section6Title: "6. Withdrawal methods",
      section6Text: "Withdrawal may involve deletion, anonymisation or contextual update.",
      section7Title: "7. Traceability",
      section7Text: "Each change is recorded to ensure transparent tracking.",
      section8Title: "8. Co-produced content",
      section8Text: "For jointly produced content, a collective discussion is organised.",
      section9Title: "9. Limits",
      section9Text: "Withdrawal is not guaranteed when information is necessary to understand a public dossier.",
      section10Title: "10. Contact",
      section10Text: "Requests should be sent to info@danswholesaleplants.com."
    },
    disclaimer: {
      title: "Disclaimer",
      intro: "The website provides analyses and guidance for informational purposes.",
      point1: "Content never replaces specialised regulatory, legal or architectural expertise.",
      point2: "Published studies rely on dated observations. Situations may evolve without prior notice.",
      point3: "danswholesaleplants declines responsibility for decisions taken based on published information.",
      point4: "External links contextualise analyses; their content is beyond the publisher’s responsibility.",
      point5: "Operational decisions should involve competent authorities or qualified professionals."
    },
    thankyou: {
      title: "Thank you for your message",
      message: "Your request has been received. We will reply within two business days.",
      backLink: "Back to home"
    },
    cookieBanner: {
      title: "Cookie management",
      text: "We use cookies to remember your language and measure audience. You may accept or refuse non-essential cookies.",
      accept: "Accept",
      decline: "Decline"
    },
    toast: {
      languageChanged: "Language updated.",
      formSubmitting: "Sending…",
      formSubmitted: "Message sent, redirecting."
    }
  }
};

function getTranslation(key, dict) {
  return key.split(".").reduce((acc, part) => (acc && acc[part] !== undefined ? acc[part] : undefined), dict) ?? "";
}

function camelToKebab(str) {
  return str.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
}

function formatPlaceholders(text, replacements = {}) {
  let output = text;
  Object.keys(replacements).forEach((token) => {
    output = output.replace(`{${token}}`, replacements[token]);
  });
  return output;
}

let currentLang = DEFAULT_LANG;

function applyTranslations(lang) {
  const dict = I18N[lang];
  if (!dict) return;
  currentLang = lang;
  document.documentElement.setAttribute("lang", lang);

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    let value = getTranslation(key, dict);
    if (value && el.dataset.i18nParams) {
      try {
        const params = JSON.parse(el.dataset.i18nParams);
        value = formatPlaceholders(value, params);
      } catch {
        // ignore malformed params
      }
    }
    if (typeof value === "string") {
      el.textContent = value;
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach((el) => {
    const key = el.dataset.i18nHtml;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      let htmlValue = value;
      if (el.dataset.i18nParams) {
        try {
          const params = JSON.parse(el.dataset.i18nParams);
          htmlValue = formatPlaceholders(htmlValue, params);
        } catch {
          // ignore
        }
      }
      el.innerHTML = htmlValue;
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      el.setAttribute("placeholder", value);
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.dataset.i18nTitle;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      if (el.tagName.toLowerCase() === "title") {
        document.title = value;
      }
      el.textContent = value;
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.dataset.i18nMeta;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      el.setAttribute("content", value);
    }
  });

  document.querySelectorAll("[data-i18n-attr-alt]").forEach((el) => {
    const key = el.dataset.i18nAttrAlt;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      el.setAttribute("alt", value);
    }
  });

  document.querySelectorAll("[data-i18n-attr-title]").forEach((el) => {
    const key = el.dataset.i18nAttrTitle;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      el.setAttribute("title", value);
    }
  });

  document.querySelectorAll("[data-i18n-attr-aria-label]").forEach((el) => {
    const key = el.dataset.i18nAttrAriaLabel;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      el.setAttribute("aria-label", value);
    }
  });

  document.querySelectorAll("[data-i18n-attr-data-lang]").forEach((el) => {
    const key = el.dataset.i18nAttrDataLang;
    const value = getTranslation(key, dict);
    if (typeof value === "string") {
      el.setAttribute("data-lang", value);
    }
  });

  document.querySelectorAll("[data-i18n-attr]").forEach((el) => {
    const mappings = el.dataset.i18nAttr.split(",");
    mappings.forEach((mapping) => {
      const [attr, key] = mapping.split(":").map((part) => part.trim());
      const value = getTranslation(key, dict);
      if (attr && typeof value === "string") {
        el.setAttribute(attr, value);
      }
    });
  });

  document.querySelectorAll("[data-i18n-attr-generic]").forEach((el) => {
    const attrMap = el.dataset.i18nAttrGeneric.split(",");
    attrMap.forEach((entry) => {
      const [attrName, key] = entry.split(":").map((part) => part.trim());
      const value = getTranslation(key, dict);
      if (attrName && typeof value === "string") {
        el.setAttribute(attrName, value);
      }
    });
  });

  document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
    const mapping = el.dataset.i18nAria;
    mapping.split(",").forEach((pair) => {
      const [attr, key] = pair.split(":").map((part) => part.trim());
      const value = getTranslation(key, dict);
      if (attr && typeof value === "string") {
        el.setAttribute(`aria-${camelToKebab(attr)}`, value);
      }
    });
  });

  localStorage.setItem(STORAGE_KEY, lang);
  updateLanguageToggle();
}

function updateLanguageToggle() {
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.lang === currentLang);
  });
}

function setLanguage(lang) {
  const targetLang = I18N[lang] ? lang : DEFAULT_LANG;
  applyTranslations(targetLang);
  showToast(getTranslation("toast.languageChanged", I18N[targetLang]));
}

function showToast(message) {
  if (!message) return;
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "toast-container";
    container.setAttribute("aria-live", "polite");
    container.setAttribute("aria-atomic", "true");
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("fade-out");
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    setTimeout(() => {
      toast.remove();
    }, 350);
  }, 2500);
}

function initNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".primary-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");
    const labelKey = isOpen ? "header.toggle.close" : "header.toggle.open";
    const label = getTranslation(labelKey, I18N[currentLang]);
    toggle.setAttribute("aria-label", label);
  });
}

function initLanguageSwitcher() {
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.lang;
      if (lang !== currentLang) {
        applyTranslations(lang);
        showToast(getTranslation("toast.languageChanged", I18N[lang]));
      }
    });
  });
}

function initFadeIn() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll(".fade-in-element").forEach((el) => observer.observe(el));
}

function initCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;
  const consent = localStorage.getItem("cookie_consent");
  if (!consent) {
    banner.classList.remove("hidden");
  }
  const acceptBtn = banner.querySelector("[data-cookie-accept]");
  const declineBtn = banner.querySelector("[data-cookie-decline]");
  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem("cookie_consent", "accepted");
      banner.classList.add("hidden");
    });
  }
  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      localStorage.setItem("cookie_consent", "declined");
      banner.classList.add("hidden");
    });
  }
}

function initFormHandling() {
  const forms = document.querySelectorAll("form[data-enhanced='true']");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const langDict = I18N[currentLang];
      showToast(getTranslation("toast.formSubmitting", langDict));
      setTimeout(() => {
        showToast(getTranslation("toast.formSubmitted", langDict));
        const action = form.getAttribute("action");
        if (action) {
          window.location.href = action;
        }
      }, 600);
    });
  });
}

function populateDynamicMeta() {
  document.querySelectorAll("[data-i18n-params]").forEach((el) => {
    const key = el.dataset.i18n;
    const params = JSON.parse(el.dataset.i18nParams || "{}");
    const value = formatPlaceholders(getTranslation(key, I18N[currentLang]), params);
    el.textContent = value;
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const storedLang = localStorage.getItem(STORAGE_KEY) || DEFAULT_LANG;
  applyTranslations(storedLang);
  initLanguageSwitcher();
  initNavToggle();
  initFadeIn();
  initCookieBanner();
  initFormHandling();
  populateDynamicMeta();
});