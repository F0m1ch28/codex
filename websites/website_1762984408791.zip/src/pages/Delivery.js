import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Delivery.module.css';

const Delivery = () => (
  <>
    <Helmet>
      <title>Доставка та оплата — Kyiv Pizzeria</title>
      <meta
        name="description"
        content="Дізнайтеся умови доставки Kyiv Pizzeria: зона покриття, час, вартість, способи оплати та програма лояльності."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span className="tag">Доставка</span>
          <h1>Тепла піца у вашому домі</h1>
          <p>Випікаємо піцу після замовлення та доставляємо в термобоксах, аби зберегти текстуру та температуру.</p>
        </div>
      </div>
    </section>

    <section className={`${styles.details} sectionSpacing`}>
      <div className="container">
        <div className={styles.grid}>
          <article>
            <h2>Зона доставки</h2>
            <p>Доставляємо в межах 7 км від вул. Хрещатик, 1. У віддалені райони організуємо індивідуальний трансфер за попереднім погодженням.</p>
            <ul>
              <li>Центр, Поділ, Печерськ — 30 хвилин</li>
              <li>Оболонь, Солом’янка — 35–40 хвилин</li>
              <li>Позняки, Лівий берег — 45 хвилин</li>
            </ul>
          </article>
          <article>
            <h2>Умови та оплата</h2>
            <p>Мінімальна сума замовлення — 400 ₴. Доставка безкоштовна від 900 ₴, інакше — 90 ₴.</p>
            <ul>
              <li>Оплата карткою на сайті або кур’єру</li>
              <li>Apple Pay, Google Pay, безготівковий рахунок</li>
              <li>Промокоди та сертифікати застосовуються онлайн</li>
            </ul>
          </article>
          <article>
            <h2>Програма лояльності</h2>
            <p>З кожного замовлення 5% повертається бонусами. Їх можна використати вже з наступної покупки.</p>
            <ul>
              <li>Після 5-го замовлення — десерт у подарунок</li>
              <li>Після 10-го — доступ до закритих дегустацій</li>
            </ul>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default Delivery;