import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { value: 12, suffix: '+', label: 'років печемо для Києва' },
  { value: 43, suffix: '+', label: 'авторських рецептів піци' },
  { value: 18, suffix: 'k', label: 'задоволених гостей щомісяця' },
  { value: 30, suffix: ' хв', label: 'середній час доставки' }
];

const advantagesData = [
  {
    title: 'Дров’яна піч з Київського Подолу',
    description: 'Випікаємо піцу на фруктових дровах, які надають тіста карамельний відтінок та пружність.',
    icon: '🔥'
  },
  {
    title: 'Фермерські інгредієнти',
    description: 'Горить серце за локальні продукти: моцарела з Черкащини, прошуто з карпатських господарств.',
    icon: '🥬'
  },
  {
    title: 'Команда піцайоло-чемпіонів',
    description: 'Наш шеф пройшов стажування у Неаполі та навчає молодь мистецтву ручного замісу.',
    icon: '👨‍🍳'
  },
  {
    title: 'Атмосфера маленької Італії',
    description: 'Тепле світло, вініл та жива зелень — простір, де повертаються на перше побачення з містом.',
    icon: '🌿'
  }
];

const pizzaData = [
  {
    title: 'Львівська вулиця',
    ingredients: 'копчена грудинка, томатний соус, бринза, печені сливи, рукола, бальзамік',
    price: '245 ₴',
    image: 'https://picsum.photos/seed/pizza1/500/400'
  },
  {
    title: 'Подільська маргарита',
    ingredients: 'томат Сан-Марцано, моцарела ді буфала, базилік, оливкова олія',
    price: '215 ₴',
    image: 'https://picsum.photos/seed/pizza2/500/400'
  },
  {
    title: 'Веганське сафарі',
    ingredients: 'крем з нуту, томати конфі, печені кабачки, мигдаль, трави',
    price: '229 ₴',
    image: 'https://picsum.photos/seed/pizza3/500/400'
  },
  {
    title: 'Софійська з грушею',
    ingredients: 'горгонзола, груша, мед з лавандою, горіх пекан, тартюфо',
    price: '265 ₴',
    image: 'https://picsum.photos/seed/pizza4/500/400'
  },
  {
    title: 'Київський ранчо',
    ingredients: 'сир страчатела, курятина су-від, кукурудза, соус ранч, зелена цибуля',
    price: '239 ₴',
    image: 'https://picsum.photos/seed/pizza5/500/400'
  },
  {
    title: 'Дніпровський лосось',
    ingredients: 'власний крем-чиз, слабосолений лосось, каперси, лайм, кріп',
    price: '279 ₴',
    image: 'https://picsum.photos/seed/pizza6/500/400'
  }
];

const testimonials = [
  {
    name: 'Олена Паламарчук',
    role: 'гастрономічний блогер',
    quote: 'Піч, яку ви відчуєте ще на вході. Сир тягнеться, хрустке тісто, а персонал знає, який настрій у кожного столика. Київська романтика на тарілці.',
    avatar: 'https://picsum.photos/seed/guest1/120/120'
  },
  {
    name: 'Ігор Малиш',
    role: 'засновник креативної агенції',
    quote: 'Зустрічали тут клієнтів з Німеччини — натхнення та сервіс на європейському рівні. Італія зустрічається з Києвом без жодних компромісів.',
    avatar: 'https://picsum.photos/seed/guest2/120/120'
  },
  {
    name: 'Марія Стадник',
    role: 'мешканка Печерська',
    quote: 'Доставка приїхала ще гарячою, тісто не розмокло. Персонал телефонує, щоб переконатися, що все смакує. Це сервіс, якого бракувало місту.',
    avatar: 'https://picsum.photos/seed/guest3/120/120'
  },
  {
    name: 'Павло Рибак',
    role: 'організатор подій',
    quote: 'Організовували кулінарний майстер-клас для команди — ребята зробили шоу. Тепер кожен знає, що таке справжній неаполітанський бортик.',
    avatar: 'https://picsum.photos/seed/guest4/120/120'
  }
];

const venueImages = [
  {
    src: 'https://picsum.photos/seed/venue3/800/600',
    alt: 'Затишний інтер’єр пиццерії з теплим освітленням'
  },
  {
    src: 'https://picsum.photos/seed/venue1/800/600',
    alt: 'Барна стійка з авторськими напоями'
  },
  {
    src: 'https://picsum.photos/seed/venue2/800/600',
    alt: 'Зелена зона з панорамними вікнами'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Ручний заміс',
    text: 'Використовуємо борошно типу 00, замішуємо без машин, даємо тісту 48 годин на ферментацію.'
  },
  {
    step: '02',
    title: 'Підбір продуктів',
    text: 'Щоранку отримуємо поставки від фермерів. Соуси та пасти готуємо за сімейними рецептами.'
  },
  {
    step: '03',
    title: 'Піч на дровах',
    text: 'Підтримуємо температуру 450°C, аби бортик був аерованим, а корж — хрустким, з характерними плямами леопарда.'
  },
  {
    step: '04',
    title: 'Красива подача',
    text: 'Кожна піца подається з локальними соусами, мікрозеленню та авторськими топінгами від шефа.'
  }
];

const projects = [
  {
    id: 1,
    category: 'корпоративи',
    title: 'Тімбілдінг для ІТ-команди',
    description: 'Майстер-клас з випікання піци та дегустація українських вин.',
    image: 'https://picsum.photos/seed/project1/1200/800'
  },
  {
    id: 2,
    category: 'зустрічі',
    title: 'Романтичний вечір на двох',
    description: 'Персоналізоване меню, жива музика та приватний сомельє.',
    image: 'https://picsum.photos/seed/project2/1200/800'
  },
  {
    id: 3,
    category: 'благодійність',
    title: 'Вечеря для волонтерів',
    description: 'Передаємо частину продажів на підтримку ветеранських ініціатив.',
    image: 'https://picsum.photos/seed/project3/1200/800'
  },
  {
    id: 4,
    category: 'корпоративи',
    title: 'Запуск бренду',
    description: 'Сцена, світло та фуршет з міні-піццою для 150 гостей.',
    image: 'https://picsum.photos/seed/project4/1200/800'
  }
];

const faqItems = [
  {
    question: 'Чи можна замовити піцу з безглютеновим тістом?',
    answer: 'Так, ми готуємо безглютенове тісто на окремому виробництві. Просимо повідомити за 2 години до візиту або позначити опцію в онлайн-замовленні.'
  },
  {
    question: 'Який радіус та час доставки?',
    answer: 'Доставляємо в радіусі 7 км від вул. Хрещатик, 1. Середній час доставки — 30 хвилин, у години пік — до 45 хвилин.'
  },
  {
    question: 'Чи проводите майстер-класи для дітей?',
    answer: 'Так, щосуботи о 12:00. Кількість місць обмежена, тому попередній запис обов’язковий.'
  },
  {
    question: 'Які способи оплати ви приймаєте?',
    answer: 'Готівка, банківські карти, Apple Pay, Google Pay, а також безготівковий рахунок для корпоративних клієнтів.'
  },
  {
    question: 'Чи можна прийти з домашнім улюбленцем?',
    answer: 'Ми pet-friendly! У холі є мисочка з водою та спеціальні місця біля входу.'
  }
];

const blogPosts = [
  {
    title: 'Як ми перетворюємо локальні продукти на неаполітанську класику',
    date: '5 січня 2024',
    excerpt: 'Чим особлива моцарела від сімейної сироварні з Черкащини та як ми співпрацюємо з фермерами.',
    link: '/about',
    image: 'https://picsum.photos/seed/blog1/800/600'
  },
  {
    title: 'Гід по винній карті: що пити з піцою взимку',
    date: '19 грудня 2023',
    excerpt: 'Сомельє Марко ділиться порадами, які вина пасують до наших зимових сезонних піц.',
    link: '/menu',
    image: 'https://picsum.photos/seed/blog2/800/600'
  },
  {
    title: 'Кулінарні події у Kyiv Pizzeria',
    date: '2 листопада 2023',
    excerpt: 'Розповідаємо, як організовуємо вечері з шефом, закриті презентації та благодійні вечори.',
    link: '/services',
    image: 'https://picsum.photos/seed/blog3/800/600'
  }
];

const Home = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeProjectFilter, setActiveProjectFilter] = useState('усі');
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const timers = statsData.map((stat, idx) => {
      const target = stat.value;
      const duration = 1600;
      const frameDuration = 40;
      const totalFrames = Math.round(duration / frameDuration);
      let frame = 0;

      return setInterval(() => {
        frame += 1;
        const progress = Math.min(frame / totalFrames, 1);
        const value = Math.floor(progress * target);
        setCounters((prev) => {
          const updated = [...prev];
          updated[idx] = value;
          return updated;
        });
        if (progress === 1) {
          clearInterval(timers[idx]);
        }
      }, frameDuration);
    });

    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  useEffect(() => {
    const autoplay = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(autoplay);
  }, []);

  useEffect(() => {
    const elements = document.querySelectorAll('[data-reveal]');
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.visible);
            observer.unobserve(entry.target);
          }
        }),
      { threshold: 0.15 }
    );
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeProjectFilter === 'усі') return projects;
    return projects.filter((project) => project.category === activeProjectFilter);
  }, [activeProjectFilter]);

  return (
    <>
      <Helmet>
        <title>Kyiv Pizzeria — Авторська піца у центрі Києва</title>
        <meta
          name="description"
          content="Скуштуйте авторські піци на дровах, сезонні страви та атмосферу маленької Італії на Хрещатику. Доставка, майстер-класи та корпоративи."
        />
        <meta
          name="keywords"
          content="піца Київ, піцерія Київ центр, авторська піца, доставка піци, піч на дровах Київ"
        />
      </Helmet>

      <section
        className={`${styles.hero} ${styles.reveal}`}
        data-reveal
        aria-labelledby="hero-heading"
      >
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Смак Києва з неаполітанським характером</span>
            <h1 id="hero-heading">
              Піца на дровах у самому серці Києва — відчуття, до яких хочеться повертатися
            </h1>
            <p>
              Ми створюємо піцу, що розповідає історію міста. Лише фермерські продукти, дров’яна піч та команда, закохана в свою справу. Завітайте на Хрещатик або замовте
              доставку з теплом в кожній коробці.
            </p>
            <div className={styles.heroActions}>
              <Link to="/menu" className={styles.primaryButton}>
                Переглянути меню
              </Link>
              <Link to="/delivery" className={styles.secondaryButton}>
                Доставка та оплата
              </Link>
            </div>
          </div>
          <div className={styles.stats}>
            {statsData.map((stat, idx) => (
              <article className={styles.statCard} key={stat.label}>
                <span className={styles.statValue}>
                  {counters[idx]}
                  {stat.suffix}
                </span>
                <p>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.advantages}`}
        data-reveal
        aria-labelledby="advantages-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Чому нас обирають</span>
            <h2 id="advantages-heading">Наші переваги</h2>
            <p>
              Усе, що ми робимо, створюється з увагою до деталей: від тісту до настрою за столом. Саме це забезпечує лояльність постійних гостей.
            </p>
          </div>
          <div className={styles.advantagesGrid}>
            {advantagesData.map((item) => (
              <article key={item.title} className={styles.advantageCard}>
                <div className={styles.iconWrapper} aria-hidden="true">
                  {item.icon}
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.testimonials}`}
        data-reveal
        aria-labelledby="testimonials-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Відгуки</span>
            <h2 id="testimonials-heading">Що кажуть наші гості</h2>
            <p>Ми слухаємо кожного гостя і ростемо завдяки вашій довірі. Ось кілька історій про Kyiv Pizzeria.</p>
          </div>
          <div className={styles.testimonialSlider} role="region" aria-live="polite">
            {testimonials.map((item, index) => (
              <article
                key={item.name}
                className={`${styles.testimonialCard} ${index === testimonialIndex ? styles.testimonialActive : styles.testimonialHidden}`}
              >
                <div className={styles.testimonialHeader}>
                  <img src={item.avatar} alt={`Фото ${item.name}`} />
                  <div>
                    <h3>{item.name}</h3>
                    <span>{item.role}</span>
                  </div>
                </div>
                <p>“{item.quote}”</p>
              </article>
            ))}
            <div className={styles.testimonialDots}>
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setTestimonialIndex(idx)}
                  aria-label={`Показати відгук ${idx + 1}`}
                  className={testimonialIndex === idx ? styles.dotActive : ''}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.popular}`}
        data-reveal
        aria-labelledby="popular-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Популярні позиції</span>
            <h2 id="popular-heading">Популярні піци</h2>
            <p>Вибрані гостями та нашими шеф-піцайоло. Скуштуйте і знайдіть свою улюблену інтерпретацію класики.</p>
          </div>
          <div className={styles.pizzaGrid}>
            {pizzaData.map((pizza) => (
              <article key={pizza.title} className={styles.pizzaCard}>
                <div className={styles.pizzaImageWrap}>
                  <img src={pizza.image} alt={`Піца ${pizza.title}`} loading="lazy" />
                  <span className="badge">{pizza.price}</span>
                </div>
                <div className={styles.pizzaContent}>
                  <h3>{pizza.title}</h3>
                  <p>{pizza.ingredients}</p>
                  <Link to="/menu" className={styles.link}>
                    Детальніше про склад →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.aboutSection}`}
        data-reveal
        aria-labelledby="about-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Kyiv Pizzeria</span>
            <h2 id="about-heading">Про нас</h2>
            <p>Ми почали як маленька сімейна піч на Подолі, а сьогодні — місце, де зустрічаються мандрівники та кияни.</p>
          </div>
          <div className={styles.aboutGrid}>
            <div>
              <h3>Наша історія</h3>
              <p>
                Першу піцу ми спекли у кам’яній печі на подвір’ї родинного будинку. Звідтоді зберігаємо рецепти, які передаємо
                новому поколінню. Сьогодні наш простір — це поєднання київської гостинності та неаполітанських традицій.
              </p>
              <p>
                У залі звучать платівки, на кухні працюють випускники світових кулінарних шкіл, а на стінах — картини сучасних українських художників.
              </p>
              <div className={styles.aboutMeta}>
                <div>
                  <strong>48 годин</strong>
                  <span>ферментації тіста</span>
                </div>
                <div>
                  <strong>100%</strong>
                  <span>локальних продуктів у меню</span>
                </div>
              </div>
              <Link to="/about" className={styles.primaryLink}>
                Дізнатися більше про команду
              </Link>
            </div>
            <div className={styles.aboutImage}>
              <img
                src="https://picsum.photos/seed/aboutkyiv/800/600"
                alt="Піцайоло готує піцу у дров’яній печі"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.venueSection}`}
        data-reveal
        aria-labelledby="venue-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Атмосфера</span>
            <h2 id="venue-heading">Наш заклад</h2>
            <p>Простір, де приємно відсвяткувати день народження, провести ділову зустріч чи просто втекти від міської метушні.</p>
          </div>
          <div className={styles.venueGrid}>
            {venueImages.map((image) => (
              <figure key={image.alt} className={styles.venueCard}>
                <img src={image.src} alt={image.alt} loading="lazy" />
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.processSection}`}
        data-reveal
        aria-labelledby="process-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Як ми працюємо</span>
            <h2 id="process-heading">Процес приготування</h2>
            <p>Магія трапляється завдяки дисципліні та любові до ремесла. Ділимося етапами, які не пропускаємо жодного дня.</p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.step} className={styles.processCard}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.projectsSection}`}
        data-reveal
        aria-labelledby="projects-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Події</span>
            <h2 id="projects-heading">Наші проєкти</h2>
            <p>Проводимо камерні вечері, масштабні корпоративи та благодійні ініціативи. Ви можете обрати формат, що підходить саме вам.</p>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Фільтр проєктів">
            {['усі', 'корпоративи', 'зустрічі', 'благодійність'].map((filter) => (
              <button
                key={filter}
                type="button"
                role="tab"
                aria-selected={activeProjectFilter === filter}
                onClick={() => setActiveProjectFilter(filter)}
                className={activeProjectFilter === filter ? styles.filterActive : ''}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className="badge">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.faqSection}`}
        data-reveal
        aria-labelledby="faq-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Питання</span>
            <h2 id="faq-heading">Питання та відповіді</h2>
            <p>Якщо не знайшли відповідь — напишіть нам у чат або зателефонуйте, і ми допоможемо.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  aria-expanded={openFaq === index}
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{openFaq === index ? '–' : '+'}</span>
                </button>
                {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.section} ${styles.blogSection}`}
        data-reveal
        aria-labelledby="blog-heading"
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Журнал</span>
            <h2 id="blog-heading">Свіжі історії</h2>
            <p>Ділимося новинами, сезонними рекомендаціями та нотатками шефа прямо з кухні.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImage}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.link}>
                    Читати далі →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection} data-reveal aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.ctaBlock}>
            <div>
              <span className="tag">Забронювати</span>
              <h2 id="cta-heading">Готові до вечері в Kyiv Pizzeria?</h2>
              <p>Зателефонуйте, щоб забронювати стіл, або замовте доставку просто зараз. Ми поруч, аби створити ваш незабутній вечір.</p>
            </div>
            <div className={styles.ctaActions}>
              <a href="tel:+380441234567" className={styles.ctaPhone}>
                +380 (44) 123-45-67
              </a>
              <Link to="/contacts" className={styles.ctaButton}>
                Написати нам
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;