import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Menu.module.css';

const categories = ['усі', 'класика', 'авторські', 'веганські'];

const pizzas = [
  {
    title: 'Маргарита Подільська',
    category: 'класика',
    description: 'томат сан-марцано, моцарела, базилік, оливкова олія',
    price: 215
  },
  {
    title: 'Карбонара у Каштані',
    category: 'авторські',
    description: 'соус бешамель, гуаціале, жовток, пекоріно романо',
    price: 259
  },
  {
    title: 'Баклажанова страчатела',
    category: 'веганські',
    description: 'печений баклажан, веганська страчатела, томати конфі, м’ята',
    price: 235
  },
  {
    title: 'Київський лосось',
    category: 'авторські',
    description: 'крем-чиз, лосось, кріп, цедра лимону, ікорний соус',
    price: 279
  },
  {
    title: 'Діавола на Подолі',
    category: 'класика',
    description: 'пікантна салямі, моцарела, базилік, мед чилі',
    price: 239
  },
  {
    title: 'Трюфель і гриби',
    category: 'авторські',
    description: 'телячий демігляс, печериці, трюфельна паста, пармезан',
    price: 289
  },
  {
    title: 'Зелена весна',
    category: 'веганські',
    description: 'крем з гороху, спаржа, цукіні, мигдальні пластівці',
    price: 229
  },
  {
    title: 'Римська четвірка сирів',
    category: 'класика',
    description: 'моцарела, горгонзола, тільзітер, пармезан, грушевий мед',
    price: 249
  }
];

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('усі');

  const filteredPizzas = useMemo(() => {
    if (activeCategory === 'усі') return pizzas;
    return pizzas.filter((item) => item.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>Меню Kyiv Pizzeria — піца на дровах, сезонні страви</title>
        <meta
          name="description"
          content="Перегляньте меню Kyiv Pizzeria: авторські піци на дровах, веганські позиції, сезонні напої та десерти."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Меню</span>
            <h1>Піца, що смакує Києву</h1>
            <p>
              Виберіть класичні рецепти або спробуйте авторські комбінації з локальними інгредієнтами. Щотижня додаємо сезонні позиції.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.menuSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.filter}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                className={activeCategory === category ? styles.active : ''}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.menuGrid}>
            {filteredPizzas.map((pizza) => (
              <article key={pizza.title} className={styles.menuCard}>
                <div>
                  <h3>{pizza.title}</h3>
                  <span className={styles.category}>{pizza.category}</span>
                  <p>{pizza.description}</p>
                </div>
                <span className={styles.price}>{pizza.price} ₴</span>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Menu;