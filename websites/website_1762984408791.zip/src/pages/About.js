import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const milestones = [
  {
    year: '2011',
    title: 'Відкриття печі на Подолі',
    description: 'Почали з маленького гаража, де горіла перша дров’яна піч та працювали двоє друзів.'
  },
  {
    year: '2015',
    title: 'Переїзд на Хрещатик',
    description: 'Знайшли історичне приміщення, відновили цегляні стіни та відкрили двері для гостей.'
  },
  {
    year: '2020',
    title: 'Школа піцайоло',
    description: 'Створили програму навчання для молодих кухарів з усієї України.'
  },
  {
    year: '2023',
    title: 'Міжнародне визнання',
    description: 'Наша піца увійшла до топ-50 найкращих піц північної Європи за версією 50 Top Pizza.'
  }
];

const team = [
  {
    name: 'Марко Довгань',
    role: 'Шеф-піцайоло',
    story: 'Вчився у Неаполі, повернувся, щоб розвивати українську гастросцену. Любить експерименти з локальними сирами.',
    image: 'https://picsum.photos/seed/team1/400/400'
  },
  {
    name: 'Ірина Гончар',
    role: 'Креативна директорка',
    story: 'Створює сезонні меню та винні пейрінги, відповідає за атмосфери і музику.',
    image: 'https://picsum.photos/seed/team2/400/400'
  },
  {
    name: 'Дмитро Руденко',
    role: 'Менеджер з сервісу',
    story: 'Команда сервісу проходить тренінги з емоційного інтелекту. Дмитро вчить слухати гостя.',
    image: 'https://picsum.photos/seed/team3/400/400'
  },
  {
    name: 'Катерина Левицька',
    role: 'Кондитерка',
    story: 'Працює з локальними ягодами та медом. Її «Київський торт» у сучасній інтерпретації — must try.',
    image: 'https://picsum.photos/seed/team4/400/400'
  }
];

const values = [
  {
    title: 'Справжність',
    description: 'Використовуємо чесні інгредієнти без напівфабрикатів. Кожен соус готуємо на кухні щодня зранку.'
  },
  {
    title: 'Спільнота',
    description: 'Підтримуємо локальних постачальників і благодійні ініціативи. Частину прибутку передаємо на соціальні проєкти.'
  },
  {
    title: 'Турбота',
    description: 'Для нас важливо, щоб кожен гість відчував тепло. Ми пам’ятаємо уподобання постійних гостей і вітаємо малят іменинників.'
  },
  {
    title: 'Розвиток',
    description: 'Команда щороку проходить стажування в Європі. Привозимо нові техніки, але адаптуємо їх під український контекст.'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>Про Kyiv Pizzeria — команда, філософія та цінності</title>
      <meta
        name="description"
        content="Дізнайтеся історію Kyiv Pizzeria: як ми виросли з маленької печі до культурного простору, хто формує меню та за що нас люблять гості."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span className="tag">Про нас</span>
          <h1>Kyiv Pizzeria — команда, яка випікає смак Києва</h1>
          <p>
            Ми віримо, що піца — це більше, ніж страва. Це спосіб зібрати людей, розповісти історію, відчути місто. Команда з 60
            людей працює як одне серце, аби ваш вечір був особливим.
          </p>
        </div>
      </div>
    </section>

    <section className="sectionSpacing">
      <div className="container">
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.timelineSection} sectionSpacing`}>
      <div className="container">
        <div className={styles.timelineHeader}>
          <span className="tag">Історія</span>
          <h2>Наш шлях</h2>
          <p>Kyiv Pizzeria народилася з мрії відкрити місце, де Київ зустрічається з Неаполем, а люди — з людьми.</p>
        </div>
        <div className={styles.timeline}>
          {milestones.map((item) => (
            <article key={item.year} className={styles.timelineItem}>
              <span className={styles.year}>{item.year}</span>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.teamSection} sectionSpacing`}>
      <div className="container">
        <div className={styles.teamHeader}>
          <span className="tag">Команда</span>
          <h2>Люди, які закохані в свою справу</h2>
          <p>Показуємо обличчя, які стоять за печами, у залі та за лаштунками. Кожен з них — частина смаку Києва.</p>
        </div>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImage}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamOverlay}>
                  <p>{member.story}</p>
                </div>
              </div>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.philosophy} sectionSpacing`}>
      <div className="container">
        <div className={styles.philosophyGrid}>
          <div>
            <h2>Наша філософія</h2>
            <p>
              Сучасний Київ потребує місць, де можна зупинитися. У нас немає телебачення — лише вініл та живий звук по п’ятницях.
              Ми хочемо, щоб ви чули друзів за столом і відчували піклування у кожній деталі.
            </p>
          </div>
          <div className={styles.philosophyCard}>
            <h3>Відкрита кухня</h3>
            <p>Ви бачите, як замішується тісто, як воно обертається у повітрі, як з’являється рум’яний бортик.</p>
            <h3>Сезонність</h3>
            <p>Раз на квартал змінюємо меню. Улітку — чорниця та базилік, восени — гарбузова паста та трюфель.</p>
            <h3>Освіта</h3>
            <p>Ми проводимо курси для молоді, підтримуємо кулінарні школи, ділимося знаннями з громадами.</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;