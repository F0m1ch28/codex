import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Будь ласка, вкажіть ваше ім'я.";
    if (!formData.phone.trim()) newErrors.phone = 'Введіть номер телефону для зв’язку.';
    if (formData.email && !/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/i.test(formData.email)) {
      newErrors.email = 'Будь ласка, вкажіть коректний email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Розкажіть коротко, що вас цікавить.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setStatus('Ваш запит отримано! Менеджер зв’яжеться з вами протягом 15 хвилин.');
      setFormData({ name: '', phone: '', email: '', message: '' });
      setTimeout(() => setStatus(''), 6000);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакти Kyiv Pizzeria — забронювати стіл або замовити доставку</title>
        <meta
          name="description"
          content="Зв’яжіться з Kyiv Pizzeria: адреса Хрещатик, 1, номер телефону +380 (44) 123-45-67, електронна пошта info@pizzeria-kyiv.com."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Контакти</span>
            <h1>Залишайтесь на зв’язку</h1>
            <p>Забронюйте стіл, замовте доставку або організуйте подію. Ми відповімо на повідомлення впродовж 15 хвилин.</p>
          </div>
        </div>
      </section>

      <section className={`${styles.contactSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.formWrap}>
              <h2>Напишіть нам</h2>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label>
                  Ім’я*
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    aria-required="true"
                    aria-invalid={Boolean(errors.name)}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ваше ім’я"
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </label>
                <label>
                  Телефон*
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    aria-required="true"
                    aria-invalid={Boolean(errors.phone)}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+380..."
                  />
                  {errors.phone && <span className={styles.error}>{errors.phone}</span>}
                </label>
                <label>
                  Email
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    aria-invalid={Boolean(errors.email)}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="example@gmail.com"
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </label>
                <label>
                  Ваш запит*
                  <textarea
                    name="message"
                    rows="4"
                    value={formData.message}
                    aria-required="true"
                    aria-invalid={Boolean(errors.message)}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Розкажіть, чим можемо бути корисними"
                  />
                  {errors.message && <span className={styles.error}>{errors.message}</span>}
                </label>
                <button type="submit">Надіслати</button>
                {status && <div className={styles.success}>{status}</div>}
              </form>
            </div>
            <div className={styles.infoWrap}>
              <h2>Завітайте до нас</h2>
              <div className={styles.infoList}>
                <div>
                  <span>Адреса</span>
                  <p>м. Київ, вул. Хрещатик, 1</p>
                </div>
                <div>
                  <span>Телефон</span>
                  <p><a href="tel:+380441234567">+380 (44) 123-45-67</a></p>
                </div>
                <div>
                  <span>Email</span>
                  <p><a href="mailto:info@pizzeria-kyiv.com">info@pizzeria-kyiv.com</a></p>
                </div>
                <div>
                  <span>Графік</span>
                  <p>Пн–Чт: 10:00 – 22:00 <br /> Пт–Сб: 10:00 – 23:30 <br /> Нд: 11:00 – 22:00</p>
                </div>
              </div>
              <div className={styles.mapWrap}>
                <iframe
                  title="Kyiv Pizzeria на мапі"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2530.834665459751!2d30.522054976360718!3d50.45002958718664!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4ce5de0b4c5b3%3A0xeaa43d3170616651!2z0LLRg9C70LjRhtGPINCn0LXRhdCy0LjRjyDQmtC-0L_QvtGA0YLQtdC60LAgMSwgS2l5aXYsINCa0LjQtdCy0LXQvdC40YbRjyDQvtCx0LvQsNGB0YLRjCwgMDEwMDA!5e0!3m2!1suk!2sua!4v1706975600000!5m2!1suk!2sua"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;