import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Політика cookies — Kyiv Pizzeria</title>
      <meta
        name="description"
        content="Дізнайтеся, які файли cookies використовує Kyiv Pizzeria та як ними керувати у своєму браузері."
      />
    </Helmet>

    <section className={styles.section}>
      <div className="container">
        <h1>Політика cookies</h1>
        <p className={styles.updated}>Останнє оновлення: 10 січня 2024 року</p>
        <p>Cookies допомагають нам зробити сервіс стабільним та персоналізованим. Використовуючи сайт, ви погоджуєтеся з їх застосуванням.</p>
        <h2>Типи cookies</h2>
        <ul>
          <li>Суттєві — забезпечують роботу кошика та форми бронювання.</li>
          <li>Аналітичні — дають змогу оцінювати відвідуваність та вдосконалювати сайт.</li>
          <li>Функціональні — запам’ятовують ваші вподобання, мову та місто.</li>
        </ul>
        <h2>Як керувати cookies</h2>
        <p>Ви можете вимкнути cookies у налаштуваннях браузера. Зверніть увагу, що деякі функції сайту можуть бути недоступні без cookies.</p>
        <h2>Контакти</h2>
        <p>Для уточнень пишіть на cookies@pizzeria-kyiv.com.</p>
      </div>
    </section>
  </>
);

export default CookiePolicy;