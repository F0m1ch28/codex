import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Кейтеринг для івентів',
    tag: 'корпоратив',
    description: 'Переносимо піч-купольку на ваш захід, випікаємо піцу наживо, підбираємо вина та коктейлі.',
    features: ['Мобільна піч', 'Команда 6 людей', 'Меню на 12 позицій'],
    image: 'https://picsum.photos/seed/service1/800/600'
  },
  {
    title: 'Майстер-класи від шефа',
    tag: 'освіта',
    description: 'Навчаємо замішувати тісто, працювати з піччю та підбирати сезонні інгредієнти.',
    features: ['Групи до 12 осіб', 'Власноруч випечена піца', 'Диплом учасника'],
    image: 'https://picsum.photos/seed/service2/800/600'
  },
  {
    title: 'Фірмові подарункові бокси',
    tag: 'подарунок',
    description: 'Зібрані шефом соуси, оливкова олія, листівка та сертифікат на вечерю.',
    features: ['Персональне привітання', 'Лімітовані соуси', 'Доставка в день замовлення'],
    image: 'https://picsum.photos/seed/service3/800/600'
  }
];

const addons = [
  {
    title: 'Live-бар',
    text: 'Авторські коктейлі та поєднання з піцою та десертами.',
    price: 'від 6 500 ₴'
  },
  {
    title: 'Жива музика',
    text: 'Саксофон, джаз-тріо або діджей сет на ваш вибір.',
    price: 'від 4 800 ₴'
  },
  {
    title: 'Фуд-стайлінг',
    text: 'Оформлення столів, меню та фотозони у стилі заходу.',
    price: 'від 3 200 ₴'
  }
];

const Services = () => {
  const [activeService, setActiveService] = useState(0);

  return (
    <>
      <Helmet>
        <title>Послуги Kyiv Pizzeria — кейтеринг, події, майстер-класи</title>
        <meta
          name="description"
          content="Kyiv Pizzeria організує кейтеринг, кулінарні майстер-класи, романтичні вечері та подарункові бокси. Оберіть свій формат!"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Послуги</span>
            <h1>Створюємо події зі смаком</h1>
            <p>
              Від камерної вечері до масштабного запуску бренду — команда Kyiv Pizzeria спланує, приготує та сервісно супроводить
              кожну деталь.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.servicesSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.servicesGrid}>
            {services.map((service, index) => (
              <article
                key={service.title}
                className={`${styles.serviceCard} ${activeService === index ? styles.serviceActive : ''}`}
                onMouseEnter={() => setActiveService(index)}
              >
                <div className={styles.serviceImage}>
                  <img src={service.image} alt={service.title} loading="lazy" />
                  <span className="badge">{service.tag}</span>
                </div>
                <div className={styles.serviceContent}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <ul>
                    {service.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.addons} sectionSpacing`}>
        <div className="container">
          <div className={styles.addonsHeader}>
            <h2>Додаткові можливості</h2>
            <p>Підсилюємо атмосферу вашого заходу креативними деталями.</p>
          </div>
          <div className={styles.addonsGrid}>
            {addons.map((addon) => (
              <article key={addon.title} className={styles.addonCard}>
                <h3>{addon.title}</h3>
                <p>{addon.text}</p>
                <span>{addon.price}</span>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;