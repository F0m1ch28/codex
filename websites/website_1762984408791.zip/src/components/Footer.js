import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={`container ${styles.footerGrid}`}>
      <div>
        <div className={styles.brand}>
          <span className={styles.brandMark}>Kyiv</span>
          <span>Pizzeria</span>
        </div>
        <p className={styles.description}>
          Готуємо піцу на дровах з локальних продуктів, підтримуємо українських фермерів та щодня створюємо теплі зустрічі у серці Києва.
        </p>
        <div className={styles.contactList}>
          <a href="tel:+380441234567" className={styles.contactLink}>+380 (44) 123-45-67</a>
          <a href="mailto:info@pizzeria-kyiv.com" className={styles.contactLink}>info@pizzeria-kyiv.com</a>
          <address className={styles.address}>м. Київ, вул. Хрещатик, 1</address>
        </div>
      </div>
      <div>
        <h3 className={styles.columnTitle}>Навігація</h3>
        <ul className={styles.links}>
          <li><Link to="/">Головна</Link></li>
          <li><Link to="/menu">Меню</Link></li>
          <li><Link to="/services">Послуги</Link></li>
          <li><Link to="/about">Про нас</Link></li>
          <li><Link to="/contacts">Контакти</Link></li>
        </ul>
      </div>
      <div>
        <h3 className={styles.columnTitle}>Політики</h3>
        <ul className={styles.links}>
          <li><Link to="/delivery">Доставка та оплата</Link></li>
          <li><Link to="/terms">Умови використання</Link></li>
          <li><Link to="/privacy">Політика конфіденційності</Link></li>
          <li><Link to="/cookie-policy">Політика cookies</Link></li>
        </ul>
      </div>
      <div>
        <h3 className={styles.columnTitle}>Графік роботи</h3>
        <ul className={styles.schedule}>
          <li><span>Пн–Чт</span><span>10:00 – 22:00</span></li>
          <li><span>Пт–Сб</span><span>10:00 – 23:30</span></li>
          <li><span>Нд</span><span>11:00 – 22:00</span></li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Kyiv Pizzeria. Усі права захищені.</p>
      <div className={styles.socials}>
        <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook">Fb</a>
        <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">Ig</a>
        <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">Yt</a>
      </div>
    </div>
  </footer>
);

export default Footer;