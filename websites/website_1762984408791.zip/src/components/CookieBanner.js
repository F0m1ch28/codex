import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const hasConsent = typeof window !== 'undefined' ? localStorage.getItem('cookieConsentKyivPizzeria') : null;
    if (!hasConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsentKyivPizzeria', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="region" aria-label="Банер використання cookies">
      <p>
        Ми використовуємо cookies, аби забезпечити стабільну роботу сайту, запам’ятовувати ваші вподобання та вдосконалювати сервіс.
        Продовжуючи перегляд, ви погоджуєтесь з нашою <Link to="/cookie-policy">Політикою cookies</Link>.
      </p>
      <button type="button" onClick={handleAccept}>
        Згоден
      </button>
    </div>
  );
};

export default CookieBanner;