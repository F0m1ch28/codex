(function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            navMenu.classList.toggle("active");
        });

        navMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.classList.remove("active");
                navMenu.classList.remove("active");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const storageKey = "friary-wbwr-consent";

    if (cookieBanner) {
        const storedPreference = localStorage.getItem(storageKey);
        if (storedPreference) {
            cookieBanner.classList.add("hidden");
        }

        cookieBanner.querySelectorAll("[data-cookie-action]").forEach(link => {
            link.addEventListener("click", (event) => {
                event.preventDefault();
                const action = link.getAttribute("data-cookie-action");
                localStorage.setItem(storageKey, action);
                cookieBanner.classList.add("hidden");
                window.location.href = link.getAttribute("href");
            });
        });
    }

    const filterChips = document.querySelectorAll(".filter-chip");
    const articles = document.querySelectorAll("[data-category]");
    const searchInput = document.querySelector("[data-post-search]");

    function normalize(text) {
        return text.toLowerCase().trim();
    }

    function applyFilters() {
        const activeChip = document.querySelector(".filter-chip.active");
        const category = activeChip ? activeChip.getAttribute("data-filter") : "all";
        const keyword = searchInput ? normalize(searchInput.value) : "";

        articles.forEach(article => {
            const matchesCategory = category === "all" || article.getAttribute("data-category") === category;
            const matchesKeyword = !keyword || normalize(article.textContent).includes(keyword);

            if (matchesCategory && matchesKeyword) {
                article.style.display = "";
            } else {
                article.style.display = "none";
            }
        });
    }

    if (filterChips.length > 0) {
        filterChips.forEach(chip => {
            chip.addEventListener("click", () => {
                filterChips.forEach(c => c.classList.remove("active"));
                chip.classList.add("active");
                applyFilters();
            });
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", () => {
            applyFilters();
        });
    }
})();