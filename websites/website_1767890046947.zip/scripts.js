document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            var isOpen = navLinks.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    }

    var banner = document.getElementById('cookie-banner');
    if (!banner) {
        return;
    }

    var consentKey = 'unlikedvniCookieConsent';

    try {
        var stored = localStorage.getItem(consentKey);
        if (!stored) {
            banner.classList.add('is-visible');
        } else {
            banner.classList.add('is-hidden');
        }
    } catch (error) {
        banner.classList.add('is-visible');
    }

    var buttons = document.querySelectorAll('.cookie-button');
    buttons.forEach(function (button) {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            var action = button.getAttribute('data-action') || 'accept';
            try {
                localStorage.setItem(consentKey, action);
            } catch (error) {
                /* localStorage not available */
            }
            banner.classList.remove('is-visible');
            banner.classList.add('is-hidden');
        });
    });
});