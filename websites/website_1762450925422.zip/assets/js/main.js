document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.getElementById('primary-navigation');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.classList.toggle('active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen);
        });
    }

    const navLinks = document.querySelectorAll('.primary-nav .nav-link');
    navLinks.forEach((link) => {
        link.addEventListener('click', () => {
            if (primaryNav && primaryNav.classList.contains('open') && navToggle) {
                primaryNav.classList.remove('open');
                navToggle.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    const scrollBtn = document.getElementById('scrollTopBtn');
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');

    if (cookieBanner && acceptCookiesBtn) {
        if (localStorage.getItem('ehteam_cookieConsent') === 'accepted') {
            cookieBanner.classList.add('hidden');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('ehteam_cookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        const formResponse = document.getElementById('formResponse');

        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name').trim();
            const email = formData.get('email').trim();
            const message = formData.get('message').trim();
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!name || !email || !message) {
                formResponse.textContent = 'Please complete every field before sending your message.';
                formResponse.style.color = '#f5a3a3';
                return;
            }

            if (!emailPattern.test(email)) {
                formResponse.textContent = 'The email address appears to be invalid. Please check and try again.';
                formResponse.style.color = '#f5a3a3';
                return;
            }

            formResponse.style.color = '#8be4e8';
            formResponse.textContent = `Thank you, ${name}. Our consultants will respond within one business day.`;
            contactForm.reset();
        });
    }
});