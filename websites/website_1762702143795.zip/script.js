document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    const scrollBtn = document.getElementById('scrollTop');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookies = document.getElementById('acceptCookies');

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            nav.classList.toggle('open');
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollBtn.style.display = 'block';
        } else {
            scrollBtn.style.display = 'none';
        }
    });

    scrollBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'instant' });
    });

    // Cookie banner
    if (localStorage.getItem('cookieConsent') === 'accepted') {
        cookieBanner.style.display = 'none';
    }

    acceptCookies.addEventListener('click', () => {
        localStorage.setItem('cookieConsent', 'accepted');
        cookieBanner.style.display = 'none';
    });

    // Recipe detail data
    const recipes = {
        fave: {
            title: 'Crema di fave, limone conservato e menta',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>600 g di fave fresche sgranate</li>
                <li>1 limone conservato, solo la buccia</li>
                <li>Brodo vegetale leggero</li>
                <li>Foglie di menta e olio extravergine</li>
                <li>Sale affumicato q.b.</li>
            </ul>
            <h3>Metodo</h3>
            <p>Sbianchire le fave, raffreddare e frullare con brodo. Aggiungere la buccia di limone tritata finemente, condire con olio e sale. Servire con foglie di menta spezzate a mano.</p>`
        },
        asparagi: {
            title: 'Asparagi arrostiti, kefir e olio affumicato',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>12 asparagi verdi</li>
                <li>200 ml di kefir intero</li>
                <li>Olio affumicato ottenuto con trucioli di faggio</li>
                <li>Scorza di limone e sale marino</li>
            </ul>
            <h3>Metodo</h3>
            <p>Arrostire gli asparagi su piastra rovente, condirli con olio affumicato e scorza di limone. Servire su base di kefir leggermente salato.</p>`
        },
        fragole: {
            title: 'Fragole marinate al pepe timut',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>400 g di fragole mature</li>
                <li>Pepe timut pestato</li>
                <li>Miele di castagno</li>
                <li>Succo di lime</li>
            </ul>
            <h3>Metodo</h3>
            <p>Tagliare le fragole, condirle con pepe timut e miele. Aggiungere qualche goccia di lime, lasciare marinare 20 minuti e servire fredde.</p>`
        },
        pomodori: {
            title: "Pomodori ripieni d'orzo e erbe aromatiche",
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>8 pomodori ramati</li>
                <li>150 g di orzo perlato</li>
                <li>Maggiorana, prezzemolo e timo freschi</li>
                <li>Capperi dissalati</li>
            </ul>
            <h3>Metodo</h3>
            <p>Cuocere l'orzo e condirlo con erbe tritate, capperi e olio. Riempire i pomodori scavati e infornare per 25 minuti a 180°C.</p>`
        },
        pesca: {
            title: 'Pesche grigliate, ricotta salata e miele di tiglio',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>4 pesche mature ma sode</li>
                <li>Ricotta salata a scaglie</li>
                <li>Miele di tiglio</li>
                <li>Foglie di basilico viola</li>
            </ul>
            <h3>Metodo</h3>
            <p>Grigliare le pesche divise a metà, nappare con miele e completare con ricotta salata e basilico.</p>`
        },
        zucca: {
            title: 'Vellutata di zucca e caffè verde',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>1 kg di zucca mantovana</li>
                <li>Brodo vegetale</li>
                <li>Caffè verde macinato fine</li>
                <li>Olio di semi di zucca</li>
            </ul>
            <h3>Metodo</h3>
            <p>Arrostire la zucca, frullarla con brodo e completare con polvere di caffè verde e olio di semi di zucca.</p>`
        },
        funghi: {
            title: 'Funghi arrosto con riduzione di mosto',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>500 g di funghi misti</li>
                <li>Mosto cotto</li>
                <li>Burro nocciola</li>
                <li>Erba cipollina</li>
            </ul>
            <h3>Metodo</h3>
            <p>Saltare i funghi fino a doratura, glassarli con mosto cotto e burro nocciola. Rifinire con erba cipollina.</p>`
        },
        cavolo: {
            title: 'Cavolo verza brasato con nocciole',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>1 cavolo verza</li>
                <li>Brodo di verdure</li>
                <li>Nocciole tostate</li>
                <li>Aceto di mele</li>
            </ul>
            <h3>Metodo</h3>
            <p>Brasare la verza con brodo e aceto, aggiungere nocciole tritate prima di servire.</p>`
        },
        agrumi: {
            title: 'Tarte agli agrumi e polline',
            content: `<h3>Ingredienti</h3>
            <ul>
                <li>Base sablée</li>
                <li>Crema al limone</li>
                <li>Segmenti di arancia e pompelmo</li>
                <li>Polline fresco</li>
            </ul>
            <h3>Metodo</h3>
            <p>Cuocere la base, riempire con crema al limone e decorare con agrumi e polline.</p>`
        }
    };

    const recipeButtons = document.querySelectorAll('.recipe-item');
    const recipeDetail = document.getElementById('recipe-detail');

    if (recipeButtons && recipeDetail) {
        recipeButtons.forEach(button => {
            button.addEventListener('click', () => {
                const key = button.dataset.recipe;
                if (recipes[key]) {
                    recipeDetail.innerHTML = `<h3>${recipes[key].title}</h3>${recipes[key].content}`;
                    recipeDetail.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });
    }
});