document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".mobile-nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("active");
      siteNav.classList.toggle("open");
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("active");
        siteNav.classList.remove("open");
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = cookieBanner ? cookieBanner.querySelector(".accept") : null;
  const declineBtn = cookieBanner ? cookieBanner.querySelector(".decline") : null;
  const consent = localStorage.getItem("giftBoxCookieConsent");
  if (!consent && cookieBanner) {
    setTimeout(() => cookieBanner.classList.add("active"), 500);
  }
  const handleConsent = (value) => {
    localStorage.setItem("giftBoxCookieConsent", value);
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  };
  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => handleConsent("accepted"));
  }
  if (declineBtn) {
    declineBtn.addEventListener("click", () => handleConsent("declined"));
  }

  const filterButtons = document.querySelectorAll("[data-filter]");
  const products = document.querySelectorAll("[data-category]");
  if (filterButtons.length && products.length) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const target = button.getAttribute("data-filter");
        filterButtons.forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");
        products.forEach((product) => {
          const category = product.getAttribute("data-category");
          if (target === "all" || category === target) {
            product.style.display = "";
          } else {
            product.style.display = "none";
          }
        });
      });
    });
  }

  const customizeForm = document.querySelector(".tool-form");
  const previewBox = document.querySelector(".preview-box");
  const previewList = document.querySelector(".preview-summary ul");
  const previewPrice = document.querySelector(".preview-price");
  if (customizeForm && previewBox && previewList && previewPrice) {
    const basePrices = {
      size: {
        petite: 45,
        signature: 75,
        grande: 120
      },
      theme: {
        classic: 0,
        festive: 15,
        luxury: 30
      },
      delivery: {
        standard: 0,
        express: 12,
        sameDay: 22
      }
    };
    const colorMap = {
      red: "#D32F2F",
      blue: "#0D47A1",
      green: "#2E7D32",
      gold: "#FFD700"
    };
    const updatePreview = () => {
      const size = customizeForm.querySelector("[name='box-size']").value;
      const color = customizeForm.querySelector("[name='box-color']").value;
      const theme = customizeForm.querySelector("[name='box-theme']").value;
      const delivery = customizeForm.querySelector("[name='delivery']").value;
      const message = customizeForm.querySelector("[name='message']").value.trim();
      const addOns = Array.from(customizeForm.querySelectorAll("[name='add-ons']:checked")).map((checkbox) => checkbox.value);
      let total = basePrices.size[size] + basePrices.theme[theme] + basePrices.delivery[delivery];
      if (addOns.length) {
        total += addOns.length * 8;
      }
      if (previewBox) {
        previewBox.style.background = colorMap[color] || "#D32F2F";
      }
      previewList.innerHTML = `
        <li><strong>Size:</strong> ${size.charAt(0).toUpperCase() + size.slice(1)}</li>
        <li><strong>Theme:</strong> ${theme.charAt(0).toUpperCase() + theme.slice(1)}</li>
        <li><strong>Delivery:</strong> ${delivery === "sameDay" ? "Same Day" : delivery.charAt(0).toUpperCase() + delivery.slice(1)}</li>
        <li><strong>Add-ons:</strong> ${addOns.length ? addOns.join(", ") : "None"}</li>
        <li><strong>Message:</strong> ${message ? message : "No message added"}</li>
      `;
      previewPrice.textContent = `$${total.toFixed(2)}`;
    };
    customizeForm.addEventListener("change", updatePreview);
    customizeForm.addEventListener("input", updatePreview);
    updatePreview();
  }

  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    const statusBox = contactForm.querySelector(".form-status");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const requiredFields = ["name", "email", "message"];
      let hasError = false;
      requiredFields.forEach((field) => {
        const value = formData.get(field);
        if (!value || !value.trim()) {
          hasError = true;
        }
      });
      if (statusBox) {
        statusBox.style.display = "block";
        if (hasError) {
          statusBox.textContent = "Please fill in all required fields before submitting.";
          statusBox.classList.add("error");
          statusBox.classList.remove("success");
        } else {
          statusBox.textContent = "Thank you! Your message has been received. We'll reach out shortly.";
          statusBox.classList.add("success");
          statusBox.classList.remove("error");
          contactForm.reset();
        }
      }
    });
  }
});