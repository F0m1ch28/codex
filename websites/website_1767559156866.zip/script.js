document.addEventListener('DOMContentLoaded', function () {
  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const storedConsent = localStorage.getItem('staCookieConsent');
    if (!storedConsent) {
      cookieBanner.classList.add('visible');
    }
    cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(function (button) {
      button.addEventListener('click', function () {
        localStorage.setItem('staCookieConsent', button.dataset.cookieChoice);
        cookieBanner.classList.remove('visible');
      });
    });
  }

  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.getElementById('primaryNav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('open');
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 900) {
        primaryNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  document.querySelectorAll('.faq-item button').forEach(function (button) {
    const content = button.nextElementSibling;
    if (content) {
      if (button.getAttribute('aria-expanded') === null) {
        button.setAttribute('aria-expanded', 'false');
      }
      button.addEventListener('click', function () {
        const isExpanded = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!isExpanded));
        if (!isExpanded) {
          content.style.maxHeight = content.scrollHeight + 'px';
        } else {
          content.style.maxHeight = null;
        }
      });
      if (content.hidden !== undefined) {
        content.hidden = true;
        button.addEventListener('click', function () {
          content.hidden = button.getAttribute('aria-expanded') !== 'true';
        });
      }
    }
  });
});