(function () {
  const redirectMap = {
    "/history": "archives.html",
    "/history/": "archives.html",
    "/signal-map": "maps.html",
    "/signal-map/": "maps.html",
    "/signals-map": "maps.html",
    "/signals-map/": "maps.html",
    "/northlyx-signals": "signals.html",
    "/northlyx-signals/": "signals.html"
  };

  function handleRedirects() {
    const path = window.location.pathname;
    if (redirectMap[path]) {
      window.location.replace(`${redirectMap[path]}${window.location.search}${window.location.hash}`);
    }
  }

  function initMobileNav() {
    const toggle = document.querySelector(".mobile-nav-toggle");
    const nav = document.querySelector(".primary-nav");
    if (!toggle || !nav) return;
    toggle.addEventListener("click", () => {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      nav.dataset.open = !expanded;
    });
  }

  function initCookieBanner() {
    const banner = document.getElementById("cookie-banner");
    if (!banner) return;
    const storedDecision = localStorage.getItem("northlyxCookieDecision");
    if (!storedDecision) {
      banner.classList.add("active");
    }
    banner.addEventListener("click", (event) => {
      const action = event.target.dataset.cookieAction;
      if (!action) return;
      if (action === "accept") {
        localStorage.setItem("northlyxCookieDecision", "accepted");
      } else if (action === "decline") {
        localStorage.setItem("northlyxCookieDecision", "declined");
      }
      banner.classList.remove("active");
    });
  }

  function initHeroCanvas() {
    const canvas = document.getElementById("hero-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    }

    const pulses = Array.from({ length: 20 }, () => ({
      x: Math.random(),
      y: Math.random(),
      radius: 30 + Math.random() * 80,
      speed: 0.4 + Math.random() * 0.8,
      hue: Math.random() > 0.5 ? 160 : 270
    }));

    function draw(timestamp) {
      if (!canvas.isConnected) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;

      pulses.forEach((pulse) => {
        const time = (timestamp / 1000) * pulse.speed;
        const alpha = (Math.sin(time) + 1) / 2;
        const radius = pulse.radius + Math.sin(time) * 14;

        const gradient = ctx.createRadialGradient(
          pulse.x * width,
          pulse.y * height,
          0,
          pulse.x * width,
          pulse.y * height,
          radius
        );
        gradient.addColorStop(0, `hsla(${pulse.hue}, 76%, 62%, 0.34)`);
        gradient.addColorStop(1, `hsla(${pulse.hue}, 76%, 62%, 0)`);

        ctx.beginPath();
        ctx.fillStyle = gradient;
        ctx.arc(pulse.x * width, pulse.y * height, radius, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.strokeStyle = `hsla(${pulse.hue}, 80%, 60%, ${0.45 * alpha})`;
        ctx.lineWidth = 1.2;
        ctx.arc(pulse.x * width, pulse.y * height, radius * 0.6, 0, Math.PI * 2);
        ctx.stroke();
      });

      requestAnimationFrame(draw);
    }

    resize();
    window.addEventListener("resize", resize);
    requestAnimationFrame(draw);
  }

  function initMapToggles() {
    const buttons = document.querySelectorAll("[data-layer-toggle]");
    const regions = document.querySelectorAll("[data-region-layer]");
    if (!buttons.length || !regions.length) return;

    buttons.forEach((button) => {
      button.addEventListener("click", () => {
        const layer = button.dataset.layer;
        buttons.forEach((b) => b.classList.remove("active"));
        button.classList.add("active");
        regions.forEach((region) => {
          const match = region.dataset.regionLayer === layer || layer === "all";
          region.style.opacity = match ? "1" : "0.1";
        });
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    handleRedirects();
    initMobileNav();
    initCookieBanner();
    initHeroCanvas();
    initMapToggles();
  });
})();