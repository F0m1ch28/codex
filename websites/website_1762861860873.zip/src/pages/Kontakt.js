```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Kontakt.module.css';

function Kontakt() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (formData.name.trim().length === 0) {
      newErrors.name = 'Bitte gib deinen Namen an.';
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(formData.email)) {
      newErrors.email = 'Bitte eine gültige E-Mail-Adresse eintragen.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Bitte formuliere deine Anfrage etwas ausführlicher.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | Slexorifyx</title>
        <meta
          name="description"
          content="Kontaktiere Slexorifyx. Unser Team in Berlin freut sich auf deine Nachricht."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Kontakt</h1>
          <p>
            Unser Team freut sich auf den Austausch. Schreib uns eine Nachricht oder besuche das
            Labor in Berlin nach Terminabsprache.
          </p>
        </div>
      </header>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div>
              <h2>Schreib uns</h2>
              {submitted ? (
                <div className={styles.success}>
                  <h3>Vielen Dank!</h3>
                  <p>Wir melden uns in Kürze bei dir.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate>
                  <label>
                    <span>Name *</span>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      aria-invalid={Boolean(errors.name)}
                    />
                    {errors.name && <span className={styles.error}>{errors.name}</span>}
                  </label>
                  <label>
                    <span>E-Mail *</span>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      aria-invalid={Boolean(errors.email)}
                    />
                    {errors.email && <span className={styles.error}>{errors.email}</span>}
                  </label>
                  <label>
                    <span>Betreff</span>
                    <input
                      type="text"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                    />
                  </label>
                  <label>
                    <span>Nachricht *</span>
                    <textarea
                      name="message"
                      rows="5"
                      value={formData.message}
                      onChange={handleChange}
                      aria-invalid={Boolean(errors.message)}
                    />
                    {errors.message && <span className={styles.error}>{errors.message}</span>}
                  </label>
                  <button type="submit" className={styles.submit}>
                    Nachricht senden
                  </button>
                </form>
              )}
            </div>

            <aside className={styles.info} aria-label="Kontaktinformationen">
              <h2>Unser Standort</h2>
              <p>Friedrichstraße 68, 10117 Berlin, Deutschland</p>
              <p>
                Telefon: <a href="tel:+493012345678">+49 30 1234 5678</a>
                <br />
                E-Mail: <a href="mailto:kontakt@slexorifyx.de">kontakt@slexorifyx.de</a>
              </p>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Slexorifyx Standort"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.848769023178!2d13.388859215996224!3d52.514352679813115!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c2e5c9d8f7%3A0xb24360a12d6e0a93!2sFriedrichstra%C3%9Fe%2068%2C%2010117%20Berlin!5e0!3m2!1sde!2sde!4v1709999999999!5m2!1sde!2sde"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Kontakt;
```