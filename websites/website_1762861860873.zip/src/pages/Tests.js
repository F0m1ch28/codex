```javascript
import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tests.module.css';

const testCatalog = [
  {
    id: 'lab-1',
    title: 'Ultrabook 14" 2024',
    category: 'Notebook',
    brand: 'Lynx',
    year: 2024,
    rating: 91,
    summary:
      'Ausgewogene Performance mit starkem Fokus auf Energieeffizienz und Farbtreue. Ideal für hybride Arbeitsmodelle.',
    pros: ['16:10 OLED-Panel', '13 Stunden Office-Laufzeit', 'Silent Mode unter 28 dB'],
    cons: ['Nur zwei Thunderbolt-Ports'],
    metrics: { battery: 13, brightness: 620, noise: 28 },
    image: 'https://picsum.photos/800/600?random=51'
  },
  {
    id: 'lab-2',
    title: 'Foldable Phone X',
    category: 'Smartphone',
    brand: 'Nebula',
    year: 2024,
    rating: 87,
    summary:
      'Verbesserte Scharnierkonstruktion mit optimierter App-Skalierung. Outdoor-Helligkeit überzeugt.',
    pros: ['1.200 cd/m² Peak', 'Starkes eSIM-Multi-Profile', 'Solide Akku-Kurve'],
    cons: ['Gewicht von 285 g'],
    metrics: { battery: 16, brightness: 1200, noise: 0 },
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    id: 'lab-3',
    title: 'Creator Monitor 32" HDR',
    category: 'Monitor',
    brand: 'Vector',
    year: 2023,
    rating: 89,
    summary:
      'Werkseitige Kalibrierung mit DeltaE unter 1, HDR600-Implementierung mit local dimming.',
    pros: ['Ab Werk kalibriert', 'USB-C mit 90W', 'Stabile Firmware'],
    cons: ['Menüführung etwas träge'],
    metrics: { battery: 0, brightness: 900, noise: 0 },
    image: 'https://picsum.photos/800/600?random=53'
  },
  {
    id: 'lab-4',
    title: 'Wi-Fi 7 Mesh Pro',
    category: 'Netzwerk',
    brand: 'Flux',
    year: 2024,
    rating: 93,
    summary:
      'Durchsatz im Multi-Gigabit-Bereich und niedrige Latenzen bei dichter Bebauung. Ideal für Streaming-Studios.',
    pros: ['2,5 Gbit WAN & LAN', 'Niedrige Latenzen', 'Intuitive App'],
    cons: ['Netzteil etwas groß'],
    metrics: { battery: 0, brightness: 0, noise: 25 },
    image: 'https://picsum.photos/800/600?random=54'
  },
  {
    id: 'lab-5',
    title: 'ANC Earbuds Air',
    category: 'Audio',
    brand: 'Sonique',
    year: 2023,
    rating: 85,
    summary:
      'Fein abgestimmte ANC-Kurve und stabile Verbindung. Transparenzmodus wirkt sehr natürlich.',
    pros: ['ANC bis 35 dB', 'Multipoint', 'Geringe Verzögerung'],
    cons: ['Kein Wireless Charging'],
    metrics: { battery: 8, brightness: 0, noise: 24 },
    image: 'httpsum.photos/800/600?random=55'
  }
];

// Fix typo in image URL (should be picsum). Correct entry to avoid broken image.
testCatalog[4].image = 'https://picsum.photos/800/600?random=55';

const categories = ['Alle', 'Notebook', 'Smartphone', 'Monitor', 'Netzwerk', 'Audio'];
const brands = ['Alle', 'Lynx', 'Nebula', 'Vector', 'Flux', 'Sonique'];
const years = ['Alle', '2024', '2023'];
const ratings = ['Alle', '90+', '85-89', 'unter 85'];

function Tests() {
  const [selectedCategory, setSelectedCategory] = useState('Alle');
  const [selectedBrand, setSelectedBrand] = useState('Alle');
  const [selectedYear, setSelectedYear] = useState('Alle');
  const [selectedRating, setSelectedRating] = useState('Alle');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTests = useMemo(() => {
    return testCatalog.filter((test) => {
      const matchesCategory =
        selectedCategory === 'Alle' || test.category === selectedCategory;
      const matchesBrand = selectedBrand === 'Alle' || test.brand === selectedBrand;
      const matchesYear =
        selectedYear === 'Alle' || test.year === Number(selectedYear);
      const matchesRating =
        selectedRating === 'Alle' ||
        (selectedRating === '90+' && test.rating >= 90) ||
        (selectedRating === '85-89' && test.rating >= 85 && test.rating < 90) ||
        (selectedRating === 'unter 85' && test.rating < 85);
      const matchesSearch =
        searchTerm.trim().length === 0 ||
        test.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        test.summary.toLowerCase().includes(searchTerm.toLowerCase());

      return matchesCategory && matchesBrand && matchesYear && matchesRating && matchesSearch;
    });
  }, [selectedCategory, selectedBrand, selectedYear, selectedRating, searchTerm]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Tests | Slexorifyx</title>
        <meta
          name="description"
          content="Durchstöbere den Slexorifyx-Testkatalog mit Filtern nach Kategorie, Marke, Jahr und Bewertung."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Testkatalog</h1>
          <p>
            Filtere nach Kategorie, Marke, Jahr und Bewertung. Alle Tests basieren auf unseren
            Laborprotokollen und enthalten Scorecards, Messdaten sowie Empfehlungen.
          </p>
        </div>
      </header>

      <section className={styles.filters} aria-labelledby="filters-heading">
        <div className="container">
          <h2 id="filters-heading" className="sr-only">
            Filter
          </h2>
          <div className={styles.filterGrid}>
            <label>
              <span>Kategorie</span>
              <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
                {categories.map((cat) => (
                  <option value={cat} key={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Marke</span>
              <select value={selectedBrand} onChange={(e) => setSelectedBrand(e.target.value)}>
                {brands.map((brand) => (
                  <option value={brand} key={brand}>
                    {brand}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Erscheinungsjahr</span>
              <select value={selectedYear} onChange={(e) => setSelectedYear(e.target.value)}>
                {years.map((year) => (
                  <option value={year} key={year}>
                    {year}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Bewertung</span>
              <select value={selectedRating} onChange={(e) => setSelectedRating(e.target.value)}>
                {ratings.map((rating) => (
                  <option value={rating} key={rating}>
                    {rating}
                  </option>
                ))}
              </select>
            </label>
            <label className={styles.search}>
              <span>Suche</span>
              <input
                type="search"
                placeholder="Titel oder Stichwort"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                aria-label="Tests durchsuchen"
              />
            </label>
          </div>
        </div>
      </section>

      <section className={styles.results} aria-live="polite">
        <div className="container">
          <p className={styles.resultCount}>
            {filteredTests.length} Test{filteredTests.length === 1 ? '' : 's'} gefunden
          </p>
          <div className={styles.resultGrid}>
            {filteredTests.map((test) => (
              <article key={test.id} className={styles.resultCard}>
                <div className={styles.resultMedia}>
                  <img src={test.image} alt={test.title} loading="lazy" />
                  <span className={styles.rating}>{test.rating}</span>
                </div>
                <div className={styles.resultBody}>
                  <div className={styles.meta}>
                    <span>{test.category}</span>
                    <span>{test.brand}</span>
                    <span>{test.year}</span>
                  </div>
                  <h3>{test.title}</h3>
                  <p>{test.summary}</p>
                  <div className={styles.resultLists}>
                    <div>
                      <h4>Pluspunkte</h4>
                      <ul>
                        {test.pros.map((item) => (
                          <li key={item}>{item}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4>Zu beachten</h4>
                      <ul>
                        {test.cons.map((item) => (
                          <li key={item}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  <div className={styles.metrics}>
                    <div>
                      <span>Akkulaufzeit</span>
                      <strong>{test.metrics.battery ? `${test.metrics.battery} h` : 'n/a'}</strong>
                    </div>
                    <div>
                      <span>Displayhelligkeit</span>
                      <strong>{test.metrics.brightness ? `${test.metrics.brightness} cd/m²` : 'n/a'}</strong>
                    </div>
                    <div>
                      <span>Lautstärke</span>
                      <strong>{test.metrics.noise ? `${test.metrics.noise} dB` : 'n/a'}</strong>
                    </div>
                  </div>
                  <button type="button" className={styles.readMore}>
                    Review öffnen
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Tests;
```