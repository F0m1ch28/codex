```javascript
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Labor-getestete Produkte', value: 328 },
  { label: 'Messpunkte pro Test', value: 1820 },
  { label: 'Community-Mitglieder', value: 6400 },
  { label: 'Verifizierte Partnerlabore', value: 12 }
];

const reviewCards = [
  {
    id: 1,
    title: 'Smarte Noise-Cancelling-Kopfhörer',
    score: 92,
    highlights: ['Adaptive Geräuschunterdrückung', 'Präziser Studioklang', 'Stabile App'],
    drawbacks: ['Leichtes Eigenrauschen beim Telefonieren'],
    image: 'https://picsum.photos/800/600?random=10',
    link: '/tests'
  },
  {
    id: 2,
    title: 'OLED-Notebook der neuen Generation',
    score: 88,
    highlights: ['16:10 OLED-Panel', 'Thermische Stabilität', 'Silent-Modus'],
    drawbacks: ['Webcam nur 1080p'],
    image: 'https://picsum.photos/800/600?random=11',
    link: '/tests'
  },
  {
    id: 3,
    title: 'Wi-Fi 7 Mesh-System',
    score: 90,
    highlights: ['Durchsatz im Multi-Gigabit-Bereich', 'Niedrige Latenzen', 'Solides Web-Dashboard'],
    drawbacks: ['Relativ großer Netzadapter'],
    image: 'https://picsum.photos/800/600?random=12',
    link: '/tests'
  }
];

const testimonials = [
  {
    quote:
      'Die Kombination aus Labordaten und narrativem Review-Flow hilft unserem Einkaufsteam enorm. Wir können Release-Strategien besser planen.',
    name: 'Mara Hoffmann',
    role: 'Produktstrategie, Techretail AG'
  },
  {
    quote:
      'Durch Slexorifyx verstehen wir nicht nur Spezifikationen, sondern reale Effizienz. Die Community liefert wertvolles Feedback für unsere Roadmap.',
    name: 'Jasper Klein',
    role: 'Head of R&D, Lumina Devices'
  },
  {
    quote:
      'Als Creator liebe ich die Visualisierung der Messwerte. Die Diagramme sind nachvollziehbar und einfach in unsere Berichterstattung integrierbar.',
    name: 'Tariq Mensah',
    role: 'Tech-Host & Podcaster'
  }
];

const projectItems = [
  {
    id: 'cam',
    title: 'Optik-Labor: Kamera-Array-Innenleben',
    category: 'Imaging',
    description:
      'Wir analysieren Sensorrauschen, Rolling-Shutter-Verhalten und Color-Grading-Pfade mit unserem Multi-Frame-Aufbau.',
    image: 'https://picsum.photos/1200/800?random=21'
  },
  {
    id: 'thermal',
    title: 'Thermalkammer: Dauerlast-Validierung',
    category: 'Performance',
    description:
      'Temperaturprofile werden mit 120 Messpunkten pro Minute erhoben, um Performance-Throttling zu visualisieren.',
    image: 'https://picsum.photos/1200/800?random=22'
  },
  {
    id: 'audio',
    title: 'Akustik-Cluster: Geräuschkulisse im Fokus',
    category: 'Audio',
    description:
      'Schallmessungen bis 20 Hz inklusive Richtcharakteristik, aufgezeichnet im schalltoten Raum.',
    image: 'https://picsum.photos/1200/800?random=23'
  },
  {
    id: 'battery',
    title: 'Energiestudio: Laufzeit & Effizienz',
    category: 'Power',
    description:
      'Detaillierte Verbrauchskurven mit programmierbaren Lastszenarien, visualisiert in Echtzeit.',
    image: 'https://picsum.photos/1200/800?random=24'
  }
];

const pollOptionsTemplate = [
  { id: 'foldable', label: 'Foldable mit eSIM-Optimierung', votes: 1240 },
  { id: 'mini-pc', label: 'Mini-PCs für Edge-AI', votes: 980 },
  { id: 'earbuds', label: 'Lossless In-Ear-Systeme', votes: 860 }
];

const measurementData = [
  {
    metric: 'Akkulaufzeit (h)',
    values: [
      { device: 'Device A', value: 19 },
      { device: 'Device B', value: 16 },
      { device: 'Device C', value: 21 }
    ],
    max: 24
  },
  {
    metric: 'Gehäusetemperatur (°C)',
    values: [
      { device: 'Device A', value: 42 },
      { device: 'Device B', value: 46 },
      { device: 'Device C', value: 39 }
    ],
    max: 60
  },
  {
    metric: 'Lautstärke (dB)',
    values: [
      { device: 'Device A', value: 28 },
      { device: 'Device B', value: 32 },
      { device: 'Device C', value: 26 }
    ],
    max: 50
  }
];

const blogPreview = [
  {
    id: 1,
    title: 'Was Early-Access-Feedback mit Launch-Projektionen macht',
    date: '12. März 2024',
    excerpt:
      'Community-basierte Datenmodelle zeigen, wie Release-Zeitpunkte mit iterativen Labormessungen verschmelzen.',
    image: 'https://picsum.photos/800/600?random=31'
  },
  {
    id: 2,
    title: 'So bauen wir Visualisierungen für Messwerte',
    date: '2. März 2024',
    excerpt:
      'Ein Blick hinter die Kulissen unserer Datenpipelines: Von Sensorik bis Storytelling auf einer einzigen Plattform.',
    image: 'https://picsum.photos/800/600?random=32'
  },
  {
    id: 3,
    title: 'Community Insights: Welche Geräte überraschen?',
    date: '21. Februar 2024',
    excerpt:
      'Wir zeigen, welche Produkte in der Community-Votingliste durch Detailfragen und Beta-Feedback auffallen.',
    image: 'https://picsum.photos/800/600?random=33'
  }
];

function Home() {
  const [statsVisible, setStatsVisible] = useState(false);
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const statsRef = useRef(null);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [pollOptions, setPollOptions] = useState(pollOptionsTemplate);
  const [hasVoted, setHasVoted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry.isIntersecting) {
          setStatsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsVisible) return;
    let animationFrame;

    const startTimestamp = performance.now();

    const animate = (timestamp) => {
      const progress = Math.min((timestamp - startTimestamp) / 1600, 1);
      setAnimatedStats(
        statsData.map((stat) => Math.round(stat.value * progress))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [statsVisible]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => window.clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Alle') return projectItems;
    return projectItems.filter((item) => item.category === projectFilter);
  }, [projectFilter]);

  const totalVotes = pollOptions.reduce((sum, option) => sum + option.votes, 0);

  const handleVote = (id) => {
    if (hasVoted) return;
    setPollOptions((prev) =>
      prev.map((option) =>
        option.id === id ? { ...option, votes: option.votes + 1 } : option
      )
    );
    setHasVoted(true);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Home | Slexorifyx – Technologie verstehen</title>
        <meta
          name="description"
          content="Slexorifyx verbindet präzise Labormessungen, Reviews und eine Early-Access-Community. Entdecke aktuelle Tests, Methodik und Zukunftsprojekte."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`${styles.heroContent} container`}>
          <div className={styles.heroText}>
            <p className={styles.heroBadge}>Laborgeprüfte Tech-Kompetenz</p>
            <h1>
              Slexorifyx – Technologie verstehen, bevor sie den Massenmarkt erreicht.
            </h1>
            <p>
              Wir vereinen unabhängige Testprotokolle, visuelle Messdaten und eine engagierte
              Community. Mit Slexorifyx erkennst du, welches Produkt wirklich zu deinem Projekt
              passt – von Early-Access-Prototypen bis zu Seriengeräten.
            </p>
            <div className={styles.heroActions}>
              <Link to="/early-access" className={styles.primaryButton}>
                Early Access sichern
              </Link>
              <Link to="/methodik" className={styles.secondaryButton}>
                Unsere Testmethodik
              </Link>
            </div>
            <div className={styles.heroMeta}>
              <span>ISO-kalibrierte Messräume</span>
              <span>Live-Kommentare aus der Community</span>
              <span>Transparente Affiliate-Marke</span>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Technologieexpertinnen in einem modernen Labor"
              loading="lazy"
            />
            <div className={styles.heroOverlay}>
              <p>Aktuelle Analyse: Foldable Performance 2024</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef} aria-label="Kennzahlen">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, idx) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{animatedStats[idx]}</span>
                <span className={styles.statLabel}>{stat.label}</span>
                <div className={styles.statBar}>
                  <div className={styles.statBarFill} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.reviews} aria-labelledby="review-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2 id="review-heading">Aktuelle Reviews</h2>
              <p>
                Datengestützte Reviews mit Scorecards, Messdiagrammen und klaren Handlungsempfehlungen
                für Produktteams, Einkäufer und Enthusiasten.
              </p>
            </div>
            <Link to="/tests" className={styles.sectionLink}>
              Alle Tests ansehen
            </Link>
          </div>
          <div className={styles.reviewGrid}>
            {reviewCards.map((card) => (
              <article key={card.id} className={styles.reviewCard}>
                <div className={styles.reviewMedia}>
                  <img src={card.image} alt={card.title} loading="lazy" />
                  <span className={styles.reviewScore}>{card.score}</span>
                </div>
                <div className={styles.reviewBody}>
                  <h3>{card.title}</h3>
                  <div className={styles.reviewLists}>
                    <div>
                      <h4>Highlights</h4>
                      <ul>
                        {card.highlights.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4>Zu beachten</h4>
                      <ul>
                        {card.drawbacks.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  <Link to={card.link} className={styles.primaryButtonAlt} aria-label={`Zum Test: ${card.title}`}>
                    Zum Test
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.earlyAccess} aria-labelledby="early-access-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2 id="early-access-heading">Early Access Community</h2>
              <p>
                Werde Teil unserer Early-Access-Programme und begleite Produkte vom Engineering Sample
                bis zum Launch. Mit Co-Creation-Sessions, Fokusgruppen und Live-Dashboards.
              </p>
            </div>
            <Link to="/early-access" className={styles.sectionLink}>
              Teilnahme beantragen
            </Link>
          </div>
          <div className={styles.earlyGrid}>
            <div className={styles.earlyCard}>
              <h3>Community Sessions</h3>
              <p>
                Wöchentliche Feedback-Loops mit unseren Testingenieurinnen. Du erhältst Fragenkataloge,
                Beta-Funktionen und kannst Prioritäten direkt einspeisen.
              </p>
            </div>
            <div className={styles.earlyCard}>
              <h3>Live-Dashboards</h3>
              <p>
                Verfolge Messdaten, Firmware-Versionen und Micro-Benchmarks in Echtzeit – inklusive
                Kommentarfunktion für produktive Diskussionen.
              </p>
            </div>
            <div className={styles.earlyCard}>
              <h3>Release-Alerts</h3>
              <p>
                Wir informieren dich, wenn Hersteller auf dein Feedback reagieren und neue Iterationen
                für unsere Labors einplanen.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.method} aria-labelledby="method-heading">
        <div className="container">
          <div className={styles.methodGrid}>
            <div>
              <h2 id="method-heading">Testmethodik mit Tiefe</h2>
              <p>
                Jede Testreihe folgt einem strukturierten Protokoll: Kalibrierung, Messlauf, Analyse,
                Peer-Review und Community-Feedback. Durch klar definierte KPIs lassen sich Ergebnisse
                Jahr für Jahr vergleichen.
              </p>
              <ul className={styles.methodList}>
                <li>Kalibrierte Messumgebungen mit ISO-zertifizierten Geräten.</li>
                <li>Firmware- und Softwarestände werden versioniert dokumentiert.</li>
                <li>Peer-Review durch Datenanalysten vor Veröffentlichung.</li>
              </ul>
              <Link to="/methodik" className={styles.secondaryButton}>
                Methodik entdecken
              </Link>
            </div>
            <div className={styles.methodVisual}>
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Messgeräte und Diagramme im Labor"
                loading="lazy"
              />
              <div className={styles.methodBadge}>
                <span>Standardisierte Protokolle</span>
                <span>Messgenauigkeit ±0,1 %</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.community} aria-labelledby="community-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2 id="community-heading">Was testen wir als Nächstes?</h2>
              <p>
                Unsere Community legt Schwerpunkte. Du kannst abstimmen, kommentieren und deine
                Anforderungen teilen. Die Ergebnisse fließen direkt in unser Test-Backlog ein.
              </p>
            </div>
          </div>
          <div className={styles.pollGrid}>
            <div className={styles.pollCard}>
              <h3>Community Voting</h3>
              <p>
                Stimme für das Gerät, das wir als nächstes in die Laborpipeline aufnehmen sollen.
                Deine Stimme zählt, sobald du am Early-Access-Programm teilnimmst.
              </p>
              <div className={styles.pollOptions}>
                {pollOptions.map((option) => {
                  const percentage = totalVotes > 0 ? Math.round((option.votes / totalVotes) * 100) : 0;
                  return (
                    <button
                      key={option.id}
                      type="button"
                      className={`${styles.pollOption} ${hasVoted ? styles.pollOptionLocked : ''}`}
                      onClick={() => handleVote(option.id)}
                      aria-pressed={false}
                      disabled={hasVoted}
                    >
                      <div className={styles.pollLabel}>
                        <span>{option.label}</span>
                        <span>{percentage} %</span>
                      </div>
                      <div className={styles.pollBar}>
                        <div
                          className={styles.pollBarFill}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
              <p className={styles.pollMeta}>
                Gesamtstimmen: {totalVotes.toLocaleString('de-DE')} – Aktualisiert alle 60 Minuten.
              </p>
            </div>
            <div className={styles.communityCard}>
              <h3>Community-Features</h3>
              <ul>
                <li>Feedback-Threads direkt unter Messgrafiken.</li>
                <li>Beta-Release-Notes mit Kommentarfunktion.</li>
                <li>Hands-on-Livestreams aus dem Berliner Labor.</li>
                <li>Matchmaking für Corporate-Use-Cases.</li>
              </ul>
              <Link to="/early-access" className={styles.primaryButton}>
                Zur Community
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.transparency}>
        <div className="container">
          <div className={styles.transparencyCard}>
            <h2>Transparenz vor jedem Review</h2>
            <p>
              Wir kennzeichnen Leihstellungen und Affiliate-Verlinkungen deutlich. Hersteller haben
              keine Möglichkeit, Review-Inhalte vorab zu ändern. Jedes Testgerät wird nach dem Review
              protokolliert archiviert oder zurückgesendet.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-heading">
        <div className="container">
          <h2 id="process-heading">So arbeiten wir</h2>
          <div className={styles.processGrid}>
            <div className={styles.processStep}>
              <span>01</span>
              <h3>Briefing &amp; Hypothesen</h3>
              <p>Gemeinsam mit der Community definieren wir Messszenarien und Hypothesen pro Produkt.</p>
            </div>
            <div className={styles.processStep}>
              <span>02</span>
              <h3>Labordurchlauf</h3>
              <p>
                Wir erfassen Sensor-, Audio-, Bild- und Performance-Daten in kontrollierten Umgebungen
                und automatisieren die Datenpipelines.
              </p>
            </div>
            <div className={styles.processStep}>
              <span>03</span>
              <h3>Analyse &amp; Review</h3>
              <p>
                Analystinnen verknüpfen Messwerte mit Anwendungsszenarien und fassen Ergebnisse in
                verständlichen Narrativen zusammen.
              </p>
            </div>
            <div className={styles.processStep}>
              <span>04</span>
              <h3>Iteration</h3>
              <p>
                Auf Basis von Community-Feedback planen wir Nachtests, Firmware-Checks und
                Vergleichsmessungen.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2 id="projects-heading">Lab-Projekte &amp; Showcases</h2>
              <p>
                Einblick in aktuelle Setups unseres Berliner Labors. Filtere nach Kategorien, um die
                passenden Insights für deine Roadmap zu finden.
              </p>
            </div>
            <div className={styles.projectFilters} role="group" aria-label="Projektfilter">
              {['Alle', 'Imaging', 'Performance', 'Audio', 'Power'].map((filter) => (
                <button
                  key={filter}
                  type="button"
                  className={`${styles.filterButton} ${
                    projectFilter === filter ? styles.filterButtonActive : ''
                  }`}
                  onClick={() => setProjectFilter(filter)}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectBody}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/methodik" className={styles.sectionLink}>
                    Setup im Detail
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.measurements} aria-labelledby="measure-heading">
        <div className="container">
          <h2 id="measure-heading">Messdaten auf einen Blick</h2>
          <p className={styles.measureIntro}>
            Wir präsentieren relevante Messwerte in interaktiven Diagrammen. Hier siehst du einen
            Ausschnitt aus unserer Datenbank – vollständig abrufbar im Vergleichsbereich.
          </p>
          <div className={styles.chartGrid}>
            {measurementData.map((metric) => (
              <div key={metric.metric} className={styles.chartCard}>
                <h3>{metric.metric}</h3>
                <div className={styles.chartBars}>
                  {metric.values.map((entry) => {
                    const width = Math.round((entry.value / metric.max) * 100);
                    return (
                      <div key={entry.device} className={styles.chartRow}>
                        <span>{entry.device}</span>
                        <div className={styles.chartBar}>
                          <div
                            className={styles.chartBarFill}
                            style={{ width: `${width}%` }}
                            aria-hidden="true"
                          />
                        </div>
                        <span className={styles.chartValue}>{entry.value}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
          <Link to="/vergleiche" className={styles.secondaryButton}>
            Zum Vergleichs-Tool
          </Link>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-heading">
        <div className="container">
          <div className={styles.sectionHeaderCenter}>
            <h2 id="testimonials-heading">Stimmen aus dem Netzwerk</h2>
            <p>
              Entscheidungsträger, Entwicklerinnen und Creator teilen, wie sie Slexorifyx nutzen, um
              Produkte besser auf den Markt zu bringen.
            </p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <blockquote
                key={testimonial.name}
                className={`${styles.testimonialSlide} ${
                  index === currentTestimonial ? styles.testimonialActive : ''
                }`}
              >
                <p>„{testimonial.quote}“</p>
                <footer>
                  <span className={styles.testimonialName}>{testimonial.name}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
            <div className={styles.carouselControls} role="group" aria-label="Testimonial-Navigation">
              <button
                type="button"
                onClick={() =>
                  setCurrentTestimonial(
                    (prev) => (prev - 1 + testimonials.length) % testimonials.length
                  )
                }
                aria-label="Vorheriges Testimonial"
              >
                ←
              </button>
              <button
                type="button"
                onClick={() =>
                  setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
                }
                aria-label="Nächstes Testimonial"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2 id="blog-heading">Blog &amp; Insights</h2>
              <p>
                Stories aus dem Labor, Analysen für Produktteams, Interviews mit Expertinnen aus
                unserem Netzwerk.
              </p>
            </div>
            <Link to="/blog" className={styles.sectionLink}>
              Zum Blog
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPreview.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogBody}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog`} className={styles.sectionLink}>
                    Weiterlesen
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.finalCTA}>
        <div className="container">
          <div className={styles.finalContent}>
            <h2>Bereit für präzise Tech-Entscheidungen?</h2>
            <p>
              Verbinde deine Produktstrategie mit unabhängigen Messdaten, Community-Insights und
              analytischen Vergleichen. Slexorifyx liefert die Grundlage, um Technik mutig und
              fundiert zu gestalten.
            </p>
            <div className={styles.finalActions}>
              <Link to="/kontakt" className={styles.primaryButton}>
                Kontakt aufnehmen
              </Link>
              <Link to="/partner" className={styles.secondaryButton}>
                Partner werden
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;
```