```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Methodik.module.css';

const protocols = [
  {
    title: 'Akkulaufzeit & Energieeffizienz',
    description:
      'Wir nutzen programmierbare Lastgeneratoren mit definierten Szenarien. Die Messung erfolgt in drei Temperaturbereichen und wird per Logging aufgezeichnet.',
    steps: ['Kalibrierung', 'Baseline-Test', 'Szenario-Loop', 'Verifikation']
  },
  {
    title: 'Thermik & Lautstärke',
    description:
      'Temperaturmessungen erfolgen mit 24 Sensorpunkten. Parallel tracken wir Schallpegel im Abstand von 30 cm und 60 cm, jeweils mit A- und C-Bewertung.',
    steps: ['Sensor-Setup', 'Warm-up', 'Lasttests', 'Cooldown']
  },
  {
    title: 'Display & Imaging',
    description:
      'Wir messen Helligkeit, Farbraumabdeckung, Kontrast und Gleichmäßigkeit. Die Kalibrierung basiert auf einem Spektroradiometer.',
    steps: ['Kelvin-Abgleich', 'Pattern-Analyse', 'Gleichmäßigkeit', 'Farbprofil-Messung']
  },
  {
    title: 'Netzwerk & Kommunikation',
    description:
      'Latenzen, Durchsatz und Paketverluste werden in einer abgeschirmten Umgebung getestet. Wir simulieren reale Störquellen und messen mit drei Abstandsstufen.',
    steps: ['Baseline', 'Störsimulation', 'Dauerlast', 'Resultat-Abgleich']
  }
];

function Methodik() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Methodik | Slexorifyx</title>
        <meta
          name="description"
          content="Erfahre, wie Slexorifyx testet: Protokolle für Akkulaufzeit, Thermik, Display, Audio, Netzwerk und mehr."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Unsere Testmethodik</h1>
          <p>
            Präzision, Reproduzierbarkeit und Transparenz: Jedes Testfeld folgt klar definierten
            Protokollen, die wir kontinuierlich weiterentwickeln. So bleiben Ergebnisse vergleichbar –
            über Geräteklassen und Modelljahre hinweg.
          </p>
        </div>
      </header>

      <section className={styles.protocols} aria-labelledby="protocols-heading">
        <div className="container">
          <h2 id="protocols-heading">Protokolle im Überblick</h2>
          <div className={styles.protocolGrid}>
            {protocols.map((protocol) => (
              <article key={protocol.title} className={styles.protocolCard}>
                <h3>{protocol.title}</h3>
                <p>{protocol.description}</p>
                <ol>
                  {protocol.steps.map((step) => (
                    <li key={step}>{step}</li>
                  ))}
                </ol>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.quality} aria-labelledby="quality-heading">
        <div className="container">
          <div className={styles.qualityGrid}>
            <div>
              <h2 id="quality-heading">Qualitätssicherung</h2>
              <p>
                Alle Testläufe durchlaufen eine interne Qualitätssicherung. Messdaten werden von
                mindestens zwei Personen geprüft. Zusätzlich holen wir Feedback aus der Community ein,
                bevor ein Review live geht.
              </p>
              <ul>
                <li>Messwerte werden automatisiert auf Ausreißer geprüft.</li>
                <li>Firmwarestände und Softwareversionen sind im Review dokumentiert.</li>
                <li>Wir führen Nachtests bei Firmware-Updates durch.</li>
              </ul>
            </div>
            <div className={styles.qualityVisual}>
              <img
                src="https://picsum.photos/800/600?random=5"
                alt="Messgeräte und Kontrollmonitore im Labor"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.validation} aria-labelledby="validation-heading">
        <div className="container">
          <h2 id="validation-heading">Validierung durch Partner</h2>
          <p>
            Unsere Protokolle werden regelmäßig mit externen Partnern validiert. Dazu zählen
            Hochschulen, unabhängige Labore und Fachjournalistinnen. Wir dokumentieren jede Revision
            und halten Versionen öffentlich nachverfolgbar.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Methodik;
```