```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

function Terms() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>AGB | Slexorifyx</title>
        <meta
          name="description"
          content="Allgemeine Geschäftsbedingungen von Slexorifyx für die Nutzung der Plattform."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Allgemeine Geschäftsbedingungen</h1>
          <p>Stand: März 2024</p>
        </div>
      </header>

      <section className={styles.content}>
        <div className="container">
          <ol>
            <li>
              <h2>Anwendungsbereich</h2>
              <p>
                Diese Bedingungen regeln die Nutzung der Plattform Slexorifyx, betrieben von der
                Slexorifyx Media GmbH, Friedrichstraße 68, 10117 Berlin. Abweichende Bedingungen
                werden nicht anerkannt.
              </p>
            </li>
            <li>
              <h2>Leistungen</h2>
              <p>
                Slexorifyx stellt technische Inhalte, Labortests, Community-Funktionen und
                Early-Access-Programme bereit. Der Umfang der Leistungen kann jederzeit angepasst
                werden, sofern dadurch keine wesentlichen Nachteile entstehen.
              </p>
            </li>
            <li>
              <h2>Registrierung</h2>
              <p>
                Für bestimmte Funktionen ist eine Registrierung erforderlich. Nutzerinnen und Nutzer
                sind verpflichtet, Angaben wahrheitsgemäß zu machen und Zugangsdaten vertraulich zu
                behandeln.
              </p>
            </li>
            <li>
              <h2>Inhalte und Rechte</h2>
              <p>
                Sämtliche Inhalte, einschließlich Messdaten, Artikel und Grafiken, sind urheberrechtlich
                geschützt. Eine Weitergabe oder Veröffentlichung bedarf der ausdrücklichen Zustimmung
                der Slexorifyx Media GmbH.
              </p>
            </li>
            <li>
              <h2>Community-Regeln</h2>
              <p>
                Beiträge in Foren, Kommentaren oder Workshops müssen respektvoll und sachlich
                bleiben. Slexorifyx behält sich vor, Beiträge zu moderieren oder zu entfernen, die
                gegen geltendes Recht oder diese Bedingungen verstoßen.
              </p>
            </li>
            <li>
              <h2>Haftung</h2>
              <p>
                Slexorifyx haftet nur für Vorsatz oder grobe Fahrlässigkeit. Bei leicht fahrlässigen
                Pflichtverletzungen haften wir lediglich für vorhersehbare Schäden aus wesentlichen
                Vertragspflichten. Die Haftung für Datenverlust ist ausgeschlossen, sofern der Verlust
                bei ordnungsgemäßer Datensicherung vermeidbar gewesen wäre.
              </p>
            </li>
            <li>
              <h2>Änderungen der Bedingungen</h2>
              <p>
                Slexorifyx kann diese Bedingungen anpassen. Über wesentliche Änderungen informieren
                wir mit angemessener Frist. Nutzerinnen können der Änderung widersprechen; in diesem
                Fall kann das Nutzungsverhältnis beendet werden.
              </p>
            </li>
            <li>
              <h2>Gerichtsstand</h2>
              <p>
                Es gilt deutsches Recht. Gerichtsstand für Kaufleute ist Berlin.
              </p>
            </li>
          </ol>
        </div>
      </section>
    </div>
  );
}

export default Terms;
```