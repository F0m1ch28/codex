```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Vergleiche.module.css';

const devices = [
  {
    id: 'device-a',
    name: 'Ultrabook 14" 2024',
    battery: 19,
    temperature: 42,
    noise: 28,
    brightness: 620
  },
  {
    id: 'device-b',
    name: 'Foldable Phone X',
    battery: 16,
    temperature: 36,
    noise: 0,
    brightness: 1200
  },
  {
    id: 'device-c',
    name: 'Wi-Fi 7 Mesh Pro',
    battery: 0,
    temperature: 38,
    noise: 25,
    brightness: 0
  },
  {
    id: 'device-d',
    name: 'ANC Earbuds Air',
    battery: 8,
    temperature: 0,
    noise: 24,
    brightness: 0
  }
];

function Vergleiche() {
  const [selection, setSelection] = useState(['device-a', 'device-b']);
  const [error, setError] = useState('');

  const toggleDevice = (id) => {
    if (selection.includes(id)) {
      setSelection((prev) => prev.filter((item) => item !== id));
      setError('');
    } else if (selection.length < 3) {
      setSelection((prev) => [...prev, id]);
      setError('');
    } else {
      setError('Bitte zuerst ein Gerät abwählen, um ein weiteres hinzuzufügen.');
    }
  };

  const selectedDevices = devices.filter((device) => selection.includes(device.id));
  const metrics = ['battery', 'temperature', 'noise', 'brightness'];

  const metricLabels = {
    battery: 'Akkulaufzeit (h)',
    temperature: 'Gehäusetemperatur (°C)',
    noise: 'Lautstärke (dB)',
    brightness: 'Displayhelligkeit (cd/m²)'
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vergleiche | Slexorifyx</title>
        <meta
          name="description"
          content="Vergleiche bis zu drei Geräte in Echtzeit. Akkulaufzeit, Temperatur, Lautstärke und Helligkeit im Überblick."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Vergleichs-Tool</h1>
          <p>
            Wähle bis zu drei Geräte aus und vergleiche zentrale Messwerte. Die Daten stammen direkt
            aus unseren Laborprotokollen und werden laufend aktualisiert.
          </p>
        </div>
      </header>

      <section className={styles.selector} aria-labelledby="selector-heading">
        <div className="container">
          <h2 id="selector-heading">Geräte auswählen</h2>
          <p className={styles.selectorHint}>Maximal drei Geräte gleichzeitig vergleichen.</p>
          {error && <p className={styles.error}>{error}</p>}
          <div className={styles.deviceList}>
            {devices.map((device) => (
              <label key={device.id} className={styles.deviceOption}>
                <input
                  type="checkbox"
                  checked={selection.includes(device.id)}
                  onChange={() => toggleDevice(device.id)}
                />
                <span>{device.name}</span>
              </label>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.comparison} aria-labelledby="comparison-heading">
        <div className="container">
          <h2 id="comparison-heading">Messwerte vergleichen</h2>
          <div className={styles.comparisonGrid}>
            {metrics.map((metric) => (
              <div key={metric} className={styles.metricCard}>
                <h3>{metricLabels[metric]}</h3>
                <div className={styles.metricBars}>
                  {selectedDevices.map((device) => {
                    const value = device[metric];
                    const maxValue = Math.max(
                      ...selectedDevices.map((item) => item[metric]),
                      1
                    );
                    const width = value > 0 ? Math.round((value / maxValue) * 100) : 5;
                    return (
                      <div key={device.id} className={styles.metricRow}>
                        <span>{device.name}</span>
                        <div className={styles.metricBar}>
                          <div
                            className={styles.metricFill}
                            style={{ width: `${width}%` }}
                            aria-hidden="true"
                          />
                        </div>
                        <strong>{value > 0 ? value : 'n/a'}</strong>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Vergleiche;
```