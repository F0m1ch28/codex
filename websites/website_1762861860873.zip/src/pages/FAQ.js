```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './FAQ.module.css';

const questions = [
  {
    question: 'Wie unabhängig sind eure Reviews?',
    answer:
      'Wir arbeiten nach klaren Richtlinien. Hersteller können Testgeräten keine Bedingungen anhängen. Alle Inhalte durchlaufen einen Peer-Review-Prozess und werden transparent markiert.'
  },
  {
    question: 'Wie funktioniert der Double-Opt-In beim Early Access?',
    answer:
      'Du meldest dich mit deiner E-Mail-Adresse an, erhältst eine Bestätigungsmail und musst diese aktiv bestätigen. Erst dann bist du Teil des Programms.'
  },
  {
    question: 'Kann ich eigene Messwerte einbringen?',
    answer:
      'Ja. In der Community kannst du eigene Setups teilen. Unser Team prüft die Daten und kennzeichnet sie als Community-Messung, sofern sie nachvollziehbar sind.'
  },
  {
    question: 'Wie oft aktualisiert ihr Testberichte?',
    answer:
      'Bei relevanten Firmware- oder Hardwareupdates führen wir Nachtests durch und kennzeichnen die aktualisierte Version im Artikelkopf.'
  },
  {
    question: 'Bietet ihr Rohdaten an?',
    answer:
      'Für Forschung und Produktteams stellen wir auf Anfrage Rohdaten bereit. Die Nutzung ist an unsere Transparenzrichtlinien gebunden.'
  }
];

function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>FAQ | Slexorifyx</title>
        <meta
          name="description"
          content="Antworten auf häufige Fragen zu Slexorifyx: Unabhängigkeit, Early Access, Datenverfügbarkeit und mehr."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>FAQ</h1>
          <p>
            Häufig gestellte Fragen rund um Slexorifyx. Falls du weitere Fragen hast, melde dich
            jederzeit bei unserem Team.
          </p>
        </div>
      </header>

      <section className={styles.accordion}>
        <div className="container">
          <div className={styles.items} role="tablist">
            {questions.map((item, index) => {
              const isOpen = openIndex === index;
              return (
                <div key={item.question} className={styles.item}>
                  <button
                    type="button"
                    className={styles.question}
                    aria-expanded={isOpen}
                    onClick={() => setOpenIndex(isOpen ? -1 : index)}
                  >
                    {item.question}
                    <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && (
                    <div className={styles.answer} role="tabpanel">
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

export default FAQ;
```