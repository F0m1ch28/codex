```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    id: 1,
    title: 'Release-Ready: Wie wir Firmware-Updates nachtesten',
    date: '14. März 2024',
    author: 'Jonas Winter',
    excerpt:
      'Firmware-Updates verändern oft Thermik, Akkulaufzeit oder Audio-Performance. Wir zeigen, wie wir Nachtests planen und dokumentieren.',
    image: 'https://picsum.photos/800/600?random=61'
  },
  {
    id: 2,
    title: 'Imaging-Workshop: Farbwiedergabe im Labor',
    date: '5. März 2024',
    author: 'Leonie Stahl',
    excerpt:
      'Wie wir Colorimeter, Spektroradiometer und Lichtbox einsetzen, um Farbwiedergabe valide zu messen.',
    image: 'https://picsum.photos/800/600?random=62'
  },
  {
    id: 3,
    title: 'Community Impact: Early-Access-Insights 2024',
    date: '28. Februar 2024',
    author: 'Carla Nguyen',
    excerpt:
      'Wir analysieren, welche Themen die Community aktuell priorisiert und wie das unsere Testreihen beeinflusst.',
    image: 'https://picsum.photos/800/600?random=63'
  },
  {
    id: 4,
    title: 'Audio-Lab: Der Weg zum natürlichen Transparenzmodus',
    date: '19. Februar 2024',
    author: 'Dr. Victor Sander',
    excerpt:
      'Analyse des Frequenzgangs, des Differenzdrucks und der Richtcharakteristik – mit Fokus auf In-Ear-Systeme.',
    image: 'https://picsum.photos/800/600?random=64'
  }
];

function Blog() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Blog | Slexorifyx</title>
        <meta
          name="description"
          content="Neuigkeiten und Analysen rund um Techniktests, Methodik und Community von Slexorifyx."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Blog &amp; Insights</h1>
          <p>
            Wir teilen Labor-Updates, Methodik-Tipps und Community-Stories. Hier findest du tiefe
            Einblicke in den Alltag von Slexorifyx.
          </p>
        </div>
      </header>

      <section className={styles.posts} aria-labelledby="posts-heading">
        <div className="container">
          <h2 id="posts-heading">Aktuelle Beiträge</h2>
          <div className={styles.postGrid}>
            {posts.map((post) => (
              <article key={post.id} className={styles.postCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.postBody}>
                  <span className={styles.meta}>
                    {post.date} · {post.author}
                  </span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <button type="button" className={styles.readMore}>
                    Beitrag öffnen
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Blog;
```