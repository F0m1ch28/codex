```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Datenschutz | Slexorifyx</title>
        <meta
          name="description"
          content="Datenschutzerklärung von Slexorifyx gemäß DSGVO."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Datenschutzerklärung</h1>
          <p>Stand: März 2024</p>
        </div>
      </header>

      <section className={styles.content}>
        <div className="container">
          <h2>1. Verantwortlicher</h2>
          <p>
            Slexorifyx Media GmbH, Friedrichstraße 68, 10117 Berlin, Deutschland, vertreten durch die
            Geschäftsführung. Kontakt: kontakt@slexorifyx.de.
          </p>

          <h2>2. Datenverarbeitung</h2>
          <p>
            Wir verarbeiten personenbezogene Daten nur, soweit es zur Bereitstellung unserer Inhalte,
            zur Community-Nutzung oder zur Bearbeitung von Anfragen erforderlich ist. Rechtsgrundlagen
            sind Art. 6 Abs. 1 lit. a, b und f DSGVO.
          </p>

          <h2>3. Newsletter &amp; Early Access</h2>
          <p>
            Für Early-Access-Programme und Newsletter nutzen wir das Double-Opt-In-Verfahren. Die
            E-Mail-Adresse wird erst nach Bestätigung gespeichert. Eine Abmeldung ist jederzeit
            möglich.
          </p>

          <h2>4. Analysen</h2>
          <p>
            Wir setzen anonymisierte Analysewerkzeuge ein, um die Nutzung unserer Inhalte zu
            verstehen. Eine Zuordnung zu einzelnen Personen erfolgt nicht.
          </p>

          <h2>5. Weitergabe von Daten</h2>
          <p>
            Eine Weitergabe personenbezogener Daten erfolgt nur, wenn dies gesetzlich vorgeschrieben
            ist oder zur Erfüllung unserer Leistungen notwendig wird, beispielsweise an Dienstleister,
            die wir sorgfältig auswählen und vertraglich binden.
          </p>

          <h2>6. Rechte der Betroffenen</h2>
          <p>
            Nutzerinnen und Nutzer haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung
            der Verarbeitung sowie auf Datenübertragbarkeit (Art. 15–20 DSGVO). Zudem besteht ein
            Beschwerderecht bei einer Aufsichtsbehörde.
          </p>

          <h2>7. Aufbewahrung</h2>
          <p>
            Daten werden gelöscht, sobald der Zweck entfällt und keine gesetzlichen Aufbewahrungsfristen
            entgegenstehen.
          </p>

          <h2>8. Sicherheit</h2>
          <p>
            Wir setzen technische und organisatorische Maßnahmen ein, um Daten vor Verlust, Manipulation
            oder unbefugtem Zugriff zu schützen.
          </p>

          <h2>9. Änderungen</h2>
          <p>
            Diese Datenschutzerklärung kann angepasst werden. Die aktuelle Version ist auf dieser Seite
            abrufbar.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Privacy;
```