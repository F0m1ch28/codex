```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Leonie Stahl',
    role: 'Head of Lab Operations',
    bio: 'Verantwortet das Testlabor in Berlin, entwickelt Messprotokolle und leitet das QA-Team.',
    focus: 'Thermische Messungen, Power-Management',
    image: 'https://picsum.photos/400/400?random=41'
  },
  {
    name: 'Dr. Victor Sander',
    role: 'Lead Data Scientist',
    bio: 'Gestaltet die Datenpipelines, sorgt für Validierung und interpretiert Messkurven für Storytelling.',
    focus: 'Machine Learning, Signalverarbeitung',
    image: 'https://picsum.photos/400/400?random=42'
  },
  {
    name: 'Carla Nguyen',
    role: 'Community & Early Access Lead',
    bio: 'Moderiert Feedback-Sessions, organisiert Workshops mit Partnern und kuratiert Beta-Programme.',
    focus: 'Community Design, Trendanalyse',
    image: 'https://picsum.photos/400/400?random=43'
  },
  {
    name: 'Jonas Winter',
    role: 'Senior Reviewer',
    bio: 'Verbindet Laborinhalte mit Alltagsszenarien, schreibt tiefgehende Reviews und analysiert Firmware.',
    focus: 'Audio, Mobile Computing',
    image: 'https://picsum.photos/400/400?random=44'
  }
];

function About() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Über Uns | Slexorifyx</title>
        <meta
          name="description"
          content="Lerne das Team von Slexorifyx kennen, erfahre mehr über unsere Geschichte, Laborstandards und Werte."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <span className={styles.label}>Unser Weg</span>
          <h1>Wir bringen Laborwissen in deine Entscheidungsprozesse.</h1>
          <p>
            Slexorifyx wurde 2018 in Berlin gegründet, um Technologie-Medien neu zu denken. Statt
            Spezifikationslisten fokussieren wir uns auf reale Messwerte, Storytelling und
            Community-getriebene Prioritäten.
          </p>
        </div>
      </header>

      <section className={styles.story} aria-labelledby="story-heading">
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2 id="story-heading">Unsere Geschichte</h2>
              <p>
                Angefangen hat alles mit einem Prototyp unseres jetzigen Messlabors in Kreuzberg.
                Schnell wurde klar: Unternehmen, Creators und Konsumentinnen brauchen eine Plattform,
                die präzise Daten liefert und zugleich verständlich bleibt. Heute betreiben wir auf
                450 Quadratmetern eine modulare Testumgebung, die von Akustik über Imaging bis zu
                Performance alles abdeckt.
              </p>
              <p>
                Wir glauben an Zusammenarbeit: Durch Early-Access-Programme, Labortage mit
                Partnern und Community-Feedback entstehen Tests, die nah am Markt sind und trotzdem
                wissenschaftlich bleiben.
              </p>
            </div>
            <div className={styles.storyStats}>
              <div>
                <span>2018</span>
                <p>Gründung in Berlin-Mitte.</p>
              </div>
              <div>
                <span>450 m²</span>
                <p>Laborfläche mit modularen Teststationen.</p>
              </div>
              <div>
                <span>38</span>
                <p>Teammitglieder in Lab, Redaktion &amp; Community.</p>
              </div>
              <div>
                <span>4</span>
                <p>Partneruniversitäten für Methoden-Reviews.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values} aria-labelledby="values-heading">
        <div className="container">
          <h2 id="values-heading">Unsere Werte</h2>
          <div className={styles.valuesGrid}>
            <article>
              <h3>Unabhängigkeit</h3>
              <p>
                Wir publizieren erst nach Abschluss des Peer-Review-Prozesses und kennzeichnen jede
                Art der Zusammenarbeit. Unsere Testreihen bleiben unverändert – auch wenn wir Geräte
                als Leihstellung erhalten.
              </p>
            </article>
            <article>
              <h3>Transparenz</h3>
              <p>
                Alle Messparameter, Softwarestände und Firmware-Versionen sind in jedem Artikel
                dokumentiert. Änderungen werden versioniert nachverfolgt.
              </p>
            </article>
            <article>
              <h3>Relevanz</h3>
              <p>
                Wir verbinden Laborergebnisse mit Kontext: Anwendungsszenarien, Branchentrends,
                Feedback aus der Community. So entsteht Wissen, das Entscheidungen erleichtert.
              </p>
            </article>
            <article>
              <h3>Ko-Kreation</h3>
              <p>
                Die Community beeinflusst unsere Prioritäten. Wir moderieren Workshops, Pilotprojekte
                und Vergleichsreihen – gemeinsam mit Herstellerteams.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.lab} aria-labelledby="lab-heading">
        <div className="container">
          <div className={styles.labGrid}>
            <div className={styles.labVisual}>
              <img
                src="https://picsum.photos/800/600?random=4"
                alt="Innenaufnahme des Slexorifyx-Testlabors"
                loading="lazy"
              />
            </div>
            <div>
              <h2 id="lab-heading">Das Labor</h2>
              <p>
                Unser Labor ist modular aufgebaut: Ein Akustikraum mit Schallpegelmonitoring, ein
                Klima- und Thermalkammer-Setup, ein Imaging-Bereich mit Lichtstufensteuerung sowie
                ein Performance-Cluster mit automatisierten Benchmarks.
              </p>
              <ul className={styles.labList}>
                <li>Temperaturbereich: -10 °C bis +60 °C, reguliert mit ±0,5 °C Genauigkeit.</li>
                <li>Audio-Messraum mit Hintergrundschall unter 22 dB(A).</li>
                <li>Programmierbare Lastgeneratoren für Power- und Batterieanalysen.</li>
                <li>Multi-Angle-Kameraaufbau für Bild- und Videovergleiche.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <div className="container">
          <h2 id="team-heading">Unser Team</h2>
          <p className={styles.teamIntro}>
            Interdisziplinäre Spezialistinnen aus Lab, Redaktion, Community-Management und Datenanalyse
            arbeiten Hand in Hand. Wir lieben Technik – und wir lieben klare Kommunikation.
          </p>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImage}>
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </div>
                <div className={styles.teamBody}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                  <span className={styles.teamFocus}>Schwerpunkte: {member.focus}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.commitment} aria-labelledby="commit-heading">
        <div className="container">
          <div className={styles.commitCard}>
            <h2 id="commit-heading">Unser Versprechen</h2>
            <p>
              Wir liefern Messungen, die nachprüfbar sind. Wir veröffentlichen Inhalte, die verständlich
              bleiben. Und wir glauben daran, dass Technologie nur dann begeistert, wenn alle
              Beteiligten einbezogen werden – Hersteller, Community, Analystinnen.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;
```