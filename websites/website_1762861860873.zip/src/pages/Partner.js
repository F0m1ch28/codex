```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Partner.module.css';

function Partner() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Partner | Slexorifyx</title>
        <meta
          name="description"
          content="Informationen für Hersteller, PR und Agenturen, die mit Slexorifyx zusammenarbeiten möchten."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Partnerprogramme</h1>
          <p>
            Hersteller, Agenturen und Kommunikations-Teams finden bei Slexorifyx eine Plattform für
            transparente Tests, Storytelling und Community-Feedback. Wir arbeiten unabhängig und
            klar dokumentiert.
          </p>
        </div>
      </header>

      <section className={styles.options} aria-labelledby="options-heading">
        <div className="container">
          <h2 id="options-heading">Kooperationsmöglichkeiten</h2>
          <div className={styles.optionGrid}>
            <article>
              <h3>Testaufträge</h3>
              <p>
                Wir testen Vorseriengeräte unter Laborbedingungen. Alle Ergebnisse werden neutral
                erfasst und veröffentlicht – inklusive klarer Markierungen für bereitgestellte Muster.
              </p>
            </article>
            <article>
              <h3>Launch-Begleitung</h3>
              <p>
                Kombiniere Labordaten mit Storytelling, Event-Livestreams und Fokusgruppen. Wir
                liefern Medien-Kits und Moderation.
              </p>
            </article>
            <article>
              <h3>Community-Dialog</h3>
              <p>
                Nimm an Q&amp;A-Sessions teil, beantworte Fragen unserer Mitglieder und sammle
                strukturiertes Feedback für die Produktentwicklung.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.contactCard}>
            <h2>Kontakt für Hersteller &amp; PR</h2>
            <p>
              Schreibe an <a href="mailto:kontakt@slexorifyx.de">kontakt@slexorifyx.de</a> und teile
              uns Produktdetails, Zeitplan und gewünschte Services mit. Wir melden uns mit einem
              individuellen Vorschlag.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Partner;
```