```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Impressum.module.css';

function Impressum() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Impressum | Slexorifyx</title>
        <meta
          name="description"
          content="Impressum der Slexorifyx Media GmbH mit allen Pflichtangaben."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Impressum</h1>
        </div>
      </header>

      <section className={styles.content}>
        <div className="container">
          <p>
            <strong>Slexorifyx Media GmbH</strong>
            <br />
            Friedrichstraße 68
            <br />
            10117 Berlin
            <br />
            Deutschland
          </p>

          <p>
            Vertreten durch die Geschäftsführung: Lea König, Martin Weber
            <br />
            Telefon: <a href="tel:+493012345678">+49 30 1234 5678</a>
            <br />
            E-Mail: <a href="mailto:kontakt@slexorifyx.de">kontakt@slexorifyx.de</a>
          </p>

          <p>
            Registergericht: Amtsgericht Charlottenburg
            <br />
            HRB 123456
            <br />
            Umsatzsteuer-ID: DE123456789
          </p>

          <p>
            Verantwortlich für journalistisch-redaktionelle Inhalte gemäß § 55 Abs. 2 RStV:
            <br />
            Lea König, Friedrichstraße 68, 10117 Berlin
          </p>

          <p>
            Haftungshinweis: Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung
            für externe Links. Für den Inhalt verlinkter Seiten sind ausschließlich deren Betreiber
            verantwortlich.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Impressum;
```