```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Labor-Reviews',
    description:
      'Von Imaging über Audio bis Performance: Wir liefern datenbasierte Testreihen inklusive Scorecards, Diagrammen und Handlungsempfehlungen.',
    features: ['Standardisierte Protokolle', 'Peer-Review-Prozess', 'Storytelling mit Daten'],
    icon: '🔬'
  },
  {
    title: 'Vergleichsplattform',
    description:
      'Vergleiche Geräte über Kennzahlen, Diagramme und Anwendungsszenarien hinweg. Perfekt für Einkauf, Redaktion und Produktstrategie.',
    features: ['Konfigurierbare Metriken', 'Export als PDF & CSV', 'Community-Kommentare'],
    icon: '📊'
  },
  {
    title: 'Early-Access-Programme',
    description:
      'Wir koordinieren Beta-Feedback, moderieren Fokusgruppen und sammeln strukturierte Insights aus der Community.',
    features: ['Curated Panels', 'Live-Workshops', 'Feedback-Synthese'],
    icon: '🚀'
  }
];

const workflow = [
  {
    step: 'Analyse & Kick-off',
    detail: 'Gemeinsames Verständnis für Zielgruppen, Use-Cases und Messschwerpunkte herstellen.',
    duration: 'Woche 1'
  },
  {
    step: 'Labordesign & Setup',
    detail: 'Messprotokolle anpassen, Hardware konfigurieren, Datenpipelines einrichten.',
    duration: 'Woche 2'
  },
  {
    step: 'Messung & Review',
    detail: 'Testläufe durchführen, Daten prüfen, Ergebnisse interpretieren und Review verfassen.',
    duration: 'Woche 3'
  },
  {
    step: 'Community & Iteration',
    detail: 'Feedback-Runden moderieren, Nachtests planen, Verbesserungen dokumentieren.',
    duration: 'ab Woche 4'
  }
];

function Services() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | Slexorifyx</title>
        <meta
          name="description"
          content="Entdecke die Services von Slexorifyx: Labor-Reviews, Vergleichsplattform und Early-Access-Programme."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <h1>Services für Produktteams, Medien und Innovatorinnen.</h1>
          <p>
            Vom ersten Konzept bis zum Marktstart begleitet Slexorifyx mit Tests, Datenvisualisierungen
            und Community-getriebenem Feedback. Unsere Services sind modular kombinierbar.
          </p>
        </div>
      </header>

      <section className={styles.cards} aria-labelledby="services-heading">
        <div className="container">
          <h2 id="services-heading">Was wir anbieten</h2>
          <div className={styles.cardGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <div className={styles.cardIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <ul>
                  {service.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.workflow} aria-labelledby="workflow-heading">
        <div className="container">
          <h2 id="workflow-heading">Unser Workflow</h2>
          <div className={styles.workflowGrid}>
            {workflow.map((item, index) => (
              <div key={item.step} className={styles.workflowCard}>
                <span className={styles.workflowNumber}>{index + 1}</span>
                <div>
                  <h3>{item.step}</h3>
                  <p>{item.detail}</p>
                  <span className={styles.workflowDuration}>{item.duration}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits} aria-labelledby="benefits-heading">
        <div className="container">
          <h2 id="benefits-heading">Warum Slexorifyx?</h2>
          <div className={styles.benefitGrid}>
            <article>
              <h3>End-to-End-Transparenz</h3>
              <p>
                Von der Testplanung bis zum veröffentlichten Review bleibt jeder Schritt sichtbar.
                Wir dokumentieren sämtliche Parameter und teilen Rohdaten auf Anfrage.
              </p>
            </article>
            <article>
              <h3>Community-Insights</h3>
              <p>
                Unsere Early-Access-Mitglieder liefern Kontext und Anwendungsbeispiele, die wir mit
                Labordaten verknüpfen. So entstehen Entscheidungen, die belastbar sind.
              </p>
            </article>
            <article>
              <h3>Moderne Visualisierung</h3>
              <p>
                Messwerte werden zu klaren Stories: interaktive Diagramme, Vergleiche, Storyboards
                für Präsentationen und Produktpitches.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.contactCard}>
            <h2>Neugierig geworden?</h2>
            <p>
              Lass uns dein Projekt besprechen. Wir definieren gemeinsam, welche Testreihen, Reports
              und Community-Formate zu deinen Zielen passen.
            </p>
            <a className={styles.contactButton} href="mailto:kontakt@slexorifyx.de">
              Mail an kontakt@slexorifyx.de
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Services;
```