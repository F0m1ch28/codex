```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './EarlyAccess.module.css';

function EarlyAccess() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    confirmEmail: '',
    company: '',
    consent: false
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (formData.name.trim().length < 2) {
      newErrors.name = 'Bitte gib einen Namen an.';
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(formData.email)) {
      newErrors.email = 'Bitte eine gültige E-Mail-Adresse eintragen.';
    }
    if (formData.email !== formData.confirmEmail) {
      newErrors.confirmEmail = 'Die E-Mail-Adressen stimmen nicht überein.';
    }
    if (!formData.consent) {
      newErrors.consent = 'Bitte bestätige den Double-Opt-In-Hinweis.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);

    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
    }
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Early Access | Slexorifyx</title>
        <meta
          name="description"
          content="Sichere dir Zugang zu unseren Early-Access-Programmen. Teile Produktfeedback, nimm an Fokusgruppen teil und begleite Labortests."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <span className={styles.badge}>Early Access</span>
          <h1>Gestalte die nächste Testreihe mit.</h1>
          <p>
            Unsere Early-Access-Community begleitet Produkte vom ersten Engineering Sample bis zum
            Marktstart. Du bekommst exklusive Einblicke in Labordaten, kannst an Fokusgruppen
            teilnehmen und Prioritäten setzen.
          </p>
        </div>
      </header>

      <section className={styles.benefits} aria-labelledby="benefits-heading">
        <div className="container">
          <h2 id="benefits-heading">Deine Vorteile</h2>
          <div className={styles.benefitGrid}>
            <article>
              <h3>Beta-Feedback &amp; Workshops</h3>
              <p>
                Nimm an moderierten Sessions teil, diskutiere deine Anforderungen mit unserem Team
                und erhalte Antworten direkt aus dem Labor.
              </p>
            </article>
            <article>
              <h3>Live-Dashboards</h3>
              <p>
                Beobachte Messreihen in Echtzeit und kommentiere Datenpunkte, die für deine
                Anwendung kritisch sind.
              </p>
            </article>
            <article>
              <h3>Priorisierter Zugang</h3>
              <p>
                Erhalte Updates zu Testplänen, Release-Terminen und Community-Votings – inklusive
                persönlicher Briefings.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.formSection} aria-labelledby="form-heading">
        <div className="container">
          <div className={styles.formWrapper}>
            <div>
              <h2 id="form-heading">Jetzt für Early Access anmelden</h2>
              <p>
                Nach deiner Anfrage senden wir dir eine Bestätigungs-Mail. Erst wenn du diesen
                Double-Opt-In bestätigst, ist dein Platz gesichert.
              </p>
            </div>
            {submitted ? (
              <div className={styles.success}>
                <h3>Danke für dein Interesse!</h3>
                <p>
                  Bitte prüfe deine E-Mails und bestätige den Double-Opt-In-Link. Wir melden uns
                  anschließend mit weiteren Details.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                <div className={styles.formGrid}>
                  <label>
                    <span>Vollständiger Name *</span>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      aria-invalid={Boolean(errors.name)}
                    />
                    {errors.name && <span className={styles.error}>{errors.name}</span>}
                  </label>
                  <label>
                    <span>E-Mail *</span>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      aria-invalid={Boolean(errors.email)}
                    />
                    {errors.email && <span className={styles.error}>{errors.email}</span>}
                  </label>
                  <label>
                    <span>E-Mail bestätigen *</span>
                    <input
                      type="email"
                      name="confirmEmail"
                      value={formData.confirmEmail}
                      onChange={handleChange}
                      aria-invalid={Boolean(errors.confirmEmail)}
                    />
                    {errors.confirmEmail && <span className={styles.error}>{errors.confirmEmail}</span>}
                  </label>
                  <label>
                    <span>Unternehmen / Projekt (optional)</span>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                    />
                  </label>
                </div>
                <label className={styles.checkbox}>
                  <input
                    type="checkbox"
                    name="consent"
                    checked={formData.consent}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.consent)}
                  />
                  <span>
                    Ich möchte an Early-Access-Informationen teilnehmen und akzeptiere, dass meine
                    Daten für den Double-Opt-In genutzt werden.
                  </span>
                </label>
                {errors.consent && <span className={styles.error}>{errors.consent}</span>}
                <button type="submit" className={styles.submit}>
                  Anfrage senden
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

export default EarlyAccess;
```