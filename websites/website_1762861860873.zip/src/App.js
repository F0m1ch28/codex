```javascript
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Tests from './pages/Tests';
import EarlyAccess from './pages/EarlyAccess';
import Methodik from './pages/Methodik';
import Vergleiche from './pages/Vergleiche';
import Blog from './pages/Blog';
import Partner from './pages/Partner';
import Kontakt from './pages/Kontakt';
import FAQ from './pages/FAQ';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Impressum from './pages/Impressum';

function App() {
  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Slexorifyx – Deutsche Technologiemediaplattform</title>
        <meta
          name="description"
          content="Slexorifyx verbindet präzise Labormessungen, fundierte Reviews und eine engagierte Early-Access-Community für Technikbegeisterte."
        />
      </Helmet>
      <Header />
      <main id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/tests" element={<Tests />} />
          <Route path="/early-access" element={<EarlyAccess />} />
          <Route path="/methodik" element={<Methodik />} />
          <Route path="/vergleiche" element={<Vergleiche />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/partner" element={<Partner />} />
          <Route path="/kontakt" element={<Kontakt />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/agb" element={<Terms />} />
          <Route path="/terms" element={<Navigate to="/agb" replace />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/privacy" element={<Navigate to="/datenschutz" replace />} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </>
  );
}

export default App;
```