```javascript
import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Home' },
  { path: '/ueber-uns', label: 'Über Uns' },
  { path: '/services', label: 'Services' },
  { path: '/tests', label: 'Tests' },
  { path: '/early-access', label: 'Early Access' },
  { path: '/blog', label: 'Blog' },
  { path: '/kontakt', label: 'Kontakt' }
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        <Link to="/" className={styles.brand} aria-label="Slexorifyx Startseite">
          <span className={styles.logo}>Slexorifyx</span>
          <span className={styles.tagline}>Tech Media &amp; Early Access</span>
        </Link>
        <nav className={styles.nav} aria-label="Hauptnavigation">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <Link to="/early-access" className={styles.cta}>
          Jetzt Early Access
        </Link>
        <button
          type="button"
          className={`${styles.menuButton} ${menuOpen ? styles.menuButtonOpen : ''}`}
          aria-label="Hauptnavigation umschalten"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span aria-hidden="true" />
          <span aria-hidden="true" />
          <span aria-hidden="true" />
        </button>
      </div>
      <nav
        className={`${styles.mobileNav} ${menuOpen ? styles.mobileNavOpen : ''}`}
        aria-label="Mobile Navigation"
      >
        <ul className={styles.mobileList}>
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `${styles.mobileLink} ${isActive ? styles.mobileActive : ''}`
                }
              >
                {item.label}
              </NavLink>
            </li>
          ))}
          <li>
            <Link to="/partner" className={styles.mobileLink}>
              Partner
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
```