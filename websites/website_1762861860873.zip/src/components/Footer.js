```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Fußbereich">
      <div className={styles.inner}>
        <div className={styles.about}>
          <span className={styles.logo}>Slexorifyx</span>
          <p>
            Slexorifyx liefert präzise Laboranalysen, tiefgehende Reviews und eine engagierte
            Community für alle, die Technik frühzeitig verstehen möchten.
          </p>
          <div className={styles.contact}>
            <span>Friedrichstraße 68, 10117 Berlin, Deutschland</span>
            <a href="tel:+493012345678">+49 30 1234 5678</a>
            <a href="mailto:kontakt@slexorifyx.de">kontakt@slexorifyx.de</a>
          </div>
        </div>
        <div className={styles.columns}>
          <div className={styles.column}>
            <h3>Navigation</h3>
            <ul>
              <li>
                <Link to="/">Start</Link>
              </li>
              <li>
                <Link to="/ueber-uns">Über Uns</Link>
              </li>
              <li>
                <Link to="/tests">Tests</Link>
              </li>
              <li>
                <Link to="/vergleiche">Vergleiche</Link>
              </li>
              <li>
                <Link to="/early-access">Early Access</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3>Ressourcen</h3>
            <ul>
              <li>
                <Link to="/methodik">Testmethodik</Link>
              </li>
              <li>
                <Link to="/blog">Blog</Link>
              </li>
              <li>
                <Link to="/faq">FAQ</Link>
              </li>
              <li>
                <Link to="/partner">Partner</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3>Rechtliches</h3>
            <ul>
              <li>
                <Link to="/agb">AGB</Link>
              </li>
              <li>
                <Link to="/datenschutz">Datenschutz</Link>
              </li>
              <li>
                <Link to="/impressum">Impressum</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Slexorifyx. Alle Rechte vorbehalten.</span>
      </div>
    </footer>
  );
}

export default Footer;
```