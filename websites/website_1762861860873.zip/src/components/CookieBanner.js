```javascript
import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('slexorifyx-cookie-consent');
    if (!consent) {
      const timer = window.setTimeout(() => setVisible(true), 1200);
      return () => window.clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem('slexorifyx-cookie-consent', value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h2>Cookies &amp; Analyse</h2>
        <p>
          Wir verwenden funktionale Cookies und anonymisierte Analysen, um die Nutzung unserer
          Inhalte besser zu verstehen. Sie können Ihre Entscheidung jederzeit anpassen.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleConsent('declined')} className={styles.secondary}>
            Ablehnen
          </button>
          <button type="button" onClick={() => handleConsent('accepted')} className={styles.primary}>
            Akzeptieren
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;
```