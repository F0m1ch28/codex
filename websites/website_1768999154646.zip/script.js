document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("primary-navigation");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      nav.classList.toggle("open");
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute("aria-expanded", "false");
          nav.classList.remove("open");
        }
      });
    });
  }

  const redirectMap = {
    "/history": "/field-notes.html",
    "/history/": "/field-notes.html",
    "/infrastructure": "/systems.html",
    "/infrastructure/": "/systems.html",
    "/resilience": "/analysis.html",
    "/resilience/": "/analysis.html",
    "/technology": "/monitoring.html",
    "/technology/": "/monitoring.html"
  };

  const currentPath = window.location.pathname.replace(/index\.html$/, "").replace(/\/+$/, "").toLowerCase();
  if (redirectMap[currentPath]) {
    window.location.replace(redirectMap[currentPath]);
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("#cookie-accept");
    const declineBtn = cookieBanner.querySelector("#cookie-decline");
    const storedConsent = localStorage.getItem("cansystechCookieConsent");
    if (!storedConsent) {
      setTimeout(() => cookieBanner.classList.add("show"), 800);
    }

    const registerChoice = (value) => {
      localStorage.setItem("cansystechCookieConsent", value);
      cookieBanner.classList.remove("show");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => registerChoice("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => registerChoice("declined"));
    }
  }
});