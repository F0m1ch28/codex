document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.getElementById('primary-navigation');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('is-open');
      document.body.classList.toggle('nav-open');
    });

    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768 && navLinks.classList.contains('is-open')) {
          navLinks.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
          document.body.classList.remove('nav-open');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const savedConsent = localStorage.getItem('cookieConsent');
    if (savedConsent) {
      cookieBanner.classList.add('is-hidden');
    }

    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');

    const closeBanner = (value) => {
      localStorage.setItem('cookieConsent', value);
      cookieBanner.classList.add('is-hidden');
      cookieBanner.setAttribute('aria-hidden', 'true');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => closeBanner('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => closeBanner('declined'));
    }
  }
});