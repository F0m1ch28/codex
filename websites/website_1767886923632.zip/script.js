document.addEventListener("DOMContentLoaded", function () {
    var banner = document.getElementById("cookie-banner");
    if (!banner) {
        return;
    }
    var storedPreference = localStorage.getItem("amenorkbgfCookiePreference");
    if (storedPreference) {
        banner.classList.add("hidden");
    }
    var buttons = banner.querySelectorAll(".cookie-button");
    buttons.forEach(function (button) {
        button.addEventListener("click", function () {
            var preference = button.dataset.preference || "unknown";
            localStorage.setItem("amenorkbgfCookiePreference", preference);
            banner.classList.add("hidden");
            var target = button.dataset.target;
            if (target) {
                window.location.href = target;
            }
        });
    });
});