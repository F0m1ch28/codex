import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | TechSolutions</title>
        <meta
          name="description"
          content="Understand how TechSolutions uses cookies and similar technologies to enhance your experience and analyze website performance."
        />
      </Helmet>
      <section className={styles.policy}>
        <div className="layout">
          <h1>Cookie Policy</h1>
          <p className={styles.updated}>Effective date: January 1, 2024</p>

          <h2>What are cookies?</h2>
          <p>
            Cookies are small text files stored on your device by a web browser. They help us recognize returning visitors, remember preferences, and improve overall site performance.
          </p>

          <h2>Types of cookies we use</h2>
          <ul>
            <li><strong>Essential cookies:</strong> Required for core functionality, such as security and accessibility.</li>
            <li><strong>Analytics cookies:</strong> Help us understand how visitors interact with our pages so we can enhance usability.</li>
            <li><strong>Preference cookies:</strong> Remember your settings, such as language or consent choices.</li>
          </ul>

          <h2>Third-party cookies</h2>
          <p>
            We may utilize third-party analytics services that place their own cookies to evaluate usage patterns. These third parties are subject to their own privacy policies.
          </p>

          <h2>Managing cookies</h2>
          <p>
            You can manage or disable cookies through your browser settings. Note that blocking essential cookies may affect the functionality of our website.
          </p>

          <h2>Updates</h2>
          <p>
            We may update this Cookie Policy periodically to reflect changes in technology or applicable regulations. We encourage you to review this policy regularly.
          </p>

          <h2>Contact</h2>
          <p>
            For questions about our use of cookies, email us at <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;