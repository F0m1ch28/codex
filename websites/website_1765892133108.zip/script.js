document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      const isOpen = siteNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
    siteNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (siteNav.classList.contains('open')) {
          siteNav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const consentKey = 'ng-cookie-consent';
    const storedConsent = localStorage.getItem(consentKey);
    if (storedConsent) {
      cookieBanner.classList.add('is-hidden');
    }
    cookieBanner.querySelectorAll('[data-consent]').forEach(function (button) {
      button.addEventListener('click', function () {
        const choice = button.getAttribute('data-consent');
        localStorage.setItem(consentKey, choice);
        cookieBanner.classList.add('is-hidden');
      });
    });
  }
});