<?php
  $submittedName = isset($_POST['name']) ? htmlspecialchars($_POST['name']) : "Client";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You | Northern Grid Energy Canada</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Thank you for contacting Northern Grid Energy Canada. Our team will respond shortly regarding your renewable monitoring inquiry.">
  <meta property="og:title" content="Thank You">
  <meta property="og:description" content="Northern Grid Energy Canada received your request. We will reach out with tailored guidance.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.northerngridenergy.ca/thanks.php">
  <meta property="og:image" content="https://picsum.photos/seed/thanks-grid/1200/630">
  <link rel="canonical" href="https://www.northerngridenergy.ca/thanks.php">
  <link rel="icon" type="image/png" href="favicon.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to main content</a>
  <header class="site-header">
    <div class="container">
      <div class="branding">
        <div class="logo-mark">NG</div>
        <span class="logo-text">Northern Grid Energy Canada</span>
      </div>
      <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">
        ☰
      </button>
      <nav class="site-nav" aria-label="Primary navigation">
        <ul class="nav-list">
          <li><a href="index.html" class="nav-link">Home</a></li>
          <li><a href="about.html" class="nav-link">About</a></li>
          <li><a href="solutions.html" class="nav-link">Solutions</a></li>
          <li><a href="technology.html" class="nav-link">Technology</a></li>
          <li><a href="performance.html" class="nav-link">Performance</a></li>
          <li><a href="projects.html" class="nav-link">Projects</a></li>
          <li><a href="contact.php" class="nav-link">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main id="main-content">
    <section class="page-hero">
      <div class="container">
        <span class="section-label">Thank You</span>
        <h1 class="section-title">We Received Your Request</h1>
        <p class="section-subtitle"><?php echo $submittedName; ?>, thank you for reaching out to Northern Grid Energy Canada. Our engineers will review your message and respond within one business day.</p>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="cta-banner">
          <h2>Next Steps</h2>
          <p>Prepare recent performance reports, site layouts, or SCADA exports that you would like to discuss. We will coordinate a discovery session to align monitoring enhancements with your operational objectives.</p>
          <div class="hero-actions" style="justify-content: center;">
            <a class="btn btn-primary" href="index.html">Return to Homepage</a>
            <a class="btn btn-secondary" href="solutions.html">Review Our Solutions</a>
          </div>
        </div>
      </div>
    </section>
  </main>
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="branding">
            <div class="logo-mark">NG</div>
            <span class="logo-text">Northern Grid Energy Canada</span>
          </div>
          <p>Engineering resilient monitoring, control, and analytics platforms tailored to Canada’s renewable future.</p>
          <a class="btn btn-primary" href="contact.php">Talk to Our Engineers</a>
        </div>
        <div class="footer-links">
          <h4>Navigate</h4>
          <ul class="footer-nav">
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="solutions.html">Solutions</a></li>
            <li><a href="technology.html">Technology</a></li>
            <li><a href="performance.html">Performance</a></li>
            <li><a href="projects.html">Projects</a></li>
            <li><a href="privacy.html">Privacy</a></li>
            <li><a href="cookies.html">Cookies</a></li>
            <li><a href="terms.html">Terms</a></li>
          </ul>
        </div>
        <div class="footer-contact">
          <h4>Contact</h4>
          <address>
            <span>1200 Frontier Trail</span>
            <span>Calgary, Alberta T2P 1G1</span>
            <a href="tel:+14035550198">+1 (403) 555-0198</a>
            <a href="mailto:info@northerngridenergy.ca">info@northerngridenergy.ca</a>
          </address>
          <div class="operating-hours">
            <strong>Operations Centre</strong><br>
            Monday to Friday, 07:00 – 18:00 MT
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        © <span id="current-year">2024</span> Northern Grid Energy Canada. All rights reserved.
      </div>
    </div>
  </footer>
  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie Consent">
    <p>We use cookies to tailor monitoring dashboards, understand platform usage, and enhance secure access. Review details in our <a href="cookies.html">Cookies Policy</a>.</p>
    <div class="cookie-actions">
      <button class="btn btn-primary" type="button" data-consent="accepted">Accept</button>
      <button class="btn btn-ghost" type="button" data-consent="declined">Decline</button>
    </div>
  </div>
</body>
</html>