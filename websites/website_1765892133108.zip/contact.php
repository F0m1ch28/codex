<?php
  $pageTitle = "Contact Northern Grid Energy Canada";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo $pageTitle; ?> | Request Energy Evaluation</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Contact Northern Grid Energy Canada to request an energy evaluation, discuss monitoring solutions, or reach our Calgary operations centre.">
  <meta property="og:title" content="Contact Northern Grid Energy Canada">
  <meta property="og:description" content="Reach our engineering team to plan monitoring, analytics, and remote control for renewable assets across Canada.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.northerngridenergy.ca/contact.php">
  <meta property="og:image" content="https://picsum.photos/seed/contact-grid/1200/630">
  <link rel="canonical" href="https://www.northerngridenergy.ca/contact.php">
  <link rel="icon" type="image/png" href="favicon.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": ["LocalBusiness", "EnergyService"],
    "name": "Northern Grid Energy Canada",
    "url": "https://www.northerngridenergy.ca/contact.php",
    "telePhone": "+1-403-555-0198",
    "email": "info@northerngridenergy.ca",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "1200 Frontier Trail",
      "addressLocality": "Calgary",
      "addressRegion": "AB",
      "postalCode": "T2P 1G1",
      "addressCountry": "CA"
    },
    "openingHours": "Mo-Fr 07:00-18:00",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-403-555-0198",
      "contactType": "Customer Support",
      "areaServed": "CA"
    }
  }
  </script>
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to main content</a>
  <header class="site-header">
    <div class="container">
      <div class="branding">
        <div class="logo-mark">NG</div>
        <span class="logo-text">Northern Grid Energy Canada</span>
      </div>
      <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">
        ☰
      </button>
      <nav class="site-nav" aria-label="Primary navigation">
        <ul class="nav-list">
          <li><a href="index.html" class="nav-link">Home</a></li>
          <li><a href="about.html" class="nav-link">About</a></li>
          <li><a href="solutions.html" class="nav-link">Solutions</a></li>
          <li><a href="technology.html" class="nav-link">Technology</a></li>
          <li><a href="performance.html" class="nav-link">Performance</a></li>
          <li><a href="projects.html" class="nav-link">Projects</a></li>
          <li><a href="contact.php" class="nav-link active" aria-current="page">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main id="main-content">
    <section class="page-hero">
      <div class="container">
        <span class="section-label">Connect With Us</span>
        <h1 class="section-title">Request an Energy Evaluation</h1>
        <p class="section-subtitle">Share your monitoring objectives and our engineers will respond with tailored recommendations for your renewable assets.</p>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="contact-layout">
          <div class="contact-form-panel" aria-labelledby="contact-form-title">
            <h2 id="contact-form-title" class="section-title" style="font-size:1.8rem;">Tell Us About Your Project</h2>
            <form action="thanks.php" method="post">
              <div class="field-group">
                <div class="field">
                  <label for="contact-name">Full Name</label>
                  <input type="text" id="contact-name" name="name" required aria-required="true" autocomplete="name">
                </div>
                <div class="field">
                  <label for="contact-email">Business Email</label>
                  <input type="email" id="contact-email" name="email" required aria-required="true" autocomplete="email">
                </div>
                <div class="field">
                  <label for="contact-phone">Phone</label>
                  <input type="tel" id="contact-phone" name="phone" autocomplete="tel">
                </div>
                <div class="field">
                  <label for="contact-organization">Organization</label>
                  <input type="text" id="contact-organization" name="organization" autocomplete="organization">
                </div>
                <div class="field">
                  <label for="contact-service">Area of Interest</label>
                  <select id="contact-service" name="service">
                    <option value="">Select</option>
                    <option value="monitoring">Advanced Monitoring</option>
                    <option value="analytics">Analytics &amp; Forecasting</option>
                    <option value="maintenance">Predictive Maintenance</option>
                    <option value="hybrid">Hybrid Grid Supervision</option>
                    <option value="cyber">Cybersecurity Assessment</option>
                  </select>
                </div>
                <div class="field">
                  <label for="contact-message">Project Overview</label>
                  <textarea id="contact-message" name="message" required aria-required="true" placeholder="Describe your renewable assets, timelines, and objectives."></textarea>
                </div>
              </div>
              <button class="btn btn-primary" type="submit">Submit Inquiry</button>
              <p class="form-note">Northern Grid Energy Canada respects your privacy. See our <a href="privacy.html">privacy policy</a> for details.</p>
            </form>
          </div>
          <div class="contact-info-panel">
            <h3>Operations Centre</h3>
            <div class="contact-details">
              <div>
                <strong>Address</strong><br>
                1200 Frontier Trail<br>
                Calgary, Alberta T2P 1G1
              </div>
              <div>
                <strong>Phone</strong><br>
                <a href="tel:+14035550198">+1 (403) 555-0198</a>
              </div>
              <div>
                <strong>Email</strong><br>
                <a href="mailto:info@northerngridenergy.ca">info@northerngridenergy.ca</a>
              </div>
            </div>
            <div class="operating-hours">
              <strong>Hours</strong><br>
              Monday – Friday: 07:00 – 18:00 MT<br>
              On-call monitoring support available 24/7
            </div>
            <div style="margin-top:1.75rem;">
              <iframe class="map-embed" title="Northern Grid Energy Canada location" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2524.6779084868285!2d-114.0719!3d51.0447!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTHCsDAyJzQwLjkiTiAxMTTCsDA0JzE4LjkiVw!5e0!3m2!1sen!2sca!4v1700000000000" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section alt">
      <div class="container">
        <div class="cta-banner">
          <h2>Need Immediate Assistance?</h2>
          <p>Our monitoring specialists are available to support urgent operational requirements for existing clients across Canada.</p>
          <a class="btn btn-secondary" href="tel:+14035550198">Call the Operations Desk</a>
        </div>
      </div>
    </section>
  </main>
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="branding">
            <div class="logo-mark">NG</div>
            <span class="logo-text">Northern Grid Energy Canada</span>
          </div>
          <p>Engineering resilient monitoring, control, and analytics platforms tailored to Canada’s renewable future.</p>
          <a class="btn btn-primary" href="contact.php">Talk to Our Engineers</a>
        </div>
        <div class="footer-links">
          <h4>Navigate</h4>
          <ul class="footer-nav">
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="solutions.html">Solutions</a></li>
            <li><a href="technology.html">Technology</a></li>
            <li><a href="performance.html">Performance</a></li>
            <li><a href="projects.html">Projects</a></li>
            <li><a href="privacy.html">Privacy</a></li>
            <li><a href="cookies.html">Cookies</a></li>
            <li><a href="terms.html">Terms</a></li>
          </ul>
        </div>
        <div class="footer-contact">
          <h4>Contact</h4>
          <address>
            <span>1200 Frontier Trail</span>
            <span>Calgary, Alberta T2P 1G1</span>
            <a href="tel:+14035550198">+1 (403) 555-0198</a>
            <a href="mailto:info@northerngridenergy.ca">info@northerngridenergy.ca</a>
          </address>
          <div class="operating-hours">
            <strong>Operations Centre</strong><br>
            Monday to Friday, 07:00 – 18:00 MT
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        © <span id="current-year">2024</span> Northern Grid Energy Canada. All rights reserved.
      </div>
    </div>
  </footer>
  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie Consent">
    <p>We use cookies to tailor monitoring dashboards, understand platform usage, and enhance secure access. Review details in our <a href="cookies.html">Cookies Policy</a>.</p>
    <div class="cookie-actions">
      <button class="btn btn-primary" type="button" data-consent="accepted">Accept</button>
      <button class="btn btn-ghost" type="button" data-consent="declined">Decline</button>
    </div>
  </div>
</body>
</html>