(function () {
  const banner = document.querySelector('[data-cookie-banner]');
  if (!banner) return;

  const acceptBtn = banner.querySelector('[data-accept]');
  const declineBtn = banner.querySelector('[data-decline]');
  const storageKey = 'mta_cookie_consent';

  const hideBanner = () => {
    banner.classList.remove('is-visible');
    const removeBanner = () => banner.setAttribute('hidden', '');
    banner.addEventListener('transitionend', removeBanner, { once: true });
  };

  const showBanner = () => {
    banner.removeAttribute('hidden');
    requestAnimationFrame(() => banner.classList.add('is-visible'));
  };

  const savedPreference = localStorage.getItem(storageKey);
  if (!savedPreference) {
    showBanner();
  }

  const handleChoice = (choice) => {
    localStorage.setItem(storageKey, choice);
    hideBanner();
  };

  acceptBtn.addEventListener('click', () => handleChoice('accepted'));
  declineBtn.addEventListener('click', () => handleChoice('declined'));
})();