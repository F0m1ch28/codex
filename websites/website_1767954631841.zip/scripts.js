document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".mobile-toggle");
    const mainNav = document.querySelector(".main-nav");

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            mainNav.classList.toggle("open");
        });

        mainNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                mainNav.classList.remove("open");
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedConsent = localStorage.getItem("parliargwfCookieConsent");
        if (!storedConsent) {
            cookieBanner.classList.add("visible");
        }

        cookieBanner.querySelectorAll(".cookie-btn").forEach(button => {
            button.addEventListener("click", event => {
                event.preventDefault();
                const decision = button.dataset.decision || "undecided";
                localStorage.setItem("parliargwfCookieConsent", decision);
                cookieBanner.classList.remove("visible");
            });
        });
    }
});