document.addEventListener('DOMContentLoaded', function () {
    var banner = document.getElementById('cookie-banner');
    var consentKey = 'otaheituqfCookieConsent';

    if (banner) {
        if (!localStorage.getItem(consentKey)) {
            banner.classList.add('is-visible');
        }

        var acceptBtn = banner.querySelector('.cookie-accept');
        var declineBtn = banner.querySelector('.cookie-decline');

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function (event) {
                event.preventDefault();
                localStorage.setItem(consentKey, 'accepted');
                banner.classList.remove('is-visible');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function (event) {
                event.preventDefault();
                localStorage.setItem(consentKey, 'declined');
                banner.classList.remove('is-visible');
            });
        }
    }

    var moduleButtons = document.querySelectorAll('.module-toggle');
    moduleButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var selector = button.getAttribute('data-target');
            if (!selector) return;
            var target = document.querySelector(selector);
            if (!target) return;

            target.classList.toggle('is-visible');

            if (target.classList.contains('is-visible')) {
                button.textContent = 'Hide Module Outline';
            } else {
                button.textContent = 'Preview Module';
            }
        });
    });
});