(function () {
    document.addEventListener('DOMContentLoaded', function () {
        var navToggle = document.querySelector('.nav-toggle');
        var siteNav = document.querySelector('.site-nav');
        if (navToggle && siteNav) {
            navToggle.addEventListener('click', function () {
                var expanded = navToggle.getAttribute('aria-expanded') === 'true';
                navToggle.setAttribute('aria-expanded', String(!expanded));
                siteNav.classList.toggle('is-open');
            });
        }

        var yearTargets = document.querySelectorAll('[data-year]');
        yearTargets.forEach(function (node) {
            node.textContent = new Date().getFullYear();
        });

        var countdownElement = document.querySelector('[data-countdown]');
        if (countdownElement) {
            var updateCountdown = function () {
                var now = new Date();
                var currentYear = now.getFullYear();
                var target = new Date(currentYear, 11, 25, 0, 0, 0);
                if (now > target) {
                    target = new Date(currentYear + 1, 11, 25, 0, 0, 0);
                }
                var diff = target - now;
                var seconds = Math.floor(diff / 1000);
                var days = Math.floor(seconds / (3600 * 24));
                seconds -= days * 3600 * 24;
                var hours = Math.floor(seconds / 3600);
                seconds -= hours * 3600;
                var minutes = Math.floor(seconds / 60);
                seconds -= minutes * 60;

                var setText = function (selector, value, label) {
                    var el = countdownElement.querySelector(selector);
                    if (el) {
                        el.textContent = value + ' ' + label;
                    }
                };
                setText('[data-days]', days, 'days');
                setText('[data-hours]', hours, 'hours');
                setText('[data-minutes]', minutes, 'minutes');
                setText('[data-seconds]', seconds, 'seconds');
            };
            updateCountdown();
            setInterval(updateCountdown, 1000);
        }

        var cookieBanner = document.querySelector('.cookie-banner');
        var acceptBtn = document.querySelector('[data-cookie-accept]');
        var declineBtn = document.querySelector('[data-cookie-decline]');
        var storageKey = 'aurora_cookie_consent';

        var showBanner = function () {
            if (cookieBanner) {
                cookieBanner.classList.add('is-visible');
            }
        };
        var hideBanner = function () {
            if (cookieBanner) {
                cookieBanner.classList.remove('is-visible');
            }
        };

        var storedConsent = localStorage.getItem(storageKey);
        if (!storedConsent) {
            showBanner();
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                localStorage.setItem(storageKey, 'accepted');
                hideBanner();
            });
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                localStorage.setItem(storageKey, 'declined');
                hideBanner();
            });
        }

        var builderForm = document.getElementById('builder-form');
        if (builderForm) {
            var selectedList = builderForm.querySelector('[data-selected-items]');
            var totalDisplay = builderForm.querySelector('[data-total]');
            var basePrice = parseFloat(builderForm.getAttribute('data-base-price')) || 0;

            var formatCurrency = function (value) {
                return '$' + value.toFixed(2);
            };

            var calculateTotal = function () {
                var total = basePrice;
                var summaryItems = [];
                summaryItems.push({ label: 'Base Keepsake Experience', price: basePrice });

                var occasionInputs = builderForm.querySelectorAll('input[type="radio"][name="occasion"]');
                occasionInputs.forEach(function (input) {
                    if (input.checked) {
                        var price = parseFloat(input.getAttribute('data-price')) || 0;
                        total += price;
                        if (price > 0) {
                            summaryItems.push({ label: input.value, price: price });
                        } else {
                            summaryItems.push({ label: input.value, price: 0 });
                        }
                    }
                });

                var itemInputs = builderForm.querySelectorAll('input[type="checkbox"][name="items"]:checked');
                itemInputs.forEach(function (input) {
                    var price = parseFloat(input.getAttribute('data-price')) || 0;
                    total += price;
                    summaryItems.push({ label: input.value, price: price });
                });

                var packageSelect = builderForm.querySelector('[data-price-select]');
                if (packageSelect) {
                    var selectedOption = packageSelect.options[packageSelect.selectedIndex];
                    var packageLabel = selectedOption.value;
                    var packagePrice = parseFloat(selectedOption.getAttribute('data-price')) || 0;
                    total += packagePrice;
                    summaryItems.push({ label: packageLabel, price: packagePrice });
                }

                if (selectedList) {
                    selectedList.innerHTML = '';
                    summaryItems.forEach(function (item) {
                        var li = document.createElement('li');
                        var labelSpan = document.createElement('span');
                        labelSpan.textContent = item.label;
                        var priceSpan = document.createElement('span');
                        priceSpan.textContent = formatCurrency(item.price);
                        li.appendChild(labelSpan);
                        li.appendChild(priceSpan);
                        selectedList.appendChild(li);
                    });
                }
                if (totalDisplay) {
                    totalDisplay.textContent = formatCurrency(total);
                }
            };

            builderForm.addEventListener('change', calculateTotal);
            builderForm.addEventListener('submit', function (event) {
                event.preventDefault();
                alert('Thank you! Our gifting concierge will confirm your bespoke box within 12 hours.');
            });
            calculateTotal();
        }
    });
})();