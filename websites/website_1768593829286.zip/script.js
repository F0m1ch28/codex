document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('[data-nav-toggle]');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            primaryNav.classList.toggle('active');
            navToggle.setAttribute('aria-expanded', primaryNav.classList.contains('active'));
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (primaryNav.classList.contains('active')) {
                    primaryNav.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const yearTarget = document.getElementById('current-year');
    if (yearTarget) {
        yearTarget.textContent = new Date().getFullYear();
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('[data-cookie-accept]');
    const declineButton = document.querySelector('[data-cookie-decline]');
    const cookieStatus = localStorage.getItem('vg_cookie_consent');

    if (cookieBanner && acceptButton && declineButton) {
        if (!cookieStatus) {
            cookieBanner.classList.add('active');
        }

        acceptButton.addEventListener('click', () => {
            localStorage.setItem('vg_cookie_consent', 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineButton.addEventListener('click', () => {
            localStorage.setItem('vg_cookie_consent', 'declined');
            cookieBanner.classList.remove('active');
        });
    }

    const layerButtons = document.querySelectorAll('[data-map-layer]');
    const mapOverlays = document.querySelectorAll('.map-overlay');
    if (layerButtons.length && mapOverlays.length) {
        layerButtons.forEach(button => {
            button.addEventListener('click', () => {
                const targetLayer = button.getAttribute('data-map-layer');
                layerButtons.forEach(b => b.classList.remove('active'));
                button.classList.add('active');
                mapOverlays.forEach(overlay => {
                    overlay.classList.toggle('active', overlay.getAttribute('data-map-layer') === targetLayer);
                });
            });
        });
    }

    const timelineButtons = document.querySelectorAll('[data-timeline]');
    const timelineEvents = document.querySelectorAll('[data-timeline-event]');
    if (timelineButtons.length && timelineEvents.length) {
        timelineButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const target = btn.getAttribute('data-timeline');
                timelineButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                timelineEvents.forEach(event => {
                    event.classList.toggle('active', event.getAttribute('data-timeline-event') === target || target === 'all');
                });
            });
        });
    }

    const filterChips = document.querySelectorAll('[data-filter]');
    const filterItems = document.querySelectorAll('[data-filter-item]');
    if (filterChips.length && filterItems.length) {
        filterChips.forEach(chip => {
            chip.addEventListener('click', () => {
                const filter = chip.getAttribute('data-filter');
                filterChips.forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                filterItems.forEach(item => {
                    const itemFilters = item.getAttribute('data-filter-item').split(',');
                    item.dataset.visible = filter === 'all' || itemFilters.includes(filter) ? 'true' : 'false';
                });
            });
        });
    }

    const observers = document.querySelectorAll('[data-observe]');
    if (observers.length) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('observed');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });

        observers.forEach(el => io.observe(el));
    }
});