import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div>
        <h3 className={styles.brand}>TechSolutions</h3>
        <p className={styles.tagline}>
          Strategic IT consulting that accelerates innovation, resilience, and growth.
        </p>
      </div>
      <div>
        <h4 className={styles.heading}>Visit Us</h4>
        <address className={styles.address}>
          123 Tech Avenue<br />
          Innovation District<br />
          San Francisco, CA 94105
        </address>
      </div>
      <div>
        <h4 className={styles.heading}>Connect</h4>
        <ul className={styles.contactList}>
          <li>
            <a href="tel:+15551234567">+1 (555) 123-4567</a>
          </li>
          <li>
            <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
          </li>
        </ul>
      </div>
      <div>
        <h4 className={styles.heading}>Resources</h4>
        <ul className={styles.links}>
          <li>
            <Link to="/services">Services</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/terms">Terms of Use</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <span>© {new Date().getFullYear()} TechSolutions. All rights reserved.</span>
    </div>
  </footer>
);

export default Footer;