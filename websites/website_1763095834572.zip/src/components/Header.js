import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isNavOpen, setIsNavOpen] = React.useState(false);

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 1024) {
        setIsNavOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleNav = () => setIsNavOpen((prev) => !prev);
  const closeNav = () => setIsNavOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo} onClick={closeNav}>
          <span className={styles.logoMark}>Tech</span>Solutions
        </Link>
        <button
          className={styles.mobileToggle}
          onClick={toggleNav}
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${isNavOpen ? styles.open : ''}`}>
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeNav}
            end
          >
            Home
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeNav}
          >
            Services
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeNav}
          >
            About
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeNav}
          >
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;