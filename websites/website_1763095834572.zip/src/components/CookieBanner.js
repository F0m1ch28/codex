import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem('techsolutions_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('techsolutions_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        We use cookies to enhance your browsing experience, analyze site traffic, and support our
        digital services. By continuing, you agree to our{' '}
        <a href="/cookie-policy">Cookie Policy</a>.
      </p>
      <button type="button" onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;