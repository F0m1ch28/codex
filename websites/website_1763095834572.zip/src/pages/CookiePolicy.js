import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | TechSolutions</title>
      <meta
        name="description"
        content="Learn how TechSolutions uses cookies and similar technologies to improve your digital experience."
      />
    </Helmet>
    <h1>Cookie Policy</h1>
    <p>Last updated: January 2024</p>
    <section>
      <h2>What Are Cookies?</h2>
      <p>
        Cookies are small text files stored on your device when you visit a website. They help us
        analyze site usage and deliver a more personalized experience.
      </p>
    </section>
    <section>
      <h2>Types of Cookies We Use</h2>
      <ul>
        <li>
          <strong>Essential cookies:</strong> Required for core functionality such as form
          submissions.
        </li>
        <li>
          <strong>Analytics cookies:</strong> Provide insights into how visitors interact with our
          site.
        </li>
        <li>
          <strong>Preference cookies:</strong> Remember your choices to enhance usability.
        </li>
      </ul>
    </section>
    <section>
      <h2>Managing Cookies</h2>
      <p>
        You can adjust your browser settings to accept or reject cookies. Disabling cookies may
        impact your experience on our site.
      </p>
    </section>
    <section>
      <h2>Contact</h2>
      <p>
        For questions about this policy, please email{' '}
        <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
      </p>
    </section>
  </div>
);

export default CookiePolicy;