import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About TechSolutions</title>
      <meta
        name="description"
        content="Learn about TechSolutions, our mission, leadership, and commitment to delivering transformative IT consulting and cloud solutions."
      />
    </Helmet>

    <section className={styles.hero}>
      <h1>Empowering enterprise transformation since day one</h1>
      <p>
        TechSolutions was founded to help organizations unlock the potential of modern technology
        without compromising security, compliance, or customer trust. Our cross-functional teams
        blend strategy, engineering, and change enablement to deliver measurable outcomes.
      </p>
    </section>

    <section className={styles.story}>
      <div className={styles.storyImage}>
        <img
          src="https://picsum.photos/seed/leadership/620/480"
          alt="TechSolutions leadership discussing strategic roadmap"
        />
      </div>
      <div className={styles.storyContent}>
        <h2>Our story</h2>
        <p>
          With backgrounds in consulting, product development, and enterprise IT, our founders knew
          that successful transformation demands more than technology. It requires resilient
          architectures, empowered teams, and an unwavering commitment to business value.
        </p>
        <p>
          Today, TechSolutions partners with organizations across industries to design and execute
          cloud-native strategies, modernize legacy ecosystems, and cultivate cultures of continuous
          improvement. We prize transparency, co-creation, and sustainable change over quick fixes.
        </p>
        <div className={styles.values}>
          <div>
            <h3>Values we live by</h3>
            <ul>
              <li>Guided by outcomes, driven by data</li>
              <li>Inclusive collaboration across every engagement</li>
              <li>Security and resilience as design principles</li>
              <li>Continuous learning and knowledge sharing</li>
            </ul>
          </div>
          <div>
            <h3>Certified expertise</h3>
            <ul>
              <li>Cloud Solution Architects (AWS, Azure, GCP)</li>
              <li>Certified Kubernetes Administrators</li>
              <li>SAFe Program Consultants & Scrum Masters</li>
              <li>ISO/IEC 27001 practitioners</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.timeline}>
      <h2>Milestones</h2>
      <div className={styles.timelineGrid}>
        <div className={styles.timeCard}>
          <span>2015</span>
          <h3>Founded in San Francisco</h3>
          <p>
            Established with a mission to bridge the gap between strategy and execution in cloud
            initiatives.
          </p>
        </div>
        <div className={styles.timeCard}>
          <span>2018</span>
          <h3>Global Delivery Expansion</h3>
          <p>
            Launched hybrid delivery model combining on-site leadership with global engineering hubs.
          </p>
        </div>
        <div className={styles.timeCard}>
          <span>2020</span>
          <h3>Digital Resilience Framework</h3>
          <p>
            Introduced proprietary framework for digitization, enabling clients to adapt quickly in
            evolving market conditions.
          </p>
        </div>
        <div className={styles.timeCard}>
          <span>2023</span>
          <h3>Sustainability by Design</h3>
          <p>
            Embedded cloud sustainability metrics and practices into every transformation program.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.commitment}>
      <div className={styles.commitmentContent}>
        <h2>Our commitment</h2>
        <p>
          We partner long-term with clients to ensure strategic alignment, effective change
          management, and continuous improvement. Our teams stay engaged beyond go-live to optimize
          operations, share knowledge, and empower internal capabilities.
        </p>
      </div>
    </section>
  </div>
);

export default About;