import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Services | TechSolutions</title>
      <meta
        name="description"
        content="Discover TechSolutions services including cloud strategy, modernization, digital transformation, and managed optimization tailored to enterprise needs."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Services engineered for lasting impact</h1>
      <p>
        We design integrated consulting services that address strategy, architecture, process, and
        change management. Each engagement is grounded in measurable outcomes aligned to your goals.
      </p>
    </section>

    <section className={styles.serviceSection}>
      <article className={styles.card}>
        <h2>Cloud Strategy & Migration</h2>
        <p>
          We evaluate current-state environments, define target architectures, and build pragmatic
          migration roadmaps. Our consultants design landing zones, establish governance, and embed
          security controls to accelerate adoption across AWS, Azure, and Google Cloud.
        </p>
        <ul>
          <li>Cloud readiness assessments and TCO modelling</li>
          <li>Landing zone design and compliance guardrails</li>
          <li>Workload prioritization and migration factory</li>
          <li>FinOps and continuous optimization practices</li>
        </ul>
      </article>

      <article className={styles.card}>
        <h2>Platform Modernization</h2>
        <p>
          Move from monolithic systems to flexible platforms built on microservices, APIs, and
          containerization. We modernize critical applications while maintaining uptime and user
          experience through progressive delivery.
        </p>
        <ul>
          <li>Application portfolio assessment and rationalization</li>
          <li>Microservices and event-driven architecture design</li>
          <li>CI/CD automation and DevSecOps enablement</li>
          <li>Observability, SRE, and performance engineering</li>
        </ul>
      </article>

      <article className={styles.card}>
        <h2>Digital Transformation Advisory</h2>
        <p>
          Align business vision and technology investments through co-created digital strategies.
          Our advisors lead workshops, map value streams, and orchestrate cross-functional delivery
          to unlock new experiences and revenue streams.
        </p>
        <ul>
          <li>Enterprise capability mapping and prioritization</li>
          <li>Experience design and service blueprinting</li>
          <li>Operating model and change enablement</li>
          <li>Data, analytics, and AI acceleration</li>
        </ul>
      </article>

      <article className={styles.card}>
        <h2>Managed Cloud Optimization</h2>
        <p>
          Keep cloud environments secure, compliant, and cost-efficient. Our managed services team
          delivers proactive monitoring, automation, and improvement backlogs aligned to your KPIs.
        </p>
        <ul>
          <li>24/7 monitoring, incident response, and SLO management</li>
          <li>Security posture assessments and remediation</li>
          <li>Lifecycle management and infrastructure as code</li>
          <li>Quarterly value reviews and innovation sprints</li>
        </ul>
      </article>
    </section>

    <section className={styles.approach}>
      <div className={styles.approachContent}>
        <h2>How we work</h2>
        <p>
          Every engagement starts with clarity. We co-create a transformation backlog backed by KPIs
          and success metrics, activate cross-functional squads, and maintain transparent governance
          to ensure continuous value realization.
        </p>
        <div className={styles.steps}>
          <div>
            <span>01</span>
            <h3>Vision & Discovery</h3>
            <p>
              Stakeholder interviews, maturity assessments, and opportunity framing to align
              priorities with outcomes.
            </p>
          </div>
          <div>
            <span>02</span>
            <h3>Design & Mobilize</h3>
            <p>
              Solution architecture, delivery roadmaps, and change plans that mobilize teams with
              confidence.
            </p>
          </div>
          <div>
            <span>03</span>
            <h3>Deliver & Optimize</h3>
            <p>
              Iterative delivery backed by analytics, automation, and governance to scale and
              sustain transformation.
            </p>
          </div>
        </div>
      </div>
      <div className={styles.imageWrapper}>
        <img
          src="https://picsum.photos/seed/approach/640/520"
          alt="Consulting team reviewing agile delivery boards"
        />
      </div>
    </section>
  </div>
);

export default Services;