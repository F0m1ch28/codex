import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>TechSolutions | Cloud Strategy & Digital Transformation</title>
        <meta
          name="description"
          content="TechSolutions helps enterprises modernize with cloud strategy, digital transformation, and managed services tailored to complex ecosystems."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Modernize with Confidence</h1>
          <p>
            TechSolutions guides enterprises through cloud adoption, platform modernization, and
            digital transformation with a focus on security, scalability, and measurable outcomes.
          </p>
          <div className={styles.heroActions}>
            <Link to="/services" className={styles.primaryButton}>
              Explore Services
            </Link>
            <Link to="/contact" className={styles.secondaryButton}>
              Talk to an Expert
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/seed/techcloud/640/480"
            alt="Professional collaborating over cloud architecture diagrams"
            className={styles.heroImage}
          />
        </div>
      </section>

      <section className={styles.trust}>
        <h2>Trusted Cloud & Digital Advisors</h2>
        <p>
          From discovery workshops to continuous optimization, we deliver end-to-end consulting that
          aligns technology investments with business value.
        </p>
        <div className={styles.metricsGrid}>
          <div className={styles.metricCard}>
            <span className={styles.metricValue}>120+</span>
            <span className={styles.metricLabel}>Enterprise Programs</span>
          </div>
          <div className={styles.metricCard}>
            <span className={styles.metricValue}>10+ yrs</span>
            <span className={styles.metricLabel}>Cloud Strategy Expertise</span>
          </div>
          <div className={styles.metricCard}>
            <span className={styles.metricValue}>98%</span>
            <span className={styles.metricLabel}>Client Satisfaction Rate</span>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.servicesIntro}>
          <h2>What We Deliver</h2>
          <p>
            Our consultants combine technical depth with business insight to design future-ready
            solutions for regulated, high-growth, and global organizations.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          <article className={styles.serviceCard}>
            <div className={styles.iconCircle}>☁️</div>
            <h3>Cloud Strategy & Migration</h3>
            <p>
              Build a resilient multi-cloud posture through architecture blueprints, migration
              roadmaps, and governance models tailored to your enterprise.
            </p>
            <Link to="/services">Learn more</Link>
          </article>
          <article className={styles.serviceCard}>
            <div className={styles.iconCircle}>⚙️</div>
            <h3>Platform Modernization</h3>
            <p>
              Transform legacy systems with microservices, container orchestration, and DevOps
              automation that accelerates delivery cycles.
            </p>
            <Link to="/services">Learn more</Link>
          </article>
          <article className={styles.serviceCard}>
            <div className={styles.iconCircle}>🔐</div>
            <h3>Secure Digital Transformation</h3>
            <p>
              Embed cybersecurity, compliance, and data governance in every stage of your digital
              initiative to protect trust and continuity.
            </p>
            <Link to="/services">Learn more</Link>
          </article>
        </div>
      </section>

      <section className={styles.highlights}>
        <div className={styles.highlightImageWrapper}>
          <img
            src="https://picsum.photos/seed/innovation/600/420"
            alt="Digital transformation workshop with leadership team"
          />
        </div>
        <div className={styles.highlightContent}>
          <h2>Accelerate Transformation with Proven Frameworks</h2>
          <p>
            Our engagement model blends strategic planning, change enablement, and agile delivery.
            We work alongside your teams to establish governance, accelerate adoption, and digitize
            core operations without disrupting what keeps your business running today.
          </p>
          <ul className={styles.highlightList}>
            <li>Outcome-driven cloud operating models and FinOps practices</li>
            <li>Experience mapping and process digitization for critical journeys</li>
            <li>Continuous improvement through automation, insights, and AI</li>
          </ul>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Ready to design your next digital milestone?</h2>
          <p>
            Schedule a discovery session to evaluate your cloud maturity, identify quick wins, and
            build a roadmap that fuels sustainable growth.
          </p>
          <Link to="/contact" className={styles.primaryButton}>
            Schedule a Conversation
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;