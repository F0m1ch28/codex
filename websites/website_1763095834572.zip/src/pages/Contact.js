import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: '',
};

const Contact = () => {
  const [formValues, setFormValues] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formValues.email.trim()) {
      newErrors.email = 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formValues.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formValues.message.trim()) newErrors.message = 'Please include a message.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setSubmitted(true);
    setFormValues(initialState);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact TechSolutions</title>
        <meta
          name="description"
          content="Connect with TechSolutions to discuss cloud strategy, modernization, or transformation initiatives. Our experts are ready to help."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Let’s build what’s next, together</h1>
        <p>
          Share your priorities and we’ll connect you with a consultant who can help map the right
          approach for your organization.
        </p>
      </section>

      <section className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Name *</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formValues.name}
              onChange={handleChange}
              placeholder="Your full name"
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Email *</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formValues.email}
              onChange={handleChange}
              placeholder="you@company.com"
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="company">Company</label>
            <input
              id="company"
              name="company"
              type="text"
              value={formValues.company}
              onChange={handleChange}
              placeholder="Organization name"
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="message">How can we help? *</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formValues.message}
              onChange={handleChange}
              placeholder="Tell us about your initiative"
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>

          {submitted && (
            <div className={styles.success}>
              Thank you for reaching out. A consultant will contact you shortly.
            </div>
          )}

          <button type="submit" className={styles.submitButton}>
            Submit
          </button>
        </form>

        <div className={styles.info}>
          <div className={styles.card}>
            <h2>Contact Information</h2>
            <p>
              TechSolutions<br />
              123 Tech Avenue<br />
              Innovation District<br />
              San Francisco, CA 94105
            </p>
            <p>
              Phone: <a href="tel:+15551234567">+1 (555) 123-4567</a>
            </p>
            <p>
              Email: <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
            </p>
          </div>
          <div className={styles.card}>
            <h2>Office Hours</h2>
            <p>Monday – Friday: 8:30 AM – 6:30 PM PT</p>
            <p>Virtual workshops available globally.</p>
          </div>
          <div className={styles.card}>
            <h2>Follow-Up Process</h2>
            <ul>
              <li>Response within one business day</li>
              <li>Discovery session scheduled to align goals</li>
              <li>Tailored proposal and roadmap recommendations</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;