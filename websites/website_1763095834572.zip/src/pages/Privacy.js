import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | TechSolutions</title>
      <meta
        name="description"
        content="Understand how TechSolutions collects, uses, and protects personal information in our Privacy Policy."
      />
    </Helmet>
    <h1>Privacy Policy</h1>
    <p>Last updated: January 2024</p>
    <section>
      <h2>Information We Collect</h2>
      <p>
        We collect information that you voluntarily provide, such as contact details and project
        requirements. We may also collect technical data including IP addresses, browser types, and
        usage patterns through analytics tools.
      </p>
    </section>
    <section>
      <h2>How We Use Information</h2>
      <p>
        Information is used to respond to inquiries, improve our services, and deliver relevant
        insights. We may also use aggregated data for analytics and reporting.
      </p>
    </section>
    <section>
      <h2>Data Sharing</h2>
      <p>
        We do not sell personal data. Information may be shared with trusted service providers who
        assist in operating our website and delivering services, subject to confidentiality
        agreements.
      </p>
    </section>
    <section>
      <h2>Security</h2>
      <p>
        We implement technical and organizational measures to safeguard personal data against
        unauthorized access, alteration, or disclosure.
      </p>
    </section>
    <section>
      <h2>Your Choices</h2>
      <p>
        You may request access, correction, or deletion of your personal information by contacting
        us at <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
      </p>
    </section>
    <section>
      <h2>Updates</h2>
      <p>
        We may update this policy periodically. Continued use of the site constitutes acceptance of
        any changes.
      </p>
    </section>
  </div>
);

export default Privacy;