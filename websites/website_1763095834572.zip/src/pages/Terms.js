import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Use | TechSolutions</title>
      <meta
        name="description"
        content="Review the TechSolutions Terms of Use governing access to our website, services, and digital resources."
      />
    </Helmet>
    <h1>Terms of Use</h1>
    <p>Last updated: January 2024</p>
    <section>
      <h2>Acceptance of Terms</h2>
      <p>
        By accessing or using this website, you acknowledge that you have read, understood, and agree
        to be bound by these Terms of Use and any additional guidelines referenced herein.
      </p>
    </section>
    <section>
      <h2>Use of Content</h2>
      <p>
        Content on this site is provided for informational purposes. You may not reproduce,
        distribute, or create derivative works without prior written consent from TechSolutions.
      </p>
    </section>
    <section>
      <h2>Disclaimers</h2>
      <p>
        Services and capabilities described on this site do not constitute a binding offer. TechSolutions
        provides materials “as-is” and disclaims all warranties to the fullest extent permitted by law.
      </p>
    </section>
    <section>
      <h2>Limitation of Liability</h2>
      <p>
        TechSolutions is not liable for any indirect, incidental, or consequential damages arising from
        your use of this site or reliance on its content.
      </p>
    </section>
    <section>
      <h2>Governing Law</h2>
      <p>
        These Terms are governed by the laws of the State of California. Any disputes will be resolved
        in the courts located within San Francisco County, California.
      </p>
    </section>
    <section>
      <h2>Contact</h2>
      <p>
        Questions about these Terms can be directed to{' '}
        <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
      </p>
    </section>
  </div>
);

export default Terms;