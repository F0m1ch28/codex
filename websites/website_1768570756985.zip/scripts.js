document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelectorAll('.site-nav a');

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const isOpen = body.classList.toggle('nav-open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (body.classList.contains('nav-open')) {
                body.classList.remove('nav-open');
                if (navToggle) {
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            }
        });
    });

    window.addEventListener('resize', () => {
        if (window.innerWidth >= 1024 && body.classList.contains('nav-open')) {
            body.classList.remove('nav-open');
            if (navToggle) {
                navToggle.setAttribute('aria-expanded', 'false');
            }
        }
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('flyingfbviCookieChoice');
        if (storedChoice) {
            cookieBanner.classList.add('is-hidden');
        }
        const cookieButtons = cookieBanner.querySelectorAll('[data-cookie-choice]');
        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.getAttribute('data-cookie-choice');
                localStorage.setItem('flyingfbviCookieChoice', choice);
                cookieBanner.classList.add('is-hidden');
                const href = button.getAttribute('href');
                setTimeout(() => {
                    window.location.href = href;
                }, 150);
            });
        });
        const closeButton = cookieBanner.querySelector('.cookie-close');
        if (closeButton) {
            closeButton.addEventListener('click', () => {
                cookieBanner.classList.add('is-hidden');
            });
        }
    }
});