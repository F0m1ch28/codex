document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.primary-nav');
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const consentKey = 'vientoCookieConsent';

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      body.classList.toggle('nav-open');
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
    });

    nav.addEventListener('click', (event) => {
      if (event.target.closest('a') && body.classList.contains('nav-open')) {
        body.classList.remove('nav-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  window.addEventListener('scroll', () => {
    if (!header) return;
    header.classList.toggle('scrolled', window.scrollY > 20);
  });

  const existingConsent = localStorage.getItem(consentKey);
  if (!existingConsent && cookieBanner) {
    requestAnimationFrame(() => {
      cookieBanner.classList.add('active');
    });
  }

  const handleConsent = (value) => {
    localStorage.setItem(consentKey, value);
    if (cookieBanner) {
      cookieBanner.classList.remove('active');
      cookieBanner.setAttribute('aria-hidden', 'true');
    }
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handleConsent('accepted'));
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => handleConsent('declined'));
  }
});