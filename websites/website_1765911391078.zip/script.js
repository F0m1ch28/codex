(() => {
  const STORAGE_KEYS = {
    cookieConsent: 'yandexGameCookieConsent',
    scores: 'yandexGameScores'
  };

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function showCookieBanner() {
    const banner = document.querySelector('.cookie-banner');
    if (!banner) return;

    const consent = localStorage.getItem(STORAGE_KEYS.cookieConsent);
    if (!consent) {
      requestAnimationFrame(() => banner.classList.add('visible'));
    }

    const acceptBtn = banner.querySelector('[data-cookie-accept]');
    const declineBtn = banner.querySelector('[data-cookie-decline]');

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => {
        localStorage.setItem(STORAGE_KEYS.cookieConsent, 'accepted');
        banner.classList.remove('visible');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', () => {
        localStorage.setItem(STORAGE_KEYS.cookieConsent, 'declined');
        banner.classList.remove('visible');
      });
    }
  }

  function loadScores() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.scores);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed;
    } catch (error) {
      console.error('Не удалось прочитать результаты игры', error);
      return [];
    }
  }

  function saveScores(scores) {
    localStorage.setItem(STORAGE_KEYS.scores, JSON.stringify(scores));
  }

  function updateGameScoreboard() {
    const list = document.querySelector('[data-score-list]');
    if (!list) return;

    const scores = loadScores().sort((a, b) => b.score - a.score).slice(0, 5);
    list.innerHTML = '';
    if (!scores.length) {
      const placeholder = document.createElement('li');
      placeholder.className = 'scoreboard-empty';
      placeholder.textContent = 'Пока нет сохранённых результатов. Будьте первыми!';
      list.appendChild(placeholder);
      return;
    }

    scores.forEach((entry, index) => {
      const item = document.createElement('li');
      const left = document.createElement('span');
      left.textContent = `${index + 1}. ${entry.name}`;
      const right = document.createElement('span');
      right.textContent = `${entry.score} очков`;
      item.append(left, right);
      list.appendChild(item);
    });
  }

  function updateLeaderboardPage() {
    const tbody = document.querySelector('[data-leaderboard]');
    if (!tbody) return;

    const scores = loadScores()
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);

    tbody.innerHTML = '';

    if (!scores.length) {
      const row = document.createElement('tr');
      row.innerHTML = '<td>—</td><td>Нет данных</td><td>—</td><td>—</td>';
      tbody.appendChild(row);
      return;
    }

    scores.forEach((entry, index) => {
      const row = document.createElement('tr');
      const formattedDate = new Date(entry.date).toLocaleDateString('ru-RU', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      });
      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${entry.name}</td>
        <td>${entry.score}</td>
        <td>${formattedDate}</td>
      `;
      tbody.appendChild(row);
    });
  }

  function initGame() {
    if (document.body.dataset.page !== 'game') return;

    const startBtn = document.querySelector('[data-game-start]');
    const restartBtn = document.querySelector('[data-game-restart]');
    const optionsContainer = document.getElementById('game-options');
    const promptEl = document.getElementById('game-prompt');
    const descriptionEl = document.getElementById('game-description');
    const timerEl = document.getElementById('game-timer');
    const scoreEl = document.getElementById('game-score');
    const streakEl = document.getElementById('game-streak');
    const resultPanel = document.getElementById('game-result');
    const summaryEl = document.getElementById('game-summary');
    const scoreForm = document.querySelector('[data-score-form]');
    const closeResultBtn = document.querySelector('[data-result-close]');

    if (!startBtn || !optionsContainer) return;

    const deck = [
      {
        query: 'Запрос «погода Москва сейчас» в рабочее утро',
        description: 'Какое действие совершают чаще всего?',
        choices: [
          'Открывают виджет Яндекс.Погоды с почасовым прогнозом',
          'Читают новости о погодных аномалиях',
          'Переключаются на Яндекс.Карты для расчёта маршрута'
        ],
        correctIndex: 0,
        explanation: 'В утренний час пик пользователям важен быстрый прогноз по часам.'
      },
      {
        query: 'Запрос «пробки на трёшке»',
        description: 'Какой сценарий популярнее?',
        choices: [
          'Переход в Яндекс.Карты с включённым слоем «Пробки»',
          'Чтение тематических блогов о дорогах',
          'Просмотр видео с обзорами ДТП'
        ],
        correctIndex: 0,
        explanation: 'Большинство сразу запускают Маршрутизацию в Яндекс.Картах.'
      },
      {
        query: 'Запрос «афиша выходные Москва»',
        description: 'Что выбирают чаще?',
        choices: [
          'Фильтр мероприятий в Яндекс.Афише',
          'Случайные статьи в Дзене',
          'Видео-обзор на YouTube'
        ],
        correctIndex: 0,
        explanation: 'Афиша предлагает персонализированную подборку и быструю покупку билетов.'
      },
      {
        query: 'Запрос «Яндекс Плюс подписка»',
        description: 'Как действует большинство?',
        choices: [
          'Сравнивают тарифы и оформляют Плюс',
          'Читают отзывы на форумах',
          'Добавляют Плюс.Музыку в избранное'
        ],
        correctIndex: 0,
        explanation: 'Пользователи чаще оформляют подписку сразу после сравнения тарифов.'
      },
      {
        query: 'Запрос «перевод денег Яндекс»',
        description: 'Какое действие типично?',
        choices: [
          'Открывают Яндекс Pay и переводят по номеру',
          'Ищут инструкции в справке',
          'Сравнивают с другими сервисами переводов'
        ],
        correctIndex: 0,
        explanation: 'Пользователи переходят к действию через привычный Pay-интерфейс.'
      },
      {
        query: 'Запрос «что посмотреть вечером»',
        description: 'Где заканчивает пользователь?',
        choices: [
          'Запускает Яндекс ТВ и выбирает фильм по жанру',
          'Читает длинный обзор в Дзене',
          'Просматривает рейтинг на стороннем сайте'
        ],
        correctIndex: 0,
        explanation: 'Яндекс ТВ даёт быстрые рекомендации и возможность запускать просмотр.'
      },
      {
        query: 'Запрос «Яндекс Еда акции»',
        description: 'Какой шаг самый популярный?',
        choices: [
          'Открыть раздел промокодов в приложении',
          'Читать новости о скидках',
          'Смотреть ролики блогеров о еде'
        ],
        correctIndex: 0,
        explanation: 'Промокоды сразу применяются к заказу, поэтому это основной сценарий.'
      },
      {
        query: 'Запрос «умная колонка Яндекс»',
        description: 'Что делает пользователь дальше?',
        choices: [
          'Читает спецификацию и оформляет покупку',
          'Ищет обзоры на внешних площадках',
          'Добавляет товар в список желаний'
        ],
        correctIndex: 0,
        explanation: 'Каталог Яндекса содержит актуальные характеристики и покупку в один клик.'
      },
      {
        query: 'Запрос «маршрут на дачу»',
        description: 'Какое действие выбирают?',
        choices: [
          'Строят маршрут в Яндекс.Картах с учётом пробок',
          'Скачивают офлайн-карту',
          'Читают форумы про дачные дороги'
        ],
        correctIndex: 0,
        explanation: 'Реальное время и пробки важнее всего, поэтому выбор падает на карты.'
      },
      {
        query: 'Запрос «скидки маркет»',
        description: 'Что делают чаще всего?',
        choices: [
          'Переходят в раздел акций на Яндекс Маркете',
          'Сравнивают цены в поиске',
          'Читают отзывы в Дзене'
        ],
        correctIndex: 0,
        explanation: 'Раздел акций даёт готовые подборки и экономит время.'
      }
    ];

    let shuffledDeck = [];
    let currentIndex = 0;
    let score = 0;
    let streak = 0;
    let timeLeft = 60;
    let timerId = null;
    let canAnswer = false;

    function shuffle(array) {
      return array
        .map(value => ({ value, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort)
        .map(({ value }) => value);
    }

    function resetGameState() {
      shuffledDeck = shuffle(deck);
      currentIndex = 0;
      score = 0;
      streak = 0;
      timeLeft = 60;
      canAnswer = false;
      clearInterval(timerId);
      timerId = null;
      timerEl.textContent = timeLeft.toString();
      scoreEl.textContent = score.toString();
      streakEl.textContent = streak.toString();
      resultPanel.classList.remove('active');
      startBtn.disabled = false;
      restartBtn.disabled = true;
      optionsContainer.innerHTML = '';
      promptEl.textContent = 'Нажмите «Старт», чтобы загрузить сценарии';
      descriptionEl.textContent = 'Каждый раунд — реальная ситуация из сервисов Яндекса. Угадайте, что делает большинство пользователей.';
    }

    function startTimer() {
      timerId = setInterval(() => {
        timeLeft -= 1;
        if (timeLeft < 0) {
          timeLeft = 0;
        }
        timerEl.textContent = timeLeft.toString();
        if (timeLeft <= 0) {
          endGame('Время вышло! Новая попытка — новый рекорд.');
        }
      }, 1000);
    }

    function renderRound() {
      if (currentIndex >= shuffledDeck.length) {
        endGame('Вы прошли все сценарии! Попробуйте ещё раз, чтобы обновить результат.');
        return;
      }

      const round = shuffledDeck[currentIndex];
      promptEl.textContent = round.query;
      descriptionEl.textContent = round.description;
      optionsContainer.innerHTML = '';

      round.choices.forEach((choice, idx) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'game-option';
        button.textContent = choice;
        button.dataset.index = idx.toString();
        button.addEventListener('click', () => handleAnswer(idx));
        optionsContainer.appendChild(button);
      });

      canAnswer = true;
    }

    function handleAnswer(selectedIndex) {
      if (!canAnswer || currentIndex >= shuffledDeck.length) return;

      canAnswer = false;
      const round = shuffledDeck[currentIndex];
      const optionButtons = Array.from(optionsContainer.querySelectorAll('.game-option'));
      optionButtons.forEach(btn => btn.disabled = true);
      const correctIndex = round.correctIndex;

      optionButtons[correctIndex].classList.add('correct');

      if (selectedIndex === correctIndex) {
        score += 10;
        streak += 1;
        timeLeft = Math.min(timeLeft + 3, 120);
      } else {
        optionButtons[selectedIndex].classList.add('incorrect');
        score = Math.max(0, score - 2);
        streak = 0;
        timeLeft = Math.max(0, timeLeft - 5);
      }

      scoreEl.textContent = score.toString();
      streakEl.textContent = streak.toString();
      timerEl.textContent = timeLeft.toString();

      setTimeout(() => {
        descriptionEl.textContent = round.explanation;
        setTimeout(() => {
          currentIndex += 1;
          renderRound();
        }, 900);
      }, 400);
    }

    function endGame(reason) {
      clearInterval(timerId);
      timerId = null;
      canAnswer = false;
      startBtn.disabled = false;
      restartBtn.disabled = false;
      optionsContainer.innerHTML = '';
      promptEl.textContent = 'Сессия завершена';
      descriptionEl.textContent = reason;
      summaryEl.textContent = `Ваш результат: ${score} очков. Серия правильных ответов: ${streak}.`;
      resultPanel.classList.add('active');
      timerEl.textContent = timeLeft.toString();
    }

    startBtn.addEventListener('click', () => {
      resetGameState();
      shuffledDeck = shuffle(deck);
      startBtn.disabled = true;
      restartBtn.disabled = false;
      canAnswer = true;
      renderRound();
      startTimer();
    });

    restartBtn.addEventListener('click', () => {
      resetGameState();
      shuffledDeck = shuffle(deck);
      startBtn.disabled = true;
      restartBtn.disabled = false;
      canAnswer = true;
      renderRound();
      startTimer();
    });

    if (scoreForm) {
      scoreForm.addEventListener('submit', event => {
        event.preventDefault();
        const formData = new FormData(scoreForm);
        const name = (formData.get('player-name') || '').toString().trim().substring(0, 24);
        if (!name) return;

        const scores = loadScores();
        scores.push({
          name,
          score,
          date: new Date().toISOString()
        });

        saveScores(scores);
        updateGameScoreboard();
        updateLeaderboardPage();
        scoreForm.reset();
        resultPanel.classList.remove('active');
      });
    }

    if (closeResultBtn) {
      closeResultBtn.addEventListener('click', () => {
        resultPanel.classList.remove('active');
      });
    }

    resetGameState();
    updateGameScoreboard();
  }

  function initContactForm() {
    if (document.body.dataset.page !== 'contact') return;
    const form = document.querySelector('[data-contact-form]');
    const statusEl = document.querySelector('[data-form-status]');
    if (!form || !statusEl) return;

    form.addEventListener('submit', event => {
      event.preventDefault();
      statusEl.textContent = 'Отправляем...';
      setTimeout(() => {
        statusEl.textContent = 'Спасибо! Мы свяжемся с вами в течение 24 часов.';
        form.reset();
      }, 1000);
    });
  }

  ready(() => {
    showCookieBanner();
    updateGameScoreboard();
    updateLeaderboardPage();
    initGame();
    initContactForm();
  });
})();