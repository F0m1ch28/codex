document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.getElementById('primary-navigation');

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            nav.classList.toggle('is-open');
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const banner = document.getElementById('cookieBanner');
    const storageKey = 'genuscayqgCookiePreference';

    if (banner) {
        try {
            const storedPreference = localStorage.getItem(storageKey);
            if (storedPreference) {
                banner.classList.add('is-hidden');
            }
        } catch (error) {
            console.warn('Cookie banner storage unavailable', error);
        }

        banner.querySelectorAll('button[data-cookie-preference]').forEach(button => {
            button.addEventListener('click', () => {
                const preference = button.getAttribute('data-cookie-preference');
                try {
                    localStorage.setItem(storageKey, preference);
                } catch (error) {
                    console.warn('Cookie preference could not be saved', error);
                }
                banner.classList.add('is-hidden');
            });
        });
    }

    const revealElements = document.querySelectorAll('.reveal-on-scroll');
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    obs.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });

        revealElements.forEach(el => observer.observe(el));
    } else {
        revealElements.forEach(el => el.classList.add('is-visible'));
    }
});