import React, { useState } from 'react';
import styles from './SubscriptionForm.module.css';

const SubscriptionForm = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleSubmit = (event) => {
    event.preventDefault();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      setStatus({ type: 'error', message: 'Please enter a valid business email address.' });
      return;
    }
    setStatus({ type: 'success', message: 'You are now part of the Northern Light briefing list.' });
    setEmail('');
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit} aria-label="Newsletter Subscription">
      <div className={styles.inputGroup}>
        <label htmlFor="newsletter-email">Stay ahead with our weekly dispatch</label>
        <div className={styles.controls}>
          <input
            id="newsletter-email"
            type="email"
            name="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="you@organization.com"
            required
            aria-required="true"
          />
          <button type="submit">Subscribe</button>
        </div>
      </div>
      {status.message && (
        <p
          className={`${styles.status} ${status.type === 'success' ? styles.success : styles.error}`}
          role="status"
        >
          {status.message}
        </p>
      )}
    </form>
  );
};

export default SubscriptionForm;