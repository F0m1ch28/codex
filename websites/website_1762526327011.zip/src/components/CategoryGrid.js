import React from 'react';
import styles from './CategoryGrid.module.css';

const CategoryGrid = ({ categories }) => (
  <div className={styles.grid} role="list">
    {categories.map((category) => (
      <article key={category.title} className={styles.card} role="listitem">
        <div className={styles.icon}>{category.icon}</div>
        <h3>{category.title}</h3>
        <p>{category.description}</p>
        <ul>
          {category.topics.map((topic) => (
            <li key={topic}>{topic}</li>
          ))}
        </ul>
      </article>
    ))}
  </div>
);

export default CategoryGrid;