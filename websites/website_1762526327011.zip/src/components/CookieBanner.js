import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('nls-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('nls-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent">
      <div className={styles.content}>
        <p>
          We use cookies to analyze site engagement and tailor data stories that matter to you.
          By continuing to navigate, you agree to our analytics-friendly cookies.
        </p>
        <button type="button" onClick={acceptCookies} className={styles.button}>
          Accept & Continue
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;