import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './ArticleCard.module.css';

const ArticleCard = ({ article }) => {
  const { title, excerpt, category, date, readTime, image, link } = article;
  const [loaded, setLoaded] = useState(false);

  return (
    <article className={styles.card}>
      <div className={styles.imageWrapper}>
        <img
          src={image}
          alt={`${title} visual`}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          className={loaded ? styles.imageLoaded : ''}
        />
      </div>
      <div className={styles.content}>
        <span className={styles.meta}>{category} • {date} • {readTime}</span>
        <h3>{title}</h3>
        <p>{excerpt}</p>
        <Link to={link} className={styles.link}>
          Read Insight
        </Link>
      </div>
    </article>
  );
};

export default ArticleCard;