import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Site Footer">
    <div className={styles.container}>
      <div className={styles.brand}>
        <h3>Northern Light Strips</h3>
        <p>
          Illuminating data analytics, AI innovation, and digital transformation with clarity and precision.
          Every article is crafted to equip leaders for intelligent evolution.
        </p>
      </div>
      <div className={styles.column}>
        <h4>Explore</h4>
        <ul>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/services">Services</Link></li>
          <li><Link to="/blog">Blog</Link></li>
          <li><Link to="/categories">Categories</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Support</h4>
        <ul>
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/terms">Terms</Link></li>
          <li><Link to="/privacy">Privacy</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Contact</h4>
        <ul>
          <li>Email: <a href="mailto:hello@northernlightstrips.com">hello@northernlightstrips.com</a></li>
          <li>HQ: Helsinki, Finland</li>
          <li>Global Research Collective</li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Northern Light Strips. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;