import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import ArticleCard from '../components/ArticleCard';
import SubscriptionForm from '../components/SubscriptionForm';
import CategoryGrid from '../components/CategoryGrid';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Analytical Playbooks Delivered', value: 240 },
  { label: 'AI Transformation Workshops', value: 68 },
  { label: 'Automation Frameworks Designed', value: 112 },
  { label: 'Markets & Sectors Benchmarked', value: 19 },
];

const processSteps = [
  {
    step: '01',
    title: 'Map the Data Terrain',
    description: 'Establish clarity on data sources, integrity, and the business signals that matter most.',
  },
  {
    step: '02',
    title: 'Model Intelligent Pathways',
    description: 'Prototype AI-led scenarios and automation options that align with strategic intent.',
  },
  {
    step: '03',
    title: 'Operationalize Insights',
    description: 'Embed analytics pipelines, automation workflows, and governance for lasting impact.',
  },
  {
    step: '04',
    title: 'Scale with Confidence',
    description: 'Continuously monitor, re-calibrate, and communicate value to stakeholders in real time.',
  },
];

const testimonials = [
  {
    quote:
      'Northern Light Strips distills complex analytics programs into actionable roadmaps. Their lens on intelligent systems keeps our teams focused.',
    name: 'Elina Korhonen',
    title: 'Chief Data Officer, Aurora Manufacturing',
  },
  {
    quote:
      'The digital transformation coverage is pragmatic and future-aware. We rely on their automation insights when shaping our platform strategy.',
    name: 'Marcus Lindgren',
    title: 'Director of Innovation, Fjord Systems',
  },
  {
    quote:
      'Every feature translates emerging AI research into executive-decision language. It is our go-to source for tech evolution briefings.',
    name: 'Priya Narayanan',
    title: 'VP Strategy, Northwind Analytics',
  },
];

const teamMembers = [
  {
    name: 'Sara Voutilainen',
    role: 'Head of Data Narratives',
    description: 'Transforms raw data signals into visual stories that boards understand.',
    image: 'https://picsum.photos/400/400?random=3',
  },
  {
    name: 'Jonas Berg',
    role: 'Intelligent Systems Analyst',
    description: 'Bridges AI research with operational realities for complex industries.',
    image: 'https://picsum.photos/400/400?random=33',
  },
  {
    name: 'Mila Anders',
    role: 'Automation Insights Lead',
    description: 'Designs automation journeys with empathy for both process and people.',
    image: 'https://picsum.photos/400/400?random=34',
  },
];

const projectsData = [
  {
    title: 'Adaptive Analytics Observatory',
    category: 'Data Analytics',
    description: 'Designing a multi-layer observability suite for real-time operational insights.',
    image: 'https://picsum.photos/1200/800?random=4',
  },
  {
    title: 'Cognitive Service Mesh',
    category: 'AI Innovation',
    description: 'Blueprinting a modular AI service mesh to accelerate experimentation.',
    image: 'https://picsum.photos/1200/800?random=44',
  },
  {
    title: 'Autonomous Process Fabric',
    category: 'Automation',
    description: 'Co-creating resilient process automation with human-in-the-loop safeguards.',
    image: 'https://picsum.photos/1200/800?random=45',
  },
  {
    title: 'Digital Twin Navigator',
    category: 'Intelligent Systems',
    description: 'Crafting a digital twin framework for precision logistics forecasting.',
    image: 'https://picsum.photos/1200/800?random=46',
  },
];

const faqs = [
  {
    question: 'How do you select topics for coverage?',
    answer:
      'Our editorial board partners with industry researchers, data architects, and transformation leads to identify themes with tangible enterprise value.',
  },
  {
    question: 'Do you offer deep-dive research collaborations?',
    answer:
      'Yes. We co-create bespoke research reports, design playbooks, and facilitate executive briefings grounded in your strategic goals.',
  },
  {
    question: 'Can we contribute insights or guest articles?',
    answer:
      'We welcome perspectives from practitioners and academic researchers. Submit your pitch via the contact page with a clear thesis and evidence plan.',
  },
];

const categories = [
  {
    title: 'Data Analytics',
    description: 'Modern architectures, observability, and experience design for data-driven decisions.',
    icon: '📊',
    topics: ['Data mesh strategy', 'Enterprise dashboards', 'Predictive models'],
  },
  {
    title: 'AI Innovation',
    description: 'Research-backed pathways for responsible, scalable artificial intelligence adoption.',
    icon: '🤖',
    topics: ['Model ops', 'Ethical AI frameworks', 'Generative AI use cases'],
  },
  {
    title: 'Digital Transformation',
    description: 'Blueprints to align processes, people, and technology for future-ready operations.',
    icon: '🌐',
    topics: ['Change orchestration', 'Digital culture', 'Capability roadmaps'],
  },
  {
    title: 'Automation Insights',
    description: 'Human-centric automation, orchestration, and workflow design strategies.',
    icon: '⚙️',
    topics: ['Process mining', 'Automation ethics', 'Adaptive workflows'],
  },
  {
    title: 'Intelligent Systems',
    description: 'Systems thinking and platform design for resilient, smart infrastructure.',
    icon: '🧠',
    topics: ['Digital twins', 'Edge intelligence', 'System resilience'],
  },
  {
    title: 'Tech Evolution',
    description: 'Signal scanning across emerging technologies shaping enterprise ecosystems.',
    icon: '🚀',
    topics: ['Platform ecosystems', 'Tech policy shifts', 'Sustainable engineering'],
  },
];

const articles = [
  {
    title: 'Designing Decision Flows for Trustworthy AI Platforms',
    excerpt: 'Frameworks and guardrails for building AI services that deliver consistent value without sacrificing oversight.',
    category: 'AI Innovation',
    date: 'Nov 8, 2023',
    readTime: '7 min read',
    image: 'https://picsum.photos/800/600?random=2',
    link: '/blog',
  },
  {
    title: 'Automation Intelligence: Layering Human Insight with Bots',
    excerpt: 'How modern automation architectures integrate human judgment to keep operations adaptive.',
    category: 'Automation Insights',
    date: 'Oct 24, 2023',
    readTime: '6 min read',
    image: 'https://picsum.photos/800/600?random=22',
    link: '/blog',
  },
  {
    title: 'Visualizing Data Futures with Experience Analytics',
    excerpt: 'Exploring new experience-led analytics that surface possibilities, not just metrics.',
    category: 'Data Analytics',
    date: 'Oct 9, 2023',
    readTime: '8 min read',
    image: 'https://picsum.photos/800/600?random=23',
    link: '/blog',
  },
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsConfig.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeFilter, setActiveFilter] = useState('All');
  const [activeMember, setActiveMember] = useState(teamMembers[0].name);

  useEffect(() => {
    const durations = statsConfig.map(() => Math.floor(Math.random() * 1000) + 900);
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / 1200, 1);
      setAnimatedStats(
        statsConfig.map((stat, index) => Math.floor(stat.value * progress * (1200 / durations[index])))
      );
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setAnimatedStats(statsConfig.map((stat) => stat.value));
      }
    };

    const frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'All') {
      return projectsData;
    }
    return projectsData.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <Helmet>
        <title>Northern Light Strips – Navigating Data, Analytics and Intelligent Transformation</title>
        <meta
          name="description"
          content="Explore data analytics, AI innovation, automation insights, and intelligent systems through the Northern Light Strips blog."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.overlay} />
        <div className={`${styles.container} ${styles.heroContent}`}>
          <div>
            <p className={styles.kicker}>Forward-focused intelligence</p>
            <h1>Northern Light Strips – Navigating Data, Analytics and Intelligent Transformation</h1>
            <p className={styles.subtitle}>
              We empower tech leaders to decode signal from noise, operationalize analytics, and architect smart automation.
            </p>
            <div className={styles.heroActions}>
              <Link to="/services" className={styles.primaryButton}>
                Explore Our Playbooks
              </Link>
              <Link to="/contact" className={styles.secondaryButton}>
                Schedule a Briefing
              </Link>
            </div>
            <div className={styles.heroStats}>
              <span>Weekly intelligence dispatch • Trusted by innovation teams across 5 continents</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className={styles.container}>
          <div className={styles.statsGrid}>
            {statsConfig.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{animatedStats[index]}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className={styles.container}>
          <div className={styles.aboutContent}>
            <h2>About the blog</h2>
            <p>
              Northern Light Strips examines the interplay between data analytics, AI innovation, automation, and enterprise culture.
              We decode research, pilot stories, and systems thinking concepts to help you move from exploration to measurable transformation.
            </p>
            <Link to="/about" className={styles.linkButton}>
              Discover Our Mission
            </Link>
          </div>
          <div className={styles.highlightPanel}>
            <h3>What we cover</h3>
            <ul>
              <li>Analytical frameworks that accelerate confident decisions</li>
              <li>Automation stories grounded in human experience</li>
              <li>Intelligent system design from prototypes to platforms</li>
              <li>Digital transformation narratives shaping resilient enterprises</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection}>
        <div className={styles.container}>
          <h2>Key Focus Areas</h2>
          <p className={styles.sectionSubtitle}>
            Explore how data, AI, and automation weave together to build intelligent, adaptive organizations.
          </p>
          <CategoryGrid categories={categories} />
        </div>
      </section>

      <section className={styles.processSection}>
        <div className={styles.container}>
          <div className={styles.processHeader}>
            <h2>Our insight process</h2>
            <p>
              We dissect every transformation narrative with a repeatable, field-tested approach. Each step blends quantitative rigor with qualitative context.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.step} className={styles.processCard}>
                <span className={styles.stepNumber}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className={styles.container}>
          <div className={styles.projectsHeader}>
            <h2>Transformation spotlights</h2>
            <div className={styles.filterControls} role="tablist" aria-label="Project categories">
              {['All', 'Data Analytics', 'AI Innovation', 'Automation', 'Intelligent Systems'].map((filter) => (
                <button
                  key={filter}
                  type="button"
                  className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
                  onClick={() => setActiveFilter(filter)}
                  aria-pressed={activeFilter === filter}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={`${project.title} visual`} loading="lazy" />
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialSection}>
        <div className={styles.container}>
          <div className={styles.testimonialContent}>
            <h2>Leaders trust our lens</h2>
            <p className={styles.sectionSubtitle}>
              Hear from executives and strategists who use Northern Light Strips to guide pivotal decisions.
            </p>
            <div className={styles.testimonialCard}>
              <p className={styles.quote}>&ldquo;{testimonials[testimonialIndex].quote}&rdquo;</p>
              <div className={styles.person}>
                <h4>{testimonials[testimonialIndex].name}</h4>
                <span>{testimonials[testimonialIndex].title}</span>
              </div>
              <div className={styles.testimonialControls}>
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    type="button"
                    className={`${styles.dot} ${index === testimonialIndex ? styles.dotActive : ''}`}
                    onClick={() => setTestimonialIndex(index)}
                    aria-label={`Show testimonial ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className={styles.container}>
          <div className={styles.teamHeader}>
            <h2>Editorial research collective</h2>
            <p>
              A multi-disciplinary team blending data science, design, and transformation strategy keeps each publication precise, visual, and actionable.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article
                key={member.name}
                className={`${styles.teamCard} ${activeMember === member.name ? styles.teamCardActive : ''}`}
                onMouseEnter={() => setActiveMember(member.name)}
                onFocus={() => setActiveMember(member.name)}
                tabIndex={0}
              >
                <img src={member.image} alt={`${member.name} portrait`} loading="lazy" />
                <div>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.container}>
          <div className={styles.faqHeader}>
            <h2>Frequently asked questions</h2>
            <p>
              Guidance for readers, contributors, and innovation teams exploring deeper collaborations.
            </p>
          </div>
          <div className={styles.accordion}>
            {faqs.map((faq, index) => (
              <details key={faq.question} className={styles.accordionItem}>
                <summary>
                  <span>{faq.question}</span>
                  <span className={styles.accordionIcon}>+</span>
                </summary>
                <p>{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className={styles.container}>
          <div className={styles.blogHeader}>
            <h2>Latest insights</h2>
            <Link to="/blog" className={styles.linkButton}>
              View All Publications
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {articles.map((article) => (
              <ArticleCard key={article.title} article={article} />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.subscriptionSection}>
        <div className={styles.container}>
          <div className={styles.subscriptionContent}>
            <h2>Join the Northern Light briefing</h2>
            <p>
              Get weekly field notes on data analytics craftsmanship, AI innovation, and automation journeys shaping intelligent enterprises.
            </p>
          </div>
          <SubscriptionForm />
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.container}>
          <h2>Ready to illuminate your next transformation sprint?</h2>
          <p>
            Our editorial and research collective partners with your teams to benchmark strategies, decode outcomes, and design the next intelligent leap.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryButton}>
              Connect with our team
            </Link>
            <Link to="/about" className={styles.secondaryButton}>
              Learn how we work
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;