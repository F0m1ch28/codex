import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms & Conditions | Northern Light Strips</title>
      <meta
        name="description"
        content="Review the terms and conditions governing the use of Northern Light Strips content and services."
      />
    </Helmet>
    <section className={styles.section}>
      <div className={styles.container}>
        <h1>Terms & Conditions</h1>
        <p>Last updated: October 2023</p>

        <h2>1. Overview</h2>
        <p>
          Northern Light Strips provides editorial content, research insights, and advisory resources focused on data analytics,
          AI innovation, automation, and digital transformation. By accessing our website or collaborating with our collective,
          you agree to these terms.
        </p>

        <h2>2. Use of content</h2>
        <p>
          Our articles, reports, and visual materials are protected by copyright. You may reference excerpts with clear attribution.
          Republishing, translating, or commercial use requires written permission from our editorial team.
        </p>

        <h2>3. Advisory engagements</h2>
        <p>
          Advisory services are subject to separate engagement agreements. These terms govern the use of publicly available materials.
        </p>

        <h2>4. Community contributions</h2>
        <p>
          Contributors confirm that submissions are original, properly credited, and do not infringe on third-party rights.
          We reserve the right to edit or decline submissions that do not align with our editorial standards.
        </p>

        <h2>5. Liability</h2>
        <p>
          We strive for accuracy yet make no warranties regarding the completeness or applicability of content. Northern Light Strips
          is not liable for decisions made based on the information provided on this site.
        </p>

        <h2>6. Updates</h2>
        <p>
          We may update these terms to reflect new services or regulatory changes. Continued use signifies acceptance of any updates.
        </p>

        <h2>7. Contact</h2>
        <p>
          For questions about these terms, contact us at <a href="mailto:legal@northernlightstrips.com">legal@northernlightstrips.com</a>.
        </p>
      </div>
    </section>
  </>
);

export default Terms;