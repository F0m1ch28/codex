import React from 'react';
import { Helmet } from 'react-helmet';
import CategoryGrid from '../components/CategoryGrid';
import styles from './Categories.module.css';

const categories = [
  {
    title: 'Data Analytics',
    description: 'Blueprints for building resilient data platforms, modern governance, and experience-led dashboards.',
    icon: '📊',
    topics: ['Analytics operating models', 'Decision intelligence', 'Metric storytelling'],
  },
  {
    title: 'AI Innovation',
    description: 'Human-centered AI playbooks, experimentation techniques, and responsible adoption practices.',
    icon: '🤖',
    topics: ['AI talent collaboration', 'Guardrail design', 'Generative experimentation'],
  },
  {
    title: 'Digital Transformation',
    description: 'Organizational design, capability building, and leadership narratives for digital reinvention.',
    icon: '🌐',
    topics: ['Transformation offices', 'Experience-led change', 'Technology portfolio evolution'],
  },
  {
    title: 'Automation Insights',
    description: 'Process mining, orchestration, and service design for automation journeys that elevate people.',
    icon: '⚙️',
    topics: ['Process intelligence', 'Automation ethics', 'Service choreography'],
  },
  {
    title: 'Intelligent Systems',
    description: 'Interconnected ecosystems that learn, adapt, and scale across environments.',
    icon: '🧠',
    topics: ['Digital twins', 'System resilience', 'Edge-to-core architectures'],
  },
  {
    title: 'Tech Evolution',
    description: 'Signals on emerging technologies, policy shifts, and strategic bets shaping the next decade.',
    icon: '🚀',
    topics: ['Sustainable engineering', 'Platform economies', 'Future tech governance'],
  },
];

const Categories = () => (
  <>
    <Helmet>
      <title>Categories | Northern Light Strips</title>
      <meta
        name="description"
        content="Navigate Northern Light Strips categories focused on data analytics, AI innovation, digital transformation, automation, intelligent systems, and tech evolution."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <h1>Research categories</h1>
        <p>Target your exploration across the key pillars of data-driven, intelligent transformation.</p>
      </div>
    </section>

    <section className={styles.gridSection}>
      <div className={styles.container}>
        <CategoryGrid categories={categories} />
      </div>
    </section>
  </>
);

export default Categories;