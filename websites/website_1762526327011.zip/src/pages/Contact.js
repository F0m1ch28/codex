import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formValues, setFormValues] = useState({ name: '', email: '', organization: '', message: '' });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formValues.name || !formValues.email || !formValues.message) {
      setStatus({ type: 'error', message: 'Please complete the required fields to help us respond precisely.' });
      return;
    }
    setStatus({ type: 'success', message: 'Thank you—an advisory lead will connect with you within two business days.' });
    setFormValues({ name: '', email: '', organization: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contact | Northern Light Strips</title>
        <meta
          name="description"
          content="Connect with Northern Light Strips to collaborate on data analytics, AI innovation, and digital transformation stories."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.container}>
          <h1>Let’s chart your next intelligent move</h1>
          <p>
            Share your goals, challenges, or insight requests. We’ll align the right research editors and advisors to respond.
          </p>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className={styles.container}>
          <form className={styles.form} onSubmit={handleSubmit} aria-label="Contact form">
            <div className={styles.row}>
              <label htmlFor="name">Name *</label>
              <input
                id="name"
                name="name"
                value={formValues.name}
                onChange={handleChange}
                placeholder="Your full name"
                required
              />
            </div>
            <div className={styles.row}>
              <label htmlFor="email">Business Email *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formValues.email}
                onChange={handleChange}
                placeholder="you@organization.com"
                required
              />
            </div>
            <div className={styles.row}>
              <label htmlFor="organization">Organization</label>
              <input
                id="organization"
                name="organization"
                value={formValues.organization}
                onChange={handleChange}
                placeholder="Company or team"
              />
            </div>
            <div className={styles.row}>
              <label htmlFor="message">How can we help? *</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formValues.message}
                onChange={handleChange}
                placeholder="Tell us about your project, article idea, or research request."
                required
              />
            </div>
            <button type="submit" className={styles.submitButton}>Send message</button>
            {status.message && (
              <p className={`${styles.status} ${status.type === 'success' ? styles.success : styles.error}`} role="status">
                {status.message}
              </p>
            )}
          </form>
          <aside className={styles.sidebar}>
            <h2>Collaboration channels</h2>
            <ul>
              <li>
                <strong>Custom research engagements</strong>
                <p>Deep-dive analytics and AI studies tailored to your transformation objectives.</p>
              </li>
              <li>
                <strong>Executive briefings</strong>
                <p>Interactive sessions for leadership teams exploring intelligent automation and AI oversight.</p>
              </li>
              <li>
                <strong>Contributor submissions</strong>
                <p>Pitch human-centered stories or research perspectives by emailing <a href="mailto:insights@northernlightstrips.com">insights@northernlightstrips.com</a>.</p>
              </li>
            </ul>
          </aside>
        </div>
      </section>
    </>
  );
};

export default Contact;