import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Northern Light Strips</title>
      <meta
        name="description"
        content="Understand how Northern Light Strips collects, uses, and protects your information."
      />
    </Helmet>
    <section className={styles.section}>
      <div className={styles.container}>
        <h1>Privacy Policy</h1>
        <p>Effective as of October 2023</p>

        <h2>Information we collect</h2>
        <p>
          We collect information you voluntarily provide such as newsletter subscriptions, workshop registrations, or contact submissions.
          We also gather aggregated analytics data to understand engagement with our content.
        </p>

        <h2>How we use information</h2>
        <p>
          Data helps us tailor content, respond to requests, improve our services, and send editorial updates you opt into.
          We do not sell your information or share it with advertisers.
        </p>

        <h2>Cookies & analytics</h2>
        <p>
          Our site uses cookies to analyze traffic patterns and enhance user experience. You can manage cookies via your browser settings.
        </p>

        <h2>Data protection</h2>
        <p>
          We implement administrative, technical, and physical safeguards to protect your information. For data access or deletion requests,
          contact <a href="mailto:privacy@northernlightstrips.com">privacy@northernlightstrips.com</a>.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this policy to reflect new practices or regulatory requirements. We encourage you to review it periodically.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;