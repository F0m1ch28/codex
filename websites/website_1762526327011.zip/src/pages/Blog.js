import React from 'react';
import { Helmet } from 'react-helmet';
import ArticleCard from '../components/ArticleCard';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Four Signals That Indicate Your Data Stack Is Ready for Autonomous Insight',
    excerpt: 'Identify the maturity signs that prove your data infrastructure can support autonomous decisioning.',
    category: 'Data Analytics',
    date: 'Nov 2023',
    readTime: '9 min read',
    image: 'https://picsum.photos/800/600?random=62',
    link: '/blog',
  },
  {
    title: 'Architecting Responsible AI Portfolios Across Distributed Teams',
    excerpt: 'Strategies for building federated AI portfolios with shared guardrails and adaptive governance.',
    category: 'AI Innovation',
    date: 'Oct 2023',
    readTime: '8 min read',
    image: 'https://picsum.photos/800/600?random=63',
    link: '/blog',
  },
  {
    title: 'Automation as Experience: Designing Orchestrations People Trust',
    excerpt: 'How to design automation journeys that respect human intuition and business context.',
    category: 'Automation Insights',
    date: 'Sep 2023',
    readTime: '7 min read',
    image: 'https://picsum.photos/800/600?random=64',
    link: '/blog',
  },
  {
    title: 'Intelligent Systems That Scale: Lessons from Edge-to-Core Programs',
    excerpt: 'Insights from teams blending edge intelligence with resilient core systems to unlock new value.',
    category: 'Intelligent Systems',
    date: 'Aug 2023',
    readTime: '10 min read',
    image: 'https://picsum.photos/800/600?random=65',
    link: '/blog',
  },
];

const Blog = () => (
  <>
    <Helmet>
      <title>Blog | Northern Light Strips Insights</title>
      <meta
        name="description"
        content="Browse the Northern Light Strips blog featuring articles on data analytics, AI innovation, automation insights, and intelligent systems."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <h1>Insights & Field Notes</h1>
        <p>Deep dives, playbooks, and experiments propelling data-driven, intelligent transformation.</p>
      </div>
    </section>

    <section className={styles.listSection}>
      <div className={styles.container}>
        <div className={styles.grid}>
          {posts.map((post) => (
            <ArticleCard key={post.title} article={post} />
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Blog;