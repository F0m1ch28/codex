import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>About Northern Light Strips | Data Analytics & Intelligent Transformation</title>
      <meta
        name="description"
        content="Learn about the Northern Light Strips collective—strategists, analysts, and designers dedicated to intelligent transformation."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <span className={styles.kicker}>About Northern Light Strips</span>
        <h1>A research-driven collective decoding intelligent transformation</h1>
        <p>
          We are strategists, analysts, designers, and systems thinkers shaping narratives that move organizations from vision to action.
        </p>
      </div>
    </section>

    <section className={styles.gridSection}>
      <div className={styles.container}>
        <article className={styles.card}>
          <h2>Our mission</h2>
          <p>
            Illuminate critical shifts in data analytics, AI innovation, automation, and digital transformation. We blend hands-on experiments,
            curated interviews, and evidence-based models to deliver insight that inspires confident execution.
          </p>
        </article>
        <article className={styles.card}>
          <h2>Our methodology</h2>
          <p>
            Each feature is anchored by primary research, conversations with operational leaders, lab simulations, and design-led analysis.
            We translate complex technical narratives into visual, human-centered stories.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.valuesSection}>
      <div className={styles.container}>
        <h2>What guides our work</h2>
        <div className={styles.valuesGrid}>
          {[
            {
              title: 'Evidence before hype',
              text: 'We validate each story with field data, real experiments, and cross-disciplinary critique.',
            },
            {
              title: 'Systems thinking',
              text: 'We examine how decisions ripple across people, processes, data, and technology ecosystems.',
            },
            {
              title: 'Human-centered adoption',
              text: 'Every transformation story is evaluated for its impact on culture, capability, and leadership.',
            },
            {
              title: 'Open collaboration',
              text: 'We collaborate with researchers, practitioners, and advisors to expand viewpoints.',
            },
          ].map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.timelineSection}>
      <div className={styles.container}>
        <h2>Milestones in our journey</h2>
        <div className={styles.timeline}>
          <div className={styles.item}>
            <span className={styles.year}>2019</span>
            <p>Founded by data strategists and transformation leaders to decode analytics adoption stories.</p>
          </div>
          <div className={styles.item}>
            <span className={styles.year}>2020</span>
            <p>Launched our automation insights hub and published the Intelligent Operations Playbook.</p>
          </div>
          <div className={styles.item}>
            <span className={styles.year}>2021</span>
            <p>Partnered with innovation labs across Europe and APAC to document digital twin initiatives.</p>
          </div>
          <div className={styles.item}>
            <span className={styles.year}>2023</span>
            <p>Extended coverage to responsible AI frameworks and human-centered algorithm design.</p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className={styles.container}>
        <h2>Core editorial team</h2>
        <p className={styles.subtitle}>
          A blend of practitioners and researchers keeping Northern Light Strips inquisitive, rigorous, and future-aware.
        </p>
        <div className={styles.teamGrid}>
          {[
            {
              name: 'Sara Voutilainen',
              role: 'Head of Data Narratives',
              focus: 'Data storytelling, visualization, executive communication.',
              image: 'https://picsum.photos/420/420?random=53',
            },
            {
              name: 'Jonas Berg',
              role: 'Intelligent Systems Analyst',
              focus: 'AI system architecture, adaptive automation, system resilience.',
              image: 'https://picsum.photos/420/420?random=54',
            },
            {
              name: 'Mila Anders',
              role: 'Automation Insights Lead',
              focus: 'Workflow design, change enablement, experience-led automation.',
              image: 'https://picsum.photos/420/420?random=55',
            },
            {
              name: 'Ibrahim Qaadir',
              role: 'Tech Evolution Researcher',
              focus: 'Emergent technology mapping, policy shifts, ecosystem design.',
              image: 'https://picsum.photos/420/420?random=56',
            },
          ].map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name} portrait`} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.focus}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.approachSection}>
      <div className={styles.container}>
        <h2>How we collaborate with partners</h2>
        <div className={styles.approachGrid}>
          <article>
            <h3>Strategic research engagements</h3>
            <p>Co-create bespoke reports, maturity assessments, and benchmarking dashboards for your leadership teams.</p>
          </article>
          <article>
            <h3>Executive briefings & workshops</h3>
            <p>Host intelligence sessions on data strategy, AI governance, and automation adoption tailored to your context.</p>
          </article>
          <article>
            <h3>Transformation storytelling</h3>
            <p>Craft internal narratives, experience maps, and vision decks that align stakeholders on the path forward.</p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default About;