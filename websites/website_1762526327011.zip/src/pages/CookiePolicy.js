import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Northern Light Strips</title>
      <meta
        name="description"
        content="Learn how Northern Light Strips uses cookies and how you can manage your preferences."
      />
    </Helmet>
    <section className={styles.section}>
      <div className={styles.container}>
        <h1>Cookie Policy</h1>
        <p>We use cookies to understand engagement, personalize experiences, and support analytics-driven improvements.</p>

        <h2>What are cookies?</h2>
        <p>
          Cookies are small text files stored on your device. They help us remember your preferences and analyze how visitors navigate our content.
        </p>

        <h2>Types of cookies we use</h2>
        <ul>
          <li><strong>Essential cookies:</strong> Enable core functionality such as page navigation.</li>
          <li><strong>Analytics cookies:</strong> Provide aggregated usage insights to improve the site.</li>
          <li><strong>Preference cookies:</strong> Remember your settings, such as cookie consent.</li>
        </ul>

        <h2>Managing cookies</h2>
        <p>
          You can adjust your browser settings to refuse or delete cookies. Note that disabling cookies may impact site experience.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this policy to reflect changes in technology or regulation. For questions, contact
          <a href="mailto:privacy@northernlightstrips.com"> privacy@northernlightstrips.com</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;