import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Insight Systems Strategy',
    description: 'Co-design data and analytics architectures that connect intelligence to measurable outcomes.',
    points: ['Vision alignment sessions', 'Capability heatmaps', 'Stakeholder journey framing'],
  },
  {
    title: 'AI Adoption Pathways',
    description: 'Chart responsible AI roadmaps that balance experimentation with trusted governance.',
    points: ['Use case qualification', 'Model lifecycle frameworks', 'Oversight operating model'],
  },
  {
    title: 'Automation Blueprinting',
    description: 'Design human-centered automation journeys that elevate experience and efficiency.',
    points: ['Process mapping immersions', 'Automation experience design', 'Change readiness playbooks'],
  },
  {
    title: 'Transformation Storycraft',
    description: 'Translate transformation impact into narratives that inspire, align, and mobilize teams.',
    points: ['Executive communication kits', 'Experience-rich reports', 'Visual scenario mapping'],
  },
];

const capabilities = [
  {
    name: 'Research Intelligence Lab',
    text: 'Rapid experimentation with datasets, prototypes, and scenario modeling to validate possibilities.',
  },
  {
    name: 'Experience Visualization Studio',
    text: 'Motion, data visualization, and interactive storytelling assets for clarity-rich storytelling.',
  },
  {
    name: 'Advisory Council',
    text: 'Cross-industry advisors stress-test blueprints to ensure practicality across complex environments.',
  },
];

const Services = () => (
  <>
    <Helmet>
      <title>Services | Northern Light Strips Advisory</title>
      <meta
        name="description"
        content="Discover Northern Light Strips services: insight systems strategy, AI adoption pathways, automation blueprinting, and transformation storycraft."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <span className={styles.kicker}>Services</span>
        <h1>Advisory experiences that accelerate intelligent transformation</h1>
        <p>
          Choose modular advisory experiences or embed our research collective within your journey.
          We orchestrate evidence-led progress from discovery to adoption.
        </p>
      </div>
    </section>

    <section className={styles.servicesSection}>
      <div className={styles.container}>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.capabilitiesSection}>
      <div className={styles.container}>
        <h2>Integrated capabilities</h2>
        <div className={styles.capabilityGrid}>
          {capabilities.map((capability) => (
            <article key={capability.name}>
              <h3>{capability.name}</h3>
              <p>{capability.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.outcomesSection}>
      <div className={styles.container}>
        <h2>Outcomes you can expect</h2>
        <div className={styles.outcomesGrid}>
          <article>
            <h3>Shared understanding</h3>
            <p>Unite leadership and operating teams around a shared, visualized transformation roadmap.</p>
          </article>
          <article>
            <h3>Faster experimentation</h3>
            <p>Accelerate learning with scenario planning, data prototypes, and automation pilots grounded in evidence.</p>
          </article>
          <article>
            <h3>Trusted governance</h3>
            <p>Embed decision frameworks and oversight models that keep AI and automation accountable.</p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default Services;