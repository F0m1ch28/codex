```javascript
import React, { useState } from 'react';
import styles from './FAQAccordion.module.css';

const FAQAccordion = ({ items }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  const handleToggle = (index) => {
    setActiveIndex((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.accordion}>
      {items.map((item, index) => {
        const isActive = activeIndex === index;
        return (
          <div className={`${styles.item} ${isActive ? styles.itemActive : ''}`} key={item.question}>
            <button
              className={styles.trigger}
              onClick={() => handleToggle(index)}
              aria-expanded={isActive}
            >
              <span>{item.question}</span>
              <span className={styles.icon}>{isActive ? '−' : '+'}</span>
            </button>
            <div
              className={`${styles.panel} ${isActive ? styles.panelOpen : ''}`}
              role="region"
              aria-hidden={!isActive}
            >
              <p>{item.answer}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default FAQAccordion;
```