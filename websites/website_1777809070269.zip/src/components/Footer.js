```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.columnWide}>
          <h3 className={styles.brand}>
            <span>Gambling</span>Insight
          </h3>
          <p className={styles.description}>
            GamblingInsight — независимый информационный ресурс для ответственного выбора онлайн-казино.
            Мы анализируем лицензии, механики бонусов, обслуживание и реальные отзывы, помогая игрокам
            принимать взвешенные решения без иллюзий лёгкого заработка.
          </p>
          <p className={styles.disclaimer}>
            Мы не являемся оператором азартных игр, не принимаем платежи и не предоставляем гарантии выигрышей.
            Помните, что азартные игры доступны только совершеннолетним пользователям и сопряжены с риском.
          </p>
        </div>
        <div className={styles.column}>
          <h4>Навигация</h4>
          <ul>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/compare">Сравнение казино</Link></li>
            <li><Link to="/services">Наши сервисы</Link></li>
            <li><Link to="/responsible-gaming">Ответственная игра</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Правовые документы</h4>
          <ul>
            <li><Link to="/privacy-policy">Политика конфиденциальности</Link></li>
            <li><Link to="/terms-of-service">Условия использования</Link></li>
            <li><Link to="/cookie-policy">Политика Cookie</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Контакты</h4>
          <ul>
            <li>Email: <a href="mailto:info@gambling-insight.com">info@gambling-insight.com</a></li>
            <li>Поддержка: support@gambling-insight.com</li>
            <li>Коллаборации: media@gambling-insight.com</li>
            <li>
              Социальные сети:
              <div className={styles.socials}>
                <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">LinkedIn</a>
                <a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Telegram">Telegram</a>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {currentYear} GamblingInsight. Все права защищены.</span>
        <Link to="/responsible-gaming" className={styles.responsibleLink}>
          Играйте ответственно
        </Link>
      </div>
    </footer>
  );
};

export default Footer;
```