```javascript
import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('gi-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('gi-cookie-consent', 'accepted');
    setVisible(false);
  };

  const handleManage = () => {
    window.localStorage.setItem('gi-cookie-consent', 'customized');
    alert('Вы можете обновить свои настройки cookie в разделе «Политика Cookie».');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h3>Мы ценим вашу конфиденциальность</h3>
        <p>
          Мы используем только необходимые и аналитические cookie-файлы, чтобы улучшить работу сайта. Вы можете
          принять все cookie или настроить их использование вручную. Подробнее — в{' '}
          <a href="/cookie-policy">Политике Cookie</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button className={styles.primary} onClick={handleAccept}>
          Принять все
        </button>
        <button className={styles.secondary} onClick={handleManage}>
          Настроить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```