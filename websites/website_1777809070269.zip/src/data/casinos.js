```javascript
const casinos = [
  {
    slug: 'crown-casino',
    name: 'Crown Casino',
    logo: 'https://picsum.photos/160/160?random=201',
    rating: 9.4,
    bonusSummary: '100% до €500 + 200 фриспинов',
    bonusSummaryShort: '100% + 200 фриспинов',
    wageringDisplay: 'x35 на бонус и фриспины',
    withdrawalSpeed: 'До 24 часов',
    regionFocus: 'Лицензия MGA, игроки ЕС',
    reviewSummary:
      'Crown Casino сочетает гибкую бонусную политику с мощной платформой для мгновенных выплат. Оператор работает по лицензии MGA, регулярно проходит аудит RNG и тщательно модерирует программы лояльности. Бонусы доступны без скрытых ограничений, однако требуют подтверждения личности до первого вывода.',
    bonusDetails: [
      {
        name: 'Приветственный пакет',
        description: '100% до €500 + 200 фриспинов на Starburst (20 в день)',
        wagering: 'x35',
        maxCashout: '€2 000',
        expiry: '14 дней'
      },
      {
        name: 'Бездепозитный бонус',
        description: '€10 на аккаунт после верификации',
        wagering: 'x45',
        maxCashout: '€100',
        expiry: '7 дней'
      },
      {
        name: 'Фриспины по выходным',
        description: '50 фриспинов за депозит от €30 по пятницам',
        wagering: 'x30',
        maxCashout: '€300',
        expiry: '3 дня'
      }
    ],
    wageringRules: [
      'Максимальная ставка при отыгрыше — €5.',
      'Только слоты вносят 100% в отыгрыш, настольные игры — 15%, live-казино — 10%.',
      'Бонусы активны только после подтверждения личности и адреса.',
      'Выигрыши из фриспинов зачисляются на бонусный баланс и требуют отыгрыша.',
      'Оператор оставляет за собой право отменить бонус при подозрении на азартную зависимость.'
    ],
    paymentMethods: [
      { method: 'Visa/Mastercard', deposit: 'Да', withdrawal: 'Да', limits: '€10-€4 000', fee: '0%', speed: '1-3 дня' },
      { method: 'Skrill/Neteller', deposit: 'Да', withdrawal: 'Да', limits: '€10-€5 000', fee: '0%', speed: 'До 12 часов' },
      { method: 'Trustly', deposit: 'Да', withdrawal: 'Да', limits: '€20-€10 000', fee: '0%', speed: 'До 24 часов' },
      { method: 'Криптовалюта', deposit: 'Да', withdrawal: 'Да', limits: '€50-€15 000', fee: '0%', speed: 'Мгновенно' }
    ],
    providers: ['NetEnt', 'Playtech', 'Pragmatic Play', 'Evolution', 'Yggdrasil', 'NoLimit City'],
    games: ['Слоты', 'Живое казино', 'Рулетка', 'Покер', 'Крэпс'],
    support: {
      email: 'support@crowncasino.com',
      chat: '24/7',
      phone: '+356 000 123',
      hours: 'Круглосуточно'
    },
    metrics: {
      bonusScore: 95,
      bonusDescription: '100% до €500 + 200 FS',
      wageringRequirement: 35,
      withdrawalTimeHours: 24,
      withdrawalLabel: 'До 24 часов',
      maxWithdrawalPerWeek: 5000,
      gameLibraryScore: 94
    }
  },
  {
    slug: 'mystic-slots',
    name: 'Mystic Slots',
    logo: 'https://picsum.photos/160/160?random=202',
    rating: 9.1,
    bonusSummary: '150% до €300 + 100 фриспинов',
    bonusSummaryShort: '150% + 100 фриспинов',
    wageringDisplay: 'x30 на бонус, x35 на фриспины',
    withdrawalSpeed: 'До 36 часов',
    regionFocus: 'Лицензия Curacao, международный доступ',
    reviewSummary:
      'Mystic Slots ориентирован на любителей слотов и предлагает быструю регистрацию с минимальными препятствиями. Бонусная программа щедра, однако важно внимательно читать ограничения по играм. Платформа поддерживает криптовалюту и предоставляет детальные отчёты об RTP.',
    bonusDetails: [
      {
        name: 'Приветственный бонус',
        description: '150% до €300 + 100 фриспинов на Gates of Olympus',
        wagering: 'x30',
        maxCashout: '€1 500',
        expiry: '10 дней'
      },
      {
        name: 'Еженедельный кэшбек',
        description: '10% кэшбека от чистых проигрышей в слотах',
        wagering: 'x10',
        maxCashout: 'Без ограничений',
        expiry: '7 дней'
      },
      {
        name: 'Турнирные очки',
        description: 'Победы в слотах начисляют баллы для розыгрыша €10 000',
        wagering: 'Без отыгрыша',
        maxCashout: '€10 000',
        expiry: 'По расписанию'
      }
    ],
    wageringRules: [
      'Максимальная ставка при отыгрыше — €4.',
      'Вывод бонусных средств доступен только после завершения верификации.',
      'Игры с джекпотом не учитываются в отыгрыше.',
      'Фриспины активируются в течение 24 часов после депозита.',
      'Бонусы недоступны при депозите через Neteller и Skrill.'
    ],
    paymentMethods: [
      { method: 'Visa/Mastercard', deposit: 'Да', withdrawal: 'Да', limits: '€20-€2 500', fee: '0%', speed: '2-4 дня' },
      { method: 'MuchBetter', deposit: 'Да', withdrawal: 'Да', limits: '€20-€3 000', fee: '0%', speed: 'До 24 часов' },
      { method: 'Bitcoin/Ethereum', deposit: 'Да', withdrawal: 'Да', limits: '€40-€10 000', fee: '0%', speed: 'Мгновенно' },
      { method: 'Bank Transfer', deposit: 'Нет', withdrawal: 'Да', limits: '€50-€5 000', fee: '0%', speed: '2-5 дней' }
    ],
    providers: ['Pragmatic Play', 'Quickspin', 'Thunderkick', 'Red Tiger', 'ELK Studios'],
    games: ['Слоты', 'Мгновенные игры', 'Рулетка', 'Кено'],
    support: {
      email: 'help@mysticslots.com',
      chat: '08:00-02:00 CET',
      phone: null,
      hours: 'Русскоязычный чат с 10:00 до 22:00 МСК'
    },
    metrics: {
      bonusScore: 92,
      bonusDescription: '150% до €300 + 100 FS',
      wageringRequirement: 30,
      withdrawalTimeHours: 36,
      withdrawalLabel: 'До 36 часов',
      maxWithdrawalPerWeek: 4000,
      gameLibraryScore: 90
    }
  },
  {
    slug: 'gold-rush',
    name: 'Gold Rush',
    logo: 'https://picsum.photos/160/160?random=203',
    rating: 8.9,
    bonusSummary: '100 фриспинов без депозита',
    bonusSummaryShort: '100 фриспинов без депозита',
    wageringDisplay: 'x45 на выигрыш из фриспинов',
    withdrawalSpeed: 'До 48 часов',
    regionFocus: 'Лицензия UKGC, игроки Великобритании',
    reviewSummary:
      'Gold Rush ориентирован на игроков из Великобритании и строго соблюдает правила UKGC. Бесплатные фриспины без депозита доступны после верификации личности. Казино активно продвигает ответственный подход, предлагая подробные инструменты самоограничения и проверки реальности.',
    bonusDetails: [
      {
        name: 'Безопасный старт',
        description: '100 фриспинов без депозита на Book of Dead',
        wagering: 'x45',
        maxCashout: '£100',
        expiry: '3 дня'
      },
      {
        name: 'Приветственный пакет',
        description: '100% до £200 + 50 фриспинов на Big Bass Bonanza',
        wagering: 'x35',
        maxCashout: '£2 500',
        expiry: '14 дней'
      },
      {
        name: 'Дневные миссии',
        description: 'Задания на слоты с мгновенными призами до £500',
        wagering: 'Без отыгрыша',
        maxCashout: '£500',
        expiry: '1 день'
      }
    ],
    wageringRules: [
      'Максимальная ставка при отыгрыше — £4.',
      'Слоты с RTP выше 97% учитываются только на 50%.',
      'Игрок обязан подтверждать адрес проживания документом.',
      'Кэшбек не имеет вейджера, но должен быть использован в течение 7 дней.',
      'Использование VPN запрещено и ведет к блокировке бонусов.'
    ],
    paymentMethods: [
      { method: 'Visa/Mastercard', deposit: 'Да', withdrawal: 'Да', limits: '£10-£2 000', fee: '0%', speed: '1-3 дня' },
      { method: 'PayPal', deposit: 'Да', withdrawal: 'Да', limits: '£10-£5 000', fee: '0%', speed: 'До 24 часов' },
      { method: 'PaySafeCard', deposit: 'Да', withdrawal: 'Нет', limits: '£10-£200', fee: '0%', speed: '—' },
      { method: 'Bank Transfer', deposit: 'Нет', withdrawal: 'Да', limits: '£20-£10 000', fee: '0%', speed: '2-5 дней' }
    ],
    providers: ['Playtech', 'Microgaming', 'Blueprint', 'Evolution', 'Play\'n GO'],
    games: ['Слоты', 'Live-игры', 'Баккара', 'Монополия Live'],
    support: {
      email: 'care@goldrush.co.uk',
      chat: '24/7',
      phone: '+44 20 0000 1234',
      hours: 'Круглосуточно, английский'
    },
    metrics: {
      bonusScore: 90,
      bonusDescription: '100 FS без депозита',
      wageringRequirement: 45,
      withdrawalTimeHours: 48,
      withdrawalLabel: 'До 48 часов',
      maxWithdrawalPerWeek: 3000,
      gameLibraryScore: 88
    }
  },
  {
    slug: 'spinin-palace',
    name: 'Spinin Palace',
    logo: 'https://picsum.photos/160/160?random=204',
    rating: 9.2,
    bonusSummary: 'До €1 000 на три первых депозита',
    bonusSummaryShort: '€1 000 на три депозита',
    wageringDisplay: 'x32 на бонус',
    withdrawalSpeed: 'До 18 часов',
    regionFocus: 'Лицензия Kahnawake, глобально',
    reviewSummary:
      'Spinin Palace привлекает игроков, ценящих быстрые выплаты и разнообразие живых игр. Программа лояльности построена на прогрессивных уровнях с личными менеджерами. Казино внедрило расширенную проверку транзакций, что повышает безопасность, но требует дополнительного времени на первую выплату.',
    bonusDetails: [
      {
        name: 'Депозит №1',
        description: '100% до €400 на первый депозит',
        wagering: 'x32',
        maxCashout: '€4 000',
        expiry: '14 дней'
      },
      {
        name: 'Депозит №2',
        description: '50% до €300',
        wagering: 'x32',
        maxCashout: '€3 000',
        expiry: '14 дней'
      },
      {
        name: 'Депозит №3',
        description: '50% до €300',
        wagering: 'x32',
        maxCashout: '€3 000',
        expiry: '14 дней'
      }
    ],
    wageringRules: [
      'Максимальная ставка при отыгрыше — €6.',
      'В отыгрыш не засчитываются ставки на игры с живыми дилерами.',
      'Фриспины доступны только после подтверждения телефона.',
      'Проверка документов может занять до 48 часов.',
      'Каждая бонусная стадия активируется только после ввода соответствующего промокода.'
    ],
    paymentMethods: [
      { method: 'Visa/Mastercard', deposit: 'Да', withdrawal: 'Да', limits: '€20-€3 000', fee: '0%', speed: '1-2 дня' },
      { method: 'EcoPayz', deposit: 'Да', withdrawal: 'Да', limits: '€20-€5 000', fee: '0%', speed: 'До 12 часов' },
      { method: 'Interac', deposit: 'Да', withdrawal: 'Да', limits: '€10-€3 000', fee: '0%', speed: 'До 24 часов' },
      { method: 'Криптовалюта', deposit: 'Да', withdrawal: 'Да', limits: '€50-€12 000', fee: '0%', speed: 'Мгновенно' }
    ],
    providers: ['Evolution', 'Playtech', 'Habanero', 'Betsoft', 'Push Gaming'],
    games: ['Слоты', 'Блэкджек', 'Живое казино', 'Кости', 'Виртуальный спорт'],
    support: {
      email: 'care@spininpalace.com',
      chat: '24/7',
      phone: '+1 800 555 019',
      hours: 'Круглосуточно, EN/DE'
    },
    metrics: {
      bonusScore: 94,
      bonusDescription: '€1 000 на 3 депозита',
      wageringRequirement: 32,
      withdrawalTimeHours: 18,
      withdrawalLabel: 'До 18 часов',
      maxWithdrawalPerWeek: 6000,
      gameLibraryScore: 96
    }
  },
  {
    slug: 'aurora-bet',
    name: 'Aurora Bet',
    logo: 'https://picsum.photos/160/160?random=205',
    rating: 8.7,
    bonusSummary: '€20 страховки проигрыша + кэшбек',
    bonusSummaryShort: 'Страховка €20 + кэшбек',
    wageringDisplay: 'x20 на страховку',
    withdrawalSpeed: 'До 72 часов',
    regionFocus: 'Лицензия Curacao, акцент на скандинавский рынок',
    reviewSummary:
      'Aurora Bet предлагает гибридный продукт с казино и ставками. Главная особенность — страховка первого проигрыша и циклические турниры. Вывод средств может занимать до 72 часов, однако поддержка оперативно информирует о статусе заявки.',
    bonusDetails: [
      {
        name: 'Страховка старта',
        description: 'Возврат до €20 при первом проигрыше',
        wagering: 'x20',
        maxCashout: '€500',
        expiry: '7 дней'
      },
      {
        name: 'Еженедельный кэшбек',
        description: '5-15% на чистые проигрыши в казино',
        wagering: 'x10',
        maxCashout: '€2 000',
        expiry: '7 дней'
      },
      {
        name: 'Слот-турниры',
        description: 'Призы до €15 000 каждые две недели',
        wagering: 'Без отыгрыша',
        maxCashout: '€15 000',
        expiry: 'По расписанию'
      }
    ],
    wageringRules: [
      'Максимальная ставка при отыгрыше — €5.',
      'Вейджер на страховку применяется только к сумме возврата.',
      'Игры live-казино не учитываются при отыгрыше бонусов.',
      'Кэшбек начисляется в понедельник и действует 7 дней.',
      'Нельзя одновременно активировать два бонуса.'
    ],
    paymentMethods: [
      { method: 'Visa/Mastercard', deposit: 'Да', withdrawal: 'Да', limits: '€20-€2 500', fee: '0%', speed: '2-3 дня' },
      { method: 'Skrill', deposit: 'Да', withdrawal: 'Да', limits: '€10-€3 000', fee: '0%', speed: 'До 48 часов' },
      { method: 'Trustly', deposit: 'Да', withdrawal: 'Да', limits: '€20-€5 000', fee: '0%', speed: 'До 36 часов' },
      { method: 'Bank Transfer', deposit: 'Нет', withdrawal: 'Да', limits: '€50-€7 000', fee: '0%', speed: '3-5 дней' }
    ],
    providers: ['NetEnt', 'Thunderkick', 'Play\'n GO', 'Relax Gaming', 'Evolution'],
    games: ['Слоты', 'Live-игры', 'Ставки на спорт', 'Виртуальные виды спорта'],
    support: {
      email: 'support@aurorabet.com',
      chat: '09:00-01:00 CET',
      phone: null,
      hours: 'Поддержка на английском и финском'
    },
    metrics: {
      bonusScore: 88,
      bonusDescription: 'Страховка €20 + кэшбек',
      wageringRequirement: 20,
      withdrawalTimeHours: 72,
      withdrawalLabel: 'До 72 часов',
      maxWithdrawalPerWeek: 3500,
      gameLibraryScore: 85
    }
  }
];

export default casinos;
```