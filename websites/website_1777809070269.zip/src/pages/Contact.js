```javascript
import React, { useState } from 'react';

const initialForm = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Укажите имя или название проекта.';
    if (!form.email.trim()) {
      newErrors.email = 'Введите рабочий email.';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(form.email)) {
      newErrors.email = 'Проверьте корректность email.';
    }
    if (form.message.trim().length < 20) {
      newErrors.message = 'Расскажите подробнее о запросе (минимум 20 символов).';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setForm(initialForm);
    }
  };

  return (
    <div className="page">
      <section className="section contact-hero">
        <div className="section-header">
          <span className="badge">Контакты</span>
          <h1 className="section-title">Свяжитесь с GamblingInsight</h1>
          <p className="section-subtitle">
            Ответим на вопросы о наших обзорах, обсудим партнерство или примем предложения по улучшению контента.
            Мы не обрабатываем запросы на поддержку конкретных казино.
          </p>
        </div>
      </section>

      <section className="section contact-section">
        <div className="contact-wrapper">
          <div className="contact-card">
            <h2>Контактная информация</h2>
            <ul>
              <li>
                Общие вопросы: <a href="mailto:info@gambling-insight.com">info@gambling-insight.com</a>
              </li>
              <li>
                Медиа и исследования: <a href="mailto:media@gambling-insight.com">media@gambling-insight.com</a>
              </li>
              <li>
                Техническая поддержка: <a href="mailto:support@gambling-insight.com">support@gambling-insight.com</a>
              </li>
              <li>Мы отвечаем в течение 24 часов в рабочие дни.</li>
            </ul>
            <p className="contact-note">
              Пожалуйста, не отправляйте конфиденциальные данные. Мы не запрашиваем платежную информацию и пароли.
            </p>
          </div>

          <div className="contact-form-card">
            <h2>Написать нам</h2>
            {submitted ? (
              <div className="form-success">
                <h3>Спасибо за обращение!</h3>
                <p>
                  Мы получили ваше сообщение и постараемся ответить в течение одного рабочего дня. Если нужно срочно —
                  напишите напрямую на info@gambling-insight.com.
                </p>
                <button className="btn btn-outline" onClick={() => setSubmitted(false)}>
                  Отправить новый запрос
                </button>
              </div>
            ) : (
              <form className="contact-form" onSubmit={handleSubmit} noValidate>
                <label>
                  Имя / Компания*
                  <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                  />
                  {errors.name && <span className="error-text">{errors.name}</span>}
                </label>
                <label>
                  Email*
                  <input
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                  />
                  {errors.email && <span className="error-text">{errors.email}</span>}
                </label>
                <label>
                  Компания / Организация
                  <input
                    type="text"
                    name="company"
                    value={form.company}
                    onChange={handleChange}
                  />
                </label>
                <label>
                  Сообщение*
                  <textarea
                    name="message"
                    rows="5"
                    value={form.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                  />
                  {errors.message && <span className="error-text">{errors.message}</span>}
                </label>
                <button type="submit" className="btn btn-primary">
                  Отправить
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```