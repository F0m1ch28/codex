```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { teamMembers, values, milestones } from '../data/siteContent';

const About = () => {
  return (
    <div className="page">
      <section className="section about-hero">
        <div className="section-header">
          <span className="badge">О проекте</span>
          <h1 className="section-title">Миссия GamblingInsight</h1>
          <p className="section-subtitle">
            Мы создаём комплексные обзоры онлайн-казино, ориентируясь на прозрачность и контроль рисков.
            Команда объединяет профессиональных аналитиков, юристов по азартным играм и журналистов.
          </p>
        </div>
      </section>

      <section className="section about-values">
        <h2 className="section-title">Наши принципы</h2>
        <div className="values-grid">
          {values.map((value) => (
            <article key={value.title} className="value-card">
              <span className="value-icon" aria-hidden="true">{value.icon}</span>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section about-milestones">
        <h2 className="section-title">Ключевые этапы развития</h2>
        <div className="timeline">
          {milestones.map((item) => (
            <div key={item.year} className="timeline-item">
              <span className="timeline-year">{item.year}</span>
              <div className="timeline-content">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="section about-team">
        <h2 className="section-title">Редакция и аналитики</h2>
        <div className="team-grid">
          {teamMembers.map((member) => (
            <article key={member.name} className="team-card">
              <img src={member.photo} alt={member.name} loading="lazy" />
              <h3>{member.name}</h3>
              <p className="team-role">{member.position}</p>
              <p>{member.bio}</p>
              <a href={member.linkedin} target="_blank" rel="noopener noreferrer">
                LinkedIn
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="section about-cta">
        <div className="cta-card">
          <h2>Хотите сотрудничать или предложить тему расследования?</h2>
          <p>
            Наша редакция открыта к партнерским исследованиям и интервью. Напишите на{' '}
            <a href="mailto:media@gambling-insight.com">media@gambling-insight.com</a> или заполните контактную форму.
          </p>
          <Link to="/contact" className="btn btn-primary">
            Связаться с нами
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;
```