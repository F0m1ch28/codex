```javascript
import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import faqData from '../data/faq';
import {
  statsData,
  processSteps,
  advantageList,
  serviceHighlights,
  testimonials,
  teamMembers,
  projectGallery,
  blogPosts
} from '../data/siteContent';
import FAQAccordion from '../components/FAQAccordion';

const Home = () => {
  const sortedCasinos = useMemo(() => {
    return [...casinos].sort((a, b) => b.rating - a.rating);
  }, []);
  const topCasinos = sortedCasinos.slice(0, 3);
  const tableCasinos = sortedCasinos.slice(0, 6);

  const [counterValues, setCounterValues] = useState(statsData.map(() => 0));

  useEffect(() => {
    const intervals = statsData.map((item, index) => {
      const target = item.value;
      const step = Math.max(1, Math.floor(target / 60));
      return setInterval(() => {
        setCounterValues((prev) => {
          const updated = [...prev];
          if (updated[index] < target) {
            updated[index] = Math.min(target, updated[index] + step);
          }
          return updated;
        });
      }, 30);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setActiveTestimonial((prev) => (prev + 1) % testimonials.length),
      6500
    );
    return () => clearInterval(timer);
  }, []);

  const categories = useMemo(
    () => ['Все', ...new Set(projectGallery.map((item) => item.category))],
    []
  );
  const [activeCategory, setActiveCategory] = useState(categories[0]);

  const handleFilterChange = useCallback((category) => {
    setActiveCategory(category);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Все') {
      return projectGallery;
    }
    return projectGallery.filter((item) => item.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className="page">
      <section className="hero">
        <div className="hero-overlay" />
        <div className="hero-content">
          <p className="hero-tagline">Аналитика онлайн-казино для взвешенных решений</p>
          <h1>
            Обзоры и сравнения лучших онлайн-казино
            <span className="accent"> с ответственным подходом</span>
          </h1>
          <p className="hero-subtitle">
            GamblingInsight исследует лицензии, бонусные предложения, платежные системы и реальный опыт игроков.
            Никаких агрессивных обещаний — только проверенные данные, прозрачные условия и инструменты для
            осознанного выбора.
          </p>
          <div className="hero-buttons">
            <Link to="/compare" className="btn btn-primary">
              Смотреть рейтинг
            </Link>
            <a
              className="btn btn-outline"
              href="#responsibility"
            >
              Ответственная игра
            </a>
          </div>
        </div>
        <div
          className="hero-visual"
          style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=101)' }}
          aria-hidden="true"
        />
      </section>

      <section className="section stats-section">
        <div className="section-header">
          <span className="badge">Статистика</span>
          <h2 className="section-title">Что уже сделано для сообщества игроков</h2>
          <p className="section-subtitle">
            Мы собираем и анализируем данные вручную, проводим интервью и регулярно обновляем обзоры,
            чтобы комплексно оценивать индустрию онлайн-гейминга.
          </p>
        </div>
        <div className="stats-grid">
          {statsData.map((item, index) => (
            <article key={item.label} className="stat-card" aria-live="polite">
              <h3>
                {counterValues[index]}
                {item.suffix}
              </h3>
              <p>{item.label}</p>
              <span>{item.description}</span>
            </article>
          ))}
        </div>
      </section>

      <section className="section top-casinos-section">
        <div className="section-header">
          <span className="badge">Топ офферов</span>
          <h2 className="section-title">Лучшие 3 казино недели</h2>
          <p className="section-subtitle">
            Выбор основан на лицензиях, честности условий бонусов и скорости выплат.
            Все значения рейтинга пересчитываются каждую неделю.
          </p>
        </div>
        <div className="top-casino-grid">
          {topCasinos.map((casino) => (
            <article key={casino.slug} className="casino-card">
              <div className="casino-card-top">
                <img src={casino.logo} alt={`Логотип ${casino.name}`} className="casino-logo" loading="lazy" />
                <div>
                  <h3>{casino.name}</h3>
                  <p>{casino.regionFocus}</p>
                </div>
                <span className="rating-badge" aria-label={`Рейтинг ${casino.rating}`}>
                  {casino.rating.toFixed(1)}
                </span>
              </div>
              <ul className="casino-meta">
                <li><strong>Бонус:</strong> {casino.bonusSummary}</li>
                <li><strong>Вейджер:</strong> {casino.wageringDisplay}</li>
                <li><strong>Выплаты:</strong> {casino.withdrawalSpeed}</li>
              </ul>
              <div className="card-actions">
                <Link to={`/casino/${casino.slug}`} className="btn btn-secondary">
                  Подробнее
                </Link>
                <Link to="/compare" className="text-link">
                  Сравнить
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section advantages-section">
        <div className="section-header">
          <span className="badge">Почему доверяют</span>
          <h2 className="section-title">Преимущества GamblingInsight</h2>
        </div>
        <div className="advantages-grid">
          {advantageList.map((item) => (
            <article key={item.title} className="adv-card">
              <span className="adv-icon" aria-hidden="true">{item.icon}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section table-section">
        <div className="section-header">
          <span className="badge">Обзорная таблица</span>
          <h2 className="section-title">Сравнение основных показателей</h2>
          <p className="section-subtitle">
            Реальные условия бонусов и выводов помогают оценить, подходит ли казино вашему игровому стилю.
            Значения в таблице обновлены {new Date().toLocaleDateString('ru-RU')}.
          </p>
        </div>
        <div className="table-wrapper">
          <table className="comparison-table">
            <thead>
              <tr>
                <th>Казино</th>
                <th>Бонус</th>
                <th>Условия отыгрыша</th>
                <th>Рейтинг</th>
              </tr>
            </thead>
            <tbody>
              {tableCasinos.map((casino) => (
                <tr key={casino.slug}>
                  <td>
                    <Link to={`/casino/${casino.slug}`} className="table-casino-link">
                      {casino.name}
                    </Link>
                  </td>
                  <td>{casino.bonusSummary}</td>
                  <td>{casino.wageringDisplay}</td>
                  <td>{casino.rating.toFixed(1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section methodology-section">
        <div className="section-header">
          <span className="badge">Методология</span>
          <h2 className="section-title">Как мы оцениваем казино</h2>
        </div>
        <div className="methodology-grid">
          {processSteps.map((step) => (
            <article key={step.title} className="method-card">
              <span className="method-step">{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section services-highlight-section">
        <div className="section-header">
          <span className="badge">Наши сервисы</span>
          <h2 className="section-title">Что мы делаем для читателей</h2>
        </div>
        <div className="service-highlight-grid">
          {serviceHighlights.map((service) => (
            <article key={service.title} className="service-card">
              <div className="service-icon" aria-hidden="true">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to={service.link} className="text-link">
                Узнать больше
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="section responsibility-section" id="responsibility">
        <div className="responsibility-card">
          <h2>Ответственная игра на первом месте</h2>
          <p>
            Азартные игры — это развлечение, а не способ заработка. Мы призываем устанавливать личные лимиты,
            следить за эмоциями и обращаться за помощью при первых признаках зависимости. Всегда проверяйте возрастные
            ограничения вашей юрисдикции.
          </p>
          <ul>
            <li>Установите дневные и недельные лимиты до начала игры.</li>
            <li>Следите за временем и избегайте игры в состоянии стресса.</li>
            <li>Используйте инструменты самоисключения и проверки реальности.</li>
            <li>
              Посетите <a href="https://www.gamblersanonymous.org" target="_blank" rel="noopener noreferrer">Gamblers Anonymous</a> или{' '}
              <a href="https://www.begambleaware.org" target="_blank" rel="noopener noreferrer">BeGambleAware</a> за профессиональной поддержкой.
            </li>
          </ul>
          <Link to="/responsible-gaming" className="btn btn-outline-light">
            Узнать о программах помощи
          </Link>
        </div>
      </section>

      <section className="section testimonials-section">
        <div className="section-header">
          <span className="badge">Отзывы</span>
          <h2 className="section-title">Эксперты и читатели о GamblingInsight</h2>
        </div>
        <div className="testimonials">
          {testimonials.map((item, index) => (
            <article
              key={item.name}
              className={`testimonial-card ${index === activeTestimonial ? 'active' : ''}`}
              aria-hidden={index !== activeTestimonial}
            >
              <div className="testimonial-header">
                <img src={item.avatar} alt={`Фото ${item.name}`} loading="lazy" />
                <div>
                  <h3>{item.name}</h3>
                  <p>{item.role} · {item.company}</p>
                </div>
              </div>
              <p className="testimonial-quote">“{item.quote}”</p>
            </article>
          ))}
          <div className="testimonial-nav" role="tablist">
            {testimonials.map((item, index) => (
              <button
                key={item.name}
                className={index === activeTestimonial ? 'dot active' : 'dot'}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Показать отзыв ${item.name}`}
                aria-current={index === activeTestimonial}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section team-section">
        <div className="section-header">
          <span className="badge">Команда</span>
          <h2 className="section-title">Аналитики и редакторы ресурса</h2>
        </div>
        <div className="team-grid">
          {teamMembers.map((member) => (
            <article key={member.name} className="team-card">
              <img src={member.photo} alt={member.name} loading="lazy" />
              <h3>{member.name}</h3>
              <p className="team-role">{member.position}</p>
              <p>{member.bio}</p>
              <a href={member.linkedin} target="_blank" rel="noopener noreferrer">
                LinkedIn профиль
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="section projects-section">
        <div className="section-header">
          <span className="badge">Исследования</span>
          <h2 className="section-title">Проекты и аналитические материалы</h2>
        </div>
        <div className="project-filters" role="tablist">
          {categories.map((category) => (
            <button
              key={category}
              className={activeCategory === category ? 'filter-button active' : 'filter-button'}
              onClick={() => handleFilterChange(category)}
              aria-pressed={activeCategory === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="project-grid">
          {filteredProjects.map((project) => (
            <article key={project.title} className="project-card">
              <div
                className="project-image"
                style={{ backgroundImage: `url(${project.image})` }}
                role="img"
                aria-label={project.alt}
              />
              <div className="project-card-body">
                <span className="project-category">{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <Link to={project.link} className="text-link">
                  Читать анализ
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section articles-section">
        <div className="section-header">
          <span className="badge">Свежие статьи</span>
          <h2 className="section-title">Обзоры и аналитические материалы</h2>
        </div>
        <div className="article-grid">
          {blogPosts.map((article) => (
            <article key={article.title} className="article-card">
              <span className="article-date">{article.date}</span>
              <h3>{article.title}</h3>
              <p>{article.excerpt}</p>
              <Link to={article.link} className="text-link">
                Читать далее
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="section faq-section">
        <div className="section-header">
          <span className="badge">FAQ</span>
          <h2 className="section-title">Часто задаваемые вопросы</h2>
          <p className="section-subtitle">
            Ответы подготовлены редакторами GamblingInsight. Для дополнительной информации свяжитесь с нами по email.
          </p>
        </div>
        <FAQAccordion items={faqData} />
      </section>

      <section className="section cta-section">
        <div className="cta-card">
          <h2>Готовы сравнить бонусы и условия?</h2>
          <p>
            Перейдите к интерактивному сравнению казино, чтобы увидеть отличия по вейджеру, скорости выплат и лимитам.
            Мы обновляем данные регулярно и отмечаем лучшие предложения в каждой категории.
          </p>
          <div className="cta-buttons">
            <Link to="/compare" className="btn btn-primary">
              Перейти к сравнению
            </Link>
            <Link to="/services" className="btn btn-outline">
              Посмотреть сервисы
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
```