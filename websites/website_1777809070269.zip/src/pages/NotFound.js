```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => (
  <div className="page">
    <section className="section">
      <div className="legal-container">
        <h1>Страница не найдена</h1>
        <p>Похоже, запрошенный вами ресурс перемещён или временно недоступен.</p>
        <Link to="/" className="btn btn-primary">
          На главную
        </Link>
      </div>
    </section>
  </div>
);

export default NotFound;
```