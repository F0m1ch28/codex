```javascript
import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';

const Compare = () => {
  const selectedCasinos = casinos.slice(0, 4);

  const bestMetrics = useMemo(() => {
    const bonusMax = Math.max(...selectedCasinos.map((casino) => casino.metrics.bonusScore));
    const wageringMin = Math.min(...selectedCasinos.map((casino) => casino.metrics.wageringRequirement));
    const payoutMin = Math.min(...selectedCasinos.map((casino) => casino.metrics.withdrawalTimeHours));
    const limitMax = Math.max(...selectedCasinos.map((casino) => casino.metrics.maxWithdrawalPerWeek));
    const gamesMax = Math.max(...selectedCasinos.map((casino) => casino.metrics.gameLibraryScore));
    return { bonusMax, wageringMin, payoutMin, limitMax, gamesMax };
  }, [selectedCasinos]);

  return (
    <div className="page">
      <section className="section compare-hero">
        <div className="section-header">
          <span className="badge">Сравнение</span>
          <h1 className="section-title">Сверка бонусов и условий казино</h1>
          <p className="section-subtitle">
            Подробно сравните ключевые метрики: размер бонуса, требования к отыгрышу, скорость выплат,
            лимиты и разнообразие игр. Мы выделяем лидеров в каждой категории.
          </p>
        </div>
      </section>

      <section className="section compare-table-section">
        <div className="table-wrapper">
          <table className="comparison-table">
            <thead>
              <tr>
                <th>Казино</th>
                <th>Бонусный пакет</th>
                <th>Вейджер</th>
                <th>Скорость вывода</th>
                <th>Лимиты</th>
                <th>Ассортимент игр</th>
              </tr>
            </thead>
            <tbody>
              {selectedCasinos.map((casino) => {
                const bonusHighlight = casino.metrics.bonusScore === bestMetrics.bonusMax;
                const wageringHighlight = casino.metrics.wageringRequirement === bestMetrics.wageringMin;
                const payoutHighlight = casino.metrics.withdrawalTimeHours === bestMetrics.payoutMin;
                const limitHighlight = casino.metrics.maxWithdrawalPerWeek === bestMetrics.limitMax;
                const gamesHighlight = casino.metrics.gameLibraryScore === bestMetrics.gamesMax;

                return (
                  <tr key={casino.slug}>
                    <td>
                      <Link to={`/casino/${casino.slug}`} className="table-casino-link">
                        {casino.name}
                      </Link>
                    </td>
                    <td className={bonusHighlight ? 'table-highlight' : ''}>
                      {casino.metrics.bonusDescription}
                    </td>
                    <td className={wageringHighlight ? 'table-highlight' : ''}>
                      x{casino.metrics.wageringRequirement}
                    </td>
                    <td className={payoutHighlight ? 'table-highlight' : ''}>
                      {casino.metrics.withdrawalLabel}
                    </td>
                    <td className={limitHighlight ? 'table-highlight' : ''}>
                      до €{casino.metrics.maxWithdrawalPerWeek.toLocaleString('ru-RU')}
                    </td>
                    <td className={gamesHighlight ? 'table-highlight' : ''}>
                      {casino.metrics.gameLibraryScore} / 100
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <p className="compare-note">
          Данные представлены в евро для удобства сравнения и приведены к усреднённым значениям. Уточняйте локальную
          валюту и ограничения вашей юрисдикции на сайте оператора.
        </p>
      </section>
    </div>
  );
};

export default Compare;
```