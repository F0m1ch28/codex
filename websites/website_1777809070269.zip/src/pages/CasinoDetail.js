```javascript
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import casinos from '../data/casinos';

const CasinoDetail = () => {
  const { slug } = useParams();
  const casino = casinos.find((item) => item.slug === slug);

  if (!casino) {
    return (
      <div className="page">
        <section className="section">
          <div className="legal-container">
            <h1>Казино не найдено</h1>
            <p>Похоже, что запрошенная страница недоступна или была обновлена.</p>
            <Link to="/compare" className="btn btn-primary">
              Перейти к сравнению
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page">
      <section className="section casino-hero">
        <div className="casino-hero-card">
          <img src={casino.logo} alt={`Логотип ${casino.name}`} loading="lazy" />
          <div>
            <h1>{casino.name}</h1>
            <p>{casino.regionFocus}</p>
            <div className="casino-rating">
              <span>Рейтинг</span>
              <strong>{casino.rating.toFixed(1)}</strong>
              <span>/10</span>
            </div>
          </div>
          <div className="casino-actions">
            <Link to="/compare" className="btn btn-secondary">
              Сравнить с другим казино
            </Link>
          </div>
        </div>
        <p className="casino-summary">{casino.reviewSummary}</p>
      </section>

      <section className="section casino-section">
        <h2 className="section-title">Бонусный пакет</h2>
        <div className="table-wrapper">
          <table className="detail-table">
            <thead>
              <tr>
                <th>Тип бонуса</th>
                <th>Описание</th>
                <th>Вейджер</th>
                <th>Макс. вывод</th>
                <th>Срок действия</th>
              </tr>
            </thead>
            <tbody>
              {casino.bonusDetails.map((bonus) => (
                <tr key={bonus.name}>
                  <td>{bonus.name}</td>
                  <td>{bonus.description}</td>
                  <td>{bonus.wagering}</td>
                  <td>{bonus.maxCashout}</td>
                  <td>{bonus.expiry}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section casino-section">
        <h2 className="section-title">Условия отыгрыша и правила</h2>
        <ul className="detail-list">
          {casino.wageringRules.map((rule) => (
            <li key={rule}>{rule}</li>
          ))}
        </ul>
      </section>

      <section className="section casino-section">
        <h2 className="section-title">Платёжные системы</h2>
        <div className="table-wrapper">
          <table className="detail-table">
            <thead>
              <tr>
                <th>Метод</th>
                <th>Депозит</th>
                <th>Вывод</th>
                <th>Лимиты</th>
                <th>Комиссии</th>
                <th>Скорость</th>
              </tr>
            </thead>
            <tbody>
              {casino.paymentMethods.map((method) => (
                <tr key={method.method}>
                  <td>{method.method}</td>
                  <td>{method.deposit}</td>
                  <td>{method.withdrawal}</td>
                  <td>{method.limits}</td>
                  <td>{method.fee}</td>
                  <td>{method.speed}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section casino-section">
        <h2 className="section-title">Игры и провайдеры</h2>
        <div className="casino-grid">
          <div>
            <h3>Провайдеры</h3>
            <ul className="detail-list">
              {casino.providers.map((provider) => (
                <li key={provider}>{provider}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3>Типы игр</h3>
            <ul className="detail-list">
              {casino.games.map((game) => (
                <li key={game}>{game}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="section casino-section">
        <h2 className="section-title">Служба поддержки</h2>
        <div className="support-card">
          <p><strong>Email:</strong> {casino.support.email}</p>
          <p><strong>Чат:</strong> {casino.support.chat}</p>
          <p><strong>Телефон:</strong> {casino.support.phone || 'Не указан'}</p>
          <p><strong>Рабочие часы:</strong> {casino.support.hours}</p>
        </div>
      </section>
    </div>
  );
};

export default CasinoDetail;
```