```javascript
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { servicePackages, serviceHighlights } from '../data/siteContent';

const Services = () => {
  const [activeId, setActiveId] = useState(servicePackages[0].id);

  return (
    <div className="page">
      <section className="section services-hero">
        <div className="section-header">
          <span className="badge">Сервисы</span>
          <h1 className="section-title">Что предлагает GamblingInsight</h1>
          <p className="section-subtitle">
            Мы создали комплекс сервисов, которые помогают игрокам, операторам и медиа-партнерам получать точные,
            проверенные и актуальные данные о рынке онлайн-казино.
          </p>
        </div>
      </section>

      <section className="section services-detailed">
        <div className="service-pack-grid">
          {servicePackages.map((item) => (
            <article
              key={item.id}
              className={activeId === item.id ? 'service-pack active' : 'service-pack'}
              onMouseEnter={() => setActiveId(item.id)}
            >
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <ul>
                {item.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
              <Link to={item.link} className="text-link">
                {item.cta}
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="section services-highlights">
        <h2 className="section-title">Дополнительные преимущества</h2>
        <div className="service-highlight-grid">
          {serviceHighlights.map((service) => (
            <article key={service.title} className="service-card">
              <div className="service-icon" aria-hidden="true">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to={service.link} className="text-link">
                Подробности
              </Link>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Services;
```