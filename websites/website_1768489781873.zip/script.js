document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', String(isOpen));
            document.body.classList.toggle('nav-open', isOpen);
        });
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('is-open');
                navToggle.classList.remove('is-active');
                navToggle.setAttribute('aria-expanded', 'false');
                document.body.classList.remove('nav-open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('.cookie-accept');
        const declineBtn = cookieBanner.querySelector('.cookie-decline');
        const storedConsent = localStorage.getItem('dramaTVKHQCookieConsent');

        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }

        const handleConsent = (event) => {
            const button = event.currentTarget;
            const choice = button.dataset.choice || 'accepted';
            localStorage.setItem('dramaTVKHQCookieConsent', choice);
            cookieBanner.classList.add('hidden');
            const targetUrl = button.getAttribute('href');
            if (targetUrl) {
                window.open(targetUrl, '_blank');
            }
            event.preventDefault();
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', handleConsent);
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', handleConsent);
        }
    }
});