document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.main-nav');
    const scrollBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');
    const contactForm = document.getElementById('contact-form');
    const yearSpan = document.getElementById('current-year');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navMenu.classList.toggle('nav-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            scrollBtn.style.display = window.scrollY > 250 ? 'block' : 'none';
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAccept) {
        const consent = localStorage.getItem('vorentaCookiesAccepted');
        if (consent !== 'true') {
            cookieBanner.style.display = 'flex';
        }
        cookieAccept.addEventListener('click', () => {
            localStorage.setItem('vorentaCookiesAccepted', 'true');
            cookieBanner.style.display = 'none';
        });
    }

    if (contactForm) {
        const feedback = contactForm.querySelector('.form-feedback');
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            feedback.textContent = `Danke, ${name}! Wir melden uns bei dir.`;
            contactForm.reset();
        });
    }

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});