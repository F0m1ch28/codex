import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.footerInner}`}>
      <div className={styles.column}>
        <h2 className={styles.brandTitle}>Nextoria Programming Academy</h2>
        <p className={styles.brandText}>
          Профессиональная образовательная платформа, помогающая начинающим и практикующим разработчикам уверенно создавать цифровые продукты.
        </p>
      </div>

      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Навигация</h3>
        <ul className={styles.list} aria-label="Основные ссылки">
          <li><Link to="/o-nas" className={styles.link}>О нас</Link></li>
          <li><Link to="/kursy" className={styles.link}>Курсы</Link></li>
          <li><Link to="/programma" className={styles.link}>Программа обучения</Link></li>
          <li><Link to="/prepodavateli" className={styles.link}>Команда</Link></li>
        </ul>
      </div>

      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Документы</h3>
        <ul className={styles.list} aria-label="Правовая информация">
          <li><Link to="/usloviya" className={styles.link}>Пользовательское соглашение</Link></li>
          <li><Link to="/konfidentsialnost" className={styles.link}>Политика конфиденциальности</Link></li>
          <li><Link to="/cookie-policy" className={styles.link}>Политика Cookie</Link></li>
        </ul>
      </div>

      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Контакты</h3>
        <address className={styles.address}>
          <span>Проспект Мира 88</span>
          <span>129110 Москва, Россия</span>
          <a className={styles.link} href="tel:+74959876543">+7 495 987 65 43</a>
        </address>
      </div>
    </div>

    <div className={styles.footerBottom}>
      <p className={styles.copy}>© {new Date().getFullYear()} Nextoria Programming Academy. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;