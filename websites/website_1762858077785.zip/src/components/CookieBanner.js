import React from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'nextoria-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 900);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.text}>
          Мы используем файлы cookie для улучшения работы сайта и повышения удобства обучения. Продолжая пользоваться сайтом, вы соглашаетесь с нашей <a href="/cookie-policy">политикой Cookie</a>.
        </p>
        <button type="button" className={styles.button} onClick={acceptCookies}>
          Согласен
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;