import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Главная' },
  { path: '/o-nas', label: 'О нас' },
  { path: '/kursy', label: 'Курсы' },
  { path: '/programma', label: 'Программа' },
  { path: '/prepodavateli', label: 'Преподаватели' },
  { path: '/kontakty', label: 'Контакты' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  React.useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isMenuOpen]);

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className={`container ${styles.inner}`}>
        <Link to="/" className={styles.logo} aria-label="На главную страницу Nextoria">
          <span className={styles.logoMark}>NX</span>
          <span className={styles.logoText}>Nextoria Programming Academy</span>
        </Link>

        <nav className={styles.navigation} aria-label="Основная навигация">
          <button
            type="button"
            className={styles.menuToggle}
            aria-label="Меню"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((prev) => !prev)}
          >
            <span />
            <span />
            <span />
          </button>

          <div
            className={`${styles.navWrapper} ${isMenuOpen ? styles.navWrapperOpen : ''}`}
            role="dialog"
            aria-modal="true"
          >
            <ul className={styles.navList}>
              {navItems.map((item) => (
                <li key={item.path} className={styles.navItem}>
                  <NavLink
                    to={item.path}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.active : ''}`
                    }
                    onClick={closeMenu}
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
            <Link
              to="/kontakty"
              className={styles.ctaButton}
              onClick={closeMenu}
            >
              Записаться
            </Link>
          </div>
        </nav>
      </div>

      {isMenuOpen && (
        <button
          type="button"
          className={styles.backdrop}
          aria-label="Закрыть меню"
          onClick={closeMenu}
        />
      )}
    </header>
  );
};

export default Header;