import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Teachers.module.css';

const Teachers = () => {
  const [activeFilter, setActiveFilter] = React.useState('Все');

  const mentors = [
    {
      name: 'Елена Синицына',
      stack: 'React, TypeScript, UX-инженерия',
      description:
        'Lead Frontend Engineer, отвечает за дизайн-системы и производительность клиентских приложений.',
      category: 'Frontend',
      image: 'https://picsum.photos/400/400?random=140'
    },
    {
      name: 'Михаил Руднев',
      stack: 'Python, Django, PostgreSQL',
      description:
        'Senior Backend Engineer, строит высоконагруженные сервисы и консультирует по архитектуре.',
      category: 'Backend',
      image: 'https://picsum.photos/400/400?random=141'
    },
    {
      name: 'Наталья Ковалева',
      stack: 'Node.js, React, DevOps',
      description:
        'Tech Lead, помогает сформировать fullstack-мышление и автоматизировать разработку.',
      category: 'Fullstack',
      image: 'https://picsum.photos/400/400?random=142'
    },
    {
      name: 'Илья Патрикеев',
      stack: 'Go, Kubernetes, Observability',
      description:
        'Backend Chapter Lead, фокусируется на распределённых системах, мониторинге и эксплуатации.',
      category: 'Backend',
      image: 'https://picsum.photos/400/400?random=143'
    },
    {
      name: 'Дарья Белова',
      stack: 'Vue, Nuxt, Accessibility',
      description:
        'Senior Frontend Engineer, помогает внедрять доступность и улучшать пользовательский опыт.',
      category: 'Frontend',
      image: 'https://picsum.photos/400/400?random=144'
    },
    {
      name: 'Антон Верещагин',
      stack: 'Data Engineering, Python, Airflow',
      description:
        'Разрабатывает пайплайны данных, проводит практику по аналитике и работе с большими данными.',
      category: 'Backend',
      image: 'https://picsum.photos/400/400?random=145'
    }
  ];

  const filteredMentors =
    activeFilter === 'Все'
      ? mentors
      : mentors.filter((mentor) => mentor.category === activeFilter);

  return (
    <>
      <Helmet>
        <title>Преподаватели Nextoria — команда наставников</title>
        <meta
          name="description"
          content="Команда преподавателей Nextoria Programming Academy: опытные разработчики из фронтенда, бэкенда и fullstack. Узнайте компетенции и стек наставников."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Наставники и преподаватели</h1>
          <p>
            Учебные группы сопровождают действующие инженеры. Они делятся опытом, ревьюят код и помогают выстраивать профессиональный трек.
          </p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className="container">
          <h2>Направления наставников</h2>
          <div className={styles.filterButtons} role="group">
            {['Все', 'Frontend', 'Backend', 'Fullstack'].map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`${styles.filterButton} ${
                  activeFilter === filter ? styles.active : ''
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          <div className={styles.mentorsGrid}>
            {filteredMentors.map((mentor) => (
              <article key={mentor.name} className={styles.mentorCard}>
                <div className={styles.mentorImage}>
                  <img src={mentor.image} alt={`Преподаватель ${mentor.name}`} loading="lazy" />
                </div>
                <div className={styles.mentorContent}>
                  <span>{mentor.category}</span>
                  <h3>{mentor.name}</h3>
                  <p className={styles.stack}>{mentor.stack}</p>
                  <p>{mentor.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Teachers;