import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const About = () => {
  const milestones = [
    {
      year: '2017',
      title: 'Идея академии',
      description:
        'Группа инженеров объединилась, чтобы создать практико-ориентированное обучение для разработчиков из регионов.'
    },
    {
      year: '2019',
      title: 'Запуск проектных спринтов',
      description:
        'Появились первые команды студентов, которые работали над продуктами под менторством разработчиков из индустрии.'
    },
    {
      year: '2021',
      title: 'Рост сообщества',
      description:
        'Мы открыли собственные лаборатории, расширили программу стажировок и запустили карьерный центр.'
    },
    {
      year: '2023',
      title: 'Партнёрские программы',
      description:
        'Сформировали коллаборации с технологическими компаниями и стали проводить совместные проектные школы.'
    }
  ];

  const principles = [
    {
      title: 'Слушаем инженеров',
      text: 'Программы обновляются ежеквартально. Мы анализируем стек, которым живут команды в индустрии, и тут же внедряем актуальные инструменты в обучение.'
    },
    {
      title: 'Проектируем вместе',
      text: 'Каждый модуль заканчивается продуктом: от бэкенд-сервисов до фронтенд-интерфейсов. Студенты и наставники работают в едином репозитории, следуют Git-flow и договариваются о code style.'
    },
    {
      title: 'Учим презентовать',
      text: 'Обучение — это не только код. Итог каждого спринта — работающая демонстрация, понятная документация и убедительный питч решения.'
    }
  ];

  const teamSnapshot = [
    {
      name: 'Артём Громов',
      role: 'Основатель и директор Nextoria',
      description:
        'Отвечает за методологию обучения и партнёрские программы. Более 12 лет в разработке и техлидстве.'
    },
    {
      name: 'Марина Сергеева',
      role: 'Руководитель учебных программ',
      description:
        'Курирует разработку курсов, следит за качеством учебных материалов и взаимодействует с наставниками.'
    },
    {
      name: 'Игорь Панин',
      role: 'Руководитель проектных лабораторий',
      description:
        'Создаёт кейсы, приближённые к реальным продуктам, и ведёт команды студентов во время проектных недель.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>О Nextoria — история, миссия и команда</title>
        <meta
          name="description"
          content="Узнайте историю Nextoria Programming Academy, познакомьтесь с нашей командой преподавателей-разработчиков и методологией проектного обучения."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div>
              <p className={styles.kicker}>О нас</p>
              <h1>Nextoria Programming Academy</h1>
              <p>
                Мы создали пространство, где разработчики учатся у практиков, решая актуальные задачи. Nextoria соединяет образование и реальную индустрию, помогая студентам уверенно чувствовать себя в проектах.
              </p>
            </div>
            <div className={styles.heroPanel}>
              <h2>Миссия</h2>
              <p>
                Делать сложные технологии доступными, помогать людям работать в любимой сфере и развивать инженерное мышление, основанное на ответственности и командном взаимодействии.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.mission} aria-labelledby="mission-heading">
        <div className="container">
          <h2 id="mission-heading">Как мы работаем</h2>
          <div className={styles.principlesGrid}>
            {principles.map((item) => (
              <article key={item.title} className={styles.principle}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timeline} aria-labelledby="timeline-heading">
        <div className="container">
          <h2 id="timeline-heading">История Nextoria</h2>
          <div className={styles.timelineGrid}>
            {milestones.map((milestone) => (
              <article key={milestone.year} className={styles.timelineItem}>
                <span>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <div className="container">
          <div className={styles.teamHeader}>
            <div>
              <h2 id="team-heading">Команда Nextoria</h2>
              <p>
                Мы собираем людей, которые делятся экспертизой и создают поддерживающее сообщество. Наставники Nextoria — инженеры с опытом проектирования сложных систем.
              </p>
            </div>
            <Link to="/prepodavateli" className={styles.teamLink}>
              Все преподаватели →
            </Link>
          </div>
          <div className={styles.teamGrid}>
            {teamSnapshot.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.methodology} aria-labelledby="methodology-heading">
        <div className="container">
          <div className={styles.methodGrid}>
            <div>
              <h2 id="methodology-heading">Методология обучения</h2>
              <p>
                Учебные модули строятся вокруг триады: теория, практика и обратная связь. Теоретический блок даёт вам ключевые знания, практика закрепляет их в проекте, а менторы помогают увидеть слепые зоны и улучшить результат.
              </p>
              <ul className={styles.methodList}>
                <li>Уроки в прямом эфире и записи для повторения</li>
                <li>Домашние задания с ревью и комментариями к коду</li>
                <li>Командные проектные недели с реальными кейсами</li>
                <li>Модуль soft skills: коммуникации, тайм-менеджмент, презетация решений</li>
              </ul>
            </div>
            <div className={styles.methodPanel}>
              <h3>Технологии в фокусе</h3>
              <p>
                Python, Django, FastAPI, PostgreSQL, Redis, Docker, React, Vue, TypeScript, Node.js, GraphQL, GitHub Actions, Kubernetes — это лишь часть стека, с которым знакомятся студенты Nextoria.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;