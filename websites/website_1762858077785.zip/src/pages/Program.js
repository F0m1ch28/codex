import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Program.module.css';

const Program = () => {
  const semesters = [
    {
      title: 'Модуль 1. Фундамент и инструменты',
      duration: '6 недель',
      outcomes: [
        'Освоение синтаксиса языка и ключевых конструкций',
        'Настройка рабочего окружения, Git и CI-процессов',
        'Первые проекты: консольные приложения и мини-сервисы'
      ]
    },
    {
      title: 'Модуль 2. Архитектура и паттерны',
      duration: '8 недель',
      outcomes: [
        'Проектирование API и работа с базами данных',
        'Паттерны разработки, декомпозиция и SOLID',
        'Практика code review и написание тестов'
      ]
    },
    {
      title: 'Модуль 3. Командный проект',
      duration: '6 недель',
      outcomes: [
        'Работа по Scrum, распределение ролей и ответственность',
        'Реализация полноценного продукта и документации',
        'Презентация решения, ретроспектива и feedback-сессии'
      ]
    }
  ];

  const certifications = [
    'Сертификат Nextoria Programming Academy с детализацией технологий',
    'Рекомендательные письма от наставников по итогам проектных работ',
    'Портфолио проектов с Git-репозиториями и документацией'
  ];

  return (
    <>
      <Helmet>
        <title>Программа обучения Nextoria — структура и модули</title>
        <meta
          name="description"
          content="Подробная программа Nextoria Programming Academy: модули, длительность, проектные спринты, сертификация и практические результаты."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Структура обучения</h1>
          <p>
            Программа построена на трех модулях: фундамент, проектирование и командный финальный проект. Каждый этап завершает спринт с презентацией результата.
          </p>
        </div>
      </section>

      <section className={styles.modules} aria-labelledby="modules-heading">
        <div className="container">
          <h2 id="modules-heading">Модули и результаты</h2>
          <div className={styles.moduleGrid}>
            {semesters.map((module) => (
              <article key={module.title} className={styles.moduleCard}>
                <div className={styles.moduleHead}>
                  <h3>{module.title}</h3>
                  <span>{module.duration}</span>
                </div>
                <ul>
                  {module.outcomes.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsGrid}>
            <div className={styles.projectsInfo}>
              <h2>Практические проекты</h2>
              <p>
                Студенты работают над продуктами: от аналитических платформ до клиентских интерфейсов. Каждая команда ведет общий репозиторий, соблюдает code review и следит за качеством документации.
              </p>
              <ul>
                <li>GitHub-репозиторий с README, архитектурными схемами и тестами</li>
                <li>CI/CD пайплайн и деплой в облако или локальную инфраструктуру</li>
                <li>Презентация решения для комитета наставников</li>
              </ul>
            </div>
            <div className={styles.projectsMedia}>
              <img
                src="https://picsum.photos/1200/800?random=130"
                alt="Команда Nextoria работает над проектом"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.certification} aria-labelledby="cert-heading">
        <div className="container">
          <h2 id="cert-heading">Сертификация и поддержка</h2>
          <div className={styles.certGrid}>
            <div>
              <h3>Что вы получаете после обучения</h3>
              <ul>
                {certifications.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className={styles.certPanel}>
              <h3>Карьерный трек</h3>
              <p>
                Карьерный центр помогает подготовиться к собеседованиям, структурировать портфолио и отточить навыки презентации проектов.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Program;