import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const heroImage = 'https://picsum.photos/1600/900?random=101';

const Home = () => {
  const statsData = React.useMemo(
    () => [
      { label: 'Выпускников по всей стране', value: 4200 },
      { label: 'Практических проектов', value: 180 },
      { label: 'Преподавателей-разработчиков', value: 35 },
      { label: 'Партнёрских технологий', value: 24 }
    ],
    []
  );

  const directions = React.useMemo(
    () => [
      {
        title: 'Python-разработка',
        description:
          'Старт с основ языка, работа с Django и Flask, масштабирование серверных приложений, работа с данными.',
        icon: '🐍'
      },
      {
        title: 'JavaScript fullstack',
        description:
          'Уверенное владение современным JavaScript, фреймворками React и Vue, серверная логика на Node.js.',
        icon: '⚡'
      },
      {
        title: 'Backend-инженерия',
        description:
          'Проектирование API, интеграция с базами данных, DevOps-практики и построение надёжной архитектуры.',
        icon: '🛠️'
      },
      {
        title: 'Frontend-интерфейсы',
        description:
          'Внимание к UI/UX, адаптивные интерфейсы, дизайн-системы и производительность веб-приложений.',
        icon: '🎨'
      }
    ],
    []
  );

  const processSteps = React.useMemo(
    () => [
      {
        number: '01',
        title: 'Диагностика целей',
        text: 'Совместно определяем стартовый уровень, формируем индивидуальные ориентиры и ожидаемые результаты.'
      },
      {
        number: '02',
        title: 'Проектные спринты',
        text: 'Каждый модуль завершается практическим проектом, приближенным к задачам реального бизнеса.'
      },
      {
        number: '03',
        title: 'Обратная связь',
        text: 'Преподаватели и менторы дают развёрнутые рекомендации, чтобы закрепить навыки и улучшить решения.'
      },
      {
        number: '04',
        title: 'Демонстрация итогов',
        text: 'Публичное представление проектов, портфолио и подготовка к техническим собеседованиям.'
      }
    ],
    []
  );

  const projects = React.useMemo(
    () => [
      {
        id: 1,
        category: 'Python',
        title: 'Интеллектуальный трекер задач',
        description: 'Django-платформа с ML-рекомендациями и гибкой системой прав пользователей.',
        image: 'https://picsum.photos/1200/800?random=104'
      },
      {
        id: 2,
        category: 'JavaScript',
        title: 'Progressive Web App для событий',
        description: 'React + Node.js приложение с офлайн-доступом и интеграцией с внешними API.',
        image: 'https://picsum.photos/1200/800?random=105'
      },
      {
        id: 3,
        category: 'Backend',
        title: 'Сервис аналитики данных',
        description: 'Микросервисная архитектура, GraphQL-шлюз и пайплайн обработки больших данных.',
        image: 'https://picsum.photos/1200/800?random=106'
      },
      {
        id: 4,
        category: 'Frontend',
        title: 'UI-kit для сложных интерфейсов',
        description: 'Design system, кастомные хуки и Storybook-документация для продуктовых команд.',
        image: 'https://picsum.photos/1200/800?random=107'
      }
    ],
    []
  );

  const testimonials = React.useMemo(
    () => [
      {
        name: 'Алина Морозова',
        role: 'Frontend-разработчик',
        quote:
          'Nextoria помогла мне не только понять синтаксис, но и научила мыслить системно. Менторы тщательно разбирают код и объясняют архитектуру.',
        image: 'https://picsum.photos/200/200?random=108'
      },
      {
        name: 'Дамир Хусаинов',
        role: 'Python backend-инженер',
        quote:
          'Мы делали настоящие проекты: от REST API до интеграций с внешними сервисами. Благодаря практике было легко перейти в коммерческую разработку.',
        image: 'https://picsum.photos/200/200?random=109'
      },
      {
        name: 'Софья Ларионова',
        role: 'Fullstack-разработчик',
        quote:
          'Отдельно отмечу работу кураторов: сессии с обратной связью, помощь в разборе багов и рекомендация по улучшению портфолио были бесценны.',
        image: 'https://picsum.photos/200/200?random=110'
      }
    ],
    []
  );

  const teamPreview = React.useMemo(
    () => [
      {
        name: 'Елена Синицына',
        role: 'Lead Frontend Engineer, Ведёт направление React',
        image: 'https://picsum.photos/400/400?random=111',
        focus: 'Проектирует дизайн-системы и учит выстраивать масштабируемую архитектуру фронтенда.'
      },
      {
        name: 'Михаил Руднев',
        role: 'Senior Backend Engineer, Python',
        image: 'https://picsum.photos/400/400?random=112',
        focus: 'Помогает студентам применять асинхронность, очереди и облачные сервисы в проектах.'
      },
      {
        name: 'Наталья Ковалева',
        role: 'Tech Lead, JavaScript fullstack',
        image: 'https://picsum.photos/400/400?random=113',
        focus: 'Показывает лучшие практики взаимодействия фронтенда и бэкенда и ревьюит код в реальном времени.'
      }
    ],
    []
  );

  const faqs = React.useMemo(
    () => [
      {
        question: 'Можно ли совмещать обучение с работой?',
        answer:
          'Да. Расписание составлено так, чтобы занятия и проектные спринты можно было проходить в удобное время. Записи встреч сохраняются, а наставники отвечают асинхронно в Slack.'
      },
      {
        question: 'Как выглядит процесс обратной связи?',
        answer:
          'После каждого спринта вы получаете детальный разбор проекта: комментарии к коду, рекомендации по улучшению архитектуры и чек-лист сильных и слабых сторон.'
      },
      {
        question: 'Что входит в сопровождение карьеры?',
        answer:
          'Мы помогаем подготовить резюме, сопроводительные письма, проводим имитацию технических интервью и подсказываем, как презентовать проекты из портфолио.'
      }
    ],
    []
  );

  const blogPosts = React.useMemo(
    () => [
      {
        title: 'Как построить архитектуру фронтенд-приложения в 2024 году',
        excerpt:
          'Разбираем подходы к модульной структуре, работе с состоянием, изоляции компонентов и стандартизации UI-кита.',
        date: '15 февраля 2024',
        link: '/o-nas#blog',
        image: 'https://picsum.photos/800/600?random=114'
      },
      {
        title: 'Django vs FastAPI: что выбрать для продакшн-проекта',
        excerpt:
          'Сравниваем фреймворки по производительности, удобству разработки, экосистеме и требованиям команды.',
        date: '3 марта 2024',
        link: '/kursy#python',
        image: 'https://picsum.photos/800/600?random=115'
      },
      {
        title: 'Практика code review: чек-лист для молодых разработчиков',
        excerpt:
          'Собрали вопросы, которые стоит задавать себе перед отправкой pull request, и критерии качественного ревью.',
        date: '22 марта 2024',
        link: '/prepodavateli#mentors',
        image: 'https://picsum.photos/800/600?random=116'
      }
    ],
    []
  );

  const [statsValues, setStatsValues] = React.useState(statsData.map(() => 0));
  const [statsVisible, setStatsVisible] = React.useState(false);
  const statsRef = React.useRef(null);

  const [activeCategory, setActiveCategory] = React.useState('Все');
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);
  const [faqOpenIndex, setFaqOpenIndex] = React.useState(null);

  React.useEffect(() => {
    const section = statsRef.current;
    if (!section) return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setStatsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.35 }
    );

    observer.observe(section);

    return () => observer.disconnect();
  }, []);

  React.useEffect(() => {
    if (!statsVisible) return undefined;

    const totalDuration = 1400;
    const steps = 40;
    const incrementDuration = totalDuration / steps;

    const intervals = statsData.map((stat, index) => {
      const step = Math.ceil(stat.value / steps);
      let intervalId = null;

      intervalId = setInterval(() => {
        setStatsValues((prevValues) => {
          const nextValues = [...prevValues];
          const current = nextValues[index];

          if (current >= stat.value) {
            clearInterval(intervalId);
            return nextValues;
          }

          nextValues[index] = Math.min(stat.value, current + step);
          return nextValues;
        });
      }, incrementDuration);

      return intervalId;
    });

    return () => intervals.forEach((intervalId) => clearInterval(intervalId));
  }, [statsVisible, statsData]);

  React.useEffect(() => {
    if (testimonials.length <= 1) return undefined;

    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const filteredProjects =
    activeCategory === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const toggleFaq = (index) => {
    setFaqOpenIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Nextoria — Программируй будущее с нами</title>
        <meta
          name="description"
          content="Практическое обучение программированию в Nextoria Programming Academy: Python, JavaScript, Backend и Frontend направления с проектной методологией."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-heading">
        <div
          className={styles.heroBackground}
          style={{ backgroundImage: `url(${heroImage})` }}
          aria-hidden="true"
        />
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <p className={styles.heroKicker}>Образовательная платформа нового поколения</p>
            <h1 id="hero-heading" className={styles.heroTitle}>
              Программируй будущее с <span>Nextoria</span>
            </h1>
            <p className={styles.heroSubtitle}>
              Осваивайте современные технологии в формате проектных спринтов вместе с командами практикующих разработчиков. Стройте работоспособные продукты и укрепляйте уверенность в своих решениях.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.heroCta}>
                Записаться на курс
              </Link>
              <Link to="/kursy" className={styles.heroSecondary}>
                Посмотреть программы
              </Link>
            </div>
          </div>

          <div className={styles.heroCard} role="presentation">
            <div className={styles.heroCardInner}>
              <h2 className={styles.cardTitle}>Что вы получите</h2>
              <ul className={styles.cardList}>
                <li>Живые занятия и проектные практики</li>
                <li>Наставничество от опытных инженеров</li>
                <li>Поддержку в подготовке портфолио и резюме</li>
              </ul>
              <Link to="/programma" className={styles.cardLink}>
                Узнать о программе →
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section ref={statsRef} className={styles.stats} aria-labelledby="stats-heading">
        <div className="container">
          <h2 id="stats-heading" className={styles.sectionTitle}>
            Результаты Nextoria Programming Academy
          </h2>
          <p className={styles.sectionSubtitle}>
            Мы создаём среду, где можно безопасно ошибаться, экспериментировать и становиться увереннее.
          </p>
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {statsValues[index]}
                  {index === 0 || index === 1 ? '+' : ''}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.intro} aria-labelledby="intro-heading">
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2 id="intro-heading" className={styles.sectionTitle}>
                Что отличает Nextoria
              </h2>
              <p className={styles.sectionSubtitle}>
                Мы создаём образовательный опыт вокруг реальных задач и тесного взаимодействия с практикующими инженерами. Каждая команда студентов работает над собственным проектом, сочетая теорию и прикладную практику.
              </p>
            </div>
            <div className={styles.introHighlights}>
              <article className={styles.highlightCard}>
                <h3>Гибкая траектория</h3>
                <p>Выбирайте фокус, который соответствует вашим целям: разработка на Python, JavaScript fullstack, backend-инженерия или создание интерфейсов.</p>
              </article>
              <article className={styles.highlightCard}>
                <h3>Современные среды</h3>
                <p>Работаем с VS Code, PyCharm, GitHub, Docker и CI/CD инструментами. Учимся взаимодействовать в командах и соблюдаем стандарты чистого кода.</p>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.directions} aria-labelledby="directions-heading">
        <div className="container">
          <h2 id="directions-heading" className={styles.sectionTitle}>
            Наши направления обучения
          </h2>
          <p className={styles.sectionSubtitle}>
            Выберите трек, чтобы сконцентрироваться на нужном стеке технологий и формате проектов.
          </p>
          <div className={styles.directionGrid}>
            {directions.map((direction) => (
              <article key={direction.title} className={styles.directionCard}>
                <div className={styles.directionIcon} aria-hidden="true">
                  {direction.icon}
                </div>
                <h3>{direction.title}</h3>
                <p>{direction.description}</p>
                <Link to="/kursy" className={styles.directionLink}>
                  Подробнее
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-heading">
        <div className="container">
          <h2 id="process-heading" className={styles.sectionTitle}>
            Как проходит обучение
          </h2>
          <p className={styles.sectionSubtitle}>
            Каждый модуль — это сфокусированный спринт с конкретным результатом и поддержкой наставников.
          </p>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.number} className={styles.processCard}>
                <span className={styles.stepNumber}>{step.number}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-heading">
        <div className="container">
          <div className={styles.projectsHeader}>
            <div>
              <h2 id="projects-heading" className={styles.sectionTitle}>
                Проекты студентов
              </h2>
              <p className={styles.sectionSubtitle}>
                Мы делаем упор на прикладные задачи, где нужно продумать архитектуру, оформить документацию и представить решение.
              </p>
            </div>
            <div className={styles.projectFilters} role="group" aria-label="Фильтр проектов">
              {['Все', 'Python', 'JavaScript', 'Backend', 'Frontend'].map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`${styles.filterButton} ${
                    activeCategory === category ? styles.filterButtonActive : ''
                  }`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={`${project.title} — проект студентов по направлению ${project.category}`}
                  loading="lazy"
                />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-heading">
        <div className="container">
          <div className={styles.testimonialsHeader}>
            <h2 id="testimonials-heading" className={styles.sectionTitle}>
              Отзывы выпускников
            </h2>
            <div className={styles.testimonialControls}>
              <button
                type="button"
                aria-label="Предыдущий отзыв"
                onClick={() =>
                  setTestimonialIndex((prev) =>
                    prev === 0 ? testimonials.length - 1 : prev - 1
                  )
                }
              >
                ←
              </button>
              <button
                type="button"
                aria-label="Следующий отзыв"
                onClick={() =>
                  setTestimonialIndex((prev) => (prev + 1) % testimonials.length)
                }
              >
                →
              </button>
            </div>
          </div>
          <div className={styles.testimonialCard}>
            <img
              src={testimonials[testimonialIndex].image}
              alt={`Фото выпускника ${testimonials[testimonialIndex].name}`}
              loading="lazy"
            />
            <blockquote>
              <p>{testimonials[testimonialIndex].quote}</p>
              <footer>
                <strong>{testimonials[testimonialIndex].name}</strong>
                <span>{testimonials[testimonialIndex].role}</span>
              </footer>
            </blockquote>
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <div className="container">
          <div className={styles.teamHeader}>
            <h2 id="team-heading" className={styles.sectionTitle}>
              Команда наставников
            </h2>
            <p className={styles.sectionSubtitle}>
              Преподаватели Nextoria — действующие инженеры, которые делятся практическим опытом и проводят ревью вашего кода.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamPreview.map((mentor) => (
              <article key={mentor.name} className={styles.teamCard}>
                <img
                  src={mentor.image}
                  alt={`Преподаватель ${mentor.name}`}
                  loading="lazy"
                />
                <div className={styles.teamContent}>
                  <h3>{mentor.name}</h3>
                  <span>{mentor.role}</span>
                  <p>{mentor.focus}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.teamAction}>
            <Link to="/prepodavateli">Познакомиться со всей командой</Link>
          </div>
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.faqHeader}>
            <h2 id="faq-heading" className={styles.sectionTitle}>
              Часто задаваемые вопросы
            </h2>
            <p className={styles.sectionSubtitle}>
              Если не нашли ответ — напишите нам, и мы обязательно поможем.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqs.map((item, index) => (
              <article key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={faqOpenIndex === index}
                  className={styles.faqButton}
                >
                  <span>{item.question}</span>
                  <span aria-hidden="true">{faqOpenIndex === index ? '−' : '+'}</span>
                </button>
                {faqOpenIndex === index && <p>{item.answer}</p>}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-heading">
        <div className="container">
          <div className={styles.blogHeader}>
            <h2 id="blog-heading" className={styles.sectionTitle}>
              Ближайшие обновления и материалы
            </h2>
            <p className={styles.sectionSubtitle}>
              Делаемся методиками, руководствами и заметками о технологиях, которые используем в академии.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <span>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link}>Читать</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.ctaCard}>
            <h2 id="cta-heading">
              Готовы прокачать навыки и создать портфолио из реальных проектов?
            </h2>
            <p>
              Оставьте заявку — расскажем о форматах обучения, поможем выбрать направление и покажем, как устроены проектные спринты.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/kontakty" className={styles.heroCta}>
                Записаться на консультацию
              </Link>
              <Link to="/programma" className={styles.heroSecondary}>
                Структура программы
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;