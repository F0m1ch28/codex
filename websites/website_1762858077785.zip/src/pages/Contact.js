import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  phone: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Введите ваше имя';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите электронную почту';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Проверьте корректность адреса';
    }
    if (!formData.message.trim()) newErrors.message = 'Расскажите о ваших целях';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Контакты Nextoria — адрес, телефон, форма регистрации</title>
        <meta
          name="description"
          content="Свяжитесь с Nextoria Programming Academy: адрес в Москве, телефон, форма регистрации на обучение, карта и график работы."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Связаться с нами</h1>
          <p>
            Ответим на вопросы, подберём программу и расскажем о ближайшем наборе в Nextoria.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.info}>
              <h2>Контакты</h2>
              <p>
                Проспект Мира 88, 129110 Москва, Россия
                <br />
                Телефон: <a href="tel:+74959876543">+7 495 987 65 43</a>
              </p>
              <p>
                Мы работаем ежедневно с 10:00 до 20:00. Записывайтеcь на экскурсию, чтобы увидеть, как проходят занятия.
              </p>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Карта местоположения Nextoria"
                  src="https://yandex.ru/map-widget/v1/-/CCUhc3OY"
                  loading="lazy"
                  aria-label="Карта с адресом Nextoria"
                />
              </div>
            </div>
            <div className={styles.formWrapper}>
              <h2>Заявка на обучение</h2>
              <p>Оставьте контакты, и наша команда свяжется с вами в течение рабочего дня.</p>

              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label>
                  Имя*
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    aria-invalid={!!errors.name}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                  />
                  {errors.name && <span id="name-error">{errors.name}</span>}
                </label>

                <label>
                  Электронная почта*
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    aria-invalid={!!errors.email}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                  />
                  {errors.email && <span id="email-error">{errors.email}</span>}
                </label>

                <label>
                  Телефон
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+7"
                  />
                </label>

                <label>
                  Какие цели вы ставите перед обучением?*
                  <textarea
                    name="message"
                    rows="4"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    aria-invalid={!!errors.message}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                  />
                  {errors.message && <span id="message-error">{errors.message}</span>}
                </label>

                <button type="submit">Отправить заявку</button>

                {submitted && (
                  <p className={styles.success} role="status">
                    Спасибо! Заявка отправлена. Мы свяжемся с вами в ближайшее время.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;