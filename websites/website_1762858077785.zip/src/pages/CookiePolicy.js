import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика использования Cookie Nextoria</title>
      <meta
        name="description"
        content="Политика использования файлов cookie Nextoria Programming Academy: какие cookie мы используем и для чего они нужны."
      />
    </Helmet>

    <section className={styles.legalSection} aria-labelledby="cookie-heading">
      <div className="container">
        <div className={styles.legalCard}>
          <div className={styles.legalIntro}>
            <h1 id="cookie-heading">Политика использования Cookie</h1>
            <p>
              Cookie помогают нам анализировать работу сайта и делать обучение удобнее. Мы используем их в соответствии с законодательством Российской Федерации.
            </p>
          </div>

          <h2>1. Что такое cookie</h2>
          <p>
            Cookie — это небольшие файлы, которые сохраняются в браузере пользователя. Они не содержат персональной информации и используются для настройки функциональности сайта.
          </p>

          <h2>2. Какие cookie мы применяем</h2>
          <ul>
            <li>Технические — обеспечивают работу сайта и формы регистрации.</li>
            <li>Аналитические — помогают понять, как пользователи взаимодействуют с материалами.</li>
            <li>Функциональные — сохраняют ваши предпочтения, чтобы упростить повторные посещения.</li>
          </ul>

          <h2>3. Управление cookie</h2>
          <p>
            Вы можете отключить cookie в настройках браузера. Однако некоторые функции сайта могут стать недоступны.
          </p>

          <h2>4. Контакт</h2>
          <p>
            Если у вас есть вопросы о cookie, свяжитесь с нами по телефону <a href="tel:+74959876543">+7 495 987 65 43</a>.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicy;