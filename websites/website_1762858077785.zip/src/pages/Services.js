import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const Services = () => {
  const [activeCourse, setActiveCourse] = React.useState('python');

  const courses = [
    {
      id: 'python',
      title: 'Python разработка',
      stack: ['Python 3', 'Django', 'FastAPI', 'PostgreSQL', 'Docker'],
      description:
        'Освойте создание backend-сервисов, REST и GraphQL API, асинхронные задачи и интеграцию с внешними системами.',
      modules: [
        'Основы Python, тестирование и клонирование проектов',
        'Django: ORM, DRF, авторизация, работа с файловыми сервисами',
        'FastAPI и асинхронность, Celery, Redis, очереди задач',
        'Проектирование архитектуры, деплой и Observability'
      ],
      image: 'https://picsum.photos/800/600?random=120'
    },
    {
      id: 'javascript',
      title: 'JavaScript (React, Vue, Node.js)',
      stack: ['JavaScript ES2023', 'TypeScript', 'React', 'Vue', 'Node.js'],
      description:
        'Станьте fullstack-разработчиком: создавайте интерфейсы, настраивайте серверную логику и объединяйте их в единый продукт.',
      modules: [
        'Современный JavaScript, TypeScript и тестирование',
        'React: хуки, маршрутизация, состояние, оптимизация',
        'Vue: композиционное API, экосистема и SSR',
        'Node.js: Express, NestJS, WebSocket, интеграция с БД'
      ],
      image: 'https://picsum.photos/800/600?random=121'
    },
    {
      id: 'backend',
      title: 'Backend разработка',
      stack: ['Architecture', 'APIs', 'Databases', 'CI/CD', 'Cloud'],
      description:
        'Научитесь проектировать масштабируемые системы, работать с микросервисами, очередями, логированием и инфраструктурой.',
      modules: [
        'Проектирование сервисов и требование к архитектуре',
        'API-first подход, протоколы, безопасность и документация',
        'Базы данных: реляционные, NoSQL, индексация, оптимизация',
        'Инфраструктура: Docker, Kubernetes, CI/CD и мониторинг'
      ],
      image: 'https://picsum.photos/800/600?random=122'
    },
    {
      id: 'frontend',
      title: 'Frontend разработка',
      stack: ['HTML5', 'CSS3', 'Design Systems', 'React', 'Performance'],
      description:
        'Создавайте удобные интерфейсы, реализуйте дизайн-системы, оптимизируйте производительность и автоматизируйте процессы.',
      modules: [
        'HTML/CSS, адаптивность, доступность и семантика',
        'JavaScript в браузере, Web APIs, сборщики, инструменты',
        'React и управление состоянием, тестирование компонентов',
        'Design-systems, Storybook, CI, оптимизация фронтенда'
      ],
      image: 'https://picsum.photos/800/600?random=123'
    }
  ];

  const activeData = courses.find((course) => course.id === activeCourse) || courses[0];

  return (
    <>
      <Helmet>
        <title>Курсы Nextoria — Python, JavaScript, Backend, Frontend</title>
        <meta
          name="description"
          content="Курсы Nextoria Programming Academy: Python, JavaScript, Backend и Frontend разработка. Структура модулей, технологии и практические задачи."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Курсы и направления</h1>
          <p>
            Выберите фокус, который совпадает с вашими планами. Каждое направление сочетает глубокую теорию, практику и проектный опыт.
          </p>
        </div>
      </section>

      <section className={styles.switcher} aria-labelledby="courses-heading">
        <div className="container">
          <h2 id="courses-heading">Выберите программу</h2>
          <div className={styles.switcherButtons} role="tablist">
            {courses.map((course) => (
              <button
                key={course.id}
                type="button"
                role="tab"
                aria-selected={activeCourse === course.id}
                onClick={() => setActiveCourse(course.id)}
                className={`${styles.switcherButton} ${
                  activeCourse === course.id ? styles.switcherButtonActive : ''
                }`}
              >
                {course.title}
              </button>
            ))}
          </div>

          <div className={styles.courseCard} role="tabpanel">
            <div className={styles.courseContent}>
              <h3>{activeData.title}</h3>
              <p>{activeData.description}</p>
              <div className={styles.courseStack}>
                {activeData.stack.map((item) => (
                  <span key={item}>{item}</span>
                ))}
              </div>
              <h4>Модули программы</h4>
              <ul>
                {activeData.modules.map((module) => (
                  <li key={module}>{module}</li>
                ))}
              </ul>
              <div className={styles.courseActions}>
                <Link to="/programma" className={styles.primaryLink}>
                  Структура обучения
                </Link>
                <Link to="/kontakty" className={styles.secondaryLink}>
                  Получить консультацию
                </Link>
              </div>
            </div>
            <div className={styles.courseMedia}>
              <img
                src={activeData.image}
                alt={`Иллюстрация курса ${activeData.title}`}
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;