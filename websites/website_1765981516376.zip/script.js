(function () {
  "use strict";

  const palettes = {
    solar: {
      gradient: ["#ffcf71", "#ff8a47", "#f45d33"],
      accents: ["#ffe29a", "#ffb769", "#ff8c42", "#ff6153"],
      highlight: "rgba(255, 240, 214, 0.6)",
      particle: "rgba(255, 255, 255, 0.58)",
      shapes: ["circle", "polygon", "stripe", "arc", "diamond"]
    },
    wind: {
      gradient: ["#3a8dff", "#1fb4f2", "#7fd4ff"],
      accents: ["#a8e3ff", "#6cc6ff", "#5ec7d6", "#93eff4"],
      highlight: "rgba(255, 255, 255, 0.6)",
      particle: "rgba(255, 255, 255, 0.5)",
      shapes: ["stripe", "circle", "arc", "diamond", "polygon"]
    },
    hybrid: {
      gradient: ["#6a00f4", "#a933ff", "#e85fff"],
      accents: ["#c77dff", "#a855f7", "#f72585", "#ff8fab"],
      highlight: "rgba(249, 221, 255, 0.65)",
      particle: "rgba(255, 255, 255, 0.55)",
      shapes: ["polygon", "circle", "stripe", "arc"]
    },
    dashboard: {
      gradient: ["#1b3dd1", "#3170ff", "#65a8ff"],
      accents: ["#93b7ff", "#4db2ff", "#1fc8db", "#8ad4ff"],
      highlight: "rgba(255, 255, 255, 0.46)",
      particle: "rgba(255, 255, 255, 0.48)",
      shapes: ["circle", "stripe", "polygon", "arc", "diamond"]
    },
    team: {
      gradient: ["#2ed0c3", "#26a6a4", "#1f8f90"],
      accents: ["#8ff6e8", "#4fd9c6", "#24c5b2", "#7be0d4"],
      highlight: "rgba(207, 255, 246, 0.55)",
      particle: "rgba(255, 255, 255, 0.5)",
      shapes: ["circle", "diamond", "polygon", "stripe"]
    },
    environment: {
      gradient: ["#00a870", "#18b86f", "#1ed59b"],
      accents: ["#5be59f", "#8be5bf", "#24c48f", "#0f996d"],
      highlight: "rgba(216, 255, 230, 0.52)",
      particle: "rgba(255, 255, 255, 0.52)",
      shapes: ["circle", "arc", "stripe", "diamond"]
    },
    map: {
      gradient: ["#243b53", "#305c7f", "#3f8a8f"],
      accents: ["#7cc5c9", "#4fa0b7", "#346b8a", "#5dbab6"],
      highlight: "rgba(210, 239, 255, 0.44)",
      particle: "rgba(255, 255, 255, 0.42)",
      shapes: ["stripe", "polygon", "circle", "arc"]
    },
    default: {
      gradient: ["#455a64", "#37474f", "#263238"],
      accents: ["#90a4ae", "#78909c", "#546e7a", "#607d8b"],
      highlight: "rgba(255, 255, 255, 0.38)",
      particle: "rgba(255, 255, 255, 0.32)",
      shapes: ["circle", "polygon", "stripe", "arc"]
    }
  };

  function createRNG(seedValue) {
    let seed = Math.floor(Math.abs(seedValue)) % 2147483647;
    if (seed === 0) {
      seed = 1;
    }
    return function () {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };
  }

  function generateImagePattern(element, type, seedValue) {
    const palette = palettes[type] || palettes.default;
    const width = Math.max(element.offsetWidth || 0, 600);
    const height = element.offsetHeight > 0 ? element.offsetHeight : Math.round(width * 0.6);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    const rng = createRNG(seedValue);

    const gradient = ctx.createLinearGradient(0, 0, width, height);
    const stops = palette.gradient.length - 1;
    palette.gradient.forEach((color, index) => {
      const ratio = stops === 0 ? 1 : index / stops;
      gradient.addColorStop(ratio, color);
    });
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    const shapesTotal = 9 + Math.floor(rng() * 6);
    for (let i = 0; i < shapesTotal; i++) {
      const color = palette.accents[Math.floor(rng() * palette.accents.length)];
      const shape = palette.shapes[Math.floor(rng() * palette.shapes.length)];
      ctx.globalAlpha = 0.24 + rng() * 0.35;
      switch (shape) {
        case "circle":
          drawCircle(ctx, rng, width, height, color);
          break;
        case "polygon":
          drawPolygon(ctx, rng, width, height, color);
          break;
        case "stripe":
          drawStripe(ctx, rng, width, height, color);
          break;
        case "arc":
          drawArc(ctx, rng, width, height, color);
          break;
        case "diamond":
          drawDiamond(ctx, rng, width, height, color);
          break;
        default:
          drawCircle(ctx, rng, width, height, color);
          break;
      }
    }

    ctx.globalAlpha = 0.14;
    const waveLayers = 2 + Math.floor(rng() * 3);
    for (let i = 0; i < waveLayers; i++) {
      drawWave(ctx, rng, width, height, palette.highlight);
    }

    ctx.globalAlpha = 1;
    const particleCount = 40 + Math.floor(rng() * 12);
    ctx.fillStyle = palette.particle;
    for (let i = 0; i < particleCount; i++) {
      const size = 1 + rng() * 2.2;
      ctx.beginPath();
      ctx.arc(width * rng(), height * rng(), size, 0, Math.PI * 2);
      ctx.fill();
    }

    element.style.backgroundImage = "url(" + canvas.toDataURL("image/png") + ")";
  }

  function drawCircle(ctx, rng, width, height, color) {
    const radius = Math.max(width, height) * (0.08 + rng() * 0.16);
    const x = width * rng();
    const y = height * rng();
    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawPolygon(ctx, rng, width, height, color) {
    const centerX = width * rng();
    const centerY = height * rng();
    const baseRadius = Math.max(width, height) * (0.06 + rng() * 0.12);
    const sides = 5 + Math.floor(rng() * 4);
    ctx.beginPath();
    for (let i = 0; i < sides; i++) {
      const angle = (Math.PI * 2 * i) / sides + rng() * 0.3;
      const radius = baseRadius * (0.7 + rng() * 0.4);
      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  }

  function drawStripe(ctx, rng, width, height, color) {
    const stripeWidth = width * (0.3 + rng() * 0.4);
    const stripeHeight = height * (0.04 + rng() * 0.06);
    const x = width * rng();
    const y = height * rng();
    const rotation = rng() * Math.PI;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.fillStyle = color;
    ctx.fillRect(-stripeWidth / 2, -stripeHeight / 2, stripeWidth, stripeHeight);
    ctx.restore();
  }

  function drawArc(ctx, rng, width, height, color) {
    const centerX = width * rng();
    const centerY = height * rng();
    const radius = Math.max(width, height) * (0.18 + rng() * 0.22);
    const start = rng() * Math.PI * 2;
    const end = start + (Math.PI / 3 + rng() * (Math.PI / 2));
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(width, height) * (0.008 + rng() * 0.02);
    ctx.lineCap = "round";
    ctx.arc(centerX, centerY, radius, start, end);
    ctx.stroke();
  }

  function drawDiamond(ctx, rng, width, height, color) {
    const centerX = width * rng();
    const centerY = height * rng();
    const w = width * (0.08 + rng() * 0.12);
    const h = height * (0.08 + rng() * 0.12);
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - h / 2);
    ctx.lineTo(centerX + w / 2, centerY);
    ctx.lineTo(centerX, centerY + h / 2);
    ctx.lineTo(centerX - w / 2, centerY);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  }

  function drawWave(ctx, rng, width, height, color) {
    const amplitude = height * (0.04 + rng() * 0.08);
    const baseY = height * (0.1 + rng() * 0.8);
    const segments = 4;
    ctx.beginPath();
    ctx.moveTo(0, baseY);
    for (let i = 1; i <= segments; i++) {
      const segmentWidth = width / segments;
      const x = segmentWidth * i;
      const cp1x = segmentWidth * (i - 0.5);
      const cp1y = baseY + amplitude * (rng() - 0.5);
      const cp2x = cp1x;
      const cp2y = baseY + amplitude * (rng() - 0.5);
      const targetY = baseY + amplitude * (rng() - 0.5);
      ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, targetY);
    }
    ctx.strokeStyle = color;
    ctx.lineWidth = 1 + rng() * 2.4;
    ctx.lineCap = "round";
    ctx.stroke();
  }

  function generateDynamicImages() {
    const elements = document.querySelectorAll(".dynamic-img");
    if (!elements.length) {
      return;
    }
    const timestamp = Date.now();
    elements.forEach((element, index) => {
      const typeAttr = element.dataset.type;
      const type = palettes[typeAttr] ? typeAttr : "default";
      if (!element.classList.contains(type)) {
        element.classList.add(type);
      }
      const seedModifier = (index + 1) * 997;
      const uniqueSeed = timestamp * (1 + Math.random()) + seedModifier + element.offsetLeft + element.offsetTop;
      generateImagePattern(element, type, uniqueSeed);
    });
  }

  function debounce(fn, delay) {
    let timeout;
    return function (...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  function setupNavigation() {
    const toggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".site-nav");
    if (!toggle || !nav) {
      return;
    }
    toggle.addEventListener("click", () => {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      document.body.classList.toggle("nav-open", !expanded);
    });
    nav.querySelectorAll(".nav-link").forEach((link) => {
      link.addEventListener("click", () => {
        if (document.body.classList.contains("nav-open")) {
          document.body.classList.remove("nav-open");
          toggle.setAttribute("aria-expanded", "false");
        }
      });
    });
    window.addEventListener("resize", () => {
      if (window.innerWidth > 960 && document.body.classList.contains("nav-open")) {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keyup", (event) => {
      if (event.key === "Escape" && document.body.classList.contains("nav-open")) {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  window.addEventListener("load", () => {
    setupNavigation();
    window.requestAnimationFrame(generateDynamicImages);
  });

  window.addEventListener("pageshow", (event) => {
    if (event.persisted) {
      window.requestAnimationFrame(generateDynamicImages);
    }
  });

  window.addEventListener(
    "resize",
    debounce(() => {
      window.requestAnimationFrame(generateDynamicImages);
    }, 400)
  );
})();