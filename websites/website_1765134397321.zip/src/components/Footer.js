import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div>
            <h3 className={styles.heading}>Dog Training Expert</h3>
            <p className={styles.text}>
              Професійне партнерство з вашою німецькою вівчаркою: індивідуальні програми дресирування у Варшаві та Кракові.
            </p>
          </div>
          <div>
            <h4 className={styles.subheading}>Навігація</h4>
            <ul className={styles.list}>
              <li><Link to="/" className={styles.link}>Головна</Link></li>
              <li><Link to="/pro-nas" className={styles.link}>Про нас</Link></li>
              <li><Link to="/posluhy-dresyruvannia" className={styles.link}>Послуги дресирування</Link></li>
              <li><Link to="/nashi-kliienty" className={styles.link}>Наші клієнти</Link></li>
              <li><Link to="/kontakty" className={styles.link}>Контакти</Link></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.subheading}>Контакти</h4>
            <ul className={styles.list}>
              <li>Варшава, вул. Собача, 15</li>
              <li>Краків, вул. Песя, 8</li>
              <li><a className={styles.link} href="tel:+48123456789">+48 123 456 789</a></li>
              <li><a className={styles.link} href="mailto:info@dogtrainingexpert.pl">info@dogtrainingexpert.pl</a></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.subheading}>Ми в соцмережах</h4>
            <div className={styles.socials}>
              <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" className={styles.socialLink}>Facebook</a>
              <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" className={styles.socialLink}>Instagram</a>
              <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" className={styles.socialLink}>YouTube</a>
            </div>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {year} Dog Training Expert. Всі права захищено.</p>
          <div className={styles.legal}>
            <Link to="/terms" className={styles.link}>Умови використання</Link>
            <Link to="/privacy" className={styles.link}>Політика конфіденційності</Link>
            <Link to="/cookie-policy" className={styles.link}>Політика Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;