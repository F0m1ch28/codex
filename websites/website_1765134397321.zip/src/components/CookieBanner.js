import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    let storedConsent = null;
    try {
      storedConsent = localStorage.getItem('dte-cookie-consent');
    } catch (error) {
      storedConsent = null;
    }
    if (!storedConsent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem('dte-cookie-consent', 'accepted');
    } catch (error) {
      /* ignore quota errors */
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner}>
      <div className={styles.content}>
        <p>
          Ми використовуємо cookies, щоб покращити ваш досвід на сайті.
          Продовжуючи перегляд, ви погоджуєтесь з нашою{' '}
          <Link to="/cookie-policy">Політикою cookies</Link>.
        </p>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Згоден
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;