import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import PageMeta from '../components/PageMeta';
import styles from './Home.module.css';

const statsData = [
  { value: 12, label: 'Років роботи з німецькими вівчарками', suffix: '+' },
  { value: 450, label: 'Собак, що пройшли повні програми', suffix: '+' },
  { value: 96, label: 'Рівень рекомендацій клієнтів', suffix: '%' },
  { value: 32, label: 'Авторських навчальних модулів' }
];

const specializationPoints = [
  {
    title: 'Науково обґрунтована методика',
    description: 'Поєднуємо позитивне підкріплення, роботу з мотивацією та контроль інстинктів, притаманних німецьким вівчаркам.'
  },
  {
    title: 'Практика у міському середовищі',
    description: 'Варшава та Краків пропонують різні сценарії, тому тренування адаптуємо під парки, міські вулиці та охоронні маршрути.'
  },
  {
    title: 'Командний підхід',
    description: 'Працюємо з власниками, щоб сформувати міцний звʼязок, розуміння сигналів та впевнену комунікацію з собакою.'
  },
  {
    title: 'Тестування та супровід',
    description: 'Моніторимо прогрес, проводимо контрольні заняття та консультуємо онлайн між сесіями.'
  }
];

const advantagesData = [
  {
    icon: '🎯',
    title: 'Фокус на німецьких вівчарках',
    description: 'Глибоко розуміємо темперамент, робочі якості та потреби породи, що гарантує точну постановку задач.'
  },
  {
    icon: '🧠',
    title: 'Сертифіковані кінологи',
    description: 'Команда має міжнародні сертифікати IACP та FCI, постійно підвищує кваліфікацію у європейських тренерів.'
  },
  {
    icon: '🤝',
    title: 'Прозора комунікація',
    description: 'Кожен етап тренувального процесу документуємо у звітах з рекомендаціями для сімʼї.'
  }
];

const servicesPreview = [
  {
    title: 'Повсякденна керованість',
    description: 'Команди слухняності у міських умовах, розвиток самоконтролю та стабільності поруч з відволіканнями.'
  },
  {
    title: 'Службова підготовка',
    description: 'Спеціалізовані програми для охоронної служби, пошуку, спорту IGP та рятувальних команд.'
  },
  {
    title: 'Підтримка поведінки',
    description: 'Корекція тривожності, ресурсної охорони, надмірного гавкоту з опорою на емоційний стан собаки.'
  }
];

const geographyData = [
  {
    city: 'Варшава',
    bullets: [
      'Заняття у парках Лазенки, Поле Мокотовське та ін.',
      'Внутрішні тренувальні майданчики для погодних умов',
      'Супровід охоронних бригад у бізнес-центрах'
    ]
  },
  {
    city: 'Краків',
    bullets: [
      'Маршрути у Старому місті та рекреаційних зонах',
      'Польові тренування у лісопаркових територіях',
      'Підготовка до службових іспитів та змагань'
    ]
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Повний аудит',
    description: 'Знайомство з собакою, тестування мотивації, емоційного стану та корекція запиту разом з власником.'
  },
  {
    step: '02',
    title: 'Планування програми',
    description: 'Формуємо модулі, частоту занять та домашні завдання. Узгоджуємо графік для Варшави чи Кракова.'
  },
  {
    step: '03',
    title: 'Практичні сесії',
    description: 'Проводимо індивідуальні заняття, поступово ускладнюємо задачі, інтегруємо ролі всіх членів сімʼї.'
  },
  {
    step: '04',
    title: 'Закріплення результату',
    description: 'Фінальне тестування, рекомендації щодо підтримки, графік онлайн-супроводу та контрольні сесії.'
  },
  {
    step: '05',
    title: 'Підтримка 24/7',
    description: 'Канал для оперативних консультацій, відеоаналіз та розбір нових ситуацій у місті чи на службі.'
  },
  {
    step: '06',
    title: 'Розвиток навичок',
    description: 'Плануємо сезонні цілі: підготовку до виставок, змагань, робочих іспитів або патрульних завдань.'
  }
];

const testimonialsData = [
  {
    quote:
      'Після співпраці з Dog Training Expert наша вівчарка стала керованою навіть у людних місцях Варшави. Тренер демонстрував повагу до собаки і до нас, пояснював логіку кожної вправи.',
    author: 'Марек та Анжеліка',
    location: 'Варшава'
  },
  {
    quote:
      'Програма службової підготовки дозволила нам здати іспит IGP. Тренери тримали звʼязок між заняттями, що було критично важливо під час підготовки.',
    author: 'Олександр',
    location: 'Краків'
  },
  {
    quote:
      'Нам допомогли впоратися з реактивністю. Після трьох місяців собака спокійно реагує на інших псів та транспорт.',
    author: 'Катажина',
    location: 'Варшава'
  }
];

const projectsData = [
  {
    title: 'Підготовка охоронної пари для бізнес-центру',
    category: 'Варшава',
    description: '12-тижнева програма з фокусом на розпізнавання загроз, патрульні маршрути та слухняність на відстані.',
    image: 'https://picsum.photos/1200/800?random=301'
  },
  {
    title: 'Реабілітація реактивної вівчарки',
    category: 'Краків',
    description: 'Побудова системи відволікань, робота з емоційною стабільністю, комплекс домашніх вправ.',
    image: 'https://picsum.photos/1200/800?random=302'
  },
  {
    title: 'Спортивна підготовка до IGP',
    category: 'Краків',
    description: 'Тренування послуху, захисту та сліду під керівництвом сертифікованого фахівця.',
    image: 'https://picsum.photos/1200/800?random=303'
  },
  {
    title: 'Керованість сімейної вівчарки в місті',
    category: 'Варшава',
    description: 'Розвиток самоконтролю, відпрацювання команд в умовах транспорту та багатолюдних парків.',
    image: 'https://picsum.photos/1200/800?random=304'
  }
];

const blogPosts = [
  {
    title: 'Як розвивати концентрацію німецької вівчарки у великому місті',
    date: '05.09.2024',
    image: 'https://picsum.photos/800/600?random=401'
  },
  {
    title: 'Топ 7 сигналів, на які варто звернути увагу під час патрулювання',
    date: '18.08.2024',
    image: 'https://picsum.photos/800/600?random=402'
  },
  {
    title: 'Методи профілактики тривожності розлуки у робочих собак',
    date: '29.07.2024',
    image: 'https://picsum.photos/800/600?random=403'
  }
];

const faqData = [
  {
    question: 'Скільки триває базова програма дресирування?',
    answer: 'Базова програма триває від 10 до 12 тижнів залежно від цілей та характеру собаки. Ми формуємо гнучкий графік під Варшаву чи Краків.'
  },
  {
    question: 'Чи можна поєднати службову та сімейну підготовку?',
    answer: 'Так, ми складаємо комбіновані плани, де собака залишається керованою у сімейному колі та виконує службові задачі.'
  },
  {
    question: 'Як відбувається підтримка між тренуваннями?',
    answer: 'Ми зберігаємо контакт через відеозвʼязок та чат, аналізуємо домашні тренування та коригуємо завдання.'
  },
  {
    question: 'Чи працюєте ви з молодими цуценятами?',
    answer: 'Починаємо підготовку з тримісячного віку, формуємо базові навички соціалізації та контролю інстинктів.'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Усі');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    dogAge: '',
    message: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => {
        let completed = true;
        const updated = prev.map((value, index) => {
          const target = statsData[index].value;
          if (value < target) {
            completed = false;
            const step = Math.ceil(target / 40);
            const nextValue = value + step;
            return nextValue >= target ? target : nextValue;
          }
          return value;
        });
        if (completed) {
          clearInterval(interval);
        }
        return updated;
      });
    }, 80);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const categories = useMemo(
    () => ['Усі', ...new Set(projectsData.map((item) => item.category))],
    []
  );

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Усі') {
      return projectsData;
    }
    return projectsData.filter((item) => item.category === activeCategory);
  }, [activeCategory]);

  const handleFormChange = (event) => {
    const { name, value } = event.target;
    setSubmitted(false);
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Вкажіть ваше ім’я';
    }
    if (!formData.email.trim()) {
      errors.email = 'Електронна пошта обов’язкова';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(formData.email)) {
      errors.email = 'Невірний формат електронної пошти';
    }
    if (!formData.phone.trim()) {
      errors.phone = 'Додайте номер телефону для зворотного зв’язку';
    }
    if (!formData.message.trim()) {
      errors.message = 'Опишіть запит або поведінку собаки';
    }
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validateForm();
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        dogAge: '',
        message: ''
      });
    }
  };

  const currentReview = testimonialsData[currentTestimonial];

  return (
    <>
      <PageMeta
        title="Dog Training Expert — дресирування німецьких вівчарок у Варшаві та Кракові"
        description="Dog Training Expert спеціалізується на дресируванні німецьких вівчарок: індивідуальні програми, службова підготовка, корекція поведінки у Варшаві та Кракові."
      />
      <section className={`container ${styles.hero}`}>
        <div className={styles.heroText}>
          <span className={styles.tag}>Німецькі вівчарки</span>
          <h1 className={styles.heroTitle}>
            Професійне дресирування та служба довіри для вашої вівчарки
          </h1>
          <p className={styles.heroSubtitle}>
            Створюємо індивідуальні програми для робочих і сімейних собак у Варшаві та Кракові. Враховуємо характер, темперамент і робочі цілі, щоб ваша вівчарка стала впевненою, слухняною та мотивованою.
          </p>
          <div className={styles.heroActions}>
            <Link className={styles.primaryBtn} to="/kontakty">
              Запланувати консультацію
            </Link>
            <Link className={styles.secondaryBtn} to="/posluhy-dresyruvannia">
              Дізнатися про програми <span>→</span>
            </Link>
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1600/900?random=101"
            alt="Тренер працює з німецькою вівчаркою"
            loading="lazy"
          />
        </div>
        <div className={styles.stats}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <div className={styles.statValue}>
                {stats[index]}
                {stat.suffix || ''}
              </div>
              <div className={styles.statLabel}>{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Спеціалізація на німецьких вівчарках</h2>
          <p>
            Ми глибоко розуміємо робочі якості породи, тому адаптуємо методики під інстинкти, емоційні реакції та умови, в яких ваша вівчарка працює щодня.
          </p>
        </div>
        <div className={styles.specialization}>
          <div className={styles.specializationList}>
            {specializationPoints.map((item) => (
              <div key={item.title} className={styles.specializationItem}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
          <div className={styles.specializationImage}>
            <img
              src="https://picsum.photos/800/600?random=102"
              alt="Тренування німецької вівчарки у міських умовах"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Наші переваги</h2>
          <p>
            Dog Training Expert гарантує системність, безпеку та результативність, спираючись на багаторічну практику та сучасні кінологічні стандарти.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          {advantagesData.map((advantage) => (
            <div key={advantage.title} className={styles.advantageCard}>
              <div className={styles.advantageIcon}>{advantage.icon}</div>
              <h3>{advantage.title}</h3>
              <p>{advantage.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Послуги дресирування</h2>
          <p>
            Обираємо поєднання модулів залежно від віку собаки, її робочих задач та цілей сім’ї. Це дозволяє отримати контроль у будь-яких умовах.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          {servicesPreview.map((service) => (
            <div key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Географія послуг: Варшава та Краків</h2>
          <p>
            Займаємось у зручних для вас локаціях: від міських парків до спеціалізованих майданчиків та службових просторів.
          </p>
        </div>
        <div className={styles.geoList}>
          {geographyData.map((geo) => (
            <div key={geo.city} className={styles.geoCard}>
              <h3>{geo.city}</h3>
              <ul>
                {geo.bullets.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Процес дресирування</h2>
          <p>
            Працюємо крок за кроком, щоб зміни були стійкими, а собака демонструвала нові навички у повсякденному житті.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <div key={step.step} className={styles.processStep}>
              <span>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.testimonials}>
          <div>
            <h2>Відгуки наших клієнтів</h2>
            <p>
              Клієнти Dog Training Expert відзначають прогрес, прозорий підхід та підтримку після завершення програми.
            </p>
            <div className={styles.testimonialControls}>
              <button
                type="button"
                className={styles.controlBtn}
                onClick={() =>
                  setCurrentTestimonial(
                    (currentTestimonial - 1 + testimonialsData.length) %
                      testimonialsData.length
                  )
                }
                aria-label="Попередній відгук"
              >
                ‹
              </button>
              <button
                type="button"
                className={styles.controlBtn}
                onClick={() =>
                  setCurrentTestimonial((currentTestimonial + 1) % testimonialsData.length)
                }
                aria-label="Наступний відгук"
              >
                ›
              </button>
            </div>
          </div>
          <div>
            <div className={styles.testimonial}>&ldquo;{currentReview.quote}&rdquo;</div>
            <div className={styles.testimonialInfo}>
              <strong>{currentReview.author}</strong>
              <span>{currentReview.location}</span>
            </div>
          </div>
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Наші проєкти</h2>
          <p>
            Результати програм у Варшаві та Кракові для робочих та сімейних вівчарок. Оберіть категорію, щоб переглянути кейси.
          </p>
        </div>
        <div className={styles.projectsFilters}>
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterBtn} ${
                activeCategory === category ? styles.filterBtnActive : ''
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <div key={project.title} className={styles.projectCard}>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <div className={styles.projectImage}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>FAQ — поширені питання</h2>
          <p>
            Зібрали відповіді на питання, які найчастіше отримуємо від власників німецьких вівчарок.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          {faqData.map((item) => (
            <div key={item.question} className={styles.faqItem}>
              <details>
                <summary>{item.question}</summary>
                <div className={styles.faqAnswer}>{item.answer}</div>
              </details>
            </div>
          ))}
        </div>
      </section>

      <section id="home-contact" className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Отримайте індивідуальний план</h2>
          <p>
            Заповніть форму, щоб ми підготували маршрут тренувань для вашої вівчарки. Відповімо протягом робочого дня.
          </p>
        </div>
        <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
          {submitted && (
            <div className={styles.success}>
              Дякуємо! Ми зв’яжемося з вами найближчим часом.
            </div>
          )}
          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <label htmlFor="home-name">Ім’я</label>
              <input
                id="home-name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleFormChange}
                placeholder="Ваше ім’я"
              />
              {formErrors.name && <span className={styles.error}>{formErrors.name}</span>}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="home-email">Електронна пошта</label>
              <input
                id="home-email"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleFormChange}
                placeholder="name@example.com"
              />
              {formErrors.email && <span className={styles.error}>{formErrors.email}</span>}
            </div>
          </div>
          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <label htmlFor="home-phone">Телефон</label>
              <input
                id="home-phone"
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleFormChange}
                placeholder="+48 ..."
              />
              {formErrors.phone && <span className={styles.error}>{formErrors.phone}</span>}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="home-dogAge">Вік собаки</label>
              <select
                id="home-dogAge"
                name="dogAge"
                value={formData.dogAge}
                onChange={handleFormChange}
              >
                <option value="">Оберіть</option>
                <option value="Цуценя до 6 місяців">Цуценя до 6 місяців</option>
                <option value="6-12 місяців">6-12 місяців</option>
                <option value="1-3 роки">1-3 роки</option>
                <option value="3+ років">3+ років</option>
              </select>
            </div>
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="home-message">Опишіть ваш запит</label>
            <textarea
              id="home-message"
              name="message"
              rows="4"
              value={formData.message}
              onChange={handleFormChange}
              placeholder="Розкажіть про цілі та поведінку вашої вівчарки"
            />
            {formErrors.message && <span className={styles.error}>{formErrors.message}</span>}
          </div>
          <button type="submit" className={styles.primaryBtn}>
            Надіслати запит
          </button>
        </form>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.sectionHeader}>
          <h2>Останні матеріали</h2>
          <p>
            Корисні поради та аналітика для власників німецьких вівчарок, зібрані нашою командою кінологів.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <span>{post.date}</span>
              <h3>{post.title}</h3>
              <Link className={styles.secondaryBtn} to="/pro-nas">
                Читати більше <span>→</span>
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.ctaBlock}>
          <h2>Готові розпочати тренування?</h2>
          <p>
            Команда Dog Training Expert допоможе вашій вівчарці реалізувати потенціал, а вам — отримати впевненість у кожній ситуації.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/kontakty" className={styles.ctaButton}>
              Записатися на консультацію
            </Link>
            <Link to="/nashi-kliienty" className={styles.ctaSecondary}>
              Дивитись історії клієнтів
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;