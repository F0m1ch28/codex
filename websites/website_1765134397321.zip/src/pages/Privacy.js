import React from 'react';
import PageMeta from '../components/PageMeta';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <PageMeta
      title="Політика конфіденційності — Dog Training Expert"
      description="Дізнайтеся, як Dog Training Expert обробляє персональні дані клієнтів у Польщі."
    />
    <section className={`container ${styles.page}`}>
      <h1 className={styles.heading}>Політика конфіденційності</h1>
      <p className={styles.updated}>Оновлено: 1 вересня 2024 року</p>

      <div className={styles.section}>
        <h2>1. Мета обробки даних</h2>
        <p>
          Ми збираємо персональні дані, щоб відповісти на запити, організувати тренування, вести комунікацію та надсилати корисні матеріали про дресирування німецьких вівчарок.
        </p>
      </div>

      <div className={styles.section}>
        <h2>2. Які дані ми отримуємо</h2>
        <ul>
          <li>Ім’я та контактні дані (телефон, email), які ви залишаєте у формах.</li>
          <li>Відомості про собаку: вік, поведінкові особливості, цілі тренування.</li>
          <li>Технічні дані (IP-адреса, тип браузера) для захисту від зловживань.</li>
        </ul>
      </div>

      <div className={styles.section}>
        <h2>3. Зберігання та захист</h2>
        <p>
          Дані зберігаються на захищених серверах, доступ до яких мають лише співробітники Dog Training Expert. Ми не передаємо інформацію третім особам без вашої згоди, крім випадків, передбачених законодавством Польщі.
        </p>
      </div>

      <div className={styles.section}>
        <h2>4. Ваші права</h2>
        <ul>
          <li>Отримати копію даних, які ми зберігаємо.</li>
          <li>Вимагати оновлення, виправлення або видалення інформації.</li>
          <li>Відкликати згоду на обробку даних, написавши на info@dogtrainingexpert.pl.</li>
        </ul>
      </div>

      <div className={styles.section}>
        <h2>5. Контакти</h2>
        <p>
          Якщо у вас є питання щодо конфіденційності, звертайтеся за адресою: Варшава, вул. Собача, 15 або Краків, вул. Песя, 8.
          Також ви можете написати на info@dogtrainingexpert.pl.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;