import React from 'react';
import PageMeta from '../components/PageMeta';
import styles from './About.module.css';

const values = [
  {
    icon: '🧭',
    title: 'Місія',
    description:
      'Підвищувати якість взаємодії між людьми та німецькими вівчарками через індивідуальний підхід, розуміння поведінки та емоцій.'
  },
  {
    icon: '🔍',
    title: 'Аналітика',
    description:
      'На кожному етапі проводимо оцінку прогресу, ведемо протоколи та відеозаписи, щоб ви бачили динаміку і могли повторювати методики вдома.'
  },
  {
    icon: '💬',
    title: 'Підтримка',
    description:
      'Консультуємо 24/7, відповідаємо на запитання щодо поведінки, режиму та розкладу тренувань у Варшаві й Кракові.'
  }
];

const teamMembers = [
  {
    name: 'Ірина Левандовська',
    role: 'Головний кінолог',
    bio: '15 років тренує службових собак, сертифікована IACP, спеціалізується на охороні та сліду.',
    image: 'https://picsum.photos/400/400?random=201'
  },
  {
    name: 'Петро Демський',
    role: 'Тренер поведінки',
    bio: 'Фахівець із корекції складної поведінки, працює з емоційними реакціями та середовищем.',
    image: 'https://picsum.photos/400/400?random=202'
  },
  {
    name: 'Марія Соболь',
    role: 'Коуч власників',
    bio: 'Педагог і кінолог, допомагає сімʼям вибудовувати рутину тренувань та комунікацію з собакою.',
    image: 'https://picsum.photos/400/400?random=203'
  }
];

const timeline = [
  {
    year: '2012',
    event: 'Старт практики у Варшаві',
    details: 'Перші індивідуальні програми для службових пар у бізнес-центрах та приватних об’єктах.'
  },
  {
    year: '2016',
    event: 'Вихід на міжнародні сертифікації',
    details: 'Команда отримала сертифікати IACP та FCI, розширила програму до спортивних дисциплін.'
  },
  {
    year: '2019',
    event: 'Відкриття філії у Кракові',
    details: 'Запустили тренування на природних локаціях, підготовку до IGP та рятувальних завдань.'
  },
  {
    year: '2023',
    event: 'Онлайн-супровід',
    details: 'Додали цифрову платформу для обміну відео і зворотного зв’язку між тренуваннями.'
  }
];

const methods = [
  {
    title: 'Синергія позитивних методів',
    text: 'Поєднуємо позитивне підкріплення, ігрову мотивацію та контроль імпульсів. Завдяки цьому собака зберігає бажання співпрацювати.'
  },
  {
    title: 'Мультисенсорні тренування',
    text: 'Відпрацьовуємо завдання на різні аналізатори: нюх, слух, зір. Так тренування максимально наближені до реальності.'
  },
  {
    title: 'Прозорі звіти',
    text: 'Після кожної сесії надсилаємо підсумок із відео, коментарями та домашнім завданням для власників.'
  },
  {
    title: 'Безпечні протоколи',
    text: 'Дотримуємося правил гуманного поводження, працюємо з ветеринарними фахівцями щодо умовних фізичних навантажень.'
  }
];

const stats = [
  { label: 'Постійних клієнтів у Варшаві', value: '120+' },
  { label: 'Командних проєктів із службами', value: '45' },
  { label: 'Собак, що пройшли реабілітацію', value: '80+' }
];

const About = () => {
  return (
    <>
      <PageMeta
        title="Про Dog Training Expert — команда професійних кінологів"
        description="Dog Training Expert — команда сертифікованих тренерів із Варшави та Кракова, що спеціалізується на дресируванні німецьких вівчарок."
      />
      <section className={`container ${styles.hero}`}>
        <div className={styles.heroContent}>
          <h1>Команда, якій довіряють власники німецьких вівчарок</h1>
          <p>
            Ми поєднуємо науковий підхід до поведінки, практику в реальних умовах та емпатію до собаки і власника. Dog Training Expert — це партнери, які допоможуть вам вибудувати впевнені стосунки з вівчаркою незалежно від ваших цілей.
          </p>
          <div className={styles.stats}>
            {stats.map((stat) => (
              <div key={stat.label} className={styles.stat}>
                <label>{stat.label}</label>
                <strong>{stat.value}</strong>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/900/700?random=204"
            alt="Команда Dog Training Expert на тренуванні"
            loading="lazy"
          />
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div>
          <h2>Наші цінності</h2>
          <p>
            Ми працюємо з людьми і собаками, тому цінуємо довіру, прозорість та правильне налаштування очікувань. З першої зустрічі ви розумієте, як буде розвиватися тренувальний план і яку роль відіграє кожен член родини.
          </p>
        </div>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <div key={value.title} className={styles.valueCard}>
              <div className={styles.valueIcon}>{value.icon}</div>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div>
          <h2>Команда Dog Training Expert</h2>
          <p>
            Кожен тренер має спеціалізацію, але ми працюємо синхронно. Обмінюємось досвідом, розробляємо спільні програми та підтримуємо один одного на заняттях.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImage}>
                <img src={member.image} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.teamInfo}>
                <span className={styles.teamRole}>{member.role}</span>
                <h3>{member.name}</h3>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div>
          <h2>Історія розвитку</h2>
          <p>
            З маленької студії дресирування у Варшаві ми виросли у мультидисциплінарну команду, що працює у двох містах та співпрацює з охоронними службами.
          </p>
        </div>
        <div className={styles.timeline}>
          {timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <div className={styles.timelineYear}>{item.year}</div>
              <strong>{item.event}</strong>
              <p>{item.details}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div>
          <h2>Методологія роботи</h2>
          <p>
            Наші протоколи поєднують досвід службових тренувань, сімейної поведінки та спортивних досягнень. Це дозволяє будувати гнучкі програми під будь-який запит.
          </p>
        </div>
        <div className={styles.methodGrid}>
          {methods.map((method) => (
            <div key={method.title} className={styles.methodCard}>
              <h3>{method.title}</h3>
              <p>{method.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.partnerBlock}>
          <h2>Партнерство з власниками</h2>
          <p>
            Ми переконані, що довготривалий результат можливий лише за умови включеності власника. Тому кожна програма включає тренування разом із сім’єю, домашні завдання та регулярний зворотний зв’язок.
          </p>
          <ul>
            <li>Проводимо тренінги для членів сім’ї щодо комунікації з собакою.</li>
            <li>Записуємо відеоінструкції та надаємо чек-листи з догляду та безпеки.</li>
            <li>Консультуємо щодо фізичних навантажень і відновлення після занять.</li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default About;