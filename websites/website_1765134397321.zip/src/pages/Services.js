import React from 'react';
import PageMeta from '../components/PageMeta';
import styles from './Services.module.css';

const serviceCategories = [
  {
    icon: '🏙️',
    title: 'Міська слухняність',
    description: 'Формуємо керованість і спокій у транспорті, біля людей, на майданчиках Варшави та Кракова.',
    points: [
      'Базові й розширені команди слухняності',
      'Розвиток самоконтролю біля відволікань',
      'Відпрацювання маршрутових прогулянок'
    ]
  },
  {
    icon: '🛡️',
    title: 'Службова підготовка',
    description: 'Тренуємо собак охорони, патрулювання, а також готуємо до нормативів IGP, Mondioring.',
    points: [
      'Розвиток захисних навичок та хватів',
      'Побудова чітких команд з дистанції',
      'Створення сценаріїв для об’єктів клієнта'
    ]
  },
  {
    icon: '🧘',
    title: 'Емоційний баланс',
    description: 'Працюємо з реактивністю, тривожністю, небажаною агресією та поведінковими викликами.',
    points: [
      'Аналіз тригерів та план десенсибілізації',
      'Робота з позитивним підкріпленням',
      'Супровід власника в складних ситуаціях'
    ]
  },
  {
    icon: '👶',
    title: 'Робота з цуценятами',
    description: 'Створюємо фундамент слухняності та соціалізації для молодих вівчарок з тримісячного віку.',
    points: [
      'Соціалізація у місті й природі',
      'Формування навичок гігієни та рутини',
      'Ігрове побудування команд'
    ]
  }
];

const programs = [
  {
    title: 'Стартовий курс оцінки',
    description: 'Дві аналітичні зустрічі, щоб визначити рівень собаки, цілі власника та форму майбутньої програми.'
  },
  {
    title: 'Комплексний інтенсив',
    description: 'Індивідуальні заняття 2-3 рази на тиждень, домашні завдання, відеозвіти та групові тренування за потреби.'
  },
  {
    title: 'Супровід після програми',
    description: 'Щомісячні контрольні сесії, оновлення вправ, підтримка онлайн-каналом з тренером.'
  }
];

const process = [
  {
    title: 'Діагностика',
    text: 'Вивчаємо історію собаки, проводимо тести на мотивацію, взаємодіємо з власником для узгодження очікувань.'
  },
  {
    title: 'Проєктування програми',
    text: 'Створюємо модулі, розклад і чіткі критерії. Пропонуємо локації у Варшаві чи Кракові залежно від задач.'
  },
  {
    title: 'Реалізація та аналіз',
    text: 'Проводимо тренування, надаємо зворотний зв’язок, коригуємо план. Кожен етап завершується контрольним тестом.'
  }
];

const assurances = [
  'Використовуємо лише гуманні методи, схвалені міжнародними асоціаціями.',
  'Працюємо у малих групах або індивідуально, щоб контролювати середовище.',
  'Передаємо власнику чіткі інструкції та відеопояснення для домашньої роботи.',
  'Підтримуємо контакт з вами та собакою після завершення інтенсиву.'
];

const Services = () => {
  return (
    <>
      <PageMeta
        title="Послуги дресирування Dog Training Expert"
        description="Dog Training Expert пропонує програми дресирування німецьких вівчарок: міська слухняність, службова підготовка, робота з поведінкою та підтримка цуценят."
      />
      <section className={`container ${styles.hero}`}>
        <h1>Послуги дресирування для німецьких вівчарок</h1>
        <p>
          Ми створюємо індивідуальні програми для робочих та сімейних собак. Незалежно від того, чи потрібна вам базова слухняність у місті, чи підготовка до службових задач, команда Dog Training Expert забезпечить чіткий план та професійний супровід.
        </p>
      </section>

      <section className={`container ${styles.sections}`}>
        <div>
          <h2>Напрями роботи</h2>
          <p>
            Обирайте те, що підходить вашій вівчарці. За потреби комбінуємо модулі, щоб охопити кілька задач одночасно.
          </p>
        </div>
        <div className={styles.categoryGrid}>
          {serviceCategories.map((category) => (
            <article key={category.title} className={styles.categoryCard}>
              <div className={styles.categoryHeader}>
                <div className={styles.categoryIcon}>{category.icon}</div>
                <h3>{category.title}</h3>
              </div>
              <p>{category.description}</p>
              <ul className={styles.list}>
                {category.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.sections}`}>
        <div className={styles.programs}>
          <h2>Структура програм</h2>
          <p>
            Кожна програма має стартову діагностику, основний блок тренувань та завершальний етап із закріпленням результату.
          </p>
          <ul>
            {programs.map((program) => (
              <li key={program.title}>
                <span>{program.title}</span>
                <p>{program.description}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={`container ${styles.sections}`}>
        <div>
          <h2>Як ми працюємо</h2>
        </div>
        <div className={styles.process}>
          {process.map((step) => (
            <div key={step.title} className={styles.processStep}>
              <strong>{step.title}</strong>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.sections}`}>
        <div className={styles.assurance}>
          <h2>Гарантії безпеки та прозорості</h2>
          <p>
            Ми цінуємо довіру та здоров’я собак, тому дотримуємося етичних стандартів і завжди пояснюємо зміст вправ.
          </p>
          <div className={styles.assuranceBadge}>Dog Training Expert</div>
          <ul className={styles.assuranceList}>
            {assurances.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
};

export default Services;