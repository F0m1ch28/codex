import React from 'react';
import PageMeta from '../components/PageMeta';
import styles from './Clients.module.css';

const caseStudies = [
  {
    title: 'Службова пара для бізнес-центру',
    location: 'Варшава',
    highlights: [
      '45 годин тренувань із нічними сценаріями',
      'Відпрацьовано команди дистанційного контролю',
      'Створено протокол взаємодії з персоналом'
    ],
    outcome:
      'Результат: службова пара успішно пройшла внутрішню атестацію та працює без позапланових інцидентів у пікові години.'
  },
  {
    title: 'Реабілітація реактивної вівчарки',
    location: 'Краків',
    highlights: [
      'Аналіз тригерів та план десенсибілізації',
      'Комбіновані тренування у місті та на природі',
      'Навчання сім’ї технікам управління'
    ],
    outcome:
      'Результат: собака впевнено рухається містом, власники отримали чіткий протокол дій для нових ситуацій.'
  },
  {
    title: 'Підготовка до змагань IGP',
    location: 'Краків',
    highlights: [
      'Поєднання сліду, послуху та захисту',
      'Відеоаналіз кожного етапу підготовки',
      'Співпраця з асистентами на стадіоні'
    ],
    outcome:
      'Результат: команда здобула 2 місце на регіональних стартах, отримала високі бали за дисципліну та контроль.'
  }
];

const testimonials = [
  {
    quote:
      'Dog Training Expert підготували нашого службового собаку до роботи у бізнес-центрі. Власники будівлі відзначили професійність і чіткі протоколи взаємодії.',
    author: 'Security Management Sp. z o.o.'
  },
  {
    quote:
      'Наша вівчарка нарешті спокійно зустрічає гостей. Ми отримали покроковий план та підтримку після завершення курсу.',
    author: 'Сім’я Новаків, Варшава'
  }
];

const metrics = [
  { value: '92%', label: 'Клієнтів зазначають підвищення керованості вже після 6 занять' },
  { value: '87%', label: 'Повертаються на сезонні програми підтримки' },
  { value: '40+', label: 'Партнерських організацій у Варшаві та Кракові' },
  { value: '4.9/5', label: 'Середній рейтинг відгуків на незалежних платформах' }
];

const partners = ['Security Warsaw Group', 'Kraków Rescue Team', 'Active Shepherd Families'];

const Clients = () => {
  return (
    <>
      <PageMeta
        title="Наші клієнти — Dog Training Expert"
        description="Ознайомтеся з кейсами Dog Training Expert: службові, сімейні та спортивні німецькі вівчарки у Варшаві та Кракові."
      />
      <section className={`container ${styles.hero}`}>
        <h1>Наші клієнти</h1>
        <p>
          Ми співпрацюємо з охоронними компаніями, приватними власниками та спортивними командами.
          Кожен кейс — це індивідуальна історія, де в центрі уваги собака, її роль та комфорт власника.
        </p>
      </section>

      <section className={`container ${styles.section}`}>
        <h2>Результати та кейси</h2>
        <div className={styles.caseGrid}>
          {caseStudies.map((item) => (
            <article key={item.title} className={styles.caseCard}>
              <div className={styles.caseHeader}>
                <strong>{item.title}</strong>
                <span className={styles.caseLocation}>{item.location}</span>
              </div>
              <ul className={styles.caseList}>
                {item.highlights.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
              <p>{item.outcome}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.testimonialBlock}>
          <h2>Відгуки партнерів</h2>
          {testimonials.map((testimonial) => (
            <blockquote key={testimonial.author}>
              “{testimonial.quote}”
              <footer>— {testimonial.author}</footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <h2>Цифри, якими ми пишаємося</h2>
        <div className={styles.metrics}>
          {metrics.map((metric) => (
            <div key={metric.label} className={styles.metricCard}>
              <strong>{metric.value}</strong>
              <p>{metric.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`container ${styles.section}`}>
        <h2>Партнерські організації</h2>
        <div className={styles.logos}>
          {partners.map((partner) => (
            <div key={partner} className={styles.logoCard}>
              {partner}
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Clients;