import React from 'react';
import PageMeta from '../components/PageMeta';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <PageMeta
      title="Політика Cookies — Dog Training Expert"
      description="Dog Training Expert пояснює використання файлів cookies на сайті."
    />
    <section className={`container ${styles.page}`}>
      <h1 className={styles.heading}>Політика Cookies</h1>
      <p className={styles.updated}>Оновлено: 1 вересня 2024 року</p>

      <div className={styles.section}>
        <h2>1. Що таке cookies</h2>
        <p>
          Cookies — це невеликі текстові файли, які зберігаються у вашому браузері для забезпечення стабільної роботи сайту.
          Вони не містять персональних даних і не використовуються для ідентифікації особи.
        </p>
      </div>

      <div className={styles.section}>
        <h2>2. Які cookies ми використовуємо</h2>
        <ul>
          <li>Технічні cookies — необхідні для роботи навігації та форм.</li>
          <li>Аналітичні cookies — допомагають зрозуміти, які сторінки користуються попитом.</li>
          <li>Функціональні cookies — запам’ятовують ваші налаштування (наприклад, вибір мови).</li>
        </ul>
      </div>

      <div className={styles.section}>
        <h2>3. Керування cookies</h2>
        <p>
          Ви можете будь-коли змінити налаштування або видалити cookies через параметри свого браузера.
          Однак повне вимкнення cookies може вплинути на роботу окремих розділів сайту.
        </p>
      </div>

      <div className={styles.section}>
        <h2>4. Зміни політики</h2>
        <p>
          Ми можемо оновлювати цю політику, щоб відобразити зміни у законодавстві чи роботі сервісу. Рекомендуємо час від часу переглядати сторінку для отримання актуальної інформації.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;