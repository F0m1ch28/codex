import React, { useState } from 'react';
import PageMeta from '../components/PageMeta';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setSubmitted(false);
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const validationErrors = {};
    if (!formData.name.trim()) {
      validationErrors.name = 'Вкажіть ваше ім’я.';
    }
    if (!formData.email.trim()) {
      validationErrors.email = 'Електронна пошта обов’язкова.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(formData.email)) {
      validationErrors.email = 'Невірний формат електронної пошти.';
    }
    if (!formData.phone.trim()) {
      validationErrors.phone = 'Будь ласка, додайте номер телефону.';
    }
    if (!formData.message.trim()) {
      validationErrors.message = 'Розкажіть про ваш запит.';
    }
    return validationErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        message: ''
      });
    }
  };

  return (
    <>
      <PageMeta
        title="Контакти Dog Training Expert"
        description="Звʼяжіться з Dog Training Expert у Варшаві та Кракові. Телефон +48 123 456 789, email info@dogtrainingexpert.pl."
      />
      <section className={`container ${styles.hero}`}>
        <h1>Контакти</h1>
        <p>
          Заплануйте зустріч у Варшаві чи Кракові, або надішліть нам повідомлення — підготуємо індивідуальний план для вашої німецької вівчарки.
        </p>
      </section>

      <section className={`container ${styles.section}`}>
        <div className={styles.grid}>
          <div className={styles.contactCard}>
            <h2>Адреси та зв’язок</h2>
            <div className={styles.contactDetails}>
              <div className={styles.detailGroup}>
                <span>Варшава</span>
                <strong>вул. Собача, 15</strong>
              </div>
              <div className={styles.detailGroup}>
                <span>Краків</span>
                <strong>вул. Песя, 8</strong>
              </div>
              <div className={styles.detailGroup}>
                <span>Телефон</span>
                <strong><a href="tel:+48123456789">+48 123 456 789</a></strong>
              </div>
              <div className={styles.detailGroup}>
                <span>Email</span>
                <strong><a href="mailto:info@dogtrainingexpert.pl">info@dogtrainingexpert.pl</a></strong>
              </div>
              <div className={styles.detailGroup}>
                <span>Графік</span>
                <strong>Пн–Сб: 08:00–20:00</strong>
              </div>
            </div>
          </div>

          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <h2>Напишіть нам</h2>
            {submitted && <div className={styles.success}>Дякуємо! Ми відповімо протягом робочого дня.</div>}
            <div className={styles.row}>
              <div className={styles.field}>
                <label htmlFor="contact-name">Ім’я</label>
                <input
                  id="contact-name"
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Ваше ім’я"
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-email">Електронна пошта</label>
                <input
                  id="contact-email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="name@example.com"
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
            </div>
            <div className={styles.field}>
              <label htmlFor="contact-phone">Телефон</label>
              <input
                id="contact-phone"
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+48 ..."
              />
              {errors.phone && <span className={styles.error}>{errors.phone}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="contact-message">Повідомлення</label>
              <textarea
                id="contact-message"
                name="message"
                rows="4"
                value={formData.message}
                onChange={handleChange}
                placeholder="Опишіть поведінку та цілі вашої вівчарки"
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>
            <button type="submit" className={styles.submit}>
              Надіслати
            </button>
          </form>
        </div>

        <div className={styles.mapSection}>
          <div className={styles.mapFrame}>
            <iframe
              title="Dog Training Expert Варшава"
              src="https://maps.google.com/maps?q=Warsaw%20Poland&z=12&output=embed"
              loading="lazy"
            />
          </div>
          <div className={styles.mapFrame}>
            <iframe
              title="Dog Training Expert Краків"
              src="https://maps.google.com/maps?q=Krakow%20Poland&z=12&output=embed"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;