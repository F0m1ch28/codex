document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.site-nav__toggle');
  const navList = document.querySelector('.site-nav__list');
  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navList.classList.toggle('site-nav__list--open');
      navList.setAttribute('aria-expanded', String(!expanded));
    });
  }

  const yearEl = document.querySelectorAll('#year');
  yearEl.forEach(el => (el.textContent = new Date().getFullYear()));

  const banner = document.getElementById('cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const consent = localStorage.getItem('cookie-consent');
  if (!consent && banner) {
    requestAnimationFrame(() => banner.classList.add('cookie-banner--visible'));
  } else {
    if (consent === 'declined') document.body.classList.add('cookies-declined');
  }
  const hideBanner = () => banner && banner.classList.remove('cookie-banner--visible');
  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('cookie-consent', 'accepted');
    document.body.classList.remove('cookies-declined');
    hideBanner();
  });
  declineBtn?.addEventListener('click', () => {
    localStorage.setItem('cookie-consent', 'declined');
    document.body.classList.add('cookies-declined');
    hideBanner();
  });

  const filterButtons = document.querySelectorAll('[data-filter]');
  const greetingCards = document.querySelectorAll('[data-category]');
  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      filterButtons.forEach(btn => btn.classList.remove('filter-bar__button--active'));
      button.classList.add('filter-bar__button--active');
      greetingCards.forEach(card => {
        const category = card.dataset.category;
        const shouldShow = filter === 'all' || category === filter;
        card.style.display = shouldShow ? 'flex' : 'none';
      });
    });
  });

  const copyButtons = document.querySelectorAll('[data-copy]');
  copyButtons.forEach(btn => {
    btn.addEventListener('click', async () => {
      const text = btn.dataset.copy;
      if (!text) return;
      try {
        await navigator.clipboard.writeText(text);
        btn.textContent = 'Көшіру орындалды!';
        setTimeout(() => (btn.textContent = 'Мәтінді көшіру'), 2200);
      } catch {
        btn.textContent = 'Қате болды';
        setTimeout(() => (btn.textContent = 'Мәтінді көшіру'), 2200);
      }
    });
  });

  const digitalCards = document.querySelectorAll('[data-card]');
  digitalCards.forEach(card => {
    const toggle = card.querySelector('[data-card-toggle]');
    toggle?.addEventListener('click', () => {
      card.classList.toggle('digital-card--open');
      toggle.textContent = card.classList.contains('digital-card--open') ? 'Картаны жабу' : 'Картаны ашу';
    });
  });

  const createForm = document.querySelector('[data-create-form]');
  if (createForm) {
    const sender = createForm.querySelector('#sender');
    const recipient = createForm.querySelector('#recipient');
    const tone = createForm.querySelector('#tone');
    const memory = createForm.querySelector('#memory');
    const message = createForm.querySelector('#message');

    const previewRecipient = document.querySelector('[data-preview-recipient]');
    const previewSender = document.querySelector('[data-preview-sender]');
    const previewTone = document.querySelector('[data-preview-tone]');
    const previewBody = document.querySelector('[data-preview-body]');

    const updatePreview = () => {
      previewRecipient.textContent = recipient.value.trim() || 'Қымбатты жан';
      previewSender.textContent = sender.value.trim() || 'Ізгі ниетпен';
      previewTone.textContent = tone.value;
      const base = memory.value ? `Бірге өткізген ${memory.value.toLowerCase()} есіме түскен сайын жүрегім қуанышқа толады.` : '';
      const messageText = message.value.trim();
      previewBody.textContent = `${base ? base + ' ' : ''}${messageText || 'Сіздің қолдауыңыз әрдайым күш береді. Мереке құтты болсын!'}`;
    };

    createForm.addEventListener('input', updatePreview);
    updatePreview();

    createForm.addEventListener('submit', async event => {
      event.preventDefault();
      const finalText = `${recipient.value || 'Құрметті жан'},\n${previewBody.textContent}\n\nІзгі тілекпен, ${sender.value || 'Жақыныңыз'}.\nСтиль: ${tone.value}.`;
      try {
        await navigator.clipboard.writeText(finalText);
        alert('Мәтін буферге сақталды!');
      } catch {
        alert('Көшіру мүмкін болмады. Мәтінді қолмен белгілеңіз.');
      }
    });
  }

  const contactForm = document.getElementById('contact-form');
  const feedbackEl = document.getElementById('form-feedback');
  if (contactForm && feedbackEl) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const message = formData.get('feedback')?.toString().trim() || '';
      if (message.length < 10) {
        feedbackEl.textContent = 'Хабарламаңыз кемінде 10 таңба болуы керек.';
        feedbackEl.style.color = '#b00020';
        return;
      }
      feedbackEl.textContent = 'Хабарламаңыз қабылданды! Жуырда байланысқа шығамыз.';
      feedbackEl.style.color = '#0a8f55';
      contactForm.reset();
    });
  }
});