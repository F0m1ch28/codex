```javascript
import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [open]);

  const closeMenu = () => setOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ""}`}>
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.logoArea}>
            <NavLink to="/" className={styles.logo} onClick={closeMenu}>
              <span className={styles.logoAccent}>Alta</span>verino
            </NavLink>
            <span className={styles.tagline}>Zeit gestalten. Leben stärken.</span>
          </div>
          <nav className={`${styles.nav} ${open ? styles.open : ""}`}>
            <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Start
            </NavLink>
            <NavLink to="/methoden" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Methoden
            </NavLink>
            <NavLink to="/ressourcen" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Ressourcen
            </NavLink>
            <NavLink to="/ueber-uns" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Über uns
            </NavLink>
            <NavLink to="/kontakt" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Kontakt
            </NavLink>
          </nav>
          <button
            className={`${styles.burger} ${open ? styles.open : ""}`}
            onClick={() => setOpen((prev) => !prev)}
            aria-label="Menü öffnen oder schließen"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
```