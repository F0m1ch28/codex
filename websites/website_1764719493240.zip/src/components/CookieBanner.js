```javascript
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("altaverino-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("altaverino-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner}>
      <div className={styles.text}>
        <strong>Cookies &amp; Analyse:</strong> Wir nutzen ausschließlich technisch notwendige Cookies sowie anonymisierte Auswertungen, um unser Angebot zu verbessern. Details findest du in unserer <Link to="/datenschutz">Datenschutzerklärung</Link>.
      </div>
      <button className="primaryButton" onClick={handleAccept}>
        Verstanden
      </button>
    </div>
  );
};

export default CookieBanner;
```