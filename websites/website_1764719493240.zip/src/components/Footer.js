```javascript
import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.columnLarge}>
          <div className={styles.brand}>
            <span className={styles.logo}>Altaverino</span>
            <p>Analytische Plattform für Menschen, die ihre Zeit bewusst gestalten und langfristig gesund produktiv bleiben möchten.</p>
          </div>
          <div className={styles.contact}>
            <span>E-Mail:</span>
            <a href="mailto:kontakt@altaverino.site">kontakt@altaverino.site</a>
            <span>Website:</span>
            <a href="https://altaverino.site" rel="noopener noreferrer">altaverino.site</a>
            <span>Standort:</span>
            <p>Deutschland</p>
          </div>
        </div>
        <div className={styles.column}>
          <h4>Navigation</h4>
          <ul>
            <li>
              <NavLink to="/">Start</NavLink>
            </li>
            <li>
              <NavLink to="/methoden">Methoden &amp; Ansätze</NavLink>
            </li>
            <li>
              <NavLink to="/ressourcen">Ressourcen &amp; Tools</NavLink>
            </li>
            <li>
              <NavLink to="/ueber-uns">Über Altaverino</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Rechtliches</h4>
          <ul>
            <li>
              <NavLink to="/impressum">Impressum</NavLink>
            </li>
            <li>
              <NavLink to="/datenschutz">Datenschutz</NavLink>
            </li>
            <li>
              <NavLink to="/nutzungsbedingungen">Nutzungsbedingungen</NavLink>
            </li>
            <li>
              <NavLink to="/kontakt">Kontakt</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Fokus-Themen</h4>
          <div className="tagRow">
            <span className="tag">Time-Management</span>
            <span className="tag">Energiepflege</span>
            <span className="tag">Wochenplanung</span>
            <span className="tag">Routinen</span>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Altaverino. Alle Rechte vorbehalten.</p>
      </div>
    </div>
  </footer>
);

export default Footer;
```