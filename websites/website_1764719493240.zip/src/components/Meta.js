```javascript
import { useEffect } from "react";

const Meta = ({ title, description }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      let element = document.querySelector('meta[name="description"]');
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute("name", "description");
        document.head.appendChild(element);
      }
      element.setAttribute("content", description);
    }
  }, [title, description]);

  return null;
};

export default Meta;
```