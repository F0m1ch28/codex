```javascript
import React, { useState } from "react";
import Meta from "../components/Meta";
import styles from "./Contact.module.css";

const initialState = {
  name: "",
  email: "",
  subject: "",
  message: ""
};

const KontaktPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) currentErrors.name = "Bitte gib deinen Namen ein.";
    if (!formData.email.trim()) {
      currentErrors.email = "Eine E-Mail-Adresse wird benötigt.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      currentErrors.email = "Bitte gib eine gültige E-Mail-Adresse ein.";
    }
    if (!formData.subject.trim()) currentErrors.subject = "Bitte gib ein Anliegen an.";
    if (formData.message.trim().length < 20) currentErrors.message = "Bitte schildere dein Anliegen in mindestens 20 Zeichen.";
    return currentErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSent(true);
    setFormData(initialState);
  };

  return (
    <>
      <Meta
        title="Kontakt | Altaverino"
        description="Nimm Kontakt zu Altaverino auf. Wir begleiten dich bei strukturierter Zeitplanung, Priorisierung und achtsamem Energiemanagement."
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <span className="badge">Kontakt</span>
          <h1>Wir freuen uns auf deinen Impuls</h1>
          <p>
            Schreibe uns, wenn du Fragen zu unseren Methoden hast oder Altaverino in deinem Team einsetzen möchtest. Wir melden uns mit Vorschlägen und
            passenden Ressourcen.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={`${styles.grid} grid two`}>
            <div className={styles.info}>
              <h2>Kontaktinformationen</h2>
              <p>Wir arbeiten remote innerhalb Deutschlands und antworten in der Regel innerhalb von zwei Werktagen.</p>
              <div className={styles.details}>
                <div>
                  <span>E-Mail</span>
                  <a href="mailto:kontakt@altaverino.site">kontakt@altaverino.site</a>
                </div>
                <div>
                  <span>Website</span>
                  <a href="https://altaverino.site">altaverino.site</a>
                </div>
                <div>
                  <span>Standort</span>
                  <p>Deutschland</p>
                </div>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Name</label>
                <input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="Dein Name" />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">E-Mail</label>
                <input id="email" name="email" value={formData.email} onChange={handleChange} placeholder="beispiel@mail.de" />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="subject">Anliegen</label>
                <input id="subject" name="subject" value={formData.subject} onChange={handleChange} placeholder="Worum geht es?" />
                {errors.subject && <span className={styles.error}>{errors.subject}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Nachricht</label>
                <textarea id="message" name="message" rows="6" value={formData.message} onChange={handleChange} placeholder="Beschreibe dein Anliegen, damit wir gezielt antworten können." />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className="primaryButton">
                Nachricht senden
              </button>
              {sent && <p className={styles.success}>Vielen Dank für deine Nachricht. Wir melden uns zeitnah bei dir.</p>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default KontaktPage;
```