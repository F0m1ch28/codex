```javascript
import React from "react";
import Meta from "../components/Meta";
import styles from "./Terms.module.css";

const NutzungsbedingungenPage = () => (
  <>
    <Meta
      title="Nutzungsbedingungen | Altaverino"
      description="Nutzungsbedingungen von Altaverino – Rahmenbedingungen für die Verwendung unserer Inhalte und Ressourcen."
    />
    <section className={`${styles.hero} section`}>
      <div className="container">
        <h1>Nutzungsbedingungen</h1>
        <p>Regeln für die Verwendung unserer Inhalte, Vorlagen und Analysen.</p>
      </div>
    </section>
    <section className="section">
      <div className="container">
        <div className={styles.card}>
          <h2>1. Geltungsbereich</h2>
          <p>Diese Nutzungsbedingungen gelten für sämtliche Inhalte und Ressourcen, die auf altaverino.site bereitgestellt werden.</p>
          <h2>2. Nutzung der Inhalte</h2>
          <p>
            Alle Texte, Grafiken und Vorlagen dürfen für persönliche oder interne Zwecke verwendet werden. Eine Weitergabe oder Veröffentlichung in
            veränderter Form bedarf unserer Zustimmung.
          </p>
          <h2>3. Haftung</h2>
          <p>
            Altaverino übernimmt keine Haftung für Entscheidungen, die auf Grundlage unserer Inhalte getroffen werden. Nutzer:innen bleiben für ihr Handeln verantwortlich.
          </p>
          <h2>4. Verfügbarkeit</h2>
          <p>Wir sind bemüht, den Zugriff auf unsere Plattform stabil zu halten. Temporäre Einschränkungen können dennoch auftreten.</p>
          <h2>5. Änderungen</h2>
          <p>Altaverino behält sich vor, Inhalte und Nutzungsbedingungen jederzeit anzupassen. Änderungen werden auf dieser Seite veröffentlicht.</p>
          <h2>6. Kontakt</h2>
          <p>Fragen zu den Nutzungsbedingungen? Schreib uns an kontakt@altaverino.site.</p>
        </div>
      </div>
    </section>
  </>
);

export default NutzungsbedingungenPage;
```