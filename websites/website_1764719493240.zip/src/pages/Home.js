```javascript
import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Meta from "../components/Meta";
import styles from "./Home.module.css";

const statsTarget = [
  { label: "Stunden pro Woche bewusst geplant", value: 28 },
  { label: "Teilnehmende, die Stress reduzieren", value: 82 },
  { label: "Empfohlene Fokus-Sessions pro Tag", value: 3 }
];

const pillars = [
  {
    title: "Klar priorisieren",
    description:
      "Aufgaben nach Wirkung, Verantwortlichkeit und Erholungsbedarf ordnen. So entsteht ein realistischer Ablauf statt überfrachteter Wunschlisten.",
    icon: "🎯"
  },
  {
    title: "Struktur schaffen",
    description:
      "Flexible, modular aufgebaute Tages- und Wochenpläne verbinden Pflicht, optionales Wachstum und Pausen in einem verlässlichen Rhythmus.",
    icon: "🧭"
  },
  {
    title: "Grenzen setzen",
    description:
      "Sichtbare Start- und Endzeiten, definierte Kommunikationskanäle und bewusste Übergänge zwischen Rollen schützen Fokus und Freizeit.",
    icon: "🛡️"
  },
  {
    title: "Energie managen",
    description:
      "Achtsames Tracking von Energiepegel, Aufmerksamkeit und Sinn schafft Basis für adaptive Routinen und frühzeitige Pausen.",
    icon: "⚡"
  }
];

const audiences = [
  {
    title: "Berufstätige",
    text: "Schaffe klare Schwerpunkte, sichere Feierabende und plane Kollaborationen so, dass Tiefenarbeit möglich bleibt.",
    tags: ["Teamabstimmung", "Fokusfenster", "Regenerative Wochenenden"]
  },
  {
    title: "Studierende",
    text: "Verbinde Seminare, Prüfungsphasen und Nebenjobs mit intelligenten Lernblöcken und realistischen Lernpfaden.",
    tags: ["Lernspuren", "Semesterplanung", "Energie-Check"]
  },
  {
    title: "Selbstständige",
    text: "Gestalte Objekttage, Kundenarbeit und Entwicklung modular. So hältst du Angebote stabil, ohne dich zu überlasten.",
    tags: ["Resilienzkonten", "Angebotsplanung", "Kundensprints"]
  }
];

const challenges = [
  "Dauerhaftes Multitasking und hoher Wechselaufwand",
  "Kalender voller Meetings ohne konzentrierte Arbeitszeit",
  "Kein bewusster Feierabend und permanente Erreichbarkeit",
  "Überforderung durch unklare To-Do-Listen und Prioritäten",
  "Fehlender Überblick über Energie und Belastungsgrenzen"
];

const faq = [
  {
    question: "Wie unterstützt Altaverino bei der Wochenplanung?",
    answer:
      "Wir verbinden strukturierte Wochenfelder mit Reflexionsfragen zu Energie und Fokus. Dadurch entstehen realistische Wochenblöcke mit Pufferzonen, statt starrer Zeitpläne."
  },
  {
    question: "Brauche ich spezielle Apps für die Methoden?",
    answer:
      "Nein. Die Frameworks sind plattformneutral und funktionieren mit Kalendern, Notiz-Apps oder analogen Boards. Wir stellen Entscheidungsraster für die passende Tool-Auswahl bereit."
  },
  {
    question: "Wie integriert man Altaverino in bestehende Teamprozesse?",
    answer:
      "Über gemeinsame Priorisierungs-Workshops, klare Übergaberituale und transparente Kommunikationsfenster. Das reduziert Reibung und schafft planbare Fokuszeiten."
  },
  {
    question: "Unterstützt ihr auch bei der Stressprävention?",
    answer:
      "Ja. Jede Methode enthält Elemente zur Regeneration, Pausenarchitektur und Frühwarnindikatoren, damit Belastung rechtzeitig sichtbar wird."
  }
];

const methods = [
  {
    title: "Wochenkompass",
    icon: "📅",
    detail:
      "Ein strukturierter Überblick, der Strategiethemen, operative Aufgaben und Erholung in visualisierte Blöcke setzt."
  },
  {
    title: "Energie-Zeit-Tracking",
    icon: "🪫",
    detail:
      "Kurze tägliche Check-ins erfassen Energie, Stimmung und Kontext. Die Daten helfen, Muster zu erkennen und Routinen anzupassen."
  },
  {
    title: "Priorisierungsmatrix Fokus 4",
    icon: "🧠",
    detail:
      "Vier Felder kombinieren Wirkung und Aufwand. So wird klar, was zuerst erledigt, delegiert, gebündelt oder gestrichen wird."
  }
];

const processSteps = [
  {
    title: "Analyse & Standortbestimmung",
    description: "Gemeinsam identifizieren wir Energiean ker, Überlastungstreiber und Potenziale in deinem Alltag."
  },
  {
    title: "Modulare Planung entwerfen",
    description: "Wir strukturieren Tages- und Wochen-Module, definieren Grenzen und schaffen flexible Routinen."
  },
  {
    title: "Erprobung & Feinjustierung",
    description: "In Reflexionszyklen passen wir Workflows an, integrieren Feedback und sichern Nachhaltigkeit."
  }
];

const projects = [
  {
    id: "weekdesign",
    title: "WeekDesign für Cross-Funktionale Teams",
    category: "Teamcoaching",
    description: "Optimierte Teamkalender mit Fokusfenstern, klaren Kommunikationsregeln und gemeinsamen Debriefing-Terminen.",
    image: "https://picsum.photos/1200/800?random=44"
  },
  {
    id: "studytrack",
    title: "StudyTrack Navigator für Studierende",
    category: "Akademische Planung",
    description: "Semesterroadmaps mit Lernphasen, Prüfungs-vorbereitung und Energieritualen für langfristige Motivation.",
    image: "https://picsum.photos/1200/800?random=45"
  },
  {
    id: "solobiz",
    title: "SoloBiz Strukturwerkstatt",
    category: "Selbstführung",
    description: "Strategische Angebotsplanung, Blocktage und Regenerationsfenster für resilient arbeitende Selbstständige.",
    image: "https://picsum.photos/1200/800?random=46"
  }
];

const blogPosts = [
  {
    title: "Pufferzonen planen: Wie 15 % Freiraum die Woche stabilisiert",
    excerpt: "Warum geplante Luft der Schlüssel zu gelingender Priorisierung ist und wie du sie konsequent schützt.",
    date: "12. Januar 2025",
    link: "/ressourcen"
  },
  {
    title: "Kontextwechsel minimieren: Rituale für fokussierte Übergänge",
    excerpt: "Ob Schreibtisch oder digitaler Workspace – Microsignale helfen, Aufgabenwelten bewusst abzuschließen.",
    date: "02. Januar 2025",
    link: "/methoden"
  },
  {
    title: "Energie-Journal: Von der Intuition zur belastbaren Datengrundlage",
    excerpt: "Wie du Stimmungen und Leistungseinflüsse sichtbarer machst, ohne dich in Tracking zu verlieren.",
    date: "18. Dezember 2024",
    link: "/ressourcen"
  }
];

const testimonials = [
  {
    name: "Zitat aus dem Altaverino Netzwerk",
    statement:
      "„Achtsam produktiv zu sein bedeutet, Prioritäten als bewusste Entscheidungen zu verstehen. Planung ist kein Korsett, sondern ein Versprechen an die eigene Lebensqualität.“"
  },
  {
    name: "Leitgedanke der Community",
    statement:
      "„Wer Grenzen setzt, schafft Klarheit für Zusammenarbeit, Kreativität und Regeneration. Altaverino erinnert uns daran, dass Verfügbarkeit kein Wert an sich ist.“"
  },
  {
    name: "Mentorinnen-Impuls",
    statement:
      "„Routinen sind dann wirksam, wenn sie zur Energie passen. Nicht Disziplin, sondern stimmige Struktur sorgt für nachhaltige Leistung.“"
  }
];

const HomePage = () => {
  const [stats, setStats] = useState(statsTarget.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [faqIndex, setFaqIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState("Alle");

  useEffect(() => {
    const increments = statsTarget.map((target) => Math.ceil(target.value / 80));
    const interval = setInterval(() => {
      setStats((prev) =>
        prev.map((value, idx) => {
          const next = value + increments[idx];
          return next >= statsTarget[idx].value ? statsTarget[idx].value : next;
        })
      );
    }, 28);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const carousel = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6800);
    return () => clearInterval(carousel);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === "Alle") return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  return (
    <>
      <Meta
        title="Altaverino | Planung des Lebens ohne Überlastung"
        description="Altaverino hilft Berufstätigen, Studierenden und Selbstständigen in Deutschland, Zeitmanagement, Energiepflege und realistische Wochenplanung miteinander zu verbinden."
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="badge">Planung des Lebens ohne Überlastung</span>
            <h1>Strukturierte Zeitplanung, die Fokus, Ruhe und Fortschritt verbindet.</h1>
            <p>
              Altaverino begleitet dich dabei, klare Prioritäten zu setzen, modulare Wochen zu gestalten und Grenzen zu
              etablieren, die Leistung und Wohlbefinden in Balance halten. Kein mikromanagement – sondern intelligente Struktur.
            </p>
            <div className={styles.heroActions}>
              <Link className="primaryButton" to="/ressourcen">
                Ressourcen &amp; Tools entdecken
                <span className={styles.ctaPulse} aria-hidden="true" />
              </Link>
              <Link className="secondaryButton" to="/methoden">
                Methoden &amp; Ansätze vertiefen
              </Link>
            </div>
            <div className={styles.heroStats}>
              {statsTarget.map((item, idx) => (
                <div key={item.label} className={styles.heroStat}>
                  <span className={styles.heroStatValue}>{stats[idx]}+</span>
                  <span className={styles.heroStatLabel}>{item.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className={styles.heroImageWrapper}>
            <div className={styles.heroImage}>
              <img src="https://picsum.photos/1600/900?random=101" alt="Strukturierter Arbeitsplatz mit ruhiger Atmosphäre" loading="lazy" />
              <div className={styles.imageBadge}>
                <span>Realistische Planung</span>
                <small>Fokus · Regeneration · Klarheit</small>
              </div>
            </div>
          </div>
        </div>
        <div className="floatingPattern" />
      </section>

      <section className="section">
        <div className="container">
          <div className="sectionHeader">
            <div>
              <h2 className="sectionTitle">Das Altaverino-Prinzip</h2>
              <p className="sectionSubtitle">
                Vier Kernpfeiler verbinden analytisches Zeitmanagement mit menschlicher, regenerativer Lebensplanung. Jeder Pfeiler beinhaltet
                konkrete Routinen, Reflexionen und visuelle Werkzeuge.
              </p>
            </div>
            <div className={styles.principleHighlight}>
              <div>
                <span className="badge">Rahmenwerk</span>
                <p>Die Pfeiler greifen ineinander und werden in Zyklen überprüft: Was trägt, was braucht Anpassung, was darf gehen?</p>
              </div>
            </div>
          </div>
          <div className={`${styles.pillarGrid} grid`}>
            {pillars.map((pillar) => (
              <article key={pillar.title} className="card">
                <div className={styles.pillarIcon}>{pillar.icon}</div>
                <h3>{pillar.title}</h3>
                <p>{pillar.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="sectionHeader">
            <div>
              <h2 className="sectionTitle">Für wen ist Altaverino gemacht?</h2>
              <p className="sectionSubtitle">
                Unsere Frameworks lassen sich in verschiedene Lebensrealitäten integrieren. Jedes Profil erhält eigene Strukturen,
                Priorisierungsraster und Pausen-Logiken.
              </p>
            </div>
            <div>
              <Link to="/ueber-uns" className="secondaryButton">
                Mehr über unsere Arbeit
              </Link>
            </div>
          </div>
          <div className={`${styles.audienceGrid} grid`}>
            {audiences.map((audience) => (
              <article key={audience.title} className={`${styles.audienceCard} card`}>
                <header>
                  <h3>{audience.title}</h3>
                  <p>{audience.text}</p>
                </header>
                <div className="tagRow">
                  {audience.tags.map((tag) => (
                    <span key={tag} className="tag">
                      {tag}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.challengeSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <div>
              <h2 className="sectionTitle">Häufige Herausforderungen im Alltag</h2>
              <p className="sectionSubtitle">
                Altaverino macht typische Überlastungspunkte sichtbar und entwickelt Rituale, die nachhaltige Entlastung schaffen.
              </p>
            </div>
            <div>
              <span className="badge">Klare Diagnose</span>
            </div>
          </div>
          <div className={`${styles.challengeGrid} grid two`}>
            <div className={styles.challengeList}>
              <ul className="list">
                {challenges.map((challenge) => (
                  <li key={challenge} className="listItem">
                    <span className={styles.listBullet}>•</span>
                    <span>{challenge}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className={styles.faqBlock}>
              <h3>Fragen aus der Community</h3>
              <div className={styles.accordion}>
                {faq.map((item, index) => (
                  <div
                    key={item.question}
                    className={`${styles.accordionItem} ${faqIndex === index ? styles.active : ""}`}
                  >
                    <button className={styles.accordionTrigger} onClick={() => setFaqIndex(index === faqIndex ? -1 : index)}>
                      <span>{item.question}</span>
                      <span>{faqIndex === index ? "–" : "+"}</span>
                    </button>
                    <div className={styles.accordionContent}>
                      <p>{item.answer}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.methodsSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <div>
              <h2 className="sectionTitle">Einblick in Methoden und Prozess</h2>
              <p className="sectionSubtitle">
                Drei Methodensets bilden den Kern. Ergänzt werden sie durch einen klaren Prozess, der Stellungnahmen, Iterationen und sichtbare Erfolge sichert.
              </p>
            </div>
            <div>
              <Link to="/methoden" className="secondaryButton">
                Methoden vertiefen
              </Link>
            </div>
          </div>

          <div className={`${styles.methodsGrid} grid three`}>
            {methods.map((method) => (
              <article key={method.title} className={`${styles.methodCard} card`}>
                <div className={styles.methodIcon}>{method.icon}</div>
                <h3>{method.title}</h3>
                <p>{method.detail}</p>
                <Link to="/methoden" className={styles.methodLink}>
                  Mehr erfahren →
                </Link>
              </article>
            ))}
          </div>

          <div className={styles.processTimeline}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processStep}>
                <div className={styles.processNumber}>{index + 1}</div>
                <div>
                  <h4>{step.title}</h4>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.teamProjectSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <div>
              <h2 className="sectionTitle">Team &amp; Projekte</h2>
              <p className="sectionSubtitle">
                Menschen mit Erfahrung in Organisationsentwicklung, Psychologie und Lernarchitektur gestalten Altaverino. Hier ein Einblick in aktuelle Projekte.
              </p>
            </div>
            <div className={styles.filterRow}>
              {["Alle", "Teamcoaching", "Akademische Planung", "Selbstführung"].map((category) => (
                <button
                  key={category}
                  className={`${styles.filterButton} ${projectFilter === category ? styles.filterButtonActive : ""}`}
                  onClick={() => setProjectFilter(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className={`${styles.teamGrid} grid three`}>
            <div className={`${styles.teamCard} card`}>
              <img src="https://picsum.photos/400/400?random=111" alt="Teammitglied bei der Arbeit an Zeitplanstrategien" loading="lazy" />
              <h3>Clara Neumann</h3>
              <p>Analystin für Zeit- und Energiestudien, spezialisiert auf hybride Arbeitsmodelle und Echtzeitfeedback.</p>
            </div>
            <div className={`${styles.teamCard} card`}>
              <img src="https://picsum.photos/400/400?random=112" alt="Teammitglied reflektiert Projektplanung" loading="lazy" />
              <h3>David Sommer</h3>
              <p>Coach für Priorisierung und Dialogformate, begleitet Teams in klaren Kommunikationsritualen.</p>
            </div>
            <div className={`${styles.teamCard} card`}>
              <img src="https://picsum.photos/400/400?random=113" alt="Teammitglied erläutert strategische Woche" loading="lazy" />
              <h3>Leonie Brandt</h3>
              <p>Expertin für Lernarchitektur, entwickelt Semesterfahrpläne und Energiejournal-Vorlagen.</p>
            </div>
          </div>

          <div className={`${styles.projectGrid} grid`}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={`${styles.projectCard} card`}>
                <img src={project.image} alt={`${project.title} – Beispiel aus der Praxis`} loading="lazy" />
                <div className={styles.projectBody}>
                  <span className="badge">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blogSection} section`}>
        <div className="container">
          <div className="sectionHeader center">
            <h2 className="sectionTitle">Einblicke, Stimmen, nächste Schritte</h2>
            <p className="sectionSubtitle">
              Reflexionen, Leitartikel und Stimmen aus der Altaverino-Community liefern Impulse für achtsame Produktivität.
            </p>
          </div>
          <div className={`${styles.blogGrid} grid three`}>
            {blogPosts.map((post) => (
              <article key={post.title} className={`${styles.blogCard} card`}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <div className={styles.blogFooter}>
                  <span>{post.date}</span>
                  <Link to={post.link}>Weiterlesen →</Link>
                </div>
              </article>
            ))}
          </div>

          <div className={styles.testimonialWrapper}>
            <div className={`${styles.testimonialCard} card`}>
              <blockquote>
                {testimonials[testimonialIndex].statement}
                <footer>{testimonials[testimonialIndex].name}</footer>
              </blockquote>
              <div className={styles.testimonialControls}>
                {testimonials.map((_, idx) => (
                  <button
                    key={idx}
                    className={`${styles.dot} ${testimonialIndex === idx ? styles.dotActive : ""}`}
                    onClick={() => setTestimonialIndex(idx)}
                    aria-label={`Zitat ${idx + 1} anzeigen`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className={styles.ctaBanner}>
            <div>
              <h3>Starte mit klaren Wochenfenstern und echter Balance.</h3>
              <p>
                Nutze unsere Ressourcen, um deine Woche zu strukturieren, oder tauche in die Methoden ein. Schritt für Schritt zu mehr Ruhe und Wirkung.
              </p>
            </div>
            <div className={styles.ctaButtons}>
              <Link className="primaryButton" to="/ressourcen">
                Ressourcen ansehen
              </Link>
              <Link className="secondaryButton" to="/methoden">
                Methoden kennenlernen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;
```