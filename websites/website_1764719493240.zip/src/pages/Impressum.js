```javascript
import React from "react";
import Meta from "../components/Meta";
import styles from "./Impressum.module.css";

const ImpressumPage = () => (
  <>
    <Meta
      title="Impressum | Altaverino"
      description="Impressum der Plattform Altaverino – Analytische Tools für Time-Management und Lebensplanung ohne Überlastung."
    />
    <section className={`${styles.hero} section`}>
      <div className="container">
        <h1>Impressum</h1>
        <p>Angaben gemäß § 5 TMG</p>
      </div>
    </section>
    <section className="section">
      <div className="container">
        <div className={styles.card}>
          <h2>Altaverino</h2>
          <p>Analytisch-bildungsorientierte Plattform für deutsches Time-Management</p>
          <p>E-Mail: <a href="mailto:kontakt@altaverino.site">kontakt@altaverino.site</a></p>
          <p>Website: <a href="https://altaverino.site">altaverino.site</a></p>
          <p>Standort: Deutschland</p>
          <h3>Vertretung</h3>
          <p>Die Plattform wird von einem interdisziplinären Redaktionsteam verantwortet.</p>
          <h3>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h3>
          <p>Altaverino Redaktionsteam, erreichbar unter kontakt@altaverino.site</p>
          <h3>Haftungshinweis</h3>
          <p>Wir prüfen Inhalte sorgfältig, übernehmen jedoch keine Haftung für externe Links. Für den Inhalt verlinkter Seiten sind ausschließlich deren Betreiber verantwortlich.</p>
        </div>
      </div>
    </section>
  </>
);

export default ImpressumPage;
```