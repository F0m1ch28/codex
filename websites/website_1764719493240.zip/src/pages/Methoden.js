```javascript
import React from "react";
import Meta from "../components/Meta";
import styles from "./Methoden.module.css";

const MethodenPage = () => {
  return (
    <>
      <Meta
        title="Methoden & Ansätze | Altaverino"
        description="Erfahre mehr über die Methoden von Altaverino: Wochenkompass, Energie-Zeit-Tracking, Priorisierungsmatrix Fokus 4 und weitere praxisorientierte Werkzeuge."
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <span className="badge">Methoden &amp; Ansätze</span>
          <h1>Analytische Frameworks für eine planbare Woche</h1>
          <p>
            Unsere Methoden kombinieren klare Visualisierungen mit reflektierten Routinen. Sie lassen sich individuell anpassen und basieren auf
            erprobten Prozesszyklen, die Überlastung vermeiden.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.grid}>
            <article className="card">
              <h2>Der Wochenkompass</h2>
              <p>
                Der Wochenkompass visualisiert Fokusbereiche, Pflichttermine, flexible Aufgaben und Regenerationsfenster. Die Woche wird nicht
                in uninterpretable Slots gesteckt, sondern in Module gegliedert, die Zweck und Energiebedarf definieren.
              </p>
              <ul className={styles.list}>
                <li>Strategiefelder vs. Tagesgeschäft klar unterscheiden</li>
                <li>Farbkodierung für Energielevel und Sozialkontakt</li>
                <li>Reflexion am Wochenende mit Rückblick und Vorschau</li>
              </ul>
            </article>

            <article className="card">
              <h2>Energie-Zeit-Tracking</h2>
              <p>
                Niederschwellige Check-ins erfassen Tagesenergie, Fokusqualität und Unterbrechungsquellen. Statt dauernd zu messen, werden
                kurze Marker genutzt, die Trends sichtbar machen.
              </p>
              <div className={styles.diagram}>
                <div>
                  <span>Montag</span>
                  <div />
                </div>
                <div>
                  <span>Dienstag</span>
                  <div />
                </div>
                <div>
                  <span>Mittwoch</span>
                  <div />
                </div>
                <div>
                  <span>Donnerstag</span>
                  <div />
                </div>
              </div>
            </article>

            <article className="card">
              <h2>Priorisierungsmatrix Fokus 4</h2>
              <p>
                Vier Felder kombinieren Wirkung und Aufwand. Aufgaben wechseln bewusst zwischen Feldern, wenn Rahmenbedingungen sich ändern.
              </p>
              <div className={styles.matrix}>
                <div>
                  <h3>Quadrant 1</h3>
                  <p>Sofortige Wirkung, überschaubarer Aufwand – zuerst erledigen.</p>
                </div>
                <div>
                  <h3>Quadrant 2</h3>
                  <p>Hohe Wirkung, hoher Aufwand – planen mit ausreichender Energie.</p>
                </div>
                <div>
                  <h3>Quadrant 3</h3>
                  <p>Mittlere Wirkung, geringer Aufwand – bündeln für Batch-Zeiten.</p>
                </div>
                <div>
                  <h3>Quadrant 4</h3>
                  <p>Geringe Wirkung – streichen oder delegieren.</p>
                </div>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.timelineSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Prozesszyklen für nachhaltige Umsetzung</h2>
          <p className="sectionSubtitle">
            Jede Methode wird in klaren Zyklen geprüft. Die Routinen bleiben flexibel und passen sich an Veränderungen an.
          </p>
          <div className={styles.timeline}>
            <div className={styles.timelineItem}>
              <div className={styles.timelinePoint}>1</div>
              <div>
                <h3>Situationsanalyse</h3>
                <p>Auslastung, Energieprofil und Verpflichtungen werden visuell erfasst. Standard- und Ausnahmephasen werden getrennt betrachtet.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelinePoint}>2</div>
              <div>
                <h3>Entwurf &amp; Simulation</h3>
                <p>Wochen- und Tagesmodule werden getestet. Simulationen zeigen, wie Puffer und Grenzen wirken, bevor sie in den Alltag übergehen.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelinePoint}>3</div>
              <div>
                <h3>Erprobung im Alltag</h3>
                <p>Methoden werden vier Wochen lang beobachtet. Feedbackschleifen sorgen dafür, dass kein starres Gerüst entsteht.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelinePoint}>4</div>
              <div>
                <h3>Review &amp; Justierung</h3>
                <p>Was funktioniert, wird verankert. Was nicht trägt, wird angepasst oder ersetzt. Ziel: Stabilität ohne Überforderung.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.downloadSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <h2 className="sectionTitle">Arbeitsblätter &amp; Leitfäden</h2>
            <p className="sectionSubtitle">
              Ergänzend zu den Methoden bieten wir strukturierte Templates, Reflexionsfragen und Checklisten an – bereit zur direkten Anwendung.
            </p>
          </div>
          <div className={`${styles.downloadGrid} grid two`}>
            <div className="card">
              <h3>Wochenkompass-Template</h3>
              <p>Modulare Übersicht mit Fokusbereichen, Energielevels und Reflexionsfragen. Ideal für analoge Boards oder digitale Planner.</p>
            </div>
            <div className="card">
              <h3>Energiejournal Starter</h3>
              <p>15 Fragen für tägliche Mini-Reflexionen plus Diagramm-Vorlagen, um individuelle Muster sichtbar zu machen.</p>
            </div>
          </div>
          <div className={styles.notice}>
            <p>
              Alle Unterlagen sind in deutscher Sprache verfügbar. Ergänzend erhältst du Vorschläge, wie du sie in Teammeetings oder Lernphasen einbindest.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default MethodenPage;
```