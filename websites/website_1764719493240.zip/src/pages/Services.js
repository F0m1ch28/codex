```javascript
import React, { useMemo, useState } from "react";
import Meta from "../components/Meta";
import styles from "./Services.module.css";

const resources = [
  {
    title: "Tagesstruktur Canvas",
    category: "Planung",
    description: "Visualisierung für fokussierte Tagesmodule inklusive Übergangsrituale und Abschlussfragen.",
    format: "PDF, A4",
    link: "/kontakt"
  },
  {
    title: "Meeting-Fokus-Kompass",
    category: "Teamarbeit",
    description: "Matrix zur Bewertung von Meetingzweck, Vorbereitungszeit und Nachbereitungsschritten.",
    format: "Miro Board & PDF",
    link: "/kontakt"
  },
  {
    title: "Semesterfahrplan Generator",
    category: "Studium",
    description: "Tabellenvorlage mit Wochenblöcken, Meilensteinen und Pausenmarkern für Studierende.",
    format: "Google Sheets",
    link: "/kontakt"
  },
  {
    title: "Resilienzkonto Tracker",
    category: "Selbstführung",
    description: "Energie- und Erholungsübersicht mit Warnsignalen und Regenerationsideen.",
    format: "Notion Template",
    link: "/kontakt"
  },
  {
    title: "Check-in Karten für Teams",
    category: "Teamarbeit",
    description: "Fragen-Sets für Wochenstart, Fokusabgleich und Abschlussreflexion in hybriden Teams.",
    format: "PDF, Druckvorlage",
    link: "/kontakt"
  }
];

const filters = ["Alle", "Planung", "Teamarbeit", "Studium", "Selbstführung"];

const RessourcenPage = () => {
  const [activeFilter, setActiveFilter] = useState("Alle");

  const filtered = useMemo(() => {
    if (activeFilter === "Alle") return resources;
    return resources.filter((resource) => resource.category === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <Meta
        title="Ressourcen & Tools | Altaverino"
        description="Arbeitsblätter, Leitfäden und Vorlagen von Altaverino. Nutze strukturierte Tools für Zeitplanung, Energiemanagement und Teamkoordination."
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <span className="badge">Ressourcen &amp; Tools</span>
          <h1>Arbeitsmaterialien für strukturierte Zeitgestaltung</h1>
          <p>
            Unsere Tools unterstützen dich darin, Routinen aufzubauen, Prioritäten zu visualisieren und Grenzen im Alltag zu schützen. Wähle das
            Material, das zu deinem Kontext passt, und bringe Struktur in deinen Tag.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.filterRow}>
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`${styles.filterButton} ${activeFilter === filter ? styles.active : ""}`}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={`${styles.resourceGrid} grid`}>
            {filtered.map((resource) => (
              <article key={resource.title} className="card">
                <h2>{resource.title}</h2>
                <span className={styles.category}>{resource.category}</span>
                <p>{resource.description}</p>
                <div className={styles.meta}>
                  <span>Format: {resource.format}</span>
                  <a href={resource.link}>Kontakt aufnehmen →</a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.toolkit} section`}>
        <div className="container">
          <h2 className="sectionTitle">Dein persönlicher Altaverino-Toolkit</h2>
          <p className="sectionSubtitle">
            Kombiniere die Ressourcen mit den Methoden, um einen eigenen Workflow zu entwickeln. Unser Toolkit führt dich Schritt für Schritt durch die
            Implementierung.
          </p>
          <div className={`${styles.toolGrid} grid three`}>
            <div className="card">
              <h3>1. Diagnose &amp; Auswahl</h3>
              <p>Analysiere deinen Alltag, wähle relevante Ressourcen und definiere, welche Grenzen du schützen möchtest.</p>
            </div>
            <div className="card">
              <h3>2. Umsetzung &amp; Rituale</h3>
              <p>Plane Wochen-Fokusfenster, setze Check-ins und nutze Vorlagen für Tagesabschluss oder Review-Meetings.</p>
            </div>
            <div className="card">
              <h3>3. Review &amp; Wachstum</h3>
              <p>Nutze Energiemonitoring und Reflexionsfragen, um Routinen anzupassen und Erfolge sichtbar zu machen.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default RessourcenPage;
```