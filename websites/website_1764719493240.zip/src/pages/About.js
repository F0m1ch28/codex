```javascript
import React from "react";
import Meta from "../components/Meta";
import styles from "./About.module.css";

const UeberUnsPage = () => {
  return (
    <>
      <Meta
        title="Über Altaverino"
        description="Altaverino verbindet analytisches Time-Management mit regenerativer Lebensplanung. Erfahre mehr über unser Team, unsere Werte und unseren Ansatz."
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <span className="badge">Über Altaverino</span>
          <h1>Wir gestalten Strukturen, die Menschen stärken</h1>
          <p>
            Altaverino vereint Expert:innen aus Organisationsentwicklung, Psychologie und Lernarchitektur. Wir teilen die Überzeugung, dass Produktivität
            ohne Achtsamkeit nicht nachhaltig ist. Deshalb verbinden wir klare Strukturen mit Raum für Erholung, Familie und persönliche Entwicklung.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={`${styles.valuesGrid} grid three`}>
            <div className="card">
              <h3>Analytische Klarheit</h3>
              <p>Daten, Muster und Feedback bilden die Grundlage unserer Arbeit. Wir gestalten Entscheidungen transparent und nachvollziehbar.</p>
            </div>
            <div className="card">
              <h3>Respekt vor Ressourcen</h3>
              <p>Zeit, Energie und Aufmerksamkeit sind begrenzt. Unsere Ansätze schützen diese Ressourcen durch klare Grenzen und Rituale.</p>
            </div>
            <div className="card">
              <h3>Gemeinschaft &amp; Verantwortung</h3>
              <p>Wir denken Time-Management als gemeinschaftliche Aufgabe – mit Dialog, geteilten Standards und wertschätzender Zusammenarbeit.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.timelineSection} section`}>
        <div className="container">
          <h2 className="sectionTitle">Meilensteine</h2>
          <p className="sectionSubtitle">
            Altaverino entwickelt sich stetig weiter. Die wichtigsten Etappen zeigen, wie sich unser Ansatz vertieft hat.
          </p>
          <div className={styles.timeline}>
            <div>
              <span>2020</span>
              <p>Start als Forschungsprojekt zu Energie- und Fokusverläufen im deutschen Mittelstand.</p>
            </div>
            <div>
              <span>2021</span>
              <p>Aufbau der Methodenbibliothek und erste Pilotprojekte mit Studierenden und Selbstständigen.</p>
            </div>
            <div>
              <span>2022</span>
              <p>Einführung des Wochenkompass und der Fokus-4-Matrix für hybride Teams.</p>
            </div>
            <div>
              <span>2024</span>
              <p>Community-Aufbau mit Dialogformaten, Energiejournal und Austauschplattform.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.mission} section`}>
        <div className="container">
          <div className="sectionHeader">
            <h2 className="sectionTitle">Unsere Mission</h2>
            <p className="sectionSubtitle">
              Wir unterstützen Menschen in Deutschland dabei, ihren Alltag so zu strukturieren, dass Leistung, Gesundheit und Beziehungen gleichzeitig Raum finden.
            </p>
          </div>
          <div className={`${styles.missionGrid} grid two`}>
            <div className="card">
              <h3>Forschung &amp; Entwicklung</h3>
              <p>
                Wir evaluieren kontinuierlich, wie Methoden wirken, und passen sie an verschiedene Branchen und Lebensphasen an. Daten, Interviews und Praxisfeedback
                bilden dabei unser Fundament.
              </p>
            </div>
            <div className="card">
              <h3>Begleitung &amp; Transfer</h3>
              <p>
                Altaverino begleitet Menschen dabei, neue Routinen in ihren Alltag zu integrieren. Wir schaffen Lernräume, in denen Austausch und Reflexion im Zentrum stehen.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default UeberUnsPage;
```