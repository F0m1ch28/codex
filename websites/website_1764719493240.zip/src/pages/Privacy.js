```javascript
import React from "react";
import Meta from "../components/Meta";
import styles from "./Privacy.module.css";

const DatenschutzPage = () => (
  <>
    <Meta
      title="Datenschutz | Altaverino"
      description="Datenschutzerklärung von Altaverino: Informationen zur Verarbeitung personenbezogener Daten und zu Rechten nach DSGVO."
    />
    <section className={`${styles.hero} section`}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>Transparente Informationen zur Verarbeitung personenbezogener Daten gemäß DSGVO.</p>
      </div>
    </section>
    <section className="section">
      <div className="container">
        <div className={styles.card}>
          <h2>1. Verantwortliche Stelle</h2>
          <p>Altaverino – kontakt@altaverino.site</p>
          <h2>2. Zweck der Verarbeitung</h2>
          <p>
            Wir verarbeiten personenbezogene Daten ausschließlich zur Beantwortung von Anfragen und zur Optimierung unserer Inhalte. Eine
            Weitergabe an Dritte findet nicht statt.
          </p>
          <h2>3. Rechtsgrundlagen</h2>
          <p>Art. 6 Abs. 1 lit. a DSGVO (Einwilligung) und lit. f DSGVO (berechtigtes Interesse an effizienter Kommunikation).</p>
          <h2>4. Speicherdauer</h2>
          <p>Anfragen werden nach Abschluss der Bearbeitung gelöscht, sofern keine gesetzlichen Aufbewahrungsfristen entgegenstehen.</p>
          <h2>5. Cookies &amp; Analyse</h2>
          <p>
            Wir setzen ausschließlich technisch notwendige Cookies ein. Optional erhobene Nutzungsstatistiken sind anonymisiert und erlauben keinen Rückschluss auf einzelne Personen.
          </p>
          <h2>6. Rechte der betroffenen Personen</h2>
          <ul>
            <li>Auskunft über gespeicherte Daten</li>
            <li>Berichtigung unrichtiger Daten</li>
            <li>Löschung oder Einschränkung der Verarbeitung</li>
            <li>Widerspruch gegen die Verarbeitung</li>
            <li>Beschwerde bei einer Datenschutzbehörde</li>
          </ul>
          <h2>7. Kontakt</h2>
          <p>Bei Fragen zum Datenschutz wende dich bitte an kontakt@altaverino.site.</p>
        </div>
      </div>
    </section>
  </>
);

export default DatenschutzPage;
```