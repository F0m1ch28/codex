import { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contact.module.css';

const topics = [
  'Neues Gestaltungsprojekt',
  'Pflegeanfrage',
  'Dach- oder Fassadenbegrünung',
  'Regenwassermanagement',
  'Allgemeine Anfrage'
];

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    topic: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Bitte geben Sie Ihren Namen an.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse an.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Bitte beschreiben Sie Ihr Anliegen.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setStatus('Vielen Dank! Wir melden uns schnellstmöglich bei Ihnen.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      topic: '',
      message: ''
    });
  };

  return (
    <>
      <SEO
        title="Kontakt | GreenLeaf Landscaping Berlin"
        description="Kontaktieren Sie GreenLeaf Landscaping für Beratung, Planung oder Pflege Ihrer Grünflächen in Berlin."
        path="/kontakt"
        image="https://picsum.photos/1200/630?random=252"
      />

      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt</h1>
          <p>
            Erzählen Sie uns von Ihrem Projekt. Wir freuen uns auf ein unverbindliches Gespräch und
            beraten Sie gern persönlich – vor Ort oder digital.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <div className={styles.infoCard}>
                <h2>GreenLeaf Landscaping</h2>
                <div className={styles.infoGrid}>
                  <div className={styles.infoItem}>
                    <strong>Adresse</strong>
                    <a
                      href="https://maps.google.com/?q=Gartenstraße+15,+10115+Berlin"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Gartenstraße 15<br />10115 Berlin
                    </a>
                  </div>
                  <div className={styles.infoItem}>
                    <strong>Telefon</strong>
                    <a href="tel:+493012345678">+49 30 12345678</a>
                  </div>
                  <div className={styles.infoItem}>
                    <strong>E-Mail</strong>
                    <a href="mailto:info@greenleaf-landscaping.de">info@greenleaf-landscaping.de</a>
                  </div>
                </div>
              </div>

              <div className={styles.hours}>
                <h3>Sprechzeiten</h3>
                <span>Montag – Freitag · 8:00 – 17:30 Uhr</span>
                <span>Samstag nach Vereinbarung</span>
                <span>Persönliche Termine in Berlin und Umgebung</span>
              </div>

              <div className={styles.map}>
                <iframe
                  title="Karte GreenLeaf Landscaping"
                  src="https://maps.google.com/maps?q=Gartenstraße%2015%2C%2010115%20Berlin&t=&z=13&ie=UTF8&iwloc=&output=embed"
                  loading="lazy"
                />
              </div>
            </div>

            <div className={styles.formCard}>
              <h2>Nachricht senden</h2>
              <p>
                Bitte teilen Sie uns ein paar Eckdaten mit. Wir melden uns innerhalb von zwei Werktagen
                zurück.
              </p>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label>
                  Name*
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Ihr Name"
                    aria-invalid={!!errors.name}
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </label>

                <label>
                  E-Mail*
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="beispiel@domain.de"
                    aria-invalid={!!errors.email}
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </label>

                <label>
                  Telefon
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+49 ..."
                  />
                </label>

                <label>
                  Thema
                  <select name="topic" value={formData.topic} onChange={handleChange}>
                    <option value="">Bitte auswählen</option>
                    {topics.map((topic) => (
                      <option key={topic} value={topic}>
                        {topic}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  Nachricht*
                  <textarea
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Wie dürfen wir Sie unterstützen?"
                    aria-invalid={!!errors.message}
                  />
                  {errors.message && <span className={styles.error}>{errors.message}</span>}
                </label>

                <p className={styles.hint}>
                  Mit dem Absenden Ihrer Nachricht bestätigen Sie, dass Sie unsere{' '}
                  <a href="/datenschutz">Datenschutzerklärung</a> gelesen haben.
                </p>

                {status && <div className={styles.success}>{status}</div>}

                <button type="submit" className="btn">
                  Nachricht senden
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;