import SEO from '../components/SEO';
import styles from './Legal.module.css';

const PrivacyPage = () => (
  <>
    <SEO
      title="Datenschutzerklärung | GreenLeaf Landscaping"
      description="Informationen zum Umgang mit personenbezogenen Daten bei GreenLeaf Landscaping in Berlin."
      path="/datenschutz"
      image="https://picsum.photos/1200/630?random=250"
    />
    <div className={`container ${styles.wrapper}`}>
      <h1 className={styles.title}>Datenschutzerklärung</h1>
      <p className={styles.intro}>
        Der Schutz Ihrer personenbezogenen Daten ist uns wichtig. Nachfolgend informieren wir über die
        Art, den Umfang und Zweck der Verarbeitung personenbezogener Daten im Rahmen der Nutzung unserer
        Website.
      </p>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Verantwortlicher</h2>
        <p>
          GreenLeaf Landscaping<br />
          Gartenstraße 15, 10115 Berlin<br />
          Telefon: +49 30 12345678 · E-Mail: info@greenleaf-landscaping.de
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Erfassung von Zugriffsdaten</h2>
        <p>
          Bei jedem Aufruf unserer Website erfasst unser Hosting-Anbieter automatisch Informationen, die
          Ihr Browser übermittelt (Server-Logfiles). Dazu gehören IP-Adresse, Datum und Uhrzeit des
          Abrufs, Browsertyp und -version, Betriebssystem, Referrer-URL sowie der Name der angeforderten
          Datei. Diese Daten dienen ausschließlich der Sicherstellung eines störungsfreien Betriebs und
          werden nach 14 Tagen automatisch gelöscht. Eine Zusammenführung mit anderen Datenquellen findet
          nicht statt.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Cookies</h2>
        <p>
          Unsere Website verwendet Cookies, um grundlegende Funktionen bereitzustellen und optionale
          Komfortfunktionen zu ermöglichen. Notwendige Cookies sichern den Betrieb der Seite. Optionale
          Cookies (Analyse und Marketing) werden nur nach Ihrer ausdrücklichen Einwilligung gesetzt.
        </p>
        <p>
          Details zu den eingesetzten Cookies und Ihren Einstellungsoptionen finden Sie in unserer{' '}
          <a href="/cookie-richtlinie">Cookie-Richtlinie</a>.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Kontaktaufnahme</h2>
        <p>
          Wenn Sie uns per Kontaktformular oder E-Mail Anfragen zukommen lassen, verarbeiten wir Ihre
          Angaben zur Bearbeitung der Anfrage sowie für den Fall, dass Anschlussfragen entstehen. Die
          Verarbeitung erfolgt auf Grundlage von Art. 6 Abs. 1 lit. b DSGVO (Vertragsanbahnung bzw.
          vorvertragliche Maßnahmen).
        </p>
        <p>
          Ihre Daten werden gelöscht, sobald die Speicherung nicht mehr erforderlich ist und gesetzlichen
          Aufbewahrungspflichten nicht entgegenstehen.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>5. Einbindung von Diensten und Inhalten Dritter</h2>
        <p>
          Zur Darstellung unseres Standorts nutzen wir eingebettete Karten von externen Anbietern
          (z.&nbsp;B. Google Maps). Beim Aufruf der Karte können personenbezogene Daten (z.&nbsp;B.
          IP-Adresse) an den jeweiligen Anbieter übertragen werden. Diese Inhalte werden nur geladen,
          wenn Sie dem in den Cookie-Einstellungen zugestimmt haben.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>6. Ihre Rechte</h2>
        <p>Sie haben das Recht auf:</p>
        <ul className={styles.list}>
          <li>Auskunft über die Verarbeitung Ihrer personenbezogenen Daten</li>
          <li>Berichtigung unrichtiger oder unvollständiger Daten</li>
          <li>Löschung Ihrer Daten, sofern keine gesetzlichen Aufbewahrungspflichten entgegenstehen</li>
          <li>Einschränkung der Verarbeitung unter bestimmten Voraussetzungen</li>
          <li>Widerspruch gegen die Datenverarbeitung aus Gründen, die sich aus Ihrer besonderen Situation ergeben</li>
          <li>Übertragbarkeit der von Ihnen bereitgestellten Daten</li>
        </ul>
        <p>
          Wenden Sie sich hierfür bitte an info@greenleaf-landscaping.de. Zudem haben Sie das Recht, sich
          bei einer Datenschutzaufsichtsbehörde zu beschweren.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>7. Aktualität</h2>
        <p>
          Wir behalten uns vor, diese Datenschutzerklärung anzupassen, um sie an geänderte Rechtslagen
          oder bei Änderungen unseres Dienstes anzupassen. Aktueller Stand: März 2024.
        </p>
      </section>
    </div>
  </>
);

export default PrivacyPage;