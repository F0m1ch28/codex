import { useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Gallery.module.css';

const categories = ['Alle', 'Privatgärten', 'Dachgärten', 'Innenhöfe', 'Gewerbeflächen'];

const projects = [
  {
    title: 'Stadthof mit Wasserlauf',
    location: 'Prenzlauer Berg',
    category: 'Innenhöfe',
    image: 'https://picsum.photos/1000/700?random=240',
    description:
      'Ein schattiger Hof wurde in eine grüne Ruhezone mit Wasserlauf, Schattenstauden und Sitzstufen verwandelt.',
    features: ['Natürlicher Bachlauf mit Regenwasserspeisung', 'Sitzstufen aus Kastanienholz', 'Nachtbeleuchtung mit warmweißen Spots']
  },
  {
    title: 'Panorama-Dachgarten',
    location: 'Berlin-Mitte',
    category: 'Dachgärten',
    image: 'https://picsum.photos/1000/700?random=241',
    description:
      'Auf dem Dach eines Bürogebäudes entstand ein vielseitiger Dachgarten mit Meetingbereichen, Blühflächen und Bewässerungssensorik.',
    features: ['Statisch optimierter Leichtsubstrataufbau', 'Wettergeführte Bewässerungssysteme', 'Begrünte Pergola als Schattenspender']
  },
  {
    title: 'Familiengarten mit Spielinseln',
    location: 'Zehlendorf',
    category: 'Privatgärten',
    image: 'https://picsum.photos/1000/700?random=242',
    description:
      'Naturnaher Familiengarten mit essbaren Pflanzen, Spielinseln und Ruhezonen. Nachhaltige Materialien schaffen eine warme Atmosphäre.',
    features: ['Essbare Pflanzenbeete und Obstgehölze', 'Spielinseln mit Fallschutzmaterial', 'Terrasse aus recyceltem Holzverbund']
  },
  {
    title: 'Innenhof als Outdoor-Workspace',
    location: 'Charlottenburg',
    category: 'Innenhöfe',
    image: 'https://picsum.photos/1000/700?random=243',
    description:
      'Ein ehemals versiegelter Hinterhof wurde zum multifunktionalen Aufenthaltsort für Mitarbeitende mit integrierten Arbeitsplätzen.',
    features: ['Modulare Möblierung mit Stromanschlüssen', 'Vertikale Pflanzmodule für mehr Grün', 'Schattenspender durch leichte Membranen']
  },
  {
    title: 'Showroom-Garten für Designhaus',
    location: 'Friedrichshain',
    category: 'Gewerbeflächen',
    image: 'https://picsum.photos/1000/700?random=244',
    description:
      'Ein flexibel nutzbarer Außenraum, der Produkte und Pflanzen in Szene setzt und als Eventfläche dient.',
    features: ['Modulare Pflanzgefäße', 'Atmosphärische Beleuchtung für Events', 'Bewässerung per App steuerbar']
  },
  {
    title: 'Mediterraner Innenhof',
    location: 'Kreuzberg',
    category: 'Innenhöfe',
    image: 'https://picsum.photos/1000/700?random=245',
    description:
      'Ein mediterran inspirierter Hof mit duftenden Kräutern, Sitzbänken und einem kleinen Wasserspiegel.',
    features: ['Wasserfläche als Mikroklima-Regulator', 'Pflanzenauswahl für sonnige Standorte', 'Feinsteinzeug in Natursteinoptik']
  },
  {
    title: 'Urbaner Pocket-Garden',
    location: 'Neukölln',
    category: 'Privatgärten',
    image: 'https://picsum.photos/1000/700?random=246',
    description:
      'Ein kleiner Stadtgarten verwandelt mit vertikalen Elementen, Spiegeln und strukturreichen Bepflanzungen.',
    features: ['Vertikale Pflanzmodule', 'Mehrjährige Stauden mit Ganzjahresaspekt', 'Ambientebeleuchtung für Abendstunden']
  },
  {
    title: 'Green Campus Plaza',
    location: 'Adlershof',
    category: 'Gewerbeflächen',
    image: 'https://picsum.photos/1000/700?random=247',
    description:
      'Außenflächen für einen Campus mit Aufenthaltszonen, klimaaktiven Pflanzflächen und Regenwassermanagement.',
    features: ['Versickerungsfähige Beläge', 'Baumpflanzungen mit Wurzelbelüftung', 'Sensorik zur Bodenfeuchtemessung']
  }
];

const GalleryPage = () => {
  const [activeCategory, setActiveCategory] = useState('Alle');
  const filteredProjects =
    activeCategory === 'Alle'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  return (
    <>
      <SEO
        title="Projektgalerie | GreenLeaf Landscaping"
        description="Lassen Sie sich von realisierten Projekten von GreenLeaf Landscaping inspirieren: Privatgärten, Innenhöfe, Dachbegrünungen und gewerbliche Grünflächen in Berlin."
        path="/projektgalerie"
        image="https://picsum.photos/1200/630?random=248"
      />

      <section className={styles.hero}>
        <div className="container">
          <h1>Projektgalerie</h1>
          <p>
            Jede Fläche erzählt eine eigene Geschichte. Entdecken Sie ausgewählte Projekte, die wir in
            den letzten Jahren in Berlin umgesetzt haben.
          </p>
          <div className={styles.filters} role="group" aria-label="Projektkategorien filtern">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.gallery}>
        <div className="container">
          <div className={styles.galleryGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={project.image} alt={`${project.title} in ${project.location}`} />
                  <span className={styles.tag}>{project.category}</span>
                </div>
                <div className={styles.cardContent}>
                  <h2>{project.title}</h2>
                  <span className={styles.location}>{project.location}</span>
                  <p>{project.description}</p>
                  <ul>
                    {project.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
          {filteredProjects.length === 0 && (
            <div className={styles.empty}>
              <p>Für diese Kategorie sind noch keine Projekte veröffentlicht.</p>
            </div>
          )}
        </div>
      </section>

      <section className={styles.note}>
        <div className="container">
          <div className={styles.noteContent}>
            <div>
              <h2>Projektbesichtigung möglich</h2>
              <p>
                Gern vermitteln wir nach Absprache Besichtigungstermine zu ausgewählten Referenzprojekten.
                So erleben Sie Materialien, Pflanzungen und Lichtstimmungen vor Ort.
              </p>
            </div>
            <Link to="/kontakt" className="btn">
              Termin anfragen
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default GalleryPage;