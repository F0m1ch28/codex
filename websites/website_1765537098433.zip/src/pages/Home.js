import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const statsData = [
  { label: 'abgeschlossene Gartenprojekte', value: 320 },
  { label: 'Quadratmeter ökologisch gepflegt', value: 54000 },
  { label: 'Bäume und Sträucher gepflanzt', value: 870 },
  { label: 'Jahre Erfahrung im Team', value: 15 }
];

const servicesData = [
  {
    title: 'Maßgeschneiderte Gartengestaltung',
    description: 'Von der ersten Visualisierung bis zur finalen Umsetzung entwickeln wir einzigartige Gartenräume, die Architektur, Standort und Bedürfnisse harmonisch vereinen.',
    image: 'https://picsum.photos/600/400?random=201'
  },
  {
    title: 'Ganzjährige Gartenpflege',
    description: 'Regelmäßige Pflegepakete für Beete, Rasenflächen, Gehölze und ökologische Bewässerung sichern langfristig vitale und gepflegte Außenflächen.',
    image: 'https://picsum.photos/600/400?random=202'
  },
  {
    title: 'Dach- & Fassadenbegrünung',
    description: 'Wir verwandeln Dächer und Fassaden in klimawirksame, energieeffiziente Grünflächen – inklusive statischer Planung und Bewässerungskonzept.',
    image: 'https://picsum.photos/600/400?random=203'
  },
  {
    title: 'Naturnahe Regenwasserkonzepte',
    description: 'Moderne Versickerungs- und Regenwassernutzungssysteme, die Ressourcen schonen und Biodiversität fördern.',
    image: 'https://picsum.photos/600/400?random=204'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Analyse & Beratung',
    description: 'Wir nehmen uns Zeit für Ihre Wünsche, analysieren Standortfaktoren und entwickeln erste Ideen – fundiert und transparent.'
  },
  {
    step: '02',
    title: 'Konzept & Visualisierung',
    description: 'Moodboards, Pflanzenauswahl, 3D-Skizzen und Materialproben machen das Projekt greifbar und ermöglichen präzise Entscheidungen.'
  },
  {
    step: '03',
    title: 'Umsetzung & Koordination',
    description: 'Unser Team koordiniert alle Gewerke, überwacht die Umsetzung und sorgt für reibungslose Abläufe auf der Baustelle.'
  },
  {
    step: '04',
    title: 'Pflege & Begleitung',
    description: 'Wir bleiben an Ihrer Seite – mit individuellen Pflegeplänen, saisonalen Checks und intelligenten Bewässerungslösungen.'
  }
];

const galleryPreview = [
  {
    title: 'Grüner Innenhof in Prenzlauer Berg',
    image: 'https://picsum.photos/800/600?random=205',
    category: 'Hof & Patio'
  },
  {
    title: 'Urbaner Dachgarten in Mitte',
    image: 'https://picsum.photos/800/600?random=206',
    category: 'Dachgarten'
  },
  {
    title: 'Naturnahes Familienrefugium in Zehlendorf',
    image: 'https://picsum.photos/800/600?random=207',
    category: 'Privatgärten'
  },
  {
    title: 'Pflanzeninszenierung für Showroom',
    image: 'https://picsum.photos/800/600?random=208',
    category: 'Gewerbe'
  }
];

const testimonials = [
  {
    quote: 'GreenLeaf hat unseren verwilderten Hinterhof in eine grüne Oase verwandelt. Besonders beeindruckt hat uns die präzise Planung und die transparente Kommunikation.',
    name: 'Nora Weber',
    role: 'Architektin, Berlin-Kreuzberg',
    image: 'https://picsum.photos/200/200?random=209'
  },
  {
    quote: 'Nachhaltige Pflege, verlässliche Absprachen und ein Team, das wirklich zuhört – wir fühlen uns bestens betreut und unsere Mieter lieben das neue Grün.',
    name: 'Jens Hartmann',
    role: 'Hausverwaltung Hartmann',
    image: 'https://picsum.photos/200/200?random=210'
  },
  {
    quote: 'Vom Konzept über die Bauleitung bis zur Pflege erleben wir Professionalität auf höchstem Niveau. Unser Firmengelände ist zum Aushängeschild geworden.',
    name: 'Elisa Köhler',
    role: 'Geschäftsführerin, Tech Campus Berlin',
    image: 'https://picsum.photos/200/200?random=211'
  }
];

const faqData = [
  {
    question: 'Wie läuft die Planung eines Projekts ab?',
    answer: 'Nach einer ausführlichen Vor-Ort-Analyse erstellen wir Konzeptskizzen, Pflanzpläne sowie Materialvorschläge. Anschließend besprechen wir Prioritäten, Zeitplan und Koordination mit allen Partnern.'
  },
  {
    question: 'Bietet GreenLeaf auch saisonale Gartenpflege an?',
    answer: 'Ja, wir betreuen Gärten ganzjährig. Dazu zählen Schnittarbeiten, Bodenpflege, nachhaltige Düngung, Bewässerungsmanagement und Wintervorbereitungen.'
  },
  {
    question: 'Können bestehende Gärten umgestaltet werden?',
    answer: 'Wir arbeiten regelmäßig mit bestehenden Anlagen und entwickeln für jede Fläche ein individuelles Upcycling-Konzept, das Bestandspflanzen integriert und neue Akzente setzt.'
  },
  {
    question: 'Wie nachhaltig sind eure Lösungen?',
    answer: 'Wir setzen auf regionale Pflanzen, torffreie Substrate, ressourcenschonende Materialien sowie smarte Bewässerungssysteme. Unsere Konzepte orientieren sich an aktuellen Nachhaltigkeitsstandards.'
  }
];

const blogPosts = [
  {
    title: 'Regenerative Gartenkonzepte für urbane Räume',
    date: '05. März 2024',
    excerpt: 'Warum essbare Pflanzen, Regenwassermanagement und Biodiversität die Zukunft urbaner Gärten prägen – und wie wir diese Aspekte kombinieren.',
    image: 'https://picsum.photos/600/400?random=212'
  },
  {
    title: 'Fünf Stauden, die Berliner Sommer lieben',
    date: '18. Februar 2024',
    excerpt: 'Pflanzenportraits robuster Arten, die Trockenperioden trotzen und dennoch lange Blühphasen garantieren.',
    image: 'https://picsum.photos/600/400?random=213'
  },
  {
    title: 'So funktioniert smarte Bewässerung',
    date: '02. Januar 2024',
    excerpt: 'Digitale Sensorik, Wetterstationen und effiziente Tropfsysteme – wie moderne Technik Wasser spart und Pflanzen stärkt.',
    image: 'https://picsum.photos/600/400?random=214'
  }
];

const teamMembers = [
  {
    name: 'Lea Sommer',
    position: 'Leitung Design & Pflanzplanung',
    image: 'https://picsum.photos/400/400?random=215',
    bio: 'Lea entwickelt Konzepte, die Ästhetik und Ökologie verbinden. Sie ist zertifizierte Landschaftsarchitektin und liebt besondere Pflanzkombinationen.',
    focus: 'Schwerpunkte: Pflanzdesign, Biodiversität, naturnahe Konzepte'
  },
  {
    name: 'Felix Brandt',
    position: 'Projektleitung & Baukoordination',
    image: 'https://picsum.photos/400/400?random=216',
    bio: 'Felix sorgt dafür, dass jedes Projekt reibungslos umgesetzt wird – mit einem Netzwerk aus zuverlässigen Gewerken und einem Blick fürs Detail.',
    focus: 'Schwerpunkte: Bauleitung, Materialkonzepte, Qualitätssicherung'
  },
  {
    name: 'Mira Nguyen',
    position: 'Pflege & Nachhaltigkeitsstrategien',
    image: 'https://picsum.photos/400/400?random=217',
    bio: 'Mira begleitet Gärten langfristig. Sie entwickelt Pflegepläne, die Ressourcen sparen und Pflanzen dauerhaft stärken.',
    focus: 'Schwerpunkte: Pflegekonzepte, Regenwassernutzung, Sensorik'
  }
];

const HomePage = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [hasAnimated, setHasAnimated] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [selectedTeamIndex, setSelectedTeamIndex] = useState(0);
  const [openFaqIndex, setOpenFaqIndex] = useState(0);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [formStatus, setFormStatus] = useState(null);
  const statsRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
        }
      },
      { threshold: 0.35 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, [hasAnimated]);

  useEffect(() => {
    if (!hasAnimated) return;
    const intervals = statsData.map((stat, index) => {
      const increment = Math.max(1, Math.floor(stat.value / 60));
      return setInterval(() => {
        setAnimatedStats((prev) => {
          const newValues = [...prev];
          if (newValues[index] < stat.value) {
            newValues[index] = Math.min(newValues[index] + increment, stat.value);
          }
          return newValues;
        });
      }, 30);
    });

    const timeout = setTimeout(() => {
      setAnimatedStats(statsData.map((stat) => stat.value));
      intervals.forEach((interval) => clearInterval(interval));
    }, 2200);

    return () => {
      intervals.forEach((interval) => clearInterval(interval));
      clearTimeout(timeout);
    };
  }, [hasAnimated]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  const handlePrevTestimonial = () => {
    setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const handleNextTestimonial = () => {
    setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const handleFaqToggle = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Bitte geben Sie Ihren Namen ein.';
    }
    if (!formData.email.trim()) {
      errors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) {
      errors.message = 'Bitte beschreiben Sie kurz Ihr Anliegen.';
    }
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    setFormErrors({});
    setFormStatus('Vielen Dank für Ihre Nachricht! Wir melden uns kurzfristig bei Ihnen.');
    setFormData({ name: '', email: '', message: '' });
  };

  const selectedTeam = teamMembers[selectedTeamIndex];

  return (
    <>
      <SEO
        title="GreenLeaf Landscaping | Kreative Gartengestaltung in Berlin"
        description="GreenLeaf Landscaping bietet nachhaltigen Landschaftsbau, maßgeschneiderte Gartengestaltung und professionelle Pflegekonzepte in Berlin."
        path="/"
        image="https://picsum.photos/1200/630?random=218"
      />
      <div className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>Berlin · Nachhaltig · Persönlich</span>
            <h1 className={styles.heroTitle}>
              Lebensräume im Grünen – individuell geplant, nachhaltig gepflegt.
            </h1>
            <p className={styles.heroText}>
              GreenLeaf Landscaping gestaltet und betreut Gärten, Höfe und Dachlandschaften in Berlin.
              Mit Liebe zum Detail, fundierter Expertise und Lösungen, die Ihren Alltag erleichtern.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakt" className="btn">
                Kontakt aufnehmen
              </Link>
              <Link to="/dienstleistungen" className="btn btn-secondary">
                Leistungen entdecken
              </Link>
            </div>
            <div className={styles.heroHighlights}>
              <div>
                <strong>Ganzheitliche Konzepte</strong>
                <span>Planung, Umsetzung & Pflege aus einer Hand</span>
              </div>
              <div>
                <strong>Ökologische Materialien</strong>
                <span>Zertifizierte Pflanzen und ressourcenschonende Lösungen</span>
              </div>
              <div>
                <strong>Persönliche Betreuung</strong>
                <span>Feste Ansprechpartner für jedes Projekt</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className={styles.about}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div>
              <h2 className="sectionTitle">Starke Ideen für lebendige Gärten</h2>
              <p className="sectionSubtitle">
                Unser Team vereint Landschaftsarchitektur, Handwerk und Pflegekompetenz. Wir hören zu,
                denken voraus und gestalten Außenräume, die langfristig begeistern.
              </p>
              <ul className={styles.aboutList}>
                <li>Individuelle Konzeptentwicklung mit klarer Visualisierung</li>
                <li>Ganzheitliche Projektsteuerung in enger Abstimmung mit Ihnen</li>
                <li>Langfristige Begleitung durch maßgeschneiderte Pflegepakete</li>
              </ul>
            </div>
            <div className={styles.teamPanel}>
              <h3 className={styles.teamTitle}>Unser Kreativteam</h3>
              <div className={styles.teamList}>
                {teamMembers.map((member, index) => (
                  <button
                    type="button"
                    key={member.name}
                    className={`${styles.teamCard} ${
                      selectedTeamIndex === index ? styles.teamCardActive : ''
                    }`}
                    onMouseEnter={() => setSelectedTeamIndex(index)}
                    onFocus={() => setSelectedTeamIndex(index)}
                    onClick={() => setSelectedTeamIndex(index)}
                  >
                    <img src={member.image} alt={`${member.name} - ${member.position}`} />
                    <div>
                      <h4>{member.name}</h4>
                      <span>{member.position}</span>
                    </div>
                  </button>
                ))}
              </div>
              <div className={styles.teamDetail}>
                <h4>{selectedTeam.name}</h4>
                <p>{selectedTeam.bio}</p>
                <span>{selectedTeam.focus}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.servicesHeader}>
            <h2 className="sectionTitle">Unsere Leistungen</h2>
            <p className="sectionSubtitle">
              Von der Idee bis zur Pflege – wir entwickeln Lösungen, die zu Ihrem Alltag, Ihrem
              Gebäude und Ihrem Budget passen. Modular kombinierbar und jederzeit erweiterbar.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <img src={service.image} alt={`${service.title} Beispiel`} />
                <div className={styles.serviceContent}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <Link to="/dienstleistungen" className={styles.serviceLink}>
                    Mehr erfahren →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.process}>
            <h3>Unser Ablauf</h3>
            <div className={styles.processSteps}>
              {processSteps.map((step) => (
                <div key={step.step} className={styles.processCard}>
                  <span>{step.step}</span>
                  <h4>{step.title}</h4>
                  <p>{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.why} ref={statsRef}>
        <div className="container">
          <div className={styles.whyGrid}>
            <div className={styles.whyContent}>
              <h2 className="sectionTitle">Warum GreenLeaf?</h2>
              <p className="sectionSubtitle">
                Wir denken Gärten als integralen Bestandteil Ihres Lebens- oder Arbeitsortes. Mit
                durchdachten Konzepten schaffen wir Räume zum Durchatmen, Wohlfühlen und Repräsentieren.
              </p>
              <ul className={styles.whyList}>
                <li>Ausgezeichnetes Team aus Landschaftsarchitektur, Gärtnerhandwerk und Technik</li>
                <li>Transparente Kommunikation, strukturierte Abwicklung, zuverlässige Zeitplanung</li>
                <li>Nachhaltige Materialien, torffreie Erde, regionale Partnerbetriebe</li>
              </ul>
            </div>
            <div className={styles.stats}>
              {statsData.map((stat, index) => (
                <div key={stat.label} className={styles.statCard}>
                  <strong>{animatedStats[index]}+</strong>
                  <span>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2 className="sectionTitle">Projektgalerie</h2>
            <p className="sectionSubtitle">
              Ein Auszug unserer Arbeiten – vom begrünten Innenhof über luxuriöse Privatgärten bis hin
              zu begrünten Unternehmensstandorten.
            </p>
            <Link to="/projektgalerie" className="btn btn-secondary">
              Alle Projekte ansehen
            </Link>
          </div>
          <div className={styles.projectGrid}>
            {galleryPreview.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} />
                  <span>{project.category}</span>
                </div>
                <h3>{project.title}</h3>
                <Link to="/projektgalerie">Details entdecken →</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialWrapper}>
            <button
              type="button"
              className={styles.testimonialControl}
              onClick={handlePrevTestimonial}
              aria-label="Vorheriges Kundenfeedback"
            >
              ‹
            </button>
            <div className={styles.testimonialContent}>
              <img
                src={testimonials[activeTestimonial].image}
                alt={`${testimonials[activeTestimonial].name} Portrait`}
              />
              <blockquote>
                „{testimonials[activeTestimonial].quote}“
              </blockquote>
              <div className={styles.testimonialMeta}>
                <strong>{testimonials[activeTestimonial].name}</strong>
                <span>{testimonials[activeTestimonial].role}</span>
              </div>
              <div className={styles.testimonialIndicators}>
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    type="button"
                    className={`${styles.dot} ${
                      index === activeTestimonial ? styles.dotActive : ''
                    }`}
                    onClick={() => setActiveTestimonial(index)}
                    aria-label={`Feedback ${index + 1} anzeigen`}
                  />
                ))}
              </div>
            </div>
            <button
              type="button"
              className={styles.testimonialControl}
              onClick={handleNextTestimonial}
              aria-label="Nächstes Kundenfeedback"
            >
              ›
            </button>
          </div>
        </div>
      </section>

      <section className={styles.insights}>
        <div className="container">
          <div className={styles.insightsGrid}>
            <div>
              <h2 className="sectionTitle">Green Insights</h2>
              <p className="sectionSubtitle">
                Aktuelle Trends, Pflanzentipps und Hintergrundwissen aus unserem Studio für
                Landschaftsarchitektur.
              </p>
              <div className={styles.blogList}>
                {blogPosts.map((post) => (
                  <article key={post.title} className={styles.blogCard}>
                    <img src={post.image} alt={post.title} />
                    <div>
                      <span>{post.date}</span>
                      <h3>{post.title}</h3>
                      <p>{post.excerpt}</p>
                      <Link to="/dienstleistungen">Zum Beitrag →</Link>
                    </div>
                  </article>
                ))}
              </div>
            </div>
            <div className={styles.faq}>
              <h3>Häufige Fragen</h3>
              <div className={styles.faqList}>
                {faqData.map((item, index) => (
                  <div
                    key={item.question}
                    className={`${styles.faqItem} ${
                      openFaqIndex === index ? styles.faqItemOpen : ''
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => handleFaqToggle(index)}
                      aria-expanded={openFaqIndex === index}
                    >
                      <span>{item.question}</span>
                      <span>{openFaqIndex === index ? '–' : '+'}</span>
                    </button>
                    <div className={styles.faqContent}>
                      <p>{item.answer}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className={styles.faqHelp}>
                <p>Noch Fragen offen? Wir beraten Sie gern persönlich.</p>
                <Link to="/kontakt" className="btn btn-secondary">
                  Termin vereinbaren
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.contactWrapper}>
            <div className={styles.contactIntro}>
              <h2 className="sectionTitle">Lassen Sie uns Ihr Projekt besprechen</h2>
              <p className="sectionSubtitle">
                Ob Neubepflanzung, Umgestaltung oder Pflege – wir freuen uns auf Ihre Ideen. Teilen Sie
                uns ein paar Eckdaten mit, wir melden uns zeitnah zurück.
              </p>
              <div className={styles.contactInfo}>
                <div>
                  <strong>Adresse</strong>
                  <span>Gartenstraße 15, 10115 Berlin</span>
                </div>
                <div>
                  <strong>Telefon</strong>
                  <a href="tel:+493012345678">+49 30 12345678</a>
                </div>
                <div>
                  <strong>E-Mail</strong>
                  <a href="mailto:info@greenleaf-landscaping.de">info@greenleaf-landscaping.de</a>
                </div>
              </div>
            </div>
            <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
              <label>
                Name*
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Ihr Name"
                  aria-invalid={!!formErrors.name}
                />
                {formErrors.name && <span className={styles.error}>{formErrors.name}</span>}
              </label>
              <label>
                E-Mail*
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="beispiel@domain.de"
                  aria-invalid={!!formErrors.email}
                />
                {formErrors.email && <span className={styles.error}>{formErrors.email}</span>}
              </label>
              <label>
                Ihr Anliegen*
                <textarea
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Was dürfen wir für Sie gestalten?"
                  aria-invalid={!!formErrors.message}
                />
                {formErrors.message && <span className={styles.error}>{formErrors.message}</span>}
              </label>
              {formStatus && <div className={styles.success}>{formStatus}</div>}
              <button type="submit" className="btn">
                Nachricht senden
              </button>
            </form>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <h2>Bereit für Ihren nächsten grünen Lieblingsort?</h2>
          <p>
            Vereinbaren Sie einen unverbindlichen Beratungstermin und entdecken Sie, wie wir Ihre Fläche
            in Berlin in einen lebendigen Wohlfühlraum verwandeln können.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/kontakt" className="btn">
              Projekt starten
            </Link>
            <Link to="/projektgalerie" className="btn btn-secondary">
              Inspiration sammeln
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;