import SEO from '../components/SEO';
import styles from './Legal.module.css';

const CookiePolicyPage = () => (
  <>
    <SEO
      title="Cookie-Richtlinie | GreenLeaf Landscaping"
      description="Informationen zum Einsatz von Cookies auf der Website von GreenLeaf Landscaping."
      path="/cookie-richtlinie"
      image="https://picsum.photos/1200/630?random=251"
    />
    <div className={`container ${styles.wrapper}`}>
      <h1 className={styles.title}>Cookie-Richtlinie</h1>
      <p className={styles.intro}>
        In dieser Richtlinie erklären wir, welche Cookies wir verwenden, zu welchem Zweck dies erfolgt
        und wie Sie Ihre Einwilligung verwalten können.
      </p>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Was sind Cookies?</h2>
        <p>
          Cookies sind kleine Textdateien, die Ihr Browser auf Ihrem Endgerät speichert. Sie ermöglichen
          Funktionen wie das Speichern von Einstellungen oder das Analysieren der Seitennutzung.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Eingesetzte Cookie-Kategorien</h2>
        <ul className={styles.list}>
          <li>
            <strong>Notwendig:</strong> Cookies, die für den Betrieb der Website erforderlich sind (z.&nbsp;B.
            zur Speicherung Ihrer Cookie-Einstellungen). Diese können nicht deaktiviert werden.
          </li>
          <li>
            <strong>Analyse:</strong> Cookies, die uns helfen, das Nutzerverhalten anonym auszuwerten und
            unser Angebot zu verbessern. Sie werden erst nach Ihrer Einwilligung gesetzt.
          </li>
          <li>
            <strong>Marketing:</strong> Cookies, die genutzt werden, um personalisierte Inhalte oder
            externe Medien (z.&nbsp;B. Karten) anzuzeigen. Auch diese setzen Ihre vorherige Zustimmung
            voraus.
          </li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Verwaltung Ihrer Einwilligung</h2>
        <p>
          Beim ersten Besuch unserer Website haben Sie die Möglichkeit, einzelne Cookie-Kategorien zu
          akzeptieren oder abzulehnen. Ihre Einstellungen können Sie jederzeit über den Button
          „Einstellungen“ im Cookie-Banner anpassen.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Speicherdauer</h2>
        <p>
          Die Speicherdauer hängt von der jeweiligen Cookie-Kategorie ab. Notwendige Cookies speichern wir
          in der Regel für 12 Monate, sofern keine gesetzlichen Vorgaben eine längere Aufbewahrung
          erfordern. Analyse- und Marketing-Cookies werden spätestens nach 12 Monaten automatisch gelöscht.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>5. Widerruf</h2>
        <p>
          Sie können Ihre Einwilligung jederzeit mit Wirkung für die Zukunft widerrufen, indem Sie Ihre
          Cookie-Einstellungen aktualisieren oder Cookies in Ihrem Browser löschen.
        </p>
      </section>

      <div className={styles.contact}>
        <strong>Fragen?</strong>
        <p>
          Schreiben Sie uns an info@greenleaf-landscaping.de oder rufen Sie uns unter +49 30 12345678 an.
        </p>
      </div>
    </div>
  </>
);

export default CookiePolicyPage;