import SEO from '../components/SEO';
import styles from './Legal.module.css';

const TermsPage = () => (
  <>
    <SEO
      title="Nutzungsbedingungen | GreenLeaf Landscaping"
      description="Erfahren Sie mehr über die allgemeinen Nutzungsbedingungen für die Website von GreenLeaf Landscaping."
      path="/nutzungsbedingungen"
      image="https://picsum.photos/1200/630?random=249"
    />
    <div className={`container ${styles.wrapper}`}>
      <h1 className={styles.title}>Nutzungsbedingungen</h1>
      <p className={styles.intro}>
        Diese Nutzungsbedingungen regeln die Nutzung der Website von GreenLeaf Landscaping. Mit dem
        Zugriff auf unsere Inhalte erklären Sie sich mit den folgenden Bestimmungen einverstanden.
      </p>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Geltungsbereich</h2>
        <p>
          Die Website richtet sich an Interessent:innen und Kund:innen in Deutschland, insbesondere im
          Raum Berlin. Die Inhalte dienen der Information über unser Unternehmen, unsere Dienstleistungen
          und aktuelle Projekte.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Leistungen</h2>
        <p>
          Die auf der Website dargestellten Leistungen sind unverbindlich und stellen kein bindendes
          Angebot dar. Individuelle Leistungsumfänge werden im Rahmen persönlicher Beratungsgespräche und
          schriftlicher Vereinbarungen festgelegt.
        </p>
        <p>
          Änderungen, Ergänzungen oder Aktualisierungen unseres Leistungsportfolios behalten wir uns vor.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Nutzung der Inhalte</h2>
        <p>
          Texte, Bilder, Grafiken und sonstige Inhalte sind urheberrechtlich geschützt. Die Nutzung ist
          ausschließlich zum privaten Gebrauch gestattet. Eine weitergehende Verwendung, insbesondere die
          Vervielfältigung, Veröffentlichung oder Weitergabe, bedarf der schriftlichen Zustimmung von
          GreenLeaf Landscaping.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Haftungsausschluss</h2>
        <p>
          Wir prüfen und aktualisieren die Inhalte unserer Website regelmäßig. Trotzdem können Fehler
          oder Unvollständigkeiten nicht ausgeschlossen werden. Eine Haftung für die Aktualität,
          Vollständigkeit und Richtigkeit der Informationen wird daher ausgeschlossen, sofern kein
          vorsätzliches oder grob fahrlässiges Verhalten vorliegt.
        </p>
        <p>
          Für Inhalte externer Websites, auf die wir verlinken, übernehmen wir keine Verantwortung. Die
          Nutzung erfolgt auf eigenes Risiko.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>5. Änderungen der Nutzungsbedingungen</h2>
        <p>
          GreenLeaf Landscaping behält sich das Recht vor, diese Nutzungsbedingungen jederzeit zu
          aktualisieren. Maßgeblich ist jeweils die zum Zeitpunkt des Zugriffs veröffentlichte Version.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>6. Anwendbares Recht</h2>
        <p>
          Es gilt deutsches Recht. Gerichtsstand ist, soweit gesetzlich zulässig, Berlin.
        </p>
      </section>

      <div className={styles.contact}>
        <strong>Kontakt</strong>
        <p>
          GreenLeaf Landscaping · Gartenstraße 15 · 10115 Berlin<br />
          Telefon: +49 30 12345678 · E-Mail: info@greenleaf-landscaping.de
        </p>
      </div>
    </div>
  </>
);

export default TermsPage;