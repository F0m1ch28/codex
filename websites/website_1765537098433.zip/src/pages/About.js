import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './About.module.css';

const valueItems = [
  {
    title: 'Partnerschaftliche Zusammenarbeit',
    description:
      'Wir legen großen Wert auf offene Kommunikation und transparente Prozesse. Jede Phase wird mit Ihnen abgestimmt, damit Gestaltung, Budget und Zeitplan übereinstimmen.',
    image: 'https://picsum.photos/600/400?random=221'
  },
  {
    title: 'Design mit Haltung',
    description:
      'Unsere Konzepte verbinden Ästhetik mit ökologischer Verantwortung. Wir planen klimaresilient, fördern Biodiversität und wählen Materialien sorgfältig aus.',
    image: 'https://picsum.photos/600/400?random=222'
  },
  {
    title: 'Hands-on Umsetzung',
    description:
      'Unser Team begleitet Ihr Projekt bis zur letzten Pflanzung. Eigene Pflegecrews und qualifizierte Partner sorgen für Präzision und langlebige Ergebnisse.',
    image: 'https://picsum.photos/600/400?random=223'
  }
];

const milestones = [
  {
    year: '2010',
    title: 'Gründung in Berlin',
    description:
      'GreenLeaf Landscaping startet als kleines Studio für Gartengestaltung und entwickelt erste Projekte im Prenzlauer Berg.'
  },
  {
    year: '2014',
    title: 'Aufbau Pflege-Services',
    description:
      'Erweiterung um ein eigenes Pflege-Team, um Kund:innen langfristig zu begleiten und Qualitätsstandards zu sichern.'
  },
  {
    year: '2018',
    title: 'Dach- & Fassadenbegrünung',
    description:
      'Integration einer Fachabteilung für gebäudebezogenes Grün inklusive Statikplanung, Bewässerungstechnik und Monitoring.'
  },
  {
    year: '2022',
    title: 'Digitales Gartenmanagement',
    description:
      'Einführung smarter Sensorik, digitales Reporting und Online-Serviceportal für unsere Kund:innen.'
  }
];

const sustainabilityFocus = [
  'Torffreie Substrate, regionale Baumschulware und recyclingfähige Materialien.',
  'Smarte Bewässerungssysteme, die sich an Wetterdaten orientieren und Wasser sparen.',
  'Biodiversität durch heimische Pflanzen, Blühstreifen und Lebensräume für Insekten.',
  'CO₂-arme Logistik dank E-Transportern und enger Zusammenarbeit mit Berliner Partnerbetrieben.'
];

const competencyAreas = [
  {
    title: 'Landschaftsarchitektur',
    points: [
      'Ganzheitliche Konzeptentwicklung',
      '3D-Visualisierungen und Materialcollagen',
      'Pflanzpläne, Beleuchtung, Wasser- und Wegegestaltung'
    ]
  },
  {
    title: 'Ausführung & Bauleitung',
    points: [
      'Koordination aller Gewerke',
      'Qualitätssicherung auf der Baustelle',
      'Dokumentation und Übergabe mit Pflegeleitfaden'
    ]
  },
  {
    title: 'Pflege & Monitoring',
    points: [
      'Individuelle Pflegepläne und Saisonpakete',
      'Pflanzenmonitoring mit digitalen Tools',
      'Workshops für Hausverwaltungen und Facility Teams'
    ]
  }
];

const AboutPage = () => (
  <>
    <SEO
      title="Über GreenLeaf Landscaping | Team, Werte & Geschichte"
      description="GreenLeaf Landscaping vereint Landschaftsarchitektur, Handwerk und nachhaltige Pflege. Erfahren Sie mehr über unser Team, unsere Arbeitsweise und unsere Werte."
      path="/ueber-uns"
      image="https://picsum.photos/1200/630?random=220"
    />

    <section className={styles.hero}>
      <div className={`container ${styles.heroGrid}`}>
        <div>
          <span className={styles.badge}>Seit 2010 in Berlin</span>
          <h1>Wer wir sind</h1>
          <p>
            GreenLeaf Landscaping ist ein Team aus Landschaftsarchitekt:innen, Gartenbautechniker:innen
            und Pflegeprofis. Wir planen, bauen und betreuen Gärten mit einem klaren Fokus auf
            Nachhaltigkeit, Ästhetik und Langlebigkeit.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className="btn">
              Beratung anfragen
            </Link>
            <Link to="/projektgalerie" className="btn btn-secondary">
              Projekte entdecken
            </Link>
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/900/700?random=224"
            alt="GreenLeaf Team bei der Gartenplanung"
          />
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <h2 className="sectionTitle">Unsere Werte</h2>
        <p className="sectionSubtitle">
          Drei Säulen prägen unseren Arbeitsalltag – verlässliche Partnerschaft, ein klares Designverständnis
          und die Umsetzung mit erfahrenen Spezialist:innen.
        </p>
        <div className={styles.valueGrid}>
          {valueItems.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <img src={value.image} alt={value.title} />
              <div>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.competencies}>
      <div className="container">
        <div className={styles.competenciesHeader}>
          <h2 className="sectionTitle">Kompetenzen unter einem Dach</h2>
          <p className="sectionSubtitle">
            Unser interdisziplinäres Team arbeitet eng verzahnt. So entstehen passgenaue Lösungen,
            die Planung, Umsetzung und Pflege zuverlässig verbinden.
          </p>
        </div>
        <div className={styles.competencyGrid}>
          {competencyAreas.map((area) => (
            <div key={area.title} className={styles.competencyCard}>
              <h3>{area.title}</h3>
              <ul>
                {area.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.milestones}>
      <div className="container">
        <h2 className="sectionTitle">Meilensteine</h2>
        <p className="sectionSubtitle">
          Wir wachsen mit unseren Projekten und entwickeln unser Portfolio stetig weiter – von der
          klassischen Gartengestaltung hin zu umfassenden Begrünungskonzepten für urbane Räume.
        </p>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <div key={milestone.year} className={styles.milestone}>
              <span>{milestone.year}</span>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.sustainability}>
      <div className="container">
        <div className={styles.sustainabilityGrid}>
          <div>
            <h2 className="sectionTitle">Nachhaltigkeit als Leitlinie</h2>
            <p className="sectionSubtitle">
              Wir verstehen Nachhaltigkeit ganzheitlich – vom Bodenaufbau über Bewässerung bis hin
              zur langfristigen Pflege. Unser Ziel: klimaresiliente, lebendige Flächen.
            </p>
            <ul className={styles.sustainabilityList}>
              {sustainabilityFocus.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div className={styles.sustainabilityImage}>
            <img
              src="https://picsum.photos/800/600?random=225"
              alt="Nachhaltige Gartenpflege in Berlin"
            />
          </div>
        </div>
      </div>
    </section>

    <section className={styles.closing}>
      <div className="container">
        <h2>Gemeinsam Großes bewirken</h2>
        <p>
          Ob privater Garten, Unternehmenscampus oder urbanes Nachverdichtungsprojekt – wir begleiten Sie
          vom ersten Gespräch bis zur langfristigen Pflegepartnerschaft.
        </p>
        <Link to="/kontakt" className="btn">
          Projekt unverbindlich anfragen
        </Link>
      </div>
    </section>
  </>
);

export default AboutPage;