import { useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Services.module.css';

const services = [
  {
    id: 'planung',
    title: 'Garten- & Landschaftsplanung',
    summary: 'Individuelle Konzepte mit klarer Visualisierung und detaillierten Pflanzplänen.',
    image: 'https://picsum.photos/900/600?random=230',
    intro:
      'Wir entwickeln maßgeschneiderte Konzepte, die Architektur, Standortbedingungen und Ihre persönlichen Vorlieben vereinen. Von Moodboards bis zu detaillierten Pflanzplänen entsteht ein Plan, der Orientierung gibt und Begeisterung schafft.',
    highlights: [
      'Analyse von Standort, Boden und Lichtverhältnissen',
      'Moodboards, Materialcollagen und 3D-Visualisierungen',
      'Pflanzpläne inklusive Blühkalender und Pflegehinweisen'
    ],
    deliverables: [
      'Konzeptmappe mit Visualisierungen',
      'Kostenschätzung nach Leistungsphasen',
      'Zeitplan und Koordination der Gewerke'
    ]
  },
  {
    id: 'bau',
    title: 'Umsetzung & Bauleitung',
    summary: 'Sorgfältige Umsetzung mit erfahrenen Teams und transparenter Koordination.',
    image: 'https://picsum.photos/900/600?random=231',
    intro:
      'Von der Baustellenvorbereitung bis zur finalen Abnahme stehen wir für Qualität. Wir koordinieren alle Gewerke, stimmen uns eng mit Ihnen ab und dokumentieren jeden Schritt.',
    highlights: [
      'Baukoordination mit zertifizierten Partnerbetrieben',
      'Präzise Umsetzung von Wegen, Terrassen, Wasser- und Lichtkonzepten',
      'Pflanzleistungen, Bodenaufbereitung und technische Installationen'
    ],
    deliverables: [
      'Bauzeitenplan und Meilensteine',
      'Regelmäßiges Reporting mit Fotodokumentation',
      'Übergabe mit Pflege- und Bewässerungsempfehlungen'
    ]
  },
  {
    id: 'pflege',
    title: 'Ganzjährige Gartenpflege',
    summary: 'Verlässliche Pflegepakete, die Ihren Garten langfristig vital halten.',
    image: 'https://picsum.photos/900/600?random=232',
    intro:
      'Gärten entfalten ihr Potential durch kontinuierliche Pflege. Wir erstellen individuelle Saisonpläne und kümmern uns um Pflanzengesundheit, Nachhaltigkeit und Ästhetik.',
    highlights: [
      'Regelmäßige Pflege- und Kontrolltermine',
      'Schnitt von Gehölzen, Stauden und Rasenmanagement',
      'Ökologische Bodenpflege und nachhaltige Düngung'
    ],
    deliverables: [
      'Pflegekalender mit empfohlenen Intervallen',
      'Digitales Protokoll jeder Pflegerunde',
      'Notfallservice bei Sturmschäden oder Schädlingsdruck'
    ]
  },
  {
    id: 'objekt',
    title: 'Dach- & Fassadenbegrünung',
    summary: 'Grüne Gebäudehüllen, die Klima und Architektur positiv beeinflussen.',
    image: 'https://picsum.photos/900/600?random=233',
    intro:
      'Wir verwandeln Dächer und Fassaden in klimaaktive Flächen. Unsere Expert:innen planen statische Voraussetzungen, Substrataufbauten und Bewässerungssysteme passgenau.',
    highlights: [
      'Machbarkeitsanalyse inklusive Statik und Entwässerung',
      'Auswahl klimaresilienter Pflanzen und Substrate',
      'Monitoring und Wartung von Bewässerungstechnik'
    ],
    deliverables: [
      'Technische Detailpläne und Aufbauzeichnungen',
      'Abstimmung mit Behörden und Förderprogramme',
      'Wartungsverträge und jährliche Kontrolle'
    ]
  },
  {
    id: 'regenwasser',
    title: 'Regenwassermanagement',
    summary: 'Ressourcenschonende Systeme für Bewässerung und Versickerung.',
    image: 'https://picsum.photos/900/600?random=234',
    intro:
      'Mit innovativen Regenwasserkonzepten nutzen wir Niederschläge effizient, entlasten Kanalisationen und sichern die Versorgung Ihrer Pflanzflächen.',
    highlights: [
      'Versickerungs- und Retentionskonzepte für urbane Flächen',
      'Integration von Zisternen, Tropfbewässerung und Sensorik',
      'Fördermittelberatung und Dokumentation'
    ],
    deliverables: [
      'Hydrologische Berechnungen und Planung',
      'Installation, Inbetriebnahme und Schulung',
      'Monitoring und regelmäßige Funktionskontrolle'
    ]
  }
];

const addons = [
  {
    title: 'Pflanzenpflege-Coaching',
    description: 'Workshops für Hausverwaltungen oder Teammitglieder, die Pflegeaufgaben selbst übernehmen möchten.'
  },
  {
    title: 'Licht- & Atmosphärenkonzepte',
    description: 'Inszenierte Beleuchtung für Wege, Bäume und Fassaden – inklusive Montage und Programmierung.'
  },
  {
    title: 'Smarte Sensorik & Monitoring',
    description: 'Feuchtigkeitssensoren, Wetterstationen und Reporting-Tools für eine effiziente Grünflächensteuerung.'
  }
];

const workflowSteps = [
  {
    title: 'Kick-off & Analyse',
    description: 'Bedarfsanalyse, Flächenaufmaß und Definition der Projektziele. Wir dokumentieren den Ist-Zustand und besprechen Prioritäten.'
  },
  {
    title: 'Konzept & Angebot',
    description: 'Erstellung von Entwürfen, Pflanzplänen und Kostenschätzungen. Transparente Angebote mit klaren Leistungsbeschreibungen.'
  },
  {
    title: 'Realisation',
    description: 'Koordination aller Gewerke, Qualitätskontrolle und enge Abstimmung mit Ihnen. Regelmäßige Updates halten Sie auf dem Laufenden.'
  },
  {
    title: 'Pflege & Weiterentwicklung',
    description: 'Übergabe mit Pflegeplan und optionaler Betreuung durch unser Team. Wir justieren Pflanzungen nach und begleiten langfristig.'
  }
];

const ServicesPage = () => {
  const [activeServiceId, setActiveServiceId] = useState(services[0].id);
  const activeService = services.find((service) => service.id === activeServiceId);

  return (
    <>
      <SEO
        title="Leistungen von GreenLeaf Landscaping | Planung, Bau & Pflege"
        description="Entdecken Sie das Leistungsspektrum von GreenLeaf Landscaping: Gartengestaltung, Bauleitung, Pflege, Dach- und Fassadenbegrünung sowie Regenwassermanagement in Berlin."
        path="/dienstleistungen"
        image="https://picsum.photos/1200/630?random=235"
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Leistungen, die Ihre Grünflächen zum Strahlen bringen</h1>
            <p>
              Wir begleiten Ihr Projekt von der ersten Idee bis zur nachhaltigen Pflege. Dank eingespielter
              Teams, klarer Prozesse und digitaler Tools entstehen Außenräume, die langfristig überzeugen.
            </p>
            <div className={styles.heroHighlights}>
              <div>
                <strong>Ganzheitlich</strong>
                <span>Planung, Umsetzung und Pflege aus einer Hand</span>
              </div>
              <div>
                <strong>Transparent</strong>
                <span>Klare Leistungsbausteine und verlässliche Absprachen</span>
              </div>
              <div>
                <strong>Nachhaltig</strong>
                <span>Ökologisch verantwortungsvolle Materialien und Lösungen</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.serviceSection}>
        <div className="container">
          <div className={styles.layout}>
            <aside className={styles.serviceList} aria-label="Leistungsübersicht">
              {services.map((service) => (
                <button
                  key={service.id}
                  type="button"
                  onClick={() => setActiveServiceId(service.id)}
                  className={`${styles.serviceButton} ${
                    activeServiceId === service.id ? styles.serviceButtonActive : ''
                  }`}
                  aria-pressed={activeServiceId === service.id}
                >
                  <h3>{service.title}</h3>
                  <p>{service.summary}</p>
                </button>
              ))}
            </aside>
            <article className={styles.serviceDetail}>
              <div className={styles.detailImage}>
                <img src={activeService.image} alt={activeService.title} />
              </div>
              <div className={styles.detailContent}>
                <h2>{activeService.title}</h2>
                <p>{activeService.intro}</p>
                <div className={styles.detailLists}>
                  <div>
                    <h4>Highlights</h4>
                    <ul>
                      {activeService.highlights.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4>Sie erhalten</h4>
                    <ul>
                      {activeService.deliverables.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
                <Link to="/kontakt" className="btn">
                  Beratungsgespräch vereinbaren
                </Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.addons}>
        <div className="container">
          <h2 className="sectionTitle">Optionale Module</h2>
          <p className="sectionSubtitle">
            Unsere Leistungen lassen sich flexibel erweitern. Gemeinsam stellen wir das Paket zusammen,
            das perfekt zu Ihren Anforderungen passt.
          </p>
          <div className={styles.addonGrid}>
            {addons.map((addon) => (
              <div key={addon.title} className={styles.addonCard}>
                <h3>{addon.title}</h3>
                <p>{addon.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.workflow}>
        <div className="container">
          <h2 className="sectionTitle">So arbeiten wir zusammen</h2>
          <p className="sectionSubtitle">
            Transparente Prozesse geben Sicherheit. Von Beginn an wissen Sie, welche Schritte anstehen
            und wer Ihr Ansprechpartner ist.
          </p>
          <div className={styles.workflowSteps}>
            {workflowSteps.map((step, index) => (
              <div key={step.title} className={styles.workflowCard}>
                <span>{String(index + 1).padStart(2, '0')}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <h2>Sie möchten Ihr Projekt starten?</h2>
          <p>
            Erzählen Sie uns von Ihrer Idee – wir erstellen ein individuelles Leistungspaket und begleiten
            Sie Schritt für Schritt.
          </p>
          <Link to="/kontakt" className="btn">
            Unverbindliches Erstgespräch sichern
          </Link>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;