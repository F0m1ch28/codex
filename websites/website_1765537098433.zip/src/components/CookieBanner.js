import { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'greenleaf-cookie-consent';

const defaultPreferences = {
  necessary: true,
  analytics: false,
  marketing: false
};

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState(defaultPreferences);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setPreferences({ ...defaultPreferences, ...parsed });
      } catch (error) {
        console.error(error);
      }
    } else {
      setIsVisible(true);
    }
  }, []);

  const handleAcceptAll = () => {
    const consent = { necessary: true, analytics: true, marketing: true };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(consent));
    setPreferences(consent);
    setIsVisible(false);
  };

  const handleSave = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
    setIsVisible(false);
  };

  const togglePreference = (key) => {
    if (key === 'necessary') return;
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h3 className={styles.title}>Wir verwenden Cookies</h3>
        <p className={styles.text}>
          Wir nutzen Cookies, um unsere Webseite nutzerfreundlicher zu machen und Inhalte zu personalisieren.
          Sie können selbst entscheiden, welche Kategorien Sie zulassen möchten.
        </p>
        {showSettings && (
          <div className={styles.settings}>
            <label className={styles.option}>
              <input type="checkbox" checked readOnly />
              <span>
                Notwendig<span className={styles.optionHint}> Immer aktiv</span>
              </span>
            </label>
            <label className={styles.option}>
              <input
                type="checkbox"
                checked={preferences.analytics}
                onChange={() => togglePreference('analytics')}
              />
              <span>Analyse</span>
            </label>
            <label className={styles.option}>
              <input
                type="checkbox"
                checked={preferences.marketing}
                onChange={() => togglePreference('marketing')}
              />
              <span>Marketing</span>
            </label>
          </div>
        )}
        <div className={styles.actions}>
          <button type="button" className="btn-secondary btn" onClick={() => setShowSettings((prev) => !prev)}>
            {showSettings ? 'Einstellungen schließen' : 'Einstellungen'}
          </button>
          {showSettings ? (
            <button type="button" className="btn" onClick={handleSave}>
              Auswahl speichern
            </button>
          ) : (
            <button type="button" className="btn" onClick={handleAcceptAll}>
              Alle akzeptieren
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;