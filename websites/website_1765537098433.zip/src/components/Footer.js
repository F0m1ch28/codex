import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.grid}`}>
      <div className={styles.brand}>
        <h3 className={styles.brandTitle}>GreenLeaf Landscaping</h3>
        <p className={styles.brandSubtitle}>
          Wir gestalten, pflegen und beleben Gärten in ganz Berlin – mit viel Liebe zur Natur,
          nachhaltigen Konzepten und einem Auge für Details.
        </p>
        <div className={styles.socials}>
          <a
            href="https://www.instagram.com/"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.social}
            aria-label="Instagram"
          >
            ♡
          </a>
          <a
            href="https://www.facebook.com/"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.social}
            aria-label="Facebook"
          >
            f
          </a>
          <a
            href="https://www.linkedin.com/"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.social}
            aria-label="LinkedIn"
          >
            in
          </a>
        </div>
      </div>
      <div>
        <h4 className={styles.columnTitle}>Navigation</h4>
        <ul className={styles.linkList}>
          <li>
            <Link to="/" className={styles.link}>Startseite</Link>
          </li>
          <li>
            <Link to="/dienstleistungen" className={styles.link}>Dienstleistungen</Link>
          </li>
          <li>
            <Link to="/ueber-uns" className={styles.link}>Über uns</Link>
          </li>
          <li>
            <Link to="/projektgalerie" className={styles.link}>Projektgalerie</Link>
          </li>
          <li>
            <Link to="/kontakt" className={styles.link}>Kontakt</Link>
          </li>
        </ul>
      </div>
      <div>
        <h4 className={styles.columnTitle}>Kontakt</h4>
        <ul className={styles.contactList}>
          <li>
            <a
              className={styles.contactLink}
              href="https://maps.google.com/?q=Gartenstraße+15,+10115+Berlin"
              target="_blank"
              rel="noopener noreferrer"
            >
              Gartenstraße 15<br />10115 Berlin
            </a>
          </li>
          <li>
            <a className={styles.contactLink} href="tel:+493012345678">+49 30 12345678</a>
          </li>
          <li>
            <a className={styles.contactLink} href="mailto:info@greenleaf-landscaping.de">info@greenleaf-landscaping.de</a>
          </li>
        </ul>
      </div>
      <div>
        <h4 className={styles.columnTitle}>Rechtliches</h4>
        <ul className={styles.linkList}>
          <li>
            <Link to="/nutzungsbedingungen" className={styles.link}>Nutzungsbedingungen</Link>
          </li>
          <li>
            <Link to="/datenschutz" className={styles.link}>Datenschutz</Link>
          </li>
          <li>
            <Link to="/cookie-richtlinie" className={styles.link}>Cookie-Richtlinie</Link>
          </li>
        </ul>
      </div>
    </div>
    <div className={`container ${styles.bottom}`}>
      <span>© {new Date().getFullYear()} GreenLeaf Landscaping. Alle Rechte vorbehalten.</span>
      <div className={styles.bottomLinks}>
        <span>Gartenstraße 15, 10115 Berlin</span>
        <span>+49 30 12345678</span>
        <span>info@greenleaf-landscaping.de</span>
      </div>
    </div>
  </footer>
);

export default Footer;