import { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Startseite' },
  { path: '/dienstleistungen', label: 'Dienstleistungen' },
  { path: '/ueber-uns', label: 'Über uns' },
  { path: '/projektgalerie', label: 'Projektgalerie' },
  { path: '/kontakt', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : 'auto';
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [menuOpen]);

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link to="/" className={styles.logo} aria-label="GreenLeaf Landscaping Startseite">
          GreenLeaf Landscaping
          <span>Gärten mit Charakter</span>
        </Link>

        <nav className={styles.nav} aria-label="Hauptnavigation">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  end={item.path === '/'}
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <Link to="/kontakt" className={`${styles.contactButton} btn`}>
          Kontakt aufnehmen
        </Link>

        <button
          type="button"
          className={styles.menuToggle}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-label="Navigation öffnen oder schließen"
        >
          {menuOpen ? '×' : '☰'}
        </button>
      </div>

      <div className={`${styles.mobileNav} ${menuOpen ? styles.open : ''}`} aria-hidden={!menuOpen}>
        <div className="container">
          <nav aria-label="Mobile Navigation">
            <ul className={styles.mobileNavList}>
              {navItems.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    end={item.path === '/'}
                    className={styles.mobileNavLink}
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
          <Link to="/kontakt" className={`${styles.mobileCTA} btn`}>
            Projekt starten
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;