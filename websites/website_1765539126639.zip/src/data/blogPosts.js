const blogPosts = [
  {
    slug: 'adventure-in-dubrovnik',
    title: 'Sunrise Adventure on Dubrovnik’s Ancient Walls',
    date: 'April 3, 2024',
    author: 'Lana Marinović',
    readingTime: '6 min read',
    image:
      'https://images.unsplash.com/photo-1548588684-16aa99b8b4ff?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'How waking up before dawn rewarded us with golden views over the terracotta rooftops and secret cafés along Dubrovnik’s fortress walls.',
    tags: ['Coastal', 'Culture', 'Morning walks'],
    highlights: [
      'Climbed the walls before the crowds and watched the sun spill over Lokrum Island.',
      'Found a tiny coffee bar tucked inside a medieval tower.',
      'Ended the morning with oysters from a family-owned stall in the harbour.'
    ],
    content: [
      {
        type: 'paragraph',
        text: 'There is something quietly electrifying about hearing church bells echo over Dubrovnik while the streets are still waking up. We slipped through Pile Gate at 5:45 a.m., coffees in hand, and made for the entrance to the famous city walls. The marble stones still held the night’s chill, yet the Adriatic already glimmered with streaks of peach and rose.'
      },
      {
        type: 'paragraph',
        text: 'Once on the ramparts, the Old Town unfolded like a storybook. The red rooftops curved towards the sea, swallows darted across hidden courtyards, and there was not a cruise ship passenger in sight. We slowed at every bastion, reading the informational plaques and imagining merchants, sailors, and artisans trading news centuries ago.'
      },
      {
        type: 'heading',
        text: 'A moment at Buža Gate'
      },
      {
        type: 'paragraph',
        text: 'Halfway around, we took the side stairs down to Buža Gate. A sleepy cat guarded the entrance to a cliffside café, and a salty breeze wrapped around us. Locals know this spot for the diving platforms, but in early spring it was a serene vantage point for watching fishing boats trace the horizon.'
      },
      {
        type: 'quote',
        text: '“Dubrovnik rewards those who wander slowly—every alleway reveals a new layer of poetry.”'
      },
      {
        type: 'paragraph',
        text: 'We rounded off the morning with fresh oysters dredged moments before by the Kralj family, who have a small stall near the old fish market. Paired with a splash of local Malvasia wine, it was a simple, celebratory breakfast that tasted of the sea and sunshine.'
      }
    ]
  },
  {
    slug: 'plitvice-lakes-guide',
    title: 'Plitvice Lakes: A Gentle Guide to Croatia’s Emerald Cascades',
    date: 'March 19, 2024',
    author: 'Marko Ivanić',
    readingTime: '8 min read',
    image:
      'https://images.unsplash.com/photo-1505739777236-09b1cc17a065?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'From boardwalk etiquette to the best times for crystal-clear reflections, here’s how to savour Plitvice Lakes without rushing the magic.',
    tags: ['National Parks', 'Nature', 'Sustainable travel'],
    highlights: [
      'Misty sunrise along the Lower Lakes boardwalk.',
      'Electric-blue dragonflies dancing over the Skradinski Brook.',
      'Lunch of homemade štrukli at a farmhouse in Korana Village.'
    ],
    content: [
      {
        type: 'paragraph',
        text: 'Plitvice Lakes National Park is more than a bucket-list stop; it is a living tapestry of terraced lakes, moss-covered cascades, and wildlife corridors that shimmer between beech forests. Visiting with respect means starting before 8 a.m., carrying out everything you carry in, and letting the park set your pace.'
      },
      {
        type: 'heading',
        text: 'Choosing the right trail'
      },
      {
        type: 'paragraph',
        text: 'Trail K circles both the Upper and Lower lakes and can take up to six hours. We recommend beginning at Entrance 1 to catch Veliki Slap glowing in the morning light. The wooden boardwalks are narrow, so walk single file and pause at designated bays for photos to keep the flow gentle for everyone.'
      },
      {
        type: 'list',
        items: [
          'Wear shoes with good grip—mist from the falls can make the planks slippery.',
          'Bring a reusable bottle; there are several natural springs to refill.',
          'Pack layers even in summer as the forest shade can feel refreshingly cool.'
        ]
      },
      {
        type: 'paragraph',
        text: 'By midday, take the electric boat across Kozjak Lake and listen for the rustle of deer in the underbrush. Finish your visit with a stop in the nearby village of Korana, where locals welcome guests for rustic lunches and stories about life beside the park.'
      }
    ]
  },
  {
    slug: 'sailing-the-dalmatian-islands',
    title: 'Slow Sailing the Dalmatian Islands',
    date: 'February 27, 2024',
    author: 'Tea Radić',
    readingTime: '7 min read',
    image:
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'A week aboard a petite gulet weaving through Šolta, Vis, and Korčula, with evenings spent chasing sunset light and local stories.',
    tags: ['Islands', 'Sailing', 'Local experiences'],
    highlights: [
      'Learning to tie nautical knots with Captain Luka.',
      'Tasting Vis-grown Vugava wine under a sky full of stars.',
      'Cycling through Korčula’s olive groves at golden hour.'
    ],
    content: [
      {
        type: 'paragraph',
        text: 'Chartering a small gulet changed our relationship with the Adriatic. Instead of ticking off islands, we lingered. The crew sourced produce from each harbour, we swam before breakfast, and afternoons were left open for serendipity—perhaps a pottery lesson in Grohote or a storytelling circle in Komiža.'
      },
      {
        type: 'heading',
        text: 'Highlights from each island'
      },
      {
        type: 'paragraph',
        text: 'Šolta surprised us with honey farms and rosemary fields. On Vis, we kayaked into Stiniva Cove at dawn before the day boats arrived. Korčula wrapped the journey in medieval charm, where we followed the footsteps of local winemakers and sampled goat cheeses infused with herbs from the Pelješac Peninsula.'
      },
      {
        type: 'quote',
        text: '“The Adriatic teaches you patience; wind and tide set the schedule.”'
      },
      {
        type: 'paragraph',
        text: 'If you sail the Dalmatian coast, choose a skipper who values sustainability: refill water on shore, avoid single-use plastics, and support family-owned konobas that keep traditional recipes alive.'
      }
    ]
  },
  {
    slug: 'zagreb-food-trail',
    title: 'Zagreb’s Food Trail: Markets, Micro Roasters, and Midnight Burek',
    date: 'January 30, 2024',
    author: 'Ivana Kralj',
    readingTime: '5 min read',
    image:
      'https://images.unsplash.com/photo-1526481280695-3c469957fd87?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'A self-guided day of eating through Zagreb, from Dolac Market’s seasonal produce to intimate wine bars and bakeries that never sleep.',
    tags: ['City life', 'Food', 'Culture'],
    highlights: [
      'Early-morning štrukli at Dolac Market with vendors we now call friends.',
      'Sampling natural wines at a basement bar in Old Zagreb.',
      'Finishing with flaky burek at 1 a.m., straight from the oven.'
    ],
    content: [
      {
        type: 'paragraph',
        text: 'Zagreb’s culinary scene feels personal; chefs and artisans happily explain the origins of each ingredient. Begin at Dolac Market where farmers display sun-blushed tomatoes, hand-plaited garlic, and jars of forest honey. Stop at the tiny counter run by the Horvat sisters for a breakfast of creamy štrukli.'
      },
      {
        type: 'heading',
        text: 'Coffee, lunch, and late-night bites'
      },
      {
        type: 'paragraph',
        text: 'After a stroll down Tkalčićeva Street, head to Cogito Coffee for a flat white roasted in the back alley. Lunch might be at Heritage, a deli championing Croatian regional tapas. In the evening, the basements near Palmotićeva Street open their cellars for guided tastings of orange wines and craft gins.'
      },
      {
        type: 'paragraph',
        text: 'Round out the night at a traditional bakery, where trays of burek emerge every hour. We ordered one filled with spinach and cheese, walked to the Croatian National Theatre, and shared flaky bites while the city lights shimmered around us.'
      }
    ]
  }
];

export default blogPosts;