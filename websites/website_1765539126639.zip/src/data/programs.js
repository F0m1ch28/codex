const programs = [
  {
    id: 'adriatic-spark',
    name: 'Adriatic Spark Escape',
    location: 'Dubrovnik',
    region: 'Dalmatia',
    durationCategory: 'short',
    durationLabel: '4 days / 3 nights',
    interests: ['culture', 'relaxation', 'history'],
    description:
      'A long weekend immersed in Dubrovnik’s storied walls, secret coves, and slow-food taverns guided by local storytellers.',
    image:
      'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=900&q=80',
    highlights: [
      'Sunrise walk along the city walls with a heritage expert.',
      'Private sea-kayak to Lokrum Island with snorkel stop.',
      'Dine at a farm-to-table konoba in Konavle valley.'
    ]
  },
  {
    id: 'plitvice-and-beyond',
    name: 'Plitvice & Forest Whisper Retreat',
    location: 'Plitvice Lakes',
    region: 'Lika',
    durationCategory: 'medium',
    durationLabel: '6 days / 5 nights',
    interests: ['nature', 'photography', 'wellness'],
    description:
      'Forest bathing, guided photography walks, and visits to waterfall viewpoints round out this restorative stay near Plitvice.',
    image:
      'https://images.unsplash.com/photo-1505739777236-09b1cc17a065?auto=format&fit=crop&w=900&q=80',
    highlights: [
      'Sunrise access to Plitvice boardwalks before official opening hours.',
      'Cooking class focused on Lika potatoes and hearty stews.',
      'Cave exploration in Baraćeve špilje with conservationists.'
    ]
  },
  {
    id: 'dalmatian-sails',
    name: 'Dalmatian Isles Sailing Quest',
    location: 'Split',
    region: 'Central Dalmatia',
    durationCategory: 'long',
    durationLabel: '8 days / 7 nights',
    interests: ['adventure', 'islands', 'sailing'],
    description:
      'Set sail on a boutique gulet through Šolta, Vis, and Korčula with daily swims, wine tastings, and blue hour photography stops.',
    image:
      'https://images.unsplash.com/photo-1526481280695-3c469957fd87?auto=format&fit=crop&w=900&q=80',
    highlights: [
      'Hands-on sailing lesson with a seasoned skipper.',
      'Evening tasting of Vugava wines in a Vis island vineyard.',
      'Cycling excursion through Korčula’s olive groves.'
    ]
  },
  {
    id: 'istrian-flavours',
    name: 'Istrian Flavours & Hilltop Stories',
    location: 'Rovinj',
    region: 'Istria',
    durationCategory: 'medium',
    durationLabel: '5 days / 4 nights',
    interests: ['food', 'culture', 'relaxation'],
    description:
      'Truffle foraging, olive oil masterclasses, and hilltop towns create a delicious meander through Istria’s countryside.',
    image:
      'https://images.unsplash.com/photo-1549893079-842e4251d1c9?auto=format&fit=crop&w=900&q=80',
    highlights: [
      'Guided truffle hunt near Motovun forests.',
      'Hands-on pasta workshop featuring fuži and pljukanci.',
      'Sunset stroll along Rovinj’s colourful harbour.'
    ]
  },
  {
    id: 'zagreb-creative-pulse',
    name: 'Zagreb’s Creative Pulse',
    location: 'Zagreb',
    region: 'Zagorje',
    durationCategory: 'short',
    durationLabel: '3 days / 2 nights',
    interests: ['culture', 'art', 'food'],
    description:
      'An urban mini-break through Zagreb’s design studios, micro-roaster cafés, and underground music venues.',
    image:
      'https://images.unsplash.com/photo-1548588684-16aa99b8b4ff?auto=format&fit=crop&w=900&q=80',
    highlights: [
      'Private architecture walk with a local historian.',
      'Coffee cupping at a micro roastery near Britanski trg.',
      'Evening vinyl session in a hidden courtyard bar.'
    ]
  },
  {
    id: 'kornati-blue-horizons',
    name: 'Kornati Blue Horizons Expedition',
    location: 'Zadar',
    region: 'Northern Dalmatia',
    durationCategory: 'long',
    durationLabel: '9 days / 8 nights',
    interests: ['adventure', 'nature', 'photography'],
    description:
      'Navigate the maze of the Kornati archipelago, snorkel crystal-clear coves, and capture Milky Way skies with a guide.',
    image:
      'https://images.unsplash.com/photo-1500534314211-1bfe87a47b52?auto=format&fit=crop&w=900&q=80',
    highlights: [
      'Full-day yacht experience through Kornati National Park.',
      'Nighttime astrophotography workshop on Dugi Otok.',
      'Foraging with fishermen for sea herbs and mussels.'
    ]
  }
];

export default programs;