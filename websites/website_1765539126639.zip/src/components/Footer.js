import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Footer">
    <div className={`container ${styles.grid}`}>
      <div className={styles.brandCol}>
        <h2 className={styles.logo}>
          <span className={styles.logoAccent}>Travel</span>Heart
        </h2>
        <p className={styles.tagline}>
          A heartfelt guide to Croatia for travellers chasing authentic moments, luminous coastlines,
          and vibrant cultural encounters.
        </p>
        <div className={styles.socialLinks}>
          <a
            href="https://www.instagram.com/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="TravelHeart on Instagram"
          >
            IG
          </a>
          <a
            href="https://www.facebook.com/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="TravelHeart on Facebook"
          >
            FB
          </a>
          <a
            href="https://www.youtube.com/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="TravelHeart on YouTube"
          >
            YT
          </a>
        </div>
      </div>
      <div className={styles.column}>
        <h3>Explore</h3>
        <ul>
          <li><Link to="/guide">Travel Guide</Link></li>
          <li><Link to="/programs">Curated Programs</Link></li>
          <li><Link to="/tools">Planning Tools</Link></li>
          <li><Link to="/blog">Stories &amp; Blog</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Company</h3>
        <ul>
          <li><Link to="/about">About TravelHeart</Link></li>
          <li><Link to="/contact">Contact Us</Link></li>
          <li><Link to="/terms">Terms of Use</Link></li>
          <li><Link to="/privacy">Privacy Policy</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Stay Inspired</h3>
        <p>Join the TravelHeart community for thoughtful itineraries and insider Croatian tips.</p>
        <form className={styles.newsletter} aria-label="Subscribe for inspiration">
          <label htmlFor="newsletter-email" className="sr-only">
            Email address
          </label>
          <input
            id="newsletter-email"
            type="email"
            placeholder="Your email address"
            aria-required="false"
          />
          <button type="button">Keep me posted</button>
        </form>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>© {new Date().getFullYear()} TravelHeart. Crafted with love for Croatia&apos;s wanderers.</p>
    </div>
  </footer>
);

export default Footer;