import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedPreference = window.localStorage.getItem('travelheart-cookie-consent');
    if (!storedPreference) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('travelheart-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          TravelHeart uses cookies to enhance your browsing experience and to understand how our
          community explores Croatia. Read more in our{' '}
          <Link to="/cookie-policy">Cookie Policy</Link>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={acceptCookies}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;