import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import blogPosts from '../data/blogPosts';
import styles from './Blog.module.css';

const BlogPage = () => (
  <>
    <Helmet>
      <title>TravelHeart Blog | Stories from Across Croatia</title>
      <meta
        name="description"
        content="Read the TravelHeart blog for first-hand stories and weekly inspiration from Dubrovnik to Zagreb, including slow travel tips and local highlights."
      />
    </Helmet>
    <section className={`container ${styles.intro}`}>
      <h1>The TravelHeart journal</h1>
      <p>
        Fresh tales from Croatia every week—shared by locals, travellers, and our in-house team.
        Browse coastal escapades, foodie finds, and nature retreats to spark your next itinerary.
      </p>
    </section>
    <section className={`container ${styles.posts}`}>
      <div className={styles.postGrid}>
        {blogPosts.map((post) => (
          <article key={post.slug} className={styles.postCard}>
            <img src={post.image} alt={post.title} />
            <div className={styles.postBody}>
              <span className={styles.meta}>
                {post.date} · {post.readingTime}
              </span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <div className={styles.tagList}>
                {post.tags.map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
              <Link to={`/blog/${post.slug}`} className={styles.readMore}>
                Read more →
              </Link>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default BlogPage;