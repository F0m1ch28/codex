import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import blogPosts from '../data/blogPosts';
import styles from './BlogPost.module.css';

const renderContent = (content) =>
  content.map((block, index) => {
    if (block.type === 'paragraph') {
      return (
        <p key={index}>
          {block.text}
        </p>
      );
    }
    if (block.type === 'heading') {
      return (
        <h2 key={index}>
          {block.text}
        </h2>
      );
    }
    if (block.type === 'quote') {
      return (
        <blockquote key={index}>
          {block.text}
        </blockquote>
      );
    }
    if (block.type === 'list') {
      return (
        <ul key={index}>
          {block.items.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      );
    }
    return null;
  });

const BlogPostPage = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className={`container ${styles.notFound}`}>
        <h1>Story not found</h1>
        <p>
          The article you&apos;re looking for may have sailed elsewhere. Discover new narratives in
          our <Link to="/blog">blog</Link>.
        </p>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | TravelHeart Journal</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>
      <article className={styles.article}>
        <header className={styles.hero}>
          <img src={post.image} alt={post.title} />
          <div className={`container ${styles.heroContent}`}>
            <span className={styles.meta}>
              {post.date} · {post.readingTime} · by {post.author}
            </span>
            <h1>{post.title}</h1>
            <div className={styles.tags}>
              {post.tags.map((tag) => (
                <span key={tag}>{tag}</span>
              ))}
            </div>
          </div>
        </header>
        <section className={`container ${styles.body}`}>
          {renderContent(post.content)}
          <section className={styles.highlights}>
            <h2>Highlights from this journey</h2>
            <ul>
              {post.highlights.map((highlight) => (
                <li key={highlight}>{highlight}</li>
              ))}
            </ul>
          </section>
          <footer className={styles.footer}>
            <Link to="/blog" className={styles.backLink}>
              ← Back to all stories
            </Link>
          </footer>
        </section>
      </article>
    </>
  );
};

export default BlogPostPage;