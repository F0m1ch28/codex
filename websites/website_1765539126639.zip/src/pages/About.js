import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const values = [
  {
    title: 'Local-first storytelling',
    description:
      'We partner with guides, hosts, and creatives who live in the destinations you visit. Their voices shape every itinerary.'
  },
  {
    title: 'Mindful pacing',
    description:
      'TravelHeart celebrates slow travel. We design journeys with breathing room, honouring both travellers and local communities.'
  },
  {
    title: 'Sustainable impact',
    description:
      'From plastic-free amenities to heritage conservation, we are committed to supporting projects that protect Croatia’s environments.'
  }
];

const teamMembers = [
  {
    name: 'Ana Horvat',
    role: 'Founder & Chief Experience Curator',
    bio: 'Born in Zagreb, Ana spent a decade guiding travellers along the Dalmatian coast. She now leads TravelHeart’s strategy and partnerships.',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=800&q=80'
  },
  {
    name: 'Nikola Radić',
    role: 'Head of Local Partnerships',
    bio: 'Nikola connects farms, skippers, and artisans with TravelHeart’s community to keep itineraries grounded in local expertise.',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=80'
  },
  {
    name: 'Ivana Kralj',
    role: 'Content & Cultural Insight Lead',
    bio: 'A journalist turned travel writer, Ivana translates Croatian culture into warm stories, guides, and on-the-ground advice.',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=801&q=80'
  },
  {
    name: 'Luka Marin',
    role: 'Adventure Architect',
    bio: 'From hiking Velebit to kayaking Kornati, Luka tests every route for safety and enjoyment before it reaches our travellers.',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=802&q=80'
  }
];

const timeline = [
  {
    year: '2016',
    title: 'TravelHeart beginnings',
    description:
      'Ana started TravelHeart as a blog capturing curated weekends in Dubrovnik, Split, and Zagreb.'
  },
  {
    year: '2018',
    title: 'Community expansion',
    description:
      'We onboarded our first round of local storytellers and launched the signature guide series.'
  },
  {
    year: '2021',
    title: 'Sustainability charter',
    description:
      'TravelHeart introduced a sustainability charter, amplifying zero-waste stays and conservation tours.'
  },
  {
    year: '2023',
    title: 'Tools & programs',
    description:
      'We launched our Travel Tools suite and curated programs to help travellers personalise every detail.'
  }
];

const AboutPage = () => (
  <>
    <Helmet>
      <title>About TravelHeart | Meet the Team Behind the Guides</title>
      <meta
        name="description"
        content="Learn about TravelHeart’s mission to make Croatian travel unforgettable through local expertise, sustainable partnerships, and heartfelt storytelling."
      />
    </Helmet>
    <section className={`container ${styles.intro}`}>
      <h1>We help travellers feel Croatia with all their senses</h1>
      <p>
        TravelHeart is a collective of Croatian explorers, storytellers, and travel designers.
        Together we craft guides, programs, and tools that honour the rhythm of the Adriatic, the
        warmth of local hospitality, and the joy of mindful discovery.
      </p>
    </section>

    <section className={`container ${styles.valuesSection}`}>
      <h2>What TravelHeart stands for</h2>
      <div className={styles.valuesGrid}>
        {values.map((value) => (
          <article key={value.title} className={styles.valueCard}>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <header className={styles.teamHeader}>
          <h2>Meet the team</h2>
          <p>
            We are guides, writers, photographers, and planners. Hover over each profile to discover
            the journeys we cherish most.
          </p>
        </header>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.imageWrapper}>
                <img src={member.image} alt={member.name} />
              </div>
              <div className={styles.info}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`container ${styles.timelineSection}`}>
      <h2>Our journey so far</h2>
      <div className={styles.timeline}>
        {timeline.map((milestone) => (
          <div key={milestone.year} className={styles.milestone}>
            <div className={styles.year}>{milestone.year}</div>
            <div className={styles.details}>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>

    <section className={styles.missionCta}>
      <div className="container">
        <div className={styles.missionCard}>
          <h2>Our mission</h2>
          <p>
            To make exploring Croatia unforgettable for every traveller—through mindful planning,
            authentic experiences, and partnerships that keep communities thriving.
          </p>
          <a href="/contact">Collaborate with us</a>
        </div>
      </div>
    </section>
  </>
);

export default AboutPage;