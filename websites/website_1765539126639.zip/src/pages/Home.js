import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import programs from '../data/programs';
import blogPosts from '../data/blogPosts';
import styles from './Home.module.css';

const statsData = [
  { label: 'Curated Croatian moments', value: 128 },
  { label: 'Local storytellers in our network', value: 47 },
  { label: 'Travellers guided last season', value: 863 }
];

const locations = [
  {
    name: 'Dubrovnik',
    description: 'Walk ancient ramparts, swim hidden coves, and dine in lantern-lit piazzas.',
    image:
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Split',
    description: 'Live inside a Roman palace, hop to islands, and taste olive oils with masters.',
    image:
      'https://images.unsplash.com/photo-1504898770365-14bdf57de1ed?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Plitvice Lakes',
    description: 'Trace wooden boardwalks over emerald water and hear the waterfalls whisper.',
    image:
      'https://images.unsplash.com/photo-1505739617631-23e1226e6c57?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Zadar',
    description: 'Watch the sun play a melody, explore Roman ruins, and sail to island jewels.',
    image:
      'https://images.unsplash.com/photo-1526481280695-3c469957fd87?auto=format&fit=crop&w=1200&q=80'
  }
];

const guideHighlights = [
  {
    title: 'Sustainable seaside escapes',
    description:
      'A blueprint for balancing adventure and preservation along Croatia’s coastline, from ferry tips to eco-certified stays.',
    link: '/guide',
    icon: '🌊'
  },
  {
    title: 'Croatian cuisine decoded',
    description:
      'Understand regional dishes, market etiquette, and the stories behind family-run konobas before you sit down to feast.',
    link: '/guide',
    icon: '🥘'
  },
  {
    title: 'Smart island hopping',
    description:
      'Our island transfer matrix details ferry routes, local skippers, and what to pack for breezy days at sea.',
    link: '/guide',
    icon: '⛵'
  },
  {
    title: 'Cultural etiquette essentials',
    description:
      'From coffee customs to festival etiquette, gain the confidence to blend in and connect with locals.',
    link: '/guide',
    icon: '🤝'
  }
];

const journeyIdeas = [
  {
    id: 'coastal-classics',
    category: 'Coast',
    name: 'Coastal Classics',
    image:
      'https://images.unsplash.com/photo-1500534314211-1bfe87a47b52?auto=format&fit=crop&w=900&q=80',
    blurb: 'A relaxed sweep from Dubrovnik to Šibenik with sunset wine pairings.',
    link: '/programs'
  },
  {
    id: 'island-improv',
    category: 'Islands',
    name: 'Island Improv Sessions',
    image:
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80',
    blurb: 'Choose your breeze: Vis, Šolta, or Korčula with flexible sailing windows.',
    link: '/programs'
  },
  {
    id: 'highland-hush',
    category: 'Inland',
    name: 'Highland Hush Retreat',
    image:
      'https://images.unsplash.com/photo-1505739777236-09b1cc17a065?auto=format&fit=crop&w=900&q=80',
    blurb: 'Plitvice dawn hikes and Lika comfort food around farmhouse tables.',
    link: '/programs'
  },
  {
    id: 'istrian-art',
    category: 'Inland',
    name: 'Istrian Art & Aroma',
    image:
      'https://images.unsplash.com/photo-1549893079-842e4251d1c9?auto=format&fit=crop&w=900&q=80',
    blurb: 'Hilltop galleries, truffle hunts, and olive oil ateliers.',
    link: '/programs'
  },
  {
    id: 'sailing-stars',
    category: 'Islands',
    name: 'Sailing Under the Stars',
    image:
      'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=900&q=80',
    blurb: 'Kornati’s nocturnal skies paired with fresh-caught dinners.',
    link: '/programs'
  }
];

const testimonials = [
  {
    name: 'Elena & Mateo',
    location: 'Buenos Aires',
    quote:
      'TravelHeart transformed our honeymoon into a tapestry of small surprises—handwritten notes at boutique stays and sunset picnics on secluded beaches.',
    journey: 'Dalmatian Isles Sailing Quest'
  },
  {
    name: 'Priya S.',
    location: 'London',
    quote:
      'Every tip from the TravelHeart guidebook rang true—from ferry hacks to the best midnight burek. Croatia felt like an old friend welcoming me back.',
    journey: 'Zagreb’s Creative Pulse'
  },
  {
    name: 'Nguyen Family',
    location: 'Singapore',
    quote:
      'The team curated gentle hikes, stroller-friendly boardwalks, and farm visits that kept our kids curious. We left Croatia rested and inspired.',
    journey: 'Plitvice & Forest Whisper Retreat'
  }
];

const faqItems = [
  {
    question: 'When is the best time to explore Croatia with fewer crowds?',
    answer:
      'Shoulder seasons—late April to early June and mid-September to October—offer warm seas, open attractions, and quieter streets. TravelHeart programs highlight these windows and adjust itineraries for seasonal highlights.'
  },
  {
    question: 'Can TravelHeart tailor programs for dietary preferences?',
    answer:
      'Absolutely. We collaborate with chefs and hosts across Croatia who celebrate local ingredients while catering to vegetarian, vegan, or gluten-free travellers. Share your needs in the contact form, and we will adapt meals without losing flavour.'
  },
  {
    question: 'Do I need a car to follow your guides?',
    answer:
      'Not necessarily. Our transport section breaks down ferry schedules, train routes, ride-sharing apps, and trusted drivers. Many itineraries can be enjoyed using public transport combined with local transfers.'
  }
];

const processSteps = [
  {
    title: 'Dream & Discover',
    description:
      'Browse TravelHeart guides and moodboard your ideal Croatian escape with our inspiration library.'
  },
  {
    title: 'Shape Your Route',
    description:
      'Pick a curated program or mix elements; use our tools to align travel days, ferry times, and experiences.'
  },
  {
    title: 'Fine-tune with Experts',
    description:
      'Chat with our local specialists, book trusted hosts, and receive a personalised TravelHeart field guide.'
  }
];

const HomePage = () => {
  const [displayedStats, setDisplayedStats] = useState(statsData.map(() => 0));
  const [activeCategory, setActiveCategory] = useState('All');
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    const animationDuration = 1600;
    const startTime = performance.now();
    const animate = (time) => {
      const progress = Math.min((time - startTime) / animationDuration, 1);
      setDisplayedStats(
        statsData.map((stat) => Math.floor(stat.value * progress))
      );
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  const filteredJourneyIdeas = useMemo(() => {
    if (activeCategory === 'All') {
      return journeyIdeas;
    }
    return journeyIdeas.filter((idea) => idea.category === activeCategory);
  }, [activeCategory]);

  const featuredPrograms = useMemo(() => programs.slice(0, 3), []);
  const blogPreview = useMemo(() => blogPosts.slice(0, 3), []);

  return (
    <>
      <Helmet>
        <title>TravelHeart | Your Croatia Travel Companion</title>
        <meta
          name="description"
          content="Plan your Croatia adventure with TravelHeart’s curated guides, programs, and tools covering coastal escapes, national parks, and cultural treasures."
        />
      </Helmet>
      <section
        className={styles.hero}
        style={{
          backgroundImage:
            'url("https://images.unsplash.com/photo-1548588684-16aa99b8b4ff?auto=format&fit=crop&w=1800&q=80")'
        }}
      >
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <p className={styles.tagline}>Croatia, curated with heart</p>
            <h1>
              Discover islands, cities, and secret trails with locals who know every corner.
            </h1>
            <p className={styles.heroDescription}>
              TravelHeart is your companion for planning soulful journeys across Croatia.
              Explore immersive guides, hand-picked programs, and intuitive tools designed for
              curious travellers.
            </p>
            <form
              className={styles.searchForm}
              aria-label="Search destinations"
              onSubmit={(event) => event.preventDefault()}
            >
              <label htmlFor="destination-search" className="sr-only">
                Search destination
              </label>
              <input
                id="destination-search"
                type="search"
                placeholder="Where would you love to go next?"
              />
              <Link to="/guide" className={styles.searchButton}>
                Start exploring
              </Link>
            </form>
            <div className={styles.heroActions}>
              <Link to="/programs" className={styles.primaryAction}>
                View curated programs
              </Link>
              <Link to="/tools" className={styles.secondaryAction}>
                Use travel tools
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={`container ${styles.statsSection}`}>
        {statsData.map((stat, index) => (
          <article key={stat.label} className={styles.statCard}>
            <h2>{displayedStats[index]}+</h2>
            <p>{stat.label}</p>
          </article>
        ))}
      </section>

      <section className={`container ${styles.locationsSection}`}>
        <header className={styles.sectionHeader}>
          <h2>Featured Croatian locations</h2>
          <p>
            Whether you crave UNESCO-listed alleys, turquoise waterfalls, or acoustic sunsets,
            these destinations are ready to welcome you.
          </p>
        </header>
        <div className={styles.locationGrid}>
          {locations.map((location) => (
            <article key={location.name} className={styles.locationCard}>
              <img src={location.image} alt={`${location.name} landscape`} />
              <div className={styles.locationContent}>
                <h3>{location.name}</h3>
                <p>{location.description}</p>
                <Link to="/guide" aria-label={`See travel guide for ${location.name}`}>
                  Deep dive →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.guidesSection}`}>
        <header className={styles.sectionHeader}>
          <h2>Popular TravelHeart guides</h2>
          <p>
            Crafted by locals and seasoned explorers, our guides unpack logistics, etiquette, and
            unforgettable experiences.
          </p>
        </header>
        <div className={styles.guideGrid}>
          {guideHighlights.map((guide) => (
            <article key={guide.title} className={styles.guideCard}>
              <span className={styles.icon} role="img" aria-label="Guide icon">
                {guide.icon}
              </span>
              <h3>{guide.title}</h3>
              <p>{guide.description}</p>
              <Link to={guide.link}>Read the guide</Link>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.programsSection}`}>
        <header className={styles.sectionHeader}>
          <h2>Signature programs</h2>
          <p>
            Gathered from our wider collection, these itineraries capture Croatia’s coastal glow,
            forest calm, and city spark—all adaptable to your rhythm.
          </p>
        </header>
        <div className={styles.programGrid}>
          {featuredPrograms.map((program) => (
            <article key={program.id} className={styles.programCard}>
              <img src={program.image} alt={`${program.name} illustration`} />
              <div className={styles.programContent}>
                <span className={styles.programTag}>{program.durationLabel}</span>
                <h3>{program.name}</h3>
                <p>{program.description}</p>
                <ul>
                  {program.highlights.slice(0, 2).map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
                <Link to="/programs" className={styles.programLink}>
                  View program details
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.processSection}`}>
        <div className={styles.processIntro}>
          <h2>How TravelHeart helps you craft the perfect Croatian story</h2>
          <p>
            We pair insightful planning with warm human touch. Our three-step flow keeps your trip
            flexible, meaningful, and grounded in local knowledge.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.title} className={styles.processCard}>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.journeySection}`}>
        <header className={styles.sectionHeader}>
          <h2>Journey ideas to spark your imagination</h2>
        </header>
        <div className={styles.filterGroup} role="tablist" aria-label="Journey categories">
          {['All', 'Coast', 'Islands', 'Inland'].map((category) => (
            <button
              key={category}
              type="button"
              role="tab"
              aria-selected={activeCategory === category}
              className={`${styles.filterButton} ${
                activeCategory === category ? styles.filterActive : ''
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.journeyGrid}>
          {filteredJourneyIdeas.map((idea) => (
            <article key={idea.id} className={styles.journeyCard}>
              <img src={idea.image} alt={`${idea.name} teaser`} />
              <div className={styles.journeyContent}>
                <span className={styles.categoryBadge}>{idea.category}</span>
                <h3>{idea.name}</h3>
                <p>{idea.blurb}</p>
                <Link to={idea.link}>See how to plan it</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.toolsSection}`}>
        <div className={styles.toolsIntro}>
          <h2>Planning tools at your fingertips</h2>
          <p>
            Weather snapshots, currency insights, and Croatian phrases are only a tap away.
            Preview highlights below, then explore the full toolkit.
          </p>
          <Link to="/tools">Open the toolbox</Link>
        </div>
        <div className={styles.toolsGrid}>
          <article>
            <h3>Weather watchlist</h3>
            <p>
              Compare Dubrovnik, Split, and Zagreb forecasts in one glance to pack smartly for your
              route.
            </p>
          </article>
          <article>
            <h3>Currency cheat sheet</h3>
            <p>
              Euro to Kuna history, local pricing norms, and quick conversions keep spending clear
              and confident.
            </p>
          </article>
          <article>
            <h3>Phrase pocket guide</h3>
            <p>
              Simple Croatian phrases with phonetic help so you can order kava or thank your hosts
              like a local.
            </p>
          </article>
        </div>
      </section>

      <section className={`container ${styles.testimonialSection}`}>
        <div className={styles.testimonialContent}>
          <header>
            <h2>Travellers who trusted TravelHeart</h2>
            <p>
              Our community shares honest reflections after exploring Croatia with our guidance.
              Every story helps shape future adventures.
            </p>
          </header>
          <div className={styles.testimonialSlider}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === testimonialIndex ? styles.testimonialActive : ''
                }`}
              >
                <p className={styles.quoteMark}>“</p>
                <p className={styles.quote}>{testimonial.quote}</p>
                <div className={styles.author}>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.location}</span>
                  <em>{testimonial.journey}</em>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.indicators}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                aria-label={`Show testimonial ${index + 1}`}
                className={`${styles.indicator} ${
                  index === testimonialIndex ? styles.indicatorActive : ''
                }`}
                onClick={() => setTestimonialIndex(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`container ${styles.blogSection}`}>
        <header className={styles.sectionHeader}>
          <h2>Latest from the TravelHeart journal</h2>
          <p>
            Fresh stories written by our community and team, highlighting corners of Croatia you
            might not have met yet.
          </p>
        </header>
        <div className={styles.blogGrid}>
          {blogPreview.map((post) => (
            <article key={post.slug} className={styles.blogCard}>
              <img src={post.image} alt={post.title} />
              <div className={styles.blogContent}>
                <span className={styles.blogMeta}>
                  {post.date} · {post.readingTime}
                </span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`}>Read the story</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.faqSection}`}>
        <header className={styles.sectionHeader}>
          <h2>Questions from fellow travellers</h2>
        </header>
        <div className={styles.faqList}>
          {faqItems.map((item) => (
            <details key={item.question}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Ready to open the heart of Croatia?</h2>
            <p>
              Dive into our detailed guides or customise a program with a TravelHeart specialist.
              Let’s design a journey that feels like you.
            </p>
            <div className={styles.ctaButtons}>
              <Link to="/guide" className={styles.ctaPrimary}>
                Explore Guides
              </Link>
              <Link to="/programs" className={styles.ctaSecondary}>
                Curate my program
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;