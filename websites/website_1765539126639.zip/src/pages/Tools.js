import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const weatherSnapshot = [
  { city: 'Dubrovnik', conditions: 'Sunny', temperature: '24°C', tip: 'Perfect for kayaking' },
  { city: 'Split', conditions: 'Partly cloudy', temperature: '22°C', tip: 'Pack a light layer' },
  { city: 'Zagreb', conditions: 'Mild rain', temperature: '18°C', tip: 'Bring a compact umbrella' }
];

const exchangeRates = [
  { currency: 'USD', rate: '1 EUR ≈ 1.08 USD', note: 'Cards widely accepted in Croatia' },
  { currency: 'GBP', rate: '1 EUR ≈ 0.86 GBP', note: 'Withdraw Euros to avoid dynamic conversion' },
  { currency: 'AUD', rate: '1 EUR ≈ 1.65 AUD', note: 'Consider a travel card with fee-free withdrawals' }
];

const phrases = [
  { croatian: 'Dobar dan', pronunciation: 'DOH-bar dahn', english: 'Good day / hello' },
  { croatian: 'Hvala', pronunciation: 'HVAAH-lah', english: 'Thank you' },
  { croatian: 'Molim', pronunciation: 'MOH-leem', english: 'Please / you are welcome' },
  { croatian: 'Gdje je trajekt?', pronunciation: 'GDYEH yeh TRAH-yekt', english: 'Where is the ferry?' },
  { croatian: 'Kava za ponijeti', pronunciation: 'KAH-vah zah POH-nyet-ee', english: 'Coffee to go' }
];

const ToolsPage = () => (
  <>
    <Helmet>
      <title>TravelHeart Tools | Plan Your Croatia Trip with Confidence</title>
      <meta
        name="description"
        content="Use TravelHeart’s Croatia travel tools—weather snapshots, exchange rate cheat sheets, and essential Croatian phrases—for smooth planning."
      />
    </Helmet>
    <section className={`container ${styles.intro}`}>
      <span className={styles.kicker}>Travel tools</span>
      <h1>Practical tools to keep your Croatian adventure flowing</h1>
      <p>
        These quick-glance resources simplify decisions on the go. Check today’s weather across
        major hubs, convert currency with ease, and pick up phrases that bring warm smiles.
      </p>
    </section>

    <section className={`container ${styles.weatherSection}`}>
      <h2>Weather snapshot</h2>
      <p>
        Croatia’s regions can differ dramatically. Here&apos;s a sample forecast to help you pack.
        For live data, use our suggested apps once you arrive.
      </p>
      <div className={styles.weatherGrid}>
        {weatherSnapshot.map((item) => (
          <article key={item.city} className={styles.weatherCard}>
            <h3>{item.city}</h3>
            <p className={styles.conditions}>{item.conditions}</p>
            <p className={styles.temperature}>{item.temperature}</p>
            <p className={styles.tip}>{item.tip}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.exchangeSection}>
      <div className="container">
        <h2>Currency cheat sheet</h2>
        <p>
          Croatia uses the Euro. Prices in markets or smaller cafés may favour cash, but cards are
          widely accepted. Always choose to be charged in Euros rather than your home currency.
        </p>
        <div className={styles.tableWrapper} role="table" aria-label="Exchange rate overview">
          <div className={styles.tableHeader} role="row">
            <span role="columnheader">Currency</span>
            <span role="columnheader">Approximate rate</span>
            <span role="columnheader">Travel note</span>
          </div>
          {exchangeRates.map((rate) => (
            <div className={styles.tableRow} role="row" key={rate.currency}>
              <span role="cell">{rate.currency}</span>
              <span role="cell">{rate.rate}</span>
              <span role="cell">{rate.note}</span>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={`container ${styles.phrasesSection}`}>
      <h2>Essential Croatian phrases</h2>
      <p>
        A few heartfelt words go a long way. Use this mini phrasebook to connect with baristas,
        ferry staff, and hosts with confidence.
      </p>
      <div className={styles.phrasesGrid}>
        {phrases.map((phrase) => (
          <article key={phrase.croatian} className={styles.phraseCard}>
            <h3>{phrase.croatian}</h3>
            <p className={styles.pronunciation}>{phrase.pronunciation}</p>
            <p className={styles.translation}>{phrase.english}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.downloads}>
      <div className="container">
        <div className={styles.downloadCard}>
          <h2>Prepare like a local</h2>
          <p>
            Access our recommended apps for ferry schedules, offline maps, and real-time cultural
            calendars. Download the TravelHeart travel kit before you depart.
          </p>
          <div className={styles.downloadButtons}>
            <a href="#download-guide" className={styles.primary}>
              Download kit
            </a>
            <a href="/contact" className={styles.secondary}>
              Request custom tips
            </a>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default ToolsPage;