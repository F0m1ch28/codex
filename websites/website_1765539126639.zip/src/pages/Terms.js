import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

const TermsPage = () => (
  <>
    <Helmet>
      <title>TravelHeart Terms of Use</title>
      <meta
        name="description"
        content="Review the TravelHeart Terms of Use to understand how to use our Croatia travel guides, programs, and online resources responsibly."
      />
    </Helmet>
    <article className={`container ${styles.article}`}>
      <h1>Terms of Use</h1>
      <p className={styles.updated}>Updated: March 2024</p>
      <p>
        Welcome to TravelHeart. These Terms of Use govern access to our website, guides, curated
        programs, and tools (collectively, the “Services”). By using TravelHeart you agree to the
        terms below. If you do not agree, please refrain from using the Services.
      </p>

      <h2>1. Purpose of our Services</h2>
      <p>
        TravelHeart provides travel inspiration, planning resources, and introductions to local
        partners across Croatia. We work diligently to keep information accurate and current,
        however availability, schedules, and regulations can change. Always confirm critical details
        directly with transport providers, accommodation hosts, and activity operators before you
        travel.
      </p>

      <h2>2. Responsible use</h2>
      <p>
        You agree to use TravelHeart for lawful purposes, respect intellectual property rights, and
        avoid copying large portions of content without permission. You may share snippets or links
        with attribution. Automated scraping, data mining, or using our content for competing travel
        products is prohibited.
      </p>

      <h2>3. Community contributions</h2>
      <p>
        From time to time we invite stories, photographs, or feedback from the TravelHeart
        community. By submitting content you confirm it is your original work and you grant
        TravelHeart a non-exclusive licence to display, edit, or remove it in connection with the
        Services. We may moderate submissions to keep the community respectful.
      </p>

      <h2>4. Third-party services</h2>
      <p>
        TravelHeart links to external websites and partners that operate independently. We are not
        responsible for their content, practices, or availability. When you book with a partner,
        their terms and privacy policies will apply. Always review them before confirming a
        reservation.
      </p>

      <h2>5. Limitation of liability</h2>
      <p>
        TravelHeart is provided “as is”. We do not guarantee uninterrupted access or error-free
        content. To the extent permitted by law, TravelHeart and its team are not liable for
        indirect or consequential losses arising from the use of our Services. Travellers remain
        responsible for arranging suitable insurance and complying with local regulations.
      </p>

      <h2>6. Updates to these terms</h2>
      <p>
        We may revise these Terms of Use as our Services evolve. When we make significant changes,
        we will update the date at the top of this page. Continued use of TravelHeart after changes
        constitutes acceptance of the new terms.
      </p>

      <h2>7. Contact</h2>
      <p>
        Questions about these terms? Reach out through our contact form and we will respond with the
        clarity you need before planning your adventure.
      </p>
    </article>
  </>
);

export default TermsPage;