import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

const CookiePolicyPage = () => (
  <>
    <Helmet>
      <title>TravelHeart Cookie Policy</title>
      <meta
        name="description"
        content="Learn how TravelHeart uses cookies to improve your browsing experience and how you can manage cookie preferences."
      />
    </Helmet>
    <article className={`container ${styles.article}`}>
      <h1>Cookie Policy</h1>
      <p className={styles.updated}>Updated: March 2024</p>
      <p>
        Cookies are small text files stored on your device. TravelHeart uses cookies to deliver a
        smooth experience, understand how visitors interact with our content, and remember your
        preferences.
      </p>

      <h2>1. Types of cookies we use</h2>
      <ul>
        <li>
          <strong>Essential cookies:</strong> Required for core functionality such as navigation and
          form submission. These cannot be disabled.
        </li>
        <li>
          <strong>Performance cookies:</strong> Help us measure website traffic and identify
          opportunities to improve usability. Data is aggregated and anonymised.
        </li>
        <li>
          <strong>Preference cookies:</strong> Remember choices like language or cookie consent so
          you do not have to set them again.
        </li>
      </ul>

      <h2>2. Managing cookies</h2>
      <p>
        When you first visit TravelHeart you can accept optional cookies or continue with essential
        cookies only. Most browsers also allow you to block or delete cookies via settings. Keep in
        mind that disabling cookies may affect site functionality.
      </p>

      <h2>3. Third-party cookies</h2>
      <p>
        Some third-party services (for example analytics tools) may set their own cookies. We only
        work with providers that uphold strong data protection standards.
      </p>

      <h2>4. Policy updates</h2>
      <p>
        We review this Cookie Policy periodically. Significant changes will be posted here together
        with the updated effective date.
      </p>
    </article>
  </>
);

export default CookiePolicyPage;