import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const guideCategories = [
  {
    id: 'transport',
    title: 'Getting around Croatia',
    description:
      'Navigate Croatia with confidence using our transport playbook covering ferries, scenic trains, buses, rentals, and mindful mobility.',
    icon: '🛶',
    insights: [
      'Ferries: Jadrolinija and Krilo timetables with insider booking windows and tips for travelling with luggage or bikes.',
      'Rail & bus: Scenic rail routes through Zagorje, premium bus lines, and sustainable alternatives for island excursions.',
      'Car hire: Advice on driving coastal roads, toll etiquette, and when to opt for a private transfer instead.'
    ]
  },
  {
    id: 'food',
    title: 'Food and drink culture',
    description:
      'From morning kava rituals to late-night burek, we celebrate the flavours that define each Croatian region.',
    icon: '🍇',
    insights: [
      'Markets: How to greet vendors, what produce is seasonal, and why haggling is rarely appropriate.',
      'Dining: Understanding daily menus (marenda), tipping customs, and discovering family-run konobas.',
      'Wines & spirits: Key varietals like Plavac Mali and Malvazija plus rakija traditions and respectful tasting.'
    ]
  },
  {
    id: 'culture',
    title: 'Culture and etiquette',
    description:
      'Feel welcomed wherever you go with cultural context—from festival etiquette to respectful photography.',
    icon: '🎭',
    insights: [
      'Greetings: When to use “Bog!” or “Dobar dan” and how to introduce yourself in small communities.',
      'Festivals: What to expect at klapa concerts, folk nights, and open-air cinema events in the summer.',
      'Responsible travel: Support heritage sites, understand dress codes for sacred spaces, and follow Leave No Trace.'
    ]
  },
  {
    id: 'outdoors',
    title: 'Outdoor adventures',
    description:
      'Chase waterfalls, summit peaks, and paddle coastlines safely with guidance from local adventure leaders.',
    icon: '🏞️',
    insights: [
      'National parks: Entry windows, crowd-free routes, and why booking a licensed guide elevates the experience.',
      'Hiking: Marked trail systems, apps to download, and gear checklists for Velebit, Biokovo, and Učka mountains.',
      'Sea experiences: Kayak safety, snorkel-friendly coves, and reef etiquette for preserving marine life.'
    ]
  }
];

const practicalTips = [
  {
    title: 'Money & connectivity',
    detail:
      'Croatia uses the Euro. ATMs are common, and digital wallets are widely accepted. eSIMs and pocket Wi-Fi devices work well across the islands.'
  },
  {
    title: 'Language essentials',
    detail:
      'Croatian is the official language, with English widely spoken in tourist areas. Learning phrases such as “Hvala” (thank you) and “Molim” (please/you’re welcome) opens doors.'
  },
  {
    title: 'Staying respectful outdoors',
    detail:
      'Stick to marked trails, carry out waste, and refill water bottles at springs to reduce plastic. Many parks have refill stations—bring a reusable bottle.'
  },
  {
    title: 'Booking windows',
    detail:
      'Reserve ferries, heritage hotels, and national park entries early for June–September. Shoulder seasons grant flexibility, yet boutique stays still book quickly.'
  }
];

const GuidePage = () => (
  <>
    <Helmet>
      <title>TravelHeart Guides | Plan Your Croatia Adventure</title>
      <meta
        name="description"
        content="Deep-dive into Croatia with TravelHeart’s guides covering transport, food culture, etiquette, and outdoor adventures."
      />
    </Helmet>
    <section className={`container ${styles.intro}`}>
      <span className={styles.kicker}>Travel guide</span>
      <h1>All the wisdom you need to feel at home in Croatia</h1>
      <p>
        TravelHeart’s guide compendium blends local knowledge with practical strategies for moving
        around Croatia effortlessly. Use it as your compass while curating personalised journeys.
      </p>
    </section>

    <section className={`container ${styles.categorySection}`}>
      <div className={styles.categoryGrid}>
        {guideCategories.map((category) => (
          <article key={category.id} className={styles.categoryCard}>
            <span className={styles.icon} role="img" aria-label={`${category.title} icon`}>
              {category.icon}
            </span>
            <h2>{category.title}</h2>
            <p>{category.description}</p>
            <ul>
              {category.insights.map((insight) => (
                <li key={insight}>{insight}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.feature}>
      <div className="container">
        <div className={styles.featureCard}>
          <div className={styles.featureContent}>
            <h2>Multi-day sample itineraries</h2>
            <p>
              Mix and match daily routes curated for coastlines, national parks, and city breaks.
              TravelHeart itineraries include transit timings, scenic stops, and dining suggestions
              that celebrate local producers.
            </p>
            <ul>
              <li>7-day Dalmatian island loop with flexible sailing segments.</li>
              <li>5-day wellness retreat combining Plitvice Lakes and Šibenik hinterland.</li>
              <li>3-day Zagreb city immersion with creative workshops and market strolls.</li>
            </ul>
          </div>
          <div className={styles.featureImageWrapper}>
            <img
              src="https://images.unsplash.com/photo-1500534314211-1bfe87a47b52?auto=format&fit=crop&w=1200&q=80"
              alt="Sailing boat along Croatia coastline"
            />
          </div>
        </div>
      </div>
    </section>

    <section className={`container ${styles.tipsSection}`}>
      <h2>Quick-glance essentials</h2>
      <div className={styles.tipsGrid}>
        {practicalTips.map((tip) => (
          <article key={tip.title} className={styles.tipCard}>
            <h3>{tip.title}</h3>
            <p>{tip.detail}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.planCta}>
      <div className="container">
        <div className={styles.planCard}>
          <h2>Need a hand tailoring your Croatia route?</h2>
          <p>
            Share your wishlist and we&apos;ll align ferry schedules, boutique stays, and cultural
            experiences for a balanced itinerary.
          </p>
          <div className={styles.planActions}>
            <a href="#contact-guides" className={styles.primary}>
              Request a planning call
            </a>
            <a href="/programs" className={styles.secondary}>
              Browse curated programs
            </a>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default GuidePage;