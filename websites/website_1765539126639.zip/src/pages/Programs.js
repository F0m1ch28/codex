import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import programs from '../data/programs';
import styles from './Programs.module.css';

const ProgramsPage = () => {
  const [selectedLocation, setSelectedLocation] = useState('All');
  const [selectedDuration, setSelectedDuration] = useState('all');
  const [selectedInterest, setSelectedInterest] = useState('All');

  const locationOptions = useMemo(
    () => ['All', ...new Set(programs.map((program) => program.location))],
    []
  );
  const interestOptions = useMemo(
    () => ['All', ...new Set(programs.flatMap((program) => program.interests))],
    []
  );

  const filteredPrograms = useMemo(
    () =>
      programs.filter((program) => {
        const matchesLocation =
          selectedLocation === 'All' || program.location === selectedLocation;
        const matchesDuration =
          selectedDuration === 'all' || program.durationCategory === selectedDuration;
        const matchesInterest =
          selectedInterest === 'All' || program.interests.includes(selectedInterest);
        return matchesLocation && matchesDuration && matchesInterest;
      }),
    [selectedLocation, selectedDuration, selectedInterest]
  );

  return (
    <>
      <Helmet>
        <title>TravelHeart Programs | Curated Journeys Across Croatia</title>
        <meta
          name="description"
          content="Browse TravelHeart’s curated Croatia programs filtered by location, duration, and interests. Find coastal escapes, nature retreats, and cultural adventures."
        />
      </Helmet>

      <section className={`container ${styles.hero}`}>
        <h1>Curated Croatia programs to match every travel rhythm</h1>
        <p>
          Each TravelHeart program is crafted with local specialists. Filter by destination,
          duration, and interest to discover experiences that reflect your style. Prices are kept
          offline so we can personalise every quote.
        </p>
      </section>

      <section className={`container ${styles.filters}`}>
        <div className={styles.filterGroup}>
          <label htmlFor="location-filter">Location</label>
          <select
            id="location-filter"
            value={selectedLocation}
            onChange={(event) => setSelectedLocation(event.target.value)}
          >
            {locationOptions.map((location) => (
              <option value={location} key={location}>
                {location}
              </option>
            ))}
          </select>
        </div>

        <div className={styles.filterGroup}>
          <label htmlFor="duration-filter">Duration</label>
          <select
            id="duration-filter"
            value={selectedDuration}
            onChange={(event) => setSelectedDuration(event.target.value)}
          >
            <option value="all">Any duration</option>
            <option value="short">Short (up to 4 nights)</option>
            <option value="medium">Medium (5 – 7 nights)</option>
            <option value="long">Long (8+ nights)</option>
          </select>
        </div>

        <div className={styles.filterGroup}>
          <label htmlFor="interest-filter">Interests</label>
          <select
            id="interest-filter"
            value={selectedInterest}
            onChange={(event) => setSelectedInterest(event.target.value)}
          >
            {interestOptions.map((interest) => (
              <option value={interest} key={interest}>
                {interest.charAt(0).toUpperCase() + interest.slice(1)}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          className={styles.resetButton}
          onClick={() => {
            setSelectedLocation('All');
            setSelectedDuration('all');
            setSelectedInterest('All');
          }}
        >
          Reset filters
        </button>
      </section>

      <section className={`container ${styles.programsList}`}>
        {filteredPrograms.length === 0 ? (
          <div className={styles.emptyState}>
            <h2>No programs match your current filters</h2>
            <p>
              Try adjusting your criteria or contact the TravelHeart team to design a tailor-made
              itinerary.
            </p>
          </div>
        ) : (
          <div className={styles.grid}>
            {filteredPrograms.map((program) => (
              <article key={program.id} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={program.image} alt={program.name} />
                  <span className={styles.locationBadge}>{program.location}</span>
                </div>
                <div className={styles.cardBody}>
                  <div className={styles.meta}>
                    <span>{program.durationLabel}</span>
                    <span>{program.region}</span>
                  </div>
                  <h2>{program.name}</h2>
                  <p>{program.description}</p>
                  <ul className={styles.highlightList}>
                    {program.highlights.map((highlight) => (
                      <li key={highlight}>{highlight}</li>
                    ))}
                  </ul>
                  <div className={styles.interestTags}>
                    {program.interests.map((interest) => (
                      <span key={interest}>{interest}</span>
                    ))}
                  </div>
                  <button type="button" className={styles.enquireButton}>
                    Enquire about this program
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <section className={styles.note}>
        <div className="container">
          <div className={styles.noteCard}>
            <h2>Personalise your itinerary</h2>
            <p>
              Share your travel dates, group size, and must-see wishes. We will adapt pacing,
              accommodation styles, and experiences to suit your preferences.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default ProgramsPage;