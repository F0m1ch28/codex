import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) {
      currentErrors.name = 'Please enter your name.';
    }
    if (!formData.email.trim()) {
      currentErrors.email = 'Please provide a valid email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      currentErrors.email = 'This does not look like a valid email address.';
    }
    if (!formData.subject.trim()) {
      currentErrors.subject = 'Let us know the subject of your message.';
    }
    if (!formData.message.trim()) {
      currentErrors.message = 'Tell us a little more about how we can help.';
    }
    return currentErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    setErrors((prev) => ({ ...prev, [event.target.name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialFormState);
    } else {
      setErrors(validationErrors);
      setSubmitted(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact TravelHeart | Plan Your Croatia Journey</title>
        <meta
          name="description"
          content="Reach out to TravelHeart to personalise your Croatia travel plans. Share your ideas, and our team will respond with curated guidance."
        />
      </Helmet>

      <section className={`container ${styles.intro}`}>
        <h1>Let’s co-create your Croatia story</h1>
        <p>
          Share your travel dreams, timing, and group details. A TravelHeart specialist will reply
          with thoughtful ideas, tailored suggestions, and next steps.
        </p>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Name</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="subject">Subject</label>
              <input
                id="subject"
                name="subject"
                type="text"
                value={formData.subject}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.subject)}
              />
              {errors.subject && <span className={styles.error}>{errors.subject}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>
            <button type="submit" className={styles.submitButton}>
              Send message
            </button>
            {submitted && (
              <p className={styles.success}>
                Thank you for reaching out! A TravelHeart specialist will be in touch soon.
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default ContactPage;