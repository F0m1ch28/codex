import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import ScrollToTop from './components/ScrollToTop';

import HomePage from './pages/Home';
import GuidePage from './pages/Guide';
import ProgramsPage from './pages/Programs';
import ToolsPage from './pages/Tools';
import BlogPage from './pages/Blog';
import BlogPostPage from './pages/BlogPost';
import AboutPage from './pages/About';
import ContactPage from './pages/Contact';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';

function App() {
  return (
    <>
      <Helmet>
        <title>TravelHeart | Croatia Travel Guide</title>
        <meta
          name="description"
          content="TravelHeart curates unforgettable journeys across Croatia with inspiring guides, curated programs, and practical tools for mindful explorers."
        />
      </Helmet>
      <ScrollToTop />
      <div className="app-shell">
        <Header />
        <main id="main-content" className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/guide" element={<GuidePage />} />
            <Route path="/programs" element={<ProgramsPage />} />
            <Route path="/tools" element={<ToolsPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:slug" element={<BlogPostPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTopButton />
      </div>
    </>
  );
}

export default App;