document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('primaryNav');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navMenu.classList.toggle('is-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const cookieButtons = cookieBanner.querySelectorAll('.cookie-button');
        const storedChoice = localStorage.getItem('qualitavykCookieChoice');

        if (storedChoice) {
            cookieBanner.classList.add('is-hidden');
        } else {
            setTimeout(() => cookieBanner.classList.add('is-visible'), 800);
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.dataset.choice || 'dismissed';
                localStorage.setItem('qualitavykCookieChoice', choice);
                cookieBanner.classList.remove('is-visible');
                setTimeout(() => {
                    cookieBanner.classList.add('is-hidden');
                }, 400);
                const target = button.getAttribute('href');
                if (target && target.includes('cookies.html')) {
                    setTimeout(() => {
                        window.location.href = target;
                    }, 250);
                }
            });
        });
    }
});