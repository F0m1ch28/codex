document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieActions = document.querySelectorAll(".cookie-actions a");

    if (cookieBanner && cookieActions.length) {
        cookieActions.forEach((action) => {
            action.addEventListener("click", (event) => {
                event.preventDefault();
                window.open("cookies.html", "_blank");
                cookieBanner.style.display = "none";
            });
        });
    }
});