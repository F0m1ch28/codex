document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const nav = document.querySelector('[data-nav]');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (nav.classList.contains('is-open')) {
          nav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const langButtons = document.querySelectorAll('[data-lang-target]');
  const langBlocks = document.querySelectorAll('.lang-block');
  const body = document.body;

  function applyLanguage(mode) {
    body.setAttribute('data-language', mode);
    langBlocks.forEach(block => {
      const blockLang = block.dataset.lang;
      const matches = mode === 'both' || blockLang === mode;
      block.style.display = matches ? '' : 'none';
      block.setAttribute('aria-hidden', matches ? 'false' : 'true');
    });
    langButtons.forEach(btn => {
      btn.classList.toggle('is-active', btn.dataset.langTarget === mode);
    });
    localStorage.setItem('hnLanguageMode', mode);
  }

  if (langButtons.length) {
    let savedMode = localStorage.getItem('hnLanguageMode');
    if (!savedMode) {
      savedMode = 'both';
    }
    applyLanguage(savedMode);
    langButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        applyLanguage(btn.dataset.langTarget);
      });
    });
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const cookieConsent = localStorage.getItem('hnCookieConsent');

  if (cookieBanner) {
    if (cookieConsent) {
      cookieBanner.classList.add('is-hidden');
    } else {
      cookieBanner.classList.remove('is-hidden');
    }

    const closeBanner = (status) => {
      cookieBanner.classList.add('is-hidden');
      localStorage.setItem('hnCookieConsent', status);
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => closeBanner('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => closeBanner('declined'));
    }
  }
});