import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

function Services() {
  return (
    <>
      <Helmet>
        <title>Services | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Discover TechSolutions Inc. services in IT consulting, software development, and cloud enablement designed to accelerate business growth."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Services Built for Resilient Digital Growth</h1>
        <p>
          Our consulting specialists and engineering teams work in concert to
          align technology with your business objectives, modernize legacy
          capabilities, and launch transformative products with confidence.
        </p>
      </section>

      <section className={styles.serviceSection}>
        <div className={styles.imageWrapper}>
          <img
            src="https://picsum.photos/seed/itstrategy/600/420"
            alt="Consultants planning digital strategy"
          />
        </div>
        <div className={styles.content}>
          <h2>IT & Digital Strategy Consulting</h2>
          <p>
            We collaborate with your leadership teams to evaluate current-state
            technology, define future-state architecture, and prioritize an
            actionable roadmap. Our consultants leverage industry benchmarks and
            proven frameworks to ensure every investment contributes to lasting
            enterprise value.
          </p>
          <ul>
            <li>Technology portfolio assessments & maturity analysis</li>
            <li>Digital transformation roadmaps & innovation programs</li>
            <li>Enterprise architecture & platform selection advisory</li>
            <li>Change management and stakeholder alignment</li>
          </ul>
        </div>
      </section>

      <section className={`${styles.serviceSection} ${styles.reverse}`}>
        <div className={styles.imageWrapper}>
          <img
            src="https://picsum.photos/seed/productdelivery/600/420"
            alt="Developers collaborating on software project"
          />
        </div>
        <div className={styles.content}>
          <h2>Custom Software Development</h2>
          <p>
            Our engineers design, prototype, and launch high-performing digital
            products across cloud, mobile, and web platforms. We embed quality
            assurance and security at every iteration, producing future-ready
            solutions that scale gracefully as your organization grows.
          </p>
          <ul>
            <li>Experience design and product discovery workshops</li>
            <li>Full-stack development using modern frameworks</li>
            <li>API-first architecture and systems integration</li>
            <li>Automated testing, QA, and secure deployment practices</li>
          </ul>
        </div>
      </section>

      <section className={styles.serviceSection}>
        <div className={styles.imageWrapper}>
          <img
            src="https://picsum.photos/seed/devops/600/420"
            alt="Cloud operations and DevOps dashboard"
          />
        </div>
        <div className={styles.content}>
          <h2>Cloud, DevOps & Managed Services</h2>
          <p>
            Optimize performance, availability, and governance with cloud-native
            infrastructure and automated operations. Our DevOps specialists
            accelerate release cycles while safeguarding compliance and
            reliability across distributed environments.
          </p>
          <ul>
            <li>Cloud migration planning and execution</li>
            <li>Infrastructure as Code & CI/CD pipeline automation</li>
            <li>Site reliability engineering and performance monitoring</li>
            <li>Managed services and 24/7 operational support</li>
          </ul>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div>
          <h2>Let’s Design the Future of Your Technology Together</h2>
          <p>
            Engage with our consultants for a discovery workshop to uncover
            opportunities, define priorities, and initiate a roadmap toward
            resilient innovation.
          </p>
        </div>
        <a href="/contact" className={styles.ctaButton}>
          Start a Project Conversation
        </a>
      </section>
    </>
  );
}

export default Services;