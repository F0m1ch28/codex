import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Understand how TechSolutions Inc. collects, uses, and protects your information."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <h1>Privacy Policy</h1>
        <p className={styles.updated}>Effective date: January 2024</p>

        <h2>Information We Collect</h2>
        <p>
          We collect personal information that you provide voluntarily,
          including contact details and project information submitted through
          our forms. We may also collect usage data through cookies and similar
          technologies to enhance user experience.
        </p>

        <h2>How We Use Information</h2>
        <p>
          TechSolutions Inc. uses collected information to respond to inquiries,
          deliver consulting services, improve our website, and communicate
          relevant updates. We do not sell personal information to third
          parties.
        </p>

        <h2>Data Security</h2>
        <p>
          We implement administrative, technical, and physical safeguards to
          protect personal information from unauthorized access, disclosure, or
          misuse.
        </p>

        <h2>Your Rights</h2>
        <p>
          Depending on your jurisdiction, you may have the right to request
          access, correction, or deletion of your personal information. To
          exercise these rights, contact{" "}
          <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
        </p>

        <h2>Updates to This Policy</h2>
        <p>
          We may update this Privacy Policy periodically. The latest revision
          date will be noted at the top of this page.
        </p>

        <h2>Contact Us</h2>
        <p>
          For questions or concerns about this Policy, please email{" "}
          <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
        </p>
      </section>
    </>
  );
}

export default Privacy;