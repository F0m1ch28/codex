import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

function Home() {
  return (
    <>
      <Helmet>
        <title>TechSolutions Inc. | Strategic IT Consulting & Software Development</title>
        <meta
          name="description"
          content="Partner with TechSolutions Inc. for tailored IT consulting, cloud transformation, and software development that empower digital growth."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>
            Transform Ideas into Intelligent Digital Experiences.
          </h1>
          <p>
            TechSolutions Inc. helps ambitious organizations design, build, and
            scale dependable technology ecosystems through strategic consulting
            and custom software development.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryCta}>
              Schedule a Consultation
            </Link>
            <Link to="/services" className={styles.secondaryCta}>
              Explore Our Services
            </Link>
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/techsolutions-hero/640/480"
            alt="Team collaborating on technology strategy"
          />
        </div>
      </section>

      <section className={styles.servicesPreview}>
        <div className={styles.sectionHeader}>
          <h2>Driving Value Across the Digital Lifecycle</h2>
          <p>
            From discovery workshops to enterprise-scale deployments, our team
            brings together strategic insight and engineering excellence to fuel
            sustainable innovation.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          <article className={styles.card}>
            <img
              src="https://picsum.photos/seed/consulting/480/320"
              alt="Consulting strategy meeting"
            />
            <h3>Strategic IT Consulting</h3>
            <p>
              Assess current technology maturity, shape transformation roadmaps,
              and prioritize investments that support measurable business
              outcomes.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Learn more →
            </Link>
          </article>
          <article className={styles.card}>
            <img
              src="https://picsum.photos/seed/development/480/320"
              alt="Software development on laptops"
            />
            <h3>Custom Software Engineering</h3>
            <p>
              Design and deliver scalable web, cloud, and mobile applications
              using modern engineering practices and rigorous quality
              assurance.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Learn more →
            </Link>
          </article>
          <article className={styles.card}>
            <img
              src="https://picsum.photos/seed/cloud/480/320"
              alt="Cloud infrastructure visual"
            />
            <h3>Cloud & DevOps Enablement</h3>
            <p>
              Modernize infrastructure, automate delivery pipelines, and unlock
              operational resilience with secure, cloud-native solutions.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Learn more →
            </Link>
          </article>
        </div>
      </section>

      <section className={styles.metrics}>
        <div className={styles.metric}>
          <span>15+</span>
          <p>Years guiding digital transformation</p>
        </div>
        <div className={styles.metric}>
          <span>120+</span>
          <p>Successful product launches and deployments</p>
        </div>
        <div className={styles.metric}>
          <span>98%</span>
          <p>Client satisfaction across consulting engagements</p>
        </div>
      </section>

      <section className={styles.testimonial}>
        <div className={styles.sectionHeader}>
          <h2>What Our Clients Say</h2>
          <p>
            “TechSolutions Inc. is the partner we trust for mission-critical
            initiatives. Their consultants quickly aligned with our goals and
            delivered a scalable platform that transformed how we serve
            customers.” — Director of Digital Strategy, Global Finance Firm
          </p>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Ready to Accelerate Your Technology Vision?</h2>
          <p>
            Partner with a multidisciplinary team that combines strategy,
            design, and engineering for measurable business impact.
          </p>
        </div>
        <Link to="/contact" className={styles.ctaButton}>
          Connect with Our Team
        </Link>
      </section>
    </>
  );
}

export default Home;