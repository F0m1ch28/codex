import React from "react";
import { Helmet } from "react-helmet";
import styles from "./CookiePolicy.module.css";

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Learn how TechSolutions Inc. uses cookies to enhance your browsing experience."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <h1>Cookie Policy</h1>
        <p className={styles.updated}>Effective date: January 2024</p>

        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a
          website. They help us provide a more personalized experience and
          understand how our site is used.
        </p>

        <h2>Types of Cookies We Use</h2>
        <ul>
          <li>
            <strong>Essential cookies:</strong> Required for basic site
            functionality, including navigation.
          </li>
          <li>
            <strong>Analytics cookies:</strong> Help us analyze traffic and
            improve usability.
          </li>
          <li>
            <strong>Preference cookies:</strong> Remember your settings and
            preferences.
          </li>
        </ul>

        <h2>Managing Cookies</h2>
        <p>
          You can manage or disable cookies through your browser settings.
          Please note that disabling certain cookies may affect site
          functionality.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this Cookie Policy periodically. Continued use of our
          site indicates acceptance of any changes.
        </p>

        <h2>Contact</h2>
        <p>
          Questions regarding this policy can be sent to{" "}
          <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
        </p>
      </section>
    </>
  );
}

export default CookiePolicy;