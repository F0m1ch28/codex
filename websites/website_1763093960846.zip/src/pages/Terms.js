import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

function Terms() {
  return (
    <>
      <Helmet>
        <title>Terms of Use | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Review the terms of use for TechSolutions Inc. website and services."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <h1>Terms of Use</h1>
        <p className={styles.updated}>Last updated: January 2024</p>

        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing or using the TechSolutions Inc. website, you agree to be
          bound by these Terms of Use. If you do not agree with these terms, you
          should not use our website or services.
        </p>

        <h2>2. Use of Content</h2>
        <p>
          All content provided on this website, including text, graphics,
          images, and information, is the property of TechSolutions Inc. and
          protected by applicable intellectual property laws. You may not
          reproduce, distribute, or modify any content without written consent.
        </p>

        <h2>3. Professional Services</h2>
        <p>
          Any proposals, statements of work, or consulting services rendered by
          TechSolutions Inc. will be governed by separate agreements mutually
          executed between the parties.
        </p>

        <h2>4. Limitation of Liability</h2>
        <p>
          To the fullest extent permitted by law, TechSolutions Inc. shall not
          be liable for any indirect, incidental, or consequential damages
          arising from your use of the website or reliance on its content.
        </p>

        <h2>5. Governing Law</h2>
        <p>
          These Terms of Use are governed by the laws of the State of
          California, without regard to its conflict-of-law principles.
        </p>

        <h2>6. Contact</h2>
        <p>
          Questions regarding these terms may be sent to{" "}
          <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
        </p>
      </section>
    </>
  );
}

export default Terms;