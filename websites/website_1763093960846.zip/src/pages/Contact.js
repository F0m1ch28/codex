import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const initialState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your name.";
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email address.";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)
    ) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Let us know how we can help.";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Contact | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Connect with TechSolutions Inc. to start your IT consulting or software development engagement."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Connect with TechSolutions Inc.</h1>
        <p>
          Tell us about your initiative and our consultants will reach out to
          arrange a tailored conversation.
        </p>
      </section>

      <section className={styles.container}>
        <div className={styles.formSection}>
          <h2>Send Us a Message</h2>
          <p>
            Complete the form and we’ll respond within one business day to
            discuss how we can support your objectives.
          </p>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Full name *</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter your full name"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Email *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@company.com"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && (
                <span className={styles.error}>{errors.email}</span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                placeholder="Company name"
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="message">How can we help? *</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                placeholder="Share a brief overview of your goals"
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && (
                <span className={styles.error}>{errors.message}</span>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Submit inquiry
            </button>

            {submitted && (
              <div className={styles.success}>
                Thank you! Our team will get in touch shortly.
              </div>
            )}
          </form>
        </div>

        <div className={styles.detailsSection}>
          <div className={styles.detailsCard}>
            <h3>Office</h3>
            <p>
              123 Tech Avenue, Innovation District,
              <br />
              San Francisco, CA 94105
            </p>
            <a href="tel:+15551234567">+1 (555) 123-4567</a>
            <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
          </div>

          <div className={styles.mapWrapper}>
            <iframe
              title="TechSolutions Inc. location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.119224194735!2d-122.3967613!3d37.7895581!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064d0c0d4f7%3A0x80847dcedd4b8ea4!2s123%20Tech%20Ave%2C%20San%20Francisco%2C%20CA%2094105!5e0!3m2!1sen!2sus!4v1700000000000"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;