import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

function About() {
  return (
    <>
      <Helmet>
        <title>About Us | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Learn about TechSolutions Inc. history, mission, and leadership team dedicated to delivering world-class IT consulting and software solutions."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Empowering Organizations Through Technology Excellence</h1>
        <p>
          Since 2008, TechSolutions Inc. has partnered with forward-looking
          businesses to architect resilient digital ecosystems and accelerate
          their innovation agendas.
        </p>
      </section>

      <section className={styles.story}>
        <div className={styles.storyImage}>
          <img
            src="https://picsum.photos/seed/history/640/440"
            alt="TechSolutions team celebrating project launch"
          />
        </div>
        <div className={styles.storyContent}>
          <h2>Our Story</h2>
          <p>
            Founded in San Francisco&apos;s Innovation District, TechSolutions
            Inc. emerged with a simple idea: combining strategic consulting,
            design thinking, and world-class engineering to guide clients
            through the evolving digital landscape. Starting as a small advisory
            collective, we have grown into a multidisciplinary agency trusted by
            global enterprises and high-growth scale-ups alike.
          </p>
          <p>
            Our team thrives on tackling complex transformation programs,
            delivering measurable outcomes, and building enduring relationships
            based on transparency and shared success.
          </p>
        </div>
      </section>

      <section className={styles.values}>
        <h2>Guiding Principles</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Client-Centered Impact</h3>
            <p>
              We immerse ourselves in your business context to identify the
              strategies and capabilities that unlock measurable value.
            </p>
          </article>
          <article>
            <h3>Engineering Craftsmanship</h3>
            <p>
              Our engineers embrace modern architectures, automation, and
              rigorous quality to deliver resilient solutions.
            </p>
          </article>
          <article>
            <h3>Collaborative Innovation</h3>
            <p>
              From ideation to delivery, we co-create with your teams to ensure
              alignment, knowledge transfer, and sustainable adoption.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.team}>
        <h2>Leadership Team</h2>
        <div className={styles.teamGrid}>
          <div className={styles.member}>
            <img
              src="https://picsum.photos/seed/team1/300/300"
              alt="Portrait of Maya Chen, CEO"
            />
            <h3>Maya Chen</h3>
            <p className={styles.role}>Chief Executive Officer</p>
            <p>
              Maya guides TechSolutions Inc. with two decades of consulting
              experience, ensuring every engagement aligns technology with
              strategic business outcomes.
            </p>
          </div>
          <div className={styles.member}>
            <img
              src="https://picsum.photos/seed/team2/300/300"
              alt="Portrait of Carlos Alvarez, CTO"
            />
            <h3>Carlos Alvarez</h3>
            <p className={styles.role}>Chief Technology Officer</p>
            <p>
              Carlos leads engineering excellence, championing secure, scalable,
              and future-ready architectures across our delivery teams.
            </p>
          </div>
          <div className={styles.member}>
            <img
              src="https://picsum.photos/seed/team3/300/300"
              alt="Portrait of Priya Desai, VP of Consulting"
            />
            <h3>Priya Desai</h3>
            <p className={styles.role}>VP of Consulting Services</p>
            <p>
              Priya oversees consulting strategy and advisory operations,
              partnering with executives to drive enterprise transformation.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <h2>Milestones</h2>
        <ul>
          <li>
            <span>2008</span>
            TechSolutions Inc. launches with a focus on IT advisory services for
            emerging startups.
          </li>
          <li>
            <span>2012</span>
            Expanded capabilities to include full-stack software development and
            UX design.
          </li>
          <li>
            <span>2017</span>
            Established dedicated Cloud & DevOps practice to support enterprise
            modernization.
          </li>
          <li>
            <span>2022</span>
            Recognized as a top consultancy for digital transformation in North
            America.
          </li>
        </ul>
      </section>
    </>
  );
}

export default About;