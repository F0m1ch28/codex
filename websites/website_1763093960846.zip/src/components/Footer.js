import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <div className={styles.logo}>TechSolutions Inc.</div>
          <p className={styles.tagline}>
            Strategic IT consulting and bespoke software that move your business
            forward.
          </p>
        </div>

        <div className={styles.links}>
          <h4 className={styles.heading}>Company</h4>
          <NavLink to="/services" className={styles.link}>
            Services
          </NavLink>
          <NavLink to="/about" className={styles.link}>
            About
          </NavLink>
          <NavLink to="/contact" className={styles.link}>
            Contact
          </NavLink>
        </div>

        <div className={styles.links}>
          <h4 className={styles.heading}>Legal</h4>
          <NavLink to="/terms" className={styles.link}>
            Terms of Use
          </NavLink>
          <NavLink to="/privacy" className={styles.link}>
            Privacy Policy
          </NavLink>
          <NavLink to="/cookie-policy" className={styles.link}>
            Cookie Policy
          </NavLink>
        </div>

        <div className={styles.contact}>
          <h4 className={styles.heading}>Contact</h4>
          <p>123 Tech Avenue, Innovation District, San Francisco, CA 94105</p>
          <a href="tel:+15551234567" className={styles.link}>
            +1 (555) 123-4567
          </a>
          <a href="mailto:info@techsolutions.com" className={styles.link}>
            info@techsolutions.com
          </a>
          <div className={styles.socials}>
            <a
              href="https://www.linkedin.com"
              className={styles.socialLink}
              aria-label="LinkedIn"
            >
              <svg
                width="20"
                height="20"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.5 23.5h4V7.5h-4v16zM8.5 7.5h3.8v2.2h.05c.53-1 1.84-2.05 3.8-2.05 4.07 0 4.82 2.68 4.82 6.15v9.7h-4v-8.6c0-2.05-.04-4.7-2.86-4.7-2.86 0-3.3 2.23-3.3 4.55v8.75h-4V7.5z" />
              </svg>
            </a>
            <a
              href="https://twitter.com"
              className={styles.socialLink}
              aria-label="Twitter"
            >
              <svg
                width="20"
                height="20"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.3 4.3 0 001.88-2.37 8.59 8.59 0 01-2.72 1.04 4.28 4.28 0 00-7.4 2.92c0 .34.04.68.11 1A12.15 12.15 0 013 4.79a4.28 4.28 0 001.33 5.71 4.25 4.25 0 01-1.94-.54v.05a4.28 4.28 0 003.43 4.2 4.3 4.3 0 01-1.93.07 4.29 4.29 0 004 2.97A8.6 8.6 0 012 19.54a12.1 12.1 0 006.56 1.92c7.88 0 12.2-6.53 12.2-12.2 0-.19 0-.39-.01-.58A8.72 8.72 0 0024 5.1a8.5 8.5 0 01-2.54.7z" />
              </svg>
            </a>
            <a
              href="https://github.com"
              className={styles.socialLink}
              aria-label="GitHub"
            >
              <svg
                width="20"
                height="20"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.1 3.3 9.43 7.88 10.96.58.1.79-.25.79-.56 0-.28-.01-1.03-.02-2.02-3.21.7-3.89-1.55-3.89-1.55-.53-1.36-1.3-1.72-1.3-1.72-1.07-.73.08-.72.08-.72 1.18.08 1.8 1.22 1.8 1.22 1.05 1.8 2.75 1.28 3.42.98.11-.76.41-1.28.75-1.57-2.56-.29-5.26-1.28-5.26-5.68 0-1.25.45-2.27 1.2-3.07-.12-.3-.52-1.5.11-3.12 0 0 .97-.31 3.18 1.18.92-.26 1.9-.39 2.88-.39.98 0 1.96.13 2.88.39 2.21-1.49 3.18-1.18 3.18-1.18.63 1.62.23 2.82.11 3.12.75.8 1.2 1.82 1.2 3.07 0 4.41-2.7 5.38-5.28 5.66.42.36.8 1.09.8 2.2 0 1.59-.01 2.87-.01 3.26 0 .31.21.67.8.56A10.52 10.52 0 0023.5 12C23.5 5.65 18.35.5 12 .5z" />
              </svg>
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} TechSolutions Inc. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;