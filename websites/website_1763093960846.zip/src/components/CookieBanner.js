import React, { useEffect, useState } from "react";
import styles from "./CookieBanner.module.css";

const STORAGE_KEY = "techsolutions-cookie-consent";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <h4>Cookies Notice</h4>
        <p>
          We use cookies to enhance your browsing experience, personalize
          content, and analyze our traffic. By clicking “Accept”, you consent to
          the use of cookies.
        </p>
        <a href="/cookie-policy" className={styles.link}>
          Learn more
        </a>
      </div>
      <button onClick={handleAccept} className={styles.button}>
        Accept
      </button>
    </div>
  );
}

export default CookieBanner;