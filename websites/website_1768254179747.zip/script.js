document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");
    if (navToggle && mainNav) {
        navToggle.addEventListener("click", function () {
            mainNav.classList.toggle("open");
        });
        document.addEventListener("click", function (event) {
            if (!mainNav.contains(event.target) && !navToggle.contains(event.target)) {
                mainNav.classList.remove("open");
            }
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptCookiesBtn = document.getElementById("accept-cookies");
    const declineCookiesBtn = document.getElementById("decline-cookies");
    const storedConsent = localStorage.getItem("croesutuexCookieConsent");

    if (!storedConsent && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    const handleConsent = function (value) {
        localStorage.setItem("croesutuexCookieConsent", value);
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
    };

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener("click", function () {
            handleConsent("accepted");
        });
    }

    if (declineCookiesBtn) {
        declineCookiesBtn.addEventListener("click", function () {
            handleConsent("declined");
        });
    }
});