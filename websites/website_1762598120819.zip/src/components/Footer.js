import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}>
          <div className={styles.logoWrapper}>
            <span className={styles.logoMark}>+</span>
            <div>
              <p className={styles.brandName}>Плюс</p>
              <span className={styles.brandTagline}>IT консалтинг • Цифровая трансформация</span>
            </div>
          </div>
          <p className={styles.description}>
            Мы ускоряем развитие компаний, выстраивая цифровые экосистемы, которые помогают бизнесу принимать решения быстрее и увереннее.
          </p>
        </div>

        <div className={styles.columns}>
          <div className={styles.column}>
            <h3 className={styles.heading}>Навигация</h3>
            <ul className={styles.list}>
              <li><Link to="/" className={styles.link}>Главная</Link></li>
              <li><Link to="/uslugi" className={styles.link}>Услуги</Link></li>
              <li><Link to="/o-nas" className={styles.link}>О компании</Link></li>
              <li><Link to="/blog" className={styles.link}>Блог</Link></li>
              <li><Link to="/kontakty" className={styles.link}>Контакты</Link></li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.heading}>Правовая информация</h3>
            <ul className={styles.list}>
              <li><Link to="/politika-konfidencialnosti" className={styles.link}>Политика конфиденциальности</Link></li>
              <li><Link to="/usloviya-ispolzovaniya" className={styles.link}>Условия использования</Link></li>
              <li><Link to="/politika-cookies" className={styles.link}>Политика cookies</Link></li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.heading}>Контакты</h3>
            <ul className={styles.list}>
              <li>
                <a href="tel:+74951234567" className={styles.link}>
                  +7 (495) 123-45-67
                </a>
              </li>
              <li>
                <a href="mailto:info@plus-consulting.ru" className={styles.link}>
                  info@plus-consulting.ru
                </a>
              </li>
              <li className={styles.address}>
                Москва, ул. Тверская, д. 15, офис 304
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className={styles.bottomBar}>
        <div className="container">
          <p className={styles.bottomText}>
            © {currentYear} ООО «Плюс Консалтинг». Все права защищены.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;