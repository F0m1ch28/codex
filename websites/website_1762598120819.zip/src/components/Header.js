import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const navLinkClass = ({ isActive }) =>
    `${styles.navLink} ${isActive ? styles.activeLink : ''}`;

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`}>
      <div className={`container ${styles.inner}`}>
        <Link to="/" className={styles.logo} aria-label="Переход на главную страницу">
          <span className={styles.logoMark}>+</span>
          <span className={styles.logoText}>
            Плюс <span className={styles.logoSubtitle}>Цифровой консалтинг</span>
          </span>
        </Link>

        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          <NavLink to="/" className={navLinkClass} end>
            Главная
          </NavLink>
          <NavLink to="/uslugi" className={navLinkClass}>
            Услуги
          </NavLink>
          <NavLink to="/o-nas" className={navLinkClass}>
            О нас
          </NavLink>
          <NavLink to="/blog" className={navLinkClass}>
            Блог
          </NavLink>
          <NavLink to="/kontakty" className={navLinkClass}>
            Контакты
          </NavLink>
        </nav>

        <div className={styles.actions}>
          <Link to="/kontakty" className={styles.ctaLink}>
            Связаться
          </Link>
          <button
            type="button"
            className={`${styles.menuToggle} ${isMenuOpen ? styles.menuToggleOpen : ''}`}
            onClick={() => setIsMenuOpen((prev) => !prev)}
            aria-label="Открыть меню"
            aria-expanded={isMenuOpen}
            aria-controls="primary-navigation"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;