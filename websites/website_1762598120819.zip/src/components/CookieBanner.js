import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('plus-cookie-consent');
    if (!consent) {
      setTimeout(() => setIsVisible(true), 1200);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('plus-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('plus-cookie-consent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookies">
      <div className={styles.content}>
        <p className={styles.text}>
          Мы используем cookies, чтобы сделать работу сайта удобнее и анализировать интерес к нашим материалам. Подробнее в разделе{' '}
          <Link to="/politika-cookies" className={styles.link}>
            Политика cookies
          </Link>
          .
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.buttonPrimary} onClick={handleAccept}>
            Принять
          </button>
          <button type="button" className={styles.buttonSecondary} onClick={handleDecline}>
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;