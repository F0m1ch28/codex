import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: 'Проектов по цифровой трансформации', value: 120, suffix: '+', description: 'За последние три года' },
      { label: 'Дней до первых результатов', value: 45, suffix: '', description: 'Средний срок для пилотных инициатив' },
      { label: 'Внедрённых цифровых платформ', value: 24, suffix: '', description: 'В крупных российских компаниях' },
      { label: 'Удовлетворённость клиентов', value: 98, suffix: '%', description: 'По итогам NPS-опросов' }
    ],
    []
  );

  const servicesList = useMemo(
    () => [
      {
        title: 'Цифровая стратегия и дорожная карта',
        description:
          'Определяем стратегические приоритеты, создаём адаптивную дорожную карту цифровой трансформации и помогаем быстро запускать инициативы.'
      },
      {
        title: 'Построение архитектуры данных',
        description:
          'Проектируем целевую архитектуру данных, настраиваем процессы их сбора и управления, внедряем современные аналитические решения.'
      },
      {
        title: 'Автоматизация и интеграция процессов',
        description:
          'Соединяем бизнес-системы в единую экосистему, создаём цифровые сервисы для сотрудников и клиентов, оптимизируем операционные процессы.'
      },
      {
        title: 'Инновации и продукты',
        description:
          'Проводим дизайн-мышление и быстрые эксперименты, создаём MVP и выводим цифровые продукты на рынок, масштабируем самые эффективные.'
      }
    ],
    []
  );

  const processSteps = useMemo(
    () => [
      {
        step: '1',
        title: 'Диагностика потенциала',
        description: 'Исследуем текущую цифровую зрелость, выявляем узкие места и точки роста, формируем гипотезы изменений.'
      },
      {
        step: '2',
        title: 'Совместное проектирование',
        description: 'Создаём продуктовые и процессные решения вместе с вашей командой, согласуем дорожную карту и метрики успеха.'
      },
      {
        step: '3',
        title: 'Внедрение и обучение',
        description: 'Организуем управление изменениями, сопровождаем внедрение, обучаем сотрудников новым инструментам и методам работы.'
      },
      {
        step: '4',
        title: 'Масштабирование эффектов',
        description: 'Оцениваем результаты, подкручиваем решения и масштабируем успешные практики на другие бизнес-направления.'
      }
    ],
    []
  );

  const testimonialsList = useMemo(
    () => [
      {
        quote:
          'Команда «Плюс» помогла нам за полгода построить новую архитектуру данных и запустить аналитическую платформу. Благодаря этому мы ускорили процесс принятия решений и заметно повысили маржинальность направления.',
        name: 'Екатерина Гордеева',
        role: 'Директор по трансформации',
        company: 'ГК «Вектор»'
      },
      {
        quote:
          'Редко встречаю консультантов, которые настолько глубоко погружаются в бизнес клиента. Совместно мы оптимизировали ключевые процессы и запустили цифровые сервисы для клиентов — за первый квартал конверсия выросла на 18%.',
        name: 'Дмитрий Лебедев',
        role: 'Генеральный директор',
        company: 'RetailX'
      },
      {
        quote:
          'Плюс стала для нас надежным партнёром по всем вопросам автоматизации. Понравился формат кооперации: быстрые пилоты, прозрачные приоритеты и постоянная вовлечённость команды.',
        name: 'Анна Соколова',
        role: 'COO',
        company: 'FinEdge'
      }
    ],
    []
  );

  const projectsList = useMemo(
    () => [
      {
        id: 1,
        title: 'Цифровая дорожная карта для холдинга',
        category: 'Финансы',
        description: 'Комплексная стратегия трансформации с акцентом на аналитическую платформу и работу с данными.',
        image: 'https://picsum.photos/1200/800?random=401'
      },
      {
        id: 2,
        title: 'Единая платформа обслуживания клиентов',
        category: 'Ритейл',
        description: 'Создание омниканального клиентского опыта и реализация сервиса персональных рекомендаций.',
        image: 'https://picsum.photos/1200/800?random=402'
      },
      {
        id: 3,
        title: 'Индустриальная аналитика в реальном времени',
        category: 'Производство',
        description: 'Внедрение IoT-платформы и dashboards для мониторинга эффективности производственных линий.',
        image: 'https://picsum.photos/1200/800?random=403'
      },
      {
        id: 4,
        title: 'Сервис цифрового онбординга',
        category: 'Сервисы',
        description: 'Разработка цифрового продукта для удалённого онбординга сотрудников и партнёров.',
        image: 'https://picsum.photos/1200/800?random=404'
      }
    ],
    []
  );

  const categories = useMemo(
    () => ['Все', 'Финансы', 'Ритейл', 'Производство', 'Сервисы'],
    []
  );

  const teamMembers = useMemo(
    () => [
      {
        name: 'Игорь Михайлов',
        role: 'Управляющий партнёр',
        description: '15 лет в стратегическом консалтинге и управлении цифровыми трансформациями.',
        image: 'https://picsum.photos/400/400?random=301'
      },
      {
        name: 'Наталья Кручинина',
        role: 'Директор по данным',
        description: 'Эксперт по построению дата-платформ и внедрению аналитических решений.',
        image: 'https://picsum.photos/400/400?random=302'
      },
      {
        name: 'Алексей Титов',
        role: 'Директор по продукту',
        description: 'Более 20 запусков цифровых продуктов в крупном бизнесе и экосистемах.',
        image: 'https://picsum.photos/400/400?random=303'
      }
    ],
    []
  );

  const faqs = useMemo(
    () => [
      {
        question: 'С чего начинается сотрудничество?',
        answer:
          'Мы начинаем с диагностической сессии и интервью ключевых стейкхолдеров. Это позволяет понять вашу текущую ситуацию, сформулировать цели и согласовать ожидания. Далее мы совместно определяем приоритетные инициативы и план работы.'
      },
      {
        question: 'Как вы интегрируетесь с внутренними командами?',
        answer:
          'Мы выстраиваем гибридную команду: наши консультанты и ваши эксперты работают как единое целое. Фокус на обмене знаниями, прозрачных решениях и совместных воркшопах, чтобы изменения были устойчивыми.'
      },
      {
        question: 'Помогаете ли вы с обучением сотрудников?',
        answer:
          'Да, мы проводим обучающие программы, фасилитируем практические сессии и готовим материалы, чтобы команда могла самостоятельно поддерживать и развивать внедрённые решения.'
      },
      {
        question: 'Работаете ли вы с небольшими проектами?',
        answer:
          'Мы фокусируемся на стратегически важных для компании инициативах. При этом готовы запускать пилоты и MVP, если они ведут к значимому эффекту и масштабируемости.'
      }
    ],
    []
  );

  const blogPosts = useMemo(
    () => [
      {
        title: 'Как перестроить процессы вокруг данных и не потерять скорость бизнеса',
        category: 'Аналитика',
        date: '12 марта 2024',
        excerpt:
          'Разбираемся, как организовать управление данными, выстроить роли и добиться прозрачности в принятии решений.',
        image: 'https://picsum.photos/800/600?random=201'
      },
      {
        title: 'Цифровой рабочий день: опыт внедрения платформы в промышленной компании',
        category: 'Практика',
        date: '28 февраля 2024',
        excerpt:
          'Рассказываем о поэтапном запуске цифрового рабочего места, ключевых инсайтах и влиянии на эффективность.',
        image: 'https://picsum.photos/800/600?random=202'
      },
      {
        title: 'Дизайн мышление в B2B: как создавать продукты вместе с клиентами',
        category: 'Продукт',
        date: '9 февраля 2024',
        excerpt:
          'Пошагово описываем наши подходы к исследованию, кастдевам и разработке продуктов в корпоративном сегменте.',
        image: 'https://picsum.photos/800/600?random=203'
      }
    ],
    []
  );

  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [faqOpenIndex, setFaqOpenIndex] = useState(null);
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [formStatus, setFormStatus] = useState({ success: '', error: '' });

  useEffect(() => {
    const totalFrames = 60;
    let frame = 0;

    const counter = setInterval(() => {
      frame += 1;
      setAnimatedStats(
        statsData.map((stat) => {
          const progress = Math.min(stat.value, Math.round((stat.value * frame) / totalFrames));
          return progress;
        })
      );

      if (frame >= totalFrames) {
        clearInterval(counter);
      }
    }, 30);

    return () => clearInterval(counter);
  }, [statsData]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonialsList.length);
    }, 7000);

    return () => clearInterval(interval);
  }, [testimonialsList.length]);

  const filteredProjects = useMemo(() => {
    if (selectedCategory === 'Все') {
      return projectsList;
    }
    return projectsList.filter((project) => project.category === selectedCategory);
  }, [selectedCategory, projectsList]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormStatus({ success: '', error: '' });
    setFormErrors((prev) => ({ ...prev, [name]: '' }));
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Укажите ваше имя.';
    }
    if (!formData.email.trim()) {
      errors.email = 'Введите рабочую почту.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/i.test(formData.email.trim())) {
      errors.email = 'Похоже, что email введён некорректно.';
    }
    if (!formData.message.trim()) {
      errors.message = 'Опишите задачу или интересующий вопрос.';
    }
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      setFormStatus({ success: '', error: 'Проверьте поля формы — мы подсветили то, что нужно уточнить.' });
      return;
    }

    setTimeout(() => {
      setFormStatus({
        success: 'Спасибо! Мы получили ваше сообщение и вернёмся с ответом в течение одного рабочего дня.',
        error: ''
      });
      setFormData({ name: '', email: '', company: '', message: '' });
      setFormErrors({});
    }, 600);
  };

  return (
    <>
      <Helmet>
        <title>Плюс — IT консалтинг и цифровые решения</title>
        <meta
          name="description"
          content="Плюс помогает компаниям строить цифровые стратегии, внедрять продукты и управлять данными. Узнайте о наших подходах и проектах."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <div className={styles.badge}>Цифровой консалтинг нового поколения</div>
            <h1>
              Превращаем
              <span className={styles.heroAccent}> данные, технологии и людей </span>
              в устойчивое конкурентное преимущество вашего бизнеса.
            </h1>
            <p className={styles.heroDescription}>
              Мы выстраиваем стратегию, создаём продукты и сопровождаем внедрение решений, которые помогают компаниям расти быстрее, действовать точнее и быть ближе к своим клиентам.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryButton}>
                Запланировать консультацию
              </Link>
              <Link to="/uslugi" className={styles.secondaryButton}>
                Посмотреть наши подходы
              </Link>
            </div>
            <ul className={styles.heroHighlights}>
              <li>Экспертиза в стратегически важных отраслях</li>
              <li>Комплексные команды под задачи клиента</li>
              <li>Переход от стратегии к реализации без пауз</li>
            </ul>
          </div>

          <div className={styles.heroMedia}>
            <div className={styles.heroImageWrapper}>
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Команда консультантов обсуждает цифровую стратегию"
                className={styles.heroImage}
                loading="lazy"
              />
              <div className={styles.heroCard}>
                <p className={styles.heroCardTitle}>Мир меняется быстрее</p>
                <p className={styles.heroCardText}>
                  Мы делаем компании гибкими, технологичными и готовыми к любым вызовам.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Ключевые достижения">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <p className={styles.statNumber}>
                  {animatedStats[index]}
                  <span className={styles.statSuffix}>{stat.suffix}</span>
                </p>
                <h3>{stat.label}</h3>
                <p className={styles.statDescription}>{stat.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className="container">
          <div className={styles.aboutContent}>
            <div className={styles.aboutText}>
              <h2>Мы — партнёр, который ведёт от идеи до масштабирования</h2>
              <p>
                Плюс — консалтинговая фирма, созданная экспертами с опытом работы в стратегическом консалтинге, продуктовой разработке и корпоративной трансформации. Мы объединяем стратегию, дизайн, технологии и управление изменениями.
              </p>
              <p>
                В каждом проекте мы работаем плечом к плечу с командой клиента: создаём совместную бизнес-логику, проверяем гипотезы и крепим результат измеримыми показателями эффективности.
              </p>
            </div>
            <div className={styles.aboutHighlights}>
              <div className={styles.highlightCard}>
                <span className={styles.highlightLabel}>Миссия</span>
                <p>Помогаем компаниям строить цифровую культуру и принимать решения на основе данных.</p>
              </div>
              <div className={styles.highlightCard}>
                <span className={styles.highlightLabel}>Подход</span>
                <p>Реализуем инициативы быстро, прозрачно и с обязательной передачей экспертизы вашей команде.</p>
              </div>
              <div className={styles.highlightCard}>
                <span className={styles.highlightLabel}>Ценность</span>
                <p>Ориентируемся на бизнес-результат: рост выручки, эффективность процессов и качество клиентского опыта.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection} aria-label="Ключевые услуги">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Что мы делаем</h2>
            <p>
              Комплекс цифровых решений, который позволяет компаниям трансформировать процессы, запускать новые сервисы и работать с данными без лишней бюрократии.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesList.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/uslugi" className={styles.serviceLink}>
                  Узнать подробности
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection} aria-label="Процесс работы">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Как мы движемся от запроса к результату</h2>
            <p>
              В основе — прозрачный процесс, в котором участвуют все ключевые игроки. Мы фиксируем цели, измеряем прогресс и превращаем результаты в масштабируемые решения.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.step} className={styles.processCard}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} aria-label="Проекты">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Проекты, которыми мы гордимся</h2>
            <p>
              Каждое решение родилось из тесной работы с командой клиента, глубоких исследований и непрерывных экспериментов.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`${styles.filterButton} ${selectedCategory === category ? styles.filterButtonActive : ''}`}
                role="tab"
                aria-selected={selectedCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={project.image}
                    alt={`Проект: ${project.title}`}
                    loading="lazy"
                  />
                  <span className={styles.projectCategory}>{project.category}</span>
                </div>
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/uslugi" className={styles.projectLink}>
                    Как мы работали →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-label="Отзывы клиентов">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Отзывы партнёров</h2>
            <p>Мы ценим доверие и всегда работаем на результат, который можно измерить.</p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonialsList.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>{testimonial.quote}</p>
                <div className={styles.testimonialAuthor}>
                  <p className={styles.testimonialName}>{testimonial.name}</p>
                  <span className={styles.testimonialRole}>
                    {testimonial.role} • {testimonial.company}
                  </span>
                </div>
              </article>
            ))}
            <div className={styles.testimonialControls}>
              {testimonialsList.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setActiveTestimonial(index)}
                  className={`${styles.testimonialDot} ${index === activeTestimonial ? styles.testimonialDotActive : ''}`}
                  aria-label={`Показать отзыв ${index + 1}`}
                  aria-pressed={index === activeTestimonial}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection} aria-label="Команда">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Команда, которая говорит с бизнесом на одном языке</h2>
            <p>
              Наш опыт — на стыке стратегии, технологий и продуктов. Мы умеем соединять людей, процессы и цифры в единый сценарий развития.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={`${member.name} — ${member.role}`} loading="lazy" />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p className={styles.teamDescription}>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} aria-label="Частые вопросы">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Частые вопросы</h2>
            <p>Если вы не нашли ответ, напишите нам — мы всегда отвечаем оперативно.</p>
          </div>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => (
              <article key={faq.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => setFaqOpenIndex((prev) => (prev === index ? null : index))}
                  aria-expanded={faqOpenIndex === index}
                >
                  <span>{faq.question}</span>
                  <span className={styles.faqIcon}>{faqOpenIndex === index ? '−' : '+'}</span>
                </button>
                {faqOpenIndex === index && <p className={styles.faqAnswer}>{faq.answer}</p>}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} aria-label="Свежие материалы">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Свежие материалы</h2>
            <p>Делимся практическими заметками о трансформации, управлении продуктами и работе с данными.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogMeta}>{post.category} • {post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/blog" className={styles.blogLink}>
                    Читать дальше →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.contactSection} aria-label="Связаться с нами">
        <div className="container">
          <div className={styles.contactContent}>
            <div className={styles.contactInfo}>
              <h2>Готовы обсудить вашу задачу</h2>
              <p>
                Расскажите, над чем вы работаете, — и мы предложим формат взаимодействия, подходящий именно вам.
              </p>
              <ul className={styles.contactList}>
                <li>
                  <span className={styles.contactLabel}>Адрес офиса</span>
                  Москва, ул. Тверская, д. 15, офис 304
                </li>
                <li>
                  <span className={styles.contactLabel}>Телефон</span>
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <span className={styles.contactLabel}>Email</span>
                  <a href="mailto:info@plus-consulting.ru">info@plus-consulting.ru</a>
                </li>
              </ul>
            </div>
            <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="home-name">Как к вам обращаться *</label>
                <input
                  id="home-name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(formErrors.name)}
                  aria-describedby={formErrors.name ? 'home-name-error' : undefined}
                  placeholder="Например, Ольга"
                />
                {formErrors.name && (
                  <span id="home-name-error" className={styles.errorText}>
                    {formErrors.name}
                  </span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="home-email">Рабочий email *</label>
                <input
                  id="home-email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(formErrors.email)}
                  aria-describedby={formErrors.email ? 'home-email-error' : undefined}
                  placeholder="name@company.ru"
                />
                {formErrors.email && (
                  <span id="home-email-error" className={styles.errorText}>
                    {formErrors.email}
                  </span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="home-company">Компания</label>
                <input
                  id="home-company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleInputChange}
                  placeholder="Название компании"
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="home-message">Опишите запрос *</label>
                <textarea
                  id="home-message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(formErrors.message)}
                  aria-describedby={formErrors.message ? 'home-message-error' : undefined}
                  placeholder="Какая задача сейчас приоритетна?"
                />
                {formErrors.message && (
                  <span id="home-message-error" className={styles.errorText}>
                    {formErrors.message}
                  </span>
                )}
              </div>
              <div className={styles.formFooter}>
                <button type="submit" className={styles.primaryButton}>
                  Отправить сообщение
                </button>
                <p className={styles.formNote}>
                  Нажимая на кнопку, вы принимаете{' '}
                  <Link to="/politika-konfidencialnosti">Политику конфиденциальности</Link>.
                </p>
              </div>
              <div className={styles.formStatus} aria-live="polite">
                {formStatus.error && <p className={styles.errorText}>{formStatus.error}</p>}
                {formStatus.success && <p className={styles.successText}>{formStatus.success}</p>}
              </div>
            </form>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Давайте построим цифровую стратегию, которая работает</h2>
            <p>
              Мы подключаемся быстро, выводим команду на единый ритм и помогаем получить заметный эффект уже на первых этапах.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/kontakty" className={styles.primaryButton}>
                Запросить встречу
              </Link>
              <Link to="/o-nas" className={styles.secondaryButton}>
                Узнать о команде
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;