import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', company: '', topic: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [statusMessage, setStatusMessage] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setStatusMessage('');
    setFormErrors((prev) => ({ ...prev, [name]: '' }));
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const errors = {};
    if (!formData.name.trim()) errors.name = 'Пожалуйста, укажите ваше имя.';
    if (!formData.email.trim()) {
      errors.email = 'Введите рабочую почту.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email.trim())) {
      errors.email = 'Проверьте правильность email.';
    }
    if (!formData.message.trim()) errors.message = 'Расскажите о задаче, чтобы мы подготовились к ответу.';
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validate();
    if (Object.keys(errors).length) {
      setFormErrors(errors);
      setStatusMessage('');
      return;
    }

    setTimeout(() => {
      setStatusMessage('Сообщение отправлено! Мы свяжемся с вами в течение одного рабочего дня.');
      setFormData({ name: '', email: '', company: '', topic: '', message: '' });
      setFormErrors({});
    }, 600);
  };

  return (
    <>
      <Helmet>
        <title>Контакты «Плюс» — обратная связь и офис</title>
        <meta
          name="description"
          content="Свяжитесь с командой «Плюс»: офис в Москве, телефон, email. Оставьте заявку и мы подготовим решение для вашей задачи."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Связаться с нами</h1>
          <p>
            Расскажите, над каким вызовом работаете. Мы подготовим команду и предложим формат работы, подходящий вашей организации.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.info}>
              <div className={styles.infoCard}>
                <h2>Офис в Москве</h2>
                <p>Москва, ул. Тверская, д. 15, офис 304</p>
              </div>
              <div className={styles.infoCard}>
                <h3>Позвонить</h3>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </div>
              <div className={styles.infoCard}>
                <h3>Написать</h3>
                <a href="mailto:info@plus-consulting.ru">info@plus-consulting.ru</a>
              </div>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Карта офиса Плюс"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.7322623406045!2d37.60652047686637!3d55.765480973144295!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a4cf4f6bff3%3A0x6d6667a3a8680a5d!2z0KLQntCSINCf0LDRgdGC0LXRgNC90YvQuSDQoNC-0LLQtdGA0YHQuNC70Lgg0YLQtdC8LCAxNSwg0JzQvtGB0LrQstCwLCAxMjUwMDI!5e0!3m2!1sru!2sru!4v1709999999999!5m2!1sru!2sru"
                  loading="lazy"
                  allowFullScreen
                />
              </div>
            </div>

            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Отправить запрос</h2>
              <div className={styles.formGrid}>
                <label htmlFor="contact-name">
                  Имя *
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(formErrors.name)}
                    aria-describedby={formErrors.name ? 'contact-name-error' : undefined}
                    placeholder="Ваше имя"
                  />
                  {formErrors.name && (
                    <span id="contact-name-error" className={styles.errorText}>
                      {formErrors.name}
                    </span>
                  )}
                </label>
                <label htmlFor="contact-email">
                  Email *
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(formErrors.email)}
                    aria-describedby={formErrors.email ? 'contact-email-error' : undefined}
                    placeholder="Рабочая почта"
                  />
                  {formErrors.email && (
                    <span id="contact-email-error" className={styles.errorText}>
                      {formErrors.email}
                    </span>
                  )}
                </label>
                <label htmlFor="contact-company">
                  Компания
                  <input
                    id="contact-company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="Организация"
                  />
                </label>
                <label htmlFor="contact-topic">
                  Тема обращения
                  <input
                    id="contact-topic"
                    name="topic"
                    type="text"
                    value={formData.topic}
                    onChange={handleChange}
                    placeholder="Например, цифровая стратегия"
                  />
                </label>
              </div>
              <label htmlFor="contact-message">
                Сообщение *
                <textarea
                  id="contact-message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(formErrors.message)}
                  aria-describedby={formErrors.message ? 'contact-message-error' : undefined}
                  placeholder="Опишите задачу, текущий статус и желаемый результат"
                />
                {formErrors.message && (
                  <span id="contact-message-error" className={styles.errorText}>
                    {formErrors.message}
                  </span>
                )}
              </label>

              <button type="submit" className={styles.submitButton}>
                Отправить
              </button>
              <p className={styles.formNote}>
                Отправляя форму, вы принимаете Политику конфиденциальности и согласны на обработку персональных данных.
              </p>
              <div className={styles.status} aria-live="polite">
                {statusMessage && <p>{statusMessage}</p>}
              </div>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;