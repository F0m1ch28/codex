import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const Blog = () => {
  const posts = useMemo(
    () => [
      {
        title: 'Бизнес-архитектура и продуктовая стратегия: как синхронизировать',
        category: 'Стратегия',
        date: '5 марта 2024',
        excerpt:
          'Рассмотрим практический подход к выстраиванию архитектуры бизнеса вокруг продуктового управления и взаимосвязи инициатив.',
        readingTime: '7 минут',
        image: 'https://picsum.photos/900/600?random=601'
      },
      {
        title: 'Создание дата-офиса: первые 100 дней',
        category: 'Данные',
        date: '22 февраля 2024',
        excerpt:
          'Как сформировать команду, определить метрики и начать приносить ценность бизнесу, не погружаясь в бесконечные согласования.',
        readingTime: '6 минут',
        image: 'https://picsum.photos/900/600?random=602'
      },
      {
        title: 'Экосистема технологических партнёров: кого и зачем подключать',
        category: 'Технологии',
        date: '15 февраля 2024',
        excerpt:
          'Делимся опытом построения партнёрства с вендорами и интеграторами, чтобы ускорять внедрение и снижать риски.',
        readingTime: '8 минут',
        image: 'https://picsum.photos/900/600?random=603'
      },
      {
        title: 'Product discovery в B2B: инструменты и типичные ловушки',
        category: 'Продукт',
        date: '2 февраля 2024',
        excerpt:
          'Показываем, как проводим discovery и какие инструменты помогают не уйти в бесконечные исследования без результата.',
        readingTime: '9 минут',
        image: 'https://picsum.photos/900/600?random=604'
      }
    ],
    []
  );

  const categories = useMemo(
    () => ['Все', 'Стратегия', 'Данные', 'Технологии', 'Продукт'],
    []
  );

  const [selected, setSelected] = useState('Все');

  const filteredPosts = useMemo(() => {
    if (selected === 'Все') return posts;
    return posts.filter((post) => post.category === selected);
  }, [posts, selected]);

  return (
    <>
      <Helmet>
        <title>Блог «Плюс» — цифровая трансформация и продукты</title>
        <meta
          name="description"
          content="Аналитика и практические заметки команды «Плюс»: стратегия, продуктовая разработка, аналитика данных и технологии."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Блог компании «Плюс»</h1>
          <p>Практический взгляд на цифровую трансформацию, продуктовые подходы и работу с данными.</p>
        </div>
      </section>

      <section className={styles.postsSection}>
        <div className="container">
          <div className={styles.filterBar}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${selected === category ? styles.filterButtonActive : ''}`}
                onClick={() => setSelected(category)}
              >
                {category}
              </button>
            ))}
          </div>

          <div className={styles.postsGrid}>
            {filteredPosts.map((post) => (
              <article key={post.title} className={styles.postCard}>
                <div className={styles.imageWrapper}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.content}>
                  <p className={styles.meta}>
                    {post.category} • {post.date} • {post.readingTime} чтения
                  </p>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <button type="button" className={styles.readMore} aria-label={`Подробнее: ${post.title}`}>
                    Читать заметку →
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;