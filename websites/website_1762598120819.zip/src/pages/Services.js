import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  const serviceCategories = useMemo(
    () => [
      {
        title: 'Цифровая стратегия и управление изменениями',
        summary:
          'Выстраиваем стратегию цифровой трансформации, управляем портфелем инициатив и создаём систему управления изменениями.',
        bulletPoints: [
          'Диагностика цифровой зрелости и определение целевого состояния',
          'Формирование дорожной карты и модели управления портфелем инициатив',
          'Настройка системы KPI и OKR для трансформационных программ',
          'Методологическая поддержка и коучинг внутренних команд'
        ]
      },
      {
        title: 'Работа с данными и аналитика',
        summary:
          'Создаём архитектуру данных, внедряем современные BI-решения и выстраиваем культуру принятия решений на основе аналитики.',
        bulletPoints: [
          'Разработка data-стратегии и модели управления данными',
          'Проектирование и внедрение дата-платформ и хранилищ',
          'BI-аналитика, self-service отчётность, визуализация данных',
          'Data governance, качество данных и обучение пользователей'
        ]
      },
      {
        title: 'Продуктовая разработка и дизайн',
        summary:
          'Помогаем создавать клиентские и операционные продукты: от исследования и прототипирования до запуска MVP и масштабирования.',
        bulletPoints: [
          'Исследования, кастдев и формирование продуктовой гипотезы',
          'Service-design, CJM, прототипирование и UX-тесты',
          'Разработка MVP и управление roadmap продуктов',
          'Настройка product-процессов и метрик, обучение команд'
        ]
      },
      {
        title: 'Автоматизация и интеграция процессов',
        summary:
          'Оптимизируем ключевые бизнес-процессы, внедряем интеграционные решения и RPA-инструменты, объединяя системы в экосистему.',
        bulletPoints: [
          'Audit процессов, выявление точек автоматизации',
          'Проектирование целевой архитектуры и интеграция систем',
          'Внедрение low-code и RPA-платформ, настройка сценариев',
          'Управление изменениями и обучение сотрудников'
        ]
      }
    ],
    []
  );

  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>Услуги «Плюс» — цифровая стратегия, данные, продукты</title>
        <meta
          name="description"
          content="Комплекс услуг по цифровой трансформации: стратегия, продукты, аналитика, автоматизация процессов и управление изменениями."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Наша экспертиза</h1>
          <p>
            Мы соединяем стратегию, технологию и культуру, чтобы цифровая трансформация приносила измеримый эффект. Работая с нами, компании получают команду, которая доводит инициативы до результата.
          </p>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.servicesLayout}>
            <div className={styles.tabs} role="tablist">
              {serviceCategories.map((category, index) => (
                <button
                  key={category.title}
                  type="button"
                  className={`${styles.tabButton} ${activeIndex === index ? styles.tabActive : ''}`}
                  onClick={() => setActiveIndex(index)}
                  role="tab"
                  aria-selected={activeIndex === index}
                >
                  {category.title}
                </button>
              ))}
            </div>
            <div className={styles.tabContent} role="tabpanel">
              <h2>{serviceCategories[activeIndex].title}</h2>
              <p className={styles.tabSummary}>{serviceCategories[activeIndex].summary}</p>
              <ul className={styles.tabList}>
                {serviceCategories[activeIndex].bulletPoints.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
              <div className={styles.cta}>
                <p>Хотите обсудить конкретную задачу? Мы с радостью поделимся кейсами и подходом.</p>
                <Link to="/kontakty" className={styles.ctaButton}>
                  Обсудить проект
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.formatsSection}>
        <div className="container">
          <h2>Форматы сотрудничества</h2>
          <div className={styles.formatsGrid}>
            <article>
              <h3>Стратегические программы</h3>
              <p>Долгосрочное партнёрство для управления трансформацией — от стратегии до внедрения и масштабирования.</p>
            </article>
            <article>
              <h3>Пилоты и MVP</h3>
              <p>Быстрые эксперименты и пилотные запуски, которые помогают проверить гипотезы и подготовиться к масштабированию.</p>
            </article>
            <article>
              <h3>Экспертное сопровождение</h3>
              <p>Точечная поддержка в важных задачах: аудит, архитектура, запуск продуктовых направлений, наставничество команд.</p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;