import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  const sections = useMemo(
    () => [
      {
        title: 'Какие данные мы обрабатываем',
        content:
          'Мы можем обрабатывать контактные данные, которые вы предоставляете добровольно через формы обратной связи, а также обезличенную статистику посещений сайта.'
      },
      {
        title: 'Цели обработки данных',
        content:
          'Персональные данные используются для ответа на ваши запросы, подготовки коммерческих предложений и улучшения качества сервисов.'
      },
      {
        title: 'Передача и хранение',
        content:
          'Мы не передаём ваши данные третьим лицам без вашего согласия, за исключением случаев, предусмотренных законом. Данные хранятся на защищённых серверах в соответствии с нормативными требованиями.'
      },
      {
        title: 'Права пользователя',
        content:
          'Вы можете запросить информацию об обработке данных, потребовать их уточнения или удаления. Для этого напишите на info@plus-consulting.ru.'
      }
    ],
    []
  );

  const [active, setActive] = useState(0);

  return (
    <>
      <Helmet>
        <title>Политика конфиденциальности — «Плюс»</title>
        <meta
          name="description"
          content="Политика конфиденциальности компании «Плюс»: обработка персональных данных, цели и права пользователей."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Политика конфиденциальности</h1>
          <p>Мы бережно относимся к вашим данным и соблюдаем требования законодательства о персональных данных.</p>
        </div>
      </section>

      <section className={styles.contentSection}>
        <div className="container">
          <div className={styles.tabs} role="tablist">
            {sections.map((section, index) => (
              <button
                key={section.title}
                type="button"
                className={`${styles.tabButton} ${active === index ? styles.tabActive : ''}`}
                onClick={() => setActive(index)}
                role="tab"
                aria-selected={active === index}
              >
                {section.title}
              </button>
            ))}
          </div>
          <div className={styles.panel} role="tabpanel">
            <p>{sections[active].content}</p>
          </div>
          <p className={styles.footerNote}>
            Для уточнений и запросов по обработке данных напишите нам: <a href="mailto:info@plus-consulting.ru">info@plus-consulting.ru</a>
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;