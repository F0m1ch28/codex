import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  const [detailsOpen, setDetailsOpen] = useState(false);

  return (
    <>
      <Helmet>
        <title>Политика cookies — «Плюс»</title>
        <meta name="description" content="Информация о том, как компания «Плюс» использует файлы cookies на сайте." />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Политика использования файлов cookies</h1>
          <p>Мы используем cookies для корректной работы сайта и аналитики. Ниже описано, какие файлы применяются и как их контролировать.</p>
        </div>
      </section>

      <section className={styles.contentSection}>
        <div className="container">
          <article className={styles.card}>
            <h2>Что такое cookies</h2>
            <p>
              Cookies — это небольшие фрагменты данных, которые сохраняются в браузере пользователя. Они помогают запоминать ваши настройки и улучшать качество сервисов.
            </p>
          </article>

          <article className={styles.card}>
            <h2>Как мы используем cookies</h2>
            <ul>
              <li>Технические cookies обеспечивают корректную работу сайта.</li>
              <li>Аналитические cookies помогают понять, какие материалы наиболее востребованы.</li>
            </ul>
          </article>

          <article className={styles.card}>
            <h2>Управление cookies</h2>
            <p>
              Вы можете ограничить или отключить использование cookies в настройках вашего браузера. Это не повлияет на доступ к контенту, но некоторые функции могут работать некорректно.
            </p>
            <button
              type="button"
              className={styles.toggle}
              onClick={() => setDetailsOpen((prev) => !prev)}
              aria-expanded={detailsOpen}
            >
              {detailsOpen ? 'Скрыть инструкции' : 'Инструкции для популярных браузеров'}
            </button>
            {detailsOpen && (
              <ul className={styles.instructions}>
                <li>Chrome: Настройки → Конфиденциальность и безопасность → Файлы cookie и другие данные сайтов.</li>
                <li>Firefox: Настройки → Приватность и безопасность → Cookies и данные сайтов.</li>
                <li>Safari: Настройки → Конфиденциальность → Управление данными веб-сайтов.</li>
              </ul>
            )}
          </article>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;