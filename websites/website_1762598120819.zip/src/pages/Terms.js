import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  const sections = useMemo(
    () => [
      {
        title: '1. Общие положения',
        content:
          'Настоящие Условия использования регулируют отношения между пользователями сайта и ООО «Плюс Консалтинг». Используя сайт, вы подтверждаете согласие с условиями и обязуетесь их соблюдать.'
      },
      {
        title: '2. Интеллектуальная собственность',
        content:
          'Все материалы, опубликованные на сайте, являются объектами интеллектуальной собственности. Любое копирование или использование материалов допускается только с письменного согласия правообладателя.'
      },
      {
        title: '3. Ответственность',
        content:
          'Информация на сайте публикуется для ознакомления. Мы прилагаем усилия для её актуальности, однако не гарантируем полноту и точность. Компания не несёт ответственности за возможные убытки, возникшие при использовании информации.'
      },
      {
        title: '4. Конфиденциальность',
        content:
          'Мы соблюдаем Политику конфиденциальности и обрабатываем персональные данные в соответствии с действующим законодательством. Детали и права пользователей описаны в отдельном документе.'
      },
      {
        title: '5. Изменение условий',
        content:
          'Компания имеет право изменять настоящие Условия использования. Обновлённая версия вступает в силу с момента публикации на сайте. Рекомендуем регулярно проверять актуальность документа.'
      }
    ],
    []
  );

  const [expanded, setExpanded] = useState(() => sections.map(() => false));

  const toggleSection = (index) => {
    setExpanded((prev) => prev.map((value, idx) => (idx === index ? !value : value)));
  };

  return (
    <>
      <Helmet>
        <title>Условия использования — «Плюс»</title>
        <meta name="description" content="Правила использования сайта компании «Плюс Консалтинг»." />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Условия использования</h1>
          <p>Пожалуйста, ознакомьтесь с нашими условиями до использования материалов и сервисов сайта.</p>
        </div>
      </section>

      <section className={styles.contentSection}>
        <div className="container">
          <div className={styles.accordion}>
            {sections.map((section, index) => (
              <article key={section.title} className={styles.item}>
                <button
                  type="button"
                  onClick={() => toggleSection(index)}
                  className={styles.header}
                  aria-expanded={expanded[index]}
                >
                  <span>{section.title}</span>
                  <span>{expanded[index] ? '−' : '+'}</span>
                </button>
                {expanded[index] && <p className={styles.body}>{section.content}</p>}
              </article>
            ))}
          </div>
          <p className={styles.note}>
            Если у вас возникли вопросы, свяжитесь с нами по адресу info@plus-consulting.ru.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;