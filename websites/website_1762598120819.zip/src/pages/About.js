import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  const values = useMemo(
    () => [
      {
        title: 'Партнёрство и вовлечённость',
        description:
          'Работаем как часть вашей команды. Погружаемся в контекст, разделяем ответственность за результат и выстраиваем открытый диалог на всех уровнях.'
      },
      {
        title: 'Практика и измеримость',
        description:
          'Ценим действия больше слов. Каждая инициатива имеет понятные метрики и план внедрения — от пилота до масштабирования.'
      },
      {
        title: 'Комбинация экспертиз',
        description:
          'Соединяем стратегию, продуктовый подход, дизайн и инженерный опыт. Это помогает находить решения, которые работают на всех горизонтах.'
      }
    ],
    []
  );

  const [activeValueIndex, setActiveValueIndex] = useState(0);

  const leadership = useMemo(
    () => [
      {
        name: 'Игорь Михайлов',
        role: 'Управляющий партнёр',
        experience:
          'Фокус на цифровой стратегии, организации трансформационных программ и управлении продуктовым портфелем. Работал в крупнейших консалтинговых компаниях и возглавлял направление цифрового развития в телеком-холдинге.',
        image: 'https://picsum.photos/420/420?random=501'
      },
      {
        name: 'Наталья Кручинина',
        role: 'Партнёр по данным и аналитике',
        experience:
          '15 лет опыта в построении дата-офисов, запуске BI-платформ и внедрении управления данными. Успешно реализовала более 30 проектов по внедрению data-driven подхода в финансовых и промышленных компаниях.',
        image: 'https://picsum.photos/420/420?random=502'
      },
      {
        name: 'Алексей Титов',
        role: 'Партнёр по продуктам и дизайну',
        experience:
          'Руководил разработкой цифровых сервисов в банковском и ритейл-сегментах. Эксперт в сервис-дизайне, управлении гибридными командами и создании продуктов, ориентированных на реальные потребности пользователей.',
        image: 'https://picsum.photos/420/420?random=503'
      }
    ],
    []
  );

  const timeline = useMemo(
    () => [
      {
        year: '2018',
        title: 'Создание команды',
        description:
          'Всё началось с объединения консультантов, product lead и архитекторов данных для запуска первых трансформационных проектов.'
      },
      {
        year: '2019',
        title: 'Первые крупные проекты',
        description:
          'Реализовали цифровую стратегию для федерального ритейлера и запустили инициативы по управлению данными в финансовом секторе.'
      },
      {
        year: '2021',
        title: 'Выход на международные рынки',
        description:
          'Расширили географию проектов: запустили программу модернизации процессов для производственной компании в Европе.'
      },
      {
        year: '2023',
        title: 'Инновационные лаборатории',
        description:
          'Создали лабораторию цифровых экспериментов, где вместе с клиентами тестируем новые технологии и продуктовые подходы.'
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>О компании «Плюс» — команда и подход</title>
        <meta
          name="description"
          content="Узнайте больше о консалтинговой фирме «Плюс»: наша миссия, команда и подход к цифровым трансформациям."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div>
              <h1>О компании «Плюс»</h1>
              <p>
                Мы строим цифровые стратегии и внедряем технологии, которые помогают бизнесу быть гибким, эффективным и востребованным. Наш путь — это путь людей, которые любят реальные изменения.
              </p>
            </div>
            <div className={styles.heroDetails}>
              <div>
                <span className={styles.heroLabel}>Штаб-квартира</span>
                <p className={styles.heroValue}>Москва</p>
              </div>
              <div>
                <span className={styles.heroLabel}>География проектов</span>
                <p className={styles.heroValue}>Россия, СНГ, Европа</p>
              </div>
              <div>
                <span className={styles.heroLabel}>Отрасли</span>
                <p className={styles.heroValue}>Финансы • Ритейл • Производство • Телеком • HoReCa</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.missionSection}>
        <div className="container">
          <div className={styles.missionContent}>
            <div className={styles.missionText}>
              <h2>Наша миссия</h2>
              <p>
                Создавать цифровые экосистемы, которые раскрывают потенциал людей и бизнеса. Для этого мы объединяем стратегию, технологическую экспертизу и работу с культурой.
              </p>
              <p>
                Мы убеждены: успешная трансформация возможна, когда команда готова экспериментировать, быстро тестировать гипотезы и строить решения вокруг потребностей клиентов.
              </p>
            </div>
            <div className={styles.values}>
              <h3>Что нас отличает</h3>
              <div className={styles.valuesSwitcher} role="tablist">
                {values.map((value, index) => (
                  <button
                    key={value.title}
                    type="button"
                    className={`${styles.valueButton} ${activeValueIndex === index ? styles.valueButtonActive : ''}`}
                    onClick={() => setActiveValueIndex(index)}
                    role="tab"
                    aria-selected={activeValueIndex === index}
                  >
                    {value.title}
                  </button>
                ))}
              </div>
              <p className={styles.valueDescription}>{values[activeValueIndex].description}</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.timelineSection} aria-label="Ключевые этапы развития">
        <div className="container">
          <h2>Как мы развивались</h2>
          <div className={styles.timelineGrid}>
            {timeline.map((item) => (
              <article key={item.year} className={styles.timelineCard}>
                <span className={styles.timelineYear}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.leadershipSection} aria-label="Лидеры команды">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Лидеры и партнеры</h2>
            <p>Погружены в задачи клиентов и лично курируют ключевые инициативы.</p>
          </div>
          <div className={styles.leadershipGrid}>
            {leadership.map((leader) => (
              <article key={leader.name} className={styles.leadershipCard}>
                <div className={styles.leadershipImageWrapper}>
                  <img src={leader.image} alt={`${leader.name} — ${leader.role}`} loading="lazy" />
                </div>
                <div className={styles.leadershipContent}>
                  <h3>{leader.name}</h3>
                  <p className={styles.leadershipRole}>{leader.role}</p>
                  <p className={styles.leadershipExperience}>{leader.experience}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cultureSection}>
        <div className="container">
          <div className={styles.cultureContent}>
            <div>
              <h2>Культура и принципы работы</h2>
              <p>
                Мы строим команды под конкретную задачу и делимся экспертизой на всех этапах. Высокий уровень вовлечённости, открытая коммуникация и гибкий формат взаимодействия — основа нашей культуры.
              </p>
            </div>
            <ul className={styles.principlesList}>
              <li>
                <span>Сделано вместе</span>
                <p>Проектируем решения совместно с командой клиента, чтобы внедрение было быстрым и устойчивым.</p>
              </li>
              <li>
                <span>От идеи до эффекта</span>
                <p>Двигаемся короткими циклами: исследования, пилоты, масштабирование. Каждому этапу — понятные метрики.</p>
              </li>
              <li>
                <span>Непрерывное обучение</span>
                <p>Встроенные воркшопы, менторство и обучение — часть любого проекта. Наша цель — передать знания и инструменты.</p>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;