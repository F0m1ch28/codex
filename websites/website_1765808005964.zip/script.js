document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  const body = document.body;

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      siteNav.classList.toggle("open");
      navToggle.classList.toggle("open");
      body.classList.toggle("nav-open");
    });

    siteNav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        siteNav.classList.remove("open");
        navToggle.classList.remove("open");
        body.classList.remove("nav-open");
      });
    });
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("[data-accept]");
    const declineBtn = cookieBanner.querySelector("[data-decline]");
    const consent = localStorage.getItem("cvaCookieConsent");

    if (!consent) {
      cookieBanner.classList.add("is-visible");
    }

    const closeBanner = (value) => {
      localStorage.setItem("cvaCookieConsent", value);
      cookieBanner.classList.remove("is-visible");
    };

    acceptBtn?.addEventListener("click", () => closeBanner("accepted"));
    declineBtn?.addEventListener("click", () => closeBanner("declined"));
  }

  document.querySelectorAll("[data-tabs]").forEach(tabComponent => {
    const tabButtons = tabComponent.querySelectorAll('[role="tab"]');
    const tabPanels = tabComponent.querySelectorAll('[role="tabpanel"]');

    tabButtons.forEach(button => {
      button.addEventListener("click", () => {
        const target = button.getAttribute("aria-controls");

        tabButtons.forEach(btn => btn.setAttribute("aria-selected", "false"));
        tabPanels.forEach(panel => panel.classList.remove("is-active"));

        button.setAttribute("aria-selected", "true");
        tabComponent.querySelector(`#${target}`)?.classList.add("is-active");
      });
    });
  });

  document.querySelectorAll(".faq-item").forEach(item => {
    const trigger = item.querySelector(".faq-question");
    trigger?.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");
      document.querySelectorAll(".faq-item").forEach(i => i.classList.remove("open"));
      if (!isOpen) {
        item.classList.add("open");
      }
    });
  });

  const contactForm = document.querySelector("[data-contact-form]");
  if (contactForm) {
    const formMessage = contactForm.querySelector(".form-message");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formValid = contactForm.checkValidity();
      if (formValid) {
        formMessage.textContent = "Thank you. Our consulting team will contact you within one business day.";
        formMessage.classList.add("is-visible");
        contactForm.reset();
      } else {
        formMessage.textContent = "Please review the highlighted fields.";
        formMessage.classList.add("is-visible");
      }
    });
  }
});