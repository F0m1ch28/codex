import Seo from '../components/Seo';
import styles from './Legal.module.css';

const Privacy = () => {
  return (
    <>
      <Seo
        title="Privacy Policy"
        description="Learn how Lingua Academy collects, processes, and protects personal data in accordance with GDPR and Dutch privacy regulations."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Legal</span>
          <h1 className="sectionTitle">Privacy Policy</h1>
          <p className="sectionSubtitle">
            Lingua Academy is committed to safeguarding your personal data in accordance
            with the EU General Data Protection Regulation (GDPR) and Dutch privacy laws.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.legalCard}>
            <h2>1. Data Controller</h2>
            <p>
              Lingua Academy B.V., based in Amsterdam, acts as the data controller for all
              personal data collected through our website, platform, and services.
            </p>

            <h2>2. Types of Data Collected</h2>
            <ul>
              <li>Contact information and learner profile details.</li>
              <li>Session attendance records, assignments, and feedback logs.</li>
              <li>Technical data such as device type, browser, and analytics cookies.</li>
            </ul>

            <h2>3. Purpose of Processing</h2>
            <p>
              We process data to deliver services, maintain learner accounts, communicate
              programme updates, improve our offerings, and comply with legal obligations.
            </p>

            <h2>4. Legal Basis</h2>
            <p>
              Processing is based on contract performance, legitimate interest, and, where
              applicable, your explicit consent. You may withdraw consent at any time.
            </p>

            <h2>5. Data Sharing</h2>
            <p>
              We only share data with trusted service providers (e.g., video platforms,
              analytics tools) who operate under GDPR-compliant agreements.
            </p>

            <h2>6. Data Retention</h2>
            <p>
              Personal data is retained for as long as necessary to provide services and
              comply with legal requirements. You may request deletion or portability of
              your data.
            </p>

            <h2>7. Your Rights</h2>
            <ul>
              <li>Right to access, rectify, or erase personal data.</li>
              <li>Right to restrict processing and object to direct marketing.</li>
              <li>Right to data portability and to lodge a complaint with the Dutch DPA.</li>
            </ul>

            <h2>8. Contact</h2>
            <p>
              For privacy requests, email{' '}
              <a href="mailto:privacy@lingua-academy.nl">privacy@lingua-academy.nl</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Privacy;