import Seo from '../components/Seo';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Seo
        title="Cookie Policy"
        description="Understand how Lingua Academy uses cookies and how you can manage your preferences."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Legal</span>
          <h1 className="sectionTitle">Cookie Policy</h1>
          <p className="sectionSubtitle">
            Lingua Academy uses cookies to deliver secure, personalised experiences. Learn
            about the cookies we use and how to manage your preferences.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.legalCard}>
            <h2>1. What are cookies?</h2>
            <p>
              Cookies are small text files stored on your device. They help us provide core
              functionalities, remember your preferences, and analyse usage to improve our
              services.
            </p>

            <h2>2. Types of cookies we use</h2>
            <ul>
              <li>
                <strong>Essential cookies</strong> – Required for secure sign-in and session
                management.
              </li>
              <li>
                <strong>Analytics cookies</strong> – Help us understand how visitors use the
                platform. These are anonymised and aggregated.
              </li>
              <li>
                <strong>Functional cookies</strong> – Remember language choices and display
                settings.
              </li>
            </ul>

            <h2>3. Managing your preferences</h2>
            <p>
              You can adjust your cookie preferences through the banner on our website or
              via your browser settings. Note that disabling essential cookies may limit
              platform functionality.
            </p>

            <h2>4. Third-party services</h2>
            <p>
              We may embed third-party tools (e.g., video conferencing, analytics) that
              place cookies on your device. These providers operate under their own privacy
              policies.
            </p>

            <h2>5. Updates</h2>
            <p>
              We review this policy regularly to reflect changes in technology and
              regulation. Updates will be posted on this page with a revised effective date.
            </p>

            <h2>6. Contact</h2>
            <p>
              Questions about cookies? Reach us at{' '}
              <a href="mailto:privacy@lingua-academy.nl">privacy@lingua-academy.nl</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;