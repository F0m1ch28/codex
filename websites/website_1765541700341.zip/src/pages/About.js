import Seo from '../components/Seo';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Elena Koster',
    role: 'Academic Director',
    bio: 'Elena has led language innovation projects across the Netherlands for 15 years, blending pedagogy, technology, and inclusive learning practices.',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Dr. Malik Benali',
    role: 'Head of Methodology',
    bio: 'Applied linguist focused on pronunciation coaching and equity in multilingual classrooms. Malik designs the frameworks behind our signature labs.',
    image:
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Sanne Visser',
    role: 'Lead Dutch Coach',
    bio: 'Specialist in integration pathways, civil service exams, and workplace Dutch for international professionals relocating to the Netherlands.',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=601&q=80',
  },
  {
    name: 'Grace O’Connor',
    role: 'Exam Preparation Lead',
    bio: 'British Council-accredited coach guiding learners to success in IELTS, Cambridge, and TOEFL through data-driven study plans.',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
  },
];

const About = () => {
  return (
    <>
      <Seo
        title="About"
        description="Meet Lingua Academy’s international coaching team, discover our teaching philosophy, and explore learner stories from across the Netherlands."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">About Lingua Academy</span>
          <h1 className="sectionTitle">An inclusive home for ambitious language learners</h1>
          <p className="sectionSubtitle">
            Lingua Academy started in Amsterdam with a simple idea: language learning feels
            better when it is personal, purposeful, and joyful. Today, we support learners
            across the Netherlands and beyond with tailored coaching, community, and
            resources.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.story}>
            <div className={styles.storyText}>
              <h2>Our teaching philosophy</h2>
              <p>
                We combine the science of learning with the art of communication. Every
                program includes three pillars: intentional input, courageous output, and
                compassionate feedback. This trio ensures you absorb language, practise
                actively, and evolve through supportive coaching loops.
              </p>
              <p>
                Our coaches draw from professional experience in diplomacy, business,
                education, tech, and the arts. That diversity allows us to tailor content to
                your daily realities—client meetings, university seminars, immigration
                interviews, or family life in the Netherlands.
              </p>
            </div>
            <div className={styles.storyImage}>
              <img
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1000&q=80"
                alt="Lingua Academy team collaborating"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.teamSection} sectionSpacing`}>
        <div className="container">
          <h2 className="sectionTitle">Meet the leadership team</h2>
          <p className="sectionSubtitle">
            Our team mixes academic expertise with real-world experience. We build bridges
            between cultures, careers, and communities.
          </p>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`${member.name}, ${member.role}`} />
                <div>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} sectionSpacing`}>
        <div className="container">
          <div className={styles.testimonialCard}>
            <h2>Learning journeys that inspire us</h2>
            <div className={styles.testimonialGrid}>
              <blockquote>
                “Lingua Academy helped our Rotterdam engineering team work fluently in
                German and Dutch within six months. The blend of corporate training and
                cultural coaching made the difference.”
                <cite>— Petra Schneider, HR Director</cite>
              </blockquote>
              <blockquote>
                “As an international student, I needed IELTS prep and Dutch integration.
                The coaches coordinated seamlessly, and I felt supported every step of the
                way.”
                <cite>— Aditya Sharma, MSc Student</cite>
              </blockquote>
              <blockquote>
                “Our family lessons are a highlight each week. The children learn through
                stories and games, while we practise real conversations for daily life in
                Amsterdam.”
                <cite>— Sofía & Lennart, Family Track</cite>
              </blockquote>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;