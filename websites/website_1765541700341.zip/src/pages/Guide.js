import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Guide.module.css';

const Guide = () => {
  return (
    <>
      <Seo
        title="Platform Guide"
        description="Navigate the Lingua Academy platform with ease. Follow our step-by-step guide to explore programs, track progress, and book sessions."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Platform Guide</span>
          <h1 className="sectionTitle">Navigate your Lingua Academy experience</h1>
          <p className="sectionSubtitle">
            We designed our platform to be intuitive, secure, and multilingual. Follow this
            guide to explore programs, access resources, and manage your learning journey
            wherever you are in the Netherlands.
          </p>
        </div>
      </section>

      <section className={`${styles.steps} sectionSpacing`}>
        <div className="container">
          <div className={styles.stepGrid}>
            <article className={styles.stepCard}>
              <span className={styles.stepNumber}>01</span>
              <h2>Create your learner profile</h2>
              <p>
                Start by sharing your goals, target language, current level, and preferred
                schedule. This helps us recommend relevant programs and match you with the
                right coaches.
              </p>
              <ul>
                <li>Choose between individual, group, or corporate pathways</li>
                <li>Set availability across CET time slots</li>
                <li>Indicate any upcoming exams or relocation plans</li>
              </ul>
            </article>

            <article className={styles.stepCard}>
              <span className={styles.stepNumber}>02</span>
              <h2>Explore recommended programs</h2>
              <p>
                Browse curated course suggestions based on your profile. Filter by skill
                focus, location (Amsterdam, Rotterdam, The Hague, online), and session
                format.
              </p>
              <ul>
                <li>Compare syllabi, learning outcomes, and coach expertise</li>
                <li>View sample lesson plans and resource previews</li>
                <li>Use the calendar integration to check live availability</li>
              </ul>
            </article>

            <article className={styles.stepCard}>
              <span className={styles.stepNumber}>03</span>
              <h2>Book a discovery call</h2>
              <p>
                Schedule a 20-minute consultation with a Lingua Advisor to confirm the best
                fit. We will discuss your objectives, timeline, and any organisational
                requirements.
              </p>
              <ul>
                <li>Meet via secure video call or visit our Amsterdam studio</li>
                <li>Receive a personalised action plan within 24 hours</li>
                <li>Invite colleagues or family members to join the call</li>
              </ul>
            </article>

            <article className={styles.stepCard}>
              <span={styles.stepNumber}>04</span>
              <h2>Activate your learning hub</h2>
              <p>
                Once you enrol, unlock the Lingua Hub—your central dashboard for session
                links, assignments, coach feedback, and progress analytics.
              </p>
              <ul>
                <li>Track CEFR milestones with visual dashboards</li>
                <li>Message your coach securely and share voice notes</li>
                <li>Access the resource library, events calendar, and community forums</li>
              </ul>
            </article>

            <article className={styles.stepCard}>
              <span className={styles.stepNumber}>05</span>
              <h2>Measure, reflect, celebrate</h2>
              <p>
                Every month, you and your coach review achievements, celebrate wins, and
                adjust the roadmap. We also provide certificates of attainment aligned with
                European standards.
              </p>
              <ul>
                <li>Receive comprehensive feedback reports</li>
                <li>Join peer showcase events and practice circles</li>
                <li>Plan your next milestone—exam, relocation, or new role</li>
              </ul>
            </article>
          </div>

          <div className={styles.guideCta}>
            <h2>Need a hand getting started?</h2>
            <p>
              Our support team is available Monday to Saturday to walk you through the
              platform in English, Dutch, Spanish, or French.
            </p>
            <div className={styles.actions}>
              <Link to="/contact" className="btnPrimary">
                Contact Support
              </Link>
              <Link to="/programs" className="btnSecondary">
                Browse Programs
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Guide;