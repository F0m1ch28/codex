import { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import Seo from '../components/Seo';
import blogPosts from '../data/blogPosts';
import styles from './BlogPost.module.css';

const BlogPost = () => {
  const { postSlug } = useParams();

  const post = useMemo(
    () => blogPosts.find((item) => item.slug === postSlug),
    [postSlug]
  );

  if (!post) {
    return (
      <>
        <Seo title="Post Not Found" description="Requested blog post not available." />
        <section className="sectionSpacing">
          <div className="container">
            <div className={styles.notFound}>
              <h1>Post not found</h1>
              <p>The article you requested may have been moved. Explore other stories.</p>
              <Link to="/blog" className="btnPrimary">
                Back to blog
              </Link>
            </div>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <Seo title={post.title} description={post.excerpt} />
      <article className={`${styles.article} sectionSpacing`}>
        <div className="container">
          <Link to="/blog" className={styles.backLink}>
            ← All articles
          </Link>
          <div className={styles.header}>
            <span className="tag">{post.category}</span>
            <h1>{post.title}</h1>
            <div className={styles.meta}>
              <span>{new Date(post.date).toLocaleDateString('en-NL')}</span>
              <span>•</span>
              <span>By {post.author}</span>
            </div>
          </div>
          <img src={post.image} alt={post.title} className={styles.heroImage} />
          <div className={styles.content}>
            {post.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
          <div className={styles.share}>
            <p>Enjoyed this read? Share it with your learning circle or join an upcoming masterclass.</p>
            <div className={styles.actions}>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="btnSecondary"
              >
                Share on LinkedIn
              </a>
              <Link to="/programs" className="btnPrimary">
                Discover Programs
              </Link>
            </div>
          </div>
        </div>
      </article>
    </>
  );
};

export default BlogPost;