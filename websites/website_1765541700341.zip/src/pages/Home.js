import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const heroImage =
  'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1600&q=80';

const testimonialsData = [
  {
    name: 'María Rodríguez',
    role: 'Marketing Manager, Utrecht',
    quote:
      'The Spanish Conversation Lab reignited my fluency. Every session combines lively culture with precise feedback, and I now lead bilingual campaigns with ease.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Kenji Sato',
    role: 'Software Engineer, Eindhoven',
    quote:
      'Business English Mastery transformed my client presentations. The coaching team drilled into every detail and aligned perfectly with European business etiquette.',
    image: 'https://images.unsplash.com/photo-1528892952291-009c663ce843?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Anouk Janssens',
    role: 'Policy Advisor, The Hague',
    quote:
      'French for Diplomacy is the most relevant training I have ever taken. Simulated EU councils prepared me for real negotiations and elevated my confidence.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
  },
];

const languages = [
  'Dutch',
  'English',
  'Spanish',
  'French',
  'German',
  'Italian',
  'Portuguese',
  'Arabic',
  'Mandarin',
  'Japanese',
  'Norwegian',
  'Polish',
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <Seo
        title="Home"
        description="Discover Lingua Academy’s tailored language courses in the Netherlands. Explore immersive programs, expert coaches, and inspiring learner stories."
      />
      <section
        className={styles.hero}
        style={{ backgroundImage: `linear-gradient(rgba(19,35,71,0.55), rgba(19,35,71,0.55)), url(${heroImage})` }}
      >
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <span className="tag">Amsterdam • Rotterdam • The Hague • Online</span>
            <h1>Speak with confidence in every European conversation</h1>
            <p>
              Lingua Academy connects you with certified language coaches who understand
              your goals in the Netherlands. From personalised tutoring to vibrant group
              sessions, every program blends cultural insight with measurable progress.
            </p>
            <div className={styles.heroActions}>
              <Link to="/programs" className="btnPrimary">
                Explore Our Courses
              </Link>
              <Link to="/contact" className="btnSecondary">
                Book a discovery call
              </Link>
            </div>
          </div>
          <div className={styles.heroStats}>
            <div className={styles.statCard}>
              <strong>30+</strong>
              <span>Expert language coaches</span>
            </div>
            <div className={styles.statCard}>
              <strong>18</strong>
              <span>Languages available</span>
            </div>
            <div className={styles.statCard}>
              <strong>92%</strong>
              <span>Achieve their language goals within 6 months</span>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing`}>
        <div className="container">
          <div className={styles.whyHeader}>
            <span className="tag">Why Choose Lingua Academy?</span>
            <h2 className="sectionTitle">We design pathways for real-life fluency</h2>
            <p className="sectionSubtitle">
              Whether you are preparing for Dutch integration exams, European boardrooms,
              or multilingual adventures, our programs deliver the structure, momentum,
              and community that make language learning stick.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <article className={styles.whyCard}>
              <span role="img" aria-hidden="true">
                🎯
              </span>
              <h3>Personal learning roadmaps</h3>
              <p>
                Receive adaptive study plans mapped to the CEFR framework, ensuring you
                always know the next skill to master.
              </p>
            </article>
            <article className={styles.whyCard}>
              <span role="img" aria-hidden="true">
                🤝
              </span>
              <h3>Coaches who partner with you</h3>
              <p>
                Our certified tutors bring cross-cultural experience and formative feedback
                to every session, both in-person and online.
              </p>
            </article>
            <article className={styles.whyCard}>
              <span role="img" aria-hidden="true">
                🌍
              </span>
              <h3>European context built in</h3>
              <p>
                Learn the vocabulary, etiquette, and professional norms that matter across
                the Netherlands and the wider EU.
              </p>
            </article>
            <article className={styles.whyCard}>
              <span role="img" aria-hidden="true">
                📊
              </span>
              <h3>Progress you can see</h3>
              <p>
                Track your skills with milestone dashboards, pronunciation diagnostics,
                and monthly coach reviews.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.methodsSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.methodsHeader}>
            <span className="tag">Featured Learning Methods</span>
            <h2 className="sectionTitle">Choose between individual coaching and dynamic groups</h2>
            <p className="sectionSubtitle">
              Balance tailored attention with collaborative practice. Our learning formats
              blend technology with human coaching to maximise engagement, accountability,
              and joy.
            </p>
          </div>
          <div className={styles.methodsGrid}>
            <article className={styles.methodCard}>
              <img
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=900&q=80"
                alt="Language coach guiding a learner via laptop"
              />
              <div className={styles.methodContent}>
                <h3>Signature 1:1 Coaching</h3>
                <p>
                  Dive deeply into your goals with flexible scheduling, personalised
                  homework loops, and instant feedback on pronunciation, writing, and
                  presentation skills.
                </p>
                <ul>
                  <li>Dedicated coach and progress mentor</li>
                  <li>Weekly focus capsules assigned to your needs</li>
                  <li>Optional immersion days in Amsterdam or The Hague</li>
                </ul>
              </div>
            </article>
            <article className={styles.methodCard}>
              <img
                src="https://images.unsplash.com/photo-1555421689-491a97ff2040?auto=format&fit=crop&w=900&q=80"
                alt="Group of international learners collaborating"
              />
              <div className={styles.methodContent}>
                <h3>Curated Group Labs</h3>
                <p>
                  Experience dynamic group sessions capped at eight learners. Collaborate,
                  debate, and celebrate milestones together in safe, multilingual spaces.
                </p>
                <ul>
                  <li>Topic-based labs with real-time coaching</li>
                  <li>Peer feedback guided by expert facilitators</li>
                  <li>Language exchange forums for additional practice</li>
                </ul>
              </div>
            </article>
            <article className={styles.methodCard}>
              <img
                src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=900&q=80"
                alt="Corporate team participating in a workshop"
              />
              <div className={styles.methodContent}>
                <h3>Corporate & Campus Programs</h3>
                <p>
                  Empower teams with language strategies customised for onboarding,
                  leadership, or exam readiness. We align with HR, L&D, and academic goals.
                </p>
                <ul>
                  <li>Bespoke learning pathways for organisations</li>
                  <li>Impact reporting aligned with ESG priorities</li>
                  <li>On-site and digital delivery across the Netherlands</li>
                </ul>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.languagesSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.languagesHeader}>
            <span className="tag">Our Languages</span>
            <h2 className="sectionTitle">From local integration to global fluency</h2>
            <p className="sectionSubtitle">
              We specialise in European languages while curating dedicated tracks for key
              global markets. Each pathway is powered by native coaches and cultural
              experts.
            </p>
          </div>
          <div className={styles.languageGrid}>
            {languages.map((language) => (
              <div key={language} className={styles.languageItem}>
                {language}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} sectionSpacing`}>
        <div className="container">
          <div className={styles.testimonialHeader}>
            <span className="tag">Testimonials</span>
            <h2 className="sectionTitle">Learners growing with Lingua Academy</h2>
            <p className="sectionSubtitle">
              Thousands of professionals, students, and families across the Netherlands
              have elevated their communication skills through our programs.
            </p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonialsData.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
              >
                <img src={testimonial.image} alt={`${testimonial.name} portrait`} />
                <blockquote>“{testimonial.quote}”</blockquote>
                <p className={styles.testimonialName}>{testimonial.name}</p>
                <span className={styles.testimonialRole}>{testimonial.role}</span>
              </div>
            ))}
          </div>
          <div className={styles.testimonialControls}>
            {testimonialsData.map((_, index) => (
              <button
                key={index}
                type="button"
                onClick={() => setActiveTestimonial(index)}
                className={`${styles.dot} ${
                  index === activeTestimonial ? styles.dotActive : ''
                }`}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.resources} sectionSpacing`} id="resources">
        <div className="container">
          <div className={styles.resourcesInner}>
            <div>
              <span className="tag">Free Learning Resources</span>
              <h2 className="sectionTitle">Keep learning between sessions</h2>
              <p className="sectionSubtitle">
                Access curated grammar checklists, pronunciation podcasts, cultural
                briefings, and interactive quizzes—available to all learners and visitors.
              </p>
              <Link to="/tools" className="btnPrimary">
                Visit the Resource Library
              </Link>
            </div>
            <div className={styles.resourceHighlights}>
              <div>
                <h3>Weekly live micro-classes</h3>
                <p>Stay inspired with 20-minute booster sessions hosted on Fridays.</p>
              </div>
              <div>
                <h3>EU culture playlists</h3>
                <p>
                  Explore the music, films, and news that keep your target language alive
                  between lessons.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.finalCta} sectionSpacing`}>
        <div className="container">
          <div className={styles.finalCtaInner}>
            <h2>Ready to start your next language chapter?</h2>
            <p>
              Connect with a Lingua Advisor to map out the best program for your goals. We
              offer complimentary consultations for individuals, families, and teams.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contact" className="btnPrimary">
                Schedule a consultation
              </Link>
              <Link to="/guide" className="btnSecondary">
                Explore the platform guide
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;