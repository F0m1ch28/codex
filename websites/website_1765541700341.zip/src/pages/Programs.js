import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import courses from '../data/courses';
import styles from './Programs.module.css';

const Programs = () => {
  return (
    <>
      <Seo
        title="Programs"
        description="Review Lingua Academy’s language programs. Discover Dutch, English, Spanish, French, German, and exam preparation courses designed for life in the Netherlands."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Language Programs</span>
          <h1 className="sectionTitle">Find the programme that fits your ambitions</h1>
          <p className="sectionSubtitle">
            Every Lingua Academy course is built on real-world scenarios, European cultural
            insight, and measurable outcomes. Browse the highlights below and dive into the
            details that matter to you.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.grid}>
            {courses.map((course) => (
              <article key={course.id} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={course.image} alt={`${course.name} session`} />
                </div>
                <div className={styles.cardContent}>
                  <span className={styles.level}>{course.level}</span>
                  <h2>{course.name}</h2>
                  <p>{course.summary}</p>
                  <Link to={`/programs/${course.id}`} className={styles.detailsLink}>
                    View Details →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.supportCard}>
            <h2>Need personal guidance?</h2>
            <p>
              Book a consultation with our advisors to design a language roadmap for your
              team or family. We will help you compare options and schedule your lessons.
            </p>
            <Link to="/contact" className="btnPrimary">
              Speak to an advisor
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Programs;