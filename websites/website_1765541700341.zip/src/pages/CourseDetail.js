import { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import Seo from '../components/Seo';
import courses from '../data/courses';
import styles from './CourseDetail.module.css';

const CourseDetail = () => {
  const { courseId } = useParams();

  const course = useMemo(
    () => courses.find((item) => item.id === courseId),
    [courseId]
  );

  if (!course) {
    return (
      <>
        <Seo title="Course Not Found" description="Course details not available." />
        <section className="sectionSpacing">
          <div className="container">
            <div className={styles.notFound}>
              <h1>Course not found</h1>
              <p>
                The course you are looking for may have been updated. Explore our latest
                programmes or contact the Lingua Academy team for assistance.
              </p>
              <Link to="/programs" className="btnPrimary">
                Back to Programs
              </Link>
            </div>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <Seo
        title={course.name}
        description={`Discover ${course.name} at Lingua Academy. ${course.summary}`}
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <Link to="/programs" className={styles.backLink}>
            ← All Programs
          </Link>
          <span className="tag">{course.level}</span>
          <h1 className="sectionTitle">{course.name}</h1>
          <p className="sectionSubtitle">{course.summary}</p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.main}>
              <img src={course.image} alt={`${course.name} learners`} />
              <div className={styles.section}>
                <h2>Program Overview</h2>
                <p>{course.description}</p>
              </div>

              <div className={styles.section}>
                <h2>Methodology Highlights</h2>
                <ul>
                  {course.methodology.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className={styles.section}>
                <h2>Learning Outcomes</h2>
                <ul>
                  {course.outcomes.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>
            <aside className={styles.sidebar}>
              <div className={styles.sidebarCard}>
                <h3>Schedule & Format</h3>
                <p>{course.schedule}</p>
                <p>{course.format}</p>
              </div>
              <div className={styles.sidebarCard}>
                <h3>Your Coaching Team</h3>
                <ul>
                  {course.instructors.map((instructor) => (
                    <li key={instructor.name}>
                      <strong>{instructor.name}</strong>
                      <span>{instructor.bio}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className={styles.sidebarCard}>
                <h3>Next Steps</h3>
                <p>
                  Ready to enrol or want to confirm if this program is the right fit? Book a
                  personalised call with our team.
                </p>
                <Link to="/contact" className="btnPrimary">
                  Book consultation
                </Link>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default CourseDetail;