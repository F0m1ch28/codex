import Seo from '../components/Seo';
import styles from './Services.module.css';

const services = [
  {
    title: 'Private Coaching',
    description:
      'Tailor-made sessions for individuals and families with flexible scheduling, personalised materials, and progress tracking that adapts to your goals.',
    image:
      'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=900&q=80',
    highlights: ['Flexible format: in-person or online', 'Dedicated success mentor', 'Monthly impact reports'],
  },
  {
    title: 'Corporate Language Partnerships',
    description:
      'Strategic language upskilling for teams operating across Europe. We integrate language goals with HR and L&D roadmaps for sustainable impact.',
    image:
      'https://images.unsplash.com/photo-1542744094-24638eff58bb?auto=format&fit=crop&w=900&q=80',
    highlights: ['Needs analysis & benchmarking', 'Custom learning hubs & analytics', 'Workshops, labs, and coaching pods'],
  },
  {
    title: 'Exam Preparation',
    description:
      'Expert-led pathways for IELTS, Cambridge, Inburgering, Staatsexamen NT2, and school entrance exams. Includes mock assessments and feedback clinics.',
    image:
      'https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=900&q=80',
    highlights: ['Diagnostic testing & study plans', 'Weekly progress sprints', 'Test-day simulations'],
  },
  {
    title: 'Cultural Integration Experiences',
    description:
      'Immersive workshops and city labs that blend language learning with Dutch culture, helping newcomers feel at home faster.',
    image:
      'https://images.unsplash.com/photo-1531934788014-76a87a66d833?auto=format&fit=crop&w=900&q=80',
    highlights: ['City-based immersion days', 'Cultural etiquette briefings', 'Family & youth programs'],
  },
];

const Services = () => {
  return (
    <>
      <Seo
        title="Services"
        description="Explore Lingua Academy services including private coaching, corporate language partnerships, exam preparation, and cultural integration experiences."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Our Services</span>
          <h1 className="sectionTitle">Comprehensive language services for every journey</h1>
          <p className="sectionSubtitle">
            From executive coaching to family integration, Lingua Academy designs services
            that adapt to your ambitions. Choose the support that matches your timeline,
            context, and preferred learning style.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <img src={service.image} alt={service.title} />
                <div className={styles.content}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                  <ul>
                    {service.highlights.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.cta}>
            <h2>Let’s design your language roadmap</h2>
            <p>
              Our advisory team will help you compare service options, build a roll-out
              plan, and align with your organisational or personal goals.
            </p>
            <a href="/contact" className="btnPrimary">
              Talk to an advisor
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;