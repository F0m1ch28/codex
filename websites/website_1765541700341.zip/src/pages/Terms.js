import Seo from '../components/Seo';
import styles from './Legal.module.css';

const Terms = () => {
  return (
    <>
      <Seo
        title="Terms of Service"
        description="Review Lingua Academy’s terms of service, outlining user responsibilities, course access, and compliance with Dutch and EU regulations."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Legal</span>
          <h1 className="sectionTitle">Terms of Service</h1>
          <p className="sectionSubtitle">
            Effective from January 2024. These Terms govern the use of the Lingua Academy
            platform, courses, and services delivered in the Netherlands and online.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.legalCard}>
            <h2>1. Agreement Overview</h2>
            <p>
              By registering for Lingua Academy services, you acknowledge that you have read
              and agree to these Terms. We operate in accordance with Dutch law and European
              Union consumer protection standards.
            </p>

            <h2>2. Services</h2>
            <p>
              Lingua Academy provides language coaching, group classes, corporate training,
              and digital resources. Programme details, schedules, and learning outcomes are
              available on our website and in enrolment communications.
            </p>

            <h2>3. Learner Responsibilities</h2>
            <ul>
              <li>Provide accurate information when creating your learner profile.</li>
              <li>
                Use the platform respectfully and avoid sharing materials without written
                consent.
              </li>
              <li>
                Inform us of any changes that may affect your participation, such as travel
                or health considerations.
              </li>
            </ul>

            <h2>4. Intellectual Property</h2>
            <p>
              All course content, materials, and recordings are the intellectual property of
              Lingua Academy or our partners. You may access them for personal learning
              purposes only.
            </p>

            <h2>5. Payments & Renewals</h2>
            <p>
              Payment terms are shared during enrolment. Invoices are issued in euros and
              subject to Dutch VAT where applicable. Renewal terms will be communicated
              prior to the end of your programme.
            </p>

            <h2>6. Cancellation & Rescheduling</h2>
            <p>
              We understand that schedules can change. Please review the cancellation policy
              provided with your enrolment confirmation or contact our support team for
              assistance.
            </p>

            <h2>7. Liability</h2>
            <p>
              Lingua Academy exercises due care in delivering services. Our liability is
              limited to the amount paid for the programme in question, except where Dutch
              law stipulates otherwise.
            </p>

            <h2>8. Contact</h2>
            <p>
              Questions about these Terms? Please contact{' '}
              <a href="mailto:info@lingua-academy.nl">info@lingua-academy.nl</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Terms;