import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import blogPosts from '../data/blogPosts';
import styles from './Blog.module.css';

const Blog = () => {
  return (
    <>
      <Seo
        title="Blog"
        description="Read Lingua Academy’s blog for language learning insights, cultural notes, and success stories from learners across the Netherlands."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Lingua Logbook</span>
          <h1 className="sectionTitle">Insights, stories, and strategies for language success</h1>
          <p className="sectionSubtitle">
            Stay inspired with articles from our coaches and learners. We explore learning
            science, European culture, exam preparation, and real stories from the Lingua
            Academy community.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.grid}>
            {blogPosts.map((post) => (
              <article key={post.slug} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={post.image} alt={post.title} />
                </div>
                <div className={styles.content}>
                  <div className={styles.meta}>
                    <span>{new Date(post.date).toLocaleDateString('en-NL')}</span>
                    <span>•</span>
                    <span>{post.category}</span>
                  </div>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.readMore}>
                    Read Article →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;