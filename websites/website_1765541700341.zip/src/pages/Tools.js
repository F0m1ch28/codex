import Seo from '../components/Seo';
import styles from './Tools.module.css';

const resourceCategories = [
  {
    title: 'Grammar Guides',
    description:
      'Clear explanations and downloadable checklists for Dutch, English, Spanish, French, and German.',
    resources: [
      { name: 'Dutch verb tenses cheat sheet', link: 'https://drive.google.com' },
      { name: 'Business English writing style guide', link: 'https://drive.google.com' },
      { name: 'French gender & agreement tracker', link: 'https://drive.google.com' },
    ],
  },
  {
    title: 'Pronunciation Tools',
    description:
      'Interactive IPA charts, shadowing exercises, and voice recognition tools tailored for EU accents.',
    resources: [
      { name: 'Dutch vowel shadowing podcast', link: 'https://spotify.com' },
      { name: 'Speech clarity checklist for presentations', link: 'https://drive.google.com' },
      { name: 'Spanish rhythm & intonation videos', link: 'https://youtube.com' },
    ],
  },
  {
    title: 'Cultural Podcasts',
    description:
      'Curated listening lists featuring European current affairs, arts, and lifestyle stories.',
    resources: [
      { name: 'Dutch news digest for newcomers', link: 'https://spotify.com' },
      { name: 'French culture bites', link: 'https://spotify.com' },
      { name: 'German innovation stories', link: 'https://spotify.com' },
    ],
  },
  {
    title: 'Study Planners',
    description:
      'Ready-to-use templates for organising daily practice, tracking goals, and logging reflections.',
    resources: [
      { name: '30-day conversation challenge planner', link: 'https://drive.google.com' },
      { name: 'IELTS writing tracker', link: 'https://drive.google.com' },
      { name: 'Corporate language upskilling roadmap', link: 'https://drive.google.com' },
    ],
  },
];

const Tools = () => {
  return (
    <>
      <Seo
        title="Tools"
        description="Access Lingua Academy’s free library of grammar guides, pronunciation tools, cultural podcasts, and study planners to support your language journey."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Resource Library</span>
          <h1 className="sectionTitle">Free tools to accelerate your language journey</h1>
          <p className="sectionSubtitle">
            Discover curated resources developed by Lingua Academy coaches. Combine them
            with your live sessions to build consistency and enjoy language learning every
            day.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.grid}>
            {resourceCategories.map((category) => (
              <article key={category.title} className={styles.card}>
                <h2>{category.title}</h2>
                <p>{category.description}</p>
                <ul>
                  {category.resources.map((resource) => (
                    <li key={resource.name}>
                      <a href={resource.link} target="_blank" rel="noreferrer">
                        {resource.name} →
                      </a>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Tools;