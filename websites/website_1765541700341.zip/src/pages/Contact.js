import { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  subject: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!formData.name || !formData.email || !formData.message) {
      setStatus({
        type: 'error',
        message: 'Please complete the required fields: Name, Email, and Message.',
      });
      return;
    }

    setStatus({
      type: 'success',
      message: 'Thank you for reaching out. Our team will respond within two working days.',
    });
    setFormData(initialState);
  };

  return (
    <>
      <Seo
        title="Contact"
        description="Contact Lingua Academy for language course inquiries, partnerships, or support. We respond within two working days."
      />
      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <span className="tag">Contact</span>
          <h1 className="sectionTitle">Let’s start a conversation</h1>
          <p className="sectionSubtitle">
            Share your goals and we will guide you to the right program, coach, or service.
            Lingua Academy advisors respond within two working days.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.formWrapper}>
              <h2>Send us a message</h2>
              <form className={styles.form} onSubmit={handleSubmit}>
                <label htmlFor="name">
                  Name*
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="Your full name"
                  />
                </label>
                <label htmlFor="email">
                  Email*
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    placeholder="your@email.com"
                  />
                </label>
                <label htmlFor="subject">
                  Subject
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="How can we support you?"
                  />
                </label>
                <label htmlFor="message">
                  Message*
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    placeholder="Tell us about your language goals..."
                  />
                </label>
                <button type="submit" className="btnPrimary">
                  Send Message
                </button>
                {status.message && (
                  <p
                    className={status.type === 'success' ? styles.success : styles.error}
                    role="status"
                    aria-live="polite"
                  >
                    {status.message}
                  </p>
                )}
              </form>
            </div>
            <aside className={styles.details}>
              <h2>Contact details</h2>
              <p>
                Visit our Amsterdam campus or connect with us online. We host consultations
                in English, Dutch, Spanish, and French.
              </p>
              <div className={styles.detailBlock}>
                <h3>Address</h3>
                <p>Language Street 123<br />1011 AB Amsterdam<br />Netherlands</p>
              </div>
              <div className={styles.detailBlock}>
                <h3>Phone</h3>
                <p>
                  <a href="tel:+31201234567">+31 20 123 4567</a>
                </p>
              </div>
              <div className={styles.detailBlock}>
                <h3>Email</h3>
                <p>
                  <a href="mailto:info@lingua-academy.nl">info@lingua-academy.nl</a>
                </p>
              </div>
              <div className={styles.detailBlock}>
                <h3>Opening hours</h3>
                <p>Monday – Friday: 08:30 – 19:00 CET<br />Saturday: 10:00 – 14:00 CET</p>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;