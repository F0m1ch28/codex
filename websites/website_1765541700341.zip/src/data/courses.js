const courses = [
  {
    id: 'dutch-beginners',
    name: 'Dutch for Beginners',
    level: 'A1 Starter',
    summary: 'Build everyday Dutch vocabulary and grow confident in conversations.',
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=1200&q=80',
    description:
      'Our Dutch for Beginners track helps newcomers settle smoothly in the Netherlands. Guided by native instructors, you will practice practical dialogues, cultural etiquette, and the essentials of Dutch grammar through immersive sessions.',
    schedule: 'Evening Track · Mondays & Wednesdays · 18:30 – 20:30 CET · 10 weeks',
    format: 'Hybrid mode: live in Amsterdam + interactive virtual classroom',
    methodology: [
      'Scenario-based role-plays focused on Dutch daily life.',
      'Weekly immersion labs at cultural hotspots in Amsterdam.',
      'Personalised pronunciation labs with recorded feedback.',
    ],
    instructors: [
      {
        name: 'Sanne Visser',
        bio: 'Certified Dutch teacher with 12 years of experience helping expats integrate through language.',
      },
      {
        name: 'Jasper de Boer',
        bio: 'Linguist specialising in Dutch phonetics and speech confidence coaching.',
      },
    ],
    outcomes: [
      'Hold essential conversations covering introductions, shopping, and travel.',
      'Understand the fundamentals of Dutch sentence structure.',
      'Navigate administrative tasks such as registering at the gemeente.',
    ],
  },
  {
    id: 'business-english',
    name: 'Business English Mastery',
    level: 'B2–C1 Professional',
    summary: 'Refine executive communication for international careers in Europe.',
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=1200&q=81',
    description:
      'Master corporate communications, negotiation language, and presentation skills tailored to the European business landscape. Ideal for professionals collaborating with multicultural teams.',
    schedule: 'Morning Labs · Tuesdays & Thursdays · 07:30 – 09:00 CET · 8 weeks',
    format: 'Virtual live cohort with micro-coaching and peer feedback sessions',
    methodology: [
      'Case studies built around Dutch and EU business scenarios.',
      'Pitch simulations with video feedback.',
      'Micro-writing sprints focused on emails and reports.',
    ],
    instructors: [
      {
        name: 'Dr. Hannah Collins',
        bio: 'Business communication strategist and former L&D lead in multinational finance.',
      },
      {
        name: 'Robert Janssen',
        bio: 'Executive coach specialising in cross-cultural leadership in the Benelux.',
      },
    ],
    outcomes: [
      'Deliver persuasive presentations with clear structures.',
      'Negotiate confidently with stakeholders across cultures.',
      'Craft concise executive-level writing for board updates.',
    ],
  },
  {
    id: 'spanish-conversation-lab',
    name: 'Spanish Conversation Lab',
    level: 'A2–B1 Conversational',
    summary: 'Stay fluent with live conversation pods led by Iberian and Latin American coaches.',
    image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80',
    description:
      'A conversation-driven program for learners ready to unleash real-world Spanish. Participate in themed dialogues, cultural debates, and pronunciation clinics.',
    schedule: 'Lunch Labs · Mondays & Thursdays · 12:15 – 13:15 CET · 12 weeks',
    format: 'Small-group sessions (max. 6 learners) hosted online',
    methodology: [
      'Weekly cultural spotlights covering Spain and Latin America.',
      'Pronunciation micro-coaching with IPA-based guidance.',
      'Conversation “tiles” to build spontaneity and confidence.',
    ],
    instructors: [
      {
        name: 'Laura Álvarez',
        bio: 'Spanish linguist passionate about intercultural storytelling and theatre.',
      },
      {
        name: 'Felipe Rocha',
        bio: 'Colombian broadcaster bringing radio-style energy to speaking labs.',
      },
    ],
    outcomes: [
      'Discuss travel, gastronomy, and current affairs comfortably.',
      'React spontaneously using natural connectors and idioms.',
      'Understand regional nuances and cultural references.',
    ],
  },
  {
    id: 'french-diplomacy',
    name: 'French for Diplomacy & EU Affairs',
    level: 'B2 Specialist',
    summary: 'Designed for policy experts engaging with Francophone institutions.',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
    description:
      'Blend protocol, persuasive briefing language, and policy debate practice in French. You will rehearse multilingual committee interventions and diplomatic exchanges.',
    schedule: 'Weekend Intensives · Saturday · 09:00 – 13:00 CET · 6 weeks',
    format: 'Live in The Hague + secure hybrid room for remote participants',
    methodology: [
      'Simulated council meetings moderated by former EU interpreters.',
      'Terminology workshops focused on EU law and international relations.',
      'High-stakes role-plays with instant interpreting feedback.',
    ],
    instructors: [
      {
        name: 'Élodie Marchand',
        bio: 'Former EU translator specialising in institutional French.',
      },
      {
        name: 'Paul Vermeer',
        bio: 'International negotiation coach with foreign service background.',
      },
    ],
    outcomes: [
      'Deliver briefings and policy statements with precision.',
      'Negotiate wording in multilingual diplomatic settings.',
      'Maintain composure during Q&A in French.',
    ],
  },
  {
    id: 'german-innovation',
    name: 'German for Innovation & Tech Teams',
    level: 'B1–B2 Professional',
    summary: 'Accelerate your collaboration with German partners in R&D and engineering.',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=80',
    description:
      'Designed for agile teams working with German-speaking stakeholders. Learn technical terminology, agile ceremonies, and meeting etiquette relevant to innovation hubs.',
    schedule: 'Evening Sprints · Tuesdays · 18:00 – 20:00 CET · 12 weeks',
    format: 'Virtual classroom with project-based breakout sessions',
    methodology: [
      'Sprint retrospectives practised in German.',
      'Terminology canvases for engineering and product design.',
      'Listening labs with German startup founders.',
    ],
    instructors: [
      {
        name: 'Claudia Hoffmann',
        bio: 'Engineer-turned-language-coach supporting European tech scale-ups.',
      },
      {
        name: 'Tim Nagel',
        bio: 'Agile facilitator bridging German and Dutch innovation cultures.',
      },
    ],
    outcomes: [
      'Lead agile ceremonies comfortably in German.',
      'Align technical roadmaps with German partners.',
      'Navigate meetings with culturally aware communication.',
    ],
  },
  {
    id: 'ielts-accelerator',
    name: 'IELTS Accelerator Program',
    level: 'Exam Prep',
    summary: 'Sharpen your IELTS performance with targeted skills coaching and mock exams.',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80',
    description:
      'Achieve your IELTS target score with expert coaches, adaptive practice, and personalised feedback aligned with European university requirements.',
    schedule: 'Power Sessions · Mon/Wed/Fri · 17:30 – 19:00 CET · 5 weeks',
    format: 'Hybrid: on-campus in Amsterdam Science Park + remote labs',
    methodology: [
      'Band-score diagnostics with tailored improvement plans.',
      'Speaking mock interviews recorded for detailed analysis.',
      'Essay writing studios with peer review and instructor annotations.',
    ],
    instructors: [
      {
        name: 'Grace O’Connor',
        bio: 'British Council-accredited IELTS specialist with a focus on academic writing.',
      },
      {
        name: 'Erik van Leeuwen',
        bio: 'Assessment expert guiding learners through test-day strategies.',
      },
    ],
    outcomes: [
      'Understand exactly how IELTS band descriptors are applied.',
      'Confidently structure high-scoring essays and reports.',
      'Deliver fluent, cohesive spoken responses under time pressure.',
    ],
  },
];

export default courses;