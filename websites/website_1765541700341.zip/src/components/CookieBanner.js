import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const storageKey = 'linguaAcademyCookieConsent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(storageKey);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(storageKey, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Cookie preferences</h4>
        <p>
          We use essential and analytical cookies to enhance your experience at Lingua
          Academy. You can update your preferences at any time.
        </p>
      </div>
      <div className={styles.actions}>
        <Link to="/cookie-policy" className="btnSecondary">
          Customize
        </Link>
        <button className="btnPrimary" onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;