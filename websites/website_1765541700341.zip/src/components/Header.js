import { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const closeOnResize = () => {
      if (window.innerWidth >= 992) {
        setMenuOpen(false);
      }
    };

    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };

    window.addEventListener('resize', closeOnResize);
    window.addEventListener('scroll', handleScroll);

    handleScroll();

    return () => {
      window.removeEventListener('resize', closeOnResize);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const handleToggle = () => setMenuOpen((prev) => !prev);
  const handleLinkClick = () => setMenuOpen(false);

  const navLinkClass = ({ isActive }) =>
    `${styles.navLink} ${isActive ? styles.active : ''}`;

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.logo}>
          <Link to="/" aria-label="Lingua Academy home">
            Lingua Academy
          </Link>
        </div>
        <button
          className={styles.navToggle}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-label="Toggle navigation"
        >
          <span className={styles.burger} />
        </button>
        <nav
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Main navigation"
        >
          <ul className={styles.navList}>
            <li>
              <NavLink to="/" className={navLinkClass} onClick={handleLinkClick}>
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to="/guide" className={navLinkClass} onClick={handleLinkClick}>
                Guide
              </NavLink>
            </li>
            <li>
              <NavLink to="/programs" className={navLinkClass} onClick={handleLinkClick}>
                Programs
              </NavLink>
            </li>
            <li>
              <NavLink to="/tools" className={navLinkClass} onClick={handleLinkClick}>
                Tools
              </NavLink>
            </li>
            <li>
              <NavLink to="/blog" className={navLinkClass} onClick={handleLinkClick}>
                Blog
              </NavLink>
            </li>
            <li>
              <NavLink to="/services" className={navLinkClass} onClick={handleLinkClick}>
                Services
              </NavLink>
            </li>
            <li>
              <NavLink to="/about" className={navLinkClass} onClick={handleLinkClick}>
                About
              </NavLink>
            </li>
            <li>
              <NavLink to="/contact" className={navLinkClass} onClick={handleLinkClick}>
                Contact
              </NavLink>
            </li>
          </ul>
          <Link
            to="/contact"
            className={`${styles.navCta} btnPrimary`}
            onClick={handleLinkClick}
          >
            Book a Consultation
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;