import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brandBlock}>
            <h3 className={styles.logo}>Lingua Academy</h3>
            <p>
              Empowering learners across the Netherlands to communicate confidently in the
              languages that shape their personal, academic, and professional goals.
            </p>
            <div className={styles.contactList}>
              <a href="mailto:info@lingua-academy.nl">info@lingua-academy.nl</a>
              <a href="tel:+31201234567">+31 20 123 4567</a>
              <span>Language Street 123, 1011 AB Amsterdam, Netherlands</span>
            </div>
          </div>
          <div className={styles.column}>
            <h4>Explore</h4>
            <ul>
              <li>
                <Link to="/guide">Platform Guide</Link>
              </li>
              <li>
                <Link to="/programs">Programs</Link>
              </li>
              <li>
                <Link to="/services">Services</Link>
              </li>
              <li>
                <Link to="/tools">Learning Tools</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Insights</h4>
            <ul>
              <li>
                <Link to="/blog">Blog & Stories</Link>
              </li>
              <li>
                <Link to="/about">Our Team</Link>
              </li>
              <li>
                <Link to="/contact">Contact</Link>
              </li>
              <li>
                <Link to="/privacy">Data Protection</Link>
              </li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Policies</h4>
            <ul>
              <li>
                <Link to="/terms">Terms of Service</Link>
              </li>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Cookie Policy</Link>
              </li>
            </ul>
            <div className={styles.socialIcons} aria-label="Social media links">
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
              >
                in
              </a>
              <a
                href="https://www.facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
              >
                fb
              </a>
              <a
                href="https://www.instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
              >
                ig
              </a>
            </div>
          </div>
        </div>
        <div className={styles.bottomBar}>
          <p>© {year} Lingua Academy. All rights reserved.</p>
          <p>Registered in the Netherlands • Chamber of Commerce placeholder</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;