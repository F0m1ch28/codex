document.addEventListener("DOMContentLoaded", function () {
    var navToggle = document.querySelector(".nav-toggle");
    var navLinks = document.querySelector(".nav-links");
    if (navToggle && navLinks) {
        navToggle.addEventListener("click", function () {
            navLinks.classList.toggle("open");
        });
    }

    var cookieBanner = document.getElementById("cookieBanner");
    var acceptBtn = document.getElementById("cookieAccept");
    var declineBtn = document.getElementById("cookieDecline");
    var cookiePreference = localStorage.getItem("ndebelwjfo_cookie_preference");

    if (cookieBanner) {
        if (!cookiePreference) {
            cookieBanner.classList.add("active");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", function () {
                localStorage.setItem("ndebelwjfo_cookie_preference", "accepted");
                cookieBanner.classList.remove("active");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", function () {
                localStorage.setItem("ndebelwjfo_cookie_preference", "declined");
                cookieBanner.classList.remove("active");
            });
        }
    }
});