document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById("cookieBanner");
  const yearElementList = document.querySelectorAll("#currentYear");
  const currentYear = new Date().getFullYear();

  yearElementList.forEach(function (el) {
    el.textContent = currentYear;
  });

  if (!banner) {
    return;
  }

  const storedConsent = localStorage.getItem("wcCookieConsent");
  if (storedConsent === "accepted" || storedConsent === "declined") {
    banner.style.display = "none";
    return;
  }

  banner.style.display = "block";

  const acceptButton = banner.querySelector('[data-action="accept"]');
  const declineButton = banner.querySelector('[data-action="decline"]');

  if (acceptButton) {
    acceptButton.addEventListener("click", function () {
      localStorage.setItem("wcCookieConsent", "accepted");
      banner.style.display = "none";
    });
  }

  if (declineButton) {
    declineButton.addEventListener("click", function () {
      localStorage.setItem("wcCookieConsent", "declined");
      banner.style.display = "none";
    });
  }
});