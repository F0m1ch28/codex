import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { motion } from "framer-motion";

const Header = () => {
  const [open, setOpen] = useState(false);

  const navItems = [
    { label: "Home", path: "/" },
    { label: "Company", path: "/company" },
    { label: "Audit Services", path: "/audit-services" },
    { label: "Performance Validation", path: "/performance-validation" },
    { label: "Lifecycle Insights", path: "/lifecycle-insights" },
    { label: "Applications", path: "/applications" },
    { label: "Contact", path: "/contact" }
  ];

  const toggleMenu = () => setOpen((prev) => !prev);
  const closeMenu = () => setOpen(false);

  return (
    <header className="bg-brand-dark text-white shadow-xl sticky top-0 z-50 backdrop-blur-sm bg-opacity-95">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
        <motion.div
          className="flex items-center space-x-3"
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
        >
          <Link
            to="/"
            className="text-xl font-semibold tracking-tight focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-dark"
            onClick={closeMenu}
          >
            Clean<span className="text-brand-yellow">AssetAudit</span>
          </Link>
          <span className="hidden rounded-full bg-white/15 px-3 py-1 text-xs font-medium uppercase tracking-wider text-brand-yellow md:inline-block">
            Canada
          </span>
        </motion.div>

        <button
          type="button"
          onClick={toggleMenu}
          className="inline-flex items-center rounded-md border border-white/20 px-3 py-2 text-sm font-medium text-white transition hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-dark lg:hidden"
          aria-expanded={open}
          aria-controls="primary-navigation"
        >
          <span className="sr-only">Toggle navigation</span>
          {open ? (
            <svg
              className="h-6 w-6"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg
              className="h-6 w-6"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>

        <nav
          id="primary-navigation"
          className={`${
            open ? "max-h-[600px] opacity-100" : "max-h-0 opacity-0 lg:opacity-100"
          } absolute left-0 top-full w-full overflow-hidden bg-brand-dark transition-all duration-300 ease-out lg:static lg:max-h-none lg:w-auto lg:bg-transparent lg:opacity-100`}
        >
          <ul className="flex flex-col gap-2 px-6 pb-6 pt-4 text-base lg:flex-row lg:items-center lg:gap-6 lg:px-0 lg:py-0">
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  onClick={closeMenu}
                  className={({ isActive }) =>
                    `inline-flex items-center rounded-md px-2 py-1.5 text-sm font-medium transition ${
                      isActive
                        ? "text-brand-yellow"
                        : "text-white hover:text-brand-yellow focus-visible:text-brand-yellow"
                    } focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow focus-visible:ring-offset-2 focus-visible:ring-offset-brand-dark`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            <li className="lg:ml-4">
              <Link
                to="/contact"
                onClick={closeMenu}
                className="btn-primary inline-flex items-center justify-center text-sm"
              >
                Request Audit
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;