import React, { useEffect, useState } from "react";

const STORAGE_KEY = "cleanAssetAuditCookieConsent";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(STORAGE_KEY, choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div
      className="fixed bottom-4 left-1/2 z-[60] w-[calc(100%-2rem)] max-w-3xl -translate-x-1/2 rounded-2xl border border-brand-dark bg-white/95 p-5 shadow-2xl backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Cookie consent prompt"
    >
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between md:gap-6">
        <div>
          <h2 className="text-sm font-semibold text-brand-dark">
            Cookies for analytics and reliability
          </h2>
          <p className="mt-1 text-xs text-slate-700">
            We use functional cookies to monitor site performance indicators and enhance renewable asset benchmarking resources.
            You can accept or decline. Your choice will be stored on this device.
          </p>
        </div>
        <div className="flex flex-shrink-0 items-center gap-3">
          <button
            type="button"
            onClick={() => handleChoice("declined")}
            className="btn-secondary text-xs"
          >
            Decline
          </button>
          <button
            type="button"
            onClick={() => handleChoice("accepted")}
            className="btn-primary text-xs"
          >
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;