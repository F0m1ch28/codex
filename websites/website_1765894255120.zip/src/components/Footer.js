import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const Footer = () => {
  return (
    <footer className="bg-brand-dark text-white">
      <div className="mx-auto max-w-7xl px-6 py-14 lg:px-10">
        <motion.div
          className="grid gap-10 md:grid-cols-2 lg:grid-cols-4"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div>
            <h3 className="text-lg font-semibold tracking-tight">Clean Asset Audit</h3>
            <p className="mt-3 text-sm text-brand-ice/90">
              Lifecycle auditing and clean energy performance validation devoted to solar, wind, and hybrid assets across Canada.
            </p>
            <p className="mt-4 text-xs font-medium uppercase tracking-wider text-brand-yellow">
              Renewable asset audit Canada — clean energy performance validation — lifecycle assessment renewables
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-brand-yellow">Explore</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li>
                <Link className="hover:underline" to="/company">
                  Company Overview
                </Link>
              </li>
              <li>
                <Link className="hover:underline" to="/audit-services">
                  Audit Services
                </Link>
              </li>
              <li>
                <Link className="hover:underline" to="/performance-validation">
                  Performance Validation
                </Link>
              </li>
              <li>
                <Link className="hover:underline" to="/lifecycle-insights">
                  Lifecycle Insights
                </Link>
              </li>
              <li>
                <Link className="hover:underline" to="/applications">
                  Applications
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-brand-yellow">Connect</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li className="flex flex-col">
                <span className="font-medium">Address</span>
                <span>Bay Adelaide Centre</span>
                <span>333 Bay Street, Floor 19</span>
                <span>Toronto, Ontario, Canada</span>
              </li>
              <li>
                <span className="font-medium">Phone:</span>{" "}
                <a className="hover:underline" href="tel:+14169016728">
                  +1 416 901 6728
                </a>
              </li>
              <li>
                <span className="font-medium">Email:</span>{" "}
                <a className="hover:underline" href="mailto:info@cleanassetaudit.com">
                  info@cleanassetaudit.com
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-brand-yellow">Governance</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li>
                <Link className="hover:underline" to="/privacy">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link className="hover:underline" to="/cookies">
                  Cookie Policy
                </Link>
              </li>
              <li>
                <Link className="hover:underline" to="/terms">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link className="hover:underline" to="/contact">
                  Request Renewable Asset Audit
                </Link>
              </li>
            </ul>
          </div>
        </motion.div>

        <div className="mt-12 border-t border-white/10 pt-6 text-xs text-white/70">
          <p>
            © {new Date().getFullYear()} Clean Asset Audit. Independent engineering and consulting partner for operational compliance renewables and degradation tracking in Canada.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;