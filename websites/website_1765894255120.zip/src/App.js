import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import PerformanceValidation from "./pages/PerformanceValidation";
import LifecycleInsights from "./pages/LifecycleInsights";
import Applications from "./pages/Applications";
import Contact from "./pages/Contact";
import Thanks from "./pages/Thanks";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import CookiesPage from "./pages/Cookies";
import TermsOfService from "./pages/TermsOfService";

const App = () => {
  const location = useLocation();

  return (
    <div className="bg-brand-paper text-slate-900 min-h-screen flex flex-col">
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <Header />
      <ScrollToTop />
      <main id="main-content" className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
          >
            <Routes location={location}>
              <Route path="/" element={<Home />} />
              <Route path="/company" element={<About />} />
              <Route path="/audit-services" element={<Services />} />
              <Route
                path="/performance-validation"
                element={<PerformanceValidation />}
              />
              <Route
                path="/lifecycle-insights"
                element={<LifecycleInsights />}
              />
              <Route path="/applications" element={<Applications />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/thanks" element={<Thanks />} />
              <Route path="/privacy" element={<PrivacyPolicy />} />
              <Route path="/cookies" element={<CookiesPage />} />
              <Route path="/terms" element={<TermsOfService />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

export default App;