import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const LifecycleInsights = () => {
  const insights = [
    {
      title: "Aging Analysis",
      detail:
        "Evaluate component aging through performance signatures, inspection records, and lab test data to forecast residual useful life."
    },
    {
      title: "Degradation Modelling",
      detail:
        "Develop degradation curves for PV modules, wind turbine blades, gearboxes, and batteries using statistical and physics-based models."
    },
    {
      title: "Maintenance Effectiveness",
      detail:
        "Benchmark maintenance plans, corrective actions, and spare strategies against asset health and downtime trends."
    },
    {
      title: "Lifecycle Cost Indicators",
      detail:
        "Track key lifecycle indicators such as equivalent forced outage rates, refurbishment timing, and financial alignment without referencing pricing."
    },
    {
      title: "Reliability Forecasting",
      detail:
        "Forecast failure modes using Weibull distributions, reliability block diagrams, and scenario planning for Canadian climates."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Lifecycle Insights | Clean Asset Audit</title>
        <meta
          name="description"
          content="Discover how Clean Asset Audit provides lifecycle insights including aging analysis, degradation modelling, maintenance effectiveness, lifecycle indicators, and reliability forecasting."
        />
        <meta property="og:title" content="Lifecycle Insights for Renewable Assets" />
        <meta property="og:url" content="https://www.cleanassetaudit.com/lifecycle-insights" />
      </Helmet>

      <div className="mx-auto max-w-6xl px-6 py-20 lg:px-10">
        <motion.div
          className="space-y-5"
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <span className="badge">Lifecycle intelligence</span>
          <h1 className="text-4xl font-semibold text-brand-dark">Lifecycle insights designed for long-term stewardship.</h1>
          <p className="text-sm text-slate-700">
            Beyond immediate performance validation, Clean Asset Audit equips teams with insight to steward assets for decades. We translate data into durable lifecycle strategies for solar arrays, wind turbines, and hybrid resources exposed to Canada&apos;s diverse climates.
          </p>
        </motion.div>

        <motion.div
          className="mt-14 grid gap-6 md:grid-cols-2"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          transition={{ staggerChildren: 0.12 }}
        >
          {insights.map((insight) => (
            <motion.div
              key={insight.title}
              variants={{
                hidden: { opacity: 0, y: 30 },
                visible: { opacity: 1, y: 0 }
              }}
              className="rounded-3xl border border-brand-dark/10 bg-white p-6 shadow-soft"
            >
              <h2 className="text-xl font-semibold text-brand-blue">{insight.title}</h2>
              <p className="mt-3 text-sm text-slate-700">{insight.detail}</p>
            </motion.div>
          ))}
        </motion.div>

        <motion.section
          className="mt-16 rounded-3xl bg-brand-blue px-6 py-10 text-white lg:px-10"
          initial={{ opacity: 0, y: 36 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
        >
          <h2 className="text-2xl font-semibold">Strategic Lifecycle Outcomes</h2>
          <p className="mt-4 text-sm text-white/85">
            Lifecycle insights inform capital planning, stakeholder reporting, and operational excellence. We emphasize transparency by pairing each insight with the supporting evidence—graphs, Menlo-style data tables, and field verification notes—so decision makers feel confident acting on recommendations.
          </p>
          <ul className="mt-6 grid gap-3 text-sm text-white/80 sm:grid-cols-2">
            <li className="rounded-2xl bg-white/10 p-4">
              Refined refurbishment schedules synchronized with seasonal constraints and supply chain logistics.
            </li>
            <li className="rounded-2xl bg-white/10 p-4">
              Alignment of asset management policies to ISO 55000 principles tailored for renewable portfolios.
            </li>
            <li className="rounded-2xl bg-white/10 p-4">
              Lifecycle assessment renewables insights connecting environmental performance and operational excellence.
            </li>
            <li className="rounded-2xl bg-white/10 p-4">
              Data governance practices that keep degradation tracking clean energy datasets reliable and audit-ready.
            </li>
          </ul>
        </motion.section>
      </div>
    </>
  );
};

export default LifecycleInsights;