import React from "react";
import { Helmet } from "react-helmet-async";

const PrivacyPolicy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Clean Asset Audit</title>
        <meta
          name="description"
          content="How Clean Asset Audit collects, uses, and protects personal information related to renewable asset audit inquiries."
        />
      </Helmet>

      <div className="mx-auto max-w-4xl space-y-8 px-6 py-20 lg:px-10">
        <h1 className="text-3xl font-semibold text-brand-dark">Privacy Policy</h1>
        <p className="text-sm text-slate-700">
          Clean Asset Audit respects your privacy. This policy explains how we handle personal information gathered through this website.
        </p>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Information We Collect</h2>
          <p className="text-sm text-slate-700">
            When you submit a form, we collect details such as your name, email, organization, asset focus, and message content. We may also gather technical information like IP address, browser type, and device characteristics for analytics to support reliability of our digital resources.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">How We Use Information</h2>
          <ul className="list-disc space-y-2 pl-6 text-sm text-slate-700">
            <li>Respond to inquiries about renewable asset audit services.</li>
            <li>Prepare proposals and project scoping materials.</li>
            <li>Improve site functionality and understand audience engagement.</li>
            <li>Maintain records consistent with Canadian privacy legislation.</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Disclosure</h2>
          <p className="text-sm text-slate-700">
            We do not sell or rent your personal information. We may share details with trusted service providers assisting in project delivery or communications, subject to confidentiality commitments. We may disclose information if required by law or to protect our legal rights.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Data Security</h2>
          <p className="text-sm text-slate-700">
            Clean Asset Audit uses administrative and technical safeguards to protect personal information. Access is limited to team members who need the data for legitimate purposes such as client service or regulatory compliance.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Retention</h2>
          <p className="text-sm text-slate-700">
            We retain personal information only as long as necessary to fulfill the purposes outlined above or to meet legal obligations. When information is no longer required, we securely delete or anonymize it.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Your Rights</h2>
          <p className="text-sm text-slate-700">
            You may request access, correction, or deletion of the personal information we hold about you, subject to legal limitations. Contact info@cleanassetaudit.com for assistance.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Updates</h2>
          <p className="text-sm text-slate-700">
            We may revise this policy to reflect changes in practices or regulations. Updates will be posted with the effective date.
          </p>
        </section>

        <p className="text-xs text-slate-500">Effective date: {new Date().getFullYear()}</p>
      </div>
    </>
  );
};

export default PrivacyPolicy;