import React from "react";
import { Helmet } from "react-helmet-async";

const CookiesPage = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Clean Asset Audit</title>
        <meta
          name="description"
          content="Learn how Clean Asset Audit uses cookies for analytics and reliability of renewable asset audit resources."
        />
      </Helmet>

      <div className="mx-auto max-w-4xl space-y-8 px-6 py-20 lg:px-10">
        <h1 className="text-3xl font-semibold text-brand-dark">Cookie Policy</h1>
        <p className="text-sm text-slate-700">
          This policy explains how Clean Asset Audit uses cookies and similar technologies to support the functionality and reliability of our website.
        </p>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold text-brand-dark">What Are Cookies?</h2>
          <p className="text-sm text-slate-700">
            Cookies are small text files placed on your device when you visit our site. They help us understand how visitors interact with our content and maintain continuous sessions.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold text-brand-dark">How We Use Cookies</h2>
          <ul className="list-disc space-y-2 pl-6 text-sm text-slate-700">
            <li>Ensure forms and navigation operate smoothly.</li>
            <li>Gather analytics to monitor site performance and improve resources.</li>
            <li>Remember your cookie consent preferences.</li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold text-brand-dark">Managing Cookies</h2>
          <p className="text-sm text-slate-700">
            You can accept or decline cookies through our consent banner. You may also update browser settings to control cookies. Please note that disabling cookies may affect some site features.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold text-brand-dark">Updates</h2>
          <p className="text-sm text-slate-700">
            We may update this policy as technology or regulation evolves. Changes will be posted here with a revised effective date.
          </p>
        </section>

        <p className="text-xs text-slate-500">Effective date: {new Date().getFullYear()}</p>
      </div>
    </>
  );
};

export default CookiesPage;