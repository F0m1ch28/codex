import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const Home = () => {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    "name": "Clean Asset Audit Knowledge Studio",
    "url": "https://www.cleanassetaudit.com",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "333 Bay Street, Floor 19",
      "addressLocality": "Toronto",
      "addressRegion": "ON",
      "addressCountry": "Canada"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-416-901-6728",
      "contactType": "customer service",
      "areaServed": "CA"
    },
    "description": "Training and advisory content covering lifecycle audits, clean energy performance validation, and degradation tracking for renewable assets in Canada.",
    "course": [
      {
        "@type": "Course",
        "name": "Renewable Asset Lifecycle Audit Fundamentals",
        "description": "Methodologies for commissioning, operational compliance, and lifecycle assessment of solar and wind assets.",
        "provider": {
          "@type": "Organization",
          "name": "Clean Asset Audit"
        }
      },
      {
        "@type": "Course",
        "name": "Performance Validation Against Design Metrics",
        "description": "Techniques to compare theoretical production with measured data, including seasonal normalization.",
        "provider": {
          "@type": "Organization",
          "name": "Clean Asset Audit"
        }
      }
    ]
  };

  const heroStats = [
    {
      title: "Lifecycle Coverage",
      description: "Commissioning health checks, operational benchmarking, and end-of-life planning all within one audit framework."
    },
    {
      title: "Canadian Expertise",
      description: "Detailed knowledge of provincial codes, grid interconnection standards, and cold climate performance criteria."
    },
    {
      title: "Data-Rich Reporting",
      description: "Interactive dashboards, Menlo-style data tables, and annotated findings tuned for engineering teams."
    }
  ];

  const testimonials = [
    {
      name: "Director of Asset Management, Ontario",
      quote:
        "Clean Asset Audit helped our solar fleet align with original design metrics and isolate seasonal derates. Their guidance informed maintenance planning and contractual reporting."
    },
    {
      name: "Wind Operations Lead, Alberta",
      quote:
        "The lifecycle audit uncovered subtle power curve deviations and turbine wake interactions. The recommendations were actionable and evidence-based."
    },
    {
      name: "Hybrid Project Owner, Atlantic Canada",
      quote:
        "We finally have a harmonized view of battery, solar, and wind performance. Their benchmarking against Canadian peers delivered clarity for stakeholders."
    }
  ];

  const lifecycleSteps = [
    {
      title: "Commissioning Integrity",
      text: "Independent validation of commissioning documentation, SCADA tagging, inverter controls, and protective relay settings."
    },
    {
      title: "Operational Diagnostics",
      text: "Live data interrogation, normalized energy yield studies, and failure mode analysis informed by degradation tracking."
    },
    {
      title: "Long-Horizon Stewardship",
      text: "Residual life projections, component refurbishment strategies, and lifecycle assessment renewables modelling for asset managers."
    }
  ];

  const auditOutcomes = [
    "Clear variance analysis between modeled and measured production to sharpen stakeholder communication.",
    "Corrective action roadmaps prioritized by energy impact and regulatory urgency.",
    "Condition-based maintenance triggers relying on degradation fingerprints and reliability statistics.",
    "Narratives tailored for board reporting, lender requirements, and provincial regulators."
  ];

  return (
    <>
      <Helmet>
        <title>Clean Asset Audit | Lifecycle Auditing & Performance Validation for Renewable Assets</title>
        <meta
          name="description"
          content="Clean Asset Audit delivers renewable asset audits across Canada, covering lifecycle assessments, clean energy performance validation, and degradation tracking for solar, wind, and hybrid infrastructure."
        />
        <meta
          name="keywords"
          content="renewable asset audit Canada, clean energy performance validation, lifecycle assessment renewables, solar wind audit services, operational compliance renewables, degradation tracking clean energy, performance verification Canada"
        />
        <meta property="og:title" content="Lifecycle Auditing & Performance Validation for Renewable Assets" />
        <meta
          property="og:description"
          content="Independent engineering oversight for Canadian renewable assets, spanning commissioning reviews, operational benchmarking, and actionable audit outcomes."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.cleanassetaudit.com/" />
        <meta property="og:site_name" content="Clean Asset Audit" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>

      <div className="space-y-24 pb-24">
        <section className="relative overflow-hidden bg-brand-dark text-white">
          <div className="absolute inset-0 opacity-50">
            <div className="absolute -left-24 top-0 h-72 w-72 rounded-full bg-brand-blue/30 blur-3xl" />
            <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-brand-yellow/20 blur-3xl" />
          </div>
          <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-24 lg:grid-cols-2 lg:px-10">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <span className="inline-flex items-center rounded-full bg-white/15 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-brand-yellow">
                Renewable asset audit Canada
              </span>
              <h1 className="text-4xl font-semibold tracking-tight sm:text-5xl">
                Lifecycle Auditing &amp; Performance Validation for Renewable Assets
              </h1>
              <p className="max-w-xl text-lg text-white/80">
                Clean Asset Audit provides independent engineering assurance for solar, wind, and hybrid resources across Canada.
                We benchmark clean energy performance against design baselines, flag degradation patterns, and steer operational compliance renewables programs.
              </p>
              <div className="flex flex-wrap items-center gap-4">
                <Link to="/contact" className="btn-primary">
                  Request Renewable Asset Audit
                </Link>
                <Link to="/company" className="btn-secondary text-white">
                  Discover our methodology
                </Link>
              </div>
              <div className="grid gap-4 pt-8 sm:grid-cols-3">
                {heroStats.map((item) => (
                  <div key={item.title} className="rounded-2xl bg-white/10 p-4 shadow-inner">
                    <h3 className="text-sm font-semibold text-brand-yellow">{item.title}</h3>
                    <p className="mt-2 text-xs text-white/80">{item.description}</p>
                  </div>
                ))}
              </div>
            </motion.div>
            <motion.div
              className="relative flex justify-center lg:justify-end"
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
            >
              <div className="relative w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-white/5 backdrop-blur">
                <img
                  src="https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=1200&q=80"
                  alt="Canadian renewable energy assets under inspection during a lifecycle audit"
                  className="h-full w-full object-cover"
                />
                <div className="absolute bottom-4 left-4 rounded-xl bg-brand-dark/70 px-4 py-3 text-xs font-medium text-brand-ice shadow-lg backdrop-blur">
                  Degradation tracking • SCADA validation • Seasonal normalization
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 lg:px-10">
          <motion.h2
            className="text-3xl font-semibold"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Why Lifecycle Audits Matter
          </motion.h2>
          <motion.p
            className="mt-4 max-w-3xl text-base text-slate-700"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.05 }}
          >
            Renewable assets evolve with changing loads, weather patterns, and regulatory expectations. Lifecycle auditing unifies commissioning records, performance validation data, and maintenance logs into one coherent view. Our engineering audits are grounded in Canadian codes, ISO 55000 asset management principles, and advanced analytics built to highlight clean energy performance validation metrics.
          </motion.p>
          <motion.div
            className="mt-10 grid gap-6 md:grid-cols-2"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            transition={{ staggerChildren: 0.08 }}
          >
            {lifecycleSteps.map((step) => (
              <motion.div
                key={step.title}
                variants={{
                  hidden: { opacity: 0, y: 30 },
                  visible: { opacity: 1, y: 0 }
                }}
                className="rounded-3xl border border-brand-dark/10 bg-white p-6 shadow-soft"
              >
                <h3 className="text-xl font-semibold text-brand-dark">{step.title}</h3>
                <p className="mt-3 text-sm text-slate-700">{step.text}</p>
              </motion.div>
            ))}
          </motion.div>
        </section>

        <section className="bg-white py-20">
          <div className="mx-auto grid max-w-6xl gap-10 px-6 lg:grid-cols-2 lg:px-10">
            <motion.div
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55 }}
            >
              <h2 className="text-3xl font-semibold text-brand-dark">
                From Commissioning to Long-Term Operation
              </h2>
              <p className="mt-4 text-sm text-slate-700">
                Our lifecycle assessments connect the dots between factory acceptance testing, performance testing, and operational reality. We confirm as-built documentation, verify firmware updates, and monitor operational compliance renewables programs through field interviews and data science.
              </p>
              <ul className="mt-6 space-y-3 text-sm text-slate-700">
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-brand-blue" />
                  Verification of commissioning punchlists, ITPs, and warranty deliverables.
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-brand-blue" />
                  Validation of performance test results against regulatory filings and interconnection rules.
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-brand-blue" />
                  Operational interviews with plant managers and service providers to map process maturity.
                </li>
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0.1 }}
              className="rounded-3xl border border-brand-dark/10 bg-brand-paper p-6 shadow-soft"
            >
              <h3 className="text-lg font-semibold text-brand-dark">
                Performance Validation Against Design Metrics
              </h3>
              <p className="mt-3 text-sm text-slate-700">
                We benchmark SCADA data, meteorological inputs, and inverter outputs against the design energy model. Our team reconciles energy-at-meter readings with contractual guarantees and Canadian ISO settlements while performing outlier detection across operational months.
              </p>
              <div className="mt-6 space-y-4">
                <div className="rounded-2xl border border-brand-blue/20 bg-white p-4">
                  <h4 className="text-sm font-semibold text-brand-blue">Analytical Highlights</h4>
                  <p className="mt-2 text-xs text-slate-700">
                    Seasonal normalization, long-term P50/P90 comparisons, and root cause classification for yield variance.
                  </p>
                </div>
                <div className="rounded-2xl border border-brand-yellow/20 bg-white p-4">
                  <h4 className="text-sm font-semibold text-brand-yellow">Engineering Dialogue</h4>
                  <p className="mt-2 text-xs text-slate-700">
                    Collaborative workshops with owner&apos;s engineers to align on design assumptions, curtailment records, and grid dispatch notes.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 lg:px-10">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
            className="rounded-3xl bg-brand-dark px-6 py-12 text-white lg:px-12"
          >
            <div className="grid gap-8 lg:grid-cols-[2fr,1fr] lg:items-center">
              <div>
                <h2 className="text-3xl font-semibold">Degradation &amp; Reliability Tracking</h2>
                <p className="mt-4 text-sm text-white/80">
                  Our degradation tracking clean energy approach combines condition monitoring with component failure statistics. We examine inverter health, tracker alignment, blade inspections, and balance-of-plant systems through a reliability lens that ties directly to lifecycle assessment renewables models.
                </p>
                <ul className="mt-6 grid gap-3 text-sm text-white/80 sm:grid-cols-2">
                  <li className="rounded-2xl bg-white/10 p-4">
                    <h4 className="text-sm font-semibold text-brand-yellow">Component Health Maps</h4>
                    <p className="mt-2 text-xs">
                      Heatmaps of transformer loading, pitch system performance, and HVAC cycles captured over multi-year windows.
                    </p>
                  </li>
                  <li className="rounded-2xl bg-white/10 p-4">
                    <h4 className="text-sm font-semibold text-brand-yellow">Reliability Forecasting</h4>
                    <p className="mt-2 text-xs">
                      Weibull and Monte Carlo modelling to anticipate refurbishment milestones and spares procurement.
                    </p>
                  </li>
                </ul>
              </div>
              <div className="rounded-3xl border border-white/15 bg-brand-paper/10 p-6 text-sm text-white/85 backdrop-blur">
                <h3 className="font-semibold text-brand-yellow">Actionable Audit Outcomes</h3>
                <ul className="mt-4 space-y-3 text-xs">
                  {auditOutcomes.map((outcome) => (
                    <li key={outcome} className="flex items-start gap-3">
                      <span className="mt-1 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-brand-yellow" />
                      {outcome}
                    </li>
                  ))}
                </ul>
                <Link to="/audit-services" className="btn-primary mt-6 inline-flex text-sm">
                  Explore audit deliverables
                </Link>
              </div>
            </div>
          </motion.div>
        </section>

        <section className="bg-white py-20">
          <div className="mx-auto max-w-6xl px-6 lg:px-10">
            <motion.h2
              className="text-3xl font-semibold text-brand-dark"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              Field Notes &amp; Testimonials
            </motion.h2>
            <motion.p
              className="mt-4 max-w-3xl text-sm text-slate-700"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.05 }}
            >
              Canadian owners, lenders, and operators rely on our clean energy performance validation narratives to inform decisions. Here is what they share about partnering with Clean Asset Audit.
            </motion.p>
            <motion.div
              className="mt-10 grid gap-6 md:grid-cols-3"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              transition={{ staggerChildren: 0.1 }}
            >
              {testimonials.map((testimonial) => (
                <motion.div
                  key={testimonial.name}
                  variants={{
                    hidden: { opacity: 0, y: 32 },
                    visible: { opacity: 1, y: 0 }
                  }}
                  className="rounded-3xl border border-brand-dark/10 bg-brand-paper p-6 shadow-soft"
                >
                  <p className="text-sm text-slate-700">“{testimonial.quote}”</p>
                  <p className="mt-4 text-xs font-semibold text-brand-dark">{testimonial.name}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 lg:px-10">
          <motion.div
            className="rounded-3xl bg-brand-blue px-6 py-12 text-white lg:flex lg:items-center lg:justify-between lg:px-12"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
          >
            <div>
              <h2 className="text-3xl font-semibold">Ready for a renewable asset audit that goes deeper?</h2>
              <p className="mt-4 max-w-2xl text-sm text-white/85">
                Let&apos;s align commissioning data, operational realities, and lifecycle ambitions. Clean Asset Audit is ready to support solar, wind, and hybrid facilities with precision diagnostics and transparent reporting.
              </p>
            </div>
            <Link to="/contact" className="btn-light mt-6 inline-flex whitespace-nowrap text-brand-dark lg:mt-0">
              Request Renewable Asset Audit
            </Link>
          </motion.div>
        </section>
      </div>
    </>
  );
};

export default Home;