import React from "react";
import { Helmet } from "react-helmet-async";

const TermsOfService = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | Clean Asset Audit</title>
        <meta
          name="description"
          content="Terms governing the use of Clean Asset Audit digital resources and renewable asset audit information."
        />
      </Helmet>

      <div className="mx-auto max-w-4xl space-y-8 px-6 py-20 lg:px-10">
        <h1 className="text-3xl font-semibold text-brand-dark">Terms of Service</h1>
        <p className="text-sm text-slate-700">
          These Terms of Service describe how you may use the website and materials published by Clean Asset Audit. By accessing our site, you agree to the terms below. If you do not agree, please discontinue use.
        </p>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Use of Information</h2>
          <p className="text-sm text-slate-700">
            Content is provided for informational purposes regarding renewable asset auditing, clean energy performance validation, and lifecycle insights in Canada. It does not constitute engineering certification or legal advice. Decisions should be supported by formal engagements and site-specific analysis.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Intellectual Property</h2>
          <p className="text-sm text-slate-700">
            Unless otherwise noted, Clean Asset Audit owns the intellectual property rights to website content, graphics, and methodologies. You may reference materials for non-commercial internal use with attribution, but you may not reproduce them for broader distribution without permission.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">User Responsibilities</h2>
          <p className="text-sm text-slate-700">
            You agree not to misuse the site, attempt unauthorized access, or deploy automated systems that could impair functionality. You are responsible for ensuring that any data shared through contact forms is accurate and that you have authority to submit it.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Limitation of Liability</h2>
          <p className="text-sm text-slate-700">
            Clean Asset Audit provides the site on an &ldquo;as available&rdquo; basis. We strive for accuracy but do not warrant completeness of information. To the extent permitted by law, Clean Asset Audit is not liable for any damages resulting from use of the site or reliance on its content.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Third-Party Links</h2>
          <p className="text-sm text-slate-700">
            External links may direct you to other resources for convenience. Clean Asset Audit does not control and is not responsible for external site content or practices.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Changes to Terms</h2>
          <p className="text-sm text-slate-700">
            We may update these terms to reflect policy changes or new regulations. Revised terms will be posted with an updated effective date.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-brand-dark">Contact</h2>
          <p className="text-sm text-slate-700">
            Questions about these terms can be directed to info@cleanassetaudit.com or by calling +1 416 901 6728.
          </p>
        </section>

        <p className="text-xs text-slate-500">Effective date: {new Date().getFullYear()}</p>
      </div>
    </>
  );
};

export default TermsOfService;