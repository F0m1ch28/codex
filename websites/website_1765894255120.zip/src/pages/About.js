import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const About = () => {
  return (
    <>
      <Helmet>
        <title>Company | Clean Asset Audit</title>
        <meta
          name="description"
          content="Learn about Clean Asset Audit, our lifecycle audit methodology, engineering certifications, Canadian regulatory insight, quality assurance, and sustainability commitments."
        />
        <meta property="og:title" content="Clean Asset Audit Company Overview" />
        <meta
          property="og:description"
          content="Independent engineering and consulting firm specializing in renewable asset audits and performance validation across Canada."
        />
        <meta property="og:url" content="https://www.cleanassetaudit.com/company" />
      </Helmet>

      <div className="mx-auto max-w-5xl space-y-16 px-6 py-20 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
          className="space-y-6"
        >
          <span className="badge">About Clean Asset Audit</span>
          <h1 className="text-4xl font-semibold text-brand-dark">
            Engineering leadership for clean energy performance validation in Canada.
          </h1>
          <p className="text-sm text-slate-700">
            Clean Asset Audit is an independent engineering and consulting practice dedicated to renewable infrastructure. From Bay Adelaide Centre in Toronto, we serve asset owners, lenders, and public agencies with lifecycle audits, operational compliance renewables assessments, and degradation tracking clean energy services.
          </p>
        </motion.div>

        <motion.section
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
          className="rounded-3xl bg-white p-8 shadow-soft"
        >
          <h2 className="text-2xl font-semibold text-brand-dark">Audit Methodology</h2>
          <p className="mt-3 text-sm text-slate-700">
            Our methodology is rooted in evidence-based engineering. We combine document reviews, onsite inspections, data analytics, and collaborative workshops. Each mandate begins with a scope alignment session where we map stakeholder objectives, regulatory triggers, and performance criteria. We then execute a structured workflow:
          </p>
          <ol className="mt-5 space-y-3 text-sm text-slate-700">
            <li>
              <strong className="font-semibold text-brand-blue">Baseline Review:</strong> Evaluate design models, as-built drawings, contracts, and commissioning reports.
            </li>
            <li>
              <strong className="font-semibold text-brand-blue">Data Collection:</strong> Secure SCADA exports, meteorological tower data, power quality logs, and maintenance tickets.
            </li>
            <li>
              <strong className="font-semibold text-brand-blue">Analytical Diagnostics:</strong> Perform statistical modelling, variance analysis, and benchmarking using Canadian climate datasets.
            </li>
            <li>
              <strong className="font-semibold text-brand-blue">Field Validation:</strong> Conduct site walkthroughs, interviews, and component inspections with calibrated measuring tools.
            </li>
            <li>
              <strong className="font-semibold text-brand-blue">Reporting &amp; Workshops:</strong> Deliver interactive dashboards, executive summaries, and operations-focused deep dives.
            </li>
          </ol>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
          className="grid gap-10 md:grid-cols-2"
        >
          <div className="rounded-3xl bg-brand-paper p-8 shadow-soft">
            <h3 className="text-xl font-semibold text-brand-dark">Engineering Certifications</h3>
            <ul className="mt-4 space-y-3 text-sm text-slate-700">
              <li>Professional Engineers Ontario (PEO) licensed practitioners.</li>
              <li>Engineers and Geoscientists British Columbia registration for west coast assignments.</li>
              <li>Measurement and Verification professionals with IPMVP training.</li>
              <li>ISO 31000 risk management and ISO 55000 asset management alignment.</li>
            </ul>
          </div>
          <div className="rounded-3xl bg-brand-dark p-8 text-white shadow-soft">
            <h3 className="text-xl font-semibold text-brand-yellow">Canadian Regulatory Context</h3>
            <p className="mt-4 text-sm text-white/85">
              We interpret Canadian Energy Regulator guidance, provincial clean energy policies, and Indigenous partnership frameworks. Our team tracks updates from the Canada Energy Regulator, Independent Electricity System Operator (IESO), Alberta AESO, and regional authorities to ensure audit recommendations support compliance and respectful engagement.
            </p>
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
          className="rounded-3xl bg-white p-8 shadow-soft"
        >
          <h2 className="text-2xl font-semibold text-brand-dark">Quality Assurance Principles</h2>
          <div className="mt-4 grid gap-6 md:grid-cols-2">
            <div>
              <h4 className="text-sm font-semibold text-brand-blue uppercase tracking-wide">Peer Review</h4>
              <p className="mt-2 text-sm text-slate-700">
                Every audit undergoes internal peer review by engineers versed in solar, wind, and energy storage technologies, ensuring balanced findings.
              </p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-brand-blue uppercase tracking-wide">Traceability</h4>
              <p className="mt-2 text-sm text-slate-700">
                We maintain Menlo-style traceability matrices linking observations to evidence, standards, and recommended actions.
              </p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-brand-blue uppercase tracking-wide">Data Integrity</h4>
              <p className="mt-2 text-sm text-slate-700">
                All data handling procedures follow secure transfer protocols, version control, and quality checks against raw sources.
              </p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-brand-blue uppercase tracking-wide">Collaborative Delivery</h4>
              <p className="mt-2 text-sm text-slate-700">
                Workshops include owner&apos;s engineers, O&amp;M teams, and financiers to foster alignment and accelerate execution.
              </p>
            </div>
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
          className="rounded-3xl bg-brand-blue p-8 text-white shadow-soft"
        >
          <h2 className="text-2xl font-semibold">Commitment to Sustainability</h2>
          <p className="mt-4 text-sm text-white/85">
            Clean Asset Audit advances sustainable development through objective insights and transparent collaboration. We integrate Indigenous engagement principles, climate resilience assessments, and circular economy thinking into our reports. Our internal operations track emissions, prioritize low-carbon travel, and support local community initiatives in Toronto and project regions alike.
          </p>
        </motion.section>
      </div>
    </>
  );
};

export default About;