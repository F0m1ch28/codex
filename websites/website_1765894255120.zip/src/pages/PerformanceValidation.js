import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const PerformanceValidation = () => {
  const kpis = [
    {
      title: "Design vs. Actual Production",
      detail:
        "We reconcile theoretical models with real-time and historical production, accounting for irradiance, wind regimes, and operational constraints."
    },
    {
      title: "Acceptance Test Analysis",
      detail:
        "Detailed review of acceptance test protocols, measurement uncertainty, and corrective actions required after COD."
    },
    {
      title: "Deviation Diagnostics",
      detail:
        "Root cause identification for energy shortfalls using machine learning clustering, engineering judgement, and field observations."
    },
    {
      title: "KPI Benchmarking",
      detail:
        "Comparison of availability, capacity factor, and curtailment metrics against Canadian peer groups and OEM expectations."
    },
    {
      title: "Seasonal Normalization",
      detail:
        "Adjustments for seasonal irradiance, snow, icing, and temperature impacts to understand underlying performance."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Performance Validation | Clean Asset Audit</title>
        <meta
          name="description"
          content="Clean Asset Audit aligns design models with operational results through KPI benchmarking, acceptance test analysis, deviation studies, and seasonal normalization."
        />
        <meta property="og:title" content="Performance Validation for Renewable Assets" />
        <meta
          property="og:description"
          content="Uncover how design expectations compare to measured performance using Clean Asset Audit's data-rich validation methodology."
        />
        <meta property="og:url" content="https://www.cleanassetaudit.com/performance-validation" />
      </Helmet>

      <div className="mx-auto max-w-6xl px-6 py-20 lg:px-10">
        <motion.div
          className="space-y-5"
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <span className="badge">Performance Validation intelligence</span>
          <h1 className="text-4xl font-semibold text-brand-dark">Precise comparison of design intent and operational reality.</h1>
          <p className="text-sm text-slate-700">
            We deliver clean energy performance validation reports that put SCADA, meteorological, and revenue meter data into perspective. Whether you&apos;re verifying EPC delivery, supporting lenders, or optimizing an operating fleet, our structured process pinpoints what drives performance variance.
          </p>
        </motion.div>

        <motion.div
          className="mt-12 grid gap-6 md:grid-cols-2"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          transition={{ staggerChildren: 0.1 }}
        >
          {kpis.map((item) => (
            <motion.div
              key={item.title}
              variants={{
                hidden: { opacity: 0, y: 32 },
                visible: { opacity: 1, y: 0 }
              }}
              className="rounded-3xl border border-brand-dark/10 bg-white p-6 shadow-soft"
            >
              <h2 className="text-xl font-semibold text-brand-blue">{item.title}</h2>
              <p className="mt-3 text-sm text-slate-700">{item.detail}</p>
            </motion.div>
          ))}
        </motion.div>

        <motion.section
          className="mt-16 rounded-3xl bg-brand-dark px-6 py-10 text-white lg:px-10"
          initial={{ opacity: 0, y: 36 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
        >
          <h2 className="text-2xl font-semibold text-brand-yellow">Our Validation Workflow</h2>
          <ul className="mt-6 space-y-4 text-sm text-white/85">
            <li>
              <strong className="text-brand-yellow">1. Baseline Alignment:</strong> Load design models, contractual performance thresholds, and grid dispatch conditions to set the validation framework.
            </li>
            <li>
              <strong className="text-brand-yellow">2. Data Harmonization:</strong> Clean and synchronize SCADA, weather, and revenue meter data while addressing missing values and timestamp offsets.
            </li>
            <li>
              <strong className="text-brand-yellow">3. KPI Benchmarking:</strong> Benchmark capacity factor, efficiency, and downtime with Canadian climate references and industry databases.
            </li>
            <li>
              <strong className="text-brand-yellow">4. Deviation Analysis:</strong> Apply regression models, time-of-day studies, and event logs to isolate underlying contributors to energy variance.
            </li>
            <li>
              <strong className="text-brand-yellow">5. Actionable Insights:</strong> Deliver clear narratives, dashboards, and follow-up support to embed improvements in operations.
            </li>
          </ul>
        </motion.section>
      </div>
    </>
  );
};

export default PerformanceValidation;