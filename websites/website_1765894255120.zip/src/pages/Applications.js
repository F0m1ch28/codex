import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const Applications = () => {
  const applications = [
    {
      title: "Utility-Scale Solar",
      description:
        "Audits covering energy yield, inverter performance, tracker reliability, and snow management strategies in provinces from Ontario to Alberta."
    },
    {
      title: "Onshore Wind Farms",
      description:
        "Performance validation for turbines in cold climates, addressing icing, wake interactions, and power curve testing across Canadian terrains."
    },
    {
      title: "Hybrid Renewable Facilities",
      description:
        "Integrated analysis for solar-plus-storage or wind-plus-storage assets, ensuring control logics and dispatch strategies align with design intent."
    },
    {
      title: "Commercial Clean Energy Assets",
      description:
        "Audits for commercial rooftops, community solar programs, and distributed wind installations with a focus on compliance and stakeholder reporting."
    },
    {
      title: "Regional Canadian Projects",
      description:
        "Insight into provincial requirements, from Atlantic Canada&apos;s maritime conditions to Prairie wind regimes and BC hydroelectric integration."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Applications | Clean Asset Audit</title>
        <meta
          name="description"
          content="Clean Asset Audit supports utility-scale solar, onshore wind, hybrid renewable facilities, commercial clean energy assets, and regional Canadian projects."
        />
        <meta property="og:title" content="Applications of Clean Asset Audit Services" />
        <meta property="og:url" content="https://www.cleanassetaudit.com/applications" />
      </Helmet>

      <div className="mx-auto max-w-6xl px-6 py-20 lg:px-10">
        <motion.div
          className="space-y-5"
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <span className="badge">Applications</span>
          <h1 className="text-4xl font-semibold text-brand-dark">Where we apply lifecycle auditing expertise.</h1>
          <p className="text-sm text-slate-700">
            Clean Asset Audit works with utilities, developers, lenders, and community partners. Our geographic reach spans all Canadian provinces and territories, adapting to local environmental conditions and regulatory expectations.
          </p>
        </motion.div>

        <motion.div
          className="mt-12 grid gap-6 md:grid-cols-2"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          transition={{ staggerChildren: 0.1 }}
        >
          {applications.map((item) => (
            <motion.div
              key={item.title}
              variants={{
                hidden: { opacity: 0, y: 32 },
                visible: { opacity: 1, y: 0 }
              }}
              className="rounded-3xl border border-brand-dark/10 bg-white p-6 shadow-soft"
            >
              <h2 className="text-xl font-semibold text-brand-blue">{item.title}</h2>
              <p className="mt-3 text-sm text-slate-700">{item.description}</p>
            </motion.div>
          ))}
        </motion.div>

        <motion.section
          className="mt-16 rounded-3xl bg-brand-dark px-6 py-10 text-white lg:px-10"
          initial={{ opacity: 0, y: 36 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55 }}
        >
          <h2 className="text-2xl font-semibold text-brand-yellow">Regional Expertise</h2>
          <p className="mt-4 text-sm text-white/85">
            We understand Canadian project realities: permafrost challenges in the north, aggressive freeze-thaw cycles in the Prairies, salinity impacts along the coasts, and snow loading across the country. Our audits draw upon site visits, satellite imagery, and historical weather data to make recommendations that stand up to real-world conditions.
          </p>
        </motion.section>
      </div>
    </>
  );
};

export default Applications;