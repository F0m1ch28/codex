import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

const initialForm = {
  name: "",
  email: "",
  company: "",
  assetType: "",
  message: ""
};

const Contact = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please share your name.";
    if (!formData.email.trim()) {
      newErrors.email = "An email address is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Enter a valid email address.";
    }
    if (!formData.company.trim()) newErrors.company = "Please indicate your organization.";
    if (!formData.assetType.trim()) newErrors.assetType = "Let us know the asset type or project focus.";
    if (!formData.message.trim()) newErrors.message = "Provide a brief overview of your request.";
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      await fetch("/thanks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
    } catch (error) {
      // Silently continue; offline-ready
    } finally {
      navigate("/thanks", { state: { name: formData.name } });
      setFormData(initialForm);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact | Clean Asset Audit</title>
        <meta
          name="description"
          content="Contact Clean Asset Audit for renewable asset lifecycle auditing, clean energy performance validation, and degradation tracking services across Canada."
        />
        <meta property="og:title" content="Contact Clean Asset Audit" />
        <meta property="og:url" content="https://www.cleanassetaudit.com/contact" />
        <meta
          property="og:description"
          content="Reach our Toronto office to request renewable asset audit support or performance validation insights."
        />
      </Helmet>

      <div className="bg-white">
        <div className="mx-auto grid max-w-6xl gap-12 px-6 py-20 lg:grid-cols-[1.4fr,1fr] lg:px-10">
          <motion.div
            className="rounded-3xl border border-brand-dark/10 bg-brand-paper p-8 shadow-soft"
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55 }}
          >
            <span className="badge">Get in touch</span>
            <h1 className="mt-4 text-3xl font-semibold text-brand-dark">Request a renewable asset audit conversation</h1>
            <p className="mt-3 text-sm text-slate-700">
              Tell us about your project and we&apos;ll align the right lifecycle specialists. We support solar, wind, and hybrid assets at every stage in Canada.
            </p>
            <form className="mt-8 space-y-5" noValidate onSubmit={handleSubmit}>
              <div>
                <label className="form-label" htmlFor="name">
                  Name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  className={`form-input ${errors.name ? "form-input-error" : ""}`}
                  value={formData.name}
                  onChange={handleChange}
                  aria-describedby={errors.name ? "name-error" : undefined}
                  required
                />
                {errors.name && (
                  <p id="name-error" className="form-error" role="alert">
                    {errors.name}
                  </p>
                )}
              </div>

              <div>
                <label className="form-label" htmlFor="email">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  className={`form-input ${errors.email ? "form-input-error" : ""}`}
                  value={formData.email}
                  onChange={handleChange}
                  aria-describedby={errors.email ? "email-error" : undefined}
                  required
                />
                {errors.email && (
                  <p id="email-error" className="form-error" role="alert">
                    {errors.email}
                  </p>
                )}
              </div>

              <div>
                <label className="form-label" htmlFor="company">
                  Organization
                </label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  className={`form-input ${errors.company ? "form-input-error" : ""}`}
                  value={formData.company}
                  onChange={handleChange}
                  aria-describedby={errors.company ? "company-error" : undefined}
                  required
                />
                {errors.company && (
                  <p id="company-error" className="form-error" role="alert">
                    {errors.company}
                  </p>
                )}
              </div>

              <div>
                <label className="form-label" htmlFor="assetType">
                  Asset Type or Project Focus
                </label>
                <input
                  id="assetType"
                  name="assetType"
                  type="text"
                  className={`form-input ${errors.assetType ? "form-input-error" : ""}`}
                  value={formData.assetType}
                  onChange={handleChange}
                  aria-describedby={errors.assetType ? "assetType-error" : undefined}
                  required
                />
                {errors.assetType && (
                  <p id="assetType-error" className="form-error" role="alert">
                    {errors.assetType}
                  </p>
                )}
              </div>

              <div>
                <label className="form-label" htmlFor="message">
                  How can we help?
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  className={`form-textarea ${errors.message ? "form-input-error" : ""}`}
                  value={formData.message}
                  onChange={handleChange}
                  aria-describedby={errors.message ? "message-error" : undefined}
                  required
                />
                {errors.message && (
                  <p id="message-error" className="form-error" role="alert">
                    {errors.message}
                  </p>
                )}
              </div>

              <div className="pt-2">
                <button type="submit" className="btn-primary">
                  Request Renewable Asset Audit
                </button>
              </div>
            </form>
          </motion.div>

          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.1 }}
          >
            <div className="rounded-3xl bg-brand-dark p-6 text-white shadow-soft">
              <h2 className="text-xl font-semibold text-brand-yellow">Toronto Office</h2>
              <p className="mt-3 text-sm text-white/80">
                Bay Adelaide Centre<br />
                333 Bay Street, Floor 19<br />
                Toronto, Ontario, Canada
              </p>
              <p className="mt-4 text-sm text-white/80">
                Phone:{" "}
                <a className="underline" href="tel:+14169016728">
                  +1 416 901 6728
                </a>
              </p>
              <p className="text-sm text-white/80">
                Email:{" "}
                <a className="underline" href="mailto:info@cleanassetaudit.com">
                  info@cleanassetaudit.com
                </a>
              </p>
            </div>

            <div className="overflow-hidden rounded-3xl shadow-soft">
              <iframe
                title="Clean Asset Audit Toronto Office Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.3570631735715!2d-79.38014462339697!3d43.64986827110233!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d62950f1f3%3A0xccf994a647ce8521!2sBay%20Adelaide%20Centre!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"
                width="100%"
                height="320"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            <div className="rounded-3xl border border-brand-dark/10 bg-brand-paper p-6 text-sm text-slate-700 shadow-soft">
              <h3 className="text-base font-semibold text-brand-dark">
                What happens next?
              </h3>
              <ol className="mt-4 space-y-3">
                <li>
                  <span className="font-semibold text-brand-blue">1.</span> We respond within two business days to confirm context and align on scope.
                </li>
                <li>
                  <span className="font-semibold text-brand-blue">2.</span> A technical lead connects for a briefing call to explore data availability, timelines, and stakeholders.
                </li>
                <li>
                  <span className="font-semibold text-brand-blue">3.</span> We issue a tailored proposal outlining lifecycle audit modules and deliverables.
                </li>
              </ol>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Contact;