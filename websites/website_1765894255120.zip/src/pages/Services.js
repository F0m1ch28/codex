import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const Services = () => {
  const services = [
    {
      title: "Pre-Commissioning Audits",
      description:
        "Independent review of EPC documentation, factory acceptance testing, protection coordination, and commissioning procedures. Our team validates that solar inverters, wind turbine controllers, and hybrid energy management systems align with design expectations before commercial operation.",
      highlights: [
        "Inspection of interconnection approvals, SCADA architecture, and protection relay settings.",
        "Verification of start-up test plans, ITP completion, and turnover packages.",
        "Readiness assessments that accelerate lender consent and regulatory filings."
      ]
    },
    {
      title: "Operational Performance Audits",
      description:
        "Detailed analysis of operating assets using high-resolution SCADA, meteorological inputs, and power meter data. We contextualize energy production against weather-corrected models, availability metrics, and Canadian benchmarks.",
      highlights: [
        "Performance validation Canada-wide using peer group benchmarking and P50/P90 reconciliation.",
        "Component-level inspection including transformers, blades, trackers, and balance-of-plant systems.",
        "Recommendations prioritized by energy impact, risk profile, and implementation feasibility."
      ]
    },
    {
      title: "Compliance Verification",
      description:
        "Assessments tailored to grid code updates, environmental approvals, and Indigenous partnership commitments. We ensure documentation and operational practices align with evolving requirements.",
      highlights: [
        "Review of IESO, AESO, BC Hydro, and Hydro-Québec compliance frameworks.",
        "Evidence packages prepared for regulatory submissions and stakeholder communication.",
        "Action plans aligned with occupational health and safety, electrical code, and environmental stewardship standards."
      ]
    },
    {
      title: "Documentation Analysis",
      description:
        "Structured review of contracts, operating procedures, maintenance logs, and data governance practices. Findings are organized in traceable matrices for easy follow-up.",
      highlights: [
        "Gap analysis across design documents, O&amp;M manuals, and warranty obligations.",
        "Digital twin of documentation with metadata tagging and revision tracking.",
        "Insight into how document control supports lifecycle assessment renewables objectives."
      ]
    },
    {
      title: "Corrective Action Frameworks",
      description:
        "Comprehensive improvement roadmaps built on audit discoveries. We define clear owners, timelines, and performance indicators to close issues efficiently.",
      highlights: [
        "Prioritized action registers categorized by safety, reliability, energy yield, and compliance.",
        "Integration with CMMS platforms and asset management systems.",
        "Follow-up analytics to confirm degradation tracking clean energy targets are met."
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Audit Services | Clean Asset Audit</title>
        <meta
          name="description"
          content="Explore Clean Asset Audit services: pre-commissioning audits, operational performance audits, compliance verification, documentation analysis, and corrective action frameworks for renewable assets."
        />
        <meta property="og:title" content="Audit Services for Renewable Assets in Canada" />
        <meta property="og:url" content="https://www.cleanassetaudit.com/audit-services" />
        <meta
          property="og:description"
          content="Lifecycle-focused audit services covering commissioning, operations, compliance, documentation, and improvement planning."
        />
      </Helmet>

      <div className="bg-white">
        <div className="mx-auto max-w-6xl px-6 py-20 lg:px-10">
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55 }}
          >
            <span className="badge">Renewable Asset Audit Services</span>
            <h1 className="text-4xl font-semibold text-brand-dark">Comprehensive audit services tailored to each asset stage.</h1>
            <p className="max-w-3xl text-sm text-slate-700">
              Clean Asset Audit delivers independent assessments that align technical performance with contractual and regulatory obligations. Each service module can be deployed standalone or combined into a multi-phase lifecycle mandate spanning solar, wind, and hybrid projects.
            </p>
          </motion.div>

          <div className="mt-12 space-y-12">
            {services.map((service, index) => (
              <motion.article
                key={service.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, delay: index * 0.05 }}
                className="rounded-3xl border border-brand-dark/10 bg-brand-paper p-8 shadow-soft"
              >
                <h2 className="text-2xl font-semibold text-brand-dark">{service.title}</h2>
                <p className="mt-3 text-sm text-slate-700">{service.description}</p>
                <ul className="mt-6 space-y-3 text-sm text-slate-700">
                  {service.highlights.map((item) => (
                    <li key={item} className="flex items-start gap-3">
                      <span className="mt-1 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-brand-blue" />
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Services;