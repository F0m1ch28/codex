import React from "react";
import { Helmet } from "react-helmet-async";
import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";

const Thanks = () => {
  const location = useLocation();
  const name = location?.state?.name;

  return (
    <>
      <Helmet>
        <title>Request Received | Clean Asset Audit</title>
        <meta name="description" content="Thank you for contacting Clean Asset Audit. We will respond shortly." />
      </Helmet>

      <div className="mx-auto max-w-4xl px-6 py-24 text-center lg:px-10">
        <motion.div
          className="rounded-3xl bg-white p-12 shadow-soft"
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <span className="badge">Request received</span>
          <h1 className="mt-6 text-3xl font-semibold text-brand-dark">
            Thank you{name ? `, ${name}` : ""}! We&apos;ll be in touch.
          </h1>
          <p className="mt-4 text-sm text-slate-700">
            Our renewable asset audit specialists will review your message and respond within two business days. If you need immediate assistance, call us at{" "}
            <a className="underline" href="tel:+14169016728">
              +1 416 901 6728
            </a>
            .
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link to="/" className="btn-primary">
              Return to Home
            </Link>
            <Link to="/performance-validation" className="btn-secondary">
              Explore performance validation
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Thanks;