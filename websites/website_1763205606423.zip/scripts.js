document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menu-toggle');
    const nav = document.querySelector('.site-nav');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const currentYear = document.getElementById('current-year');

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }

    if (menuToggle && nav) {
        menuToggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('open');
            menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    window.addEventListener('scroll', () => {
        if (scrollBtn) {
            scrollBtn.style.display = window.scrollY > 300 ? 'flex' : 'none';
        }
    });

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner) {
        const consent = localStorage.getItem('adwCookieConsent');
        if (consent === 'accepted') {
            cookieBanner.style.display = 'none';
        } else {
            cookieBanner.style.display = 'block';
        }

        if (acceptCookiesBtn) {
            acceptCookiesBtn.addEventListener('click', () => {
                localStorage.setItem('adwCookieConsent', 'accepted');
                cookieBanner.style.display = 'none';
            });
        }
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const statusField = document.getElementById('formStatus');
            if (statusField) {
                statusField.textContent = 'Thank you. Our consultants will reach out within one business day.';
            }
            contactForm.reset();
        });
    }
});