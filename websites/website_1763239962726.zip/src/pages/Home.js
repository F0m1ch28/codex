import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const statsData = [
  { label: 'Installationen in Bayern', value: 860, unit: '+', description: 'erfolgreich umgesetzt' },
  { label: 'Kundenzufriedenheit', value: 98, unit: '%', description: 'zufriedene Kundinnen und Kunden' },
  { label: 'Tonnen CO₂ eingespart', value: 12750, unit: '+', description: 'durch nachhaltige Energie' },
  { label: 'Jahre Erfahrung', value: 15, unit: '', description: 'Photovoltaik-Expertise' }
];

const servicesData = [
  {
    icon: '🏡',
    title: 'Photovoltaik für Eigenheime',
    description: 'Maßgeschneiderte PV-Anlagen für Ein- und Mehrfamilienhäuser in ganz Bayern.',
    points: [
      'Leistungsstarke Module mit maximalem Ertrag',
      'Speichersysteme für maximale Autarkie',
      'Smart-Home-Integration und Monitoring'
    ],
    image: 'https://picsum.photos/800/600?random=101'
  },
  {
    icon: '🏢',
    title: 'Gewerbliche Solarlösungen',
    description: 'Skalierbare Anlagen für Unternehmen, Landwirtschaft und Industrie.',
    points: [
      'Lastprofile-Analyse und Wirtschaftlichkeitsberechnung',
      'Dach- und Freiflächenlösungen',
      'Finanzierungs- und Fördermittelberatung'
    ],
    image: 'https://picsum.photos/800/600?random=102'
  },
  {
    icon: '🛠️',
    title: 'Wartung & Monitoring',
    description: 'Proaktive Wartung, Fernüberwachung und Soforthilfe bei Störungen.',
    points: [
      '24/7-Überwachung via Leitstand',
      'Regelmäßige Inspektionen & Reinigung',
      'Leistungsoptimierung in Echtzeit'
    ],
    image: 'https://picsum.photos/800/600?random=103'
  },
  {
    icon: '🧭',
    title: 'Beratung & Planung',
    description: 'Ganzheitliche Beratung von der ersten Idee bis zur Netzanbindung.',
    points: [
      'Ertrags- und Verschattungsanalysen',
      'Genehmigungsmanagement & Netzanschluss',
      'Transparente Projektsteuerung'
    ],
    image: 'https://picsum.photos/800/600?random=104'
  }
];

const advantagesData = [
  {
    icon: '⚡',
    title: 'Unabhängige Energieversorgung',
    description: 'Reduzieren Sie Ihre Stromkosten nachhaltig und sichern Sie sich stabile Energiepreise.'
  },
  {
    icon: '🌿',
    title: 'Nachhaltiger Klimaschutz',
    description: 'Mit jeder Anlage vermeiden Sie CO₂-Emissionen und leisten einen messbaren Beitrag für Bayern.'
  },
  {
    icon: '💡',
    title: 'Innovative Technologie',
    description: 'Wir verbauen ausschließlich erprobte Premiummodule mit modernster Leistungselektronik.'
  },
  {
    icon: '🤝',
    title: 'Regionale Servicepartner',
    description: 'Unser Team aus München und regionale Partnerbetriebe gewährleisten kurze Wege und schnelle Hilfe.'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Bedarfsanalyse & Potentialcheck',
    description: 'Wir analysieren Ihr Dach, Ihren Verbrauch und identifizieren Fördermöglichkeiten.'
  },
  {
    step: '02',
    title: 'Individuelles Konzept',
    description: 'Sie erhalten ein detailliertes Angebot mit Wirtschaftlichkeitsberechnung und Visualisierung.'
  },
  {
    step: '03',
    title: 'Genehmigungen & Förderung',
    description: 'Wir kümmern uns um Netzanschluss, Behörden und sichern Fördermittel für Ihr Projekt.'
  },
  {
    step: '04',
    title: 'Installation & Inbetriebnahme',
    description: 'Unsere erfahrenen Montageteams installieren Ihre Anlage sauber und termintreu.'
  },
  {
    step: '05',
    title: 'Monitoring & Support',
    description: 'Nach der Inbetriebnahme begleiten wir Sie mit digitalem Monitoring und Wartungsverträgen.'
  }
];

const testimonialsData = [
  {
    quote:
      'GreenTech Solutions hat unsere Firmenzentrale in Augsburg innerhalb von acht Wochen auf Solarstrom umgestellt. Die Zusammenarbeit war beeindruckend professionell.',
    name: 'Dr. Markus Schneider',
    role: 'Geschäftsführer, Schneider & Partner GmbH',
    image: 'https://picsum.photos/200/200?random=105'
  },
  {
    quote:
      'Die Beratung war transparent, die Montage schnell und sauber. Dank Speicherlösung nutzen wir jetzt 82% unseres Stroms selbst.',
    name: 'Julia und Thomas Wagner',
    role: 'Eigenheimbesitzer aus Regensburg',
    image: 'https://picsum.photos/200/200?random=106'
  },
  {
    quote:
      'Wir haben unsere landwirtschaftlichen Hallen mit GreenTech Solutions ausgestattet. Die Erträge liegen sogar über den Prognosen.',
    name: 'Katharina Bauer',
    role: 'Landwirtin aus Rosenheim',
    image: 'https://picsum.photos/200/200?random=107'
  }
];

const projectHighlights = [
  {
    title: 'Solarpark für Logistikzentrum',
    category: 'Gewerbe',
    description: '1,2 MWp Dachanlage mit intelligenter Laststeuerung in Nürnberg.',
    image: 'https://picsum.photos/800/600?random=108'
  },
  {
    title: 'Energetische Sanierung eines Mehrfamilienhauses',
    category: 'Wohnbau',
    description: '75 kWp Fassaden- und Dachanlage mit Mieterstrommodell in München.',
    image: 'https://picsum.photos/800/600?random=109'
  },
  {
    title: 'Agri-PV in der Oberpfalz',
    category: 'Landwirtschaft',
    description: 'Hybridlösung für Stall und Hofladen mit 45 kWh Speicher.',
    image: 'https://picsum.photos/800/600?random=110'
  }
];

const faqData = [
  {
    question: 'Welche Förderungen kann ich für eine Photovoltaikanlage in Bayern nutzen?',
    answer:
      'Wir prüfen für Sie regionale Programme wie das 10.000-Häuser-Programm, KfW-Kredite sowie steuerliche Vorteile und übernehmen auf Wunsch die Antragstellung.'
  },
  {
    question: 'Wie lange dauert es von der Anfrage bis zur Inbetriebnahme?',
    answer:
      'Je nach Projektumfang benötigen wir zwischen 6 und 12 Wochen. Dazu zählen Planung, Genehmigungen, Montage und der Netzanschluss durch den Energieversorger.'
  },
  {
    question: 'Kann ich meine bestehende Anlage erweitern lassen?',
    answer:
      'Ja. Wir analysieren Ihren Bestand, prüfen Dachlasten, Netzkapazitäten und integrieren Erweiterungen oder Speicherlösungen nahtlos in Ihr System.'
  },
  {
    question: 'Bieten Sie auch Wartungsverträge an?',
    answer:
      'Natürlich. Mit unseren Wartungspaketen erhalten Sie regelmäßige Checks, Reinigung, Versicherungspakete und laufendes Monitoring mit Alarmfunktion.'
  }
];

const blogPosts = [
  {
    title: 'Warum sich Photovoltaik in Bayern besonders lohnt',
    date: '18. Januar 2024',
    excerpt:
      'Sonneneinstrahlung, Förderungen und Netzeinspeisung im Überblick – wir zeigen die wichtigsten Argumente.',
    image: 'https://picsum.photos/600/400?random=111',
    link: '/leistungen'
  },
  {
    title: 'So planen Sie Speicherlösungen richtig',
    date: '05. Februar 2024',
    excerpt: 'Von Kapazität bis Lastprofil: Unsere Expertentipps für wirtschaftliche Batteriesysteme.',
    image: 'https://picsum.photos/600/400?random=112',
    link: '/leistungen'
  },
  {
    title: 'Solarstrom für Unternehmen: steuerliche Vorteile 2024',
    date: '28. März 2024',
    excerpt: 'Welche steuerlichen Rahmenbedingungen aktuell gelten und wie Sie profitieren.',
    image: 'https://picsum.photos/600/400?random=113',
    link: '/ueber-uns'
  }
];

const initialFormState = {
  name: '',
  email: '',
  telefon: '',
  nachricht: ''
};

const Home = () => {
  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeFaq, setActiveFaq] = useState(null);
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      let current = 0;
      const target = stat.value;
      const increment = target / 60;
      const interval = setInterval(() => {
        current += increment;
        setStatValues((prevValues) => {
          const updated = [...prevValues];
          updated[index] = current >= target ? target : Math.round(current);
          return updated;
        });
        if (current >= target) {
          clearInterval(interval);
        }
      }, 30);
      return interval;
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const timer = setInterval(
      () => setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length),
      7000
    );
    return () => clearInterval(timer);
  }, [currentTestimonial]);

  const toggleFaq = (index) => {
    setActiveFaq((prev) => (prev === index ? null : index));
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setSubmitted(false);
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (formData.telefon && !/^[\d+\s()-]{6,}$/.test(formData.telefon)) {
      newErrors.telefon = 'Bitte geben Sie eine gültige Telefonnummer ein.';
    }
    if (!formData.nachricht.trim()) {
      newErrors.nachricht = 'Bitte schildern Sie Ihr Anliegen.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>GreenTech Solutions | Solarenergie aus Bayern</title>
        <meta
          name="description"
          content="GreenTech Solutions ist Ihr Münchner Spezialist für Solaranlagen, Speicherlösungen und nachhaltige Energie in Bayern."
        />
        <meta
          name="keywords"
          content="solaranlagen, photovoltaik, bavaria, nachhaltigkeit, erneuerbare energie, greentech solutions"
        />
        <link rel="canonical" href="https://www.greentech-solutions.de/" />
      </Helmet>

      <section
        className={styles.hero}
        style={{
          backgroundImage:
            'linear-gradient(120deg, rgba(33,33,33,0.45), rgba(46,125,50,0.7)), url(https://picsum.photos/1600/900?random=121)'
        }}
      >
        <div className={`container ${styles.heroContent}`}>
          <span className={styles.heroBadge}>Solarenergie aus Bayern</span>
          <h1 className={styles.heroTitle}>
            Effiziente Photovoltaiklösungen für private und gewerbliche Kunden
          </h1>
          <p className={styles.heroText}>
            Wir planen, installieren und betreuen hochmoderne Solaranlagen, die Sie unabhängig von steigenden
            Strompreisen machen. Profitieren Sie von regionaler Expertise, transparenten Prozessen und messbarem Erfolg.
          </p>
          <div className={styles.heroButtons}>
            <Link className={`btn btn-primary ${styles.heroCta}`} to="/kontakt">
              Kostenlose Beratung sichern
            </Link>
            <Link className={`btn btn-secondary ${styles.heroSecondary}`} to="/projekte">
              Erfolgsprojekte entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.stats} section`}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {statValues[index]}
                  {stat.unit}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
                <p className={styles.statDescription}>{stat.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.services} section`} id="leistungen">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Unsere Leistungen</h2>
            <p className={styles.sectionSubtitle}>
              Von der ersten Idee bis zur langfristigen Betreuung – GreenTech Solutions liefert ganzheitliche
              Photovoltaiklösungen für Bayern.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3 className={styles.serviceTitle}>{service.title}</h3>
                <p className={styles.serviceDescription}>{service.description}</p>
                <ul className={styles.serviceList}>
                  {service.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
                <div
                  className={styles.serviceMedia}
                  style={{ backgroundImage: `url(${service.image})` }}
                  aria-hidden="true"
                />
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.advantages} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Ihre Vorteile mit GreenTech Solutions</h2>
            <p className={styles.sectionSubtitle}>
              Vertrauen Sie auf ein erfahrenes Expertenteam, transparente Kommunikation und führende Technologien.
            </p>
          </div>
          <div className={styles.advantageList}>
            {advantagesData.map((advantage) => (
              <article key={advantage.title} className={styles.advantageItem}>
                <div className={styles.advantageIcon} aria-hidden="true">
                  {advantage.icon}
                </div>
                <div>
                  <h3>{advantage.title}</h3>
                  <p>{advantage.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.process} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>So läuft die Zusammenarbeit</h2>
            <p className={styles.sectionSubtitle}>
              Strukturierte Prozesse, klare Ansprechpartner:innen und volle Transparenz in jeder Phase Ihres Projekts.
            </p>
          </div>
          <div className={styles.processSteps}>
            {processSteps.map((step) => (
              <article key={step.step} className={styles.processStep}>
                <span className={styles.processNumber}>{step.step}</span>
                <div className={styles.processContent}>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} section`} aria-labelledby="kundenstimmen-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="kundenstimmen-heading" className={styles.sectionTitle}>
              Stimmen unserer Kundschaft
            </h2>
            <p className={styles.sectionSubtitle}>
              Echte Erfahrungen aus Wohnbau, Gewerbe und Landwirtschaft – wir sind stolz auf jedes Projekt.
            </p>
          </div>
          <article className={styles.testimonialCard} aria-live="polite">
            <div className={styles.testimonialQuote}>
              <p>„{testimonialsData[currentTestimonial].quote}“</p>
            </div>
            <div className={styles.testimonialPerson}>
              <img
                src={testimonialsData[currentTestimonial].image}
                alt={`Portrait von ${testimonialsData[currentTestimonial].name}`}
                loading="lazy"
              />
              <div>
                <strong>{testimonialsData[currentTestimonial].name}</strong>
                <span>{testimonialsData[currentTestimonial].role}</span>
              </div>
            </div>
          </article>
          <div className={styles.testimonialNav} role="tablist" aria-label="Kundenstimmen auswählen">
            {testimonialsData.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                className={`${styles.testimonialDot} ${
                  currentTestimonial === index ? styles.activeDot : ''
                }`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Kundenstimme ${index + 1} auswählen`}
                aria-pressed={currentTestimonial === index}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.projects} section`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Projekt-Highlights</h2>
            <p className={styles.sectionSubtitle}>
              Ein Auszug aus über 800 realisierten Photovoltaikanlagen in Bayern. Weitere Projekte finden Sie in unserem
              Portfolio.
            </p>
          </div>
          <div className={styles.projectGrid}>
            {projectHighlights.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div
                  className={styles.projectImage}
                  style={{ backgroundImage: `url(${project.image})` }}
                  aria-hidden="true"
                />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.projectCta}>
            <Link className="btn btn-primary" to="/projekte">
              Alle Referenzen ansehen
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.faq} section`} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="faq-heading" className={styles.sectionTitle}>
              Häufige Fragen
            </h2>
            <p className={styles.sectionSubtitle}>
              Transparente Antworten auf die wichtigsten Fragen rund um Photovoltaik und unsere Dienstleistungen.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <div
                key={item.question}
                className={`${styles.faqItem} ${activeFaq === index ? styles.faqOpen : ''}`}
              >
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => toggleFaq(index)}
                  aria-expanded={activeFaq === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon} aria-hidden="true">
                    {activeFaq === index ? '−' : '+'}
                  </span>
                </button>
                <div className={styles.faqAnswer}>
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blog} section`} aria-labelledby="blog-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog-heading" className={styles.sectionTitle}>
              Aktuelle Einblicke
            </h2>
            <p className={styles.sectionSubtitle}>
              Wissen, Trends und Tipps rund um Photovoltaik, Speicher und nachhaltige Energiekonzepte.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div
                  className={styles.blogImage}
                  style={{ backgroundImage: `url(${post.image})` }}
                  aria-hidden="true"
                />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>
                    Mehr erfahren
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.contactSection} section`} id="kontakt">
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.contactInfo}>
              <span className={styles.contactBadge}>Direktkontakt</span>
              <h2>Wir freuen uns auf Ihr Projekt</h2>
              <p>
                Lassen Sie uns gemeinsam herausfinden, wie Sie von Solarenergie profitieren. Unser Team meldet sich
                innerhalb von 24 Stunden bei Ihnen.
              </p>
              <ul className={styles.contactList}>
                <li>
                  <strong>Adresse:</strong> Musterstraße 123, 80331 München
                </li>
                <li>
                  <strong>Telefon:</strong>{' '}
                  <a href="tel:+498912345678" aria-label="Telefonnummer wählen">
                    +49 89 12345678
                  </a>
                </li>
                <li>
                  <strong>E-Mail:</strong>{' '}
                  <a href="mailto:info@greentech-solutions.de" aria-label="E-Mail schreiben">
                    info@greentech-solutions.de
                  </a>
                </li>
              </ul>
              <Link className="btn btn-secondary" to="/kontakt">
                Alle Kontaktmöglichkeiten
              </Link>
            </div>
            <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
              <div className={styles.formHeader}>
                <h3>Schnellanfrage senden</h3>
                <p>Wir melden uns innerhalb eines Werktags mit den nächsten Schritten.</p>
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="name">Name*</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(errors.name)}
                  required
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">E-Mail*</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(errors.email)}
                  required
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="telefon">Telefon</label>
                <input
                  type="tel"
                  id="telefon"
                  name="telefon"
                  value={formData.telefon}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(errors.telefon)}
                  placeholder="+49 ..."
                />
                {errors.telefon && <span className={styles.error}>{errors.telefon}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="nachricht">Nachricht*</label>
                <textarea
                  id="nachricht"
                  name="nachricht"
                  rows="4"
                  value={formData.nachricht}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(errors.nachricht)}
                  required
                />
                {errors.nachricht && <span className={styles.error}>{errors.nachricht}</span>}
              </div>
              <button type="submit" className="btn btn-primary">
                Anfrage senden
              </button>
              {submitted && (
                <p className={styles.successMessage} role="status">
                  Vielen Dank! Wir haben Ihre Anfrage erhalten und melden uns zeitnah bei Ihnen.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Bereit für Ihren Schritt in Richtung Energieunabhängigkeit?</h2>
            <p>
              Vereinbaren Sie ein unverbindliches Erstgespräch mit unseren Expert:innen und erhalten Sie eine präzise
              Potenzialanalyse für Ihr Objekt.
            </p>
            <div className={styles.ctaButtons}>
              <Link className="btn btn-primary" to="/kontakt">
                Termin vereinbaren
              </Link>
              <Link className="btn btn-secondary" to="/leistungen">
                Leistungen im Überblick
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;