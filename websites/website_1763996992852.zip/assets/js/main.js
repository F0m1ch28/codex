document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  navToggle?.addEventListener('click', () => {
    navToggle.classList.toggle('open');
    siteNav?.classList.toggle('open');
  });

  document.querySelectorAll('.site-nav a').forEach(link => {
    link.addEventListener('click', () => {
      if (window.innerWidth < 768) {
        navToggle?.classList.remove('open');
        siteNav?.classList.remove('open');
      }
    });
  });

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const storedPreference = localStorage.getItem('vm_cookie_pref');

  if (storedPreference) {
    cookieBanner?.classList.add('hidden');
  }

  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('vm_cookie_pref', 'accepted');
    cookieBanner?.classList.add('hidden');
  });

  declineBtn?.addEventListener('click', () => {
    localStorage.setItem('vm_cookie_pref', 'declined');
    cookieBanner?.classList.add('hidden');
  });

  document.querySelectorAll('[data-tracker]').forEach(tracker => {
    const range = tracker.querySelector('[data-range]');
    const rangeValue = tracker.querySelector('[data-range-value]');
    const strategy = tracker.querySelector('[data-strategy]');
    const ahorro = tracker.querySelector('[data-saving]');
    const co2 = tracker.querySelector('[data-co2]');
    const cost = tracker.querySelector('[data-cost]');

    const updateValues = () => {
      const consumo = parseFloat(range?.value || '0');
      const factor = parseFloat(strategy?.value || '0');
      const ahorroEstimado = consumo * factor;
      const co2Estimado = ahorroEstimado * 0.45;
      const costoEstimado = ahorroEstimado * 1100;

      if (rangeValue) {
        rangeValue.textContent = `${consumo.toFixed(0)} MWh`;
      }
      if (ahorro) {
        ahorro.textContent = `${ahorroEstimado.toFixed(1)} MWh`;
      }
      if (co2) {
        co2.textContent = `${co2Estimado.toFixed(1)} t CO₂`;
      }
      if (cost) {
        cost.textContent = `$${costoEstimado.toLocaleString('es-MX')} MXN`;
      }
    };

    range?.addEventListener('input', updateValues);
    strategy?.addEventListener('change', updateValues);
    updateValues();
  });
});