(function () {
  document.addEventListener('DOMContentLoaded', function () {
    const body = document.body;
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-navigation');

    if (navToggle && primaryNav) {
      navToggle.setAttribute('aria-expanded', 'false');
      navToggle.addEventListener('click', () => {
        const isOpen = primaryNav.classList.toggle('is-open');
        navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        navToggle.classList.toggle('is-active', isOpen);
        body.classList.toggle('nav-open', isOpen);
      });

      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && primaryNav.classList.contains('is-open')) {
          primaryNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
          body.classList.remove('nav-open');
        }
      });
    }

    const submenuButtons = document.querySelectorAll('.submenu-toggle');
    const handleSubmenuVisibility = () => {
      submenuButtons.forEach((button) => {
        const submenu = button.nextElementSibling;
        if (!submenu) {
          return;
        }
        if (window.innerWidth >= 1024) {
          submenu.hidden = false;
          button.setAttribute('aria-expanded', 'false');
        } else {
          submenu.hidden = !button.classList.contains('is-open');
        }
      });
    };

    submenuButtons.forEach((button) => {
      const submenu = button.nextElementSibling;
      if (submenu) {
        submenu.hidden = true;
      }
      button.addEventListener('click', () => {
        if (window.innerWidth >= 1024) {
          return;
        }
        const submenu = button.nextElementSibling;
        const isOpen = button.classList.toggle('is-open');
        button.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        if (submenu) {
          submenu.hidden = !isOpen;
        }
      });
    });

    window.addEventListener('resize', handleSubmenuVisibility);
    handleSubmenuVisibility();

    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener('click', function (event) {
        const targetId = this.getAttribute('href').slice(1);
        const target = document.getElementById(targetId);
        if (target) {
          event.preventDefault();
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });

    const fadeObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            fadeObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    document.querySelectorAll('.fade-section').forEach((section) => {
      fadeObserver.observe(section);
    });

    const timelineObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-active');
          }
        });
      },
      { threshold: 0.6 }
    );
    document.querySelectorAll('.timeline-event').forEach((eventItem) => {
      timelineObserver.observe(eventItem);
    });

    const filterButtons = document.querySelectorAll('[data-region-filter]');
    const regionCards = document.querySelectorAll('[data-region]');
    const clearActiveFilters = () => {
      filterButtons.forEach((button) => button.setAttribute('aria-pressed', 'false'));
      regionCards.forEach((card) => card.classList.remove('active-filter'));
    };

    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const filterValue = button.getAttribute('data-region-filter');
        clearActiveFilters();
        button.setAttribute('aria-pressed', 'true');
        regionCards.forEach((card) => {
          if (filterValue === 'todos' || card.getAttribute('data-region') === filterValue) {
            card.style.display = '';
            card.classList.add('active-filter');
          } else {
            card.style.display = 'none';
          }
        });
      });
    });

    const canvas = document.getElementById('comparative-chart');
    if (canvas) {
      const deviceRatio = window.devicePixelRatio || 1;
      const width = canvas.clientWidth * deviceRatio;
      const height = canvas.clientHeight * deviceRatio;
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.scale(deviceRatio, deviceRatio);

      const chartData = [
        { label: 'Energía distribuida', values: [62, 68, 71, 79, 84, 90], color: '#5E35B1' },
        { label: 'Cobertura sanitaria digital', values: [48, 53, 58, 63, 70, 76], color: '#00ACC1' },
      ];
      const years = ['2019', '2020', '2021', '2022', '2023', '2024'];

      const padding = { top: 30, right: 40, bottom: 50, left: 54 };
      const plotWidth = canvas.clientWidth - padding.left - padding.right;
      const plotHeight = canvas.clientHeight - padding.top - padding.bottom;

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 1;
      const horizontalLines = 5;
      for (let i = 0; i <= horizontalLines; i += 1) {
        const y = padding.top + (plotHeight / horizontalLines) * i;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + plotWidth, y);
        ctx.stroke();
        const value = Math.round(40 + ((horizontalLines - i) * (55 / horizontalLines)));
        ctx.fillStyle = 'rgba(230,233,242,0.6)';
        ctx.font = '12px "Inter"';
        ctx.fillText(`${value}%`, padding.left - 40, y + 4);
      }

      years.forEach((year, index) => {
        const x = padding.left + (plotWidth / (years.length - 1)) * index;
        ctx.fillStyle = 'rgba(230,233,242,0.6)';
        ctx.font = '12px "Inter"';
        ctx.fillText(year, x - 10, padding.top + plotHeight + 25);
      });

      chartData.forEach((series) => {
        ctx.beginPath();
        ctx.lineWidth = 3;
        ctx.strokeStyle = series.color;
        series.values.forEach((value, index) => {
          const x = padding.left + (plotWidth / (years.length - 1)) * index;
          const percentage = (value - 40) / 55;
          const y = padding.top + plotHeight - percentage * plotHeight;
          if (index === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        });
        ctx.stroke();

        series.values.forEach((value, index) => {
          const x = padding.left + (plotWidth / (years.length - 1)) * index;
          const percentage = (value - 40) / 55;
          const y = padding.top + plotHeight - percentage * plotHeight;
          ctx.fillStyle = series.color;
          ctx.beginPath();
          ctx.arc(x, y, 5, 0, Math.PI * 2);
          ctx.fill();
        });
      });

      chartData.forEach((series, seriesIndex) => {
        const legendY = padding.top - 12;
        const legendX = padding.left + seriesIndex * 160;
        ctx.fillStyle = series.color;
        ctx.fillRect(legendX, legendY - 12, 18, 6);
        ctx.fillStyle = 'rgba(230,233,242,0.85)';
        ctx.font = '13px "Inter"';
        ctx.fillText(series.label, legendX + 26, legendY - 7);
      });
    }

    const toastNode = document.querySelector('.form-toast');
    const showToast = (message) => {
      if (!toastNode) {
        return;
      }
      toastNode.textContent = message;
      toastNode.classList.add('is-visible');
      setTimeout(() => {
        toastNode.classList.remove('is-visible');
      }, 1100);
    };

    const forms = document.querySelectorAll('form.site-form');
    forms.forEach((form) => {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        showToast('Solicitud registrada. Redirigiendo...');
        setTimeout(() => {
          window.location.href = form.getAttribute('action');
        }, 1200);
      });
    });

    const yearSpans = document.querySelectorAll('#current-year');
    const currentYear = new Date().getFullYear();
    yearSpans.forEach((span) => {
      span.textContent = currentYear;
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookies = document.querySelector('.cookie-accept');
    const rejectCookies = document.querySelector('.cookie-reject');
    const cookieStorageKey = 'odese-cookie-choice';

    if (cookieBanner && acceptCookies && rejectCookies) {
      const storedChoice = localStorage.getItem(cookieStorageKey);
      if (!storedChoice) {
        cookieBanner.classList.add('is-active');
      }
      const handleCookieChoice = (choice) => {
        localStorage.setItem(cookieStorageKey, choice);
        cookieBanner.classList.remove('is-active');
      };
      acceptCookies.addEventListener('click', () => handleCookieChoice('aceptado'));
      rejectCookies.addEventListener('click', () => handleCookieChoice('rechazado'));
    }
  });
})();