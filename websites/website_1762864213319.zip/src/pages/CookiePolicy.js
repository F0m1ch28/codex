import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Политика использования cookies Braventy</title>
        <meta
          name="description"
          content="Braventy использует cookies для обеспечения корректной работы сайта и анализа взаимодействия с пользователями."
        />
      </Helmet>

      <h1>Политика cookies</h1>
      <p>
        Cookies — небольшие файлы, которые сохраняются на вашем устройстве для оптимизации работы сайта. Используя сайт Braventy, вы соглашаетесь на применение cookies.
      </p>
      <h2>1. Какие cookies мы используем</h2>
      <p>
        Технические cookies обеспечивают стабильную работу платформы. Аналитические cookies помогают понимать, как пользователи взаимодействуют с материалами.
      </p>
      <h2>2. Управление cookies</h2>
      <p>
        Вы можете изменить настройки браузера и отказаться от некоторых или всех cookies. Обратите внимание, что отключение технических cookies может повлиять на работу отдельных функций.
      </p>
      <h2>3. Контакты</h2>
      <p>
        Вопросы по политике cookies можно отправить на contact@braventy.eu. Мы ответим и поможем настроить оптимальный режим использования сайта.
      </p>
    </div>
  );
};

export default CookiePolicy;