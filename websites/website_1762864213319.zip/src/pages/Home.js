import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { label: 'Семей, завершивших обучение', value: 860 },
  { label: 'Практических упражнений', value: 120 },
  { label: 'Экспертов-наставников', value: 18 },
  { label: 'Часов живых встреч в месяц', value: 24 },
];

const topics = [
  {
    title: 'Отношения в паре',
    description:
      'Глубокие практики для поддержания доверия, взаимного уважения и романтической близости на долгие годы.',
    icon: '💞',
  },
  {
    title: 'Сознательное воспитание',
    description:
      'Методы, которые помогают детям чувствовать себя услышанными, уверенными и любимыми.',
    icon: '🌱',
  },
  {
    title: 'Эмоциональная грамотность',
    description:
      'Учимся проживать сильные эмоции бережно, без критики и подавления, через диалог и поддержку.',
    icon: '🎧',
  },
  {
    title: 'Коммуникация',
    description:
      'Стратегии ненасильственного общения, активное слушание и искреннее выражение чувств.',
    icon: '🗣️',
  },
];

const steps = [
  {
    title: 'Диагностика и вводная встреча',
    text: 'Стартуем с мягкой оценки текущего состояния семьи. Формируем индивидуальную траекторию и обозначаем цели обучения.',
  },
  {
    title: 'Практические модули и живые сессии',
    text: 'Проходим видеоуроки, участвуем в интерактивных вебинарах, обсуждаем кейсы и закрепляем навыки в домашних сценариях.',
  },
  {
    title: 'Супервизия и обратная связь',
    text: 'Получаем поддержку кураторов и психологов, корректируем стратегию взаимодействия, отмечаем прогресс.',
  },
  {
    title: 'Интеграция в повседневность',
    text: 'Закрепляем новые привычки, формируем ритуалы и семейные договорённости, которые продолжают работать после курса.',
  },
];

const advantages = [
  {
    title: 'Система, которая меняет привычки',
    text: 'Совмещаем учёбу, тренировки навыков и рефлексию, чтобы устойчивые изменения стали новой нормой вашей семьи.',
  },
  {
    title: 'Экспертная команда психологов',
    text: 'С нами телесно-ориентированные терапевты, семейные консультанты, специалисты по детско-родительским отношениям.',
  },
  {
    title: 'Европейский контекст',
    text: 'Работаем с семьями в ЕС, учитывая культурное разнообразие и специфику мультинациональных отношений.',
  },
];

const testimonials = [
  {
    name: 'Ирина и Марко',
    city: 'Амстердам',
    quote:
      'Каждое занятие становилось диалогом, а не лекцией. Мы научились слышать друг друга и создавать пространство для эмоций наших детей.',
  },
  {
    name: 'Ксения и Томас',
    city: 'Берлин',
    quote:
      'Braventy помогла превратить конфликтные ситуации в осознанные встречи. В семье появилось спокойствие и уважение к границам.',
  },
  {
    name: 'Лия и Армин',
    city: 'Вена',
    quote:
      'Программа задала нам новую систему ценностей и ритуалов. Поддержка психологов была невероятно чуткой и ориентированной на нас.',
  },
];

const projects = [
  { id: 1, title: 'Форум «Семейная коммуникация»', category: 'коммуникация', image: 'https://picsum.photos/1200/800?random=4', description: 'Практикум по навыкам диалога и активного слушания.' },
  { id: 2, title: 'Интенсив «Переходы и кризисы»', category: 'кризисы', image: 'https://picsum.photos/1200/800?random=5', description: 'Инструменты для поддерживающих разговоров в сложные периоды.' },
  { id: 3, title: 'Родительская лаборатория', category: 'воспитание', image: 'https://picsum.photos/1200/800?random=6', description: 'Живая работа с кейсами и сенсорной регуляцией детей.' },
  { id: 4, title: 'Марафон близости', category: 'отношения', image: 'https://picsum.photos/1200/800?random=7', description: 'Формируем новые привычки в паре через практики присутствия.' },
];

const faqList = [
  {
    question: 'Для кого подходит курс Braventy?',
    answer:
      'Для пар и семей, живущих в Европе и ищущих устойчивые практики доверия, уважения и поддержки. Подходит родителям детей любого возраста и парам без детей, желающим укрепить эмоциональную связь.',
  },
  {
    question: 'Сколько времени необходимо уделять обучению?',
    answer:
      'В среднем 3–4 часа в неделю: просмотр видеоматериалов, участие в живых встречах и выполнение практических заданий. График гибкий и подстраивается под расписание семьи.',
  },
  {
    question: 'Есть ли индивидуальная поддержка?',
    answer:
      'Да, каждую семью сопровождает личный куратор и психолог. Вы получаете обратную связь, корректируете план развития и обсуждаете трудные ситуации в конфиденциальном формате.',
  },
  {
    question: 'Можно ли подключаться из разных стран?',
    answer:
      'Конечно. Braventy — онлайн-платформа, поэтому вы можете участвовать из любого города ЕС. Сессии проходят в удобное для вас время и доступны в записи.',
  },
];

const blogPosts = [
  {
    title: 'Как говорить о чувствах, чтобы дети слышали?',
    excerpt:
      'Пять простых шагов, которые помогают ребёнку проживать эмоции и чувствовать безопасность в семье.',
    link: '/programma',
    image: 'https://picsum.photos/800/600?random=8',
  },
  {
    title: 'Диалог в паре: практика равного партнёрства',
    excerpt:
      'Узнайте, почему честность и признание потребностей — ключ к зрелому союзничеству.',
    link: '/kurs',
    image: 'https://picsum.photos/800/600?random=9',
  },
  {
    title: 'Семейные ритуалы как источник устойчивости',
    excerpt:
      'Рассказываем, как маленькие традиции создают чувство дома и помогают переживать перемены.',
    link: '/o-nas',
    image: 'https://picsum.photos/800/600?random=10',
  },
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = React.useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [activeCategory, setActiveCategory] = React.useState('все');
  const [openFaq, setOpenFaq] = React.useState(null);
  const [hasAnimatedStats, setHasAnimatedStats] = React.useState(false);

  React.useEffect(() => {
    if (hasAnimatedStats) return;

    const observerTarget = document.getElementById('stats-section');
    if (!observerTarget) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            let start = 0;
            const duration = 1500;
            const frameRate = 30;
            const totalFrames = Math.round((duration / 1000) * frameRate);

            const interval = setInterval(() => {
              start += 1;
              setAnimatedStats((prev) =>
                prev.map((value, idx) => {
                  const target = statsData[idx].value;
                  const progress = Math.min((start / totalFrames) * target, target);
                  return Math.round(progress);
                })
              );
              if (start >= totalFrames) {
                clearInterval(interval);
              }
            }, 1000 / frameRate);

            setHasAnimatedStats(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.4 }
    );

    observer.observe(observerTarget);

    return () => observer.disconnect();
  }, [hasAnimatedStats]);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);

    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    activeCategory === 'все'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const handleFaqToggle = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Braventy — курс семейного счастья онлайн</title>
        <meta
          name="description"
          content="Braventy помогает парам и родителям создавать гармоничные отношения, развивать эмоциональную грамотность и строить семейную культуру поддержки."
        />
        <meta
          name="keywords"
          content="курс семейного счастья, семейная психология Европа, отношения между партнерами, гармония в семье онлайн, воспитание детей курс"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.pretitle}>Онлайн-платформа семейного счастья</p>
          <h1 className={styles.heroTitle}>
            Создайте семью, полную любви и понимания
          </h1>
          <p className={styles.heroSubtitle}>
            Braventy — пространство, где пары и родители изучают современные практики отношений, учатся слышать друг друга и создают новую семейную культуру заботы.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.heroPrimary}>
              Записаться на курс
            </Link>
            <Link to="/programma" className={styles.heroSecondary}>
              Узнать программу
            </Link>
          </div>
          <div className={styles.heroStats}>
            <span>Поддержка 24/7 кураторов</span>
            <span>Гибкий формат обучения</span>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Счастливая семья, обнимающаяся дома"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.intro} id="intro">
        <div className={styles.sectionHeader}>
          <h2>Braventy — новая глава семейного образования</h2>
          <p>
            Мы объединяем психотерапевтов, семейных консультантов, арт-терапевтов и коучей, чтобы дарить семьям инструменты заботы, эмпатии и зрелого диалога. Наша платформа помогает выстраивать устойчивые привычки, а не просто давать советы.
          </p>
        </div>
        <div className={styles.introGrid}>
          <article>
            <h3>Осознанная трансформация</h3>
            <p>
              Каждый модуль включает диагностические опросы, микро-рефлексии и практики, которые легко адаптировать под семейную жизнь. Мы учитываем ритм европейских городов, гибкие графики и мультикультурный контекст.
            </p>
          </article>
          <article>
            <h3>Живые совместные встречи</h3>
            <p>
              Ведущие эксперты Braventy проводят вебинары, коучинговые сессии и групповые обсуждения. Комфортное пространство для честного разговора и поиска решений без оценивания.
            </p>
          </article>
          <article>
            <h3>Инструменты действия</h3>
            <p>
              Готовые сценарии диалогов, чек-листы ритуалов, карты эмоций, техники для детей и взрослых — всё, что помогает внедрять изменения сразу после урока.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.stats} id="stats-section" aria-label="Достижения платформы Braventy">
        {statsData.map((stat, index) => (
          <div key={stat.label} className={styles.statCard}>
            <span className={styles.statValue}>{animatedStats[index]}+</span>
            <p className={styles.statLabel}>{stat.label}</p>
          </div>
        ))}
      </section>

      <section className={styles.topics} aria-labelledby="topics-title">
        <div className={styles.sectionHeader}>
          <h2 id="topics-title">Основные темы курса</h2>
          <p>
            Программа построена по спиральной модели: вы постепенно углубляетесь в четыре взаимосвязанные области, чтобы создавать целостное семейное пространство.
          </p>
        </div>
        <div className={styles.topicGrid}>
          {topics.map((topic) => (
            <article key={topic.title} className={styles.topicCard}>
              <span aria-hidden="true" className={styles.topicIcon}>
                {topic.icon}
              </span>
              <h3>{topic.title}</h3>
              <p>{topic.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <h2 id="process-title" className={styles.sectionTitle}>
          Как проходит обучение
        </h2>
        <div className={styles.processTimeline}>
          {steps.map((step, index) => (
            <article className={styles.processStep} key={step.title}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.advantages}>
        <div className={styles.sectionHeader}>
          <h2>Почему выбирают Braventy</h2>
          <p>
            Мы объединяем научные подходы, терапевтическую заботу и современные образовательные форматы, чтобы вы могли менять семейную динамику мягко и уверенно.
          </p>
        </div>
        <div className={styles.advantageGrid}>
          {advantages.map((advantage) => (
            <article key={advantage.title} className={styles.advantageCard}>
              <h3>{advantage.title}</h3>
              <p>{advantage.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-title">
        <div className={styles.testimonialHeader}>
          <h2 id="testimonials-title">Отзывы семей</h2>
          <div className={styles.dots}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`${styles.dot} ${activeTestimonial === index ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Перейти к отзыву ${index + 1}`}
              />
            ))}
          </div>
        </div>
        <div className={styles.testimonialCard}>
          <p className={styles.testimonialQuote}>
            «{testimonials[activeTestimonial].quote}»
          </p>
          <p className={styles.testimonialAuthor}>
            {testimonials[activeTestimonial].name}, {testimonials[activeTestimonial].city}
          </p>
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-title">
        <div className={styles.sectionHeader}>
          <h2 id="projects-title">Практические проекты</h2>
          <div className={styles.filters} role="tablist" aria-label="Фильтр проектов">
            {['все', 'отношения', 'воспитание', 'коммуникация', 'кризисы'].map((category) => (
              <button
                key={category}
                role="tab"
                aria-selected={activeCategory === category}
                className={`${styles.filterButton} ${activeCategory === category ? styles.filterButtonActive : ''}`}
                onClick={() => setActiveCategory(category)}
              >
                {category === 'все' ? 'Все направления' : category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img
                  src={`${project.image}`}
                  alt={project.description}
                  loading="lazy"
                />
              </div>
              <div className={styles.projectContent}>
                <span className={styles.projectTag}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-title">
        <h2 id="faq-title" className={styles.sectionTitle}>
          Часто задаваемые вопросы
        </h2>
        <div className={styles.faqList}>
          {faqList.map((item, index) => (
            <div key={item.question} className={styles.faqItem}>
              <button
                className={styles.faqQuestion}
                onClick={() => handleFaqToggle(index)}
                aria-expanded={openFaq === index}
              >
                <span>{item.question}</span>
                <span className={styles.faqIcon}>{openFaq === index ? '−' : '+'}</span>
              </button>
              {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-title">
        <div className={styles.sectionHeader}>
          <h2 id="blog-title">Свежие материалы</h2>
          <p>Берите идеи, делитесь с партнёром, обогащайте семейные разговоры уже сегодня.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImageWrapper}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>
                  Читать далее →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaInner}>
          <h2>Готовы начать путь к семейной гармонии?</h2>
          <p>
            Забронируйте вводную консультацию, познакомьтесь с командой Braventy и получите персональный план обучения.
          </p>
          <Link to="/kontakty" className={styles.ctaButton}>
            Записаться на встречу
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;