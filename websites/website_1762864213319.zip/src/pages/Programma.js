import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programma.module.css';

const weeks = [
  {
    week: 'Неделя 1',
    title: 'Диагностика и намерения',
    focus:
      'Определяем семейные ценности, обсуждаем ожидания, проводим стартовую диагностику отношений и эмоционального климата.',
  },
  {
    week: 'Неделя 2',
    title: 'Язык эмоций',
    focus:
      'Осваиваем алфавит чувств, практики активного слушания и техники, которые помогают говорить о важном без напряжения.',
  },
  {
    week: 'Неделя 3',
    title: 'Партнёрский союз',
    focus:
      'Работаем над близостью, поддержкой в повседневности, распределением ролей и созданием совместных ритуалов.',
  },
  {
    week: 'Неделя 4',
    title: 'Родительство',
    focus:
      'Добавляем инструменты для диалога с детьми, учимся восстанавливать ресурс и выстраивать границы.',
  },
  {
    week: 'Неделя 5',
    title: 'Коммуникация и конфликты',
    focus:
      'Отрабатываем стратегии переговоров, разбор кейсов, формируем семейные правила обсуждений и рефлексии.',
  },
  {
    week: 'Неделя 6',
    title: 'Интеграция и будущее',
    focus:
      'Создаём карту устойчивых привычек, планируем следующую ступень развития семьи, отмечаем достижения.',
  },
];

const Programma = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Braventy — программа курса</title>
        <meta
          name="description"
          content="Подробный план курса Braventy: тематические блоки, длительность, формат практических заданий и ожидаемые результаты."
        />
        <meta
          name="keywords"
          content="план курса, тематические блоки, программа обучения, семейная платформа"
        />
      </Helmet>

      <section className={styles.intro}>
        <h1>План обучения Braventy</h1>
        <p>
          Шестинедельная траектория, где теория и практика объединены в систему. Каждый блок завершает команда экспертов, чтобы вы чувствовали поддержку и видели результат.
        </p>
      </section>

      <section className={styles.timeline}>
        {weeks.map((item) => (
          <article key={item.week} className={styles.timelineCard}>
            <div className={styles.timelineHeader}>
              <span>{item.week}</span>
              <h2>{item.title}</h2>
            </div>
            <p>{item.focus}</p>
          </article>
        ))}
      </section>

      <section className={styles.practices}>
        <div className={styles.practiceText}>
          <h2>Практические задания</h2>
          <ul>
            <li>Сценарии семейных бесед и вопросы для рефлексии</li>
            <li>Игры и упражнения для детей разного возраста</li>
            <li>Видеомастерские с психологами и обратной связью</li>
            <li>Домашние ритуалы, которые создают чувство безопасности</li>
          </ul>
        </div>
        <div className={styles.practiceImage}>
          <img
            src="https://picsum.photos/900/700?random=21"
            alt="Семья обсуждает программу курса Braventy"
            loading="lazy"
          />
        </div>
      </section>
    </div>
  );
};

export default Programma;