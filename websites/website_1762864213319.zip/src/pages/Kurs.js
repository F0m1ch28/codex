import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Kurs.module.css';

const modules = [
  {
    title: 'Гармония в паре',
    description:
      'Исследуем привязанность, строим безопасные рамки, учимся восстанавливать доверие и создавать «мы-пространство».',
    highlights: [
      'Упражнения на эмпатию и признание потребностей',
      'Практики ненасильственного диалога',
      'Переговоры и разделение ответственности',
    ],
  },
  {
    title: 'Воспитание с любовью',
    description:
      'Понимаем потребности ребёнка, подбираем подходящие ритуалы, развиваем навыки эмоциональной регуляции.',
    highlights: [
      'Сенсорные карты чувств',
      'Дисциплина без наказаний',
      'Родительская команда: мы вместе',
    ],
  },
  {
    title: 'Семейная коммуникация',
    description:
      'Учимся создавать пространство для диалога: от семейных советов до ежедневных коротких встреч.',
    highlights: [
      'Чёткие и мягкие границы',
      'Стратегии слушания и перефразирования',
      'Разрешение конфликтов через сотрудничество',
    ],
  },
  {
    title: 'Кризисы и переходы',
    description:
      'Работаем с переменами: переезд, рождение ребёнка, смена работы, подростковый период.',
    highlights: [
      'Рессурсная карта семьи',
      'Принятие эмоций и устойчивость',
      'Сценарии поддержки друг друга',
    ],
  },
];

const Kurs = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Braventy — структура курса для семей</title>
        <meta
          name="description"
          content="Подробное описание модулей курса Braventy: гармония в паре, воспитание с любовью, семейная коммуникация и управление кризисами."
        />
        <meta
          name="keywords"
          content="курс отношений, семейная коммуникация, воспитание с любовью, кризисы в семье"
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Курс семейного счастья</h1>
        <p>
          Четыре взаимосвязанных модуля ведут вас от диагностики к устойчивым навыкам. Мы будем мягко сопровождать каждую трансформацию вашей семьи.
        </p>
      </header>

      <section className={styles.moduleGrid}>
        {modules.map((module) => (
          <article key={module.title} className={styles.moduleCard}>
            <h2>{module.title}</h2>
            <p>{module.description}</p>
            <ul>
              {module.highlights.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className={styles.summary}>
        <div className={styles.summaryText}>
          <h2>Формат обучения</h2>
          <p>
            Обучение проходит в формате гибридных недельных спринтов: лекции, рабочие тетради и групповые встречи. Каждая семья получает персонального куратора, а доступ ко всем материалам сохраняется.
          </p>
        </div>
        <div className={styles.summaryImage}>
          <img
            src="https://picsum.photos/800/600?random=20"
            alt="Пара и ребёнок проходят онлайн-обучение"
            loading="lazy"
          />
        </div>
      </section>
    </div>
  );
};

export default Kurs;