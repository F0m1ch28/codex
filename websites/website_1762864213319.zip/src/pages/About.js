import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const values = [
  {
    title: 'История создания',
    description:
      'Braventy появилась из инициативы группы семейных психологов, которые хотели объединить европейский опыт и современную психотерапию в одном пространстве.',
  },
  {
    title: 'Миссия',
    description:
      'Мы создаём пространство, где каждый член семьи чувствует себя услышанным. Помогаем парам быть союзниками, а детям — расти в атмосфере уважения.',
  },
  {
    title: 'Философия',
    description:
      'Главная опора — бережность, открытый диалог и осознанность. Мы верим, что гармония строится через ежедневные практики поддержки и признания эмоций.',
  },
];

const teamMembers = [
  {
    name: 'Аннет Шульц',
    role: 'Семейный терапевт, сооснователь',
    description:
      '15 лет помогает международным парам выстраивать диалог и совместную стратегию воспитания. Специалист по системной терапии и фасилитации сложных разговоров.',
    image: 'https://picsum.photos/400/400?random=3',
  },
  {
    name: 'Мария Погодина',
    role: 'Детский психолог, арт-терапевт',
    description:
      'Работает с нейросенсорной регуляцией, создаёт практики для родителей и детей. Разрабатывает кейсы для семей с детьми 3–12 лет.',
    image: 'https://picsum.photos/400/400?random=12',
  },
  {
    name: 'Даниэль Краус',
    role: 'Психотерапевт, супервизор',
    description:
      'Сертифицированный специалист в области эмоционально-фокусированной терапии. Курирует модуль о партнёрской поддержке и кризисах.',
    image: 'https://picsum.photos/400/400?random=13',
  },
];

const About = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Braventy — история и команда</title>
        <meta
          name="description"
          content="Узнайте историю создания Braventy, познакомьтесь с командой и философией работы. Платформа создана психологами для семей в Европе."
        />
        <meta
          name="keywords"
          content="Braventy команда, семейная психология Европа, миссия платформы, история создания Braventy"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Команда Braventy</h1>
          <p>
            Мы объединили специалистов из Германии, Нидерландов, Австрии и Чехии, чтобы создать платформу, способную поддержать семьи разного культурного фона.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1200/800?random=14"
            alt="Команда психологов Braventy на встрече"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.values}>
        <h2>Наши ориентиры</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team} aria-label="Команда Braventy">
        <h2>Психологи и кураторы</h2>
        <p className={styles.teamIntro}>
          Мы строим курс как живой процесс: рядом с вами всегда есть специалисты, которые поддерживают в моменте и помогают двигаться вперёд.
        </p>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImage}>
                <img src={member.image} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default About;