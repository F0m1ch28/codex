import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Kontakty.module.css';

const Kontakty = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    message: '',
  });

  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Пожалуйста, представьтесь.';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email для обратной связи.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Похоже на опечатку в email.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Расскажите подробнее о вашей ситуации (минимум 10 символов).';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
    }
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Контакты Braventy</title>
        <meta
          name="description"
          content="Свяжитесь с Braventy: адрес, телефон, электронная почта и форма обратной связи. Платформа находится в Берлине, работает по всему ЕС."
        />
        <meta
          name="keywords"
          content="контакты Braventy, семейный курс Европа, поддержка семей онлайн"
        />
      </Helmet>

      <section className={styles.header}>
        <div>
          <h1>Мы рядом</h1>
          <p>
            Пишите, если хотите обсудить программу, задать вопрос команде или пройти вводную диагностику. Ответим в течение одного рабочего дня.
          </p>
          <div className={styles.contactInfo}>
            <p><strong>Адрес:</strong> Alexanderplatz 7, 10178 Berlin, Germany</p>
            <p><strong>Телефон:</strong> <a href="tel:+493045678901">+49 30 4567 8901</a></p>
            <p><strong>Email:</strong> <a href="mailto:contact@braventy.eu">contact@braventy.eu</a></p>
          </div>
        </div>
        <div className={styles.mapWrapper}>
          <iframe
            title="Braventy Berlin"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.7679311267797!2d13.411708315806696!3d52.5219187798127!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c48036c9df%3A0xa64507621a834d1b!2sAlexanderplatz%207%2C%2010178%20Berlin%2C%20Germany!5e0!3m2!1sen!2sde!4v1700000000000!5m2!1sen!2sde"
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Напишите нам</h2>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">
            Имя
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Как к вам обращаться?"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={!!errors.name}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </label>
          <label htmlFor="email">
            Email
            <input
              type="email"
              id="email"
              name="email"
              placeholder="example@domain.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={!!errors.email}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </label>
          <label htmlFor="message">
            Сообщение
            <textarea
              id="message"
              name="message"
              rows="6"
              placeholder="Расскажите о вашей семье и запросе"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={!!errors.message}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </label>
          <button type="submit">Отправить сообщение</button>
          {submitted && (
            <p className={styles.success}>
              Спасибо! Ваше сообщение отправлено. Команда Braventy свяжется с вами очень скоро.
            </p>
          )}
        </form>
      </section>
    </div>
  );
};

export default Kontakty;