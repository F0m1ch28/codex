import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Specialisty.module.css';

const specialists = [
  {
    name: 'Лилия Новак',
    title: 'Семейный психолог, член Европейской ассоциации терапии',
    experience: '12 лет практики, специализация на поддержке мультикультурных пар, автор методики семейных договоров.',
    focus: 'Работает с темой доверия, эмоциональной безопасности и сохранением близости в долгих отношениях.',
    image: 'https://picsum.photos/400/400?random=30',
  },
  {
    name: 'Юлианна Сокол',
    title: 'Психолог-консультант, фасилитатор групп',
    experience: 'Сертифицирована по EFT и практикам mindful parenting. Ведёт живые воркшопы и семейные ретриты.',
    focus: 'Помогает прорабатывать триггеры, строить диалог без обвинений, работать со злостью и обидами.',
    image: 'https://picsum.photos/400/400?random=31',
  },
  {
    name: 'Давид Келлер',
    title: 'Детский и подростковый психолог',
    experience: '10 лет работает с подростками, создаёт программы для семей с особыми образовательными потребностями.',
    focus: 'Сопровождает родителей в непростых периодах перехода и адаптации в новых странах.',
    image: 'https://picsum.photos/400/400?random=32',
  },
  {
    name: 'Екатерина Михель',
    title: 'Телесно-ориентированный терапевт',
    experience: 'Специалист по травма-информированным подходам, проводит сенсорные практики для родителей и детей.',
    focus: 'Учится оживлять тело, возвращать поддержку через дыхание и движение, укреплять границы.',
    image: 'https://picsum.photos/400/400?random=33',
  },
];

const Specialisty = () => {
  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Специалисты Braventy</title>
        <meta
          name="description"
          content="Познакомьтесь с психологами Braventy: квалификация, опыт и направления работы. Команда, которая поддерживает семьи в Европе."
        />
        <meta
          name="keywords"
          content="психологи Braventy, специалисты семейной платформы, команда курс семейного счастья"
        />
      </Helmet>

      <section className={styles.intro}>
        <h1>Психологи и наставники</h1>
        <p>
          Наша команда — сочетание глубокой эмпатии и профессиональной экспертизы. Мы работаем на русском языке и сопровождаем семьи по всей Европе.
        </p>
      </section>

      <section className={styles.grid}>
        {specialists.map((person) => (
          <article key={person.name} className={styles.card}>
            <div className={styles.photo}>
              <img src={person.image} alt={person.name} loading="lazy" />
            </div>
            <div className={styles.info}>
              <h2>{person.name}</h2>
              <span>{person.title}</span>
              <p>{person.experience}</p>
              <p className={styles.focus}>{person.focus}</p>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Specialisty;