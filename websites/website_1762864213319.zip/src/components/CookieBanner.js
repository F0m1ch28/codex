import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = React.useState(() => {
    return localStorage.getItem('braventy-cookie-consent') !== 'accepted';
  });

  const acceptCookies = () => {
    localStorage.setItem('braventy-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Мы используем cookies для улучшения работы сайта и персонализации материалов. Продолжая использовать ресурс, вы подтверждаете своё согласие.
        </p>
        <div className={styles.actions}>
          <a className={styles.link} href="/cookie-policy">
            Подробнее
          </a>
          <button className={styles.button} onClick={acceptCookies}>
            Согласен
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;