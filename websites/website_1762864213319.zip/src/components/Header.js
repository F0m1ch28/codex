import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  const toggleMenu = () => setIsOpen((prev) => !prev);
  const closeMenu = () => setIsOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Braventy — переход на главную">
          <span className={styles.logoAccent}>Braventy</span>
          <span className={styles.logoTagline}>семейная платформа</span>
        </NavLink>
        <button
          className={styles.burger}
          onClick={toggleMenu}
          aria-expanded={isOpen}
          aria-controls="main-navigation"
          aria-label="Открыть главное меню"
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="main-navigation"
          className={`${styles.nav} ${isOpen ? styles.navOpen : ''}`}
        >
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Главная
          </NavLink>
          <NavLink
            to="/o-nas"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            О нас
          </NavLink>
          <NavLink
            to="/kurs"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Курсы
          </NavLink>
          <NavLink
            to="/programma"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Программа
          </NavLink>
          <NavLink
            to="/specialisty"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Специалисты
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;