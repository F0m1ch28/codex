import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Подвал сайта Braventy">
      <div className={styles.container}>
        <div className={styles.brand}>
          <h3>Braventy</h3>
          <p>
            Образовательная онлайн-платформа для семей, которые стремятся к гармонии, поддержке и устойчивой эмоциональной связи.
          </p>
          <div className={styles.contacts}>
            <a href="tel:+493045678901">+49 30 4567 8901</a>
            <a href="mailto:contact@braventy.eu">contact@braventy.eu</a>
            <span>Alexanderplatz 7, 10178 Berlin, Germany</span>
            <span>Домен: braventy.eu</span>
          </div>
        </div>
        <div className={styles.links}>
          <h4>Навигация</h4>
          <NavLink to="/">Главная</NavLink>
          <NavLink to="/o-nas">О нас</NavLink>
          <NavLink to="/kurs">Курсы</NavLink>
          <NavLink to="/programma">Программа</NavLink>
          <NavLink to="/specialisty">Специалисты</NavLink>
          <NavLink to="/kontakty">Контакты</NavLink>
        </div>
        <div className={styles.legal}>
          <h4>Правовая информация</h4>
          <NavLink to="/soglashenie">Пользовательское соглашение</NavLink>
          <NavLink to="/privatnost">Политика конфиденциальности</NavLink>
          <NavLink to="/cookie-policy">Политика cookies</NavLink>
          <p className={styles.notice}>
            © {new Date().getFullYear()} Braventy. Все права защищены. Сделано с заботой в Берлине для семей по всему Европейскому Союзу.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;