import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Kurs from './pages/Kurs';
import Programma from './pages/Programma';
import Specialisty from './pages/Specialisty';
import Kontakty from './pages/Kontakty';
import Soglashenie from './pages/Soglashenie';
import Privatnost from './pages/Privatnost';
import CookiePolicy from './pages/CookiePolicy';

const RouteChangeHandler = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return null;
};

function App() {
  return (
    <div className="appShell">
      <Header />
      <RouteChangeHandler />
      <main className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/o-nas" element={<About />} />
          <Route path="/kurs" element={<Kurs />} />
          <Route path="/programma" element={<Programma />} />
          <Route path="/specialisty" element={<Specialisty />} />
          <Route path="/kontakty" element={<Kontakty />} />
          <Route path="/soglashenie" element={<Soglashenie />} />
          <Route path="/privatnost" element={<Privatnost />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;