import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import BlogPage from './pages/Services';
import ContactPage from './pages/Contact';
import { TermsPage, CookiePolicyPage } from './pages/TermsOfService';
import PrivacyPage from './pages/PrivacyPolicy';
import styles from './App.module.css';

const ScrollToTopOnRouteChange = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return null;
};

const App = () => {
  return (
    <div className={styles.appShell}>
      <a className={styles.skipLink} href="#contenido-principal">
        Saltar al contenido principal
      </a>
      <Header />
      <ScrollToTopOnRouteChange />
      <main id="contenido-principal" className={styles.mainContent}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/nosotros" element={<AboutPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/contacto" element={<ContactPage />} />
          <Route path="/terminos" element={<TermsPage />} />
          <Route path="/privacidad" element={<PrivacyPage />} />
          <Route path="/cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;