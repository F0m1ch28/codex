import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const navLinkClassName = ({ isActive }) =>
    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink;

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <div className={styles.branding}>
          <Link to="/" className={styles.logo} onClick={closeMenu}>
            <span aria-hidden="true">🌙</span> Luna &amp; José Tamira
          </Link>
        </div>
        <button
          className={styles.menuToggle}
          aria-expanded={isMenuOpen}
          aria-controls="menu-principal"
          onClick={toggleMenu}
          type="button"
        >
          <span className={styles.srOnly}>Abrir o cerrar menú</span>
          <span className={styles.menuIcon} aria-hidden="true">
            {isMenuOpen ? '✕' : '☰'}
          </span>
        </button>
        <nav
          className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`}
          aria-label="Menú principal"
        >
          <ul id="menu-principal" className={styles.navList}>
            <li>
              <NavLink to="/" className={navLinkClassName} onClick={closeMenu}>
                Inicio
              </NavLink>
            </li>
            <li>
              <NavLink to="/nosotros" className={navLinkClassName} onClick={closeMenu}>
                Nosotros
              </NavLink>
            </li>
            <li>
              <NavLink to="/blog" className={navLinkClassName} onClick={closeMenu}>
                Blog
              </NavLink>
            </li>
            <li>
              <NavLink to="/contacto" className={navLinkClassName} onClick={closeMenu}>
                Contacto
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;