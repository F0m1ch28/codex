import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brand}>
          <span className={styles.brandTitle}>Luna &amp; José Tamira</span>
          <p className={styles.brandDescription}>
            Inspiramos a hogares mexicanos a transformar sus hábitos cotidianos en acciones
            significativas para el clima. Creamos guías, historias y herramientas que conectan con
            la vida urbana y rural del país.
          </p>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Explora</h3>
          <ul className={styles.linkList}>
            <li>
              <Link to="/" className={styles.link}>
                Inicio
              </Link>
            </li>
            <li>
              <Link to="/nosotros" className={styles.link}>
                Nosotros
              </Link>
            </li>
            <li>
              <Link to="/blog" className={styles.link}>
                Blog
              </Link>
            </li>
            <li>
              <Link to="/contacto" className={styles.link}>
                Contacto
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Legal</h3>
          <ul className={styles.linkList}>
            <li>
              <Link to="/terminos" className={styles.link}>
                Términos de uso
              </Link>
            </li>
            <li>
              <Link to="/privacidad" className={styles.link}>
                Privacidad
              </Link>
            </li>
            <li>
              <Link to="/cookies" className={styles.link}>
                Cookies
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Contáctanos</h3>
          <div className={styles.contactInfo}>
            <span>
              <strong>Dirección:</strong> Por definir, Ciudad de México, México
            </span>
            <span>
              <strong>Teléfono:</strong>{' '}
              <a className={styles.link} href="tel:+525512345678">
                +52 55 1234 5678
              </a>
            </span>
            <span>
              <strong>Email:</strong>{' '}
              <a className={styles.link} href="mailto:info@lunarejostamira.site">
                info@lunarejostamira.site
              </a>
            </span>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© 2023 Luna &amp; José Tamira. Todos los derechos reservados.</p>
        <div className={styles.socials}>
          <a
            className={styles.socialLink}
            href="https://www.instagram.com/"
            target="_blank"
            rel="noreferrer"
            aria-label="Instagram"
          >
            <span aria-hidden="true">📸</span>
          </a>
          <a
            className={styles.socialLink}
            href="https://www.facebook.com/"
            target="_blank"
            rel="noreferrer"
            aria-label="Facebook"
          >
            <span aria-hidden="true">👍</span>
          </a>
          <a
            className={styles.socialLink}
            href="https://www.linkedin.com/"
            target="_blank"
            rel="noreferrer"
            aria-label="LinkedIn"
          >
            <span aria-hidden="true">💼</span>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;