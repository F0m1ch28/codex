import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'lunajosetamiraCookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedConsent = window.localStorage.getItem(COOKIE_KEY);
      if (!storedConsent) {
        setIsVisible(true);
      }
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(COOKIE_KEY, 'accepted');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <strong>Cookies:</strong> Usamos cookies para analizar el uso del sitio y mejorar tu
        experiencia. Al continuar aceptas nuestra{' '}
        <Link to="/cookies" className={styles.link}>
          Política de cookies
        </Link>
        .
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Entendido
      </button>
    </div>
  );
};

export default CookieBanner;