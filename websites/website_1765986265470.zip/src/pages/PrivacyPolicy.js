import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const PrivacyPage = () => (
  <div className={styles.legalPage}>
    <Helmet>
      <title>Política de privacidad | Luna &amp; José Tamira</title>
      <meta
        name="description"
        content="Revisa cómo Luna & José Tamira protege tu información personal y qué derechos tienes sobre tus datos."
      />
    </Helmet>

    <article className={styles.card}>
      <h1 className={styles.title}>Política de privacidad</h1>
      <p className={styles.text}>
        En Luna &amp; José Tamira nos comprometemos a proteger la información personal que compartes
        con nosotros. Recopilamos únicamente los datos necesarios para brindarte contenidos, responder
        tus mensajes y mejorar la experiencia.
      </p>
      <ul className={styles.list}>
        <li>Nombre y correo electrónico proporcionados mediante formularios o suscripciones.</li>
        <li>
          Información estadística anónima como dispositivo, navegador y páginas visitadas para análisis
          interno.
        </li>
        <li>
          Comentarios o testimonios que decides compartir voluntariamente; te pediremos permiso antes de
          publicarlos.
        </li>
      </ul>
    </article>

    <article className={styles.card}>
      <h2 className={styles.subtitle}>Uso y resguardo de datos</h2>
      <p className={styles.text}>
        Utilizamos tus datos para enviar boletines, responder consultas y compartir novedades relevantes.
        No vendemos ni rentamos tus datos a terceros. Implementamos medidas de seguridad administrativas
        y tecnológicas para prevenir accesos no autorizados.
      </p>
      <div className={styles.highlight}>
        Puedes solicitar acceso, corrección o eliminación de tus datos escribiendo a
        info@lunarejostamira.site.
      </div>
    </article>

    <article className={styles.card}>
      <h2 className={styles.subtitle}>Cambios a esta política</h2>
      <p className={styles.text}>
        Actualizaremos esta política cuando exista un cambio significativo en el manejo de datos y
        publicaremos la fecha de la última modificación. Te invitamos a revisarla periódicamente.
      </p>
    </article>
  </div>
);

export default PrivacyPage;