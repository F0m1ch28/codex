import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (status) {
      setStatus('');
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Ingresa tu nombre completo.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Incluye un correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'El correo no tiene un formato válido.';
    }
    if (formData.message.trim().length < 20) {
      newErrors.message = 'Cuéntanos con al menos 20 caracteres cómo podemos ayudarte.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setStatus('');
      return;
    }

    setErrors({});
    setStatus('¡Gracias! Revisaremos tu mensaje y te responderemos en un máximo de 48 horas.');
    setFormData({
      name: '',
      email: '',
      message: ''
    });
  };

  return (
    <div className={styles.contactPage}>
      <Helmet>
        <title>Contacto | Luna &amp; José Tamira</title>
        <meta
          name="description"
          content="Contacta a Luna & José Tamira para colaborar, solicitar talleres o recibir asesoría sobre hábitos climáticos inteligentes."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="contact-title">
        <h1 id="contact-title" className={styles.heroTitle}>
          Conversemos y diseñemos hábitos resilientes para tu comunidad
        </h1>
        <p className={styles.heroText}>
          Comparte tus ideas, necesidades o proyectos. Nos encanta colaborar con escuelas, empresas
          sociales y gobiernos locales.
        </p>
      </section>

      <section className={styles.content} aria-label="Formulario de contacto y datos de comunicación">
        <div className={styles.formCard}>
          <h2 className={styles.formTitle}>Comparte tu idea climática</h2>
          <p className={styles.heroText}>
            Llena el formulario y nos pondremos en contacto contigo para programar una sesión.
          </p>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name" className={styles.label}>
                Nombre completo
              </label>
              <input
                id="name"
                name="name"
                type="text"
                className={styles.input}
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'error-name' : undefined}
                placeholder="Ej. Alejandra Ramírez"
              />
              {errors.name && (
                <span id="error-name" className={styles.error}>
                  {errors.name}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email" className={styles.label}>
                Correo electrónico
              </label>
              <input
                id="email"
                name="email"
                type="email"
                className={styles.input}
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'error-email' : undefined}
                placeholder="nombre@correo.com"
              />
              {errors.email && (
                <span id="error-email" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="message" className={styles.label}>
                Mensaje
              </label>
              <textarea
                id="message"
                name="message"
                className={styles.textarea}
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'error-message' : undefined}
                placeholder="Cuéntanos sobre el proyecto, comunidad o duda que te gustaría resolver."
              />
              {errors.message && (
                <span id="error-message" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Enviar mensaje
            </button>
            {status && (
              <p className={styles.successMessage} role="status" aria-live="polite">
                {status}
              </p>
            )}
          </form>
        </div>

        <aside className={styles.infoCard}>
          <h2 className={styles.formTitle}>Datos de contacto</h2>
          <p className={styles.heroText}>
            Estamos disponibles de lunes a viernes de 9:00 a 18:00 h (GMT-6). Responderemos cada
            consulta con dedicación.
          </p>
          <ul className={styles.infoList}>
            <li>
              <strong>Dirección</strong>
              <span>Por definir, Ciudad de México, México</span>
            </li>
            <li>
              <strong>Teléfono</strong>
              <a href="tel:+525512345678">+52 55 1234 5678</a>
            </li>
            <li>
              <strong>Email</strong>
              <a href="mailto:info@lunarejostamira.site">info@lunarejostamira.site</a>
            </li>
          </ul>
          <p className={styles.heroText}>
            También organizamos sesiones virtuales para colonias y escuelas que desean activar hábitos
            verdes desde cualquier parte del país.
          </p>
        </aside>
      </section>
    </div>
  );
};

export default ContactPage;