import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const posts = [
  {
    title: 'Transporte multimodal para barrios activos',
    excerpt:
      'Tácticas para combinar bici, transporte público y autos compartidos, reduciendo emisiones mientras se gana tiempo.',
    category: 'Movilidad sostenible',
    image: 'https://picsum.photos/seed/bloghabito1/900/700',
    alt: 'Persona andando en bicicleta sobre una avenida arbolada',
    readTime: '5 min de lectura',
    date: '15 enero 2024'
  },
  {
    title: 'Guía para mercados libres de plástico',
    excerpt:
      'Kit descargable para tianguis y mercados sobre ruedas que desean migrar a empaques retornables.',
    category: 'Consumo responsable',
    image: 'https://picsum.photos/seed/bloghabito2/900/700',
    alt: 'Verduras frescas en bolsas reutilizables',
    readTime: '7 min de lectura',
    date: '02 febrero 2024'
  },
  {
    title: 'Recetas de aprovechamiento total en temporadas de sequía',
    excerpt:
      'Menús nutritivos que requieren menos agua y aprovechan cada ingrediente sin desperdicio.',
    category: 'Cocina sustentable',
    image: 'https://picsum.photos/seed/bloghabito3/900/700',
    alt: 'Mesa con platillos vegetales coloridos',
    readTime: '6 min de lectura',
    date: '17 febrero 2024'
  },
  {
    title: 'Azoteas frescas: agricultura urbana paso a paso',
    excerpt:
      'Planea un huerto urbano resistente al calor con materiales accesibles y recolección de lluvia.',
    category: 'Espacios verdes',
    image: 'https://picsum.photos/seed/bloghabito4/900/700',
    alt: 'Huerto urbano sobre una azotea en la ciudad',
    readTime: '8 min de lectura',
    date: '28 febrero 2024'
  },
  {
    title: 'Comunidades solares compartidas',
    excerpt:
      'Cómo organizar a tus vecinas y vecinos para instalar energía solar comunitaria con financiamiento colaborativo.',
    category: 'Energía renovable',
    image: 'https://picsum.photos/seed/bloghabito5/900/700',
    alt: 'Paneles solares instalados en un edificio multifamiliar',
    readTime: '9 min de lectura',
    date: '10 marzo 2024'
  },
  {
    title: 'Escuelas regenerativas en México rural',
    excerpt:
      'Historias de planteles que gestionan agua de lluvia, compostaje y proyectos de reforestación estudiantil.',
    category: 'Educación ambiental',
    image: 'https://picsum.photos/seed/bloghabito6/900/700',
    alt: 'Estudiantes plantando árboles en un patio escolar',
    readTime: '5 min de lectura',
    date: '24 marzo 2024'
  }
];

const BlogPage = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleSubmit = (event) => {
    event.preventDefault();
    const trimmedEmail = email.trim();

    if (!trimmedEmail) {
      setStatus({ type: 'error', message: 'Ingresa un correo electrónico.' });
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      setStatus({ type: 'error', message: 'El correo no tiene un formato válido.' });
      return;
    }

    setStatus({
      type: 'success',
      message: '¡Listo! Recibirás nuestras novedades cada quincena.'
    });
    setEmail('');
  };

  const handleChange = (event) => {
    setEmail(event.target.value);
    if (status.message) {
      setStatus({ type: '', message: '' });
    }
  };

  return (
    <div className={styles.blogPage}>
      <Helmet>
        <title>Blog | Luna &amp; José Tamira</title>
        <meta
          name="description"
          content="Artículos sobre hábitos cotidianos inteligentes, movilidad sostenible, alimentación local y energía renovable en México."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="blog-title">
        <h1 id="blog-title" className={styles.heroTitle}>
          Blog de hábitos cotidianos inteligentes
        </h1>
        <p className={styles.heroText}>
          Historias, guías y plantillas para que adaptes tu rutina y la de tu comunidad hacia un
          futuro bajo en carbono.
        </p>
      </section>

      <section aria-label="Listado de artículos destacados">
        <div className={styles.postGrid}>
          {posts.map((post) => (
            <article key={post.title} className={styles.postCard}>
              <img
                src={post.image}
                alt={post.alt}
                className={styles.postImage}
                loading="lazy"
              />
              <div className={styles.postContent}>
                <div className={styles.postMeta}>
                  <span className={styles.tag}>{post.category}</span>
                  <span>{post.date}</span>
                  <span>{post.readTime}</span>
                </div>
                <h2 className={styles.postTitle}>{post.title}</h2>
                <p className={styles.postExcerpt}>{post.excerpt}</p>
                <Link to="/contacto" className={styles.readMore}>
                  Leer más <span aria-hidden="true">→</span>
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.newsletter} aria-labelledby="newsletter-title">
        <h2 id="newsletter-title" className={styles.sectionHeading}>
          Recibe la agenda verde cada quincena
        </h2>
        <p className={styles.heroText}>
          Suscríbete para obtener plantillas descargables, recordatorios de talleres y nuevas ideas
          para tu barrio antes que nadie.
        </p>
        <form onSubmit={handleSubmit} noValidate>
          <label className={styles.srOnly} htmlFor="newsletter-email">
            Correo electrónico
          </label>
          <input
            id="newsletter-email"
            name="email"
            type="email"
            placeholder="tu@correo.com"
            value={email}
            onChange={handleChange}
            aria-label="Correo electrónico"
          />
          <button type="submit">Suscribirme</button>
          {status.message && (
            <p
              className={status.type === 'error' ? styles.statusError : styles.statusSuccess}
              role="status"
              aria-live="polite"
            >
              {status.message}
            </p>
          )}
        </form>
      </section>
    </div>
  );
};

export default BlogPage;