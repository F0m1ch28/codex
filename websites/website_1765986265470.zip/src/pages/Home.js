import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const keyHabits = [
  {
    icon: '♻️',
    title: 'Reducción de residuos',
    description:
      'Separa tus desechos, participa en puntos de reciclaje y evita el plástico de un solo uso en los mercados locales.'
  },
  {
    icon: '🚲',
    title: 'Movilidad sostenible',
    description:
      'Integra bicicleta, transporte público y caminatas para reducir emisiones y disfrutar la ciudad con más calma.'
  },
  {
    icon: '💡',
    title: 'Energía consciente',
    description:
      'Cambia a focos LED, desconecta equipos en desuso y explora soluciones solares accesibles para azoteas mexicanas.'
  },
  {
    icon: '🥑',
    title: 'Alimentación local',
    description:
      'Elige productos de temporada, apoya tianguis y reduce el desperdicio con recetas creativas para toda la familia.'
  },
  {
    icon: '💧',
    title: 'Agua responsable',
    description:
      'Reusa agua de enjuague, instala aireadores y participa en programas barriales de captación pluvial.'
  },
  {
    icon: '🌱',
    title: 'Comunidad verde',
    description:
      'Organiza trueques, jardines vecinales y retos climáticos con tus amistades y vecinos.'
  }
];

const testimonials = [
  {
    quote:
      'Desde que seguimos las guías de Luna & José Tamira, nuestro edificio separa residuos y redujimos el pago de recolección especial.',
    name: 'Valeria Rojas',
    role: 'Vecina y voluntaria en Xochimilco',
    avatar: 'https://picsum.photos/seed/valeria/120/120'
  },
  {
    quote:
      'La checklist de movilidad sostenible nos ayudó a organizar un sistema de bici compartida entre compañeros de trabajo.',
    name: 'Mauricio Aguilar',
    role: 'Coordinador de innovación en Monterrey',
    avatar: 'https://picsum.photos/seed/mauricio/120/120'
  },
  {
    quote:
      'Las actividades para escuelas rurales están aterrizadas a nuestra realidad y motivan a las y los estudiantes a cuidar el agua.',
    name: 'Itzel Hernández',
    role: 'Profesora comunitaria en Puebla',
    avatar: 'https://picsum.photos/seed/itzel/120/120'
  }
];

const whyReasons = [
  {
    title: 'Cada acción suma',
    description:
      'El 40% de las emisiones urbanas en México proviene de decisiones domésticas. Ajustar hábitos cotidianos reduce esa huella inmediatamente.'
  },
  {
    title: 'Resiliencia frente a extremos',
    description:
      'Olas de calor, sequías e inundaciones ya afectan a las ciudades mexicanas. Hábitos inteligentes preparan hogares y barrios para adaptarse.'
  },
  {
    title: 'Economía local viva',
    description:
      'Comprar a productores regionales y compartir recursos fortalece la economía solidaria y disminuye el transporte de larga distancia.'
  }
];

const featuredPost = {
  tag: 'Nueva guía 2024',
  title: 'Cómo preparar tu hogar para aprovechar la energía solar compartida',
  description:
    'Consejos prácticos para vecindarios que desean instalar paneles solares colectivos sin complicaciones administrativas.',
  link: '/blog'
};

const HomePage = () => {
  return (
    <div className={styles.home}>
      <Helmet>
        <title>Inicio | Luna &amp; José Tamira</title>
        <meta
          name="description"
          content="Descubre hábitos cotidianos inteligentes para el clima pensados para comunidades mexicanas y guías prácticas de Luna & José Tamira."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={styles.heroContent}>
          <span className={styles.heroTag}>Hábitos cotidianos inteligentes para el clima</span>
          <h1 id="hero-title" className={styles.heroTitle}>
            Pequeños gestos, gran alivio para el clima mexicano
          </h1>
          <p className={styles.heroDescription}>
            Diseñamos retos, talleres y recursos que toman en cuenta la realidad de nuestros barrios,
            la diversidad de México y la necesidad de actuar hoy mismo desde casa.
          </p>
          <div className={styles.heroActions}>
            <Link to="/blog" className={styles.primaryButton}>
              Descubre más
            </Link>
            <Link to="/contacto" className={styles.secondaryButton}>
              Conversemos
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.introduction}`} aria-labelledby="intro-title">
        <div className={styles.introCard}>
          <h2 id="intro-title" className={styles.sectionTitle}>
            Una red de hábitos conscientes en todo México
          </h2>
          <p className={styles.sectionIntro}>
            Luna &amp; José Tamira nace del deseo de acompañar a familias, escuelas y colectivos que
            buscan vivir de manera sostenible sin perder su identidad. Desde talleres de compostaje
            en azoteas hasta guías de movilidad multimodal, acercamos soluciones listas para aplicar.
          </p>
          <p className={styles.sectionIntro}>
            Nuestro enfoque combina ciencia climática, creatividad comunitaria y narrativas que
            inspiran acción. Creemos que cada calle puede convertirse en un laboratorio de innovación
            verde a través de hábitos cotidianos inteligentes.
          </p>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="habits-title">
        <div>
          <h2 id="habits-title" className={styles.sectionTitle}>
            Hábitos clave para tu día a día
          </h2>
          <p className={styles.sectionIntro}>
            Seleccionamos prácticas sencillas que generan impacto real en emisiones, resiliencia y
            bienestar colectivo.
          </p>
        </div>
        <div className={styles.habitsGrid}>
          {keyHabits.map((habit) => (
            <article key={habit.title} className={styles.habitCard}>
              <span className={styles.habitIcon} aria-hidden="true">
                {habit.icon}
              </span>
              <h3 className={styles.habitTitle}>{habit.title}</h3>
              <p className={styles.habitDescription}>{habit.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="featured-title">
        <div className={styles.featured}>
          <span className={styles.featuredTitle}>{featuredPost.tag}</span>
          <h2 id="featured-title" className={styles.featuredHeadline}>
            {featuredPost.title}
          </h2>
          <p className={styles.featuredDescription}>{featuredPost.description}</p>
          <Link to={featuredPost.link} className={styles.featuredLink}>
            Leer más recursos <span aria-hidden="true">→</span>
          </Link>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="why-title">
        <div className={styles.whySection}>
          <h2 id="why-title" className={styles.sectionTitle}>
            ¿Por qué importan nuestros hábitos?
          </h2>
          <p className={styles.sectionIntro}>
            Cada ciudad mexicana enfrenta retos climáticos distintos. Al coordinar hábitos
            cotidianos inteligentes, fortalecemos la salud, la economía y el sentido de comunidad.
          </p>
          <div className={styles.whyList}>
            {whyReasons.map((reason) => (
              <div key={reason.title} className={styles.whyItem}>
                <span className={styles.whyHeading}>{reason.title}</span>
                <p className={styles.whyText}>{reason.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="testimonials-title">
        <div>
          <h2 id="testimonials-title" className={styles.sectionTitle}>
            Historias que nos inspiran
          </h2>
          <p className={styles.sectionIntro}>
            Comunidades que ya cambiaron su rutina y hoy comparten aprendizajes con otras ciudades.
          </p>
        </div>
        <div className={styles.testimonials}>
          {testimonials.map((testimonial) => (
            <article key={testimonial.name} className={styles.testimonialCard}>
              <p className={styles.testimonialQuote}>"{testimonial.quote}"</p>
              <div className={styles.testimonialPerson}>
                <img
                  src={testimonial.avatar}
                  alt={`Retrato de ${testimonial.name}`}
                  className={styles.personAvatar}
                  loading="lazy"
                />
                <div className={styles.personInfo}>
                  <span className={styles.personName}>{testimonial.name}</span>
                  <span className={styles.personRole}>{testimonial.role}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="cta-title">
        <div className={styles.ctaSection}>
          <h2 id="cta-title" className={styles.sectionTitle}>
            Sumemos nuevos hábitos con intención
          </h2>
          <p className={styles.sectionIntro}>
            Recibe guías, retos mensuales y talleres en vivo para transformar tu rutina sin perder la
            esencia de tu comunidad.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/blog" className={styles.primaryButton}>
              Explorar el blog
            </Link>
            <Link to="/contacto" className={styles.secondaryButton}>
              Coordinar una charla
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;