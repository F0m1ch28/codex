import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const TermsPage = () => (
  <div className={styles.legalPage}>
    <Helmet>
      <title>Términos de uso | Luna &amp; José Tamira</title>
      <meta
        name="description"
        content="Consulta los términos de uso de lunarejostamira.site y conoce tus derechos y responsabilidades al utilizar nuestros recursos."
      />
    </Helmet>

    <article className={styles.card}>
      <h1 className={styles.title}>Términos de uso</h1>
      <p className={styles.text}>
        Bienvenida/o a lunarejostamira.site. Al acceder o utilizar esta plataforma aceptas los
        presentes términos, diseñados para proteger a nuestra comunidad y mantener un espacio seguro,
        respetuoso y útil.
      </p>
      <ul className={styles.list}>
        <li>Utiliza la información del sitio para fines personales, educativos o comunitarios.</li>
        <li>
          Cita la fuente cuando compartas materiales descargables, mencionando a Luna &amp; José Tamira.
        </li>
        <li>
          Evita distribuir los contenidos con fines comerciales sin nuestro consentimiento por escrito.
        </li>
        <li>
          No realices acciones que puedan dañar, sobrecargar o comprometer la seguridad del sitio.
        </li>
      </ul>
    </article>

    <article className={styles.card}>
      <h2 className={styles.subtitle}>Actualizaciones y disponibilidad</h2>
      <p className={styles.text}>
        Nos reservamos el derecho de actualizar estos términos y los contenidos publicados. Te
        notificaremos los cambios relevantes a través del blog o de nuestro boletín. Procuramos
        mantener el sitio disponible en todo momento, pero no garantizamos ausencia de interrupciones
        temporales.
      </p>
      <div className={styles.highlight}>
        Para cualquier comentario sobre los términos, escríbenos a info@lunarejostamira.site.
      </div>
    </article>
  </div>
);

const CookiePolicyPage = () => (
  <div className={styles.legalPage}>
    <Helmet>
      <title>Política de cookies | Luna &amp; José Tamira</title>
      <meta
        name="description"
        content="Conoce cómo Luna & José Tamira utiliza cookies para mejorar tu experiencia y las opciones que tienes para gestionarlas."
      />
    </Helmet>

    <article className={styles.card}>
      <h1 className={styles.title}>Política de cookies</h1>
      <p className={styles.text}>
        Este sitio emplea cookies propias y de terceros con fines analíticos y para personalizar tu
        experiencia. Las cookies son pequeños archivos que se almacenan en tu dispositivo al navegar.
      </p>
      <p className={styles.text}>Usamos principalmente tres tipos:</p>
      <ul className={styles.list}>
        <li>
          <strong>Cookies esenciales:</strong> necesarias para garantizar el funcionamiento del sitio y
          recordar tus preferencias básicas.
        </li>
        <li>
          <strong>Cookies de rendimiento:</strong> recogen datos anónimos sobre el uso del sitio para
          optimizar contenidos y detectar errores.
        </li>
        <li>
          <strong>Cookies de funcionalidad:</strong> permiten recordarte entre visitas y adaptar la
          experiencia según tu interacción previa.
        </li>
      </ul>
    </article>

    <article className={styles.card}>
      <h2 className={styles.subtitle}>Gestión de cookies</h2>
      <p className={styles.text}>
        Puedes aceptar o rechazar el uso de cookies desde el banner inicial o configurando tu navegador.
        Si decides deshabilitarlas, algunas funciones podrían no mostrarse correctamente.
      </p>
      <div className={styles.highlight}>
        Para más información o para solicitar la eliminación de datos asociados a cookies, escribe a
        info@lunarejostamira.site.
      </div>
    </article>
  </div>
);

export { TermsPage, CookiePolicyPage };