import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const values = [
  {
    title: 'Ciencia aterrizada',
    description:
      'Traducimos reportes climáticos globales en acciones viables para hogares mexicanos, con lenguaje claro y ejemplos cotidianos.'
  },
  {
    title: 'Escucha comunitaria',
    description:
      'Co-creamos soluciones con colectivos, escuelas y vecindarios para asegurar que las propuestas respondan a necesidades reales.'
  },
  {
    title: 'Creatividad cultural',
    description:
      'Integramos tradiciones mexicanas, gastronomía y arte local para que los nuevos hábitos sean significativos y disfrutables.'
  },
  {
    title: 'Impacto medible',
    description:
      'Monitoreamos los resultados de cada proyecto para demostrar cómo la suma de pequeñas decisiones reduce emisiones y mejora la resiliencia.'
  }
];

const team = [
  {
    name: 'Luna Martínez',
    role: 'Co-fundadora y estratega climática',
    photo: 'https://picsum.photos/seed/luna-equipo/200/200',
    bio: 'Diseñadora de retos comunitarios y especialista en educación ambiental con enfoque en ciudades mexicanas.'
  },
  {
    name: 'José Tamira',
    role: 'Co-fundador y narrador de historias',
    photo: 'https://picsum.photos/seed/jose-equipo/200/200',
    bio: 'Periodista ambiental que convierte datos complejos en relatos cercanos, inspirando participación comunitaria.'
  },
  {
    name: 'Andrea Sol',
    role: 'Coordinadora de alianzas',
    photo: 'https://picsum.photos/seed/andrea-equipo/200/200',
    bio: 'Facilita conexiones con organizaciones, universidades y gobiernos locales para escalar proyectos regenerativos.'
  }
];

const AboutPage = () => {
  return (
    <div className={styles.about}>
      <Helmet>
        <title>Nosotros | Luna &amp; José Tamira</title>
        <meta
          name="description"
          content="Conoce al equipo de Luna & José Tamira y descubre cómo impulsamos hábitos climáticos inteligentes con comunidades mexicanas."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="about-title">
        <h1 id="about-title" className={styles.sectionTitle}>
          Somos una dupla que convierte ideas verdes en hábitos cotidianos
        </h1>
        <p className={styles.lead}>
          Trabajamos en colaboración con barrios, escuelas, organizaciones y gobiernos locales de
          México para diseñar experiencias que promuevan estilos de vida resilientes, solidarios y
          bajos en emisiones.
        </p>
      </section>

      <section aria-labelledby="values-title">
        <h2 id="values-title" className={styles.sectionTitle}>
          Nuestros pilares
        </h2>
        <p className={styles.lead}>
          Cada proyecto parte de escuchar el contexto local y proponer soluciones que puedan
          mantenerse en el tiempo.
        </p>
        <div className={styles.values}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3 className={styles.valueTitle}>{value.title}</h3>
              <p className={styles.valueText}>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-title">
        <h2 id="team-title" className={styles.sectionTitle}>
          Un equipo en constante movimiento
        </h2>
        <p className={styles.lead}>
          Colaboramos con especialistas en agua, movilidad, alimentación y energía para asegurar que
          nuestros contenidos sean rigurosos y adaptables.
        </p>
        <div className={styles.teamGrid}>
          {team.map((person) => (
            <article key={person.name} className={styles.teamMember}>
              <img
                src={person.photo}
                alt={`Retrato de ${person.name}`}
                className={styles.memberPhoto}
                loading="lazy"
              />
              <div>
                <p className={styles.memberName}>{person.name}</p>
                <p className={styles.memberRole}>{person.role}</p>
              </div>
              <p className={styles.memberBio}>{person.bio}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.vision} aria-labelledby="vision-title">
        <h2 id="vision-title" className={styles.sectionTitle}>
          Nuestra visión a futuro
        </h2>
        <p className={styles.lead}>
          Queremos que cada ciudad mexicana cuente con una red de hábitos climáticos inteligentes,
          impulsada por personas que comparten conocimiento y celebran sus avances. Nuestra meta es
          sumar 200 comunidades activas antes de 2026.
        </p>
      </section>
    </div>
  );
};

export default AboutPage;