document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.site-nav');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navToggle.classList.toggle('is-active');
      navMenu.classList.toggle('is-open');
    });
    navMenu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.classList.remove('is-active');
        navMenu.classList.remove('is-open');
      });
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const acceptButton = document.getElementById('cookieAccept');
  const declineButton = document.getElementById('cookieDecline');

  if (cookieBanner && acceptButton && declineButton) {
    const storedConsent = localStorage.getItem('cookieConsent');
    if (storedConsent === 'accepted' || storedConsent === 'declined') {
      cookieBanner.classList.add('is-hidden');
    }

    const saveConsent = function (value) {
      localStorage.setItem('cookieConsent', value);
      cookieBanner.classList.add('is-hidden');
    };

    acceptButton.addEventListener('click', function () {
      saveConsent('accepted');
    });

    declineButton.addEventListener('click', function () {
      saveConsent('declined');
    });
  }
});