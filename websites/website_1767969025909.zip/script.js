document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navigation = document.getElementById('primary-navigation');

    if (menuToggle && navigation) {
        menuToggle.addEventListener('click', () => {
            const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', String(!isExpanded));
            navigation.classList.toggle('is-open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const storedChoice = localStorage.getItem('napCookieChoice');

    if (cookieBanner && storedChoice) {
        cookieBanner.classList.add('is-hidden');
    }

    const cookieButtons = document.querySelectorAll('[data-cookie-choice]');
    cookieButtons.forEach((button) => {
        button.addEventListener('click', (event) => {
            const choice = button.getAttribute('data-cookie-choice');
            if (!choice) return;
            event.preventDefault();
            localStorage.setItem('napCookieChoice', choice);
            if (cookieBanner) {
                cookieBanner.classList.add('is-hidden');
            }
            const destination = button.getAttribute('href');
            if (destination) {
                setTimeout(() => {
                    window.location.href = destination;
                }, 180);
            }
        });
    });

    const filterButtons = document.querySelectorAll('[data-filter]');
    const postCards = document.querySelectorAll('.post-card');
    const searchInput = document.querySelector('#postSearch');
    let activeFilter = 'all';

    function applyFilters() {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
        postCards.forEach((card) => {
            const category = card.dataset.category;
            const title = card.dataset.title;
            const summary = card.dataset.summary;
            const matchesCategory = activeFilter === 'all' || category === activeFilter;
            const matchesSearch = query.length === 0 ||
                title.includes(query) ||
                summary.includes(query);
            card.style.display = matchesCategory && matchesSearch ? '' : 'none';
        });
    }

    filterButtons.forEach((button) => {
        button.addEventListener('click', () => {
            activeFilter = button.dataset.filter || 'all';
            filterButtons.forEach((btn) => btn.classList.toggle('is-active', btn === button));
            applyFilters();
        });
    });

    if (searchInput) {
        searchInput.addEventListener('input', () => {
            applyFilters();
        });
    }
});