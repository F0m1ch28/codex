document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  const navLinks = document.querySelectorAll('.main-nav a');
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-btn--accept');
  const declineBtn = document.querySelector('.cookie-btn--decline');
  const consentKey = 'ish_cookie_consent';

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen);
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (mainNav.classList.contains('is-open')) {
          mainNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    }

    const handleConsent = value => {
      localStorage.setItem(consentKey, value);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', () => handleConsent('accepted'));
    declineBtn?.addEventListener('click', () => handleConsent('declined'));
  }
});