document.addEventListener('DOMContentLoaded', () => {
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const cookieKey = 'qbm_cookie_pref';

    if (cookieBanner && acceptBtn && declineBtn) {
        const pref = localStorage.getItem(cookieKey);
        if (!pref) {
            cookieBanner.classList.add('show');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            cookieBanner.classList.remove('show');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'declined');
            cookieBanner.classList.remove('show');
        });
    }

    const messageField = document.getElementById('message');
    if (messageField) {
        const validateMessage = () => {
            if (messageField.value.trim().length < 20) {
                messageField.setCustomValidity('Хабарламаңыз кемінде 20 таңбадан тұруы қажет.');
            } else {
                messageField.setCustomValidity('');
            }
        };
        messageField.addEventListener('input', validateMessage);
        validateMessage();
    }

    const contactForm = document.getElementById('contactForm');
    const formSuccess = document.getElementById('formSuccess');

    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            if (!contactForm.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                contactForm.classList.add('was-validated');
            } else {
                event.preventDefault();
                contactForm.reset();
                contactForm.classList.remove('was-validated');
                if (formSuccess) {
                    formSuccess.classList.remove('d-none');
                    formSuccess.textContent = 'Рахмет! Хабарламаңыз сәтті жіберілді. Біз жақын арада байланысамыз.';
                }
            }
        });
    }

    const newsletterForm = document.getElementById('newsletterForm');
    const newsletterFeedback = document.getElementById('newsletterFeedback');

    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (event) => {
            event.preventDefault();
            if (newsletterForm.checkValidity()) {
                newsletterForm.reset();
                if (newsletterFeedback) {
                    newsletterFeedback.classList.remove('d-none');
                    newsletterFeedback.textContent = 'Сәтті! Жаңалықтар тізіміне қосылдыңыз.';
                }
            } else {
                newsletterForm.classList.add('was-validated');
                if (newsletterFeedback) {
                    newsletterFeedback.classList.remove('d-none');
                    newsletterFeedback.textContent = 'Email дұрыс енгізілгенін тексеріңіз.';
                }
            }
        });
    }
});