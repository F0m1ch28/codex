document.addEventListener("DOMContentLoaded", () => {
    const cookieBanner = document.getElementById("cookieBanner");
    if (cookieBanner) {
        const consentChoice = localStorage.getItem("waxycamlcrCookieConsent");
        if (consentChoice) {
            cookieBanner.setAttribute("hidden", "true");
        }
        const actions = cookieBanner.querySelectorAll(".cookie-action");
        actions.forEach((action) => {
            action.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = action.dataset.choice || "undecided";
                localStorage.setItem("waxycamlcrCookieConsent", choice);
                cookieBanner.setAttribute("hidden", "true");
            });
        });
    }

    document.querySelectorAll(".tab-group").forEach((group) => {
        const buttons = group.querySelectorAll(".tab-button");
        const panels = group.querySelectorAll(".tab-panel");
        buttons.forEach((button) => {
            button.addEventListener("click", () => {
                const targetId = button.getAttribute("data-target");
                buttons.forEach((btn) => {
                    btn.classList.remove("active");
                    btn.setAttribute("aria-selected", "false");
                    btn.setAttribute("tabindex", "-1");
                });
                button.classList.add("active");
                button.setAttribute("aria-selected", "true");
                button.setAttribute("tabindex", "0");
                panels.forEach((panel) => {
                    if (panel.id === targetId) {
                        panel.classList.add("active");
                        panel.removeAttribute("hidden");
                    } else {
                        panel.classList.remove("active");
                        panel.setAttribute("hidden", "true");
                    }
                });
            });
        });
    });

    document.querySelectorAll(".faq-accordion").forEach((accordion) => {
        accordion.querySelectorAll(".faq-question").forEach((button) => {
            button.addEventListener("click", () => {
                const item = button.closest(".faq-item");
                const answer = item.querySelector(".faq-answer");
                const expanded = button.getAttribute("aria-expanded") === "true";
                button.setAttribute("aria-expanded", String(!expanded));
                item.classList.toggle("open", !expanded);
                if (!expanded) {
                    answer.style.maxHeight = answer.scrollHeight + "px";
                } else {
                    answer.style.maxHeight = null;
                }
            });
        });
    });

    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");
    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            mainNav.classList.toggle("open");
        });
        mainNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                mainNav.classList.remove("open");
            });
        });
    }
});