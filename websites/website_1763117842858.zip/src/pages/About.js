```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './About.module.css';

const About = () => {
  const values = [
    {
      title: 'Непрерывная экспертиза',
      description:
        'Следим за технологическими трендами, инвестируем в обучение команды, участвуем в профессиональных сообществах.',
    },
    {
      title: 'Ориентация на результат',
      description:
        'Проекты TechSolutions строятся вокруг KPI клиента: скорость вывода продукта, рост выручки, снижение затрат.',
    },
    {
      title: 'Партнёрство и прозрачность',
      description:
        'Мы строим доверительные отношения, обеспечиваем прозрачную коммуникацию и общую ответственность за результат.',
    },
  ];

  return (
    <div className={styles.about}>
      <Helmet>
        <title>О компании TechSolutions — команда и миссия</title>
        <meta
          name="description"
          content="TechSolutions — команда экспертов в IT-консалтинге и разработке ПО. Узнайте о миссии, истории и ценностях компании."
        />
        <meta
          name="keywords"
          content="TechSolutions, о компании, команда, миссия, ценности, эксперты IT"
        />
      </Helmet>

      <section className={`${styles.hero} sectionPadding`}>
        <div className="container">
          <h1>О компании</h1>
          <p>
            TechSolutions — это команда мультидисциплинарных специалистов, объединённых общей
            целью: помогать компаниям внедрять инновации, превращая технологии в драйвер роста.
            Мы развиваем IT-консалтинг и создаём программные решения с 2008 года.
          </p>
        </div>
      </section>

      <section className="sectionPadding">
        <div className="container">
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <div key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.timeline} sectionPadding`}>
        <div className="container">
          <h2>История и компетенции</h2>
          <div className={styles.timelineGrid}>
            <article>
              <span>2008</span>
              <p>Основание TechSolutions и первые проекты по внедрению ERP-систем.</p>
            </article>
            <article>
              <span>2014</span>
              <p>Запуск направления разработки цифровых продуктов и мобильных сервисов.</p>
            </article>
            <article>
              <span>2018</span>
              <p>Формирование DevOps практики и расширение поддержки глобальных клиентов.</p>
            </article>
            <article>
              <span>2022</span>
              <p>Создание аналитического центра и развитие компетенций в области данных и AI.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.team} sectionPadding`}>
        <div className="container">
          <div className={styles.teamGrid}>
            <div className={styles.teamContent}>
              <h2>Команда TechSolutions</h2>
              <p>
                Более 120 специалистов: системные архитекторы, бизнес-аналитики, разработчики,
                дизайнеры, инженеры по качеству и специалисты по безопасности. Мы придерживаемся
                гибких методологий, практикуем кросс-функциональные команды и уделяем особое
                внимание развитию экспертизы.
              </p>
              <Link to="/contact" className="primaryButton">
                Присоединиться к проекту
              </Link>
            </div>
            <div className={styles.teamMedia}>
              <img
                src="https://picsum.photos/seed/techsolutions-team/1080/720"
                alt="Команда TechSolutions за совместной работой"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
```