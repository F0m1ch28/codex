```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((data) => ({ ...data, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormData({
      name: '',
      email: '',
      company: '',
      message: '',
    });
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <div className={styles.contact}>
      <Helmet>
        <title>Контакты TechSolutions — свяжитесь с нами</title>
        <meta
          name="description"
          content="Свяжитесь с TechSolutions: получите консультацию, обсудите проект или задайте вопрос. Адрес, телефон и форма обратной связи."
        />
        <meta
          name="keywords"
          content="контакты TechSolutions, IT-консалтинг, консультация, форма обратной связи"
        />
      </Helmet>

      <section className={`${styles.hero} sectionPadding`}>
        <div className="container">
          <h1>Свяжитесь с нами</h1>
          <p>
            Оставьте заявку, и команда TechSolutions оперативно свяжется с вами, чтобы обсудить
            задачи и предложить эффективные решения.
          </p>
        </div>
      </section>

      <section className="sectionPadding">
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit}>
              <div className={styles.formRow}>
                <label htmlFor="name">Имя *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Ваше имя"
                  required
                />
              </div>
              <div className={styles.formRow}>
                <label htmlFor="email">Email *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="email@company.com"
                  required
                />
              </div>
              <div className={styles.formRow}>
                <label htmlFor="company">Компания</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Название компании"
                />
              </div>
              <div className={styles.formRow}>
                <label htmlFor="message">Сообщение *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Опишите задачу или интересующий проект"
                  required
                />
              </div>
              <button type="submit" className="primaryButton">
                Отправить запрос
              </button>
              {submitted && (
                <p className={styles.success}>
                  Спасибо! Мы получили вашу заявку и свяжемся с вами в ближайшее время.
                </p>
              )}
            </form>

            <div className={styles.info}>
              <div className={styles.card}>
                <h3>Контактная информация</h3>
                <p>
                  <strong>Адрес:</strong> ул. Технологическая, 123, Москва, Россия, 123456
                </p>
                <p>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </p>
                <p>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>
                </p>
                <p>
                  <strong>Время работы:</strong> Пн–Пт, 09:00–19:00 (МСК)
                </p>
              </div>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Офис TechSolutions"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1998.6143736196734!2d37.61749451625207!3d55.75582698055362!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTXCsDQ1JzIwLjkiTiAzN8KwMzYnNTkuMCJF!5e0!3m2!1sru!2sru!4v1689172800000!5m2!1sru!2sru"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```