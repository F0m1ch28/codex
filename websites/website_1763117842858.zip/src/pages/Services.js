```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const Services = () => {
  const serviceItems = [
    {
      title: 'Стратегический IT-консалтинг',
      description:
        'Аудит цифровой зрелости, формирование стратегии внедрения технологий, разработка дорожных карт модернизации и оптимизации процессов.',
      bullets: [
        'Анализ бизнес-процессов и архитектуры',
        'Планирование цифровой трансформации',
        'Управление изменениями и внедрение',
      ],
      image: 'https://picsum.photos/seed/techsolutions-consulting/960/620',
    },
    {
      title: 'Разработка программного обеспечения',
      description:
        'Проектирование и реализация пользовательских сервисов, корпоративных платформ и интеграционных решений с использованием современных стеков.',
      bullets: [
        'Полный цикл разработки: discovery, UX/UI, разработка, тестирование',
        'Гибкие методологии (Scrum, Kanban, Lean)',
        'Интеграция с существующей инфраструктурой и системами',
      ],
      image: 'https://picsum.photos/seed/techsolutions-development/960/620',
    },
    {
      title: 'Технологическая поддержка и DevOps',
      description:
        'Обеспечение устойчивой работы и эволюционного развития продуктов: мониторинг, автоматизация CI/CD, управление инфраструктурой.',
      bullets: [
        '24/7 мониторинг и реагирование на инциденты',
        'Настройка DevOps процессов и культур',
        'Проактивная оптимизация производительности',
      ],
      image: 'https://picsum.photos/seed/techsolutions-support/960/620',
    },
  ];

  return (
    <div className={styles.services}>
      <Helmet>
        <title>Услуги компании TechSolutions — IT-консалтинг и разработка ПО</title>
        <meta
          name="description"
          content="Услуги TechSolutions: стратегический IT-консалтинг, разработка программного обеспечения, техническая поддержка и DevOps сопровождение."
        />
        <meta
          name="keywords"
          content="услуги IT-консалтинг, разработка программного обеспечения, DevOps поддержка, TechSolutions"
        />
      </Helmet>

      <section className={`${styles.intro} sectionPadding`}>
        <div className="container">
          <h1>Услуги</h1>
          <p>
            Мы создаём устойчивые технологические экосистемы и продукты, которые помогают бизнесу
            расти и адаптироваться к изменениям рынка. Команда TechSolutions объединяет стратегов,
            аналитиков, дизайнеров и инженеров для достижения конкретных результатов.
          </p>
        </div>
      </section>

      <section className="sectionPadding">
        <div className="container">
          <div className={styles.serviceList}>
            {serviceItems.map((service) => (
              <article key={service.title} className={styles.serviceItem}>
                <img src={service.image} alt={service.title} />
                <div className={styles.serviceContent}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                  <ul>
                    {service.bullets.map((bullet) => (
                      <li key={bullet}>{bullet}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.bottomCta} sectionPadding`}>
        <div className="container">
          <h2>Комбинируем компетенции под ваши задачи</h2>
          <p>
            Готовы подключиться на любом этапе: от стратегического аудита до поддержки готового
            решения. Расскажите о проекте — предложим оптимальную конфигурацию услуг.
          </p>
          <Link to="/contact" className="primaryButton">
            Обсудить проект
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;
```