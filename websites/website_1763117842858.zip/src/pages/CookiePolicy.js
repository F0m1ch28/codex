```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.policy}>
      <Helmet>
        <title>Политика использования cookies — TechSolutions</title>
        <meta
          name="description"
          content="Политика использования файлов cookies на сайте TechSolutions. Узнайте, какие cookies мы применяем и с какой целью."
        />
        <meta
          name="keywords"
          content="политика cookies, файлы cookie, TechSolutions, сбор данных"
        />
      </Helmet>

      <section className="sectionPadding">
        <div className="container">
          <h1>Политика cookies</h1>
          <p>
            Cookies — это небольшие файлы, которые сохраняются на вашем устройстве при посещении
            сайта. TechSolutions использует cookies, чтобы обеспечить корректную работу сервисов и
            улучшить пользовательский опыт.
          </p>

          <h2>1. Типы используемых cookies</h2>
          <ul>
            <li>Технические cookies — необходимы для работы сайта.</li>
            <li>Аналитические cookies — помогают анализировать трафик и улучшать сервисы.</li>
            <li>Функциональные cookies — запоминают ваши настройки и предпочтения.</li>
          </ul>

          <h2>2. Управление cookies</h2>
          <p>
            Вы можете ограничить или отключить использование cookies в настройках браузера. Однако
            некоторые функции сайта могут работать некорректно без технических cookies.
          </p>

          <h2>3. Обновление политики</h2>
          <p>
            Политика cookies может обновляться. Все изменения публикуются на этой странице и вступают
            в силу с момента публикации.
          </p>

          <p>
            По вопросам использования cookies обращайтесь на{' '}
            <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;
```