```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const Home = () => {
  const services = [
    {
      title: 'IT-консалтинг',
      description:
        'Комплексная оценка текущих процессов, построение дорожной карты цифровой трансформации и поддержка на всех этапах изменений.',
      icon: '💡',
    },
    {
      title: 'Разработка программного обеспечения',
      description:
        'Создание масштабируемых решений под ваши задачи: веб-платформы, мобильные приложения, корпоративные системы.',
      icon: '⚙️',
    },
    {
      title: 'Техническая поддержка',
      description:
        'Непрерывное сопровождение, мониторинг и оптимизация инфраструктуры с гарантией SLA и прозрачной отчётностью.',
      icon: '🛡️',
    },
  ];

  const advantages = [
    '15+ лет опыта в IT-консалтинге и разработке корпоративных решений',
    'Экспертиза в финтехе, ретейле, производстве и госсекторе',
    'Команда сертифицированных архитекторов, аналитиков и инженеров',
    'Фокус на измеримом бизнес-результате и окупаемости инвестиций',
  ];

  return (
    <div className={styles.home}>
      <Helmet>
        <title>TechSolutions — IT-консалтинг и разработка ПО</title>
        <meta
          name="description"
          content="TechSolutions помогает компаниям ускорять цифровую трансформацию: IT-консалтинг, разработка программного обеспечения и поддержка инфраструктуры."
        />
        <meta
          name="keywords"
          content="IT-консалтинг, разработка программного обеспечения, цифровая трансформация, TechSolutions, поддержка инфраструктуры"
        />
      </Helmet>

      <section className={`${styles.hero} sectionPadding`}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <p className={styles.overline}>Профессиональные IT-решения</p>
              <h1>
                Ускоряем ваш бизнес благодаря технологиям, данным и экспертизе TechSolutions
              </h1>
              <p>
                Мы проектируем и внедряем цифровые продукты, которые повышают эффективность
                процессов, повышают удовлетворенность клиентов и открывают новые источники роста.
              </p>
              <div className={styles.heroActions}>
                <Link to="/contact" className="primaryButton">
                  Запросить консультацию
                </Link>
                <Link to="/services" className="ghostButton">
                  Каталог услуг
                </Link>
              </div>
              <div className={styles.stats}>
                <div>
                  <span>250+</span>
                  <p>успешных проектов</p>
                </div>
                <div>
                  <span>50%</span>
                  <p>сокращение Time-to-Market</p>
                </div>
                <div>
                  <span>99,9%</span>
                  <p>доступность решений</p>
                </div>
              </div>
            </div>
            <div className={styles.heroMedia}>
              <img
                src="https://picsum.photos/seed/techsolutions-hero/1080/720"
                alt="Команда TechSolutions за рабочим обсуждением цифрового проекта"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.services} sectionPadding`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Что мы делаем</h2>
            <p>
              Наши решения объединяют бизнес-цели и современные технологии, чтобы создавать
              устойчивую ценность для вашего предприятия.
            </p>
          </div>
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <div className={styles.icon}>{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.cardLink}>
                  Узнать больше →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.advantages} sectionPadding`}>
        <div className="container">
          <div className={styles.advantagesGrid}>
            <div>
              <h2>Почему выбирают TechSolutions</h2>
              <p>
                Мы объединяем стратегическое мышление, дизайн и инженерную точность. Наш подход
                строится на глубоком понимании бизнеса, прозрачной коммуникации и культуре
                совместного успеха.
              </p>
              <Link to="/about" className="ghostButton">
                О нашей команде
              </Link>
            </div>
            <div className={styles.advList}>
              {advantages.map((advantage) => (
                <div key={advantage} className={styles.advItem}>
                  <span>✓</span>
                  <p>{advantage}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.cta} sectionPadding`}>
        <div className="container">
          <div className={styles.ctaInner}>
            <h2>Готовы обсудить ваш следующий проект?</h2>
            <p>
              Расскажите нам о своей задачe, и мы предложим оптимальное решение: от стратегической
              консультации до полного цикла разработки продукта.
            </p>
            <Link to="/contact" className="primaryButton">
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
```