```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.footerContent}`}>
        <div className={styles.brand}>
          <h3>TechSolutions</h3>
          <p>
            Партнёр по цифровой трансформации: IT-консалтинг, разработка программного
            обеспечения и технологическая поддержка.
          </p>
        </div>
        <div className={styles.links}>
          <h4>Компания</h4>
          <Link to="/services">Услуги</Link>
          <Link to="/about">О компании</Link>
          <Link to="/contact">Контакты</Link>
        </div>
        <div className={styles.links}>
          <h4>Документы</h4>
          <Link to="/privacy">Политика конфиденциальности</Link>
          <Link to="/terms">Условия использования</Link>
          <Link to="/cookie-policy">Политика cookies</Link>
        </div>
        <div className={styles.contacts}>
          <h4>Связаться с нами</h4>
          <p>ул. Технологическая, 123<br />Москва, 123456, Россия</p>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className="container">
          <span>© {new Date().getFullYear()} TechSolutions. Все права защищены.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```