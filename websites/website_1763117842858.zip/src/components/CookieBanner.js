```javascript
import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'techsolutions-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(COOKIE_STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner}>
      <p>
        Мы используем cookies для улучшения работы сайта и персонализации сервисов. Продолжая
        пользоваться сайтом, вы подтверждаете своё согласие с нашей политикой обработки данных.
      </p>
      <button type="button" onClick={acceptCookies}>
        Согласен
      </button>
    </div>
  );
};

export default CookieBanner;
```