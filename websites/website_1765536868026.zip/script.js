document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('primary-nav');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen.toString());
      document.body.classList.toggle('nav-open', isOpen);
    });

    nav.querySelectorAll('.nav-link, .btn-cta').forEach((link) => {
      link.addEventListener('click', () => {
        if (nav.classList.contains('open')) {
          nav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
          document.body.classList.remove('nav-open');
        }
      });
    });
  }

  const pageKey = document.body.dataset.page;
  if (pageKey) {
    document.querySelectorAll('[data-nav]').forEach((link) => {
      if (link.dataset.nav === pageKey) {
        link.classList.add('active');
      }
    });
  }

  const banner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');

  if (banner && acceptBtn && declineBtn) {
    const consent = localStorage.getItem('discoverCroatiaCookieConsent');
    const sessionDecline = sessionStorage.getItem('discoverCroatiaCookieDeclined');

    if (consent === 'accepted' || sessionDecline === 'declined') {
      banner.classList.add('is-hidden');
    }

    acceptBtn.addEventListener('click', () => {
      localStorage.setItem('discoverCroatiaCookieConsent', 'accepted');
      banner.classList.add('is-hidden');
    });

    declineBtn.addEventListener('click', () => {
      sessionStorage.setItem('discoverCroatiaCookieDeclined', 'declined');
      banner.classList.add('is-hidden');
    });
  }

  document.querySelectorAll('.faq-item button').forEach((button) => {
    const answer = button.nextElementSibling;
    if (answer && answer.classList.contains('faq-answer')) {
      if (button.getAttribute('aria-expanded') === 'true') {
        answer.hidden = false;
      }
      button.addEventListener('click', () => {
        const expanded = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', (!expanded).toString());
        answer.hidden = expanded;
      });
    }
  });

  const form = document.querySelector('.contact-form');
  if (form) {
    const messageEl = form.querySelector('.form-message');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      let valid = true;

      form.querySelectorAll('[data-required]').forEach((field) => {
        if (!field.value.trim()) {
          field.classList.add('input-error');
          valid = false;
        } else {
          field.classList.remove('input-error');
        }
      });

      if (!valid) {
        if (messageEl) {
          messageEl.textContent = 'Please complete all required fields before sending your message.';
          messageEl.classList.add('is-visible', 'is-error');
        }
        return;
      }

      if (messageEl) {
        messageEl.textContent = 'Thank you! Our Croatia specialists will reach out within one business day.';
        messageEl.classList.add('is-visible');
        messageEl.classList.remove('is-error');
      }

      form.reset();
    });
  }
});