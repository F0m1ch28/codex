document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieButtons = cookieBanner ? cookieBanner.querySelectorAll('button[data-cookie-action]') : [];
    const consentKey = 'phonicqgul-cookie-consent';

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navMenu.classList.toggle('is-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768 && navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            cookieBanner.classList.add('is-visible');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-cookie-action');
                localStorage.setItem(consentKey, action === 'accept' ? 'accepted' : 'declined');
                cookieBanner.classList.remove('is-visible');
            });
        });
    }
});