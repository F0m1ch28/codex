document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            siteNav.classList.toggle('is-active');
            navToggle.setAttribute('aria-expanded', siteNav.classList.contains('is-active'));
        });

        document.addEventListener('click', (event) => {
            if (!siteNav.contains(event.target) && !navToggle.contains(event.target)) {
                siteNav.classList.remove('is-active');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 900) {
                siteNav.classList.remove('is-active');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptButton = document.querySelector('[data-cookie-accept]');
    const declineButton = document.querySelector('[data-cookie-decline]');
    const consentKey = 'flushnrie-cookie-consent';

    if (cookieBanner && acceptButton && declineButton) {
        const existingConsent = localStorage.getItem(consentKey);
        if (existingConsent) {
            cookieBanner.style.display = 'none';
        }

        acceptButton.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.style.display = 'none';
        });

        declineButton.addEventListener('click', () => {
            window.location.href = 'cookies.html';
        });
    }
});