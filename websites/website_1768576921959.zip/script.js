document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navList = document.querySelector(".nav-list");

    if (navToggle && navList) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            navList.classList.toggle("show");
        });

        navList.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navToggle.classList.remove("active");
                navList.classList.remove("show");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");

    if (cookieBanner && acceptBtn && declineBtn) {
        const consent = localStorage.getItem("freedodoms-cookie-consent");
        if (!consent) {
            cookieBanner.classList.add("visible");
        }

        acceptBtn.addEventListener("click", () => {
            localStorage.setItem("freedodoms-cookie-consent", "accepted");
            cookieBanner.classList.remove("visible");
        });

        declineBtn.addEventListener("click", () => {
            localStorage.setItem("freedodoms-cookie-consent", "declined");
            cookieBanner.classList.remove("visible");
        });
    }
});