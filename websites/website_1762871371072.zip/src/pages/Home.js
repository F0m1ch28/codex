import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Antwortzeit reduziert', suffix: '%', target: 68 },
  { label: 'Tickets automatisiert', suffix: '%', target: 72 },
  { label: 'Kundenzufriedenheit', suffix: '%', target: 94 },
  { label: 'Integrationen live', suffix: '+', target: 45 }
];

const features = [
  { title: 'KI-Chatbot & Agent Assist', description: 'Intelligente Konversationen rund um die Uhr – mit Kontextübergabe an Ihr Team.' },
  { title: 'Omnichannel-Inbox', description: 'E-Mail, Chat, Social und Voice in einer Ansicht, orchestriert über klare Prioritäten.' },
  { title: 'Workflows & Automationen', description: 'Visuelle Builder für Regeln, Eskalationen und Servicelevel-basiertes Routing.' },
  { title: 'Wissensmanagement', description: 'Verifizierte Antworten, kuratiert von Ihrem Team und stetig optimiert durch Feedback.' }
];

const processSteps = [
  { title: 'Verbinden', detail: 'Anschlüsse an CRM, Shop, ERP und Chat-Systeme via vorgefertigter Integrationen.' },
  { title: 'Automatisieren', detail: 'No-Code-Editoren, KI-Modelle und Eskalationspfade je nach Service-Level.' },
  { title: 'Ausliefern', detail: 'Relevante Antworten, Aufgaben und Alerts in Echtzeit an Agent:innen und Kund:innen.' },
  { title: 'Messen', detail: 'Dashboards, Servicequalität und Stimmungsanalyse für kontinuierliche Optimierung.' }
];

const reasons = [
  { title: 'DSGVO-Hoheit', detail: 'Datenhaltung ausschließlich in Deutschland mit verschlüsselten Datenbanken.' },
  { title: 'Enterprise Integrationen', detail: 'Nahtlose Anbindung an Salesforce, HubSpot, Microsoft, Shopify und mehr.' },
  { title: 'Skalierbarkeit', detail: 'Elastische Infrastruktur für Hochlastphasen und saisonale Spitzen.' },
  { title: 'Governance', detail: 'Feingranulares Rollenmodell, Audit-Logs und Richtlinienmanagement.' }
];

const testimonials = [
  {
    name: 'Saskia Richter',
    role: 'Director Customer Care, RetailTech',
    quote: 'Mit Nuvrionex steuern wir sämtliche Kontaktkanäle aus einer Oberfläche. Erstreaktionszeiten haben sich halbiert – bei gleichzeitig höherer Qualität.',
    kpi: '35% mehr beantwortete Anfragen pro Agent:in'
  },
  {
    name: 'Leon Heise',
    role: 'Head of Operations, FinTech',
    quote: 'Workflows lassen sich in Minuten anpassen. Die Plattform liefert uns Transparenz über Compliance und Performance in Echtzeit.',
    kpi: 'Audit-Timeframes um 40% verkürzt'
  },
  {
    name: 'Nora Keller',
    role: 'Customer Experience Lead, SaaS',
    quote: 'Der KI-Assist liefert präzise Vorschläge für unser Team. Die Zufriedenheit unserer Kund:innen liegt auf Rekordniveau.',
    kpi: 'CSAT-Steigerung von 17 Punkten'
  }
];

const teamMembers = [
  { name: 'Marius Krüger', role: 'CEO & Co-Founder', focus: 'Strategie & Partnerschaften', img: 'https://picsum.photos/400/400?random=31' },
  { name: 'Ebru Seidel', role: 'Head of AI', focus: 'Applied Machine Learning', img: 'https://picsum.photos/400/400?random=32' },
  { name: 'Jakob Fink', role: 'VP Engineering', focus: 'Plattform & Integrationen', img: 'https://picsum.photos/400/400?random=33' }
];

const projectGallery = [
  { id: 1, title: 'Smart Fulfillment Desk', category: 'Logistik', img: 'https://picsum.photos/1200/800?random=41' },
  { id: 2, title: 'Subscription Care Suite', category: 'SaaS', img: 'https://picsum.photos/1200/800?random=42' },
  { id: 3, title: 'Checkout Support Automation', category: 'E-Commerce', img: 'https://picsum.photos/1200/800?random=43' },
  { id: 4, title: 'Payment Resolution Hub', category: 'FinTech', img: 'https://picsum.photos/1200/800?random=44' }
];

const faqItems = [
  { question: 'Wie integriert sich Nuvrionex in bestehende Systeme?', answer: 'Über zertifizierte Konnektoren, offene APIs und sichere Webhooks. Ein dediziertes Team begleitet die Umsetzung mit klaren Meilensteinen.' },
  { question: 'Welche Sprachen unterstützt der KI-Chatbot?', answer: 'Deutsch und Englisch sind nativ verfügbar. Weitere Sprachen lassen sich mit domänenspezifischem Training ergänzen.' },
  { question: 'Wie stellt Nuvrionex Datensicherheit sicher?', answer: 'Durch ISO 27001-konforme Prozesse, Ende-zu-Ende-Verschlüsselung, rollenbasierte Freigaben und regelmäßige Penetrationstests.' },
  { question: 'Gibt es Onboarding-Unterstützung?', answer: 'Ja, unsere Customer Success Manager planen Rollout, Schulungen und Governance gemeinsam mit Ihrem Team.' }
];

const blogPosts = [
  { title: 'Blueprint für resiliente Service-Teams 2024', date: '05. März 2024', category: 'Guides' },
  { title: 'Wie Omnichannel KPIs vereinheitlicht werden', date: '20. Februar 2024', category: 'Insights' },
  { title: 'Erfahrungsbericht: KI-Augmentation im Support', date: '06. Februar 2024', category: 'Case Study' }
];

const Home = () => {
  const [counters, setCounters] = useState(statsConfig.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Alle');

  useEffect(() => {
    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, idx) => {
          const target = statsConfig[idx].target;
          if (value >= target) return target;
          const increment = Math.ceil(target / 40);
          return value + increment > target ? target : value + increment;
        })
      );
    }, 80);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(rotation);
  }, []);

  const filteredProjects =
    activeCategory === 'Alle'
      ? projectGallery
      : projectGallery.filter((project) => project.category === activeCategory);

  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Nuvrionex Kundenservice Automatisierung für Teams</title>
        <meta
          name="description"
          content="Nuvrionex ist die deutsche SaaS-Plattform für automatisierten Kundenservice. Verbinden, automatisieren, ausliefern und messen – sicher und skalierbar."
        />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'SoftwareApplication',
            name: 'Nuvrionex',
            applicationCategory: 'CustomerSupportApplication',
            operatingSystem: 'Web',
            offers: { '@type': 'Offer', availability: 'https://schema.org/InStock' },
            aggregateRating: { '@type': 'AggregateRating', ratingValue: '4.9', reviewCount: '128' },
            creator: {
              '@type': 'Organization',
              name: 'Nuvrionex GmbH',
              address: 'Friedrichstraße 123, 10117 Berlin, Deutschland',
              telephone: '+49 30 12345678',
              email: 'info@nuvrionex.com'
            }
          })}
        </script>
      </Helmet>
      <div className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <span className="tag">Automatisierter Kundenservice</span>
              <h1 className={styles.heroTitle}>Automatisierter Kundenservice, der skaliert</h1>
              <p className={styles.heroText}>
                Nuvrionex orchestriert Kanäle, Workflows und KI in einer Plattform. Für Teams, die exzellente Kundenerlebnisse
                liefern und Compliance jederzeit sichern wollen.
              </p>
              <div className={styles.heroActions}>
                <Link to="/kontakt" className={styles.primaryAction}>
                  Jetzt starten
                </Link>
                <Link to="/funktionen" className={styles.secondaryAction}>
                  Funktionen ansehen
                </Link>
              </div>
              <div className={styles.heroLogos} aria-label="Vertrauenswürdige Partner">
                <p>Vertrauen von führenden Marken aus Deutschland</p>
                <div>
                  <span>Nordlicht Retail</span>
                  <span>FuturaPay</span>
                  <span>SkyRoute Logistics</span>
                </div>
              </div>
            </div>
            <div className={styles.heroMedia}>
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Support-Team arbeitet mit dem Nuvrionex Dashboard"
                className={styles.heroImage}
                loading="lazy"
              />
              <div className={styles.heroWidget}>
                <p>Live Insights</p>
                <div>
                  <strong>98%</strong>
                  <span>SLA erfüllt</span>
                </div>
                <div>
                  <strong>212</strong>
                  <span>Aktive Sessions</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className={styles.statsSection} aria-labelledby="leistungsdaten">
        <div className="container">
          <h2 id="leistungsdaten" className="section-title">Ergebnisse, die Kundenteams weiterbringen</h2>
          <p className="section-subtitle">
            Präzise Automatisierung und Analyse sorgen für messbare Fortschritte entlang Ihrer Serviceziele.
          </p>
          <div className={styles.statsGrid}>
            {statsConfig.map((stat, idx) => (
              <article key={stat.label} className={styles.statCard}>
                <strong>{counters[idx]}{stat.suffix}</strong>
                <span>{stat.label}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.featuresSection} aria-labelledby="funktionen">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="funktionen" className="section-title">Funktionen für moderne Service-Organisationen</h2>
            <p className="section-subtitle">
              Von KI-gestützten Dialogen bis hin zu tiefen Integrationen – Nuvrionex bündelt alle Bausteine für nahtlose Interaktion.
            </p>
          </div>
          <div className={styles.featuresGrid}>
            {features.map((feature) => (
              <article key={feature.title} className={styles.featureCard}>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
                <Link to="/funktionen" className={styles.cardLink} aria-label={`Mehr zu ${feature.title}`}>
                  Mehr erfahren →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection} aria-labelledby="prozess">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="prozess" className="section-title">So funktioniert Nuvrionex von Tag eins an</h2>
            <p className="section-subtitle">
              Ein durchgängiger Ablauf, der Ihre Systeme verbindet, Aufgaben automatisiert und Ergebnisse messbar macht.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span>{String(index + 1).padStart(2, '0')}</span>
                <h3>{step.title}</h3>
                <p>{step.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.whySection} aria-labelledby="vorteile">
        <div className="container">
          <h2 id="vorteile" className="section-title">Warum Teams sich für Nuvrionex entscheiden</h2>
          <div className={styles.whyGrid}>
            {reasons.map((reason) => (
              <article key={reason.title} className={styles.whyCard}>
                <h3>{reason.title}</h3>
                <p>{reason.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialSection} aria-labelledby="stimmen">
        <div className="container">
          <h2 id="stimmen" className="section-title">Erfolgsgeschichten unserer Kund:innen</h2>
          <div className={styles.testimonialWrapper}>
            <article className={styles.testimonialCard}>
              <p className={styles.quote}>&ldquo;{testimonials[testimonialIndex].quote}&rdquo;</p>
              <div className={styles.testimonialMeta}>
                <div>
                  <strong>{testimonials[testimonialIndex].name}</strong>
                  <span>{testimonials[testimonialIndex].role}</span>
                </div>
                <span className={styles.kpi}>{testimonials[testimonialIndex].kpi}</span>
              </div>
            </article>
            <div className={styles.carouselDots} role="tablist" aria-label="Testimonials">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setTestimonialIndex(idx)}
                  className={`${styles.dot} ${idx === testimonialIndex ? styles.dotActive : ''}`}
                  aria-label={`Testimonial ${idx + 1} anzeigen`}
                  aria-selected={idx === testimonialIndex}
                  role="tab"
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection} aria-labelledby="team">
        <div className="container">
          <h2 id="team" className="section-title">Leadership für wegweisende Service-Innovationen</h2>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.img} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p>{member.role}</p>
                  <span>{member.focus}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} aria-labelledby="projekte">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="projekte" className="section-title">Use Cases aus vier Schlüsselbranchen</h2>
            <p className="section-subtitle">
              Unsere Plattform bildet komplexe Anforderungen ab – von Checkout-Flows bis hin zu zeitkritischen Supply-Chain-Updates.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Projektkategorien">
            {['Alle', 'E-Commerce', 'SaaS', 'FinTech', 'Logistik'].map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${activeCategory === category ? styles.filterButtonActive : ''}`}
                onClick={() => setActiveCategory(category)}
                role="tab"
                aria-selected={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <figure key={project.id} className={styles.projectCard}>
                <img src={project.img} alt={`${project.title} für ${project.category}`} loading="lazy" />
                <figcaption>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="faq" className="section-title">Antworten auf häufige Fragen</h2>
            <p className="section-subtitle">Transparente Informationen zu Funktionalität, Integration und Governance.</p>
          </div>
          <div className={styles.accordion}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.accordionItem}>
                <summary>
                  <span>{item.question}</span>
                  <span className={styles.plus}>+</span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} aria-labelledby="blog">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog" className="section-title">Einblicke aus dem Nuvrionex Ressourcenhub</h2>
            <p className="section-subtitle">
              Aktuelle Perspektiven rund um Service-Automatisierung, KI-Governance und Experience-Design.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span>{post.category}</span>
                <h3>{post.title}</h3>
                <p>{post.date}</p>
                <Link to="/ressourcen" className={styles.cardLink}>
                  Dokumentation lesen
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection} aria-labelledby="cta">
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2 id="cta">Bereit, Kundenerlebnisse neu zu definieren?</h2>
              <p>
                Lassen Sie uns gemeinsam den nächsten Sprint planen. Unsere Expert:innen zeigen, wie Ihre Prozesse mit Nuvrionex
                schneller, präziser und messbarer werden.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/kontakt" className={styles.primaryAction}>
                Demo anfordern
              </Link>
              <Link to="/pläne" className={styles.secondaryAction}>
                Pläne entdecken
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;