import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/über-uns', label: 'Über uns' },
  { path: '/funktionen', label: 'Funktionen' },
  { path: '/lösungen', label: 'Lösungen' },
  { path: '/integrationen', label: 'Integrationen' },
  { path: '/ressourcen', label: 'Ressourcen' },
  { path: '/sicherheit', label: 'Sicherheit' },
  { path: '/pläne', label: 'Pläne' },
  { path: '/kontakt', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Zur Startseite">
          <span className={styles.logoMark}>N</span>
          <span className={styles.logoText}>Nuvrionex</span>
        </Link>
        <button
          type="button"
          className={`${styles.toggle} ${menuOpen ? styles.toggleOpen : ''}`}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-label="Navigation öffnen"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
          <ul className={styles.list}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.item}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) => (isActive ? `${styles.link} ${styles.linkActive}` : styles.link)}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link className={styles.cta} to="/kontakt">
            Demo anfordern
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;