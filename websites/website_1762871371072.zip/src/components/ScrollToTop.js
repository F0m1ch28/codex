import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import styles from './ScrollToTop.module.css';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [pathname]);

  useEffect(() => {
    const toggleVisibility = () => {
      setVisible(window.scrollY > 320);
    };
    window.addEventListener('scroll', toggleVisibility, { passive: true });
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return visible ? (
    <button type="button" className={styles.button} onClick={handleClick} aria-label="Nach oben scrollen">
      ↑
    </button>
  ) : null;
};

export default ScrollToTop;