import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('nuvrionex_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('nuvrionex_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <p>
        Wir nutzen Cookies, um Funktionen der Plattform bereitzustellen und die Nutzung zu analysieren. Ihre Daten
        werden gemäß unserer <a href="/datenschutz">Datenschutzrichtlinie</a> verarbeitet.
      </p>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Einverstanden
      </button>
    </aside>
  );
};

export default CookieBanner;