import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <div className={styles.logo} aria-hidden="true">N</div>
          <div>
            <p className={styles.title}>Nuvrionex</p>
            <p className={styles.subtitle}>Automatisierter Kundenservice aus Berlin</p>
          </div>
        </div>
        <div className={styles.columns}>
          <div>
            <h3 className={styles.heading}>Kontakt</h3>
            <ul className={styles.list}>
              <li>Friedrichstraße 123<br />10117 Berlin, Deutschland</li>
              <li><a href="tel:+493012345678">+49 30 12345678</a></li>
              <li><a href="mailto:info@nuvrionex.com">info@nuvrionex.com</a></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Unternehmen</h3>
            <ul className={styles.list}>
              <li><Link to="/über-uns">Über uns</Link></li>
              <li><Link to="/sicherheit">Sicherheit</Link></li>
              <li><Link to="/ressourcen">Ressourcen</Link></li>
              <li><Link to="/kontakt">Kontakt</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Rechtliches</h3>
            <ul className={styles.list}>
              <li><Link to="/rechtliches">Nutzungsbedingungen</Link></li>
              <li><Link to="/datenschutz">Datenschutz</Link></li>
              <li><Link to="/cookie-richtlinie">Cookie-Richtlinie</Link></li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {year} Nuvrionex GmbH. Alle Rechte vorbehalten.</p>
        <div className={styles.socials} aria-label="Social Media">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer">Twitter</a>
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer">YouTube</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;