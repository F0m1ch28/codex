import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Solutions from './pages/Solutions';
import Integrations from './pages/Integrations';
import Resources from './pages/Resources';
import Security from './pages/Security';
import Plans from './pages/Plans';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  return (
    <div className="app">
      <a href="#hauptinhalt" className="skip-link">
        Zum Inhalt springen
      </a>
      <ScrollToTop />
      <Header />
      <main id="hauptinhalt" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/über-uns" element={<About />} />
          <Route path="/funktionen" element={<Services />} />
          <Route path="/lösungen" element={<Solutions />} />
          <Route path="/integrationen" element={<Integrations />} />
          <Route path="/ressourcen" element={<Resources />} />
          <Route path="/sicherheit" element={<Security />} />
          <Route path="/pläne" element={<Plans />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/rechtliches" element={<Terms />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
}

export default App;