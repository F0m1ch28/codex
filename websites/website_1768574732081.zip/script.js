document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-actions .accept');
    const declineBtn = document.querySelector('.cookie-actions .decline');
    const consentKey = 'lateraCookieConsent';

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', navLinks.classList.contains('open'));
        });

        navLinks.addEventListener('click', (event) => {
            if (event.target.tagName === 'A' && navLinks.classList.contains('open')) {
                navLinks.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (cookieBanner) {
        const consent = localStorage.getItem(consentKey);
        if (!consent) {
            cookieBanner.classList.add('active');
        }

        const handleConsent = (value) => {
            localStorage.setItem(consentKey, value);
            cookieBanner.classList.remove('active');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleConsent('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleConsent('declined'));
        }
    }
});