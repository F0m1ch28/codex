import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <h3>Tu Progreso Hoy</h3>
          <p className="footer-text">
            Datos verificados para planificar tu presupuesto. Decisiones responsables, objetivos nítidos.
          </p>
          <p className="footer-text">
            Conocimiento financiero impulsado por tendencias. Pasos acertados hoy, mejor futuro mañana.
          </p>
        </div>
        <div>
          <h4>Visit us</h4>
          <p>Av. 9 de Julio 1000<br />C1043 Buenos Aires, Argentina</p>
          <p>
            Tel: <a href="tel:+541155551234">+54 11 5555-1234</a>
          </p>
          <p>
            Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          </p>
        </div>
        <div>
          <h4>Learn</h4>
          <ul className="footer-links">
            <li>
              <Link to="/inflation">Inflation insights</Link>
            </li>
            <li>
              <Link to="/course">Course overview</Link>
            </li>
            <li>
              <Link to="/resources">Recursos EN/ES</Link>
            </li>
            <li>
              <Link to="/contact">Contacto</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Legal</h4>
          <ul className="footer-links">
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/cookies">Cookies Notice</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Use</Link>
            </li>
          </ul>
          <p className="footer-text">
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</span>
        <div className="social-links" aria-label="Social media">
          <a href="https://www.linkedin.com" aria-label="LinkedIn">LinkedIn</a>
          <a href="https://www.twitter.com" aria-label="Twitter">X</a>
          <a href="https://www.instagram.com" aria-label="Instagram">Instagram</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;