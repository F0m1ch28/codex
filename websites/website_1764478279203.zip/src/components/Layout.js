import React, { useEffect } from "react";
import Header from "./Header";
import Footer from "./Footer";
import CookieBanner from "./CookieBanner";
import DisclaimerModal from "./DisclaimerModal";
import { Helmet } from "react-helmet";

const Layout = ({ children }) => {
  useEffect(() => {
    const main = document.querySelector("main");
    if (main) {
      main.setAttribute("tabIndex", "-1");
    }
  }, []);

  return (
    <>
      <Helmet>
        <html lang="en" />
        <link
          rel="alternate"
          hrefLang="en"
          href="https://www.tuprogresohoy.com/"
        />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href="https://www.tuprogresohoy.com/"
        />
        <title>Tu Progreso Hoy</title>
      </Helmet>
      <DisclaimerModal />
      <CookieBanner />
      <Header />
      <main id="main-content">{children}</main>
      <Footer />
    </>
  );
};

export default Layout;