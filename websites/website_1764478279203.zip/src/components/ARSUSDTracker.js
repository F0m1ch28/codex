import React, { useEffect, useState } from "react";

const ARSUSDTracker = () => {
  const [rate, setRate] = useState(null);
  const [trend, setTrend] = useState("steady");
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const response = await fetch("https://api.exchangerate.host/convert?from=ARS&to=USD");
        const data = await response.json();
        if (data && data.result) {
          const rounded = Number(data.result.toFixed(4));
          setRate(rounded);
          if (data.info && data.info.rate > data.result) {
            setTrend("down");
          } else if (data.info && data.info.rate < data.result) {
            setTrend("up");
          } else {
            setTrend("steady");
          }
        } else {
          throw new Error("No data");
        }
      } catch (err) {
        setError("Live data unavailable. Using reference rate 0.0012.");
        setRate(0.0012);
      }
    };
    fetchRate();
  }, []);

  return (
    <section className="tracker-card" aria-live="polite">
      <div>
        <h3>ARS → USD Tracker</h3>
        <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
      </div>
      <div className="tracker-rate">
        <span className="rate-label">Current rate</span>
        <span className="rate-value">
          {rate !== null ? rate : "Loading..."}
        </span>
        <span className={`rate-trend trend-${trend}`} aria-label={`Trend ${trend}`}>
          {trend === "up" ? "▲" : trend === "down" ? "▼" : "▬"}
        </span>
        {error && <p className="tracker-error">{error}</p>}
      </div>
    </section>
  );
};

export default ARSUSDTracker;