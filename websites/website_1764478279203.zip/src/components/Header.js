import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { ReactComponent as LogoIcon } from "../icons/logo.svg";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header">
      <div className="container header-container">
        <div className="logo-wrapper" aria-label="Tu Progreso Hoy logo">
          <LogoIcon className="logo-icon" focusable="false" aria-hidden="true" />
          <span className="logo-text">Tu Progreso Hoy</span>
        </div>
        <button
          aria-label="Toggle navigation menu"
          className="menu-toggle"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span aria-hidden="true">☰</span>
        </button>
        <nav
          className={`main-nav ${menuOpen ? "open" : ""}`}
          aria-label="Main navigation"
        >
          <NavLink to="/" onClick={closeMenu}>
            Home
          </NavLink>
          <NavLink to="/inflation" onClick={closeMenu}>
            Inflation
          </NavLink>
          <NavLink to="/course" onClick={closeMenu}>
            Course
          </NavLink>
          <NavLink to="/resources" onClick={closeMenu}>
            Resources
          </NavLink>
          <NavLink to="/contact" onClick={closeMenu}>
            Contacto
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;