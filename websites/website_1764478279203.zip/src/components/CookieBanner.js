import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const decision = window.localStorage.getItem("tph-cookie-consent");
    if (!decision) {
      setVisible(true);
    }
  }, []);

  const acceptAll = () => {
    window.localStorage.setItem("tph-cookie-consent", "accepted");
    setVisible(false);
  };

  const rejectAll = () => {
    window.localStorage.setItem("tph-cookie-consent", "rejected");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie notice">
      <div>
        <p>
          We use cookies to enhance your learning experience and measure anonymized engagement. Puedes ajustar tus preferencias en cualquier momento.
        </p>
      </div>
      <div className="cookie-actions">
        <button className="btn-secondary" onClick={rejectAll}>
          Reject non-essential
        </button>
        <button className="btn-primary" onClick={acceptAll}>
          Accept cookies
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;