import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const CTAForm = ({ headline = "Получить бесплатный пробный урок" }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    whatsapp: "",
    consent: false,
    doubleOptIn: false,
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setSubmitting] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please add your full name.";
    if (!formData.email) newErrors.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = "Enter a valid email address.";
    if (!formData.consent)
      newErrors.consent = "Consent is required to proceed.";
    if (!formData.doubleOptIn)
      newErrors.doubleOptIn = "Please confirm the double opt-in agreement.";
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitting(true);
      setTimeout(() => {
        setSubmitting(false);
        navigate("/thank-you", {
          state: {
            name: formData.name,
            email: formData.email,
          },
        });
      }, 800);
    }
  };

  return (
    <form className="cta-form" onSubmit={handleSubmit}>
      <fieldset>
        <legend className="sr-only">{headline}</legend>
        <label htmlFor="cta-name">Full name</label>
        <input
          id="cta-name"
          name="name"
          type="text"
          autoComplete="name"
          value={formData.name}
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, name: e.target.value }))
          }
          aria-invalid={Boolean(errors.name)}
        />
        {errors.name && <p className="form-error">{errors.name}</p>}

        <label htmlFor="cta-email">Email</label>
        <input
          id="cta-email"
          name="email"
          type="email"
          autoComplete="email"
          value={formData.email}
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, email: e.target.value }))
          }
          aria-invalid={Boolean(errors.email)}
        />
        {errors.email && <p className="form-error">{errors.email}</p>}

        <label htmlFor="cta-whatsapp">WhatsApp (optional)</label>
        <input
          id="cta-whatsapp"
          name="whatsapp"
          type="tel"
          autoComplete="tel"
          value={formData.whatsapp}
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, whatsapp: e.target.value }))
          }
        />

        <div className="form-check">
          <input
            id="cta-consent"
            type="checkbox"
            checked={formData.consent}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, consent: e.target.checked }))
            }
          />
          <label htmlFor="cta-consent">
            I agree to receive course insights and understand Platforma educativa con datos esenciales, sin asesoría financiera directa.
          </label>
        </div>
        {errors.consent && <p className="form-error">{errors.consent}</p>}

        <div className="form-check">
          <input
            id="cta-doubleOptIn"
            type="checkbox"
            checked={formData.doubleOptIn}
            onChange={(e) =>
              setFormData((prev) => ({
                ...prev,
                doubleOptIn: e.target.checked,
              }))
            }
          />
          <label htmlFor="cta-doubleOptIn">
            I confirm I will complete the double opt-in by validating the confirmation email.
          </label>
        </div>
        {errors.doubleOptIn && (
          <p className="form-error">{errors.doubleOptIn}</p>
        )}
      </fieldset>

      <button className="btn-primary" type="submit" disabled={isSubmitting}>
        {isSubmitting ? "Sending..." : "Получить бесплатный пробный урок"}
      </button>
      <p className="form-caption">
        Al enviar aceptas recibir comunicaciones educativas. Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
      </p>
    </form>
  );
};

export default CTAForm;