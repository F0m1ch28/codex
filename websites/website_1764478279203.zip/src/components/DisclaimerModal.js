import React, { useEffect, useState } from "react";

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const seen = window.sessionStorage.getItem("tph-disclaimer-seen");
    if (!seen) {
      setOpen(true);
    }
  }, []);

  const close = () => {
    window.sessionStorage.setItem("tph-disclaimer-seen", "true");
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="disclaimer-overlay" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="disclaimer-modal">
        <h2 id="disclaimer-title">Aviso importante</h2>
        <p>Мы не предоставляем финансовые услуги / We do not provide financial services.</p>
        <p>
          La información se entrega con fines educativos. Información confiable que respalda elecciones responsables sobre tu dinero.
        </p>
        <button className="btn-primary" onClick={close}>
          Acknowledge
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;