import React from "react";
import CTAForm from "../components/CTAForm";

const modules = [
  {
    title: "Module 1 — Inflation literacy in Argentina",
    description: "Understand CPI components, historical anchors, and how indices impact household decisions.",
  },
  {
    title: "Module 2 — ARS→USD fundamentals",
    description: "Track official, blue, and financial rates responsibly while avoiding speculation traps.",
  },
  {
    title: "Module 3 — Responsible budgeting",
    description: "Design frameworks for essential spending, savings buffers, and prioritization with transparent data.",
  },
  {
    title: "Module 4 — Scenario planning",
    description: "Simulate volatility, stress test your goals, and communicate plans with family or teams.",
  },
  {
    title: "Module 5 — Trend monitoring toolkit",
    description: "Build dashboards, alerts, and routines to stay updated without overwhelm.",
  },
];

const audiences = [
  "Young professionals starting to manage their own budgets.",
  "Families navigating inflation volatility across Argentina.",
  "Entrepreneurs who need reliable context for decision-making.",
  "Communities seeking bilingual financial literacy resources.",
];

const CoursePage = () => {
  return (
    <div className="page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Personal Finance Starter Course</h1>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
        </div>
      </section>

      <section className="page-section">
        <div className="container">
          <h2>Syllabus overview</h2>
          <p>
            Course duration: 6 weeks with two live touchpoints per week and guided self-study between sessions. Conocimiento financiero impulsado por tendencias.
          </p>
          <div className="module-grid">
            {modules.map((module, index) => (
              <div key={index} className="module-card">
                <h3>{module.title}</h3>
                <p>{module.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="page-section">
        <div className="container audience">
          <h2>Who is it for?</h2>
          <ul>
            {audiences.map((item, idx) => (
              <li key={idx}>{item}</li>
            ))}
          </ul>
          <p>
            Pasos acertados hoy, mejor futuro mañana. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
      </section>

      <section className="page-section cta-anchor" id="course-cta">
        <div className="container">
          <h2>Получить бесплатный пробный урок</h2>
          <CTAForm headline="Получить бесплатный пробный урок" />
        </div>
      </section>
    </div>
  );
};

export default CoursePage;