import React from "react";

const TermsPage = () => {
  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Terms of Use</h1>
          <p>
            Please read these terms carefully. By accessing Tu Progreso Hoy you agree to responsible usage of educational materials.
          </p>
        </div>
      </section>
      <section className="page-section">
        <div className="container narrow">
          <h2>1. Purpose</h2>
          <p>
            The platform provides educational content. Plataforma educativa con datos esenciales, sin asesoría financiera directa. Мы не предоставляем финансовые услуги.
          </p>
          <h2>2. User responsibilities</h2>
          <p>
            Users must verify any financial decisions with qualified professionals. Tu Progreso Hoy does not guarantee outcomes and avoids speculative promises.
          </p>
          <h2>3. Intellectual property</h2>
          <p>
            Content, charts, and materials are owned by Tu Progreso Hoy. You may share excerpts with attribution for educational purposes.
          </p>
          <h2>4. Account & communications</h2>
          <p>
            You agree to provide accurate information and maintain the confidentiality of any login credentials. Double opt-in is required for email subscriptions.
          </p>
          <h2>5. Limitation of liability</h2>
          <p>
            We are not liable for losses arising from reliance on the educational material. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
          <h2>6. Governing law</h2>
          <p>
            These terms are governed by the laws of Argentina. Disputes will be handled in the courts of Buenos Aires.
          </p>
          <h2>7. Contact</h2>
          <p>
            For questions about these terms contact hola@tuprogresohoy.com.
          </p>
        </div>
      </section>
    </div>
  );
};

export default TermsPage;