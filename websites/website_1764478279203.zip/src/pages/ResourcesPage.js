import React from "react";

const resourcesEn = [
  {
    title: "Argentina Inflation Cheat Sheet",
    description: "Weekly summary of CPI categories and their impact on common expenses.",
    link: "#",
  },
  {
    title: "Exchange Rate Monitoring Basics",
    description: "Best practices for responsible ARS→USD tracking without speculative claims.",
    link: "#",
  },
  {
    title: "Building a Resilient Budget",
    description: "Step-by-step guide for establishing emergency buffers and communicating goals.",
    link: "#",
  },
];

const resourcesEs = [
  {
    title: "Glosario de inflación argentina",
    description: "Términos clave explicados en lenguaje sencillo para toda la familia.",
    link: "#",
  },
  {
    title: "Seguimiento responsable del tipo de cambio",
    description: "Cómo interpretar las brechas entre tasas oficiales, financieras y paralelas.",
    link: "#",
  },
  {
    title: "Plantilla de presupuesto mensual",
    description: "Formato editable para planificar gastos esenciales y metas realistas.",
    link: "#",
  },
];

const ResourcesPage = () => {
  return (
    <div className="page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Resources / Recursos</h1>
          <p>
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Bilingual materials to support decision-making and shared learning.
          </p>
        </div>
      </section>

      <section className="page-section">
        <div className="container resources-grid">
          <div>
            <h2>English Resources</h2>
            <ul className="resource-list">
              {resourcesEn.map((res, idx) => (
                <li key={idx}>
                  <h3>{res.title}</h3>
                  <p>{res.description}</p>
                  <a className="inline-link" href={res.link}>
                    Download
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2>Recursos en Español</h2>
            <ul className="resource-list">
              {resourcesEs.map((res, idx) => (
                <li key={idx}>
                  <h3>{res.title}</h3>
                  <p>{res.description}</p>
                  <a className="inline-link" href={res.link}>
                    Descargar
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ResourcesPage;