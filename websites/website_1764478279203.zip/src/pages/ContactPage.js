import React, { useState } from "react";

const ContactPage = () => {
  const [status, setStatus] = useState("idle");

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus("submitting");
    setTimeout(() => {
      setStatus("submitted");
    }, 900);
  };

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Contact / Contacto</h1>
          <p>
            Estamos en Buenos Aires para acompañarte con información clara. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
        </div>
      </section>

      <section className="page-section">
        <div className="container contact-grid">
          <div className="map-wrapper" aria-label="Map of Buenos Aires">
            <iframe
              title="Buenos Aires Map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.776230885332!2d-58.38159292373147!3d-34.60806017295508!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccac887bf71ab%3A0x9ce0dfafad9dca57!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
          <div>
            <h2>Send us a message</h2>
            <form className="contact-form" onSubmit={handleSubmit}>
              <label htmlFor="contact-name">Full name</label>
              <input id="contact-name" name="name" required aria-required="true" />
              <label htmlFor="contact-email">Email</label>
              <input id="contact-email" name="email" type="email" required aria-required="true" />
              <label htmlFor="contact-message">Message</label>
              <textarea id="contact-message" name="message" rows="4" required aria-required="true"></textarea>
              <button className="btn-primary" type="submit" disabled={status === "submitting"}>
                {status === "submitting" ? "Sending..." : "Submit"}
              </button>
            </form>
            {status === "submitted" && (
              <p className="form-success">
                Thank you for reaching out. We will reply with educational information only. Мы не предоставляем финансовые услуги.
              </p>
            )}
            <div className="contact-info">
              <p><strong>Address:</strong> Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
              <p><strong>Phone:</strong> <a href="tel:+541155551234">+54 11 5555-1234</a></p>
              <p><strong>Email:</strong> <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a></p>
              <p><strong>Social:</strong> LinkedIn · X · Instagram</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;