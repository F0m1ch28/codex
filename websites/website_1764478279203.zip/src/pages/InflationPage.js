import React from "react";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip, AreaChart, Area } from "recharts";

const cpiData = [
  { month: "Jan", cpi: 98, fx: 184 },
  { month: "Feb", cpi: 104, fx: 191 },
  { month: "Mar", cpi: 111, fx: 203 },
  { month: "Apr", cpi: 120, fx: 211 },
  { month: "May", cpi: 132, fx: 230 },
  { month: "Jun", cpi: 145, fx: 248 },
];

const purchasingPower = [
  { quarter: "Q1", peso: 100, basket: 82 },
  { quarter: "Q2", peso: 95, basket: 78 },
  { quarter: "Q3", peso: 88, basket: 73 },
  { quarter: "Q4", peso: 81, basket: 69 },
];

const faqItems = [
  {
    question: "How do you source CPI data?",
    answer: "We reference INDEC releases and audited datasets. Datos verificados para planificar tu presupuesto.",
  },
  {
    question: "Do you provide currency forecasts?",
    answer: "We provide scenario ranges based on historical variance. Información confiable que respalda elecciones responsables sobre tu dinero.",
  },
  {
    question: "Is this financial advice?",
    answer: "No. Plataforma educativa con datos esenciales, sin asesoría financiera directa. Мы не предоставляем финансовые услуги.",
  },
  {
    question: "How often is ARS→USD refreshed?",
    answer: "Tracker values update daily with an API feed and manual validation on business days.",
  },
];

const InflationPage = () => {
  return (
    <div className="page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Inflation Methodology</h1>
          <p>
            Decisiones responsables, objetivos nítidos. Our approach combines official CPI reports, market consensus, FX references, and sensitivity testing.
          </p>
        </div>
      </section>

      <section className="page-section">
        <div className="container">
          <h2>Methodology pillars</h2>
          <ol className="method-list">
            <li>
              <strong>Data validation:</strong> Cross-verification with INDEC, private consultancies, and academic sources to ensure consistency.
            </li>
            <li>
              <strong>Contextual drivers:</strong> Linking CPI components with ARS depreciation, wage growth, and commodity trends.
            </li>
            <li>
              <strong>Scenario modeling:</strong> Probabilistic ranges for 3, 6, and 12 months to guide responsible planning decisions.
            </li>
            <li>
              <strong>Educational framing:</strong> Conocimiento financiero impulsado por tendencias, oriented to build criterio financiero.
            </li>
          </ol>
        </div>
      </section>

      <section className="page-section graphs">
        <div className="container">
          <h2>CPI vs FX context</h2>
          <p>
            Visualize the relationship between consumer price increases and ARS depreciation. Pasos acertados hoy, mejor futuro mañana.
          </p>
          <div className="chart-card" role="img" aria-label="Line chart comparing CPI and FX">
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={cpiData}>
                <CartesianGrid stroke="#E2E8F0" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="cpi" stroke="#2563EB" strokeWidth={3} name="CPI index" />
                <Line type="monotone" dataKey="fx" stroke="#1F3A6F" strokeWidth={3} name="FX ARS/USD" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <h2>Purchasing power scenarios</h2>
          <div className="chart-card" role="img" aria-label="Area chart showing purchasing power scenarios">
            <ResponsiveContainer width="100%" height={320}>
              <AreaChart data={purchasingPower}>
                <defs>
                  <linearGradient id="colorPeso" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorBasket" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1F3A6F" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#1F3A6F" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#E2E8F0" />
                <XAxis dataKey="quarter" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="peso" stroke="#2563EB" fillOpacity={1} fill="url(#colorPeso)" name="ARS power" />
                <Area type="monotone" dataKey="basket" stroke="#1F3A6F" fillOpacity={1} fill="url(#colorBasket)" name="Essential basket" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      <section className="page-section faq">
        <div className="container narrow">
          <h2>FAQ</h2>
          <dl>
            {faqItems.map((item, idx) => (
              <div key={idx} className="faq-item">
                <dt>{item.question}</dt>
                <dd>{item.answer}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>
    </div>
  );
};

export default InflationPage;