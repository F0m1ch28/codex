import React from "react";

const CookiesPage = () => {
  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Cookies Notice</h1>
          <p>
            We use minimal cookies to improve usability and gather aggregated analytics. Decisiones responsables, objetivos nítidos.
          </p>
        </div>
      </section>
      <section className="page-section">
        <div className="container narrow">
          <h2>Essential cookies</h2>
          <p>
            Required for site security and session management. These cannot be disabled as they ensure the platform operates correctly.
          </p>
          <h2>Analytics cookies</h2>
          <p>
            Used to track anonymized usage metrics. Only activated when you provide consent through the cookie banner.
          </p>
          <h2>Managing preferences</h2>
          <p>
            Puedes actualizar tu consentimiento borrando las cookies de tu navegador or revisiting our banner. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
          <h2>Contact</h2>
          <p>
            For questions email hola@tuprogresohoy.com. Мы не предоставляем финансовые услуги.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiesPage;