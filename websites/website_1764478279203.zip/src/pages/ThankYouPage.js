import React from "react";
import { useLocation, Link } from "react-router-dom";

const ThankYouPage = () => {
  const location = useLocation();
  const name = location.state?.name || "New learner";

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Gracias, {name}!</h1>
          <p>
            Step 1 complete: registramos tu solicitud. Step 2: revisa tu email y confirma la suscripción (double opt-in). Datos verificados para planificar tu presupuesto.
          </p>
          <p>
            Conocimiento financiero impulsado por tendencias. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
          <Link className="btn-primary" to="/">
            Return to Home
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ThankYouPage;