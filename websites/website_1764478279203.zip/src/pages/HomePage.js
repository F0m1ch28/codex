import React from "react";
import { Link } from "react-router-dom";
import ARSUSDTracker from "../components/ARSUSDTracker";
import CTAForm from "../components/CTAForm";

const HomePage = () => {
  return (
    <div className="home-page">
      <section className="hero" aria-label="Tu Progreso Hoy hero">
        <div className="container hero-content">
          <div className="hero-text">
            <h1>Datos verificados para planificar tu presupuesto.</h1>
            <p className="hero-subtitle">
              Conocimiento financiero impulsado por tendencias. Pasos acertados hoy, mejor futuro mañana.
            </p>
            <p>
              Análisis transparentes y datos de mercado para decidir con seguridad. Información confiable que respalda elecciones responsables sobre tu dinero.
            </p>
            <div className="hero-actions">
              <a className="btn-primary" href="#cta-form">
                Получить бесплатный пробный урок
              </a>
              <Link className="btn-secondary" to="/inflation">
                Explore AR inflation data
              </Link>
            </div>
          </div>
          <div className="hero-insights">
            <div className="insight-card">
              <h3>Key promises / Claves</h3>
              <ul>
                <li>Decisiones responsables, objetivos nítidos.</li>
                <li>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</li>
                <li>De la información al aprendizaje: fortalece tu criterio financiero paso a paso.</li>
              </ul>
            </div>
            <div className="insight-card">
              <h3>Course snapshot</h3>
              <p>
                Platform modules cover inflation literacy, ARS→USD planning,
                and resilient budgeting scenarios for Argentina.
              </p>
              <Link to="/course" className="inline-link">
                View syllabus
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        <ARSUSDTracker />
      </div>

      <section className="insights-section">
        <div className="container insights-grid">
          <article className="insight-item">
            <h3>Macro insights</h3>
            <p>
              Our Argentina-focused research connects CPI, wage index, and FX trends, so you can contextualize daily decisions with reliable indicators.
            </p>
          </article>
          <article className="insight-item">
            <h3>Budget scenarios</h3>
            <p>
              Evaluate ARS volatility scenarios linked to essential expenses like housing, mobility, education, and healthcare in Buenos Aires and beyond.
            </p>
          </article>
          <article className="insight-item">
            <h3>Learning outcomes</h3>
            <p>
              Participants learn how to monitor inflation drivers, simulate purchasing power shifts, and set responsible personal objectives.
            </p>
          </article>
        </div>
      </section>

      <section className="course-overview">
        <div className="container course-grid">
          <div>
            <h2>Course overview</h2>
            <p>
              Conocimiento financiero impulsado por tendencias, adaptable a entornos cambiantes. Módulos prácticos diseñados para recién iniciados y perfiles intermedios que desean claridad.
            </p>
            <ul className="course-points">
              <li>Weekly live sessions with bilingual support (EN/ES).</li>
              <li>Access to AR-specific dashboards and downloadable trackers.</li>
              <li>Responsible decision frameworks without prescriptive advice.</li>
            </ul>
            <Link className="btn-secondary" to="/course">
              Read details
            </Link>
          </div>
          <div className="testimonial-block" aria-label="Testimonials">
            <h3>Testimonials</h3>
            <blockquote>
              “The combination of data transparency and bilingual guidance helps me stay ahead of inflation headlines.” — Martina, CABA
            </blockquote>
            <blockquote>
              “CPI context plus budgeting workshops gave our family a shared language for financial priorities.” — Diego, Córdoba
            </blockquote>
            <blockquote>
              “Useful ARS→USD trend trackers; they never promise outcomes but teach us to interpret signals.” — Laura, Mendoza
            </blockquote>
          </div>
        </div>
      </section>

      <section className="cta-section" id="cta-form">
        <div className="container">
          <h2>Ready to translate data into confident actions?</h2>
          <p>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa. Recibe un probador gratuito y confirma tu registro por correo.
          </p>
          <CTAForm />
        </div>
      </section>
    </div>
  );
};

export default HomePage;