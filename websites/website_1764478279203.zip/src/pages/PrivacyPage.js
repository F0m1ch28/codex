import React from "react";

const PrivacyPage = () => {
  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Privacy Policy</h1>
          <p>
            We protect your personal data according to Argentinian regulations (Ley 25.326) and GDPR principles for EU visitors.
          </p>
        </div>
      </section>
      <section className="page-section">
        <div className="container narrow">
          <h2>1. Data collection</h2>
          <p>
            We collect identification and contact details provided voluntarily via forms: name, email, teléfono/WhatsApp. Datos verificados para planificar tu presupuesto.
          </p>
          <h2>2. Purpose of processing</h2>
          <p>
            We use your information to deliver educational content, double opt-in confirmations, and updates about the course. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
          <h2>3. Legal basis</h2>
          <p>
            Consent provided through explicit opt-in fields. Users can withdraw consent at any time by contacting hola@tuprogresohoy.com.
          </p>
          <h2>4. Storage & security</h2>
          <p>
            Data is stored securely on cloud services located within compliant jurisdictions. Access is limited to authorized staff for educational communications.
          </p>
          <h2>5. Data subject rights</h2>
          <p>
            You may request access, rectification, or deletion of your data. Residents of Argentina can file claims with the Agencia de Acceso a la Información Pública.
          </p>
          <h2>6. Cookies</h2>
          <p>
            See our Cookies Notice for details on analytics and preferences. We respect your cookie opt-in choices and do not use invasive tracking.
          </p>
          <h2>7. Updates</h2>
          <p>
            We will notify subscribers of significant changes. Continued use signifies acceptance of the updated policy.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPage;