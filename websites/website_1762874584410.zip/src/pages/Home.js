import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";
import { NavLink } from "react-router-dom";

const statsData = [
  { label: "Signale täglich", target: 1800 },
  { label: "Datenquellen angebunden", target: 64 },
  { label: "Median Latenz (Minuten)", target: 6 },
  { label: "Modellvertrauen (%)", target: 94 }
];

const featureCards = [
  {
    title: "Forecasting",
    description:
      "Zeitreihen-Modelle, ensembles und probabilistische Projektionen für Nachfrage, Preisindizes und Volumen.",
    icon: "📈"
  },
  {
    title: "Signale",
    description:
      "Kontextualisierte Marktindikatoren mit Schwellenwerten, Confidence Scores und Alert-Orchestrierung.",
    icon: "🔔"
  },
  {
    title: "Dashboards",
    description:
      "Interaktive Visualisierungspakete mit Drill-Down, Custom KPIs und kollaborativen Anmerkungen.",
    icon: "📊"
  },
  {
    title: "API",
    description:
      "Robuste REST & Streaming APIs mit SLA, SDKs und Webhooks zur Integration in Ihre Datenplattform.",
    icon: "🧩"
  }
];

const processSteps = [
  {
    title: "Daten anbinden",
    description:
      "Verknüpfen Sie Data Warehouses, Streams und externe Quellen mit wenigen Klicks über sichere Konnektoren."
  },
  {
    title: "Modelle trainieren",
    description:
      "Wählen Sie kuratierte Modell-Blueprints oder passen Sie Hyperparameter mit unserem Expertenmodus an."
  },
  {
    title: "Signale ausspielen",
    description:
      "Steuern Sie Alerts in Tools Ihrer Teams, triggern Sie Workflows oder liefern Sie Daten an BI-Systeme."
  },
  {
    title: "Überwachen",
    description:
      "Nachvollziehbare Metriken, Stability Scores und automatische Drift-Erkennung halten Modelle im Takt."
  }
];

const uspItems = [
  {
    title: "DSGVO & Sicherheit",
    description:
      "ISO-konforme Prozesse, Verschlüsselung in allen Schichten und datenlokale Cluster in Frankfurt am Main."
  },
  {
    title: "Nahtlose Integrationen",
    description:
      "Native Konnektoren für Snowflake, BigQuery, Databricks, SAP Datasphere sowie REST, MQTT und Kafka."
  },
  {
    title: "Transparente Modelle",
    description:
      "Explainability Layer, Feature Attribution und Audit-Trails unterstützen Compliance und Vertrauen."
  }
];

const testimonials = [
  {
    quote:
      "Tredifynix liefert unseren Category-Managern verlässliche Frühindikatoren. Die Signale treffen täglich im ERP ein und reduzieren manuelle Abstimmungen erheblich.",
    name: "Mara Lichtenberg",
    role: "Head of Planning, Nordhandel",
    kpi: "Abdeckung +32%"
  },
  {
    quote:
      "Die API-Anbindung in unser Energiemonitoring war in zwei Wochen produktiv. Besonders überzeugt uns die Modellstabilität und die transparente Dokumentation.",
    name: "Janus Engel",
    role: "Analytics Lead, Venato Energy",
    kpi: "Modellstabilität 98%"
  },
  {
    quote:
      "Dashboards und Alerts laufen bei uns direkt ins Collaboration-Tool. Teams können Entwicklungen sofort kommentieren und Maßnahmen anstoßen.",
    name: "Lina Rahn",
    role: "Leiterin Business Intelligence, MoveLog",
    kpi: "Latenz < 10 Min"
  }
];

const teamMembers = [
  {
    name: "Dr. Elisa Krüger",
    role: "Chief Data Scientist",
    focus: "Zeitreihenforschung & Modellvalidierung",
    image: "https://picsum.photos/400/400?random=3",
    alt: "Porträt von Dr. Elisa Krüger"
  },
  {
    name: "Jonas Fährmann",
    role: "Director Product",
    focus: "Signal Experience & Marktintegration",
    image: "https://picsum.photos/400/400?random=31",
    alt: "Porträt von Jonas Fährmann"
  },
  {
    name: "Darya Holm",
    role: "Security & Compliance Lead",
    focus: "DSGVO Prozesse & Audit Steuerung",
    image: "https://picsum.photos/400/400?random=32",
    alt: "Porträt von Darya Holm"
  }
];

const projects = [
  {
    title: "Absatzprognosen für FMCG Retail",
    category: "E-Commerce",
    description:
      "Demand Sensing für 450 Produktlinien mit kombinierten Point-of-Sale-Daten und Wettersignalen.",
    image: "https://picsum.photos/1200/800?random=4",
    alt: "Dashboard mit Nachfrageprognose im Handel"
  },
  {
    title: "Intraday Volatilitätsradar",
    category: "Energie",
    description:
      "Stromnetz-Balancing Signale mit <7 Minuten Latenz und automatisierten Eskalationen.",
    image: "https://picsum.photos/1200/800?random=41",
    alt: "Zeitreihenanalyse für Energiemärkte"
  },
  {
    title: "Content Engagement Forecast",
    category: "Medien",
    description:
      "Proaktive Content-Planung basierend auf Publish-Signalen und Konsumverhalten in Echtzeit.",
    image: "https://picsum.photos/1200/800?random=42",
    alt: "Medienanalyse Dashboard"
  }
];

const faqItems = [
  {
    question: "Welche Datenquellen lassen sich anbinden?",
    answer:
      "Unterstützt werden relationale Datenbanken, Data Warehouses, Data Lakes, Event-Streams sowie Drittanbieter-APIs. Standardkonnektoren existieren für Snowflake, BigQuery, Azure Synapse, SAP Datasphere, Kafka, MQTT und REST."
  },
  {
    question: "Wie erfolgt die Modellüberwachung?",
    answer:
      "Modelle erhalten automatisierte Drift-Checks, Performance-Alerts und werden mit Benchmarks verglichen. Alle Trigger sind konfigurierbar und via Dashboard oder API abrufbar."
  },
  {
    question: "Wie wird Sicherheit gewährleistet?",
    answer:
      "Daten werden in deutschen Rechenzentren verarbeitet. End-to-end Verschlüsselung, rollenbasierte Zugriffe, Audit-Logs und regelmäßige Penetrationstests sichern Ihre Umgebung."
  },
  {
    question: "Wie kann ich Testläufe starten?",
    answer:
      "Kontaktieren Sie unser Team für eine kuratierte Evaluierungsphase. Wir begleiten Sie mit einem Solution Architect und definieren gemeinsam KPIs, Datenquellen und Integrationspfade."
  }
];

const blogPosts = [
  {
    title: "Zeitreihen-Features für deutsche Marktdaten priorisieren",
    date: "12. März 2024",
    description:
      "Wie wir Feature Stores für volatilere Marktindikatoren strukturieren, um Forecasting-Modelle zu stabilisieren.",
    link: "/ressourcen"
  },
  {
    title: "Explainability in regulierten Branchen operationalisieren",
    date: "7. Februar 2024",
    description:
      "Transparente Modelle unterstützen Compliance-Anforderungen und stärken das Vertrauen in automatisierte Signale.",
    link: "/ressourcen"
  },
  {
    title: "Vergleich: API-Strategien für Echtzeit-Signale",
    date: "22. Januar 2024",
    description:
      "Welche Schnittstellen-Architektur für Ihre Teams sinnvoll ist und wie sie skalierbar bleibt.",
    link: "/ressourcen"
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [filter, setFilter] = React.useState("Alle");
  const [animatedStats, setAnimatedStats] = React.useState(
    statsData.map(() => 0)
  );

  React.useEffect(() => {
    const intervalId = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(intervalId);
  }, []);

  React.useEffect(() => {
    const durations = statsData.map((stat) => (stat.target > 100 ? 1800 : 900));
    const start = Date.now();
    const animate = () => {
      const current = Date.now() - start;
      setAnimatedStats(
        statsData.map((stat, index) =>
          Math.min(
            stat.target,
            Math.floor((current / durations[index]) * stat.target)
          )
        )
      );
      if (current < Math.max(...durations)) {
        requestAnimationFrame(animate);
      }
    };
    animate();
  }, []);

  const filteredProjects =
    filter === "Alle"
      ? projects
      : projects.filter((project) => project.category === filter);

  return (
    <>
      <Helmet>
        <title>Tredifynix | Markttrends früh erkennen in Deutschland</title>
        <meta
          name="description"
          content="Tredifynix kombiniert Zeitreihen-Modelle, Signale und Dashboards für Markttrends in Deutschland. Prognosen erstellen, Alerts steuern und Compliance absichern."
        />
        <script type="application/ld+json">{JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "Tredifynix",
          "url": "https://www.tredifynix.de",
          "logo": "https://www.tredifynix.de/logo.png",
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+49 40 98765432",
            "contactType": "customer support",
            "availableLanguage": "German"
          },
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Neuer Wall 50",
            "addressLocality": "Hamburg",
            "postalCode": "20354",
            "addressCountry": "DE"
          }
        })}</script>
      </Helmet>
      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className={styles.heroContent}>
          <p className={styles.heroPill}>Marktsignale für Deutschland</p>
          <h1 id="hero-heading">Erkenne Markttrends frühzeitig</h1>
          <p className={styles.heroSub}>
            Tredifynix verbindet hochwertige Datenquellen mit präzisen Vorhersagemodellen und
            ausgereiften Signalen. Teams erhalten nachvollziehbare Dashboards und APIs, um Entscheidungen
            kontinuierlich zu beschleunigen.
          </p>
          <div className={styles.heroActions}>
            <NavLink to="/kontakt" className={styles.primaryBtn}>
              Jetzt starten
            </NavLink>
            <NavLink to="/funktionen" className={styles.secondaryBtn}>
              Funktionen ansehen
            </NavLink>
          </div>
          <div className={styles.heroStats} aria-label="Kennzahlen">
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.heroStat}>
                <span className={styles.statValue}>
                  {animatedStats[index]}
                  {stat.label.includes("%") ? "%" : ""}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroMedia} role="img" aria-label="Visualisierte Markttrends">
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Analytisches Dashboard mit Zeitreihen und Trendlinien"
            loading="lazy"
          />
          <div className={styles.mediaOverlay}>
            <div>
              <span className={styles.overlayLabel}>Forecast Confidence</span>
              <span className={styles.overlayValue}>94%</span>
            </div>
            <div>
              <span className={styles.overlayLabel}>Signal Stabilität</span>
              <span className={styles.overlayValue}>98,6</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.intro} aria-labelledby="intro-heading">
        <div className={styles.introContent}>
          <h2 id="intro-heading">Wer wir sind</h2>
          <p>
            Tredifynix ist eine Forschungs- und Engineering-orientierte Plattform mit Sitz in Hamburg.
            Unser Team aus Data Scientists, Software-Engineers und Branchenexperten entwickelt belastbare
            Markttrendmodelle für deutsche Unternehmen. Wir verbinden wissenschaftliche Methoden mit
            operativer Umsetzbarkeit.
          </p>
          <p>
            Mit Tredifynix orchestrieren Sie Daten, Modelle und Signale in einem zusammenhängenden
            Workflow. Wir kümmern uns um Monitoring, Modellpflege, Audit und die transparente Ausspielung
            in bestehende Systeme.
          </p>
        </div>
      </section>

      <section className={styles.features} aria-labelledby="features-heading">
        <div className={styles.sectionHeader}>
          <h2 id="features-heading">Funktionen im Überblick</h2>
          <p>
            Von Forecasting über Signale bis zu Integrationen: Tredifynix liefert belastbare Werkzeuge, die
            Teams in allen Phasen der Entscheidungsfindung unterstützen.
          </p>
        </div>
        <div className={styles.featureGrid}>
          {featureCards.map((feature) => (
            <article key={feature.title} className={styles.featureCard}>
              <span className={styles.featureIcon} aria-hidden="true">
                {feature.icon}
              </span>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
              <NavLink to="/funktionen" className={styles.featureLink}>
                Technische Doku öffnen →
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-heading">
        <div className={styles.sectionHeader}>
          <h2 id="process-heading">So funktioniert&apos;s</h2>
          <p>
            Durchgängige Workflows – von der Datenaufnahme bis zur kontinuierlichen Überwachung. Die Schritte
            werden von Tredifynix orchestriert und bleiben transparent.
          </p>
        </div>
        <ol className={styles.processList}>
          {processSteps.map((step, index) => (
            <li key={step.title} className={styles.processStep}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className={styles.usp} aria-labelledby="usp-heading">
        <div className={styles.sectionHeader}>
          <h2 id="usp-heading">Warum Tredifynix</h2>
          <p>
            Wir fokussieren uns auf Sicherheit, messbare Präzision und Integrationen in Ihre bestehende
            Architektur.
          </p>
        </div>
        <div className={styles.uspGrid}>
          {uspItems.map((usp) => (
            <article key={usp.title} className={styles.uspItem}>
              <h3>{usp.title}</h3>
              <p>{usp.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.caseStudies} aria-labelledby="case-heading">
        <div className={styles.sectionHeader}>
          <h2 id="case-heading">Erfolgsgeschichten</h2>
          <p>
            Kennzahlen, die das Zusammenspiel von Forecasting, Signalen und Dashboards in realen
            Projekten zeigen.
          </p>
        </div>
        <div className={styles.caseGrid}>
          {testimonials.map((testimonial, index) => (
            <article key={testimonial.name} className={styles.caseCard}>
              <header>
                <span className={styles.caseIndex}>Case {index + 1}</span>
                <span className={styles.caseKpi}>{testimonial.kpi}</span>
              </header>
              <p className={styles.caseQuote}>&ldquo;{testimonial.quote}&rdquo;</p>
              <footer>
                <strong>{testimonial.name}</strong>
                <span>{testimonial.role}</span>
              </footer>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonial-heading">
        <div className={styles.sectionHeader}>
          <h2 id="testimonial-heading">Stimmen aus der Praxis</h2>
          <p>
            Rotierende Einblicke unserer Kundinnen und Kunden. Wechsel alle sechs Sekunden oder wählen Sie
            selbst aus.
          </p>
        </div>
        <div className={styles.testimonialWrapper}>
          <div className={styles.testimonialContent}>
            <p className={styles.testimonialQuote}>
              &ldquo;{testimonials[activeTestimonial].quote}&rdquo;
            </p>
            <div className={styles.testimonialMeta}>
              <div>
                <span className={styles.testimonialName}>
                  {testimonials[activeTestimonial].name}
                </span>
                <span className={styles.testimonialRole}>
                  {testimonials[activeTestimonial].role}
                </span>
              </div>
              <span className={styles.testimonialKpi}>
                {testimonials[activeTestimonial].kpi}
              </span>
            </div>
          </div>
          <div className={styles.testimonialControls}>
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                aria-label={`Testimonial ${idx + 1}`}
                className={
                  idx === activeTestimonial
                    ? `${styles.dot} ${styles.dotActive}`
                    : styles.dot
                }
                onClick={() => setActiveTestimonial(idx)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <div className={styles.sectionHeader}>
          <h2 id="team-heading">Unser Kernteam</h2>
          <p>
            Interdisziplinär, forschungsnah und mit starkem Branchenfokus. Lernen Sie die Menschen kennen,
            die Tredifynix formen.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <figure className={styles.teamFigure}>
                <img src={member.image} alt={member.alt} loading="lazy" />
              </figure>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.role}</p>
                <p className={styles.teamFocus}>{member.focus}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="project-heading">
        <div className={styles.sectionHeader}>
          <h2 id="project-heading">Projektbeispiele</h2>
          <p>
            Filterbare Einblicke in realisierte Lösungen. Wählen Sie die Kategorie, die Ihrem Einsatzszenario
            entspricht.
          </p>
        </div>
        <div className={styles.filterControls} role="tablist" aria-label="Projektfilter">
          {["Alle", "E-Commerce", "Energie", "Medien"].map((category) => (
            <button
              key={category}
              role="tab"
              aria-selected={filter === category}
              className={
                filter === category
                  ? `${styles.filterButton} ${styles.filterActive}`
                  : styles.filterButton
              }
              onClick={() => setFilter(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <figure>
                <img src={project.image} alt={project.alt} loading="lazy" />
              </figure>
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <NavLink to="/loesungen" className={styles.projectLink}>
                  Mehr zu Branchenlösungen →
                </NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-heading">
        <div className={styles.sectionHeader}>
          <h2 id="faq-heading">FAQ</h2>
          <p>
            Antworten auf häufige Fragen rund um Datenanbindung, Modelle, Sicherheit und Evaluation.
          </p>
        </div>
        <div className={styles.accordion} role="tablist">
          {faqItems.map((item, index) => {
            const [open, setOpen] = React.useState(index === 0);
            return (
              <details
                key={item.question}
                open={open}
                onClick={(event) => {
                  event.preventDefault();
                  setOpen((prev) => !prev);
                }}
                className={styles.accordionItem}
              >
                <summary
                  className={styles.accordionSummary}
                  role="button"
                  aria-expanded={open}
                >
                  {item.question}
                  <span className={styles.accordionIcon}>{open ? "−" : "+"}</span>
                </summary>
                <div className={styles.accordionContent}>
                  <p>{item.answer}</p>
                </div>
              </details>
            );
          })}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-heading">
        <div className={styles.sectionHeader}>
          <h2 id="blog-heading">Aktuelle Insights</h2>
          <p>
            Forschungsupdates, Methoden und Erfahrungen aus laufenden Projekten. Bleiben Sie auf dem Laufenden.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogMeta}>{post.date}</div>
              <h3>{post.title}</h3>
              <p>{post.description}</p>
              <NavLink to={post.link} className={styles.blogLink}>
                Beitrag lesen →
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-heading">
        <div className={styles.ctaContent}>
          <h2 id="cta-heading">Signale in Ihren Teams nutzbar machen</h2>
          <p>
            Vereinbaren Sie eine Demo mit unserem Solution Team. Wir zeigen Ihnen, wie Tredifynix Signale,
            Forecasts und Dashboards in Ihre Prozesse einbettet.
          </p>
          <div className={styles.ctaActions}>
            <NavLink to="/kontakt" className={styles.primaryBtn}>
              Demo anfragen
            </NavLink>
            <NavLink to="/integrationen" className={styles.secondaryBtn}>
              Integrationen ansehen
            </NavLink>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;