import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTop";
import Home from "./pages/Home";
import UeberUns from "./pages/UeberUns";
import Funktionen from "./pages/Funktionen";
import Loesungen from "./pages/Loesungen";
import Integrationen from "./pages/Integrationen";
import Ressourcen from "./pages/Ressourcen";
import Sicherheit from "./pages/Sicherheit";
import Plaene from "./pages/Plaene";
import Kontakt from "./pages/Kontakt";
import Nutzungsbedingungen from "./pages/Nutzungsbedingungen";
import Datenschutz from "./pages/Datenschutz";
import CookieRichtlinie from "./pages/CookieRichtlinie";
import styles from "./App.module.css";

const App = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [location.pathname]);

  return (
    <div className={styles.app}>
      <a className={styles.skipLink} href="#hauptinhalt">
        Zum Hauptinhalt springen
      </a>
      <Header />
      <main id="hauptinhalt" className={styles.main}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<UeberUns />} />
          <Route path="/funktionen" element={<Funktionen />} />
          <Route path="/loesungen" element={<Loesungen />} />
          <Route path="/integrationen" element={<Integrationen />} />
          <Route path="/ressourcen" element={<Ressourcen />} />
          <Route path="/sicherheit" element={<Sicherheit />} />
          <Route path="/plaene" element={<Plaene />} />
          <Route path="/kontakt" element={<Kontakt />} />
          <Route path="/nutzungsbedingungen" element={<Nutzungsbedingungen />} />
          <Route path="/datenschutz" element={<Datenschutz />} />
          <Route path="/cookie-richtlinie" element={<CookieRichtlinie />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;