import React from "react";
import styles from "./Footer.module.css";
import { NavLink } from "react-router-dom";

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.container}>
      <div className={styles.brand}>
        <div className={styles.logoGroup}>
          <span className={styles.logoMark}>T</span>
          <span className={styles.logoText}>Tredifynix</span>
        </div>
        <p className={styles.description}>
          Präzise Markttrend-Prognosen für datengetriebene Teams in Deutschland.
          Wir verbinden hochwertige Datenquellen mit belastbaren Modellen und
          machen Signale nachvollziehbar.
        </p>
      </div>
      <div className={styles.columns}>
        <div className={styles.column}>
          <h3 className={styles.heading}>Navigation</h3>
          <ul>
            <li><NavLink to="/ueber-uns">Über uns</NavLink></li>
            <li><NavLink to="/funktionen">Funktionen</NavLink></li>
            <li><NavLink to="/loesungen">Lösungen</NavLink></li>
            <li><NavLink to="/integrationen">Integrationen</NavLink></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Ressourcen</h3>
          <ul>
            <li><NavLink to="/ressourcen">Insights & Guides</NavLink></li>
            <li><NavLink to="/sicherheit">Sicherheit</NavLink></li>
            <li><NavLink to="/plaene">Pläne</NavLink></li>
            <li><NavLink to="/kontakt">Demo anfragen</NavLink></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Rechtliches</h3>
          <ul>
            <li><NavLink to="/nutzungsbedingungen">Nutzungsbedingungen</NavLink></li>
            <li><NavLink to="/datenschutz">Datenschutz</NavLink></li>
            <li><NavLink to="/cookie-richtlinie">Cookie-Richtlinie</NavLink></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Kontakt</h3>
          <address className={styles.address}>
            Neuer Wall 50<br />
            20354 Hamburg, Deutschland<br />
            <a href="tel:+494098765432">+49 40 98765432</a><br />
            <span>E-Mail: [wird nachgereicht]</span>
          </address>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Tredifynix. Alle Rechte vorbehalten.</p>
    </div>
  </footer>
);

export default Footer;