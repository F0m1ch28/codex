import React from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const storedConsent = window.localStorage.getItem("tredifynix-cookie-consent");
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (consent) => {
    window.localStorage.setItem("tredifynix-cookie-consent", consent);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h2>Cookies & Telemetrie</h2>
        <p>
          Wir nutzen Cookies, um Ihre Erfahrung zu verbessern und aggregierte Nutzungsstatistiken zu analysieren.
          Sie können jederzeit Ihre Entscheidung im Bereich „Cookie-Richtlinie“ anpassen.
        </p>
      </div>
      <div className={styles.actions}>
        <button onClick={() => handleConsent("declined")} className={styles.secondary}>
          Ablehnen
        </button>
        <button onClick={() => handleConsent("accepted")} className={styles.primary}>
          Akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;