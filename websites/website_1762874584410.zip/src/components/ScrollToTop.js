import React from "react";
import styles from "./ScrollToTop.module.css";

const ScrollToTopButton = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const handler = () => {
      setVisible(window.scrollY > 400);
    };
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (!visible) {
    return null;
  }

  return (
    <button
      onClick={scrollToTop}
      className={styles.button}
      aria-label="Zurück zum Seitenanfang"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;