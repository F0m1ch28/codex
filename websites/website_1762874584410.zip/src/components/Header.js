import React from "react";
import { NavLink } from "react-router-dom";
import { ReactComponent as MenuIcon } from "../icons/menu.svg";
import { ReactComponent as CloseIcon } from "../icons/close.svg";
import styles from "./Header.module.css";

const navItems = [
  { path: "/", label: "Start" },
  { path: "/ueber-uns", label: "Über uns" },
  { path: "/funktionen", label: "Funktionen" },
  { path: "/loesungen", label: "Lösungen" },
  { path: "/integrationen", label: "Integrationen" },
  { path: "/ressourcen", label: "Ressourcen" },
  { path: "/sicherheit", label: "Sicherheit" },
  { path: "/plaene", label: "Pläne" },
  { path: "/kontakt", label: "Kontakt" }
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const toggleMenu = () => setMobileOpen((prev) => !prev);

  React.useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [mobileOpen]);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Tredifynix Logo">
          <span className={styles.logoMark}>T</span>
          <span className={styles.logoText}>Tredifynix</span>
        </NavLink>
        <nav className={styles.nav} aria-label="Hauptnavigation">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <button
          className={styles.menuButton}
          aria-label={mobileOpen ? "Menü schließen" : "Menü öffnen"}
          aria-expanded={mobileOpen}
          aria-controls="mobile-navigation"
          onClick={toggleMenu}
        >
          {mobileOpen ? <CloseIcon /> : <MenuIcon />}
        </button>
        <nav
          id="mobile-navigation"
          className={`${styles.mobileNav} ${mobileOpen ? styles.mobileOpen : ""}`}
          aria-label="Mobile Navigation"
        >
          <ul className={styles.mobileNavList}>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    isActive ? `${styles.mobileLink} ${styles.mobileActive}` : styles.mobileLink
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            <li>
              <NavLink
                to="/kontakt"
                onClick={() => setMobileOpen(false)}
                className={`${styles.mobileLink} ${styles.mobileCTA}`}
              >
                Jetzt starten
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;