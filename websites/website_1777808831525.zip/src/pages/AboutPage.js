import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About GambleMaster | Responsible Casino Intelligence</title>
        <meta
          name="description"
          content="Learn about GambleMaster’s mission, expert team, and commitment to transparent casino assessment backed by a decade of research."
        />
        <meta property="og:title" content="About GambleMaster" />
        <meta
          property="og:description"
          content="Discover the team behind GambleMaster and our dedication to fair, responsible casino comparisons."
        />
        <link rel="canonical" href="https://gamblemaster.netlify.app/about" />
        <meta name="robots" content="index, follow" />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <h1>Our Mission</h1>
          <p>
            GambleMaster exists to empower adults to make responsible, well-informed decisions about where they play. Since launching in 2013, we have combed through licensing registers, payout audits, and player feedback to produce unbiased reviews that respect local regulations worldwide.
          </p>
        </div>
        <div className={styles.heroStats}>
          <div className={styles.statCard}>
            <strong>500+</strong>
            <span>Casinos Reviewed</span>
          </div>
          <div className={styles.statCard}>
            <strong>10</strong>
            <span>Years Researching iGaming</span>
          </div>
          <div className={styles.statCard}>
            <strong>1M+</strong>
            <span>Global Users</span>
          </div>
        </div>
      </section>

      <section className={styles.values} aria-labelledby="values-heading">
        <h2 id="values-heading">Core Principles</h2>
        <div className={styles.valueGrid}>
          <article className={styles.valueCard}>
            <h3>Evidence-Based Ratings</h3>
            <p>Our ratings are compiled from documented licensing, third-party testing certificates, payout processing logs, and responsible gambling policies.</p>
          </article>
          <article className={styles.valueCard}>
            <h3>Responsible Play First</h3>
            <p>Every review highlights safety features such as deposit limits, reality checks, and self-exclusion paths, ensuring player protection remains central.</p>
          </article>
          <article className={styles.valueCard}>
            <h3>Global Perspective</h3>
            <p>We monitor regulatory changes across Europe, North America, Oceania, and emerging markets, helping our readers understand jurisdictional requirements.</p>
          </article>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <h2 id="team-heading">Meet the Team</h2>
        <div className={styles.teamGrid}>
          <article className={styles.teamCard}>
            <img src="https://picsum.photos/300/300?random=41" alt="Portrait of Emma Sinclair, Head of Research" />
            <h3>Emma Sinclair</h3>
            <span>Head of Research</span>
            <p>Emma leads our auditing agenda, cross-referencing regulator filings and payout logs to verify claims made by operators.</p>
          </article>
          <article className={styles.teamCard}>
            <img src="https://picsum.photos/300/300?random=42" alt="Portrait of Marcus Chen, Gaming Analyst" />
            <h3>Marcus Chen</h3>
            <span>Gaming Analyst</span>
            <p>Marcus evaluates game libraries, volatility profiles, and RTP disclosures to ensure our comparisons focus on measurable metrics.</p>
          </article>
          <article className={styles.teamCard}>
            <img src="https://picsum.photos/300/300?random=43" alt="Portrait of Lila Duarte, Compliance Specialist" />
            <h3>Lila Duarte</h3>
            <span>Compliance Specialist</span>
            <p>Lila tracks regulatory updates, making sure our recommendations align with the laws of the United States, EU, and Australia.</p>
          </article>
          <article className={styles.teamCard}>
            <img src="https://picsum.photos/300/300?random=44" alt="Portrait of Aaron Patel, UX Researcher" />
            <h3>Aaron Patel</h3>
            <span>UX Researcher</span>
            <p>Aaron interviews players and tests casino interfaces to score usability, accessibility, and support responsiveness.</p>
          </article>
        </div>
      </section>

      <section className={styles.commitment}>
        <h2>Commitment to Integrity</h2>
        <p>
          Our comparison methodology is updated quarterly. We never accept revenue arrangements that compromise editorial independence. Casinos earn featured placement only after demonstrating clear terms, proactive responsible gambling tools, and reliable withdrawals. When operators fall short, we update reviews immediately and inform our subscribers.
        </p>
      </section>
    </div>
  );
};

export default AboutPage;