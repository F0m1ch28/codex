import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const TermsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Service | GambleMaster</title>
      <meta
        name="description"
        content="Review GambleMaster’s terms of service governing site usage, intellectual property, disclaimers, and user responsibilities."
      />
      <meta property="og:title" content="GambleMaster Terms of Service" />
      <meta
        property="og:description"
        content="Understand the terms and conditions governing the use of GambleMaster’s comparison services."
      />
      <link rel="canonical" href="https://gamblemaster.netlify.app/terms-of-service" />
      <meta name="robots" content="index, follow" />
    </Helmet>
    <h1>Terms of Service</h1>
    <p>Effective date: January 1, 2024</p>
    <h2>1. Acceptance</h2>
    <p>
      By accessing GambleMaster, you agree to these Terms. If you do not agree, please discontinue use. These Terms apply to all visitors aged 18 or older.
    </p>
    <h2>2. Information Accuracy</h2>
    <p>
      We strive to maintain accurate comparison data; however, operators may change offers without notice. Users must verify promotions, wagering rules, and eligibility directly with the casino before participating.
    </p>
    <h2>3. Responsible Gambling</h2>
    <p>
      GambleMaster promotes responsible gambling. We do not provide guarantees of winning and encourage users to set personal limits. If gambling is causing harm, seek help from local support organizations.
    </p>
    <h2>4. No Operator Relationship</h2>
    <p>
      GambleMaster is an independent comparison platform. We are not a casino operator and do not process gaming transactions. Links to third-party sites are provided for informational purposes.
    </p>
    <h2>5. Intellectual Property</h2>
    <p>
      All content, graphics, and data compilations are the property of GambleMaster unless otherwise noted. You may not reproduce or distribute material without prior written permission.
    </p>
    <h2>6. User Conduct</h2>
    <p>
      Users must not misuse the site, attempt to breach security, or interfere with others' experience. Posting illegal, harmful, or offensive content is prohibited.
    </p>
    <h2>7. Disclaimers</h2>
    <p>
      GambleMaster provides information “as is” without warranties. We disclaim liability for errors, omissions, or outcomes arising from reliance on our content.
    </p>
    <h2>8. Limitation of Liability</h2>
    <p>
      GambleMaster shall not be liable for indirect, incidental, or consequential damages. Our total liability shall not exceed the amount paid, if any, for accessing our services.
    </p>
    <h2>9. Governing Law</h2>
    <p>
      These Terms are governed by the laws of Nevada, United States, without regard to conflict of law provisions. Disputes shall be resolved in competent courts located in Clark County, Nevada.
    </p>
    <h2>10. Changes</h2>
    <p>
      We may update these Terms as our services evolve. Continued use after changes constitutes acceptance. Significant updates will be highlighted on this page.
    </p>
    <h2>11. Contact</h2>
    <p>
      For questions, contact <a href="mailto:support@gamblemaster.com">support@gamblemaster.com</a>.
    </p>
  </div>
);

export default TermsPage;