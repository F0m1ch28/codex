import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const PrivacyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | GambleMaster</title>
      <meta
        name="description"
        content="Review GambleMaster’s privacy policy to understand how we handle data, cookies, and user rights in accordance with global regulations."
      />
      <meta property="og:title" content="GambleMaster Privacy Policy" />
      <meta
        property="og:description"
        content="Details on data handling, security, and privacy rights at GambleMaster."
      />
      <link rel="canonical" href="https://gamblemaster.netlify.app/privacy-policy" />
      <meta name="robots" content="index, follow" />
    </Helmet>
    <h1>Privacy Policy</h1>
    <p>Effective date: January 1, 2024</p>
    <p>
      GambleMaster respects your privacy and complies with applicable laws governing personal data in the United States, European Union, Australia, and other jurisdictions where we operate. This policy explains what data we collect, why we collect it, and how you can exercise control over your information.
    </p>
    <h2>Information We Collect</h2>
    <ul>
      <li>Contact details you provide voluntarily (name, email address, organization) when subscribing or contacting us.</li>
      <li>Usage data such as pages visited, referral sources, and device type, aggregated to improve site performance.</li>
      <li>Cookie preferences chosen via our consent banner.</li>
    </ul>
    <h2>How We Use Information</h2>
    <p>We process data to:</p>
    <ul>
      <li>Respond to enquiries and provide requested information.</li>
      <li>Send newsletters when you subscribe (you may opt out at any time).</li>
      <li>Analyze site performance and improve our comparison tools.</li>
    </ul>
    <h2>Legal Basis</h2>
    <p>Our processing is based on your consent, legitimate interest in improving services, and compliance with legal obligations.</p>
    <h2>Data Sharing</h2>
    <p>
      GambleMaster does not sell personal information. We may share limited data with trusted service providers who assist with email delivery, analytics, or hosting. These providers are bound by confidentiality and data protection obligations.
    </p>
    <h2>International Transfers</h2>
    <p>
      When transferring data outside of your jurisdiction, we implement safeguards such as Standard Contractual Clauses to maintain equivalent protection levels.
    </p>
    <h2>Your Rights</h2>
    <p>You have the right to access, correct, delete, or restrict use of your personal data. EU/UK residents may also object to processing or request data portability. To exercise any right, email <a href="mailto:support@gamblemaster.com">support@gamblemaster.com</a>.</p>
    <h2>Cookies</h2>
    <p>
      We use functional cookies to maintain site operation. Optional analytics and marketing cookies are disabled unless you provide consent. You can adjust preferences anytime via the cookie settings link in the footer.
    </p>
    <h2>Security</h2>
    <p>
      We implement encryption, access controls, and routine monitoring to protect information. While no system is completely secure, we strive to mitigate risk and respond promptly to potential incidents.
    </p>
    <h2>Retention</h2>
    <p>
      We store personal data only as long as needed to fulfill the purpose collected or comply with legal obligations. Newsletter data is deleted upon unsubscribe.
    </p>
    <h2>Children</h2>
    <p>
      Our services are intended for adults aged 18 or older. We do not knowingly collect information from minors. If you believe a minor has provided data, contact us for deletion.
    </p>
    <h2>Updates</h2>
    <p>
      We may update this policy to reflect regulatory changes or improvements. Significant updates will be noted on this page with a revised effective date.
    </p>
    <h2>Contact</h2>
    <p>
      For privacy questions or requests, please email <a href="mailto:support@gamblemaster.com">support@gamblemaster.com</a> or write to 123 Gaming Street, Las Vegas, NV 89109, USA.
    </p>
  </div>
);

export default PrivacyPage;