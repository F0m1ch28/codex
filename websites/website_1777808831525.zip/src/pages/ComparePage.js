import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ComparePage.module.css';

const casinoOptions = [
  {
    id: 'spin-palace',
    name: 'Spin Palace',
    rating: '4.8 / 5',
    bonus: '100% up to $1000',
    wagering: '35x bonus',
    gameTypes: 'Slots, Blackjack, Roulette, Live Dealer',
    payments: 'Visa, Mastercard, PayPal, Skrill, Neteller, Bitcoin',
    rtp: '96.4%',
  },
  {
    id: 'royal-vegas',
    name: 'Royal Vegas',
    rating: '4.7 / 5',
    bonus: '120% up to $1200',
    wagering: '40x bonus',
    gameTypes: 'Slots, Baccarat, Roulette, Live Dealer',
    payments: 'Visa, Mastercard, Skrill, Neteller, Interac, Ethereum',
    rtp: '96.2%',
  },
  {
    id: '777-casino',
    name: '777 Casino',
    rating: '4.5 / 5',
    bonus: '77 Spins + $777',
    wagering: '30x winnings',
    gameTypes: 'Retro Slots, Table Games, Live Blackjack',
    payments: 'Visa, Mastercard, PayPal, Neteller, Bitcoin',
    rtp: '96.0%',
  },
  {
    id: 'betway',
    name: 'Betway',
    rating: '4.6 / 5',
    bonus: '100% up to $1500',
    wagering: '32x bonus',
    gameTypes: 'Slots, Sportsbook, Live Casino, Esports',
    payments: 'Visa, Mastercard, PayPal, Skrill, Neteller, Paysafecard',
    rtp: '96.8%',
  },
  {
    id: 'jackpot-city',
    name: 'Jackpot City',
    rating: '4.6 / 5',
    bonus: '100% up to $1600',
    wagering: '35x bonus',
    gameTypes: 'Slots, Progressive Jackpots, Live Roulette',
    payments: 'Visa, Mastercard, Skrill, Neteller, EcoPayz, Bitcoin',
    rtp: '96.3%',
  },
  {
    id: 'ruby-fortune',
    name: 'Ruby Fortune',
    rating: '4.4 / 5',
    bonus: '200% up to $750',
    wagering: '45x bonus',
    gameTypes: 'Slots, Video Poker, Live Baccarat',
    payments: 'Visa, Mastercard, PayPal, Skrill, Neteller',
    rtp: '96.1%',
  },
];

const ComparePage = () => {
  const [selectedIds, setSelectedIds] = useState([]);
  const [showTable, setShowTable] = useState(false);
  const [error, setError] = useState('');

  const handleSelection = (id) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : prev.length < 3 ? [...prev, id] : prev
    );
    setError('');
  };

  const handleCompare = () => {
    if (selectedIds.length < 2) {
      setError('Select at least two casinos to start the comparison.');
      setShowTable(false);
      return;
    }
    setShowTable(true);
  };

  const selectedCasinos = casinoOptions.filter((casino) => selectedIds.includes(casino.id));

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Compare Casinos | GambleMaster Interactive Tool</title>
        <meta
          name="description"
          content="Select up to three casinos and compare ratings, bonuses, wagering requirements, game types, payment methods, and RTP using GambleMaster’s comparison tool."
        />
        <meta property="og:title" content="Compare Online Casinos" />
        <meta
          property="og:description"
          content="Interactive comparison of casino ratings, bonuses, wagering terms, and payment options."
        />
        <link rel="canonical" href="https://gamblemaster.netlify.app/compare" />
        <meta name="robots" content="index, follow" />
      </Helmet>

      <header className={styles.header}>
        <h1>Compare Casinos</h1>
        <p>Select up to three operators and click compare to review key metrics side-by-side.</p>
      </header>

      <section className={styles.selector} aria-labelledby="selector-heading">
        <h2 id="selector-heading">Select Casinos</h2>
        <div className={styles.options}>
          {casinoOptions.map((casino) => (
            <label key={casino.id} className={`${styles.option} ${selectedIds.includes(casino.id) ? styles.selected : ''}`}>
              <input
                type="checkbox"
                value={casino.id}
                checked={selectedIds.includes(casino.id)}
                onChange={() => handleSelection(casino.id)}
                aria-label={`Select ${casino.name} for comparison`}
              />
              <span className={styles.optionDetails}>
                <strong>{casino.name}</strong>
                <span className={styles.optionMeta}>{casino.rating} • {casino.bonus}</span>
              </span>
            </label>
          ))}
        </div>
        <button type="button" className={styles.compareButton} onClick={handleCompare} aria-label="Compare selected casinos">
          Compare Now
        </button>
        {error && <p className={styles.error} role="alert">{error}</p>}
      </section>

      {showTable && selectedCasinos.length >= 2 && (
        <section className={styles.results} aria-live="polite">
          <div className={styles.tableWrapper}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th scope="col">Metric</th>
                  {selectedCasinos.map((casino) => (
                    <th scope="col" key={casino.id}>{casino.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">Rating</th>
                  {selectedCasinos.map((casino) => <td key={`${casino.id}-rating`}>{casino.rating}</td>)}
                </tr>
                <tr>
                  <th scope="row">Welcome Bonus</th>
                  {selectedCasinos.map((casino) => <td key={`${casino.id}-bonus`}>{casino.bonus}</td>)}
                </tr>
                <tr>
                  <th scope="row">Wagering Requirements</th>
                  {selectedCasinos.map((casino) => <td key={`${casino.id}-wagering`}>{casino.wagering}</td>)}
                </tr>
                <tr>
                  <th scope="row">Game Types</th>
                  {selectedCasinos.map((casino) => <td key={`${casino.id}-games`}>{casino.gameTypes}</td>)}
                </tr>
                <tr>
                  <th scope="row">Payment Methods</th>
                  {selectedCasinos.map((casino) => <td key={`${casino.id}-payments`}>{casino.payments}</td>)}
                </tr>
                <tr>
                  <th scope="row">Average RTP</th>
                  {selectedCasinos.map((casino) => <td key={`${casino.id}-rtp`}>{casino.rtp}</td>)}
                </tr>
              </tbody>
            </table>
          </div>
          <p className={styles.note}>Data verified as of Q1 2024. Always confirm bonus terms and local eligibility before registering.</p>
        </section>
      )}
    </div>
  );
};

export default ComparePage;