import React from 'react';
import { Helmet } from 'react-helmet';
import { NavLink } from 'react-router-dom';
import styles from './ReviewsPage.module.css';

const reviews = [
  {
    name: 'Spin Palace',
    rating: '4.8 / 5',
    bonus: '100% up to $1000',
    path: '/casino/spin-palace',
    image: 'https://via.placeholder.com/320x200?text=Spin+Palace',
  },
  {
    name: 'Royal Vegas',
    rating: '4.7 / 5',
    bonus: '120% up to $1200',
    path: '/casino/royal-vegas',
    image: 'https://via.placeholder.com/320x200?text=Royal+Vegas',
  },
  {
    name: '777 Casino',
    rating: '4.5 / 5',
    bonus: '77 Spins + $777',
    path: '/casino/777-casino',
    image: 'https://via.placeholder.com/320x200?text=777+Casino',
  },
  {
    name: 'Betway',
    rating: '4.6 / 5',
    bonus: '100% up to $1500',
    path: '/casino/betway',
    image: 'https://via.placeholder.com/320x200?text=Betway',
  },
  {
    name: 'Jackpot City',
    rating: '4.6 / 5',
    bonus: '100% up to $1600',
    path: '/casino/jackpot-city',
    image: 'https://via.placeholder.com/320x200?text=Jackpot+City',
  },
  {
    name: 'Ruby Fortune',
    rating: '4.4 / 5',
    bonus: '200% up to $750',
    path: '/casino/ruby-fortune',
    image: 'https://via.placeholder.com/320x200?text=Ruby+Fortune',
  },
];

const ReviewsPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Casino Reviews | GambleMaster Expert Breakdown</title>
        <meta
          name="description"
          content="Browse GambleMaster’s comprehensive casino reviews covering bonuses, wagering rules, payment limits, and responsible gaming tools."
        />
        <meta property="og:title" content="Casino Reviews | GambleMaster" />
        <meta
          property="og:description"
          content="Objective casino reviews focusing on licensing, wagering transparency, and payout speed."
        />
        <link rel="canonical" href="https://gamblemaster.netlify.app/casino-reviews" />
        <meta name="robots" content="index, follow" />
      </Helmet>
      <header className={styles.header}>
        <h1>Casino Reviews</h1>
        <p>
          Each review is compiled from documented data sources. Click through to learn about bonus rules, game portfolios, RTP averages, and payment performance for every operator.
        </p>
      </header>
      <div className={styles.grid}>
        {reviews.map((review) => (
          <NavLink key={review.name} to={review.path} className={styles.card} aria-label={`Read review for ${review.name}`}>
            <img src={review.image} alt={`${review.name} review cover`} />
            <div className={styles.cardContent}>
              <h2>{review.name}</h2>
              <p>Rating: {review.rating}</p>
              <p>Welcome Bonus: {review.bonus}</p>
              <span className={styles.more}>Read Review</span>
            </div>
          </NavLink>
        ))}
      </div>
    </div>
  );
};

export default ReviewsPage;