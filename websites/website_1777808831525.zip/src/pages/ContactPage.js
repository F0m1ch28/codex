import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [feedback, setFeedback] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setFeedback('');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const { name, email, subject, message } = formData;
    const emailPattern = /\S+@\S+\.\S+/;
    if (!name || !email || !subject || !message) {
      setFeedback('All fields are required.');
      return;
    }
    if (!emailPattern.test(email)) {
      setFeedback('Please provide a valid email address.');
      return;
    }
    setFeedback('Thank you for reaching out. Our team will respond within one business day.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact GambleMaster | Connect with Our Team</title>
        <meta
          name="description"
          content="Contact GambleMaster for media inquiries, partnership opportunities, or feedback on our casino comparison data."
        />
        <meta property="og:title" content="Contact GambleMaster" />
        <meta
          property="og:description"
          content="Reach out to the GambleMaster team for questions about our casino reviews and data methodology."
        />
        <link rel="canonical" href="https://gamblemaster.netlify.app/contact" />
        <meta name="robots" content="index, follow" />
      </Helmet>
      <header className={styles.header}>
        <h1>Contact Us</h1>
        <p>
          We welcome media enquiries, partnership proposals, and responsible gambling collaboration requests. Please use the form and provide as much detail as possible.
        </p>
      </header>
      <div className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">Name</label>
          <input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            aria-required="true"
            placeholder="Your full name"
          />
          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            aria-required="true"
            placeholder="your@email.com"
            type="email"
          />
          <label htmlFor="subject">Subject</label>
          <input
            id="subject"
            name="subject"
            value={formData.subject}
            onChange={handleChange}
            aria-required="true"
            placeholder="Topic of your message"
          />
          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            aria-required="true"
            rows="6"
            placeholder="How can we help?"
          ></textarea>
          <button type="submit" aria-label="Submit contact form">Send Message</button>
          {feedback && <p className={styles.feedback} role="status">{feedback}</p>}
        </form>
        <aside className={styles.info}>
          <h2>Head Office</h2>
          <p>123 Gaming Street<br />Las Vegas, NV 89109, USA</p>
          <p><strong>Phone:</strong> <a href="tel:+17025550199">+1-702-555-0199</a></p>
          <p><strong>Email:</strong> <a href="mailto:support@gamblemaster.com">support@gamblemaster.com</a></p>
          <p><strong>Support Hours:</strong> Monday – Friday, 9:00 – 18:00 PST</p>
          <div className={styles.map} aria-label="GambleMaster office location">
            <iframe
              title="GambleMaster Las Vegas office location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3239.471470968511!2d-115.16553258473871!3d36.11620348009425!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c8c42d06bbb1fd%3A0x6d020b7f4c9f29a0!2sLas%20Vegas%20Strip!5e0!3m2!1sen!2sus!4v1700000000000"
              width="100%"
              height="260"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default ContactPage;