import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const CookiesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookies Policy | GambleMaster</title>
      <meta
        name="description"
        content="Learn how GambleMaster uses cookies, the types of cookies employed, and how you can control your preferences."
      />
      <meta property="og:title" content="GambleMaster Cookies Policy" />
      <meta
        property="og:description"
        content="Details about functional, analytics, and marketing cookies used by GambleMaster."
      />
      <link rel="canonical" href="https://gamblemaster.netlify.app/cookies-policy" />
      <meta name="robots" content="index, follow" />
    </Helmet>
    <h1>Cookies Policy</h1>
    <p>Effective date: January 1, 2024</p>
    <h2>What Are Cookies?</h2>
    <p>Cookies are small text files stored on your device when you visit a website. They help us remember preferences and measure how the site is used.</p>
    <h2>Types of Cookies We Use</h2>
    <ul>
      <li><strong>Functional Cookies:</strong> Required for site operation, such as remembering your cookie choices.</li>
      <li><strong>Analytics Cookies:</strong> Measure traffic and user engagement. These are optional and only active with your consent.</li>
      <li><strong>Marketing Cookies:</strong> Provide relevant communications. Currently disabled by default and activated only if you opt in.</li>
    </ul>
    <h2>Managing Preferences</h2>
    <p>You can manage preferences via our cookie banner or adjust browser settings to block cookies. Disabling functional cookies may impact site usability.</p>
    <h2>Third-Party Providers</h2>
    <p>We work with analytics and email tools that may set their own cookies. They adhere to data protection agreements and only process data as instructed by us.</p>
    <h2>Retention</h2>
    <p>Functional cookies generally expire within 12 months. Analytics and marketing cookies, when enabled, follow the retention periods defined in our consent manager.</p>
    <h2>Updates</h2>
    <p>We will update this policy if our cookie usage changes. The revision date will be updated accordingly.</p>
    <h2>Contact</h2>
    <p>
      Questions? Email <a href="mailto:support@gamblemaster.com">support@gamblemaster.com</a>.
    </p>
  </div>
);

export default CookiesPage;