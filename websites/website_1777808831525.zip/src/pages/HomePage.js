import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { NavLink } from 'react-router-dom';
import styles from './HomePage.module.css';

const HomePage = () => {
  const [email, setEmail] = useState('');
  const [feedback, setFeedback] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    const emailPattern = /\S+@\S+\.\S+/;
    if (!emailPattern.test(email)) {
      setFeedback('Please enter a valid email address.');
      return;
    }
    setFeedback('Thanks! You will receive curated comparison updates soon.');
    setEmail('');
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>GambleMaster | Your Ultimate Casino Comparison Tool</title>
        <meta
          name="description"
          content="Compare online casinos, evaluate wagering terms, and explore bonus transparency with GambleMaster’s global comparison system."
        />
        <meta property="og:title" content="GambleMaster | Casino Comparison Tool" />
        <meta
          property="og:description"
          content="Objective casino reviews, trusted ratings, and transparent data to help you choose reputable gaming brands."
        />
        <link rel="canonical" href="https://gamblemaster.netlify.app/" />
        <meta name="robots" content="index, follow" />
      </Helmet>

      <section className={styles.hero} role="banner" aria-label="Casino comparison hero">
        <div className={styles.heroContent}>
          <p className={styles.heroBadge}>Trusted insights • Responsible play</p>
          <h1 className={styles.heroTitle}>Your Ultimate Casino Comparison Tool</h1>
          <p className={styles.heroSubtitle}>
            Cross-check licensing, wagering rules, game portfolios, and payment speed in minutes. GambleMaster compiles audited information so adult players can make data-driven decisions wherever they play.
          </p>
          <div className={styles.heroActions}>
            <NavLink to="/compare" className={styles.heroCta} aria-label="Start comparing casinos now">
              Start Comparing Now
            </NavLink>
            <NavLink to="/casino-reviews" className={styles.heroSecondary} aria-label="Explore detailed casino reviews">
              Explore Reviews
            </NavLink>
          </div>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img src="https://picsum.photos/600/400?random=32" alt="Casino dashboard illustration" />
        </div>
      </section>

      <section className={styles.how} aria-labelledby="how-title">
        <h2 id="how-title" className={styles.sectionTitle}>How It Works</h2>
        <div className={styles.steps}>
          <article className={styles.stepCard}>
            <i className="fas fa-search" aria-hidden="true"></i>
            <h3>Browse</h3>
            <p>Filter casinos by jurisdiction, software provider, and bonus structure to find brands matching your preferences.</p>
          </article>
          <article className={styles.stepCard}>
            <i className="fas fa-sliders-h" aria-hidden="true"></i>
            <h3>Compare</h3>
            <p>Place casinos side-by-side to view wagering requirements, RTP averages, game diversity, and payment options in one snapshot.</p>
          </article>
          <article className={styles.stepCard}>
            <i className="fas fa-check" aria-hidden="true"></i>
            <h3>Choose</h3>
            <p>Use concise highlights and expert commentary to select a licensed operator with policies that suit responsible play.</p>
          </article>
        </div>
      </section>

      <section className={styles.topRated} aria-labelledby="top-rated-title">
        <div className={styles.sectionHeader}>
          <h2 id="top-rated-title" className={styles.sectionTitle}>Top Rated Casinos</h2>
          <p className={styles.sectionSubtitle}>Analyzed against licensing, bonus clarity, and player support metrics.</p>
        </div>
        <div className={styles.cardGrid}>
          <NavLink to="/casino/spin-palace" className={styles.casinoCard} aria-label="Spin Palace detailed review">
            <div className={styles.cardHeader}>
              <img src="https://via.placeholder.com/300x180?text=Spin+Palace" alt="Spin Palace casino cover" />
            </div>
            <div className={styles.cardBody}>
              <h3>Spin Palace</h3>
              <p>Rating: <strong>4.8 / 5</strong></p>
              <p>Welcome Bonus: 100% up to $1000</p>
              <span className={styles.tag}>35x wagering</span>
            </div>
          </NavLink>
          <NavLink to="/casino/royal-vegas" className={styles.casinoCard} aria-label="Royal Vegas detailed review">
            <div className={styles.cardHeader}>
              <img src="https://via.placeholder.com/300x180?text=Royal+Vegas" alt="Royal Vegas casino cover" />
            </div>
            <div className={styles.cardBody}>
              <h3>Royal Vegas</h3>
              <p>Rating: <strong>4.7 / 5</strong></p>
              <p>Welcome Bonus: 120% up to $1200</p>
              <span className={styles.tag}>40x wagering</span>
            </div>
          </NavLink>
          <NavLink to="/casino/777-casino" className={styles.casinoCard} aria-label="777 Casino detailed review">
            <div className={styles.cardHeader}>
              <img src="https://via.placeholder.com/300x180?text=777+Casino" alt="777 Casino cover" />
            </div>
            <div className={styles.cardBody}>
              <h3>777 Casino</h3>
              <p>Rating: <strong>4.5 / 5</strong></p>
              <p>Welcome Bonus: 77 spins + $777</p>
              <span className={styles.tag}>30x wagering</span>
            </div>
          </NavLink>
          <NavLink to="/casino/betway" className={styles.casinoCard} aria-label="Betway detailed review">
            <div className={styles.cardHeader}>
              <img src="https://via.placeholder.com/300x180?text=Betway" alt="Betway casino cover" />
            </div>
            <div className={styles.cardBody}>
              <h3>Betway</h3>
              <p>Rating: <strong>4.6 / 5</strong></p>
              <p>Welcome Bonus: 100% up to $1500</p>
              <span className={styles.tag}>32x wagering</span>
            </div>
          </NavLink>
        </div>
      </section>

      <section className={styles.why} aria-labelledby="why-title">
        <h2 id="why-title" className={styles.sectionTitle}>Why GambleMaster?</h2>
        <div className={styles.whyGrid}>
          <article className={styles.whyCard}>
            <i className="fas fa-eye" aria-hidden="true"></i>
            <h3>Transparent Reviews</h3>
            <p>Every review discloses wagering rules, bet limits, and jurisdictional information. No hype, no exaggerated claims.</p>
          </article>
          <article className={styles.whyCard}>
            <i className="fas fa-brain" aria-hidden="true"></i>
            <h3>Expert Analysis</h3>
            <p>Our analysts cross-reference licensing registers, RNG audits, and withdrawal speed reports before issuing our verdict.</p>
          </article>
          <article className={styles.whyCard}>
            <i className="fas fa-shield-alt" aria-hidden="true"></i>
            <h3>Trusted Data</h3>
            <p>We aggregate operator data from independent testing agencies and regulatory filings to ensure accuracy.</p>
          </article>
        </div>
      </section>

      <section className={styles.categories} aria-labelledby="categories-title">
        <h2 id="categories-title" className={styles.sectionTitle}>Casino Categories</h2>
        <div className={styles.categoryGrid}>
          <div className={styles.categoryCard}>
            <i className="fas fa-dice" aria-hidden="true"></i>
            <h3>Slots</h3>
            <p>Volatility profiles, jackpots, and studio diversity for reel enthusiasts.</p>
          </div>
          <div className={styles.categoryCard}>
            <i className="fas fa-cards" aria-hidden="true"></i>
            <h3>Table Games</h3>
            <p>Blackjack, roulette, and poker variants with rule clarity and RTP benchmarks.</p>
          </div>
          <div className={styles.categoryCard}>
            <i className="fas fa-user-tie" aria-hidden="true"></i>
            <h3>Live Dealer</h3>
            <p>Studio providers, streaming quality, and dealer-assisted limits for immersive sessions.</p>
          </div>
          <div className={styles.categoryCard}>
            <i className="fab fa-bitcoin" aria-hidden="true"></i>
            <h3>Crypto</h3>
            <p>Blockchain-friendly casinos with on-chain verification and transparent limits.</p>
          </div>
        </div>
      </section>

      <section className={styles.reviews} aria-labelledby="user-reviews-title">
        <h2 id="user-reviews-title" className={styles.sectionTitle}>What Our Users Say</h2>
        <div className={styles.carousel} tabIndex="0" aria-label="User testimonials">
          <article className={styles.reviewCard}>
            <p>“Best comparison resource I’ve found! It highlighted wagering clauses that many operators bury in small print.”</p>
            <span>— John D.</span>
          </article>
          <article className={styles.reviewCard}>
            <p>“Saved me hours of research and pointed me toward casinos with verifiable licensing in my jurisdiction.”</p>
            <span>— Sarah K.</span>
          </article>
          <article className={styles.reviewCard}>
            <p>“Accurate, fair, and up-to-date. I appreciate the reminders about responsible gambling tools.”</p>
            <span>— Mike L.</span>
          </article>
        </div>
      </section>

      <section className={styles.offers} aria-labelledby="offers-title">
        <h2 id="offers-title" className={styles.sectionTitle}>Latest Casino Offers</h2>
        <div className={styles.tableWrapper}>
          <table className={styles.table} aria-describedby="offers-title">
            <thead>
              <tr>
                <th scope="col">Casino</th>
                <th scope="col">Bonus</th>
                <th scope="col">Wagering</th>
                <th scope="col">Average RTP</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Spin Palace</td>
                <td>100% up to $1000</td>
                <td>35x on bonus</td>
                <td>96.4%</td>
              </tr>
              <tr>
                <td>Royal Vegas</td>
                <td>120% up to $1200</td>
                <td>40x on bonus</td>
                <td>96.2%</td>
              </tr>
              <tr>
                <td>777 Casino</td>
                <td>77 Free Spins + $777</td>
                <td>30x on winnings</td>
                <td>96.0%</td>
              </tr>
              <tr>
                <td>Betway</td>
                <td>100% up to $1500</td>
                <td>32x on bonus</td>
                <td>96.8%</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className={styles.offerNote}>Always review the full bonus terms, eligible games, and withdrawal limits before opting in.</p>
      </section>

      <section className={styles.cta} aria-labelledby="cta-title">
        <div className={styles.ctaContent}>
          <h2 id="cta-title">Never miss transparent bonus intel again!</h2>
          <p>Subscribe for updates highlighting audited offers, payment speed improvements, and new responsible gaming tools.</p>
          <form className={styles.ctaForm} onSubmit={handleSubmit}>
            <label htmlFor="email-input" className="sr-only">Email address</label>
            <input
              id="email-input"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="Enter your email"
              aria-required="true"
              aria-label="Email address"
            />
            <button type="submit" aria-label="Get notified about casino updates">Get Notified</button>
          </form>
          {feedback && <p className={styles.feedback} role="status">{feedback}</p>}
        </div>
      </section>
    </div>
  );
};

export default HomePage;