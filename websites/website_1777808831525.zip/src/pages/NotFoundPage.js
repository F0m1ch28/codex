import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import styles from './NotFoundPage.module.css';

const NotFoundPage = () => {
  const navigate = useNavigate();
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Page Not Found | GambleMaster</title>
        <meta name="robots" content="noindex, follow" />
      </Helmet>
      <div className={styles.content}>
        <h1>404</h1>
        <p>The page you are looking for might have been moved or removed.</p>
        <button type="button" onClick={() => navigate('/')} className={styles.button} aria-label="Go back to home page">
          Go Home
        </button>
      </div>
    </div>
  );
};

export default NotFoundPage;