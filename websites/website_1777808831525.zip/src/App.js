import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import styles from './App.module.css';
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import CookieBanner from './components/CookieBanner/CookieBanner';
import ScrollToTop from './components/ScrollToTop/ScrollToTop';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ReviewsPage from './pages/ReviewsPage';
import ComparePage from './pages/ComparePage';
import ContactPage from './pages/ContactPage';
import PrivacyPage from './pages/PrivacyPage';
import TermsPage from './pages/TermsPage';
import CookiesPage from './pages/CookiesPage';
import NotFoundPage from './pages/NotFoundPage';
import SpinPalaceReview from './pages/CasinoReview/SpinPalaceReview';
import RoyalVegasReview from './pages/CasinoReview/RoyalVegasReview';
import SevenSevenSevenReview from './pages/CasinoReview/SevenSevenSevenReview';
import BetwayReview from './pages/CasinoReview/BetwayReview';
import JackpotCityReview from './pages/CasinoReview/JackpotCityReview';
import RubyFortuneReview from './pages/CasinoReview/RubyFortuneReview';

const App = () => {
  return (
    <BrowserRouter>
      <div className={styles.app}>
        <ScrollToTop />
        <Header />
        <main className={styles.main} aria-live="polite">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/casino-reviews" element={<ReviewsPage />} />
            <Route path="/compare" element={<ComparePage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy-policy" element={<PrivacyPage />} />
            <Route path="/terms-of-service" element={<TermsPage />} />
            <Route path="/cookies-policy" element={<CookiesPage />} />
            <Route path="/casino/spin-palace" element={<SpinPalaceReview />} />
            <Route path="/casino/royal-vegas" element={<RoyalVegasReview />} />
            <Route path="/casino/777-casino" element={<SevenSevenSevenReview />} />
            <Route path="/casino/betway" element={<BetwayReview />} />
            <Route path="/casino/jackpot-city" element={<JackpotCityReview />} />
            <Route path="/casino/ruby-fortune" element={<RubyFortuneReview />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </BrowserRouter>
  );
};

export default App;