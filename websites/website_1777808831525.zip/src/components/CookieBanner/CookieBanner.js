import React, { useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [preferences, setPreferences] = useState({
    functional: true,
    analytics: false,
    marketing: false,
  });

  const handleAccept = () => {
    setPreferences({ functional: true, analytics: true, marketing: true });
    setIsVisible(false);
  };

  const handleReject = () => {
    setPreferences({ functional: true, analytics: false, marketing: false });
    setIsVisible(false);
  };

  const handleSave = () => {
    setIsModalOpen(false);
    setIsVisible(false);
  };

  const togglePreference = (key) => {
    if (key === 'functional') return;
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  if (!isVisible) return null;

  return (
    <>
      <div className={styles.banner} role="dialog" aria-live="polite">
        <div className={styles.content}>
          <p className={styles.message}>
            We use cookies to enhance site performance and understand engagement. Functional cookies stay active; choose additional preferences below.
          </p>
          <div className={styles.actions}>
            <button className={styles.reject} onClick={handleReject} aria-label="Reject all optional cookies">
              Reject All
            </button>
            <button className={styles.customize} onClick={() => setIsModalOpen(true)} aria-label="Customize cookie settings">
              Customize
            </button>
            <button className={styles.accept} onClick={handleAccept} aria-label="Accept all cookies">
              Accept All
            </button>
          </div>
        </div>
      </div>
      {isModalOpen && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true" aria-label="Cookie preferences">
          <div className={styles.modal}>
            <h2 className={styles.modalTitle}>Cookie Preferences</h2>
            <div className={styles.checkboxRow}>
              <label className={styles.checkboxLabel}>
                <input type="checkbox" checked={preferences.functional} disabled readOnly />
                Functional (required)
              </label>
            </div>
            <div className={styles.checkboxRow}>
              <label className={styles.checkboxLabel}>
                <input
                  type="checkbox"
                  checked={preferences.analytics}
                  onChange={() => togglePreference('analytics')}
                />
                Analytics
              </label>
            </div>
            <div className={styles.checkboxRow}>
              <label className={styles.checkboxLabel}>
                <input
                  type="checkbox"
                  checked={preferences.marketing}
                  onChange={() => togglePreference('marketing')}
                />
                Marketing
              </label>
            </div>
            <div className={styles.modalActions}>
              <button className={styles.modalCancel} onClick={() => setIsModalOpen(false)} aria-label="Close cookie preference modal">
                Cancel
              </button>
              <button className={styles.modalSave} onClick={handleSave} aria-label="Save cookie preferences">
                Save Preferences
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CookieBanner;