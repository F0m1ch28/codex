import React from 'react';
import styles from './Footer.module.css';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.container}>
        <div className={styles.col}>
          <h3 className={styles.title}>GambleMaster</h3>
          <p className={styles.text}>
            GambleMaster is a global comparison system delivering objective assessments of regulated online casinos. We highlight transparent terms, responsible play tools, and verified data so adults can make informed decisions.
          </p>
        </div>
        <div className={styles.col}>
          <h4 className={styles.subtitle}>Quick Links</h4>
          <ul className={styles.list}>
            <li><NavLink to="/casino-reviews" className={styles.link}>Casino Reviews</NavLink></li>
            <li><NavLink to="/compare" className={styles.link}>Compare Casinos</NavLink></li>
            <li><NavLink to="/privacy-policy" className={styles.link}>Privacy Policy</NavLink></li>
            <li><NavLink to="/terms-of-service" className={styles.link}>Terms of Service</NavLink></li>
            <li><NavLink to="/cookies-policy" className={styles.link}>Cookies Policy</NavLink></li>
          </ul>
        </div>
        <div className={styles.col}>
          <h4 className={styles.subtitle}>Contact</h4>
          <address className={styles.address}>
            <span>123 Gaming Street</span>
            <span>Las Vegas, NV 89109, USA</span>
            <a href="tel:+17025550199" className={styles.link}>+1-702-555-0199</a>
            <a href="mailto:support@gamblemaster.com" className={styles.link}>support@gamblemaster.com</a>
          </address>
        </div>
      </div>
      <div className={styles.bottom}>
        <p className={styles.copy}>
          © {new Date().getFullYear()} GambleMaster. All rights reserved. Gambling involves risk. Please play responsibly and keep gambling out of reach of minors.
        </p>
      </div>
    </footer>
  );
};

export default Footer;