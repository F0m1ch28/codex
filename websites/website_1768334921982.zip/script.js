document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links.desktop');
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            menuToggle.setAttribute('aria-expanded', String(isOpen));
        });

        navLinks.querySelectorAll('a').forEach((link) => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('eliteink_cookie_consent');
        if (!storedConsent) {
            cookieBanner.classList.add('active');
        }

        cookieBanner.querySelectorAll('[data-consent]').forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const decision = button.getAttribute('data-consent');
                localStorage.setItem('eliteink_cookie_consent', decision);
                cookieBanner.classList.remove('active');
                if (button.getAttribute('href')) {
                    setTimeout(() => {
                        window.location.href = button.getAttribute('href');
                    }, 120);
                }
            });
        });
    }

    const dateField = document.querySelector('input[type="date"]');
    if (dateField) {
        const today = new Date();
        const pad = (value) => String(value).padStart(2, '0');
        const minDate = `${today.getFullYear()}-${pad(today.getMonth() + 1)}-${pad(today.getDate())}`;
        dateField.setAttribute('min', minDate);
    }

    document.querySelectorAll('[data-current-year]').forEach((node) => {
        node.textContent = '2025';
    });
});