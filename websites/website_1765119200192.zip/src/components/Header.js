import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  const toggleMobile = () => setIsMobileOpen((prev) => !prev);

  useEffect(() => {
    setIsMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}
      role="banner"
    >
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.brand} aria-label="На головну">
            <span className={styles.logoAccent}>Професійне</span>
            <span className={styles.logoText}>дресирування собак</span>
          </Link>
          <nav className={styles.nav} aria-label="Головне меню">
            <button
              type="button"
              className={styles.mobileToggle}
              onClick={toggleMobile}
              aria-expanded={isMobileOpen}
              aria-controls="main-navigation"
            >
              <span className={styles.toggleBar} />
              <span className={styles.toggleBar} />
              <span className={styles.toggleBar} />
              <span className="visually-hidden">Меню</span>
            </button>
            <ul
              id="main-navigation"
              className={`${styles.navList} ${
                isMobileOpen ? styles.navListOpen : ''
              }`}
            >
              <li>
                <NavLink
                  to="/"
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  Головна
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/about"
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  Про нас
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/services"
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  Послуги
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/methodology"
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  Методика
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/contacts"
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  Контакти
                </NavLink>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;