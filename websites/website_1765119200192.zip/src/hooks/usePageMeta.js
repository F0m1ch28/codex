import { useEffect } from 'react';

const ensureMetaTag = (name) => {
  let tag = document.querySelector(`meta[name="${name}"]`);
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute('name', name);
    document.head.appendChild(tag);
  }
  return tag;
};

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    const previousTitle = document.title;
    const descriptionTag = ensureMetaTag('description');
    const keywordsTag = ensureMetaTag('keywords');
    const previousDescription = descriptionTag.getAttribute('content') || '';
    const previousKeywords = keywordsTag.getAttribute('content') || '';

    if (title) {
      document.title = title;
    }
    if (description) {
      descriptionTag.setAttribute('content', description);
    }
    if (keywords) {
      keywordsTag.setAttribute('content', keywords);
    }

    return () => {
      document.title = previousTitle;
      descriptionTag.setAttribute('content', previousDescription);
      keywordsTag.setAttribute('content', previousKeywords);
    };
  }, [title, description, keywords]);
};

export default usePageMeta;