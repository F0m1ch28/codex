import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './About.module.css';

const About = () => {
  usePageMeta({
    title: 'Про команду — Професійне дресирування собак',
    description:
      'Дізнайтеся про команду кінологів у Варшаві та Кракові: досвід, філософія, цінності та історія тренувального центру для німецьких вівчарок.',
    keywords:
      'про кінолога, команда дресирування, професіонали дресирування Варшава, кінолог Краків',
  });

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <div className="container">
          <h1>Про нас</h1>
          <p className={styles.lead}>
            «Професійне дресирування собак» — це команда кінологів, які
            об’єдналися для створення сучасного центру підготовки німецьких
            вівчарок. Ми переконані, що дисципліна, повага та емоційний зв’язок
            формують стабільну поведінку у будь-яких умовах.
          </p>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.valueGrid}>
            <div className={styles.valueCard}>
              <h3>Професіоналізм</h3>
              <p>
                Ми співпрацюємо з кінологічними асоціаціями Польщі та України,
                постійно оновлюємо знання і відвідуємо міжнародні семінари
                FCI/IGP.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Відповідальність</h3>
              <p>
                Безпека собаки та людини — наш пріоритет. Кожну програму
                адаптуємо до характеру собаки, враховуючи правові аспекти
                захисту.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Партнерство</h3>
              <p>
                Ми будуємо прозорі взаємини з власниками, пояснюємо методи,
                надаємо_feedback_ після кожного заняття та підтримуємо у
                повсякденних ситуаціях.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.storyGrid}>
            <img
              src="https://picsum.photos/800/600?random=13"
              alt="Команда кінологів під час тренування"
              className={styles.storyImage}
              loading="lazy"
            />
            <div>
              <h2>Як з’явилася наша школа</h2>
              <p>
                Ми почали як ініціатива тренерів з Варшави та Кракова, які
                помітили зростаючий запит на професійну підготовку вівчарок для
                міських умов. З часом сформувалася команда, котра об’єднала
                спортивних, службових та сімейних кінологів.
              </p>
              <p>
                Сьогодні ми ведемо програму менторства для молодих тренерів,
                беремо участь у змаганнях, підтримуємо волонтерські ініціативи
                та допомагаємо собакам-експертам у рятувальних підрозділах.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2>Наш шлях у датах</h2>
          <div className={styles.timelineList}>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2012</span>
              <p>Перші індивідуальні заняття з вівчарками у Варшаві.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2016</span>
              <p>Запуск програм спортивного дресирування та перші призові місця IGP.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2019</span>
              <p>Розширення команди, відкриття майданчика у Кракові.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2023</span>
              <p>Створення системи онлайн-підтримки для власників та молодих тренерів.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <h2>Лідери команди</h2>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/500/500?random=14"
                alt="Марія Мельник, головний тренер"
                loading="lazy"
              />
              <div>
                <h3>Марія Мельник</h3>
                <p className={styles.role}>Головний тренер</p>
                <ul>
                  <li>Майстер спорту з кінології, сертифікована FCI.</li>
                  <li>Працює з службовими собаками поліції Варшави.</li>
                  <li>Авторка програми «Управління драйвом вівчарки».</li>
                </ul>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/500/500?random=15"
                alt="Анджей Ковальський, кінолог"
                loading="lazy"
              />
              <div>
                <h3>Анджей Ковальський</h3>
                <p className={styles.role}>Кінолог, Краків</p>
                <ul>
                  <li>Спеціаліст з поведінкових корекцій та рятувальних собак.</li>
                  <li>Проводить семінари з безпечної соціалізації.</li>
                  <li>Розробив курс для собак-початківців у мегаполісі.</li>
                </ul>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img
                src="httpsum.photos/500/500?random=16"
                alt="Олег Гринь, тренер-методист"
                loading="lazy"
              />
              <div>
                <h3>Олег Гринь</h3>
                <p className={styles.role}>Тренер-методист</p>
                <ul>
                  <li>Автор методичних матеріалів зі структурованої мотивації.</li>
                  <li>Контролює якість програм у Варшаві та Кракові.</li>
                  <li>Проводить супервізії для молодших тренерів.</li>
                </ul>
              </div>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;