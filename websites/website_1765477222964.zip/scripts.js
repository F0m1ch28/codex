document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      document.body.classList.toggle('nav-open', isOpen);
    });
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const resourceItems = document.querySelectorAll('[data-category]');

  if (filterButtons.length && resourceItems.length) {
    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const filter = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove('is-active'));
        button.classList.add('is-active');
        resourceItems.forEach((item) => {
          const match = filter === 'all' || item.dataset.category === filter;
          item.hidden = !match;
        });
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('[data-cookie-accept]');
    const declineButton = cookieBanner.querySelector('[data-cookie-decline]');
    const consent = localStorage.getItem('cic_cookie_consent');

    if (consent) {
      cookieBanner.classList.add('is-hidden');
    } else {
      cookieBanner.classList.add('is-visible');
    }

    acceptButton?.addEventListener('click', () => {
      localStorage.setItem('cic_cookie_consent', 'accepted');
      cookieBanner.classList.remove('is-visible');
      cookieBanner.classList.add('is-hidden');
    });

    declineButton?.addEventListener('click', () => {
      localStorage.setItem('cic_cookie_consent', 'declined');
      cookieBanner.classList.remove('is-visible');
      cookieBanner.classList.add('is-hidden');
    });
  }
});