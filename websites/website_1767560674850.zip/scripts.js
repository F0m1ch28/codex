document.addEventListener('DOMContentLoaded', () => {
  const menuToggle = document.querySelector('.menu-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (menuToggle && siteNav) {
    menuToggle.addEventListener('click', () => {
      siteNav.classList.toggle('is-open');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const consentStatus = localStorage.getItem('cookieConsent');

  if (!consentStatus && cookieBanner) {
    cookieBanner.classList.remove('hidden');
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      localStorage.setItem('cookieConsent', 'accepted');
      if (cookieBanner) {
        cookieBanner.classList.add('hidden');
      }
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => {
      localStorage.setItem('cookieConsent', 'declined');
      if (cookieBanner) {
        cookieBanner.classList.add('hidden');
      }
    });
  }

  document.querySelectorAll('.filter-buttons').forEach(filterBlock => {
    const targetSelector = filterBlock.dataset.filterTarget;
    if (!targetSelector) return;

    const buttons = filterBlock.querySelectorAll('button[data-filter]');
    const items = document.querySelectorAll(targetSelector);

    buttons.forEach(button => {
      button.addEventListener('click', () => {
        const filter = button.dataset.filter;
        buttons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        items.forEach(item => {
          const categories = (item.dataset.category || '').split(' ');
          if (filter === 'all' || categories.includes(filter)) {
            item.classList.remove('is-hidden');
          } else {
            item.classList.add('is-hidden');
          }
        });
      });
    });
  });
});