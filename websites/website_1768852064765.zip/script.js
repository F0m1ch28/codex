document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.mobile-nav-toggle');
    const navigation = document.querySelector('.main-navigation');
    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const isVisible = navigation.getAttribute('data-visible') === 'true';
            navigation.setAttribute('data-visible', (!isVisible).toString());
            navToggle.setAttribute('aria-expanded', (!isVisible).toString());
        });
        document.addEventListener('click', (event) => {
            if (!navigation.contains(event.target) && !navToggle.contains(event.target)) {
                navigation.setAttribute('data-visible', 'false');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('myf-cookie-consent');
        if (!storedPreference) {
            cookieBanner.classList.add('show');
        }
        cookieBanner.addEventListener('click', (event) => {
            const target = event.target;
            if (target instanceof HTMLElement && target.dataset.cookieAction) {
                const action = target.dataset.cookieAction;
                localStorage.setItem('myf-cookie-consent', action);
                cookieBanner.classList.add('hide');
                setTimeout(() => {
                    cookieBanner.classList.remove('show', 'hide');
                    cookieBanner.classList.add('hidden');
                }, 250);
            }
        });
    }
});