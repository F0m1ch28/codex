const navToggle = document.getElementById("nav-toggle");
const nav = document.getElementById("site-nav");
const cookieBanner = document.getElementById("cookie-banner");
const cookieAccept = document.getElementById("cookie-accept");
const cookieDecline = document.getElementById("cookie-decline");
const COOKIE_STORAGE_KEY = "singulwyxq-cookie-preference";

if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
        nav.classList.toggle("open");
    });

    document.addEventListener("click", (event) => {
        if (!nav.contains(event.target) && !navToggle.contains(event.target)) {
            nav.classList.remove("open");
        }
    });
}

const handleCookieDecision = (value) => {
    localStorage.setItem(COOKIE_STORAGE_KEY, value);
    if (cookieBanner) {
        cookieBanner.classList.add("hidden");
    }
};

if (cookieAccept) {
    cookieAccept.addEventListener("click", () => handleCookieDecision("accepted"));
}

if (cookieDecline) {
    cookieDecline.addEventListener("click", () => handleCookieDecision("declined"));
}

const savedPreference = localStorage.getItem(COOKIE_STORAGE_KEY);
if (cookieBanner) {
    if (savedPreference === "accepted" || savedPreference === "declined") {
        cookieBanner.classList.add("hidden");
    } else {
        cookieBanner.classList.remove("hidden");
    }
}