import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Политика cookies — ТехноПрофи</title>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Политика использования файлов cookies</h1>
          <p>
            Объясняем, какие cookies мы применяем на сайте, для чего они нужны и как вы можете управлять своими настройками.
          </p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article className={styles.article}>
            <h2>1. Что такое cookies</h2>
            <p>
              Cookies — это небольшие файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают
              повысить удобство пользования и позволяют анализировать работу сайта.
            </p>
            <h2>2. Виды используемых cookies</h2>
            <ul>
              <li>Обязательные — обеспечивают корректную работу основных функций сайта;</li>
              <li>Аналитические — помогают нам понимать, как пользователи взаимодействуют с сайтом;</li>
              <li>Функциональные — запоминают ваши предпочтения и настройки.</li>
            </ul>
            <h2>3. Управление cookies</h2>
            <p>
              Вы можете настроить использование cookies в своем браузере. Ограничение cookies может повлиять на
              корректность работы отдельных функций сайта.
            </p>
            <h2>4. Контакты</h2>
            <p>По вопросам использования cookies обращайтесь на email <a href="mailto:info@technoprofi.ru">info@technoprofi.ru</a>.</p>
          </article>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;