import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Инжиниринговое обследование',
    description:
      'Подробный аудит производственных процессов, оборудования и IT-инфраструктуры с подготовкой дорожной карты модернизации.',
    items: ['Технический аудит', 'Анализ узких мест', 'Экономическая эффективность', 'План-график внедрения'],
    icon: 'https://picsum.photos/80/80?random=81'
  },
  {
    title: 'Проектирование и интеграция',
    description:
      'Разработка проектной и рабочей документации, подбор оборудования, интеграция систем управления и автоматизации.',
    items: ['Проектирование линий', '3D моделирование', 'Интеграция MES/SCADA', 'Системы безопасности'],
    icon: 'https://picsum.photos/80/80?random=82'
  },
  {
    title: 'Поставка оборудования',
    description:
      'Комплексная логистика, таможенное оформление, шеф-монтаж и пуско-наладка. Работаем с поставщиками из Европы, Азии и России.',
    items: ['Логистика', 'Монтаж', 'Пуско-наладка', 'Сертификация'],
    icon: 'https://picsum.photos/80/80?random=83'
  },
  {
    title: 'Сервис и поддержка',
    description:
      'Плановое и аварийное обслуживание, гарантийные обязательства, обучение операторов и технического персонала.',
    items: ['Сервисные контракты', 'Удаленный мониторинг', 'Запасные части', 'Обучение'],
    icon: 'https://picsum.photos/80/80?random=84'
  }
];

const advantages = [
  { title: 'Выделенный менеджер', text: 'Каждый проект ведёт персональный менеджер, который координирует все команды.' },
  { title: 'Внедрение по стандартам', text: 'Соблюдаем международные стандарты и регламенты безопасностии качества.' },
  { title: 'Гибкие модели сотрудничества', text: 'Работаем по EPC, EPCM, а также по сервисным контрактам с SLA.' },
  { title: 'Экосистема партнёров', text: 'Сотрудничаем с 40+ производителями, что позволяет подобрать оптимальное решение.' }
];

function Services() {
  return (
    <>
      <Helmet>
        <title>Услуги компании ТехноПрофи</title>
        <meta
          name="description"
          content="Инжиниринг, автоматизация, поставка и сервис промышленного оборудования. Комплексные услуги компании ТехноПрофи."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Комплексные услуги для современного производства</h1>
          <p>
            Мы сопровождаем клиентов на каждом этапе модернизации: от диагностики и проектирования до внедрения и
            последующей поддержки. Такой подход гарантирует предсказуемый результат и устойчивый рост эффективности.
          </p>
        </div>
      </section>

      <section className={styles.serviceList}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <div className={styles.iconWrap}>
                  <img src={service.icon} alt={service.title} loading="lazy" />
                </div>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className="container">
          <h2 className="sectionTitle">Преимущества сотрудничества</h2>
          <div className={styles.advantageGrid}>
            {advantages.map((advantage) => (
              <div key={advantage.title} className={styles.advantageCard}>
                <h3>{advantage.title}</h3>
                <p>{advantage.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;