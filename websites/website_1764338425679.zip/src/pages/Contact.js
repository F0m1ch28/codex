import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

function Contact() {
  const [formData, setFormData] = useState({ name: '', company: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Укажите ваше имя.';
    }
    if (!formData.company.trim()) {
      newErrors.company = 'Укажите компанию.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Проверьте корректность email.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Коротко опишите задачу.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setIsSubmitted(true);
    setFormData({ name: '', company: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Контакты ТехноПрофи</title>
        <meta
          name="description"
          content="Свяжитесь с компанией ТехноПрофи: консультации по промышленному оборудованию, автоматизации и сервисному сопровождению."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Контакты</h1>
          <p>Свяжитесь с нами, чтобы обсудить проект модернизации или получить консультацию технического эксперта.</p>
        </div>
      </section>

      <section className={styles.contactInfo}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Офис в Москве</h2>
              <p>г. Москва, ул. Промышленная, д. 15, офис 304</p>
              <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              <a href="mailto:info@technoprofi.ru">info@technoprofi.ru</a>
            </div>
            <div className={styles.formCard}>
              <h2>Напишите нам</h2>
              {isSubmitted && <div className={styles.success}>Спасибо! Мы свяжемся с вами в ближайшее время.</div>}
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label htmlFor="name">
                  Имя*
                  <input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                    required
                  />
                  {errors.name && (
                    <span id="name-error" className={styles.error}>
                      {errors.name}
                    </span>
                  )}
                </label>
                <label htmlFor="company">
                  Компания*
                  <input
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.company)}
                    aria-describedby={errors.company ? 'company-error' : undefined}
                    required
                  />
                  {errors.company && (
                    <span id="company-error" className={styles.error}>
                      {errors.company}
                    </span>
                  )}
                </label>
                <label htmlFor="email">
                  Email*
                  <input
                    id="email"
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                    required
                  />
                  {errors.email && (
                    <span id="email-error" className={styles.error}>
                      {errors.email}
                    </span>
                  )}
                </label>
                <label htmlFor="message">
                  Комментарий*
                  <textarea
                    id="message"
                    name="message"
                    rows="4"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                    required
                  />
                  {errors.message && (
                    <span id="message-error" className={styles.error}>
                      {errors.message}
                    </span>
                  )}
                </label>
                <button type="submit" className="btnPrimary">
                  Отправить заявку
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;