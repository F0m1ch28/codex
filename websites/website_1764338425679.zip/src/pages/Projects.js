import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Projects.module.css';

const projects = [
  {
    title: 'Автоматизация сварочного производства',
    sector: 'Металлургия',
    result: 'Сокращение времени цикла на 28%, уменьшение брака на 40%.',
    tags: ['Автоматизация', 'Роботы'],
    image: 'https://picsum.photos/1200/800?random=91'
  },
  {
    title: 'Цифровая диспетчеризация металлургического комбината',
    sector: 'Металлургия',
    result: 'Прозрачность загрузки агрегатов, снижение простоев на 22%.',
    tags: ['Цифровизация', 'MES'],
    image: 'https://picsum.photos/1200/800?random=92'
  },
  {
    title: 'Модернизация деревообрабатывающего комплекса',
    sector: 'ЛПК',
    result: 'Повышение производительности на 35%, экономия энергоресурсов 15%.',
    tags: ['Станки', 'Инжиниринг'],
    image: 'httpsum.photos/1200/800?random=93'
  },
  {
    title: 'Роботизация линии упаковки пищевой продукции',
    sector: 'Пищевая промышленность',
    result: 'Рост пропускной способности на 42%, синхронизация с ERP.',
    tags: ['Автоматизация', 'IIoT'],
    image: 'https://picsum.photos/1200/800?random=94'
  }
];

const sectors = ['Все отрасли', 'Металлургия', 'ЛПК', 'Пищевая промышленность'];

function Projects() {
  const [activeSector, setActiveSector] = useState('Все отрасли');

  const filteredProjects = useMemo(() => {
    if (activeSector === 'Все отрасли') {
      return projects;
    }
    return projects.filter((project) => project.sector === activeSector);
  }, [activeSector]);

  return (
    <>
      <Helmet>
        <title>Проекты компании ТехноПрофи</title>
        <meta
          name="description"
          content="Портфолио проектов ТехноПрофи: автоматизация, роботизация, цифровизация производства для предприятий России и СНГ."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Реализованные проекты</h1>
          <p>Каждый кейс — это измеримый результат для клиента. Мы внедряем решения, которые повышают эффективность и устойчивость производства.</p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className="container">
          <div className={styles.filterButtons}>
            {sectors.map((sector) => (
              <button
                key={sector}
                type="button"
                onClick={() => setActiveSector(sector)}
                className={`${styles.filterButton} ${activeSector === sector ? styles.filterButtonActive : ''}`}
              >
                {sector}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectList}>
        <div className="container">
          <div className={styles.grid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.card}>
                <div className={styles.imageWrap}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.content}>
                  <span className={styles.sector}>{project.sector}</span>
                  <h2>{project.title}</h2>
                  <p>{project.result}</p>
                  <div className={styles.tagList}>
                    {project.tags.map((tag) => (
                      <span key={tag} className={styles.tag}>
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Projects;