import React, { useMemo, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'лет опыта на рынке', value: 18 },
  { label: 'производственных проектов', value: 240 },
  { label: 'сервисных инженеров', value: 45 },
  { label: 'городов присутствия в СНГ', value: 12 }
];

const servicesData = [
  {
    title: 'Поставка станков и линий',
    description: 'Выбор, комплектация и логистика станков с числовым программным управлением и роботизированных линий.',
    icon: '🛠️'
  },
  {
    title: 'Инжиниринговый аудит',
    description: 'Техническая диагностика производства, анализ узких мест и подготовка рекомендаций по модернизации.',
    icon: '🔍'
  },
  {
    title: 'Автоматизация и цифровизация',
    description: 'Интеграция MES/SCADA, внедрение датчиков IIoT, построение цифровых двойников и аналитики.',
    icon: '⚙️'
  },
  {
    title: 'Сервис и обучение',
    description: 'Пуско-наладка, регламентное обслуживание, обучение персонала и круглосуточная поддержка.',
    icon: '🎯'
  }
];

const processSteps = [
  { title: 'Диагностика и проектирование', text: 'Сбор исходных данных, обследование производства и моделирование оптимальных решений.', number: '01' },
  { title: 'Комплектация и поставка', text: 'Подбор оборудования, координация поставок и таможенного оформления, соблюдение графиков.', number: '02' },
  { title: 'Интеграция и запуск', text: 'Монтаж, пуско-наладка, адаптация систем управления, тестирование в реальных условиях.', number: '03' },
  { title: 'Поддержка и развитие', text: 'Сервисные контракты, обучение персонала, аналитика эффективности и масштабирование решений.', number: '04' }
];

const testimonials = [
  {
    text: 'ТехноПрофи реализовали комплексную модернизацию нашего механообрабатывающего участка. Производительность выросла на 32%, простоев стало заметно меньше.',
    author: 'Анна Крылова',
    role: 'Генеральный директор, Завод «Северстальмаш»'
  },
  {
    text: 'Команда чётко соблюла сроки поставки оборудования и взяла на себя сложную интеграцию MES. Сейчас мы видим реальную картину загрузки в режиме реального времени.',
    author: 'Игорь Самойлов',
    role: 'Технический директор, «ВостокАвтоКомплект»'
  },
  {
    text: 'Отдельное спасибо за обучение операторов и сервисную поддержку. Уровень компетенций engineers впечатляет.',
    author: 'Мария Громова',
    role: 'Руководитель производства, «СибПром»'
  }
];

const teamMembers = [
  {
    name: 'Евгений Соловьёв',
    role: 'Директор по развитию',
    bio: '15 лет внедряет цифровые решения на машиностроительных предприятиях.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Надежда Зайцева',
    role: 'Руководитель инженерного отдела',
    bio: 'Специалист по автоматизации, курирует интеграцию MES и SCADA.',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Александр Плотников',
    role: 'Главный сервисный инженер',
    bio: 'Отвечает за пуско-наладку и поддерживает клиентов 24/7.',
    image: 'https://picsum.photos/400/400?random=33'
  }
];

const projectsData = [
  {
    id: 1,
    title: 'Роботизированная линия сварки',
    category: 'Автоматизация',
    description: 'Комплекс из шести сварочных постов с промышленными роботами и системой контроля качества.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    id: 2,
    title: 'Модернизация механообработки',
    category: 'Станки',
    description: 'Поставка пятиосевых обрабатывающих центров и интеграция с ERP.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    id: 3,
    title: 'Цифровой диспетчерский центр',
    category: 'Цифровизация',
    description: 'Внедрение SCADA и аналитической платформы для металлургического комбината.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    id: 4,
    title: 'Линия упаковки пищевой продукции',
    category: 'Автоматизация',
    description: 'Автоматизация упаковки и маркировки с использованием машинного зрения.',
    image: 'https://picsum.photos/1200/800?random=44'
  }
];

const faqs = [
  {
    question: 'Какие отрасли вы обслуживаете?',
    answer: 'Мы работаем с машиностроением, металлургией, химической, пищевой и фармацевтической промышленностью, а также с предприятиями ТЭК.'
  },
  {
    question: 'Сколько времени занимает внедрение?',
    answer: 'Сроки зависят от масштаба проекта. Аудит и проектирование занимают 2-6 недель, поставка и запуск — от 3 до 9 месяцев.'
  },
  {
    question: 'Предоставляете ли вы сервисное обслуживание?',
    answer: 'Да, мы предлагаем регламентный сервис, аварийные выезды, дистанционный мониторинг и обучение персонала.'
  },
  {
    question: 'Можно ли интегрировать новое оборудование с существующими системами?',
    answer: 'Мы разрабатываем адаптеры и используем открытые протоколы обмена, что позволяет интегрировать решения с ERP, MES и другими ИТ-системами.'
  }
];

const blogPosts = [
  {
    title: 'Как подготовить производство к цифровой трансформации',
    excerpt: 'Пять практических шагов для оценки зрелости предприятия и запуска пилотных проектов IoT.',
    date: '15 января 2024',
    image: 'https://picsum.photos/800/600?random=51'
  },
  {
    title: 'Тренды роботизации в 2024 году',
    excerpt: 'Рассказываем о коллаборативных роботах, гибких ячейках и ключевых драйверах эффективности.',
    date: '05 февраля 2024',
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    title: 'Пять ошибок при модернизации цеха',
    excerpt: 'Избегаем типичных просчетов при переходе на высокоточное оборудование и автоматизацию.',
    date: '22 февраля 2024',
    image: 'https://picsum.photos/800/600?random=53'
  }
];

const products = [
  {
    title: 'Обрабатывающие центры',
    features: ['5-осевая обработка', 'Привод с ЧПУ Siemens', 'Система автоматической смены инструмента'],
    image: 'https://picsum.photos/800/600?random=61'
  },
  {
    title: 'Роботизированные комплексы',
    features: ['Коллаборативные и промышленные роботы', 'Интеграция с датчиками зрения', 'Гибкая конфигурация'],
    image: 'https://picsum.photos/800/600?random=62'
  },
  {
    title: 'Системы контроля качества',
    features: ['Машинное зрение', 'Неразрушающий контроль', 'Сбор и аналитика данных'],
    image: 'https://picsum.photos/800/600?random=63'
  }
];

function Home() {
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Все');
  const [openFaq, setOpenFaq] = useState(faqs[0].question);

  useEffect(() => {
    let animationFrame;
    let startTimestamp = null;

    const duration = 1800;

    const animateCounts = (timestamp) => {
      if (!startTimestamp) {
        startTimestamp = timestamp;
      }
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      setCounts(statsData.map((stat) => Math.round(stat.value * progress)));
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animateCounts);
      }
    };

    animationFrame = requestAnimationFrame(animateCounts);

    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const elements = document.querySelectorAll('[data-reveal]');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.visible);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Все') {
      return projectsData;
    }
    return projectsData.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>ТехноПрофи — решения для современного производства</title>
        <meta
          name="description"
          content="ТехноПрофи поставляет промышленное оборудование, автоматизирует производства и обеспечивает полный сервисный цикл по всей России и СНГ."
        />
      </Helmet>
      <section className={styles.hero} data-reveal>
        <div className={styles.heroOverlay} />
        <img
          src="https://picsum.photos/1600/900?random=11"
          alt="Современный промышленный комплекс"
          className={styles.heroImage}
          loading="lazy"
        />
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.heroBadge}>#1 в комплексных поставках оборудования</p>
            <h1 className={styles.heroTitle}>
              Промышленное оборудование и автоматизация, которые ускоряют рост вашего производства
            </h1>
            <p className={styles.heroText}>
              Помогаем предприятиям России и стран СНГ внедрять высокоточные станки, роботизированные комплексы и
              цифровые платформы для устойчивого развития.
            </p>
            <div className={styles.heroActions}>
              <Link to="/catalog" className="btnPrimary">
                Смотреть каталог
              </Link>
              <Link to="/contacts" className="btnSecondary">
                Связаться с экспертом
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.about} data-reveal>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div>
              <h2 className="sectionTitle">ТехноПрофи в двух словах</h2>
              <p className={styles.aboutText}>
                Мы — команда инженеров, аналитиков и проектных менеджеров, которая уже 18 лет внедряет эффективные
                решения на заводах и фабриках по всей стране. Наша экспертиза охватывает полный цикл: от аудита и выбора
                оборудования до обучения персонала и сопровождения эксплуатации.
              </p>
              <ul className={styles.aboutList}>
                <li>Собственный склад и сервисные инженеры в 12 регионах</li>
                <li>Партнерства с ведущими мировыми и российскими производителями</li>
                <li>Фокус на эффективности и прозрачности внедрения</li>
              </ul>
            </div>
            <div className={styles.statsCard}>
              {statsData.map((stat, index) => (
                <div key={stat.label} className={styles.statItem}>
                  <span className={styles.statValue}>
                    {counts[index]}
                    {stat.label === 'лет опыта на рынке' ? '+' : ''}
                  </span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services} data-reveal id="services">
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Ключевые услуги</h2>
            <p className={styles.sectionSubtitle}>
              Подбираем оптимальные технологии и берём на себя все этапы — от концепции до запуска и поддержки.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <div key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon}>{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.serviceLink} aria-label={`Подробнее об услуге ${service.title}`}>
                  Подробнее →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process} data-reveal>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Как мы работаем</h2>
            <p className={styles.sectionSubtitle}>
              От первого контакта до долгосрочного сопровождения — единая команда и прозрачная методология.
            </p>
          </div>
          <div className={styles.processTimeline}>
            {processSteps.map((step) => (
              <div key={step.title} className={styles.processCard}>
                <span className={styles.processNumber}>{step.number}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.products} data-reveal>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Популярное оборудование</h2>
            <p className={styles.sectionSubtitle}>
              Актуальные решения, которые доказали эффективность на промышленных площадках наших клиентов.
            </p>
          </div>
          <div className={styles.productGrid}>
            {products.map((product) => (
              <article key={product.title} className={styles.productCard}>
                <div className={styles.productImageWrap}>
                  <img src={product.image} alt={product.title} loading="lazy" />
                </div>
                <div className={styles.productContent}>
                  <h3>{product.title}</h3>
                  <ul>
                    {product.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                  <Link to="/catalog" className={styles.productLink}>
                    Подробнее в каталоге →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} data-reveal>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Реализованные проекты</h2>
            <p className={styles.sectionSubtitle}>
              Запускаем решения на предприятиях различного масштаба и отраслей, фокусируясь на измеримых показателях.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Фильтр проектов">
            {['Все', 'Автоматизация', 'Станки', 'Цифровизация'].map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterButtonActive : ''
                }`}
                role="tab"
                aria-selected={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrap}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/projects" className={styles.projectLink}>
                    Подробнее о кейсе →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials} data-reveal>
        <div className="container">
          <div className={styles.sectionHeadAlt}>
            <h2 className="sectionTitle">Отзывы клиентов</h2>
            <p className={styles.sectionSubtitle}>
              Нам доверяют лидеры отрасли. Каждый проект сопровождаем вплоть до достижения целевых показателей эффективности.
            </p>
          </div>
          <div className={styles.testimonialSlider}>
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.author}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialCardActive : ''
                }`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialText}>“{testimonial.text}”</p>
                <div className={styles.testimonialAuthor}>
                  <span className={styles.testimonialName}>{testimonial.author}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </div>
              </div>
            ))}
            <div className={styles.testimonialDots} role="tablist" aria-label="Переключение отзывов">
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.author}
                  type="button"
                  className={`${styles.testimonialDot} ${
                    index === activeTestimonial ? styles.testimonialDotActive : ''
                  }`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Показать отзыв ${testimonial.author}`}
                  aria-selected={index === activeTestimonial}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team} data-reveal>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Команда экспертов</h2>
            <p className={styles.sectionSubtitle}>
              За каждым проектом стоит команда инженеров, проектировщиков и аналитиков, готовых поддержать вас на каждом этапе.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrap}>
                  <img src={member.image} alt={member.name} loading="lazy" />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq} data-reveal>
        <div className="container">
          <div className={styles.sectionHeadAlt}>
            <h2 className="sectionTitle">Часто задаваемые вопросы</h2>
            <p className={styles.sectionSubtitle}>
              Если вы не нашли ответ на свой вопрос, напишите нам — и команда быстро свяжется с вами.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqs.map((item) => {
              const isOpen = openFaq === item.question;
              return (
                <div key={item.question} className={`${styles.faqItem} ${isOpen ? styles.faqItemOpen : ''}`}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => setOpenFaq(isOpen ? '' : item.question)}
                    aria-expanded={isOpen}
                  >
                    <span>{item.question}</span>
                    <span className={styles.faqIcon}>{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && <p className={styles.faqAnswer}>{item.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blog} data-reveal>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Экспертиза и аналитика</h2>
            <p className={styles.sectionSubtitle}>
              Делимся практическими материалами о модернизации и автоматизации производств.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrap}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/about" className={styles.blogLink}>
                    Читать далее →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta} data-reveal>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Готовы обсудить модернизацию вашего производства?</h2>
            <p>
              Оставьте заявку, и наш эксперт подготовит для вас персональную дорожную карту внедрения оборудования и
              автоматизации.
            </p>
            <Link to="/contacts" className="btnPrimary">
              Запросить консультацию
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.contactSection} data-reveal>
        <div className="container">
          <div className={styles.contactCard}>
            <h2>Контактная информация</h2>
            <p>
              г. Москва, ул. Промышленная, д. 15, офис 304 <br /> Тел.: <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              <br />
              Email: <a href="mailto:info@technoprofi.ru">info@technoprofi.ru</a>
            </p>
            <Link to="/contacts" className={styles.contactLink}>
              Все контакты →
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;