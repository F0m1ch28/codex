import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Catalog.module.css';

const categories = [
  {
    name: 'Металлообработка',
    description: 'Высокоточные токарные и фрезерные центры, гибридные станки, шлифовальные комплексы.',
    features: ['До 5 осей обработки', 'Автоматическая смена инструмента', 'ЧПУ Fanuc, Siemens, Heidenhain'],
    image: 'https://picsum.photos/800/600?random=71'
  },
  {
    name: 'Роботизация',
    description: 'Роботы-манипуляторы, коллаборативные роботы и готовые ячейки для сварки, паллетирования, сборки.',
    features: ['Интеграция с системами зрения', 'Гибкие сценарии работы', 'Сертификация по безопасности'],
    image: 'https://picsum.photos/800/600?random=72'
  },
  {
    name: 'Автоматические линии',
    description: 'Комплексные линии упаковки, транспортировки и контроля качества.',
    features: ['Гибкая производительность', 'Интеллектуальные сенсоры', 'Прозрачная диагностика'],
    image: 'https://picsum.photos/800/600?random=73'
  },
  {
    name: 'Контроль и измерения',
    description: 'Системы визуального контроля, 3D-сканеры, координатно-измерительные машины.',
    features: ['Точность до 0.002 мм', 'Модульность', 'Интеграция с PLM'],
    image: 'https://picsum.photos/800/600?random=74'
  }
];

const filters = ['Все', 'Металлообработка', 'Роботизация', 'Автоматизация', 'Контроль'];

const highlightItems = [
  { title: 'Энергоэффективные решения', text: 'Оптимизируем энергопотребление за счёт умных приводов и рекуперации.' },
  { title: 'Гибкая логистика', text: 'Доставка оборудования по России и СНГ собственным транспортом и через доверенных перевозчиков.' },
  { title: 'Демо-залы и тестирование', text: 'Организуем тесты на производственных площадках партнеров или в нашем демо-центре.' }
];

function Catalog() {
  const [activeFilter, setActiveFilter] = useState('Все');

  const filteredCategories = useMemo(() => {
    if (activeFilter === 'Все') {
      return categories;
    }
    return categories.filter((category) => category.name === activeFilter || (activeFilter === 'Автоматизация' && category.name === 'Автоматические линии') || (activeFilter === 'Контроль' && category.name === 'Контроль и измерения'));
  }, [activeFilter]);

  return (
    <>
      <Helmet>
        <title>Каталог оборудования — ТехноПрофи</title>
        <meta
          name="description"
          content="Каталог промышленного оборудования ТехноПрофи: металлообрабатывающие станки, роботизированные комплексы, автоматические линии и системы контроля."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Каталог промышленного оборудования</h1>
          <p>
            Подбираем оптимальные решения под задачи производства. Каждое оборудование адаптируем под стандарты предприятия
            и обеспечиваем пуско-наладку, обучение персонала и сервисное сопровождение.
          </p>
        </div>
      </section>
      <section className={styles.filters}>
        <div className="container">
          <div className={styles.filterButtons}>
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterButtonActive : ''}`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.catalogList}>
        <div className="container">
          <div className={styles.grid}>
            {filteredCategories.map((category) => (
              <article key={category.name} className={styles.card}>
                <div className={styles.cardImage}>
                  <img src={category.image} alt={category.name} loading="lazy" />
                </div>
                <div className={styles.cardContent}>
                  <h2>{category.name}</h2>
                  <p>{category.description}</p>
                  <ul>
                    {category.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.highlights}>
        <div className="container">
          <h2 className="sectionTitle">Почему выбирают наш каталог</h2>
          <div className={styles.highlightGrid}>
            {highlightItems.map((item) => (
              <div key={item.title} className={styles.highlightCard}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Catalog;