import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-labelledby="footer-title">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <h2 id="footer-title" className={styles.brandTitle}>
              ТехноПрофи
            </h2>
            <p className={styles.brandText}>
              Комплексные решения для промышленного производства: от поставки станков до внедрения цифровых систем
              управления и сервисного сопровождения.
            </p>
            <div className={styles.contactBlock}>
              <a href="tel:+74951234567" className={styles.contactLink}>
                +7 (495) 123-45-67
              </a>
              <a href="mailto:info@technoprofi.ru" className={styles.contactLink}>
                info@technoprofi.ru
              </a>
              <p className={styles.address}>г. Москва, ул. Промышленная, д. 15, офис 304</p>
            </div>
          </div>
          <div className={styles.links}>
            <h3 className={styles.columnTitle}>Навигация</h3>
            <ul className={styles.linkList}>
              <li>
                <NavLink to="/about" className={styles.link}>
                  О компании
                </NavLink>
              </li>
              <li>
                <NavLink to="/catalog" className={styles.link}>
                  Каталог оборудования
                </NavLink>
              </li>
              <li>
                <NavLink to="/services" className={styles.link}>
                  Услуги
                </NavLink>
              </li>
              <li>
                <NavLink to="/projects" className={styles.link}>
                  Реализованные проекты
                </NavLink>
              </li>
              <li>
                <NavLink to="/contacts" className={styles.link}>
                  Контакты
                </NavLink>
              </li>
            </ul>
          </div>
          <div className={styles.resources}>
            <h3 className={styles.columnTitle}>Документы</h3>
            <ul className={styles.linkList}>
              <li>
                <NavLink to="/privacy" className={styles.link}>
                  Политика конфиденциальности
                </NavLink>
              </li>
              <li>
                <NavLink to="/terms" className={styles.link}>
                  Условия использования
                </NavLink>
              </li>
              <li>
                <NavLink to="/cookie-policy" className={styles.link}>
                  Политика cookies
                </NavLink>
              </li>
            </ul>
            <div className={styles.badges}>
              <span className={styles.badge}>ISO 9001</span>
              <span className={styles.badge}>Сертифицированный партнер</span>
            </div>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} ТехноПрофи. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;