import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSticky, setIsSticky] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setIsSticky(window.scrollY > 10);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  }, [isMenuOpen]);

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={`${styles.header} ${isSticky ? styles.headerSticky : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu}>
            <span className={styles.logoMark}>ТП</span>
            <span className={styles.logoText}>ТехноПрофи</span>
          </NavLink>
          <button
            type="button"
            className={`${styles.menuToggle} ${isMenuOpen ? styles.menuToggleActive : ''}`}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
          >
            <span />
            <span />
            <span />
          </button>
          <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Главная навигация">
            <ul className={styles.navList}>
              <li>
                <NavLink
                  to="/"
                  onClick={closeMenu}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.navLinkActive}` : styles.navLink)}
                >
                  Главная
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/about"
                  onClick={closeMenu}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.navLinkActive}` : styles.navLink)}
                >
                  О компании
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/catalog"
                  onClick={closeMenu}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.navLinkActive}` : styles.navLink)}
                >
                  Каталог
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/services"
                  onClick={closeMenu}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.navLinkActive}` : styles.navLink)}
                >
                  Услуги
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/projects"
                  onClick={closeMenu}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.navLinkActive}` : styles.navLink)}
                >
                  Проекты
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/contacts"
                  onClick={closeMenu}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.navLinkActive}` : styles.navLink)}
                >
                  Контакты
                </NavLink>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;