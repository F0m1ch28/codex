import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'technoprofi_cookie_consent';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Мы используем cookies и сервисы аналитики, чтобы улучшить взаимодействие с сайтом. Продолжая пользование сайтом,
        вы соглашаетесь с{' '}
        <a href="/cookie-policy" className={styles.link}>
          политикой cookies
        </a>
        .
      </p>
      <button type="button" className={styles.button} onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
}

export default CookieBanner;