document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("nav");
  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieAccept = document.querySelector("#cookie-aceptar");
  const cookieDecline = document.querySelector("#cookie-rechazar");
  const consentKey = "monteravelliumCookieConsent";
  const bodyPage = document.body.dataset.page;

  if (navToggle) {
    navToggle.addEventListener("click", () => {
      nav.classList.toggle("visible");
    });
  }

  if (bodyPage) {
    const enlaceActivo = document.querySelector(`nav a[data-page="${bodyPage}"]`);
    if (enlaceActivo) {
      enlaceActivo.classList.add("activo");
    }
  }

  if (cookieBanner) {
    const consentimientoGuardado = localStorage.getItem(consentKey);
    if (consentimientoGuardado) {
      cookieBanner.classList.add("cookie-oculta");
    }

    cookieAccept?.addEventListener("click", () => {
      localStorage.setItem(consentKey, "aceptado");
      cookieBanner.classList.add("cookie-oculta");
    });

    cookieDecline?.addEventListener("click", () => {
      localStorage.setItem(consentKey, "rechazado");
      cookieBanner.classList.add("cookie-oculta");
    });
  }
});