document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('is-open');
    });

    primaryNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (primaryNav.classList.contains('is-open')) {
          primaryNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieButtons = document.querySelectorAll('.cookie-banner .cookie-btn');

  if (cookieBanner) {
    const consentValue = localStorage.getItem('tttCookieConsent');
    if (consentValue === 'accepted' || consentValue === 'declined') {
      cookieBanner.classList.add('is-hidden');
    }

    cookieButtons.forEach(function (button) {
      button.addEventListener('click', function (event) {
        event.preventDefault();
        const action = button.classList.contains('accept') ? 'accepted' : 'declined';
        localStorage.setItem('tttCookieConsent', action);
        cookieBanner.classList.add('is-hidden');
      });
    });
  }
});