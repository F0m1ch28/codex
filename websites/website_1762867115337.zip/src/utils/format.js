export const formatCurrency = (value) =>
  new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0
  }).format(value);

export const formatDate = (date) =>
  new Intl.DateTimeFormat('de-DE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(new Date(date));

export const formatMonth = (month) =>
  new Intl.DateTimeFormat('de-DE', {
    year: 'numeric',
    month: 'short'
  }).format(new Date(`${month}-01`));