import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';

const navItems = [
  { to: '/', label: 'Home' },
  { to: '/reviews', label: 'Reviews' },
  { to: '/early', label: 'Early Access' },
  { to: '/deals', label: 'Deals' },
  { to: '/compare', label: 'Vergleich' },
  { to: '/guide', label: 'Guide' },
  { to: '/news', label: 'News' },
  { to: '/services', label: 'Services' },
  { to: '/about', label: 'Über uns' },
  { to: '/faq', label: 'FAQ' },
  { to: '/contact', label: 'Kontakt' }
];

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-50 bg-mist/90 shadow-sm backdrop-blur-md dark:bg-slateNight/90">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4">
          <NavLink
            to="/"
            className="flex items-center gap-2 text-slateNight dark:text-cloud"
            aria-label="Slexorifyx Startseite"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slateNight text-xl font-extrabold text-mist shadow-md dark:bg-mist dark:text-slateNight">
              Sx
            </span>
            <span className="font-display text-xl font-bold tracking-tight">
              Slexorifyx
            </span>
          </NavLink>
        </div>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Hauptnavigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `rounded-full px-4 py-2 text-sm font-medium transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 focus-visible:ring-offset-mist dark:focus-visible:ring-offset-slateNight ${
                  isActive
                    ? 'bg-slateNight text-mist dark:bg-mist dark:text-slateNight'
                    : 'text-slateNight hover:bg-cloud/80 hover:text-slateNight dark:text-cloud dark:hover:bg-slate-700/40'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            type="button"
            className="rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slateNight shadow-sm transition hover:bg-cloud focus:outline-none focus-visible:ring-2 focus-visible:ring-aquaPulse focus-visible:ring-offset-2 dark:border-slate-600 dark:bg-slate-800 dark:text-cloud dark:hover:bg-slate-700"
            aria-label="Darstellung umschalten"
          >
            {theme === 'dark' ? '☀️ Hell' : '🌙 Dunkel'}
          </button>
          <button
            type="button"
            onClick={() => setIsOpen((prev) => !prev)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slateNight transition hover:bg-cloud focus:outline-none focus-visible:ring-2 focus-visible:ring-aquaPulse focus-visible:ring-offset-2 dark:border-slate-600 dark:bg-slate-800 dark:text-cloud lg:hidden"
            aria-expanded={isOpen}
            aria-controls="mobile-menu"
            aria-label="Menü öffnen"
          >
            <span className="text-lg">{isOpen ? '✕' : '☰'}</span>
          </button>
        </div>
      </div>

      <div
        id="mobile-menu"
        className={`border-t border-cloud/60 bg-mist/95 backdrop-blur dark:border-slate-700 dark:bg-slateNight/95 lg:hidden ${
          isOpen ? 'block' : 'hidden'
        }`}
      >
        <nav className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-4 sm:px-6" aria-label="Mobile Navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setIsOpen(false)}
              className={({ isActive }) =>
                `rounded-xl px-4 py-3 text-base font-semibold transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-aquaPulse focus-visible:ring-offset-2 focus-visible:ring-offset-mist dark:focus-visible:ring-offset-slateNight ${
                  isActive
                    ? 'bg-slateNight text-mist dark:bg-mist dark:text-slateNight'
                    : 'text-slateNight hover:bg-cloud/90 dark:text-cloud dark:hover:bg-slate-700/60'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;