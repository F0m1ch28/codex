import React from 'react';
import { formatMonth } from '../utils/format';

const PriceTrend = ({ data }) => {
  if (!data || data.length === 0) return null;
  const max = Math.max(...data.map((point) => point.uvp));
  const min = Math.min(...data.map((point) => point.street));

  const getY = (value) => {
    const range = max - min || 1;
    return 180 - ((value - min) / range) * 160;
  };

  const getX = (index) => 40 + (index * 220) / (data.length - 1 || 1);

  return (
    <div className="rounded-2xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
      <div className="flex items-center justify-between">
        <h4 className="font-display text-lg font-semibold text-slateNight dark:text-cloud">
          Preisverlauf
        </h4>
        <span className="text-xs font-semibold uppercase text-slate-500 dark:text-slate-300">
          UVP vs. Straße
        </span>
      </div>
      <svg
        viewBox="0 0 260 200"
        role="img"
        aria-label="Preisverlauf in Euro"
        className="mt-4 w-full"
      >
        <defs>
          <linearGradient id="streetGradient" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#38BDF8" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d={`M ${data
            .map((point, index) => `${getX(index)},${getY(point.uvp)}`)
            .join(' L ')}`}
          fill="none"
          stroke="#94A3B8"
          strokeWidth="2"
          strokeDasharray="6"
        />
        <path
          d={`M ${data
            .map((point, index) => `${getX(index)},${getY(point.street)}`)
            .join(' L ')}`}
          fill="none"
          stroke="#38BDF8"
          strokeWidth="3"
        />
        <path
          d={`M 40,200 L ${data
            .map((point, index) => `${getX(index)},${getY(point.street)}`)
            .join(' L ')} L ${getX(data.length - 1)},200`}
          fill="url(#streetGradient)"
          opacity="0.4"
        />
        {data.map((point, index) => (
          <g key={point.month}>
            <circle
              cx={getX(index)}
              cy={getY(point.street)}
              r="4"
              fill="#38BDF8"
            />
            <text
              x={getX(index)}
              y="195"
              textAnchor="middle"
              className="fill-slate-500 text-[10px]"
            >
              {formatMonth(point.month)}
            </text>
          </g>
        ))}
      </svg>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl bg-cloud/70 p-4 text-sm text-slate-600 dark:bg-slate-700/70 dark:text-slate-200">
          <p className="font-semibold text-slateNight dark:text-cloud">
            Höchstwert (UVP)
          </p>
          <p>
            {max.toLocaleString('de-DE', {
              style: 'currency',
              currency: 'EUR'
            })}
          </p>
        </div>
        <div className="rounded-xl bg-skyPulse/10 p-4 text-sm text-slate-600 dark:bg-skyPulse/20 dark:text-slate-200">
          <p className="font-semibold text-slateNight dark:text-cloud">
            Tiefstpreis (Straße)
          </p>
          <p>
            {min.toLocaleString('de-DE', {
              style: 'currency',
              currency: 'EUR'
            })}
          </p>
        </div>
      </div>
    </div>
  );
};

export default PriceTrend;