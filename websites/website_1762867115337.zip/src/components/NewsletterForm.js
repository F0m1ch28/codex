import React, { useState } from 'react';

const NewsletterForm = ({ variant = 'light' }) => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      setError('Bitte geben Sie eine gültige E-Mail-Adresse ein.');
      return;
    }
    setSubmitted(true);
    setError('');
  };

  if (submitted) {
    return (
      <div
        className={`rounded-xl border ${
          variant === 'dark'
            ? 'border-skyPulse/50 bg-skyPulse/20 text-slateNight'
            : 'border-slateNight/20 bg-skyPulse/10 text-slateNight'
        } px-4 py-3`}
        role="status"
      >
        Danke! Bitte bestätigen Sie den Link in Ihrer E-Mail.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3" noValidate>
      <label htmlFor="newsletter-email" className="sr-only">
        E-Mail-Adresse
      </label>
      <input
        id="newsletter-email"
        type="email"
        name="email"
        required
        autoComplete="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="E-Mail-Adresse"
        className={`w-full rounded-full border px-4 py-3 text-sm outline-none transition focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 ${
          variant === 'dark'
            ? 'border-cloud/30 bg-slate-800 text-cloud placeholder:text-cloud/60'
            : 'border-slateNight/20 bg-white text-slateNight placeholder:text-slate-400'
        }`}
      />
      {error && <p className="text-xs text-red-500">{error}</p>}
      <button
        type="submit"
        className={`w-full rounded-full px-4 py-3 text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ${
          variant === 'dark'
            ? 'bg-mist text-slateNight hover:bg-white focus-visible:ring-skyPulse focus-visible:ring-offset-slateNight'
            : 'bg-slateNight text-mist hover:bg-slate-900 focus-visible:ring-skyPulse focus-visible:ring-offset-white'
        }`}
      >
        Jetzt abonnieren
      </button>
    </form>
  );
};

export default NewsletterForm;