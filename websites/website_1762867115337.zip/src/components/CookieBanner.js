import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem('slexorifyx-cookie');
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('slexorifyx-cookie', 'accepted');
    setVisible(false);
  };

  const handlePreferences = () => {
    alert('Feinjustierung folgt in Kürze. Kontaktieren Sie privacy@slexorifyx.com für individuelle Anliegen.');
  };

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-live="polite"
      aria-label="Cookie-Hinweis"
      className="fixed bottom-0 left-0 right-0 z-40 mx-4 mb-4 rounded-2xl border border-slate-200 bg-white/95 p-6 shadow-floating backdrop-blur md:mx-auto md:w-2/3 lg:w-1/2 dark:border-slate-600 dark:bg-slate-800/95"
    >
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="font-semibold text-slateNight dark:text-cloud">
            Cookies für faire Auswertungen
          </p>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Wir nutzen essentielle Cookies sowie anonymisierte Analytics, um
            Preisverläufe und Testdaten konsistent zu halten. Mehr Informationen
            finden Sie in unserer{' '}
            <a
              href="/policy"
              className="font-semibold text-skyPulse underline decoration-dotted underline-offset-4"
            >
              Datenschutzerklärung
            </a>.
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <button
            onClick={handlePreferences}
            className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slateNight transition hover:bg-cloud/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:text-cloud dark:hover:bg-slate-700"
          >
            Einstellungen
          </button>
          <button
            onClick={handleAccept}
            className="rounded-full bg-slateNight px-4 py-2 text-sm font-semibold text-mist shadow-md transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 focus-visible:ring-offset-white dark:bg-skyPulse dark:text-slateNight dark:hover:bg-aquaPulse"
          >
            Akzeptieren
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;