import React from 'react';
import { Link } from 'react-router-dom';
import { formatCurrency } from '../utils/format';

const ReviewCard = ({ review }) => {
  return (
    <article className="group flex flex-col rounded-2xl border border-cloud bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl focus-within:ring-2 focus-within:ring-skyPulse dark:border-slate-700 dark:bg-slate-800">
      <Link to={`/reviews/${review.slug}`} className="relative overflow-hidden rounded-t-2xl">
        <img
          src={`${review.image}&auto=format&fit=crop&w=1200&q=80`}
          alt={`Produktaufnahme ${review.title}`}
          className="h-56 w-full object-cover transition duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute left-4 top-4 flex gap-2">
          {review.badges.map((badge) => (
            <span
              key={badge}
              className="rounded-full bg-slateNight/80 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-mist backdrop-blur dark:bg-mist/80 dark:text-slateNight"
            >
              {badge}
            </span>
          ))}
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-4 p-6">
        <div className="flex items-center justify-between">
          <span className="rounded-full bg-cloud px-3 py-1 text-xs font-medium text-slate-600 dark:bg-slate-700/70 dark:text-slate-200">
            {review.category}
          </span>
          <div
            className="flex items-center gap-2"
            aria-label={`Bewertung ${review.rating} von 100`}
          >
            <span className="text-sm font-semibold text-slate-500 dark:text-slate-300">
              Score
            </span>
            <span className="rounded-full bg-aquaPulse/20 px-3 py-1 font-display text-lg font-bold text-slateNight dark:bg-skyPulse/20 dark:text-skyPulse">
              {review.rating}
            </span>
          </div>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-slateNight transition group-hover:text-skyPulse dark:text-cloud">
            <Link to={`/reviews/${review.slug}`}>{review.title}</Link>
          </h3>
          <p className="mt-2 line-clamp-3 text-sm text-slate-600 dark:text-slate-300">
            {review.shortDescription}
          </p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
              Vorteile
            </p>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-slate-600 dark:text-slate-200">
              {review.pros.slice(0, 3).map((pro) => (
                <li key={pro}>{pro}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
              Grenzen
            </p>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-slate-600 dark:text-slate-200">
              {review.cons.slice(0, 2).map((con) => (
                <li key={con}>{con}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-auto flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-wide text-slate-400 dark:text-slate-500">
              Preis (Stand)
            </span>
            <div className="text-base font-semibold text-slateNight dark:text-cloud">
              {formatCurrency(review.currentPrice)}
            </div>
          </div>
          <Link
            to={`/reviews/${review.slug}`}
            className="inline-flex items-center gap-2 rounded-full bg-slateNight px-4 py-2 text-sm font-semibold text-mist transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 focus-visible:ring-offset-white dark:bg-skyPulse dark:text-slateNight dark:hover:bg-aquaPulse"
          >
            Review ansehen <span aria-hidden="true">→</span>
          </Link>
        </div>
      </div>
    </article>
  );
};

export default ReviewCard;