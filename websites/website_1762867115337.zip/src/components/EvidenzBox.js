import React from 'react';

const EvidenzBox = ({ label, value, method, source }) => {
  return (
    <div className="rounded-2xl border border-skyPulse/40 bg-skyPulse/10 p-5 text-sm text-slate-700 shadow-sm dark:border-skyPulse/30 dark:bg-skyPulse/20 dark:text-slate-200">
      <p className="font-semibold text-slateNight dark:text-slate-50">
        {label}
      </p>
      <p className="mt-1 font-display text-lg text-slateNight dark:text-white">
        {value}
      </p>
      <p className="mt-2 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
        Methode
      </p>
      <p className="text-sm text-slate-600 dark:text-slate-200">{method}</p>
      <p className="mt-2 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
        Quelle
      </p>
      <p className="text-sm text-slate-600 dark:text-slate-200">{source}</p>
    </div>
  );
};

export default EvidenzBox;