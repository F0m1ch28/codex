import React from 'react';
import { Link } from 'react-router-dom';
import NewsletterForm from './NewsletterForm';

const Footer = () => {
  return (
    <footer className="bg-slateNight text-cloud" aria-label="Footer">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-4">
          <div>
            <Link to="/" className="flex items-center gap-2">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-mist text-2xl font-extrabold text-slateNight shadow-md">
                Sx
              </span>
              <span className="font-display text-2xl font-bold">
                Slexorifyx
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm text-cloud/80">
              Unabhängige Gadget-Reviews, Langzeittests und Early-Access-Programme
              für den deutschen Markt – mit transparenten Messwerten und
              dokumentierten Methoden.
            </p>
            <div className="mt-4 flex gap-3">
              <a
                href="https://www.linkedin.com"
                className="rounded-full border border-cloud/30 p-2 transition hover:border-aquaPulse hover:text-aquaPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-aquaPulse"
              >
                <span className="sr-only">LinkedIn</span>in
              </a>
              <a
                href="https://www.youtube.com"
                className="rounded-full border border-cloud/30 p-2 transition hover:border-aquaPulse hover:text-aquaPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-aquaPulse"
              >
                <span className="sr-only">YouTube</span>▶
              </a>
              <a
                href="https://mastodon.social"
                className="rounded-full border border-cloud/30 p-2 transition hover:border-aquaPulse hover:text-aquaPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-aquaPulse"
              >
                <span className="sr-only">Mastodon</span>🦣
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-display text-lg font-semibold text-white">
              Navigation
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-cloud/80">
              <li><Link to="/reviews" className="hover:text-aquaPulse">Reviews</Link></li>
              <li><Link to="/early" className="hover:text-aquaPulse">Early Access</Link></li>
              <li><Link to="/deals" className="hover:text-aquaPulse">Deals</Link></li>
              <li><Link to="/compare" className="hover:text-aquaPulse">Vergleich</Link></li>
              <li><Link to="/guide" className="hover:text-aquaPulse">Guide</Link></li>
              <li><Link to="/news" className="hover:text-aquaPulse">News</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-lg font-semibold text-white">
              Rechtliches & Transparenz
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-cloud/80">
              <li><Link to="/policy" className="hover:text-aquaPulse">Datenschutzerklärung</Link></li>
              <li><Link to="/cookies" className="hover:text-aquaPulse">Cookie-Hinweise</Link></li>
              <li><Link to="/terms" className="hover:text-aquaPulse">Nutzungsbedingungen</Link></li>
              <li><Link to="/disclosure" className="hover:text-aquaPulse">Transparenz & Disclosure</Link></li>
              <li><Link to="/impressum" className="hover:text-aquaPulse">Impressum</Link></li>
              <li><Link to="/quellen" className="hover:text-aquaPulse">Quellenverzeichnis</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-lg font-semibold text-white">
              Newsletter
            </h4>
            <p className="mt-4 text-sm text-cloud/80">
              Jeden Donnerstag: Preisanalysen, Firmware-Updates und offene Slots
              in Beta-Programmen. Kein Spam, jederzeit kündbar.
            </p>
            <div className="mt-4">
              <NewsletterForm variant="dark" />
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-cloud/20 pt-6">
          <p className="text-xs text-cloud/60">
            © {new Date().getFullYear()} Slexorifyx GmbH. Alle Rechte vorbehalten. Sitz Köln,
            Handelsregister HRB 92731. Umsatzsteuer-ID DE 342 178 909.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;