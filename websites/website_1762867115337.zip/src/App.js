import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Reviews from './pages/Reviews';
import ReviewDetail from './pages/ReviewDetail';
import EarlyAccess from './pages/EarlyAccess';
import Deals from './pages/Deals';
import Compare from './pages/Compare';
import Guide from './pages/Guide';
import News from './pages/News';
import About from './pages/About';
import Services from './pages/Services';
import FAQ from './pages/FAQ';
import Contact from './pages/Contact';
import Policy from './pages/Policy';
import CookiesPolicy from './pages/Cookies';
import Terms from './pages/Terms';
import Impressum from './pages/Impressum';
import Sources from './pages/Sources';
import Disclosure from './pages/Disclosure';
import NotFound from './pages/NotFound';
import { ThemeProvider } from './context/ThemeContext';

const App = () => {
  return (
    <ThemeProvider>
      <div className="flex min-h-screen flex-col bg-mist text-slateNight transition-colors dark:bg-slateNight dark:text-cloud">
        <a href="#hauptinhalt" className="skip-link">
          Zum Inhalt springen
        </a>
        <Header />
        <main id="hauptinhalt" className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/reviews" element={<Reviews />} />
            <Route path="/reviews/:slug" element={<ReviewDetail />} />
            <Route path="/early" element={<EarlyAccess />} />
            <Route path="/deals" element={<Deals />} />
            <Route path="/compare" element={<Compare />} />
            <Route path="/guide" element={<Guide />} />
            <Route path="/news" element={<News />} />
            <Route path="/services" element={<Services />} />
            <Route path="/about" element={<About />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/policy" element={<Policy />} />
            <Route path="/privacy" element={<Policy />} />
            <Route path="/cookies" element={<CookiesPolicy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/impressum" element={<Impressum />} />
            <Route path="/quellen" element={<Sources />} />
            <Route path="/disclosure" element={<Disclosure />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTop />
      </div>
    </ThemeProvider>
  );
};

export default App;