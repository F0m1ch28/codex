import React from 'react';
import { Helmet } from 'react-helmet-async';
import { teamMembers, projects } from '../data/content';

const About = () => {
  return (
    <>
      <Helmet>
        <title>Über Slexorifyx | Labore, Team & Mission</title>
        <meta
          name="description"
          content="Lernen Sie das Team hinter Slexorifyx kennen – unabhängige Labore, transparente Finanzierung und unsere Mission für faire Tech-Entscheidungen."
        />
        <link rel="canonical" href="https://slexorifyx.com/about" />
      </Helmet>
      <section className="bg-white py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-6xl space-y-12 px-4 sm:px-6 lg:px-8">
          <header className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              Über uns
            </p>
            <h1 className="mt-3 font-display text-3xl font-bold text-slateNight dark:text-white">
              Unabhängige Labore. Faire Entscheidungen.
            </h1>
            <p className="mx-auto mt-4 max-w-3xl text-sm text-slate-600 dark:text-slate-300">
              Slexorifyx wurde 2019 in Köln gegründet. Unser Ziel: Messungen, Preise und
              Produktpolitik transparent zu machen – mit eigenen Laboren in Berlin,
              Hamburg und Köln, unterstützt von einer Community aus über 6.000 Beta-Tester:innen.
            </p>
          </header>

          <section className="grid gap-8 md:grid-cols-2">
            {projects.slice(0, 3).map((project) => (
              <div
                key={project.id}
                className="rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800"
              >
                <h2 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                  {project.title}
                </h2>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                  {project.summary}
                </p>
                <p className="mt-2 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                  {project.highlight}
                </p>
              </div>
            ))}
          </section>

          <section className="rounded-3xl bg-slateNight px-8 py-10 text-white dark:bg-slate-800">
            <h2 className="font-display text-2xl font-bold">Team</h2>
            <p className="mt-3 max-w-3xl text-sm text-cloud/80">
              Interdisziplinär, divers und mit Laboren verbunden. Jedes Mitglied besitzt
              Branchenerfahrung, nimmt an jährlichen Ethikschulungen teil und veröffentlicht
              Interessenkonflikte offen.
            </p>
            <div className="mt-8 grid gap-8 md:grid-cols-2">
              {teamMembers.map((member) => (
                <article key={member.id} className="rounded-3xl bg-white/10 p-6">
                  <div className="flex items-center gap-4">
                    <img
                      src={member.image}
                      alt={`${member.name} – ${member.role}`}
                      className="h-20 w-20 rounded-full object-cover"
                      loading="lazy"
                    />
                    <div>
                      <h3 className="font-display text-xl font-semibold text-white">
                        {member.name}
                      </h3>
                      <p className="text-sm text-cloud/80">{member.role}</p>
                    </div>
                  </div>
                  <p className="mt-4 text-sm text-cloud/90">{member.bio}</p>
                  <p className="mt-2 text-xs text-skyPulse">Fokus: {member.focus}</p>
                  <a
                    href={member.socials.linkedin}
                    className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-skyPulse hover:text-aquaPulse"
                  >
                    LinkedIn Profil →
                  </a>
                </article>
              ))}
            </div>
          </section>

          <section className="grid gap-6 lg:grid-cols-2">
            <div className="rounded-3xl border border-cloud bg-white p-6 dark:border-slate-700 dark:bg-slate-800">
              <h2 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                Finanzierung & Disclosure
              </h2>
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                Slexorifyx finanziert sich über Labordienstleistungen, Community-Abos und
                Bildungsangebote. Hersteller können keine Bewertungen kaufen. Alle Kooperationen
                werden im{' '}
                <a href="/disclosure" className="text-skyPulse">
                  Disclosure
                </a>{' '}
                transparent gemacht.
              </p>
            </div>
            <div className="rounded-3xl border border-cloud bg-white p-6 dark:border-slate-700 dark:bg-slate-800">
              <h2 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                Nachhaltigkeit & Reparatur
              </h2>
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                Wir konservieren Ersatzteile für fünf Jahre, sammeln Reparaturdaten und
                unterstützen Circular-Economy-Projekte. Defekte Testgeräte gehen an Partnerwerkstätten
                in Köln und Hamburg.
              </p>
            </div>
          </section>
        </div>
      </section>
    </>
  );
};

export default About;