import React from 'react';
import { Helmet } from 'react-helmet-async';
import { betaPrograms } from '../data/content';

const EarlyAccess = () => {
  return (
    <>
      <Helmet>
        <title>Early Access Programme | Slexorifyx</title>
        <meta
          name="description"
          content="Offene Early-Access-Programme in Deutschland: Bewerbungsbedingungen, Datenschutz, Versand und Aufwandsentschädigungen."
        />
        <link rel="canonical" href="https://slexorifyx.com/early" />
      </Helmet>
      <section className="bg-white py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <header className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              Early Access
            </p>
            <h1 className="mt-3 font-display text-3xl font-bold text-slateNight dark:text-white">
              Früh testen, fair dokumentieren
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-sm text-slate-600 dark:text-slate-200">
              Wir organisieren Testdurchläufe in Deutschland – inklusive Versicherungen, Versand,
              Netzteil-Prüfungen und DSGVO-konformer Datenverarbeitung. Bewerber:innen erhalten
              Klarheit über Pflichten, Aufwandsentschädigungen und Rücksendeprozesse.
            </p>
          </header>

          <div className="mt-12 grid gap-8">
            {betaPrograms.map((program) => (
              <article
                key={program.id}
                className="rounded-3xl border border-cloud bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-xl dark:border-slate-700 dark:bg-slate-800"
              >
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <h2 className="font-display text-2xl font-semibold text-slateNight dark:text-white">
                    {program.name}
                  </h2>
                  <span className="rounded-full bg-slateNight px-4 py-1 text-sm font-semibold text-mist dark:bg-skyPulse dark:text-slateNight">
                    {program.status}
                  </span>
                </div>
                <p className="mt-4 text-sm text-slate-600 dark:text-slate-200">
                  {program.description}
                </p>
                <div className="mt-6 grid gap-4 md:grid-cols-2">
                  <div>
                    <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
                      Voraussetzungen
                    </h3>
                    <ul className="mt-2 space-y-2 text-sm text-slate-600 dark:text-slate-200">
                      {program.requirements.map((item) => (
                        <li key={item} className="flex gap-2">
                          <span aria-hidden="true">•</span> {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
                      Leistungen
                    </h3>
                    <ul className="mt-2 space-y-2 text-sm text-slate-600 dark:text-slate-200">
                      {program.benefits.map((item) => (
                        <li key={item} className="flex gap-2">
                          <span aria-hidden="true">•</span> {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <dl className="mt-6 grid gap-3 text-sm text-slate-600 dark:text-slate-200 md:grid-cols-3">
                  <div>
                    <dt className="font-semibold text-slateNight dark:text-white">
                      Start
                    </dt>
                    <dd>{new Date(program.startDate).toLocaleDateString('de-DE')}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold text-slateNight dark:text-white">
                      Ort
                    </dt>
                    <dd>{program.location}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold text-slateNight dark:text-white">
                      Slots
                    </dt>
                    <dd>{program.slots} Plätze</dd>
                  </div>
                </dl>
                <div className="mt-8 flex flex-wrap gap-4">
                  <a
                    href={`mailto:${program.contactEmail}`}
                    className="inline-flex items-center gap-2 rounded-full bg-slateNight px-6 py-3 text-sm font-semibold text-mist transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:bg-skyPulse dark:text-slateNight"
                  >
                    Bewerbung senden
                  </a>
                  <a
                    href="/disclosure"
                    className="inline-flex items-center gap-2 text-sm font-semibold text-skyPulse hover:text-aquaPulse"
                  >
                    Transparenz & Richtlinien →
                  </a>
                </div>
              </article>
            ))}
          </div>

          <div className="mt-16 rounded-3xl bg-slateNight px-8 py-10 text-white dark:bg-slate-800">
            <h2 className="font-display text-2xl font-bold">
              Ablauf & Rechtliches
            </h2>
            <div className="mt-6 grid gap-6 md:grid-cols-3">
              <div>
                <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                  Versand & Hardware
                </p>
                <p className="mt-2 text-sm text-cloud/80">
                  Geräte werden versichert verschickt, Seriennummern dokumentiert, Zubehör
                  nach EU-Normen geprüft. Rücksendung erfolgt kostenfrei via Pick-Up Service.
                </p>
              </div>
              <div>
                <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                  Datenschutz
                </p>
                <p className="mt-2 text-sm text-cloud/80">
                  Feedback läuft über unser Portal in Frankfurt. Persönliche Daten werden
                  anonymisiert, Audio/Video nur nach schriftlicher Zustimmung.
                </p>
              </div>
              <div>
                <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                  Aufwandsentschädigung
                </p>
                <p className="mt-2 text-sm text-cloud/80">
                  Vergütung ab 80 € je Testwoche, je nach Programm. Auszahlung innerhalb von
                  zehn Tagen nach Abschlussbericht.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default EarlyAccess;