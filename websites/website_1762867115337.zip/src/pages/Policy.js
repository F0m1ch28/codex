import React from 'react';
import { Helmet } from 'react-helmet-async';

const Policy = () => {
  return (
    <>
      <Helmet>
        <title>Datenschutzerklärung | Slexorifyx</title>
        <meta
          name="description"
          content="Transparente Datenschutzerklärung von Slexorifyx gemäß DSGVO."
        />
        <link rel="canonical" href="https://slexorifyx.com/policy" />
      </Helmet>
      <section className="bg-white py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-4xl space-y-8 px-4 sm:px-6 lg:px-8">
          <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
            Datenschutzerklärung
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Wir verarbeiten personenbezogene Daten ausschließlich auf Grundlage der DSGVO und
            des BDSG. Serverstandort ist Frankfurt am Main (ISO 27001 zertifiziert).
          </p>
          <div className="space-y-6 text-sm text-slate-600 dark:text-slate-200">
            <section>
              <h2 className="font-semibold text-slateNight dark:text-white">1. Verantwortliche Stelle</h2>
              <p>Slexorifyx GmbH, Vogelsanger Straße 325, 50827 Köln · privacy@slexorifyx.com</p>
            </section>
            <section>
              <h2 className="font-semibold text-slateNight dark:text-white">2. Verarbeitungszwecke</h2>
              <ul className="list-disc space-y-2 pl-5">
                <li>Bereitstellung der Website und Logfiles</li>
                <li>Newsletter-Versand (Double-Opt-In, Brevo / Server in DE)</li>
                <li>Beta-Programme (Teilnehmerverwaltung, Versand)</li>
                <li>Kommunikation (Kontaktformular, E-Mail)</li>
              </ul>
            </section>
            <section>
              <h2 className="font-semibold text-slateNight dark:text-white">3. Rechtsgrundlagen</h2>
              <p>Art. 6 Abs. 1 lit. a, b, c und f DSGVO je nach Zweck. Bei Beta-Programmen schließen wir Auftragsverarbeitungsverträge (Art. 28 DSGVO).</p>
            </section>
            <section>
              <h2 className="font-semibold text-slateNight dark:text-white">4. Speicherdauer</h2>
              <p>Kontaktanfragen und Messdaten 3 Jahre. Bewerbungsunterlagen 12 Monate. Newsletter-Daten bis zum Widerruf.</p>
            </section>
            <section>
              <h2 className="font-semibold text-slateNight dark:text-white">5. Ihre Rechte</h2>
              <p>Sie haben Rechte auf Auskunft, Berichtigung, Löschung, Einschränkung, Datenübertragbarkeit und Beschwerde bei der Landesdatenschutzbehörde NRW.</p>
            </section>
          </div>
        </div>
      </section>
    </>
  );
};

export default Policy;