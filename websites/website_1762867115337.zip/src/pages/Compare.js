import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { reviews } from '../data/content';
import { formatCurrency } from '../utils/format';

const fields = [
  { key: 'display', label: 'Display' },
  { key: 'processor', label: 'Prozessor' },
  { key: 'ram', label: 'RAM' },
  { key: 'storage', label: 'Speicher' },
  { key: 'battery', label: 'Akku' },
  { key: 'weight', label: 'Gewicht' },
  { key: 'connectivity', label: 'Konnektivität' },
  { key: 'os', label: 'Betriebssystem' },
  { key: 'charging', label: 'Laden/Netz' }
];

const Compare = () => {
  const [selected, setSelected] = useState([reviews[0].slug, reviews[1].slug]);

  const selectedReviews = useMemo(
    () => reviews.filter((review) => selected.includes(review.slug)),
    [selected]
  );

  const toggleSelection = (slug) => {
    setSelected((prev) => {
      if (prev.includes(slug)) {
        return prev.filter((item) => item !== slug);
      }
      if (prev.length >= 4) return prev;
      return [...prev, slug];
    });
  };

  return (
    <>
      <Helmet>
        <title>Produktvergleich – bis zu vier Gadgets | Slexorifyx</title>
        <meta
          name="description"
          content="Vergleiche technische Daten, Messwerte, Preise und Besonderheiten von bis zu vier getesteten Produkten."
        />
        <link rel="canonical" href="https://slexorifyx.com/compare" />
      </Helmet>
      <section className="bg-white py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <header>
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              Vergleich
            </p>
            <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
              Technische Daten nebeneinander
            </h1>
            <p className="mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
              Wähle bis zu vier Produkte aus unseren Reviews. Die Tabelle bleibt auch auf
              mobilen Geräten übersichtlich – Header und Spalten bleiben beim Scrollen sichtbar.
            </p>
          </header>

          <div className="mt-8 rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
            <h2 className="text-lg font-semibold text-slateNight dark:text-white">
              Auswahl
            </h2>
            <div className="mt-4 grid gap-3 md:grid-cols-3">
              {reviews.map((review) => {
                const checked = selected.includes(review.slug);
                return (
                  <label
                    key={review.slug}
                    className={`flex cursor-pointer items-center gap-3 rounded-2xl border px-4 py-3 text-sm transition focus-within:ring-2 focus-within:ring-skyPulse ${
                      checked
                        ? 'border-skyPulse bg-skyPulse/15 text-slateNight dark:bg-skyPulse/20'
                        : 'border-cloud text-slate-600 hover:border-skyPulse dark:border-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleSelection(review.slug)}
                      className="h-4 w-4 rounded accent-skyPulse"
                    />
                    <span>
                      <span className="font-semibold">{review.title}</span>
                      <span className="block text-xs text-slate-500 dark:text-slate-300">
                        {review.category} · Score {review.rating}
                      </span>
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="mt-12 overflow-x-auto rounded-3xl border border-cloud dark:border-slate-700">
            <table className="min-w-full border-collapse">
              <thead className="sticky top-0 bg-cloud/70 backdrop-blur dark:bg-slate-800/90">
                <tr>
                  <th className="sticky left-0 z-10 bg-cloud/80 px-4 py-4 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 dark:bg-slate-800/90 dark:text-slate-300">
                    Merkmal
                  </th>
                  {selectedReviews.map((review) => (
                    <th
                      key={review.slug}
                      className="px-6 py-4 text-left font-display text-lg font-semibold text-slateNight dark:text-white"
                    >
                      {review.title}
                      <div className="mt-1 text-xs font-medium uppercase text-slate-500 dark:text-slate-300">
                        Score {review.rating} · {formatCurrency(review.currentPrice)}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white text-sm dark:bg-slate-900 dark:text-slate-200">
                {fields.map((field) => (
                  <tr key={field.key} className="border-t border-cloud/60 dark:border-slate-700/70">
                    <th className="sticky left-0 z-10 bg-cloud/60 px-4 py-4 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 dark:bg-slate-800/70 dark:text-slate-300">
                      {field.label}
                    </th>
                    {selectedReviews.map((review) => (
                      <td key={review.slug} className="px-6 py-4 align-top">
                        {review.specs[field.key] || 'n/a'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </>
  );
};

export default Compare;