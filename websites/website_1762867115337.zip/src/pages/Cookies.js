import React from 'react';
import { Helmet } from 'react-helmet-async';

const Cookies = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie | Slexorifyx</title>
      <meta
        name="description"
        content="Cookie-Richtlinie von Slexorifyx: Essentielle Cookies, Analytics und Opt-out."
      />
      <link rel="canonical" href="https://slexorifyx.com/cookies" />
    </Helmet>
    <section className="bg-white py-16 dark:bg-slate-900">
      <div className="mx-auto max-w-4xl space-y-8 px-4 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
          Cookie-Richtlinie
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          Wir verwenden essentielle Cookies (Session, CSRF) sowie anonymisierte Statistiken
          mit Matomo (Self-Hosted, IP-Anonymisierung). Sie können Analytics jederzeit deaktivieren.
        </p>
        <ul className="list-disc space-y-2 pl-5 text-sm text-slate-600 dark:text-slate-200">
          <li>Essentiell: Session-ID, Cookie-Banner-Status (12 Monate)</li>
          <li>Statistik: Matomo (_pk_id, _pk_ses) – 6 Monate, Opt-Out im Footer</li>
          <li>Keine Marketing-Cookies, kein Tracking durch Dritte</li>
        </ul>
      </div>
    </section>
  </>
);

export default Cookies;