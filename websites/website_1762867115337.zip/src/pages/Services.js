import React from 'react';
import { Helmet } from 'react-helmet-async';

const services = [
  {
    title: 'Labordienstleistungen',
    description:
      'Kalibrierte Messungen für Display, Akku und Audio nach IEC-Standards. Ergebnisberichte inkl. Messprotokollen und Empfehlungen.',
    deliverables: ['Kalibrierte Messwerte', 'Digitale Messprotokolle', 'Auditfähige Dokumente']
  },
  {
    title: 'Beta-Programm-Design',
    description:
      'Aufsetzen und Moderieren von Feldtests in Deutschland. Teilnehmer-Onboarding, Logistik, Datenschutz und Feedbackauswertung.',
    deliverables: ['Teilnehmerportal', 'Feedback-Workshops', 'Aufwandsentschädigung']
  },
  {
    title: 'Markt- & Preisanalysen',
    description:
      'Preisradar für Deutschland, Wettbewerbsvergleich, Lieferfähigkeiten und Netto-Preise inklusive gesetzlicher Abgaben.',
    deliverables: ['Preisreport', 'Wettbewerbs-Benchmark', 'Vertriebs-Check']
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Services & Partnerschaften | Slexorifyx</title>
        <meta
          name="description"
          content="Unsere Leistungen für Hersteller, Händler und Medien in Deutschland: Labordaten, Beta-Programme, Marktanalysen."
        />
        <link rel="canonical" href="https://slexorifyx.com/services" />
      </Helmet>
      <section className="bg-mist py-16 dark:bg-slateNight">
        <div className="mx-auto max-w-6xl space-y-12 px-4 sm:px-6 lg:px-8">
          <header className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              Services
            </p>
            <h1 className="mt-3 font-display text-3xl font-bold text-slateNight dark:text-white">
              Leistungen für Hersteller & Medien
            </h1>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
              Maßgeschneiderte Testberichte, Beta-Communities und Marktanalysen mit Fokus auf
              den deutschen Markt. Transparenz und Unabhängigkeit bleiben garantiert.
            </p>
          </header>

          <div className="grid gap-8 md:grid-cols-3">
            {services.map((service) => (
              <article
                key={service.title}
                className="rounded-3xl border border-cloud bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-700 dark:bg-slate-800"
              >
                <h2 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                  {service.title}
                </h2>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                  {service.description}
                </p>
                <p className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
                  Deliverables
                </p>
                <ul className="mt-2 space-y-2 text-sm text-slate-600 dark:text-slate-200">
                  {service.deliverables.map((item) => (
                    <li key={item} className="flex gap-2">
                      <span aria-hidden="true">•</span> {item}
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>

          <div className="rounded-3xl bg-slateNight px-8 py-10 text-white dark:bg-slate-800">
            <h2 className="font-display text-2xl font-bold">
              Interesse an einer Zusammenarbeit?
            </h2>
            <p className="mt-3 max-w-3xl text-sm text-cloud/80">
              Wir erstellen individuelle Angebote und binden Interessenkonflikte transparent in
              unsere Berichterstattung ein. Nutzen Sie unser Kontaktformular oder schreiben Sie
              uns an partnerships@slexorifyx.com.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;