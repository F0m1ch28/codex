import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import ReviewCard from '../components/ReviewCard';
import { reviews } from '../data/content';

const uniqueCategories = ['Alle', ...new Set(reviews.map((item) => item.category))];

const Reviews = () => {
  const [category, setCategory] = useState('Alle');
  const [minRating, setMinRating] = useState(70);
  const [query, setQuery] = useState('');

  const filteredReviews = useMemo(() => {
    return reviews
      .filter((review) => (category === 'Alle' ? true : review.category === category))
      .filter((review) => review.rating >= minRating)
      .filter((review) =>
        review.title.toLowerCase().includes(query.toLowerCase()) ||
        review.summary.toLowerCase().includes(query.toLowerCase())
      );
  }, [category, minRating, query]);

  return (
    <>
      <Helmet>
        <title>Gadget Reviews – Messwerte & Analysen | Slexorifyx</title>
        <meta
          name="description"
          content="Alle aktuellen Reviews von Slexorifyx: Smartphones, Audio, Smart Home, Gaming und mehr. Mit Evidenzboxen, Preisverläufen und Gewährleistungs-Tipps."
        />
        <link rel="canonical" href="https://slexorifyx.com/reviews" />
      </Helmet>
      <section className="bg-gradient-to-b from-mist to-white py-16 dark:from-slateNight dark:to-slate-900">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                Reviews
              </p>
              <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
                Unabhängige Messwerte & Langzeitprotokolle
              </h1>
              <p className="mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
                Unsere Reviews enthalten nachvollziehbare Messmethoden, Angaben zu Netzen,
                Steckern und Gewährleistung. Filtere nach Kategorie oder Mindestscore, um das
                richtige Gerät zu finden.
              </p>
            </div>
          </header>

          <div className="mt-10 grid gap-4 rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
            <div className="grid gap-4 md:grid-cols-4">
              <label className="flex flex-col gap-2 text-sm font-medium text-slateNight dark:text-white">
                Kategorie
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
                >
                  {uniqueCategories.map((cat) => (
                    <option key={cat}>{cat}</option>
                  ))}
                </select>
              </label>
              <label className="flex flex-col gap-2 text-sm font-medium text-slateNight dark:text-white">
                Mindestscore
                <input
                  type="range"
                  min="60"
                  max="100"
                  step="5"
                  value={minRating}
                  onChange={(e) => setMinRating(Number(e.target.value))}
                  className="accent-skyPulse"
                />
                <span className="text-xs text-slate-500 dark:text-slate-300">
                  {minRating}+
                </span>
              </label>
              <label className="md:col-span-2 flex flex-col gap-2 text-sm font-medium text-slateNight dark:text-white">
                Suche
                <input
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Produkt, Feature oder Autor:in"
                  className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
                />
              </label>
            </div>
          </div>

          <div className="mt-12 grid gap-8 md:grid-cols-2 xl:grid-cols-3">
            {filteredReviews.map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
            {filteredReviews.length === 0 && (
              <div className="rounded-2xl border border-dashed border-cloud bg-white p-10 text-center text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200">
                Keine passenden Reviews gefunden. Passe die Filter an oder kontaktiere uns
                für eine individuelle Kaufberatung.
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default Reviews;