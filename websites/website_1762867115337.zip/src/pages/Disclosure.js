import React from 'react';
import { Helmet } from 'react-helmet-async';

const Disclosure = () => (
  <>
    <Helmet>
      <title>Transparenz & Disclosure | Slexorifyx</title>
      <meta
        name="description"
        content="Alle Kooperationen, Affiliate-Hinweise und Interessenkonflikte transparent dargelegt."
      />
      <link rel="canonical" href="https://slexorifyx.com/disclosure" />
    </Helmet>
    <section className="bg-white py-16 dark:bg-slate-900">
      <div className="mx-auto max-w-4xl space-y-6 px-4 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
          Transparenz & Disclosure
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          Slexorifyx arbeitet unabhängig. Hersteller stellen fallweise Geräte leihweise zur Verfügung.
          Nach Testende werden Geräte zurückgesendet oder markiert als Dauerleihgabe. Dauerleihgaben sind
          im Review gekennzeichnet.
        </p>
        <ul className="list-disc space-y-3 pl-5 text-sm text-slate-600 dark:text-slate-200">
          <li>Keine bezahlten Reviews. Kooperationen nur auf Dienstleistungsbasis (z. B. Labormessung).</li>
          <li>Affiliate-Links werden klar markiert, aktuell keine aktiv.</li>
          <li>Interessenkonflikte des Teams werden jährlich veröffentlicht.</li>
        </ul>
      </div>
    </section>
  </>
);

export default Disclosure;