import React from 'react';
import { Helmet } from 'react-helmet-async';

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum | Slexorifyx GmbH</title>
      <meta
        name="description"
        content="Impressum von Slexorifyx gemäß §5 TMG."
      />
      <link rel="canonical" href="https://slexorifyx.com/impressum" />
    </Helmet>
    <section className="bg-white py-16 dark:bg-slate-900">
      <div className="mx-auto max-w-4xl space-y-6 px-4 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
          Impressum
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          Anbieter gemäß § 5 TMG: Slexorifyx GmbH, Vogelsanger Straße 325, 50827 Köln
        </p>
        <div className="space-y-4 text-sm text-slate-600 dark:text-slate-200">
          <p>Vertreten durch: Geschäftsführerin Lea Krämer</p>
          <p>Kontakt: Telefon +49 (0)221 828 930 40 · E-Mail hallo@slexorifyx.com</p>
          <p>Registernummer: HRB 92731 · Registergericht: Amtsgericht Köln</p>
          <p>USt-ID: DE 342 178 909</p>
          <p>Aufsichtsbehörde: Landesanstalt für Medien NRW</p>
        </div>
      </div>
    </section>
  </>
);

export default Impressum;