import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: '',
  consent: false
};

const Contact = () => {
  const [form, setForm] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = 'Bitte geben Sie Ihren Namen an.';
    if (!form.email || !/^\S+@\S+\.\S+$/.test(form.email)) errs.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    if (!form.message.trim()) errs.message = 'Bitte schildern Sie Ihr Anliegen.';
    if (!form.consent) errs.consent = 'Bitte stimmen Sie der Datenverarbeitung zu.';
    return errs;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length === 0) {
      setSubmitted(true);
      setForm(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Slexorifyx</title>
        <meta
          name="description"
          content="Kontaktieren Sie Slexorifyx für Kooperationen, Presseanfragen oder persönliche Kaufberatung."
        />
        <link rel="canonical" href="https://slexorifyx.com/contact" />
      </Helmet>
      <section className="bg-mist py-16 dark:bg-slateNight">
        <div className="mx-auto max-w-5xl space-y-12 px-4 sm:px-6 lg:px-8">
          <header className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              Kontakt
            </p>
            <h1 className="mt-3 font-display text-3xl font-bold text-slateNight dark:text-white">
              Wir sind für Sie da
            </h1>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
              Presse, Kooperation, Beta-Programm oder individuelle Kaufberatung – schreiben Sie uns.
              Wir antworten innerhalb von zwei Werktagen.
            </p>
          </header>

          <div className="grid gap-10 lg:grid-cols-2">
            <form
              onSubmit={handleSubmit}
              className="space-y-4 rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800"
            >
              <div>
                <label className="block text-sm font-medium text-slateNight dark:text-white">
                  Name *
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))}
                    className="mt-2 w-full rounded-full border border-slate-200 px-4 py-2 text-sm text-slate-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
                  />
                </label>
                {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-slateNight dark:text-white">
                  E-Mail *
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm((prev) => ({ ...prev, email: e.target.value }))}
                    className="mt-2 w-full rounded-full border border-slate-200 px-4 py-2 text-sm text-slate-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
                  />
                </label>
                {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-slateNight dark:text-white">
                  Unternehmen / Organisation
                  <input
                    type="text"
                    value={form.company}
                    onChange={(e) => setForm((prev) => ({ ...prev, company: e.target.value }))}
                    className="mt-2 w-full rounded-full border border-slate-200 px-4 py-2 text-sm text-slate-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
                  />
                </label>
              </div>
              <div>
                <label className="block text-sm font-medium text-slateNight dark:text-white">
                  Nachricht *
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm((prev) => ({ ...prev, message: e.target.value }))}
                    rows={5}
                    className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-slate-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
                  ></textarea>
                </label>
                {errors.message && <p className="mt-1 text-xs text-red-500">{errors.message}</p>}
              </div>
              <label className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-200">
                <input
                  type="checkbox"
                  checked={form.consent}
                  onChange={(e) => setForm((prev) => ({ ...prev, consent: e.target.checked }))}
                  className="mt-1 h-4 w-4 rounded accent-skyPulse"
                />
                <span>
                  Ich stimme zu, dass meine Angaben zur Beantwortung der Anfrage gespeichert werden.
                  Weitere Informationen in der <a href="/policy" className="text-skyPulse">Datenschutzerklärung</a>.
                </span>
              </label>
              {errors.consent && <p className="text-xs text-red-500">{errors.consent}</p>}
              <button
                type="submit"
                className="rounded-full bg-slateNight px-6 py-3 text-sm font-semibold text-mist transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:bg-skyPulse dark:text-slateNight"
              >
                Nachricht senden
              </button>
              {submitted && (
                <p className="text-sm text-skyPulse">
                  Danke! Wir melden uns innerhalb von zwei Werktagen.
                </p>
              )}
            </form>

            <div className="space-y-6">
              <div className="rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
                <h2 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                  Standorte & Kontakt
                </h2>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                  Slexorifyx GmbH<br />
                  Vogelsanger Straße 325<br />
                  50827 Köln
                </p>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                  Telefon: +49 (0)221 828 930 40<br />
                  E-Mail: hallo@slexorifyx.com
                </p>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                  Presse: press@slexorifyx.com<br />
                  Partnerschaften: partnerships@slexorifyx.com
                </p>
              </div>
              <div className="overflow-hidden rounded-3xl border border-cloud shadow-sm dark:border-slate-700">
                <iframe
                  title="Slexorifyx Standort Köln"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2516.134815437294!2d6.90937861574434!3d50.95374987954683!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47bf255bc8f0b2a3%3A0x586eccd9af70906f!2sVogelsanger%20Str.%20325%2C%2050827%20K%C3%B6ln!5e0!3m2!1sde!2sde!4v1689143077717!5m2!1sde!2sde"
                  width="100%"
                  height="300"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;