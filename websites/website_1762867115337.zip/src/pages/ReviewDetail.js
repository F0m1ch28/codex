import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { useParams, Link } from 'react-router-dom';
import { reviews } from '../data/content';
import PriceTrend from '../components/PriceTrend';
import EvidenzBox from '../components/EvidenzBox';
import { formatCurrency, formatDate } from '../utils/format';

const ReviewDetail = () => {
  const { slug } = useParams();
  const review = useMemo(
    () => reviews.find((item) => item.slug === slug),
    [slug]
  );

  const relatedReviews = useMemo(() => {
    if (!review) return [];
    return reviews.filter((item) =>
      review.alternatives?.includes(item.slug)
    );
  }, [review]);

  if (!review) {
    return (
      <section className="py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
            Review nicht gefunden
          </h1>
          <p className="mt-4 text-sm text-slate-600 dark:text-slate-200">
            Dieses Review ist aktuell nicht verfügbar. Zurück zur{' '}
            <Link to="/reviews" className="text-skyPulse">
              Übersicht
            </Link>
            .
          </p>
        </div>
      </section>
    );
  }

  const schemaReview = {
    '@context': 'https://schema.org',
    '@type': 'Review',
    itemReviewed: {
      '@type': 'Product',
      name: review.title,
      image: review.coverImage,
      description: review.shortDescription,
      sku: review.id,
      brand: {
        '@type': 'Brand',
        name: review.title.split(' ')[0]
      },
      offers: {
        '@type': 'Offer',
        priceCurrency: 'EUR',
        price: review.currentPrice.toFixed(2),
        availability: 'https://schema.org/InStock'
      }
    },
    author: {
      '@type': 'Person',
      name: review.author
    },
    datePublished: review.reviewDate,
    reviewBody: review.summary,
    reviewRating: {
      '@type': 'Rating',
      ratingValue: review.rating,
      bestRating: '100',
      worstRating: '0'
    }
  };

  const schemaProduct = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: review.title,
    description: review.shortDescription,
    image: review.coverImage,
    brand: review.title.split(' ')[0],
    offers: {
      '@type': 'Offer',
      url: `https://slexorifyx.com/reviews/${review.slug}`,
      priceCurrency: 'EUR',
      price: review.currentPrice,
      availability: 'https://schema.org/InStock'
    },
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: review.rating,
      reviewCount: review.reviewScoreCount
    }
  };

  return (
    <>
      <Helmet>
        <title>{review.title} | Review & Messwerte | Slexorifyx</title>
        <meta name="description" content={review.shortDescription} />
        <link rel="canonical" href={`https://slexorifyx.com/reviews/${review.slug}`} />
        <script type="application/ld+json">{JSON.stringify(schemaReview)}</script>
        <script type="application/ld+json">{JSON.stringify(schemaProduct)}</script>
      </Helmet>

      <article className="pb-20">
        <header className="relative bg-slateNight text-white">
          <img
            src={`${review.coverImage}`}
            alt={`${review.title} Produktvisualisierung`}
            className="absolute inset-0 h-full w-full object-cover opacity-40"
          />
          <div className="relative mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <Link to="/reviews" className="rounded-full bg-white/20 px-4 py-1">
                Zurück zur Übersicht
              </Link>
              <span className="rounded-full bg-skyPulse/30 px-4 py-1 text-skyPulse">
                {review.category}
              </span>
              <span className="rounded-full bg-white/10 px-4 py-1">
                Review vom {formatDate(review.reviewDate)}
              </span>
            </div>
            <h1 className="mt-6 max-w-3xl font-display text-4xl font-bold sm:text-5xl">
              {review.title}
            </h1>
            <p className="mt-4 max-w-2xl text-lg text-cloud/80">
              {review.heroSubtitle}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-4">
              <div className="rounded-2xl border border-white/30 bg-white/10 px-4 py-3">
                <p className="text-xs uppercase tracking-wider text-cloud/70">
                  Gesamtwertung
                </p>
                <p className="font-display text-3xl font-extrabold text-white">
                  {review.rating}/100
                </p>
              </div>
              <div className="rounded-2xl border border-white/30 bg-white/10 px-4 py-3 text-sm text-cloud/80">
                <p>
                  UVP: <strong>{formatCurrency(review.uvp)}</strong>
                </p>
                <p>
                  Aktuell: <strong>{formatCurrency(review.currentPrice)}</strong>
                </p>
              </div>
              <div className="rounded-2xl border border-white/30 bg-white/10 px-4 py-3 text-sm text-cloud/80">
                <p className="font-semibold text-white">
                  Autor:in {review.author}
                </p>
                <p>Veröffentlichung: {formatDate(review.reviewDate)}</p>
              </div>
            </div>
          </div>
        </header>

        <section className="mx-auto max-w-5xl space-y-12 px-4 pt-12 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-[0.65fr,0.35fr]">
            <div>
              <h2 className="font-display text-2xl font-semibold text-slateNight dark:text-white">
                Kurzfazit
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-slate-700 dark:text-slate-200">
                {review.summary}
              </p>
              <div className="mt-6 grid gap-6 md:grid-cols-2">
                <div className="rounded-2xl bg-skyPulse/10 p-5 dark:bg-skyPulse/20">
                  <h3 className="font-semibold text-slateNight dark:text-white">
                    Pros
                  </h3>
                  <ul className="mt-3 space-y-2 text-sm text-slate-700 dark:text-slate-200">
                    {review.pros.map((item) => (
                      <li key={item} className="flex gap-2">
                        <span aria-hidden="true">✔</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-2xl bg-cloud p-5 dark:bg-slate-800/70">
                  <h3 className="font-semibold text-slateNight dark:text-white">
                    Cons
                  </h3>
                  <ul className="mt-3 space-y-2 text-sm text-slate-700 dark:text-slate-200">
                    {review.cons.map((item) => (
                      <li key={item} className="flex gap-2">
                        <span aria-hidden="true">⚠</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-10 space-y-6">
                <h3 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                  Spezifikationen & Netzfragen
                </h3>
                <div className="overflow-hidden rounded-2xl border border-cloud dark:border-slate-700">
                  <table className="min-w-full border-collapse bg-white text-sm text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                    <tbody>
                      {Object.entries(review.specs).map(([key, value]) => (
                        <tr key={key} className="border-b border-cloud/70 dark:border-slate-700/70">
                          <th className="w-1/3 bg-cloud/60 px-4 py-3 text-left font-semibold uppercase tracking-wide text-slate-500 dark:bg-slate-700/50 dark:text-slate-300">
                            {key}
                          </th>
                          <td className="px-4 py-3">{value}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-300">
                  Hinweis: Alle Angaben geprüft auf Netz- und Steckdosenkompatibilität in Deutschland.
                  Gewährleistung: Mindestens 24 Monate Mängelhaftung laut Händlerangaben.
                </p>
              </div>
            </div>
            <aside className="space-y-6">
              <div className="rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
                <h3 className="font-display text-lg font-semibold text-slateNight dark:text-white">
                  Liefer- & Garantiehinweise
                </h3>
                <ul className="mt-3 space-y-2 text-sm text-slate-700 dark:text-slate-200">
                  <li>Versand: {review.availability}</li>
                  <li>{review.shippingInfo}</li>
                  <li>Gewährleistung: 24 Monate (gesetzlich), Garantie laut Hersteller.</li>
                </ul>
                <Link
                  to="/contact"
                  className="mt-4 inline-flex items-center gap-2 rounded-full bg-slateNight px-4 py-2 text-sm font-semibold text-mist transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:bg-skyPulse dark:text-slateNight"
                >
                  Beratungsanfrage
                </Link>
              </div>
              <div className="space-y-4">
                {review.measurements.map((measure) => (
                  <EvidenzBox key={measure.label} {...measure} />
                ))}
              </div>
            </aside>
          </div>

          <section>
            <h3 className="font-display text-xl font-semibold text-slateNight dark:text-white">
              Preisentwicklung & Marktverfügbarkeit
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              Wir tracken autorisierte Händler, überprüfen Lieferzeiten und garantieren,
              dass keine Grauimporte in die Bewertung einfließen.
            </p>
            <div className="mt-6">
              <PriceTrend data={review.priceHistory} />
            </div>
          </section>

          <section className="grid gap-6 lg:grid-cols-[0.6fr,0.4fr]">
            <div className="rounded-3xl border border-cloud bg-white p-6 dark:border-slate-700 dark:bg-slate-800">
              <h3 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                Langzeitnotizen
              </h3>
              <ul className="mt-4 space-y-4 text-sm text-slate-600 dark:text-slate-200">
                {review.longTermInsights.map((entry) => (
                  <li key={entry.month} className="rounded-2xl bg-cloud/70 p-4 dark:bg-slate-700/60">
                    <p className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                      {formatDate(`${entry.month}-01`)}
                    </p>
                    <p className="mt-1">{entry.text}</p>
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-3xl border border-skyPulse/40 bg-skyPulse/15 p-6 dark:border-skyPulse/30 dark:bg-skyPulse/10">
              <h4 className="font-display text-lg font-semibold text-slateNight dark:text-slate-900">
                Community Insight
              </h4>
              <p className="mt-2 text-sm text-slate-700 dark:text-slate-900/80">
                Feedback aus Early-Tester:innen wird anonymisiert und nach Relevanz
                priorisiert. Änderungen an Firmware oder Hardware markieren wir oben im
                Review mit Versionsnummer und Datum.
              </p>
            </div>
          </section>

          {relatedReviews.length > 0 && (
            <section className="rounded-3xl border border-cloud bg-white p-6 dark:border-slate-700 dark:bg-slate-800">
              <h3 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                Alternativen im Vergleich
              </h3>
              <div className="mt-4 grid gap-6 md:grid-cols-2">
                {relatedReviews.map((item) => (
                  <div
                    key={item.id}
                    className="rounded-2xl border border-cloud p-4 transition hover:border-skyPulse hover:shadow-md dark:border-slate-700 dark:hover:border-skyPulse"
                  >
                    <h4 className="font-semibold text-slateNight dark:text-white">
                      {item.title}
                    </h4>
                    <p className="mt-2 text-sm text-slate-600 dark:text-slate-200">
                      {item.shortDescription}
                    </p>
                    <Link
                      to={`/reviews/${item.slug}`}
                      className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-skyPulse hover:text-aquaPulse"
                    >
                      Review lesen →
                    </Link>
                  </div>
                ))}
              </div>
            </section>
          )}
        </section>
      </article>
    </>
  );
};

export default ReviewDetail;