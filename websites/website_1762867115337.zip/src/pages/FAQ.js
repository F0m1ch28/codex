import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { faqItems } from '../data/content';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  const schemaFaq = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqItems.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer
      }
    }))
  };

  return (
    <>
      <Helmet>
        <title>FAQ – Antworten auf häufige Fragen | Slexorifyx</title>
        <meta
          name="description"
          content="Alles zu Teilnahmebedingungen, Messwerten, Datenschutz und Versand bei Slexorifyx."
        />
        <link rel="canonical" href="https://slexorifyx.com/faq" />
        <script type="application/ld+json">{JSON.stringify(schemaFaq)}</script>
      </Helmet>
      <section className="bg-white py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <header className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              FAQ
            </p>
            <h1 className="mt-3 font-display text-3xl font-bold text-slateNight dark:text-white">
              Antworten auf häufige Fragen
            </h1>
          </header>

          <div className="mt-12 space-y-4">
            {faqItems.map((faq, index) => {
              const isOpen = index === openIndex;
              return (
                <div
                  key={faq.question}
                  className="overflow-hidden rounded-3xl border border-cloud bg-white transition dark:border-slate-700 dark:bg-slate-800"
                >
                  <button
                    onClick={() => setOpenIndex(isOpen ? -1 : index)}
                    className="flex w-full items-center justify-between px-6 py-4 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse"
                    aria-expanded={isOpen}
                  >
                    <span className="font-semibold text-slateNight dark:text-white">
                      {faq.question}
                    </span>
                    <span aria-hidden="true" className="text-2xl text-skyPulse">
                      {isOpen ? '−' : '+'}
                    </span>
                  </button>
                  {isOpen && (
                    <div className="px-6 pb-6 text-sm text-slate-600 dark:text-slate-200">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
};

export default FAQ;