import React from 'react';
import { Helmet } from 'react-helmet-async';

const Terms = () => (
  <>
    <Helmet>
      <title>Nutzungsbedingungen | Slexorifyx</title>
      <meta
        name="description"
        content="Nutzungsbedingungen für slexorifyx.com inklusive Haftungsausschluss und Urheberrecht."
      />
      <link rel="canonical" href="https://slexorifyx.com/terms" />
    </Helmet>
    <section className="bg-mist py-16 dark:bg-slateNight">
      <div className="mx-auto max-w-4xl space-y-6 px-4 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
          Nutzungsbedingungen
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          Nutzung unserer Inhalte ausschließlich für private und journalistische Zwecke.
          Labordaten dürfen zitiert werden, sofern Quelle genannt und Link gesetzt wird.
        </p>
        <div className="space-y-4 text-sm text-slate-600 dark:text-slate-200">
          <section>
            <h2 className="font-semibold text-slateNight dark:text-white">Haftung für Inhalte</h2>
            <p>Wir prüfen Inhalte sorgfältig, übernehmen jedoch keine Gewähr für Aktualität.</p>
          </section>
          <section>
            <h2 className="font-semibold text-slateNight dark:text-white">Haftung für Links</h2>
            <p>Wir verlinken auf seriöse Quellen. Für externe Inhalte übernehmen wir keine Verantwortung.</p>
          </section>
          <section>
            <h2 className="font-semibold text-slateNight dark:text-white">Urheberrecht</h2>
            <p>Alle Inhalte stehen unter Creative Commons BY-NC-SA 4.0, sofern nicht anders gekennzeichnet.</p>
          </section>
        </div>
      </div>
    </section>
  </>
);

export default Terms;