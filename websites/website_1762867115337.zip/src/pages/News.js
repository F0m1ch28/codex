import React from 'react';
import { Helmet } from 'react-helmet-async';
import { newsArticles } from '../data/content';

const News = () => {
  return (
    <>
      <Helmet>
        <title>News & Analysen | Slexorifyx</title>
        <meta
          name="description"
          content="Aktuelle Branchennews zu Gadgets, Energie und Smart Home mit Fokus auf den deutschen Markt."
        />
        <link rel="canonical" href="https://slexorifyx.com/news" />
      </Helmet>
      <section className="bg-mist py-16 dark:bg-slateNight">
        <div className="mx-auto max-w-6xl space-y-12 px-4 sm:px-6 lg:px-8">
          <header>
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              News & Analysen
            </p>
            <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
              Updates aus Laboren, Markt und Politik
            </h1>
            <p className="mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
              Wir beleuchten Technologien, Förderungen und Firmware-Updates mit Relevanz
              für deutsche Verbraucher:innen. Alle Beiträge sind unabhängig recherchiert.
            </p>
          </header>

          <div className="grid gap-8 md:grid-cols-2">
            {newsArticles.map((article) => (
              <article
                id={article.slug}
                key={article.id}
                className="rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800"
              >
                <img
                  src={article.image}
                  alt={`Symbolbild für ${article.title}`}
                  className="h-48 w-full rounded-2xl object-cover"
                  loading="lazy"
                />
                <div className="mt-4 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                  {new Date(article.date).toLocaleDateString('de-DE')} · {article.category}
                </div>
                <h2 className="mt-2 font-display text-xl font-semibold text-slateNight dark:text-white">
                  {article.title}
                </h2>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                  {article.excerpt}
                </p>
                <p className="mt-4 text-xs text-slate-500 dark:text-slate-300">
                  Autor:in {article.author}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default News;