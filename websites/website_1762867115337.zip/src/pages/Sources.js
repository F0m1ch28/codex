import React from 'react';
import { Helmet } from 'react-helmet-async';

const Sources = () => (
  <>
    <Helmet>
      <title>Quellenverzeichnis | Slexorifyx</title>
      <meta
        name="description"
        content="Alle externen Quellen, Normen und Messreferenzen, die wir in unseren Tests nutzen."
      />
      <link rel="canonical" href="https://slexorifyx.com/quellen" />
    </Helmet>
    <section className="bg-mist py-16 dark:bg-slateNight">
      <div className="mx-auto max-w-4xl space-y-6 px-4 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
          Quellen & Referenzen
        </h1>
        <ul className="list-disc space-y-3 pl-5 text-sm text-slate-600 dark:text-slate-200">
          <li>IEC 62368-1: Sicherheitsanforderungen für Audio-/Video-, Informations- und Kommunikationstechnikgeräte.</li>
          <li>Calman Ultimate 2024: Farbkalibrierung und ΔE-Analyse.</li>
          <li>Bundesnetzagentur SAR-Datenbank (Stand 2024).</li>
          <li>Bitkom-Leitfaden „Cloud Computing und Datenschutz“ 2023.</li>
          <li>DIN EN 60268-5: Lautsprecher-Messnorm (Anwendung im Akustik-Lab Berlin).</li>
        </ul>
      </div>
    </section>
  </>
);

export default Sources;