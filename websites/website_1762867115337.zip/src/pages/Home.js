import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import ReviewCard from '../components/ReviewCard';
import PriceTrend from '../components/PriceTrend';
import EvidenzBox from '../components/EvidenzBox';
import NewsletterForm from '../components/NewsletterForm';
import { stats, reviews, betaPrograms, longTermTests, projects, testimonials, newsArticles, faqItems } from '../data/content';
import { useInView } from '../hooks/useInView';

const Counter = ({ value, suffix, label, description }) => {
  const { ref, isIntersecting } = useInView();
  const [displayValue, setDisplayValue] = useState(0);

  React.useEffect(() => {
    if (isIntersecting) {
      const interval = setInterval(() => {
        setDisplayValue((prev) => {
          if (prev >= value) {
            clearInterval(interval);
            return value;
          }
          const increment = Math.ceil(value / 60);
          return Math.min(value, prev + increment);
        });
      }, 16);
      return () => clearInterval(interval);
    }
  }, [isIntersecting, value]);

  return (
    <div
      ref={ref}
      className="rounded-2xl border border-cloud bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-700 dark:bg-slate-800"
    >
      <p className="text-sm font-medium uppercase tracking-wide text-slate-500 dark:text-slate-300">
        {label}
      </p>
      <p className="mt-2 font-display text-4xl font-bold text-slateNight dark:text-white">
        {displayValue}
        {suffix}
      </p>
      <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">
        {description}
      </p>
    </div>
  );
};

const TestimonialsCarousel = ({ items }) => {
  const [index, setIndex] = useState(0);
  const next = () => setIndex((prev) => (prev + 1) % items.length);
  const prev = () =>
    setIndex((prev) => (prev - 1 + items.length) % items.length);

  React.useEffect(() => {
    const timer = setInterval(next, 8000);
    return () => clearInterval(timer);
  }, []);

  const item = items[index];
  return (
    <div className="relative overflow-hidden rounded-3xl border border-skyPulse/30 bg-skyPulse/15 p-6 text-slate-700 dark:border-skyPulse/20 dark:bg-skyPulse/10 dark:text-slate-100">
      <blockquote className="text-lg leading-relaxed">
        „{item.quote}“
      </blockquote>
      <cite className="mt-6 block text-sm font-semibold text-slateNight dark:text-white">
        {item.name} · {item.role}
      </cite>
      <div className="mt-6 flex gap-2">
        <button
          onClick={prev}
          className="rounded-full bg-white/70 px-4 py-2 text-sm font-medium text-slateNight shadow-sm transition hover:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:bg-slate-800/70 dark:text-white"
          aria-label="Vorheriges Testimonial"
        >
          ←
        </button>
        <button
          onClick={next}
          className="rounded-full bg-slateNight px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:bg-skyPulse dark:text-slateNight dark:hover:bg-aquaPulse"
          aria-label="Nächstes Testimonial"
        >
          →
        </button>
      </div>
    </div>
  );
};

const Home = () => {
  const topReviews = useMemo(() => reviews.slice(0, 4), []);
  const priceChampion = useMemo(() => reviews[0], []);

  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Slexorifyx',
    url: 'https://slexorifyx.com',
    logo: 'https://slexorifyx.com/logo.png',
    sameAs: [
      'https://www.linkedin.com',
      'https://www.youtube.com',
      'https://mastodon.social'
    ],
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: (
        reviews.reduce((sum, item) => sum + item.rating, 0) / reviews.length
      ).toFixed(1),
      ratingCount: reviews.reduce((sum, item) => sum + item.reviewScoreCount, 0)
    }
  };

  return (
    <>
      <Helmet>
        <title>Slexorifyx – Früh dabei. Besser entscheiden.</title>
        <meta
          name="description"
          content="Slexorifyx liefert unabhängige Gadget-Reviews, Langzeittests und Early-Access-Programme für den deutschen Markt – mit nachvollziehbaren Messwerten und Preisanalysen."
        />
        <link rel="canonical" href="https://slexorifyx.com/" />
        <script type="application/ld+json">{JSON.stringify(schemaData)}</script>
      </Helmet>

      <section className="relative overflow-hidden bg-gradient-to-b from-mist via-white to-mist dark:from-slateNight dark:via-slate-900 dark:to-slateNight">
        <div className="absolute inset-0 -z-10 bg-[url('https://picsum.photos/1600/900?random=1')] bg-cover bg-center opacity-10"></div>
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-[2fr,1fr] lg:items-center">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-skyPulse/20 px-4 py-2 text-sm font-medium text-slateNight dark:bg-skyPulse/30 dark:text-white">
                Neue Ausgabe 07/2024
              </span>
              <h1 className="mt-6 max-w-3xl font-display text-4xl font-extrabold tracking-tight text-slateNight sm:text-5xl lg:text-6xl dark:text-white">
                Früh dabei. <span className="text-skyPulse">Besser entscheiden.</span>
              </h1>
              <p className="mt-6 max-w-2xl text-lg text-slate-600 dark:text-slate-200">
                Unabhängige Tests, echte Messwerte, frühzeitiger Zugriff auf die
                spannendsten Gadgets in Deutschland. Wir dokumentieren jede Messung,
                verhandeln faire Early-Access-Kontingente und begleiten Produkte durch
                den gesamten Lebenszyklus – von der Steckdose bis zur Reparaturwerkbank.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link
                  to="/early"
                  className="inline-flex items-center gap-3 rounded-full bg-slateNight px-6 py-3 text-base font-semibold text-mist shadow-lg shadow-slateNight/20 transition hover:-translate-y-[1px] hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:bg-skyPulse dark:text-slateNight dark:hover:bg-aquaPulse"
                >
                  Early Access sichern
                  <span aria-hidden="true" className="text-xl">→</span>
                </Link>
                <Link
                  to="/reviews"
                  className="inline-flex items-center gap-2 rounded-full border border-slateNight bg-white px-6 py-3 text-base font-semibold text-slateNight transition hover:border-skyPulse hover:text-skyPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:border-slate-600 dark:bg-slate-800 dark:text-cloud dark:hover:border-skyPulse dark:hover:text-skyPulse"
                >
                  Alle Reviews ansehen
                </Link>
              </div>
              <div className="mt-10 grid gap-4 sm:grid-cols-3">
                {stats.map((stat) => (
                  <Counter key={stat.id} {...stat} />
                ))}
              </div>
            </div>
            <div className="rounded-3xl border border-white/40 bg-white/80 p-6 shadow-floating backdrop-blur dark:border-slate-700/70 dark:bg-slate-800/80">
              <h3 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                Diese Woche im Fokus
              </h3>
              <ul className="mt-4 space-y-4 text-sm text-slate-600 dark:text-slate-200">
                <li className="rounded-xl bg-cloud/70 p-4 shadow-sm dark:bg-slate-700/60">
                  <p className="font-semibold text-slateNight dark:text-white">
                    Bosch Smart Home Controller II
                  </p>
                  <p>Live-Test Matter-Update mit KNX-Bridge.</p>
                </li>
                <li className="rounded-xl bg-cloud/70 p-4 shadow-sm dark:bg-slate-700/60">
                  <p className="font-semibold text-slateNight dark:text-white">
                    Framework Field Notes
                  </p>
                  <p>Neue Akkumodule im 30-Tage-Härtetest.</p>
                </li>
                <li className="rounded-xl bg-cloud/70 p-4 shadow-sm dark:bg-slate-700/60">
                  <p className="font-semibold text-slateNight dark:text-white">
                    Glyph Automation Update
                  </p>
                  <p>Nothing OS 2.5.3 prüft regionale Einschränkungen.</p>
                </li>
              </ul>
              <div className="mt-6">
                <NewsletterForm />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="top-reviews" className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                Top-Reviews
              </p>
              <h2
                id="top-reviews"
                className="font-display text-3xl font-bold text-slateNight dark:text-white"
              >
                Aktuelle Tests mit Evidenz
              </h2>
              <p className="mt-2 max-w-xl text-sm text-slate-600 dark:text-slate-300">
                Jede Review enthält Messprotokolle, Preisanalysen und Hinweise zur
                Gewährleistung für Deutschland. Wir kennzeichnen Beta-Firmware klar
                und verlinken offizielle Hersteller-Quellen.
              </p>
            </div>
            <Link
              to="/reviews"
              className="inline-flex items-center gap-2 rounded-full border border-slateNight px-5 py-2 text-sm font-semibold text-slateNight transition hover:border-skyPulse hover:text-skyPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:border-slate-600 dark:text-cloud"
            >
              Zu allen Tests
            </Link>
          </div>

          <div className="mt-10 grid gap-8 md:grid-cols-2 xl:grid-cols-3">
            {topReviews.map((review) => (
              <ReviewCard key={review.id} review={review} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-20 dark:bg-slate-900">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-[1.2fr,0.8fr] lg:items-center">
            <PriceTrend data={priceChampion.priceHistory} />
            <div className="space-y-6 rounded-3xl bg-slateNight px-6 py-8 text-mist shadow-xl dark:bg-slate-800">
              <h3 className="font-display text-2xl font-semibold">
                Preisradar – Fairphone 5
              </h3>
              <p className="text-sm text-cloud/80">
                Unser Preisradar trackt UVP, Straßenpreis und Angebotstage bei
                autorisierten Händlern in Deutschland. Benachrichtigungen lassen sich
                in der Deal-Sektion aktivieren.
              </p>
              <EvidenzBox
                label="Messung Netzteil-Hitzeentwicklung"
                value="max. 58 °C nach 30 min"
                method="FLIR Wärmebildkamera, Laborstrom bei 230 V"
                source="Energy Insight Yard"
              />
              <Link
                to="/deals"
                className="inline-flex items-center gap-2 rounded-full bg-skyPulse px-5 py-2 text-sm font-semibold text-slateNight transition hover:bg-aquaPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-slateNight"
              >
                Preisalarm aktivieren
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl space-y-10 px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                Beta & Wartelisten
              </p>
              <h2 className="font-display text-3xl font-bold text-slateNight dark:text-white">
                Programme mit begrenzten Slots
              </h2>
              <p className="mt-2 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
                Wir prüfen rechtliche Rahmenbedingungen, kümmern uns um Versicherungen
                und stellen technische Ansprechpartner:innen bereit. Transparente
                Auswahlkriterien sichern faire Teilnahme.
              </p>
            </div>
            <Link
              to="/early"
              className="inline-flex items-center gap-2 rounded-full border border-slateNight px-5 py-2 text-sm font-semibold text-slateNight transition hover:border-skyPulse hover:text-skyPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:text-cloud"
            >
              Alle Programme
            </Link>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {betaPrograms.map((program) => (
              <article
                key={program.id}
                className="flex flex-col rounded-2xl border border-cloud bg-white/80 p-6 shadow-sm backdrop-blur transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-700 dark:bg-slate-800/80"
              >
                <div className="flex items-center justify-between text-sm">
                  <span className="rounded-full bg-slateNight px-3 py-1 text-mist dark:bg-skyPulse dark:text-slateNight">
                    {program.status}
                  </span>
                  <span className="text-slate-500 dark:text-slate-300">
                    {program.slots} Plätze
                  </span>
                </div>
                <h3 className="mt-4 font-display text-xl font-semibold text-slateNight dark:text-white">
                  {program.name}
                </h3>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-200">
                  {program.description}
                </p>
                <dl className="mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-200">
                  <div className="flex justify-between">
                    <dt className="font-semibold">Start:</dt>
                    <dd>{new Date(program.startDate).toLocaleDateString('de-DE')}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="font-semibold">Ort:</dt>
                    <dd>{program.location}</dd>
                  </div>
                </dl>
                <div className="mt-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
                    Voraussetzungen
                  </p>
                  <ul className="mt-1 space-y-1 text-sm">
                    {program.requirements.map((req) => (
                      <li key={req} className="flex gap-2">
                        <span aria-hidden="true">•</span> {req}
                      </li>
                    ))}
                  </ul>
                </div>
                <a
                  href={`mailto:${program.contactEmail}`}
                  className="mt-auto inline-flex items-center gap-2 rounded-full bg-slateNight px-4 py-2 text-sm font-semibold text-mist transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:bg-skyPulse dark:text-slateNight"
                >
                  Interesse melden
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-b from-white to-mist py-20 dark:from-slate-900 dark:to-slateNight">
        <div className="mx-auto max-w-7xl space-y-10 px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-2">
            <div className="rounded-3xl border border-cloud bg-white p-8 shadow-lg dark:border-slate-700 dark:bg-slate-800">
              <h3 className="font-display text-2xl font-semibold text-slateNight dark:text-white">
                So testen wir – unser Prozess
              </h3>
              <ol className="mt-6 space-y-5 text-sm text-slate-600 dark:text-slate-200">
                <li>
                  <span className="font-semibold text-slateNight dark:text-white">
                    1. Eingangskontrolle
                  </span>
                  <p>Seriennummer, Firmware-Stand, Lieferumfang inkl. EU-Netzteil werden dokumentiert.</p>
                </li>
                <li>
                  <span className="font-semibold text-slateNight dark:text-white">
                    2. Messreihen
                  </span>
                  <p>Display, Leistung, Energieaufnahme und Wireless prüfen wir nach IEC-Normen.</p>
                </li>
                <li>
                  <span className="font-semibold text-slateNight dark:text-white">
                    3. Alltagstest & Feldversuch
                  </span>
                  <p>Community-Tester:innen erhalten Feedback-Kits, Messungen werden verifiziert.</p>
                </li>
                <li>
                  <span className="font-semibold text-slateNight dark:text-white">
                    4. Veröffentlichung & Langzeitlog
                  </span>
                  <p>Review, Preisradar und Langzeittagebuch bleiben dynamisch und versioniert.</p>
                </li>
              </ol>
            </div>
            <div className="rounded-3xl border border-cloud bg-white p-8 shadow-lg dark:border-slate-700 dark:bg-slate-800">
              <h3 className="font-display text-2xl font-semibold text-slateNight dark:text-white">
                Stimmen aus der Community
              </h3>
              <TestimonialsCarousel items={testimonials} />
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {projects.map((project) => (
              <div
                key={project.id}
                className="group rounded-3xl border border-cloud bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl dark:border-slate-700 dark:bg-slate-800"
              >
                <div className="overflow-hidden rounded-t-3xl">
                  <img
                    src={`${project.image}`}
                    alt={`Projektfoto ${project.title}`}
                    className="h-44 w-full object-cover transition duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                </div>
                <div className="space-y-3 p-6">
                  <span className="inline-block rounded-full bg-skyPulse/20 px-3 py-1 text-xs font-medium text-skyPulse">
                    {project.category}
                  </span>
                  <h4 className="font-semibold text-slateNight dark:text-white">
                    {project.title}
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-200">
                    {project.summary}
                  </p>
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
                    Besonderheit
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-200">
                    {project.highlight}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl space-y-12 px-4 sm:px-6 lg:px-8">
          <div className="grid gap-6 lg:grid-cols-[0.4fr,0.6fr]">
            <div className="rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
              <h3 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                Langzeittests
              </h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-200">
                Laufende Tagebücher mit monatlichen Updates, offen einsehbaren Messprotokollen
                und Community-Kommentaren.
              </p>
              <Link
                to="/reviews"
                className="mt-4 inline-flex items-center gap-2 rounded-full border border-slateNight px-5 py-2 text-sm font-semibold text-slateNight transition hover:border-skyPulse hover:text-skyPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:border-slate-600 dark:text-cloud"
              >
                Zu den Langzeittests
              </Link>
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              {longTermTests.map((entry) => (
                <div
                  key={entry.id}
                  className="rounded-3xl border border-cloud bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800"
                >
                  <img
                    src={entry.image}
                    alt={`Langzeittest ${entry.title}`}
                    className="h-32 w-full rounded-2xl object-cover"
                    loading="lazy"
                  />
                  <h4 className="mt-4 font-semibold text-slateNight dark:text-white">
                    {entry.title}
                  </h4>
                  <p className="mt-2 text-sm text-slate-600 dark:text-slate-200">
                    {entry.summary}
                  </p>
                  <p className="mt-2 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                    Letztes Update: {new Date(entry.latestUpdate).toLocaleDateString('de-DE')}
                  </p>
                  <ul className="mt-2 space-y-1 text-sm text-slate-600 dark:text-slate-200">
                    {entry.insights.map((insight) => (
                      <li key={insight} className="flex gap-2">
                        <span aria-hidden="true">•</span> {insight}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl bg-slateNight px-8 py-10 text-white shadow-xl dark:bg-slate-800">
            <div className="grid gap-10 md:grid-cols-2 md:items-center">
              <div>
                <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                  Call to Action
                </p>
                <h3 className="mt-3 font-display text-3xl font-bold">
                  Werden Sie Teil der Test-Community
                </h3>
                <p className="mt-4 text-sm text-cloud/80">
                  Erhalten Sie frühzeitige Zugänge, teilen Sie Ihr Feedback mit Herstellern
                  und helfen Sie uns, Transparenz am deutschen Markt voranzutreiben.
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/early"
                  className="inline-flex items-center gap-2 rounded-full bg-skyPulse px-5 py-3 text-sm font-semibold text-slateNight transition hover:bg-aquaPulse focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 focus-visible:ring-offset-slateNight"
                >
                  Bewerbung starten
                </Link>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 rounded-full border border-white px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 focus-visible:ring-offset-slateNight"
                >
                  Beratung anfordern
                </Link>
              </div>
            </div>
          </div>

          <div className="grid gap-10 lg:grid-cols-[0.6fr,0.4fr]">
            <div className="rounded-3xl border border-cloud bg-white p-8 shadow-lg dark:border-slate-700 dark:bg-slate-800">
              <h3 className="font-display text-2xl font-semibold text-slateNight dark:text-white">
                Aktuelle Insights & News
              </h3>
              <div className="mt-6 grid gap-6">
                {newsArticles.slice(0, 3).map((article) => (
                  <article key={article.id} className="flex flex-col gap-4 border-b border-cloud/60 pb-4 last:border-b-0 dark:border-slate-700/70">
                    <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                      <span>{new Date(article.date).toLocaleDateString('de-DE')}</span>
                      <span>•</span>
                      <span>{article.category}</span>
                    </div>
                    <h4 className="text-lg font-semibold text-slateNight transition hover:text-skyPulse dark:text-white">
                      <Link to={`/news#${article.slug}`}>{article.title}</Link>
                    </h4>
                    <p className="text-sm text-slate-600 dark:text-slate-200">
                      {article.excerpt}
                    </p>
                    <Link
                      to={`/news#${article.slug}`}
                      className="text-sm font-semibold text-skyPulse hover:text-aquaPulse"
                    >
                      Weiterlesen →
                    </Link>
                  </article>
                ))}
              </div>
            </div>
            <div className="rounded-3xl border border-cloud bg-white p-8 shadow-lg dark:border-slate-700 dark:bg-slate-800">
              <h3 className="font-display text-2xl font-semibold text-slateNight dark:text-white">
                Häufig gefragt
              </h3>
              <div className="mt-6 space-y-5">
                {faqItems.slice(0, 3).map((faq) => (
                  <div key={faq.question}>
                    <p className="font-semibold text-slateNight dark:text-white">
                      {faq.question}
                    </p>
                    <p className="mt-1 text-sm text-slate-600 dark:text-slate-200">
                      {faq.answer}
                    </p>
                  </div>
                ))}
                <Link
                  to="/faq"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-skyPulse hover:text-aquaPulse"
                >
                  Zur FAQ-Seite →
                </Link>
              </div>
            </div>
          </div>

          <div className="rounded-3xl border border-cloud bg-white p-10 shadow-xl dark:border-slate-700 dark:bg-slate-800">
            <h3 className="font-display text-3xl font-bold text-slateNight dark:text-white">
              Newsletter „Frühstarter“
            </h3>
            <p className="mt-4 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
              Jeden Donnerstag: Marktanalysen, Firmware-Notizen, Preisalarme und offene Slots in
              Early-Access-Programmen. Kein Abo-Funnel, keine Datenweitergabe – wir halten uns an
              DSGVO und nutzen Server in Frankfurt am Main.
            </p>
            <div className="mt-6 max-w-md">
              <NewsletterForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;