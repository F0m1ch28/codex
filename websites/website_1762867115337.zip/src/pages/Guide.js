import React from 'react';
import { Helmet } from 'react-helmet-async';
import { guides } from '../data/content';
import EvidenzBox from '../components/EvidenzBox';

const Guide = () => {
  return (
    <>
      <Helmet>
        <title>Guide: Kaufberatung & Recht in Deutschland | Slexorifyx</title>
        <meta
          name="description"
          content="Kaufberatung, Steckdosen- und Netzfragen, Gewährleistung, Datenschutz und Refurbished-Tipps speziell für den deutschen Markt."
        />
        <link rel="canonical" href="https://slexorifyx.com/guide" />
      </Helmet>
      <section className="bg-white py-16 dark:bg-slate-900">
        <div className="mx-auto max-w-6xl space-y-12 px-4 sm:px-6 lg:px-8">
          <header className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
              Kaufberatung & Wissen
            </p>
            <h1 className="mt-3 font-display text-3xl font-bold text-slateNight dark:text-white">
              Orientierung für den deutschen Markt
            </h1>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
              Unsere Guides basieren auf Praxistests, Gesprächen mit Reparaturbetrieben,
              rechtlicher Beratung und Nutzerfeedback aus Early-Access-Programmen.
            </p>
          </header>

          <div className="grid gap-8 md:grid-cols-2">
            {guides.map((guide) => (
              <article
                key={guide.id}
                className="rounded-3xl border border-cloud bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-700 dark:bg-slate-800"
              >
                <h2 className="font-display text-xl font-semibold text-slateNight dark:text-white">
                  {guide.title}
                </h2>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-200">
                  {guide.summary}
                </p>
                <ul className="mt-4 space-y-2 text-sm text-slate-600 dark:text-slate-200">
                  {guide.tips.map((tip) => (
                    <li key={tip} className="flex gap-2">
                      <span aria-hidden="true">•</span> {tip}
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>

          <section className="rounded-3xl bg-slateNight px-8 py-10 text-white dark:bg-slate-800">
            <h2 className="font-display text-2xl font-bold">Evidenz in unseren Guides</h2>
            <p className="mt-4 max-w-2xl text-sm text-cloud/80">
              Messwerte, Normen und Quellen werden transparent aufbereitet. Wir validieren
              Herstellerangaben und listen alle Drittquellen im Quellenverzeichnis.
            </p>
            <div className="mt-6 grid gap-4 md:grid-cols-3">
              <EvidenzBox
                label="Netzteil-Prüfungen"
                value="IEC 62368-1, VDE 0620"
                method="Gerätesicherheit & Effizienzprüfung"
                source="Gegenprüfung mit TÜV Rheinland"
              />
              <EvidenzBox
                label="Datenschutz-Audits"
                value="DSGVO Art. 28 Verträge"
                method="Fragenkatalog anhand Bitkom-Leitfaden"
                source="Legal Partner Kanzlei Mertens"
              />
              <EvidenzBox
                label="Refurb-Qualität"
                value="Mind. 85 % Akkukapazität"
                method="QD-Technik Diagnosetools, Logfile-Auswertung"
                source="Refurb-Partnerprogramm 2024"
              />
            </div>
          </section>
        </div>
      </section>
    </>
  );
};

export default Guide;