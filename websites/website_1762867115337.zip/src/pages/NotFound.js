import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => (
  <section className="bg-mist py-20 dark:bg-slateNight">
    <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
      <h1 className="font-display text-5xl font-bold text-slateNight dark:text-white">
        404
      </h1>
      <p className="mt-4 text-sm text-slate-600 dark:text-slate-300">
        Diese Seite konnte nicht gefunden werden.
      </p>
      <Link
        to="/"
        className="mt-6 inline-flex items-center gap-2 rounded-full bg-slateNight px-6 py-3 text-sm font-semibold text-mist transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:bg-skyPulse dark:text-slateNight"
      >
        Zur Startseite
      </Link>
    </div>
  </section>
);

export default NotFound;