import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { deals } from '../data/content';
import { formatCurrency } from '../utils/format';

const Deals = () => {
  const [sort, setSort] = useState('soon');
  const sortedDeals = useMemo(() => {
    return [...deals].sort((a, b) => {
      if (sort === 'discount') {
        return b.originalPrice - b.price - (a.originalPrice - a.price);
      }
      return new Date(a.validUntil) - new Date(b.validUntil);
    });
  }, [sort]);

  return (
    <>
      <Helmet>
        <title>Deals & Preisalarme | Slexorifyx</title>
        <meta
          name="description"
          content="Ausgewählte Angebote für Deutschland – geprüft auf Gewährleistung, Versandbedingungen und Netzteilkonformität."
        />
        <link rel="canonical" href="https://slexorifyx.com/deals" />
      </Helmet>
      <section className="bg-mist py-16 dark:bg-slateNight">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-wide text-skyPulse">
                Deals für Deutschland
              </p>
              <h1 className="font-display text-3xl font-bold text-slateNight dark:text-white">
                Angebote mit geprüfter Gewährleistung
              </h1>
              <p className="mt-3 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
                Wir listen nur Angebote von autorisierten Händlern mit vollständigem
                Lieferumfang, EU-Netzteilen und nachvollziehbaren Garantiebedingungen.
              </p>
            </div>
            <div>
              <label className="text-sm font-medium text-slateNight dark:text-slate-200">
                Sortieren nach
              </label>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="ml-3 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200"
              >
                <option value="soon">Läuft bald ab</option>
                <option value="discount">Höchste Ersparnis</option>
              </select>
            </div>
          </header>

          <div className="mt-10 space-y-8">
            {sortedDeals.map((deal) => (
              <article
                key={deal.id}
                className="rounded-3xl border border-cloud bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-xl dark:border-slate-700 dark:bg-slate-800"
              >
                <header className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h2 className="font-display text-2xl font-semibold text-slateNight dark:text-white">
                      {deal.title}
                    </h2>
                    <p className="text-sm text-slate-600 dark:text-slate-200">
                      Händler: {deal.vendor}
                    </p>
                  </div>
                  <span className="rounded-full bg-skyPulse/20 px-4 py-2 text-sm font-semibold text-skyPulse">
                    gültig bis {new Date(deal.validUntil).toLocaleDateString('de-DE')}
                  </span>
                </header>
                <div className="mt-6 grid gap-6 md:grid-cols-3">
                  <div>
                    <p className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                      Aktueller Preis
                    </p>
                    <p className="text-2xl font-bold text-slateNight dark:text-white">
                      {formatCurrency(deal.price)}
                    </p>
                    <p className="text-sm text-slate-500 line-through dark:text-slate-300">
                      {formatCurrency(deal.originalPrice)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                      Bedingungen
                    </p>
                    <p className="text-sm text-slate-600 dark:text-slate-200">
                      {deal.conditions}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-300">
                      Versand
                    </p>
                    <p className="text-sm text-slate-600 dark:text-slate-200">
                      {deal.shipping}
                    </p>
                  </div>
                </div>
                <div className="mt-6">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">
                    Preisverlauf
                  </h3>
                  <ul className="mt-2 flex flex-wrap gap-4 text-sm text-slate-600 dark:text-slate-200">
                    {deal.history.map((entry) => (
                      <li key={entry.date} className="rounded-full bg-cloud px-4 py-2 dark:bg-slate-700/60">
                        {new Date(entry.date).toLocaleDateString('de-DE')} – {formatCurrency(entry.price)}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
                  <p className="text-sm font-semibold text-red-500">{deal.alert}</p>
                  <a
                    href={deal.link}
                    className="inline-flex items-center gap-2 rounded-full bg-slateNight px-6 py-3 text-sm font-semibold text-mist transition hover:bg-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-skyPulse focus-visible:ring-offset-2 dark:bg-skyPulse dark:text-slateNight"
                  >
                    Angebot sichern →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Deals;