export const stats = [
  {
    id: 'tested-devices',
    value: 218,
    suffix: '+',
    title: 'Geräte im Labor geprüft',
    description:
      'Messprotokolle nach IEC-Standards inklusive Energie- und Netztests.'
  },
  {
    id: 'community',
    value: 6400,
    suffix: '+',
    title: 'Beta-Mitglieder',
    description:
      'Aktive Tester:innen aus ganz Deutschland mit transparenten Feedbackschleifen.'
  },
  {
    id: 'hours',
    value: 12800,
    suffix: '+',
    title: 'Messstunden dokumentiert',
    description:
      'Langzeitläufe, thermische Analysen und Feldtests unter realen Bedingungen.'
  }
];

export const reviews = [
  {
    id: 'fairphone-5',
    slug: 'fairphone-5-2024',
    title: 'Fairphone 5 – Nachhaltiges Flaggschiff mit Fokus auf Reparierbarkeit',
    heroSubtitle:
      'Modular, fair beschafft und überraschend leistungsfähig für den Alltag.',
    shortDescription:
      'Das Fairphone 5 kombiniert ein helles 90-Hz-OLED, austauschbare Module und fünf Jahre Update-Zusage – ideal für alle, die Nachhaltigkeit und Leistung verbinden möchten.',
    category: 'Smartphone',
    rating: 88,
    reviewScoreCount: 47,
    badges: ['Neu', 'Getestet'],
    image:
      'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=900&q=80',
    coverImage:
      'https://images.unsplash.com/photo-1510553889415-b69c6ac96717?auto=format&fit=crop&w=1400&q=80',
    releaseDate: '2024-02-15',
    reviewDate: '2024-04-20',
    author: 'Lea Krämer',
    uvp: 699,
    currentPrice: 649,
    availability:
      'Versand aus den Niederlanden, DHL GoGreen innerhalb Deutschlands (2-4 Werktage).',
    shippingInfo:
      'EU-Stecker im Lieferumfang, CO₂-kompensierter Versand durch Hersteller.',
    pros: [
      'OLED-Panel mit 876 cd/m² Spitzenhelligkeit und sauberer Kalibrierung',
      'Austauschbare Hauptmodule in unter 5 Minuten ohne Spezialwerkzeug',
      '5 Jahre Update-Zusage inklusive Sicherheits-Patches bis 2030'
    ],
    cons: [
      'Keine optische Bildstabilisierung in der Ultraweitwinkel-Kamera',
      '120-Hz-Modus fehlt im Vergleich zu similarly bepreisten Modellen'
    ],
    summary:
      'Fairphone beweist mit dem fünften Modell, dass Nachhaltigkeit und faire Lieferketten auch in der Oberklasse funktionieren. Wer Wert auf modulare Reparaturen und lange Update-Zyklen legt, bekommt ein sehr ausgewogenes Gesamtpaket.',
    specs: {
      display: '6,46" OLED, 90 Hz',
      processor: 'Qualcomm QCM6490',
      ram: '8 GB',
      storage: '256 GB (microSD erweiterbar)',
      battery: '4200 mAh, wechselbar',
      weight: '212 g',
      connectivity: '5G, Wi-Fi 6E, NFC, Bluetooth 5.2',
      os: 'Android 13 (5 Jahre Updates)',
      charging: '30 W USB-C (EU-Stecker), Qi Wireless 15 W'
    },
    measurements: [
      {
        label: 'Display-Helligkeit',
        value: '876 cd/m² Spitzwert',
        method: 'Gemessen mit X-Rite i1Display Pro bei 100 % APL',
        source: 'Slexorifyx Lab Köln'
      },
      {
        label: 'Leistungsaufnahme Idle',
        value: '1,8 W',
        method: 'DC-Labornetzteil Keysight E36234A, 230 V Referenznetz',
        source: 'Slexorifyx Energietests 2024'
      },
      {
        label: 'SAR-Wert Kopf',
        value: '0,91 W/kg',
        method: 'Herstellerangabe validiert mit Gigahertz Solutions HF-Analyser',
        source: 'Bundesnetzagentur Datenbank'
      }
    ],
    longTermInsights: [
      {
        month: '2024-06',
        text: 'Nach 60 Tagen Dauertest zeigen sich keine thermischen Drosselungen. Die modulare Rückseite hält wiederholte Öffnungen ohne spürbares Spiel aus.'
      },
      {
        month: '2024-09',
        text: 'Akkuwechsel nach 180 Ladezyklen in 2:42 Minuten möglich, Kapazitätsverlust bei 4,3 %.'
      }
    ],
    priceHistory: [
      { month: '2023-12', uvp: 699, street: 699 },
      { month: '2024-01', uvp: 699, street: 679 },
      { month: '2024-02', uvp: 699, street: 669 },
      { month: '2024-03', uvp: 699, street: 659 },
      { month: '2024-04', uvp: 699, street: 649 },
      { month: '2024-05', uvp: 699, street: 649 }
    ],
    alternatives: ['nothing-phone-2a-2024', 'bosch-smart-home-controller-ii'],
    keywords: ['nachhaltig', 'reparierbar', 'fairphone']
  },
  {
    id: 'nothing-phone-2a',
    slug: 'nothing-phone-2a-2024',
    title: 'Nothing Phone (2a) – Glyph-Look trifft starke Laufzeit',
    heroSubtitle:
      'Ein Charakter-Smartphone mit ausgewogener Performance für unter 400 €.',
    shortDescription:
      'Das Nothing Phone (2a) verbindet das charakteristische Glyph-Design mit solider Mittelklasse-Leistung, sauberem Nothing OS und schnellem 45-Watt-Laden.',
    category: 'Smartphone',
    rating: 84,
    reviewScoreCount: 39,
    badges: ['Neu', 'Beta'],
    image:
      'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=900&q=80',
    coverImage:
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=1400&q=80',
    releaseDate: '2024-03-12',
    reviewDate: '2024-04-05',
    author: 'Tobias Ehrlich',
    uvp: 399,
    currentPrice: 379,
    availability:
      'Sofort lieferbar, Versand DE mit UPS Express Saver (1-2 Tage).',
    shippingInfo:
      'EU-konformer 45-Watt-Netzadapter im Lieferumfang, Glyph-LEDs individuell steuerbar.',
    pros: [
      'Glyph-Interface mit neuen Timer- und Aufnahmefunktionen',
      '120-Hz-AMOLED mit 10-bit Farbtiefe und HDR10+ Zertifizierung',
      'Sehr gute Laufzeit: 13h 42min im Video-Dauertest'
    ],
    cons: [
      'Kein IP68, lediglich IP54 Spritzwasserschutz',
      'Ultraweitwinkel-Kamera mit sichtbarem Rauschen in Innenräumen'
    ],
    summary:
      'Das Nothing Phone (2a) ist mehr als ein Design-Statement. Die Kombination aus starkem Dimensity 7200 Pro SoC, effizienten Updates und Glyph-Automationen macht das Gerät zur Empfehlung der oberen Mittelklasse.',
    specs: {
      display: '6,7" AMOLED, 120 Hz',
      processor: 'MediaTek Dimensity 7200 Pro',
      ram: '8 GB',
      storage: '128 GB (UFS 3.1)',
      battery: '5000 mAh',
      weight: '190 g',
      connectivity: '5G, Wi-Fi 6, Dual SIM',
      os: 'Nothing OS 2.5 (Android 14)',
      charging: '45 W USB-C (PD3.0)'
    },
    measurements: [
      {
        label: 'Akkulaufzeit Video',
        value: '13h 42min',
        method: 'Loop mit 200 Nit, MX Player, WLAN an',
        source: 'Slexorifyx Battery Bench v2'
      },
      {
        label: 'Farbtreue ΔE2000',
        value: '1,9 (Referenzmodus)',
        method: 'Calman Ultimate, X-Rite i1Pro 3',
        source: 'ColorLabor München'
      },
      {
        label: 'Ladezeit 0-80%',
        value: '28 Minuten',
        method: 'Original 45-Watt-Netzteil, 23°C Umgebung',
        source: 'Slexorifyx Charging Rig'
      }
    ],
    longTermInsights: [
      {
        month: '2024-07',
        text: 'Glyph-Automationen funktionieren zuverlässig mit Google Home. Nach 120 Ladezyklen kein nennenswerter Kapazitätsverlust.'
      }
    ],
    priceHistory: [
      { month: '2024-02', uvp: 399, street: 399 },
      { month: '2024-03', uvp: 399, street: 389 },
      { month: '2024-04', uvp: 399, street: 379 },
      { month: '2024-05', uvp: 399, street: 369 },
      { month: '2024-06', uvp: 399, street: 359 }
    ],
    alternatives: ['fairphone-5-2024', 'steam-deck-oled-2024'],
    keywords: ['glyph', 'nothing', 'mittelklasse']
  },
  {
    id: 'framework-laptop-13',
    slug: 'framework-laptop-13-2024',
    title: 'Framework Laptop 13 (13. Gen) – Modularer Begleiter fürs Pro-Leben',
    heroSubtitle:
      'Ein modularer 13-Zoller, der aufrüstbar bleibt und trotzdem leise arbeitet.',
    shortDescription:
      'Der Framework Laptop 13 überzeugt mit modularem Ports-System, hervorragender Wartbarkeit und Intel Core Ultra Prozessoren für produktive Workflows unterwegs.',
    category: 'Laptop',
    rating: 91,
    reviewScoreCount: 32,
    badges: ['Getestet'],
    image:
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=80',
    coverImage:
      'https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?auto=format&fit=crop&w=1400&q=80',
    releaseDate: '2024-01-22',
    reviewDate: '2024-03-11',
    author: 'Mareike Sturm',
    uvp: 1599,
    currentPrice: 1549,
    availability:
      'Direktvertrieb, Versand via UPS Carbon Neutral, Lieferung 5-7 Tage.',
    shippingInfo:
      'Modul-Slots frei konfigurierbar, EU-Netzteil mit 2 Meter Kabel beigelegt.',
    pros: [
      'Werkzeugloser Zugriff auf RAM, SSD, Akku und Mainboard',
      'Sehr gutes 3K-Display mit 98 % DCI-P3 Abdeckung',
      'Leiser Betrieb: 27,6 dB(A) unter Office-Last'
    ],
    cons: [
      'Keine dedizierte GPU-Option',
      'Scharnier etwas weich beim Öffnen unter 30°'
    ],
    summary:
      'Framework bleibt die Referenz für modulare Notebooks. Die 13. Generation kombiniert starke Intel-Core-Ultra-CPUs mit einer update-fähigen Plattform, die echte Nachhaltigkeit für mobile Professionals ermöglicht.',
    specs: {
      display: '13,5" IPS 3:2, 2880 × 1920, 120 Hz',
      processor: 'Intel Core Ultra 7 155H',
      ram: '32 GB DDR5-5600',
      storage: '1 TB NVMe SSD (PCIe 4.0)',
      battery: '61 Wh austauschbar',
      weight: '1,29 kg',
      connectivity: 'Wi-Fi 6E, Bluetooth 5.3, 4x Expansion-Bays',
      os: 'Windows 11 Pro, optional Fedora 39',
      charging: '60 W USB-C Netzteil (GaN)'
    },
    measurements: [
      {
        label: 'Display-Farbraum',
        value: '98 % DCI-P3',
        method: 'SpectraCal C6-HDR, Calman Analyse',
        source: 'Slexorifyx Display Suite'
      },
      {
        label: 'Geräuschpegel Load',
        value: '34,1 dB(A)',
        method: 'Messung in 1 m Abstand, anechoischer Raum',
        source: 'Akustik-Lab Berlin'
      },
      {
        label: 'SSD-Performance',
        value: '6.820 MB/s Lesen',
        method: 'CrystalDiskMark 8, 5 Durchläufe',
        source: 'Slexorifyx Storage Bench'
      }
    ],
    longTermInsights: [
      {
        month: '2024-08',
        text: 'BIOS 3.06 verbessert Lüfterkurven deutlich. Nach 6 Monaten Dauereinsatz keine Materialermüdung an den Ports.'
      }
    ],
    priceHistory: [
      { month: '2023-12', uvp: 1599, street: 1599 },
      { month: '2024-01', uvp: 1599, street: 1599 },
      { month: '2024-02', uvp: 1599, street: 1569 },
      { month: '2024-03', uvp: 1599, street: 1549 },
      { month: '2024-04', uvp: 1599, street: 1549 }
    ],
    alternatives: ['fairphone-5-2024'],
    keywords: ['modular', 'framework']
  },
  {
    id: 'sonos-era-300',
    slug: 'sonos-era-300-raumklang',
    title: 'Sonos Era 300 – Raumklang zum Aufstellen statt Einbauen',
    heroSubtitle:
      'Ein Wi-Fi-Lautsprecher mit Dolby Atmos, der sich nahtlos in deutsche Wohnzimmer integrieren lässt.',
    shortDescription:
      'Der Sonos Era 300 bietet räumliche Klangbühne, Trueplay-Raumeinmessung auf Android und umfangreiche Streaming-Unterstützung inklusive Apple Music Lossless.',
    category: 'Audio',
    rating: 86,
    reviewScoreCount: 28,
    badges: ['Getestet'],
    image:
      'https://images.unsplash.com/photo-1614689588113-7b0c96f5d1b2?auto=format&fit=crop&w=900&q=80',
    coverImage:
      'https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=1400&q=80',
    releaseDate: '2024-02-01',
    reviewDate: '2024-03-22',
    author: 'Kai Gutowski',
    uvp: 499,
    currentPrice: 479,
    availability:
      'Verfügbar bei Sonos.com sowie MediaMarkt, Versand innerhalb Deutschlands 2-3 Werktage.',
    shippingInfo:
      'Lieferung inkl. Schukostecker, kompatibel mit Sonos Voice Control und Sprachsteuerung via Alexa.',
    pros: [
      'Dolby Atmos mit präziser Höhen-Abbildung in 20 m² Testraum',
      'Bluetooth 5.0 mit AAC und SBC als schnelle Alternative zum WLAN',
      'Automatische Trueplay-Einmessung jetzt auch auf Android-Geräten'
    ],
    cons: [
      'Kein integrierter Line-In ohne Sonos-Adapter',
      'Satter Raumklang benötigt mindestens 20 cm Wandabstand'
    ],
    summary:
      'Der Era 300 ist aktuell die ausgewogenste All-in-One-Lösung von Sonos. Wer immersiven Klang ohne komplexe Installationen sucht, findet hier ein rundes Paket mit starker App-Einbindung.',
    specs: {
      drivers: '6 Klasse-D Verstärker, 4 Hochtöner, 2 Mitteltöner',
      connectivity: 'Wi-Fi 6, Bluetooth 5.0, Apple AirPlay 2',
      control: 'Touchpanel, Sonos App, Sprachsteuerung',
      weight: '4,47 kg',
      dimensions: '16 cm x 26 cm x 18,5 cm',
      power: 'Schukostecker, 230 V',
      compatibility: 'Sonos Multiroom, Dolby Atmos Music'
    },
    measurements: [
      {
        label: 'Max. Schalldruck',
        value: '98,3 dB(A) @ 1 m',
        method: 'NTi Audio XL2, Rosa Rauschen',
        source: 'Slexorifyx Akustik-Lab Berlin'
      },
      {
        label: 'Frequenzgang',
        value: '±3 dB (42 Hz – 19 kHz)',
        method: 'Klippel Near-Field Scanner',
        source: 'Audio Research Dresden'
      },
      {
        label: 'Leistungsaufnahme Standby',
        value: '1,6 W',
        method: 'HT Instruments PQA824 Netzanalysator',
        source: 'Slexorifyx Energiecheck'
      }
    ],
    longTermInsights: [
      {
        month: '2024-07',
        text: 'Software-Update 15.7 verbessert Dolby Atmos Rendering. Keine Ausfälle trotz 16h/d Dauerbetrieb im Studio.'
      }
    ],
    priceHistory: [
      { month: '2024-02', uvp: 499, street: 499 },
      { month: '2024-03', uvp: 499, street: 489 },
      { month: '2024-04', uvp: 499, street: 479 },
      { month: '2024-05', uvp: 499, street: 469 }
    ],
    alternatives: ['bosch-smart-home-controller-ii'],
    keywords: ['sonos', 'dolby atmos']
  },
  {
    id: 'bosch-smart-home',
    slug: 'bosch-smart-home-controller-ii',
    title: 'Bosch Smart Home Controller II – Zentrale für das vernetzte Zuhause',
    heroSubtitle:
      'Stabile, datenschutzfreundliche Schaltzentrale mit Matter-Upgrade.',
    shortDescription:
      'Der Controller II bündelt Bosch-Sensoren, Rolladensteuerung und Heizungsventile, unterstützt Matter und bringt optional Thread ins deutsche Einfamilienhaus.',
    category: 'Smart Home',
    rating: 82,
    reviewScoreCount: 22,
    badges: ['Neu'],
    image:
      'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=900&q=80',
    coverImage:
      'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1400&q=80',
    releaseDate: '2024-04-04',
    reviewDate: '2024-05-16',
    author: 'Steffen Wilke',
    uvp: 199,
    currentPrice: 189,
    availability:
      'Sofort lieferbar, Versand aus deutschem Lager innerhalb von 48 Stunden.',
    shippingInfo:
      'Lieferumfang inkl. EU-Netzteil (1,5 m) und Wandhalter, Konformität nach DSGVO durch lokale Datenverarbeitung.',
    pros: [
      'Matter über Software-Update aktiviert, lokale Automationen bleiben erhalten',
      'Sehr gute Ausfallsicherheit: 0,04 % Paketverlust im 24h-Dauertest',
      'Starker Datenschutz dank lokaler Speicherung und optionalem Fernzugriff via VPN'
    ],
    cons: [
      'Keine nativen Zigbee-Backups, nur via Bridge',
      'App wirkt textlastig und benötigt Überarbeitung für Screenreader'
    ],
    summary:
      'Der Bosch Smart Home Controller II konsolidiert smarte Haushaltsgeräte ohne Cloud-Zwang. Für deutsche Haushalte, die Wert auf Datenschutz und Gewährleistung legen, eine sichere Basis mit Zukunftsgarantie.',
    specs: {
      connectivity: 'LAN, WLAN, Thread (optional), Zigbee über Bridge',
      compatibility: 'Matter, HomeKit, Bosch Smart Home',
      power: '12 V Netzteil (EU)',
      dimensions: '13,5 × 13,5 × 4,5 cm',
      weight: '460 g',
      operatingTemp: '0–40 °C',
      security: 'TLS 1.3, lokale Datenhaltung'
    },
    measurements: [
      {
        label: 'Paketverlust',
        value: '0,04 %',
        method: 'Wireshark Capture, 24h Automations-Loop',
        source: 'Slexorifyx Netzwerk-Lab'
      },
      {
        label: 'Leistungsaufnahme aktiv',
        value: '4,1 W',
        method: 'Gossen Metrawatt Mehrkanal-Messung',
        source: 'Energie-Messfeld Bonn'
      }
    ],
    longTermInsights: [
      {
        month: '2024-09',
        text: 'Matter-Update stabil, Integration mit Homematic IP zuverlässig. Kein Ausfall trotz 35 °C Umgebung in Dachbodeninstallation.'
      }
    ],
    priceHistory: [
      { month: '2024-04', uvp: 199, street: 199 },
      { month: '2024-05', uvp: 199, street: 189 },
      { month: '2024-06', uvp: 199, street: 189 }
    ],
    alternatives: ['sonos-era-300-raumklang'],
    keywords: ['smart home', 'bosch', 'matter']
  },
  {
    id: 'steam-deck-oled',
    slug: 'steam-deck-oled-2024',
    title: 'Steam Deck OLED – Handheld mit kräftigem Panel und leisem Lüfter',
    heroSubtitle: 'Updates bei Display, Akku und Thermik machen den Unterschied.',
    shortDescription:
      'Das Steam Deck OLED bringt 90-Hz-OLED, effizientere APU und größeren Akku. Perfekt für Pendler:innen, die PC-Spiele mobil genießen möchten.',
    category: 'Gaming',
    rating: 89,
    reviewScoreCount: 41,
    badges: ['Getestet'],
    image:
      'https://images.unsplash.com/photo-1606813902914-00d4b4c0948b?auto=format&fit=crop&w=900&q=80',
    coverImage:
      'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1400&q=80',
    releaseDate: '2023-11-16',
    reviewDate: '2024-02-02',
    author: 'Lea Krämer',
    uvp: 569,
    currentPrice: 569,
    availability:
      'Versand via Steam Store, Zustellung DHL Express 3-5 Werktage deutschlandweit.',
    shippingInfo:
      '65-Watt-EU-Netzteil inklusive, optional Dockingstation verfügbar (separat).',
    pros: [
      'OLED mit perfektem Schwarz und 90 Hz sorgt für flüssiges Gameplay',
      'Bis zu 9 % mehr Akkulaufzeit dank effizienterer APU',
      'Deutlich leiseres Lüfterprofil: 32,1 dB(A) unter Battlefield-Test'
    ],
    cons: [
      'Speicherwechsel erfordert feines Werkzeug',
      'Deck Verified noch nicht für alle Spiele optimiert'
    ],
    summary:
      'Valve liefert ein durchdachtes Refresh seines beliebten Handheld-PCs. Wer mobil spielen will, erhält mit dem OLED-Modell ein leises, farbkräftiges und ausdauerndes Update.',
    specs: {
      display: '7,4" OLED, 1280 × 800, 90 Hz',
      processor: 'AMD Custom APU (Zen 2 + RDNA 2, 6 nm)',
      ram: '16 GB LPDDR5',
      storage: '512 GB NVMe (austauschbar)',
      battery: '50 Wh',
      weight: '640 g',
      connectivity: 'Wi-Fi 6E, Bluetooth 5.3, USB-C',
      os: 'SteamOS 3.5 (Linux)',
      charging: '65 W USB-C PD'
    },
    measurements: [
      {
        label: 'Lautstärke Last',
        value: '32,1 dB(A)',
        method: 'Messung auf Ohrhöhe, 30 cm Abstand',
        source: 'Slexorifyx Gaming-Lab'
      },
      {
        label: 'OLED Peak Luminanz',
        value: '642 cd/m²',
        method: 'Konica Minolta LS-150, 10 % Fenster',
        source: 'Display-Labor Köln'
      },
      {
        label: 'Akkulaufzeit Indie Game',
        value: '7h 05min',
        method: 'Hades 2, 60 Hz, 200 Nit, WLAN an',
        source: 'Slexorifyx Battery Loop'
      }
    ],
    longTermInsights: [
      {
        month: '2024-08',
        text: 'Nach 500 Betriebsstunden keine Burn-in-Erscheinungen. Lüfter minimal lauter bei Staubansammlung, Reinigung kinderleicht.'
      }
    ],
    priceHistory: [
      { month: '2023-12', uvp: 569, street: 569 },
      { month: '2024-01', uvp: 569, street: 569 },
      { month: '2024-02', uvp: 569, street: 559 },
      { month: '2024-03', uvp: 569, street: 559 },
      { month: '2024-04', uvp: 569, street: 549 }
    ],
    alternatives: ['nothing-phone-2a-2024'],
    keywords: ['steam deck', 'handheld', 'oled']
  }
];

export const betaPrograms = [
  {
    id: 'beta-ar-living',
    name: 'AR Living Room Initiative',
    status: 'Offen',
    slots: 120,
    location: 'Köln, Remote möglich',
    startDate: '2024-09-01',
    description:
      'Testet neue Mixed-Reality-Headsets mit lokalen Content-Partnern aus Köln, inkl. Netzteil-Checks für deutsche Steckdosen.',
    requirements: [
      'Wohnraum mit mind. 4 × 4 m freier Fläche',
      'Router mit Wi-Fi 6 Unterstützung',
      'DSGVO-konformer Umgang mit Testdaten'
    ],
    benefits: [
      'Früher Zugriff auf Hardware (3 Monate vor Marktstart)',
      'Versicherte Geräteanlieferung und Abholung',
      '250 € Aufwandspauschale'
    ],
    contactEmail: 'beta@slexorifyx.com'
  },
  {
    id: 'beta-solardock',
    name: 'SolarDock Backyard Trials',
    status: 'Warteliste',
    slots: 80,
    location: 'Berlin/Brandenburg',
    startDate: '2024-10-15',
    description:
      'Mobile Balkonkraftwerke mit Energiespeicher im Alltag testen. Fokus auf Schukostecker, VDE-Normen und Wechselrichter-Effizienz.',
    requirements: [
      'Eigne Außensteckdose mit FI-Schutzschalter',
      'Zugang zu Balkon oder Terrasse mit Südausrichtung',
      'Bereitschaft zur Energiedaten-Erfassung'
    ],
    benefits: [
      'Exklusive Einspeiseanalysen für den deutschen Markt',
      'Rabattierter Kauf nach Testphase',
      'Direkter Austausch mit Bosch Energy Lab'
    ],
    contactEmail: 'energy@slexorifyx.com'
  },
  {
    id: 'beta-audio-lab',
    name: 'Spatial Audio Creator Pool',
    status: 'Neu',
    slots: 40,
    location: 'Hamburg Studio Nord',
    startDate: '2024-08-20',
    description:
      'Beta-Phase für immersive Lautsprecher-Setups inklusive Sonos Era 300, Focal Bathys und Apple Music Spatial.',
    requirements: [
      'Musikalischer Background oder Audio-Produktionserfahrung',
      'Wohnort im Großraum Hamburg',
      'Teilnahme an drei Feedback-Sessions'
    ],
    benefits: [
      'Zugang zu exklusiven Firmware-Builds',
      'Professionelle Raumvermessung inklusive',
      'Feature-Spotlight auf slexorifyx.com'
    ],
    contactEmail: 'audio@slexorifyx.com'
  }
];

export const longTermTests = [
  {
    id: 'longterm-fairphone',
    title: 'Fairphone 5 Langzeitlog über 180 Tage',
    start: '2024-03-01',
    focus: 'Modularität & Akkustabilität im Pendler-Alltag',
    summary:
      'Pendler-Strecke Köln–Düsseldorf, tägliche Navigation, 5G-Only. Akkuwechsel nach 4 Monaten dokumentiert, Ersatzteile verfügbar.',
    image:
      'https://picsum.photos/seed/fairphone-street/800/600',
    latestUpdate: '2024-09-12',
    insights: [
      'Staubschutz der USB-C-Buchse nach 120 Steckzyklen intakt.',
      'Kamera-Modul einmal gewechselt, Kostenersparnis 70 € gegenüber Neukauf.'
    ]
  },
  {
    id: 'longterm-framework',
    title: 'Framework Laptop 13 Pendeltest',
    start: '2024-02-15',
    focus: 'Modulare Aufrüstbarkeit im Agenturalltag',
    summary:
      'Getestet in Agenturen in Berlin und München. Fokus auf Lüfterkühlung in Sommerhitze und Portwechsel unterwegs.',
    image:
      'https://picsum.photos/seed/framework-lab/800/600',
    latestUpdate: '2024-08-30',
    insights: [
      'Portmodule zeigen keine Abnutzung trotz häufigem Wechsel.',
      'Batterieaustausch in 4:10 Minuten inklusive Schraubzeiten.'
    ]
  }
];

export const deals = [
  {
    id: 'deal-framework',
    title: 'Framework Laptop 13 – Education Bundle',
    vendor: 'Framework Europe',
    price: 1499,
    originalPrice: 1599,
    validUntil: '2024-07-31',
    shipping: 'Versand aus NL, kostenloser Rückversand innerhalb 30 Tage.',
    conditions: 'Nur für Studierende mit gültiger Immatrikulationsbescheinigung.',
    history: [
      { date: '2024-05-01', price: 1559 },
      { date: '2024-06-01', price: 1529 },
      { date: '2024-07-01', price: 1499 }
    ],
    alert: 'Lagerbestand < 20 Stück – schneller Abschluss empfohlen.',
    link: 'https://framework.com'
  },
  {
    id: 'deal-sonos',
    title: 'Sonos Era 300 Doppelpack',
    vendor: 'Sonos Shop DE',
    price: 899,
    originalPrice: 998,
    validUntil: '2024-08-15',
    shipping: 'Kostenloser Premiumversand, Zustellung per DHL Express.',
    conditions: 'Nur in Kombination mit Sonos+ Abo Monatsplan erhältlich.',
    history: [
      { date: '2024-04-10', price: 998 },
      { date: '2024-06-10', price: 949 },
      { date: '2024-07-05', price: 899 }
    ],
    alert: 'Ratenzahlung über Klarna möglich, 0 % effektiv.',
    link: 'https://sonos.com'
  },
  {
    id: 'deal-psp',
    title: 'Steam Deck OLED + Dock',
    vendor: 'Valve Store EU',
    price: 619,
    originalPrice: 719,
    validUntil: '2024-07-20',
    shipping: 'DHL Express, 3-5 Werktage, zollfrei in DE.',
    conditions: 'Bundle enthält offizielles Dock, begrenzte Stückzahl.',
    history: [
      { date: '2024-05-01', price: 699 },
      { date: '2024-06-01', price: 659 },
      { date: '2024-07-01', price: 619 }
    ],
    alert: 'Push-Benachrichtigungen verfügbar – aktiviert über Deal-Alarm.',
    link: 'https://store.steampowered.com'
  }
];

export const projects = [
  {
    id: 'project-acoustic',
    title: 'Akustik-Lab Berlin – Freifeldmessungen',
    category: 'Audio',
    image: 'https://picsum.photos/seed/acoustic-lab/1200/800',
    summary:
      'Eigenes 70 m² Akustiklabor für Lautsprecher- und Mikrofontests mit Klippel-System.',
    highlight: 'Messungen nach DIN EN 60268-5, Zugriff auf 48-Kanal-Mikrofon-Array.'
  },
  {
    id: 'project-energy',
    title: 'Energy Insight Yard',
    category: 'Energie',
    image: 'https://picsum.photos/seed/energy-yard/1200/800',
    summary:
      'Outdoor-Testfeld für Balkonkraftwerke, Speicher und Wallboxen mit realen Wetterdaten.',
    highlight:
      'Direkte Netzanalyse inkl. Schukostecker-Sicherheitsprüfungen nach VDE 0620.'
  },
  {
    id: 'project-automation',
    title: 'Automation Studio Köln',
    category: 'Smart Home',
    image: 'https://picsum.photos/seed/automation-studio/1200/800',
    summary:
      'Testwohnung mit KNX, Matter und Zigbee zur Simulation deutscher Wohnsituationen.',
    highlight:
      'Reproduzierbare Szenarien für Heizung, Sonnenschutz und Energieoptimierung.'
  },
  {
    id: 'project-mobile',
    title: 'Mobile Battery Bench',
    category: 'Mobile',
    image: 'https://picsum.photos/seed/mobile-battery/1200/800',
    summary:
      '24-Stunden-Akkutests mit Umweltkammer für Smartphones, Tablets und Handhelds.',
    highlight: 'Temperaturzyklus -10 bis 45 °C, Lastprofile für ÖPNV-Szenarien.'
  }
];

export const testimonials = [
  {
    id: 'testimonial-1',
    quote:
      'Die Testprotokolle von Slexorifyx helfen uns, die Qualität im deutschen Markt durchzusetzen. Besonders die Transparenz bei Netzteilen war entscheidend.',
    name: 'Sofia Ackermann',
    role: 'Partner Managerin, Fairphone DACH'
  },
  {
    id: 'testimonial-2',
    quote:
      'Unsere Beta-Nutzer:innen in Berlin erhielten fundierte Schulungen und Feedback-Workshops. Die Community ist engagiert und konstruktiv.',
    name: 'Martin Varga',
    role: 'Lead Product, Bosch Smart Home'
  },
  {
    id: 'testimonial-3',
    quote:
      'Für meine Kaufberatung im Studio setzte ich auf die Messwerte von Slexorifyx. Die Daten sind nachvollziehbar und passen zur Praxis.',
    name: 'Flavia Mertens',
    role: 'Audio Consultant, Hamburg'
  }
];

export const faqItems = [
  {
    question: 'Wie wählt Slexorifyx Geräte für Langzeittests aus?',
    answer:
      'Wir priorisieren Produkte mit hoher Relevanz für den deutschen Markt, prüfen Lieferfähigkeit, Gewährleistung und Reparaturzugänglichkeit. Auswahlkriterien und Testdauer werden vorab veröffentlicht.'
  },
  {
    question: 'Sind eure Messwerte reproduzierbar?',
    answer:
      'Ja. Wir dokumentieren alle Messmethoden detailliert, nennen eingesetzte Kalibriergeräte und ermöglichen Audits durch unabhängige Labore. Werte lassen sich mit vergleichbarem Equipment reproduzieren.'
  },
  {
    question: 'Welche Versandbedingungen gelten für Early-Access-Geräte?',
    answer:
      'Alle Testgeräte werden innerhalb Deutschlands versichert geliefert. Rücksendungen sind kostenfrei. Wir nutzen ausschließlich Versandpartner mit nachvollziehbarer Tracking-Historie.'
  },
  {
    question: 'Wie geht ihr mit personenbezogenen Daten um?',
    answer:
      'Alle Daten werden in ISO-27001-zertifizierten Rechenzentren innerhalb Deutschlands verarbeitet. Feedback aus Beta-Programmen wird vor Veröffentlichung anonymisiert.'
  },
  {
    question: 'Kann ich meine Teilnahme an einem Beta-Programm pausieren?',
    answer:
      'Ja. Über das Teilnehmerportal kann eine Pause von bis zu vier Wochen beantragt werden. Währenddessen werden Geräte auf Wunsch abgeholt oder versiegelt eingelagert.'
  }
];

export const teamMembers = [
  {
    id: 'team-lea',
    name: 'Lea Krämer',
    role: 'Leitung Testredaktion',
    focus: 'Mobile & Nachhaltigkeit',
    image: 'https://picsum.photos/seed/lea-kraemer/400/400',
    bio: 'Dipl.-Ing. Nachrichtentechnik, zertifizierte Energieberaterin. Leitet das Mobile Testing Lab in Köln.',
    socials: {
      linkedin: 'https://www.linkedin.com/in/leakraemer'
    }
  },
  {
    id: 'team-tobias',
    name: 'Tobias Ehrlich',
    role: 'Head of Beta Operations',
    focus: 'Community & Feldtests',
    image: 'https://picsum.photos/seed/tobias-ehrlich/400/400',
    bio: 'Ehemals Programmmanager bei Deutsche Telekom, bringt Beta-Teams in ganz Deutschland zusammen.',
    socials: {
      linkedin: 'https://www.linkedin.com/in/tobias-ehrlich'
    }
  },
  {
    id: 'team-mareike',
    name: 'Mareike Sturm',
    role: 'Leiterin Messlabor',
    focus: 'Akustik & Display',
    image: 'https://picsum.photos/seed/mareike-sturm/400/400',
    bio: 'M.Sc. Elektrotechnik, betreut das Akustik-Labor Berlin und entwickelt Messprotokolle.',
    socials: {
      linkedin: 'https://www.linkedin.com/in/mareike-sturm'
    }
  },
  {
    id: 'team-steffen',
    name: 'Steffen Wilke',
    role: 'Senior Analyst Smart Living',
    focus: 'Energie & Automatisierung',
    image: 'https://picsum.photos/seed/steffen-wilke/400/400',
    bio: '15 Jahre Erfahrung im Bereich Gebäudeautomatisierung, zertifizierter KNX Trainer.',
    socials: {
      linkedin: 'https://www.linkedin.com/in/steffen-wilke'
    }
  }
];

export const newsArticles = [
  {
    id: 'news-matter',
    slug: 'matter-update-bosch',
    title: 'Bosch rollt Matter-Update für Thermostate in Deutschland aus',
    excerpt:
      'Ab sofort können Bosch Thermostate ohne Cloud in bestehende Matter-Setups integriert werden. Wir haben das Update im Automation Studio getestet.',
    image: 'https://picsum.photos/seed/news-matter/800/600',
    author: 'Steffen Wilke',
    date: '2024-06-14',
    category: 'Smart Home'
  },
  {
    id: 'news-fairphone',
    slug: 'fairphone-update-programm',
    title: 'Fairphone verlängert Software-Support bis 2031',
    excerpt:
      'Fairphone bestätigt Extended-Support-Programm für Deutschland. Wir ordnen die Auswirkungen auf Reparierbarkeit und Restwert ein.',
    image: 'https://picsum.photos/seed/news-fairphone/800/600',
    author: 'Lea Krämer',
    date: '2024-05-28',
    category: 'Mobile'
  },
  {
    id: 'news-energy-storage',
    slug: 'speicher-foerderung-2024',
    title: 'Neue Speicherförderung in NRW startet im August',
    excerpt:
      'NRW unterstützt Heimspeicher-Anlagen mit bis zu 7.500 €. Wir vergleichen die Anforderungen mit aktuellen Marktangeboten.',
    image: 'https://picsum.photos/seed/news-energy/800/600',
    author: 'Tobias Ehrlich',
    date: '2024-06-30',
    category: 'Energie'
  },
  {
    id: 'news-handhelds',
    slug: 'mobiles-gaming-ifa',
    title: 'Mobile Gaming: Was wir zur IFA 2024 erwarten',
    excerpt:
      'OLED-Handhelds und modulare Controller stehen im Fokus. Wir geben einen Ausblick auf die spannendsten Vorseriengeräte.',
    image: 'https://picsum.photos/seed/news-gaming/800/600',
    author: 'Mareike Sturm',
    date: '2024-07-05',
    category: 'Gaming'
  }
];

export const guides = [
  {
    id: 'guide-kaufberatung',
    title: 'Kaufberatung Smartphones 2024',
    summary:
      'So bewerten wir Laufzeit, Netzabdeckung, Update-Politik und Reparierbarkeit für den deutschen Markt.',
    tips: [
      'Wichtig: Prüfen Sie, ob ein Netzteil mit EU-Stecker beiliegt und ob chargerschutz vorhanden ist.',
      'Achten Sie auf ausgewiesene Update-Garantien in Monaten statt annähernden Angaben.',
      'Testen Sie regionale 5G-Bänder – nicht jedes internationale Modell unterstützt n78/n28 vollständig.'
    ]
  },
  {
    id: 'guide-stecker',
    title: 'Stecker & Netzkompatibilität',
    summary:
      'Warum CE-Kennzeichnung und VDE-Prüfzeichen relevant sind und wie wir Netzteile prüfen.',
    tips: [
      'Geräte ohne Schukostecker liefern wir nur mit zertifizierten Adaptern aus.',
      'Im Labor messen wir Leerlauf-Verbrauch und Effizienz bei typischen Lasten (10 %, 50 %, 100 %).',
      'Achten Sie bei Balkonkraftwerken auf Wieland-Dosen oder Einspeise-Relais.'
    ]
  },
  {
    id: 'guide-gewährleistung',
    title: 'Gewährleistung & Garantie',
    summary:
      'Was deutsche Verbraucher:innen über Mängelhaftung, freiwillige Garantie und Ersatzteile wissen sollten.',
    tips: [
      'Gewährleistung gilt 24 Monate – bei Gebrauchtware mindestens 12 Monate, wenn nicht anders vereinbart.',
      'Dokumentieren Sie Mängel mit Fotos und Protokollen – wir stellen Vorlagen bereit.',
      'Herstellergarantie ist ein Zusatz. Prüfen Sie die Übertragbarkeit bei Weiterverkauf.'
    ]
  },
  {
    id: 'guide-datenschutz',
    title: 'Datenschutz bei smarten Gadgets',
    summary:
      'Wie wir Datenflüsse prüfen, DSGVO-Auskünfte einholen und welche Cloud-Alternativen existieren.',
    tips: [
      'Nutzen Sie lokale Auswertung, wo immer möglich, und aktivieren Sie Zwei-Faktor-Authentifizierung.',
      'Bei Beta-Programmen anonymisieren wir Feedback vor Übergabe an Hersteller.',
      'Prüfen Sie, welche Daten in Drittstaaten übertragen werden – wir listen dies in jedem Review auf.'
    ]
  },
  {
    id: 'guide-refurb',
    title: 'Refurbished-Geräte richtig einschätzen',
    summary:
      'Woran Sie seriöse Refurbisher erkennen und welche Ersatzteil-Politik sich lohnt.',
    tips: [
      'Achten Sie auf Batteriestandards (mind. 85 % Restkapazität) und zertifizierte Ersatzteile.',
      'Überprüfen Sie, ob Gewährleistung und Rückgaberecht der deutschen Gesetzgebung entsprechen.',
      'Wir empfehlen Anbieter mit nachvollziehbaren Prüfprotokollen und Diagnosetools.'
    ]
  }
];