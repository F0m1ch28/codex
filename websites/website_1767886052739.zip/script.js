document.addEventListener('DOMContentLoaded', function () {
    const banner = document.querySelector('.cookie-banner');
    if (!banner) {
        return;
    }
    const acceptBtn = banner.querySelector('.cookie-accept');
    const declineBtn = banner.querySelector('.cookie-decline');
    const storedChoice = localStorage.getItem('waxycamlcrCookieConsent');

    if (!storedChoice) {
        banner.classList.add('active');
        banner.removeAttribute('hidden');
    } else {
        banner.setAttribute('hidden', '');
    }

    const handleChoice = (choice, event) => {
        if (event) {
            event.preventDefault();
        }
        localStorage.setItem('waxycamlcrCookieConsent', choice);
        banner.classList.remove('active');
        banner.setAttribute('hidden', '');
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', (event) => handleChoice('accepted', event));
    }
    if (declineBtn) {
        declineBtn.addEventListener('click', (event) => handleChoice('declined', event));
    }
});