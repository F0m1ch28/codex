import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`${styles.inner} container`}>
      <div className={styles.identity}>
        <span className={styles.badge}>Archivio del Morso</span>
        <p className={styles.description}>
          Quaderno editoriale e osservatorio gastronomico con sede a Carugate, Milano. Tracciamo ingredienti,
          gesti e paesaggi alimentari in una prospettiva culturale e narrativa.
        </p>
        <address className={styles.address}>
          <span>Centro Commerciale Carosello</span>
          <span>Via Giuseppe Verdi 1</span>
          <span>20061 Carugate MI · Italia</span>
          <a href="tel:+390256564020">+39 02 5656 4020</a>
        </address>
      </div>
      <div className={styles.column}>
        <h3>Esplora</h3>
        <ul>
          <li>
            <Link to="/about">Chi siamo</Link>
          </li>
          <li>
            <Link to="/services">Servizi</Link>
          </li>
          <li>
            <Link to="/recipes">Ricette stagionali</Link>
          </li>
          <li>
            <Link to="/workshop">Workshop</Link>
          </li>
          <li>
            <Link to="/blog">Blog</Link>
          </li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Norme</h3>
        <ul>
          <li>
            <Link to="/terms">Termini d&apos;uso</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Policy cookie</Link>
          </li>
          <li>
            <Link to="/contact">Contatti editoriali</Link>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Archivio del Morso · Tutti i diritti riservati</p>
      <div className={styles.social}>
        <a href="https://www.instagram.com/" aria-label="Instagram Archivio del Morso">
          Instagram
        </a>
        <a href="https://www.linkedin.com/" aria-label="LinkedIn Archivio del Morso">
          LinkedIn
        </a>
        <a href="https://www.pinterest.it/" aria-label="Pinterest Archivio del Morso">
          Pinterest
        </a>
      </div>
    </div>
  </footer>
);

export default Footer;