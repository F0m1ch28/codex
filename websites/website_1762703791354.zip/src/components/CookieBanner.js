import { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const storageKey = 'archivio-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(storageKey);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(storageKey, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <p>
          Utilizziamo cookie editoriali per comprendere quali ingredienti meritano approfondimenti.
          Proseguendo confermi il consenso all&apos;uso di questi strumenti.
        </p>
        <a href="/cookie-policy">Leggi la policy</a>
      </div>
      <button type="button" className="ctaPrimary" onClick={handleAccept}>
        Accetto
      </button>
    </div>
  );
};

export default CookieBanner;