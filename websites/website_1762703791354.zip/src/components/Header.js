import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Quaderno' },
  { path: '/about', label: 'Chi siamo' },
  { path: '/services', label: 'Servizi' },
  { path: '/recipes', label: 'Ricette' },
  { path: '/workshop', label: 'Workshop' },
  { path: '/blog', label: 'Blog' },
  { path: '/contact', label: 'Contatti' }
];

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const toggleMenu = () => setIsOpen((prev) => !prev);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const closeMenu = () => setIsOpen(false);

  return (
    <header className={styles.header} aria-label="Intestazione principale">
      <div className={`${styles.inner} container`}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Archivio del Morso home">
          <span className={styles.logoInitial}>A</span>
          <span className={styles.logoText}>Archivio del Morso</span>
        </NavLink>
        <nav className={`${styles.nav} ${isOpen ? styles.navOpen : ''}`} aria-label="Navigazione primaria">
          <ul>
            {navLinks.map((link) => (
              <li key={link.path}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                  onClick={closeMenu}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className={styles.meta}>
            <span>Centro Commerciale Carosello</span>
            <span>Via Giuseppe Verdi 1, Carugate</span>
          </div>
        </nav>
        <button
          className={`${styles.burger} ${isOpen ? styles.burgerOpen : ''}`}
          type="button"
          aria-label={isOpen ? 'Chiudi menu' : 'Apri menu'}
          aria-expanded={isOpen}
          onClick={toggleMenu}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;