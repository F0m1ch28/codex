import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './BlogArticle.module.css';

function BlogCartografiaCommestibile() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cartografia commestibile | Archivio del Morso</title>
        <meta
          name="description"
          content="Cartografia commestibile è un saggio dell’Archivio del Morso che esplora mappe sensoriali, paesaggi alimentari e note di campo."
        />
        <link
          rel="canonical"
          href="https://www.archivio-del-morso.it/blog/cartografia-commestibile"
        />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Cluster Memoria</div>
        <h1>Cartografia commestibile</h1>
        <div className={styles.meta}>
          <span>di Sara Baldi</span>
          <span>Pubblicato il 9 dicembre 2023</span>
          <span>Tempo di lettura · 9 minuti</span>
        </div>
      </section>

      <section className={`${styles.content} container`}>
        <p>
          Disegnare mappe commestibili significa fissare emozioni su carta. Ogni ingrediente del territorio
          lombardo, dalle rane di risaia alle pere martin sec, porta con sé latitudini e ricordi familiari.
        </p>
        <p>
          Nel nostro laboratorio tracciamo coordinate a partire da tre parametri: consistenza, temperatura,
          memoria. Il risultato è un planisfero intimo in cui il tempo dell’infanzia convive con la tecnica
          contemporanea.
        </p>
        <img
          src="https://picsum.photos/seed/cartografia1/1200/820"
          alt="Mappa gastronomica con ingredienti disegnati"
          loading="lazy"
        />
        <p>
          Ogni residenza di campo si conclude con una mappa. Disegniamo linee spezzate per i passaggi di
          cucina, curve morbide per le fermentazioni lente. Colleghiamo agricoltori, fornai, chef con tratti
          sottili che raccontano comunità.
        </p>
        <p>
          Cartografia è anche parola. Trascriviamo le storie dei produttori accanto ai segni grafici: un
          panettiere parla della farina mentre traccia con il dito un cerchio sulla tavola. Noi lo seguiamo,
          trasformiamo quel gesto in tipografia.
        </p>
        <img
          src="https://picsum.photos/seed/cartografia2/1200/820"
          alt="Dettaglio di ingredienti disposti su mappa"
          loading="lazy"
        />
        <p>
          Le mappe commestibili sono strumenti per chi legge ma anche per chi cucina. Permettono di navigare
          un menù complesso, di ritrovare legami tra montagna e pianura. Per questo le consegniamo sempre
          insieme alle ricette, come bussola.
        </p>
        <p>
          Nei workshop invitiamo i partecipanti a disegnare la loro geografia del gusto. È un esercizio di
          memoria: ricordare il primo profumo di basilico, la consistenza del pane di casa, il rumore dell’
          olio che sfrigola. Ogni ricordo diventa coordinate.
        </p>
        <aside className={styles.notes}>
          <h3>Note di campo</h3>
          <ul>
            <li>
              Coordinate raccolte a Carugate, Milano, durante la residenza “Grani in ascolto”, novembre 2023.
            </li>
            <li>Cartografie stampate su carta cotone 300 g, formato 50×70 cm.</li>
            <li>
              Palette colori: sabbia, nebbia, verde brughiera, rosso ruggine per le mele antiche.
            </li>
          </ul>
        </aside>
        <p>
          Cartografia commestibile è il modo in cui manteniamo vivo il dialogo tra ingredienti e persone.
          Ogni mappa è un invito a perderci, a ritrovare il cammino attraverso un sapore.
        </p>
        <Link to="/blog" className={styles.backLink}>
          ← Torna al blog
        </Link>
      </section>
    </div>
  );
}

export default BlogCartografiaCommestibile;