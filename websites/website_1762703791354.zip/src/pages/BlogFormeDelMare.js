import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './BlogArticle.module.css';

function BlogFormeDelMare() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Forme del mare, grammatica delle salse | Archivio del Morso</title>
        <meta
          name="description"
          content="Analisi delle salse marine tra gesti costieri, schemi cromatici e narrazione gastronomica curata da Archivio del Morso."
        />
        <link
          rel="canonical"
          href="https://www.archivio-del-morso.it/blog/forme-del-mare-grammatica-delle-salse"
        />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Cluster Tecnica</div>
        <h1>Forme del mare, grammatica delle salse</h1>
        <div className={styles.meta}>
          <span>di Giacomo Ratti</span>
          <span>Pubblicato il 18 gennaio 2024</span>
          <span>Tempo di lettura · 8 minuti</span>
        </div>
      </section>

      <section className={`${styles.content} container`}>
        <p>
          Lavorare con le salse di mare significa osservare le maree. Il gesto dell’emulsione imita le onde,
          alternando densità e aria. Nei porti siciliani abbiamo seguito pescatori che montavano salse con
          colpi lenti, quasi a inseguire la risacca.
        </p>
        <p>
          Ogni salsa possiede un corpo, una pelle e un sottosuolo. Il corpo è l’emulsione principale: brodo,
          grasso, acqua di mare. La pelle è la superficie lucida che racconta la temperatura. Il sottosuolo è
          l’insieme di erbe, agrumi, sedimenti.
        </p>
        <img
          src="https://picsum.photos/seed/salsaMare1/1200/820"
          alt="Macro di salsa marina con superficie lucida"
          loading="lazy"
        />
        <p>
          In laboratorio ricreiamo la grammatica del mare usando piatti concavi e spatole morbide. Il gesto è
          sempre diagonale, mai circolare. Si spinge la salsa verso il bordo e poi si lascia tornare, come
          l’onda quando si ritira.
        </p>
        <p>
          Abbiamo disegnato uno schema per codificare le forme più ricorrenti: lama, risacca, frangente,
          spirale. Ogni forma corrisponde a una funzione narrativa del piatto. La lama indica precisione, la
          risacca restituisce morbidezza.
        </p>
        <figure className={styles.figure}>
          <svg
            viewBox="0 0 400 160"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            aria-labelledby="schemaMare"
          >
            <title id="schemaMare">Schema delle forme delle salse marine</title>
            <rect x="10" y="20" width="120" height="36" rx="18" fill="#98A683" opacity="0.65" />
            <rect x="150" y="20" width="220" height="36" rx="18" fill="#C97C4A" opacity="0.4" />
            <path
              d="M30 120 Q110 60 190 120 T350 120"
              fill="none"
              stroke="#2E2E2E"
              strokeWidth="6"
              strokeLinecap="round"
            />
          </svg>
          <figcaption>Forma lama · forma risacca · onda frangente</figcaption>
        </figure>
        <p>
          Quando raccontiamo una salsa nel quaderno, annotiamo sempre la direzione del gesto. Scriviamo
          “stendere verso est” oppure “richiamare al centro”. Sono coordinate utili per chi replica il piatto
          ma anche per il lettore che immagina la scena.
        </p>
        <img
          src="https://picsum.photos/seed/salsaMare2/1200/820"
          alt="Chef che emulsionano salsa di mare in laboratorio"
          loading="lazy"
        />
        <p>
          Le salse di mare non sopportano rumori inutili. Bastano tre ingredienti ben accordati. Il rischio è
          la saturazione: troppi agrumi, troppi grassi. La grammatica che proponiamo invita a togliere, a
          lasciar parlare l’acqua salata che abbiamo raccolto all’alba.
        </p>
        <p>
          Ogni articolo del cluster Tecnica si chiude con un esercizio. Per questa volta: prendete un brodo
          di pesce leggero, un olio al finocchietto e un’acqua di pomodoro. Montate con colpi diagonali, poi
          tracciare una lama su piatto freddo. Guardate come la luce vi racconta il mare.
        </p>
        <Link to="/blog" className={styles.backLink}>
          ← Torna al blog
        </Link>
      </section>
    </div>
  );
}

export default BlogFormeDelMare;