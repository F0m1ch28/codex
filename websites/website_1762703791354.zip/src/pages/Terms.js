import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

function Terms() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Termini d’uso | Archivio del Morso</title>
        <meta
          name="description"
          content="Condizioni di utilizzo del sito Archivio del Morso e linee guida per i contenuti editoriali pubblicati."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/terms" />
      </Helmet>

      <section className="container">
        <h1>Termini d’uso</h1>
        <p>
          L’accesso e l’utilizzo del sito Archivio del Morso implicano l’accettazione delle presenti
          condizioni. I contenuti sono protetti da copyright e possono essere condivisi citando la fonte.
        </p>
        <h2>Utilizzo del materiale</h2>
        <p>
          È consentita la citazione parziale dei contenuti con attribuzione a Archivio del Morso e link al
          materiale originale. È vietato l’uso commerciale senza accordo scritto.
        </p>
        <h2>Responsabilità</h2>
        <p>
          Archivio del Morso cura con attenzione l’accuratezza delle informazioni pubblicate ma non può essere
          ritenuto responsabile di eventuali inesattezze dovute a fonti esterne.
        </p>
        <h2>Modifiche</h2>
        <p>
          Ci riserviamo la facoltà di aggiornare i termini in qualsiasi momento. Gli utenti sono invitati a
          verificarne periodicamente il contenuto.
        </p>
      </section>
    </div>
  );
}

export default Terms;