import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Recipes.module.css';

const recipes = [
  {
    id: 'carciofo',
    titolo: 'Carciofo violetto in infusione di mandorla verde',
    image: 'https://picsum.photos/seed/carciofoRicetta/1200/900',
    alt: 'Macro del cuore di carciofo immerso in latte di mandorla',
    ingredienti: [
      '3 carciofi violetti di Niscemi',
      '150 ml latte di mandorla fresca',
      'Olio extravergine cultivar Biancolilla',
      'Pepe Timut pestato',
      'Fiori di finocchietto essiccati'
    ],
    narrazione: [
      'Mondare i carciofi lasciando 4 cm di gambo. Immergerli in acqua e ghiaccio per mantenere la fibrosità tonica.',
      'Scaldare il latte di mandorla a 28 °C insieme a finocchietto e pepe. Lasciare in infusione per 45 minuti.',
      'Servire il carciofo scolato, lucidato con olio, in ciotola opaca con l’infusione tiepida filtrata.'
    ],
    servizio: 'Appoggiare sul fondo della ciotola una pietra riscaldata per mantenere la temperatura gentile.',
    annotazione: 'Acidità morbida, finale mandorlato con ritorno balsamico.'
  },
  {
    id: 'ricciola',
    titolo: 'Ricciola marinata alla polvere di porro',
    image: 'https://picsum.photos/seed/ricciolaRicetta/1200/900',
    alt: 'Ricciola affettata con polvere verde di porro',
    ingredienti: [
      '500 g filetto di ricciola',
      'Sale integrale di Trapani',
      'Polvere di porro essiccato',
      'Olio limone nero',
      'Fiori di borragine'
    ],
    narrazione: [
      'Coprire la ricciola con sale e zucchero al 30% per 18 minuti. Sciacquare e asciugare delicatamente.',
      'Affettare a 45° creando scaglie larghe. Spennellare con olio al limone nero.',
      'Spolverare con porro essiccato e completare con fiori di borragine appena colti.'
    ],
    servizio: 'Disporre su piatto in ceramica grezza inclinato per far colare l’olio aromatico.',
    annotazione: 'Salinità verticale, centro setoso, note agrumate affumicate.'
  },
  {
    id: 'mandorla',
    titolo: 'Mandorla fresca, kefir e polvere di sambuco',
    image: 'https://picsum.photos/seed/mandorlaRicetta/1200/900',
    alt: 'Dessert con granita di kefir e mandorle fresche',
    ingredienti: [
      'Mandorle fresche con pellicina',
      '500 ml kefir autoprodotto',
      'Sciroppo di sambuco',
      'Zeste di cedro candito',
      'Foglie di artemisia'
    ],
    narrazione: [
      'Congelare il kefir in contenitore basso, poi grattare creando neve leggera.',
      'Pelare le mandorle in acqua a 65 °C, mantenerle in siero leggero per 12 ore.',
      'Servire in ciotola fredda con granita di kefir, sciroppo di sambuco e micro zeste.'
    ],
    servizio: 'Portare in tavola con cucchiaio largo e piattino ghiacciato per rallentare lo scioglimento.',
    annotazione: 'Acidità luminosa, finale erbaceo con persistenza lattea.'
  },
  {
    id: 'topinambur',
    titolo: 'Topinambur sotto cera d’api e polline',
    image: 'https://picsum.photos/seed/topinamburRicetta/1200/900',
    alt: 'Topinambur lucido avvolto da cera d’api',
    ingredienti: [
      '6 topinambur medi',
      'Cera d’api naturale',
      'Brodo di verdure leggero',
      'Polline fresco',
      'Aceto di mele torbido'
    ],
    narrazione: [
      'Sigillare i topinambur in cera d’api e infornare a 160 °C per 45 minuti.',
      'Aprire la cera, raccogliere i succhi e unirli al brodo caldo con un cucchiaino di aceto.',
      'Spennellare i tuberi con il jus ottenuto e completare con polline fresco.'
    ],
    servizio: 'Servire con coltellino seghettato per tagliare la superficie lucida senza sbriciolare.',
    annotazione: 'Dolcezza terrosa, retro gusto ceroso e acidità sottile.'
  }
];

function Recipes() {
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') setSelectedRecipe(null);
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (selectedRecipe) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [selectedRecipe]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Ricette stagionali | Archivio del Morso</title>
        <meta
          name="description"
          content="Ricette stagionali con macro fotografie, note narrative e annotazioni sul gusto curate da Archivio del Morso."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/recipes" />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Ricettario</div>
        <h1>Indice di ricette stagionali con narrazioni sensorie</h1>
        <p>
          Ogni ricetta è un frammento narrativo corredato da macro fotografia, note di servizio e annotazione
          sul gusto. Clicca per aprire il taccuino dedicato.
        </p>
      </section>

      <section className={`${styles.grid} container`} aria-label="Ricette stagionali">
        {recipes.map((recipe) => (
          <article key={recipe.id} className={styles.card}>
            <button type="button" onClick={() => setSelectedRecipe(recipe)}>
              <figure>
                <img src={recipe.image} alt={recipe.alt} loading="lazy" />
              </figure>
              <h2>{recipe.titolo}</h2>
              <p>{recipe.annotazione}</p>
              <span>Apri la scheda</span>
            </button>
          </article>
        ))}
      </section>

      {selectedRecipe && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal} role="dialog" aria-modal="true">
            <button
              type="button"
              className={styles.close}
              onClick={() => setSelectedRecipe(null)}
              aria-label="Chiudi ricetta"
            >
              ×
            </button>
            <figure>
              <img src={selectedRecipe.image} alt={selectedRecipe.alt} />
            </figure>
            <div className={styles.modalContent}>
              <h2>{selectedRecipe.titolo}</h2>
              <h3>Ingredienti</h3>
              <ul>
                {selectedRecipe.ingredienti.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <h3>Procedimento narrativo</h3>
              {selectedRecipe.narrazione.map((step, index) => (
                <p key={index}>{step}</p>
              ))}
              <aside>
                <strong>Servizio:</strong> {selectedRecipe.servizio}
              </aside>
              <p className={styles.taste}>
                <strong>Annotazione gusto:</strong> {selectedRecipe.annotazione}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Recipes;