import { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

function Contact() {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    messaggio: '',
    motivo: 'Collaborazione editoriale'
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.nome.trim()) newErrors.nome = 'Inserisci il tuo nome.';
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!emailPattern.test(formData.email)) newErrors.email = 'Email non valida.';
    if (formData.messaggio.trim().length < 20) {
      newErrors.messaggio = 'Scrivi almeno 20 caratteri per aiutarci a comprendere il progetto.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setStatus('Grazie, abbiamo ricevuto il tuo messaggio. Ti risponderemo entro 48 ore.');
      setFormData({
        nome: '',
        email: '',
        messaggio: '',
        motivo: 'Collaborazione editoriale'
      });
    } else {
      setStatus('');
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contatti | Archivio del Morso</title>
        <meta
          name="description"
          content="Contatta Archivio del Morso per collaborazioni editoriali, workshop o invio di materiali. Qui trovi indirizzo, telefono e modulo."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/contact" />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Contatti</div>
        <h1>Scrivici per avviare una collaborazione editoriale</h1>
        <p>
          Raccontaci ingredienti, obiettivi e formato desiderato. Ti rispondiamo dal nostro studio al Centro
          Commerciale Carosello.
        </p>
      </section>

      <section className={`${styles.info} container`}>
        <div className={styles.details}>
          <h2>Coordinate</h2>
          <address>
            <span>Centro Commerciale Carosello</span>
            <span>Via Giuseppe Verdi 1</span>
            <span>20061 Carugate MI, Italia</span>
            <a href="tel:+390256564020">+39 02 5656 4020</a>
            <a href="mailto:archivio@delmorso.it">archivio@delmorso.it</a>
          </address>
          <h3>Linee guida per invii editoriali</h3>
          <ul>
            <li>Invia un abstract di 1.500 battute massimo.</li>
            <li>Specificare ingredienti, territorio e intento narrativo.</li>
            <li>Allega fino a 5 immagini matte (jpg 2 MB max).</li>
            <li>Segnala eventuali scadenze o debutti.</li>
          </ul>
        </div>
        <div className={styles.mapWrapper} aria-label="Mappa della sede">
          <iframe
            title="Mappa Archivio del Morso"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2794.214213226631!2d9.348690976763485!3d45.545629630541484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4786bc9788230571%3A0xeca5fa51b9c76f87!2sCentro%20Commerciale%20Carosello!5e0!3m2!1sit!2sit!4v1707057145000"
            loading="lazy"
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>

      <section className={`${styles.formSection} container`} aria-labelledby="formLabel">
        <h2 id="formLabel">Modulo di contatto</h2>
        <form onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="nome">Nome e cognome</label>
            <input
              id="nome"
              name="nome"
              value={formData.nome}
              onChange={handleChange}
              required
            />
            {errors.nome && <span className={styles.error}>{errors.nome}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="motivo">Motivo</label>
            <select
              id="motivo"
              name="motivo"
              value={formData.motivo}
              onChange={handleChange}
            >
              <option>Collaborazione editoriale</option>
              <option>Richiesta workshop</option>
              <option>Invio materiali stampa</option>
              <option>Altro</option>
            </select>
          </div>
          <div className={styles.field}>
            <label htmlFor="messaggio">Messaggio</label>
            <textarea
              id="messaggio"
              name="messaggio"
              rows="6"
              value={formData.messaggio}
              onChange={handleChange}
              required
            />
            {errors.messaggio && <span className={styles.error}>{errors.messaggio}</span>}
          </div>
          <button type="submit" className="ctaPrimary">
            Invia
          </button>
          {status && <p className={styles.success}>{status}</p>}
        </form>
      </section>
    </div>
  );
}

export default Contact;