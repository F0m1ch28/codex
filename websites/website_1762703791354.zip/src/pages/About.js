import { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    nome: 'Elena Di Toma',
    ruolo: 'Fondatrice · Autrice',
    bio: 'Ha fondato Archivio del Morso dopo anni di giornalismo gastronomico. Laureata in antropologia, appunta su carta ruvida ogni gesto di cucina.',
    visione:
      '“Credo nella scrittura come strumento per rallentare la masticazione e restituirle dignità culturale.”',
    image: 'https://picsum.photos/seed/elenaTeam/600/650'
  },
  {
    nome: 'Giacomo Ratti',
    ruolo: 'Cartografo del gusto',
    bio: 'Disegna mappe sensoriali e gestisce le residenze nei campi. Coordina i dati provenienti da agronomi e cuochi.',
    visione:
      '“La cucina è un paesaggio: la cartografia ci aiuta a non perderci nelle sue altitudini.”',
    image: 'https://picsum.photos/seed/giacomoTeam/600/650'
  },
  {
    nome: 'Sara Baldi',
    ruolo: 'Designer editoriale',
    bio: 'Costruisce layout tipografici, cura le stampe su carta materica e le interfacce mobile del quaderno.',
    visione:
      '“Ogni ingrediente merita un margine netto e uno spazio bianco per respirare.”',
    image: 'https://picsum.photos/seed/saraTeam/600/650'
  }
];

function About() {
  const [activeMember, setActiveMember] = useState(teamMembers[0]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Chi siamo | Archivio del Morso</title>
        <meta
          name="description"
          content="Scopri l’origine di Archivio del Morso, la sua metodologia di osservazione gastronomica, il canone editoriale e il team multidisciplinare."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/about" />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Chi siamo</div>
        <h1>Origine, sguardo e metodo dell’Archivio del Morso</h1>
        <p>
          Archivio del Morso nasce da un’urgenza: osservare il cibo come fatto culturale, registrando
          gesti e materie con la precisione dell’antropologia e la poesia della fotografia macro.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>Origine dell’autrice</h2>
        <p>
          Elena Di Toma ha trascorso dieci anni tra redazioni gastronomiche e campagne agricole. Nel 2019
          apre Archivio del Morso per tessere relazioni tra chef, produttori, antropologi e designer.
        </p>
        <p>
          La base operativa è a Carugate, nello spazio del Centro Commerciale Carosello, trasformato in
          laboratorio editoriale con superfici opache, tavoli lunghi e scaffali di quaderni.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>Come osserviamo il cibo</h2>
        <ul>
          <li>Raccogliamo campioni di ingredienti, annotiamo luce, temperatura, texture.</li>
          <li>Intervistiamo chi produce, cucina o trasforma, registrando voce e gestualità.</li>
          <li>Mappiamo luoghi con carte tattili e coordinate sensoriali.</li>
          <li>Montiamo racconti in layout mobile-first, integrando audio, video e macro fotografie matte.</li>
        </ul>
      </section>

      <section className={`${styles.section} container`}>
        <h2>Canone di collegamenti</h2>
        <p>
          Ogni progetto è nutrito da riferimenti ancorati a editoria, cinema e agronomia. Ecco alcune
          stazioni per orientarsi:
        </p>
        <ul className={styles.links}>
          <li>
            <a href="https://www.slowfood.it/" target="_blank" rel="noreferrer">
              Slow Food Italia · Reti del gusto resistente
            </a>
          </li>
          <li>
            <a href="https://www.jacquespetersen.com/" target="_blank" rel="noreferrer">
              Jacques Petersen · Fotografia matte dei gesti
            </a>
          </li>
          <li>
            <a href="https://www.pedrosoares.com/" target="_blank" rel="noreferrer">
              Pedro Soares · Cartografie culinarie
            </a>
          </li>
          <li>
            <a href="https://www.fao.org/home/it" target="_blank" rel="noreferrer">
              FAO · Dati climatici per colture resilienti
            </a>
          </li>
        </ul>
      </section>

      <section className={`${styles.section} container`}>
        <h2>Posizione estetica</h2>
        <p>
          Prediligiamo superfici asciutte, carte non patinate e luci radenti. Ogni fotografia è un documento
          materico privo di riflessi. Le parole sono strumenti di precisione: verbi lenti, frasi che lasciano
          spazio al lettore per posare il cucchiaio.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>Metodologia</h2>
        <div className={styles.method}>
          <article>
            <h3>Ascolto</h3>
            <p>
              Prima di scattare o scrivere stiamo in silenzio. Registriamo suoni, ritmi, respiro delle cucine.
              Annotiamo su carta ruvida, con grafite morbida, evitando dispositivi che distraggono.
            </p>
          </article>
          <article>
            <h3>Trascrizione</h3>
            <p>
              Convertiamo emozioni in dati: tabelle di texture, gradienti cromatici, griglie olfattive.
              Ogni elemento passa al vaglio di designer e antropologi.
            </p>
          </article>
          <article>
            <h3>Restituzione</h3>
            <p>
              Impaginiamo in modo mobile-first con tagli netti. Stampiamo su carte cotone, confezioniamo
              quaderni a filo singer. Tutto è pensato per un’esperienza lenta e tattile.
            </p>
          </article>
        </div>
      </section>

      <section className={`${styles.section} container`} aria-labelledby="teamTitle">
        <h2 id="teamTitle">Team</h2>
        <p>
          Una squadra trasversale che unisce ricerca testuale, cartografia sensoriale e design tipografico.
          Seleziona un profilo per leggere la visione personale.
        </p>
        <div className={styles.teamGrid}>
          <div className={styles.teamList}>
            {teamMembers.map((member) => (
              <button
                key={member.nome}
                type="button"
                className={`${styles.teamButton} ${
                  activeMember.nome === member.nome ? styles.teamButtonActive : ''
                }`}
                onClick={() => setActiveMember(member)}
              >
                <span>{member.nome}</span>
                <small>{member.ruolo}</small>
              </button>
            ))}
          </div>
          <article className={styles.teamDetail}>
            <figure>
              <img src={activeMember.image} alt={`Ritratto di ${activeMember.nome}`} loading="lazy" />
              <figcaption>{activeMember.ruolo}</figcaption>
            </figure>
            <div className={styles.teamText}>
              <h3>{activeMember.nome}</h3>
              <p>{activeMember.bio}</p>
              <blockquote>{activeMember.visione}</blockquote>
            </div>
          </article>
        </div>
      </section>
    </div>
  );
}

export default About;