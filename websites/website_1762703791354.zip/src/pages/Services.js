import { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    id: 'editorial',
    titolo: 'Editoriale su misura',
    intro: 'Costruiamo quaderni autoriali per ristoranti, consorzi e istituzioni.',
    descrizione:
      'Ogni progetto parte da settimane di ricerca sul campo, interviste e raccolta di immagini macro. Il risultato è un racconto stratificato in formato mobile-first e stampa su carta materica.',
    deliverables: [
      'Storyboard narrativo e indice editoriale',
      'Reportage fotografico matte e still life 45°',
      'Impaginazione responsive e file pronti per stampa'
    ]
  },
  {
    id: 'residenza',
    titolo: 'Residenza di osservazione',
    intro: 'Portiamo il nostro studio nel vostro laboratorio, in cucina o in azienda agricola.',
    descrizione:
      'Organizziamo residenze immersive di 7 o 14 giorni con sessioni di ascolto, mappatura degli ingredienti e restituzioni quotidiane per il team interno.',
    deliverables: [
      'Agenda quotidiana e analisi tattile',
      'Taccuini condivisi con note audio',
      'Sessione finale con tavola di sintesi'
    ]
  },
  {
    id: 'atlas',
    titolo: 'Atlante sensoriale',
    intro: 'Disegniamo mappe gastronomiche per valorizzare territori, festival e brand.',
    descrizione:
      'Creiamo cartografie cromatiche, pattern di texture e schemi olfattivi per guidare il pubblico in percorsi degustativi consapevoli.',
    deliverables: [
      'Palette colore per ingredienti e ambienti',
      'Infografiche e schede tattili',
      'Versioni multilingue e adattamento digitale'
    ]
  }
];

const addOn = [
  {
    titolo: 'Coaching di scrittura sensoriale',
    testo: 'Sessioni dedicate al team comunicazione per sviluppare un lessico preciso e coerente con il vostro ingrediente.'
  },
  {
    titolo: 'Direzione artistica fotografica',
    testo: 'Supervisioniamo shooting interni o con partner per mantenere coerenza tra luce, superfici e narrazione.'
  },
  {
    titolo: 'Podcast di materia',
    testo: 'Mini serie audio per accompagnare il lancio di un quaderno o di un atlante con testimonianze sul campo.'
  }
];

function Services() {
  const [selected, setSelected] = useState(services[0]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Servizi editoriali | Archivio del Morso</title>
        <meta
          name="description"
          content="Scopri i servizi editoriali di Archivio del Morso: quaderni su misura, residenze di osservazione e atlanti sensoriali per raccontare ingredienti e territori."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/services" />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Servizi</div>
        <h1>Soluzioni editoriali per dare voce a ingredienti e territori</h1>
        <p>
          Dalla residenza di osservazione al quaderno autoriale, offriamo strumenti per trasformare materia
          culinaria in narrazione culturale coerente, mobile-first e stampabile.
        </p>
      </section>

      <section className={`${styles.catalog} container`}>
        <div className={styles.catalogList}>
          {services.map((service) => (
            <button
              key={service.id}
              type="button"
              className={`${styles.catalogButton} ${
                selected.id === service.id ? styles.catalogButtonActive : ''
              }`}
              onClick={() => setSelected(service)}
            >
              <span>{service.titolo}</span>
              <small>{service.intro}</small>
            </button>
          ))}
        </div>
        <article className={styles.catalogDetail}>
          <h2>{selected.titolo}</h2>
          <p>{selected.descrizione}</p>
          <h3>Cosa consegniamo</h3>
          <ul>
            {selected.deliverables.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </article>
      </section>

      <section className={`${styles.process} container`}>
        <div className="badge">Processo</div>
        <h2>Workflow in quattro tagli</h2>
        <div className={styles.steps}>
          <article>
            <span>01</span>
            <h3>Brief sensoriale</h3>
            <p>
              Sessione di ascolto per definire ingredienti chiave, pubblico e tono. Consegniamo un documento
              di taglio con tavola cromatica preliminare.
            </p>
          </article>
          <article>
            <span>02</span>
            <h3>Osservazione</h3>
            <p>
              Residenza sul campo: raccogliamo audio, macro fotografie, campioni. Compiliamo schede di texture
              e note di luce.
            </p>
          </article>
          <article>
            <span>03</span>
            <h3>Montaggio</h3>
            <p>
              Scriviamo saggi e schede ingredienti, disegniamo layout responsive e selezioniamo immagini con
              finitura matte.
            </p>
          </article>
          <article>
            <span>04</span>
            <h3>Diffusione</h3>
            <p>
              Prepariamo materiali per stampa, web e workshop. Offriamo coaching per team interni e supporto
              agli eventi di presentazione.
            </p>
          </article>
        </div>
      </section>

      <section className={`${styles.addOn} container`}>
        <div className="badge">Estensioni</div>
        <h2>Servizi add-on per amplificare la narrazione</h2>
        <div className={styles.addOnGrid}>
          {addOn.map((item) => (
            <article key={item.titolo}>
              <h3>{item.titolo}</h3>
              <p>{item.testo}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.cta} container`}>
        <h2>Pronti a disegnare il vostro quaderno?</h2>
        <p>
          Prenota un incontro introduttivo: analizzeremo ingredienti, tono di voce e superfici preferite per
          costruire un progetto coerente.
        </p>
        <a className="ctaPrimary" href="/contact">
          Prenota un incontro
        </a>
      </section>
    </div>
  );
}

export default Services;