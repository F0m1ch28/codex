import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const seasonalCalendar = [
  {
    mese: 'Gennaio',
    ingrediente: 'Broccolo fiolaro',
    texture: 'Filamenti croccanti, note affumicate',
    tecnica: 'Sbollentato e poi laccato con agrume bruciato'
  },
  {
    mese: 'Febbraio',
    ingrediente: 'Carciofo violetto di Niscemi',
    texture: 'Fasci fibrosi, cuore morbido e tonico',
    tecnica: 'Sfoglie crude in acqua di mandorla'
  },
  {
    mese: 'Marzo',
    ingrediente: 'Borragine tenera',
    texture: 'Velluto minerale, ritorno balneare',
    tecnica: 'Foglia pressata a freddo con siero'
  },
  {
    mese: 'Aprile',
    ingrediente: 'Pisello rugoso',
    texture: 'Perle dolci, scorza erbacea',
    tecnica: 'Macerazione in olio di camomilla'
  },
  {
    mese: 'Maggio',
    ingrediente: 'Fragola candonga',
    texture: 'Polpa lucida, acidità luminosa',
    tecnica: 'Cottura breve in sale di sedano'
  },
  {
    mese: 'Giugno',
    ingrediente: 'Zucchina trombetta',
    texture: 'Lamelle sottili, succo verde',
    tecnica: 'Fermentazione con polvere di alloro'
  },
  {
    mese: 'Luglio',
    ingrediente: 'Pomodoro cuore di bue',
    texture: 'Polpa stratificata, acqua sapida',
    tecnica: 'Essiccazione parziale e brodo crudo'
  },
  {
    mese: 'Agosto',
    ingrediente: 'Pesca tabacchiera',
    texture: 'Fibra satinata, profumo di fieno',
    tecnica: 'Fumo freddo di mandorlo'
  },
  {
    mese: 'Settembre',
    ingrediente: 'Fico dottato',
    texture: 'Semi vellutati, sciroppo naturale',
    tecnica: 'Caramellizzazione lenta in argilla'
  },
  {
    mese: 'Ottobre',
    ingrediente: 'Zucca violina',
    texture: 'Crema compatta, eco di nocciola',
    tecnica: 'Torrefazione con miso di castagna'
  },
  {
    mese: 'Novembre',
    ingrediente: 'Radicchio tardivo',
    texture: 'Falde croccanti, amaro profondo',
    tecnica: 'Riposo in acqua affumicata'
  },
  {
    mese: 'Dicembre',
    ingrediente: 'Topinambur',
    texture: 'Polpa lattiginosa, crosta terrosa',
    tecnica: 'Cottura sotto cera d’api'
  }
];

const ingredientSpotlight = [
  {
    titolo: 'Sedano rapa latente',
    descrizione:
      'Trucioli pressati con polvere di kombu, grafite vegetale che avvolge il palato.',
    micro: 'Taglio 1,5 mm | Pressione a freddo | 6° C',
    image: 'https://picsum.photos/seed/sedanoRapa/800/640'
  },
  {
    titolo: 'Ricciola in conchiglia di sale',
    descrizione:
      'Spalla del mare, lucidata con olio di finocchietto e infusione di limone nero.',
    micro: 'Angolo 45° | Tempo asciugatura 4h | Sale di miniera',
    image: 'https://picsum.photos/seed/ricciolaMacro/800/640'
  },
  {
    titolo: 'Mandorla fresca in neve di kefir',
    descrizione:
      'Granito lattico, vibrazione acidula e masticazione lenta come gesto di memoria.',
    micro: 'Fermento madre #8 | 2° C | 48h osservazione',
    image: 'https://picsum.photos/seed/mandorlaKefir/800/640'
  }
];

const servicesDeck = [
  {
    id: 'residenza',
    titolo: 'Residenze di campo',
    descrizione:
      'Settimane in residenza per osservare i gesti dei produttori, raccogliendo appunti tattili e fotografie matte.',
    dettagli: [
      'Diari condivisi ingredienti-territorio',
      'Sessioni sensoriali all’alba',
      'Reportage fotografico in macro testurale'
    ]
  },
  {
    id: 'quaderno',
    titolo: 'Quaderni autoriali',
    descrizione:
      'Progetti editoriali per raccontare tavole, chef e artigiani con narrativa stratificata e grafica essenziale.',
    dettagli: [
      'Ricerca storica e iconografica',
      'Interviste e trascrizioni liriche',
      'Impaginazione mobile-first e stampa'
    ]
  },
  {
    id: 'atlas',
    titolo: 'Atlante dei sapori',
    descrizione:
      'Mappatura cartografica delle forme e dei colori del gusto per brand, archivi museali e istituzioni.',
    dettagli: [
      'Schede cromatiche e pattern',
      'Schemi olfattivi multilivello',
      'Cartografia narrativa per percorsi'
    ]
  }
];

const processSteps = [
  {
    titolo: 'Immersione',
    testo: 'Entriamo nei laboratori, nelle cucine e nei campi annotando su carta ruvida gesti minimi e luci.'
  },
  {
    titolo: 'Trascrizione',
    testo: 'Convertiamo ciò che vediamo in mappe concettuali, tavole cromatiche e racconti tecnici in lingua sensoriale.'
  },
  {
    titolo: 'Montaggio',
    testo: 'Componiamo layout mobile-first, fotografie matte e tipografia calibrata sul respiro della lettura.'
  },
  {
    titolo: 'Risonanza',
    testo: 'Accompagniamo la diffusione con podcast, workshop e talk per far vibrare l’archivio in comunità.'
  }
];

const testimonials = [
  {
    nome: 'Marta Ferri · curatrice',
    citazione:
      '“Archivio del Morso ha trasformato una degustazione in un atlante emotivo. Ogni ingrediente è diventato racconto di luce e memoria.”',
    ruolo: 'Curatrice di festival gastronomici'
  },
  {
    nome: 'Chef Paolo Neroni',
    citazione:
      '“Le loro note tattili mi hanno consegnato un nuovo vocabolario. Ho ripensato il menù seguendo i loro gradienti di colore.”',
    ruolo: 'Chef residente al Laboratorio Mirto'
  },
  {
    nome: 'Consorzio Vite Sul Fiume',
    citazione:
      '“Hanno connesso viticoltori, ceramisti e botanici attorno a un unico gesto: versare. L’archivio parla la lingua del territorio.”',
    ruolo: 'Osservatorio agricolo'
  }
];

const teamShowcase = [
  {
    nome: 'Elena Di Toma',
    ruolo: 'Fondatrice · autrice',
    bio: 'Ricercatrice di semi, scrive e fotografa strati sensoriali dal 2011.',
    image: 'https://picsum.photos/seed/elenaArchivio/400/480'
  },
  {
    nome: 'Giacomo Ratti',
    ruolo: 'Cartografo del gusto',
    bio: 'Trasforma ingredienti in mappe tattili e palette di campo.',
    image: 'https://picsum.photos/seed/giacomoArchivio/400/480'
  },
  {
    nome: 'Sara Baldi',
    ruolo: 'Designer editoriale',
    bio: 'Disegna layout a taglio netto e cura le stampe su carte materiche.',
    image: 'https://picsum.photos/seed/saraArchivio/400/480'
  }
];

const projectGallery = [
  {
    id: 1,
    titolo: 'Atlante delle acidità alpine',
    categoria: 'Atlante Sensoriale',
    descrizione: 'Rilievi cromatici dei latticini d’altura, tavole in scala fredda.',
    image: 'https://picsum.photos/seed/progettoAcidita/900/700'
  },
  {
    id: 2,
    titolo: 'Residenza Terra-Mare',
    categoria: 'Residenza',
    descrizione: 'Ricerca sulle creste saline del Delta del Po e sulle ceramiche opache.',
    image: 'https://picsum.photos/seed/progettoResidenza/900/700'
  },
  {
    id: 3,
    titolo: 'Quaderno Sosta Lenta',
    categoria: 'Quaderno',
    descrizione: 'Narrazione fotografica di una pasticceria siciliana e dei suoi gesti d’attesa.',
    image: 'https://picsum.photos/seed/progettoQuaderno/900/700'
  },
  {
    id: 4,
    titolo: 'Campo Aperto · Cereali antichi',
    categoria: 'Campo',
    descrizione: 'Documentazione di spighe e farine con microscopia e note miniaturizzate.',
    image: 'https://picsum.photos/seed/progettoCampo/900/700'
  }
];

const faqItems = [
  {
    domanda: 'Quanto dura un ciclo di osservazione?',
    risposta:
      'Ogni ciclo prevede tre settimane di immersione e due di montaggio editoriale, con sessioni di restituzione intermedie.'
  },
  {
    domanda: 'È possibile proporre ingredienti da investigare?',
    risposta:
      'Accettiamo suggerimenti inviati via mail. Valutiamo l’ingredienti per stagionalità, storia e potenziale narrativo sul territorio.'
  },
  {
    domanda: 'Come vengono gestite le immagini macro?',
    risposta:
      'Scattiamo su superfici opache con luce controllata, evitando riflessi e preservando matericità. Forniamo file ottimizzati per stampa e web.'
  },
  {
    domanda: 'Realizzate workshop privati?',
    risposta:
      'Sì, progettiamo workshop su misura sia in presenza sia da remoto, integrando esercizi di scrittura sensoriale e regia fotografica.'
  }
];

const blogPreview = [
  {
    titolo: 'Luce che accende l’acidità',
    descrizione: 'Un viaggio nella dialettica tra luce radente e sapori taglienti.',
    path: '/blog/luce-che-accende-l-acidita'
  },
  {
    titolo: 'Forme del mare, grammatica delle salse',
    descrizione: 'Studio sui fondi marini e sui legami emulsionati delle cucine costiere.',
    path: '/blog/forme-del-mare-grammatica-delle-salse'
  },
  {
    titolo: 'Cartografia commestibile',
    descrizione: 'Mappe sensoriali per orientarsi tra alture, pianure e piatti.',
    path: '/blog/cartografia-commestibile'
  }
];

const countersTarget = {
  anni: 12,
  ingredienti: 134,
  taccuini: 328,
  residenze: 19
};

function Home() {
  const [counters, setCounters] = useState({
    anni: 0,
    ingredienti: 0,
    taccuini: 0,
    residenze: 0
  });
  const [activeService, setActiveService] = useState(servicesDeck[0].id);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Tutto');
  const [openFaq, setOpenFaq] = useState(null);
  const [email, setEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState('');
  const [newsletterError, setNewsletterError] = useState('');

  const currentMonth = new Date().getMonth();
  const seasonalFocus = seasonalCalendar[currentMonth];

  useEffect(() => {
    let frame = 0;
    const duration = 1800;
    const frameDuration = 40;
    const totalFrames = Math.round(duration / frameDuration);

    const counterInterval = setInterval(() => {
      frame += 1;
      setCounters((prev) => {
        const progress = frame / totalFrames;
        const easeProgress = 1 - Math.pow(1 - progress, 3);
        return {
          anni: Math.min(
            countersTarget.anni,
            Math.round(countersTarget.anni * easeProgress)
          ),
          ingredienti: Math.min(
            countersTarget.ingredienti,
            Math.round(countersTarget.ingredienti * easeProgress)
          ),
          taccuini: Math.min(
            countersTarget.taccuini,
            Math.round(countersTarget.taccuini * easeProgress)
          ),
          residenze: Math.min(
            countersTarget.residenze,
            Math.round(countersTarget.residenze * easeProgress)
          )
        };
      });
      if (frame === totalFrames) {
        clearInterval(counterInterval);
      }
    }, frameDuration);

    return () => clearInterval(counterInterval);
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6500);

    return () => clearInterval(rotation);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Tutto') return projectGallery;
    return projectGallery.filter((project) => project.categoria === activeCategory);
  }, [activeCategory]);

  const activeServiceData = servicesDeck.find((service) => service.id === activeService);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!emailPattern.test(email)) {
      setNewsletterError('Inserisci un indirizzo email valido.');
      setNewsletterStatus('');
      return;
    }
    setNewsletterError('');
    setNewsletterStatus('Iscrizione completata. Benvenuta/o nel quaderno del Morso.');
    setEmail('');
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Archivio del Morso | Quaderno di cultura gastronomica</title>
        <meta
          name="description"
          content="Archivio del Morso è un osservatorio editoriale italiano che esplora ingredienti, gesti e tecniche attraverso racconti, workshop e ricette stagionali."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/" />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className={styles.heroImage} role="presentation">
          <img
            src="https://picsum.photos/seed/eroIngredient/1600/900"
            alt="Macro fotografia di ingredienti con luce obliqua"
            loading="lazy"
          />
          <div className={styles.microMeta}>
            <span>Iso 200 · 45°</span>
            <span>Luce radente</span>
            <span>Superficie opaca</span>
          </div>
        </div>
        <div className={styles.heroContent}>
          <div className="badge">Quaderno editoriale</div>
          <h1>Archivio del Morso: osservare il cibo per rimescolare i gesti.</h1>
          <p>
            Un laboratorio narrativo che ascolta ingredienti stagionali, cartografie del gusto e comunità
            culinarie. Scriviamo, fotografiamo e traduciamo in formati editoriali mobile-first con un
            linguaggio sensoriale e preciso.
          </p>
          <div className={styles.heroActions}>
            <a className="ctaPrimary" href="#newsletter">
              Iscriviti alla Lettera del Morso
            </a>
            <Link className={styles.secondary} to="/about">
              Scopri la nostra metodologia
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.seasonal} container`}>
        <div className={styles.seasonalCard}>
          <div className="badge">Angolo stagionale</div>
          <h2>{seasonalFocus.mese}: sapore in ascolto</h2>
          <p className={styles.ingName}>{seasonalFocus.ingrediente}</p>
          <div className={styles.seasonalDetails}>
            <div>
              <h3>Texture</h3>
              <p>{seasonalFocus.texture}</p>
            </div>
            <div>
              <h3>Tecnica</h3>
              <p>{seasonalFocus.tecnica}</p>
            </div>
          </div>
            <Link to="/recipes" className={styles.linkInline}>
              Entra nelle ricette dedicate
            </Link>
        </div>
        <div className={styles.formColor}>
          <h2 className="sectionTitle">Forme &amp; colori del mese</h2>
          <div className={styles.colorStrips} aria-hidden="true">
            <span style={{ backgroundColor: '#6F7C58' }} />
            <span style={{ backgroundColor: '#B9A57C' }} />
            <span style={{ backgroundColor: '#F8E4C9' }} />
            <span style={{ backgroundColor: '#342F2A' }} />
          </div>
          <p>
            Documentiamo gradienti cromatici, linee e volumi di ogni ingrediente per consegnare ai lettori
            una grammatica visiva del gusto.
          </p>
        </div>
      </section>

      <section className={`${styles.spotlight} container`} aria-labelledby="spotlightHeading">
        <div className={styles.spotlightHeader}>
          <div className="badge">Ingredient spotlight</div>
          <h2 id="spotlightHeading" className="sectionTitle">
            Macro osservazioni sugli ingredienti in evidenza
          </h2>
          <p>
            Ogni dettaglio è raccolto con luce inclinata e appunti a margine: micro tipografie,
            coordinate tattili e note di temperatura.
          </p>
        </div>
        <div className={styles.spotlightGrid}>
          {ingredientSpotlight.map((item) => (
            <article key={item.titolo} className={styles.spotlightCard}>
              <figure>
                <img src={item.image} alt={`Dettaglio di ${item.titolo}`} loading="lazy" />
                <figcaption>{item.micro}</figcaption>
              </figure>
              <h3>{item.titolo}</h3>
              <p>{item.descrizione}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.stats} aria-label="Metriche dell'archivio">
        <div className="container">
          <div className={styles.statsGrid}>
            <div>
              <span>{counters.anni}</span>
              <p>Anni di indagine gastronomica</p>
            </div>
            <div>
              <span>{counters.ingredienti}</span>
              <p>Ingredienti mappati con note tattili</p>
            </div>
            <div>
              <span>{counters.taccuini}</span>
              <p>Taccuini digitali e cartacei pubblicati</p>
            </div>
            <div>
              <span>{counters.residenze}</span>
              <p>Residenze culinarie co-curate</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.servicesSection} container`} aria-labelledby="servicesHome">
        <div className={styles.servicesIntro}>
          <div className="badge">Servizi editoriali</div>
          <h2 id="servicesHome" className="sectionTitle">
            Strumenti per trasformare ingredienti in narrazione culturale
          </h2>
          <p>
            Dal campo al layout, costruiamo percorsi narrativi per chef, consorzi e istituzioni che desiderano
            raccontare il cibo con profondità e chiarezza visiva.
          </p>
          <Link to="/services" className="ctaPrimary">
            Vedi tutti i servizi
          </Link>
        </div>
        <div className={styles.servicesGrid}>
          <div className={styles.servicesTabs}>
            {servicesDeck.map((service) => (
              <button
                key={service.id}
                type="button"
                className={`${styles.serviceTab} ${
                  activeService === service.id ? styles.serviceTabActive : ''
                }`}
                onMouseEnter={() => setActiveService(service.id)}
                onFocus={() => setActiveService(service.id)}
                onClick={() => setActiveService(service.id)}
                aria-pressed={activeService === service.id}
              >
                {service.titolo}
              </button>
            ))}
          </div>
          <div className={styles.serviceDetail}>
            <h3>{activeServiceData.titolo}</h3>
            <p>{activeServiceData.descrizione}</p>
            <ul>
              {activeServiceData.dettagli.map((detail) => (
                <li key={detail}>{detail}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={`${styles.process} container`} aria-labelledby="processLabel">
        <div className={styles.processHeader}>
          <div className="badge">Processo</div>
          <h2 id="processLabel" className="sectionTitle">
            Dalla raccolta delle micro tracce alla diffusione del racconto
          </h2>
        </div>
        <div className={styles.processSteps}>
          {processSteps.map((step, index) => (
            <article key={step.titolo}>
              <span className={styles.stepNumber}>{`0${index + 1}`}</span>
              <h3>{step.titolo}</h3>
              <p>{step.testo}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Testimonianze">
        <div className="container">
          <div className="badge">Risonanza</div>
          <div className={styles.testimonialCard}>
            <blockquote>
              {testimonials[testimonialIndex].citazione}
            </blockquote>
            <p className={styles.testimonialName}>{testimonials[testimonialIndex].nome}</p>
            <span className={styles.testimonialRole}>{testimonials[testimonialIndex].ruolo}</span>
            <div className={styles.testimonialDots}>
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  aria-label={`Mostra testimonianza ${idx + 1}`}
                  className={idx === testimonialIndex ? styles.dotActive : ''}
                  onClick={() => setTestimonialIndex(idx)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.team} container`} aria-labelledby="teamLabel">
        <div className={styles.teamHeader}>
          <div className="badge">Team</div>
          <h2 id="teamLabel" className="sectionTitle">
            Una squadra editoriale che intreccia ricerca, cartografia e design
          </h2>
        </div>
        <div className={styles.teamGrid}>
          {teamShowcase.map((member) => (
            <article key={member.nome} className={styles.teamCard}>
              <figure>
                <img src={member.image} alt={`Ritratto di ${member.nome}`} loading="lazy" />
                <figcaption>{member.ruolo}</figcaption>
              </figure>
              <h3>{member.nome}</h3>
              <p>{member.bio}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.projects} container`} aria-labelledby="projectsLabel">
        <div className={styles.projectsHeader}>
          <div className="badge">Progetti</div>
          <h2 id="projectsLabel" className="sectionTitle">
            Gallerie editoriali filtrabili per entrare nei nostri archivi
          </h2>
          <div className={styles.filters}>
            {['Tutto', 'Atlante Sensoriale', 'Residenza', 'Quaderno', 'Campo'].map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <figure>
                <img
                  src={`${project.image}?auto=compress`}
                  alt={`Visual del progetto ${project.titolo}`}
                  loading="lazy"
                />
              </figure>
              <div>
                <span>{project.categoria}</span>
                <h3>{project.titolo}</h3>
                <p>{project.descrizione}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.faq} container`} aria-labelledby="faqLabel">
        <div className={styles.faqHeader}>
          <div className="badge">FAQ</div>
          <h2 id="faqLabel" className="sectionTitle">
            Domande frequenti su metodo e collaborazione
          </h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div key={item.domanda} className={styles.faqItem}>
              <button
                type="button"
                onClick={() => setOpenFaq((prev) => (prev === index ? null : index))}
                aria-expanded={openFaq === index}
              >
                {item.domanda}
                <span>{openFaq === index ? '−' : '+'}</span>
              </button>
              {openFaq === index && <p>{item.risposta}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.blogPreview} container`} aria-labelledby="blogPreviewLabel">
        <div className="badge">Ultime letture</div>
        <h2 id="blogPreviewLabel" className="sectionTitle">
          Leggerezze e densità di campo: gli ultimi saggi dal quaderno
        </h2>
        <div className={styles.blogGrid}>
          {blogPreview.map((post) => (
            <article key={post.path} className={styles.blogCard}>
              <h3>{post.titolo}</h3>
              <p>{post.descrizione}</p>
              <Link to={post.path}>Apri l&apos;articolo</Link>
            </article>
          ))}
        </div>
      </section>

      <section id="newsletter" className={styles.newsletter}>
        <div className="container">
          <div className={styles.newsletterCard}>
            <div>
              <div className="badge">Newsletter</div>
              <h2 className="sectionTitle">Lettera del Morso</h2>
              <p>
                Ogni mese ricevi schede macro, note di campo e link al nostro canone editoriale. Nessun rumore,
                solo materia viva.
              </p>
            </div>
            <form onSubmit={handleNewsletterSubmit}>
              <label htmlFor="newsletterEmail">Email</label>
              <div className={styles.newsletterInput}>
                <input
                  id="newsletterEmail"
                  type="email"
                  placeholder="nome@studio.it"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  required
                />
                <button type="submit" className="ctaPrimary">
                  Iscriviti
                </button>
              </div>
              {newsletterError && <p className={styles.error}>{newsletterError}</p>}
              {newsletterStatus && <p className={styles.success}>{newsletterStatus}</p>}
            </form>
          </div>
        </div>
      </section>

      <section className={`${styles.cta} container`} aria-labelledby="ctaLabel">
        <h2 id="ctaLabel" className="sectionTitle">
          Pronti a osservare il vostro ingrediente con una lente editoriale?
        </h2>
        <p>
          Organizziamo incontri esplorativi per comprendere storie, desideri e coordinate materiche.
          Scrivici e progettiamo insieme il prossimo quaderno del Morso.
        </p>
        <Link className="ctaPrimary" to="/contact">
          Prenota una call editoriale
        </Link>
      </section>
    </div>
  );
}

export default Home;