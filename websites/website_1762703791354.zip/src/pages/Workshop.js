import { Helmet } from 'react-helmet';
import styles from './Workshop.module.css';

const workshops = [
  {
    titolo: 'Composizione editoriale',
    descrizione:
      'Impariamo a progettare layout mobile-first per racconti gastronomici, con focus su tipografia, ritmo e gestione delle immagini matte.'
  },
  {
    titolo: 'Angoli e luce',
    descrizione:
      'Sessioni dedicate alla fotografia macro in luce naturale controllata. Lavoriamo su superfici opache, angoli a 45° e micro-metadati.'
  },
  {
    titolo: 'Micro-texture e nota sensoriale',
    descrizione:
      'Laboratorio di scrittura per tradurre texture e sapori in parole. Usiamo esercizi di etnografia dell’ingrediente e campionari cromatici.'
  }
];

const calendar = [
  {
    data: '16 marzo 2024',
    titolo: 'Workshop in presenza · Milano',
    dettagli: 'Studio luminoso, 12 posti. Include visita al mercato e sessione fotografica.'
  },
  {
    data: '4 aprile 2024',
    titolo: 'Laboratorio digitale · Storie aromatiche',
    dettagli: 'Online, 3 ore con kit ingredienti spedito in anticipo.'
  },
  {
    data: '25 maggio 2024',
    titolo: 'Residenza di campo · Monferrato',
    dettagli: 'Weekend intensivo, 8 posti, alloggio incluso. Analisi uve e erbe spontanee.'
  }
];

function Workshop() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Workshop | Archivio del Morso</title>
        <meta
          name="description"
          content="Workshop e residenze di Archivio del Morso: composizione editoriale, fotografia macro e scrittura sensoriale per professionisti del cibo."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/workshop" />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Workshop</div>
        <h1>Allenare lo sguardo gastronomico tra campo e schermo</h1>
        <p>
          I nostri workshop uniscono narrazione, fotografia e antropologia del cibo. Disponibili in presenza
          e online, con approccio mobile-first e materiali tattili.
        </p>
      </section>

      <section className={`${styles.modules} container`} aria-label="Moduli tematici">
        {workshops.map((mod) => (
          <article key={mod.titolo}>
            <h2>{mod.titolo}</h2>
            <p>{mod.descrizione}</p>
          </article>
        ))}
      </section>

      <section className={`${styles.calendar} container`} aria-label="Calendario workshop">
        <h2>Prossime date</h2>
        <div className={styles.calendarGrid}>
          {calendar.map((item) => (
            <article key={item.titolo}>
              <span>{item.data}</span>
              <h3>{item.titolo}</h3>
              <p>{item.dettagli}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.cta} container`}>
        <h2>Partecipa o richiedi un workshop dedicato</h2>
        <p>
          Scrivici indicando obiettivi, numero di partecipanti e luogo. Risponderemo con una proposta
          personalizzata e materiali preparatori.
        </p>
        <a className="ctaPrimary" href="/contact">
          Prenota un posto
        </a>
      </section>
    </div>
  );
}

export default Workshop;