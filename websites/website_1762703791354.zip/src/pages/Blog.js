import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';

const clusters = {
  Gesto: [
    {
      titolo: 'Luce che accende l’acidità',
      abstract: 'Uno studio sulle inclinazioni della luce che risvegliano sapori taglienti.',
      path: '/blog/luce-che-accende-l-acidita'
    }
  ],
  Memoria: [
    {
      titolo: 'Cartografia commestibile',
      abstract: 'Memorie geografiche e palati che diventano mappe emotive.',
      path: '/blog/cartografia-commestibile'
    }
  ],
  Tecnica: [
    {
      titolo: 'Forme del mare, grammatica delle salse',
      abstract: 'Emulsioni costiere e tracciati liquidi tra maree e cucine.',
      path: '/blog/forme-del-mare-grammatica-delle-salse'
    }
  ],
  Campo: [
    {
      titolo: 'Atlante delle erbe spontanee',
      abstract: 'Appunti visivi dalle campagne lombarde (coming soon).',
      path: '/blog'
    }
  ]
};

function Blog() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Blog | Archivio del Morso</title>
        <meta
          name="description"
          content="Il blog di Archivio del Morso raccoglie saggi ed esperienze: gesti, memorie, tecniche e racconti di campo sulla cultura gastronomica."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/blog" />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Blog</div>
        <h1>Saggi e storie dal campo gastronomico</h1>
        <p>
          Le nostre rubriche sono organizzate per cluster tematici: gesti, memorie, tecniche e campi. Ogni
          carta è un invito a una lettura lenta e stratificata.
        </p>
      </section>

      <section className={`${styles.grid} container`} aria-label="Cluster di articoli">
        {Object.entries(clusters).map(([cluster, posts]) => (
          <article key={cluster} className={styles.cluster}>
            <header>
              <span>{cluster}</span>
              <h2>{`Cluster ${cluster}`}</h2>
            </header>
            <div className={styles.posts}>
              {posts.map((post) => (
                <div key={post.titolo} className={styles.postCard}>
                  <h3>{post.titolo}</h3>
                  <p>{post.abstract}</p>
                  {post.path === '/blog' ? (
                    <span className={styles.soon}>In arrivo</span>
                  ) : (
                    <Link to={post.path}>Leggi</Link>
                  )}
                </div>
              ))}
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

export default Blog;