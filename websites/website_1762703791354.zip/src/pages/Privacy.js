import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Privacy | Archivio del Morso</title>
        <meta
          name="description"
          content="Informativa privacy di Archivio del Morso relativa al trattamento dei dati personali e alla gestione delle comunicazioni."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/privacy" />
      </Helmet>

      <section className="container">
        <h1>Informativa Privacy</h1>
        <p>
          Archivio del Morso tratta i dati personali nel rispetto del Regolamento UE 679/2016. I dati raccolti
          tramite form o newsletter sono usati esclusivamente per rispondere alle richieste e inviare
          comunicazioni editoriali.
        </p>
        <h2>Titolare del trattamento</h2>
        <p>Archivio del Morso · Centro Commerciale Carosello, Via Giuseppe Verdi 1, 20061 Carugate MI.</p>
        <h2>Tipologia di dati</h2>
        <p>Raccogliamo nome, email e messaggi volontariamente inviati dagli utenti.</p>
        <h2>Diritti dell’interessato</h2>
        <p>
          È possibile esercitare i diritti di accesso, rettifica, cancellazione scrivendoci a
          archivio@delmorso.it.
        </p>
      </section>
    </div>
  );
}

export default Privacy;