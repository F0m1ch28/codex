import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './BlogArticle.module.css';

function BlogLuceCheAccendeLAcidita() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Luce che accende l’acidità | Archivio del Morso</title>
        <meta
          name="description"
          content="Un saggio dedicato alla relazione tra luce e acidità: osservazioni fotografiche e narrazioni sensoriali dall’Archivio del Morso."
        />
        <link
          rel="canonical"
          href="https://www.archivio-del-morso.it/blog/luce-che-accende-l-acidita"
        />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className="badge">Cluster Gesto</div>
        <h1>Luce che accende l’acidità</h1>
        <div className={styles.meta}>
          <span>di Elena Di Toma</span>
          <span>Pubblicato il 5 febbraio 2024</span>
          <span>Tempo di lettura · 7 minuti</span>
        </div>
      </section>

      <section className={`${styles.content} container`}>
        <p>
          L’acidità non è mai un sapore isolato: è un gesto di luce. Quando entriamo in una cucina o in un
          campo cerchiamo angoli radenti, superfici che possano riflettere una temperatura precisa. Senza
          luce, l’acidità resta muta.
        </p>
        <p>
          Un carciofo immerso in acqua di limone racconta una storia diversa se la lampada è neutra o calda.
          Con luce fredda emergono le fibre, con luce tiepida si percepisce il latte interno. È la stessa
          lama che accende limoni, arance, kefir.
        </p>
        <img
          src="https://picsum.photos/seed/lumeAcido1/1200/800"
          alt="Macro di agrumi illuminati da luce radente"
          loading="lazy"
        />
        <p>
          Durante una residenza sulle coste di Siracusa abbiamo sperimentato con quattro sorgenti luminose.
          Le ostriche aperte, illuminate a 45°, rivelavano la percezione salina e acidula con maggiore
          precisione. L’ombra proiettata attivava il lato più scuro dell’acqua marina.
        </p>
        <blockquote className={styles.pullQuote}>
          “L’acidità si rivela quando incontriamo un bordo. È in quell’istante luminoso che il palato apre gli
          occhi.”
        </blockquote>
        <p>
          Nei quaderni del Morso annotiamo sempre l’angolo della luce. Non si tratta solo di fotografia:
          scrivere “45° radente” significa ricordare che quella crema di kefir deve essere servita davanti a
          un vetro grande, durante il pomeriggio, con il sole che scivola verso ovest.
        </p>
        <img
          src="https://picsum.photos/seed/lumeAcido2/1200/800"
          alt="Dettaglio di kefir illuminato con luce inclinata"
          loading="lazy"
        />
        <p>
          Ci sono acidità che vivono solo in presenza di luce diffusa. Penso a una fermentazione di sedano
          rapa: senza un tessuto bianco dietro, la bevanda resta opaca, confusa. Con un fondale chiaro la
          trasparenza prende corpo, l’occhio prepara il palato.
        </p>
        <p>
          Lo stesso accade con i dessert lattici. Una pannacotta servita al buio perde vibrazione. Se
          l’accompagniamo con un raggio stretto, l’acidità latente emerge. È una questione di ritmo: la luce
          conduce il cucchiaio verso una direzione, definisce dove posare il morso.
        </p>
        <p>
          Nei nostri workshop chiediamo sempre di portare lampade portatili. Non per creare effetti scenici,
          ma per allenare la vista a riconoscere come l’acidità risponda alla luce. È un esercizio di etnografia
          visiva: osservare come il palato traduce un bagliore in vibrazione.
        </p>
        <Link to="/blog" className={styles.backLink}>
          ← Torna al blog
        </Link>
      </section>
    </div>
  );
}

export default BlogLuceCheAccendeLAcidita;