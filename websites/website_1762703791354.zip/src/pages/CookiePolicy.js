import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

function CookiePolicy() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie Policy | Archivio del Morso</title>
        <meta
          name="description"
          content="Informazioni sui cookie utilizzati dal sito Archivio del Morso e su come gestire le preferenze degli utenti."
        />
        <link rel="canonical" href="https://www.archivio-del-morso.it/cookie-policy" />
      </Helmet>

      <section className="container">
        <h1>Cookie Policy</h1>
        <p>
          Archivio del Morso utilizza cookie tecnici per garantire il funzionamento del sito e cookie analitici
          anonimizzati per monitorare le visite in forma aggregata.
        </p>
        <h2>Cookie tecnici</h2>
        <p>Essenziali per la navigazione, memorizzano le preferenze di sessione e la lingua.</p>
        <h2>Cookie analitici</h2>
        <p>
          Utilizziamo strumenti di analytics con IP anonimizzati per analizzare l’uso del sito e migliorare
          l’esperienza editoriale.
        </p>
        <h2>Gestione delle preferenze</h2>
        <p>
          Puoi modificare le impostazioni del browser per disattivare i cookie. Continuando la navigazione
          acconsenti all’uso dei cookie descritti.
        </p>
      </section>
    </div>
  );
}

export default CookiePolicy;