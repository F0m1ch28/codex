import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import JSONLD from './components/JSONLD';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Recipes from './pages/Recipes';
import Workshop from './pages/Workshop';
import Blog from './pages/Blog';
import BlogLuceCheAccendeLAcidita from './pages/BlogLuceCheAccendeLAcidita';
import BlogFormeDelMare from './pages/BlogFormeDelMare';
import BlogCartografiaCommestibile from './pages/BlogCartografiaCommestibile';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import styles from './App.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Archivio del Morso',
  url: 'https://www.archivio-del-morso.it',
  description:
    'Archivio del Morso è un osservatorio editoriale italiano dedicato alla cultura gastronomica, agli ingredienti stagionali e alla narrazione dei gesti culinari.',
  image: 'https://picsum.photos/seed/archivioDelMorso/1200/630',
  logo: 'https://www.archivio-del-morso.it/favicon.svg',
  address: {
    '@type': 'PostalAddress',
    streetAddress: 'Centro Commerciale Carosello, Via Giuseppe Verdi 1',
    addressLocality: 'Carugate',
    postalCode: '20061',
    addressRegion: 'MI',
    addressCountry: 'IT'
  },
  contactPoint: [
    {
      '@type': 'ContactPoint',
      telephone: '+39 02 5656 4020',
      contactType: 'customer support',
      areaServed: 'IT',
      availableLanguage: ['it']
    }
  ],
  sameAs: [
    'https://www.instagram.com/',
    'https://www.linkedin.com/',
    'https://www.pinterest.it/'
  ]
};

function App() {
  return (
    <div className={styles.app}>
      <Helmet>
        <html lang="it" />
        <meta
          name="keywords"
          content="saggio cultura alimentare, storytelling ingrediente stagionale, note concettuali culinarie, scrittura su chef e influenza, critica gastronomica italiana, editoriale cibo Italia, narrazione del piatto, osservazione gastronomica contemporanea, etnografia dell’ingrediente"
        />
      </Helmet>
      <JSONLD data={organizationJsonLd} />
      <Header />
      <ScrollToTop />
      <main className={styles.main}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/recipes" element={<Recipes />} />
          <Route path="/workshop" element={<Workshop />} />
          <Route path="/blog" element={<Blog />} />
          <Route
            path="/blog/luce-che-accende-l-acidita"
            element={<BlogLuceCheAccendeLAcidita />}
          />
          <Route
            path="/blog/forme-del-mare-grammatica-delle-salse"
            element={<BlogFormeDelMare />}
          />
          <Route
            path="/blog/cartografia-commestibile"
            element={<BlogCartografiaCommestibile />}
          />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
}

export default App;