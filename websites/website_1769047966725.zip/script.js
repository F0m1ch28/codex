document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const mobileNav = document.getElementById('mobileNavigation');
  if (navToggle && mobileNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      mobileNav.classList.toggle('open');
    });
  }

  const animateElements = document.querySelectorAll('[data-animate]');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.18, rootMargin: '0px 0px -40px 0px' });

  animateElements.forEach((el) => observer.observe(el));

  const cookieBanner = document.getElementById('cookieBanner');
  const cookieAccept = document.getElementById('cookieAccept');
  const cookieDecline = document.getElementById('cookieDecline');
  const cookieChoice = localStorage.getItem('crbt-cookie-choice');

  if (cookieBanner && !cookieChoice) {
    cookieBanner.classList.add('show');
  }

  const handleCookieChoice = (value) => {
    localStorage.setItem('crbt-cookie-choice', value);
    if (cookieBanner) {
      cookieBanner.classList.remove('show');
    }
  };

  if (cookieAccept) {
    cookieAccept.addEventListener('click', () => handleCookieChoice('accepted'));
  }

  if (cookieDecline) {
    cookieDecline.addEventListener('click', () => handleCookieChoice('declined'));
  }

  const toast = document.getElementById('globalToast');
  const showToast = (message = 'Submission received. Redirecting...') => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('visible');
    setTimeout(() => {
      toast.classList.remove('visible');
    }, 2600);
  };

  const forms = document.querySelectorAll('form[data-async="true"]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const message = form.getAttribute('data-success-message') || undefined;
      showToast(message);
      const targetUrl = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = targetUrl;
      }, 1200);
    });
  });

  const yearEl = document.getElementById('currentYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear().toString();
  }
});