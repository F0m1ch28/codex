document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.mobile-nav-toggle');
  const nav = document.querySelector('.site-nav');

  const closeNav = () => {
    if (nav) {
      nav.classList.remove('is-open');
    }
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
    }
    document.body.classList.remove('nav-active');
  };

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isExpanded = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(isExpanded));
      document.body.classList.toggle('nav-active', isExpanded);
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 900) {
        closeNav();
      }
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const cookieChoice = localStorage.getItem('cl-cookie-choice');
  if (cookieBanner) {
    if (!cookieChoice) {
      cookieBanner.classList.remove('is-hidden');
    }
    cookieBanner.addEventListener('click', (event) => {
      const target = event.target;
      if (target instanceof HTMLElement && target.dataset.cookieChoice) {
        const choice = target.dataset.cookieChoice;
        localStorage.setItem('cl-cookie-choice', choice);
        cookieBanner.classList.add('is-hidden');
      }
    });
  }

  const toast = document.getElementById('formToast');
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 2000);
  };

  const forms = document.querySelectorAll('form[data-enhanced="true"]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const submitButton = form.querySelector('button[type="submit"]');
      if (submitButton) {
        submitButton.disabled = true;
      }
      showToast('Message received. Redirecting...');
      setTimeout(() => {
        form.submit();
      }, 1400);
    });
  });

  const animatedElements = document.querySelectorAll('.animate-on-scroll');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    animatedElements.forEach((el) => observer.observe(el));
  } else {
    animatedElements.forEach((el) => el.classList.add('in-view'));
  }

  const yearSpans = document.querySelectorAll('.footer-year');
  const currentYear = new Date().getFullYear();
  yearSpans.forEach((span) => {
    span.textContent = String(currentYear);
  });
});