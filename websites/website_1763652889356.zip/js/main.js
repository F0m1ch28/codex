document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('primary-nav');
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookiesBtn = document.getElementById('accept-cookies');
  const yearSpans = document.querySelectorAll('#current-year');

  if (yearSpans.length) {
    const currentYear = new Date().getFullYear();
    yearSpans.forEach(span => {
      span.textContent = currentYear;
    });
  }

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      nav.classList.toggle('open');
    });

    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768 && nav.classList.contains('open')) {
          nav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        nav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  if (cookieBanner && acceptCookiesBtn) {
    const cookieConsentKey = 'aurora-cookie-consent';
    const hasConsent = localStorage.getItem(cookieConsentKey);

    if (!hasConsent) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('show');
      });
    }

    acceptCookiesBtn.addEventListener('click', () => {
      localStorage.setItem(cookieConsentKey, 'accepted');
      cookieBanner.classList.remove('show');
    });
  }
});