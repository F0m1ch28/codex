import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <h3>NovaEdge Consulting</h3>
          <p>
            Driving transformation for forward-thinking businesses through strategic insights and
            human-centered innovation.
          </p>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
              Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>

        <div className="footer-column">
          <h4>Company</h4>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/services">Services</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </div>

        <div className="footer-column">
          <h4>Resources</h4>
          <a href="/#blog" className="footer-link">
            Blog
          </a>
          <a href="/#faq" className="footer-link">
            FAQs
          </a>
          <a href="/#projects" className="footer-link">
            Case Studies
          </a>
        </div>

        <div className="footer-column">
          <h4>Legal</h4>
          <NavLink to="/terms">Terms of Service</NavLink>
          <NavLink to="/privacy">Privacy Policy</NavLink>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} NovaEdge Consulting. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;