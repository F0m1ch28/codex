import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`site-header ${isScrolled ? "site-header--scrolled" : ""}`}>
      <div className="container header-container">
        <NavLink to="/" className="logo" aria-label="NovaEdge Consulting Home">
          <span className="logo__mark">N</span>
          <span className="logo__text">NovaEdge Consulting</span>
        </NavLink>

        <nav className={`primary-nav ${isMobileMenuOpen ? "primary-nav--open" : ""}`}>
          <NavLink to="/" end className="primary-nav__link">
            Home
          </NavLink>
          <NavLink to="/about" className="primary-nav__link">
            About
          </NavLink>
          <NavLink to="/services" className="primary-nav__link">
            Services
          </NavLink>
          <NavLink to="/contact" className="primary-nav__link">
            Contact
          </NavLink>
        </nav>

        <button
          className={`hamburger ${isMobileMenuOpen ? "hamburger--active" : ""}`}
          onClick={() => setIsMobileMenuOpen((prev) => !prev)}
          aria-label="Toggle navigation"
          aria-expanded={isMobileMenuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;