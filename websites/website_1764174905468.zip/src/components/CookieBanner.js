import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("novaedgeCookieConsent");
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("novaedgeCookieConsent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          We use cookies to tailor experiences and analyze traffic. By continuing, you consent to
          our cookies. Read the{" "}
          <a href="/privacy" className="cookie-link">
            privacy policy
          </a>
          .
        </p>
        <button onClick={acceptCookies} className="btn btn--primary">
          Accept &amp; Continue
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;