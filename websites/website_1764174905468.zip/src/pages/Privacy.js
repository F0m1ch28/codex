import React from "react";

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Privacy</span>
          <h1>Privacy Policy</h1>
          <p>Effective March 1, 2024</p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container narrow">
          <h2>1. Information We Collect</h2>
          <p>
            We collect information you provide via contact forms, email, and events. This may include
            your name, company, email, and areas of interest. We may also collect anonymized usage
            data through analytics tools.
          </p>

          <h2>2. How We Use Information</h2>
          <p>
            Information is used to respond to inquiries, deliver services, improve our offerings, and
            send relevant updates. We never sell your personal data.
          </p>

          <h2>3. Cookies</h2>
          <p>
            Our website uses cookies to personalize content and analyze traffic. You can adjust
            cookie preferences through your browser settings.
          </p>

          <h2>4. Third-Party Sharing</h2>
          <p>
            We may share information with trusted partners who help us operate our services, provided
            they agree to maintain confidentiality and data security standards.
          </p>

          <h2>5. Data Retention</h2>
          <p>
            We retain data only as long as necessary to fulfill the purposes outlined in this policy
            or as required by law. You may request deletion or corrections at any time.
          </p>

          <h2>6. Security</h2>
          <p>
            We implement industry-standard security measures to protect your information. However, no
            system is completely secure, and we cannot guarantee absolute security.
          </p>

          <h2>7. Your Rights</h2>
          <p>
            Depending on your location, you may have rights to access, correct, delete, or restrict
            processing of your personal data. Contact us at{" "}
            <a href="mailto:privacy@novaedge.com">privacy@novaedge.com</a> to exercise these rights.
          </p>

          <h2>8. Updates</h2>
          <p>
            We may update this policy periodically. Changes will be posted on this page with a revised
            effective date.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;