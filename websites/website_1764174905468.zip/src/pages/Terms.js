import React from "react";

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Legal</span>
          <h1>Terms of Service</h1>
          <p>Effective March 1, 2024</p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container narrow">
          <h2>1. Overview</h2>
          <p>
            These Terms of Service govern your use of NovaEdge Consulting’s website and services. By
            engaging with NovaEdge, you acknowledge that you have read, understood, and agree to be
            bound by these terms.
          </p>

          <h2>2. Services</h2>
          <p>
            NovaEdge provides strategic consulting, innovation, and transformation services. Project
            scope, deliverables, timelines, and pricing will be outlined in a mutually executed
            statement of work.
          </p>

          <h2>3. Confidentiality</h2>
          <p>
            We maintain strict confidentiality of client information. Both parties agree not to
            disclose confidential information without written consent, except as required by law.
          </p>

          <h2>4. Intellectual Property</h2>
          <p>
            NovaEdge retains ownership of methodologies, frameworks, and tools developed prior to or
            independently from any engagement. Project deliverables outlined in the scope of work
            will be assigned as specified in the contract.
          </p>

          <h2>5. Limitation of Liability</h2>
          <p>
            To the maximum extent permitted by law, NovaEdge is not liable for indirect or
            consequential damages. Direct damages are limited to the fees paid for the services in
            question.
          </p>

          <h2>6. Governing Law</h2>
          <p>
            These Terms are governed by the laws of the State of New York, without regard to conflict
            of law provisions.
          </p>

          <h2>7. Contact</h2>
          <p>
            Questions regarding these Terms may be directed to{" "}
            <a href="mailto:legal@novaedge.com">legal@novaedge.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;