import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";

const statsData = [
  { label: "Projects Delivered", value: 128 },
  { label: "Growth Achieved", value: 212, suffix: "%" },
  { label: "Clients Worldwide", value: 64 },
  { label: "Awards & Honors", value: 24 },
];

const servicesData = [
  {
    title: "Strategic Advisory",
    description: "Data-backed strategy roadmaps aligning business potential with market realities.",
    icon: "🎯",
  },
  {
    title: "Digital Transformation",
    description:
      "Reimagine experiences and operations with human-centered technology adoption funnels.",
    icon: "⚙️",
  },
  {
    title: "Innovation Labs",
    description:
      "Rapid prototyping sprints and venture design to unlock sustainable business value.",
    icon: "🚀",
  },
  {
    title: "Change Enablement",
    description:
      "Empathetic change frameworks empowering teams to adopt new ways of working quickly.",
    icon: "🤝",
  },
];

const processSteps = [
  {
    title: "Discover",
    description:
      "Map the complete ecosystem, interview stakeholders, and identify hidden opportunities.",
  },
  {
    title: "Design",
    description:
      "Define the future blueprint using advanced modeling, experience mapping, and scenario planning.",
  },
  {
    title: "Deliver",
    description:
      "Execute iterative pilots, orchestrate teams, and embed a culture of rapid learning.",
  },
  {
    title: "Scale",
    description:
      "Measure impact, scale successful initiatives, and ensure long-term operational excellence.",
  },
];

const testimonials = [
  {
    quote:
      "NovaEdge redefined our digital transformation journey. Their team balanced pragmatism with visionary thinking, resulting in measurable growth.",
    name: "Elena Martinez",
    role: "Chief Strategy Officer, HorizonTech",
  },
  {
    quote:
      "From strategy to execution, they brought clarity, alignment, and momentum. Our organization now innovates with confidence.",
    name: "Malik Johnson",
    role: "CEO, Vertex Labs",
  },
  {
    quote:
      "The most impressive consultancy we've collaborated with. Insightful, empathetic, and relentlessly focused on outcomes.",
    name: "Priya Singh",
    role: "VP Operations, Aurora Enterprises",
  },
];

const teamMembers = [
  {
    name: "Avery Chen",
    role: "Managing Partner",
    image: "https://picsum.photos/400/400?random=31",
    bio: "Former Fortune 100 strategist with a passion for human-centered innovation.",
  },
  {
    name: "Jonah Reyes",
    role: "Director of Transformation",
    image: "https://picsum.photos/400/400?random=32",
    bio: "Specialist in large-scale transformation and change enablement programs.",
  },
  {
    name: "Lina O'Connor",
    role: "Head of Research",
    image: "https://picsum.photos/400/400?random=33",
    bio: "Brings ethnographic research and data analytics together for actionable insights.",
  },
];

const projectData = [
  {
    id: 1,
    title: "Immersive Customer Journey Platform",
    category: "Digital",
    image: "https://picsum.photos/1200/800?random=41",
  },
  {
    id: 2,
    title: "Operational Excellence Redesign",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=42",
  },
  {
    id: 3,
    title: "Future of Work Blueprint",
    category: "Culture",
    image: "https://picsum.photos/1200/800?random=43",
  },
  {
    id: 4,
    title: "Sustainable Supply Chain Roadmap",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=44",
  },
  {
    id: 5,
    title: "Phygital Retail Experience",
    category: "Digital",
    image: "https://picsum.photos/1200/800?random=45",
  },
];

const faqData = [
  {
    question: "What industries does NovaEdge specialize in?",
    answer:
      "We work across technology, finance, healthcare, retail, and energy sectors, partnering with cross-functional teams to drive strategic transformation.",
  },
  {
    question: "How long do your engagements typically last?",
    answer:
      "Engagements range from 6-week discovery sprints to multi-year transformation programs tailored to your organization’s needs.",
  },
  {
    question: "Do you offer implementation support?",
    answer:
      "Absolutely. We stay hands-on through implementation, change management, and scaling to ensure the strategy becomes reality.",
  },
  {
    question: "Can you work with remote and distributed teams?",
    answer:
      "Yes. We are structured for hybrid collaboration, embedding seamlessly with distributed teams across time zones.",
  },
];

const blogPosts = [
  {
    title: "Designing Organizations for Continuous Innovation",
    date: "April 12, 2024",
    image: "https://picsum.photos/800/600?random=21",
    excerpt:
      "Unlock a mindset of experimentation and agility by harmonizing strategy, operations, and culture.",
  },
  {
    title: "Human-Centered AI: Responsible Adoption Playbook",
    date: "March 22, 2024",
    image: "https://picsum.photos/800/600?random=22",
    excerpt:
      "A pragmatic approach to scaling AI initiatives without compromising trust, ethics, or transparency.",
  },
  {
    title: "Crafting Experiences Beyond the Screen",
    date: "February 28, 2024",
    image: "https://picsum.photos/800/600?random=23",
    excerpt:
      "How phygital ecosystems are reshaping customer relationships across industries.",
  },
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("All");
  const [faqOpenIndex, setFaqOpenIndex] = useState(0);
  const [stats, setStats] = useState(statsData.map(() => 0));
  const statsRef = useRef(null);
  const hasCounted = useRef(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!statsRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasCounted.current) {
            hasCounted.current = true;
            statsData.forEach((stat, index) => {
              let start = 0;
              const end = stat.value;
              const duration = 1600;
              const startTime = performance.now();

              const animate = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const eased = 1 - Math.pow(1 - progress, 3);

                const currentValue = Math.floor(eased * (end - start) + start);
                setStats((prev) => {
                  const updated = [...prev];
                  updated[index] = currentValue;
                  return updated;
                });

                if (progress < 1) {
                  requestAnimationFrame(animate);
                }
              };

              requestAnimationFrame(animate);
            });
          }
        });
      },
      { threshold: 0.4 }
    );

    observer.observe(statsRef.current);
    return () => observer.disconnect();
  }, []);

  const filteredProjects =
    projectFilter === "All"
      ? projectData
      : projectData.filter((project) => project.category === projectFilter);

  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="badge">Human-centered strategy</span>
            <h1>
              Catalyzing Transformations
              <span className="accent"> with Purpose & Precision</span>
            </h1>
            <p>
              We partner with leaders to craft adaptive strategies, activate talent, and build
              connected experiences that shape the next decade of business.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn btn--primary btn--pulse">
                Schedule a Consultation
              </Link>
              <Link to="/services" className="btn btn--ghost">
                Explore Services
              </Link>
            </div>
            <div className="hero-meta">
              <div>
                <strong>20+</strong>
                <span>Transformation accelerators</span>
              </div>
              <div>
                <strong>Global</strong>
                <span>Team working across 12 countries</span>
              </div>
            </div>
          </div>
          <div className="hero-media">
            <div className="hero-image-wrapper">
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Executive leaders collaborating in a strategy workshop"
                className="hero-image"
                loading="lazy"
              />
              <div className="hero-card">
                <span className="hero-card__label">Latest Achievement</span>
                <p>Accelerated a digital ecosystem relaunch, unlocking 3x customer retention.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <span className="stat-number">
                {stats[index]}
                {stat.suffix || ""}
              </span>
              <p>{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="services">
        <div className="container section-heading">
          <span className="section-eyebrow">Our Services</span>
            <h2>Flexible engagements, tuned to your strategic ambition</h2>
            <p>
              Assemble modular teams tailored to your transformation objectives. Each engagement is
              guided by evidence, empathy, and measurable impact.
            </p>
        </div>
        <div className="container services-grid">
          {servicesData.map((service) => (
            <div className="service-card" key={service.title}>
              <div className="service-icon">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-link">
                Learn more →
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="process">
        <div className="container process-grid">
          <div className="process-intro">
            <span className="section-eyebrow">Our Process</span>
            <h2>Co-creating future-ready organizations, step by step</h2>
            <p>
              We embed with your teams to navigate the complexities of change. From discovery to
              scaling, our collaborative approach creates momentum and sustained outcomes.
            </p>
            <Link to="/about" className="btn btn--secondary">
              Discover our approach
            </Link>
          </div>
          <div className="process-steps">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title}>
                <span className="process-step__number">0{index + 1}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container testimonial-wrapper">
          <div className="testimonial-display">
            <blockquote key={activeTestimonial}>
              “{testimonials[activeTestimonial].quote}”
            </blockquote>
            <div className="testimonial-meta">
              <p className="testimonial-name">{testimonials[activeTestimonial].name}</p>
              <span>{testimonials[activeTestimonial].role}</span>
            </div>
          </div>
          <div className="testimonial-controls">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                className={`testimonial-dot ${index === activeTestimonial ? "active" : ""}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="team" id="team">
        <div className="container section-heading">
          <span className="section-eyebrow">Leadership</span>
          <h2>Strategists, makers, and innovators committed to lasting impact</h2>
        </div>
        <div className="container team-grid">
          {teamMembers.map((member) => (
            <div className="team-card" key={member.name}>
              <div className="team-image">
                <img src={member.image} alt={`${member.name} - ${member.role}`} loading="lazy" />
              </div>
              <div className="team-info">
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container section-heading">
          <span className="section-eyebrow">Case Studies</span>
          <h2>Stories of transformation delivered with precision</h2>
          <div className="project-filters">
            {["All", "Strategy", "Digital", "Culture"].map((category) => (
              <button
                key={category}
                className={`filter-btn ${projectFilter === category ? "filter-btn--active" : ""}`}
                onClick={() => setProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className="container project-grid">
          {filteredProjects.map((project) => (
            <article className="project-card" key={project.id}>
              <div className="project-image">
                <img
                  src={project.image}
                  alt={`${project.title} case study visualization`}
                  loading="lazy"
                />
              </div>
              <div className="project-content">
                <span className="project-category">{project.category}</span>
                <h3>{project.title}</h3>
                <Link to="/services" className="project-link">
                  View strategic approach →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container faq-grid">
          <div className="faq-intro">
            <span className="section-eyebrow">FAQs</span>
            <h2>Answers to the questions we hear most</h2>
            <p>
              Can't find what you're looking for? Our team is ready to explore your goals and tailor
              a program that fits perfectly.
            </p>
            <Link to="/contact" className="btn btn--primary">
              Talk with an advisor
            </Link>
          </div>
          <div className="faq-accordions">
            {faqData.map((item, index) => {
              const isOpen = faqOpenIndex === index;
              return (
                <div
                  className={`faq-item ${isOpen ? "faq-item--open" : ""}`}
                  key={item.question}
                  onClick={() => setFaqOpenIndex(isOpen ? null : index)}
                >
                  <div className="faq-question">
                    <h3>{item.question}</h3>
                    <span>{isOpen ? "-" : "+"}</span>
                  </div>
                  {isOpen && <p className="faq-answer">{item.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="blog" id="blog">
        <div className="container section-heading">
          <span className="section-eyebrow">Insights</span>
          <h2>Latest thinking from our strategy labs</h2>
        </div>
        <div className="container blog-grid">
          {blogPosts.map((post) => (
            <article className="blog-card" key={post.title}>
              <div className="blog-image">
                <img src={post.image} alt={`${post.title} blog cover`} loading="lazy" />
              </div>
              <div className="blog-content">
                <span className="blog-date">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href="/#" className="blog-link">
                  Read article →
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="cta">
        <div className="container cta-inner">
          <div className="cta-content">
            <span className="section-eyebrow">Let’s co-create the future</span>
            <h2>Unlock the next level of performance with NovaEdge</h2>
            <p>
              We help leaders navigate uncertainty with clarity and conviction. Partner with us to
              design resilient strategies, empower teams, and accelerate outcomes.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn--primary btn--large">
              Book a discovery session
            </Link>
            <Link to="/about" className="btn btn--ghost btn--large">
              Meet the team
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;