import React, { useState } from "react";

const serviceCategories = [
  {
    title: "Strategic Discovery",
    summary:
      "Uncover bold opportunities through market intelligence, customer research, and opportunity mapping.",
    details: [
      "Immersive discovery sprints",
      "Competitive landscape analysis",
      "Customer journey and experience mapping",
      "Opportunity prioritization workshops",
    ],
  },
  {
    title: "Transformation Architecture",
    summary:
      "Design future state operating models and experience ecosystems anchored in measurable outcomes.",
    details: [
      "Operating model design",
      "Transformation roadmap creation",
      "Measurement frameworks",
      "Stakeholder alignment sessions",
    ],
  },
  {
    title: "Digital Innovation",
    summary:
      "Prototype, test, and launch digital products that deliver new value to customers and communities.",
    details: [
      "Rapid prototyping and experimentation",
      "Product strategy and portfolio planning",
      "Technology partner orchestration",
      "Pilot launch and iteration programs",
    ],
  },
  {
    title: "Change Enablement",
    summary:
      "Build capability and culture that accelerates adoption, engagement, and sustainable results.",
    details: [
      "Change readiness assessments",
      "Learning journeys and academies",
      "Culture and leadership activation",
      "Governance and communications design",
    ],
  },
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Services</span>
          <h1>Adaptive services designed to unlock enterprise momentum</h1>
          <p>
            Whether you're launching a new venture, reimagining operations, or scaling innovation,
            NovaEdge brings multidisciplinary teams to realize your vision faster.
          </p>
        </div>
      </section>

      <section className="service-tabs">
        <div className="container service-tab-grid">
          <div className="service-tab-list">
            {serviceCategories.map((category, index) => (
              <button
                key={category.title}
                className={`service-tab ${activeIndex === index ? "service-tab--active" : ""}`}
                onClick={() => setActiveIndex(index)}
              >
                <span>{category.title}</span>
              </button>
            ))}
          </div>
          <div className="service-tab-panel">
            <h2>{serviceCategories[activeIndex].title}</h2>
            <p>{serviceCategories[activeIndex].summary}</p>
            <ul>
              {serviceCategories[activeIndex].details.map((detail) => (
                <li key={detail}>{detail}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="service-highlight">
        <div className="container highlight-grid">
          <div className="highlight-image">
            <img
              src="https://picsum.photos/1200/800?random=71"
              alt="Facilitated strategy session with NovaEdge consultants"
              loading="lazy"
            />
          </div>
          <div className="highlight-content">
            <span className="section-eyebrow">Impact in action</span>
            <h2>Embedding innovation inside a global energy leader</h2>
            <p>
              Partnering with the executive team, we built a transformation office, launched
              innovation labs across three continents, and established pathways for rapid
              experimentation. The result: a 35% acceleration in program delivery and a culture of
              empowered intrapreneurs.
            </p>
            <div className="highlight-stats">
              <div>
                <strong>35%</strong>
                <span>Faster delivery velocity</span>
              </div>
              <div>
                <strong>5x</strong>
                <span>Increase in innovation pipeline</span>
              </div>
              <div>
                <strong>12</strong>
                <span>New ventures launched</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;