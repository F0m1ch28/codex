import React, { useState } from "react";

const initialState = {
  fullName: "",
  email: "",
  company: "",
  message: "",
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ submitting: false, submitted: false });

  const validate = () => {
    const newErrors = {};
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Please enter your full name.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Please provide a valid email.";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        newErrors.email = "Please enter a valid email address.";
      }
    }
    if (!formData.message.trim()) {
      newErrors.message = "Tell us about your goals.";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setStatus({ submitting: true, submitted: false });
    setTimeout(() => {
      setStatus({ submitting: false, submitted: true });
      setFormData(initialState);
    }, 1200);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">Contact</span>
          <h1>Let’s explore what’s possible together</h1>
          <p>
            Share your aspirations and challenges. We’ll assemble the right team to help you rapidly
            define and deliver transformational outcomes.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <div className="contact-info">
            <h2>Start the conversation</h2>
            <p>
              We collaborate with executive teams, founders, and intrapreneurs to activate strategy,
              culture, and technology. Expect a thoughtful response within two business days.
            </p>
            <div className="contact-details">
              <div>
                <strong>Email</strong>
                <a href="mailto:hello@novaedge.com">hello@novaedge.com</a>
              </div>
              <div>
                <strong>Offices</strong>
                <span>New York · Toronto · London · Singapore</span>
              </div>
              <div>
                <strong>Phone</strong>
                <a href="tel:+12345678900">+1 (234) 567-8900</a>
              </div>
            </div>
          </div>

          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="fullName">Full name *</label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                value={formData.fullName}
                onChange={handleChange}
                placeholder="Jordan Blake"
                aria-invalid={Boolean(errors.fullName)}
              />
              {errors.fullName && <span className="form-error">{errors.fullName}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="email">Email *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="jordan@example.com"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                placeholder="Company name"
              />
            </div>

            <div className="form-group">
              <label htmlFor="message">Project vision *</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                placeholder="Tell us about your goals, timelines, and success metrics."
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className="form-error">{errors.message}</span>}
            </div>

            <button type="submit" className="btn btn--primary btn--large" disabled={status.submitting}>
              {status.submitting ? "Sending..." : "Submit inquiry"}
            </button>
            {status.submitted && (
              <p className="form-success">Thanks! We’ll reach out shortly to coordinate next steps.</p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;