import React from "react";

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="section-eyebrow">About NovaEdge</span>
          <h1>Purpose-driven experts guiding organizations toward resilient futures</h1>
          <p>
            Our collective brings together strategists, designers, technologists, and change makers
            who believe in the power of human-centric ingenuity. We partner deeply with leaders to
            activate meaningful, measurable transformation.
          </p>
        </div>
      </section>

      <section className="about-story">
        <div className="container about-grid">
          <div className="about-highlight">
            <h2>Our story</h2>
            <p>
              NovaEdge was founded by former executives and innovation leaders who had seen
              first-hand the gaps between strategic ambition and operational reality. We created a
              consultancy that bridges those gaps with empathy, experimentation, and evidence.
            </p>
            <p>
              Our distributed team spans North America, Europe, and APAC. This global perspective
              equips us to navigate complexity and unlock value in diverse markets.
            </p>
          </div>
          <div className="about-image">
            <img
              src="https://picsum.photos/1200/800?random=51"
              alt="NovaEdge consultants collaborating with client teams"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="values">
        <div className="container section-heading">
          <span className="section-eyebrow">Our Values</span>
          <h2>Principles that guide every engagement</h2>
        </div>
        <div className="container values-grid">
          <div className="value-card">
            <h3>Empathy first</h3>
            <p>
              We start with people—understanding needs, motivations, and constraints to build
              strategies that resonate and stick.
            </p>
          </div>
          <div className="value-card">
            <h3>Evidence obsessed</h3>
            <p>
              We combine qualitative insights with quantitative rigor, ensuring decisions are rooted
              in truth—not assumptions.
            </p>
          </div>
          <div className="value-card">
            <h3>Bias for action</h3>
            <p>
              Progress beats perfection. We experiment thoughtfully, learn rapidly, and iterate with
              intention.
            </p>
          </div>
          <div className="value-card">
            <h3>Shared success</h3>
            <p>
              We operate as one team with our clients, aligning incentives and celebrating wins
              together.
            </p>
          </div>
        </div>
      </section>

      <section className="about-team">
        <div className="container section-heading">
          <span className="section-eyebrow">Leadership</span>
          <h2>The team behind NovaEdge</h2>
        </div>
        <div className="container team-grid">
          <div className="team-card">
            <div className="team-image">
              <img
                src="https://picsum.photos/400/400?random=61"
                alt="Sophia Ramirez - Founder & CEO"
                loading="lazy"
              />
            </div>
            <div className="team-info">
              <h3>Sophia Ramirez</h3>
              <span>Founder &amp; CEO</span>
              <p>
                Sophia guides enterprise leaders through transformation, blending systems thinking
                with a passion for inclusive innovation.
              </p>
            </div>
          </div>

          <div className="team-card">
            <div className="team-image">
              <img
                src="https://picsum.photos/400/400?random=62"
                alt="Marcus Allen - Chief Strategy Officer"
                loading="lazy"
              />
            </div>
            <div className="team-info">
              <h3>Marcus Allen</h3>
              <span>Chief Strategy Officer</span>
              <p>
                Marcus architected growth strategies for global brands and now leads NovaEdge’s
                strategic advisory practice.
              </p>
            </div>
          </div>

          <div className="team-card">
            <div className="team-image">
              <img
                src="https://picsum.photos/400/400?random=63"
                alt="Dr. Hana Suleiman - Head of Insights"
                loading="lazy"
              />
            </div>
            <div className="team-info">
              <h3>Dr. Hana Suleiman</h3>
              <span>Head of Insights</span>
              <p>
                Hana blends behavioral science and analytics to surface actionable insights that
                empower confident decision-making.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;