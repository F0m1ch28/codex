document.addEventListener('DOMContentLoaded', () => {
  const storageKey = 'veridianEcoCookies';
  const root = document.documentElement;

  const navToggle = document.querySelector('[data-js="nav-toggle"]');
  const siteNav = document.querySelector('[data-js="site-nav"]');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
  }

  const banner = document.querySelector('[data-js="cookies-banner"]');
  if (!banner) {
    return;
  }

  const acceptButton = banner.querySelector('[data-js="accept-cookies"]');
  const rejectButton = banner.querySelector('[data-js="reject-cookies"]');
  const customizeButton = banner.querySelector('[data-js="customize-cookies"]');
  const preferencesPanel = banner.querySelector('[data-js="cookies-preferences"]');
  const closePreferencesButton = banner.querySelector('[data-js="close-preferences"]');
  const form = banner.querySelector('[data-js="cookies-form"]');

  const applyConsent = (preferences) => {
    const analytics = Boolean(preferences.analytics);
    const marketing = Boolean(preferences.marketing);
    root.dataset.cookieAnalytics = analytics ? 'granted' : 'denied';
    root.dataset.cookieMarketing = marketing ? 'granted' : 'denied';
  };

  const persistConsent = (preferences) => {
    const payload = {
      necessary: true,
      analytics: Boolean(preferences.analytics),
      marketing: Boolean(preferences.marketing),
      timestamp: new Date().toISOString()
    };
    localStorage.setItem(storageKey, JSON.stringify(payload));
    applyConsent(payload);
    banner.classList.remove('is-visible');
    if (preferencesPanel) {
      preferencesPanel.classList.remove('is-expanded');
      preferencesPanel.setAttribute('aria-hidden', 'true');
    }
  };

  const stored = localStorage.getItem(storageKey);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      applyConsent(parsed);
    } catch (error) {
      localStorage.removeItem(storageKey);
      banner.classList.add('is-visible');
    }
  } else {
    banner.classList.add('is-visible');
  }

  if (acceptButton) {
    acceptButton.addEventListener('click', () => {
      persistConsent({ analytics: true, marketing: true });
    });
  }

  if (rejectButton) {
    rejectButton.addEventListener('click', () => {
      persistConsent({ analytics: false, marketing: false });
    });
  }

  if (customizeButton && preferencesPanel) {
    customizeButton.addEventListener('click', () => {
      preferencesPanel.classList.add('is-expanded');
      preferencesPanel.setAttribute('aria-hidden', 'false');
    });
  }

  if (closePreferencesButton && preferencesPanel) {
    closePreferencesButton.addEventListener('click', () => {
      preferencesPanel.classList.remove('is-expanded');
      preferencesPanel.setAttribute('aria-hidden', 'true');
    });
  }

  if (form) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const analytics = form.querySelector('#cookies-analytics')?.checked ?? false;
      const marketing = form.querySelector('#cookies-marketing')?.checked ?? false;
      persistConsent({ analytics, marketing });
    });
  }
});