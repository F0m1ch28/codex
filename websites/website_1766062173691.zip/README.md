VERIDIAN ECOTECH PLATFORM

OVERVIEW
This project contains the marketing and knowledge website for Veridian EcoTech, showcasing regenerative infrastructure solutions, validated case studies, and compliance resources.

STRUCTURE
- styles.css: Global design system, layout utilities, and cookies banner styling.
- index.html and supporting pages: Overview, Solutions, Case Studies, Insights, Engage, Policy, Terms, FAQ.
- script.js: Navigation toggle and consent management.
- sitemap.xml, robots.txt, site.webmanifest, favicon placeholder, README, .gitignore.

IMAGES
All imagery references hosted assets from Pexels with responsive srcset (400w, 800w, 1200w, 1600w) ensuring adaptive delivery.

COOKIES
Every page ships with a consent banner supporting accept, reject, and custom preferences stored in localStorage.

DEVELOPMENT NOTES
Serve files with a static web server to preserve relative links. Replace favicon.ico with generated artwork and extend script.js if analytics integrations are required.