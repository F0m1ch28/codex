document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const stored = localStorage.getItem('cil-cookie-consent');
  if (stored) {
    banner.classList.add('is-hidden');
  } else {
    requestAnimationFrame(() => banner.classList.add('is-visible'));
  }

  const acceptBtn = banner.querySelector('[data-action="accept"]');
  const declineBtn = banner.querySelector('[data-action="decline"]');

  const closeBanner = (choice) => {
    localStorage.setItem('cil-cookie-consent', choice);
    banner.classList.remove('is-visible');
    banner.classList.add('is-hidden');
  };

  acceptBtn?.addEventListener('click', () => closeBanner('accepted'));
  declineBtn?.addEventListener('click', () => closeBanner('declined'));
});