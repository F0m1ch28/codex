document.addEventListener("DOMContentLoaded", function () {
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-banner .cookie-action");
    const consentKey = "bmoCookieConsent";

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
        }

        cookieButtons.forEach((button) => {
            button.addEventListener("click", () => {
                const choice = button.dataset.choice || "undecided";
                localStorage.setItem(consentKey, choice);
            });
        });
    }

    const searchInput = document.querySelector(".search-input");
    const filterButtons = document.querySelectorAll(".filter-button");
    const postCards = document.querySelectorAll(".posts-list .card");

    if (searchInput && postCards.length > 0) {
        const filterPosts = () => {
            const query = searchInput.value.toLowerCase().trim();
            const activeButton = document.querySelector(".filter-button.active");
            const activeCategory = activeButton ? activeButton.dataset.category : "all";

            postCards.forEach((card) => {
                const title = card.querySelector("h3").textContent.toLowerCase();
                const excerpt = card.querySelector("p").textContent.toLowerCase();
                const category = card.dataset.category;

                const matchesQuery = !query || title.includes(query) || excerpt.includes(query);
                const matchesCategory = activeCategory === "all" || category === activeCategory;

                if (matchesQuery && matchesCategory) {
                    card.removeAttribute("hidden");
                } else {
                    card.setAttribute("hidden", "hidden");
                }
            });
        };

        searchInput.addEventListener("input", filterPosts);

        filterButtons.forEach((button) => {
            button.addEventListener("click", () => {
                filterButtons.forEach((btn) => btn.classList.remove("active"));
                button.classList.add("active");
                filterPosts();
            });
        });
    }
});