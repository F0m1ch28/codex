import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  const navigate = useNavigate();
  const [exchange, setExchange] = useState({
    loading: true,
    rate: null,
    updatedAt: null,
    error: null,
  });
  const [counters, setCounters] = useState([0, 0, 0, 0]);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('All');
  const [openFaq, setOpenFaq] = useState(null);
  const [showDisclaimer, setShowDisclaimer] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
  });
  const [consent, setConsent] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  const statsTarget = useMemo(
    () => [
      { label: 'Households using our dashboards', target: 1280 },
      { label: 'Trusted data sources monitored monthly', target: 87 },
      { label: 'Lesson minutes across our curriculum', target: 640 },
      { label: 'Learners who built an emergency plan', target: 98 },
    ],
    []
  );

  useEffect(() => {
    let isMounted = true;
    const fetchRate = async () => {
      try {
        const response = await fetch(
          'https://api.exchangerate.host/latest?base=ARS&symbols=USD'
        );
        if (!response.ok) {
          throw new Error('Network error');
        }
        const data = await response.json();
        const rate = data?.rates?.USD
          ? Number(data.rates.USD).toFixed(6)
          : null;
        if (isMounted) {
          setExchange({
            loading: false,
            rate,
            updatedAt: data?.date ?? new Date().toISOString().split('T')[0],
            error: null,
          });
        }
      } catch (error) {
        if (isMounted) {
          setExchange({
            loading: false,
            rate: null,
            updatedAt: null,
            error: 'Unable to load live rate. Using last known snapshot.',
          });
        }
      }
    };

    fetchRate();
    const interval = setInterval(fetchRate, 60000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    const increments = statsTarget.map((item) => Math.ceil(item.target / 60));
    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, index) => {
          const next = value + increments[index];
          return next >= statsTarget[index].target
            ? statsTarget[index].target
            : next;
        })
      );
    }, 30);

    return () => clearInterval(interval);
  }, [statsTarget]);

  useEffect(() => {
    const rotation = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(rotation);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => setShowDisclaimer(true), 1800);
    return () => clearTimeout(timer);
  }, []);

  const testimonials = [
    {
      quote:
        'The inflation trackers let our family build realistic USD projections. We cut overspending by 14% in three months.',
      name: 'Lucía Martínez',
      title: 'Arquitecta & Learner',
    },
    {
      quote:
        'I finally understand ARS-to-USD dynamics. The weekly lessons in Spanish and English give me clarity without jargon.',
      name: 'Federico Rivas',
      title: 'Product Manager',
    },
    {
      quote:
        'Tu Progreso Hoy combines hard data with excellent storytelling. It keeps me accountable for my budgeting goals.',
      name: 'María José Vivas',
      title: 'Communications Specialist',
    },
  ];

  const projectFilters = ['All', 'Inflation Models', 'Scenario Planning', 'Course Assets'];

  const projectItems = [
    {
      id: 1,
      category: 'Inflation Models',
      title: 'Monthly CPI dashboard with scenario toggles',
      description:
        'Track IPC Nacional, food staples, and tradable vs non-tradable splits. Spanish annotations included.',
      image: 'https://picsum.photos/1200/800?random=4',
    },
    {
      id: 2,
      category: 'Scenario Planning',
      title: 'Dual currency household budgeting playbook',
      description:
        'Project ARS and USD cash flows with inflation overlays and blue market sensitivity.',
      image: 'https://picsum.photos/1200/800?random=5',
    },
    {
      id: 3,
      category: 'Course Assets',
      title: 'Personal finance microlearning series',
      description:
        '40+ bite-sized lessons covering essentials: buffer funds, debt strategy, digital tools.',
      image: 'https://picsum.photos/1200/800?random=6',
    },
    {
      id: 4,
      category: 'Scenario Planning',
      title: 'Emergency planning checklist in English & Español',
      description:
        'Step-by-step workbook combining local context with global best practice.',
      image: 'https://picsum.photos/1200/800?random=7',
    },
  ];

  const faqItems = [
    {
      id: 1,
      question: 'How often do you update your ARS → USD data?',
      answer:
        'We refresh official exchange data every 60 minutes and highlight variance between official, MEP, and blue rates within our subscriber dashboards.',
    },
    {
      id: 2,
      question: 'Is the course suitable for beginners?',
      answer:
        'Yes. Lessons start with foundational personal finance concepts in plain English with Spanish support and include quick practice tasks.',
    },
    {
      id: 3,
      question: 'Do you provide investment advice or financial services?',
      answer:
        'No. We provide educational materials and data visuals only. You remain responsible for personal financial decisions.',
    },
    {
      id: 4,
      question: 'Can I invite other family members to join the platform?',
      answer:
        'Absolutely. Partner seats are included in Premium plans so each household member can track expenses and review lessons together.',
    },
  ];

  const blogPosts = [
    {
      id: 1,
      title: 'Inflation checkpoints before closing each month',
      excerpt:
        'Build a review ritual in 20 minutes: monitor IPC Nacional vs. your household basket, revisit USD exposure, and confirm upcoming cash needs.',
      date: 'April 2024',
      lang: 'English',
    },
    {
      id: 2,
      title: 'Traducción rápida: Cómo priorizar objetivos financieros en 2024',
      excerpt:
        'Define tus objetivos con parámetros claros, ajusta escenarios de inflación y asigna buffers realistas para tu familia.',
      date: 'Abril 2024',
      lang: 'Español',
    },
    {
      id: 3,
      title: 'What we learned from 500 Argentine learners',
      excerpt:
        'Key behaviors that help learners stay on track with budgets, emergency funds, and USD conversions despite volatility.',
      date: 'March 2024',
      lang: 'English',
    },
  ];

  const processSteps = [
    {
      title: 'Assess & calibrate',
      text: 'Upload or recreate your current budget, highlight USD commitments, and map inflation-sensitive categories.',
    },
    {
      title: 'Learn live & async',
      text: 'Attend live cohort sessions or self-paced lessons; cada video incluye subtítulos en español.',
    },
    {
      title: 'Model scenarios',
      text: 'Compare official vs. parallel FX scenarios, simulate 30-90 day inflation adjustments, and prioritize buffers.',
    },
    {
      title: 'Track progress',
      text: 'Receive bi-weekly nudges, report progress to your household, and celebrate milestones together.',
    },
  ];

  const servicesCards = [
    {
      title: 'Inflation Observatory',
      subtitle: 'Observatorio de inflación',
      description:
        'Live CPI monitors, volatility alerts, and curated insights contextualized for Argentina-based households.',
      icon: '📊',
    },
    {
      title: 'Dual Currency Planner',
      subtitle: 'Planificador bimoneda',
      description:
        'Blend ARS and USD planning in one workspace with automated conversion layers and scenario toggles.',
      icon: '💱',
    },
    {
      title: 'Financial Literacy Course',
      subtitle: 'Curso de finanzas personales',
      description:
        'Nine-module curriculum covering budgeting, emergency funds, debt prioritization, and long-term habits.',
      icon: '🎓',
    },
    {
      title: 'Community Coaching',
      subtitle: 'Acompañamiento comunitario',
      description:
        'Group sessions, Q&A office hours, and accountability circles with bilingual facilitators.',
      icon: '🤝',
    },
  ];

  const teamMembers = [
    {
      name: 'Valeria Giménez',
      role: 'Founder & Lead Economist',
      bio: 'Former BCRA analyst focused on CPI modeling and consumer behavior. Leads data accuracy initiatives.',
      image: 'https://picsum.photos/400/400?random=3',
    },
    {
      name: 'Matías Álvarez',
      role: 'Learning Experience Director',
      bio: 'EdTech specialist crafting bilingual curricula for adult learners throughout LATAM.',
      image: 'https://picsum.photos/400/400?random=8',
    },
    {
      name: 'Sofía Ramírez',
      role: 'Data Product Manager',
      bio: 'Translates macro data into intuitive dashboards. Oversees product roadmap and user research.',
      image: 'https://picsum.photos/400/400?random=9',
    },
  ];

  const insights = [
    {
      title: 'Inflation sensitivity index',
      description:
        'Weighted index comparing IPC Nacional with the household staples basket, updated weekly.',
      image: 'https://picsum.photos/800/600?random=2',
    },
    {
      title: 'ARS liquidity heatmap',
      description:
        'View cash flow peaks and troughs per category to anticipate exposure to FX shocks.',
      image: 'https://picsum.photos/800/600?random=10',
    },
    {
      title: 'Savings resilience tracker',
      description:
        'Assess how long your buffer lasts under moderate or high inflation scenarios.',
      image: 'https://picsum.photos/800/600?random=11',
    },
  ];

  const closeDisclaimer = () => setShowDisclaimer(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = {};

    if (!formData.fullName.trim()) {
      errors.fullName = 'Full name is required.';
    }
    if (!formData.email.trim()) {
      errors.email = 'Email is required.';
    } else if (
      !/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email.trim())
    ) {
      errors.email = 'Enter a valid email address.';
    }
    if (!formData.phone.trim()) {
      errors.phone = 'Phone number helps us tailor follow-up.';
    }
    if (!consent) {
      errors.consent =
        'Please confirm double opt-in so we can email you the confirmation link.';
    }

    setFormErrors(errors);

    if (Object.keys(errors).length === 0) {
      navigate('/thank-you', {
        state: { email: formData.email, from: 'free-lesson' },
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>
          Tu Progreso Hoy | Inflation Data & Financial Course for Argentina
        </title>
        <meta
          name="description"
          content="Track ARS to USD in real time, understand Argentina inflation trends, and learn foundational personal finance skills with Tu Progreso Hoy."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={styles.heroOverlay} aria-hidden="true" />
        <div className={styles.heroContent}>
          <h1 id="hero-title">
            Data clarity for Argentina&apos;s next financial decisions.
          </h1>
          <p>
            Align ARS → USD insights with bilingual personal finance lessons.
            Build resilient plans para tu familia hoy y mañana.
          </p>
          <div className={styles.heroActions}>
            <button
              type="button"
              className="btn-primary"
              onClick={() => navigate('/course')}
            >
              Explore the curriculum
            </button>
            <a className="btn-secondary" href="#free-lesson-form">
              Start with a free lesson
            </a>
          </div>
          <div className={styles.heroMeta}>
            <span>Datos verificados para planificar tu presupuesto.</span>
            <span>Decisiones responsables, objetivos nítidos.</span>
            <span>Conocimiento financiero impulsado por tendencias.</span>
            <span>Pasos acertados hoy, mejor futuro mañana.</span>
          </div>
        </div>
      </section>

      <section className={styles.tracker} aria-labelledby="tracker-title">
        <div className={styles.sectionHeader}>
          <h2 id="tracker-title">
            ARS → USD real-time tracker / Seguimiento en tiempo real
          </h2>
          <p>
            Monitor the official reference every minute and compare with
            high-frequency estimates inside the platform.
          </p>
        </div>
        <div className={styles.trackerCard}>
          <div>
            <p className={styles.trackerLabel}>1 Argentine Peso equals</p>
            <p className={styles.rate}>
              {exchange.loading && 'Loading…'}
              {!exchange.loading && exchange.rate && `${exchange.rate} USD`}
              {!exchange.loading && !exchange.rate && '0.0012 USD'}
            </p>
            <p className={styles.update}>
              Updated:{' '}
              {exchange.updatedAt
                ? exchange.updatedAt
                : 'Latest snapshot — see dashboard for details'}
            </p>
            {exchange.error && (
              <p className={styles.error} role="status">
                {exchange.error}
              </p>
            )}
          </div>
          <div className={styles.trackerAside}>
            <p>
              Compare with Mercado Blue, MEP, and 30-day moving averages in
              context. Visual cues highlight deviations above 3%.
            </p>
            <button
              type="button"
              className="btn-link"
              onClick={() => navigate('/inflation')}
            >
              View methodology
            </button>
          </div>
        </div>
      </section>

      <section className={styles.insights} aria-labelledby="insights-title">
        <div className={styles.sectionHeader}>
          <h2 id="insights-title">Live insights & analytics suite</h2>
          <p>Visualizations designed for household decisions and fast check-ins.</p>
        </div>
        <div className={styles.insightGrid}>
          {insights.map((insight) => (
            <article className={styles.insightCard} key={insight.title}>
              <div className={styles.imageWrap}>
                <img
                  src={insight.image}
                  alt={`${insight.title} visual`}
                  loading="lazy"
                />
              </div>
              <h3>{insight.title}</h3>
              <p>{insight.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.course} aria-labelledby="course-title">
        <div className={styles.sectionHeader}>
          <h2 id="course-title">Course snapshot / Curso en resumen</h2>
          <p>
            Build fundamental habits with bilingual assets, practice labs, and
            contextual data from Argentina.
          </p>
        </div>
        <div className={styles.courseGrid}>
          <article>
            <h3>Modules / Módulos</h3>
            <ul>
              <li>01. Inflation & currency basics</li>
              <li>02. Household budgeting frameworks</li>
              <li>03. Buffer funds & emergency planning</li>
              <li>04. Debt priorities & negotiation</li>
              <li>05. Scenario planning with ARS & USD</li>
              <li>06. Income diversification ideas</li>
              <li>07. Long-term planning habits</li>
              <li>08. Accountability & tracking</li>
              <li>09. Future trends & resilience</li>
            </ul>
          </article>
          <article>
            <h3>What you get</h3>
            <ul>
              <li>Weekly live cohort sessions (EN + ES)</li>
              <li>Interactive dashboards & templates</li>
              <li>Community office hours each Friday</li>
              <li>Certification after capstone submission</li>
            </ul>
            <button
              type="button"
              className="btn-primary"
              onClick={() => navigate('/course')}
            >
              Download syllabus (PDF)
            </button>
          </article>
          <article>
            <h3>Who benefits / Para quién</h3>
            <p>
              Argentine families managing ARS volatility, professionals planning
              USD expenses, freelancers building savings buffers, and students
              seeking foundational finance knowledge.
            </p>
            <a className="btn-secondary" href="#free-lesson-form">
              Reserve a free trial lesson
            </a>
          </article>
        </div>
      </section>

      <section className={styles.stats} aria-label="Impact metrics">
        {statsTarget.map((item, index) => (
          <div className={styles.statCard} key={item.label}>
            <span className={styles.statNumber}>{counters[index]}+</span>
            <p>{item.label}</p>
          </div>
        ))}
      </section>

      <section className={styles.services} aria-labelledby="services-title">
        <div className={styles.sectionHeader}>
          <h2 id="services-title">Solutions built for volatility</h2>
          <p>
            Minimalist dashboards, bilingual lessons, and collaborative
            workflows to keep your household calm and informed.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          {servicesCards.map((card) => (
            <article key={card.title} className={styles.serviceCard}>
              <div className={styles.icon}>{card.icon}</div>
              <h3>{card.title}</h3>
              <span className={styles.subtitle}>{card.subtitle}</span>
              <p>{card.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <div className={styles.sectionHeader}>
          <h2 id="process-title">Our process / Nuestro proceso</h2>
          <p>
            From first assessment to progress tracking, we stay focused on
            practical actions.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <article key={step.title} className={styles.processCard}>
              <span className={styles.processNumber}>
                {String(index + 1).padStart(2, '0')}
              </span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section
        className={styles.testimonials}
        aria-labelledby="testimonials-title"
      >
        <div className={styles.sectionHeader}>
          <h2 id="testimonials-title">Testimonials / Testimonios</h2>
          <p>Community voices from Buenos Aires, Córdoba, Rosario y más.</p>
        </div>
        <div className={styles.testimonialCard}>
          <blockquote>{testimonials[currentTestimonial].quote}</blockquote>
          <p className={styles.testimonialName}>
            {testimonials[currentTestimonial].name}
          </p>
          <span>{testimonials[currentTestimonial].title}</span>
          <div className={styles.testimonialDots} role="tablist">
            {testimonials.map((_, index) => (
              <button
                key={`dot-${index}`}
                type="button"
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Testimonial ${index + 1}`}
                className={
                  currentTestimonial === index
                    ? styles.dotActive
                    : styles.dotInactive
                }
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-title">
        <div className={styles.sectionHeader}>
          <h2 id="team-title">Meet the team / Conocé al equipo</h2>
          <p>
            Economists, learning designers, and data storytellers from across
            Argentina.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img
                src={member.image}
                alt={`${member.name}, ${member.role}`}
                loading="lazy"
              />
              <div className={styles.teamBody}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-title">
        <div className={styles.sectionHeader}>
          <h2 id="projects-title">Platform projects & labs</h2>
          <p>
            Explore the assets that keep our learners accountable and informed.
          </p>
        </div>
        <div className={styles.filterBar} role="tablist">
          {projectFilters.map((filter) => (
            <button
              key={filter}
              type="button"
              onClick={() => setProjectFilter(filter)}
              className={`${styles.filterButton} ${
                projectFilter === filter ? styles.filterActive : ''
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {projectItems
            .filter(
              (item) =>
                projectFilter === 'All' || item.category === projectFilter
            )
            .map((item) => (
              <article key={item.id} className={styles.projectCard}>
                <img
                  src={item.image}
                  alt={`${item.title} visual`}
                  loading="lazy"
                />
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <span className={styles.projectTag}>{item.category}</span>
                </div>
              </article>
            ))}
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-title">
        <div className={styles.sectionHeader}>
          <h2 id="faq-title">Frequently asked questions / Preguntas frecuentes</h2>
          <p>Quick answers en ambos idiomas para tu próxima decisión.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item) => (
            <div className={styles.faqItem} key={item.id}>
              <button
                type="button"
                aria-expanded={openFaq === item.id}
                onClick={() =>
                  setOpenFaq((prev) => (prev === item.id ? null : item.id))
                }
              >
                {item.question}
                <span>{openFaq === item.id ? '−' : '+'}</span>
              </button>
              {openFaq === item.id && <p>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-title">
        <div className={styles.sectionHeader}>
          <h2 id="blog-title">Latest insights & updates</h2>
          <p>
            Short reads and bilingual explainers for inflation trends y hábitos
            financieros.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <p className={styles.blogMeta}>
                {post.date} · {post.lang}
              </p>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <button
                type="button"
                className="btn-link"
                onClick={() => navigate('/resources')}
              >
                Read more
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-title">
        <div className={styles.ctaContent}>
          <h2 id="cta-title">Small steps today, futuro ordenado mañana.</h2>
          <p>
            Join learners across Argentina building confidence with guided data,
            bilingual lessons, and real accountability.
          </p>
          <div className={styles.ctaActions}>
            <button
              type="button"
              className="btn-primary"
              onClick={() => navigate('/contact')}
            >
              Talk with our team
            </button>
            <a className="btn-secondary" href="#free-lesson-form">
              Free trial class
            </a>
          </div>
        </div>
      </section>

      <section
        className={styles.formSection}
        id="free-lesson-form"
        aria-labelledby="form-title"
      >
        <div className={styles.sectionHeader}>
          <h2 id="form-title">Get your free trial lesson / Clase de prueba</h2>
          <p>
            Complete the double opt-in form and check your inbox (and spam)
            within 5 minutes to confirm participation.
          </p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="fullName">
            Full name / Nombre completo
            <input
              id="fullName"
              name="fullName"
              type="text"
              value={formData.fullName}
              onChange={(event) =>
                setFormData((prev) => ({
                  ...prev,
                  fullName: event.target.value,
                }))
              }
              aria-invalid={!!formErrors.fullName}
            />
            {formErrors.fullName && (
              <span className={styles.errorMessage}>{formErrors.fullName}</span>
            )}
          </label>
          <label htmlFor="email">
            Email
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={(event) =>
                setFormData((prev) => ({
                  ...prev,
                  email: event.target.value,
                }))
              }
              aria-invalid={!!formErrors.email}
            />
            {formErrors.email && (
              <span className={styles.errorMessage}>{formErrors.email}</span>
            )}
          </label>
          <label htmlFor="phone">
            Phone / Teléfono (WhatsApp recomendado)
            <input
              id="phone"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={(event) =>
                setFormData((prev) => ({
                  ...prev,
                  phone: event.target.value,
                }))
              }
              aria-invalid={!!formErrors.phone}
            />
            {formErrors.phone && (
              <span className={styles.errorMessage}>{formErrors.phone}</span>
            )}
          </label>
          <label className={styles.checkbox}>
            <input
              type="checkbox"
              checked={consent}
              onChange={(event) => setConsent(event.target.checked)}
            />
            <span>
              I agree to receive the confirmation email and understand it
              requires a second opt-in. / Confirmo doble opt-in por email.
            </span>
          </label>
          {formErrors.consent && (
            <span className={styles.errorMessage}>{formErrors.consent}</span>
          )}
          <button type="submit" className="btn-primary">
            Submit & send confirmation
          </button>
        </form>
        <p className={styles.formNote}>
          Note: This is an educational service. We do not provide financial
          services nor individualized investment advice. No brindamos servicios
          financieros ni asesoramiento personalizado.
        </p>
      </section>

      {showDisclaimer && (
        <div className={styles.modalBackdrop} role="dialog" aria-modal="true">
          <div className={styles.modal}>
            <h3>Important notice</h3>
            <p>We do not provide financial services. No brindamos servicios financieros.</p>
            <button
              type="button"
              className="btn-secondary"
              onClick={closeDisclaimer}
            >
              Understood
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default Home;