import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ThankYou.module.css';

const ThankYou = () => (
  <>
    <Helmet>
      <title>Thank You | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="Thank you for requesting a free lesson with Tu Progreso Hoy. Please confirm your email to finalize double opt-in."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.card}>
        <h1>Thank you! / ¡Gracias!</h1>
        <p>
          We sent a confirmation email. Please confirm within 24 hours to access
          your free lesson. Revisá tu bandeja de entrada y spam.
        </p>
        <a href="/" className="btn-secondary">
          Return home
        </a>
      </div>
    </section>
  </>
);

export default ThankYou;