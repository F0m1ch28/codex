import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="Terms of use governing Tu Progreso Hoy educational services and platform access."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Terms of Use</h1>
      <p>Effective date: 1 April 2024</p>
    </section>
    <section className={styles.body}>
      <h2>1. Acceptance</h2>
      <p>
        By accessing Tu Progreso Hoy, you agree to these Terms of Use. If you do
        not agree, please discontinue use.
      </p>
      <h2>2. Educational purpose</h2>
      <p>
        Tu Progreso Hoy provides educational content only. We do not provide
        financial services, investment advice, or guarantees.
      </p>
      <h2>3. Accounts</h2>
      <p>
        Users are responsible for maintaining the confidentiality of their
        accounts and ensuring double opt-in confirmation.
      </p>
      <h2>4. Intellectual property</h2>
      <p>
        All content, including dashboards and course materials, is owned by Tu
        Progreso Hoy. Do not redistribute without permission.
      </p>
      <h2>5. Limitation of liability</h2>
      <p>
        We strive for accuracy but cannot guarantee outcomes. Users remain
        responsible for decisions based on our educational materials.
      </p>
      <h2>6. Termination</h2>
      <p>
        We may suspend accounts if terms are violated or if payment is overdue.
      </p>
      <h2>7. Governing law</h2>
      <p>
        These terms are governed by the laws of Argentina. Disputes will be
        resolved in Buenos Aires courts.
      </p>
      <h2>8. Contact</h2>
      <p>Email: info@tuprogresohoy.com</p>
    </section>
  </>
);

export default Terms;