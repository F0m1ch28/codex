import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Resources.module.css';

const Resources = () => {
  const resources = [
    {
      title: 'Household Budget Template (English)',
      lang: 'EN',
      description:
        'Spreadsheet with ARS & USD tracking, buffer recommendations, and visual alerts for variances.',
    },
    {
      title: 'Guía rápida: Inflación y ahorros en Argentina',
      lang: 'ES',
      description:
        'Una hoja de ruta para ajustar tus gastos esenciales y proteger tu fondo de emergencia.',
    },
    {
      title: 'Glossary: Argentina FX terms explained',
      lang: 'EN',
      description:
        'Understand official, MEP, CCL, and blue market definitions with examples.',
    },
    {
      title: 'Checklist mensual de hábitos financieros',
      lang: 'ES',
      description:
        'Acciones concretas cada mes para revisar presupuesto, deuda, e ingresos variables.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Resources | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Access bilingual articles, templates, and glossaries related to Argentina inflation, ARS-USD trends, and personal finance habits."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.content}>
          <h1>Resource library / Biblioteca de recursos</h1>
          <p>
            Articles, checklists, and glossaries. English and Spanish support for
            every learning style.
          </p>
        </div>
      </section>

      <section className={styles.list}>
        <div className={styles.grid}>
          {resources.map((item) => (
            <article key={item.title}>
              <span>{item.lang}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <button type="button" className="btn-link">
                Download
              </button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Resources;