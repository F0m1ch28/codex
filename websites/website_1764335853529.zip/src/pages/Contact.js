import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    message: '',
  });
  const [consent, setConsent] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};

    if (!formData.fullName.trim()) newErrors.fullName = 'Name is required.';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required.';
    } else if (
      !/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email.trim())
    ) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Please include information about your needs.';
    }
    if (!consent) {
      newErrors.consent =
        'We use double opt-in. Confirm your consent to receive follow-up communications.';
    }
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact Tu Progreso Hoy | Buenos Aires</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy in Buenos Aires for inquiries about inflation analytics, financial education, or partnerships."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.content}>
          <h1>Contact our Buenos Aires team</h1>
          <p>
            Visit us at Av. 9 de Julio 1000, Buenos Aires or schedule a virtual
            consultation. Estamos listos para ayudarte.
          </p>
        </div>
      </section>

      <section className={styles.info}>
        <div className={styles.details}>
          <h2>Let’s connect</h2>
          <p>
            Phone: <a href="tel:+541155551234">+54 11 5555-1234</a>
          </p>
          <p>
            Email: <a href="mailto:info@tuprogresohoy.com">info@tuprogresohoy.com</a>
          </p>
          <p>Address: Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <div className={styles.mapWrap}>
            <iframe
              title="Tu Progreso Hoy location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.156627495733!2d-58.38375922343581!3d-34.60373475993927!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacec03a2ff9%3A0x8a5cb582fa4189ad!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA!5e0!3m2!1sen!2sar!4v1686111111111"
              loading="lazy"
              allowFullScreen
            />
          </div>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="contact-name">
            Name / Nombre
            <input
              id="contact-name"
              value={formData.fullName}
              onChange={(event) =>
                setFormData((prev) => ({
                  ...prev,
                  fullName: event.target.value,
                }))
              }
              aria-invalid={!!errors.fullName}
            />
            {errors.fullName && (
              <span className={styles.error}>{errors.fullName}</span>
            )}
          </label>
          <label htmlFor="contact-email">
            Email
            <input
              id="contact-email"
              type="email"
              value={formData.email}
              onChange={(event) =>
                setFormData((prev) => ({
                  ...prev,
                  email: event.target.value,
                }))
              }
              aria-invalid={!!errors.email}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </label>
          <label htmlFor="contact-message">
            Message / Mensaje
            <textarea
              id="contact-message"
              rows={5}
              value={formData.message}
              onChange={(event) =>
                setFormData((prev) => ({
                  ...prev,
                  message: event.target.value,
                }))
              }
              aria-invalid={!!errors.message}
            />
            {errors.message && (
              <span className={styles.error}>{errors.message}</span>
            )}
          </label>
          <label className={styles.checkbox}>
            <input
              type="checkbox"
              checked={consent}
              onChange={(event) => setConsent(event.target.checked)}
            />
            <span>
              I consent to receiving Tu Progreso Hoy emails and will confirm via
              double opt-in. / Confirmo doble opt-in.
            </span>
          </label>
          {errors.consent && <span className={styles.error}>{errors.consent}</span>}
          <button type="submit" className="btn-primary">
            Send message
          </button>
          {submitted && (
            <p className={styles.success}>
              Thank you! We will send a confirmation email shortly. Revisa tu
              bandeja y confirmá tu suscripción.
            </p>
          )}
        </form>
      </section>
    </>
  );
};

export default Contact;