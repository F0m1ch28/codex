import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Inflation.module.css';

const Inflation = () => {
  const inflationSeries = [
    { month: 'Oct 23', value: 8.3 },
    { month: 'Nov 23', value: 12.8 },
    { month: 'Dec 23', value: 25.5 },
    { month: 'Jan 24', value: 20.6 },
    { month: 'Feb 24', value: 13.2 },
    { month: 'Mar 24', value: 11.7 },
  ];

  const fxContext = [
    { label: 'Official', value: 0.0012 },
    { label: 'MEP', value: 0.00098 },
    { label: 'Blue', value: 0.00087 },
  ];

  const faq = [
    {
      q: 'Where do you get CPI data?',
      a: 'We rely on INDEC for official CPI (IPC Nacional) and blend it with provincial statistics to highlight dispersion. Each data point includes source links.'
    },
    {
      q: 'How do you treat peso devaluations?',
      a: 'We mark structural shifts and provide contextual notes. Users can replay the last 18 months to understand compounding effects.'
    },
    {
      q: 'Do you track parallel market rates?',
      a: 'Yes. We include MEP and blue references from reputable sources, updating every 30 minutes.'
    },
    {
      q: 'Is methodology transparent?',
      a: 'Absolutely. We publish assumptions, smoothing techniques, and model limitations in English and Spanish.'
    },
  ];

  return (
    <>
      <Helmet>
        <title>Inflation Methodology | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Understand Tu Progreso Hoy inflation methodology, CPI context, ARS-USD exchange rates, and frequently asked questions."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.content}>
          <h1>Inflation methodology & FX context</h1>
          <p>
            Transparent assumptions, regional breakdowns, and ARS → USD
            sensitivity analysis to keep you informed.
          </p>
        </div>
      </section>

      <section className={styles.methodology} aria-labelledby="methodology-title">
        <div className={styles.sectionHeader}>
          <h2 id="methodology-title">Methodology overview</h2>
          <p>
            Our inflation dashboard combines official CPI, curated proxies, and
            contextual narratives. Scroll below for our full workflow.
          </p>
        </div>
        <div className={styles.grid}>
          <article>
            <h3>1. Source validation</h3>
            <p>
              We ingest INDEC CPI prints, provincial surveys, and trusted
              private indices. Every feed includes metadata, timestamp, and
              credibility scoring.
            </p>
          </article>
          <article>
            <h3>2. Basket calibration</h3>
            <p>
              We adapt baskets to household contexts (families, freelancers,
              retirees). Spanish guidance clarifies weight adjustments.
            </p>
          </article>
          <article>
            <h3>3. Scenario building</h3>
            <p>
              Our models draw moderate, accelerated, and deceleration scenarios,
              factoring in FX expectations and regulated tariffs.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.chartSection}>
        <div className={styles.sectionHeader}>
          <h2>Monthly CPI trend (m/m %)</h2>
          <p>
            Visualize the last six months and compare against household-level
            inflation experiences.
          </p>
        </div>
        <div className={styles.chart}>
          {inflationSeries.map((item) => (
            <div key={item.month} className={styles.barWrap}>
              <div
                className={styles.bar}
                style={{ height: `${item.value * 6}px` }}
                aria-label={`${item.month} inflation ${item.value}%`}
              />
              <span>{item.month}</span>
              <p>{item.value}%</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.fxSection}>
        <div className={styles.sectionHeader}>
          <h2>Exchange rate snapshot / Panorama cambiario</h2>
          <p>
            We track multiple references to highlight spreads y oportunidades de
            cobertura.
          </p>
        </div>
        <div className={styles.fxGrid}>
          {fxContext.map((item) => (
            <article key={item.label}>
              <h3>{item.label}</h3>
              <p>{item.value.toFixed(5)} USD</p>
              <span>Per ARS · Updated hourly</span>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="inflation-faq">
        <div className={styles.sectionHeader}>
          <h2 id="inflation-faq">FAQ</h2>
          <p>Methodology questions answered in both English and Spanish.</p>
        </div>
        <div className={styles.faqGrid}>
          {faq.map((item) => (
            <article key={item.q}>
              <h3>{item.q}</h3>
              <p>{item.a}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Inflation;