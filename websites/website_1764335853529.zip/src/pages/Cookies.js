import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiesPolicy = () => (
  <>
    <Helmet>
      <title>Cookies Policy | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="Cookies policy explaining how Tu Progreso Hoy uses cookies for analytics and user experience."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Cookies Policy</h1>
      <p>Effective date: 1 April 2024</p>
    </section>
    <section className={styles.body}>
      <p>
        Tu Progreso Hoy uses cookies and similar technologies to understand
        platform usage and optimize content delivery. Cookies are small text
        files placed on your device when you visit our site.
      </p>
      <h2>Types of cookies</h2>
      <ul>
        <li>
          <strong>Essential:</strong> Required for core functionality such as
          session management.
        </li>
        <li>
          <strong>Analytics:</strong> Help us understand how users interact with
          dashboards and learning modules.
        </li>
      </ul>
      <h2>Consent</h2>
      <p>
        We use an opt-in banner to request consent for non-essential cookies.
        You can withdraw consent at any time by clearing cookies or contacting
        us.
      </p>
      <h2>Managing cookies</h2>
      <p>
        Most browsers allow you to block or delete cookies. Note that disabling
        essential cookies may impact platform functionality.
      </p>
      <h2>Contact</h2>
      <p>
        For questions, email info@tuprogresohoy.com.
      </p>
    </section>
  </>
);

export default CookiesPolicy;