import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="Privacy policy detailing how Tu Progreso Hoy collects, uses, and protects personal data."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Privacy Policy</h1>
      <p>Effective date: 1 April 2024</p>
    </section>
    <section className={styles.body}>
      <p>
        Tu Progreso Hoy (“we”, “our”) operates an educational SaaS platform
        focused on inflation insights and personal finance education for
        Argentina. We collect limited personal data to deliver the service,
        including name, email, and learning preferences. Data is stored securely
        in GDPR-compliant servers.
      </p>
      <h2>Collection & usage</h2>
      <p>
        We collect information you voluntarily provide when registering,
        downloading resources, or contacting us. We also gather usage analytics
        with anonymized identifiers to improve the experience. We do not sell or
        rent personal data.
      </p>
      <h2>Legal basis</h2>
      <p>
        Data processing is based on consent, contractual necessity, and
        legitimate interest in delivering educational content.
      </p>
      <h2>Storage & security</h2>
      <p>
        Personal data is stored in encrypted databases. Access is limited to
        authorized personnel. We regularly review security controls.
      </p>
      <h2>Your rights</h2>
      <p>
        You may request access, correction, deletion, or portability of your
        data by emailing info@tuprogresohoy.com. We respond within 30 days.
      </p>
      <h2>International transfers</h2>
      <p>
        If we transfer data outside Argentina, we ensure appropriate safeguards
        in line with GDPR standards.
      </p>
      <h2>Updates</h2>
      <p>
        We may update this policy as needed. Continued use of the platform
        indicates acceptance of the changes.
      </p>
      <h2>Contact</h2>
      <p>
        Email: info@tuprogresohoy.com <br />
        Address: Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
      </p>
    </section>
  </>
);

export default Privacy;