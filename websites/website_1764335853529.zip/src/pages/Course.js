import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Course.module.css';

const Course = () => (
  <>
    <Helmet>
      <title>Course Overview | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="Explore Tu Progreso Hoy course syllabus, modules, live sessions, and enrollment details for bilingual financial education."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.content}>
        <h1>Bilingual financial literacy course designed for Argentina.</h1>
        <p>
          9 modules, live accountability, and data-driven practice labs. Disponible
          en inglés y español.
        </p>
      </div>
    </section>

    <section className={styles.modules}>
      <div className={styles.sectionHeader}>
        <h2>Module breakdown / Detalle de módulos</h2>
        <p>
          Structured to deliver relevant knowledge in under 6 weeks with weekly
          assignments.
        </p>
      </div>
      <div className={styles.moduleGrid}>
        {[
          ['1', 'Understanding inflation & currency risk'],
          ['2', 'Mapping household cash flows'],
          ['3', 'Choosing budgeting frameworks'],
          ['4', 'Emergency funds & liquidity buffers'],
          ['5', 'ARS & USD scenario modeling'],
          ['6', 'Debt management & negotiation'],
          ['7', 'Income diversification basics'],
          ['8', 'Future planning & goal setting'],
          ['9', 'Capstone: Your resilient blueprint'],
        ].map(([number, title]) => (
          <article key={number}>
            <span>{number}</span>
            <h3>{title}</h3>
            <p>
              Includes case studies, worksheets, and Spanish notes to reinforce
              the concept.
            </p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.cta}>
      <div className={styles.ctaCard}>
        <h2>Enrollment details</h2>
        <ul>
          <li>Live cohort every Tuesday 19:00 (GMT-3)</li>
          <li>Peer groups with bilingual facilitators</li>
          <li>Lifetime access to updates</li>
          <li>Certificate upon completion</li>
        </ul>
        <a className="btn-secondary" href="#free-lesson-form">
          Request a free trial lesson
        </a>
      </div>
    </section>
  </>
);

export default Course;