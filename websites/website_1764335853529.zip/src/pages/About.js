import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>About Tu Progreso Hoy | Mission, Team & Story</title>
      <meta
        name="description"
        content="Learn about Tu Progreso Hoy: an Argentina-based educational SaaS platform combining verified data and personal finance education."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.overlay} />
      <div className={styles.content}>
        <h1>We turn uncertainty into informed action.</h1>
        <p>
          Tu Progreso Hoy nació en Buenos Aires para ofrecer datos confiables y
          formación financiera bilingüe. We operate as an independent education
          company with a strong commitment to accuracy and accessibility.
        </p>
      </div>
    </section>

    <section className={styles.mission} aria-labelledby="mission-title">
      <div className={styles.sectionHeader}>
        <h2 id="mission-title">Our mission / Nuestra misión</h2>
        <p>
          Help Argentine households build confidence around budgeting, FX
          exposure, and personal finance decisions through transparent data and
          human-centered learning experiences.
        </p>
      </div>
      <div className={styles.missionGrid}>
        <article>
          <h3>Independence</h3>
          <p>
            We operate without ties to financial institutions. Our only goal is
            to bring clarity and actionable insights to learners.
          </p>
        </article>
        <article>
          <h3>Data rigor</h3>
          <p>
            Every visualization passes a quality checklist: source validation,
            methodology notes, and transparent assumptions.
          </p>
        </article>
        <article>
          <h3>Bilingual access</h3>
          <p>
            Lessons, playbooks, and live sessions are available in English and
            Spanish to serve a diverse community.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.timeline} aria-labelledby="timeline-title">
      <div className={styles.sectionHeader}>
        <h2 id="timeline-title">Milestones desde 2020</h2>
        <p>
          We constantly iterate with our community to bring context-aware tools.
        </p>
      </div>
      <div className={styles.timelineList}>
        <div>
          <span>2020</span>
          <p>Initial inflation dashboards launched for early adopters.</p>
        </div>
        <div>
          <span>2021</span>
          <p>First bilingual financial literacy course cohort (120 learners).</p>
        </div>
        <div>
          <span>2022</span>
          <p>Scenario planning toolkit released with ARS-USD linked models.</p>
        </div>
        <div>
          <span>2023</span>
          <p>Community coaching network expanded to 15 facilitators.</p>
        </div>
        <div>
          <span>2024</span>
          <p>New learning experience platform with real-time alerts.</p>
        </div>
      </div>
    </section>

    <section className={styles.values} aria-labelledby="values-title">
      <div className={styles.sectionHeader}>
        <h2 id="values-title">How we operate / Cómo trabajamos</h2>
        <p>
          Ethical data practices, empathetic instruction, and continuous feedback
          from our learners.
        </p>
      </div>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Context-first storytelling</h3>
          <p>
            Numbers are nothing without context. We annotate each chart with
            “what this means for households” guidance.
          </p>
        </article>
        <article>
          <h3>Inclusive community</h3>
          <p>
            From students to retirees, we welcome any Argentine resident aiming
            to improve personal finance habits.
          </p>
        </article>
        <article>
          <h3>Long-term alignment</h3>
          <p>
            Nuestro compromiso es acompañarte más allá de un curso. We publish
            ongoing resources and host periodic check-ins.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default About;