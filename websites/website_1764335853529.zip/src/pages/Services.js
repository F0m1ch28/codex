import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Services & Solutions | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="Discover Tu Progreso Hoy services: inflation analytics, bilingual personal finance education, scenario planning and household collaboration tools."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.content}>
        <h1>Solutions for families, freelancers, and small teams.</h1>
        <p>
          Pick the workflows that fit your household rhythm, mix ARS-USD
          analytics with guided learning, and stay in sync with every
          fluctuation.
        </p>
      </div>
    </section>

    <section className={styles.offers}>
      <div className={styles.sectionHeader}>
        <h2>Platform bundles</h2>
        <p>
          Transparent pricing, bilingual support, and no hidden commitments.
        </p>
      </div>
      <div className={styles.cardGrid}>
        <article>
          <h3>Starter Household</h3>
          <p>
            Ideal for couples or roommates getting started with structured
            budgeting.
          </p>
          <ul>
            <li>Weekly ARS → USD alerts</li>
            <li>Quarterly coaching call</li>
            <li>Access to core course modules</li>
            <li>Printable budgeting templates</li>
          </ul>
          <button type="button" className="btn-primary">
            Request quote
          </button>
        </article>
        <article>
          <h3>Growth Household</h3>
          <p>
            Recommended for families balancing multiple income streams and USD
            commitments.
          </p>
          <ul>
            <li>Advanced scenario modeling</li>
            <li>Full cohort course access</li>
            <li>Monthly live workshops</li>
            <li>2 partner seats included</li>
          </ul>
          <button type="button" className="btn-primary">
            Talk to an advisor
          </button>
        </article>
        <article>
          <h3>Freelancer Lab</h3>
          <p>
            Designed for independent professionals managing client payments in
            both currencies.
          </p>
          <ul>
            <li>Income volatility tracking</li>
            <li>Tax & compliance checklists</li>
            <li>Peer mastermind sessions</li>
            <li>Priority support en español</li>
          </ul>
          <button type="button" className="btn-primary">
            Join waiting list
          </button>
        </article>
      </div>
    </section>

    <section className={styles.features}>
      <div className={styles.sectionHeader}>
        <h2>Feature highlights / Funcionalidades</h2>
        <p>
          Everything is built to reduce friction and help you focus on progress.
        </p>
      </div>
      <div className={styles.featuresGrid}>
        <article>
          <h3>Scenario templates</h3>
          <p>
            Create optimistic, base, and conservative projections. Export PDF
            summaries in English or Spanish.
          </p>
        </article>
        <article>
          <h3>Accountability loops</h3>
          <p>
            Set monthly commitments, share progress with your household, and
            celebrate wins with our community.
          </p>
        </article>
        <article>
          <h3>Live trend briefings</h3>
          <p>
            Receive concise explainers of economic shifts directly from our
            analysts. Sin ruido, con claridad.
          </p>
        </article>
        <article>
          <h3>Safe data practices</h3>
          <p>
            We take privacy seriously—GDPR-aligned, local data residency, and
            enterprise-grade encryption.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default Services;