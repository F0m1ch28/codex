import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.container}>
      <div className={styles.brand}>
        <h3>Tu Progreso Hoy</h3>
        <p>
          Data-led personal finance education designed for Argentina. Empowering
          households to plan better and move confidently, paso a paso.
        </p>
        <p className={styles.disclaimer}>
          Disclaimer (RU/EN/ES): Мы не предоставляем финансовые услуги. We do
          not provide financial services. No brindamos servicios financieros.
        </p>
      </div>
      <div className={styles.columns}>
        <div>
          <h4>Platform</h4>
          <ul>
            <li>
              <Link to="/inflation">Inflation Lab</Link>
            </li>
            <li>
              <Link to="/course">Financial Course</Link>
            </li>
            <li>
              <Link to="/services">Solutions</Link>
            </li>
            <li>
              <Link to="/resources">Resources</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">About us</Link>
            </li>
              <li>
                <a href="#free-lesson-form">Free trial lesson</a>
              </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <Link to="/terms">Terms</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Policies</h4>
          <ul>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/cookies">Cookies Policy</Link>
            </li>
          </ul>
          <h4>Contact</h4>
          <ul className={styles.contactList}>
            <li>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</li>
            <li>
              <a href="tel:+541155551234">+54 11 5555-1234</a>
            </li>
            <li>
              <a href="mailto:info@tuprogresohoy.com">
                info@tuprogresohoy.com
              </a>
            </li>
          </ul>
          <div className={styles.socials}>
            <a
              href="https://www.linkedin.com"
              rel="noopener noreferrer"
              target="_blank"
            >
              LinkedIn
            </a>
            <a
              href="https://twitter.com"
              rel="noopener noreferrer"
              target="_blank"
            >
              Twitter
            </a>
            <a
              href="https://www.youtube.com"
              rel="noopener noreferrer"
              target="_blank"
            >
              YouTube
            </a>
          </div>
        </div>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;