import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleToggleMenu = () => {
    setIsMobileMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoMark}>Tu</span>
          <span className={styles.logoText}>Progreso Hoy</span>
        </NavLink>
        <nav className={styles.nav} aria-label="Primary navigation">
          <button
            className={styles.menuButton}
            onClick={handleToggleMenu}
            aria-expanded={isMobileMenuOpen}
            aria-controls="primary-menu"
            aria-label="Toggle navigation menu"
          >
            <span />
            <span />
            <span />
          </button>
          <div
            className={`${styles.menu} ${isMobileMenuOpen ? styles.menuOpen : ''}`}
            id="primary-menu"
          >
            <NavLink
              to="/"
              onClick={closeMenu}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Home
            </NavLink>
            <NavLink
              to="/inflation"
              onClick={closeMenu}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Inflation
            </NavLink>
            <NavLink
              to="/course"
              onClick={closeMenu}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Course
            </NavLink>
            <NavLink
              to="/resources"
              onClick={closeMenu}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Resources
            </NavLink>
            <NavLink
              to="/about"
              onClick={closeMenu}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              About
            </NavLink>
            <NavLink
              to="/services"
              onClick={closeMenu}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Solutions
            </NavLink>
            <NavLink
              to="/contact"
              onClick={closeMenu}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Contact
            </NavLink>
            <a
              href="#free-lesson-form"
              className={styles.cta}
              onClick={closeMenu}
            >
              Free trial lesson
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;