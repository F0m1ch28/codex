import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('tuph-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = () => {
    window.localStorage.setItem('tuph-cookie-consent', 'granted');
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem('tuph-cookie-consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Cookies & analytics</h4>
        <p>
          We use analytical cookies to understand platform usage and improve the
          learning experience. Adjust your preferences anytime in our cookies
          policy.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={handleDecline} className={styles.secondary}>
          Decline
        </button>
        <button type="button" onClick={handleConsent} className={styles.primary}>
          Accept & continue
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;