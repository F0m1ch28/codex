(function () {
  const navToggle = document.querySelector('.mobile-nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      navMenu.classList.toggle('open');
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
    });
  }
  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedPref = localStorage.getItem('cansys_cookie_pref');
    if (!storedPref) {
      cookieBanner.classList.add('active');
    }
    const acceptBtn = cookieBanner.querySelector('.cookie-accept');
    const declineBtn = cookieBanner.querySelector('.cookie-decline');
    const hideBanner = (value) => {
      localStorage.setItem('cansys_cookie_pref', value);
      cookieBanner.classList.remove('active');
    };
    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => hideBanner('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => hideBanner('declined'));
    }
  }
  const redirects = {
    '/history': 'field-notes.html',
    '/infrastructure': 'systems.html',
    '/resilience': 'analysis.html',
    '/technology': 'monitoring.html'
  };
  const currentPath = window.location.pathname.replace(/\/+$/, '');
  if (redirects[currentPath]) {
    window.location.replace(redirects[currentPath]);
  }
})();