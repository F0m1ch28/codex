document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.getElementById("primary-nav");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = primaryNav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", String(isOpen));
            document.body.classList.toggle("nav-open", isOpen);
        });

        primaryNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768 && primaryNav.classList.contains("is-open")) {
                    primaryNav.classList.remove("is-open");
                    document.body.classList.remove("nav-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedConsent = localStorage.getItem("politiyfdb-cookie-consent");
        if (storedConsent) {
            cookieBanner.classList.add("is-hidden");
        }

        const acceptButton = cookieBanner.querySelector('[data-cookie="accept"]');
        const declineButton = cookieBanner.querySelector('[data-cookie="decline"]');
        const customizeButton = cookieBanner.querySelector('[data-cookie="customize"]');

        const hideBanner = () => cookieBanner.classList.add("is-hidden");

        if (acceptButton) {
            acceptButton.addEventListener("click", () => {
                localStorage.setItem("politiyfdb-cookie-consent", "accepted");
                hideBanner();
            });
        }

        if (declineButton) {
            declineButton.addEventListener("click", () => {
                localStorage.setItem("politiyfdb-cookie-consent", "declined");
                hideBanner();
            });
        }

        if (customizeButton) {
            customizeButton.addEventListener("click", () => {
                localStorage.setItem("politiyfdb-cookie-consent", "customise");
                window.location.href = "cookies.html#preferences";
            });
        }
    }
});