import { useEffect } from 'react';

const Meta = ({ title, description, keywords, canonical }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }

    const setMetaTag = (selector, attrName, attrValue, content) => {
      if (!content) return;
      let element = document.head.querySelector(`${selector}[${attrName}=`${attrValue}"]");
      if (!element) {
        element = document.createElement(selector);
        element.setAttribute(attrName, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    if (description) {
      setMetaTag('meta', 'name', 'description', description);
      setMetaTag('meta', 'property', 'og:description', description);
    }

    if (keywords) {
      setMetaTag('meta', 'name', 'keywords', keywords);
    }

    if (title) {
      setMetaTag('meta', 'property', 'og:title', title);
      setMetaTag('meta', 'name', 'twitter:title', title);
    }

    if (canonical) {
      let link = document.head.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      link.setAttribute('href', canonical);
      setMetaTag('meta', 'property', 'og:url', canonical);
    }

    setMetaTag('meta', 'name', 'twitter:card', 'summary_large_image');
  }, [title, description, keywords, canonical]);

  return null;
};

export default Meta;