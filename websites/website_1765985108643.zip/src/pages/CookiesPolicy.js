import React from 'react';
import Meta from '../components/Meta';
import styles from './CookiesPolicy.module.css';

const CookiesPolicy = () => {
  return (
    <div className={styles.cookies}>
      <Meta
        title="Política de Cookies | Valentor Amicado"
        description="Información sobre el uso de cookies en el sitio web de Valentor Amicado."
        keywords="política de cookies Valentor Amicado"
        canonical="https://valentoramicado.site/cookies"
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Política de Cookies</h1>
          <p>Fecha de última actualización: enero 2024</p>

          <h2>¿Qué son las cookies?</h2>
          <p>
            Las cookies son pequeños archivos que se almacenan en tu dispositivo cuando visitas nuestro sitio.
            Nos ayudan a mejorar la experiencia de usuario, analizar el rendimiento y personalizar contenidos.
          </p>

          <h2>Tipos de cookies que utilizamos</h2>
          <ul>
            <li>
              <strong>Cookies esenciales:</strong> Permiten la navegación y el acceso a funcionalidades básicas.
            </li>
            <li>
              <strong>Cookies de analítica:</strong> Recopilan datos sobre el uso del sitio para optimizarlo.
            </li>
            <li>
              <strong>Cookies de personalización:</strong> Recuerdan tus preferencias de aprendizaje y navegación.
            </li>
          </ul>

          <h2>Gestión de cookies</h2>
          <p>
            Puedes configurar tu navegador para aceptar, bloquear o eliminar cookies. Ten en cuenta que desactivar
            cookies puede afectar la experiencia en nuestro sitio.
          </p>

          <h2>Contacto</h2>
          <p>
            Si tienes dudas sobre esta Política de Cookies, escríbenos a{' '}
            <a href="mailto:hola@valentoramicado.site">hola@valentoramicado.site</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiesPolicy;