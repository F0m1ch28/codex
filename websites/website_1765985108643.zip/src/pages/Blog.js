import React from 'react';
import Meta from '../components/Meta';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Cómo la IA redefine la experiencia de aprendizaje para adultos',
    excerpt:
      'Exploramos casos reales de personalización y acompañamiento inteligente que impulsan resultados de alto impacto.',
    date: '15 enero 2024',
    author: 'Equipo Valentor Amicado',
    image: 'https://picsum.photos/seed/valblog1/720/480'
  },
  {
    title: 'Claves para medir el impacto de tus programas de capacitación',
    excerpt:
      'Indicadores y herramientas accionables para traducir el aprendizaje en métricas estratégicas dentro de tu organización.',
    date: '8 enero 2024',
    author: 'Sofía Calderón',
    image: 'https://picsum.photos/seed/valblog2/720/480'
  },
  {
    title: 'Tendencias de aprendizaje corporativo en México 2024',
    excerpt:
      'Un vistazo a los comportamientos del talento adulto, prioridades de las empresas y tecnologías emergentes.',
    date: '2 enero 2024',
    author: 'Julián Herrera',
    image: 'https://picsum.photos/seed/valblog3/720/480'
  }
];

const Blog = () => {
  return (
    <div className={styles.blog}>
      <Meta
        title="Blog | Valentor Amicado"
        description="Insights, tendencias y estrategias sobre educación para adultos, IA y desarrollo de habilidades en México."
        keywords="blog Valentor Amicado, educación adultos, IA aprendizaje, tendencias capacitación"
        canonical="https://valentoramicado.site/blog"
      />

      <section className={styles.hero}>
        <div className="container">
          <h1>Ideas que inspiran el aprendizaje continuo</h1>
          <p>
            Artículos, tendencias y casos que muestran cómo la inteligencia artificial transforma la
            educación para adultos en México.
          </p>
        </div>
      </section>

      <section className={styles.postsSection}>
        <div className="container">
          <div className={styles.postsGrid}>
            {posts.map((post) => (
              <article key={post.title} className={styles.postCard}>
                <div className={styles.imageWrapper}>
                  <img src={post.image} alt={post.title} />
                </div>
                <div className={styles.postContent}>
                  <span className={styles.meta}>{post.date} · {post.author}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <a className={styles.readMore} href="#!">
                    Seguir leyendo →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;