import React from 'react';
import Meta from '../components/Meta';
import styles from './Methodology.module.css';

const phases = [
  {
    title: 'Exploración Inteligente',
    description:
      'Recolectamos datos de contexto, habilidades y expectativas para crear un mapa integral de cada profesional.',
    details: ['Encuestas dinámicas', 'Análisis de desempeño', 'Objetivos de negocio compartidos']
  },
  {
    title: 'Diseño de Trayectorias',
    description:
      'Combinamos IA y diseño instruccional para construir rutas que integran microlearning, práctica y mentoría.',
    details: ['Rutas adaptativas', 'Micro-retos situados', 'Mentoría especializada']
  },
  {
    title: 'Ejecución y Activación',
    description:
      'Activamos experiencias blended con sesiones sincrónicas, cápsulas on-demand y comunidades de práctica.',
    details: ['Laboratorios inmersivos', 'Simulaciones guiadas', 'Feedback automatizado']
  },
  {
    title: 'Evaluación Evolutiva',
    description:
      'Monitoreamos resultados en tiempo real y ajustamos la experiencia para mantener la relevancia y el impacto.',
    details: ['Dashboards ejecutivos', 'Recomendaciones IA', 'Reportes personalizados']
  }
];

const Methodology = () => {
  return (
    <div className={styles.methodology}>
      <Meta
        title="Metodología | Valentor Amicado"
        description="Descubre la metodología de Valentor Amicado para crear experiencias de aprendizaje personalizadas con IA para adultos."
        keywords="metodología Valentor Amicado, aprendizaje personalizado, IA educación adultos"
        canonical="https://valentoramicado.site/metodologia"
      />

      <section className={styles.hero}>
        <div className="container">
          <h1>Nuestra Metodología Valentor</h1>
          <p>
            Un modelo integral que combina datos, ciencia del aprendizaje y acompañamiento humano para impulsar
            el crecimiento profesional continuo.
          </p>
        </div>
      </section>

      <section className={styles.phasesSection}>
        <div className="container">
          <div className={styles.phasesGrid}>
            {phases.map((phase, index) => (
              <article key={phase.title} className={styles.phaseCard}>
                <span className={styles.index}>0{index + 1}</span>
                <h2>{phase.title}</h2>
                <p>{phase.description}</p>
                <ul>
                  {phase.details.map((detail) => (
                    <li key={detail}>{detail}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.outcomes}>
        <div className="container">
          <div className={styles.outcomesCard}>
            <h2>Resultados tangibles y alineados al negocio</h2>
            <p>
              Cada etapa está pensada para generar evidencia accionable sobre el avance individual y colectivo,
              ayudando a las organizaciones a tomar decisiones informadas.
            </p>
            <div className={styles.metrics}>
              <div>
                <span>+38%</span>
                <p>Incremento promedio en adopción de nuevas habilidades</p>
              </div>
              <div>
                <span>3.5x</span>
                <p>Retorno estimado en productividad anual</p>
              </div>
              <div>
                <span>96%</span>
                <p>Participantes que completan las rutas propuestas</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Methodology;