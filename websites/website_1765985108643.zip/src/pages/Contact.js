import React, { useState } from 'react';
import Meta from '../components/Meta';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) currentErrors.name = 'Por favor ingresa tu nombre completo.';
    if (!formData.email.trim()) {
      currentErrors.email = 'Necesitamos un correo electrónico válido.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      currentErrors.email = 'El formato del correo no es válido.';
    }
    if (!formData.message.trim()) currentErrors.message = 'Cuéntanos cómo podemos ayudarte.';
    return currentErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
    setErrors((prev) => ({ ...prev, [event.target.name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <div className={styles.contact}>
      <Meta
        title="Contacto | Valentor Amicado"
        description="Ponte en contacto con Valentor Amicado para diseñar programas de aprendizaje personalizado con IA. Estamos en Ciudad de México."
        keywords="contacto Valentor Amicado, educación adulta, programas IA, Ciudad de México"
        canonical="https://valentoramicado.site/contacto"
      />

      <section className={styles.hero}>
        <div className="container">
          <h1>Conversemos sobre el futuro del aprendizaje en tu organización</h1>
          <p>
            Completa el formulario y nuestro equipo te contactará en menos de 24 horas hábiles para
            explorar juntos la solución ideal.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="name">Nombre completo</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Ingresa tu nombre"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && (
                  <span id="name-error" className={styles.error}>
                    {errors.name}
                  </span>
                )}
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="email">Correo electrónico</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="nombre@empresa.com"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && (
                  <span id="email-error" className={styles.error}>
                    {errors.email}
                  </span>
                )}
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="company">Empresa / Organización</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  placeholder="Nombre de tu empresa"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="message">Mensaje</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  placeholder="Describe tus objetivos de aprendizaje"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                />
                {errors.message && (
                  <span id="message-error" className={styles.error}>
                    {errors.message}
                  </span>
                )}
              </div>

              <button type="submit" className={styles.submitButton}>
                Enviar mensaje
              </button>

              {submitted && (
                <div className={styles.success}>
                  ¡Gracias! Nuestro equipo se pondrá en contacto contigo muy pronto.
                </div>
              )}
            </form>

            <div className={styles.infoCard}>
              <h2>Encuéntranos</h2>
              <address>
                <p>Av. Insurgentes Sur 1234</p>
                <p>Col. Del Valle, Benito Juárez</p>
                <p>03100 Ciudad de México, CDMX, México</p>
              </address>
              <p>
                Teléfono: <a href="tel:+525512345678">+52 55 1234 5678</a>
              </p>
              <p>
                Email: <a href="mailto:hola@valentoramicado.site">hola@valentoramicado.site</a>
              </p>
              <div className={styles.mapWrapper} aria-hidden="true">
                <iframe
                  title="Ubicación de Valentor Amicado"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3763.5978214284184!2d-99.16635832476397!3d19.387095041694485!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85ce0024e5cba7f7%3A0xd02d4a64cc8b6509!2sAv.%20Insurgentes%20Sur%201234%2C%20Del%20Valle%2C%20Benito%20Ju%C3%A1rez%2C%2003100%20Ciudad%20de%20M%C3%A9xico%2C%20CDMX%2C%20M%C3%A9xico!5e0!3m2!1sen!2smx!4v1700000000000!5m2!1sen!2smx"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;