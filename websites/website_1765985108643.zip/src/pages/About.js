import React from 'react';
import Meta from '../components/Meta';
import ImageWithLoader from '../components/ImageWithLoader';
import styles from './About.module.css';

const values = [
  {
    title: 'Humanidad Amplificada',
    description:
      'Creemos en la tecnología al servicio de las personas. La IA amplifica diagnósticos y personalización, mientras el acompañamiento humano sostiene la transformación.'
  },
  {
    title: 'Aprendizaje Relevante',
    description:
      'Cada contenido responde a desafíos reales del contexto mexicano. Curamos experiencias que hacen sentido a las metas profesionales presentes y futuras.'
  },
  {
    title: 'Impacto Medible',
    description:
      'Diseñamos indicadores accionables para demostrar valor. El aprendizaje debe traducirse en desempeño visible y decisiones estratégicas más inteligentes.'
  }
];

const teamMembers = [
  {
    name: 'Sofía Calderón',
    role: 'Directora General',
    bio: 'Arquitecta de experiencias de aprendizaje con 15 años liderando iniciativas de upskilling corporativo en México y Latinoamérica.',
    photo: 'https://picsum.photos/seed/valteam1/360/400'
  },
  {
    name: 'Julián Herrera',
    role: 'Chief Learning Scientist',
    bio: 'Especialista en analítica educativa y machine learning aplicado a itinerarios personalizados para adultos.',
    photo: 'https://picsum.photos/seed/valteam2/360/400'
  },
  {
    name: 'Daniela Ríos',
    role: 'Head of Client Success',
    bio: 'Diseña estrategias de adopción y acompañamiento para garantizar que cada organización alcance resultados medibles.',
    photo: 'https://picsum.photos/seed/valteam3/360/400'
  }
];

const About = () => {
  return (
    <div className={styles.about}>
      <Meta
        title="Nosotros | Valentor Amicado"
        description="Conoce al equipo de Valentor Amicado, nuestra misión y visión para transformar la educación de adultos en México con inteligencia artificial."
        keywords="Valentor Amicado, nosotros, misión, equipo, educación adultos México"
        canonical="https://valentoramicado.site/nosotros"
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Somos tu aliado estratégico en aprendizaje inteligente</h1>
            <p>
              Valentor Amicado nace con la convicción de que el aprendizaje continuo es vital para
              la competitividad. Integramos ciencia del aprendizaje, datos y mentoring para acelerar
              la evolución de adultos profesionales en México.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.valuesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Nuestra esencia</h2>
            <p>
              Inspiramos experiencias significativas centradas en las personas, potenciadas por IA y
              orientadas a resultados reales.
            </p>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2>Nuestra evolución</h2>
          <div className={styles.timelineGrid}>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2019</span>
              <p>Conformamos el equipo fundador con expertos en capacitación corporativa y data science.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2020</span>
              <p>Lanzamos la primera versión de nuestra plataforma adaptativa para empresas mexicanas.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2022</span>
              <p>Integramos motores de IA propios para diagnosticar habilidades y recomendar rutas dinámicas.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2023</span>
              <p>Alcanzamos más de 40 organizaciones aliadas y 15,000 horas de aprendizaje activadas.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Conoce a nuestro equipo</h2>
            <p>
              Profesionales apasionados por conectar innovación educativa, tecnología y acompañamiento humano.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <ImageWithLoader
                  src={member.photo}
                  alt={`Fotografía de ${member.name}`}
                  wrapperClassName={styles.photoWrapper}
                  imageClassName={styles.teamPhoto}
                />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;