document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.getElementById('primary-menu');
    const navLinks = document.querySelectorAll('.site-nav a');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('is-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    siteNav.classList.remove('is-open');
                }
            });
        });
    }

    const banner = document.getElementById('cookie-banner');
    if (banner) {
        const storedConsent = localStorage.getItem('luliCookieConsent');
        if (!storedConsent) {
            banner.classList.add('is-visible');
        }

        banner.addEventListener('click', event => {
            const button = event.target.closest('button[data-cookie]');
            if (!button) return;

            const decision = button.getAttribute('data-cookie');
            localStorage.setItem('luliCookieConsent', decision);
            banner.classList.remove('is-visible');
        });
    }

    const yearElements = document.querySelectorAll('.current-year');
    const currentYear = new Date().getFullYear();
    yearElements.forEach(element => {
        element.textContent = currentYear;
    });
});