export const portfolioItems = [
  {
    id: 1,
    title: 'Интерактивный музейный портал «Новый свет»',
    category: 'Культура',
    description: 'Цифровая витрина национальной коллекции с мультимедийными турами и живой навигацией по экспозициям.',
    image: 'https://picsum.photos/1200/800?random=301',
    year: '2024',
    services: ['Концепция', 'UX/UI дизайн', 'Интерактивные сценарии'],
    featured: true
  },
  {
    id: 2,
    title: 'Платформа для акселерации технологических стартапов',
    category: 'Технологии',
    description: 'Информационная платформа с личным кабинетом и гибкой системой подачи заявок для инвесторов и команд.',
    image: 'https://picsum.photos/1200/800?random=302',
    year: '2023',
    services: ['Продуктовая аналитика', 'Дизайн системы', 'Front-end разработка'],
    featured: true
  },
  {
    id: 3,
    title: 'Образовательный портал «Город навыков»',
    category: 'Образование',
    description: 'Экосистема для городских образовательных программ с поддержкой форматов событий и персональных рекомендаций.',
    image: 'https://picsum.photos/1200/800?random=303',
    year: '2023',
    services: ['UX-исследования', 'Контент-стратегия', 'Дизайн интерфейсов'],
    featured: true
  },
  {
    id: 4,
    title: 'Маркетплейс ремесленных брендов «Craft&Co»',
    category: 'Коммерция',
    description: 'Площадка для локальных производителей с адаптивным визуальным мерчендайзингом и storytelling-фидом товаров.',
    image: 'https://picsum.photos/1200/800?random=304',
    year: '2022',
    services: ['Брендинг', 'UX', 'Front-end'],
    featured: false
  },
  {
    id: 5,
    title: 'Корпоративная платформа для архитектурного бюро',
    category: 'B2B',
    description: 'Презентабельный portal с каталогом реализованных проектов и защищенной зоной для документации.',
    image: 'https://picsum.photos/1200/800?random=305',
    year: '2022',
    services: ['Дизайн-система', 'CMS-интеграция'],
    featured: false
  },
  {
    id: 6,
    title: 'Лаборатория цифровой моды «Shift»',
    category: 'Fashion',
    description: 'Иммерсивный сайт-исследование о цифровой моде с игровой механикой и AR-фильтрами.',
    image: 'https://picsum.photos/1200/800?random=306',
    year: '2024',
    services: ['Creative direction', 'Motion design', 'WebGL'],
    featured: false
  }
];