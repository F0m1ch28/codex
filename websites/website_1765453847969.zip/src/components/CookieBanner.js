import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const defaultPreferences = {
  necessary: true,
  analytics: true,
  marketing: false
};

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState(defaultPreferences);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem('cookiePreferences');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setPreferences({
          ...defaultPreferences,
          ...parsed
        });
        setIsVisible(false);
      } catch (error) {
        setIsVisible(true);
      }
    } else {
      setIsVisible(true);
    }
  }, []);

  const handleAcceptAll = () => {
    const acceptedPrefs = {
      necessary: true,
      analytics: true,
      marketing: true,
      acceptedAt: new Date().toISOString()
    };
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('cookiePreferences', JSON.stringify(acceptedPrefs));
    }
    setPreferences(acceptedPrefs);
    setIsVisible(false);
  };

  const handleSave = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(
        'cookiePreferences',
        JSON.stringify({ ...preferences, acceptedAt: new Date().toISOString() })
      );
    }
    setIsVisible(false);
  };

  const togglePreference = (key) => {
    if (key === 'necessary') return;
    setPreferences((prev) => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div
      className={styles.banner}
      role="dialog"
      aria-live="polite"
      aria-label="Информация об использовании файлов cookies"
    >
      <div className={styles.inner}>
        <p className={styles.message}>
          Мы используем cookies, чтобы сайт работал безупречно и помогал вам быстрее находить нужную информацию.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.primary} onClick={handleAcceptAll}>
            Принять все
          </button>
          <button
            type="button"
            className={styles.secondary}
            onClick={() => setShowSettings((prev) => !prev)}
            aria-expanded={showSettings}
            aria-controls="cookie-settings"
          >
            Настроить
          </button>
        </div>
        {showSettings && (
          <div id="cookie-settings" className={styles.settings} role="group" aria-label="Настройки cookies">
            <div className={styles.preference}>
              <div>
                <p className={styles.preferenceTitle}>Обязательные</p>
                <p className={styles.preferenceText}>
                  Нужны для корректной работы сайта, отключить их невозможно.
                </p>
              </div>
              <label className={styles.switch}>
                <input type="checkbox" checked readOnly aria-readonly="true" />
                <span className={`${styles.slider} ${styles.sliderDisabled}`} />
              </label>
            </div>
            <div className={styles.preference}>
              <div>
                <p className={styles.preferenceTitle}>Аналитика</p>
                <p className={styles.preferenceText}>
                  Помогает нам понимать, что вам нравится, и улучшать интерфейс.
                </p>
              </div>
              <label className={styles.switch}>
                <input
                  type="checkbox"
                  checked={preferences.analytics}
                  onChange={() => togglePreference('analytics')}
                />
                <span className={styles.slider} />
              </label>
            </div>
            <div className={styles.preference}>
              <div>
                <p className={styles.preferenceTitle}>Маркетинг</p>
                <p className={styles.preferenceText}>
                  Делает наши коммуникации более персональными и уместными.
                </p>
              </div>
              <label className={styles.switch}>
                <input
                  type="checkbox"
                  checked={preferences.marketing}
                  onChange={() => togglePreference('marketing')}
                />
                <span className={styles.slider} />
              </label>
            </div>
            <button type="button" className={styles.save} onClick={handleSave}>
              Сохранить выбор
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CookieBanner;