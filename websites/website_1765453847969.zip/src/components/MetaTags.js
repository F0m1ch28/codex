import { useEffect } from 'react';

const ensureMeta = (name, content, attr = 'name') => {
  if (typeof document === 'undefined') return;
  let tag = document.head.querySelector(`meta[${attr}="${name}"]`);
  if (!content) {
    if (tag) {
      tag.setAttribute('content', '');
    }
    return;
  }
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute(attr, name);
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', content);
};

const ensureLink = (rel, href) => {
  if (typeof document === 'undefined' || !href) return;
  let link = document.head.querySelector(`link[rel="${rel}"]`);
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', rel);
    document.head.appendChild(link);
  }
  link.setAttribute('href', href);
};

const MetaTags = ({
  title,
  description,
  keywords,
  ogTitle,
  ogDescription,
  ogImage,
  ogUrl,
  canonical,
  schema
}) => {
  useEffect(() => {
    if (typeof document === 'undefined') return;
    if (title) {
      document.title = title;
    }
    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
    ensureMeta('og:title', ogTitle || title, 'property');
    ensureMeta('og:description', ogDescription || description, 'property');
    ensureMeta('og:image', ogImage, 'property');
    ensureMeta('og:url', ogUrl, 'property');
    ensureMeta('og:type', 'website', 'property');
    ensureMeta('og:locale', 'ru_RU', 'property');
    ensureMeta('twitter:card', 'summary_large_image');
    ensureMeta('twitter:title', ogTitle || title);
    ensureMeta('twitter:description', ogDescription || description);
    ensureMeta('twitter:image', ogImage);
    ensureLink('canonical', canonical || ogUrl);
  }, [title, description, keywords, ogTitle, ogDescription, ogImage, ogUrl, canonical]);

  if (schema) {
    return (
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
    );
  }

  return null;
};

export default MetaTags;