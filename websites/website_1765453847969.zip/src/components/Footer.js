import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <p className={styles.logo}>🎨 Сколько вариантов сайта создать?</p>
          <p className={styles.description}>
            Мы соединяем эстетику и технологии, чтобы бренды звучали ярко в цифровой среде и выстраивали доверие с аудиторией.
          </p>
          <div className={styles.socials} aria-label="Социальные сети">
            <a href="https://www.behance.net" target="_blank" rel="noopener noreferrer" aria-label="Behance">
              Behance
            </a>
            <a href="https://dribbble.com" target="_blank" rel="noopener noreferrer" aria-label="Dribbble">
              Dribbble
            </a>
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              LinkedIn
            </a>
          </div>
        </div>
        <div className={styles.links}>
          <h3 className={styles.heading}>Навигация</h3>
          <ul className={styles.linkList}>
            <li><Link to="/uslugi">Услуги</Link></li>
            <li><Link to="/portfolio">Портфолио</Link></li>
            <li><Link to="/o-nas">О нас</Link></li>
            <li><Link to="/blog">Блог</Link></li>
            <li><Link to="/kontakty">Контакты</Link></li>
          </ul>
        </div>
        <div className={styles.contacts}>
          <h3 className={styles.heading}>Контакты</h3>
          <address className={styles.address}>
            <span>Москва, ул. Тверская, д. 15, офис 304</span>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a>
          </address>
        </div>
        <div className={styles.legal}>
          <h3 className={styles.heading}>Документы</h3>
          <ul className={styles.linkList}>
            <li><Link to="/usloviya-ispolzovaniya">Условия использования</Link></li>
            <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
            <li><Link to="/politika-cookies">Политика использования cookies</Link></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className="container">
          <p className={styles.copy}>
            © {new Date().getFullYear()} 🎨 Сколько вариантов сайта создать? Все права защищены. Сделано с любовью к идеям и людям.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;