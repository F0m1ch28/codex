import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Главная' },
  { path: '/uslugi', label: 'Услуги' },
  { path: '/portfolio', label: 'Портфолио' },
  { path: '/o-nas', label: 'О нас' },
  { path: '/blog', label: 'Блог' },
  { path: '/kontakty', label: 'Контакты' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const handleCloseMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={`container ${styles.inner}`}>
        <Link to="/" className={styles.logo} aria-label="На главную страницу">
          🎨 Сколько вариантов сайта создать?
        </Link>
        <button
          type="button"
          className={styles.navToggle}
          onClick={handleToggle}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Меню"
        >
          <span className={styles.navToggleBar} />
          <span className={styles.navToggleBar} />
          <span className={styles.navToggleBar} />
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.path} className={styles.navItem}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    isActive
                      ? `${styles.navLink} ${styles.navLinkActive}`
                      : styles.navLink
                  }
                  onClick={handleCloseMenu}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <Link to="/kontakty" className={styles.actionButton} onClick={handleCloseMenu}>
          Обсудить проект
        </Link>
      </div>
    </header>
  );
};

export default Header;