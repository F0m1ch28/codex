import React, { useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Contacts.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: '',
  consent: false
};

const Contacts = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, представьтесь.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите электронную почту.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/.test(formData.email)) {
      newErrors.email = 'Похоже, в адресе ошибка.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите, что вам нужно.';
    }
    if (!formData.consent) {
      newErrors.consent = 'Необходимо согласие на обработку данных.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setStatus({ type: 'error', message: 'Проверьте, все ли поля заполнены корректно.' });
      return;
    }
    setErrors({});
    setStatus({
      type: 'success',
      message:
        'Спасибо! Мы получили запрос и свяжемся с вами в течение рабочего дня.'
    });
    setFormData(initialFormState);
  };

  return (
    <div className={styles.page}>
      <MetaTags
        title="Контакты — 🎨 Сколько вариантов сайта создать?"
        description="Свяжитесь с нами: +7 (495) 123-45-67, info@skolko-variantov.ru. Москва, ул. Тверская, д. 15, офис 304."
        keywords="контакты, связаться, креативное агентство Москва, бриф"
        ogTitle="Контакты креативного агентства 🎨 Сколько вариантов сайта создать?"
        ogDescription="Напишите нам или загляните в офис в центре Москвы. Мы всегда открыты к новым идеям."
        ogImage="https://picsum.photos/1200/630?random=250"
        ogUrl="https://www.skolko-variantov.ru/kontakty"
        canonical="https://www.skolko-variantov.ru/kontakty"
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div>
            <p className={styles.kicker}>Контакты</p>
            <h1>Давайте обсудим ваш проект</h1>
            <p>
              Расскажите о задаче, и мы предложим формат взаимодействия. Готовы подключиться к проекту на любой стадии —
              от идеи до развития уже запущенного продукта.
            </p>
            <ul className={styles.details}>
              <li>
                <strong>Адрес:</strong> Москва, ул. Тверская, д. 15, офис 304
              </li>
              <li>
                <strong>Телефон:</strong>{' '}
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>
                <strong>Email:</strong>{' '}
                <a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a>
              </li>
            </ul>
          </div>
          <div className={styles.mapWrapper}>
            <iframe
              title="Карта расположения офиса агентства"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.522988926026!2d37.60219231570364!3d55.76556628055773!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a43ab3c2d1d%3A0xf2d1b4aaaa1ff717!2z0KLQtdC80Y8g0KjQkNCW0JzQkA!5e0!3m2!1sru!2sru!4v1707738151383!5m2!1sru!2sru"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className={`container ${styles.formInner}`}>
          <div className={styles.formIntro}>
            <h2>Заполните короткий бриф</h2>
            <p>Опишите задачу, и мы подготовим предложение с таймлайном, командой и первым списком гипотез.</p>
          </div>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.fieldGroup}>
              <label htmlFor="name">Имя<span aria-hidden="true">*</span></label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Как к вам обращаться?"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.errorText}>
                  {errors.name}
                </span>
              )}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="email">Email<span aria-hidden="true">*</span></label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="example@company.ru"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.errorText}>
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="company">Компания</label>
              <input
                id="company"
                name="company"
                type="text"
                placeholder="Бренд или проект"
                value={formData.company}
                onChange={handleChange}
              />
            </div>

            <div className={styles.fieldGroupFull}>
              <label htmlFor="message">Расскажите о задаче<span aria-hidden="true">*</span></label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Что нужно решить? Какие есть сроки или ограничения?"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.errorText}>
                  {errors.message}
                </span>
              )}
            </div>

            <label className={styles.checkboxLabel}>
              <input
                type="checkbox"
                name="consent"
                checked={formData.consent}
                onChange={handleChange}
              />
              <span>
                Даю согласие на обработку персональных данных и соглашаюсь с{' '}
                <a href="/politika-konfidencialnosti">политикой конфиденциальности</a>.
              </span>
            </label>
            {errors.consent && <span className={styles.errorText}>{errors.consent}</span>}

            <button type="submit" className={styles.submitButton}>
              Отправить запрос
            </button>

            {status.message && (
              <p
                className={`${styles.statusMessage} ${
                  status.type === 'success' ? styles.statusSuccess : styles.statusError
                }`}
                role="status"
                aria-live="polite"
              >
                {status.message}
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contacts;