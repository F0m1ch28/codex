import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './About.module.css';

const timeline = [
  {
    year: '2017',
    title: 'Запустили студию из трёх человек',
    description:
      'Первый офис располагался в лофте на Арме. Мы разрабатывали лендинги для локальных брендов и учились работать как единая команда.'
  },
  {
    year: '2019',
    title: 'Перешли к комплексным цифровым продуктам',
    description:
      'В портфеле появились образовательные платформы и городские сервисы. Мы встроили исследовательскую практику в каждый проект.'
  },
  {
    year: '2021',
    title: 'Собрали продуктовый офис и запустили поддержку',
    description:
      'Нас стало 30 человек, появилась отлаженная дизайн-система и отдельное направление стратегического консалтинга.'
  },
  {
    year: '2024',
    title: 'Работаем как гибридная команда',
    description:
      'Строим долгие партнерства с клиентами, сопровождаем запуск цифровых экосистем и продолжаем экспериментировать с форматами.'
  }
];

const values = [
  {
    title: 'Смелость в идеях',
    description:
      'Сочетаем исследовательскую точность и художественную свободу, чтобы находить решения, которые удивляют и работают.'
  },
  {
    title: 'Ответственность за результат',
    description:
      'Не ограничиваемся сдачей макета. Думаем о бизнес-метриках, пользовательском опыте и будущих итерациях.'
  },
  {
    title: 'Человечность',
    description:
      'Строим доверительные отношения с клиентами и внутри команды. Поддерживаем баланс работы и жизни.'
  }
];

const teamMembers = [
  {
    name: 'Мария Крылова',
    role: 'Креативный директор и основатель',
    bio: 'Разрабатывает визуальные концепции, курирует общий дизайн-курс и менторит новую волну арт-директоров.',
    image: 'https://picsum.photos/600/600?random=711'
  },
  {
    name: 'Алексей Григорьев',
    role: 'Tech Lead',
    bio: 'Отвечает за архитектуру проектов, следит за качеством кода и помогает командам внедрять новые технологии.',
    image: 'https://picsum.photos/600/600?random=712'
  },
  {
    name: 'Наталья Титова',
    role: 'Lead UX-исследователь',
    bio: 'Проводит глубинные интервью, тестирует гипотезы и переводит инсайты пользователей в понятные артефакты.',
    image: 'https://picsum.photos/600/600?random=713'
  },
  {
    name: 'Роман Беляев',
    role: 'Стратег и фасилитатор',
    bio: 'Помогает клиентам сформировать цифровую стратегию, модерирует воркшопы и отвечает за партнерство.',
    image: 'https://picsum.photos/600/600?random=714'
  }
];

const About = () => {
  return (
    <div className={styles.page}>
      <MetaTags
        title="О нас — 🎨 Сколько вариантов сайта создать?"
        description="Мы — креативное агентство из Москвы, которое соединяет исследования, дизайн и технологию. Узнайте, как мы строим команду и чем живём."
        keywords="о нас, команда агентства, креативное агентство Москва, дизайнеры, разработчики"
        ogTitle="Команда 🎨 Сколько вариантов сайта создать?"
        ogDescription="Познакомьтесь с людьми, которые создают цифровые впечатления. Мы работаем как расширенная команда клиента."
        ogImage="https://picsum.photos/1200/630?random=120"
        ogUrl="https://www.skolko-variantov.ru/o-nas"
        canonical="https://www.skolko-variantov.ru/o-nas"
      />

      <section className={styles.intro}>
        <div className={`container ${styles.introGrid}`}>
          <div>
            <p className={styles.kicker}>Кто мы</p>
            <h1>Агентство, которое превращает идеи в цифровые истории</h1>
            <p>
              Мы объединили дизайнеров, исследователей, разработчиков и стратегов, чтобы работать над проектами,
              где важны смысл, эстетика и технологичность. Нас вдохновляют компании, которые хотят говорить с
              аудиторией по-настоящему и готовы экспериментировать.
            </p>
          </div>
          <div className={styles.introImage}>
            <img
              src="https://picsum.photos/1200/900?random=130"
              alt="Команда агентства обсуждает концепцию проекта"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>История</p>
            <h2>Как мы росли</h2>
          </div>
          <p>
            За семь лет мы прошли путь от маленькой студии до стратегии цифровых экосистем. Но главное — сохранили
            способность слушать, учиться и действовать быстро.
          </p>
        </div>
        <div className={`container ${styles.timelineList}`}>
          {timeline.map((milestone) => (
            <article key={milestone.year} className={styles.timelineCard}>
              <span className={styles.timelineYear}>{milestone.year}</span>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.values}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Ценности</p>
            <h2>Что нас объединяет</h2>
          </div>
        </div>
        <div className={`container ${styles.valuesGrid}`}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Команда</p>
            <h2>Лица агентства</h2>
          </div>
          <p>
            Одна из наших сильных сторон — разнообразие. Внутри компании есть background в архитектуре, журналистике,
            маркетинге, театре и аналитике. Это позволяет нам видеть проект под разными углами и находить нестандартные решения.
          </p>
        </div>
        <div className={`container ${styles.teamGrid}`}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamMember}>
              <div className={styles.memberImage}>
                <img src={member.image} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.memberBody}>
                <p className={styles.memberName}>{member.name}</p>
                <p className={styles.memberRole}>{member.role}</p>
                <p className={styles.memberBio}>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.culture}>
        <div className={`container ${styles.cultureGrid}`}>
          <div>
            <h2>Как мы работаем внутри</h2>
            <p>
              Мы поддерживаем культуру обратной связи, экспериментов и взаимного обучения. У нас открытая библиотека знаний,
              внутренние демо и проектные «ретро» — чтобы видеть сильные стороны и расти.
            </p>
          </div>
          <ul className={styles.cultureList}>
            <li>
              <h3>Обучаемся постоянно</h3>
              <p>Делимся новыми инструментами, проводим воркшопы и обсуждаем тренды каждую пятницу.</p>
            </li>
            <li>
              <h3>Заботимся о балансе</h3>
              <p>Строим гибкие графики и поддерживаем культуру выходных без уведомлений.</p>
            </li>
            <li>
              <h3>Прозрачно общаемся</h3>
              <p>Используем открытые каналы, чтобы каждый понимал, куда движется проект.</p>
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default About;