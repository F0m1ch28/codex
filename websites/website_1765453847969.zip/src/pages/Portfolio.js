import React, { useMemo, useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Portfolio.module.css';
import { portfolioItems } from '../data/portfolio';

const Portfolio = () => {
  const categories = useMemo(() => ['Все', ...new Set(portfolioItems.map((item) => item.category))], []);
  const [activeCategory, setActiveCategory] = useState('Все');

  const filteredItems = useMemo(() => {
    if (activeCategory === 'Все') {
      return portfolioItems;
    }
    return portfolioItems.filter((item) => item.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className={styles.page}>
      <MetaTags
        title="Портфолио — 🎨 Сколько вариантов сайта создать?"
        description="Наши цифровые проекты для культурных инициатив, технологических компаний и образовательных платформ."
        keywords="портфолио, кейсы, веб-проекты, дизайн студии, цифровые продукты"
        ogTitle="Портфолио проектов агентства 🎨 Сколько вариантов сайта создать?"
        ogDescription="Изучите, как мы решаем задачи клиентов: от музейных порталов до акселераторов стартапов."
        ogImage="https://picsum.photos/1200/630?random=230"
        ogUrl="https://www.skolko-variantov.ru/portfolio"
        canonical="https://www.skolko-variantov.ru/portfolio"
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div>
            <p className={styles.kicker}>Портфолио</p>
            <h1>Проекты, которые раскрывают характер брендов</h1>
            <p>
              Мы работаем с компаниями из разных отраслей — культурой, образованием, технологиями, коммерцией. Во всех
              кейсах можно увидеть нашу любовь к деталям, исследовательский подход и смелые визуальные решения.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.filters}>
        <div className={`container ${styles.filtersInner}`}>
          {categories.map((category) => (
            <button
              type="button"
              key={category}
              className={`${styles.filterButton} ${activeCategory === category ? styles.filterButtonActive : ''}`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      <section className={styles.gallery}>
        <div className={`container ${styles.grid}`}>
          {filteredItems.map((item) => (
            <article key={item.id} className={styles.card}>
              <div className={styles.cardImage}>
                <img src={item.image} alt={item.title} loading="lazy" />
              </div>
              <div className={styles.cardBody}>
                <p className={styles.cardMeta}>
                  {item.category} · {item.year}
                </p>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
                <ul className={styles.cardTags}>
                  {item.services.map((service) => (
                    <li key={service}>{service}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Portfolio;