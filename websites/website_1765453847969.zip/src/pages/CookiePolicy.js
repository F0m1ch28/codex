import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <MetaTags
        title="Политика использования cookies — 🎨 Сколько вариантов сайта создать?"
        description="Подробно рассказываем, какие файлы cookies использует наш сайт и как управлять ими."
        keywords="cookies, политика файлов cookies"
        ogTitle="Политика использования cookies"
        ogDescription="Узнайте, какие типы cookies используются на сайте и как вы можете изменить настройки."
        ogImage="https://picsum.photos/1200/630?random=280"
        ogUrl="https://www.skolko-variantov.ru/politika-cookies"
        canonical="https://www.skolko-variantov.ru/politika-cookies"
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Политика использования cookies</h1>
          <p className={styles.date}>Последнее обновление: 8 апреля 2024 года</p>

          <h2>1. Что такое cookies</h2>
          <p>
            Cookies — это небольшие файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают
            запомнить ваши настройки и делают взаимодействие более удобным.
          </p>

          <h2>2. Какие cookies мы используем</h2>
          <ul>
            <li>
              <strong>Обязательные</strong> — обеспечивают работу сайта и безопасность. Без них сайт может функционировать некорректно.
            </li>
            <li>
              <strong>Аналитические</strong> — помогают понимать, как пользователи взаимодействуют с сайтом, чтобы мы могли его улучшать.
            </li>
            <li>
              <strong>Маркетинговые</strong> — используются для персонализации коммуникаций и предложений.
            </li>
          </ul>

          <h2>3. Управление cookies</h2>
          <p>
            Вы можете изменить настройки cookies в баннере на сайте или в настройках браузера. Обратите внимание, что
            отключение обязательных cookies невозможно, так как они отвечают за базовую функциональность.
          </p>

          <h2>4. Сторонние cookies</h2>
          <p>
            Некоторые разделы сайта могут использовать сторонние сервисы (например, карты или встроенные видео). Эти сервисы могут
            сохранять собственные cookies. Мы рекомендуем ознакомиться с их политиками конфиденциальности.
          </p>

          <h2>5. Обратная связь</h2>
          <p>
            Если у вас есть вопросы об использовании cookies, напишите нам на <a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;