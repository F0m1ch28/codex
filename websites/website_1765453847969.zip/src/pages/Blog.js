import React, { useMemo, useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Blog.module.css';
import { blogPosts } from '../data/blogPosts';

const Blog = () => {
  const categories = useMemo(() => ['Все', ...new Set(blogPosts.map((post) => post.category))], []);
  const [activeCategory, setActiveCategory] = useState('Все');

  const filteredPosts = useMemo(() => {
    if (activeCategory === 'Все') {
      return blogPosts;
    }
    return blogPosts.filter((post) => post.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className={styles.page}>
      <MetaTags
        title="Блог — 🎨 Сколько вариантов сайта создать?"
        description="Практика креативного агентства: исследования, дизайн, технологии, контент. Читайте инсайты нашей команды."
        keywords="блог агентства, UX исследования, UI дизайн, продуктовая разработка"
        ogTitle="Блог агентства 🎨 Сколько вариантов сайта создать?"
        ogDescription="Делимся опытом: как проектировать цифровые продукты, которые любят пользователи."
        ogImage="https://picsum.photos/1200/630?random=240"
        ogUrl="https://www.skolko-variantov.ru/blog"
        canonical="https://www.skolko-variantov.ru/blog"
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div>
            <p className={styles.kicker}>Блог</p>
            <h1>Мастерская идей и практик</h1>
            <p>
              Здесь мы делимся рабочими инструментами, рассказываем о находках, делаем разборы и показываем закулисье
              наших проектов. Все тексты написаны людьми из команды — без копипаста и общих фраз.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.filters}>
        <div className={`container ${styles.filtersInner}`}>
          {categories.map((category) => (
            <button
              type="button"
              key={category}
              className={`${styles.filterButton} ${category === activeCategory ? styles.filterButtonActive : ''}`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      <section className={styles.posts}>
        <div className={`container ${styles.grid}`}>
          {filteredPosts.map((post) => (
            <article key={post.id} className={styles.card}>
              <div className={styles.cardImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.cardBody}>
                <p className={styles.cardMeta}>
                  {post.category} · {new Date(post.date).toLocaleDateString('ru-RU')} · {post.readingTime}
                </p>
                <h2>{post.title}</h2>
                <p>{post.excerpt}</p>
                <p className={styles.cardAuthor}>Автор: {post.author}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Blog;