import React, { useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Services.module.css';

const servicesData = [
  {
    id: 'research',
    title: 'Исследования и стратегия',
    description:
      'Проводим пользовательские интервью, аудит, конкурентный анализ, проектируем CJM и формируем дорожную карту развития продукта.',
    image: 'https://picsum.photos/900/600?random=210',
    bulletPoints: [
      'Глубинные интервью и аналитика данных',
      'Сесии по формированию vision',
      'Workshop с командой клиента',
      'Product roadmap и KPI'
    ]
  },
  {
    id: 'design',
    title: 'UX/UI дизайн и визуальная система',
    description:
      'Создаем прототипы, дизайн-системы и макеты, которые учитывают пользовательские сценарии, бренд-платформу и технические ограничения.',
    image: 'https://picsum.photos/900/600?random=211',
    bulletPoints: [
      'Информационная архитектура',
      'Прототипы и тестирование',
      'Дизайн-система и UI-кит',
      'Микроанимации и motion'
    ]
  },
  {
    id: 'development',
    title: 'Фронтенд и интеграции',
    description:
      'Разрабатываем адаптивные интерфейсы, настраиваем CMS, подключаем CRM и внешние сервисы, обеспечиваем производительность.',
    image: 'https://picsum.photos/900/600?random=212',
    bulletPoints: [
      'React/Next.js разработка',
      'Headless CMS (Contentful, Strapi)',
      'Оптимизация скорости и SEO',
      'Интеграции с CRM и аналитикой'
    ]
  },
  {
    id: 'support',
    title: 'Контент, A/B-тесты и развитие',
    description:
      'После релиза не пропадаем: анализируем метрики, предлагаем гипотезы, поддерживаем дизайн-систему и делаем контент актуальным.',
    image: 'https://picsum.photos/900/600?random=213',
    bulletPoints: [
      'Контент-менеджмент и редактура',
      'A/B-тестирование и эксперименты',
      'Поддержка и развитие функционала',
      'Команда на аутсорсе'
    ]
  }
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicesData[0].id);

  const handleServiceChange = (id) => {
    setActiveService(id);
  };

  const currentService = servicesData.find((service) => service.id === activeService);

  return (
    <div className={styles.page}>
      <MetaTags
        title="Услуги — 🎨 Сколько вариантов сайта создать?"
        description="Исследования, UX/UI дизайн, разработка и развитие сайтов. Мы ведем проект целиком или подключаемся на отдельный этап."
        keywords="услуги агентства, UX/UI, разработка сайтов, дизайн-система, исследования"
        ogTitle="Услуги креативного агентства 🎨 Сколько вариантов сайта создать?"
        ogDescription="Комплексный подход: от исследования и стратегии до разработки, контента и сопровождения."
        ogImage="https://picsum.photos/1200/630?random=220"
        ogUrl="https://www.skolko-variantov.ru/uslugi"
        canonical="https://www.skolko-variantov.ru/uslugi"
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div>
            <p className={styles.kicker}>Что мы делаем</p>
            <h1>Комплексные цифровые проекты на любую глубину</h1>
            <p>
              Мы подключаемся на всех этапах — от исследования до роста продукта. Можно выбрать полный цикл или отдельный
              этап, если вам нужна экспертиза в конкретной области.
            </p>
          </div>
          <div className={styles.heroHighlights}>
            <div>
              <span>01</span>
              <p>Формируем стратегию и проверяем гипотезы</p>
            </div>
            <div>
              <span>02</span>
              <p>Проектируем и визуализируем пользовательские сценарии</p>
            </div>
            <div>
              <span>03</span>
              <p>Разрабатываем, интегрируем и сопровождаем</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className={`container ${styles.layout}`}>
          <div className={styles.serviceTabs} role="tablist" aria-label="Услуги агентства">
            {servicesData.map((service) => (
              <button
                type="button"
                key={service.id}
                role="tab"
                aria-selected={service.id === activeService}
                className={`${styles.tabButton} ${service.id === activeService ? styles.tabButtonActive : ''}`}
                onClick={() => handleServiceChange(service.id)}
              >
                {service.title}
              </button>
            ))}
          </div>
          {currentService && (
            <article className={styles.serviceDetail} role="tabpanel">
              <div className={styles.serviceImage}>
                <img src={currentService.image} alt={currentService.title} loading="lazy" />
              </div>
              <div className={styles.serviceContent}>
                <h2>{currentService.title}</h2>
                <p>{currentService.description}</p>
                <ul>
                  {currentService.bulletPoints.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            </article>
          )}
        </div>
      </section>

      <section className={styles.process}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Командная работа</p>
            <h2>Прозрачный процесс взаимодействия</h2>
          </div>
          <p>
            Мы заранее фиксируем формат работы, точки контакта и инструменты. Так команда с вашей стороны всегда знает,
            что происходит, какие материалы готовятся и когда принимать решения.
          </p>
        </div>
        <div className={`container ${styles.processGrid}`}>
          <article>
            <h3>Старт проекта</h3>
            <p>Формируем команду, проводим стратегическую сессию, собираем артефакты и согласуем календарь.</p>
          </article>
          <article>
            <h3>Проектирование</h3>
            <p>Готовим карты путей, прототипы, сценарии. Тестируем гипотезы и собираем обратную связь.</p>
          </article>
          <article>
            <h3>Разработка и запуск</h3>
            <p>Собираем интерфейсы, интегрируем сервисы, проводим тестирование, готовим инструкции и поддержку.</p>
          </article>
          <article>
            <h3>Рост и поддержка</h3>
            <p>Следим за метриками, запускаем эксперименты, развиваем контент и функциональность.</p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Services;