import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './Home.module.css';
import { blogPosts } from '../data/blogPosts';
import { portfolioItems } from '../data/portfolio';

const servicesPreview = [
  {
    title: 'Концептуальный веб-дизайн',
    description:
      'Создаем визуальные системы, которые транслируют характер бренда и остаются понятными пользователям.',
    image: 'https://picsum.photos/800/600?random=102'
  },
  {
    title: 'Продуктовая разработка',
    description:
      'Собираем интерфейсы на современном технологическом стеке, чтобы проект оставался гибким и масштабируемым.',
    image: 'https://picsum.photos/800/600?random=103'
  },
  {
    title: 'UX-исследования и аналитика',
    description:
      'Понимаем мотивацию аудитории через интервью, CJM и юзабилити-тесты, чтобы принимать взвешенные решения.',
    image: 'https://picsum.photos/800/600?random=104'
  },
  {
    title: 'Контент и микроанимации',
    description:
      'Наполняем интерфейсы живыми историями и динамикой, которые удерживают внимание и вызывают эмоцию.',
    image: 'https://picsum.photos/800/600?random=105'
  }
];

const processSteps = [
  {
    name: 'Исследуем контекст',
    detail: 'Погружаемся в бизнес-цели, аудиторию и конкурентную среду, чтобы найти точку фокуса.',
    number: '01'
  },
  {
    name: 'Создаем концепт',
    detail: 'Формируем визуальную и смысловую концепцию, собираем прототипы и сценарии.',
    number: '02'
  },
  {
    name: 'Проектируем детали',
    detail: 'Продумываем дизайн-систему, анимации, микрокопирайтинг и настраиваем логику взаимодействия.',
    number: '03'
  },
  {
    name: 'Разрабатываем и тестируем',
    detail: 'Собираем интерфейсы, подключаем аналитики, проводим тесты на разных устройствах.',
    number: '04'
  },
  {
    name: 'Сопровождаем запуск',
    detail: 'Готовим документацию, обучаем команду и отслеживаем ключевые метрики после релиза.',
    number: '05'
  }
];

const testimonials = [
  {
    name: 'Антон Жарков',
    role: 'Директор по продукту, UrbanLab',
    quote:
      'Команда агентства помогла собрать цифровой сервис, который одинаково удобно использовать архитекторам, жителям и партнерам. Особенно впечатлило внимание к деталям и готовность экспериментировать.',
    photo: 'https://picsum.photos/200/200?random=601'
  },
  {
    name: 'Екатерина Миллер',
    role: 'Куратор образовательных программ, «Город навыков»',
    quote:
      'Редко встречаешь команду, которая одинаково хорошо понимает и бизнес-задачи, и культурную миссию проекта. Благодаря им мы запустили экосистему, которая растет вместе с сообществом.',
    photo: 'https://picsum.photos/200/200?random=602'
  },
  {
    name: 'Илья Горский',
    role: 'CEO, акселератор Vector',
    quote:
      'Мы получили не только сайт, но и аналитический инструмент: личный кабинет, управляемые воронки и понятные отчеты. Коллеги гибко реагировали на изменения и всегда держали нас в курсе.',
    photo: 'https://picsum.photos/200/200?random=603'
  }
];

const teamPreview = [
  {
    name: 'Мария Крылова',
    role: 'Креативный директор',
    description:
      'Собирает визуальные вселенные брендов и следит, чтобы каждая пиксельная деталь работала на идею.',
    photo: 'https://picsum.photos/400/400?random=701'
  },
  {
    name: 'Алексей Григорьев',
    role: 'Tech Lead',
    description:
      'Из любви к чистому коду превращает сложные концепты в быстрые и надежные интерфейсы.',
    photo: 'https://picsum.photos/400/400?random=702'
  },
  {
    name: 'Наталья Титова',
    role: 'Lead UX-исследователь',
    description:
      'Разговаривает с пользователями на их языке и помогает команде слышать настоящие потребности.',
    photo: 'https://picsum.photos/400/400?random=703'
  }
];

const faqList = [
  {
    question: 'Сколько времени занимает разработка сайта с нуля?',
    answer:
      'Средний цикл — от 10 до 14 недель. На скорость влияют объем контента, сложность интеграций и количество заинтересованных сторон. Мы фиксируем чекпоинты и прозрачный роадмап, чтобы процесс был управляемым.'
  },
  {
    question: 'Вы помогаете с наполнением и запуском?',
    answer:
      'Да, мы готовим контентные гайды, обучаем вашу команду работе с админкой, подключаем аналитику и сопровождаем запуск, чтобы все прошло спокойно.'
  },
  {
    question: 'Можно ли стартовать с исследования, а дизайн подключить позже?',
    answer:
      'Конечно. Часто мы начинаем с исследований и прототипов, чтобы сформировать видение, а дизайн и разработку подключаем, когда команда готова двигаться дальше.'
  }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState({
    projects: 0,
    partners: 0,
    scenarios: 0,
    satisfaction: 0
  });

  useEffect(() => {
    const target = {
      projects: 128,
      partners: 26,
      scenarios: 48,
      satisfaction: 97
    };
    const duration = 1600;
    const start = performance.now();

    const step = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      setAnimatedStats({
        projects: Math.floor(target.projects * progress),
        partners: Math.floor(target.partners * progress),
        scenarios: Math.floor(target.scenarios * progress),
        satisfaction: Math.floor(target.satisfaction * progress)
      });
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };

    requestAnimationFrame(step);
  }, []);

  const featuredProjects = useMemo(
    () => portfolioItems.filter((project) => project.featured).slice(0, 3),
    []
  );
  const latestPosts = useMemo(() => blogPosts.slice(0, 3), []);
  const [activeFaqIndex, setActiveFaqIndex] = useState(0);

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: '🎨 Сколько вариантов сайта создать?',
    url: 'https://www.skolko-variantov.ru',
    logo: 'https://picsum.photos/200/200?random=999',
    email: 'info@skolko-variantov.ru',
    telephone: '+7 (495) 123-45-67',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'ул. Тверская, д. 15, офис 304',
      addressLocality: 'Москва',
      postalCode: '125009',
      addressCountry: 'RU'
    },
    sameAs: [
      'https://www.behance.net',
      'https://dribbble.com',
      'https://www.linkedin.com'
    ]
  };

  return (
    <div className={styles.page}>
      <MetaTags
        title="Создаем уникальные цифровые впечатления — 🎨 Сколько вариантов сайта создать?"
        description="Креативное агентство из Москвы. Проектируем и разрабатываем сайты, которые помогают брендам раскрывать потенциал, говорить с аудиторией и добиваться измеримых результатов."
        keywords="разработка сайта, креативное агентство, UX, UI, цифровая стратегия, дизайн"
        ogTitle="🎨 Сколько вариантов сайта создать? — Создаем уникальные цифровые впечатления"
        ogDescription="Наша команда объединяет исследователей, дизайнеров и разработчиков, чтобы создавать цифровые продукты, к которым хочется возвращаться."
        ogImage="https://picsum.photos/1200/630?random=101"
        ogUrl="https://www.skolko-variantov.ru/"
        canonical="https://www.skolko-variantov.ru/"
        schema={schema}
      />
      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <p className={styles.kicker}>Креативное агентство полного цикла</p>
            <h1 className={styles.title}>Создаем уникальные цифровые впечатления</h1>
            <p className={styles.subtitle}>
              Мы помогаем брендам звучать громче, благодаря сайтам, где эстетика связана с логикой, а технологии поддерживают смысл. Работаем с компаниями, у которых есть история и амбиции.
            </p>
            <div className={styles.ctaGroup}>
              <Link className={styles.primaryCta} to="/kontakty">
                Обсудить идею
              </Link>
              <Link className={styles.secondaryCta} to="/portfolio">
                Смотреть кейсы
              </Link>
            </div>
            <ul className={styles.heroBadges}>
              <li>Индивидуальные дизайн-системы</li>
              <li>Комплексное исследование пользователей</li>
              <li>Поддержка после запуска</li>
            </ul>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/1600/900?random=110"
              alt="Команда агентства помогает клиенту формировать цифровую стратегию"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Основные показатели">
        <div className={`container ${styles.statsGrid}`}>
          <div className={styles.statCard}>
            <span className={styles.statNumber}>{animatedStats.projects}+</span>
            <p className={styles.statLabel}>проектов преобразили бренды клиента в цифре</p>
          </div>
          <div className={styles.statCard}>
            <span className={styles.statNumber}>{animatedStats.partners}</span>
            <p className={styles.statLabel}>партнёров работают с нами на постоянной основе</p>
          </div>
          <div className={styles.statCard}>
            <span className={styles.statNumber}>{animatedStats.scenarios}</span>
            <p className={styles.statLabel}>новых сценариев взаимодействия запущено за год</p>
          </div>
          <div className={styles.statCard}>
            <span className={styles.statNumber}>{animatedStats.satisfaction}%</span>
            <p className={styles.statLabel}>команд отмечают рост удовлетворенности пользователей</p>
          </div>
        </div>
      </section>

      <section className={styles.services} id="services">
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Наши компетенции</p>
            <h2>Ведем проект от замысла до устойчивого результата</h2>
          </div>
          <p className={styles.sectionText}>
            В работе мы комбинируем стратегию, дизайн, разработку и контент. Команда быстро подключается к вашему бизнесу, погружается в контекст и предлагает решения, которые остаются актуальными в долгосрочной перспективе.
          </p>
        </div>
        <div className={`container ${styles.servicesGrid}`}>
          {servicesPreview.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <div className={styles.serviceImageWrapper}>
                <img src={service.image} alt={service.title} loading="lazy" />
              </div>
              <div className={styles.serviceBody}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </div>
            </article>
          ))}
        </div>
        <div className={`container ${styles.sectionFooter}`}>
          <Link to="/uslugi" className={styles.linkButton}>
            Смотреть все услуги
          </Link>
        </div>
      </section>

      <section className={styles.portfolio}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Избранные работы</p>
            <h2>Проекты, которыми гордимся</h2>
          </div>
          <p className={styles.sectionText}>
            Каждый проект — это совместное путешествие с клиентом. Мы делимся процессом, вовлекаем команду стороны и фокусируемся на метриках, которые действительно важны.
          </p>
        </div>
        <div className={`container ${styles.projectGrid}`}>
          {featuredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <p className={styles.projectMeta}>
                  {project.category} · {project.year}
                </p>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <ul className={styles.projectTags}>
                  {project.services.map((service) => (
                    <li key={service}>{service}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
        <div className={`container ${styles.sectionFooter}`}>
          <Link to="/portfolio" className={styles.linkButton}>
            Все кейсы
          </Link>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Почему выбирают нас</p>
            <h2>Мы работаем как расширенная команда клиента</h2>
          </div>
        </div>
        <div className={`container ${styles.advGrid}`}>
          <article className={styles.advCard}>
            <h3>Ныряем в контекст</h3>
            <p>Разбираемся в продукте, терминологии и потребностях ваших пользователей, чтобы предлагать релевантные идеи и не тратить время на догадки.</p>
          </article>
          <article className={styles.advCard}>
            <h3>Прозрачные процессы</h3>
            <p>У нас есть четкие чекпоинты, статусные встречи и единый рабочий бэклог. Вы всегда понимаете, на каком этапе проект и что произойдет дальше.</p>
          </article>
          <article className={styles.advCard}>
            <h3>Внимание к деталям</h3>
            <p>Мы думаем о тексте, микроанимациях, состояниях ошибок и пустых экранов. Просто красивого макета недостаточно.</p>
          </article>
          <article className={styles.advCard}>
            <h3>Команда для долгой дистанции</h3>
            <p>После релиза продолжаем развивать проект: анализируем метрики, предлагаем гипотезы и поддерживаем дизайн-систему.</p>
          </article>
        </div>
      </section>

      <section className={styles.process}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Как мы работаем</p>
            <h2>От инсайта к живому цифровому продукту</h2>
          </div>
          <p className={styles.sectionText}>
            У каждого проекта свой сценарий, но есть этапы, которые неизменны. Мы делимся ими заранее, чтобы вам было комфортно планировать ресурсы и вовлекать коллег.
          </p>
        </div>
        <div className={`container ${styles.processGrid}`}>
          {processSteps.map((step) => (
            <article key={step.number} className={styles.processCard}>
              <span className={styles.processNumber}>{step.number}</span>
              <h3>{step.name}</h3>
              <p>{step.detail}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Отзывы</p>
            <h2>Партнеры о работе с нами</h2>
          </div>
        </div>
        <div className={`container ${styles.testimonialGrid}`}>
          {testimonials.map((testimonial) => (
            <article key={testimonial.name} className={styles.testimonialCard}>
              <div className={styles.testimonialHead}>
                <img src={testimonial.photo} alt={testimonial.name} loading="lazy" />
                <div>
                  <p className={styles.testimonialName}>{testimonial.name}</p>
                  <p className={styles.testimonialRole}>{testimonial.role}</p>
                </div>
              </div>
              <p className={styles.testimonialQuote}>{testimonial.quote}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Команда</p>
            <h2>Люди, которые любят сложные задачи</h2>
          </div>
          <p className={styles.sectionText}>
            Мы собираем в проект только тех специалистов, которые необходимы для результата: от исследователей и UX-архитекторов до motion-дизайнеров и разработчиков.
          </p>
        </div>
        <div className={`container ${styles.teamGrid}`}>
          {teamPreview.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImage}>
                <img src={member.photo} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.teamBody}>
                <p className={styles.teamName}>{member.name}</p>
                <p className={styles.teamRole}>{member.role}</p>
                <p className={styles.teamDescription}>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>FAQ</p>
            <h2>Ответы на популярные вопросы</h2>
          </div>
        </div>
        <div className={`container ${styles.faqList}`}>
          {faqList.map((item, index) => (
            <div key={item.question} className={styles.faqItem}>
              <button
                type="button"
                className={styles.faqButton}
                onClick={() => setActiveFaqIndex(index === activeFaqIndex ? -1 : index)}
                aria-expanded={index === activeFaqIndex}
              >
                <span>{item.question}</span>
                <span className={styles.faqIcon}>{index === activeFaqIndex ? '−' : '+'}</span>
              </button>
              {index === activeFaqIndex && <p className={styles.faqAnswer}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={`container ${styles.sectionHeader}`}>
          <div>
            <p className={styles.kicker}>Блог</p>
            <h2>Свежие заметки из нашей мастерской</h2>
          </div>
          <p className={styles.sectionText}>
            Мы делимся практикой и наблюдениями: от методик пользовательских исследований до лайфхаков анимации интерфейсов.
          </p>
        </div>
        <div className={`container ${styles.blogGrid}`}>
          {latestPosts.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogBody}>
                <p className={styles.blogMeta}>
                  {post.category} · {new Date(post.date).toLocaleDateString('ru-RU')}
                </p>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/blog" className={styles.blogLink}>
                  Читать в блоге
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={`container ${styles.ctaInner}`}>
          <div>
            <h2>Готовы придать форму вашим идеям?</h2>
            <p>
              Расскажите нам о задаче, и мы предложим маршрут: проведем экспресс-диагностику текущего сайта или соберем план с нуля.
            </p>
          </div>
          <Link to="/kontakty" className={styles.primaryCta}>
            Заполнить бриф
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;