const CASE_DATA = [
  {
    id: 'neon-storm',
    name: 'Неоновый Шторм',
    price: 189,
    rarityChances: { common: 0.48, uncommon: 0.28, rare: 0.15, epic: 0.07, legendary: 0.02 },
    image: 'https://picsum.photos/600/400?random=csgo-neon',
    description: 'Эксплозия киберпанка и неоновых акцентов для тех, кто хочет выделяться.',
    items: ['ak-neon', 'glock-vortex', 'm4a1-quantum', 'karambit-synth', 'deagle-plasma', 'famas-holo']
  },
  {
    id: 'tactical-elite',
    name: 'Тактическая Элита',
    price: 249,
    rarityChances: { common: 0.4, uncommon: 0.3, rare: 0.18, epic: 0.09, legendary: 0.03 },
    image: 'https://picsum.photos/600/400?random=csgo-tactical',
    description: 'Чистые линии и военная эстетика для профессионалов.',
    items: ['ak-obsidian', 'usp-cyrex', 'awp-cobalt', 'knife-ember', 'mp7-phantom', 'galil-carbon']
  },
  {
    id: 'frost-rupture',
    name: 'Арктический Разлом',
    price: 149,
    rarityChances: { common: 0.52, uncommon: 0.27, rare: 0.13, epic: 0.06, legendary: 0.02 },
    image: 'https://picsum.photos/600/400?random=csgo-frost',
    description: 'Ледяные текстуры и холодные градиенты для морозной доминации.',
    items: ['ak-glacier', 'ssg-polar', 'five-seven-crystal', 'knife-aurora', 'tec9-ice', 'mac10-frostbite']
  }
];

const ITEM_DATA = [
  { id: 'ak-neon', name: 'AK-47 «Неоновый Гонщик»', rarity: 'legendary', basePrice: 3899, caseId: 'neon-storm', image: 'https://picsum.photos/400/400?random=ak-neon' },
  { id: 'glock-vortex', name: 'Glock-18 «Вихрь»', rarity: 'rare', basePrice: 699, caseId: 'neon-storm', image: 'https://picsum.photos/400/400?random=glock-vortex' },
  { id: 'm4a1-quantum', name: 'M4A1-S «Квант»', rarity: 'epic', basePrice: 1890, caseId: 'neon-storm', image: 'https://picsum.photos/400/400?random=m4a1-quantum' },
  { id: 'karambit-synth', name: 'Керамбит «Синтвейв»', rarity: 'legendary', basePrice: 15490, caseId: 'neon-storm', image: 'https://picsum.photos/400/400?random=karambit-synth' },
  { id: 'deagle-plasma', name: 'Desert Eagle «Плазма»', rarity: 'epic', basePrice: 2390, caseId: 'neon-storm', image: 'https://picsum.photos/400/400?random=deagle-plasma' },
  { id: 'famas-holo', name: 'FAMAS «Голограмма»', rarity: 'uncommon', basePrice: 420, caseId: 'neon-storm', image: 'https://picsum.photos/400/400?random=famas-holo' },
  { id: 'ak-obsidian', name: 'AK-47 «Оникс»', rarity: 'epic', basePrice: 3290, caseId: 'tactical-elite', image: 'https://picsum.photos/400/400?random=ak-obsidian' },
  { id: 'usp-cyrex', name: 'USP-S «Cyrex»', rarity: 'rare', basePrice: 890, caseId: 'tactical-elite', image: 'https://picsum.photos/400/400?random=usp-cyrex' },
  { id: 'awp-cobalt', name: 'AWP «Кобальт»', rarity: 'legendary', basePrice: 7690, caseId: 'tactical-elite', image: 'https://picsum.photos/400/400?random=awp-cobalt' },
  { id: 'knife-ember', name: 'Bayonet «Ember Fade»', rarity: 'legendary', basePrice: 18990, caseId: 'tactical-elite', image: 'https://picsum.photos/400/400?random=knife-ember' },
  { id: 'mp7-phantom', name: 'MP7 «Фантом»', rarity: 'uncommon', basePrice: 360, caseId: 'tactical-elite', image: 'https://picsum.photos/400/400?random=mp7-phantom' },
  { id: 'galil-carbon', name: 'Galil AR «Carbon»', rarity: 'common', basePrice: 120, caseId: 'tactical-elite', image: 'https://picsum.photos/400/400?random=galil-carbon' },
  { id: 'ak-glacier', name: 'AK-47 «Глетчер»', rarity: 'rare', basePrice: 990, caseId: 'frost-rupture', image: 'https://picsum.photos/400/400?random=ak-glacier' },
  { id: 'ssg-polar', name: 'SSG 08 «Полярис»', rarity: 'uncommon', basePrice: 250, caseId: 'frost-rupture', image: 'https://picsum.photos/400/400?random=ssg-polar' },
  { id: 'five-seven-crystal', name: 'Five-SeveN «Кристалл»', rarity: 'rare', basePrice: 580, caseId: 'frost-rupture', image: 'https://picsum.photos/400/400?random=fiveseven-crystal' },
  { id: 'knife-aurora', name: 'Navaja «Aurora Borealis»', rarity: 'legendary', basePrice: 11200, caseId: 'frost-rupture', image: 'https://picsum.photos/400/400?random=knife-aurora' },
  { id: 'tec9-ice', name: 'Tec-9 «Icebreaker»', rarity: 'common', basePrice: 90, caseId: 'frost-rupture', image: 'https://picsum.photos/400/400?random=tec9-ice' },
  { id: 'mac10-frostbite', name: 'MAC-10 «Frostbite»', rarity: 'epic', basePrice: 1490, caseId: 'frost-rupture', image: 'https://picsum.photos/400/400?random=mac10-frost' }
];

const RARITY_ORDER = ['common', 'uncommon', 'rare', 'epic', 'legendary'];

const RARITY_LABELS = {
  common: 'Обычный',
  uncommon: 'Необычный',
  rare: 'Редкий',
  epic: 'Эпический',
  legendary: 'Легендарный'
};

const centerIndex = 2;
const itemWidth = 150 + 18;

const inventoryKey = 'virtual_inventory';

document.addEventListener('DOMContentLoaded', () => {
  highlightCurrentNav();
  initCookieBanner();
  initCaseOpening();
  renderCases();
  renderItemsTable();
  animateMetrics();
});

/* Navigation active link */
function highlightCurrentNav() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('[data-nav-link]').forEach(link => {
    const href = link.getAttribute('href');
    if (href === path || (path === '' && href === 'index.html')) {
      link.classList.add('is-active');
    }
  });
}

/* Cookie banner */
function initCookieBanner() {
  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const storageKey = 'cookieConsent';
  const saved = localStorage.getItem(storageKey);
  if (!saved) {
    requestAnimationFrame(() => {
      banner.classList.add('is-visible');
    });
  }

  banner.addEventListener('click', (event) => {
    if (event.target.matches('[data-cookie-accept]')) {
      localStorage.setItem(storageKey, 'accepted');
      hideBanner();
    }
    if (event.target.matches('[data-cookie-decline]')) {
      localStorage.setItem(storageKey, 'declined');
      hideBanner();
    }
  });

  function hideBanner() {
    banner.classList.remove('is-visible');
    setTimeout(() => banner.remove(), 300);
  }
}

/* Case opening simulator */
function initCaseOpening() {
  const wheel = document.querySelector('.case-wheel-track');
  const resultBox = document.querySelector('[data-result]');
  const inventoryList = document.querySelector('[data-inventory]');
  const openBtn = document.querySelector('[data-open-case]');
  const caseSelect = document.querySelector('[data-case-select]');
  const statsEl = document.querySelector('[data-case-stats]');

  if (!wheel || !resultBox || !openBtn || !caseSelect) return;

  CASE_DATA.forEach(cs => {
    const option = document.createElement('option');
    option.value = cs.id;
    option.textContent = `${cs.name} — ${cs.price} ₽`;
    caseSelect.appendChild(option);
  });

  caseSelect.value = CASE_DATA[0].id;
  updateStats();

  let isSpinning = false;

  openBtn.addEventListener('click', () => {
    if (isSpinning) return;
    isSpinning = true;
    const selectedCase = CASE_DATA.find(cs => cs.id === caseSelect.value);
    const resultItem = rollItem(selectedCase);
    buildWheel(wheel, selectedCase, resultItem);
    requestAnimationFrame(() => {
      wheel.style.transition = 'none';
      wheel.style.transform = 'translateX(0)';
      requestAnimationFrame(() => {
        wheel.style.transition = 'transform 4.2s cubic-bezier(0.12, 0.85, 0.28, 1)';
        const totalCards = wheel.children.length;
        const resultIndex = totalCards - 1;
        const offset = Math.max(0, (resultIndex - centerIndex) * itemWidth);
        wheel.style.transform = `translateX(-${offset}px)`;
      });
    });

    wheel.addEventListener('transitionend', onFinish, { once: true });

    function onFinish() {
      displayResult(resultItem);
      addToInventory(resultItem);
      renderInventory(inventoryList);
      playRewardSound(resultItem.rarity);
      isSpinning = false;
    }
  });

  caseSelect.addEventListener('change', updateStats);

  renderInventory(inventoryList);

  function updateStats() {
    const selectedCase = CASE_DATA.find(cs => cs.id === caseSelect.value);
    if (!selectedCase || !statsEl) return;
    statsEl.innerHTML = RARITY_ORDER.map(rarity => {
      const percent = Math.round(selectedCase.rarityChances[rarity] * 1000) / 10;
      return `<span class="tag tag-${rarity}">${RARITY_LABELS[rarity]} — ${percent}%</span>`;
    }).join('');
  }

  function buildWheel(container, selectedCase, resultItem) {
    container.innerHTML = '';
    const poolItems = selectedCase.items.map(id => ITEM_DATA.find(it => it.id === id)).filter(Boolean);
    const sequence = [];
    for (let i = 0; i < 28; i++) {
      sequence.push(randomFrom(poolItems));
    }
    sequence.push(resultItem);

    sequence.forEach(item => {
      const card = document.createElement('div');
      card.className = `wheel-item rarity-${item.rarity}`;
      card.innerHTML = `
        <strong>${item.name.split(' «')[0]}</strong>
        <small>${RARITY_LABELS[item.rarity]}</small>
        <span class="badge">${item.basePrice.toLocaleString('ru-RU')} ₽</span>
      `;
      container.appendChild(card);
    });
  }

  function displayResult(item) {
    resultBox.innerHTML = `
      <span class="badge badge-live"><span class="status-dot"></span> Вы выбили</span>
      <h3 class="highlight">${item.name}</h3>
      <p class="rarity-text">${RARITY_LABELS[item.rarity]} уровень редкости • Рыночная стоимость: ${item.basePrice.toLocaleString('ru-RU')} ₽</p>
    `;
  }
}

function rollItem(selectedCase) {
  const weights = selectedCase.rarityChances;
  const roll = Math.random();
  let cumulative = 0;
  let chosenRarity = 'common';
  for (const rarity of RARITY_ORDER) {
    cumulative += weights[rarity];
    if (roll <= cumulative) {
      chosenRarity = rarity;
      break;
    }
  }
  const availableItems = selectedCase.items
    .map(id => ITEM_DATA.find(it => it.id === id && it.rarity === chosenRarity))
    .filter(Boolean);
  return availableItems.length ? randomFrom(availableItems) : ITEM_DATA.find(it => selectedCase.items.includes(it.id));
}

function randomFrom(array) {
  return array[Math.floor(Math.random() * array.length)];
}

/* Inventory handling */
function getInventory() {
  try {
    const saved = localStorage.getItem(inventoryKey);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

function saveInventory(items) {
  localStorage.setItem(inventoryKey, JSON.stringify(items));
}

function addToInventory(item) {
  const items = getInventory();
  const newEntry = {
    id: crypto.randomUUID(),
    baseId: item.id,
    name: item.name,
    rarity: item.rarity,
    timestamp: Date.now(),
    price: item.basePrice
  };
  items.unshift(newEntry);
  saveInventory(items.slice(0, 20));
}

function renderInventory(container) {
  if (!container) return;
  const items = getInventory();
  if (!items.length) {
    container.innerHTML = `<p>Ваш инвентарь пуст. Откройте кейс, чтобы пополнить коллекцию.</p>`;
    return;
  }
  container.innerHTML = items.map(entry => `
    <article class="inventory-card rarity-${entry.rarity}">
      <strong>${entry.name}</strong>
      <span class="tag tag-${entry.rarity}">${RARITY_LABELS[entry.rarity]}</span>
      <small>Стоимость: ${entry.price.toLocaleString('ru-RU')} ₽</small>
      <small>Получено: ${new Date(entry.timestamp).toLocaleString('ru-RU')}</small>
    </article>
  `).join('');
}

/* Render cases on catalog page */
function renderCases() {
  const grid = document.querySelector('[data-case-grid]');
  if (!grid) return;
  grid.innerHTML = CASE_DATA.map(cs => {
    const items = cs.items.map(id => ITEM_DATA.find(item => item.id === id)).filter(Boolean);
    const legendaryCount = items.filter(item => item.rarity === 'legendary').length;
    return `
      <article class="case-card">
        <img src="${cs.image}" alt="${cs.name}" loading="lazy">
        <div>
          <h3>${cs.name}</h3>
          <p>${cs.description}</p>
        </div>
        <div class="case-meta">
          <span class="badge">Цена: ${cs.price} ₽</span>
          <span class="tag tag-legendary">Легендарных: ${legendaryCount}</span>
        </div>
        <div class="case-meta">
          ${RARITY_ORDER.map(rarity => {
            const percent = Math.round(cs.rarityChances[rarity] * 1000) / 10;
            return `<span class="tag tag-${rarity}">${percent}% ${RARITY_LABELS[rarity]}</span>`;
          }).join('')}
        </div>
        <small>Предметы: ${items.map(it => it.name).join(', ')}</small>
      </article>
    `;
  }).join('');
}

/* Render items table */
function renderItemsTable() {
  const target = document.querySelector('[data-items-table]');
  if (!target) return;
  const rows = ITEM_DATA.map(item => {
    const parentCase = CASE_DATA.find(cs => cs.id === item.caseId);
    return `
      <tr class="rarity-${item.rarity}">
        <td>${item.name}</td>
        <td><span class="tag tag-${item.rarity}">${RARITY_LABELS[item.rarity]}</span></td>
        <td>${item.basePrice.toLocaleString('ru-RU')} ₽</td>
        <td>${parentCase ? parentCase.name : '—'}</td>
      </tr>
    `;
  }).join('');
  target.innerHTML = rows;
}

/* Metrics count-up */
function animateMetrics() {
  document.querySelectorAll('[data-count-up]').forEach(el => {
    const target = parseInt(el.dataset.countUp, 10);
    if (Number.isNaN(target)) return;
    let current = 0;
    const duration = 1800;
    const startTime = performance.now();

    function update(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      current = Math.floor(progress * target);
      el.textContent = current.toLocaleString('ru-RU');
      if (progress < 1) requestAnimationFrame(update);
    }

    requestAnimationFrame(update);
  });
}

/* Audio feedback */
function playRewardSound(rarity) {
  if (!window.AudioContext && !window.webkitAudioContext) return;
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const oscillator = ctx.createOscillator();
  const gain = ctx.createGain();
  oscillator.type = 'triangle';
  const baseFreq = { common: 320, uncommon: 360, rare: 420, epic: 500, legendary: 620 }[rarity] || 320;
  oscillator.frequency.setValueAtTime(baseFreq, ctx.currentTime);
  gain.gain.setValueAtTime(0.001, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.7);
  oscillator.connect(gain).connect(ctx.destination);
  oscillator.start();
  oscillator.stop(ctx.currentTime + 0.7);
}