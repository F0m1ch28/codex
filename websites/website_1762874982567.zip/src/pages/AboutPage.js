import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './GenericPage.module.css';

const milestones = [
  { title: 'Gründung 2019', text: 'Lumetranova startet mit der Vision, Büroflächen datenbasiert zu steuern.' },
  { title: 'Launch Sensor Suite 2021', text: 'Integration von Präsenz-, Klima- und Energie-Sensoren mit eigenen Dashboards.' },
  { title: 'Expansion 2023', text: 'Rollout in fünf europäischen Metropolen und Ausbau des Partner-Netzwerks.' }
];

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Über Lumetranova</title>
      <meta name="description" content="Erfahren Sie mehr über Lumetranova: Mission, Team und Entwicklung der Smart-Office-Plattform." />
    </Helmet>
    <header className={styles.header}>
      <h1>Über Lumetranova</h1>
      <p>Wir verbinden Technologie, Architektur und Nachhaltigkeit zu intelligenten Arbeitswelten.</p>
    </header>
    <section className={styles.section}>
      <h2>Mission</h2>
      <p>Lumetranova hilft Organisationen, hybride Arbeitsmodelle, Sicherheit und Energieeffizienz nahtlos zu vereinen. Unsere Plattform analysiert Echtzeitdaten und verwandelt sie in konkrete Entscheidungen – für Mitarbeitende, Facility-Teams und Führung.</p>
    </section>
    <section className={styles.section}>
      <h2>Meilensteine</h2>
      <div className={styles.timeline}>
        {milestones.map((milestone) => (
          <div key={milestone.title} className={styles.timelineItem}>
            <span>{milestone.title}</span>
            <p>{milestone.text}</p>
          </div>
        ))}
      </div>
    </section>
    <section className={styles.section}>
      <h2>Werte</h2>
      <ul className={styles.list}>
        <li>Transparenz in Daten und Entscheidungen.</li>
        <li>Inklusive, barrierefreie Nutzererlebnisse.</li>
        <li>Security-by-Design und Privacy-by-Default.</li>
        <li>Partnerschaften mit Architekt:innen, CRE-Teams und IT.</li>
      </ul>
    </section>
  </div>
);

export default AboutPage;