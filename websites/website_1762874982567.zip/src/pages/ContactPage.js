import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './KontaktPage.module.css';

const initialState = { name: '', email: '', company: '', message: '', newsletter: false };

const ContactPage = () => {
  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const scriptId = 'recaptcha-v2';
    if (document.getElementById(scriptId)) return;
    const script = document.createElement('script');
    script.id = scriptId;
    script.src = 'https://www.google.com/recaptcha/api.js';
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);
  }, []);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    if (!form.company.trim()) newErrors.company = 'Bitte nennen Sie Ihr Unternehmen.';
    if (!form.message.trim()) newErrors.message = 'Bitte teilen Sie uns Ihr Anliegen mit.';
    if (!document.querySelector('.g-recaptcha-response')?.value) newErrors.recaptcha = 'Bitte bestätigen Sie den reCAPTCHA.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setForm(initialState);
    // Hier würde ein API-Call erfolgen
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | Lumetranova</title>
        <meta
          name="description"
          content="Kontaktieren Sie Lumetranova: Demo, Beratung oder Support für Ihre Smart-Office-Strategie."
        />
        <meta
          name="keywords"
          content="smart office kontakt, demo anfordern, lumetranova berlin"
        />
      </Helmet>
      <div className={styles.container}>
        <header className={styles.header}>
          <h1>Kontakt &amp; Demo</h1>
          <p>Wir freuen uns auf Ihre Anfrage – innerhalb von 24 Stunden melden wir uns mit Terminvorschlägen.</p>
        </header>

        <div className={styles.grid}>
          <section className={styles.card} aria-labelledby="kontakt-formular">
            <h2 id="kontakt-formular">Nachricht senden</h2>
            <p>Teilen Sie uns Ihr Projekt mit. Wir planen gerne eine individualisierte Demo – inklusive Double-Opt-In für Benachrichtigungen.</p>
            {submitted && (
              <div className={styles.success} role="status">
                Vielen Dank! Bitte prüfen Sie Ihren Posteingang und bestätigen Sie unsere Double-Opt-In-Mail, damit wir Ihnen Unterlagen senden können.
              </div>
            )}
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Name*</label>
                <input
                  id="name"
                  className={styles.input}
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">E-Mail*</label>
                <input
                  id="email"
                  className={styles.input}
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="company">Unternehmen*</label>
                <input
                  id="company"
                  className={styles.input}
                  type="text"
                  value={form.company}
                  onChange={(e) => setForm({ ...form, company: e.target.value })}
                  aria-invalid={Boolean(errors.company)}
                />
                {errors.company && <span className={styles.error}>{errors.company}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Nachricht*</label>
                <textarea
                  id="message"
                  className={styles.textarea}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={form.newsletter}
                  onChange={(e) => setForm({ ...form, newsletter: e.target.checked })}
                  aria-label="Newsletter abonnieren"
                />
                <span>Ich möchte optionale Updates zu Smart-Office-Trends erhalten (Double-Opt-In).</span>
              </label>
              <div className="g-recaptcha" data-sitekey="your-site-key" />
              {errors.recaptcha && <span className={styles.error}>{errors.recaptcha}</span>}
              <button type="submit" className={styles.submit}>Absenden</button>
            </form>
          </section>

          <section className={styles.card} aria-labelledby="kontakt-infos">
            <h2 id="kontakt-infos">Kontaktinformationen</h2>
            <ul className={styles.meta}>
              <li><strong>Adresse:</strong> Alexanderstraße 5, 10178 Berlin, Deutschland</li>
              <li><strong>Telefon:</strong> <a href="tel:+493012345678">+49 30 1234 5678</a></li>
              <li><strong>E-Mail:</strong> <a href="mailto:hello@lumetranova.com">hello@lumetranova.com</a></li>
            </ul>
            <p>Unser HQ befindet sich in unmittelbarer Nähe zum Alexanderplatz. Besucher melden sich über das digitale Empfangsterminal an.</p>
            <div className={styles.map} role="presentation">
              <iframe
                title="Lumetranova Standort Berlin"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.8094337002823!2d13.413215!3d52.521918!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a84e1f257a7c2b%3A0x9c63a64a6b740249!2sAlexanderstra%C3%9Fe%205%2C%2010178%20Berlin!5e0!3m2!1sde!2sde!4v1700000000000!5m2!1sde!2sde"
                width="100%"
                height="340"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;