import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './GenericPage.module.css';

const featureDetails = [
  {
    title: 'Raumbuchung',
    description: 'Visuelle Buchungstabellen, Ressourcen-Checks, automatische Freigaben und Integration in Outlook sowie Google Calendar.'
  },
  {
    title: 'Desk-Booking',
    description: 'Zones, Neighborhoods, QR-Check-in und flexible Regeln für Hybrid Teams inklusive Self-Service App.'
  },
  {
    title: 'IoT-Sensorik & Live-Belegung',
    description: 'Präsenz-, CO₂-, Temperatur- und Energie-Sensoren liefern Echtzeitdaten in interaktiven Heatmaps und Dashboards.'
  },
  {
    title: 'Besucher & Zutritt',
    description: 'Digitale Empfangsprozesse mit Voranmeldung, Badge-Printing, NDA-Signaturen und automatischer Zutrittsvergabe.'
  },
  {
    title: 'Energie-Monitoring',
    description: 'Submetering, Spitzenlast-Alarmierung, Wärmepumpensteuerung und Szenarien zur Verbrauchsoptimierung.'
  },
  {
    title: 'Analytics',
    description: 'Workplace Analytics mit Forecasts, Szenarioplanung und Tenant-übergreifenden Reports.'
  },
  {
    title: 'RBAC',
    description: 'Granulare Rollenprofile, SAML SSO, SCIM Provisioning und Audit Logs für jede Aktion im System.'
  }
];

const FunktionenPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Funktionen | Lumetranova Plattform</title>
      <meta
        name="description"
        content="Alle Funktionen von Lumetranova im Überblick: Raumbuchung, Desk-Booking, IoT-Sensorik, Besucherprozesse, Energie-Monitoring, Analytics und RBAC."
      />
      <meta
        name="keywords"
        content="smart office, raumbuchung, desk booking, belegungssensoren, energie monitoring, besuchermanagement, zutrittskontrolle, workplace analytics, flächeneffizienz, dsgvo, saml sso, scim"
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Funktionen im Überblick</h1>
      <p>Eine modulare Smart-Office-Suite für alle Touchpoints von Mitarbeitenden, Gästen und Gebäuden.</p>
    </header>
    <section className={styles.grid} aria-label="Funktionen">
      {featureDetails.map((feature) => (
        <article key={feature.title} className={styles.card}>
          <h3>{feature.title}</h3>
          <p>{feature.description}</p>
        </article>
      ))}
    </section>
    <section className={styles.section}>
      <h2>Visualisierungen &amp; Dashboards</h2>
      <p>Der zentrale Workplace Hub verbindet Kalender, Buchungen, Live-Heatmaps, Energiegraphs und Besucherflows – alles mit klarer Typografie und Barrierefreiheit (WCAG AA).</p>
      <ul className={styles.list}>
        <li>Kalender mit Tages-, Wochen- und Teamansicht inklusive Drag &amp; Drop.</li>
        <li>Heatmaps für Belegung, Energie und Komfort mit Zonenfilter.</li>
        <li>Sensor-Dashboards mit Drill-Down bis auf Flächentyp und Uhrzeit.</li>
        <li>Grafiken für Energieverbrauch, Prognosen und Einsparpotenziale.</li>
      </ul>
    </section>
  </div>
);

export default FunktionenPage;