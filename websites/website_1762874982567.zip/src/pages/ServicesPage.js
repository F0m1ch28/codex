import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './GenericPage.module.css';

const services = [
  {
    title: 'Smart Office Advisory',
    description: 'Workshops für Hybrid-Strategien, Zonierung und Flächenanalysen – inklusive KPI-Definition.'
  },
  {
    title: 'IoT Deployment',
    description: 'Planung, Rollout und Monitoring von Sensoren, Gateways und Netzwerkintegration.'
  },
  {
    title: 'Change & Enablement',
    description: 'Kommunikationspläne, Schulungen, Trainingsportale und Double-Opt-In-Onboarding.'
  },
  {
    title: 'Data & Analytics Services',
    description: 'Custom Dashboards, API-Integrationen und Predictive Modelle für Portfolioentscheidungen.'
  }
];

const ServicesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Services | Lumetranova</title>
      <meta
        name="description"
        content="Professional Services für Smart Offices: Advisory, IoT Deployment, Change Management und Analytics."
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Professional Services</h1>
      <p>Unser Team begleitet Sie von der Strategie bis zur langfristigen Adoption.</p>
    </header>
    <section className={styles.grid}>
      {services.map((service) => (
        <article key={service.title} className={styles.card}>
          <h3>{service.title}</h3>
          <p>{service.description}</p>
        </article>
      ))}
    </section>
    <section className={`${styles.section} ${styles.highlight}`}>
      <h2>Projektmethodik</h2>
      <p>Wir arbeiten nach einem bewährten Framework aus Assessment, Design, Pilot und Scale. Jede Phase beinhaltet Checkpoints, Security-Reviews und Updates für Stakeholder – transparent dokumentiert in unserem Project Hub.</p>
    </section>
  </div>
);

export default ServicesPage;