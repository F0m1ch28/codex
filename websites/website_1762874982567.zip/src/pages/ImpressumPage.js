import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPage.module.css';

const ImpressumPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Impressum | Lumetranova</title>
      <meta name="description" content="Impressum der Lumetranova GmbH, Alexanderstraße 5, 10178 Berlin." />
    </Helmet>
    <div className={styles.container}>
      <header className={styles.header}>
        <h1>Impressum</h1>
        <p>Angaben gemäß § 5 TMG</p>
      </header>
      <section className={styles.section}>
        <h2>Verantwortlich</h2>
        <p>Lumetranova GmbH<br />Alexanderstraße 5<br />10178 Berlin<br />Deutschland</p>
        <p>Telefon: <a href="tel:+493012345678">+49 30 1234 5678</a><br />E-Mail: <a href="mailto:hello@lumetranova.com">hello@lumetranova.com</a></p>
      </section>
      <section className={styles.section}>
        <h2>Vertretungsberechtigte Personen</h2>
        <p>Jonas Richter (Geschäftsführer)</p>
      </section>
      <section className={styles.section}>
        <h2>Registereintrag</h2>
        <p>Amtsgericht Berlin-Charlottenburg<br />HRB 123456</p>
      </section>
      <section className={styles.section}>
        <h2>Umsatzsteuer-ID</h2>
        <p>DE 999 999 999</p>
      </section>
      <section className={styles.section}>
        <h2>Haftungsausschluss</h2>
        <p>Die Inhalte dieser Website wurden mit größtmöglicher Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte übernehmen wir keine Gewähr.</p>
      </section>
    </div>
  </div>
);

export default ImpressumPage;