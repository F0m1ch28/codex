import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './GenericPage.module.css';

const useCases = [
  {
    title: 'Hybrid Work',
    description: 'Planbare Teamtage, flexible Buchungen, digitale Check-ins und transparente Auslastung für neue Arbeitsmodelle.'
  },
  {
    title: 'HQ / Hub',
    description: 'Command Center für Headquarter, inklusive Energie- und Sicherheitsmonitoring, Besuche und Concierge-Prozesse.'
  },
  {
    title: 'Compliance & Sicherheit',
    description: 'Zutritts- und Besucherlogs, automatisierte Evakuierungslisten und Rechtevergabe per RBAC & SCIM.'
  },
  {
    title: 'Budget- & Flächeneffizienz',
    description: 'Benchmarks, Flächenanalysen und Szenarien, um Portfolioentscheidungen datenbasiert zu treffen.'
  }
];

const UseCasesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Use Cases | Lumetranova Smart Office</title>
      <meta
        name="description"
        content="Erfahren Sie, wie Lumetranova Hybrid Work, HQ-Steuerung, Compliance & Sicherheit sowie Budget- und Flächeneffizienz ermöglicht."
      />
      <meta
        name="keywords"
        content="smart office, hybrid work, flächeneffizienz, workplace analytics, besuchermanagement, zutrittskontrolle"
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Use Cases</h1>
      <p>Von Hybrid Work bis Compliance – Lumetranova skaliert mit Ihren Anforderungen.</p>
    </header>
    <section className={styles.grid}>
      {useCases.map((item) => (
        <article key={item.title} className={styles.card}>
          <h3>{item.title}</h3>
          <p>{item.description}</p>
        </article>
      ))}
    </section>
    <section className={styles.section}>
      <h2>Messbare Ergebnisse</h2>
      <p>Unternehmen erzielen mit Lumetranova:</p>
      <ul className={styles.list}>
        <li>Bis zu 35% weniger Leerstände durch datenbasierte Desk- und Raumplanung.</li>
        <li>30% weniger Energieverbrauch durch Präsenz- und Klimasteuerung.</li>
        <li>Höhere Experience-Scores bei Besuchenden dank digitaler Journey.</li>
        <li>Audits in Minuten statt Tagen dank zentraler Log-Daten.</li>
      </ul>
    </section>
  </div>
);

export default UseCasesPage;