import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPage.module.css';

const AGBPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>AGB | Lumetranova</title>
      <meta name="description" content="Allgemeine Geschäftsbedingungen der Lumetranova GmbH für die Nutzung der Smart-Office-Plattform." />
    </Helmet>
    <div className={styles.container}>
      <header className={styles.header}>
        <h1>Allgemeine Geschäftsbedingungen</h1>
        <p>Stand: März 2024</p>
      </header>
      <section className={styles.section}>
        <h2>1. Geltungsbereich</h2>
        <p>Diese Bedingungen regeln die Nutzung der Lumetranova Smart-Office-Plattform durch Unternehmen.</p>
      </section>
      <section className={styles.section}>
        <h2>2. Leistungen</h2>
        <p>Lumetranova stellt SaaS-Module für Raumbuchung, Desk-Booking, IoT-Sensorik, Energie-Monitoring, Analytics sowie Besucher- und Zutrittsmanagement bereit.</p>
      </section>
      <section className={styles.section}>
        <h2>3. Zugang &amp; Sicherheit</h2>
        <ul>
          <li>Der Zugang erfolgt per SAML SSO oder gesicherten Logins.</li>
          <li>Der Kunde sorgt für RBAC-konforme Rollenvergabe.</li>
          <li>Audit-Logs stehen mindestens 24 Monate zur Verfügung.</li>
        </ul>
      </section>
      <section className={styles.section}>
        <h2>4. Verfügbarkeit</h2>
        <p>Geplante Wartungsfenster werden rechtzeitig kommuniziert. Incident-Management folgt ITIL-konformen Prozessen.</p>
      </section>
      <section className={styles.section}>
        <h2>5. Datenschutz</h2>
        <p>Die Verarbeitung personenbezogener Daten erfolgt gemäß Auftragsverarbeitungsvertrag und DSGVO.</p>
      </section>
      <section className={styles.section}>
        <h2>6. Haftung</h2>
        <p>Lumetranova haftet für Vorsatz und grobe Fahrlässigkeit. Weitere Haftungsregelungen ergeben sich aus dem Einzelvertrag.</p>
      </section>
      <section className={styles.section}>
        <h2>7. Schlussbestimmungen</h2>
        <p>Es gilt deutsches Recht. Gerichtsstand ist Berlin.</p>
      </section>
    </div>
  </div>
);

export default AGBPage;