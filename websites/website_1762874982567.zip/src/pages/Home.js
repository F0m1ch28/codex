import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Arbeitsflächen optimiert', value: 24000, suffix: ' m²' },
  { label: 'Sensoren online', value: 1850, suffix: '' },
  { label: 'Integrationen aktiv', value: 47, suffix: '' }
];

const benefitCards = [
  {
    title: 'Adaptive Workplace Experience',
    text: 'Raumbuchung, Desk-Booking und Besucherprozesse in einem Interface – mit Live-Status für jede Fläche.',
    icon: '📅'
  },
  {
    title: 'Energie-Intelligenz',
    text: 'IoT-Sensorik und Energie-Monitoring orchestrieren Heizung, Licht und Klima abhängig von echter Belegung.',
    icon: '⚡'
  },
  {
    title: 'DSGVO-Sichere Kontrolle',
    text: 'Rollenbasiertes Rechte- und Zutrittsmanagement verbindet Compliance mit nahtloser Nutzerführung.',
    icon: '🔐'
  }
];

const featureTiles = [
  {
    title: 'Raumbuchung & Kalender',
    description: 'Intuitiver Buchungskalender mit Echtzeit-Heatmaps für alle Räume, inklusive MS365 & Google Sync.',
    detail: 'UI mit Drag & Drop, automatischen Ausstattungs-Checks und Benachrichtigungen.'
  },
  {
    title: 'Desk-Booking & Zonen',
    description: 'Flexible Zonenplanung, QR-Check-in und mobile Buchung für Hybrid Work.',
    detail: 'AI-gestützte Vorschläge auf Basis der Teampräferenzen.'
  },
  {
    title: 'Sensorik & Live-Belegung',
    description: 'LoRaWAN-, BLE- und PoE-Sensoren liefern Live-Auslastung und Komfortwerte.',
    detail: 'Heatmaps, Schwellwerte, Alerts und Benchmark-Dashboards.'
  },
  {
    title: 'Besucher & Zutritt',
    description: 'Self-Service Kioske, Voranmeldung, Ausweiserstellung und SSO-basierte Zugriffsrechte.',
    detail: 'Digitale Signaturen, Escalation-Routes und Sicherheitszonen.'
  },
  {
    title: 'Energie-Monitoring',
    description: 'Submetering, Predictive Insights und Netzlast-Optimierung in einer Übersicht.',
    detail: 'Visualisiert Verbrauch, Spitzenlast und Einsparpotenziale in Echtzeit.'
  },
  {
    title: 'Analytics & Insights',
    description: 'Workplace Analytics mit Szenario-Simulator für Flächeneffizienz.',
    detail: 'Vergleiche von Hybrid-Tagen, Teampräferenzen und ROI-Modellen.'
  }
];

const processSteps = [
  { step: '1', title: 'Analysephase', text: 'Digitaler Zwilling Ihres Campus und Import historischer Buchungsdaten für einen klaren Start.' },
  { step: '2', title: 'Rollout & Enablement', text: 'Geführtes Onboarding mit Playbooks, Schulungen, SCIM-Benutzerbereitstellung und Testlab.' },
  { step: '3', title: 'Live Monitoring', text: 'Dashboards für Occupancy, Energie, Komfort und Visitor Journeys mit individuellen Alerts.' },
  { step: '4', title: 'Optimierung', text: 'Predictive Rebalancing, Szenarioplanung und kontinuierliche Benchmarks mit Customer Success.' }
];

const integrationLogos = [
  { name: 'Microsoft 365', url: 'https://picsum.photos/220/120?random=10', path: '/integrationen' },
  { name: 'Google Workspace', url: 'https://picsum.photos/220/120?random=11', path: '/integrationen' },
  { name: 'Okta', url: 'https://picsum.photos/220/120?random=12', path: '/integrationen' },
  { name: 'Azure AD', url: 'https://picsum.photos/220/120?random=13', path: '/integrationen' },
  { name: 'Slack', url: 'https://picsum.photos/220/120?random=14', path: '/integrationen' },
  { name: 'Teams', url: 'https://picsum.photos/220/120?random=15', path: '/integrationen' }
];

const testimonials = [
  {
    quote: 'Lumetranova gibt uns die Transparenz, um hybride Zusammenarbeit und Energieverbrauch in Einklang zu bringen.',
    name: 'Mara Schulze',
    role: 'Head of Workplace Strategy, Nordlicht Group'
  },
  {
    quote: 'Die Plattform verbindet Desk-Booking, Zutritt und Besucherprozesse ohne Medienbrüche – genau das, was unsere Teams brauchen.',
    name: 'David Krüger',
    role: 'CIO, UrbanTech AG'
  },
  {
    quote: 'Mit den Sensor-Dashboards erkennen wir Auslastungsspitzen frühzeitig und planen Flächen vorausschauend.',
    name: 'Selina Hoffmann',
    role: 'Director Real Estate, Finopolis'
  }
];

const teamMembers = [
  {
    name: 'Jonas Richter',
    role: 'CEO & Co-Founder',
    focus: 'Strategie & Workplace Transformation',
    img: 'https://picsum.photos/420/420?random=31'
  },
  {
    name: 'Nadja Sommer',
    role: 'VP Product',
    focus: 'UX für Raumbuchung & Sensorik',
    img: 'https://picsum.photos/420/420?random=32'
  },
  {
    name: 'Dr. Amir Seidel',
    role: 'CTO',
    focus: 'IoT, Security & Plattformarchitektur',
    img: 'https://picsum.photos/420/420?random=33'
  },
  {
    name: 'Lina Navarro',
    role: 'Head of Customer Value',
    focus: 'Adoption, Insights & Enablement',
    img: 'https://picsum.photos/420/420?random=34'
  }
];

const faqItems = [
  {
    question: 'Wie unterstützt Lumetranova hybride Arbeitsmodelle?',
    answer:
      'Teams buchen Räume, Zonen und Desks in einer Oberfläche. Sensorbasierte Heatmaps zeigen reale Belegung, sodass Flächen nachfrageorientiert geplant werden. Automatisierte Regeln schließen nicht genutzte Bereiche und senken Energieverbräuche.'
  },
  {
    question: 'Welche Sicherheitsstandards werden erfüllt?',
    answer:
      'Wir setzen auf Ende-zu-Ende-Verschlüsselung, rollenbasierte Zugriffskontrolle (RBAC), SAML SSO, SCIM Provisioning und Audit-Logs. Hosting erfolgt in ISO 27001-zertifizierten Rechenzentren innerhalb der EU.'
  },
  {
    question: 'Wie läuft das Onboarding ab?',
    answer:
      'Nach einer Discovery-Phase begleiten wir Sie mit einem dedizierten Customer-Success-Team. Sie erhalten Leitfäden, Templates und Webinare. Double-Opt-In Workflows stellen sicher, dass Benachrichtigungen DSGVO-konform aktiviert werden.'
  },
  {
    question: 'Welche Sensoren werden unterstützt?',
    answer:
      'Lumetranova ist herstellerneutral: Von Präsenz- und CO₂-Sensoren über Stromzähler bis zu Access Points integrieren wir via BACnet, Modbus, MQTT, REST und Webhooks.'
  }
];

const blogPosts = [
  {
    title: 'Workplace Analytics: Von der Belegung zur Zukunftsplanung',
    date: '15. März 2024',
    link: '/ressourcen',
    image: 'https://picsum.photos/640/420?random=41'
  },
  {
    title: 'Energie-Monitoring im Smart Office: Best Practices ',
    date: '28. Februar 2024',
    link: '/ressourcen',
    image: 'https://picsum.photos/640/420?random=42'
  },
  {
    title: 'Visitor Journey neu gedacht: Digitale Empfangsprozesse',
    date: '10. Februar 2024',
    link: '/ressourcen',
    image: 'https://picsum.photos/640/420?random=43'
  }
];

const projectCards = [
  {
    id: 1,
    title: 'Hybrid Campus Navigator',
    category: 'Hybrid Work',
    description: 'Kombinierte Desk- und Raumplanung für 4.800 Mitarbeitende mit IoT-Sensorik und Live-Komfortdaten.',
    image: 'https://picsum.photos/1200/800?random=51'
  },
  {
    id: 2,
    title: 'HQ Command Center',
    category: 'HQ / Hub',
    description: 'Digitale Leitwarte für Energie- und Belegungsdaten mit Echtzeit-Badge-Tracking.',
    image: 'https://picsum.photos/1200/800?random=52'
  },
  {
    id: 3,
    title: 'Compliance & Access Suite',
    category: 'Compliance',
    description: 'RBAC-Zutrittskontrolle mit Besuchermanagement und Audit-Reporting.',
    image: 'https://picsum.photos/1200/800?random=53'
  },
  {
    id: 4,
    title: 'Energy Intelligence Grid',
    category: 'Energie',
    description: 'Automatisiertes Energie-Load-Shedding basierend auf Auslastungsprognosen.',
    image: 'https://picsum.photos/1200/800?random=54'
  }
];

const Home = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Alle');
  const [expandedFaq, setExpandedFaq] = useState(null);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Alle') return projectCards;
    return projectCards.filter((card) => card.category === activeFilter);
  }, [activeFilter]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const increments = statsData.map((stat) => Math.ceil(stat.value / 80));
    const timer = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, index) => {
          const next = value + increments[index];
          return next >= statsData[index].value ? statsData[index].value : next;
        })
      );
    }, 30);
    return () => clearInterval(timer);
  }, []);

  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Lumetranova',
    url: 'https://www.lumetranova.com',
    logo: 'https://www.lumetranova.com/logo.png',
    contactPoint: [
      {
        '@type': 'ContactPoint',
        telephone: '+49 30 1234 5678',
        contactType: 'sales',
        areaServed: 'DE',
        availableLanguage: ['de', 'en']
      }
    ],
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Alexanderstraße 5',
      addressLocality: 'Berlin',
      postalCode: '10178',
      addressCountry: 'DE'
    },
    sameAs: ['https://www.linkedin.com']
  };

  return (
    <>
      <Helmet>
        <title>Lumetranova | Smart Office Plattform für hybride Teams</title>
        <meta
          name="description"
          content="Lumetranova verbindet Raumbuchung, Desk-Booking, Sensorik und Energie-Monitoring in einer modernen Smart-Office-Plattform. Ideal für Hybrid Work, Sicherheit und Flächeneffizienz."
        />
        <meta
          name="keywords"
          content="smart office, raumbuchung, desk booking, belegungssensoren, energie monitoring, besuchermanagement, zutrittskontrolle, workplace analytics, flächeneffizienz, dsgvo, saml sso, scim"
        />
        <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>SaaS für Smart Office &amp; Hybrid Work</span>
          <h1>Lumetranova orchestriert Räume, Menschen und Energie in Echtzeit.</h1>
          <p>
            Unsere Plattform verbindet Raumbuchung, Desk-Booking, IoT-Sensorik und Energie-Monitoring zu einem nahtlosen Erlebnis.
            Mit Live-Heatmaps, Zutrittskontrolle und Workplace Analytics treffen Teams klare Entscheidungen – standortübergreifend und DSGVO-sicher.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.primaryBtn}>
              Demo anfordern
            </Link>
            <Link to="/funktionen" className={styles.secondaryBtn}>
              Funktionen erkunden
            </Link>
          </div>
          <div className={styles.heroHighlight}>
            <div>
              <strong>Live Heatmaps</strong>
              <span>Visuelle Belegungs- und Komfortdaten</span>
            </div>
            <div>
              <strong>Kalender Sync</strong>
              <span>Microsoft 365 &amp; Google Workspace</span>
            </div>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <div className={styles.visualCard}>
            <img
              src="https://picsum.photos/1600/900?random=101"
              alt="Smart Office Dashboard mit Heatmap und Kalender"
              loading="lazy"
            />
            <div className={styles.visualOverlay}>
              <div>
                <p>Live-Belegung</p>
                <span>Spaces 72% · Collaboration Zones 64%</span>
              </div>
              <div>
                <p>Energie Insights</p>
                <span>Peak Load -18% · CO₂-Score 412 ppm</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Kennzahlen">
        {statsData.map((stat, index) => (
          <div key={stat.label} className={styles.statCard}>
            <span className={styles.statValue}>
              {counters[index].toLocaleString('de-DE')}
              {stat.suffix}
            </span>
            <span className={styles.statLabel}>{stat.label}</span>
          </div>
        ))}
      </section>

      <section className={styles.benefits} id="benefits" aria-labelledby="benefits-title">
        <div className={styles.sectionHeader}>
          <h2 id="benefits-title">Warum führende Unternehmen auf Lumetranova setzen</h2>
          <p>
            Wir schaffen Spitzen-Erlebnisse für Hybrid Work: von smarter Buchung über intelligente Sensorik bis zu energieeffizienten Entscheidungen.
          </p>
        </div>
        <div className={styles.benefitGrid}>
          {benefitCards.map((card) => (
            <article key={card.title} className={styles.benefitCard}>
              <span className={styles.benefitIcon} aria-hidden="true">{card.icon}</span>
              <h3>{card.title}</h3>
              <p>{card.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.features} aria-labelledby="features-title">
        <div className={styles.sectionHeader}>
          <h2 id="features-title">Alle Kernfunktionen in einer Oberfläche</h2>
          <p>
            Von Desk-Booking bis Energie-Analytics – Lumetranova bildet die gesamte Workplace Journey ab.
            Interaktive Kalender, Sensor-Dashboards, Visitor Flows und Compliance-Reporting kommen als modulare Suite.
          </p>
        </div>
        <div className={styles.featureGrid}>
          {featureTiles.map((tile) => (
            <article key={tile.title} className={styles.featureTile}>
              <h3>{tile.title}</h3>
              <p>{tile.description}</p>
              <span>{tile.detail}</span>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.useCases} aria-labelledby="usecases-title">
        <div className={styles.sectionHeader}>
          <h2 id="usecases-title">Use Cases – so profitieren Teams</h2>
          <p>Nutzen Sie Lumetranova für hybride Zusammenarbeit, sichere Hubs und effiziente Flächennutzung.</p>
        </div>
        <div className={styles.useCaseGrid}>
          <article>
            <h3>Hybrid Work Playbook</h3>
            <p>Desk- und Raumzuteilung nach Team-Präferenzen, inklusive Check-in via App und Sensor-Feedback.</p>
            <Link to="/use-cases" className={styles.linkArrow}>Mehr erfahren</Link>
          </article>
          <article>
            <h3>HQ / Hub Steuerung</h3>
            <p>Digitale Lagezentren mit Live-Occupancy, Energiekennzahlen und Besuchermanagement.</p>
            <Link to="/use-cases" className={styles.linkArrow}>Mehr erfahren</Link>
          </article>
          <article>
            <h3>Compliance &amp; Sicherheit</h3>
            <p>Verfolgbare Zutritte, Audit-Logs, Evakuierungslisten und SCIM-basierte Identitäten.</p>
            <Link to="/use-cases" className={styles.linkArrow}>Mehr erfahren</Link>
          </article>
          <article>
            <h3>Budget- &amp; Flächeneffizienz</h3>
            <p>Szenarioplanung, Auslastungsbenchmarks und Portfoliovergleiche für nachhaltige Flächenstrategien.</p>
            <Link to="/use-cases" className={styles.linkArrow}>Mehr erfahren</Link>
          </article>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <div className={styles.sectionHeader}>
          <h2 id="process-title">Ihr Weg zur Smart-Office-Plattform</h2>
          <p>Vier Phasen, ein Ziel: Datengetriebene, energieeffiziente Arbeitswelten.</p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.step} className={styles.processStep}>
              <span className={styles.stepBadge}>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.integrations} aria-labelledby="integrations-title">
        <div className={styles.sectionHeader}>
          <h2 id="integrations-title">Integriert in Ihre digitale Arbeitswelt</h2>
          <p>Native Connectors, offene APIs und Webhooks sorgen für fließende Prozesse.</p>
        </div>
        <div className={styles.integrationLogos}>
          {integrationLogos.map((logo) => (
            <Link key={logo.name} to={logo.path} className={styles.integrationCard} aria-label={`${logo.name} Integration`}>
              <img src={logo.url} alt={`Logo ${logo.name}`} loading="lazy" />
              <span>{logo.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-title">
        <div className={styles.sectionHeader}>
          <h2 id="projects-title">Projekte &amp; Szenarien</h2>
          <p>Filterbare Referenzen zeigen, wie sich Lumetranova in verschiedenen Portfolio-Strukturen bewährt.</p>
        </div>
        <div className={styles.projectFilters} role="tablist" aria-label="Projektfilter">
          {['Alle', 'Hybrid Work', 'HQ / Hub', 'Compliance', 'Energie'].map((filter) => (
            <button
              key={filter}
              type="button"
              onClick={() => setActiveFilter(filter)}
              className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
              role="tab"
              aria-selected={activeFilter === filter}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <img src={project.image} alt={`Projekt ${project.title}`} loading="lazy" />
              <div>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-title">
        <div className={styles.sectionHeader}>
          <h2 id="testimonials-title">Stimmen unserer Kunden</h2>
          <p>Führende Unternehmen vertrauen auf Lumetranova für ihre Workplace Transformation.</p>
        </div>
        <div className={styles.testimonialSlider}>
          <button
            type="button"
            onClick={() =>
              setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
            }
            aria-label="Vorheriges Testimonial"
          >
            ‹
          </button>
          <div className={styles.testimonialCard} aria-live="polite">
            <p className={styles.quote}>&ldquo;{testimonials[testimonialIndex].quote}&rdquo;</p>
            <p className={styles.author}>{testimonials[testimonialIndex].name}</p>
            <span className={styles.role}>{testimonials[testimonialIndex].role}</span>
          </div>
          <button
            type="button"
            onClick={() =>
              setTestimonialIndex((prev) => (prev + 1) % testimonials.length)
            }
            aria-label="Nächstes Testimonial"
          >
            ›
          </button>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-title">
        <div className={styles.sectionHeader}>
          <h2 id="team-title">Leadership &amp; Expertenteams</h2>
          <p>Ein multidisziplinäres Team aus Workplace, IoT, Energie und Security.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.img} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <span>{member.focus}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-title">
        <div className={styles.sectionHeader}>
          <h2 id="faq-title">FAQ – Antworten auf zentrale Fragen</h2>
          <p>Alles, was Sie zur Smart-Office-Einführung mit Lumetranova wissen müssen.</p>
        </div>
        <div className={styles.accordion} role="tablist">
          {faqItems.map((item, index) => (
            <div key={item.question} className={styles.accordionItem}>
              <button
                type="button"
                className={styles.accordionButton}
                onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                aria-expanded={expandedFaq === index}
                aria-controls={`faq-panel-${index}`}
              >
                <span>{item.question}</span>
                <span aria-hidden="true">{expandedFaq === index ? '−' : '+'}</span>
              </button>
              <div
                id={`faq-panel-${index}`}
                role="region"
                hidden={expandedFaq !== index}
                className={styles.accordionPanel}
              >
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-title">
        <div className={styles.sectionHeader}>
          <h2 id="blog-title">Insights &amp; Ressourcen</h2>
          <p>Guides, Templates und Webinare für Smart-Office-Strateg:innen.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src={post.image} alt={`Blogartikel: ${post.title}`} loading="lazy" />
              <div className={styles.blogContent}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <Link to={post.link} className={styles.linkArrow}>
                  Zum Beitrag
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className={styles.finalCtaInner}>
          <div>
            <h2>Bereit für messbare Effekte im Smart Office?</h2>
            <p>
              Vereinbaren Sie eine individuelle Demo – mit Ihrem Grundriss, Ihren Anforderungen und einem klaren Fahrplan für Rollout, Enablement und Double-Opt-In-Kommunikation.
            </p>
          </div>
          <Link to="/kontakt" className={styles.finalCtaButton}>
            Demo anfordern
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;