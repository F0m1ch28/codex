import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './GenericPage.module.css';

const resources = [
  { title: 'Leitfaden: Hybrid Work Spaces', description: 'Das vollständige Playbook für zukunftssichere Arbeitsplatzplanung.' },
  { title: 'Vorlage: Desk-Booking Policies', description: 'Strukturierte Vorgaben für Teams, Zonen und Check-in-Prozesse.' },
  { title: 'Webinar: Energie-Monitoring', description: 'Live-Demo der Sensor- und Energie-Dashboards inkl. Q&A.' },
  { title: 'Onboarding Toolkit', description: 'Trainingsmodule, Change-Story und Kommunikationsvorlagen für Rollout-Teams.' }
];

const RessourcenPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Ressourcen | Lumetranova</title>
      <meta
        name="description"
        content="Guides, Vorlagen, Webinare und Onboarding-Material rund um Smart Offices und Lumetranova."
      />
      <meta
        name="keywords"
        content="smart office leitfaden, webinars, onboarding, hybrid work templates"
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Ressourcen &amp; Enablement</h1>
      <p>Nutzen Sie Leitfäden, Templates und Webinare, um Ihr Smart Office weiterzuentwickeln.</p>
    </header>
    <section className={styles.grid}>
      {resources.map((resource) => (
        <article key={resource.title} className={styles.card}>
          <h3>{resource.title}</h3>
          <p>{resource.description}</p>
        </article>
      ))}
    </section>
    <section className={styles.section}>
      <h2>Customer Enablement</h2>
      <p>Mit unserem Onboarding-Programm stellen wir sicher, dass Adoption und Double-Opt-In-Kommunikation reibungslos funktionieren. Dazu gehören:</p>
      <ul className={styles.list}>
        <li>Workshops für Corporate Real Estate, IT und HR.</li>
        <li>Trainings für Front Desk und Sicherheits-Teams.</li>
        <li>Enablement-Hub mit Video-Library, Checklisten und Release Notes.</li>
        <li>Community Calls und Benchmark-Reports.</li>
      </ul>
    </section>
  </div>
);

export default RessourcenPage;