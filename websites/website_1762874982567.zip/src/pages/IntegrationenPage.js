import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './GenericPage.module.css';

const integrations = [
  { title: 'Microsoft 365 / Outlook', description: 'Buchungen werden in Outlook synchronisiert, inklusive Ressourcen und Teams Rooms.' },
  { title: 'Google Workspace / Calendar', description: 'Kalender, Meet-Links und Räume sind gekoppelt und bleiben stets aktuell.' },
  { title: 'Okta / Azure AD (SSO)', description: 'SAML SSO, MFA und Lifecycle-Events sorgen für sichere Identitäten.' },
  { title: 'Slack / Teams', description: 'Buchungen, Erinnerungen und Besucherankündigungen direkt im bevorzugten Messenger.' },
  { title: 'BAC / Access-Systeme', description: 'Zutrittssteuerung für Gebäude, Etagen und Räume inklusive Besuchertokens.' },
  { title: 'Webhooks & APIs', description: 'Offene REST- und GraphQL-APIs sowie Event-basierte Webhooks für individuelle Integrationen.' }
];

const IntegrationenPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Integrationen | Lumetranova</title>
      <meta
        name="description"
        content="Lumetranova integriert Microsoft 365, Google Workspace, Okta, Azure AD, Slack, Teams, Access-Systeme sowie flexible Webhooks."
      />
      <meta
        name="keywords"
        content="integrationen, saml sso, scim, webhooks, microsoft 365, google workspace, smart office"
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Integrationen</h1>
      <p>Smarte Workflows entstehen durch nahtlose Verbindungen – out-of-the-box oder via API.</p>
    </header>
    <section className={styles.grid}>
      {integrations.map((integration) => (
        <article key={integration.title} className={styles.card}>
          <h3>{integration.title}</h3>
          <p>{integration.description}</p>
        </article>
      ))}
    </section>
    <section className={`${styles.section} ${styles.highlight}`}>
      <h2>Security &amp; Identity</h2>
      <p>
        Lumetranova unterstützt SAML 2.0, OpenID Connect, SCIM 2.0 und Just-in-Time-Provisioning. Durch fein granulare RBAC-Policies steuern Sie, wer Räume, Reports oder Integrationen administriert. Audit-Logs und SIEM-Exports sorgen für vollständige Nachverfolgbarkeit.
      </p>
    </section>
  </div>
);

export default IntegrationenPage;