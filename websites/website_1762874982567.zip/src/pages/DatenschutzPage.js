import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPage.module.css';

const DatenschutzPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Datenschutz | Lumetranova</title>
      <meta
        name="description"
        content="Datenschutz und DSGVO-Konformität bei Lumetranova: Informationen zu Datenverarbeitung, Cookies, Tracking und Betroffenenrechten."
      />
    </Helmet>
    <div className={styles.container}>
      <header className={styles.header}>
        <h1>Datenschutz</h1>
        <p>Wir schützen personenbezogene Daten nach den Vorgaben der DSGVO und des BDSG.</p>
      </header>
      <section className={styles.section}>
        <h2>Verantwortlicher</h2>
        <p>Lumetranova GmbH, Alexanderstraße 5, 10178 Berlin, Deutschland.<br />E-Mail: <a href="mailto:privacy@lumetranova.com">privacy@lumetranova.com</a></p>
      </section>
      <section className={styles.section}>
        <h2>Verarbeitungszwecke</h2>
        <ul>
          <li>Bereitstellung der Smart-Office-Plattform.</li>
          <li>Nutzerverwaltung, SAML SSO und SCIM Provisioning.</li>
          <li>Analyse von Nutzungsdaten zur Verbesserung der Workplace-Funktionen (nur mit Einwilligung).</li>
          <li>Support- und Kommunikationsprozesse.</li>
        </ul>
      </section>
      <section className={styles.section}>
        <h2>Rechtsgrundlagen</h2>
        <p>Die Verarbeitung erfolgt auf Basis von Art. 6 Abs. 1 lit. b, lit. c und lit. f DSGVO sowie auf Grundlage Ihrer Einwilligung nach Art. 6 Abs. 1 lit. a DSGVO.</p>
      </section>
      <section className={styles.section}>
        <h2>Cookies &amp; Tracking</h2>
        <p>Wir setzen essenzielle Cookies für Login und Sicherheit ein. Analyse-Cookies nutzen wir nur nach aktiver Einwilligung über unser Consent-Banner.</p>
      </section>
      <section className={styles.section}>
        <h2>Betroffenenrechte</h2>
        <p>Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung, Datenübertragbarkeit und Widerspruch. Kontaktieren Sie privacy@lumetranova.com.</p>
      </section>
      <section className={styles.section}>
        <h2>Auftragsverarbeitung</h2>
        <p>Wir arbeiten mit DSGVO-konformen Subprozessoren. Eine aktuelle Liste stellen wir auf Anfrage zur Verfügung.</p>
      </section>
    </div>
  </div>
);

export default DatenschutzPage;