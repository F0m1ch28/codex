import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import FunktionenPage from './pages/FunktionenPage';
import UseCasesPage from './pages/UseCasesPage';
import IntegrationenPage from './pages/IntegrationenPage';
import RessourcenPage from './pages/RessourcenPage';
import ContactPage from './pages/ContactPage';
import ImpressumPage from './pages/ImpressumPage';
import DatenschutzPage from './pages/DatenschutzPage';
import AGBPage from './pages/AGBPage';
import AboutPage from './pages/AboutPage';
import ServicesPage from './pages/ServicesPage';

const App = () => {
  return (
    <div className="app-shell">
      <Header />
      <ScrollToTop />
      <main className="main-content" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/funktionen" element={<FunktionenPage />} />
          <Route path="/use-cases" element={<UseCasesPage />} />
          <Route path="/integrationen" element={<IntegrationenPage />} />
          <Route path="/ressourcen" element={<RessourcenPage />} />
          <Route path="/kontakt" element={<ContactPage />} />
          <Route path="/impressum" element={<ImpressumPage />} />
          <Route path="/datenschutz" element={<DatenschutzPage />} />
          <Route path="/agb" element={<AGBPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

export default App;