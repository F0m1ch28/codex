import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 8);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const navItems = [
    { to: '/', label: 'Start' },
    { to: '/funktionen', label: 'Funktionen' },
    { to: '/use-cases', label: 'Use Cases' },
    { to: '/integrationen', label: 'Integrationen' },
    { to: '/ressourcen', label: 'Ressourcen' },
    { to: '/about', label: 'Über uns' },
    { to: '/services', label: 'Services' },
    { to: '/kontakt', label: 'Kontakt' }
  ];

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`} aria-label="Hauptnavigation">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Lumetranova Startseite">
          <span className={styles.logoMark} aria-hidden="true">L</span>
          <span className={styles.logoText}>Lumetranova</span>
        </Link>

        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Primäre Navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            >
              {item.label}
            </NavLink>
          ))}
          <Link to="/kontakt" className={styles.ctaLink}>
            Demo anfordern
          </Link>
        </nav>

        <button
          className={`${styles.menuButton} ${isMenuOpen ? styles.menuButtonActive : ''}`}
          onClick={() => setIsMenuOpen((prev) => !prev)}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Navigation umschalten"
        >
          <span aria-hidden="true" />
          <span aria-hidden="true" />
          <span aria-hidden="true" />
        </button>
      </div>
    </header>
  );
};

export default Header;