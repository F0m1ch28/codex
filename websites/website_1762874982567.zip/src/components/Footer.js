import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <div className={styles.logo} aria-hidden="true">L</div>
          <div>
            <p className={styles.brandName}>Lumetranova</p>
            <p className={styles.brandTagline}>Smarte Räume. Klarer Fokus.</p>
          </div>
        </div>

        <div className={styles.columns}>
          <div>
            <h4 className={styles.heading}>Plattform</h4>
            <ul className={styles.list}>
              <li><Link to="/funktionen">Funktionen</Link></li>
              <li><Link to="/use-cases">Use Cases</Link></li>
              <li><Link to="/integrationen">Integrationen</Link></li>
              <li><Link to="/services">Services</Link></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.heading}>Unternehmen</h4>
            <ul className={styles.list}>
              <li><Link to="/about">Über uns</Link></li>
              <li><Link to="/ressourcen">Ressourcen</Link></li>
              <li><Link to="/kontakt">Kontakt</Link></li>
              <li><a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.heading}>Rechtliches</h4>
            <ul className={styles.list}>
              <li><Link to="/impressum">Impressum</Link></li>
              <li><Link to="/datenschutz">Datenschutz</Link></li>
              <li><Link to="/agb">AGB</Link></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.heading}>Kontakt</h4>
            <ul className={styles.list}>
              <li>Alexanderstraße 5</li>
              <li>10178 Berlin</li>
              <li>Deutschland</li>
              <li><a href="tel:+493012345678">+49 30 1234 5678</a></li>
              <li><a href="mailto:hello@lumetranova.com">hello@lumetranova.com</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>&copy; {year} Lumetranova GmbH. Alle Rechte vorbehalten.</p>
        <div className={styles.badges} aria-label="Zertifizierungen">
          <span>ISO 27001 Ready</span>
          <span>SOC 2 vorbereitet</span>
          <span>DSGVO-konform</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;