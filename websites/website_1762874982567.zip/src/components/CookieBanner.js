import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [analytics, setAnalytics] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('lumetranova-cookie-consent');
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    const consent = {
      date: new Date().toISOString(),
      analytics
    };
    localStorage.setItem('lumetranova-cookie-consent', JSON.stringify(consent));
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('lumetranova-cookie-consent', JSON.stringify({ date: new Date().toISOString(), analytics: false }));
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie-Einstellungen">
      <div className={styles.content}>
        <h4>Cookies &amp; Privacy</h4>
        <p>
          Wir verwenden essentielle Cookies, um den Betrieb unserer Plattform sicherzustellen. Optional helfen uns Analyse-Cookies, Ihr Nutzererlebnis zu optimieren. Sie können Ihre Auswahl jederzeit anpassen.
        </p>
        <label className={styles.checkbox}>
          <input
            type="checkbox"
            checked={analytics}
            onChange={(e) => setAnalytics(e.target.checked)}
            aria-label="Analyse-Cookies erlauben"
          />
          <span>Analyse-Cookies aktivieren</span>
        </label>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={handleDecline} className={styles.decline}>
          Nur essenziell
        </button>
        <button type="button" onClick={handleAccept} className={styles.accept}>
          Auswahl speichern
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;