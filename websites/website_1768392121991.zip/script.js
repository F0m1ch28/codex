document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".primary-nav");
    const body = document.body;

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const isOpen = navMenu.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", isOpen);
            body.style.overflow = isOpen ? "hidden" : "";
        });

        navMenu.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
                body.style.overflow = "";
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const consentKey = "maricomplyCookieConsent";

    function hideBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
            cookieBanner.setAttribute("aria-hidden", "true");
        }
    }

    function showBanner() {
        if (cookieBanner) {
            cookieBanner.classList.add("active");
            cookieBanner.setAttribute("aria-hidden", "false");
        }
    }

    if (cookieBanner) {
        const consent = localStorage.getItem(consentKey);
        if (!consent) {
            setTimeout(showBanner, 1000);
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem(consentKey, "accepted");
                hideBanner();
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem(consentKey, "declined");
                hideBanner();
            });
        }
    }

    if (window.mermaid) {
        window.mermaid.initialize({
            startOnLoad: true,
            theme: "dark",
            securityLevel: "loose",
            fontFamily: "Inter, sans-serif"
        });
    }
});