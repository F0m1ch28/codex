document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.getElementById('site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navToggle.classList.toggle('open');
      siteNav.classList.toggle('open');
    });

    siteNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (navToggle.offsetParent !== null) {
          navToggle.setAttribute('aria-expanded', 'false');
          navToggle.classList.remove('open');
          siteNav.classList.remove('open');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('sl_cookie_consent');
    if (!storedPreference) {
      requestAnimationFrame(function () {
        cookieBanner.classList.add('show');
      });
    }

    const acceptBtn = cookieBanner.querySelector('[data-cookie-action="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-action="decline"]');

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        localStorage.setItem('sl_cookie_consent', 'accepted');
        cookieBanner.classList.remove('show');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        localStorage.setItem('sl_cookie_consent', 'declined');
        cookieBanner.classList.remove('show');
      });
    }
  }
});