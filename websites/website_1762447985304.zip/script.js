document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('open');
        });
    }

    document.querySelectorAll('[data-scroll]').forEach(link => {
        link.addEventListener('click', (event) => {
            const targetId = link.getAttribute('data-scroll');
            const currentPath = window.location.pathname.split('/').pop() || 'index.html';
            if ((currentPath === '' || currentPath === 'index.html') && targetId) {
                const element = document.getElementById(targetId);
                if (element) {
                    event.preventDefault();
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    if (navMenu && navMenu.classList.contains('open')) {
                        navMenu.classList.remove('open');
                        navToggle?.setAttribute('aria-expanded', 'false');
                    }
                }
            }
        });
    });

    const scrollBtn = document.getElementById('scrollTopBtn');
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieKey = 'tt_cookie_consent';
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');

    if (cookieBanner && !localStorage.getItem(cookieKey)) {
        cookieBanner.classList.add('show');
    }

    acceptCookiesBtn?.addEventListener('click', () => {
        localStorage.setItem(cookieKey, 'accepted');
        cookieBanner?.classList.remove('show');
    });

    const contactForm = document.getElementById('contact-form');
    const feedback = document.getElementById('form-feedback');

    if (contactForm && feedback) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            feedback.textContent = 'Thank you for reaching out. Our consultants will respond within one business day.';
            contactForm.reset();
        });
    }

    const yearSpan = document.getElementById('current-year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});