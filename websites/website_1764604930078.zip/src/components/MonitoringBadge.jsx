import React from 'react';

const MonitoringBadge = () => (
  <div className="monitoring-badge" aria-label="Статус мониторинга">
    <span className="monitoring-dot" aria-hidden="true" />
    <span>24/7 мониторинг</span>
  </div>
);

export default MonitoringBadge;