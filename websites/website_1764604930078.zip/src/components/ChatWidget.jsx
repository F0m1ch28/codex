import React from 'react';
import { motion } from 'framer-motion';
import { FiMessageCircle, FiSend, FiX } from 'react-icons/fi';

const initialMessages = [
  {
    sender: 'bot',
    text: 'Здравствуйте! Я виртуальный координатор Fortis Shield. Какую задачу нужно решить?'
  }
];

const quickActions = [
  'Нужна охрана объекта',
  'Хочу подключить видеомониторинг',
  'Требуется оценка рисков',
  'Связаться с оперативным дежурным'
];

const ChatWidget = () => {
  const [open, setOpen] = React.useState(false);
  const [messages, setMessages] = React.useState(initialMessages);
  const [input, setInput] = React.useState('');
  const chatBodyRef = React.useRef(null);

  const handleSend = (text) => {
    const userMessage = text || input.trim();
    if (!userMessage) return;
    setMessages((prev) => [...prev, { sender: 'user', text: userMessage }]);
    setInput('');
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'bot',
          text:
            'Спасибо за запрос. Дежурный офицер перезвонит в течение 5 минут. Укажите, пожалуйста, контактный телефон на странице Контакты или оставьте заявку через форму.'
        }
      ]);
    }, 600);
  };

  React.useEffect(() => {
    if (chatBodyRef.current) {
      chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
    }
  }, [messages, open]);

  return (
    <div className={`chat-widget ${open ? 'open' : ''}`}>
      {open && (
        <motion.div
          className="chat-window"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          role="dialog"
          aria-label="Онлайн-чат Fortis Shield"
        >
          <div className="chat-header">
            <div>
              <strong>Fortis Shield — Оперативный чат</strong>
              <p>Ответим в течение 1 минуты</p>
            </div>
            <button aria-label="Закрыть чат" onClick={() => setOpen(false)}>
              <FiX size={18} />
            </button>
          </div>
          <div className="chat-body" ref={chatBodyRef}>
            {messages.map((message, index) => (
              <div
                key={index}
                className={`chat-message ${message.sender === 'user' ? 'chat-user' : 'chat-bot'}`}
              >
                {message.text}
              </div>
            ))}
          </div>
          <div className="chat-quick">
            {quickActions.map((action) => (
              <button key={action} onClick={() => handleSend(action)}>
                {action}
              </button>
            ))}
          </div>
          <form
            className="chat-input"
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
          >
            <input
              type="text"
              placeholder="Опишите задачу..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              aria-label="Сообщение"
            />
            <button type="submit" aria-label="Отправить сообщение">
              <FiSend />
            </button>
          </form>
        </motion.div>
      )}
      <motion.button
        className="chat-fab"
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen((prev) => !prev)}
        aria-expanded={open}
        aria-controls="chat-window"
      >
        <FiMessageCircle size={22} />
        <span>Связь 24/7</span>
      </motion.button>
    </div>
  );
};

export default ChatWidget;