import React from 'react';
import { motion } from 'framer-motion';

const initialState = {
  objectType: 'Бизнес-центр',
  location: '',
  priority: 'Инциденты исключены',
  timeframe: 'В течение недели'
};

const ProtectionAssessmentForm = () => {
  const [formState, setFormState] = React.useState(initialState);
  const [feedback, setFeedback] = React.useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    setFeedback({
      message: 'Мы составим оценку рисков и свяжемся в течение 15 минут. Оставьте контакт в форме ниже или напишите в чат.',
      timestamp: new Date().toLocaleTimeString('ru-RU')
    });
  };

  return (
    <motion.form
      className="assessment-form"
      onSubmit={handleSubmit}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <div className="form-row">
        <label htmlFor="objectType">Тип объекта</label>
        <select
          id="objectType"
          value={formState.objectType}
          onChange={(e) => setFormState((prev) => ({ ...prev, objectType: e.target.value }))}
        >
          <option>Бизнес-центр</option>
          <option>Логистический комплекс</option>
          <option>Коттеджный посёлок</option>
          <option>Индустриальный парк</option>
          <option>VIP-резиденция</option>
        </select>
      </div>
      <div className="form-row">
        <label htmlFor="location">Локация объекта</label>
        <input
          id="location"
          type="text"
          placeholder="Город, район, улица"
          value={formState.location}
          onChange={(e) => setFormState((prev) => ({ ...prev, location: e.target.value }))}
        />
      </div>
      <div className="form-row">
        <label htmlFor="priority">Приоритет</label>
        <select
          id="priority"
          value={formState.priority}
          onChange={(e) => setFormState((prev) => ({ ...prev, priority: e.target.value }))}
        >
          <option>Инциденты исключены</option>
          <option>Снижение рисков до минимума</option>
          <option>Быстрое развёртывание охраны</option>
        </select>
      </div>
      <div className="form-row">
        <label htmlFor="timeframe">Срок запуска проекта</label>
        <select
          id="timeframe"
          value={formState.timeframe}
          onChange={(e) => setFormState((prev) => ({ ...prev, timeframe: e.target.value }))}
        >
          <option>В течение недели</option>
          <option>В течение месяца</option>
          <option>Запуск сегодня</option>
          <option>Планируем заранее</option>
        </select>
      </div>
      <button type="submit" className="btn-ghost">Получить оценку рисков</button>
      {feedback && (
        <div className="assessment-feedback" role="status">
          <strong>Готово!</strong>
          <p>{feedback.message}</p>
          <span>Время регистрации заявки: {feedback.timestamp}</span>
        </div>
      )}
    </motion.form>
  );
};

export default ProtectionAssessmentForm;