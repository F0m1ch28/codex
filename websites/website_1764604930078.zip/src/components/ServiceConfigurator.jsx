import React from 'react';
import { motion } from 'framer-motion';
import { FiSliders } from 'react-icons/fi';

const riskOptions = [
  { value: 'низкий', label: 'Низкий' },
  { value: 'средний', label: 'Средний' },
  { value: 'высокий', label: 'Высокий' }
];

const responseOptions = [
  { value: 'патруль', label: 'Группа быстрого реагирования' },
  { value: 'стационар', label: 'Пост на объекте' },
  { value: 'комбинированный', label: 'Смешанный формат' }
];

const ServiceConfigurator = () => {
  const [area, setArea] = React.useState(1500);
  const [risk, setRisk] = React.useState('средний');
  const [response, setResponse] = React.useState('комбинированный');
  const [cctv, setCctv] = React.useState(true);

  const result = React.useMemo(() => {
    let base = 45000;
    if (area > 3000) base += 15000;
    if (area > 6000) base += 25000;

    if (risk === 'высокий') base *= 1.6;
    if (risk === 'средний') base *= 1.2;

    if (response === 'патруль') base += 20000;
    if (response === 'стационар') base += 35000;
    if (response === 'комбинированный') base += 50000;

    if (cctv) base += 18000;

    const recommendedStaff =
      area > 6000 ? 6 : area > 3000 ? 4 : 2;

    const drones = risk === 'высокий' || area > 8000;

    return {
      budget: Math.round(base / 1000) * 1000,
      staff: recommendedStaff,
      drones,
      description:
        risk === 'высокий'
          ? 'Рекомендуем организовать усиленную периметровую охрану, подключить аналитическую видеоаналитику и дежурную группу немедленного реагирования.'
          : 'Оптимальное сочетание мониторинга, шлагбаумов и патрулирования обеспечит контроль территории и предотвращение угроз.'
    };
  }, [area, risk, response, cctv]);

  return (
    <motion.section
      className="configurator-card"
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <header>
        <FiSliders size={22} aria-hidden="true" />
        <div>
          <h3>Калькулятор охранного решения</h3>
          <p>Получите предварительную конфигурацию за несколько параметров. Данные не сохраняются.</p>
        </div>
      </header>
      <div className="configurator-grid">
        <div className="configurator-control">
          <label htmlFor="area">Площадь объекта (м²)</label>
          <div className="slider-row">
            <input
              id="area"
              type="range"
              min="500"
              max="10000"
              step="100"
              value={area}
              onChange={(e) => setArea(Number(e.target.value))}
            />
            <span>{area.toLocaleString('ru-RU')} м²</span>
          </div>
        </div>
        <div className="configurator-control">
          <label htmlFor="risk">Уровень риска</label>
          <div className="select-group">
            {riskOptions.map((option) => (
              <button
                key={option.value}
                type="button"
                className={`pill-button ${risk === option.value ? 'active' : ''}`}
                onClick={() => setRisk(option.value)}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
        <div className="configurator-control">
          <label htmlFor="response">Формат реагирования</label>
          <select
            id="response"
            value={response}
            onChange={(e) => setResponse(e.target.value)}
          >
            {responseOptions.map((option) => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
        </div>
        <div className="configurator-control checkbox-control">
          <input
            id="cctv"
            type="checkbox"
            checked={cctv}
            onChange={(e) => setCctv(e.target.checked)}
          />
          <label htmlFor="cctv">Включить интеллектуальную систему видеонаблюдения</label>
        </div>
      </div>
      <div className="configurator-result">
        <div>
          <span className="result-label">Ориентировочный бюджет</span>
          <strong>{result.budget.toLocaleString('ru-RU')} ₽ / мес</strong>
        </div>
        <div>
          <span className="result-label">Рекомендуемый состав смены</span>
          <strong>{result.staff} сотрудника</strong>
        </div>
        <div>
          <span className="result-label">Дроны в системе</span>
          <strong>{result.drones ? 'Да' : 'Опционально'}</strong>
        </div>
      </div>
      <p className="configurator-description">{result.description}</p>
    </motion.section>
  );
};

export default ServiceConfigurator;