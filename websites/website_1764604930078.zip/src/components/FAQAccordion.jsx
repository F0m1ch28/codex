import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiChevronDown } from 'react-icons/fi';

const FAQAccordion = ({ items }) => {
  const [openItem, setOpenItem] = React.useState(null);

  const handleToggle = (index) => {
    setOpenItem((prev) => (prev === index ? null : index));
  };

  return (
    <div className="faq-accordion">
      {items.map((item, index) => {
        const isOpen = openItem === index;
        return (
          <article key={item.question} className={`faq-item ${isOpen ? 'open' : ''}`}>
            <button
              className="faq-question"
              onClick={() => handleToggle(index)}
              aria-expanded={isOpen}
            >
              <span>{item.question}</span>
              <FiChevronDown aria-hidden="true" />
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  className="faq-answer"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: 'easeOut' }}
                >
                  <p>{item.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </article>
        );
      })}
    </div>
  );
};

export default FAQAccordion;