import React from 'react';
import { motion } from 'framer-motion';
import { FiCheckShield } from 'react-icons/fi';

const testimonials = [
  {
    name: 'Александр Смирнов',
    role: 'Генеральный директор, ЭнергоХолдинг',
    text: 'Fortis Shield взяли на себя стратегическую защиту критической инфраструктуры. Отчётность, дисциплина и силовые ресурсы — на высшем уровне.',
    image: 'https://cdn.pixabay.com/photo/2015/01/08/18/24/man-593333_1280.jpg'
  },
  {
    name: 'Елена Корнилова',
    role: 'Управляющая, жилой комплекс «Северный Ветер»',
    text: 'Система контроля доступа и видеомониторинг работают безукоризненно. Жильцы чувствуют безопасность, а диспетчерская служба реагирует мгновенно.',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/13/14/woman-1869726_1280.jpg'
  },
  {
    name: 'Игорь Романов',
    role: 'Директор по безопасности, логистическая компания «Альянс»',
    text: 'После аудита рисков мы выбрали Fortis Shield. Гибридное решение с патрулями и дронами позволило минимизировать потери и сократить расходы.',
    image: 'https://cdn.pixabay.com/photo/2017/01/31/13/05/man-2020767_1280.jpg'
  }
];

const Testimonials = () => (
  <div className="testimonials-grid">
    {testimonials.map((testimonial, index) => (
      <motion.article
        key={testimonial.name}
        className="testimonial-card"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.5, delay: index * 0.15 }}
      >
        <div className="testimonial-header">
          <img src={testimonial.image} alt={`Портрет клиента ${testimonial.name}`} />
          <div>
            <strong>{testimonial.name}</strong>
            <span>{testimonial.role}</span>
          </div>
        </div>
        <p>{testimonial.text}</p>
        <div className="testimonial-verified">
          <FiCheckShield aria-hidden="true" />
          <span>Отзыв проверен службой контроля качества</span>
        </div>
      </motion.article>
    ))}
  </div>
);

export default Testimonials;