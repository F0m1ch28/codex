import React from 'react';
import { Link } from 'react-router-dom';
import { FiPhoneCall, FiMail, FiMapPin } from 'react-icons/fi';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="footer-grid">
        <div>
          <h3>Fortis Shield</h3>
          <p>Комплексная охрана бизнеса и частных резиденций по всей России. 24/7 контроль, высокотехнологичные решения и персональные команды быстрого реагирования.</p>
          <div className="footer-status">
            <span className="status-dot" />
            <span>Оперативный центр активен</span>
          </div>
        </div>
        <div>
          <h4>Навигация</h4>
          <ul>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/services">Услуги</Link></li>
            <li><Link to="/about">О компании</Link></li>
            <li><Link to="/faq">FAQ</Link></li>
          </ul>
        </div>
        <div>
          <h4>Юридическая информация</h4>
          <ul>
            <li><Link to="/privacy">Политика конфиденциальности</Link></li>
            <li><Link to="/terms">Условия использования</Link></li>
          </ul>
        </div>
        <div>
          <h4>Контакты</h4>
          <ul className="contact-list">
            <li><FiMapPin /> Россия, Москва, ул. Безопасности, 12</li>
            <li><FiPhoneCall /> +7 (495) 123-45-67</li>
            <li><FiMail /> info@fortis-shield.ru</li>
          </ul>
          <p className="footer-note">Лицензия Росгвардии № 000000 от 2024 г.</p>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Fortis Shield. Все права защищены.</span>
        <span>Создано с соблюдением стандартов безопасности и доступности.</span>
      </div>
    </footer>
  );
};

export default Footer;