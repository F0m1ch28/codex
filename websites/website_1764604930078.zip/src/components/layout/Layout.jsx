import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header.jsx';
import Footer from './Footer.jsx';
import EmergencyBar from '../EmergencyBar.jsx';
import CookieBanner from '../CookieBanner.jsx';
import ChatWidget from '../ChatWidget.jsx';

const Layout = () => {
  return (
    <div className="app-shell">
      <EmergencyBar />
      <Header />
      <Outlet />
      <Footer />
      <CookieBanner />
      <ChatWidget />
    </div>
  );
};

export default Layout;