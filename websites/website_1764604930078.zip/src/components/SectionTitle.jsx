import React from 'react';
import { motion } from 'framer-motion';

const SectionTitle = ({ overline, title, description, align = 'left' }) => (
  <motion.div
    className={`section-title ${align}`}
    initial={{ opacity: 0, y: 12 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.4 }}
    transition={{ duration: 0.4, ease: 'easeOut' }}
  >
    {overline && <span className="overline">{overline}</span>}
    <h2>{title}</h2>
    {description && <p>{description}</p>}
  </motion.div>
);

export default SectionTitle;