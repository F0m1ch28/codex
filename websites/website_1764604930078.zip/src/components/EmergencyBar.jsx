import React from 'react';
import { FiAlertCircle, FiPhoneOutgoing } from 'react-icons/fi';

const EmergencyBar = () => (
  <div className="emergency-bar">
    <div className="emergency-content">
      <FiAlertCircle size={20} aria-hidden="true" />
      <span>Экстренный канал связи с ситуационным центром Fortis Shield — круглосуточно.</span>
    </div>
    <a className="emergency-button" href="tel:+74951234567">
      <FiPhoneOutgoing aria-hidden="true" />
      <span>Экстренный звонок: +7 (495) 123-45-67</span>
    </a>
  </div>
);

export default EmergencyBar;