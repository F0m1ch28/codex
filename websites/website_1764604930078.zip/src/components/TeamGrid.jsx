import React from 'react';
import { motion } from 'framer-motion';

const teamMembers = [
  {
    name: 'Илья Данилов',
    role: 'Директор операционного центра',
    expertise: '16 лет в управлении быстро реагирующими группами, бывший офицер спецподразделения.',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/05/08/adult-1866469_1280.jpg'
  },
  {
    name: 'Мария Истомина',
    role: 'Руководитель аналитики и аудита рисков',
    expertise: 'Эксперт по корпоративной безопасности, сертификация ASIS PSP.',
    image: 'https://cdn.pixabay.com/photo/2019/08/11/18/59/woman-4390567_1280.jpg'
  },
  {
    name: 'Владимир Романов',
    role: 'Главный инженер по системам видеомониторинга',
    expertise: 'Проектирование комплексных систем CCTV, градостроительные объекты и дата-центры.',
    image: 'https://cdn.pixabay.com/photo/2015/01/21/14/14/industrial-606656_1280.jpg'
  },
  {
    name: 'Кира Шувалова',
    role: 'Куратор VIP-направления',
    expertise: 'Персональная охрана, построение маршрутов безопасности, международные командировки.',
    image: 'https://cdn.pixabay.com/photo/2019/11/02/13/31/businesswoman-4590634_1280.jpg'
  }
];

const TeamGrid = () => (
  <div className="team-grid">
    {teamMembers.map((member, index) => (
      <motion.article
        key={member.name}
        className="team-card"
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.45, delay: index * 0.12 }}
      >
        <div className="team-image-wrapper">
          <img src={member.image} alt={member.name} />
        </div>
        <div className="team-info">
          <h3>{member.name}</h3>
          <span>{member.role}</span>
          <p>{member.expertise}</p>
        </div>
      </motion.article>
    ))}
  </div>
);

export default TeamGrid;