import React from 'react';
import { motion } from 'framer-motion';

const StatsGrid = ({ stats }) => (
  <div className="stats-grid">
    {stats.map((stat, index) => (
      <motion.div
        key={stat.label}
        className="stat-card"
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.4, delay: index * 0.1 }}
      >
        <span className="stat-value">{stat.value}</span>
        <span className="stat-label">{stat.label}</span>
        <p>{stat.description}</p>
      </motion.div>
    ))}
  </div>
);

export default StatsGrid;