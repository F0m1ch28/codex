import React from 'react';
import { motion } from 'framer-motion';

const COOKIE_STORAGE_KEY = 'fortis-shield-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!consent) setVisible(true);
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(COOKIE_STORAGE_KEY, choice);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <motion.aside
      className="cookie-banner"
      initial={{ opacity: 0, y: 32 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      role="dialog"
      aria-live="polite"
    >
      <div className="cookie-text">
        <h4>Мы ценим вашу конфиденциальность</h4>
        <p>Fortis Shield использует cookie для безопасной авторизации, аналитики и улучшения сервиса. Вы можете принять или отклонить обработку данных.</p>
        <a href="/privacy">Подробнее в политике конфиденциальности</a>
      </div>
      <div className="cookie-actions">
        <button className="btn-secondary" onClick={() => handleChoice('declined')}>Отклонить</button>
        <button className="btn-primary" onClick={() => handleChoice('accepted')}>Принять</button>
      </div>
    </motion.aside>
  );
};

export default CookieBanner;