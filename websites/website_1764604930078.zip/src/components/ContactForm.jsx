import React from 'react';
import { motion } from 'framer-motion';

const initialState = {
  name: '',
  phone: '',
  email: '',
  company: '',
  message: ''
};

const ContactForm = () => {
  const [formData, setFormData] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Укажите имя';
    if (!formData.phone.trim()) newErrors.phone = 'Укажите номер телефона';
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = 'Некорректный email';
    if (!formData.message.trim()) newErrors.message = 'Опишите задачу';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
      setTimeout(() => setSubmitted(false), 5000);
    }
  };

  return (
    <motion.form
      className="contact-form"
      onSubmit={handleSubmit}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
    >
      <div className="form-row">
        <label htmlFor="name">Имя и фамилия*</label>
        <input
          id="name"
          name="name"
          type="text"
          placeholder="Иван Иванов"
          value={formData.name}
          onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
          aria-invalid={Boolean(errors.name)}
          aria-describedby={errors.name ? 'name-error' : undefined}
        />
        {errors.name && <span className="form-error" id="name-error">{errors.name}</span>}
      </div>
      <div className="form-row">
        <label htmlFor="phone">Телефон для связи*</label>
        <input
          id="phone"
          name="phone"
          type="tel"
          placeholder="+7 (___) ___-__-__"
          value={formData.phone}
          onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
          aria-invalid={Boolean(errors.phone)}
          aria-describedby={errors.phone ? 'phone-error' : undefined}
        />
        {errors.phone && <span className="form-error" id="phone-error">{errors.phone}</span>}
      </div>
      <div className="form-row">
        <label htmlFor="email">Email (по желанию)</label>
        <input
          id="email"
          name="email"
          type="email"
          placeholder="security@company.ru"
          value={formData.email}
          onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? 'email-error' : undefined}
        />
        {errors.email && <span className="form-error" id="email-error">{errors.email}</span>}
      </div>
      <div className="form-row">
        <label htmlFor="company">Компания / объект</label>
        <input
          id="company"
          name="company"
          type="text"
          placeholder="ООО «Безопасный периметр»"
          value={formData.company}
          onChange={(e) => setFormData((prev) => ({ ...prev, company: e.target.value }))}
        />
      </div>
      <div className="form-row">
        <label htmlFor="message">Описание задачи*</label>
        <textarea
          id="message"
          name="message"
          placeholder="Укажите тип объекта, требования к охране и сроки запуска."
          value={formData.message}
          onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
          rows={4}
          aria-invalid={Boolean(errors.message)}
          aria-describedby={errors.message ? 'message-error' : undefined}
        />
        {errors.message && <span className="form-error" id="message-error">{errors.message}</span>}
      </div>
      <button type="submit" className="btn-primary">Отправить заявку</button>
      {submitted && (
        <div className="form-success" role="status">
          Заявка принята. Дежурный офицер свяжется с вами в течение 5 минут.
        </div>
      )}
    </motion.form>
  );
};

export default ContactForm;