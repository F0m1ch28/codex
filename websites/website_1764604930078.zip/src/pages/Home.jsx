import React from 'react';
import { motion } from 'framer-motion';
import { FiShield, FiArrowRightCircle, FiVideo, FiUsers, FiCommand } from 'react-icons/fi';
import SectionTitle from '../components/SectionTitle.jsx';
import StatsGrid from '../components/StatsGrid.jsx';
import Testimonials from '../components/Testimonials.jsx';
import ServiceConfigurator from '../components/ServiceConfigurator.jsx';
import ProtectionAssessmentForm from '../components/ProtectionAssessmentForm.jsx';

const stats = [
  {
    value: '14 минут',
    label: 'Среднее время реагирования',
    description: 'Группы быстрого реагирования Fortis Shield по Москве и регионам.'
  },
  {
    value: '98%',
    label: 'Успешно предотвращённых инцидентов',
    description: 'По итогам 2023–2024 гг. благодаря комплексным решениям.'
  },
  {
    value: '650+',
    label: 'Объектов под круглосуточной защитой',
    description: 'Бизнес, логистика, элитная недвижимость и критическая инфраструктура.'
  },
  {
    value: '24/7',
    label: 'Ситуационный центр',
    description: 'Непрерывный мониторинг, аналитика и связь с клиентами.'
  }
];

const Home = () => {
  return (
    <div className="page home-page">
      <section className="hero-section">
        <div className="hero-background">
          <img
            src="https://cdn.pixabay.com/photo/2016/11/29/06/21/adult-1866522_1280.jpg"
            alt="Профессиональная охрана на объекте"
          />
          <div className="hero-overlay" />
        </div>
        <div className="hero-content">
          <motion.span
            className="hero-badge"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
          >
            Премиальные охранные решения с гарантированной готовностью 24/7
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Fortis Shield — персональная безопасность бизнеса и частных резиденций по всей России
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            Мы объединяем вооружённые группы быстрого реагирования, ситуационный центр, интеллектуальные системы видеомониторинга
            и профессиональные команды для обеспечения непрерывной защиты. Каждое решение индивидуально и опирается на глубокий анализ рисков.
          </motion.p>
          <motion.div
            className="hero-actions"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <a className="btn-primary" href="/services">
              <FiShield />
              Индивидуальное решение
            </a>
            <a className="btn-outline" href="/contact">
              <FiArrowRightCircle />
              Связаться с офицером
            </a>
          </motion.div>
        </div>
      </section>

      <section className="section-padding">
        <SectionTitle
          overline="Стандарты Fortis Shield"
          title="Комплексные охранные решения нового уровня"
          description="Наша архитектура безопасности строится на трёх фундаментальных блоках: профессиональная команда, технологическая экосистема и прозрачная аналитика."
        />
        <div className="features-grid">
          <motion.article
            className="feature-card glass"
            whileHover={{ y: -8 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          >
            <div className="feature-icon">
              <FiUsers aria-hidden="true" />
            </div>
            <h3>Персональные команды</h3>
            <p>Контрольно-пропускные пункты, мобильные бойцы, VIP-эскорт. Каждый сотрудник проходит ежегодную переаттестацию и подготовку по протоколам реагирования.</p>
          </motion.article>
          <motion.article
            className="feature-card glass"
            whileHover={{ y: -8 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          >
            <div className="feature-icon">
              <FiVideo aria-hidden="true" />
            </div>
            <h3>Интеллектуальный мониторинг</h3>
            <p>Интеграция CCTV, тепловизоров, датчиков периметра и аналитики поведения. Подключение к ситуационному центру с мгновенными уведомлениями.</p>
          </motion.article>
          <motion.article
            className="feature-card glass"
            whileHover={{ y: -8 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          >
            <div className="feature-icon">
              <FiCommand aria-hidden="true" />
            </div>
            <h3>Управление рисками</h3>
            <p>Аудит, моделирование сценариев, план реагирования, тесты проникновения и непрерывные отчёты. Прозрачность и контроль на каждом этапе.</p>
          </motion.article>
        </div>
      </section>

      <section className="section-padding soft-bg">
        <SectionTitle
          overline="Результаты в цифрах"
          title="Стабильная защита, подтверждённая статистикой"
          description="Цифры — отражение нашей дисциплины и технологического превосходства."
        />
        <StatsGrid stats={stats} />
      </section>

      <section className="section-padding with-side">
        <div className="with-side-text">
          <SectionTitle
            overline="Физическая и технологическая охрана"
            title="Почувствуйте уверенность в завтрашнем дне"
            description="Патрулирование, контроль сопровождения, интеграция инженерных систем и безопасность персонала — всё в одном контуре."
          />
          <ul className="security-list">
            <li>Посты охраны и КПП, мобильные экипажи, скрытое наблюдение</li>
            <li>Комплекс CCTV, аналитика распознавания, контроль доступа по биометрии</li>
            <li>Дроны наблюдения, охранные роботы, мониторинг с тепловизорами</li>
            <li>VIP-сопровождение, защита мероприятий, безопасность руководителей</li>
          </ul>
          <a className="btn-link" href="/services">
            Увидеть полный перечень услуг
          </a>
        </div>
        <div className="with-side-media">
          <img
            src="https://cdn.pixabay.com/photo/2016/10/15/19/44/gun-1740614_1280.jpg"
            alt="Экипировка сотрудников охраны Fortis Shield"
          />
          <div className="floating-card">
            <span>Инцидентов за 2024: 0</span>
            <strong>Контрольный отчёт № FS-24/2211</strong>
            <p>Ситуационный центр подтверждает стабильность уровня риска.</p>
          </div>
        </div>
      </section>

      <section className="section-padding soft-bg">
        <SectionTitle
          overline="Точка входа"
          title="Проведите экспресс-оценку защищённости"
          description="Мы подготовим индивидуальный план защиты меньше чем за час после получения исходных данных."
        />
        <ProtectionAssessmentForm />
      </section>

      <section className="section-padding">
        <SectionTitle
          overline="Дов доверяют лидеры отраслей"
          title="Отзывы клиентов Fortis Shield"
          description="Каждый отзыв подтверждён службой контроля качества и зашифрован в корпоративном хранилище."
        />
        <Testimonials />
      </section>

      <section className="section-padding soft-bg">
        <SectionTitle
          overline="Гибкая конфигурация услуг"
          title="Соберите своё решение онлайн"
          description="Рассчитайте ориентировочный бюджет и узнайте, какие ресурсы мы подключим на вашем объекте."
        />
        <ServiceConfigurator />
      </section>

      <section className="section-padding cta-section">
        <div className="cta-content">
          <h2>Готовы к защите любого уровня сложности</h2>
          <p>Оперативный офицер Fortis Shield подключится к вашему проекту в течение 5 минут после запроса.</p>
          <div className="cta-actions">
            <a className="btn-primary" href="/contact">Запросить встречу</a>
            <a className="btn-outline" href="tel:+74951234567">Позвонить сейчас</a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;