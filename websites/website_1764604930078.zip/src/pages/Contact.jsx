import React from 'react';
import { motion } from 'framer-motion';
import { FiPhoneCall, FiMail, FiMapPin, FiClock, FiShield } from 'react-icons/fi';
import SectionTitle from '../components/SectionTitle.jsx';
import ContactForm from '../components/ContactForm.jsx';

const contactDetails = [
  {
    icon: <FiPhoneCall />,
    label: 'Дежурная линия',
    value: '+7 (495) 123-45-67',
    link: 'tel:+74951234567'
  },
  {
    icon: <FiMail />,
    label: 'Корпоративная почта',
    value: 'info@fortis-shield.ru',
    link: 'mailto:info@fortis-shield.ru'
  },
  {
    icon: <FiMapPin />,
    label: 'Операционный штаб',
    value: 'Россия, Москва, ул. Безопасности, 12',
    link: 'https://yandex.ru/maps'
  },
  {
    icon: <FiClock />,
    label: 'График работы',
    value: 'Ситуационный центр — круглосуточно'
  }
];

const Contact = () => (
  <div className="page">
    <section className="section-padding hero-min">
      <SectionTitle
        overline="Связаться с Fortis Shield"
        title="Ситуационный центр готов принять ваш запрос"
        description="Мы обеспечиваем незамедлительную реакцию на обращения и предоставляем индивидуальные предложения в течение часа."
      />
      <div className="contact-highlight">
        <FiShield size={20} aria-hidden="true" />
        <p>Все обращения фиксируются в защищённой системе и обрабатываются дежурным офицером уровня «Старший смены».</p>
      </div>
    </section>

    <section className="section-padding soft-bg">
      <div className="contact-grid">
        <div className="contact-info">
          {contactDetails.map((detail) => (
            <motion.div
              key={detail.label}
              className="contact-info-card"
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.4 }}
            >
              <div className="contact-icon">{detail.icon}</div>
              <div>
                <span>{detail.label}</span>
                {detail.link ? (
                  <a href={detail.link}>{detail.value}</a>
                ) : (
                  <p>{detail.value}</p>
                )}
              </div>
            </motion.div>
          ))}
          <div className="contact-alert">
            <h4>Физический визит</h4>
            <p>При визите в штаб необходимо иметь паспорт. Пропуск оформляется дежурным офицером по предварительной записи.</p>
          </div>
        </div>
        <div className="contact-form-wrapper">
          <h3>Оставьте заявку</h3>
          <p>Опишите задачу. Мы свяжемся в течение 5 минут для подтверждения и определения следующего шага.</p>
          <ContactForm />
        </div>
      </div>
    </section>

    <section className="section-padding">
      <div className="map-wrapper">
        <h3>Мы на карте</h3>
        <p>Для обсуждения конфиденциальных вопросов используйте выделенные переговорные комнаты нашего штаба.</p>
        <div className="map-iframe">
          <iframe
            title="Офис Fortis Shield"
            src="https://yandex.ru/map-widget/v1/?um=constructor%3A2f275f6f69b611b2df1b9a9d7a693fddaa9d3e7c1282c58e445b7344a5bc9a1f&amp;source=constructor"
            width="100%"
            height="320"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
          ></iframe>
        </div>
      </div>
    </section>
  </div>
);

export default Contact;