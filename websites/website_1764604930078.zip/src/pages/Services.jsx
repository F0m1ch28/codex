import React from 'react';
import { motion } from 'framer-motion';
import { FiShield, FiCamera, FiNavigation, FiAlertTriangle, FiUserCheck, FiMap } from 'react-icons/fi';
import SectionTitle from '../components/SectionTitle.jsx';
import ServiceConfigurator from '../components/ServiceConfigurator.jsx';

const services = [
  {
    icon: <FiShield />,
    title: 'Физическая охрана и посты',
    description: 'Вооружённые и невооружённые посты охраны, контроль доступа, досмотр, охрана периметра и внутренних зон.',
    points: ['КПП, рамки и металлодетекторы', 'Служба сопровождения и сопровождение грузов', 'Скрытое наблюдение и undercover-форматы', 'Дежурные инспекции и ночной контроль']
  },
  {
    icon: <FiCamera />,
    title: 'Видеомониторинг и аналитика',
    description: 'Интеллектуальные системы CCTV, тепловизоры, аналитика поведения и автоматическое оповещение ситуационного центра.',
    points: ['Проектирование и монтаж CCTV', 'Аналитика оставленных предметов, вторжений, скоплений', 'Хранение данных в защищённом контуре', 'Интеграция с системами контроля доступа']
  },
  {
    icon: <FiNavigation />,
    title: 'Мобильные патрули и дроны',
    description: 'Патрулирование на автомобилях и квадроциклах, мониторинг сложных периметров с воздушной поддержки.',
    points: ['Оперативные группы в радиусе 5 минут', 'Дрон-контроль удалённых зон', 'Ночной тепловой мониторинг', 'Протокол немедленного задержания']
  },
  {
    icon: <FiAlertTriangle />,
    title: 'Анализ рисков и аудит безопасности',
    description: 'Комплексная оценка угроз, разработка сценариев реагирования, тестирования готовности и обучение персонала.',
    points: ['Аудит действующих систем охраны', 'Моделирование сценариев угроз', 'Тестовые проникновения и стресс-тесты', 'Регламенты действий сотрудников клиента']
  },
  {
    icon: <FiUserCheck />,
    title: 'VIP сопровождение и персональная охрана',
    description: 'Персональная безопасность первых лиц, делегаций, частных лиц. Планирование маршрутов, разведка, бронированный транспорт.',
    points: ['Персональные телохранители', 'План эвакуации и резервные маршруты', 'Бронированные автомобили бизнес-класса', 'Сопровождение за рубежом']
  },
  {
    icon: <FiMap />,
    title: 'Безопасность территорий и поселков',
    description: 'Защита жилых комплексов, коттеджных поселков, курортов. Контроль въезда, видеонаблюдение, реагирование на месте.',
    points: ['Диспетчеризация и контроль сотрудников сервисов', 'Система цифровых пропусков для жителей', 'Патрульные экипажи по графику и по сигналу', 'Отчётность и аналитика для управляющей компании']
  }
];

const Services = () => (
  <div className="page">
    <section className="section-padding hero-min">
      <SectionTitle
        overline="Сервисы Fortis Shield"
        title="Полный спектр охранных и аналитических услуг"
        description="Мы соединяем опыт офицеров спецслужб, лицензированных охранников и аналитиков, чтобы обеспечить неоспоримую безопасность ваших активов."
      />
      <p className="lead-text">Каждый проект начинается с глубокого анализа рисков и разработки индивидуального протокола. Мы берем ответственность за результат и прозрачность процессов.</p>
    </section>

    <section className="section-padding soft-bg">
      <div className="services-grid">
        {services.map((service, index) => (
          <motion.article
            key={service.title}
            className="service-card"
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.45, delay: index * 0.08 }}
          >
            <div className="service-icon">{service.icon}</div>
            <h3>{service.title}</h3>
            <p>{service.description}</p>
            <ul>
              {service.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </motion.article>
        ))}
      </div>
    </section>

    <section className="section-padding">
      <SectionTitle
        overline="Премиальные опции"
        title="Дополнительные направления"
        description="Fortis Shield развивает расширенные сервисы для клиентов с высокими требованиями к конфиденциальности и скорости реагирования."
      />
      <div className="options-grid">
        <motion.div
          className="option-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.4 }}
        >
          <h4>Кибербезопасность физических объектов</h4>
          <p>Защита сетевой инфраструктуры, мониторинг доступа к системам безопасности, реагирование на цифровые инциденты.</p>
        </motion.div>
        <motion.div
          className="option-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.45 }}
        >
          <h4>Служба расследований</h4>
          <p>Сбор доказательной базы, взаимодействие с правоохранительными органами, аналитика внутренних угроз и мошенничества.</p>
        </motion.div>
        <motion.div
          className="option-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
        >
          <h4>Обучение и тренировки персонала</h4>
          <p>Тренинги по поведению при угрозах, эвакуации, взаимодействию с охраной и ситуационным центром.</p>
        </motion.div>
      </div>
    </section>

    <section className="section-padding soft-bg">
      <SectionTitle
        overline="Калькулятор решения"
        title="Подберите конфигурацию охраны"
        description="Онлайн-расчёт поможет определить базовый бюджет и состав команды. За точной сметой обратитесь к дежурному офицеру."
      />
      <ServiceConfigurator />
      <div className="note-text">
        <strong>Важно:</strong> Итоговый бюджет формируется после выезда специалиста и детального изучения объекта. Все расчёты конфиденциальны.
      </div>
    </section>
  </div>
);

export default Services;