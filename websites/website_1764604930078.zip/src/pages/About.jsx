import React from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../components/SectionTitle.jsx';
import TeamGrid from '../components/TeamGrid.jsx';

const timeline = [
  {
    year: '2014',
    title: 'Основание Fortis Shield',
    description: 'Команда офицеров спецподразделений создала агентство с фокусом на охрану высокорискованных объектов.'
  },
  {
    year: '2017',
    title: 'Запуск ситуационного центра',
    description: 'Построен 24/7 центр мониторинга в Москве, подключено более 150 объектов.'
  },
  {
    year: '2020',
    title: 'Развитие технологий',
    description: 'Интегрированы AI-аналитика видеопотоков, дроны наблюдения, собственные мобильные приложения.'
  },
  {
    year: '2023',
    title: 'Федеральное присутствие',
    description: 'Открыты оперативные базы в Санкт-Петербурге, Казани, Екатеринбурге и Новосибирске.'
  },
  {
    year: '2024',
    title: 'Премиальный стандарт',
    description: 'Разработаны гибридные решения для критической инфраструктуры и VIP-категории.'
  }
];

const About = () => (
  <div className="page">
    <section className="section-padding hero-min">
      <SectionTitle
        overline="О Fortis Shield"
        title="Профессионалы, которые берут безопасность на себя"
        description="Мы создаём стратегические щиты для бизнеса, государственных структур и частных лиц, объединяя людей, процессы и передовые технологии."
      />
      <p className="lead-text">Fortis Shield — лицензированное охранное агентство России. Мы работаем по принципу единого окна, обеспечивая охрану, мониторинг, аудит рисков, сопровождение и расследования.</p>
    </section>

    <section className="section-padding soft-bg">
      <div className="about-grid">
        <motion.div
          className="about-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.4 }}
        >
          <h3>Миссия</h3>
          <p>Предоставлять клиентам непрерывную уверенность в завтрашнем дне через сочетание силовой поддержки и интеллектуальных систем контроля безопасности.</p>
        </motion.div>
        <motion.div
          className="about-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.45 }}
        >
          <h3>Принципы</h3>
          <ul>
            <li>Абсолютная конфиденциальность</li>
            <li>Прозрачная отчётность и контроль</li>
            <li>Оперативность и дисциплина реагирования</li>
            <li>Этические стандарты и уважение к закону</li>
          </ul>
        </motion.div>
        <motion.div
          className="about-card"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
        >
          <h3>Сертификация</h3>
          <p>Лицензии Росгвардии, сертификаты ISO 18788, ISO 9001, подготовка сотрудников по стандартам ASIS, регулярные проверки компетенций.</p>
        </motion.div>
      </div>
    </section>

    <section className="section-padding">
      <SectionTitle
        overline="Эволюция"
        title="Ключевые этапы развития"
        description="Мы постоянно усиливаем наш периметр и расширяем возможности для клиентов."
      />
      <div className="timeline">
        {timeline.map((item, index) => (
          <motion.div
            key={item.year}
            className="timeline-item"
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.45, delay: index * 0.08 }}
          >
            <span className="timeline-year">{item.year}</span>
            <h4>{item.title}</h4>
            <p>{item.description}</p>
          </motion.div>
        ))}
      </div>
    </section>

    <section className="section-padding soft-bg">
      <SectionTitle
        overline="Команда Fortis Shield"
        title="Эксперты, отвечающие за вашу безопасность"
        description="Каждый руководитель направлений имеет многолетний опыт в силовых структурах, частной охране и управлении кризисами."
      />
      <TeamGrid />
    </section>

    <section className="section-padding">
      <div className="culture-card">
        <h3>Почему клиенты выбирают нас</h3>
        <ul>
          <li><strong>Конфиденциальность:</strong> закрытые каналы связи, NDA, шифрование всех отчётов.</li>
          <li><strong>Гибкость:</strong> персональные протоколы, интеграция с внутренними службами безопасности клиента.</li>
          <li><strong>Технологии:</strong> IoT-сенсоры, аналитика видео, цифровые пропуска, мобильные приложения для резидентов.</li>
          <li><strong>Ответственность:</strong> страхование ответственности, юридическая поддержка, постинцидентный анализ.</li>
        </ul>
      </div>
    </section>
  </div>
);

export default About;