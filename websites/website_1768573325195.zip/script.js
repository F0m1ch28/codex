document.addEventListener('DOMContentLoaded', function () {
    const body = document.body;
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            body.classList.toggle('nav-open');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                body.classList.remove('nav-open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('[data-cookie-accept]');
    const declineBtn = document.querySelector('[data-cookie-decline]');
    const customizeBtn = document.querySelector('[data-cookie-customize]');
    const consentKey = 'parameluknCookieConsent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.add('show');
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'accepted');
                cookieBanner.classList.remove('show');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'declined');
                cookieBanner.classList.remove('show');
            });
        }

        if (customizeBtn) {
            customizeBtn.addEventListener('click', () => {
                window.location.href = 'cookies.html';
            });
        }
    }
});