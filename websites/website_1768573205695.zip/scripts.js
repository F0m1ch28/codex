document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = primaryNav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (primaryNav.classList.contains('is-open')) {
                    primaryNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('[data-cookie="accept"]');
    const declineBtn = document.querySelector('[data-cookie="decline"]');
    const consentKey = 'disencaadsCookieConsent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.add('is-visible');
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'accepted');
                cookieBanner.classList.remove('is-visible');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'declined');
                cookieBanner.classList.remove('is-visible');
            });
        }
    }
});