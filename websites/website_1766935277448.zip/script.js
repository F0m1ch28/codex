(function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      siteNav.classList.toggle('is-open');
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
    });
  }

  const countdownContainer = document.querySelector('[data-countdown]');
  if (countdownContainer) {
    const dayEl = countdownContainer.querySelector('[data-countdown-days]');
    const hourEl = countdownContainer.querySelector('[data-countdown-hours]');
    const minuteEl = countdownContainer.querySelector('[data-countdown-minutes]');
    const secondEl = countdownContainer.querySelector('[data-countdown-seconds]');

    function getNextChristmas() {
      const now = new Date();
      const year = now.getMonth() === 11 && now.getDate() > 25 ? now.getFullYear() + 1 : now.getFullYear();
      return new Date(year, 11, 25, 0, 0, 0);
    }

    const targetDate = getNextChristmas();

    function updateCountdown() {
      const now = new Date();
      const diff = targetDate - now;
      if (diff <= 0) {
        dayEl.textContent = '00';
        hourEl.textContent = '00';
        minuteEl.textContent = '00';
        secondEl.textContent = '00';
        return;
      }
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      dayEl.textContent = String(days).padStart(2, '0');
      hourEl.textContent = String(hours).padStart(2, '0');
      minuteEl.textContent = String(minutes).padStart(2, '0');
      secondEl.textContent = String(seconds).padStart(2, '0');
    }

    updateCountdown();
    setInterval(updateCountdown, 1000);
  }

  const customForm = document.getElementById('custom-gift-form');
  if (customForm) {
    const baseSelect = customForm.querySelector('[name="base-box"]');
    const ribbonRadios = customForm.querySelectorAll('input[name="ribbon"]');
    const quantityInput = customForm.querySelector('[name="quantity"]');
    const messageInput = customForm.querySelector('[name="card-message"]');
    const previewImage = document.getElementById('box-preview');
    const summaryList = document.getElementById('summary-items');
    const totalPriceEl = document.getElementById('total-price');
    const quantityValue = document.getElementById('quantity-value');
    const summaryHeader = document.getElementById('summary-title');

    const basePackages = {
      'sparkling-christmas': {
        label: 'Sparkling Christmas Deluxe',
        price: 145,
        image: 'https://picsum.photos/seed/customchristmas/600/420'
      },
      'birthday-starlight': {
        label: 'Birthday Starlight Celebration',
        price: 120,
        image: 'https://picsum.photos/seed/custombirthday/600/420'
      },
      'winter-gourmet': {
        label: 'Winter Gourmet Feast',
        price: 165,
        image: 'https://picsum.photos/seed/customgourmet/600/420'
      },
      'joy-mini': {
        label: 'Joyful Mini Keepsake',
        price: 85,
        image: 'https://picsum.photos/seed/custommini/600/420'
      }
    };

    const addOnPrices = {
      'artisan-truffles': { label: 'Artisan Truffle Collection', price: 24 },
      'handmade-ornament': { label: 'Handmade Keepsake Ornament', price: 18 },
      'luxury-candle': { label: 'Luxury Candle Duo', price: 32 },
      'personalized-mug': { label: 'Personalized Holiday Mug', price: 22 },
      'confetti-fountain': { label: 'Birthday Confetti Fountain', price: 15 }
    };

    function getSelectedRibbon() {
      const selected = Array.from(ribbonRadios).find(function (radio) {
        return radio.checked;
      });
      return selected ? selected.value : '';
    }

    function updateQuantityDisplay() {
      if (quantityValue && quantityInput) {
        quantityValue.textContent = quantityInput.value;
      }
    }

    function buildSummary() {
      if (!baseSelect || !quantityInput || !summaryList || !totalPriceEl) return;

      const selectedBase = basePackages[baseSelect.value];
      if (!selectedBase) return;

      const selectedRibbon = getSelectedRibbon();
      const quantity = parseInt(quantityInput.value, 10) || 1;
      const message = messageInput ? messageInput.value.trim() : '';

      const checkedAddOns = Array.from(customForm.querySelectorAll('input[name="add-ons"]:checked'));
      const addOnDetails = checkedAddOns.map(function (input) {
        return addOnPrices[input.value];
      }).filter(Boolean);

      let subtotal = selectedBase.price;
      addOnDetails.forEach(function (addOn) {
        subtotal += addOn.price;
      });

      const ribbonLabel = selectedRibbon ? selectedRibbon.replace('-', ' ').replace(/\b\w/g, function (char) {
        return char.toUpperCase();
      }) + ' Ribbon' : 'Festive Ribbon';

      const total = subtotal * quantity;

      summaryList.innerHTML = '';
      const baseItem = document.createElement('li');
      baseItem.textContent = selectedBase.label + ' — $' + selectedBase.price;
      summaryList.appendChild(baseItem);

      addOnDetails.forEach(function (addOn) {
        const li = document.createElement('li');
        li.textContent = addOn.label + ' — $' + addOn.price;
        summaryList.appendChild(li);
      });

      const ribbonItem = document.createElement('li');
      ribbonItem.textContent = ribbonLabel;
      summaryList.appendChild(ribbonItem);

      if (message) {
        const messageItem = document.createElement('li');
        messageItem.textContent = 'Personal Message: "' + message + '"';
        summaryList.appendChild(messageItem);
      }

      totalPriceEl.textContent = '$' + total.toFixed(2);

      if (summaryHeader) {
        summaryHeader.textContent = 'Your ' + selectedBase.label + ' Box';
      }

      if (previewImage && selectedBase.image) {
        previewImage.setAttribute('src', selectedBase.image);
        previewImage.setAttribute('alt', selectedBase.label + ' preview');
      }
    }

    if (baseSelect) {
      baseSelect.addEventListener('change', buildSummary);
    }

    ribbonRadios.forEach(function (radio) {
      radio.addEventListener('change', buildSummary);
    });

    if (quantityInput) {
      quantityInput.addEventListener('input', function () {
        updateQuantityDisplay();
        buildSummary();
      });
      updateQuantityDisplay();
    }

    const addOnInputs = customForm.querySelectorAll('input[name="add-ons"]');
    addOnInputs.forEach(function (checkbox) {
      checkbox.addEventListener('change', buildSummary);
    });

    if (messageInput) {
      messageInput.addEventListener('input', buildSummary);
    }

    buildSummary();

    customForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const confirmation = document.getElementById('customizer-confirmation');
      if (confirmation) {
        confirmation.textContent = 'Your personalized gift box is ready! Our stylists will contact you within 24 hours to finalize every detail.';
        confirmation.classList.remove('hidden');
      }
      window.scrollTo({ top: customForm.offsetTop - 80, behavior: 'smooth' });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    let storageAvailable = true;

    try {
      const testKey = '__cookie_test__';
      localStorage.setItem(testKey, '1');
      localStorage.removeItem(testKey);
    } catch (error) {
      storageAvailable = false;
    }

    function hideBanner() {
      cookieBanner.classList.add('is-hidden');
    }

    function setConsent(value) {
      if (storageAvailable) {
        localStorage.setItem('giftBoxCookieConsent', value);
      }
      hideBanner();
    }

    if (storageAvailable) {
      const consentValue = localStorage.getItem('giftBoxCookieConsent');
      if (consentValue === 'accepted' || consentValue === 'declined') {
        hideBanner();
      }
    }

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        setConsent('accepted');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        setConsent('declined');
      });
    }
  }
})();