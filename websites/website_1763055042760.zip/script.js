document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('primaryMenu');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const navLinks = document.querySelectorAll('.primary-nav a');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu.classList.contains('open')) {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollBtn.style.display = 'flex';
            } else {
                scrollBtn.style.display = 'none';
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem('animalqdktCookieConsent');
        if (!consent) {
            cookieBanner.style.display = 'flex';
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('animalqdktCookieConsent', 'accepted');
            cookieBanner.style.display = 'none';
        });
    }
});