import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Seo
        title="Політика щодо файлів cookie"
        description="Дізнайтеся, як ми використовуємо файли cookie на сайті та як керувати налаштуваннями."
      />
      <section className="section">
        <div className="container">
          <h1 className="sectionTitle">Політика щодо файлів cookie</h1>
          <div className={styles.content}>
            <p>Ця політика описує, як ми використовуємо файли cookie та схожі технології на сайті.</p>

            <h2>1. Що таке cookie?</h2>
            <p>
              Cookie — це невеликі текстові файли, які зберігаються на вашому пристрої та допомагають нам розпізнавати вас під час наступних відвідувань.
            </p>

            <h2>2. Які cookie ми використовуємо?</h2>
            <ul>
              <li>Необхідні cookie — забезпечують коректну роботу сайту (форма, навігація).</li>
              <li>Аналітичні cookie — допомагають нам розуміти, як відвідувачі користуються сайтом.</li>
            </ul>

            <h2>3. Як керувати cookie?</h2>
            <p>
              Ви можете змінити налаштування cookie у браузері або видалити файли вручну. Зверніть увагу, що відключення необхідних cookie може вплинути на функціональність сайту.
            </p>

            <h2>4. Контакт</h2>
            <p>Якщо у вас є запитання щодо політики cookie, напишіть нам: info@dresirovanie-sobak.pl.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;