import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const statsData = [
  { label: 'Років професійного досвіду', value: 12, suffix: '+' },
  { label: 'Німецьких вівчарок під опікою', value: 350, suffix: '+' },
  { label: 'Годин тренувань щорічно', value: 1200, suffix: '+' },
  { label: 'Рівень задоволених клієнтів', value: 98, suffix: '%' },
];

const advantages = [
  {
    title: 'Індивідуальний підхід',
    description:
      'Кожна програма дресирування створюється з урахуванням віку, темпераменту та завдань конкретної вівчарки.',
    icon: '🎯',
  },
  {
    title: 'Досвід з вівчарками',
    description:
      '12 років спеціалізованої практики з робочими та шоу-лініями німецьких вівчарок у Польщі.',
    icon: '🐕',
  },
  {
    title: 'Сучасні методи',
    description:
      'Використовуємо позитивне підкріплення, контроль емоцій та підвищення мотивації, уникаючи жорстких методів.',
    icon: '⚙️',
  },
  {
    title: 'Бездоганний результат',
    description:
      'Підготовка собак-охоронців, компаньйонів та спортсменів з гарантією стабільної поведінки.',
    icon: '🏆',
  },
];

const processSteps = [
  {
    title: 'Стартова консультація',
    text: 'Знайомимося з собакою, збираємо інформацію про цілі, режим та виклики. Формуємо базову діагностику.',
  },
  {
    title: 'Стратегічний план',
    text: 'Готуємо погоджений план занять, розподіляємо домашні завдання та формуємо календар зустрічей.',
  },
  {
    title: 'Тренувальні сесії',
    text: 'Проводимо практичні заняття у Варшаві чи Кракові, відпрацьовуємо послух, захист та побутову поведінку.',
  },
  {
    title: 'Підтримка власника',
    text: 'Навчаємо власника технікам управління, супроводжуємо після завершення програми для закріплення навичок.',
  },
];

const testimonials = [
  {
    name: 'Оксана та Макс',
    role: 'Власники вівчарки Айко (Варшава)',
    quote:
      'За три місяці Айко з некерованого підлітка перетворився на уважного партнера. Команда працює дуже делікатно та системно.',
    image: 'https://picsum.photos/200/200?random=21',
  },
  {
    name: 'Роман',
    role: 'Охоронна компанія (Краків)',
    quote:
      'Отримали ідеально підготовленого собаку-охоронця, який чудово реагує на команди та швидко перемикається між режимами.',
    image: 'https://picsum.photos/200/200?random=22',
  },
  {
    name: 'Ірина',
    role: 'Власниця виставкової вівчарки (Варшава)',
    quote:
      'Професіонали, які пояснюють кожен крок. Працюємо як одна команда, результати видно після кожного заняття.',
    image: 'https://picsum.photos/200/200?random=23',
  },
];

const teamMembers = [
  {
    name: 'Тарас Мельник',
    role: 'Головний кінолог, захисна підготовка',
    description:
      'Сертифікований тренер FCI, спеціалізується на побудові службового послуху та підготовці собак до IPO/IGP.',
    image: 'https://picsum.photos/400/400?random=24',
  },
  {
    name: 'Марія Ковальська',
    role: 'Кінолог-поведінковий терапевт',
    description:
      'Працює з корекцією поведінки, страхами та агресією. Використовує позитивне підкріплення та ігрові методи.',
    image: 'https://picsum.photos/400/400?random=25',
  },
  {
    name: 'Анджей Новак',
    role: 'Спеціаліст з кінологічної підготовки в місті',
    description:
      'Організовує заняття у міському середовищі Варшави та Кракова, готує собак до службової роботи.',
    image: 'https://picsum.photos/400/400?random=26',
  },
];

const projectsData = [
  {
    id: 1,
    title: 'Програма охоронної підготовки «Варшава-Сіті»',
    category: 'Варшава',
    image: 'https://picsum.photos/1200/800?random=27',
    description:
      'Комплексна робота з трьома вівчарками для охоронної компанії: патрулювання, фільтрація та контроль.',
  },
  {
    id: 2,
    title: 'Сімейний послух та соціалізація «Краків-Казімеж»',
    category: 'Краків',
    image: 'https://picsum.photos/1200/800?random=28',
    description:
      'Навчання молодої вівчарки співіснувати з дітьми та іншими тваринами у насиченому міському середовищі.',
  },
  {
    id: 3,
    title: 'Спортивна підготовка до IGP',
    category: 'Варшава',
    image: 'https://picsum.photos/1200/800?random=29',
    description:
      'Підготовка спортсмена з дисциплін послуху та захисту, робота над драйвом та концентрацією.',
  },
  {
    id: 4,
    title: 'Програма «Старт щеняти»',
    category: 'Краків',
    image: 'https://picsum.photos/1200/800?random=30',
    description:
      'Структурний розвиток щеняти: базові команди, самоконтроль, ігри для закладання правильних звичок.',
  },
];

const faqData = [
  {
    question: 'З якого віку можна починати тренування німецької вівчарки?',
    answer:
      'Починати можемо з 8-10 тижнів у форматі щенячого курсу. Основи послуху та соціалізації закладаються через ігрові сценарії та правильну взаємодію в сім’ї.',
  },
  {
    question: 'Чи працюєте ви з дорослими собаками, які мають проблемну поведінку?',
    answer:
      'Так. Проводимо повну діагностику, визначаємо тригери та формуємо план корекції. Власник проходить навчання, щоб закріпити результат у повсякденному житті.',
  },
  {
    question: 'Де проходять заняття у Варшаві та Кракові?',
    answer:
      'Маємо власні кінологічні майданчики у кожному місті, а також організовуємо виїзні тренування на території клієнта чи у міському середовищі.',
  },
  {
    question: 'Скільки часу потрібно для помітного результату?',
    answer:
      'Перші зміни помітні вже після стартових занять, але для стабільного результату рекомендуємо програму від 6 до 12 тижнів із регулярними тренуваннями та домашніми сесіями.',
  },
];

const blogPosts = [
  {
    id: 1,
    title: '5 ключових сигналів, що німецькій вівчарці потрібна корекція поведінки',
    excerpt:
      'Розпізнайте ранні маркери тривожності чи агресії, щоб вчасно підтримати собаку і уникнути ризиків.',
    image: 'https://picsum.photos/600/400?random=31',
    link: '/posluhy',
  },
  {
    id: 2,
    title: 'Як поєднати спортивні тренування та сімейне життя вівчарки',
    excerpt:
      'Говоримо про баланс фізичного навантаження, розумових вправ та відпочинку для гармонійного розвитку.',
    image: 'https://picsum.photos/600/400?random=32',
    link: '/pro-nas',
  },
  {
    id: 3,
    title: 'Топ-7 вправ для розвитку послуху «з першого виклику»',
    excerpt:
      'Практичні вправи, які ми впроваджуємо на тренуваннях у Варшаві та Кракові для бездоганного послуху.',
    image: 'https://picsum.photos/600/400?random=33',
    link: '/posluhy',
  },
];

const servicesHighlights = [
  {
    title: 'Послух та контроль',
    description: 'Розвиток бездоганного відгуку, витримки та керованості в умовах міста й службової роботи.',
    icon: '🧭',
  },
  {
    title: 'Підготовка собак-охоронців',
    description: 'Формуємо впевнену охоронну поведінку з чітким переключенням між режимами.',
    icon: '🛡️',
  },
  {
    title: 'Корекція поведінки',
    description: 'Працюємо з агресією, страхами, реактивністю, навчаємо технікам управління власників.',
    icon: '🧠',
  },
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [activeFilter, setActiveFilter] = useState('Усі');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) =>
        prev.map((value, index) => {
          const target = statsData[index].value;
          if (value >= target) return target;
          const increment = Math.ceil(target / 40);
          return Math.min(value + increment, target);
        })
      );
    }, 80);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Усі') return projectsData;
    return projectsData.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  return (
    <div className={styles.page}>
      <Seo
        title="Професійне дресерування німецьких вівчарок у Варшаві та Кракові"
        description="Кінологічний центр, що спеціалізується на дресируванні німецьких вівчарок у Варшаві та Кракові. Службова підготовка, корекція поведінки, собаки-охоронці."
      />

      <section className={`${styles.hero} section`} id="hero">
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>Варшава • Краків</span>
            <h1 className={styles.heroTitle}>Професійне дресерування німецьких вівчарок</h1>
            <p className={styles.heroText}>
              Допомагаємо німецьким вівчаркам розкривати потенціал — від слухняного компаньйона до висококласного охоронця. Системна робота з поведінкою, мотивацією та дисципліною.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className="btnPrimary">
                Записатися на консультацію
              </Link>
              <Link to="/posluhy" className="btnSecondary">
                Переглянути програми
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="advantages-heading">
        <div className="container">
          <h2 id="advantages-heading" className="sectionTitle">
            Наші переваги для власників вівчарок
          </h2>
          <p className="sectionSubtitle">
            Ми поєднуємо методики кінологів Польщі та Європи, щоб ви отримали собаку з бездоганним послухом, стабільною психікою та безпекою для родини.
          </p>
          <div className={styles.advantagesGrid}>
            {advantages.map((item) => (
              <article key={item.title} className={styles.advantageCard}>
                <span aria-hidden="true" className={styles.advantageIcon}>
                  {item.icon}
                </span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.specialization} section`} aria-labelledby="specialization-heading">
        <div className="container">
          <div className={styles.specializationContent}>
            <div>
              <h2 id="specialization-heading" className="sectionTitle">
                Спеціалізація — німецькі вівчарки
              </h2>
              <p>
                Німецькі вівчарки відомі розумом, силою та відданістю. Щоб ці якості працювали на вас, важлива системна підготовка. Ми знаємо, як розкрити природні інстинкти, не втрачаючи контролю.
              </p>
              <ul className={styles.specializationList}>
                <li>Працюємо з робочими, спортивними та сімейними лініями породи.</li>
                <li>Баланс між охоронним інстинктом і керованою поведінкою.</li>
                <li>Вчимо стабільності реакцій навіть у стресових ситуаціях.</li>
                <li>Ділимося сценаріями тренувань для самостійних занять вдома.</li>
              </ul>
            </div>
            <div className={styles.specializationMedia}>
              <img
                src="https://picsum.photos/800/600?random=12"
                alt="Тренування німецької вівчарки на відкритому майданчику"
              />
              <div className={styles.specializationNote}>
                <strong>Фокус на деталях:</strong> фіксуємо правильну позицію, слухняність та мотивацію собаки.
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.stats} section`} aria-label="Наші досягнення">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((item, index) => (
              <div key={item.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {stats[index]}
                  {item.suffix}
                </span>
                <span className={styles.statLabel}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="geography-heading">
        <div className="container">
          <h2 id="geography-heading" className="sectionTitle">
            Географія послуг — Варшава та Краків
          </h2>
          <p className="sectionSubtitle">
            Працюємо на двох кінологічних майданчиках і виїжджаємо до клієнтів у межах Варшави та Кракова. Забезпечуємо однаково високий стандарт тренувань у кожному місті.
          </p>
          <div className={styles.cityGrid}>
            <article className={styles.cityCard}>
              <img src="https://picsum.photos/600/400?random=13" alt="Панорама Варшави з тренувальним майданчиком" />
              <div className={styles.cityBody}>
                <h3>Варшава</h3>
                <p>
                  Закритий майданчик у Вілянуві з обладнанням для послуху та захисної підготовки. Проводимо тренування в умовах міста та на приватних територіях.
                </p>
                <ul>
                  <li>Консультації для нових власників вівчарок.</li>
                  <li>Підготовка до виставок та службових випробувань.</li>
                  <li>Програми охорони для бізнесу та приватних маєтків.</li>
                </ul>
              </div>
            </article>
            <article className={styles.cityCard}>
              <img src="https://picsum.photos/600/400?random=14" alt="Урбаністичний краєвид Кракова" />
              <div className={styles.cityBody}>
                <h3>Краків</h3>
                <p>
                  Просторий тренувальний майданчик у Подгуже, а також виїзні заняття в історичному центрі. Навчимо вівчарку впевнено почуватися серед туристів і транспорту.
                </p>
                <ul>
                  <li>Спеціалізація на міській адаптації та соціалізації.</li>
                  <li>Програми «Старт щеняти» та корекція поведінки.</li>
                  <li>Підготовка собак-охоронців для приватних резиденцій.</li>
                </ul>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="process-heading">
        <div className="container">
          <h2 id="process-heading" className="sectionTitle">
            Процес роботи: від першого дзвінка до впевненої вівчарки
          </h2>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.processNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.servicesPreview} section`} aria-labelledby="services-preview-heading">
        <div className="container">
          <h2 id="services-preview-heading" className="sectionTitle">
            Основні напрямки роботи
          </h2>
          <div className={styles.servicesGrid}>
            {servicesHighlights.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span aria-hidden="true" className={styles.serviceIcon}>
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/posluhy" className={styles.serviceLink}>
                  Детальніше про програму →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.projects} section`} aria-labelledby="projects-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="projects-heading" className="sectionTitle">
              Практичні кейси та проєкти
            </h2>
            <div className={styles.filters}>
              {['Усі', 'Варшава', 'Краків'].map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setActiveFilter(filter)}
                  className={`${styles.filterButton} ${activeFilter === filter ? styles.filterButtonActive : ''}`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} />
                <div className={styles.projectBody}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} section`} aria-labelledby="testimonials-heading">
        <div className="container">
          <div className={styles.testimonialHeader}>
            <h2 id="testimonials-heading" className="sectionTitle">
              Відгуки власників вівчарок
            </h2>
            <div className={styles.testimonialControls}>
              <button type="button" onClick={() => setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)} aria-label="Попередній відгук">
                ‹
              </button>
              <button type="button" onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)} aria-label="Наступний відгук">
                ›
              </button>
            </div>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${index === currentTestimonial ? styles.testimonialActive : ''}`}
                aria-hidden={index !== currentTestimonial}
              >
                <img src={testimonial.image} alt={`${testimonial.name}, ${testimonial.role}`} />
                <blockquote>{testimonial.quote}</blockquote>
                <div className={styles.testimonialMeta}>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.team} section`} aria-labelledby="team-heading">
        <div className="container">
          <h2 id="team-heading" className="sectionTitle">
            Команда кінологів
          </h2>
          <p className="sectionSubtitle">
            Працюємо як одна команда, щоб підтримати власника та собаку на кожному етапі. Кожен спеціаліст відповідає за свій блок тренувань і супровід.
          </p>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={`${member.name} — ${member.role}`} />
                </div>
                <div className={styles.teamBody}>
                  <h3>{member.name}</h3>
                  <span className={styles.teamRole}>{member.role}</span>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.faq} section`} aria-labelledby="faq-heading">
        <div className="container">
          <h2 id="faq-heading" className="sectionTitle">
            Часті запитання
          </h2>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => setOpenFaq(index === openFaq ? null : index)}
                  aria-expanded={openFaq === index}
                  aria-controls={`faq-panel-${index}`}
                >
                  <span>{item.question}</span>
                  <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
                </button>
                <div
                  id={`faq-panel-${index}`}
                  className={`${styles.faqPanel} ${openFaq === index ? styles.faqPanelOpen : ''}`}
                >
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blog} section`} aria-labelledby="blog-heading">
        <div className="container">
          <h2 id="blog-heading" className="sectionTitle">
            Останні поради з дресирування
          </h2>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.title} />
                <div className={styles.blogBody}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>
                    Дізнатися більше →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.cta} section`} aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.ctaContent}>
            <h2 id="cta-heading">Готові розпочати навчання вашої вівчарки?</h2>
            <p>
              Залиште заявку — зв’яжемося вже сьогодні, щоб узгодити консультацію у Варшаві чи Кракові та обговорити цілі тренувань.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/kontakty" className="btnPrimary">
                Зв&apos;язатися з нами
              </Link>
              <Link to="/pro-nas" className="btnSecondary">
                Дізнатися про команду
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;