import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const Contact = () => {
  const [formValues, setFormValues] = useState({
    name: '',
    email: '',
    phone: '',
    city: 'Варшава',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) newErrors.name = "Вкажіть ім'я";
    if (!formValues.email.trim()) {
      newErrors.email = 'Вкажіть email';
    } else if (!/^[\w-.]+@[\w-]+\.[a-z]{2,}$/i.test(formValues.email.trim())) {
      newErrors.email = 'Невірний формат email';
    }
    if (!formValues.phone.trim()) newErrors.phone = 'Вкажіть телефон';
    if (!formValues.message.trim()) newErrors.message = 'Опишіть мету звернення';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      console.log('Форма відправлена:', formValues);
    }
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Контакти — дресирування вівчарок Варшава та Краків"
        description="Зв'яжіться з кінологами з Варшави та Кракова. Професійне дресирування німецьких вівчарок, консультації, запис на заняття."
      />
      <section className="section">
        <div className="container">
          <div className={styles.hero}>
            <div>
              <h1 className="sectionTitle">Контакти</h1>
              <p className="sectionSubtitle">
                Оберіть зручне місто для тренувань чи залиште заявку на виїзд. Відповімо протягом робочого дня та допоможемо підібрати програму.
              </p>
            </div>
            <div className={styles.contactInfo}>
              <div>
                <h2>Адреси майданчиків</h2>
                <p>Варшава, вул. Собача, 10 / Краків, вул. Песя, 5</p>
              </div>
              <div>
                <h2>Телефон</h2>
                <a href="tel:+48123456789">+48 123 456 789</a>
              </div>
              <div>
                <h2>Email</h2>
                <a href="mailto:info@dresirovanie-sobak.pl">info@dresirovanie-sobak.pl</a>
              </div>
            </div>
          </div>

          <div className={styles.layout}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate aria-label="Форма зворотнього зв'язку">
              <div className={styles.field}>
                <label htmlFor="name">Ім&apos;я *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formValues.name}
                  onChange={(e) => setFormValues({ ...formValues, name: e.target.value })}
                  aria-invalid={errors.name ? 'true' : 'false'}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Email *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formValues.email}
                  onChange={(e) => setFormValues({ ...formValues, email: e.target.value })}
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="phone">Телефон *</label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formValues.phone}
                  onChange={(e) => setFormValues({ ...formValues, phone: e.target.value })}
                  aria-invalid={errors.phone ? 'true' : 'false'}
                />
                {errors.phone && <span className={styles.error}>{errors.phone}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="city">Місто для тренувань</label>
                <select
                  id="city"
                  name="city"
                  value={formValues.city}
                  onChange={(e) => setFormValues({ ...formValues, city: e.target.value })}
                >
                  <option value="Варшава">Варшава</option>
                  <option value="Краків">Краків</option>
                  <option value="Інше">Інше (виїзд)</option>
                </select>
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Опишіть вашу вівчарку та запит *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formValues.message}
                  onChange={(e) => setFormValues({ ...formValues, message: e.target.value })}
                  aria-invalid={errors.message ? 'true' : 'false'}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>

              <button type="submit" className="btnPrimary">
                Надіслати запит
              </button>
              {submitted && <p className={styles.success}>Дякуємо! Ми надішлемо відповідь найближчим часом.</p>}
            </form>

            <div className={styles.map}>
              <img
                src="https://picsum.photos/900/500?random=40"
                alt="Локації тренувальних майданчиків у Варшаві та Кракові"
              />
              <div className={styles.mapNote}>
                <strong>Виїзд до клієнта</strong>
                <p>Можливий у межах Варшави та Кракова після узгодження з тренером.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;