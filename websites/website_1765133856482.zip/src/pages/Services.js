import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const services = [
  {
    id: 'obedience',
    title: 'Індивідуальні програми послуху',
    description:
      'Побудова чіткого виконання команд, контроль імпульсів, витримка та робота поруч. Розробляємо домашні завдання, щоб закріпити навички між тренуваннями.',
    benefits: ['Відгук з першого виклику', 'Корекція небажаних звичок', 'Підтримка у побутових ситуаціях'],
    image: 'https://picsum.photos/900/600?random=36',
  },
  {
    id: 'guard',
    title: 'Підготовка собак-охоронців',
    description:
      'Програма для службової та приватної охорони. Відпрацьовуємо фокус на загрозі, контроль укусу та швидке переключення на режим «спокій».',
    benefits: ['Оцінювання охоронного потенціалу', 'Робота на спеціальному обладнанні', 'Психологічна стійкість'],
    image: 'https://picsum.photos/900/600?random=37',
  },
  {
    id: 'behavior',
    title: 'Корекція поведінки',
    description:
      'Розв’язуємо проблеми з агресією, ревнощами, страхами. Проводимо аналіз середовища, вчимо правильній реакції власника і встановлюємо нові правила поведінки.',
    benefits: ['Детальна діагностика', 'План дій для родини', 'Супровід до стабільного результату'],
    image: 'https://picsum.photos/900/600?random=38',
  },
  {
    id: 'puppy',
    title: 'Програма для щенят «Старт»',
    description:
      'Формуємо у щеняти базові команди, соціалізацію, контроль емоцій та навички життя в місті. Навчаємо власника правильним ритуалам догляду.',
    benefits: ['Побутові навички', 'Ігрові вправи для розвитку', 'Підготовка до майбутніх дисциплін'],
    image: 'https://picsum.photos/900/600?random=39',
  },
];

const Services = () => {
  const [activeService, setActiveService] = useState(services[0].id);

  const selectedService = services.find((service) => service.id === activeService);

  return (
    <div className={styles.page}>
      <Seo
        title="Послуги дресирування німецьких вівчарок"
        description="Індивідуальні програми дресирування німецьких вівчарок: послух, охорона, корекція поведінки, робота зі щенятами."
      />
      <section className="section">
        <div className="container">
          <header className={styles.header}>
            <h1 className="sectionTitle">Послуги та програми</h1>
            <p className="sectionSubtitle">
              Працюємо з власниками німецьких вівчарок, які хочуть мати слухняного, психічно стійкого та безпечного собаку. Кожен курс адаптуємо до потреб сім’ї чи служби.
            </p>
          </header>

          <div className={styles.layout}>
            <div className={styles.sidebar} role="tablist" aria-label="Категорії послуг">
              {services.map((service) => (
                <button
                  key={service.id}
                  type="button"
                  className={`${styles.tabButton} ${activeService === service.id ? styles.active : ''}`}
                  onClick={() => setActiveService(service.id)}
                  aria-selected={activeService === service.id}
                  role="tab"
                  id={`tab-${service.id}`}
                  aria-controls={`panel-${service.id}`}
                >
                  {service.title}
                </button>
              ))}
            </div>

            <div className={styles.content} role="tabpanel" id={`panel-${selectedService.id}`} aria-labelledby={`tab-${selectedService.id}`}>
              <div className={styles.imageWrapper}>
                <img src={selectedService.image} alt={selectedService.title} />
              </div>
              <div className={styles.info}>
                <h2>{selectedService.title}</h2>
                <p>{selectedService.description}</p>
                <ul>
                  {selectedService.benefits.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <p className={styles.note}>
                  Заняття проводимо на наших майданчиках у Варшаві та Кракові або на території клієнта після попереднього узгодження.
                </p>
              </div>
            </div>
          </div>

          <section className={styles.extra}>
            <div className={styles.extraCard}>
              <h3>Навчання власника</h3>
              <p>Пояснюємо логіку кожної вправи, щоб власник міг продовжувати тренування вдома та закріплювати результат.</p>
            </div>
            <div className={styles.extraCard}>
              <h3>Тестування навичок</h3>
              <p>Проводимо контрольні заняття в міських умовах, на змаганнях або на території клієнта для перевірки стабільності поведінки.</p>
            </div>
            <div className={styles.extraCard}>
              <h3>Пакет звітів</h3>
              <p>Після кожного блоку занять надаємо звіт із рекомендаціями, відеоприкладами та домашніми завданнями.</p>
            </div>
          </section>
        </div>
      </section>
    </div>
  );
};

export default Services;