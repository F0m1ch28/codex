import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  return (
    <div className="appWrapper">
      <Header />
      <main className="mainContent" id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/pro-nas" element={<About />} />
          <Route path="/posluhy" element={<Services />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/umovy-vykorystannia" element={<Terms />} />
          <Route path="/polityka-konfidentsiinosti" element={<Privacy />} />
          <Route path="/polityka-failiv-cookie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;