import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Нижній колонтитул сайту">
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}>
          <h2 className={styles.title}>Професійне дресерування собак</h2>
          <p className={styles.subtitle}>
            Надійний партнер у вихованні та підготовці німецьких вівчарок у Варшаві та Кракові.
          </p>
          <div className={styles.socials} aria-label="Соціальні мережі">
            <a href="#" aria-label="Facebook" className={styles.socialLink}>
              <span aria-hidden="true">Fb</span>
            </a>
            <a href="#" aria-label="Instagram" className={styles.socialLink}>
              <span aria-hidden="true">Ig</span>
            </a>
            <a href="#" aria-label="YouTube" className={styles.socialLink}>
              <span aria-hidden="true">Yt</span>
            </a>
          </div>
        </div>

        <div className={styles.linksWrapper}>
          <div>
            <h3 className={styles.heading}>Навігація</h3>
            <ul className={styles.linkList}>
              <li>
                <Link to="/posluhy" className={styles.link}>
                  Послуги
                </Link>
              </li>
              <li>
                <Link to="/pro-nas" className={styles.link}>
                  Про нас
                </Link>
              </li>
              <li>
                <Link to="/kontakty" className={styles.link}>
                  Контакти
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className={styles.heading}>Правова інформація</h3>
            <ul className={styles.linkList}>
              <li>
                <Link to="/umovy-vykorystannia" className={styles.link}>
                  Умови використання
                </Link>
              </li>
              <li>
                <Link to="/polityka-konfidentsiinosti" className={styles.link}>
                  Політика конфіденційності
                </Link>
              </li>
              <li>
                <Link to="/polityka-failiv-cookie" className={styles.link}>
                  Політика щодо файлів cookie
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className={styles.heading}>Контакти</h3>
            <address className={styles.address}>
              <span>Варшава, вул. Собача, 10 / Краків, вул. Песя, 5</span>
              <a className={styles.link} href="tel:+48123456789">
                +48 123 456 789
              </a>
              <a className={styles.link} href="mailto:info@dresirovanie-sobak.pl">
                info@dresirovanie-sobak.pl
              </a>
            </address>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className="container">
          <p className={styles.copy}>&copy; {new Date().getFullYear()} Професійне дресерування собак. Усі права захищені.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;