import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      const consent = localStorage.getItem('cookieConsent');
      if (!consent) {
        setVisible(true);
      }
    } catch (error) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem('cookieConsent', 'accepted');
    } catch (error) {
      // ignore
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Сповіщення про використання файлів cookie">
      <p className={styles.text}>
        Ми використовуємо файли cookie, щоб зробити ваш досвід роботи з сайтом ще кращим. Продовжуючи перегляд, ви погоджуєтеся з нашим використанням файлів cookie. Деталі у{' '}
        <Link to="/polityka-failiv-cookie" className={styles.link}>
          політиці щодо файлів cookie
        </Link>
        .
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Прийняти
      </button>
    </div>
  );
};

export default CookieBanner;