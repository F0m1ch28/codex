document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navMenu.classList.toggle("active");
        });
        navMenu.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (window.innerWidth < 768) {
                    navMenu.classList.remove("active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptCookies = document.querySelector(".accept-cookies");
    if (cookieBanner) {
        const cookieChoice = localStorage.getItem("tipstaksdtCookieChoice");
        if (cookieChoice === "accepted") {
            cookieBanner.classList.add("is-hidden");
        }
        if (acceptCookies) {
            acceptCookies.addEventListener("click", function (event) {
                event.preventDefault();
                localStorage.setItem("tipstaksdtCookieChoice", "accepted");
                cookieBanner.classList.add("is-hidden");
            });
        }
    }
});