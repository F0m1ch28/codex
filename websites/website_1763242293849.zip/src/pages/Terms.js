import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Nutzungsbedingungen | GreenTech Solutions</title>
      <meta
        name="description"
        content="Nutzungsbedingungen der Website von GreenTech Solutions. Informationen zu Nutzung, Haftung und Rechten."
      />
      <link rel="canonical" href="https://www.greentech-solutions.de/nutzungsbedingungen" />
    </Helmet>

    <section className={styles.wrapper}>
      <div className="container">
        <div className={styles.header}>
          <h1>Nutzungsbedingungen</h1>
          <p>
            Willkommen auf der Website von GreenTech Solutions. Mit dem Zugriff auf unsere Inhalte erklären Sie sich mit
            den folgenden Bedingungen einverstanden.
          </p>
        </div>

        <article className={styles.section}>
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Nutzungsbedingungen gelten für alle Seiten und Inhalte unter der Domain greentech-solutions.de. Abweichende
            Vereinbarungen sind nur in schriftlicher Form gültig.
          </p>
        </article>

        <article className={styles.section}>
          <h2>2. Inhalte und Verfügbarkeit</h2>
          <p>
            Wir bemühen uns um aktuelle und sorgfältig recherchierte Informationen. Dennoch übernehmen wir keine Gewähr für
            Vollständigkeit, Richtigkeit oder ständige Verfügbarkeit der bereitgestellten Inhalte.
          </p>
          <p>
            Änderungen und Aktualisierungen der Informationen behalten wir uns vor. Wir können das Angebot jederzeit ohne
            vorherige Ankündigung verändern oder einstellen.
          </p>
        </article>

        <article className={styles.section}>
          <h2>3. Haftung</h2>
          <p>
            Haftungsansprüche gegen GreenTech Solutions, die sich auf Schäden materieller oder ideeller Art beziehen und durch
            die Nutzung der Website verursacht wurden, sind ausgeschlossen, sofern kein nachweislich vorsätzliches oder grob
            fahrlässiges Verschulden vorliegt.
          </p>
        </article>

        <article className={styles.section}>
          <h2>4. Urheberrecht</h2>
          <p>
            Die durch GreenTech Solutions erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen
            Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung oder jede Art der Verwertung bedarf unserer
            ausdrücklichen Zustimmung.
          </p>
        </article>

        <article className={styles.section}>
          <h2>5. Externe Links</h2>
          <p>
            Unsere Website enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Für
            diese fremden Inhalte übernehmen wir keine Gewähr. Für Inhalte der verlinkten Seiten ist stets der jeweilige
            Anbieter oder Betreiber verantwortlich.
          </p>
        </article>

        <article className={styles.section}>
          <h2>6. Anwendbares Recht</h2>
          <p>
            Es gilt das Recht der Bundesrepublik Deutschland. Erfüllungsort und Gerichtsstand ist München, soweit gesetzlich
            zulässig.
          </p>
        </article>

        <div className={styles.notice}>
          <p>
            Stand: März 2024. Bei Fragen erreichen Sie uns unter +49 89 12345678 oder via{' '}
            <a href="mailto:info@greentech-solutions.de">info@greentech-solutions.de</a>.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Terms;