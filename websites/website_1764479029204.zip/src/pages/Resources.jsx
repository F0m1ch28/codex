const articles = [
  {
    title: 'Budgeting in peso and dollar terms',
    summaryEn: 'Learn how to align peso incomes with USD-linked obligations without overshooting conversions.',
    summaryEs: 'Aprende a equilibrar ingresos en pesos con obligaciones en dólares sin sobrerreaccionar en las conversiones.',
    link: '#',
  },
  {
    title: 'Understanding Argentine CPI categories',
    summaryEn: 'Break down CPI divisions and how they relate to household spending buckets.',
    summaryEs: 'Desglosa las divisiones del IPC y cómo se relacionan con los gastos del hogar.',
    link: '#',
  },
  {
    title: 'Scenario planning template',
    summaryEn: 'A guided worksheet to map best, base, and challenging scenarios for your finances.',
    summaryEs: 'Una plantilla guiada para mapear escenarios óptimos, base y adversos para tus finanzas.',
    link: '#',
  },
];

const glossaries = [
  {
    term: 'Inflation expectation',
    definitionEn: 'Market perception of future price changes, influencing wage negotiations and pricing.',
    definitionEs: 'Percepción de mercado sobre los aumentos de precios futuros, influye en paritarias y fijación de precios.',
  },
  {
    term: 'ARS liquidity',
    definitionEn: 'Availability of Argentine pesos to settle obligations or invest, impacted by monetary policy.',
    definitionEs: 'Disponibilidad de pesos argentinos para cancelar obligaciones o invertir, afectada por la política monetaria.',
  },
  {
    term: 'FX gap',
    definitionEn: 'Spread between official and alternative exchange rates, signalling market stress.',
    definitionEs: 'Brecha entre el tipo de cambio oficial y alternativo, señalando tensiones de mercado.',
  },
];

const Resources = () => (
  <div>
    <section className="section">
      <div className="section-inner">
        <header>
          <h1 className="section-title">Resources library</h1>
          <p className="section-subtitle">
            Stay informed with bilingual articles, glossaries, and data explainers tailored to Argentina.
            Análisis transparentes y datos de mercado para decidir con seguridad.
          </p>
        </header>
        <div className="cards-grid">
          {articles.map((article) => (
            <article key={article.title} className="card">
              <h3>{article.title}</h3>
              <p><strong>EN:</strong> {article.summaryEn}</p>
              <p><strong>ES:</strong> {article.summaryEs}</p>
              <a href={article.link} aria-label={`Read ${article.title}`}>
                Read more →
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section section-alt">
      <div className="section-inner">
        <h2 className="section-title">Glossary (English · Español)</h2>
        <div className="cards-grid">
          {glossaries.map((item) => (
            <article key={item.term} className="card">
              <h3>{item.term}</h3>
              <p><strong>EN:</strong> {item.definitionEn}</p>
              <p><strong>ES:</strong> {item.definitionEs}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="section-inner">
        <div className="bottom-cta">
          <div>
            <h2 className="section-title">Stay updated</h2>
            <p className="section-subtitle">
              Subscribe to receive bilingual digests each time new CPI data, FX adjustments, or templates
              are published. Datos verificados para planificar tu presupuesto.
            </p>
          </div>
          <a href="#trial-form" className="btn-primary">
            Join the mailing list
          </a>
        </div>
      </div>
    </section>
  </div>
);

export default Resources;