import { useState } from 'react';

const encodeFormData = (data) =>
  Object.keys(data)
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(data[key])}`)
    .join('&');

const Contact = () => {
  const [status, setStatus] = useState('idle');

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    formData.append('form-name', 'contact-support');
    setStatus('submitting');
    try {
      await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encodeFormData(Object.fromEntries(formData.entries())),
      });
      form.reset();
      setStatus('success');
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <section className="section">
      <div className="section-inner">
        <header>
          <h1 className="section-title">Contact us</h1>
          <p className="section-subtitle">
            We are based in Buenos Aires and welcome messages in English or Spanish. Información confiable
            que respalda elecciones responsables sobre tu dinero.
          </p>
        </header>
        <div className="contact-grid">
          <div>
            <div className="map-container" role="img" aria-label="Map showing Buenos Aires location">
              <iframe
                title="Tu Progreso Hoy office in Buenos Aires"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.024620304262!2d-58.38375942409475!3d-34.60373445745525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccad5627c5c5b%3A0x76f74fc1024c6ebe!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <div style={{ marginTop: '1.5rem' }}>
              <h3>Office hours</h3>
              <p>Monday to Friday: 9:00 – 18:00 ART</p>
              <p>Phone: <a href="tel:+541155551234">+54 11 5555-1234</a></p>
              <p>Email: <a href="mailto:contacto@tuprogresohoy.com">contacto@tuprogresohoy.com</a></p>
            </div>
          </div>
          <div>
            <form className="trial-form" name="contact-support" data-netlify="true" onSubmit={handleSubmit}>
              <input type="hidden" name="form-name" value="contact-support" />
              <p style={{ display: 'none' }}>
                <label>
                  Do not fill:
                  <input name="bot-field" />
                </label>
              </p>
              <div className="input-field">
                <label htmlFor="contact-name">Name</label>
                <input id="contact-name" name="name" type="text" placeholder="Your name" required />
              </div>
              <div className="input-field">
                <label htmlFor="contact-email">Email</label>
                <input id="contact-email" name="email" type="email" placeholder="you@example.com" required />
              </div>
              <div className="input-field">
                <label htmlFor="contact-message">Message</label>
                <textarea
                  id="contact-message"
                  name="message"
                  placeholder="Tell us about your goals, your team, or how we can assist."
                  required
                />
              </div>
              <div className="checkbox-group">
                <input id="contact-double" name="doubleOptIn" type="checkbox" required />
                <label htmlFor="contact-double">
                  I agree to receive a verification email and will confirm my request (double opt-in).
                </label>
              </div>
              <button type="submit" className="btn-primary">
                Send message
              </button>
              {status === 'submitting' && (
                <p className="status-message">Sending your message…</p>
              )}
              {status === 'success' && (
                <p className="status-message">
                  Message received! Check your inbox to confirm and finalise the request.
                </p>
              )}
              {status === 'error' && (
                <p style={{ color: '#DC2626', fontWeight: 600 }}>
                  We could not send your message. Please try again.
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;