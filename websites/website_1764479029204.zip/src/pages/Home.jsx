import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import CurrencyTracker from '../components/CurrencyTracker';

const encodeFormData = (data) =>
  Object.keys(data)
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(data[key])}`)
    .join('&');

const Home = () => {
  const navigate = useNavigate();
  const [formStatus, setFormStatus] = useState('idle');
  const [error, setError] = useState('');

  const handleTrialSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    formData.append('form-name', 'trial-access');
    setFormStatus('submitting');
    setError('');
    try {
      await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encodeFormData(Object.fromEntries(formData.entries())),
      });
      form.reset();
      setFormStatus('pending');
      setTimeout(() => {
        navigate('/thank-you', {
          state: { from: 'trial-form', doubleOptIn: true },
        });
      }, 1200);
    } catch (err) {
      console.error(err);
      setError('Could not submit right now. Please try again in a moment.');
      setFormStatus('error');
    }
  };

  return (
    <div>
      <section className="hero">
        <div className="hero-content">
          <div>
            <h1>Empower your financial learning journey in Argentina today.</h1>
            <p className="hero-lead">
              Conocimiento financiero impulsado por tendencias. Build resilient plans around inflation,
              exchange rates, and personalised study paths without speculative noise.
            </p>
            <ul className="hero-bullets" aria-label="Core promises">
              <li>Datos verificados para planificar tu presupuesto.</li>
              <li>Decisiones responsables, objetivos nítidos.</li>
              <li>Pasos acertados hoy, mejor futuro mañana.</li>
            </ul>
            <div className="hero-cta">
              <Link to="/course" className="btn-primary">
                Explore the course
              </Link>
              <Link to="/inflation" className="btn-secondary">
                See ARS→USD insights
              </Link>
            </div>
            <p className="hero-footnote">
              Plataforma educativa con datos esenciales, sin asesoría financiera directa.
            </p>
          </div>
        </div>
      </section>

      <section className="section section-alt">
        <div className="section-inner">
          <header>
            <h2 className="section-title">Reliable data, contextual decisions</h2>
            <p className="section-subtitle">
              We combine verified macro indicators, market monitors, and everyday budget templates so you
              can analyse scenarios that match your reality.
            </p>
          </header>
          <div className="cards-grid">
            <article className="card">
              <h3>Documented sources</h3>
              <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
              <p>
                Every dashboard references BCRA releases, INDEC CPI, IMF projections, and curated industry
                indices. Each chart displays its methodology for instant validation.
              </p>
            </article>
            <article className="card">
              <h3>Household-ready insights</h3>
              <p>Información confiable que respalda elecciones responsables sobre tu dinero.</p>
              <p>
                Translate macro metrics into household cashflow actions, from updating allowances to
                restructuring peso and dollar balances.
              </p>
            </article>
            <article className="card">
              <h3>Future-proof tools</h3>
              <p>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</p>
              <p>
                Configure alerts, scenario dashboards, and role-based learning playlists to track the
                indicators that matter most to your personal or business budget.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-inner">
          <CurrencyTracker />
        </div>
      </section>

      <section className="section section-alt" id="course-overview">
        <div className="section-inner">
          <header>
            <h2 className="section-title">Course snapshot</h2>
            <p className="section-subtitle">
              Designed for everyday managers, founders, freelancers, and families seeking clarity on money
              decisions amid Argentine volatility.
            </p>
          </header>
          <div className="timeline">
            <div className="timeline-step">
              <h4>Module 1 · Inflation literacy</h4>
              <p>
                Track CPI components, explore price pass-through, and use scenario planning templates to
                update spending caps every fortnight.
              </p>
            </div>
            <div className="timeline-step">
              <h4>Module 2 · Currency management</h4>
              <p>
                Grasp ARS→USD dynamics, blend live FX data with your own expenses, and learn how to stage
                currency conversions responsibly.
              </p>
            </div>
            <div className="timeline-step">
              <h4>Module 3 · Goal-based plans</h4>
              <p>
                Allocate cash, short-term instruments, and emergency buffers, aligning each bucket to
                inflation-adjusted targets.
              </p>
            </div>
            <div className="timeline-step">
              <h4>Module 4 · Accountability systems</h4>
              <p>
                Implement double-entry dashboards, checklists, and accountability prompts so small actions
                become durable financial habits.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-inner">
          <header>
            <h2 className="section-title">Voices from our community</h2>
            <p className="section-subtitle">
              From SMEs to households, Tu Progreso Hoy learners turn complex data into informed, calm
              decision-making steps.
            </p>
          </header>
          <div className="testimonials-grid">
            <article className="testimonial-card">
              <p>
                “The ARS scenarios dashboard helped me align supplier payments with realistic exchange
                ranges. It keeps the team grounded and avoids panic.”
              </p>
              <cite>Valeria M., Operations Manager, Córdoba</cite>
            </article>
            <article className="testimonial-card">
              <p>
                “The course shows how to translate CPI releases into simple budget adjustments. We now talk
                about goals without anxiety.”
              </p>
              <cite>Ramiro L., Family planner, Buenos Aires</cite>
            </article>
          </div>
        </div>
      </section>

      <section className="section section-alt">
        <div className="section-inner">
          <div className="insights-grid">
            <article className="insight-panel">
              <h3>Why Tu Progreso Hoy?</h3>
              <p>
                We bring together macro datasets, micro budgeting tools, and bilingual content so every
                learner can cross-check numbers and understand market signals faster.
              </p>
              <p>
                De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
              </p>
            </article>
            <article className="insight-panel">
              <h3>Guided yet flexible</h3>
              <p>
                Your dashboard evolves with new releases and research. Replay lessons, track your notes,
                and export insights to share with your team or household.
              </p>
              <p>
                Need a deeper dive? Join weekly office hours to interpret the latest inflation and FX
                prints collaboratively.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section" id="trial-form">
        <div className="section-inner">
          <div className="bottom-cta">
            <div>
              <h2 className="section-title">Start your guided experience</h2>
              <p className="section-subtitle">
                Información confiable que respalda elecciones responsables sobre tu dinero. Receive a
                structured onboarding email and confirm via our double opt-in process to activate your free
                module and dashboards.
              </p>
            </div>
            <form className="trial-form" name="trial-access" data-netlify="true" onSubmit={handleTrialSubmit}>
              <input type="hidden" name="form-name" value="trial-access" />
              <p style={{ display: 'none' }}>
                <label>
                  Don’t fill this out if you’re human:
                  <input name="bot-field" />
                </label>
              </p>
              <div className="form-grid">
                <div className="input-field">
                  <label htmlFor="trial-name">Full name</label>
                  <input id="trial-name" name="fullName" type="text" placeholder="Ana Martínez" required autoComplete="name" />
                </div>
                <div className="input-field">
                  <label htmlFor="trial-email">Email</label>
                  <input id="trial-email" name="email" type="email" placeholder="ana@example.com" required autoComplete="email" />
                </div>
              </div>
              <div className="checkbox-group">
                <input id="trial-consent" name="consent" type="checkbox" required />
                <label htmlFor="trial-consent">
                  I consent to receive educational emails about Tu Progreso Hoy and understand that I can
                  unsubscribe at any time.
                </label>
              </div>
              <div className="checkbox-group">
                <input id="trial-double" name="doubleOptIn" type="checkbox" required />
                <label htmlFor="trial-double">
                  I will confirm my subscription via the verification email (double opt-in required to
                  access the free trial).
                </label>
              </div>
              <button type="submit" className="btn-primary">
                Получить бесплатный пробный урок
              </button>
              {formStatus === 'submitting' && (
                <p className="status-message">Submitting your request…</p>
              )}
              {formStatus === 'pending' && (
                <p className="status-message">
                  Check your inbox to confirm the subscription and unlock the trial materials.
                </p>
              )}
              {formStatus === 'error' && (
                <p style={{ color: '#DC2626', fontWeight: 600 }}>{error}</p>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;