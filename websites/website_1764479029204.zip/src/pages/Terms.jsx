const Terms = () => (
  <section className="section">
    <div className="section-inner">
      <h1 className="section-title">Terms of Service</h1>
      <p className="section-subtitle">
        These terms govern your use of Tu Progreso Hoy&apos;s website, dashboards, and educational content.
      </p>
      <div className="insight-panel">
        <h2>Acceptance of terms</h2>
        <p>
          By accessing our site or participating in our course, you agree to these Terms of Service and all
          referenced policies. If you disagree, please refrain from using the platform.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Educational purpose</h2>
        <p>
          Tu Progreso Hoy provides educational materials and data visualisations. We do not offer financial,
          investment, legal, or tax advice. Decisions based on the information remain your responsibility.
        </p>
      </div>
      <div className="insight-panel">
        <h2>User responsibilities</h2>
        <ul style={{ paddingLeft: '1.2rem', display: 'grid', gap: '0.5rem', margin: 0 }}>
          <li>Provide accurate information when registering or subscribing.</li>
          <li>Respect intellectual property rights; do not resell or distribute content without permission.</li>
          <li>Use the platform lawfully and refrain from disruptive or fraudulent activity.</li>
        </ul>
      </div>
      <div className="insight-panel">
        <h2>Intellectual property</h2>
        <p>
          All text, videos, graphics, and tools are the property of Tu Progreso Hoy unless otherwise stated.
          You receive a limited licence for personal or internal business use.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Limitation of liability</h2>
        <p>
          To the extent permitted by law, Tu Progreso Hoy is not liable for indirect, incidental, or
          consequential damages resulting from the use of our platform.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Termination</h2>
        <p>
          We may suspend or terminate access if a user breaches these terms, engages in abusive behaviour,
          or undermines the security of the platform.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Governing law</h2>
        <p>
          These terms are governed by the laws of the Argentine Republic. Any disputes shall be resolved in
          the competent courts of Buenos Aires.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Contact</h2>
        <p>
          For questions about these terms, email{' '}
          <a href="mailto:legal@tuprogresohoy.com">legal@tuprogresohoy.com</a>.
        </p>
      </div>
    </div>
  </section>
);

export default Terms;