const Privacy = () => (
  <section className="section">
    <div className="section-inner">
      <h1 className="section-title">Privacy Policy</h1>
      <p className="section-subtitle">
        Tu Progreso Hoy respects your privacy and complies with Argentine regulations and international
        best practices for data protection.
      </p>
      <div className="insight-panel">
        <h2>Information we collect</h2>
        <ul style={{ paddingLeft: '1.2rem', display: 'grid', gap: '0.4rem', margin: 0 }}>
          <li>Contact details submitted through forms (name, email, organisation).</li>
          <li>Usage data such as page visits, device information, and course progress.</li>
          <li>Voluntary survey responses and feedback.</li>
        </ul>
      </div>
      <div className="insight-panel">
        <h2>How we use your data</h2>
        <p>We process personal data to:</p>
        <ul style={{ paddingLeft: '1.2rem', display: 'grid', gap: '0.4rem', margin: 0 }}>
          <li>Deliver educational content, updates, and course communications.</li>
          <li>Improve our dashboards, study materials, and overall learner experience.</li>
          <li>Comply with contractual obligations and legal requirements.</li>
        </ul>
      </div>
      <div className="insight-panel">
        <h2>Retention & security</h2>
        <p>
          Data is stored securely in encrypted systems located in compliant data centres. We retain
          information only as long as necessary to fulfil its purpose or meet legal obligations.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Your rights</h2>
        <p>
          You may request access, correction, deletion, or portability of your personal data. To exercise
          these rights, contact{' '}
          <a href="mailto:privacidad@tuprogresohoy.com">privacidad@tuprogresohoy.com</a>.
        </p>
      </div>
      <div className="insight-panel">
        <h2>International transfers</h2>
        <p>
          When data is stored or processed outside Argentina, we apply safeguards such as standard
          contractual clauses and vendor assessments to ensure equivalent protection.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Updates</h2>
        <p>
          This policy may be updated periodically. We will notify users via email or banner notices when
          material changes occur. Last updated: April 2024.
        </p>
      </div>
    </div>
  </section>
);

export default Privacy;