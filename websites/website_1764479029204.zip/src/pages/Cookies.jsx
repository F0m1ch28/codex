const Cookies = () => (
  <section className="section">
    <div className="section-inner">
      <h1 className="section-title">Cookies Policy</h1>
      <p className="section-subtitle">
        We use cookies to optimise your experience, measure engagement, and enable essential security
        functions.
      </p>
      <div className="insight-panel">
        <h2>What are cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a website. They help remember
          your preferences, keep you logged in, and analyse how our platform is used.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Types of cookies we use</h2>
        <ul style={{ paddingLeft: '1.2rem', display: 'grid', gap: '0.5rem', margin: 0 }}>
          <li><strong>Essential:</strong> Required for core functionality, such as secure login and form submission.</li>
          <li><strong>Analytics:</strong> Measure visits, content performance, and navigation paths.</li>
          <li><strong>Preference:</strong> Store language selection and accessibility options.</li>
        </ul>
      </div>
      <div className="insight-panel">
        <h2>Managing cookies</h2>
        <p>
          You can accept or decline optional cookies via our banner. You may also adjust browser settings to
          manage cookies. Declining analytics cookies will not impact access to the course or dashboards.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Third-party providers</h2>
        <p>
          We rely on trusted analytics and email delivery partners. Each provider adheres to privacy and
          security commitments. A list of active partners is available upon request.
        </p>
      </div>
      <div className="insight-panel">
        <h2>Contact</h2>
        <p>
          For questions about cookies, contact{' '}
          <a href="mailto:privacidad@tuprogresohoy.com">privacidad@tuprogresohoy.com</a>.
        </p>
      </div>
    </div>
  </section>
);

export default Cookies;