import { useLocation, Link } from 'react-router-dom';

const ThankYou = () => {
  const location = useLocation();
  const doubleOptIn = location.state?.doubleOptIn;

  return (
    <section className="section">
      <div className="section-inner">
        <div className="insight-panel">
          <h1 className="section-title">Thank you for joining Tu Progreso Hoy</h1>
          <p className="section-subtitle">
            Your request was received. {doubleOptIn ? 'Please confirm the verification email to activate your access.' : ''}
          </p>
          <p>
            We have sent a confirmation email to finalise the double opt-in process. Once you confirm, you
            will receive the free lesson, ARS→USD dashboard access, and onboarding instructions within a few
            minutes.
          </p>
          <p>
            Need support? Email us at{' '}
            <a href="mailto:contacto@tuprogresohoy.com">contacto@tuprogresohoy.com</a>.
          </p>
          <Link to="/" className="btn-primary" style={{ width: 'fit-content' }}>
            Return to homepage
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ThankYou;