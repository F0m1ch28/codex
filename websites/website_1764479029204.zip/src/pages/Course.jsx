import { Link } from 'react-router-dom';

const modules = [
  {
    title: 'Module 1 · Inflation Essentials',
    bullets: [
      'Decode CPI prints, weighting structures, and seasonality patterns.',
      'Apply rolling averages to soften volatility and plan realistic price reviews.',
      'Build a bilingual glossary to align team and household conversations.',
    ],
  },
  {
    title: 'Module 2 · ARS→USD Fundamentals',
    bullets: [
      'Compare official, MEP, and CCL references while respecting regulations.',
      'Design conversion checklists: when, how, and why to adjust currency exposure.',
      'Integrate FX bands into personal balance sheets to stay aligned with goals.',
    ],
  },
  {
    title: 'Module 3 · Scenario Planning',
    bullets: [
      'Stress test best, base, and challenging environments for income and expenses.',
      'Track leading indicators (grain harvest, commodity prices, fiscal signals).',
      'Outline plan B and plan C so your budget remains resilient.',
    ],
  },
  {
    title: 'Module 4 · Accountability & Habits',
    bullets: [
      'Set up dashboards with alerts, journaling prompts, and monthly reviews.',
      'Facilitate family or team meetings with data-first scripts in EN/ES.',
      'Audit past decisions to strengthen responsible money management habits.',
    ],
  },
];

const audience = [
  'Households managing peso incomes with USD-linked expenses.',
  'SME leaders navigating supplier payments and payroll under inflation.',
  'Freelancers charging abroad while budgeting locally.',
  'Students and first-job professionals building financial literacy.',
];

const Course = () => (
  <div>
    <section className="section">
      <div className="section-inner">
        <header>
          <h1 className="section-title">Personal finance starter course</h1>
          <p className="section-subtitle">
            All content is bilingual, mobile-friendly, and designed for Argentina. Learn at your own pace,
            combining data, templates, and reflective exercises. Decisiones responsables, objetivos nítidos.
          </p>
        </header>
        <div className="insight-panel">
          <h3>Learning experience</h3>
          <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.5rem' }}>
            <li>Video classes with English narration and Spanish captions.</li>
            <li>Interactive dashboards embedding live ARS→USD and CPI feeds.</li>
            <li>Downloadable workbook and notion-style trackers.</li>
            <li>Weekly study prompts and reflection questions.</li>
          </ul>
        </div>
      </div>
    </section>

    <section className="section section-alt">
      <div className="section-inner">
        <h2 className="section-title">Syllabus overview</h2>
        <div className="timeline">
          {modules.map((module) => (
            <article key={module.title} className="timeline-step">
              <h4>{module.title}</h4>
              <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.35rem' }}>
                {module.bullets.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="section-inner">
        <div className="insights-grid">
          <article className="insight-panel">
            <h3>Who is it for?</h3>
            <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.35rem' }}>
              {audience.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
          <article className="insight-panel">
            <h3>Your outcomes</h3>
            <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.35rem' }}>
              <li>Build a living budget that reacts to inflation data responsibly.</li>
              <li>Understand ARS and USD trade-offs without speculative hype.</li>
              <li>Establish habits that reinforce healthy financial dialogues.</li>
              <li>Gain confidence to brief advisors or stakeholders effectively.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section className="section section-alt">
      <div className="section-inner">
        <div className="bottom-cta">
          <div>
            <h2 className="section-title">Ready to participate?</h2>
            <p className="section-subtitle">
              Pasos acertados hoy, mejor futuro mañana. Join the upcoming cohort or request a private
              onboarding for your household or team.
            </p>
          </div>
          <Link to="/#trial-form" className="btn-primary">
            Claim the free trial lesson
          </Link>
        </div>
      </div>
    </section>
  </div>
);

export default Course;