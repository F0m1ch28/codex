import CurrencyTracker from '../components/CurrencyTracker';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';

const inflationSeries = [
  { month: 'Nov 23', inflation: 12.4, fx: 0.00156 },
  { month: 'Dec 23', inflation: 25.5, fx: 0.00125 },
  { month: 'Jan 24', inflation: 20.6, fx: 0.0011 },
  { month: 'Feb 24', inflation: 13.2, fx: 0.00102 },
  { month: 'Mar 24', inflation: 11.0, fx: 0.00098 },
  { month: 'Apr 24', inflation: 8.8, fx: 0.00095 },
  { month: 'May 24', inflation: 8.0, fx: 0.00093 },
  { month: 'Jun 24', inflation: 7.5, fx: 0.00091 },
  { month: 'Jul 24', inflation: 7.2, fx: 0.00090 },
];

const faqs = [
  {
    question: 'How do you compile CPI trends for Argentina?',
    answer:
      'We synchronise each monthly INDEC release at the division and sub-division levels, calculating rolling three-month averages and annualised rates. You can segment items (e.g., food, housing, transport) and plug them directly into personalised budget plans.',
  },
  {
    question: 'Which FX reference rates are compared?',
    answer:
      'Our dashboards focus on the official wholesale ARS→USD rate and include context about blue-chip swap spreads. Historical series are sourced from BCRA and private data vendors, timestamped and footnoted.',
  },
  {
    question: 'How can I mix inflation and FX data in one plan?',
    answer:
      'Use our worksheets to tie weekly expense categories to CPI baselines, then assign whether each line is ARS- or USD-sensitive. The template automatically applies price change assumptions and FX adjustments to projected cashflows.',
  },
  {
    question: 'Do you provide personalised investment guidance?',
    answer:
      'No. Tu Progreso Hoy is strictly educational. We illustrate how to read indicators, structure budgets, and ask better questions. Every user adapts these materials to their own goals and, when needed, seeks certified professional advice.',
  },
  {
    question: 'Can I export the datasets?',
    answer:
      'Yes. Download CSV snapshots, schedule email summaries, or connect the API-ready feeds to your preferred BI tool. Each export retains bilingual headers for shared understanding across teams.',
  },
];

const Inflation = () => (
  <div>
    <section className="section">
      <div className="section-inner">
        <header>
          <h1 className="section-title">Inflation methodology & context</h1>
          <p className="section-subtitle">
            Understand the mechanics behind our inflation dashboards, how ARS→USD movements interplay
            with CPI, and how to translate data into responsible actions.
          </p>
        </header>
        <article className="insight-panel">
          <h3>Methodology highlights</h3>
          <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.5rem' }}>
            <li>
              <strong>Source integrity:</strong> INDEC CPI data, BCRA monetary reports, IMF WEO updates,
              reputable private surveys, and regional comparisons. Each chart is time-stamped.
            </li>
            <li>
              <strong>Adjustment layers:</strong> We calculate three-month moving averages to smooth
              short-term volatility and provide both headline and core inflation overviews.
            </li>
            <li>
              <strong>Scenario modelling:</strong> Apply stress tests (mild, base, severe) combining CPI
              trends and FX projections to stress your monthly plan.
            </li>
            <li>
              <strong>Household lens:</strong> Translate inflation segments into daily life cost categories
              (housing, food, transport, education, health) with bilingual definitions.
            </li>
          </ul>
        </article>
      </div>
    </section>

    <section className="section section-alt">
      <div className="section-inner">
        <div className="tracker-card">
          <h2 className="section-title" style={{ marginBottom: '0.5rem' }}>
            CPI vs. ARS→USD trendlines
          </h2>
          <p className="section-subtitle" style={{ marginBottom: '1.5rem' }}>
            Overlay headline inflation with the official exchange rate (USD per ARS). Colour-coded zones
            help you assess the relative pressure of prices and FX in the same window.
          </p>
          <div className="chart-container" style={{ height: '360px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={inflationSeries}>
                <CartesianGrid strokeDasharray="4 8" stroke="rgba(148,163,184,0.4)" />
                <XAxis dataKey="month" stroke="var(--color-muted)" />
                <YAxis
                  yAxisId="inflation"
                  stroke="#F97316"
                  tickFormatter={(value) => `${value}%`}
                  allowDecimals
                />
                <YAxis
                  yAxisId="fx"
                  orientation="right"
                  stroke="#2563EB"
                  tickFormatter={(value) => value.toFixed(4)}
                />
                <Tooltip
                  formatter={(value, name) =>
                    name === 'Headline inflation'
                      ? [`${value}%`, name]
                      : [`${value.toFixed(4)} USD`, name]
                  }
                />
                <Legend />
                <Line
                  yAxisId="inflation"
                  type="monotone"
                  dataKey="inflation"
                  name="Headline inflation"
                  stroke="#F97316"
                  strokeWidth={3}
                  dot={{ r: 5 }}
                />
                <Line
                  yAxisId="fx"
                  type="monotone"
                  dataKey="fx"
                  name="USD per ARS"
                  stroke="#2563EB"
                  strokeWidth={3}
                  dot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p style={{ margin: 0 }}>
            When inflation slows faster than the peso depreciates, imported goods may become relatively
            cheaper in the short term. Use this window to schedule purchases or reset savings targets while
            keeping emergency buffers intact.
          </p>
        </div>
      </div>
    </section>

    <section className="section">
      <div className="section-inner">
        <header>
          <h2 className="section-title">How to act on the data</h2>
          <p className="section-subtitle">
            Translate macro indicators into household or business routines. Balance emergency reserves,
            update price lists, and negotiate from a place of clarity.
          </p>
        </header>
        <div className="insights-grid">
          <article className="insight-panel">
            <h3>Weekly routines</h3>
            <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.35rem' }}>
              <li>Monitor short-term CPI spikes for essentials (food, transport) to adapt grocery plans.</li>
              <li>Cross-check supplier quotes with FX-adjusted price bands before committing to purchases.</li>
              <li>Update allowance envelopes and business petty cash limits based on latest price data.</li>
            </ul>
          </article>
          <article className="insight-panel">
            <h3>Monthly checkpoints</h3>
            <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.35rem' }}>
              <li>Reforecast 30/60/90-day expenses using our inflation overlay templates.</li>
              <li>Scenario-test peso savings and dollar obligations to align conversion timing.</li>
              <li>Document adjustments and share bilingual summaries with your family or team.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section className="section section-alt">
      <div className="section-inner">
        <header>
          <h2 className="section-title">Frequently Asked Questions</h2>
          <p className="section-subtitle">
            Find detailed answers about inflation sources, FX monitoring, and how our educational approach
            works in Argentina.
          </p>
        </header>
        <div className="faq-list">
          {faqs.map((item) => (
            <article key={item.question} className="faq-item">
              <h3 className="faq-question">{item.question}</h3>
              <p className="faq-answer">{item.answer}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="section-inner">
        <CurrencyTracker />
        <div className="bottom-cta" style={{ marginTop: '2rem' }}>
          <div>
            <h3 className="section-title">Keep learning with Tu Progreso Hoy</h3>
            <p className="section-subtitle">
              Confront inflation confidently. Join the course to combine live dashboards, bilingual study
              notes, and ready-to-use templates tailored to Argentina.
            </p>
          </div>
          <Link to="/course" className="btn-primary" style={{ justifySelf: 'start' }}>
            Go to course overview
          </Link>
        </div>
      </div>
    </section>
  </div>
);

export default Inflation;