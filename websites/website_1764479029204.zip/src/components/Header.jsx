import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Header = () => {
  const { language, toggleLanguage } = useLanguage();

  return (
    <header>
      <div className="header-inner" role="navigation" aria-label="Primary">
        <div className="brand">
          Tu Progreso Hoy
          <span>Argentina · Educación financiera</span>
        </div>
        <nav>
          <div className="nav-links">
            <NavLink to="/" end>
              Home
            </NavLink>
            <NavLink to="/inflation">Inflation</NavLink>
            <NavLink to="/course">Course</NavLink>
            <NavLink to="/resources">Resources</NavLink>
            <NavLink to="/contact">Contact</NavLink>
          </div>
        </nav>
        <button
          type="button"
          className="lang-toggle"
          onClick={toggleLanguage}
          aria-label="Toggle language"
        >
          {language === 'en' ? 'ES' : 'EN'}
        </button>
      </div>
    </header>
  );
};

export default Header;