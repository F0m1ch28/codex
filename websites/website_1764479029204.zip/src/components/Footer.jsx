import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="footer">
    <div className="footer-inner">
      <div className="footer-columns">
        <div>
          <h4>Tu Progreso Hoy</h4>
          <p>
            Data-driven learning for households and professionals across Argentina. Align your
            decisions with reliable market context and accessible personal finance education.
          </p>
        </div>
        <div>
          <h4>Visit & Contact</h4>
          <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <p>Phone: <a href="tel:+541155551234">+54 11 5555-1234</a></p>
          <p>Email: <a href="mailto:contacto@tuprogresohoy.com">contacto@tuprogresohoy.com</a></p>
          <div>
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              LinkedIn
            </a>{' '}
            ·{' '}
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
              Twitter
            </a>{' '}
            ·{' '}
            <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
              YouTube
            </a>
          </div>
        </div>
        <div>
          <h4>Quick links</h4>
          <nav aria-label="Footer navigation">
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.5rem' }}>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cookies">Cookies Policy</Link>
              </li>
              <li>
                <Link to="/terms">Terms of Service</Link>
              </li>
              <li>
                <a href="/sitemap.xml">Sitemap</a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</span>
        <span>Мы не предоставляем финансовые услуги · We do not provide financial services.</span>
      </div>
    </div>
  </footer>
);

export default Footer;