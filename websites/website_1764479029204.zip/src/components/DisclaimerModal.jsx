import { useEffect, useState } from 'react';

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const acknowledged = localStorage.getItem('financialDisclaimerAcknowledged');
    if (!acknowledged) {
      const timer = setTimeout(() => setOpen(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const closeModal = () => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('financialDisclaimerAcknowledged', 'true');
    }
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="modal-overlay" role="alertdialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="modal-content">
        <h3 id="disclaimer-title">Important disclaimer</h3>
        <p>Мы не предоставляем финансовые услуги.</p>
        <p>We do not provide financial services. Tu Progreso Hoy is an educational platform offering contextual data, learning journeys, and self-paced analysis templates. Nothing on this site constitutes personalised advice.</p>
        <button type="button" onClick={closeModal}>
          I understand
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;