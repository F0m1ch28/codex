import { useEffect, useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';

const fallbackSeries = [
  { date: '2024-03-18', usd: 0.00115 },
  { date: '2024-03-21', usd: 0.00112 },
  { date: '2024-03-24', usd: 0.00109 },
  { date: '2024-03-27', usd: 0.00105 },
  { date: '2024-03-30', usd: 0.00102 },
  { date: '2024-04-02', usd: 0.001 },
  { date: '2024-04-05', usd: 0.00098 },
  { date: '2024-04-08', usd: 0.00096 },
  { date: '2024-04-11', usd: 0.00095 },
  { date: '2024-04-14', usd: 0.00094 },
];

const formatDate = (date) => date.toISOString().split('T')[0];

const CurrencyTracker = () => {
  const [range, setRange] = useState(14);
  const [series, setSeries] = useState(fallbackSeries);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [timestamp, setTimestamp] = useState(() => new Date().toISOString());

  useEffect(() => {
    let ignore = false;

    const fetchRates = async () => {
      try {
        setLoading(true);
        setError('');
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(endDate.getDate() - range);
        const url = `https://api.exchangerate.host/timeseries?start_date=${formatDate(
          startDate
        )}&end_date=${formatDate(endDate)}&base=ARS&symbols=USD`;
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('Network error');
        }
        const data = await response.json();
        if (!data.rates) {
          throw new Error('No data received');
        }
        const sorted = Object.keys(data.rates)
          .sort()
          .map((date) => {
            const rate = data.rates[date]?.USD;
            const usd = rate && Number.isFinite(rate) ? rate : null;
            return {
              date,
              usd,
            };
          })
          .filter((item) => item.usd);
        if (!ignore && sorted.length > 2) {
          setSeries(
            sorted.map((item) => ({
              ...item,
              arsPerUsd: item.usd ? 1 / item.usd : null,
            }))
          );
          setTimestamp(new Date().toISOString());
        } else if (!ignore) {
          setSeries(
            fallbackSeries.map((item) => ({
              ...item,
              arsPerUsd: item.usd ? 1 / item.usd : null,
            }))
          );
        }
      } catch (err) {
        console.error(err);
        if (!ignore) {
          setError('Live exchange feed unavailable. Displaying recent averages.');
          setSeries(
            fallbackSeries.map((item) => ({
              ...item,
              arsPerUsd: item.usd ? 1 / item.usd : null,
            }))
          );
        }
      } finally {
        if (!ignore) {
          setLoading(false);
        }
      }
    };

    fetchRates();

    return () => {
      ignore = true;
    };
  }, [range]);

  const enrichedSeries = useMemo(
    () =>
      series.map((item) => ({
        ...item,
        arsPerUsd: item.arsPerUsd ?? (item.usd ? 1 / item.usd : null),
      })),
    [series]
  );

  const latest = enrichedSeries[enrichedSeries.length - 1];
  const first = enrichedSeries[0];
  const latestUsd = latest?.usd ?? 0;
  const latestArs = latest?.arsPerUsd ?? (latestUsd ? 1 / latestUsd : 0);
  const delta = latestUsd - (first?.usd ?? latestUsd);
  const percentage =
    first?.usd && latestUsd ? ((latestUsd - first.usd) / first.usd) * 100 : 0;

  return (
    <div className="tracker-card">
      <div className="tracker-summary">
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap' }}>
          <div>
            <h2 className="section-title" style={{ marginBottom: '0.3rem' }}>
              ARS→USD live tracker
            </h2>
            <p style={{ margin: 0, color: 'var(--color-primary)', fontWeight: 600 }}>
              Conocimiento financiero impulsado por tendencias.
            </p>
            <p style={{ fontSize: '0.95rem', color: 'var(--color-muted)', marginTop: '0.4rem' }}>
              Updated: {new Date(timestamp).toLocaleString('en-GB', { timeZone: 'America/Argentina/Buenos_Aires' })}
            </p>
          </div>
          <div>
            <label htmlFor="range-select" className="sr-only">
              Select time range
            </label>
            <select
              id="range-select"
              className="range-select"
              value={range}
              onChange={(event) => setRange(Number(event.target.value))}
            >
              <option value={7}>Last 7 days</option>
              <option value={14}>Last 14 days</option>
              <option value={30}>Last 30 days</option>
            </select>
          </div>
        </div>
        <div className="tracker-stats">
          <span className="stat-chip">
            1 ARS = {latestUsd ? latestUsd.toFixed(5) : '—'} USD
          </span>
          <span className="stat-chip">
            1 USD ≈ {latestArs ? latestArs.toFixed(2) : '—'} ARS
          </span>
          <span
            className={`stat-chip ${
              delta >= 0 ? 'change-positive' : 'change-negative'
            }`}
          >
            {delta >= 0 ? '▲' : '▼'} {delta.toFixed(5)} USD ({percentage.toFixed(2)}%)
          </span>
        </div>
        {error && (
          <p style={{ margin: 0, color: '#DC2626', fontWeight: 600 }}>
            {error}
          </p>
        )}
        <p style={{ margin: 0 }}>
          Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
        </p>
      </div>
      <div className="chart-container" role="img" aria-label="Line chart showing ARS to USD movements">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={enrichedSeries}>
            <CartesianGrid strokeDasharray="4 8" stroke="rgba(148,163,184,0.4)" />
            <XAxis dataKey="date" stroke="var(--color-muted)" />
            <YAxis
              yAxisId="usd"
              orientation="left"
              stroke="#2563EB"
              tickFormatter={(value) => value.toFixed(4)}
            />
            <YAxis
              yAxisId="ars"
              orientation="right"
              stroke="#1F3A6F"
              allowDecimals={false}
              tickFormatter={(value) => Math.round(value)}
            />
            <Tooltip
              formatter={(value, name) =>
                name === 'USD per ARS'
                  ? [`${Number(value).toFixed(5)} USD`, name]
                  : [`${Number(value).toFixed(2)} ARS`, name]
              }
            />
            <Legend />
            <Line
              yAxisId="usd"
              type="monotone"
              dataKey="usd"
              name="USD per ARS"
              stroke="#2563EB"
              strokeWidth={3}
              dot={false}
              activeDot={{ r: 6 }}
            />
            <Line
              yAxisId="ars"
              type="monotone"
              dataKey="arsPerUsd"
              name="ARS per USD"
              stroke="#1F3A6F"
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div>
        <h3 style={{ marginBottom: '0.5rem' }}>Key insights</h3>
        <ul style={{ paddingLeft: '1.2rem', margin: 0, display: 'grid', gap: '0.35rem' }}>
          <li>
            Monitoring both ARS depreciation and USD purchasing power highlights how import-linked expenses
            or USD-denominated obligations impact monthly budgets.
          </li>
          <li>
            Pair the FX trend with inflation adjustments to plan for tuition, rent, or supplier payments
            in advance and avoid stress from abrupt changes.
          </li>
          <li>
            Set alert thresholds inside your personal tracker to revisit your budget when weekly variation
            exceeds your risk tolerance.
          </li>
        </ul>
      </div>
      {loading && <p className="status-message">Loading live exchange movements…</p>}
    </div>
  );
};

export default CurrencyTracker;