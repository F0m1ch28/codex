import { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem('cookieConsent');
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem('cookieConsent', choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div>
        <strong>Cookie preferences</strong>
        <p>
          We use analytical cookies to understand how Tu Progreso Hoy is used. Accept to help us
          improve the learning experience, or decline to use strictly necessary cookies only.
        </p>
      </div>
      <div className="cookie-banner-buttons">
        <button
          type="button"
          className="cookie-button cookie-accept"
          onClick={() => handleChoice('accepted')}
        >
          Accept
        </button>
        <button
          type="button"
          className="cookie-button cookie-decline"
          onClick={() => handleChoice('declined')}
        >
          Decline
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;