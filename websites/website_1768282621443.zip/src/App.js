import React, { useEffect } from "react";
import { Routes, Route, useLocation, Link } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import TermsOfService from "./pages/TermsOfService";
import PrivacyPolicy from "./pages/PrivacyPolicy";

const App = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname]);

  return (
    <div className="app-shell">
      <Header />
      <main className="main-content" id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/new-arrivals" element={<NewArrivals />} />
          <Route path="/bestsellers" element={<Bestsellers />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/terms" element={<TermsOfService />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  );
};

const Categories = () => {
  usePageMeta(
    "TechStore | Categories",
    "Browse TechStore categories to discover smartphones, laptops, audio gear, smart home devices, and more."
  );

  const categories = [
    {
      title: "Smartphones & Accessories",
      description:
        "Discover breakthrough mobile experiences with devices engineered for speed, clarity, and creativity.",
      image: "https://picsum.photos/id/1005/800/500"
    },
    {
      title: "Laptops & Workstations",
      description:
        "From agile ultrabooks to powerhouse mobile workstations, build your dream productivity setup.",
      image: "https://picsum.photos/id/1033/800/500"
    },
    {
      title: "Audio & Immersive Sound",
      description:
        "Feel every beat and hear every detail with premium headphones, earbuds, and smart speakers.",
      image: "https://picsum.photos/id/1025/800/500"
    },
    {
      title: "Smart Home Living",
      description:
        "Automate comfort and security with connected lighting, assistants, and sensors that learn your routine.",
      image: "https://picsum.photos/id/1044/800/500"
    },
    {
      title: "Gaming & XR",
      description:
        "Experience ultra-responsive gameplay and leap into new realities with consoles, VR, and accessories.",
      image: "https://picsum.photos/id/1069/800/500"
    },
    {
      title: "Wearables & Wellness",
      description:
        "Monitor health, stay productive, and keep connected with smartwatches and fitness trackers.",
      image: "https://picsum.photos/id/1084/800/500"
    }
  ];

  return (
    <div className="page">
      <section className="page-hero categories-hero">
        <div className="overlay" />
        <div className="inner">
          <h1>Explore Every Corner of Innovation</h1>
          <p>
            Navigate curated collections built for creators, learners, gamers,
            and explorers who never settle for average tech.
          </p>
        </div>
      </section>
      <section className="section container">
        <h2 className="section-title">Signature TechStore Categories</h2>
        <div className="tiling-grid">
          {categories.map((category) => (
            <article className="category-card" key={category.title}>
              <div
                className="category-media"
                style={{ backgroundImage: "url(${category.image})" }}
                aria-hidden="true"
              />
              <div className="category-content">
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <Link className="text-link" to="/new-arrivals">
                  See the latest arrivals →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="cta-section">
        <div className="cta-inner container">
          <h2>Need tailored recommendations?</h2>
          <p>
            Share your goals with the TechStore experts and we will assemble a
            future-proof ecosystem just for you.
          </p>
          <Link className="btn-secondary" to="/contact">
            Talk to an expert
          </Link>
        </div>
      </section>
    </div>
  );
};

const NewArrivals = () => {
  usePageMeta(
    "TechStore | New Arrivals",
    "Be first to experience the newest electronics, smart gadgets, and immersive gear at TechStore."
  );

  const arrivals = [
    {
      title: "Nebula Vision Pro Camera",
      description:
        "Capture lifelike detail with a hybrid lens array tuned for creators on the move.",
      image: "https://picsum.photos/id/1050/600/420"
    },
    {
      title: "Quantum Arc Laptop",
      description:
        "AI-accelerated performance in a featherweight chassis crafted for mobile pioneers.",
      image: "https://picsum.photos/id/1011/600/420"
    },
    {
      title: "PulseSync Earbuds",
      description:
        "Adaptive noise intelligence and dynamic EQ bring studio-grade sound everywhere.",
      image: "https://picsum.photos/id/1012/600/420"
    },
    {
      title: "Halo Smart Display",
      description:
        "Transform your home command center with voice-ready dashboards and ambient insights.",
      image: "https://picsum.photos/id/1002/600/420"
    },
    {
      title: "Aether Fitness Band",
      description:
        "Real-time biometrics, guided recovery, and solar-assisted charging for endless energy.",
      image: "https://picsum.photos/id/103/600/420"
    },
    {
      title: "Flux VR Console",
      description:
        "Dive into responsive gameplay with haptic feedback tuned to your motions.",
      image: "https://picsum.photos/id/1040/600/420"
    }
  ];

  return (
    <div className="page">
      <section className="page-header container">
        <h1>New Arrivals</h1>
        <p className="lead">
          Fresh, future-first, and ready to reinvent how you live, work, and
          play. Discover the latest inventions handpicked by TechStore.
        </p>
      </section>
      <section className="section container">
        <div className="product-grid">
          {arrivals.map((item) => (
            <article className="product-card" key={item.title}>
              <div
                className="product-media"
                style={{ backgroundImage: "url(${item.image})" }}
                aria-hidden="true"
              />
              <div className="product-info">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <Link className="text-link" to="/contact">
                  Request availability →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

const Bestsellers = () => {
  usePageMeta(
    "TechStore | Bestsellers",
    "Meet TechStore bestsellers trusted by tech enthusiasts worldwide for quality and innovation."
  );

  const favorites = [
    {
      title: "Zenith Ultra Laptop",
      detail:
        "Beloved by developers for its thermal design and all-day multi-core stamina.",
      image: "https://picsum.photos/id/180/600/420"
    },
    {
      title: "EchoSphere Smart Speaker",
      detail:
        "Immersive audio with adaptive room sensing and seamless smart home handoffs.",
      image: "https://picsum.photos/id/191/600/420"
    },
    {
      title: "Nimbus Watch X",
      detail:
        "A wellness-first wearable delivering precision tracking and mindful insights.",
      image: "https://picsum.photos/id/433/600/420"
    },
    {
      title: "Photon Drone Lite",
      detail:
        "Lightweight aerial photography companion with cinematic stabilization.",
      image: "https://picsum.photos/id/395/600/420"
    }
  ];

  return (
    <div className="page">
      <section className="page-header container">
        <h1>Customer Favorites & Icons</h1>
        <p className="lead">
          These devices earned global praise for reliability, intelligence, and
          design excellence. Explore what the TechStore community keeps reaching
          for.
        </p>
      </section>
      <section className="section container">
        <div className="product-grid">
          {favorites.map((item) => (
            <article className="product-card bestseller-card" key={item.title}>
              <div
                className="product-media"
                style={{ backgroundImage: "url(${item.image})" }}
                aria-hidden="true"
              />
              <div className="product-info">
                <h3>{item.title}</h3>
                <p>{item.detail}</p>
                <Link className="text-link" to="/blog">
                  Discover use cases →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="cta-section alt">
        <div className="cta-inner container">
          <h2>Ready to elevate your setup?</h2>
          <p>
            Tell us how you work or play—our specialists will assemble a
            personalized shortlist of standout devices.
          </p>
          <Link className="btn-primary" to="/contact">
            Plan a consultation
          </Link>
        </div>
      </section>
    </div>
  );
};

const Blog = () => {
  usePageMeta(
    "TechStore | Blog",
    "Stay informed with TechStore insights on breakthrough electronics, trends, and future tech culture."
  );

  const posts = [
    {
      title: "How AI Is Reimagining Personal Devices",
      excerpt:
        "From predictive performance tuning to adaptive user flows, discover how AI elevates daily interactions.",
      image: "https://picsum.photos/id/369/800/520",
      date: "September 14, 2023"
    },
    {
      title: "Building A Zero-Lag Creative Studio Anywhere",
      excerpt:
        "Unpack the mobile tools and accessories that keep creative pros in flow across continents.",
      image: "https://picsum.photos/id/444/800/520",
      date: "August 28, 2023"
    },
    {
      title: "The Smart Home Playbook for Sustainability",
      excerpt:
        "Explore connected devices that harmonize comfort, security, and responsible energy usage.",
      image: "https://picsum.photos/id/555/800/520",
      date: "August 08, 2023"
    }
  ];

  return (
    <div className="page blog-page">
      <section className="page-header container">
        <h1>Tech Insights & News</h1>
        <p className="lead">
          Dive into expert perspectives, emerging trends, and stories shaping
          the future of technology—curated by the TechStore editorial team.
        </p>
      </section>
      <section className="section container">
        <div className="blog-grid">
          {posts.map((post) => (
            <article className="blog-card" key={post.title}>
              <div
                className="blog-media"
                style={{ backgroundImage: "url(${post.image})" }}
                aria-hidden="true"
              />
              <div className="blog-body">
                <p className="blog-date">{post.date}</p>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a
                  className="text-link"
                  href="https://blog.techstore.com"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Continue reading →
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

const CookiePolicy = () => {
  usePageMeta(
    "TechStore | Cookie Policy",
    "Understand how TechStore uses cookies to improve your browsing experience."
  );

  return (
    <div className="page legal-page container">
      <header className="page-header">
        <h1>Cookie Policy</h1>
        <p className="lead">
          This Cookie Policy outlines how TechStore uses cookies and similar
          technologies to recognize, personalize, and improve your visits.
        </p>
      </header>
      <section className="legal-section">
        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you interact
          with websites. They help us remember your preferences, understand site
          usage patterns, and deliver relevant content.
        </p>
      </section>
      <section className="legal-section">
        <h2>Types of Cookies We Use</h2>
        <ul>
          <li>
            <strong>Essential cookies:</strong> Enable core functionality such
            as secure sign-in and navigation.
          </li>
          <li>
            <strong>Performance cookies:</strong> Provide aggregated analytics
            that guide experience improvements.
          </li>
          <li>
            <strong>Functional cookies:</strong> Remember your settings such as
            language, region, or saved preferences.
          </li>
          <li>
            <strong>Marketing cookies:</strong> Help us deliver relevant
            communications aligned with your interests.
          </li>
        </ul>
      </section>
      <section className="legal-section">
        <h2>Managing Cookies</h2>
        <p>
          You can adjust cookie preferences through your browser settings or the
          TechStore cookie banner. Keep in mind certain features may not work
          optimally when essential cookies are disabled.
        </p>
      </section>
      <section className="legal-section">
        <h2>Contact Us</h2>
        <p>
          Questions about this policy? Contact us at{" "}
          <Link to="/contact" className="text-link">
            info@techstore.com
          </Link>{" "}
          or visit our{" "}
          <Link to="/contact" className="text-link">
            Contact page
          </Link>
          .
        </p>
      </section>
    </div>
  );
};

const NotFound = () => {
  usePageMeta(
    "TechStore | Page Not Found",
    "The page you are looking for cannot be found. Explore TechStore's innovative catalog."
  );

  return (
    <div className="page container not-found">
      <h1>Page not found</h1>
      <p>
        The page you requested has moved or no longer exists. Discover the
        latest innovations on our home page.
      </p>
      <Link className="btn-primary" to="/">
        Back to Home
      </Link>
    </div>
  );
};

const usePageMeta = (title, description) => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = title;
    if (metaTag) {
      metaTag.setAttribute("content", description);
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, [title, description]);
};

export default App;