import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("techstoreCookieConsent");
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem("techstoreCookieConsent", "accepted");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <aside className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <h4>We value your privacy</h4>
        <p>
          TechStore uses cookies to personalize your experience, analyze site
          traffic, and deliver relevant content. Review our{" "}
          <Link to="/cookie-policy" className="underline">
            Cookie Policy
          </Link>{" "}
          to learn more.
        </p>
      </div>
      <div className="cookie-actions">
        <button className="btn-secondary" onClick={acceptCookies}>
          Accept & continue
        </button>
        <Link className="btn-link" to="/privacy">
          Privacy preferences
        </Link>
      </div>
    </aside>
  );
};

export default CookieBanner;