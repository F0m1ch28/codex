import React from "react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="site-footer" role="contentinfo">
    <div className="container footer-grid">
      <div>
        <div className="footer-brand">
          <span className="brand-icon">⚡</span>
          <span className="brand-text">TechStore</span>
        </div>
        <p>
          TechStore curates cutting-edge electronics that empower bold thinkers
          worldwide. We champion thoughtful design, sustainable innovation, and
          technology that enriches everyday life.
        </p>
        <div className="footer-social">
          <a
            href="https://www.facebook.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="currentColor"
                d="M13 22h-3v-9H8v-3h2V8.5C10 5.9 11.4 4 14.6 4c1.2 0 2.2.1 2.2.1v2.8h-1.5C13.9 7 13 7.6 13 8.8V10h3l-.4 3H13v9z"
              />
            </svg>
          </a>
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="currentColor"
                d="M7 2h10a5 5 0 015 5v10a5 5 0 01-5 5H7a5 5 0 01-5-5V7a5 5 0 015-5zm10 2H7a3 3 0 00-3 3v10a3 3 0 003 3h10a3 3 0 003-3V7a3 3 0 00-3-3zm-5 3a5 5 0 110 10 5 5 0 010-10zm0 2.2a2.8 2.8 0 100 5.6 2.8 2.8 0 000-5.6zM18 5.7a1.3 1.3 0 110 2.6 1.3 1.3 0 010-2.6z"
              />
            </svg>
          </a>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="currentColor"
                d="M5.5 3A2.5 2.5 0 018 5.5 2.5 2.5 0 015.5 8 2.5 2.5 0 013 5.5 2.5 2.5 0 015.5 3zM4 9h3v12H4zm5.5 0H12v1.8h.1c.4-.7 1.4-1.5 2.9-1.5 3 0 3.6 2 3.6 4.6V21h-3v-5c0-1.2 0-2.7-1.7-2.7s-2 1.3-2 2.6V21h-3z"
              />
            </svg>
          </a>
        </div>
      </div>
      <div>
        <h4>Quick Links</h4>
        <ul className="footer-links">
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/categories">Categories</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </div>
      <div>
        <h4>Contact</h4>
        <address>
          <p>123 Innovation Drive</p>
          <p>San Francisco, CA 94107, USA</p>
        </address>
        <div className="footer-links">
          <Link to="/contact">+1 (555) 123-4567</Link>
          <Link to="/contact">info@techstore.com</Link>
        </div>
      </div>
      <div>
        <h4>Legal</h4>
        <ul className="footer-links">
          <li>
            <Link to="/terms">Terms of Service</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© 2023 TechStore. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;