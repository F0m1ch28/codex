import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header" role="banner">
      <div className="container header-inner">
        <Link to="/" className="brand" aria-label="TechStore Home">
          <span className="brand-icon">⚡</span>
          <span className="brand-text">TechStore</span>
        </Link>
        <nav className={"site-nav ${menuOpen ? "is-open" : ""}"} aria-label="Main navigation">
          <NavLink onClick={closeMenu} to="/" end>
            Home
          </NavLink>
          <NavLink onClick={closeMenu} to="/about">
            About
          </NavLink>
          <NavLink onClick={closeMenu} to="/categories">
            Categories
          </NavLink>
          <NavLink onClick={closeMenu} to="/new-arrivals">
            New Arrivals
          </NavLink>
          <NavLink onClick={closeMenu} to="/bestsellers">
            Bestsellers
          </NavLink>
          <NavLink onClick={closeMenu} to="/blog">
            Blog
          </NavLink>
          <NavLink onClick={closeMenu} to="/services">
            Services
          </NavLink>
          <NavLink onClick={closeMenu} to="/contact">
            Contact
          </NavLink>
        </nav>
        <div className="header-actions">
          <button className="icon-button" aria-label="Search">
            <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="currentColor"
                d="M21 20.3l-4.65-4.65a7 7 0 10-.7.7L20.3 21l.7-.7zM5 11a6 6 0 1112 0 6 6 0 01-12 0z"
              />
            </svg>
          </button>
          <button className="icon-button" aria-label="View cart">
            <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="currentColor"
                d="M7 4h-2l-1 2v2h2l3 9h10l3-9h2V6h-3l-1-2H7zm3 13l-2.25-7h11.5L17 17h-7zm-1 2a2 2 0 110 4 2 2 0 010-4zm8 0a2 2 0 110 4 2 2 0 010-4z"
              />
            </svg>
          </button>
          <button
            className="menu-toggle"
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            onClick={() => setMenuOpen((state) => !state)}
          >
            <span className="menu-bar" />
            <span className="menu-bar" />
            <span className="menu-bar" />
            <span className="sr-only">Toggle navigation</span>
          </button>
        </div>
      </div>
      <nav
        id="mobile-menu"
        className={"mobile-nav ${menuOpen ? "is-open" : ""}"}
        aria-label="Mobile navigation"
      >
        <NavLink onClick={closeMenu} to="/" end>
          Home
        </NavLink>
        <NavLink onClick={closeMenu} to="/about">
          About
        </NavLink>
        <NavLink onClick={closeMenu} to="/categories">
          Categories
        </NavLink>
        <NavLink onClick={closeMenu} to="/new-arrivals">
          New Arrivals
        </NavLink>
        <NavLink onClick={closeMenu} to="/bestsellers">
          Bestsellers
        </NavLink>
        <NavLink onClick={closeMenu} to="/blog">
          Blog
        </NavLink>
        <NavLink onClick={closeMenu} to="/services">
          Services
        </NavLink>
        <NavLink onClick={closeMenu} to="/contact">
          Contact
        </NavLink>
      </nav>
    </header>
  );
};

export default Header;