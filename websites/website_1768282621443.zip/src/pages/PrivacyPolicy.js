import React, { useEffect } from "react";
import { Link } from "react-router-dom";

const PrivacyPolicy = () => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = "TechStore | Privacy Policy";
    if (metaTag) {
      metaTag.setAttribute(
        "content",
        "Read the TechStore Privacy Policy to understand how we collect, use, and protect your personal information."
      );
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, []);

  return (
    <div className="page legal-page container">
      <header className="page-header">
        <h1>Privacy Policy</h1>
        <p className="lead">
          TechStore is committed to protecting your privacy. This policy explains how we
          collect, use, and safeguard personal data when you engage with our services.
        </p>
      </header>

      <section className="legal-section">
        <h2>Information We Collect</h2>
        <p>
          We gather information you provide directly, such as contact details or
          preferences, as well as data automatically collected from device usage,
          analytics, and cookies.
        </p>
      </section>

      <section className="legal-section">
        <h2>How We Use Information</h2>
        <ul>
          <li>Personalize product recommendations and experiences.</li>
          <li>Respond to inquiries and deliver customer support.</li>
          <li>Improve platform performance through analytics.</li>
          <li>Share relevant updates about TechStore offerings.</li>
        </ul>
      </section>

      <section className="legal-section">
        <h2>Data Protection</h2>
        <p>
          We implement administrative, technical, and physical safeguards to protect your
          information. Access is restricted to authorized team members who require it for
          business operations.
        </p>
      </section>

      <section className="legal-section">
        <h2>Your Rights</h2>
        <p>
          You may request access, correction, or deletion of your personal data. Depending
          on your region, additional rights may apply.
        </p>
      </section>

      <section className="legal-section">
        <h2>Contact Us</h2>
        <p>
          For privacy questions, email{" "}
          <Link className="text-link" to="/contact">
            info@techstore.com
          </Link>{" "}
          or visit our{" "}
          <Link className="text-link" to="/contact">
            Contact page
          </Link>
          .
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicy;