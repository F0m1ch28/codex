import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Home = () => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = "TechStore | Future-Ready Electronics & Gadgets";
    if (metaTag) {
      metaTag.setAttribute(
        "content",
        "Experience next-generation electronics, smart gadgets, and wearable innovations curated by TechStore for a global community."
      );
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, []);

  const featuredCategories = [
    {
      title: "Smartphones",
      description: "Edge-to-edge displays and AI-ready cameras built for daily brilliance.",
      image: "https://picsum.photos/id/1015/600/420"
    },
    {
      title: "Laptops",
      description: "Performance-tuned machines that empower hybrid work and creativity.",
      image: "https://picsum.photos/id/1/600/420"
    },
    {
      title: "Audio",
      description: "Noise-smart headphones and earbuds crafted for immersive clarity.",
      image: "https://picsum.photos/id/180/600/420"
    },
    {
      title: "Smart Home",
      description: "Automate comfort, security, and sustainability with intuitive devices.",
      image: "https://picsum.photos/id/1056/600/420"
    },
    {
      title: "Wearables",
      description: "Track wellness, productivity, and performance on the go.",
      image: "https://picsum.photos/id/1019/600/420"
    },
    {
      title: "Gaming",
      description: "High-refresh displays and responsive gear for competitive play.",
      image: "https://picsum.photos/id/1044/600/420"
    }
  ];

  const newArrivals = [
    {
      title: "LumenFold 2-in-1",
      description: "A convertible experience tuned for designers and digital nomads.",
      image: "https://picsum.photos/id/1051/500/360"
    },
    {
      title: "PulseBeam Speaker",
      description: "Adaptive ambient audio that flexes from studio to living room.",
      image: "https://picsum.photos/id/1042/500/360"
    },
    {
      title: "OrbitCam Mini",
      description: "Pocket-sized 6K imaging with pro-level stabilization.",
      image: "https://picsum.photos/id/1035/500/360"
    }
  ];

  const services = [
    {
      title: "Lifecycle Planning",
      description:
        "Strategize upgrades, migrations, and device refresh plans that keep your ecosystem agile.",
      icon: "🧭"
    },
    {
      title: "Configuration Lab",
      description:
        "Get hardware tuned and ready to deploy with firmware updates, security hardening, and bespoke profiles.",
      icon: "🛠️"
    },
    {
      title: "Global Fulfillment",
      description:
        "Ship the right tech to teams anywhere with transparent logistics and proactive support.",
      icon: "🌐"
    },
    {
      title: "Sustainability Consulting",
      description:
        "Optimize energy usage, extend product life, and recycle responsibly with our experts.",
      icon: "♻️"
    }
  ];

  const testimonials = [
    {
      name: "Amelia Chen",
      title: "Head of Product, Stellar Labs",
      quote:
        "TechStore translated our ambitious roadmap into a cohesive hardware strategy. Every shipment arrives configured, tested, and ready to perform.",
      avatar: "https://picsum.photos/id/1027/120/120"
    },
    {
      name: "Julian Park",
      title: "Creative Director, Lunar Studio",
      quote:
        "From laptops to studio monitors, every recommendation has elevated our craft. Their team anticipates what we need before we even ask.",
      avatar: "https://picsum.photos/id/1011/120/120"
    },
    {
      name: "Priya Desai",
      title: "Wellness Entrepreneur",
      quote:
        "The wearables collection is unmatched, and the guidance around data privacy gave me complete confidence to scale my programs globally.",
      avatar: "https://picsum.photos/id/1005/120/120"
    }
  ];

  const blogPreviews = [
    {
      title: "Designing a Zero-Gravity Workspace",
      description:
        "Essential tech choices when productivity needs to follow you to mountain peaks, trains, or client studios.",
      image: "https://picsum.photos/id/338/500/360"
    },
    {
      title: "Smart Home Synergy Explained",
      description:
        "How to orchestrate lighting, climate, and home security without sacrificing simplicity or privacy.",
      image: "https://picsum.photos/id/454/500/360"
    },
    {
      title: "Wellness Wearables to Watch",
      description:
        "The sensors and insights redefining how athletes, founders, and creators recharge fast.",
      image: "https://picsum.photos/id/321/500/360"
    }
  ];

  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterStatus, setNewsletterStatus] = useState("");

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    const trimmed = newsletterEmail.trim();
    if (!trimmed || !/^\S+@\S+\.\S+$/.test(trimmed)) {
      setNewsletterStatus("Please provide a valid email address.");
      return;
    }
    setNewsletterStatus("Thanks for joining the TechStore community!");
    setNewsletterEmail("");
  };

  return (
    <div className="home">
      <section
        className="hero"
        style={{
          backgroundImage:
            "linear-gradient(100deg, rgba(15,23,42,0.88), rgba(37,99,235,0.6)), url('https://picsum.photos/id/1047/1600/900')"
        }}
      >
        <div className="container hero-content">
          <p className="eyebrow">Global Tech Marketplace</p>
          <h1>Fuel Your Future with Breakthrough Electronics</h1>
          <p className="hero-subtitle">
            TechStore hand-selects visionary gadgets and intelligent devices that
            keep innovators a step ahead. Explore a universe of smart solutions built
            for creators, makers, and pioneers across the globe.
          </p>
          <div className="hero-actions">
            <Link className="btn-primary" to="/categories">
              Explore Gadgets
            </Link>
            <Link className="btn-outline" to="/services">
              Our Services
            </Link>
          </div>
        </div>
      </section>

      <section className="section container">
        <div className="section-header">
          <h2 className="section-title">Featured Categories</h2>
          <Link className="text-link" to="/categories">
            View all categories →
          </Link>
        </div>
        <div className="featured-grid">
          {featuredCategories.map((item) => (
            <article className="feature-card" key={item.title}>
              <div
                className="feature-media"
                style={{ backgroundImage: "url(${item.image})" }}
                aria-hidden="true"
              />
              <div className="feature-content">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <Link className="text-link" to="/new-arrivals">
                  Discover new arrivals →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section container">
        <div className="section-header">
          <h2 className="section-title">New Arrivals Spotlight</h2>
          <Link className="btn-link" to="/new-arrivals">
            View all
          </Link>
        </div>
        <div className="arrivals-grid">
          {newArrivals.map((item) => (
            <article className="arrival-card" key={item.title}>
              <div
                className="arrival-media"
                style={{ backgroundImage: "url(${item.image})" }}
                aria-hidden="true"
              />
              <div className="arrival-content">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <Link className="text-link" to="/contact">
                  Ask our team →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section highlight-section">
        <div className="container highlight-grid">
          <div className="highlight-copy">
            <h2 className="section-title">Why Choose TechStore?</h2>
            <p>
              Every device in our catalog undergoes rigorous testing, sustainability
              assessments, and usability reviews. We pair that with dedicated experts
              ready to tailor solutions for your ambitions.
            </p>
            <ul className="checklist">
              <li>Free global shipping on flagship categories</li>
              <li>2-year warranty coverage with proactive support</li>
              <li>24/7 expert assistance from product specialists</li>
              <li>Certified and responsibly sourced devices</li>
            </ul>
          </div>
          <div className="service-cards">
            {services.map((service) => (
              <article className="service-card" key={service.title}>
                <span className="service-icon" role="img" aria-label={service.title}>
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section container testimonials-section">
        <h2 className="section-title">Loved by Innovators Everywhere</h2>
        <div className="testimonials-grid">
          {testimonials.map((item) => (
            <figure className="testimonial-card" key={item.name}>
              <img src={item.avatar} alt={"${item.name}"} />
              <blockquote>{""${item.quote}""}</blockquote>
              <figcaption>
                <strong>{item.name}</strong>
                <span>{item.title}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="section container blog-preview">
        <div className="section-header">
          <h2 className="section-title">Tech Insights & News</h2>
          <Link className="text-link" to="/blog">
            Read our blog →
          </Link>
        </div>
        <div className="blog-grid">
          {blogPreviews.map((post) => (
            <article className="blog-card" key={post.title}>
              <div
                className="blog-media"
                style={{ backgroundImage: "url(${post.image})" }}
                aria-hidden="true"
              />
              <div className="blog-body">
                <h3>{post.title}</h3>
                <p>{post.description}</p>
                <Link className="text-link" to="/blog">
                  Continue reading →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="newsletter">
        <div className="container newsletter-inner">
          <div>
            <h2>Stay ahead of the curve</h2>
            <p>
              Subscribe for curated product drops, industry insights, and behind-the-scenes
              stories powering tomorrow’s tech.
            </p>
          </div>
          <form className="newsletter-form" onSubmit={handleNewsletterSubmit} noValidate>
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              placeholder="Enter your email"
              value={newsletterEmail}
              onChange={(event) => {
                setNewsletterEmail(event.target.value);
                setNewsletterStatus("");
              }}
              aria-describedby="newsletter-feedback"
              required
            />
            <button type="submit" className="btn-primary">
              Subscribe
            </button>
            {newsletterStatus && (
              <p id="newsletter-feedback" className="form-feedback">
                {newsletterStatus}
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Home;