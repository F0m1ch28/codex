import React, { useEffect } from "react";
import { Link } from "react-router-dom";

const Services = () => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = "TechStore | Services";
    if (metaTag) {
      metaTag.setAttribute(
        "content",
        "Discover TechStore services including lifecycle planning, configuration labs, logistics, and sustainability consulting."
      );
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, []);

  const serviceLayers = [
    {
      title: "Discovery & Advisory",
      points: [
        "Technology roadmap consultations",
        "Device benchmarking and comparative analysis",
        "Workstyle profiling for tailored recommendations"
      ],
      icon: "🔍"
    },
    {
      title: "Deployment & Integration",
      points: [
        "Pre-deployment configuration and testing",
        "Secure imaging and asset tagging",
        "Smart home and office installation support"
      ],
      icon: "🚀"
    },
    {
      title: "Lifecycle & Support",
      points: [
        "Proactive maintenance schedules",
        "Global repair coordination",
        "End-of-life recycling and data sanitization"
      ],
      icon: "♻️"
    }
  ];

  return (
    <div className="page services-page">
      <section className="page-header container">
        <h1>Services Designed for Visionaries</h1>
        <p className="lead">
          TechStore services surround each purchase with strategy, configuration,
          and long-term support so your teams can focus on breakthroughs.
        </p>
      </section>

      <section className="section container service-layers">
        {serviceLayers.map((layer) => (
          <article className="layer-card" key={layer.title}>
            <span className="layer-icon" role="img" aria-label={layer.title}>
              {layer.icon}
            </span>
            <div>
              <h3>{layer.title}</h3>
              <ul>
                {layer.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className="section container service-highlight">
        <div>
          <h2 className="section-title">Dedicated to Seamless Experiences</h2>
          <p>
            From bespoke bundles for startup teams to enterprise-grade logistics,
            we orchestrate every step with precision. Our global warehouses ensure
            fast, reliable delivery while our specialists provide support that feels
            timelessly personal.
          </p>
          <Link className="btn-primary" to="/contact">
            Schedule a consultation
          </Link>
        </div>
        <div className="service-gallery">
          <div
            style={{
              backgroundImage: "url('https://picsum.photos/id/110/500/520')"
            }}
            aria-hidden="true"
          />
          <div
            style={{
              backgroundImage: "url('https://picsum.photos/id/456/500/520')"
            }}
            aria-hidden="true"
          />
        </div>
      </section>
    </div>
  );
};

export default Services;