import React, { useEffect } from "react";

const About = () => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = "TechStore | About Us";
    if (metaTag) {
      metaTag.setAttribute(
        "content",
        "Learn about TechStore’s mission to empower innovators with curated electronics, global logistics, and lifelong support."
      );
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, []);

  const pillars = [
    {
      title: "Curated Excellence",
      description:
        "Every product in our catalog endures laboratory testing, real-world stress trials, and human-centered usability reviews."
    },
    {
      title: "Sustainable Innovation",
      description:
        "We collaborate with responsible manufacturers, prioritize recyclable materials, and support circular tech initiatives."
    },
    {
      title: "Global Community",
      description:
        "Our teams span five continents, delivering localized expertise and support while sharing a unified love for technology."
    }
  ];

  const team = [
    {
      name: "Sofia Alvarez",
      role: "Chief Executive Officer",
      image: "https://picsum.photos/id/1037/320/320"
    },
    {
      name: "Marcus Lee",
      role: "Head of Customer Experience",
      image: "https://picsum.photos/id/1047/320/320"
    },
    {
      name: "Leila Farah",
      role: "Director of Sustainability",
      image: "https://picsum.photos/id/1005/320/320"
    },
    {
      name: "Kenji Nakamura",
      role: "Lead Technologist",
      image: "https://picsum.photos/id/1012/320/320"
    }
  ];

  return (
    <div className="page about-page">
      <section className="page-hero about-hero">
        <div className="overlay" />
        <div className="inner">
          <h1>Engineering a World Where Technology Empowers Everyone</h1>
          <p>
            Founded in San Francisco and connected globally, TechStore unites product
            specialists, designers, and technologists who believe in the transformative
            power of smart hardware.
          </p>
        </div>
      </section>

      <section className="section container">
        <div className="two-column">
          <div>
            <h2 className="section-title">Our Story</h2>
            <p>
              TechStore began as a collective of engineers frustrated with generic gadget
              outlets. We envisioned a destination where quality excelled, guidance was
              personal, and technology elevated imagination. Today that vision powers a
              global marketplace serving creators, researchers, educators, and explorers.
            </p>
            <p>
              We continue to forge partnerships with emerging inventors and established
              industry leaders alike—bringing exclusive launches, collaborative support,
              and a fearless appetite for innovation to our community.
            </p>
          </div>
          <div className="about-stats">
            <div>
              <span className="stat-number">65+</span>
              <span className="stat-label">Countries served</span>
            </div>
            <div>
              <span className="stat-number">480</span>
              <span className="stat-label">Curated product lines</span>
            </div>
            <div>
              <span className="stat-number">24/7</span>
              <span className="stat-label">Specialist support</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section container pillars">
        <h2 className="section-title">What Drives Us</h2>
        <div className="pillar-grid">
          {pillars.map((pillar) => (
            <article className="pillar-card" key={pillar.title}>
              <h3>{pillar.title}</h3>
              <p>{pillar.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section container team-section">
        <h2 className="section-title">Leadership Team</h2>
        <div className="team-grid">
          {team.map((member) => (
            <article className="team-card" key={member.name}>
              <img src={member.image} alt={"${member.name}"} />
              <h3>{member.name}</h3>
              <p>{member.role}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default About;