import React, { useEffect } from "react";
import { Link } from "react-router-dom";

const ThankYou = () => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = "TechStore | Thank You";
    if (metaTag) {
      metaTag.setAttribute(
        "content",
        "Thank you for reaching out to TechStore. Our specialists will respond shortly."
      );
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, []);

  return (
    <div className="page container thank-you-page">
      <div className="thank-you-card">
        <h1>We received your message!</h1>
        <p>
          Thank you for contacting TechStore. A member of our specialist team will be in
          touch shortly to help you explore the right technology solutions.
        </p>
        <div className="thank-you-actions">
          <Link className="btn-primary" to="/">
            Return to Home
          </Link>
          <Link className="btn-outline" to="/categories">
            Browse categories
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ThankYou;