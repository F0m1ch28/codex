import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Contact = () => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = "TechStore | Contact Us";
    if (metaTag) {
      metaTag.setAttribute(
        "content",
        "Connect with TechStore specialists for product guidance, partnership opportunities, or global support."
      );
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, []);

  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
    setErrors((prev) => ({
      ...prev,
      [event.target.name]: ""
    }));
  };

  const validate = () => {
    const validationErrors = {};
    if (!formData.name.trim()) {
      validationErrors.name = "Please enter your name.";
    }
    if (!formData.email.trim()) {
      validationErrors.email = "Please enter your email.";
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email.trim())) {
      validationErrors.email = "Please provide a valid email address.";
    }
    if (!formData.message.trim()) {
      validationErrors.message = "Please share how we can help.";
    }
    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    setFormData({ name: "", email: "", message: "" });
    navigate("/thank-you");
  };

  return (
    <div className="page contact-page">
      <section className="page-header container">
        <h1>Let’s Build Your Next Breakthrough</h1>
        <p className="lead">
          Reach out to TechStore for product recommendations, deployment planning,
          or partnership opportunities. Our specialists respond within 24 hours.
        </p>
      </section>

      <section className="section container contact-grid">
        <div className="contact-info">
          <h2 className="section-title">Talk with our team</h2>
          <p>
            Prefer a conversation? Call us or send an email and a dedicated advisor
            will connect to co-create your perfect solution.
          </p>
          <div className="info-block">
            <h3>Address</h3>
            <p>123 Innovation Drive</p>
            <p>San Francisco, CA 94107, USA</p>
          </div>
          <div className="info-block">
            <h3>Phone</h3>
            <p>+1 (555) 123-4567</p>
          </div>
          <div className="info-block">
            <h3>Email</h3>
            <p>info@techstore.com</p>
          </div>
          <div className="info-block">
            <h3>Service Hours</h3>
            <p>Monday – Friday · 24/7 virtual assistance</p>
          </div>
        </div>

        <form className="contact-form" onSubmit={handleSubmit} noValidate>
          <div className="form-field">
            <label htmlFor="contact-name">Name</label>
            <input
              id="contact-name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              required
              aria-describedby={errors.name ? "contact-name-error" : undefined}
            />
            {errors.name && (
              <p className="form-error" id="contact-name-error">
                {errors.name}
              </p>
            )}
          </div>
          <div className="form-field">
            <label htmlFor="contact-email">Email</label>
            <input
              id="contact-email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              required
              aria-describedby={errors.email ? "contact-email-error" : undefined}
            />
            {errors.email && (
              <p className="form-error" id="contact-email-error">
                {errors.email}
              </p>
            )}
          </div>
          <div className="form-field">
            <label htmlFor="contact-message">How can we help?</label>
            <textarea
              id="contact-message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              required
              aria-describedby={errors.message ? "contact-message-error" : undefined}
            />
            {errors.message && (
              <p className="form-error" id="contact-message-error">
                {errors.message}
              </p>
            )}
          </div>
          <button type="submit" className="btn-primary">
            Submit message
          </button>
        </form>
      </section>
    </div>
  );
};

export default Contact;