import React, { useEffect } from "react";
import { Link } from "react-router-dom";

const TermsOfService = () => {
  useEffect(() => {
    const previousTitle = document.title;
    const metaTag = document.querySelector('meta[name="description"]');
    const previousDescription = metaTag ? metaTag.getAttribute("content") : "";
    document.title = "TechStore | Terms of Service";
    if (metaTag) {
      metaTag.setAttribute(
        "content",
        "Review the TechStore Terms of Service governing access, use, and responsibilities for our platform."
      );
    }
    return () => {
      document.title = previousTitle;
      if (metaTag) {
        metaTag.setAttribute("content", previousDescription);
      }
    };
  }, []);

  return (
    <div className="page legal-page container">
      <header className="page-header">
        <h1>Terms of Service</h1>
        <p className="lead">
          These Terms of Service outline the agreement between you and TechStore regarding
          your access to and use of our digital experiences, products, and services.
        </p>
      </header>

      <section className="legal-section">
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing TechStore digital properties, you acknowledge that you have read,
          understood, and agree to be bound by these terms. If you do not agree, please
          refrain from using the platform.
        </p>
      </section>

      <section className="legal-section">
        <h2>2. Use of the Platform</h2>
        <p>
          You agree to use TechStore services only for lawful purposes. You will not
          interfere with or disrupt our infrastructure, or attempt to gain unauthorized
          access to any systems or data.
        </p>
      </section>

      <section className="legal-section">
        <h2>3. Intellectual Property</h2>
        <p>
          All content, trademarks, and assets available through TechStore remain the
          property of TechStore or its partners. You may not reproduce or distribute
          content without explicit permission.
        </p>
      </section>

      <section className="legal-section">
        <h2>4. Limitation of Liability</h2>
        <p>
          TechStore provides services on an “as is” basis. We do not guarantee uninterrupted
          access and are not liable for indirect damages resulting from your use of the
          platform.
        </p>
      </section>

      <section className="legal-section">
        <h2>5. Changes to Terms</h2>
        <p>
          TechStore may update these terms to reflect evolving products or regulations.
          Continued use after modifications constitutes acceptance of the new terms.
        </p>
      </section>

      <section className="legal-section">
        <h2>6. Contact</h2>
        <p>
          Questions? Reach us at{" "}
          <Link className="text-link" to="/contact">
            info@techstore.com
          </Link>
          .
        </p>
      </section>
    </div>
  );
};

export default TermsOfService;