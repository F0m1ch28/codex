document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('.main-nav');
    const navLinks = document.querySelectorAll('.nav-links a');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            mainNav.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (mainNav && mainNav.classList.contains('open')) {
                mainNav.classList.remove('open');
                navToggle?.setAttribute('aria-expanded', 'false');
            }
            setTimeout(() => window.scrollTo({ top: 0, behavior: 'auto' }), 0);
        });
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('.cookie-accept');
        const consent = localStorage.getItem('tgfCookieConsent');

        if (consent === 'accepted') {
            cookieBanner.classList.add('hidden');
        }

        acceptBtn?.addEventListener('click', () => {
            localStorage.setItem('tgfCookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    const scrollBtn = document.querySelector('.scroll-to-top');
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const currentPage = document.body.dataset.page;
    if (currentPage) {
        navLinks.forEach(link => {
            if (link.dataset.page === currentPage) {
                link.classList.add('active');
                link.setAttribute('aria-current', 'page');
            }
        });
    }
});