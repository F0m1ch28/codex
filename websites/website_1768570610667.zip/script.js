document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteNav.classList.toggle('active');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    siteNav.classList.remove('active');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const cookieButtons = cookieBanner.querySelectorAll('.cookie-action');
        cookieButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                const choice = event.currentTarget.dataset.choice || 'dismissed';
                try {
                    localStorage.setItem('atomicgawa-cookie-choice', choice);
                } catch (error) {
                    /* graceful fallback */
                }
            });
        });

        try {
            const storedChoice = localStorage.getItem('atomicgawa-cookie-choice');
            if (storedChoice) {
                cookieBanner.style.display = 'none';
            }
        } catch (error) {
            /* localStorage may be unavailable */
        }

        const dismissControl = cookieBanner.querySelector('.cookie-dismiss');
        if (dismissControl) {
            dismissControl.addEventListener('click', () => {
                cookieBanner.style.display = 'none';
                try {
                    localStorage.setItem('atomicgawa-cookie-choice', 'dismissed');
                } catch (error) {
                    /* ignore storage errors */
                }
            });
        }
    }
});