<?php
$nombre = isset($_GET["nombre"]) ? htmlspecialchars($_GET["nombre"], ENT_QUOTES, 'UTF-8') : "Cliente";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gracias por contactar | Aqua Hydro Control España</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Confirmación de contacto con Aqua Hydro Control España.">
  <link rel="canonical" href="https://www.aquahydrocontrol.com/thanks.php">
  <link rel="icon" href="assets/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="styles.css">
  <script src="main.js" defer></script>
</head>
<body>
  <a class="skip-link" href="#main-content">Saltar al contenido</a>
  <div class="page-wrapper">
    <header class="site-header">
      <div class="container header-inner">
        <a class="brand" href="index.html">
          <span class="brand-logo">AH</span>
          <span class="brand-name">
            Aqua Hydro Control
            <span>Gestión hidroeléctrica España</span>
          </span>
        </a>
        <button class="nav-toggle" type="button" aria-label="Abrir menú" aria-expanded="false">
          <span class="tablet-hidden">☰</span>
        </button>
        <nav class="main-nav" aria-label="Navegación principal">
          <ul class="nav-list">
            <li><a class="nav-link" href="index.html">Inicio</a></li>
            <li><a class="nav-link" href="about.html">Nosotros</a></li>
            <li><a class="nav-link" href="solutions.html">Soluciones</a></li>
            <li><a class="nav-link" href="technology.html">Tecnología</a></li>
            <li><a class="nav-link" href="performance.html">Rendimiento</a></li>
            <li><a class="nav-link" href="projects.html">Proyectos</a></li>
            <li><a class="nav-link" href="contact.php">Contacto</a></li>
          </ul>
        </nav>
        <div class="header-cta">
          <a class="btn primary" href="contact.php">Solicitar Evaluación</a>
        </div>
      </div>
    </header>

    <main id="main-content">
      <section class="page-hero">
        <div class="container">
          <span class="section-title">Gracias</span>
          <h1>Gracias por tu mensaje, <?php echo $nombre; ?>.</h1>
          <p class="lead">Nuestro equipo analizará tu solicitud y se pondrá en contacto en las próximas 24 horas laborales para coordinar los siguientes pasos.</p>
        </div>
      </section>

      <section class="section">
        <div class="container cta-banner">
          <h2>Mientras tanto, explora nuestras innovaciones</h2>
          <p>Descubre cómo transformamos la monitorización presas y la eficiencia centrales hidroeléctricas en España.</p>
          <div class="cta-actions">
            <a class="btn primary" href="index.html">Volver al inicio</a>
            <a class="btn secondary" href="projects.html">Ver nuevos proyectos</a>
          </div>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <div class="container">
        <div class="footer-top">
          <div class="footer-brand">
            <a class="brand" href="index.html">
              <span class="brand-logo">AH</span>
              <span class="brand-name">
                Aqua Hydro Control
                <span>Smart hydro operations</span>
              </span>
            </a>
            <p>Lideramos la transformación digital de centrales hidroeléctricas con soluciones de monitorización presas, analítica avanzada y control inteligente hidráulico.</p>
          </div>
          <div class="footer-columns">
            <div class="footer-nav">
              <strong>Compañía</strong>
              <a href="about.html">Quiénes somos</a>
              <a href="projects.html">Proyectos</a>
              <a href="privacy.html">Privacidad</a>
              <a href="cookies.html">Cookies</a>
              <a href="terms.html">Términos legales</a>
            </div>
            <div class="footer-nav">
              <strong>Soluciones</strong>
              <a href="solutions.html">Monitorización</a>
              <a href="technology.html">Tecnología</a>
              <a href="performance.html">Rendimiento</a>
              <a href="contact.php">Soporte operativo</a>
            </div>
            <div>
              <strong>Contacto</strong>
              <div class="contact-info">
                <span>Aqua Hydro Control España</span>
                <span>Torre Mapfre, Carrer de la Marina 16-18<br>08005 Barcelona, España</span>
                <a href="tel:+34932123456">+34 932 123 456</a>
                <a href="mailto:contacto@aquahydrocontrol.com">contacto@aquahydrocontrol.com</a>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <span>© <span id="current-year-thanks">2024</span> Aqua Hydro Control España.</span>
          <span>Seguimos conectados.</span>
        </div>
      </div>
    </footer>
  </div>
  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <h3 class="cookie-banner__title">Control de cookies</h3>
    <p class="cookie-banner__text">Usamos cookies técnicas para mantener la seguridad y mejorar la experiencia de monitorización. Puedes aceptar o rechazar según tus preferencias.</p>
    <div class="cookie-banner__actions">
      <button class="btn secondary" type="button" data-cookie="reject">Rechazar</button>
      <button class="btn primary" type="button" data-cookie="accept">Aceptar</button>
    </div>
  </div>
  <script>
    const yearThanks = document.getElementById("current-year-thanks");
    if (yearThanks) {
      yearThanks.textContent = new Date().getFullYear();
    }
  </script>
</body>
</html>