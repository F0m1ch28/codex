<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = isset($_POST["nombre"]) ? trim($_POST["nombre"]) : "";
    $correo = isset($_POST["correo"]) ? trim($_POST["correo"]) : "";
    $empresa = isset($_POST["empresa"]) ? trim($_POST["empresa"]) : "";
    $mensaje = isset($_POST["mensaje"]) ? trim($_POST["mensaje"]) : "";
    $servicio = isset($_POST["servicio"]) ? trim($_POST["servicio"]) : "";

    $nombre = htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8');
    $correo = htmlspecialchars($correo, ENT_QUOTES, 'UTF-8');
    $empresa = htmlspecialchars($empresa, ENT_QUOTES, 'UTF-8');
    $servicio = htmlspecialchars($servicio, ENT_QUOTES, 'UTF-8');

    $redirectUrl = "thanks.php?nombre=" . urlencode($nombre);
    header("Location: " . $redirectUrl);
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto | Aqua Hydro Control España</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Contacta con el equipo de Aqua Hydro Control España para solicitar una evaluación hidráulica o soporte en monitorización de presas.">
  <meta property="og:title" content="Contacto Aqua Hydro Control España">
  <meta property="og:description" content="Solicita una evaluación hidráulica personalizada para tu central hidroeléctrica.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.aquahydrocontrol.com/contact.php">
  <meta property="og:image" content="https://picsum.photos/seed/hydrocontact/1200/630">
  <link rel="canonical" href="https://www.aquahydrocontrol.com/contact.php">
  <link rel="icon" href="assets/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="styles.css">
  <script src="main.js" defer></script>
</head>
<body>
  <a class="skip-link" href="#main-content">Saltar al contenido</a>
  <div class="page-wrapper">
    <header class="site-header">
      <div class="container header-inner">
        <a class="brand" href="index.html">
          <span class="brand-logo">AH</span>
          <span class="brand-name">
            Aqua Hydro Control
            <span>Gestión hidroeléctrica España</span>
          </span>
        </a>
        <button class="nav-toggle" type="button" aria-label="Abrir menú" aria-expanded="false">
          <span class="tablet-hidden">☰</span>
        </button>
        <nav class="main-nav" aria-label="Navegación principal">
          <ul class="nav-list">
            <li><a class="nav-link" href="index.html">Inicio</a></li>
            <li><a class="nav-link" href="about.html">Nosotros</a></li>
            <li><a class="nav-link" href="solutions.html">Soluciones</a></li>
            <li><a class="nav-link" href="technology.html">Tecnología</a></li>
            <li><a class="nav-link" href="performance.html">Rendimiento</a></li>
            <li><a class="nav-link" href="projects.html">Proyectos</a></li>
            <li><a class="nav-link" href="contact.php">Contacto</a></li>
          </ul>
        </nav>
        <div class="header-cta">
          <a class="btn primary" href="contact.php">Solicitar Evaluación</a>
        </div>
      </div>
    </header>

    <main id="main-content">
      <section class="page-hero">
        <div class="container">
          <span class="section-title">Conecta con nosotros</span>
          <h1>Solicita tu evaluación hidráulica personalizada</h1>
          <p class="lead">Completa el formulario y uno de nuestros ingenieros expertos se pondrá en contacto contigo para planificar el diagnóstico de tu central hidroeléctrica.</p>
        </div>
      </section>

      <section class="section">
        <div class="container grid two-columns">
          <div>
            <div class="card elevated form-card">
              <h2>Formulario de contacto</h2>
              <form action="contact.php" method="post" class="form-grid" aria-label="Formulario de contacto Aqua Hydro Control">
                <div class="input-field">
                  <label for="nombre">Nombre y apellidos</label>
                  <input id="nombre" name="nombre" type="text" autocomplete="name" required>
                </div>
                <div class="input-field">
                  <label for="correo">Correo corporativo</label>
                  <input id="correo" name="correo" type="email" autocomplete="email" required>
                </div>
                <div class="input-field">
                  <label for="empresa">Central o empresa</label>
                  <input id="empresa" name="empresa" type="text" required>
                </div>
                <div class="input-field">
                  <label for="servicio">Interés principal</label>
                  <select id="servicio" name="servicio" required>
                    <option value="">Selecciona una opción</option>
                    <option value="monitorizacion">Monitorización de presas</option>
                    <option value="mantenimiento">Mantenimiento predictivo hidráulico</option>
                    <option value="optimizar">Optimización energía hidroeléctrica</option>
                    <option value="control">Control inteligente hidráulico</option>
                  </select>
                </div>
                <div class="input-field">
                  <label for="mensaje">Mensaje</label>
                  <textarea id="mensaje" name="mensaje" rows="4" placeholder="Describe brevemente tu proyecto o necesidad"></textarea>
                </div>
                <div class="input-field">
                  <label>
                    <input type="checkbox" name="acepto" required>
                    He leído y acepto la <a href="privacy.html">política de privacidad</a>.
                  </label>
                </div>
                <button class="btn primary" type="submit">Solicitar Evaluación Hidráulica</button>
              </form>
            </div>
          </div>
          <div>
            <div class="card elevated">
              <h2>Información de contacto</h2>
              <p>Aqua Hydro Control España<br>Torre Mapfre, Carrer de la Marina 16-18<br>08005 Barcelona, España</p>
              <p><strong>Teléfono:</strong> <a href="tel:+34932123456">+34 932 123 456</a></p>
              <p><strong>Correo:</strong> <a href="mailto:contacto@aquahydrocontrol.com">contacto@aquahydrocontrol.com</a></p>
              <p>Atendemos de lunes a viernes con soporte para operaciones críticas y smart hydro operations en todo el territorio español.</p>
            </div>
            <div class="map-container" aria-label="Mapa de la ubicación de Aqua Hydro Control España">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2994.998469425278!2d2.194312776598075!3d41.38869799712171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4a3002ccdf58b%3A0xdffe4d3b5a793102!2sTorre%20Mapfre!5e0!3m2!1ses!2ses!4v1697040000000" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>
        </div>
      </section>

      <section class="section alt">
        <div class="container cta-banner">
          <h2>¿Necesitas asistencia inmediata?</h2>
          <p>Contacta con nuestro equipo de guardia para coordinar acciones de control remoto centralizado ante eventos críticos.</p>
          <div class="cta-actions">
            <a class="btn primary" href="tel:+34932123456">Llamar a soporte 24/7</a>
            <a class="btn secondary" href="solutions.html">Explorar soluciones</a>
          </div>
        </div>
      </section>
    </main>

    <footer class="site-footer">
      <div class="container">
        <div class="footer-top">
          <div class="footer-brand">
            <a class="brand" href="index.html">
              <span class="brand-logo">AH</span>
              <span class="brand-name">
                Aqua Hydro Control
                <span>Smart hydro operations</span>
              </span>
            </a>
            <p>Lideramos la transformación digital de centrales hidroeléctricas con soluciones de monitorización presas, analítica avanzada y control inteligente hidráulico.</p>
          </div>
          <div class="footer-columns">
            <div class="footer-nav">
              <strong>Compañía</strong>
              <a href="about.html">Quiénes somos</a>
              <a href="projects.html">Proyectos</a>
              <a href="privacy.html">Privacidad</a>
              <a href="cookies.html">Cookies</a>
              <a href="terms.html">Términos legales</a>
            </div>
            <div class="footer-nav">
              <strong>Soluciones</strong>
              <a href="solutions.html">Monitorización</a>
              <a href="technology.html">Tecnología</a>
              <a href="performance.html">Rendimiento</a>
              <a href="contact.php">Soporte operativo</a>
            </div>
            <div>
              <strong>Contacto</strong>
              <div class="contact-info">
                <span>Aqua Hydro Control España</span>
                <span>Torre Mapfre, Carrer de la Marina 16-18<br>08005 Barcelona, España</span>
                <a href="tel:+34932123456">+34 932 123 456</a>
                <a href="mailto:contacto@aquahydrocontrol.com">contacto@aquahydrocontrol.com</a>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <span>© <span id="current-year-contact">2024</span> Aqua Hydro Control España.</span>
          <span>Excelencia en soporte hidráulico.</span>
        </div>
      </div>
    </footer>
  </div>
  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <h3 class="cookie-banner__title">Control de cookies</h3>
    <p class="cookie-banner__text">Usamos cookies técnicas para mantener la seguridad y mejorar la experiencia de monitorización. Puedes aceptar o rechazar según tus preferencias.</p>
    <div class="cookie-banner__actions">
      <button class="btn secondary" type="button" data-cookie="reject">Rechazar</button>
      <button class="btn primary" type="button" data-cookie="accept">Aceptar</button>
    </div>
  </div>
  <script>
    const yearContact = document.getElementById("current-year-contact");
    if (yearContact) {
      yearContact.textContent = new Date().getFullYear();
    }
  </script>
</body>
</html>