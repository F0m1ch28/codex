document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  const navLinks = document.querySelectorAll(".nav-link");
  const header = document.querySelector(".site-header");

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = mainNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
  }

  navLinks.forEach((link) => {
    if (link.href && window.location.href.includes(link.getAttribute("href"))) {
      link.classList.add("active");
    }
  });

  const counters = document.querySelectorAll("[data-counter]");
  if (counters.length > 0) {
    const counterObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target;
            const target = Number(el.getAttribute("data-counter")) || 0;
            const duration = 2000;
            const start = 0;
            const startTime = performance.now();

            const updateCounter = (currentTime) => {
              const elapsed = currentTime - startTime;
              const progress = Math.min(elapsed / duration, 1);
              const value = Math.floor(progress * (target - start) + start);
              el.textContent = value.toLocaleString("es-ES");
              if (progress < 1) {
                requestAnimationFrame(updateCounter);
              }
            };

            requestAnimationFrame(updateCounter);
            observer.unobserve(el);
          }
        });
      },
      { threshold: 0.5 }
    );
    counters.forEach((counter) => counterObserver.observe(counter));
  }

  const accordionItems = document.querySelectorAll(".accordion-item");
  accordionItems.forEach((item) => {
    const headerEl = item.querySelector(".accordion-header");
    headerEl?.addEventListener("click", () => {
      const openItem = document.querySelector(".accordion-item.open");
      if (openItem && openItem !== item) {
        openItem.classList.remove("open");
      }
      item.classList.toggle("open");
    });
  });

  if (header) {
    const headerObserver = new IntersectionObserver(
      ([entry]) => {
        header.classList.toggle("scrolled", !entry.isIntersecting);
      },
      { threshold: 0.1 }
    );
    headerObserver.observe(document.body);
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptButton = document.querySelector('[data-cookie="accept"]');
  const rejectButton = document.querySelector('[data-cookie="reject"]');
  const storageKey = "ahc-cookie-preference";

  const showCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.add("active");
    }
  };

  const hideCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  };

  const cookiePreference = localStorage.getItem(storageKey);
  if (!cookiePreference) {
    setTimeout(showCookieBanner, 600);
  }

  acceptButton?.addEventListener("click", () => {
    localStorage.setItem(storageKey, "accepted");
    hideCookieBanner();
  });

  rejectButton?.addEventListener("click", () => {
    localStorage.setItem(storageKey, "rejected");
    hideCookieBanner();
  });

  const galleryCards = document.querySelectorAll(".gallery-card");
  galleryCards.forEach((card) => {
    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        card.click();
      }
    });
  });
});