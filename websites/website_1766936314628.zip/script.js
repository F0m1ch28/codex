(function () {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      nav.classList.toggle("opened");
      navToggle.classList.toggle("opened");
      const spans = navToggle.querySelectorAll("span");
      if (navToggle.classList.contains("opened")) {
        spans[0].style.transform = "translateY(9px) rotate(45deg)";
        spans[1].style.opacity = "0";
        spans[2].style.transform = "translateY(-9px) rotate(-45deg)";
      } else {
        spans[0].style.transform = "";
        spans[1].style.opacity = "1";
        spans[2].style.transform = "";
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieAccept = document.querySelector(".cookie-accept");
  const cookieDecline = document.querySelector(".cookie-decline");

  const COOKIE_KEY = "aurora-gift-cookie-consent";

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("active");
    }
  }

  if (!localStorage.getItem(COOKIE_KEY)) {
    setTimeout(showCookieBanner, 1200);
  }

  if (cookieAccept) {
    cookieAccept.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "accepted");
      hideCookieBanner();
    });
  }

  if (cookieDecline) {
    cookieDecline.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "declined");
      hideCookieBanner();
    });
  }

  const CART_KEY = "aurora-gift-cart-count";
  const cartCountElement = document.querySelector(".cart-count");
  const addButtons = document.querySelectorAll("[data-add-to-cart]");
  const addedNotice = document.querySelector(".added-notice");

  function updateCartDisplay(count) {
    if (cartCountElement) {
      cartCountElement.textContent = count;
    }
  }

  function showAddNotice(message) {
    if (!addedNotice) return;
    addedNotice.textContent = message;
    addedNotice.classList.add("visible");
    setTimeout(() => {
      addedNotice.classList.remove("visible");
    }, 2200);
  }

  let cartCount = parseInt(localStorage.getItem(CART_KEY) || "0", 10);
  if (Number.isNaN(cartCount)) {
    cartCount = 0;
  }
  updateCartDisplay(cartCount);

  addButtons.forEach((button) => {
    button.addEventListener("click", () => {
      cartCount += 1;
      localStorage.setItem(CART_KEY, String(cartCount));
      updateCartDisplay(cartCount);
      const name = button.getAttribute("data-product-name") || "Gift Box";
      showAddNotice(`${name} added to cart`);
    });
  });

  const filterChips = document.querySelectorAll("[data-filter]");
  const filterItems = document.querySelectorAll("[data-category]");

  filterChips.forEach((chip) => {
    chip.addEventListener("click", () => {
      const activeFilter = chip.getAttribute("data-filter");
      filterChips.forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");

      filterItems.forEach((item) => {
        const categories = item.getAttribute("data-category");
        if (!categories) return;
        if (activeFilter === "all" || categories.includes(activeFilter)) {
          item.style.display = "";
          item.style.opacity = "1";
          item.style.transform = "scale(1)";
        } else {
          item.style.opacity = "0";
          item.style.transform = "scale(0.95)";
          setTimeout(() => {
            item.style.display = "none";
          }, 200);
        }
      });
    });
  });

  const themeSelect = document.querySelector("#box-theme");
  const ribbonSelect = document.querySelector("#ribbon-color");
  const messageInput = document.querySelector("#gift-message");
  const extrasInputs = document.querySelectorAll("input[name='extras']");
  const previewVisual = document.querySelector(".preview-visual");
  const previewMessage = document.querySelector(".preview-message");

  const themeGradients = {
    christmas: "linear-gradient(135deg, rgba(178,31,41,0.92), rgba(27,123,67,0.95))",
    birthday: "linear-gradient(135deg, rgba(97,184,255,0.95), rgba(140,74,140,0.85))",
    luxury: "linear-gradient(135deg, rgba(212,175,55,0.92), rgba(17,19,32,0.9))",
    surprise: "linear-gradient(135deg, rgba(255,178,36,0.9), rgba(235,96,110,0.9))"
  };

  const ribbonShades = {
    scarlet: "#b21f29",
    emerald: "#1b7b43",
    champagne: "#f5d47c",
    cerulean: "#4ba3dd",
    amethyst: "#8c4a8c",
    ivory: "#f8f1df"
  };

  function updatePreview() {
    if (!previewVisual || !previewMessage) return;
    const theme = themeSelect ? themeSelect.value : "christmas";
    const ribbon = ribbonSelect ? ribbonSelect.value : "champagne";
    const message = messageInput ? messageInput.value.trim() : "";
    const chosenExtras = Array.from(extrasInputs)
      .filter((input) => input.checked)
      .map((input) => input.value);

    previewVisual.style.background = themeGradients[theme] || themeGradients.christmas;
    previewVisual.innerHTML = `<span>${theme} collection</span><strong>${ribbon} ribbon</strong>`;

    const extrasText = chosenExtras.length ? `<br><em>Extras: ${chosenExtras.join(", ")}</em>` : "";
    previewMessage.innerHTML = message ? `"${message}"${extrasText}` : `Write a heartfelt note to make this box unforgettable.${extrasText}`;
    previewMessage.style.borderLeft = `6px solid ${ribbonShades[ribbon] || ribbonShades.champagne}`;
  }

  if (themeSelect) {
    themeSelect.addEventListener("change", updatePreview);
  }
  if (ribbonSelect) {
    ribbonSelect.addEventListener("change", updatePreview);
  }
  if (messageInput) {
    messageInput.addEventListener("input", updatePreview);
  }
  extrasInputs.forEach((input) => {
    input.addEventListener("change", updatePreview);
  });
  updatePreview();

  const faqQuestions = document.querySelectorAll(".faq-question");
  faqQuestions.forEach((question) => {
    question.addEventListener("click", () => {
      const item = question.closest(".faq-item");
      if (!item) return;
      item.classList.toggle("open");
    });
  });

  const cookies = document.querySelectorAll(".cookie-banner");
  cookies.forEach((banner) => {
    banner.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        hideCookieBanner();
      }
    });
  });
})();