import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Familien begleitet', value: 8500 },
  { label: 'Budget-Workshops', value: 320 },
  { label: 'Praxis-Tools', value: 24 },
  { label: 'Zufriedenheit', value: 98, suffix: '%' }
];

const topics = [
  {
    title: 'Budgetierung & Haushaltsbuch',
    description: 'Gemeinsam entwickeln wir Ihr digitales Haushaltsbuch und verankern nachhaltige Routinen im Familienalltag.',
    icon: '📒',
    link: '/themenbereiche#budgetierung'
  },
  {
    title: 'Finanzplanung für Familien',
    description: 'Klare Ziele, smarte Rücklagen und Planungssicherheit für jede Lebensphase – verlässlich und transparent.',
    icon: '📊',
    link: '/themenbereiche#finanzplanung'
  },
  {
    title: 'Finanztools & Apps',
    description: 'Vergleich und Einführung passender Finanztools mit Schritt-für-Schritt-Anleitungen und Checklisten.',
    icon: '🧭',
    link: '/themenbereiche#finanztools'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Bedarfsanalyse',
    description: 'Wir analysieren Ihre aktuelle Budgetsituation, Ziele und Gewohnheiten anhand einer strukturierten Familien-Checkliste.'
  },
  {
    step: '02',
    title: 'Lernpfad & Materialien',
    description: 'Individuelle Lernmodule, Videos, Arbeitsblätter und Praxisübungen werden für Ihre Familie zusammengestellt.'
  },
  {
    step: '03',
    title: 'Umsetzung & Begleitung',
    description: 'Gemeinsame Budget-Workshops, digitale Tools und persönliche Beratung sichern dauerhaftes Finanzbewusstsein.'
  },
  {
    step: '04',
    title: 'Reflexion & Zertifikat',
    description: 'Wir evaluieren Fortschritte, optimieren Prozesse und zertifizieren den Abschluss Ihres Familien-Finanzplans.'
  }
];

const reasons = [
  {
    title: 'Didaktisch erprobtes Konzept',
    text: 'Unser Lernprogramm verbindet Fachwissen mit leicht verständlichen Methoden, speziell für Familien konzipiert.'
  },
  {
    title: 'Digitale Tools inklusive',
    text: 'Alle relevanten Vorlagen, Haushaltsbuch-Templates und App-Empfehlungen stehen sofort zum Einsatz bereit.'
  },
  {
    title: 'Zertifizierte Finanzpädagogen',
    text: 'Unser Team besteht aus erfahrenen Finanztrainer:innen mit Fokus auf Transparenz und Familienwirklichkeit.'
  },
  {
    title: 'Community & Austausch',
    text: 'Profitieren Sie von Erfahrungswerten anderer Familien und moderierten Live-Sessions unserer Experten.'
  }
];

const testimonials = [
  {
    quote: 'Wir haben endlich einen klaren Überblick über unsere Ausgaben und Rücklagen. Die Materialien sind praxisnah und familienfreundlich.',
    name: 'Familie Schneider',
    location: 'Hamburg',
    image: 'https://picsum.photos/160/160?random=11'
  },
  {
    quote: 'Strukturiert, motivierend und vor allem realistisch. Die Beratung hat uns geholfen, Ziele greifbar zu machen.',
    name: 'Familie Kaya',
    location: 'München',
    image: 'https://picsum.photos/160/160?random=12'
  },
  {
    quote: 'Die digitalen Vorlagen sparen Zeit und schaffen Routine. Unser Haushaltsbuch läuft nun wie von selbst.',
    name: 'Familie Fischer',
    location: 'Berlin',
    image: 'https://picsum.photos/160/160?random=13'
  }
];

const projects = [
  {
    title: 'Haushaltsbuch für junge Familien',
    category: 'Budgetierung',
    description: 'Einführung eines gemeinsamen digitalen Haushaltsbuchs mit automatisierten Auswertungstabellen.',
    image: 'https://picsum.photos/1200/800?random=21'
  },
  {
    title: 'Langfristige Familienplanung',
    category: 'Finanzplanung',
    description: 'Mehrstufige Sparziele, Notfallreserve und Planung von Bildungsbudgets für zwei Kinder.',
    image: 'https://picsum.photos/1200/800?random=22'
  },
  {
    title: 'Tool-Vergleich und App-Setup',
    category: 'Tools',
    description: 'Implementierung eines Finanz-Cockpits mit jasnoen Dashboard-Auswertungen und Erinnerungsfunktionen.',
    image: 'https://picsum.photos/1200/800?random=23'
  },
  {
    title: 'Budget-Workshop für Patchwork-Familien',
    category: 'Budgetierung',
    description: 'Strukturierte Budgetregeln und transparente Gesprächsformate für mehrere Haushalte.',
    image: 'https://picsum.photos/1200/800?random=24'
  }
];

const faqItems = [
  {
    question: 'Für welche Familien ist der FamilienFinanz Ratgeber geeignet?',
    answer: 'Unser Angebot richtet sich an Familien in Deutschland, die ihre Finanzen gemeinsam strukturieren möchten – unabhängig davon, ob sie gerade neu starten oder bestehende Prozesse optimieren wollen.'
  },
  {
    question: 'Wie läuft das Lernprogramm ab?',
    answer: 'Das Programm besteht aus modularen Video-Lektionen, Live-Sessions mit Finanzpädagog:innen, praxisnahen Aufgaben sowie Checklisten. Sie entscheiden flexibel über Tempo und Zeitpunkt.'
  },
  {
    question: 'Ist die Beratung produktneutral?',
    answer: 'Ja. Wir arbeiten unabhängig von Finanzprodukten und fokussieren uns ausschließlich auf Bildung, Struktur und Entscheidungsgrundlagen.'
  },
  {
    question: 'Welche technischen Voraussetzungen gibt es?',
    answer: 'Sie benötigen lediglich einen aktuellen Browser sowie wahlweise eine Tabellenkalkulation oder unsere empfohlenen Budget-Apps. Alle Vorlagen lassen sich einfach anpassen.'
  }
];

const blogPosts = [
  {
    title: 'Sechs Schritte zu einem nachhaltigen Familienbudget',
    excerpt: 'Wie Sie Schritt für Schritt Ihr Budget strukturieren, Prioritäten setzen und motivierende Routinen etablieren.',
    image: 'https://picsum.photos/800/600?random=31',
    date: '12. Februar 2024'
  },
  {
    title: 'Digitale Helfer für das Haushaltsbuch im Vergleich',
    excerpt: 'Welche App passt zu Ihrer Familie? Wir beleuchten Auswahlkriterien, Datenschutz und Bedienbarkeit.',
    image: 'https://picsum.photos/800/600?random=32',
    date: '30. Januar 2024'
  },
  {
    title: 'Finanzgespräche im Familienalltag',
    excerpt: 'Tipps, wie Sie Geldgespräche transparent und wertschätzend gestalten – auch mit Kindern und Jugendlichen.',
    image: 'https://picsum.photos/800/600?random=33',
    date: '16. Januar 2024'
  }
];

const Home = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('alle');
  const [openFAQ, setOpenFAQ] = useState(null);

  useEffect(() => {
    let animationFrame;
    const duration = 1600;
    const start = performance.now();

    const step = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      setCounters(statsData.map((stat) => Math.floor(progress * stat.value)));
      if (progress < 1) {
        animationFrame = requestAnimationFrame(step);
      }
    };

    animationFrame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'alle') return projects;
    return projects.filter((project) => project.category.toLowerCase() === projectFilter);
  }, [projectFilter]);

  const handleFAQToggle = (index) => {
    setOpenFAQ((prev) => (prev === index ? null : index));
  };

  const handlePrevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const handleNextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>FamilienFinanz Ratgeber | Finanzielle Klarheit für Ihre Familie</title>
        <meta
          name="description"
          content="Der FamilienFinanz Ratgeber unterstützt Familien in Deutschland bei Budgetierung, Finanzplanung und digitalen Tools – praxisnah, vertrauenswürdig und didaktisch fundiert."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay} aria-hidden="true" />
        <img
          src="https://picsum.photos/1600/900?random=1"
          alt="Familie arbeitet gemeinsam an ihrem Finanzplan"
          className={styles.heroImage}
          loading="eager"
        />
        <div className={styles.heroContent}>
          <p className={styles.heroTag}>Finanzielle Bildung für Familien in Deutschland</p>
          <h1 className={styles.heroTitle}>Finanzielle Klarheit für Ihre Familie</h1>
          <p className={styles.heroSubtitle}>
            Gemeinsam bringen wir Struktur in Ihr Budget, schaffen Transparenz für Entscheidungen und stärken Ihr finanzielle Wohlbefinden – Schritt für Schritt, verständlich und nachhaltig.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.heroCta}>
              Jetzt informieren
            </Link>
            <Link to="/lernprogramm" className={styles.heroSecondary}>
              Lernpfad entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Ergebnisse und Wirkungszahlen">
        {statsData.map((stat, index) => (
          <div className={styles.statCard} key={stat.label}>
            <span className={styles.statValue}>
              {counters[index]}
              {stat.suffix ? stat.suffix : '+'}
            </span>
            <span className={styles.statLabel}>{stat.label}</span>
          </div>
        ))}
      </section>

      <section className={styles.intro}>
        <div className={styles.introText}>
          <h2>Wer wir sind</h2>
          <p>
            Der FamilienFinanz Ratgeber ist eine Bildungsplattform, die Familien dabei unterstützt, ihre Finanzen mit Klarheit und System zu organisieren. Mit einer Kombination aus Lernmodulen, Workshops und
            individuellen Beratungen schaffen wir Vertrauen und langfristige Stabilität.
          </p>
          <p>
            Unsere Inhalte basieren auf wissenschaftlich fundierten Methoden, werden kontinuierlich aktualisiert und auf den familiären Alltag abgestimmt – für Entscheidungen, die heute wirken und morgen Bestand
            haben.
          </p>
          <Link to="/ueber-uns" className={styles.linkArrow}>
            Mehr über unsere Geschichte
          </Link>
        </div>
        <div className={styles.introMedia}>
          <img src="https://picsum.photos/800/600?random=2" alt="Familie plant Ihr Budget mit digitalen Werkzeugen" loading="lazy" />
          <div className={styles.introBadge}>
            <span className={styles.badgeIcon}>✔</span>
            <div>
              <strong>Transparente Methodik</strong>
              <p>Didaktisch gestaltet und leicht umsetzbar.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.topics} id="themen">
        <header className={styles.sectionHeader}>
          <h2>Unsere Themenbereiche</h2>
          <p>Praxisnah, verständlich und auf den Familienalltag zugeschnitten – mit Fokus auf Struktur, Klarheit und nachhaltige Finanzkompetenz.</p>
        </header>
        <div className={styles.topicGrid}>
          {topics.map((topic) => (
            <article key={topic.title} className={styles.topicCard}>
              <span className={styles.topicIcon} aria-hidden="true">
                {topic.icon}
              </span>
              <h3>{topic.title}</h3>
              <p>{topic.description}</p>
              <Link to={topic.link} className={styles.linkArrow}>
                Mehr erfahren
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-label="So funktioniert es">
        <header className={styles.sectionHeader}>
          <h2>So funktioniert es</h2>
          <p>Ein klarer Lernpfad mit persönlicher Begleitung – für nachhaltige Umsetzung und finanzielle Sicherheit.</p>
        </header>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.step} className={styles.processCard}>
              <span className={styles.processStep} aria-hidden="true">
                {step.step}
              </span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.reasons}>
        <header className={styles.sectionHeader}>
          <h2>Warum FamilienFinanz?</h2>
          <p>Wir verbinden Fachwissen mit Empathie und stehen Familien als zuverlässige Partner zur Seite.</p>
        </header>
        <div className={styles.reasonsGrid}>
          {reasons.map((reason) => (
            <article key={reason.title}>
              <h3>{reason.title}</h3>
              <p>{reason.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Erfahrungsberichte">
        <header className={styles.sectionHeader}>
          <h2>Erfahrungsberichte</h2>
          <p>Familien berichten über ihren Weg zu mehr finanzieller Klarheit und Sicherheit.</p>
        </header>
        <div className={styles.testimonialWrapper}>
          <button type="button" className={styles.testimonialControl} onClick={handlePrevTestimonial} aria-label="Vorheriges Testimonial">
            ‹
          </button>
          <article className={styles.testimonialCard}>
            <img src={testimonials[currentTestimonial].image} alt={`Portrait von ${testimonials[currentTestimonial].name}`} loading="lazy" />
            <blockquote>
              <p>„{testimonials[currentTestimonial].quote}“</p>
              <footer>
                <strong>{testimonials[currentTestimonial].name}</strong>, {testimonials[currentTestimonial].location}
              </footer>
            </blockquote>
          </article>
          <button type="button" className={styles.testimonialControl} onClick={handleNextTestimonial} aria-label="Nächstes Testimonial">
            ›
          </button>
        </div>
        <div className={styles.testimonialDots} role="tablist" aria-label="Testimonials auswählen">
          {testimonials.map((_, index) => (
            <button
              type="button"
              key={`dot-${index}`}
              onClick={() => setCurrentTestimonial(index)}
              className={`${styles.dot} ${currentTestimonial === index ? styles.dotActive : ''}`}
              aria-label={`Testimonial ${index + 1}`}
              aria-selected={currentTestimonial === index}
            />
          ))}
        </div>
      </section>

      <section className={styles.projects} aria-label="Projektbeispiele">
        <header className={styles.sectionHeader}>
          <h2>Projektbeispiele aus der Praxis</h2>
          <p>Ausgewählte Szenarien zeigen, wie Familien Finanzkompetenz im Alltag verankern.</p>
        </header>
        <div className={styles.projectFilters} role="tablist" aria-label="Projektkategorien filtern">
          <button type="button" onClick={() => setProjectFilter('alle')} className={projectFilter === 'alle' ? styles.filterActive : ''}>
            Alle
          </button>
          <button type="button" onClick={() => setProjectFilter('budgetierung')} className={projectFilter === 'budgetierung' ? styles.filterActive : ''}>
            Budgetierung
          </button>
          <button type="button" onClick={() => setProjectFilter('finanzplanung')} className={projectFilter === 'finanzplanung' ? styles.filterActive : ''}>
            Finanzplanung
          </button>
          <button type="button" onClick={() => setProjectFilter('tools')} className={projectFilter === 'tools' ? styles.filterActive : ''}>
            Tools & Apps
          </button>
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <img src={project.image} alt={`Projektbeispiel: ${project.title}`} loading="lazy" />
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaBanner}>
        <div className={styles.ctaContent}>
          <h2>Bereit für Ihren Finanzlernweg?</h2>
          <p>Wir begleiten Sie persönlich – mit klaren Strukturen, modernen Tools und praxisnahen Materialien für Ihren Familienalltag.</p>
          <div className={styles.ctaActions}>
            <Link to="/kontakt" className={styles.heroCta}>
              Kostenlose Erstinformation
            </Link>
            <Link to="/berater" className={styles.heroSecondary}>
              Beraterteam kennenlernen
            </Link>
          </div>
        </div>
        <img src="https://picsum.photos/800/600?random=4" alt="Beraterin unterstützt Familie bei Finanzplanung" loading="lazy" />
      </section>

      <section className={styles.faq} id="faq">
        <header className={styles.sectionHeader}>
          <h2>Häufige Fragen</h2>
          <p>Antworten auf häufige Anliegen rund um unser Finanzbildungsprogramm.</p>
        </header>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <article key={item.question} className={`${styles.faqItem} ${openFAQ === index ? styles.faqOpen : ''}`}>
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => handleFAQToggle(index)}
                aria-expanded={openFAQ === index}
              >
                {item.question}
                <span aria-hidden="true">{openFAQ === index ? '−' : '+'}</span>
              </button>
              <div className={styles.faqAnswer} role="region">{item.answer}</div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-label="Aktuelle Impulse">
        <header className={styles.sectionHeader}>
          <h2>Aktuelle Impulse & Ressourcen</h2>
          <p>Bleiben Sie auf dem Laufenden mit aktuellen Einblicken und hilfreichen Materialien.</p>
        </header>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/lernprogramm" className={styles.linkArrow}>
                  Zum Lernbereich
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.contactPreview}>
        <div className={styles.contactText}>
          <h2>Wir sind für Sie da</h2>
          <p>
            Ob kurzer Austausch oder ausführliches Gespräch – wir beantworten Ihre Fragen und begleiten Sie beim Start in eine strukturierte Finanzzukunft.
          </p>
          <ul>
            <li>Persönliche Ansprechpartner:innen</li>
            <li>Vertrauliche Beratung & klare Prozesse</li>
            <li>Ressourcen und Checklisten zum Mitnehmen</li>
          </ul>
          <Link to="/kontakt" className={styles.heroCta}>
            Kontakt aufnehmen
          </Link>
        </div>
        <div className={styles.contactCard}>
          <h3>Kontaktinformationen</h3>
          <p>Unter den Linden 42<br />10117 Berlin, Deutschland</p>
          <a href="tel:+493087654321">+49 30 8765 4321</a>
          <a href="mailto:kontakt@familienfinanz.de">kontakt@familienfinanz.de</a>
        </div>
      </section>
    </div>
  );
};

export default Home;