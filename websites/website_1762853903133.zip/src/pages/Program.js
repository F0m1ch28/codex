import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Program.module.css';

const modules = [
  {
    title: 'Modul 1: Grundlagen & Analyse',
    duration: '2 Wochen',
    description: 'Bestandsaufnahme, Zieldefinition und Einrichtung des Familien-Cockpits für Einnahmen und Ausgaben.',
    deliverables: ['Familien-Checkliste', 'Ausgabeanalyse', 'Budget-Canvas']
  },
  {
    title: 'Modul 2: Haushaltsbuch & Routinen',
    duration: '3 Wochen',
    description: 'Aufbau eines individuellen Haushaltsbuchs, Festlegung von Routinen und Monats-Reviews.',
    deliverables: ['Digitale Vorlagen', 'Routine-Planer', 'Monatsreflexion']
  },
  {
    title: 'Modul 3: Finanzplanung & Rücklagen',
    duration: '3 Wochen',
    description: 'Sparziele, Notfallreserven und Planung für Bildung, Vorsorge und Familienprojekte.',
    deliverables: ['Ziel-Tracker', 'Rücklagenplan', 'Langfrist-Kalender']
  },
  {
    title: 'Modul 4: Familienkommunikation & Zukunft',
    duration: '2 Wochen',
    description: 'Moderierte Finanzgespräche, Entscheidungslogiken und nachhaltige Implementierung.',
    deliverables: ['Gesprächsleitfäden', 'Reflexionsfragen', 'Zertifikat']
  }
];

const Program = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Lernprogramm | FamilienFinanz Ratgeber</title>
        <meta
          name="description"
          content="Das Lernprogramm des FamilienFinanz Ratgebers: modulare Einheiten, praxisnahe Übungen und Zertifikate für nachhaltige Finanzkompetenz."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Strukturiertes Lernprogramm</h1>
        <p>In vier aufeinander aufbauenden Modulen begleiten wir Ihre Familie zu einem transparenten, reflektierten Finanzalltag.</p>
      </header>

      <section className={styles.modules}>
        {modules.map((module) => (
          <article key={module.title} className={styles.moduleCard}>
            <div>
              <h2>{module.title}</h2>
              <span className={styles.duration}>{module.duration}</span>
              <p>{module.description}</p>
            </div>
            <ul>
              {module.deliverables.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className={styles.support}>
        <div className={styles.supportText}>
          <h2>Begleitung & Umsetzung</h2>
          <p>Jedes Modul wird durch Live-Session, Q&A und individuelle Feedback-Schleifen unterstützt. Unsere Berater:innen begleiten Sie bei der Umsetzung und regen zu regelmäßiger Reflexion an.</p>
          <ul>
            <li>Live-Workshops und digitale Arbeitsräume</li>
            <li>Persönliche Check-ins mit Finanzpädagog:innen</li>
            <li>Zertifikat nach Abschluss des Programms</li>
          </ul>
        </div>
        <img src="https://picsum.photos/900/600?random=43" alt="Teilnehmerin arbeitet mit Lernunterlagen" loading="lazy" />
      </section>
    </div>
  );
};

export default Program;