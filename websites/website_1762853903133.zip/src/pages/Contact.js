import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name || formData.name.trim().length < 2) {
      newErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    }
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.topic) {
      newErrors.topic = 'Bitte wählen Sie ein Thema aus.';
    }
    if (!formData.message || formData.message.trim().length < 10) {
      newErrors.message = 'Bitte beschreiben Sie Ihr Anliegen ausführlicher.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;

    setStatus('Ihre Nachricht wird übermittelt ...');
    setTimeout(() => {
      setStatus('Vielen Dank! Wir melden uns zeitnah bei Ihnen.');
      setFormData({
        name: '',
        email: '',
        topic: '',
        message: ''
      });
    }, 1000);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | FamilienFinanz Ratgeber</title>
        <meta
          name="description"
          content="Kontaktieren Sie den FamilienFinanz Ratgeber in Berlin: Telefon, E-Mail, Kontaktformular und Standortkarte."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Kontakt</h1>
        <p>Wir beantworten Ihre Fragen zum FamilienFinanz Ratgeber und begleiten Sie beim Start in unser Lernprogramm.</p>
      </section>

      <section className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Nachricht senden</h2>
          <label htmlFor="name">
            Name
            <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} aria-invalid={!!errors.name} />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </label>
          <label htmlFor="email">
            E-Mail
            <input id="email" name="email" type="email" value={formData.email} onChange={handleChange} aria-invalid={!!errors.email} />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </label>
          <label htmlFor="topic">
            Anliegen
            <select id="topic" name="topic" value={formData.topic} onChange={handleChange} aria-invalid={!!errors.topic}>
              <option value="">Bitte auswählen</option>
              <option value="beratung">Beratung & Erstgespräch</option>
              <option value="programm">Fragen zum Lernprogramm</option>
              <option value="materialien">Materialien & Download</option>
              <option value="sonstiges">Sonstiges Anliegen</option>
            </select>
            {errors.topic && <span className={styles.error}>{errors.topic}</span>}
          </label>
          <label htmlFor="message">
            Nachricht
            <textarea id="message" name="message" rows="5" value={formData.message} onChange={handleChange} aria-invalid={!!errors.message} />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </label>
          <button type="submit">Nachricht senden</button>
          <div className={styles.status} aria-live="polite">
            {status}
          </div>
        </form>

        <div className={styles.details}>
          <h2>Direkte Kontaktmöglichkeiten</h2>
          <div className={styles.infoCard}>
            <p>
              <strong>Anschrift</strong>
              <br />
              Unter den Linden 42<br />
              10117 Berlin, Deutschland
            </p>
            <p>
              <strong>Telefon</strong>
              <br />
              <a href="tel:+493087654321">+49 30 8765 4321</a>
            </p>
            <p>
              <strong>E-Mail</strong>
              <br />
              <a href="mailto:kontakt@familienfinanz.de">kontakt@familienfinanz.de</a>
            </p>
          </div>
          <div className={styles.mapWrapper} aria-label="Standort Berlin">
            <iframe
              title="FamilienFinanz Ratgeber Standort Berlin"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.83595952009!2d13.382354777214693!3d52.51627997212264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c6d1d78df9%3A0xd4e8f1118a4d6104!2sUnter%20den%20Linden%2042%2C%2010117%20Berlin!5e0!3m2!1sde!2sde!4v1707990000000!5m2!1sde!2sde"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;