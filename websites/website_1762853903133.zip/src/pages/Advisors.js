import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Advisors.module.css';

const advisors = [
  {
    name: 'Anna Hoffmann',
    title: 'Zertifizierte Finanzpädagogin (DFE)',
    specialty: 'Budgetgespräche in Familien, Finanzroutinen, moderierte Workshops',
    focus: 'Schwerpunkte: Haushaltsbuch, Familienkommunikation, Alltagsstrukturen',
    image: 'https://picsum.photos/400/400?random=51'
  },
  {
    name: 'Dr. Tobias Müller',
    title: 'Finanzplaner (IHK), Pädagoge',
    specialty: 'Langfristige Finanzplanung, Vorsorge, Bildungsbudgets',
    focus: 'Schwerpunkte: Sparziele, Rücklagen, Entscheidungslogiken',
    image: 'https://picsum.photos/400/400?random=52'
  },
  {
    name: 'Leyla Aydin',
    title: 'Trainerin für Finanzkompetenz',
    specialty: 'Digitale Tools, App-Implementierung, Datenschutz',
    focus: 'Schwerpunkte: Tool-Auswahl, Automatisierung, Reporting',
    image: 'https://picsum.photos/400/400?random=53'
  },
  {
    name: 'Marco Feldhaus',
    title: 'Familiencoach & Finanzmentor',
    specialty: 'Patchwork-Finanzplanung, transparente Rollenmodelle',
    focus: 'Schwerpunkte: Mehrhaushalt, Alltagskoordination, Reflexion',
    image: 'https://picsum.photos/400/400?random=54'
  }
];

const Advisors = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Beraterteam | FamilienFinanz Ratgeber</title>
        <meta
          name="description"
          content="Lernen Sie das Beraterteam des FamilienFinanz Ratgebers kennen: zertifizierte Finanzpädagog:innen mit Erfahrung in Budgetierung, Finanzplanung und digitalen Tools."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Ihr Beraterteam</h1>
        <p>Kompetent, empathisch und auf Familienbedürfnisse spezialisiert – unsere Expert:innen begleiten Sie auf Ihrem Finanzlernweg.</p>
      </header>

      <section className={styles.grid}>
        {advisors.map((advisor) => (
          <article key={advisor.name} className={styles.card}>
            <div className={styles.avatar}>
              <img src={advisor.image} alt={`Porträt von ${advisor.name}`} loading="lazy" />
            </div>
            <h2>{advisor.name}</h2>
            <p className={styles.title}>{advisor.title}</p>
            <p className={styles.specialty}>{advisor.specialty}</p>
            <p className={styles.focus}>{advisor.focus}</p>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Advisors;