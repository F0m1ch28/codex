import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const milestones = [
  {
    year: '2016',
    title: 'Gründung in Berlin',
    description: 'Start der Plattform, um Familien einen transparenten Zugang zu Finanzwissen zu ermöglichen.'
  },
  {
    year: '2018',
    title: 'Digitale Lernplattform',
    description: 'Einführung der modularen Lernumgebung mit Videos, Worksheets und interaktiven Elementen.'
  },
  {
    year: '2021',
    title: 'Netzwerk aus Finanzpädagog:innen',
    description: 'Ausbau des Beraterteams mit zertifizierten Expert:innen aus ganz Deutschland.'
  },
  {
    year: '2023',
    title: 'FamilienCommunity',
    description: 'Launch der begleiteten Community-Sessions und themenspezifischen Live-Formate.'
  }
];

const values = [
  {
    title: 'Verständlichkeit',
    text: 'Komplexe Finanzthemen werden alltagsnah und sprachlich klar vermittelt.'
  },
  {
    title: 'Verantwortung',
    text: 'Wir agieren unabhängig, produktneutral und im Sinne der Familien.'
  },
  {
    title: 'Partnerschaftlichkeit',
    text: 'Wir hören zu, begleiten individuell und entwickeln Lösungen auf Augenhöhe.'
  },
  {
    title: 'Nachhaltigkeit',
    text: 'Unsere Methoden zielen auf langfristige Routinen und finanzielle Stabilität ab.'
  }
];

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Über uns | FamilienFinanz Ratgeber</title>
        <meta
          name="description"
          content="Lernen Sie den FamilienFinanz Ratgeber kennen: unsere Geschichte, unser Finanzpädagogik-Team und unser Anspruch, Familien nachhaltig zu begleiten."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Gemeinsam für finanzielle Klarheit</h1>
          <p>
            FamilienFinanz Ratgeber ist aus der Überzeugung entstanden, dass finanzielle Bildung ein Grundstein für Sicherheit und Selbstbestimmung ist. Unser Team verbindet Finanzexpertise mit pädagogischer
            Erfahrung, um Wissen verständlich und alltagstauglich zu vermitteln.
          </p>
        </div>
        <img src="https://picsum.photos/1200/700?random=41" alt="Teammeeting der FamilienFinanz Experten" loading="lazy" />
      </section>

      <section className={styles.mission}>
        <div>
          <h2>Unsere Mission</h2>
          <p>
            Wir befähigen Familien, informierte Finanzentscheidungen zu treffen. Dabei setzen wir auf Transparenz, methodische Klarheit und praxisorientierte Begleitung. Jede Familie erhält Zugang zu Wissen, Tools und
            Reflexionsräumen, um finanzielle Ziele individuell umzusetzen.
          </p>
        </div>
        <div>
          <h2>Unser Ansatz</h2>
          <p>
            Unser didaktisches Konzept baut auf modularen Lernpfaden, interaktiven Sessions und personalisierten Begleitungen auf. Wir fördern Finanzkompetenz als Familienprojekt und stärken den Dialog über Werte,
            Ziele und Prioritäten.
          </p>
        </div>
      </section>

      <section className={styles.milestones}>
        <h2>Stationen unserer Entwicklung</h2>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <article key={milestone.year} className={styles.timelineItem}>
              <span className={styles.year}>{milestone.year}</span>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.values}>
        <h2>Was uns leitet</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.method}>
        <div className={styles.methodContent}>
          <h2>Pädagogischer Ansatz</h2>
          <p>
            Wir arbeiten nach den Prinzipien der handlungsorientierten Erwachsenenbildung: Jede Einheit verbindet Wissensaufbau, Anwendung und Reflexion. Checklisten, Budget-Templates und Gesprächsleitfäden helfen,
            Gelernte unmittelbar im Familienalltag zu verankern.
          </p>
          <ul>
            <li>Individuelle Lernpfade mit klaren Etappenzielen</li>
            <li>Verständliche Materialien für unterschiedliche Lerntypen</li>
            <li>Regelmäßige Feedbackschleifen und Reflexionsimpulse</li>
          </ul>
        </div>
        <div className={styles.methodMedia}>
          <img src="https://picsum.photos/900/600?random=42" alt="Workshopeinheit mit Familien" loading="lazy" />
        </div>
      </section>
    </div>
  );
};

export default About;