import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const sections = [
  {
    id: 'budgetierung',
    title: 'Budgetierung & Haushaltsbuch',
    intro: 'Mit klaren Strukturen und flexiblen Tools behalten Sie Ihre Ausgaben im Blick und schaffen Raum für Ziele.',
    items: [
      'Analyse aktueller Einnahmen- und Ausgabenströme',
      'Aufbau eines gemeinsamen Haushaltsbuchs mit Kategorien',
      'Routinen für Familien-Check-ins und Budgetgespräche',
      'Vorlagen für variable und fixe Kosten inkl. saisonaler Besonderheiten'
    ]
  },
  {
    id: 'finanzplanung',
    title: 'Familienorientierte Finanzplanung',
    intro: 'Langfristige Planung sorgt für Sicherheit in verschiedenen Lebensphasen und schafft verlässliche Rücklagen.',
    items: [
      'Zieldefinition für Wünsche, Bildung und Vorsorge',
      'Methoden zur Bildung von Notfall- und Projektreserven',
      'Planungswerkzeuge für Familienmeilensteine',
      'Transparente Kommunikation und Entscheidungslogik'
    ]
  },
  {
    id: 'finanztools',
    title: 'Finanztools & Apps',
    intro: 'Wir finden und implementieren digitale Lösungen, die zu Ihren Gewohnheiten und Sicherheitsansprüchen passen.',
    items: [
      'Vergleich führender Haushaltsbuch-Apps',
      'Integration von Online-Banking und automatisierten Reports',
      'Schritt-für-Schritt-Anleitungen für den Familienalltag',
      'Datenschutz- und Sicherheitsempfehlungen'
    ]
  }
];

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Themenbereiche | FamilienFinanz Ratgeber</title>
        <meta
          name="description"
          content="Entdecken Sie die Themenbereiche des FamilienFinanz Ratgebers: Budgetierung, Finanzplanung und digitale Tools für Familien in Deutschland."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Unsere Themenbereiche</h1>
        <p>Von der Budgetbasis über strukturierte Finanzplanung bis zu digitalen Tools – wir begleiten Familien ganzheitlich.</p>
      </header>

      <section className={styles.sections}>
        {sections.map((section) => (
          <article id={section.id} key={section.title} className={styles.sectionCard}>
            <div className={styles.sectionHeader}>
              <h2>{section.title}</h2>
              <p>{section.intro}</p>
            </div>
            <ul>
              {section.items.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className={styles.tools}>
        <h2>Was Sie erhalten</h2>
        <div className={styles.toolGrid}>
          <div>
            <h3>Vorlagen & Checklisten</h3>
            <p>Digitale Haushaltsbücher, Planungs-Templates, Gesprächsleitfäden und Jahresübersichten.</p>
          </div>
          <div>
            <h3>Live-Sessions & Workshops</h3>
            <p>Interaktive Formate mit unseren Finanzpädagog:innen – live begleitet oder als Aufzeichnung.</p>
          </div>
          <div>
            <h3>Community & Austausch</h3>
            <p>Moderierte Gruppenformate, Q&A Sessions und Erfahrungsberichte anderer Familien.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;