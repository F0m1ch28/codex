import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Datenschutzerklärung | FamilienFinanz Ratgeber</title>
        <meta
          name="description"
          content="Datenschutzinformationen des FamilienFinanz Ratgebers gemäß DSGVO – transparente Verarbeitung personenbezogener Daten."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Datenschutzerklärung</h1>
        <p>Wir nehmen den Schutz Ihrer Daten ernst und verarbeiten personenbezogene Informationen gemäß DSGVO.</p>
      </header>

      <section className={styles.section}>
        <h2>1. Verantwortliche Stelle</h2>
        <p>FamilienFinanz Ratgeber, Unter den Linden 42, 10117 Berlin, Deutschland, kontakt@familienfinanz.de</p>
      </section>

      <section className={styles.section}>
        <h2>2. Erhobene Daten</h2>
        <p>Wir verarbeiten Kontaktdaten, Nutzungsdaten und Inhalte aus Kontaktformularen ausschließlich zur Bearbeitung der Anfrage sowie zur Bereitstellung unserer Bildungsangebote.</p>
      </section>

      <section className={styles.section}>
        <h2>3. Rechtsgrundlage</h2>
        <p>Die Verarbeitung erfolgt auf Grundlage von Art. 6 Abs. 1 lit. b und f DSGVO zur Erfüllung vertraglicher Leistungen und zur Optimierung unserer Angebote.</p>
      </section>

      <section className={styles.section}>
        <h2>4. Speicherdauer</h2>
        <p>Daten werden nur so lange gespeichert, wie es für die Bearbeitung oder gesetzliche Aufbewahrungsfristen erforderlich ist.</p>
      </section>

      <section className={styles.section}>
        <h2>5. Rechte der Betroffenen</h2>
        <p>Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie Widerspruch.</p>
      </section>
    </div>
  );
};

export default Privacy;