import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Allgemeine Geschäftsbedingungen | FamilienFinanz Ratgeber</title>
        <meta name="description" content="Allgemeine Geschäftsbedingungen des FamilienFinanz Ratgebers – Transparenz für unsere Bildungs- und Beratungsangebote." />
      </Helmet>

      <header className={styles.hero}>
        <h1>Allgemeine Geschäftsbedingungen</h1>
        <p>Stand: Februar 2024</p>
      </header>

      <section className={styles.section}>
        <h2>1. Geltungsbereich</h2>
        <p>Diese AGB gelten für sämtliche Bildungs- und Beratungsleistungen des FamilienFinanz Ratgebers gegenüber Verbraucher:innen in Deutschland.</p>
      </section>

      <section className={styles.section}>
        <h2>2. Leistungsumfang</h2>
        <p>Wir bieten digitale Lerninhalte, Beratungen und Workshops zur Finanzbildung an. Inhalte, Termine und Formate werden transparent kommuniziert.</p>
      </section>

      <section className={styles.section}>
        <h2>3. Urheberrechte</h2>
        <p>Alle bereitgestellten Unterlagen, Videos und Materialien sind urheberrechtlich geschützt und dürfen ausschließlich im Rahmen der Nutzung durch die Familie verwendet werden.</p>
      </section>

      <section className={styles.section}>
        <h2>4. Haftung</h2>
        <p>Unsere Inhalte dienen der Finanzbildung. Wir übernehmen keine Haftung für individuelle Entscheidungen. Eine rechtliche oder steuerliche Beratung findet nicht statt.</p>
      </section>

      <section className={styles.section}>
        <h2>5. Datenschutz</h2>
        <p>Personenbezogene Daten werden gemäß unserer Datenschutzerklärung verarbeitet.</p>
      </section>
    </div>
  );
};

export default Terms;