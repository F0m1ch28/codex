import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Program from './pages/Program';
import Advisors from './pages/Advisors';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

const App = () => {
  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>FamilienFinanz Ratgeber | Finanzielle Bildung für Familien</title>
        <meta
          name="description"
          content="FamilienFinanz Ratgeber unterstützt Familien in Deutschland mit praxisnaher Finanzbildung, strukturierter Budgetplanung und digitalen Werkzeugen."
        />
        <meta
          name="keywords"
          content="Familienfinanzen Deutschland, Budgetplanung lernen, Haushaltsbuch digital, Finanzmanagement Familien"
        />
      </Helmet>
      <Header />
      <main className="main-content" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/themenbereiche" element={<Services />} />
          <Route path="/lernprogramm" element={<Program />} />
          <Route path="/berater" element={<Advisors />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/agb" element={<Terms />} />
          <Route path="/datenschutz" element={<Privacy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </>
  );
};

export default App;