import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Startseite FamilienFinanz Ratgeber">
          <span className={styles.logoMark}>F</span>
          <span className={styles.logoText}>FamilienFinanz Ratgeber</span>
        </NavLink>

        <nav className={`${styles.nav} ${menuOpen ? styles.navActive : ''}`} aria-label="Hauptnavigation">
          <ul className={styles.navList}>
            <li className={styles.navItem}>
              <NavLink end to="/" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
                Startseite
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/ueber-uns" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
                Über uns
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/themenbereiche" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
                Themenbereiche
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/lernprogramm" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
                Lernprogramm
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/berater" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
                Beraterteam
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/kontakt" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
                Kontakt
              </NavLink>
            </li>
          </ul>
        </nav>

        <button
          className={`${styles.menuToggle} ${menuOpen ? styles.menuOpen : ''}`}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="mobile-navigation"
          aria-label="Navigation ein- und ausklappen"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;