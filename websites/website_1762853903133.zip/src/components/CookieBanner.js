import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('ffr-cookie-consent');
    if (!consent) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('ffr-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um Ihr Nutzungserlebnis zu optimieren und unsere Inhalte für Familien in Deutschland kontinuierlich zu verbessern. Weitere Informationen finden Sie in unserer{' '}
          <a href="/datenschutz">Datenschutzerklärung</a>.
        </p>
        <button type="button" onClick={handleAccept} className={styles.button}>
          Einverstanden
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;