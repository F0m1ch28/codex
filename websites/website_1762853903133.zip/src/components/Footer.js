import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.top}>
        <div className={styles.brand}>
          <div className={styles.logo}>
            <span>F</span>
          </div>
          <p className={styles.description}>
            FamilienFinanz Ratgeber begleitet Familien in Deutschland mit verlässlicher Finanzbildung, verständlichen Methoden und praxisorientierten Werkzeugen für ein stabiles Haushaltsbudget.
          </p>
        </div>

        <div className={styles.columns}>
          <div>
            <h3 className={styles.heading}>Navigation</h3>
            <ul className={styles.links}>
              <li>
                <NavLink to="/ueber-uns">Über uns</NavLink>
              </li>
              <li>
                <NavLink to="/themenbereiche">Themenbereiche</NavLink>
              </li>
              <li>
                <NavLink to="/lernprogramm">Lernprogramm</NavLink>
              </li>
              <li>
                <NavLink to="/berater">Beraterteam</NavLink>
              </li>
              <li>
                <NavLink to="/kontakt">Kontakt</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Rechtliches</h3>
            <ul className={styles.links}>
              <li>
                <NavLink to="/agb">AGB</NavLink>
              </li>
              <li>
                <NavLink to="/datenschutz">Datenschutz</NavLink>
              </li>
              <li>
                <a href="#faq">FAQ</a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Kontakt</h3>
            <ul className={styles.contact}>
              <li>
                <span className={styles.label}>Adresse:</span>
                <span>Unter den Linden 42, 10117 Berlin, Deutschland</span>
              </li>
              <li>
                <span className={styles.label}>Telefon:</span>
                <a href="tel:+493087654321">+49 30 8765 4321</a>
              </li>
              <li>
                <span className={styles.label}>E-Mail:</span>
                <a href="mailto:kontakt@familienfinanz.de">kontakt@familienfinanz.de</a>
              </li>
            </ul>
          </div>
        </div>

        <div className={styles.newsletter}>
          <h3 className={styles.heading}>Monatliche Impulse</h3>
          <p>Finanzielle Tipps und Checklisten für Familien direkt ins Postfach – seriös, verständlich und kostenlos.</p>
          <form className={styles.form} aria-label="Newsletter Anmeldung">
            <label htmlFor="newsletter-email" className="sr-only">
              E-Mail Adresse
            </label>
            <input id="newsletter-email" type="email" name="email" placeholder="E-Mail Adresse" required />
            <button type="submit">Anmelden</button>
          </form>
          <small>Mit der Anmeldung bestätigen Sie die Verarbeitung gemäß unserer Datenschutzrichtlinie.</small>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} FamilienFinanz Ratgeber. Alle Rechte vorbehalten.</p>
        <div className={styles.social}>
          <a href="https://www.linkedin.com" aria-label="LinkedIn" target="_blank" rel="noreferrer">
            LinkedIn
          </a>
          <a href="https://www.youtube.com" aria-label="YouTube Kanal" target="_blank" rel="noreferrer">
            YouTube
          </a>
          <a href="https://www.instagram.com" aria-label="Instagram" target="_blank" rel="noreferrer">
            Instagram
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;