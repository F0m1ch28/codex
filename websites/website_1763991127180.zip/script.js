document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".menu");

  if (menuToggle && menu) {
    menuToggle.addEventListener("click", () => {
      const expanded = menuToggle.getAttribute("aria-expanded") === "true";
      menuToggle.setAttribute("aria-expanded", String(!expanded));
      menu.classList.toggle("activo");
    });

    menu.querySelectorAll("a").forEach((enlace) => {
      enlace.addEventListener("click", () => {
        menu.classList.remove("activo");
        menuToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const banner = document.querySelector(".cookie-banner");
  if (banner) {
    const pref = localStorage.getItem("miralendorius_cookie_preference");
    if (!pref) {
      setTimeout(() => {
        banner.classList.add("activo");
      }, 800);
    }

    banner.addEventListener("click", (evento) => {
      const boton = evento.target.closest("button[data-cookie]");
      if (!boton) return;

      const decision = boton.dataset.cookie === "accept" ? "accepted" : "declined";
      localStorage.setItem("miralendorius_cookie_preference", decision);
      banner.classList.remove("activo");
    });
  }

  const formularios = document.querySelectorAll("form");
  formularios.forEach((formulario) => {
    formulario.addEventListener("submit", (evento) => {
      evento.preventDefault();
      formulario.classList.add("exito");
      formulario.querySelectorAll("input, textarea").forEach((campo) => campo.value = "");
    });
  });
});