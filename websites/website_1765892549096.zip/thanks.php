<?php
$nombre = isset($_GET["nombre"]) ? htmlspecialchars($_GET["nombre"]) : "Equipo";
$empresa = isset($_GET["empresa"]) ? htmlspecialchars($_GET["empresa"]) : "tu organización";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gracias por tu mensaje | Iber Wind Control</title>
    <meta name="description" content="Gracias por contactar con Iber Wind Control. Responderemos a la brevedad.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="canonical" href="https://www.iberwindcontrol.com/thanks.php">
    <link rel="icon" href="https://picsum.photos/seed/ibw/48/48" type="image/png">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <a class="skip-link" href="#contenido">Saltar al contenido principal</a>
    <header class="site-header">
        <div class="site-header_inner">
            <div class="brand">
                <div class="brand-logo" aria-hidden="true">IW</div>
                <div>
                    <h1>Iber Wind Control España<span>Control inteligente de energía eólica</span></h1>
                </div>
            </div>
            <button class="nav-toggle" aria-label="Abrir menú" aria-expanded="false">☰</button>
            <nav class="main-nav" aria-label="Navegación principal">
                <ul>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="about.html">Compañía</a></li>
                    <li><a href="solutions.html">Soluciones</a></li>
                    <li><a href="technology.html">Tecnología</a></li>
                    <li><a href="performance.html">Desempeño</a></li>
                    <li><a href="projects.html">Proyectos</a></li>
                    <li><a class="current" href="contact.php">Contacto</a></li>
                </ul>
                <div class="main-nav_cta">
                    <a class="btn btn-secondary" href="contact.php">Agendar demo</a>
                </div>
            </nav>
        </div>
    </header>
    <main id="contenido" class="main-content">
        <section class="page-hero">
            <div class="page-header">
                <h1>Hemos recibido tu mensaje</h1>
                <p>Gracias <?php echo $nombre; ?>. Nuestro equipo se pondrá en contacto con <?php echo $empresa; ?> a la brevedad para coordinar los siguientes pasos.</p>
            </div>
        </section>
        <section class="section">
            <div class="content">
                <article class="callout">
                    <div>
                        <h3>¿Qué sucede ahora?</h3>
                        <p>Un consultor especializado revisará la información y te contactará para profundizar en las necesidades de tu parque eólico.</p>
                    </div>
                    <div>
                        <a class="btn btn-primary" href="index.html">Volver al inicio</a>
                    </div>
                </article>
            </div>
        </section>
    </main>
    <footer class="site-footer">
        <div class="footer-top">
            <div class="footer-brand">
                <div class="brand-logo" aria-hidden="true">IW</div>
                <p>Ingeniería, analítica y control para impulsar la operación de parques eólicos industriales a lo largo de toda España.</p>
            </div>
            <div class="footer-grid">
                <div class="footer-column">
                    <h4>Compañía</h4>
                    <ul>
                        <li><a href="about.html">Historia y misión</a></li>
                        <li><a href="projects.html">Casos de estudio</a></li>
                        <li><a href="technology.html">Capacidades tecnológicas</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Recursos</h4>
                    <ul>
                        <li><a href="solutions.html">Herramientas de monitorización</a></li>
                        <li><a href="performance.html">Informes de desempeño</a></li>
                        <li><a href="privacy.html">Privacidad</a></li>
                        <li><a href="cookies.html">Cookies</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Contacto</h4>
                    <ul>
                        <li><a href="https://goo.gl/maps/fake" rel="noopener">Torre Iberdrola, Plaza Euskadi 5, Bilbao</a></li>
                        <li><a href="tel:+34944123456">+34 944 123 456</a></li>
                        <li><a href="mailto:contacto@iberwindcontrol.com">contacto@iberwindcontrol.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <small>© <span id="year">2024</span> Iber Wind Control España. Todos los derechos reservados.</small>
            <div class="footer-bottom_links">
                <a href="privacy.html">Privacidad</a>
                <a href="cookies.html">Uso de cookies</a>
                <a href="terms.html">Aviso legal</a>
                <a href="sitemap.xml">Mapa del sitio</a>
            </div>
        </div>
    </footer>
    <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
        <p>Utilizamos cookies para mejorar la experiencia de navegación y medir métricas operativas. Puedes aceptar o rechazar su uso en cualquier momento.</p>
        <div class="cookie-actions">
            <button class="btn-text" data-cookie-decline type="button">Rechazar</button>
            <button class="btn btn-primary" data-cookie-accept type="button">Aceptar</button>
        </div>
    </div>
    <script>
        document.getElementById("year").textContent = new Date().getFullYear();
    </script>
    <script src="scripts.js" defer></script>
</body>
</html>