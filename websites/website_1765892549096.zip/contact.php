<?php
$errors = [];
$values = [
    "nombre" => "",
    "email" => "",
    "empresa" => "",
    "telefono" => "",
    "mensaje" => "",
    "consentimiento" => ""
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $values["nombre"] = trim(filter_input(INPUT_POST, "nombre", FILTER_SANITIZE_STRING));
    $values["email"] = trim(filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL));
    $values["empresa"] = trim(filter_input(INPUT_POST, "empresa", FILTER_SANITIZE_STRING));
    $values["telefono"] = trim(filter_input(INPUT_POST, "telefono", FILTER_SANITIZE_STRING));
    $values["mensaje"] = trim(filter_input(INPUT_POST, "mensaje", FILTER_SANITIZE_STRING));
    $values["consentimiento"] = isset($_POST["consentimiento"]) ? "on" : "";

    if ($values["nombre"] === "") {
        $errors["nombre"] = "Por favor, indica tu nombre completo.";
    }
    if ($values["email"] === "" || !filter_var($values["email"], FILTER_VALIDATE_EMAIL)) {
        $errors["email"] = "Introduce un correo electrónico válido.";
    }
    if ($values["empresa"] === "") {
        $errors["empresa"] = "Indica la empresa u organización.";
    }
    if ($values["mensaje"] === "") {
        $errors["mensaje"] = "Incluye un mensaje con tus necesidades.";
    }
    if ($values["consentimiento"] !== "on") {
        $errors["consentimiento"] = "Es necesario aceptar la política de privacidad.";
    }

    if (empty($errors)) {
        $query = http_build_query([
            "nombre" => $values["nombre"],
            "empresa" => $values["empresa"]
        ]);
        header("Location: thanks.php?" . $query);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contacto Iber Wind Control | Solicita Información Técnica</title>
    <meta name="description" content="Contacta con Iber Wind Control España para coordinar un diagnóstico técnico o solicitar más información sobre la plataforma de control eólico.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:title" content="Contacto Iber Wind Control">
    <meta property="og:description" content="Coordina una reunión con especialistas en monitorización eólica y analítica avanzada.">
    <meta property="og:url" content="https://www.iberwindcontrol.com/contact.php">
    <meta property="og:image" content="https://picsum.photos/seed/contactwind/1200/630">
    <link rel="canonical" href="https://www.iberwindcontrol.com/contact.php">
    <link rel="icon" href="https://picsum.photos/seed/ibw/48/48" type="image/png">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <a class="skip-link" href="#contenido">Saltar al contenido principal</a>
    <header class="site-header">
        <div class="site-header_inner">
            <div class="brand">
                <div class="brand-logo" aria-hidden="true">IW</div>
                <div>
                    <h1>Iber Wind Control España<span>Control inteligente de energía eólica</span></h1>
                </div>
            </div>
            <button class="nav-toggle" aria-label="Abrir menú" aria-expanded="false">☰</button>
            <nav class="main-nav" aria-label="Navegación principal">
                <ul>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="about.html">Compañía</a></li>
                    <li><a href="solutions.html">Soluciones</a></li>
                    <li><a href="technology.html">Tecnología</a></li>
                    <li><a href="performance.html">Desempeño</a></li>
                    <li><a href="projects.html">Proyectos</a></li>
                    <li><a class="current" href="contact.php">Contacto</a></li>
                </ul>
                <div class="main-nav_cta">
                    <a class="btn btn-secondary" href="contact.php">Agendar demo</a>
                </div>
            </nav>
        </div>
    </header>
    <main id="contenido" class="main-content">
        <section class="page-hero">
            <div class="page-header">
                <nav class="breadcrumb" aria-label="Miga de pan">
                    <a href="index.html">Inicio</a> / Contacto
                </nav>
                <h1>Formulario de contacto</h1>
                <p>Cuéntanos sobre tu parque eólico y coordinaremos un diagnóstico técnico con nuestros especialistas.</p>
            </div>
        </section>
        <section class="section">
            <div class="content">
                <article class="two-column">
                    <div>
                        <h2>Escríbenos</h2>
                        <p>Resolvemos dudas sobre integración de sistemas, analítica avanzada y ciberseguridad operacional. Nuestro equipo responde en horario laboral con prioridad para operaciones críticas.</p>
                        <?php if (!empty($errors)): ?>
                            <div class="alert" role="alert">
                                Revisa la información proporcionada e inténtalo nuevamente.
                            </div>
                        <?php endif; ?>
                        <form class="form-card" method="post" action="contact.php" novalidate>
                            <div class="form-group">
                                <label for="nombre">Nombre y apellidos</label>
                                <input id="nombre" name="nombre" type="text" value="<?php echo htmlspecialchars($values["nombre"]); ?>" aria-required="true" aria-invalid="<?php echo isset($errors["nombre"]) ? "true" : "false"; ?>">
                                <?php if (isset($errors["nombre"])): ?>
                                    <div class="form-error"><?php echo $errors["nombre"]; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="email">Correo electrónico</label>
                                <input id="email" name="email" type="email" value="<?php echo htmlspecialchars($values["email"]); ?>" aria-required="true" aria-invalid="<?php echo isset($errors["email"]) ? "true" : "false"; ?>">
                                <?php if (isset($errors["email"])): ?>
                                    <div class="form-error"><?php echo $errors["email"]; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="empresa">Empresa / Organización</label>
                                <input id="empresa" name="empresa" type="text" value="<?php echo htmlspecialchars($values["empresa"]); ?>" aria-required="true" aria-invalid="<?php echo isset($errors["empresa"]) ? "true" : "false"; ?>">
                                <?php if (isset($errors["empresa"])): ?>
                                    <div class="form-error"><?php echo $errors["empresa"]; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="telefono">Teléfono de contacto</label>
                                <input id="telefono" name="telefono" type="tel" value="<?php echo htmlspecialchars($values["telefono"]); ?>">
                            </div>
                            <div class="form-group">
                                <label for="mensaje">Mensaje</label>
                                <textarea id="mensaje" name="mensaje" rows="5" aria-required="true" aria-invalid="<?php echo isset($errors["mensaje"]) ? "true" : "false"; ?>"><?php echo htmlspecialchars($values["mensaje"]); ?></textarea>
                                <?php if (isset($errors["mensaje"])): ?>
                                    <div class="form-error"><?php echo $errors["mensaje"]; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <div class="form-inline">
                                    <input id="consentimiento" name="consentimiento" type="checkbox" <?php echo $values["consentimiento"] === "on" ? "checked" : ""; ?>>
                                    <label for="consentimiento">Acepto la <a href="privacy.html">política de privacidad</a>.</label>
                                </div>
                                <?php if (isset($errors["consentimiento"])): ?>
                                    <div class="form-error"><?php echo $errors["consentimiento"]; ?></div>
                                <?php endif; ?>
                            </div>
                            <button class="btn btn-primary" type="submit">Enviar solicitud</button>
                        </form>
                    </div>
                    <div>
                        <h2>Visítanos</h2>
                        <p>Centro de Control Iber Wind Control España</p>
                        <div class="map-embed">
                            <iframe title="Ubicación de Iber Wind Control" src="https://www.openstreetmap.org/export/embed.html?bbox=-2.939%2C43.267%2C-2.935%2C43.270&amp;layer=mapnik" style="border:0; width:100%; height:100%;" loading="lazy"></iframe>
                        </div>
                        <div class="contact-details">
                            <p><strong>Dirección:</strong> Torre Iberdrola, Plaza Euskadi 5, 48009 Bilbao</p>
                            <p><strong>Teléfono:</strong> <a href="tel:+34944123456">+34 944 123 456</a></p>
                            <p><strong>Correo:</strong> <a href="mailto:contacto@iberwindcontrol.com">contacto@iberwindcontrol.com</a></p>
                            <p><strong>Horario:</strong> Lunes a viernes 09:00 - 18:00</p>
                        </div>
                    </div>
                </article>
            </div>
        </section>
    </main>
    <footer class="site-footer">
        <div class="footer-top">
            <div class="footer-brand">
                <div class="brand-logo" aria-hidden="true">IW</div>
                <p>Ingeniería, analítica y control para impulsar la operación de parques eólicos industriales a lo largo de toda España.</p>
            </div>
            <div class="footer-grid">
                <div class="footer-column">
                    <h4>Compañía</h4>
                    <ul>
                        <li><a href="about.html">Historia y misión</a></li>
                        <li><a href="projects.html">Casos de estudio</a></li>
                        <li><a href="technology.html">Capacidades tecnológicas</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Recursos</h4>
                    <ul>
                        <li><a href="solutions.html">Herramientas de monitorización</a></li>
                        <li><a href="performance.html">Informes de desempeño</a></li>
                        <li><a href="privacy.html">Privacidad</a></li>
                        <li><a href="cookies.html">Cookies</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Contacto</h4>
                    <ul>
                        <li><a href="https://goo.gl/maps/fake" rel="noopener">Torre Iberdrola, Plaza Euskadi 5, Bilbao</a></li>
                        <li><a href="tel:+34944123456">+34 944 123 456</a></li>
                        <li><a href="mailto:contacto@iberwindcontrol.com">contacto@iberwindcontrol.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <small>© <span id="year">2024</span> Iber Wind Control España. Todos los derechos reservados.</small>
            <div class="footer-bottom_links">
                <a href="privacy.html">Privacidad</a>
                <a href="cookies.html">Uso de cookies</a>
                <a href="terms.html">Aviso legal</a>
                <a href="sitemap.xml">Mapa del sitio</a>
            </div>
        </div>
    </footer>
    <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
        <p>Utilizamos cookies para mejorar la experiencia de navegación y medir métricas operativas. Puedes aceptar o rechazar su uso en cualquier momento.</p>
        <div class="cookie-actions">
            <button class="btn-text" data-cookie-decline type="button">Rechazar</button>
            <button class="btn btn-primary" data-cookie-accept type="button">Aceptar</button>
        </div>
    </div>
    <script>
        document.getElementById("year").textContent = new Date().getFullYear();
    </script>
    <script src="scripts.js" defer></script>
</body>
</html>