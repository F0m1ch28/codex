document.addEventListener('DOMContentLoaded', function () {
    const currentYear = new Date().getFullYear();
    document.querySelectorAll('.current-year').forEach(function (element) {
        element.textContent = currentYear;
    });

    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const expanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('is-open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('hackjglzCookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        }

        const acceptButton = cookieBanner.querySelector('.cookie-accept');
        const declineButton = cookieBanner.querySelector('.cookie-decline');

        const closeBanner = function (status) {
            localStorage.setItem('hackjglzCookieConsent', status);
            cookieBanner.classList.add('is-hidden');
        };

        if (acceptButton) {
            acceptButton.addEventListener('click', function (event) {
                event.preventDefault();
                closeBanner('accepted');
            });
        }

        if (declineButton) {
            declineButton.addEventListener('click', function (event) {
                event.preventDefault();
                closeBanner('declined');
            });
        }
    }

    document.querySelectorAll('[data-toggle-target]').forEach(function (trigger) {
        trigger.addEventListener('click', function () {
            const targetId = trigger.getAttribute('data-toggle-target');
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.classList.toggle('is-active');
            }
        });
    });
});