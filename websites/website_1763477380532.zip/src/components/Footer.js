import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <h3>Taliverenso</h3>
        <p>
          Ihr Partner für nachhaltige Work-Life-Balance, resiliente Teams und
          stressfreie Arbeitskulturen.
        </p>
      </div>
      <div className={styles.column}>
        <h4>Navigation</h4>
        <NavLink to="/" className={styles.link}>
          Startseite
        </NavLink>
        <NavLink to="/ueber-uns" className={styles.link}>
          Über uns
        </NavLink>
        <NavLink to="/leistungen" className={styles.link}>
          Leistungen
        </NavLink>
        <NavLink to="/blog" className={styles.link}>
          Blog
        </NavLink>
        <NavLink to="/kontakt" className={styles.link}>
          Kontakt
        </NavLink>
      </div>
      <div className={styles.column}>
        <h4>Rechtliches</h4>
        <NavLink to="/impressum" className={styles.link}>
          Impressum
        </NavLink>
        <NavLink to="/datenschutz" className={styles.link}>
          Datenschutz
        </NavLink>
        <NavLink to="/cookie-richtlinie" className={styles.link}>
          Cookie-Richtlinie
        </NavLink>
      </div>
      <div className={styles.column}>
        <h4>Kontakt</h4>
        <p>Musterstraße 123<br />10115 Berlin</p>
        <p>Telefon: +49 30 12345678</p>
        <p>E-Mail: <a href="mailto:info@taliverenso.site">info@taliverenso.site</a></p>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>&copy; {new Date().getFullYear()} Taliverenso. Alle Rechte vorbehalten.</p>
    </div>
  </footer>
);

export default Footer;