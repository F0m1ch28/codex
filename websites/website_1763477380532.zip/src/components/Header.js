import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setOpen(!open);
  };

  const closeMenu = () => {
    setOpen(false);
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          Taliverenso
        </NavLink>
        <nav className={`${styles.nav} ${open ? styles.open : ''}`}>
          <NavLink
            to="/"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={closeMenu}
          >
            Start
          </NavLink>
          <NavLink
            to="/ueber-uns"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={closeMenu}
          >
            Über uns
          </NavLink>
          <NavLink
            to="/leistungen"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={closeMenu}
          >
            Leistungen
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={closeMenu}
          >
            Blog
          </NavLink>
          <NavLink
            to="/kontakt"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={closeMenu}
          >
            Kontakt
          </NavLink>
        </nav>
        <button
          className={`${styles.burger} ${open ? styles.burgerOpen : ''}`}
          onClick={toggleMenu}
          aria-label="Navigation umschalten"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;