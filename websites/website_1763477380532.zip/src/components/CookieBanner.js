import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(() => {
    return !window.localStorage.getItem('taliverenso_cookie_consent');
  });

  const acceptCookies = () => {
    window.localStorage.setItem('taliverenso_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner}>
      <p>
        Wir verwenden Cookies, um Ihre Erfahrung zu verbessern und unsere
        Inhalte zu optimieren. Weitere Informationen finden Sie in unserer{' '}
        <Link to="/datenschutz">Datenschutzerklärung</Link> und{' '}
        <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>.
      </p>
      <button onClick={acceptCookies}>Verstanden</button>
    </div>
  );
};

export default CookieBanner;