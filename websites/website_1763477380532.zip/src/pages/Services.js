import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const serviceDetails = [
  {
    title: 'Individuelles Anti-Burnout-Coaching',
    summary:
      'Systemisches Coaching für Führungskräfte und Mitarbeitende, die nachhaltige Balance etablieren möchten.',
    bulletPoints: [
      'Analyse persönlicher Stressmuster und Ressourcen',
      'Aufbau individueller Regenerations-Routinen',
      'Stärkung von Selbstführung und Grenzen setzen'
    ],
    image: 'https://picsum.photos/900/600?random=601'
  },
  {
    title: 'Team-Resilienz Workshops',
    summary:
      'Interaktive Workshop-Serien, die psychologische Sicherheit fördern und Teamdynamiken stärken.',
    bulletPoints: [
      'Gemeinsame Resilienzsprache etablieren',
      'Energie- und Fokusmanagement im Team',
      'Konstruktive Kommunikation in Stresssituationen'
    ],
    image: 'https://picsum.photos/900/600?random=602'
  },
  {
    title: 'Organisationsberatung Work-Life-Balance',
    summary:
      'Langfristige Begleitung für Unternehmen, die gesunde Arbeitsmodelle entwickeln oder skalieren möchten.',
    bulletPoints: [
      'Analyse von Arbeitsabläufen und Meeting-Kultur',
      'Definition gesunder Erreichbarkeits-Standards',
      'Implementierung messbarer Balance-KPIs'
    ],
    image: 'https://picsum.photos/900/600?random=603'
  }
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>Leistungen | Taliverenso Anti-Burnout Programme</title>
        <meta
          name="description"
          content="Entdecken Sie unsere Leistungen: individuelles Anti-Burnout-Coaching, Team-Resilienz-Workshops und strategische Beratung für Work-Life-Balance."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Unsere Leistungen für spürbare Balance</h1>
          <p>
            Wir verbinden Coaching, Workshops und Beratung zu einem Maßnahmenmix,
            der Menschen stärkt und Unternehmen wandlungsfähig hält.
          </p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.tabs}>
          {serviceDetails.map((service, index) => (
            <button
              key={service.title}
              className={index === activeIndex ? styles.active : ''}
              onClick={() => setActiveIndex(index)}
            >
              {service.title}
            </button>
          ))}
        </div>
        <div className={styles.detail}>
          <div className={styles.text}>
            <h2>{serviceDetails[activeIndex].title}</h2>
            <p>{serviceDetails[activeIndex].summary}</p>
            <ul>
              {serviceDetails[activeIndex].bulletPoints.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </div>
          <div className={styles.imageWrapper}>
            <img
              src={serviceDetails[activeIndex].image}
              alt={serviceDetails[activeIndex].title}
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.approach}`}>
        <div className="container">
          <h2>So arbeiten wir</h2>
          <div className={styles.steps}>
            <div>
              <span>1</span>
              <h3>Analyse & Zielbild</h3>
              <p>
                Wir schauen genau hin: Welche Stressoren sind aktiv, welche
                Ressourcen stehen zur Verfügung, wohin soll die Reise gehen?
              </p>
            </div>
            <div>
              <span>2</span>
              <h3>Co-Kreation & Umsetzung</h3>
              <p>
                Gemeinsam entwickeln wir Maßnahmen und begleiten die praktische
                Umsetzung mit klaren Check-ins.
              </p>
            </div>
            <div>
              <span>3</span>
              <h3>Evaluation & Verstetigung</h3>
              <p>
                Wir messen Fortschritte, lernen daraus und verankern gesunde Routinen
                in Strukturen und Kultur.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;