import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'zufriedene Kund:innen', target: 180 },
  { label: 'begleitete Teams', target: 65 },
  { label: 'Workshops pro Jahr', target: 42 },
  { label: 'Burnout-Präventionspläne', target: 120 }
];

const services = [
  {
    title: 'Individuelles Anti-Burnout-Coaching',
    description:
      'Persönliche 1:1 Begleitung, die Stressauslöser aufdeckt und einen machbaren Alltag schafft.',
    icon: '🎧'
  },
  {
    title: 'Resilienz-Workshops für Teams',
    description:
      'Interaktive Formate, die psychologische Sicherheit fördern und Teamdynamik stärken.',
    icon: '🤝'
  },
  {
    title: 'Ganzheitliche Unternehmensprogramme',
    description:
      'Strategische Beratung für nachhaltige Arbeitsmodelle und gesunde Unternehmenskultur.',
    icon: '🏢'
  }
];

const processSteps = [
  {
    title: 'Erstgespräch',
    text: 'Wir hören zu, verstehen Ihre Situation und definieren Ziele, die wirklich zu Ihnen passen.'
  },
  {
    title: 'Strategie-Design',
    text: 'Gemeinsam entwickeln wir einen klaren Plan mit Sofortmaßnahmen und langfristiger Perspektive.'
  },
  {
    title: 'Begleitung',
    text: 'In Coachings, Workshops und Check-ins verankern wir neue Routinen Schritt für Schritt.'
  },
  {
    title: 'Evaluation & Anpassung',
    text: 'Wir messen Fortschritte, feiern Erfolge und justieren, wo es sinnvoll ist.'
  }
];

const testimonials = [
  {
    quote:
      'Taliverenso hat uns gezeigt, wie Teamführung ohne Dauerstress funktioniert. Die Workshops waren praxisnah und haben nachhaltig gewirkt.',
    name: 'Laura Neumann',
    role: 'People & Culture Lead, TechCollective'
  },
  {
    quote:
      'Durch das Coaching habe ich gelernt, Grenzen klar zu kommunizieren und trotzdem Leistung zu bringen. Mein Energielevel ist spürbar höher.',
    name: 'Dr. Markus Feld',
    role: 'Chefarzt, Klinik am Park'
  },
  {
    quote:
      'Wir haben eine neue Meeting-Kultur entwickelt, die Fokus schafft und Überstunden reduziert. Die Begleitung war empathisch und hochprofessionell.',
    name: 'Svenja Krüger',
    role: 'Leitung HR, Kreativagentur Nord'
  }
];

const teamMembers = [
  {
    name: 'Talia Verensen',
    role: 'Gründerin & Systemische Coach',
    focus: 'Ganzheitliche Burnout-Prävention, Mindful Leadership',
    image: 'https://picsum.photos/400/400?random=301'
  },
  {
    name: 'Leon Gruber',
    role: 'Organisationspsychologe',
    focus: 'Teamresilienz, psychologische Sicherheit, Change-Design',
    image: 'https://picsum.photos/400/400?random=302'
  },
  {
    name: 'Mira Fuchs',
    role: 'Achtsamkeitstrainerin',
    focus: 'Somatische Stressregulation, Micro-Breaks im Alltag',
    image: 'https://picsum.photos/400/400?random=303'
  }
];

const projects = [
  {
    title: 'Hybrid Work Resilience',
    category: 'Consulting',
    image: 'https://picsum.photos/1200/800?random=401',
    description: 'Entwicklung eines hybriden Arbeitsmodells mit Fokus auf Erholungsphasen.'
  },
  {
    title: 'Mindful Leadership Lab',
    category: 'Workshops',
    image: 'https://picsum.photos/1200/800?random=402',
    description: 'Leadership-Programm, das Mindfulness in Entscheidungsprozesse integriert.'
  },
  {
    title: 'Healthy Sprints',
    category: 'Coaching',
    image: 'https://picsum.photos/1200/800?random=403',
    description: 'Begleitung eines Produktteams mit stressarmen Sprints und klaren Fokusfenstern.'
  },
  {
    title: 'Recovery Culture Blueprint',
    category: 'Consulting',
    image: 'https://picsum.photos/1200/800?random=404',
    description: 'Unternehmensweite Richtlinien für Pausen, Erreichbarkeit und Erholung.'
  }
];

const faqItems = [
  {
    question: 'Wie läuft das kostenlose Erstgespräch ab?',
    answer:
      'Wir nehmen uns 30 Minuten Zeit, um Ihre Ausgangslage und Erwartungen kennenzulernen. Dabei erhalten Sie bereits erste Impulse und wir skizzieren mögliche nächste Schritte.'
  },
  {
    question: 'Arbeiten Sie auch remote mit Teams außerhalb Berlins?',
    answer:
      'Ja. Wir begleiten Teams deutschlandweit und international – sowohl online als auch in hybriden Settings. Präsenzformate in Berlin und Umgebung sind ebenfalls möglich.'
  },
  {
    question: 'Wie werden individuelle Bedürfnisse berücksichtigt?',
    answer:
      'Wir starten immer mit einer Analyse Ihrer Ressourcen und Stressoren. Daraus entsteht ein Maßnahmenmix, der zu Ihrem Alltag passt und flexibel anpassbar bleibt.'
  },
  {
    question: 'Welche Branchen betreuen Sie?',
    answer:
      'Von Tech-Start-ups über Kliniken bis hin zu Kreativagenturen: Entscheidend ist der Wunsch nach gesunden Arbeitsstrukturen. Unsere Methoden sind branchenübergreifend erprobt.'
  }
];

const blogPosts = [
  {
    title: '5 Mikropausen, die Ihren Arbeitstag leichter machen',
    excerpt:
      'Kurze Atemräume sind das neue Multitasking. Wir zeigen, wie 5-Minuten-Rituale Fokus und Energie zurückbringen.',
    date: '12. März 2024'
  },
  {
    title: 'Psychologische Sicherheit als Burnout-Schutzschild',
    excerpt:
      'Warum Teams mit Vertrauen resilienter sind – und wie Sie den ersten Schritt in Richtung Sicherheit gehen.',
    date: '01. März 2024'
  },
  {
    title: 'Hybrid Work: Grenzen ziehen ohne Schuldgefühl',
    excerpt:
      'Rituale, Kommunikationsvereinbarungen und digitale Detox-Zonen für gesunde Remote-Arbeit.',
    date: '16. Februar 2024'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Alle');
  const [openFaq, setOpenFaq] = useState(null);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Alle') return projects;
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const increment = Math.ceil(stat.target / 80);
      return setInterval(() => {
        setStats((prev) => {
          const updated = [...prev];
          if (updated[index] < stat.target) {
            updated[index] = Math.min(updated[index] + increment, stat.target);
          }
          return updated;
        });
      }, 30);
    });

    const testimonialInterval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => {
      intervals.forEach(clearInterval);
      clearInterval(testimonialInterval);
    };
  }, []);

  const categories = ['Alle', 'Consulting', 'Workshops', 'Coaching'];

  return (
    <>
      <Helmet>
        <title>Taliverenso | Work-Life-Balance & Anti-Burnout Beratung</title>
        <meta
          name="description"
          content="Taliverenso hilft Menschen und Teams in Berlin und darüber hinaus, Burnout zu vermeiden, Stress zu reduzieren und nachhaltige Work-Life-Balance zu etablieren."
        />
      </Helmet>
      <section
        className={styles.hero}
        style={{
          backgroundImage: "url('https://picsum.photos/1600/900?random=101')"
        }}
      >
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <span className={styles.badge}>Work-Life-Balance neu gedacht</span>
          <h1>Finde deine Work-Life-Balance – Strategien gegen Burnout</h1>
          <p>
            Wir begleiten Führungskräfte, Mitarbeitende und Teams dabei, Stress
            in Energie zu verwandeln. Mit klaren Routinen, menschlicher Führung
            und gesunden Rahmenbedingungen.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.primaryBtn}>
              Kostenloses Erstgespräch
            </Link>
            <Link to="/leistungen" className={styles.secondaryBtn}>
              Unsere Ansätze entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statNumber}>{stats[index]}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.twoColumn}>
          <div>
            <h2>Taliverenso – Ihr Partner für nachhaltige Arbeitsbalance</h2>
            <p>
              Wir glauben an Arbeitswelten, in denen Leistung und Lebensfreude
              miteinander wachsen. Unsere systemische Expertise vereint
              Psychologie, Organisationsentwicklung und achtsame Praxis.
            </p>
            <ul className={styles.list}>
              <li>Individuelle Roadmaps statt Standardlösungen</li>
              <li>Vertrauensvolle Begleitung auf Augenhöhe</li>
              <li>Messbare Ergebnisse für Menschen und Unternehmen</li>
            </ul>
            <Link to="/ueber-uns" className={styles.linkBtn}>
              Mehr über uns
            </Link>
          </div>
          <div className={styles.imageCard}>
            <img
              src="https://picsum.photos/800/600?random=202"
              alt="Team in einem entspannten Workshop zur Burnout-Prävention"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <h2>Unsere Anti-Burnout-Ansätze</h2>
          <p>
            Vom persönlichen Coaching über Team-Resilienz bis hin zu
            Organisationsberatung – wir schaffen Lösungen, die wirken.
          </p>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <div key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon}>{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/leistungen">Mehr erfahren →</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.highlight}`}>
        <div className="container">
          <h2>Warum Work-Life-Balance wichtig ist</h2>
          <div className={styles.benefits}>
            <div>
              <h3>Gesunde Menschen, gesunde Unternehmen</h3>
              <p>
                Wer regenerieren kann, bleibt neugierig, kreativ und resilient.
                Wir gestalten Rahmenbedingungen, die Menschen stärken und
                Fluktuation reduzieren.
              </p>
            </div>
            <div>
              <h3>Produktivität ohne Dauerstress</h3>
              <p>
                Balance heißt nicht weniger Leistung – sondern fokussierter
                Einsatz. Mit klaren Prioritäten, Erholung und wirksamen
                Routinen.
              </p>
            </div>
            <div>
              <h3>Langfristige Zufriedenheit</h3>
              <p>
                Nachhaltige Work-Life-Balance schafft Bindung, Motivation und
                eine Kultur des echten Miteinanders.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section}`}>
        <div className="container">
          <div className={styles.twoColumn}>
            <div>
              <h2>Unser Beratungsansatz</h2>
              <p>
                Klar strukturiert und gleichzeitig flexibel: Unser Prozess führt
                Sie Schritt für Schritt zu einer gesunden Balance – ohne
                Druck, aber mit konsequenter Umsetzung.
              </p>
            </div>
            <div className={styles.processTimeline}>
              {processSteps.map((step, index) => (
                <div key={step.title} className={styles.processStep}>
                  <span className={styles.stepNumber}>{index + 1}</span>
                  <div>
                    <h3>{step.title}</h3>
                    <p>{step.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonials}`}>
        <div className="container">
          <h2>Erfolgsgeschichten</h2>
          <div className={styles.testimonialSlider}>
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === currentTestimonial ? styles.activeSlide : ''
                }`}
              >
                <p>“{testimonial.quote}”</p>
                <div>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </div>
            ))}
          </div>
          <div className={styles.sliderDots}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={index === currentTestimonial ? styles.dotActive : ''}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <h2>Team Taliverenso</h2>
        <p className={styles.sectionIntro}>
          Interdisziplinär, empathisch und praxisnah – wir vereinen Erfahrung
          aus Coaching, Psychologie und Achtsamkeit.
        </p>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <div key={member.name} className={styles.teamCard}>
              <img
                src={member.image}
                alt={`Teammitglied ${member.name}`}
                loading="lazy"
              />
              <div className={styles.teamOverlay}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.focus}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.projectsSection}`}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2>Projekte & Programme</h2>
            <div className={styles.filters}>
              {categories.map((category) => (
                <button
                  key={category}
                  className={
                    activeCategory === category ? styles.filterActive : ''
                  }
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={`Projekt ${project.title}`}
                  loading="lazy"
                />
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.faq}>
          <h2>FAQ – Häufige Fragen</h2>
          <div className={styles.accordion}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.accordionItem}>
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className={styles.accordionHeader}
                >
                  <span>{item.question}</span>
                  <span>{openFaq === index ? '−' : '+'}</span>
                </button>
                {openFaq === index && (
                  <div className={styles.accordionBody}>
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.blogSection}`}>
        <div className="container">
          <div className={styles.blogHeader}>
            <div>
              <h2>Aktuelle Insights aus dem Taliverenso Blog</h2>
              <p>
                Inspiration und Wissen für gesunde Arbeitswelten – kompakt,
                umsetzbar und menschlich.
              </p>
            </div>
            <Link to="/blog" className={styles.linkBtn}>
              Zum Blog
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/blog">Weiterlesen →</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.finalCta}`}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Bereit, Arbeit und Leben in Einklang zu bringen?</h2>
            <p>
              Lassen Sie uns in einem unverbindlichen Gespräch schauen, wie wir
              Sie oder Ihr Team stärken können. Wir freuen uns auf Sie!
            </p>
            <Link to="/kontakt" className={styles.primaryBtn}>
              Kostenloses Erstgespräch vereinbaren
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;