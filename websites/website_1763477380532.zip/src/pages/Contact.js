import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Bitte Ihren Namen angeben.';
    if (!form.email.trim()) {
      newErrors.email = 'Bitte Ihre E-Mail-Adresse angeben.';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'Bitte eine gültige E-Mail-Adresse eingeben.';
    }
    if (!form.message.trim()) newErrors.message = 'Bitte teilen Sie Ihr Anliegen mit.';
    return newErrors;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setForm(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Taliverenso Berlin</title>
        <meta
          name="description"
          content="Nehmen Sie Kontakt mit Taliverenso auf – wir freuen uns auf ein unverbindliches Erstgespräch zu Anti-Burnout und Work-Life-Balance."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Sprechen wir über gesunde Arbeit</h1>
          <p>
            Ob individuelles Coaching, Team-Workshop oder Organisationsberatung:
            Wir sind gespannt auf Ihre Herausforderungen und Ideen.
          </p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.layout}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <h2>Nachricht senden</h2>
            <p>Wir melden uns in der Regel innerhalb von 24 Stunden zurück.</p>
            <label>
              Name*
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                aria-invalid={!!errors.name}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </label>
            <label>
              E-Mail*
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                aria-invalid={!!errors.email}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </label>
            <label>
              Unternehmen (optional)
              <input
                type="text"
                name="company"
                value={form.company}
                onChange={handleChange}
              />
            </label>
            <label>
              Nachricht*
              <textarea
                name="message"
                rows="5"
                value={form.message}
                onChange={handleChange}
                aria-invalid={!!errors.message}
              />
              {errors.message && (
                <span className={styles.error}>{errors.message}</span>
              )}
            </label>
            <button type="submit">Nachricht abschicken</button>
            {submitted && (
              <div className={styles.success}>
                Vielen Dank! Ihre Nachricht ist bei uns eingegangen.
              </div>
            )}
          </form>

          <div className={styles.details}>
            <div className={styles.card}>
              <h3>Kontakt</h3>
              <p>Musterstraße 123<br />10115 Berlin</p>
              <p>Telefon: +49 30 12345678</p>
              <p>E-Mail: info@taliverenso.site</p>
            </div>
            <div className={styles.card}>
              <h3>Erreichbarkeit</h3>
              <p>Montag – Freitag: 9:00 – 18:00 Uhr</p>
              <p>Termine nach Vereinbarung, online oder vor Ort.</p>
            </div>
            <div className={styles.map}>
              <img
                src="https://picsum.photos/900/600?random=701"
                alt="Bürostandort Taliverenso Berlin"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;