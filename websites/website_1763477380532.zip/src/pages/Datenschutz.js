import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Datenschutz = () => (
  <>
    <Helmet>
      <title>Datenschutzerklärung | Taliverenso</title>
      <meta name="description" content="Datenschutzerklärung der Taliverenso Work-Life-Balance Beratung." />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <div className={styles.block}>
          <h2>1. Datenschutz auf einen Blick</h2>
          <p>
            Der Schutz Ihrer persönlichen Daten ist uns wichtig. Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend den gesetzlichen Datenschutzvorschriften.
          </p>
        </div>
        <div className={styles.block}>
          <h2>2. Verantwortliche Stelle</h2>
          <p>
            Taliverenso<br />
            Musterstraße 123, 10115 Berlin<br />
            E-Mail: info@taliverenso.site
          </p>
        </div>
        <div className={styles.block}>
          <h2>3. Datenerfassung auf unserer Website</h2>
          <p>
            Personenbezogene Daten werden nur erhoben, wenn Sie uns diese freiwillig mitteilen, z. B. über das Kontaktformular.
            Die Verarbeitung erfolgt zur Bearbeitung Ihres Anliegens (Art. 6 Abs. 1 lit. b DSGVO).
          </p>
        </div>
        <div className={styles.block}>
          <h2>4. Cookies</h2>
          <p>
            Unsere Website verwendet Cookies, um die Nutzerfreundlichkeit zu erhöhen. Sie können die Speicherung von Cookies in den Einstellungen Ihres Browsers deaktivieren.
          </p>
        </div>
        <div className={styles.block}>
          <h2>5. Analyse-Tools</h2>
          <p>
            Wir verzichten auf den Einsatz externer Tracking- und Analyse-Tools. Sämtliche Logfiles werden ausschließlich zur technischen Fehleranalyse genutzt und regelmäßig gelöscht.
          </p>
        </div>
        <div className={styles.block}>
          <h2>6. Ihre Rechte</h2>
          <p>
            Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Kontaktieren Sie uns dazu jederzeit.
          </p>
        </div>
        <div className={styles.block}>
          <h2>7. Datensicherheit</h2>
          <p>
            Wir setzen technische und organisatorische Maßnahmen ein, um Ihre Daten gegen zufällige oder vorsätzliche Manipulation zu schützen.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Datenschutz;