import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>Über Taliverenso | Unsere Mission für gesunde Arbeit</title>
      <meta
        name="description"
        content="Taliverenso steht für eine Arbeitswelt ohne Burnout. Lernen Sie unser Team, unsere Werte und unsere Haltung für nachhaltige Work-Life-Balance kennen."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Taliverenso – Wir gestalten gesunde Arbeitsrealitäten</h1>
        <p>
          Unsere Vision ist eine Arbeitskultur, in der Menschen sich entfalten
          können, ohne ihre Energie zu verlieren. Wir begleiten Unternehmen und
          Einzelpersonen auf dem Weg zu nachhaltiger Balance.
        </p>
      </div>
    </section>

    <section className={`${styles.section} container`}>
      <div className={styles.grid}>
        <div>
          <h2>Unsere Haltung</h2>
          <p>
            Arbeit soll Sinn stiften und gleichzeitig Raum für Regeneration
            lassen. Deshalb kombinieren wir systemisches Coaching, moderne
            Organisationsentwicklung und Achtsamkeitstraining. Wir arbeiten
            datenbasiert, empathisch und konsequent lösungsorientiert.
          </p>
        </div>
        <div className={styles.card}>
          <h3>Was uns antreibt</h3>
          <ul>
            <li>Partnerschaftliche Zusammenarbeit auf Augenhöhe</li>
            <li>Messbare Ergebnisse und nachhaltige Veränderungen</li>
            <li>Mut zu neuen Arbeitsmodellen und gesunden Grenzen</li>
          </ul>
        </div>
      </div>
    </section>

    <section className={`${styles.section} ${styles.timelineSection}`}>
      <div className="container">
        <h2>Meilensteine</h2>
        <div className={styles.timeline}>
          <div>
            <span>2018</span>
            <p>
              Gründung von Taliverenso als Coaching-Studio für Work-Life-Balance
            </p>
          </div>
          <div>
            <span>2020</span>
            <p>Ausbau um Team- und Leadership-Programme für skalierende Start-ups</p>
          </div>
          <div>
            <span>2022</span>
            <p>Integration psychologischer Sicherheit und hybrider Arbeitsmodelle</p>
          </div>
          <div>
            <span>2024</span>
            <p>
              Aufbau eines interdisziplinären Netzwerks für deutschlandweite
              Stresspräventionsprojekte
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={`${styles.section} container`}>
      <h2>Unser Kernteam</h2>
      <p className={styles.intro}>
        Unterschiedliche Perspektiven, ein gemeinsames Ziel: gesunde Menschen,
        starke Organisationen.
      </p>
      <div className={styles.teamGrid}>
        <article className={styles.teamCard}>
          <img
            src="https://picsum.photos/420/420?random=501"
            alt="Taliverenso Gründerin Talia Verensen"
            loading="lazy"
          />
          <div>
            <h3>Talia Verensen</h3>
            <span>Gründerin & Systemische Coach</span>
            <p>
              Verbindet achtsamkeitsbasierte Stressregulation mit modernen
              Leadership-Konzepten. Liebt klare Strukturen und tiefe Gespräche.
            </p>
          </div>
        </article>
        <article className={styles.teamCard}>
          <img
            src="https://picsum.photos/420/420?random=502"
            alt="Organisationspsychologe Leon Gruber"
            loading="lazy"
          />
          <div>
            <h3>Leon Gruber</h3>
            <span>Organisationspsychologe</span>
            <p>
              Entwickelt evidenzbasierte Programme für Teamresilienz und
              psychologische Sicherheit. Fan von transparenten Kommunikationsritualen.
            </p>
          </div>
        </article>
        <article className={styles.teamCard}>
          <img
            src="https://picsum.photos/420/420?random=503"
            alt="Achtsamkeitstrainerin Mira Fuchs"
            loading="lazy"
          />
          <div>
            <h3>Mira Fuchs</h3>
            <span>Achtsamkeitstrainerin</span>
            <p>
              Spezialisiert auf somatische Ansätze, Embodiment und Micro-Breaks
              im Arbeitsalltag. Bringt Leichtigkeit in jede Session.
            </p>
          </div>
        </article>
      </div>
    </section>

    <section className={`${styles.section} ${styles.values}`}>
      <div className="container">
        <h2>Was Zusammenarbeit mit uns bedeutet</h2>
        <div className={styles.valuesGrid}>
          <div>
            <h3>Co-Kreation</h3>
            <p>
              Wir entwickeln Lösungen gemeinsam mit Ihnen – maßgeschneidert und
              realistisch umsetzbar.
            </p>
          </div>
          <div>
            <h3>Transparenz</h3>
            <p>
              Klare Kommunikation, regelmäßiges Feedback und sichtbare Fortschritte.
            </p>
          </div>
          <div>
            <h3>Wertschätzung</h3>
            <p>
              Wir schaffen Räume, in denen Menschen sich zeigen können und
              ernstgenommen werden.
            </p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;