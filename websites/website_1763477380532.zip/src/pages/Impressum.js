import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum | Taliverenso</title>
      <meta name="description" content="Impressum der Taliverenso Work-Life-Balance Beratung in Berlin." />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Impressum</h1>
        <p>Angaben gemäß § 5 TMG</p>
        <div className={styles.block}>
          <p>
            Taliverenso<br />
            Musterstraße 123<br />
            10115 Berlin<br />
            Deutschland
          </p>
          <p>
            Telefon: +49 30 12345678<br />
            E-Mail: info@taliverenso.site
          </p>
        </div>
        <div className={styles.block}>
          <h2>Vertreten durch</h2>
          <p>Talia Verensen</p>
        </div>
        <div className={styles.block}>
          <h2>Umsatzsteuer-ID</h2>
          <p>USt-IdNr.: DE123456789</p>
        </div>
        <div className={styles.block}>
          <h2>Berufshaftpflichtversicherung</h2>
          <p>
            Allianz Versicherung AG<br />
            Königinstraße 28<br />
            80802 München
          </p>
        </div>
        <div className={styles.block}>
          <h2>Haftung für Inhalte</h2>
          <p>
            Als Diensteanbieter sind wir für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich.
            Wir übernehmen keine Haftung für die Richtigkeit, Vollständigkeit und Aktualität der bereitgestellten Informationen.
          </p>
        </div>
        <div className={styles.block}>
          <h2>Haftung für Links</h2>
          <p>
            Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb übernehmen wir
            für diese fremden Inhalte keine Gewähr. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter verantwortlich.
          </p>
        </div>
        <div className={styles.block}>
          <h2>Urheberrecht</h2>
          <p>
            Die durch die Seitenbetreiber erstellten Inhalte und Werke unterliegen dem deutschen Urheberrecht. Downloads und Kopien dieser Seite
            sind nur für den privaten, nicht kommerziellen Gebrauch gestattet.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Impressum;