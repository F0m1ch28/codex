import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie | Taliverenso</title>
      <meta name="description" content="Cookie-Richtlinie von Taliverenso." />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Cookie-Richtlinie</h1>
        <div className={styles.block}>
          <h2>Was sind Cookies?</h2>
          <p>
            Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden. Sie unterstützen die nutzerfreundliche Bereitstellung unserer Inhalte.
          </p>
        </div>
        <div className={styles.block}>
          <h2>Verwendete Cookies</h2>
          <ul>
            <li>
              <strong>Essentielle Cookies:</strong> notwendig für die Grundfunktionen der Website (z. B. Cookie-Banner).
            </li>
            <li>
              <strong>Statistik-Cookies:</strong> werden derzeit nicht eingesetzt.
            </li>
          </ul>
        </div>
        <div className={styles.block}>
          <h2>Cookie-Einstellungen</h2>
          <p>
            Sie können Ihre Cookie-Präferenzen in Ihrem Browser anpassen oder die gespeicherten Cookies löschen. Bei der Deaktivierung kann die Funktionalität der Website eingeschränkt sein.
          </p>
        </div>
        <div className={styles.block}>
          <h2>Speicherdauer</h2>
          <p>
            Cookies werden entweder nach Ende der Sitzung automatisch gelöscht oder verbleiben als permanente Cookies bis zum Ablauf ihrer Lebensdauer.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicy;