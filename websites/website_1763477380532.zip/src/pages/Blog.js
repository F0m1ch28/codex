import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Die vier Phasen der Erholung im Arbeitsalltag',
    date: '28. Februar 2024',
    excerpt:
      'Von Mikro-Pausen bis Deep Rest: Wie Erholungsphasen geplant werden können, ohne den Flow zu verlieren.',
    category: 'Work-Life-Balance'
  },
  {
    title: 'Psychologische Sicherheit: 7 Fragen für Ihr Team',
    date: '19. Februar 2024',
    excerpt:
      'Mit diesen Fragen spüren Sie auf, wie sicher sich Ihr Team fühlt – und wo Potenzial für mehr Vertrauen liegt.',
    category: 'Teamresilienz'
  },
  {
    title: 'Burnout-Prävention für Führungskräfte',
    date: '5. Februar 2024',
    excerpt:
      'Selbstführung beginnt mit Klarheit. Konkrete Methoden, wie Führungskräfte ihre Energiebilanz im Blick behalten.',
    category: 'Leadership'
  },
  {
    title: 'Digital Detox: Rituale für hybride Teams',
    date: '22. Januar 2024',
    excerpt:
      'Slack, Zoom und Co. – so definieren Teams gesunde digitale Grenzen, ohne die Zusammenarbeit zu bremsen.',
    category: 'Hybrid Work'
  }
];

const Blog = () => (
  <>
    <Helmet>
      <title>Blog | Taliverenso Insights</title>
      <meta
        name="description"
        content="Artikel, Impulse und Best Practices rund um Stressprävention, Burnout-Prophylaxe und Work-Life-Balance."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Taliverenso Blog</h1>
        <p>
          Inspiration, Tools und menschliche Geschichten über gelingende
          Arbeitswelten. Für alle, die Stress als Chance für Entwicklung sehen.
        </p>
      </div>
    </section>

    <section className={`${styles.section} container`}>
      <div className={styles.grid}>
        {posts.map((post) => (
          <article key={post.title} className={styles.card}>
            <span className={styles.category}>{post.category}</span>
            <h2>{post.title}</h2>
            <span className={styles.date}>{post.date}</span>
            <p>{post.excerpt}</p>
            <a href="#!" className={styles.readMore}>
              Weiterlesen (bald verfügbar)
            </a>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;