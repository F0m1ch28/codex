import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutzerklärung | GreenTech Solutions</title>
      <meta
        name="description"
        content="Datenschutzerklärung von GreenTech Solutions. Informationen zur Verarbeitung personenbezogener Daten."
      />
      <link rel="canonical" href="https://www.greentech-solutions.de/datenschutz" />
    </Helmet>

    <section className={styles.wrapper}>
      <div className="container">
        <div className={styles.header}>
          <h1>Datenschutzerklärung</h1>
          <p>
            Wir nehmen den Schutz Ihrer personenbezogenen Daten sehr ernst. Nachfolgend informieren wir Sie über Art,
            Umfang und Zwecke der Erhebung und Verwendung.
          </p>
        </div>

        <article className={styles.section}>
          <h2>1. Verantwortlicher</h2>
          <p>
            GreenTech Solutions, Musterstraße 123, 80331 München, Deutschland. Bei Fragen wenden Sie sich bitte an{' '}
            <a href="mailto:datenschutz@greentech-solutions.de">datenschutz@greentech-solutions.de</a>.
          </p>
        </article>

        <article className={styles.section}>
          <h2>2. Erhebung und Verarbeitung</h2>
          <p>
            Wir verarbeiten personenbezogene Daten, wenn Sie unser Kontaktformular nutzen, sich für unseren Newsletter
            anmelden oder uns telefonisch beziehungsweise per E-Mail kontaktieren. Dazu zählen Name, Kontaktdaten und
            projektbezogene Informationen.
          </p>
        </article>

        <article className={styles.section}>
          <h2>3. Zweck der Verarbeitung</h2>
          <ul>
            <li>Bearbeitung Ihrer Anfragen und Vorbereitung von Angeboten</li>
            <li>Durchführung vertraglicher Leistungen</li>
            <li>Optimierung unseres Online-Angebots und statistische Auswertungen</li>
            <li>Erfüllung gesetzlicher Dokumentationspflichten</li>
          </ul>
        </article>

        <article className={styles.section}>
          <h2>4. Rechtsgrundlagen</h2>
          <p>
            Die Verarbeitung erfolgt auf Basis von Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung), Art. 6 Abs. 1 lit. a
            DSGVO (Einwilligung) sowie Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an der Verbesserung unseres
            Angebots).
          </p>
        </article>

        <article className={styles.section}>
          <h2>5. Weitergabe an Dritte</h2>
          <p>
            Eine Weitergabe an Dritte erfolgt nur, wenn dies zur Vertragserfüllung erforderlich ist (z. B. an
            Montagepartner) oder wenn gesetzliche Verpflichtungen bestehen. Wir schließen mit Dienstleistern
            Auftragsverarbeitungsverträge gemäß Art. 28 DSGVO.
          </p>
        </article>

        <article className={styles.section}>
          <h2>6. Cookies & Tracking</h2>
          <p>
            Wir setzen essenzielle Cookies ein, um die Funktionalität der Website sicherzustellen. Analytische Cookies
            verwenden wir nur nach Ihrer Einwilligung. Details entnehmen Sie bitte unserer Cookie-Richtlinie.
          </p>
        </article>

        <article className={styles.section}>
          <h2>7. Betroffenenrechte</h2>
          <ul>
            <li>Auskunft, Berichtigung, Löschung (Art. 15–17 DSGVO)</li>
            <li>Einschränkung der Verarbeitung und Datenübertragbarkeit (Art. 18–20 DSGVO)</li>
            <li>Widerspruch gegen Verarbeitung (Art. 21 DSGVO)</li>
            <li>Beschwerderecht bei einer Aufsichtsbehörde</li>
          </ul>
          <p>
            Zur Ausübung Ihrer Rechte schreiben Sie bitte an{' '}
            <a href="mailto:datenschutz@greentech-solutions.de">datenschutz@greentech-solutions.de</a>.
          </p>
        </article>

        <article className={styles.section}>
          <h2>8. Speicherdauer</h2>
          <p>
            Wir speichern Ihre Daten nur so lange, wie es für die jeweiligen Zwecke notwendig ist oder gesetzliche
            Aufbewahrungsfristen bestehen. Danach werden die Daten gelöscht oder anonymisiert.
          </p>
        </article>

        <div className={styles.notice}>
          <p>Stand: März 2024. Aktualisierungen dieser Erklärung werden an dieser Stelle veröffentlicht.</p>
        </div>
      </div>
    </section>
  </>
);

export default Privacy;