import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const technologies = [
  {
    title: 'Sensores de Distribución',
    description:
      'Sensórica adaptativa con comunicaciones LoRaWAN, 5G y fibra que captura variables eléctricas y ambientales con resolución de segundos.',
    image: 'https://images.unsplash.com/photo-1555679421-558f5c062d5f?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Medidores Inteligentes AMI',
    description:
      'Sistemas AMI interoperables que permiten telegestión, balance neto y sincronización con plataformas de facturación energética.',
    image: 'https://images.unsplash.com/photo-1541532713592-79a0317b6b77?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Microrredes Autónomas',
    description:
      'Diseño de microrredes con capacidad de isla automática, integrando almacenamiento, renovables y cargas críticas en campus y barrios.',
    image: 'https://images.unsplash.com/photo-1465406325904-6c85234b6d57?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'DERMS',
    description:
      'Distributed Energy Resource Management System con algoritmos de optimización para coordinar activos distribuidos y minimizar congestiones.',
    image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Mercado P2P Local',
    description:
      'Habilitamos intercambios energéticos entre prosumidores y comunidades mediante smart contracts regulados y trazabilidad certificada.',
    image: 'https://images.unsplash.com/photo-1482192597420-4817fdd7e8b0?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Edge Computing',
    description:
      'Pasarelas edge que ejecutan análisis, reglas de protección y limpieza de datos al borde, reduciendo latencias críticas.',
    image: 'https://images.unsplash.com/photo-1580894908373-6990f22381f0?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Dashboard Analítico',
    description:
      'Capas visuales multiusuario con indicadores de flexibilidad, fiabilidad y planificación. Integración con SCADA y GIS.',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1000&q=80'
  }
];

const Technologies = () => {
  usePageMeta({
    title: 'Tecnologías & IoT | RedInteligente España',
    description:
      'Descubre las tecnologías de smart grid e IoT energético de RedInteligente España: sensores, AMI, microrredes, DERMS y analítica avanzada.',
    keywords:
      'sensores de distribución, medidores inteligentes AMI, microrredes autónomas, DERMS, P2P local, edge computing, dashboard analítico',
    canonical: 'https://www.redinteligente.com/tecnologias-smart-grid'
  });

  return (
    <div className="page">
      <section
        className="page-hero"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(12,30,59,0.92) 0%, rgba(12,30,59,0.55) 100%), url('https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1400&q=80')"
        }}
      >
        <div className="page-hero-content">
          <p className="hero-kicker">Tecnologías &amp; IoT</p>
          <h1>Capas tecnológicas para redes eléctricas inteligentes y colaborativas</h1>
          <p>
            Integramos hardware, software y modelos de datos para conectar nodos energéticos,
            detectar eventos críticos y habilitar decisiones basadas en analítica avanzada.
          </p>
        </div>
      </section>

      <section className="section technology-section">
        <div className="tech-grid">
          {technologies.map((item) => (
            <article key={item.title} className="tech-card">
              <div className="tech-image">
                <img src={item.image} alt={item.title} loading="lazy" />
              </div>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="two-columns">
          <div>
            <h2>Integración sin fisuras</h2>
            <p>
              Trabajamos con un framework de APIs y adaptadores que permite sumar nuevos
              dispositivos sin interrupciones. La plataforma traduce protocolos y armoniza
              modelos de datos para que cada activo se incorpore con trazabilidad completa.
            </p>
          </div>
          <div>
            <h2>Laboratorio de interoperabilidad</h2>
            <p>
              Disponemos de entornos de laboratorio donde validamos equipamiento de diferentes
              fabricantes bajo escenarios reales. Probamos ciberseguridad, latencia y fiabilidad
              antes de desplegar en campo.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Technologies;