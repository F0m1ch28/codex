import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Collaborate = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    organizacion: '',
    proyecto: '',
    mensaje: ''
  });
  const [feedback, setFeedback] = useState('');

  usePageMeta({
    title: 'Únete al Ecosistema | RedInteligente España',
    description:
      'Contacta con RedInteligente España para explorar colaboración en proyectos de smart grids, IoT energético y microrredes.',
    keywords:
      'colaboración smart grid, contacto red inteligente, proyectos microrredes, IoT energético colaboración',
    canonical: 'https://www.redinteligente.com/colabora'
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.nombre || !formData.organizacion || !formData.mensaje) {
      setFeedback('Por favor, completa los campos obligatorios marcados con *.');
      return;
    }
    setFeedback('Gracias. Revisaremos tu propuesta y contactaremos contigo a través del teléfono facilitado.');
    setFormData({
      nombre: '',
      organizacion: '',
      proyecto: '',
      mensaje: ''
    });
  };

  return (
    <div className="page">
      <section
        className="page-hero"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(12,30,59,0.92) 0%, rgba(12,30,59,0.6) 100%), url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1400&q=80')"
        }}
      >
        <div className="page-hero-content">
          <p className="hero-kicker">Únete al Ecosistema</p>
          <h1>Construyamos juntos redes inteligentes más humanas y conectadas</h1>
          <p>
            Municipios, empresas, universidades y ciudadanía encuentran en RedInteligente
            España un espacio para impulsar proyectos energéticos avanzados.
          </p>
        </div>
      </section>

      <section className="section collaborate-section">
        <div className="collaborate-grid">
          <div className="collaborate-form">
            <h2>Comparte tu iniciativa</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="nombre">Nombre y apellidos *</label>
                <input
                  type="text"
                  id="nombre"
                  name="nombre"
                  value={formData.nombre}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="organizacion">Organización *</label>
                <input
                  type="text"
                  id="organizacion"
                  name="organizacion"
                  value={formData.organizacion}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="proyecto">Tipo de proyecto</label>
                <input
                  type="text"
                  id="proyecto"
                  name="proyecto"
                  value={formData.proyecto}
                  onChange={handleChange}
                  placeholder="Microrred urbana, AMI, V2G..."
                />
              </div>
              <div className="form-group">
                <label htmlFor="mensaje">Mensaje *</label>
                <textarea
                  id="mensaje"
                  name="mensaje"
                  rows="4"
                  value={formData.mensaje}
                  onChange={handleChange}
                  required
                />
              </div>
              <button type="submit" className="btn-primary">
                Enviar propuesta
              </button>
            </form>
            {feedback && <p className="form-feedback">{feedback}</p>}
          </div>

          <div className="collaborate-info">
            <h2>Contacto directo</h2>
            <p>
              <strong>Dirección:</strong> Paseo de la Castellana 141, 28046 Madrid
            </p>
            <p>
              <strong>Teléfono:</strong>{' '}
              <a href="tel:+34917893456">+34 917 89 34 56</a>
            </p>
            <p>
              El hub físico integra laboratorio IoT, sala de control y espacio de cocreación
              donde impulsamos pilotos y formaciones técnicas.
            </p>
            <div className="map-container" role="region" aria-label="Mapa de la sede RedInteligente España">
              <iframe
                title="Ubicación RedInteligente España"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3037.590147875955!2d-3.690215323321962!3d40.470573754910966!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd42291d9c8e9e95%3A0xc5d64700c29b0d4d!2sP.%20de%20la%20Castellana%2C%20141%2C%2028046%20Madrid!5e0!3m2!1ses!2ses!4v1715758293720!5m2!1ses!2ses"
                loading="lazy"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Collaborate;