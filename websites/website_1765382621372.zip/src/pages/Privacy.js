import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Privacy = () => {
  usePageMeta({
    title: 'Política de Privacidad | RedInteligente España',
    description:
      'Política de privacidad y tratamiento de datos personales de RedInteligente España, conforme al RGPD.',
    keywords:
      'política de privacidad, RGPD, protección de datos, RedInteligente España',
    canonical: 'https://www.redinteligente.com/privacidad'
  });

  return (
    <div className="page page-legal">
      <h1>Política de Privacidad</h1>
      <p>Última actualización: 15 de mayo de 2024</p>

      <h2>1. Responsable del tratamiento</h2>
      <p>
        RedInteligente España, Paseo de la Castellana 141, 28046 Madrid. Teléfono: +34 917 89 34 56.
      </p>

      <h2>2. Datos tratados</h2>
      <p>
        Tratamos datos identificativos (nombre, apellidos, organización), datos de contacto y la información
        que nos facilites en formularios o interacciones con la plataforma.
      </p>

      <h2>3. Finalidad</h2>
      <p>
        Los datos se emplean para gestionar solicitudes de información, colaborar en proyectos energéticos,
        enviar comunicaciones técnicas y mejorar la experiencia de navegación mediante analítica de uso.
      </p>

      <h2>4. Base legitimadora</h2>
      <p>
        El tratamiento se fundamenta en tu consentimiento expreso, así como en el interés legítimo de RedInteligente
        España para mantener y mejorar la plataforma.
      </p>

      <h2>5. Conservación</h2>
      <p>
        Los datos se conservarán mientras se mantenga la relación y, posteriormente, durante los plazos legales
        aplicables o hasta que solicites su supresión.
      </p>

      <h2>6. Destinatarios</h2>
      <p>
        No se ceden datos a terceros salvo obligación legal o cuando sea necesario para prestar un servicio contratado,
        en cuyo caso se firmarán los acuerdos de tratamiento correspondientes.
      </p>

      <h2>7. Derechos</h2>
      <p>
        Puedes ejercer tus derechos de acceso, rectificación, supresión, limitación, oposición y portabilidad enviando
        una solicitud al responsable del tratamiento. También puedes dirigir reclamaciones ante la Agencia Española
        de Protección de Datos.
      </p>

      <h2>8. Seguridad</h2>
      <p>
        Implementamos medidas técnicas y organizativas orientadas a preservar la confidencialidad, integridad y
        disponibilidad de la información tratada.
      </p>
    </div>
  );
};

export default Privacy;