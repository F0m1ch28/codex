import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const projectBlocks = [
  {
    title: 'Microrred Barcelona',
    subtitle: 'Red resiliente en distrito 22@',
    description:
      'Microrred híbrida con generación solar, almacenamiento y controladores de media tensión. Permite operación en modo isla y coordinación con redes vecinas mediante protocolos IEC 61850.',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1100&q=80'
  },
  {
    title: 'Smart Metering Sevilla',
    subtitle: 'Telegestión para hogares y pymes',
    description:
      'Desplegamos medidores AMI con capacidad de lectura remota y comandos programables. La plataforma detecta fraudes, anomalías y geolocaliza eventos en segundos.',
    image: 'https://images.unsplash.com/photo-1517433456452-f9633a875f6f?auto=format&fit=crop&w=1100&q=80'
  },
  {
    title: 'Demanda Valencia',
    subtitle: 'Plataforma de flexibilidad urbana',
    description:
      'Agregamos edificios públicos y comercios para proporcionar capacidad de respuesta a la demanda. Algoritmos predictivos anticipan picos y envían señales coordinadas.',
    image: 'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1100&q=80'
  },
  {
    title: 'V2G Madrid',
    subtitle: 'Movilidad eléctrica bidireccional',
    description:
      'El piloto V2G conecta flotas corporativas con estaciones inteligentes capaces de devolver energía a la red durante horas punta, manteniendo la disponibilidad operativa de los vehículos.',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1100&q=80'
  },
  {
    title: 'IA Bilbao',
    subtitle: 'Gemelos digitales para campus',
    description:
      'Creamos modelos digitales de edificios y redes internas para predecir demanda, planificar mantenimiento y activar almacenamiento según condiciones ambientales.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1100&q=80'
  }
];

const Projects = () => {
  usePageMeta({
    title: 'Pilotos & Despliegues | RedInteligente España',
    description:
      'Explora los proyectos piloto de RedInteligente España: microrredes Barcelona, smart metering Sevilla, demanda Valencia, V2G Madrid e IA Bilbao.',
    keywords:
      'microrred Barcelona, smart metering Sevilla, demanda Valencia, V2G Madrid, IA Bilbao, proyectos piloto smart grid',
    canonical: 'https://www.redinteligente.com/proyectos-piloto'
  });

  return (
    <div className="page">
      <section
        className="page-hero"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(12,30,59,0.92) 0%, rgba(12,30,59,0.6) 100%), url('https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1400&q=80')"
        }}
      >
        <div className="page-hero-content">
          <p className="hero-kicker">Pilotos &amp; Despliegues</p>
          <h1>Laboratorios vivos que anticipan la red eléctrica del mañana</h1>
          <p>
            Nuestros proyectos piloto conectan ciudades, campus y puertos con soluciones
            inteligentes que muestran el potencial de una infraestructura coordinada.
          </p>
        </div>
      </section>

      <section className="section project-section">
        <div className="project-grid">
          {projectBlocks.map((project) => (
            <article key={project.title} className="project-card">
              <div className="project-image">
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className="project-content">
                <h3>{project.title}</h3>
                <span>{project.subtitle}</span>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section background-light">
        <div className="two-columns">
          <div>
            <h2>Archivo Técnico</h2>
            <p>
              Documentamos cada piloto con memorias técnicas, diagramas unifilares, flujos de datos,
              indicadores de resiliencia y aprendizajes para futuras réplicas.
            </p>
          </div>
          <div>
            <h2>Mapa Interactivo</h2>
            <p>
              El mapa dinámico de la plataforma muestra KPIs en directo, alarmas contextualizadas
              y la evolución temporal de los principales proyectos en España.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;