import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import blogPosts from '../data/blogPosts';

const statsConfig = [
  { label: 'Microrredes urbanas monitorizadas', target: 128, suffix: '+' },
  { label: 'Sensores IoT integrados', target: 4800, suffix: '' },
  { label: 'Respuestas a la demanda coordinadas al año', target: 920, suffix: '' },
  { label: 'Casos de interoperabilidad IEC 61850', target: 36, suffix: '+' }
];

const mapNodes = [
  { name: 'Madrid', top: '42%', left: '48%', status: 'Operativa' },
  { name: 'Barcelona', top: '30%', left: '62%', status: 'En expansión' },
  { name: 'Bilbao', top: '32%', left: '40%', status: 'Analítica IA' },
  { name: 'Sevilla', top: '58%', left: '45%', status: 'Smart Metering' },
  { name: 'Valencia', top: '44%', left: '58%', status: 'Flexibilidad' }
];

const monitorStreams = [
  { name: 'Línea Norte', intensity: 72 },
  { name: 'Anillo Central', intensity: 54 },
  { name: 'Terminal V2G', intensity: 38 },
  { name: 'Micro-grid Costera', intensity: 64 }
];

const processSteps = [
  {
    title: 'Ideación multicapa',
    description: 'Identificamos nodos críticos y escenarios de operación híbrida con los actores locales.'
  },
  {
    title: 'Laboratorio digital',
    description: 'Simulamos cargas, interacciones y control distribuido con gemelos virtuales de la red.'
  },
  {
    title: 'Despliegue iterativo',
    description: 'Integramos sensores, DERMS y analítica edge siguiendo lotes de mejora continua.'
  },
  {
    title: 'Optimización continua',
    description: 'Evaluamos KPIs energéticos y ambientales para recalibrar respuestas y automatizaciones.'
  }
];

const testimonials = [
  {
    name: 'María López · Ayuntamiento de Madrid',
    message:
      'La plataforma ha conectado nuestras microrredes municipales con una visibilidad minuto a minuto, permitiendo decisiones ágiles desde el centro de control energético.'
  },
  {
    name: 'Jordi Soler · Consorcio Energético Barcelona',
    message:
      'El enfoque colaborativo nos ha permitido desplegar nodos IoT interoperables con arquitecturas IEC 61850 sin interrumpir la operación diaria.'
  },
  {
    name: 'Ana Pérez · Gestor de carga V2G',
    message:
      'RedInteligente España nos facilitó algoritmos de planificación dinámica que equilibran la disponibilidad de las flotas con la demanda urbana.'
  }
];

const faqItems = [
  {
    question: '¿Cómo integráis nuevas microrredes sin afectar la red principal?',
    answer:
      'Evaluamos el modelo eléctrico existente, sincronizamos nodos mediante pasarelas edge y usamos protocolos estandarizados para que la microrred pueda operar de forma coordinada o en modo isla cuando sea necesario.'
  },
  {
    question: '¿Qué metodologías empleáis para la respuesta a la demanda?',
    answer:
      'Combinamos algoritmos predictivos, agregadores certificados y reglas de priorización que respetan la flexibilidad de cada usuario final. Todo queda trazado en dashboards analíticos para auditar cada activación.'
  },
  {
    question: '¿La plataforma soporta interoperabilidad multi-fabricante?',
    answer:
      'Sí. Trabajamos con modelos semánticos abiertos, traductores IEC 61850 y APIs seguras que permiten incorporar equipos de distintos fabricantes sin reconfiguraciones complejas.'
  }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsConfig.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [demandaData, setDemandaData] = useState({
    viviendas: 120,
    consumo: 2.8,
    generacion: 35
  });
  const [simResult, setSimResult] = useState(null);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterFeedback, setNewsletterFeedback] = useState('');

  usePageMeta({
    title: 'RedInteligente España | Smart Grids, IoT Energético y Microrredes',
    description:
      'RedInteligente España impulsa la digitalización energética con smart grids, microrredes urbanas y soluciones IoT interoperables en todo el territorio español.',
    keywords:
      'smart grid, IoT energético, microrredes, medidores inteligentes, automatización eléctrica, respuesta a demanda, infraestructura conectada',
    canonical: 'https://www.redinteligente.com/',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'RedInteligente España',
      url: 'https://www.redinteligente.com/',
      logo: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=300&q=60',
      description:
        'Plataforma digital energética especializada en smart grids, IoT Energético y despliegue de microrredes en España.',
      address: {
        '@type': 'PostalAddress',
        streetAddress: 'Paseo de la Castellana 141',
        addressLocality: 'Madrid',
        postalCode: '28046',
        addressCountry: 'ES'
      },
      contactPoint: [
        {
          '@type': 'ContactPoint',
          telephone: '+34 917 89 34 56',
          contactType: 'customer support',
          areaServed: 'ES'
        }
      ],
      sameAs: [
        'https://www.linkedin.com',
        'https://twitter.com'
      ]
    }
  });

  useEffect(() => {
    let animationFrame;
    const duration = 1800;
    const start = performance.now();

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const nextValues = statsConfig.map((item) =>
        Math.round(item.target * progress)
      );
      setAnimatedStats(nextValues);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  const handleSimuladorChange = (event) => {
    const { name, value } = event.target;
    setDemandaData((prev) => ({
      ...prev,
      [name]: Number(value)
    }));
  };

  const handleSimulate = (event) => {
    event.preventDefault();
    const consumoTotal = demandaData.viviendas * demandaData.consumo;
    const reduccion = (consumoTotal * demandaData.generacion) / 100;
    const picoCoordinado = (consumoTotal - reduccion) * 0.62;
    const estabilidad = Math.min(100, Math.round(68 + demandaData.generacion * 0.4));
    setSimResult({
      consumoTotal: consumoTotal.toFixed(1),
      reduccion: reduccion.toFixed(1),
      picoCoordinado: picoCoordinado.toFixed(1),
      estabilidad
    });
  };

  const handleNewsletter = (event) => {
    event.preventDefault();
    if (!newsletterEmail.includes('@')) {
      setNewsletterFeedback('Introduce un correo electrónico válido.');
      return;
    }
    setNewsletterFeedback(
      'Gracias. Te enviaremos las próximas novedades sobre smart grids y microrredes.'
    );
    setNewsletterEmail('');
  };

  const previewPosts = blogPosts.slice(0, 3);

  return (
    <div className="page">
      <section
        className="hero"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(12,30,59,0.92) 0%, rgba(12,30,59,0.65) 40%, rgba(0,217,255,0.25) 100%), url('https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1600&q=80')"
        }}
      >
        <div className="hero-content">
          <p className="hero-kicker">La Red del Futuro</p>
          <h1>
            Inteligencia distribuida para redes eléctricas conectadas y resilientes
          </h1>
          <p className="hero-subtitle">
            RedInteligente España articula una plataforma digital que integra medición avanzada,
            edge computing y analítica colaborativa para coordinar microrredes urbanas y territoriales.
          </p>
          <div className="hero-actions">
            <Link to="/colabora" className="btn-primary">
              Conectar con el ecosistema
            </Link>
            <Link to="/tecnologias-smart-grid" className="btn-secondary">
              Ver tecnologías
            </Link>
          </div>
          <div className="hero-meta">
            <span>Smart Grids</span>
            <span>IoT Energético</span>
            <span>Microrredes Autónomas</span>
          </div>
        </div>
        <div className="hero-visual">
          <img
            src="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=900&q=80"
            alt="Centro de control energético con dashboards digitales"
          />
        </div>
      </section>

      <section className="section stats-section">
        <div className="section-header">
          <h2>Impacto cuantificable en la infraestructura conectada</h2>
          <p>
            Aceleramos la transición hacia redes inteligentes desde la monitorización
            en campo hasta la gobernanza de datos energéticos.
          </p>
        </div>
        <div className="stats-grid">
          {statsConfig.map((item, index) => (
            <article key={item.label} className="stat-card">
              <span className="stat-value">
                {animatedStats[index]}
                {item.suffix}
              </span>
              <p>{item.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section mapa-section" aria-labelledby="mapa-title">
        <div className="section-header">
          <h2 id="mapa-title">Mapa de Microrredes</h2>
          <p>
            Visualizamos la actividad en tiempo real de las microrredes desplegadas en España,
            destacando nodos críticos y escenarios de expansión.
          </p>
        </div>
        <div className="mapa-wrapper">
          <div
            className="mapa-visual"
            style={{
              backgroundImage:
                "url('https://images.unsplash.com/photo-1521292270410-a8c3a1aeb5d5?auto=format&fit=crop&w=1400&q=80')"
            }}
            role="img"
            aria-label="Mapa estilizado de España con nodos de microrredes"
          >
            {mapNodes.map((node) => (
              <button
                key={node.name}
                className="map-node"
                style={{ top: node.top, left: node.left }}
                type="button"
              >
                <span className="map-node-dot" />
                <span className="map-node-info">
                  <strong>{node.name}</strong>
                  <span>{node.status}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="section monitor-section" aria-labelledby="monitor-title">
        <div className="section-header">
          <h2 id="monitor-title">Monitor de Flujo</h2>
          <p>
            Un panel de lectura ágil para percibir el pulso energético de la red digital,
            con animaciones que representan la intensidad de los circuitos clave.
          </p>
        </div>
        <div className="monitor-grid">
          {monitorStreams.map((stream) => (
            <div key={stream.name} className="monitor-card">
              <div className="monitor-card-header">
                <h3>{stream.name}</h3>
                <span>{stream.intensity}%</span>
              </div>
              <div className="flow-visual">
                <div
                  className="flow-bar"
                  style={{ width: `${stream.intensity}%` }}
                />
              </div>
              <p>
                La telemetría sincronizada indica un flujo estable con ajustes automáticos
                a partir de los nodos IoT distribuidos.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="section gallery-section" aria-labelledby="gallery-title">
        <div className="section-header">
          <h2 id="gallery-title">Galería IoT</h2>
          <p>
            Dispositivos y cuadros inteligentes que habilitan la orquestación de datos
            energéticos en edificios, industria y espacios públicos.
          </p>
        </div>
        <div className="iot-gallery">
          {[
            {
              src: 'https://images.unsplash.com/photo-1580894906472-6a8a2508673e?auto=format&fit=crop&w=800&q=80',
              alt: 'Sensor IoT montado en tablero eléctrico'
            },
            {
              src: 'https://images.unsplash.com/photo-1580894897408-6c88be8ec735?auto=format&fit=crop&w=800&q=80',
              alt: 'Medidor inteligente con pantalla digital'
            },
            {
              src: 'https://images.unsplash.com/photo-1581090699325-227af4c47cab?auto=format&fit=crop&w=800&q=80',
              alt: 'Pasarela edge instalada en microrred urbana'
            },
            {
              src: 'https://images.unsplash.com/photo-1581091870622-2eebca269bc1?auto=format&fit=crop&w=800&q=80',
              alt: 'Dashboard analítico con indicadores energéticos'
            },
            {
              src: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
              alt: 'Equipo técnico revisando nodos de comunicación'
            },
            {
              src: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
              alt: 'Panel solar conectado a microrred residencial'
            }
          ].map((item, index) => (
            <figure key={`${item.alt}-${index}`} className="gallery-item">
              <img src={item.src} alt={item.alt} loading="lazy" />
              <figcaption>{item.alt}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="section simulador-section" aria-labelledby="simulador-title">
        <div className="section-header">
          <h2 id="simulador-title">Simulador de Demanda</h2>
          <p>
            Proyecta escenarios de demanda urbana combinando viviendas, consumo medio
            y generación distribuida para anticipar picos y coordinaciones.
          </p>
        </div>
        <div className="simulador-grid">
          <form className="simulador-form" onSubmit={handleSimulate}>
            <div className="form-group">
              <label htmlFor="viviendas">Número de viviendas conectadas</label>
              <input
                type="number"
                id="viviendas"
                name="viviendas"
                min="10"
                max="1000"
                value={demandaData.viviendas}
                onChange={handleSimuladorChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="consumo">
                Consumo medio diario por vivienda (MWh)
              </label>
              <input
                type="number"
                step="0.1"
                id="consumo"
                name="consumo"
                min="0.5"
                max="10"
                value={demandaData.consumo}
                onChange={handleSimuladorChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="generacion">
                Porcentaje de generación distribuida (%)
              </label>
              <input
                type="number"
                id="generacion"
                name="generacion"
                min="0"
                max="80"
                value={demandaData.generacion}
                onChange={handleSimuladorChange}
                required
              />
            </div>
            <button type="submit" className="btn-primary">
              Calcular escenario
            </button>
          </form>
          <div className="simulador-result">
            <h3>Resultados estimados</h3>
            {simResult ? (
              <ul>
                <li>
                  <span>Demanda diaria agregada:</span>
                  <strong>{simResult.consumoTotal} MWh</strong>
                </li>
                <li>
                  <span>Mitigación por generación distribuida:</span>
                  <strong>{simResult.reduccion} MWh</strong>
                </li>
                <li>
                  <span>Pico coordinado tras respuesta a la demanda:</span>
                  <strong>{simResult.picoCoordinado} MWh</strong>
                </li>
                <li>
                  <span>Índice de estabilidad proyectado:</span>
                  <strong>{simResult.estabilidad}%</strong>
                </li>
              </ul>
            ) : (
              <p>
                Ajusta los parámetros y lanza el simulador para identificar cómo
                influyen las decisiones de flexibilidad en el equilibrio energético.
              </p>
            )}
          </div>
        </div>
      </section>

      <section className="section casos-section" aria-labelledby="casos-title">
        <div className="section-header">
          <h2 id="casos-title">Casos Urbanos</h2>
          <p>
            Proyectos piloto que conectan ciudad, industria y ciudadanía a través de
            microrredes inteligentes con coordinación en tiempo real.
          </p>
        </div>
        <div className="casos-grid">
          {[
            {
              title: 'Distrito Madrid Norte',
              description:
                'Corredores energéticos conectados a la red municipal con medición avanzada y capacidades de isla automática.',
              image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1000&q=80'
            },
            {
              title: 'Puerto Innovador Valencia',
              description:
                'Integración de sensores marítimos, almacenamiento y estaciones V2G para sincronizar carga y descarga en el puerto.',
              image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1000&q=80'
            },
            {
              title: 'Campus Bilbao IA',
              description:
                'Microrred académica con inteligencia artificial que predice picos de demanda y activa baterías locales.',
              image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1000&q=80'
            }
          ].map((caso) => (
            <article key={caso.title} className="caso-card">
              <div className="caso-image">
                <img src={caso.image} alt={`Microrred urbana: ${caso.title}`} loading="lazy" />
              </div>
              <div className="caso-content">
                <h3>{caso.title}</h3>
                <p>{caso.description}</p>
                <Link to="/proyectos-piloto" className="caso-link">
                  Explorar detalle
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section process-section" aria-labelledby="process-title">
        <div className="section-header">
          <h2 id="process-title">Proceso colaborativo de implementación</h2>
          <p>
            Una hoja de ruta para desplegar redes inteligentes que responde a los retos
            de cada territorio con tecnología y gobernanza compartida.
          </p>
        </div>
        <div className="process-grid">
          {processSteps.map((step, index) => (
            <div key={step.title} className="process-card">
              <span className="process-number">{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section testimonials-section" aria-labelledby="testimonials-title">
        <div className="section-header">
          <h2 id="testimonials-title">Testimonios del ecosistema</h2>
          <p>
            Aliados municipales, gestores de carga y operadores de red evalúan el impacto
            de RedInteligente España tras cada despliegue.
          </p>
        </div>
        <div className="testimonials-wrapper">
          <div className="testimonial-card">
            <p>“{testimonials[currentTestimonial].message}”</p>
            <span>{testimonials[currentTestimonial].name}</span>
          </div>
          <div className="testimonial-controls">
            {testimonials.map((testimonial, index) => (
              <button
                type="button"
                key={testimonial.name}
                className={index === currentTestimonial ? 'active' : ''}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Ver testimonio ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section faq-section" aria-labelledby="faq-title">
        <div className="section-header">
          <h2 id="faq-title">Preguntas frecuentes</h2>
          <p>
            Aclaramos dudas habituales sobre interoperabilidad, despliegue y operación
            colaborativa de las smart grids.
          </p>
        </div>
        <div className="faq-grid">
          {faqItems.map((faq, index) => (
            <details key={faq.question} className="faq-item">
              <summary>
                <span>{faq.question}</span>
              </summary>
              <p>{faq.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="section blog-preview-section" aria-labelledby="blog-preview-title">
        <div className="section-header">
          <h2 id="blog-preview-title">Últimos análisis de digitalización</h2>
          <p>
            Investigación aplicada, normativa y estrategias IoT para impulsar redes inteligentes
            resilientes en España.
          </p>
        </div>
        <div className="blog-preview-grid">
          {previewPosts.map((post) => (
            <article key={post.slug} className="blog-preview-card">
              <div className="blog-preview-image">
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className="blog-preview-content">
                <span className="blog-category">{post.category}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className="blog-preview-link">
                  Leer artículo
                </Link>
              </div>
            </article>
          ))}
        </div>
        <div className="section-actions">
          <Link to="/blog" className="btn-secondary">
            Ver todas las publicaciones
          </Link>
        </div>
      </section>

      <section className="section newsletter-section" aria-labelledby="newsletter-title">
        <div className="newsletter-content">
          <div>
            <h2 id="newsletter-title">Newsletter de la red inteligente</h2>
            <p>
              Recibe actualizaciones mensuales sobre pilotos, guías técnicas y convocatorias
              colaborativas en smart grids e IoT energético.
            </p>
          </div>
          <form className="newsletter-form" onSubmit={handleNewsletter}>
            <label htmlFor="newsletter-email" className="sr-only">
              Correo electrónico
            </label>
            <input
              type="email"
              id="newsletter-email"
              placeholder="tu-email@ejemplo.com"
              value={newsletterEmail}
              onChange={(event) => setNewsletterEmail(event.target.value)}
              required
            />
            <button type="submit" className="btn-primary">
              Unirme
            </button>
          </form>
          {newsletterFeedback && <p className="newsletter-feedback">{newsletterFeedback}</p>}
        </div>
      </section>
    </div>
  );
};

export default Home;