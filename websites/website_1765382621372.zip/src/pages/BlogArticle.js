import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import blogPosts from '../data/blogPosts';

const BlogArticle = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const article = blogPosts.find((post) => post.slug === slug);

  usePageMeta({
    title: article
      ? `${article.title} | RedInteligente España`
      : 'Artículo no encontrado | RedInteligente España',
    description: article ? article.excerpt : 'Artículo no disponible',
    keywords:
      'smart grid, IoT energético, microrredes, ciberseguridad, regulación energética, IA demanda, V2G movilidad',
    canonical: article
      ? `https://www.redinteligente.com/blog/${article.slug}`
      : 'https://www.redinteligente.com/blog'
  });

  if (!article) {
    return (
      <div className="page page-centered">
        <h1>Artículo no disponible</h1>
        <p>
          El contenido que buscas no se encuentra publicado o ha sido movido.
        </p>
        <button type="button" className="btn-primary" onClick={() => navigate(-1)}>
          Volver atrás
        </button>
      </div>
    );
  }

  return (
    <div className="page">
      <section className="article-hero">
        <div className="article-hero-content">
          <span className="blog-category">{article.category}</span>
          <h1>{article.title}</h1>
          <p>{article.excerpt}</p>
          <span className="article-date">
            {new Date(article.date).toLocaleDateString('es-ES')}
          </span>
        </div>
        <div className="article-hero-image">
          <img src={article.image} alt={article.title} loading="lazy" />
        </div>
      </section>

      <section className="section article-content">
        {article.content.map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
        <div className="article-footer">
          <Link to="/blog" className="btn-secondary">
            Volver al blog
          </Link>
        </div>
      </section>
    </div>
  );
};

export default BlogArticle;