import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Cookies = () => {
  usePageMeta({
    title: 'Política de Cookies | RedInteligente España',
    description:
      'Conoce cómo RedInteligente España utiliza cookies para mejorar la experiencia digital.',
    keywords:
      'política de cookies, cookies analíticas, cookies técnicas',
    canonical: 'https://www.redinteligente.com/politica-de-cookies'
  });

  return (
    <div className="page page-legal">
      <h1>Política de Cookies</h1>
      <p>Última actualización: 15 de mayo de 2024</p>

      <h2>1. ¿Qué son las cookies?</h2>
      <p>
        Las cookies son archivos que se descargan en tu dispositivo al acceder a determinados sitios web.
        Permiten almacenar información y recuperar datos sobre los hábitos de navegación.
      </p>

      <h2>2. Tipos de cookies utilizadas</h2>
      <ul>
        <li>
          <strong>Cookies técnicas:</strong> necesarias para garantizar el funcionamiento básico del sitio web.
        </li>
        <li>
          <strong>Cookies de personalización:</strong> recuerdan preferencias como el idioma o la vista seleccionada.
        </li>
        <li>
          <strong>Cookies analíticas:</strong> ayudan a medir la actividad del sitio y a elaborar estadísticas anónimas.
        </li>
      </ul>

      <h2>3. Gestión de cookies</h2>
      <p>
        Puedes configurar tu navegador para aceptar o rechazar cookies, así como eliminar aquellas ya instaladas.
        Consulta la ayuda de tu navegador para conocer las instrucciones específicas.
      </p>

      <h2>4. Actualizaciones</h2>
      <p>
        RedInteligente España puede modificar la presente política para adaptarla a nuevas exigencias normativas
        o a instrucciones de la autoridad de control en materia de protección de datos.
      </p>
    </div>
  );
};

export default Cookies;