import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const partners = [
  { name: 'GridLab Iberia', url: 'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=400&q=60' },
  { name: 'Energía Urbana 360', url: 'https://images.unsplash.com/photo-1580894906472-6a8a2508673e?auto=format&fit=crop&w=400&q=60' },
  { name: 'IoT Connect Spain', url: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=400&q=60' },
  { name: 'Edge Alliance', url: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=400&q=60' }
];

const teamMembers = [
  {
    name: 'Elena Martín',
    role: 'Directora de Estrategia Digital',
    bio: 'Ingeniera industrial, lidera la visión de smart grids combinando análisis de datos y gobernanza energética.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Luis Romero',
    role: 'Responsable de Microrredes',
    bio: 'Especialista en topologías de media tensión. Coordina pilotos urbanos y rurales con socios locales.',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Nuria Sánchez',
    role: 'Líder de Ciberseguridad OT',
    bio: 'Diseña arquitecturas Zero Trust para infraestructuras críticas y supervisa auditorías técnicas.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Gabriel Ortega',
    role: 'Arquitecto de Datos Energéticos',
    bio: 'Impulsa el modelo de datos común, APIs interoperables y analítica avanzada con IA.',
    image: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=400&q=80'
  }
];

const About = () => {
  usePageMeta({
    title: 'RedInteligente España | Conectando el Futuro',
    description:
      'Conoce la visión, historia y equipo multidisciplinar de RedInteligente España, plataforma digital energética y hub de innovación en smart grids.',
    keywords:
      'smart grid, innovación energética, hub de innovación, microrredes, IoT energético, ciberseguridad',
    canonical: 'https://www.redinteligente.com/quienes-somos'
  });

  return (
    <div className="page">
      <section
        className="page-hero"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(12,30,59,0.92) 0%, rgba(12,30,59,0.6) 100%), url('https://images.unsplash.com/photo-1451188502541-13943edb6acb?auto=format&fit=crop&w=1400&q=80')"
        }}
      >
        <div className="page-hero-content">
          <p className="hero-kicker">Conectando el Futuro</p>
          <h1>Un ecosistema digital que transforma la infraestructura energética española</h1>
          <p>
            RedInteligente España nace de la colaboración entre operadores, municipios y
            empresas tecnológicas para articular redes inteligentes preparadas para los retos
            del siglo XXI.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="two-columns">
          <div>
            <h2>Visión</h2>
            <p>
              Aspiramos a un sistema eléctrico colaborativo, abierto y transparente,
              donde cada kilovatio se gestione con inteligencia, coordinación territorial
              y sensibilidad climática. Impulsamos infraestructuras cableadas y
              digitales como motores de una nueva movilidad y de comunidades energéticas
              autosuficientes.
            </p>
          </div>
          <div>
            <h2>Historia</h2>
            <p>
              En 2016 comenzamos como laboratorio de datos con operadores de distribución.
              Desde entonces hemos escalado hacia pilotos de microrredes urbanas, despliegue
              de medidores inteligentes y analítica crítica para ciudades y campus tecnológicos.
            </p>
          </div>
        </div>
      </section>

      <section className="section background-light">
        <div className="two-columns">
          <div>
            <h2>Filosofía Digital</h2>
            <p>
              Colocamos la interoperabilidad en el centro. Cada solución se basa en estándares,
              APIs documentadas y modelos de datos enriquecidos. Entendemos la tecnología como
              facilitadora de decisiones colectivas y de impacto proporcional en comunidades.
            </p>
          </div>
          <div>
            <h2>Hub de Innovación</h2>
            <p>
              El hub actúa como punto de encuentro entre startups, universidades, operadores
              y administraciones públicas. Creamos espacios de co-creación donde se validan
              nuevas arquitecturas de red, se testean algoritmos y se comparte conocimiento.
            </p>
          </div>
        </div>
      </section>

      <section className="section partners-section">
        <div className="section-header">
          <h2>Partners estratégicos</h2>
          <p>
            La colaboración genera impacto real. Trabajamos con organizaciones que lideran
            la transición energética en España y Europa.
          </p>
        </div>
        <div className="partners-grid">
          {partners.map((partner) => (
            <div key={partner.name} className="partner-card">
              <img src={partner.url} alt={`Socio estratégico ${partner.name}`} loading="lazy" />
              <p>{partner.name}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section team-section">
        <div className="section-header">
          <h2>Equipo Multidisciplinar</h2>
          <p>
            Integramos perfiles técnicos, analíticos y de políticas públicas para abordar
            proyectos complejos desde múltiples perspectivas.
          </p>
        </div>
        <div className="team-grid">
          {teamMembers.map((member) => (
            <article key={member.name} className="team-card">
              <img src={member.image} alt={member.name} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="two-columns">
          <div>
            <h2>Ciberseguridad y Privacidad</h2>
            <p>
              Operamos con principios Zero Trust, segmentación dinámica y cifrado extremo a extremo.
              Todas las integraciones respetan las guías del Esquema Nacional de Seguridad y la normativa
              europea NIS2. Los datos personales se tratan bajo los criterios del RGPD y se anonimizan
              cuando el proyecto lo requiere.
            </p>
          </div>
          <div>
            <h2>Ética y Gobernanza</h2>
            <p>
              Priorizamos la transparencia en cada proceso decisional. Los algoritmos se documentan
              y se auditan, asegurando que comunidades, operadores y administraciones participen en
              la evolución de la plataforma.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;