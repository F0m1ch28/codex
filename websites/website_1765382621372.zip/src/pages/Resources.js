import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const guides = [
  {
    title: 'Guía de despliegue AMI en ciudades medianas',
    description: 'Checklist técnico y operativo para lanzar programas AMI interoperables.',
    link: '#'
  },
  {
    title: 'Manual de microrredes resilientes',
    description: 'Diseño modular, procesos de isla automática y coordinación con DSO.',
    link: '#'
  },
  {
    title: 'Toolkit de orquestación DERMS',
    description: 'Plantillas de configuración y métricas clave para controlar recursos distribuidos.',
    link: '#'
  }
];

const webinars = [
  {
    title: 'Respuesta a la demanda en contextos urbanos',
    date: 'Mayo 2024',
    description: 'Casos reales en Valencia y Madrid con participación de agregadores.',
    link: '#'
  },
  {
    title: 'Ciberseguridad OT en smart grids',
    date: 'Junio 2024',
    description: 'Implementación Zero Trust en infraestructuras eléctricas.',
    link: '#'
  }
];

const datasets = [
  {
    title: 'Dataset: Consumo horario microrred urbana',
    description: 'Serie temporal anonimizada de consumos y generación distribuida.',
    link: '#'
  },
  {
    title: 'Dataset: Eventos de flexibilidad agregada',
    description: 'Activaciones coordinadas con clasificación por sector y tipología.',
    link: '#'
  }
];

const glossary = [
  { term: 'DERMS', definition: 'Sistema de gestión de recursos energéticos distribuidos.' },
  { term: 'Flexibilidad', definition: 'Capacidad de modificar la demanda o la generación en respuesta a señales.' },
  { term: 'Edge Analytics', definition: 'Procesamiento de datos energéticos en el borde de la red.' }
];

const Resources = () => {
  usePageMeta({
    title: 'Biblioteca Smart Grid | RedInteligente España',
    description:
      'Accede a guías, estándares, whitepapers, webinars, datasets y glosario de RedInteligente España para redes inteligentes.',
    keywords:
      'guías smart grid, estándares IEC 61850, whitepapers smart grid, webinars IoT energético, datasets energéticos, glosario smart grid',
    canonical: 'https://www.redinteligente.com/recursos-tecnicos'
  });

  return (
    <div className="page">
      <section
        className="page-hero"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(12,30,59,0.92) 0%, rgba(12,30,59,0.65) 100%), url('https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1400&q=80')"
        }}
      >
        <div className="page-hero-content">
          <p className="hero-kicker">Biblioteca Smart Grid</p>
          <h1>Conocimiento técnico y herramientas para redes inteligentes</h1>
          <p>
            Documentación, estándares y datasets que respaldan los proyectos de digitalización
            energética impulsados por RedInteligente España.
          </p>
        </div>
      </section>

      <section className="section">
        <h2>Guías</h2>
        <div className="resource-grid">
          {guides.map((guide) => (
            <article key={guide.title} className="resource-card">
              <h3>{guide.title}</h3>
              <p>{guide.description}</p>
              <a href={guide.link} className="resource-link">
                Consultar guía
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="section background-light">
        <div className="resource-columns">
          <div>
            <h2>Estándares</h2>
            <ul className="standard-list">
              <li>
                <strong>IEC 61850</strong> · Modelos semánticos para subestaciones y automatización.
              </li>
              <li>
                <strong>IEEE 2030</strong> · Recomendaciones para interoperabilidad entre redes eléctricas y TIC.
              </li>
              <li>
                <strong>UNE 178900</strong> · Marco de ciudad inteligente alineado con infraestructuras críticas.
              </li>
            </ul>
          </div>
          <div>
            <h2>Whitepapers</h2>
            <ul className="standard-list">
              <li>
                <span>Enfoque integral de resiliencia urbana basado en microrredes autónomas.</span>
              </li>
              <li>
                <span>Arquitectura de datos para plataformas energéticas regionales.</span>
              </li>
              <li>
                <span>Estrategias de ciberseguridad OT en ecosistemas distribuidos.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section">
        <h2>Webinars</h2>
        <div className="resource-grid">
          {webinars.map((webinar) => (
            <article key={webinar.title} className="resource-card">
              <span className="resource-meta">{webinar.date}</span>
              <h3>{webinar.title}</h3>
              <p>{webinar.description}</p>
              <a href={webinar.link} className="resource-link">
                Reservar plaza
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="section background-light">
        <h2>Datasets</h2>
        <div className="resource-grid">
          {datasets.map((dataset) => (
            <article key={dataset.title} className="resource-card">
              <h3>{dataset.title}</h3>
              <p>{dataset.description}</p>
              <a href={dataset.link} className="resource-link">
                Descargar dataset
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <h2>Glosario</h2>
        <dl className="glossary-list">
          {glossary.map((entry) => (
            <div key={entry.term}>
              <dt>{entry.term}</dt>
              <dd>{entry.definition}</dd>
            </div>
          ))}
        </dl>
      </section>
    </div>
  );
};

export default Resources;