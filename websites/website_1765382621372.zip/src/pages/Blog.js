import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import blogPosts from '../data/blogPosts';

const categories = [
  'Todas',
  'IoT Industrial',
  'Ciberseguridad',
  'Regulación',
  'Microrredes Comunitarias',
  'IA Demanda',
  'V2G Movilidad'
];

const Blog = () => {
  const [filter, setFilter] = useState('Todas');

  usePageMeta({
    title: 'Análisis de Digitalización | Blog RedInteligente España',
    description:
      'Lecturas sobre digitalización energética, IoT industrial, ciberseguridad, regulación, microrredes comunitarias, IA de demanda y V2G.',
    keywords:
      'blog smart grid, IoT industrial, ciberseguridad, regulación energética, microrredes comunitarias, IA demanda, V2G movilidad',
    canonical: 'https://www.redinteligente.com/blog'
  });

  const filteredPosts =
    filter === 'Todas'
      ? blogPosts
      : blogPosts.filter((post) => post.category === filter);

  return (
    <div className="page">
      <section
        className="page-hero"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(12,30,59,0.92) 0%, rgba(12,30,59,0.55) 100%), url('https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?auto=format&fit=crop&w=1400&q=80')"
        }}
      >
        <div className="page-hero-content">
          <p className="hero-kicker">Análisis de Digitalización</p>
          <h1>Perspectivas para impulsar redes inteligentes en España</h1>
          <p>
            Documentamos aprendizajes técnicos, regulatorios y operativos para acelerar
            la transición hacia una infraestructura eléctrica conectada.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="blog-filters" role="tablist" aria-label="Filtros de categoría">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`blog-filter ${filter === category ? 'active' : ''}`}
              onClick={() => setFilter(category)}
              role="tab"
              aria-selected={filter === category}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="blog-grid">
          {filteredPosts.map((post) => (
            <article key={post.slug} className="blog-card">
              <div className="blog-card-image">
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className="blog-card-content">
                <span className="blog-category">{post.category}</span>
                <h2>{post.title}</h2>
                <p>{post.excerpt}</p>
                <div className="blog-card-footer">
                  <span>{new Date(post.date).toLocaleDateString('es-ES')}</span>
                  <Link to={`/blog/${post.slug}`} className="blog-card-link">
                    Leer más
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Blog;