import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Terms = () => {
  usePageMeta({
    title: 'Términos de Uso | RedInteligente España',
    description:
      'Consulta los términos de uso de la plataforma digital energética RedInteligente España.',
    keywords:
      'términos de uso, condiciones de servicio, RedInteligente España',
    canonical: 'https://www.redinteligente.com/legal'
  });

  return (
    <div className="page page-legal">
      <h1>Términos de Uso</h1>
      <p>Última actualización: 15 de mayo de 2024</p>

      <h2>1. Objeto</h2>
      <p>
        El presente documento regula el acceso y la utilización de la plataforma digital
        redinteligente.com, titularidad de RedInteligente España. Al navegar por el sitio
        aceptas estas condiciones.
      </p>

      <h2>2. Uso permitido</h2>
      <p>
        Puedes consultar contenidos, descargar recursos y contactar con el equipo siempre
        que respetes la legislación vigente. Queda prohibido utilizar la plataforma para
        actividades que puedan dañar la infraestructura tecnológica o vulnerar derechos de terceros.
      </p>

      <h2>3. Propiedad intelectual</h2>
      <p>
        Todos los materiales publicados (textos, gráficos, marcas y contenidos audiovisuales)
        pertenecen a RedInteligente España o a sus legítimos titulares. Se permite la cita parcial
        siempre que se mencione la fuente y no se altere el sentido original.
      </p>

      <h2>4. Responsabilidad</h2>
      <p>
        RedInteligente España trabaja para ofrecer información fiable y actualizada. No obstante,
        no se asume responsabilidad por decisiones que se adopten exclusivamente a partir del contenido
        publicado sin consultar con profesionales especializados.
      </p>

      <h2>5. Enlaces externos</h2>
      <p>
        La plataforma puede incluir enlaces a sitios de terceros. RedInteligente España no controla
        dichos contenidos y, por tanto, no responde de su disponibilidad ni de sus políticas.
      </p>

      <h2>6. Modificaciones</h2>
      <p>
        Nos reservamos el derecho a actualizar estas condiciones cuando sea necesario. Las nuevas
        versiones serán publicadas en esta misma página.
      </p>

      <h2>7. Legislación aplicable</h2>
      <p>
        Los presentes términos se rigen por la legislación española. Para cualquier controversia
        se acudirá a los juzgados y tribunales de Madrid capital.
      </p>
    </div>
  );
};

export default Terms;