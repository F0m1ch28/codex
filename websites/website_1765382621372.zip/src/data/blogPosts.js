const blogPosts = [
  {
    slug: 'arquitecturas-resilientes-microrredes-comunitarias',
    title: 'Arquitecturas resilientes para microrredes comunitarias',
    category: 'Microrredes Comunitarias',
    date: '2024-04-10',
    image: 'https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'Cómo diseñar topologías modulares que aseguren continuidad operativa y capacidad de isla en barrios urbanos.',
    content: [
      'Las microrredes comunitarias se han consolidado como la opción más versátil para integrar recursos energéticos distribuidos en entornos residenciales y mixtos. La clave está en diseñar arquitecturas modulares, con nodos autoorganizados y herramientas de visibilidad en tiempo real.',
      'En RedInteligente España hemos puesto el foco en orquestadores DERMS capaces de dialogar con controladores de baja tensión y con plataformas municipales. El objetivo es que cada microrred adopte decisiones autónomas sin perder coordinación con la red principal.',
      'La resiliencia se refuerza incorporando escenarios de reconfiguración automática, mecanismos de respuesta a la demanda y algoritmos de predicción meteorológica. Con ello se asegura una operación segura incluso ante eventos disruptivos o picos temporales de consumo.'
    ]
  },
  {
    slug: 'iot-industrial-interoperabilidad-iec61850',
    title: 'IoT industrial e interoperabilidad IEC 61850',
    category: 'IoT Industrial',
    date: '2024-03-22',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'La integración de sensores industriales con modelos semánticos IEC 61850 permite acelerar la automatización eléctrica.',
    content: [
      'El estándar IEC 61850 sigue siendo el eje de la automatización eléctrica avanzada. Sin embargo, su adopción plena requiere traducir modelos semánticos hacia dispositivos IoT ligeros y heterogéneos.',
      'Nuestra plataforma aborda este reto con pasarelas Edge que sincronizan perfiles de datos y ejecutan validaciones antes de enviar paquetes a la nube. Esto reduce latencias y garantiza confiabilidad en las órdenes de control.',
      'El resultado es una infraestructura verdaderamente conectada donde las alarmas se correlacionan con contextos operativos, habilitando decisiones precisas en subestaciones y celdas de media tensión.'
    ]
  },
  {
    slug: 'ciberseguridad-zero-trust-redes-electricas',
    title: 'Ciberseguridad Zero Trust para redes eléctricas',
    category: 'Ciberseguridad',
    date: '2024-02-28',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'Estrategias prácticas para desplegar un enfoque Zero Trust en entornos energéticos altamente distribuidos.',
    content: [
      'La digitalización del sistema eléctrico exige adoptar un enfoque Zero Trust donde cada identidad, dispositivo y flujo de datos sea verificado de extremo a extremo.',
      'Proponemos una arquitectura con segmentación dinámica, autenticación multifactor y análisis continuo de comportamiento. Las pasarelas Edge actúan como guardianes que revisan cada mensaje hacia la red troncal.',
      'Además, los centros de operación integran análisis de amenazas con inteligencia de fuentes colaborativas, fortaleciendo la prevención ante posibles incidentes.'
    ]
  },
  {
    slug: 'regulacion-flexibilidad-respuesta-demanda',
    title: 'Regulación y flexibilidad en programas de respuesta a la demanda',
    category: 'Regulación',
    date: '2024-03-01',
    image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'Panorama regulatorio español y europeo para habilitar programas ágiles de respuesta a la demanda coordinados por agregadores.',
    content: [
      'España avanza hacia un modelo donde el usuario activo y el agregador independiente juegan un papel crucial. Las recientes consultas públicas de CNMC apuntan a marcos más flexibles.',
      'Para operar de forma eficiente es imprescindible contar con sistemas que gestionen órdenes en segundos y agreguen señales de múltiples fuentes. Aquí la plataforma digital adquiere relevancia central.',
      'RedInteligente España participa en grupos de trabajo que definen métricas de desempeño y trazabilidad necesarias para la futura remuneración de estos servicios.'
    ]
  },
  {
    slug: 'ia-pronostico-demanda-urbana',
    title: 'IA para pronóstico de demanda urbana',
    category: 'IA Demanda',
    date: '2024-01-30',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'Modelos de inteligencia artificial que combinan datos energéticos con variables urbanas para anticipar consumo.',
    content: [
      'Los algoritmos de aprendizaje profundo han mejorado de forma notable la precisión de los pronósticos urbanos cuando se alimentan con datos heterogéneos: climatología, movilidad, y patrones socioeconómicos.',
      'Nuestra propuesta utiliza modelos híbridos que combinan LSTM con grafos espaciales, representando cada microrred como un nodo conectado por relaciones de flujo.',
      'El impacto directo es la posibilidad de afinar estrategias de flexibilidad, activar almacenamiento distribuido y mejorar la coordinación con plantas renovables cercanas.'
    ]
  },
  {
    slug: 'v2g-movilidad-electrica-madrid',
    title: 'V2G y movilidad eléctrica en Madrid',
    category: 'V2G Movilidad',
    date: '2024-02-12',
    image: 'https://images.unsplash.com/photo-1517433456452-f9633a875f6f?auto=format&fit=crop&w=1200&q=80',
    excerpt:
      'Lecciones aprendidas del piloto V2G desplegado en Madrid con flotas corporativas y gestores de carga urbanos.',
    content: [
      'El proyecto V2G Madrid demuestra que los vehículos pueden actuar como nodos energéticos ofreciendo potencia flexible en horas pico.',
      'Se diseñaron algoritmos que priorizan la disponibilidad de las flotas, combinando ventanas horarias y proyecciones de uso. La integración con microrredes locales permite almacenar excedentes renovables.',
      'Los próximos pasos incluyen la interoperabilidad con gestores de aparcamiento municipales y la incorporación de métricas de sostenibilidad para certificar la trazabilidad energética.'
    ]
  }
];

export default blogPosts;