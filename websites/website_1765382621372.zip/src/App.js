import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Technologies from './pages/Technologies';
import Projects from './pages/Projects';
import Resources from './pages/Resources';
import Blog from './pages/Blog';
import BlogArticle from './pages/BlogArticle';
import Collaborate from './pages/Collaborate';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';

function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Header />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/quienes-somos" element={<About />} />
          <Route path="/tecnologias-smart-grid" element={<Technologies />} />
          <Route path="/proyectos-piloto" element={<Projects />} />
          <Route path="/recursos-tecnicos" element={<Resources />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogArticle />} />
          <Route path="/colabora" element={<Collaborate />} />
          <Route path="/legal" element={<Terms />} />
          <Route path="/privacidad" element={<Privacy />} />
          <Route path="/politica-de-cookies" element={<Cookies />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </BrowserRouter>
  );
}

export default App;