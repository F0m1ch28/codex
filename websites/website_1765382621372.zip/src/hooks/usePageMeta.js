import { useEffect } from 'react';

const ensureMetaTag = (name, value) => {
  if (!value) return;
  let tag = document.querySelector(`meta[name="${name}"]`);
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute('name', name);
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', value);
};

const ensureCanonical = (href) => {
  if (!href) return;
  let link = document.querySelector('link[rel="canonical"]');
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', href);
};

const handleJsonLd = (jsonLd) => {
  const existing = document.getElementById('structured-data-jsonld');
  if (!jsonLd) {
    if (existing) {
      existing.remove();
    }
    return;
  }
  if (existing) {
    existing.text = JSON.stringify(jsonLd);
    return;
  }
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.id = 'structured-data-jsonld';
  script.text = JSON.stringify(jsonLd);
  document.head.appendChild(script);
};

const usePageMeta = ({ title, description, keywords, canonical, jsonLd }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    ensureMetaTag('description', description);
    ensureMetaTag('keywords', keywords);
    ensureCanonical(canonical);
    handleJsonLd(jsonLd);
  }, [title, description, keywords, canonical, jsonLd]);
};

export default usePageMeta;