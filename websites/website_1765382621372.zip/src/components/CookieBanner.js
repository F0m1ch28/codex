import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('ri-cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('ri-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="region" aria-label="Aviso de cookies">
      <p>
        Utilizamos cookies para mejorar la experiencia digital y analizar métricas de la plataforma.
        Puedes conocer más detalles en nuestra <Link to="/politica-de-cookies">Política de Cookies</Link>.
      </p>
      <button className="btn-primary" onClick={handleAccept}>
        Aceptar
      </button>
    </div>
  );
};

export default CookieBanner;