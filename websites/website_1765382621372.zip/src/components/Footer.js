import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="footer-container">
      <div className="footer-brand">
        <div className="footer-logo">
          <span className="logo-mark">Red</span>
          <span className="logo-text">Inteligente España</span>
        </div>
        <p>
          Plataforma digital energética y hub de innovación para desplegar smart grids,
          microrredes y soluciones IoT que conectan a los territorios de España.
        </p>
        <div className="footer-contact">
          <p>Paseo de la Castellana 141, 28046 Madrid</p>
          <p>Teléfono: <a href="tel:+34917893456">+34 917 89 34 56</a></p>
        </div>
      </div>
      <div className="footer-columns">
        <div>
          <h4>Navegación</h4>
          <ul>
            <li><Link to="/">Inicio</Link></li>
            <li><Link to="/quienes-somos">Quiénes Somos</Link></li>
            <li><Link to="/tecnologias-smart-grid">Tecnologías</Link></li>
            <li><Link to="/proyectos-piloto">Proyectos Piloto</Link></li>
          </ul>
        </div>
        <div>
          <h4>Recursos</h4>
          <ul>
            <li><Link to="/recursos-tecnicos">Biblioteca Smart Grid</Link></li>
            <li><Link to="/blog">Blog &amp; Análisis</Link></li>
            <li><Link to="/colabora">Colabora</Link></li>
          </ul>
        </div>
        <div>
          <h4>Legal</h4>
          <ul>
            <li><Link to="/legal">Términos de Uso</Link></li>
            <li><Link to="/privacidad">Privacidad</Link></li>
            <li><Link to="/politica-de-cookies">Política de Cookies</Link></li>
          </ul>
        </div>
      </div>
    </div>
    <div className="footer-bottom">
      <p>&copy; {new Date().getFullYear()} RedInteligente España. Todos los derechos reservados.</p>
    </div>
  </footer>
);

export default Footer;