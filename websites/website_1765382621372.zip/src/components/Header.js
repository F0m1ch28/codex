import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen(!menuOpen);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header">
      <div className="header-container">
        <NavLink to="/" className="logo" onClick={closeMenu}>
          <span className="logo-mark">Red</span>
          <span className="logo-text">Inteligente España</span>
        </NavLink>
        <button
          className={`menu-toggle ${menuOpen ? 'active' : ''}`}
          onClick={toggleMenu}
          aria-label="Abrir menú de navegación"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`main-nav ${menuOpen ? 'open' : ''}`}>
          <NavLink to="/" onClick={closeMenu} className="nav-link">
            Inicio
          </NavLink>
          <NavLink to="/quienes-somos" onClick={closeMenu} className="nav-link">
            Quiénes Somos
          </NavLink>
          <NavLink to="/tecnologias-smart-grid" onClick={closeMenu} className="nav-link">
            Tecnologías
          </NavLink>
          <NavLink to="/proyectos-piloto" onClick={closeMenu} className="nav-link">
            Proyectos
          </NavLink>
          <NavLink to="/recursos-tecnicos" onClick={closeMenu} className="nav-link">
            Recursos
          </NavLink>
          <NavLink to="/blog" onClick={closeMenu} className="nav-link">
            Blog
          </NavLink>
          <NavLink to="/colabora" onClick={closeMenu} className="nav-link nav-link-highlight">
            Colabora
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;