document.addEventListener("DOMContentLoaded", function () {
    const body = document.body;
    const navToggle = document.querySelector("[data-nav-toggle]");
    const navLinks = document.querySelectorAll("#primary-nav a");
    const nav = document.getElementById("primary-nav");
    const cookieBanner = document.querySelector("[data-cookie-banner]");
    const acceptBtn = document.querySelector("[data-cookie-accept]");
    const declineBtn = document.querySelector("[data-cookie-decline]");
    const storageKey = "politiyfdb_cookie_consent";

    if (navToggle && nav) {
        navToggle.addEventListener("click", function () {
            const isOpen = body.classList.toggle("nav-open");
            navToggle.setAttribute("aria-expanded", String(isOpen));
        });

        navLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                if (body.classList.contains("nav-open")) {
                    body.classList.remove("nav-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    if (cookieBanner) {
        const consent = localStorage.getItem(storageKey);
        if (!consent) {
            setTimeout(function () {
                cookieBanner.classList.add("active");
            }, 600);
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", function () {
                localStorage.setItem(storageKey, "accepted");
                cookieBanner.classList.remove("active");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", function () {
                localStorage.setItem(storageKey, "declined");
                cookieBanner.classList.remove("active");
            });
        }
    }
});