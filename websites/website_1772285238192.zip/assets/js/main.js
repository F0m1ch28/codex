document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');

  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navList.classList.toggle('open');
    });

    document.querySelectorAll('.nav-list a').forEach(link => {
      link.addEventListener('click', event => {
        const target = link.getAttribute('href');
        if (target && target.startsWith('#')) {
          event.preventDefault();
          const section = document.querySelector(target);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          if (section) {
            setTimeout(() => {
              section.scrollIntoView({ behavior: 'smooth' });
            }, 300);
          }
        }
        navList.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const scrollTopButton = document.getElementById('scrollTopButton');
  if (scrollTopButton) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 400) {
        scrollTopButton.classList.add('show');
      } else {
        scrollTopButton.classList.remove('show');
      }
    });

    scrollTopButton.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  const currentYearSpans = document.querySelectorAll('#current-year');
  const currentYear = new Date().getFullYear();
  currentYearSpans.forEach(span => {
    span.textContent = String(currentYear);
  });

  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const consentKey = 'luminosity_cookie_consent';

  if (cookieBanner && cookieAccept) {
    const consent = localStorage.getItem(consentKey);
    if (consent !== 'accepted') {
      cookieBanner.classList.add('active');
    }

    cookieAccept.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.classList.remove('active');
    });
  }
});