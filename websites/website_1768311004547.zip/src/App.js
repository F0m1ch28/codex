import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import ContactsPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsOfUsePage from './pages/TermsOfService';
import PrivacyPolicyPage, { CookiePolicyPage } from './pages/PrivacyPolicy';
import { BreedsPage, BehaviorPage, InterestingPage } from './pages/About';
import { CarePage } from './pages/Services';

function App() {
  return (
    <div className="app">
      <Header />
      <main id="main-content" className="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/porody-koshek" element={<BreedsPage />} />
          <Route path="/uhod-i-zdorove" element={<CarePage />} />
          <Route path="/povedenie" element={<BehaviorPage />} />
          <Route path="/interesnoe" element={<InterestingPage />} />
          <Route path="/kontakty" element={<ContactsPage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPolicyPage />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsOfUsePage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
          <Route path="/spasibo" element={<ThankYouPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;