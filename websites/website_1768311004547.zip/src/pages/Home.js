import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';

const HomePage = () => {
  const services = [
    {
      title: 'Атлас пород',
      description: 'Красивые карточки с описанием темперамента, особенностей и ухода за каждой породой.',
      link: '/porody-koshek',
      icon: '🐾'
    },
    {
      title: 'Советы по уходу',
      description: 'Практичные рекомендации по питанию, гигиене, игре и укреплению здоровья.',
      link: '/uhod-i-zdorove',
      icon: '🧴'
    },
    {
      title: 'Поведение и общение',
      description: 'Разбираем язык кошек, помогаем наладить доверительные отношения.',
      link: '/povedenie',
      icon: '💬'
    },
    {
      title: 'Интересные истории',
      description: 'Вдохновляющие рассказы, удивительные открытия и кошачьи традиции мира.',
      link: '/interesnoe',
      icon: '✨'
    }
  ];

  const breeds = [
    {
      name: 'Мейн-кун',
      description:
        'Величественные гиганты с добрым характером. Любят внимание, быстро учатся и прекрасно уживаются с детьми.',
      image: 'https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop&w=840&q=80'
    },
    {
      name: 'Британская короткошёрстная',
      description:
        'Спокойные, уравновешенные и преданные компаньоны. Подходят для проживания в квартире и любят уют.',
      image: 'https://images.unsplash.com/photo-1519752594763-2633d8d4ea29?auto=format&fit=crop&w=840&q=80'
    },
    {
      name: 'Сфинкс',
      description:
        'Энергичные, ласковые и невероятно общительные кошки. Нуждаются в особом уходе за кожей и теплом.',
      image: 'https://images.unsplash.com/photo-1574158622682-e40e69881006?auto=format&fit=crop&w=840&q=80'
    },
    {
      name: 'Русская голубая',
      description:
        'Интеллигентные и деликатные, с мягкой шерстью серебристого оттенка. Предпочитают размеренные игры.',
      image: 'https://images.unsplash.com/photo-1501820488136-72669149e0d4?auto=format&fit=crop&w=840&q=80'
    }
  ];

  const careTips = [
    {
      title: 'Сбалансированное питание',
      text: 'Подбирайте рацион с учётом возраста и активности питомца, чередуйте влажный и сухой корм.',
      icon: '🥣'
    },
    {
      title: 'Гигиена и груминг',
      text: 'Регулярно чистите ушки, проверяйте когти и не забывайте о профилактике паразитов.',
      icon: '🛁'
    },
    {
      title: 'Игры и активность',
      text: 'Когтеточки, интерактивные игрушки и игры «охотника» помогают поддерживать хорошее настроение.',
      icon: '🎯'
    },
    {
      title: 'Ветеринарный контроль',
      text: 'Плановые осмотры и своевременная вакцинация продлевают жизнь и сохраняют здоровье кошки.',
      icon: '🏥'
    }
  ];

  const facts = [
    'Кошки способны запоминать до 100 различных звуков и интонаций.',
    'Домашние питомцы спят до 16 часов в сутки — сон помогает им сохранять энергию.',
    'У каждой кошки уникальный рисунок на подушечках лап, как отпечатки пальцев у людей.',
    'Кошки мурлыкают не только от удовольствия, но и для ускорения восстановления тканей.'
  ];

  const testimonials = [
    {
      name: 'Анна, заводчик мейн-кунов',
      quote:
        '«Мир Кошек» помог мне структурировать информацию для новых владельцев. Статьи написаны простым языком, а советы по уходу точны и современны.',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=200&q=70'
    },
    {
      name: 'Иван, хозяин двух котов',
      quote:
        'Нашёл ответы на все вопросы по поведению. Благодаря рекомендациям удалось решить проблему с метками и настроить игры для кошек.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=70'
    },
    {
      name: 'Мария, ветеринар',
      quote:
        'Советую портал своим клиентам. Материалы основаны на современных исследованиях, а инфографика помогает объяснить сложные темы.',
      image: 'https://images.unsplash.com/photo-1521572167111-3c0b84f89c71?auto=format&fit=crop&w=200&q=70'
    }
  ];

  const team = [
    {
      name: 'Екатерина Миронова',
      role: 'Редактор и фелинолог',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=320&q=80'
    },
    {
      name: 'Константин Романов',
      role: 'Ветеринарный эксперт',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=320&q=80'
    },
    {
      name: 'Светлана Котова',
      role: 'Поведенческий специалист',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=320&q=80'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Мир Кошек — всё о кошках, породах и заботе</title>
        <meta
          name="description"
          content="Мир Кошек — уютный информационный портал о породах кошек, грамотном уходе, поведении и здоровье хвостатых друзей."
        />
        <meta
          name="keywords"
          content="кошки, породы кошек, уход за кошкой, здоровье кошки, советы по уходу, коты"
        />
      </Helmet>
      <section className="hero" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1518791841217-8f162f1e1131?auto=format&fit=crop&w=1920&q=80)' }}>
        <div className="hero__overlay" />
        <div className="container hero__content">
          <p className="hero__tagline">Информационный портал о кошках</p>
          <h1 className="hero__title">Мир Кошек — вдохновение и забота о хвостатых друзьях</h1>
          <p className="hero__subtitle">
            Мы объединяем знания, опыт и любовь к кошкам, чтобы каждая мурлыка чувствовала себя счастливой, а вы —
            уверенным хозяином.
          </p>
          <div className="hero__actions">
            <Link to="/porody-koshek" className="button button--primary">
              Исследовать породы
            </Link>
            <Link to="/kontakty" className="button button--ghost">
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>

      <section className="section services">
        <div className="container">
          <h2 className="section__title">Что вы найдёте на «Мир Кошек»</h2>
          <p className="section__subtitle">
            Мы собрали лучшие материалы, чтобы сделать совместную жизнь с питомцем ещё теплее и интереснее.
          </p>
          <div className="grid grid--services">
            {services.map((service) => (
              <article key={service.title} className="card card--service">
                <div className="card__icon" aria-hidden="true">{service.icon}</div>
                <h3 className="card__title">{service.title}</h3>
                <p className="card__text">{service.description}</p>
                <Link className="card__link" to={service.link}>
                  Читать подробнее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section breeds">
        <div className="container">
          <h2 className="section__title">Популярные породы кошек</h2>
          <p className="section__subtitle">
            Узнайте особенности характера, истории происхождения и советы по уходу за любимыми породами.
          </p>
          <div className="grid grid--breeds">
            {breeds.map((breed) => (
              <article key={breed.name} className="card card--breed">
                <div className="card__image-wrapper">
                  <img src={breed.image} alt={breed.name} className="card__image" loading="lazy" />
                </div>
                <div className="card__body">
                  <h3 className="card__title">{breed.name}</h3>
                  <p className="card__text">{breed.description}</p>
                  <Link className="card__link" to="/porody-koshek">
                    Узнать больше →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section care">
        <div className="container">
          <h2 className="section__title">Советы по уходу</h2>
          <div className="grid grid--care">
            {careTips.map((tip) => (
              <article key={tip.title} className="card card--tip">
                <span className="card__icon" aria-hidden="true">{tip.icon}</span>
                <h3 className="card__title">{tip.title}</h3>
                <p className="card__text">{tip.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section facts">
        <div className="container">
          <h2 className="section__title">Интересные факты о кошках</h2>
          <div className="facts__list">
            {facts.map((fact, index) => (
              <blockquote key={index} className="fact">
                <span className="fact__icon">★</span>
                <p className="fact__text">{fact}</p>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="section about-project">
        <div className="container about-project__grid">
          <div className="about-project__content">
            <h2 className="section__title">О проекте «Мир Кошек»</h2>
            <p className="section__subtitle">
              Мы создаём пространство, где каждый любитель кошек найдёт проверенные знания, искренние истории и
              поддержку единомышленников.
            </p>
            <ul className="list list--check">
              <li>Актуальные статьи, основанные на ветеринарных рекомендациях и исследовательских данных.</li>
              <li>Советы от практикующих специалистов и опытных хозяев.</li>
              <li>Красивые подборки пород с простыми фильтрами для быстрого поиска.</li>
            </ul>
            <Link to="/interesnoe" className="button button--primary">
              Читать вдохновляющие истории
            </Link>
          </div>
          <div className="about-project__team">
            {team.map((member) => (
              <article key={member.name} className="card card--team">
                <img src={member.image} alt={member.name} className="card__image" loading="lazy" />
                <div className="card__body">
                  <h3 className="card__title">{member.name}</h3>
                  <p className="card__text">{member.role}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section testimonials">
        <div className="container">
          <h2 className="section__title">Отзывы наших читателей</h2>
          <div className="grid grid--testimonials">
            {testimonials.map((testimonial) => (
              <article key={testimonial.name} className="card card--testimonial">
                <div className="card__header">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="card__avatar"
                    loading="lazy"
                  />
                  <div>
                    <h3 className="card__title">{testimonial.name}</h3>
                    <span className="card__subtitle">Читатель</span>
                  </div>
                </div>
                <p className="card__text">{testimonial.quote}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section contact-preview">
        <div className="container contact-preview__inner">
          <div>
            <h2 className="section__title">Нужна помощь или хотите поделиться историей?</h2>
            <p className="section__subtitle">
              Напишите нам, и мы подскажем, как сделать жизнь ваших питомцев ещё комфортнее. Делитесь вопросами,
              историями и предложениями.
            </p>
          </div>
          <div className="contact-preview__details">
            <a className="contact-preview__link" href="tel:+74951234567">
              +7 (495) 123-45-67
            </a>
            <a className="contact-preview__link" href="mailto:info@mir-koshek.ru">
              info@mir-koshek.ru
            </a>
            <Link to="/kontakty" className="button button--ghost">
              Перейти к контактам
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;