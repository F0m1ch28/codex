import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';

const initialState = {
  name: '',
  email: '',
  message: ''
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите имя.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите адрес электронной почты.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Введите корректный email.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите, что вас интересует.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setFormData(initialState);
      navigate('/spasibo', { replace: true });
    }
  };

  return (
    <div className="page page--contacts">
      <Helmet>
        <title>Контакты «Мир Кошек» — напишите нам</title>
        <meta
          name="description"
          content="Свяжитесь с редакцией «Мир Кошек»: адрес, телефон, email и форма обратной связи для вопросов и предложений."
        />
        <meta
          name="keywords"
          content="контакты, написать Мир Кошек, телефон, email"
        />
      </Helmet>
      <div className="container page__container">
        <h1 className="page__title">Контакты</h1>
        <div className="contacts__grid">
          <div className="contacts__info">
            <h2 className="page-section__title">Мы на связи</h2>
            <p className="page-section__text">
              Команда «Мир Кошек» открыта для ваших вопросов, идей и историй. Мы ответим на сообщения в течение двух
              рабочих дней.
            </p>
            <ul className="list list--contact">
              <li><strong>Адрес:</strong> г. Москва, ул. Кошачья, д. 15</li>
              <li><strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
              <li><strong>Email:</strong> <a href="mailto:info@mir-koshek.ru">info@mir-koshek.ru</a></li>
            </ul>
          </div>
          <form className="form" onSubmit={handleSubmit} noValidate>
            <h2 className="form__title">Напишите нам</h2>
            <label className="form__label" htmlFor="name">
              Имя
              <input
                className={"form__input ${errors.name ? 'form__input--error' : ''}"}
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
            </label>
            {errors.name && (
              <span className="form__error" id="name-error">
                {errors.name}
              </span>
            )}

            <label className="form__label" htmlFor="email">
              Email
              <input
                className={"form__input ${errors.email ? 'form__input--error' : ''}"}
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
            </label>
            {errors.email && (
              <span className="form__error" id="email-error">
                {errors.email}
              </span>
            )}

            <label className="form__label" htmlFor="message">
              Сообщение
              <textarea
                className={"form__textarea ${errors.message ? 'form__textarea--error' : ''}"}
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows="5"
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
            </label>
            {errors.message && (
              <span className="form__error" id="message-error">
                {errors.message}
              </span>
            )}

            <button type="submit" className="button button--primary form__submit">
              Отправить сообщение
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactsPage;