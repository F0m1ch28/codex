import React from 'react';
import { Helmet } from 'react-helmet-async';

const TermsOfUsePage = () => (
  <div className="page page--terms">
    <Helmet>
      <title>Условия использования — Мир Кошек</title>
      <meta
        name="description"
        content="Правила пользования сайтом «Мир Кошек»: ответственность, авторские права, порядок использования материалов."
      />
    </Helmet>
    <div className="container page__container">
      <h1 className="page__title">Условия использования</h1>
      <section className="page-section">
        <h2 className="page-section__title">1. Общие положения</h2>
        <p className="page-section__text">
          Сайт «Мир Кошек» предназначен для распространения информационных материалов о кошках. Используя сайт, вы
          соглашаетесь соблюдать действующее законодательство Российской Федерации и условия, изложенные ниже.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">2. Авторские права</h2>
        <p className="page-section__text">
          Все тексты, изображения и графические элементы являются интеллектуальной собственностью редакции или
          предоставлены с согласия авторов. Перепечатка возможна только при наличии активной ссылки на источник.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">3. Ограничение ответственности</h2>
        <p className="page-section__text">
          Материалы носят информационный характер. Перед применением рекомендаций, связанных со здоровьем питомца,
          проконсультируйтесь с лицензированным специалистом.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">4. Обратная связь</h2>
        <p className="page-section__text">
          По вопросам использования материалов и предложений по сотрудничеству пишите на info@mir-koshek.ru.
        </p>
      </section>
    </div>
  </div>
);

export default TermsOfUsePage;