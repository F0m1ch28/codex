import React from 'react';
import { Helmet } from 'react-helmet-async';

const PrivacyPolicyPage = () => (
  <div className="page page--policy">
    <Helmet>
      <title>Политика конфиденциальности — Мир Кошек</title>
      <meta
        name="description"
        content="Политика конфиденциальности сайта «Мир Кошек»: какие данные мы собираем и как их защищаем."
      />
    </Helmet>
    <div className="container page__container">
      <h1 className="page__title">Политика конфиденциальности</h1>
      <section className="page-section">
        <h2 className="page-section__title">1. Сбор информации</h2>
        <p className="page-section__text">
          Мы обрабатываем только те персональные данные, которые пользователь добровольно отправляет через форму
          обратной связи: имя, email и текст сообщения. Данные используются исключительно для ответа на запрос.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">2. Хранение данных</h2>
        <p className="page-section__text">
          Сообщения хранятся в защищённых почтовых сервисах. Доступ имеют только сотрудники «Мир Кошек», работающие
          с обращениями читателей.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">3. Передача третьим лицам</h2>
        <p className="page-section__text">
          Мы не передаём персональные данные сторонним организациям, кроме случаев, предусмотренных законодательством
          РФ.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">4. Защита данных</h2>
        <p className="page-section__text">
          Мы используем шифрование в процессе передачи данных и регулярно обновляем программное обеспечение, чтобы
          обеспечить безопасность информации.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">5. Контакты</h2>
        <p className="page-section__text">
          По вопросам обработки данных обращайтесь на info@mir-koshek.ru с темой письма «Политика конфиденциальности».
        </p>
      </section>
    </div>
  </div>
);

export const CookiePolicyPage = () => (
  <div className="page page--policy">
    <Helmet>
      <title>Политика использования cookies — Мир Кошек</title>
      <meta
        name="description"
        content="Узнайте, как сайт «Мир Кошек» использует cookies для улучшения удобства и анализа посещаемости."
      />
    </Helmet>
    <div className="container page__container">
      <h1 className="page__title">Политика использования cookies</h1>
      <section className="page-section">
        <h2 className="page-section__title">1. Что такое cookies</h2>
        <p className="page-section__text">
          Cookies — небольшие файлы, которые помогают запоминать настройки и собирать статистику посещений. Они не
          содержат персональных данных.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">2. Какие cookies мы используем</h2>
        <p className="page-section__text">
          Мы применяем функциональные cookies для сохранения предпочтений и аналитические cookies для улучшения
          контента. Вы можете ограничить их использование в настройках браузера.
        </p>
      </section>
      <section className="page-section">
        <h2 className="page-section__title">3. Управление cookies</h2>
        <p className="page-section__text">
          Большинство браузеров позволяют удалять или блокировать cookies. Обратите внимание: отключение некоторых
          файлов может снизить удобство использования сайта.
        </p>
      </section>
    </div>
  </div>
);

export default PrivacyPolicyPage;