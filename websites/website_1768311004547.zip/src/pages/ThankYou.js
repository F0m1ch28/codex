import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';

const ThankYouPage = () => (
  <div className="page page--thankyou">
    <Helmet>
      <title>Спасибо за обращение — Мир Кошек</title>
      <meta
        name="description"
        content="Благодарим за ваше сообщение. Команда «Мир Кошек» обязательно свяжется с вами."
      />
    </Helmet>
    <div className="container page__container page__container--center">
      <h1 className="page__title">Спасибо за вашу искренность!</h1>
      <p className="page__intro">
        Мы получили ваше сообщение и ответим в ближайшее время. Пока ждёте, можете почитать свежие статьи или
        познакомиться с новыми историями о кошках.
      </p>
      <div className="thankyou__actions">
        <Link to="/" className="button button--primary">
          На главную
        </Link>
        <Link to="/interesnoe" className="button button--ghost">
          Читать интересное
        </Link>
      </div>
    </div>
  </div>
);

export default ThankYouPage;