import React from 'react';
import { Helmet } from 'react-helmet-async';

export const CarePage = () => {
  const checkups = [
    {
      title: 'Питание по возрасту',
      details:
        'Котята нуждаются в белке и кальции для роста, взрослым кошкам важно поддерживать оптимальный вес, а питомцам старшего возраста — защищать суставы и сердце.'
    },
    {
      title: 'Уход за шерстью и когтями',
      details:
        'Регулярное расчёсывание предотвращает колтуны и снижает количество шерсти в доме. Когти подрезают каждые 2-3 недели, используя специальные ножницы.'
    },
    {
      title: 'Гигиена и профилактика',
      details:
        'Подбирайте удобный лоток и наполнитель, поддерживайте чистоту мисок и следите за графиком вакцинации и обработки от паразитов.'
    },
    {
      title: 'Контроль самочувствия',
      details:
        'Измеряйте вес, наблюдайте за аппетитом и настроением. Малейшие изменения — повод обратиться к ветеринару заранее.'
    }
  ];

  return (
    <div className="page page--care">
      <Helmet>
        <title>Уход и здоровье кошек — полезные рекомендации</title>
        <meta
          name="description"
          content="Узнайте, как заботиться о здоровье кошки: питание, гигиена, профилактика заболеваний, плановые осмотры."
        />
        <meta
          name="keywords"
          content="уход за кошкой, здоровье кошки, кормление, вакцинация"
        />
      </Helmet>
      <div className="container page__container">
        <h1 className="page__title">Уход и здоровье</h1>
        <p className="page__intro">
          Любовь к питомцу проявляется в ежедневных привычках. Мы подготовили системные рекомендации, которые помогут
          сохранить здоровье и бодрость кошки на долгие годы.
        </p>
        <div className="page__sections">
          {checkups.map((item) => (
            <section key={item.title} className="page-section">
              <h2 className="page-section__title">{item.title}</h2>
              <p className="page-section__text">{item.details}</p>
            </section>
          ))}
        </div>
        <section className="page-section">
          <h2 className="page-section__title">Аптечка первой помощи</h2>
          <p className="page-section__text">
            Держите под рукой антисептик, стерильные салфетки, сорбент, термометр и контакты круглосуточного
            ветеринарного центра. Никогда не занимайтесь самолечением без консультации специалиста.
          </p>
        </section>
      </div>
    </div>
  );
};