import React, { useEffect, useState } from 'react';

const COOKIE_KEY = 'mir-koshek-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Уведомление о cookies">
      <div className="cookie-banner__content">
        <p>
          Мы используем cookies, чтобы сайт «Мир Кошек» работал стабильно и был удобен. Продолжая пользоваться
          сайтом, вы соглашаетесь с нашей <a href="/politika-cookie">политикой использования cookies</a>.
        </p>
      </div>
      <button type="button" className="cookie-banner__button" onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;