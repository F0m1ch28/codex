import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleClose = () => {
    setMenuOpen(false);
  };

  return (
    <header className="header" role="banner">
      <div className="header__inner container">
        <Link to="/" className="header__logo" onClick={handleClose} aria-label="На главную страницу">
          Мир Кошек
        </Link>
        <nav className={"nav ${menuOpen ? 'nav--open' : ''}"} aria-label="Основная навигация">
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? 'nav__link nav__link--active' : 'nav__link')}
            onClick={handleClose}
            end
          >
            Главная
          </NavLink>
          <NavLink
            to="/porody-koshek"
            className={({ isActive }) => (isActive ? 'nav__link nav__link--active' : 'nav__link')}
            onClick={handleClose}
          >
            Породы
          </NavLink>
          <NavLink
            to="/uhod-i-zdorove"
            className={({ isActive }) => (isActive ? 'nav__link nav__link--active' : 'nav__link')}
            onClick={handleClose}
          >
            Уход и здоровье
          </NavLink>
          <NavLink
            to="/povedenie"
            className={({ isActive }) => (isActive ? 'nav__link nav__link--active' : 'nav__link')}
            onClick={handleClose}
          >
            Поведение
          </NavLink>
          <NavLink
            to="/interesnoe"
            className={({ isActive }) => (isActive ? 'nav__link nav__link--active' : 'nav__link')}
            onClick={handleClose}
          >
            Интересное
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) => (isActive ? 'nav__link nav__link--active' : 'nav__link')}
            onClick={handleClose}
          >
            Контакты
          </NavLink>
        </nav>
        <button
          type="button"
          className={"header__burger ${menuOpen ? 'header__burger--open' : ''}"}
          onClick={handleToggle}
          aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;