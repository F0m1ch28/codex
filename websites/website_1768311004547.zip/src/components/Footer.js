import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="footer">
    <div className="container footer__grid">
      <div className="footer__brand">
        <h2 className="footer__title">Мир Кошек</h2>
        <p className="footer__text">
          Уютный дом для всех любителей кошек. Мы помогаем понимать, любить и заботиться о хвостатых друзьях.
        </p>
        <div className="footer__social">
          <a href="https://vk.com" target="_blank" rel="noopener noreferrer" aria-label="Мы во ВКонтакте">
            <span>VK</span>
          </a>
          <a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Наш Telegram">
            <span>TG</span>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="Наш YouTube">
            <span>YT</span>
          </a>
        </div>
      </div>
      <div className="footer__column">
        <h3 className="footer__subtitle">Навигация</h3>
        <ul className="footer__list">
          <li><Link to="/">Главная</Link></li>
          <li><Link to="/porody-koshek">Породы кошек</Link></li>
          <li><Link to="/uhod-i-zdorove">Уход и здоровье</Link></li>
          <li><Link to="/povedenie">Поведение</Link></li>
          <li><Link to="/interesnoe">Интересное</Link></li>
        </ul>
      </div>
      <div className="footer__column">
        <h3 className="footer__subtitle">Контакты</h3>
        <ul className="footer__list">
          <li>Адрес: г. Москва, ул. Кошачья, д. 15</li>
          <li>
            <Link to="/kontakty">Телефон: +7 (495) 123-45-67</Link>
          </li>
          <li>
            <Link to="/kontakty">Email: info@mir-koshek.ru</Link>
          </li>
        </ul>
      </div>
      <div className="footer__column">
        <h3 className="footer__subtitle">Правовая информация</h3>
        <ul className="footer__list">
          <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
          <li><Link to="/usloviya-ispolzovaniya">Условия использования</Link></li>
          <li><Link to="/politika-cookie">Политика использования cookies</Link></li>
        </ul>
      </div>
    </div>
    <div className="footer__bottom">
      <p>© {new Date().getFullYear()} Мир Кошек. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;