import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

const ScrollToTopButton = () => {
  const [visible, setVisible] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  useEffect(() => {
    const toggleVisibility = () => {
      setVisible(window.scrollY > 400);
    };

    window.addEventListener('scroll', toggleVisibility, { passive: true });
    return () => {
      window.removeEventListener('scroll', toggleVisibility);
    };
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      className={"scroll-top ${visible ? 'scroll-top--visible' : ''}"}
      onClick={handleClick}
      aria-label="Вернуться наверх страницы"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;