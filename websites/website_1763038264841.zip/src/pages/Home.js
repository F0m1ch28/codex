import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Сложных дел выиграно', value: 365 },
  { label: 'Корпоративных клиентов', value: 128 },
  { label: 'Партнёрских программ', value: 54 },
  { label: 'Лет практики экспертов', value: 18 }
];

const servicesData = [
  {
    title: 'Комплексное сопровождение бизнеса',
    description: 'Разработка юридической стратегии, анализ рисков и сопровождение сделок от идеи до закрытия.',
    icon: '⚖️'
  },
  {
    title: 'Судебное представительство',
    description: 'Защищаем интересы клиентов в арбитражных судах и судах общей юрисдикции при спорах любой сложности.',
    icon: '🛡️'
  },
  {
    title: 'Корпоративное право и M&A',
    description: 'Структурирование сделок, due diligence, договоры и правовая интеграция новых активов.',
    icon: '📑'
  },
  {
    title: 'Правовая аналитика и комплаенс',
    description: 'Внедряем комплаенс-системы, проводим аудит, обучаем команды управлять регуляторными изменениями.',
    icon: '🧭'
  }
];

const processSteps = [
  { title: 'Диагностика', text: 'Выявляем ключевые запросы, оцениваем риски, формируем карту задач.' },
  { title: 'Стратегия', text: 'Готовим дорожную карту действий, согласуем критерии успеха и сроки.' },
  { title: 'Реализация', text: 'Ведём переговоры, готовим документы, сопровождаем процесс на каждом этапе.' },
  { title: 'Контроль результата', text: 'Анализируем итоги, регулируем повторные вопросы, закрепляем изменения.' }
];

const testimonials = [
  {
    quote: 'Команда Advocate Solutions помогла быстро перестроить договорную базу и успешно пройти налоговую проверку. Высокий уровень аналитики и командной работы.',
    name: 'Ирина Михайлова',
    role: 'Финансовый директор, IT-компания'
  },
  {
    quote: 'Редко встречаешь юристов, которые говорят с бизнесом на одном языке. С их помощью мы закрыли крупную сделку без осложнений.',
    name: 'Алексей Минин',
    role: 'Управляющий партнёр инвестиционного фонда'
  },
  {
    quote: 'Получили грамотное сопровождение по трудовым спорам. Юристы переосмыслили процессы и помогли снизить нагрузку на HR.',
    name: 'Наталья Чистякова',
    role: 'Директор по персоналу, ритейл'
  }
];

const faqItems = [
  {
    question: 'Как быстро мы можем начать работу?',
    answer: 'После первичной консультации мы фиксируем запрос, подписываем соглашение и назначаем ответственного партнёра. Обычно стартуем в течение 1–2 рабочих дней.'
  },
  {
    question: 'Ведёте ли вы проекты под NDA?',
    answer: 'Да, мы соблюдаем конфиденциальность и подписываем необходимые соглашения до начала обмена информацией.'
  },
  {
    question: 'Работаете ли вы с региональными компаниями?',
    answer: 'Мы сопровождаем клиентов по всей России и за её пределами, используя гибридный формат — очные и онлайн встречи.'
  },
  {
    question: 'Можно ли получить разовую консультацию?',
    answer: 'Да, мы предоставляем индивидуальные консультации, после которых вы получаете краткий письменный обзор рекомендаций.'
  }
];

const teamMembers = [
  {
    name: 'Марина Журавлёва',
    role: 'Управляющий партнёр',
    expertise: 'Корпоративное право, M&A',
    image: 'https://picsum.photos/400/400?random=3',
    bio: '15 лет практики, автор программы юридической безопасности бизнеса.'
  },
  {
    name: 'Андрей Ковалёв',
    role: 'Партнёр по судебной практике',
    expertise: 'Арбитраж, досудебное урегулирование',
    image: 'https://picsum.photos/400/400?random=13',
    bio: 'Более 200 успешно разрешённых споров в арбитражных судах.'
  },
  {
    name: 'Ольга Литвинова',
    role: 'Руководитель практики комплаенс',
    expertise: 'Коммерческое право, регуляторика',
    image: 'https://picsum.photos/400/400?random=23',
    bio: 'Помогла внедрить комплаенс-системы в 30+ компаниях.'
  }
];

const projects = [
  {
    title: 'Правовое сопровождение цифрового сервиса',
    category: 'Бизнес',
    description: 'Комплексная реструктуризация договорной модели и защита интеллектуальных прав.',
    image: 'https://picsum.photos/1200/800?random=4'
  },
  {
    title: 'Арбитражное дело в сфере строительства',
    category: 'Споры',
    description: 'Защита интересов девелопера и взыскание ущерба с подрядчика.',
    image: 'https://picsum.photos/1200/800?random=14'
  },
  {
    title: 'Комплаенс-программа для финансового холдинга',
    category: 'Комплаенс',
    description: 'Разработка внутренних политик, обучение и автоматизация мониторинга.',
    image: 'https://picsum.photos/1200/800?random=24'
  },
  {
    title: 'Досудебное урегулирование налогового спора',
    category: 'Споры',
    description: 'Сокращение доначислений на 72% благодаря комплексной защите аргументов.',
    image: 'https://picsum.photos/1200/800?random=34'
  }
];

const blogPosts = [
  {
    title: 'Как подготовиться к налоговой проверке в 2024 году',
    date: '12 марта 2024',
    category: 'Комплаенс',
    excerpt: 'Шаги, которые помогут бизнесу пройти проверку без штрафов — от подготовки документов до работы с инспекторами.',
    link: '#'
  },
  {
    title: 'Корпоративный договор: самые частые ошибки',
    date: '27 февраля 2024',
    category: 'Корпоративное право',
    excerpt: 'Разбираем ошибки, которые приводят к корпоративным конфликтам, и предлагаем практические решения.',
    link: '#'
  },
  {
    title: 'Digital evidence: новые правила игры в судах',
    date: '15 января 2024',
    category: 'Судебная практика',
    excerpt: 'Почему цифровые доказательства стали решающим фактором и как правильно их формировать.',
    link: '#'
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [faqOpen, setFaqOpen] = useState(0);
  const [statsValues, setStatsValues] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const [skillsVisible, setSkillsVisible] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [ctaForm, setCtaForm] = useState({ name: '', email: '', message: '' });
  const [ctaErrors, setCtaErrors] = useState({});
  const [ctaSuccess, setCtaSuccess] = useState('');
  const [loadedImages, setLoadedImages] = useState({});
  const statsRef = useRef(null);
  const skillsRef = useRef(null);

  const filteredProjects = useMemo(() => {
    if (selectedCategory === 'Все') return projects;
    return projects.filter((project) => project.category === selectedCategory);
  }, [selectedCategory]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !statsAnimated) {
          setStatsAnimated(true);
          statsData.forEach((stat, index) => {
            const duration = 1600;
            const start = performance.now();
            const animate = (time) => {
              const progress = Math.min((time - start) / duration, 1);
              setStatsValues((prev) => {
                const updated = [...prev];
                updated[index] = Math.floor(progress * stat.value);
                return updated;
              });
              if (progress < 1) requestAnimationFrame(animate);
              else {
                setStatsValues((prev) => {
                  const updated = [...prev];
                  updated[index] = stat.value;
                  return updated;
                });
              }
            };
            requestAnimationFrame(animate);
          });
        }
      },
      { threshold: 0.3 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, [statsAnimated]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setSkillsVisible(true);
        }
      },
      { threshold: 0.2 }
    );
    if (skillsRef.current) {
      observer.observe(skillsRef.current);
    }
    return () => observer.disconnect();
  }, []);

  const handleFaqToggle = (index) => {
    setFaqOpen((prev) => (prev === index ? null : index));
  };

  const handleCtaChange = (event) => {
    const { name, value } = event.target;
    setCtaForm((prev) => ({ ...prev, [name]: value }));
  };

  const validateCta = () => {
    const errors = {};
    if (!ctaForm.name.trim()) errors.name = 'Укажите ваше имя';
    if (!ctaForm.email.trim()) errors.email = 'Введите рабочий email';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ctaForm.email)) errors.email = 'Некорректный формат email';
    if (!ctaForm.message.trim()) errors.message = 'Опишите ваш запрос';
    return errors;
  };

  const handleCtaSubmit = (event) => {
    event.preventDefault();
    const errors = validateCta();
    setCtaErrors(errors);
    if (Object.keys(errors).length === 0) {
      setCtaSuccess('Спасибо! Мы свяжемся с вами в течение рабочего дня.');
      setCtaForm({ name: '', email: '', message: '' });
      setTimeout(() => setCtaSuccess(''), 6000);
    } else {
      setCtaSuccess('');
    }
  };

  const handleImageLoad = (id) => {
    setLoadedImages((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <>
      <Helmet>
        <title>Advocate Solutions — современная юридическая фирма в Москве</title>
        <meta
          name="description"
          content="Юридическая фирма Advocate Solutions в Москве: адвокаты, судебная защита, сопровождение бизнеса, комплаенс и стратегия. Современный подход к правовой поддержке."
        />
        <meta name="keywords" content="юридические услуги, адвокат, правовая помощь, консультация, Москва" />
      </Helmet>
      <div className={styles.hero}>
        <div className={styles.heroOverlay} />
        <picture>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Команда юристов Advocate Solutions"
            className={styles.heroImage}
            loading="eager"
          />
        </picture>
        <div className={styles.heroContent}>
          <span className={styles.heroKicker}>юридическая архитектура будущего</span>
          <h1 className={styles.heroTitle}>
            Стратегическая правовая поддержка бизнеса и лидеров в Москве
          </h1>
          <p className={styles.heroSubtitle}>
            Команда Advocate Solutions объединяет опыт адвокатов, аналитиков и переговорщиков, чтобы вы получили
            результат без лишних сложностей. Мы строим доверие и цифровые решения вокруг ваших задач.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className="btn btn--primary">
              Запланировать консультацию
            </Link>
            <a href="#services" className="btn btn--ghost">
              Наши практики
            </a>
          </div>
        </div>
      </div>

      <section className={`${styles.section} ${styles.why}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">почему advocate solutions</span>
          <h2>Больше, чем юридическая поддержка</h2>
          <p>
            Мы смотрим шире судебных практик: видим стратегию компании, цифровые процессы и команды, которые должны
            чувствовать безопасность.
          </p>
        </div>
        <div className={styles.whyGrid}>
          <article className={styles.whyCard}>
            <div className={styles.whyIcon} aria-hidden="true">🧠</div>
            <h3>Глубокая аналитика</h3>
            <p>Работаем с данными и инсайтами, чтобы обосновать позицию и заранее просчитать сценарии.</p>
          </article>
          <article className={styles.whyCard}>
            <div className={styles.whyIcon} aria-hidden="true">🤝</div>
            <h3>Партнёрский подход</h3>
            <p>Вовлекаемся в контекст команды, общаемся простым языком, обеспечиваем прозрачную коммуникацию.</p>
          </article>
          <article className={styles.whyCard}>
            <div className={styles.whyIcon} aria-hidden="true">🚀</div>
            <h3>Цифровые решения</h3>
            <p>Используем технологии для управления документами, сроками и статусами дел в реальном времени.</p>
          </article>
          <article className={styles.whyCard}>
            <div className={styles.whyIcon} aria-hidden="true">🌍</div>
            <h3>Международный опыт</h3>
            <p>Работаем с трансграничными проектами, международным правом и поддерживаем английский язык.</p>
          </article>
        </div>
      </section>

      <section className={`${styles.section} ${styles.stats}`} ref={statsRef} aria-label="Достижения компании">
        {statsData.map((stat, index) => (
          <div key={stat.label} className={styles.statCard}>
            <span className={styles.statValue} aria-live="polite">{statsValues[index]}+</span>
            <p className={styles.statLabel}>{stat.label}</p>
          </div>
        ))}
      </section>

      <section id="services" className={`${styles.section} ${styles.services}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">юридические практики</span>
          <h2>Комплекс услуг Advocate Solutions</h2>
          <p>
            Мы создаём юридическую стратегию, которая поддерживает каждый этап развития бизнеса — от старта и первых
            контрактов до масштабирования и выхода на новые рынки.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {servicesData.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/uslugi" className={styles.serviceLink} aria-label={`Подробнее о услуге ${service.title}`}>
                Узнать детали →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.about}`}>
        <div className={styles.aboutContent}>
          <span className="section-kicker">о нас</span>
          <h2>Команда, ориентированная на результат</h2>
          <p>
            Advocate Solutions выросла из идеи объединить гибкость бутик-бюро и масштабность международной практики.
            Мы выстраиваем процессы, позволяющие предпринимателям и корпорациям принимать смелые решения.
          </p>
          <ul className={styles.aboutList}>
            <li>Работаем с цифрами, фактами и людьми — открыто и экологично.</li>
            <li>Нас выбирают за стратегическое мышление и скорость реакции.</li>
            <li>Обучаем команды клиентов управлять юридическими рисками самостоятельно.</li>
          </ul>
        </div>
        <div className={styles.aboutSkills} ref={skillsRef}>
          <div className={styles.skill}>
            <div className={styles.skillHeader}>
              <span>Корпоративное право</span>
              <span>95%</span>
            </div>
            <div className={styles.skillTrack}>
              <div className={styles.skillBar} style={{ width: skillsVisible ? '95%' : '0%' }} />
            </div>
          </div>
          <div className={styles.skill}>
            <div className={styles.skillHeader}>
              <span>Судебные споры</span>
              <span>92%</span>
            </div>
            <div className={styles.skillTrack}>
              <div className={styles.skillBar} style={{ width: skillsVisible ? '92%' : '0%' }} />
            </div>
          </div>
          <div className={styles.skill}>
            <div className={styles.skillHeader}>
              <span>Комплаенс и риск-менеджмент</span>
              <span>88%</span>
            </div>
            <div className={styles.skillTrack}>
              <div className={styles.skillBar} style={{ width: skillsVisible ? '88%' : '0%' }} />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.process}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">процесс</span>
          <h2>Работаем по прозрачной и гибкой методологии</h2>
        </div>
        <div className={styles.timeline} aria-label="Этапы работы">
          {processSteps.map((step, index) => (
            <div key={step.title} className={styles.timelineItem}>
              <div className={styles.timelineBadge}>{index + 1}</div>
              <div>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonials}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">отзывы</span>
          <h2>Нам доверяют лидеры отраслей</h2>
        </div>
        <div className={styles.testimonialCarousel}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
              aria-hidden={index !== activeTestimonial}
            >
              <p className={styles.testimonialQuote}>{testimonial.quote}</p>
              <p className={styles.testimonialAuthor}>{testimonial.name}</p>
              <p className={styles.testimonialRole}>{testimonial.role}</p>
            </article>
          ))}
        </div>
        <div className={styles.carouselControls} role="tablist">
          {testimonials.map((_, index) => (
            <button
              key={index}
              type="button"
              aria-label={`Отзыв ${index + 1}`}
              aria-selected={activeTestimonial === index}
              className={`${styles.carouselDot} ${activeTestimonial === index ? styles.carouselDotActive : ''}`}
              onClick={() => setActiveTestimonial(index)}
            />
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.team}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">команда</span>
          <h2>Эксперты Advocate Solutions</h2>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImageWrapper}>
                <img
                  src={member.image}
                  alt={`${member.name} — ${member.role}`}
                  className={`${styles.teamImage} ${loadedImages[member.name] ? styles.loaded : ''}`}
                  loading="lazy"
                  onLoad={() => handleImageLoad(member.name)}
                />
                <div className={styles.teamOverlay}>
                  <p>{member.bio}</p>
                </div>
              </div>
              <div className={styles.teamInfo}>
                <p className={styles.teamName}>{member.name}</p>
                <p className={styles.teamRole}>{member.role}</p>
                <p className={styles.teamExpertise}>{member.expertise}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.projects}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">кейсы</span>
          <h2>Проекты, которыми мы гордимся</h2>
        </div>
        <div className={styles.projectFilters} role="tablist" aria-label="Фильтр проектов">
          {['Все', 'Бизнес', 'Споры', 'Комплаенс'].map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${selectedCategory === category ? styles.filterButtonActive : ''}`}
              onClick={() => setSelectedCategory(category)}
              aria-pressed={selectedCategory === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img
                  src={project.image}
                  alt={project.title}
                  className={`${styles.projectImage} ${loadedImages[project.title] ? styles.loaded : ''}`}
                  loading="lazy"
                  onLoad={() => handleImageLoad(project.title)}
                />
              </div>
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.faq}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">faq</span>
          <h2>Частые вопросы клиентов</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div key={item.question} className={styles.faqItem}>
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => handleFaqToggle(index)}
                aria-expanded={faqOpen === index}
              >
                {item.question}
                <span>{faqOpen === index ? '−' : '+'}</span>
              </button>
              <div
                className={`${styles.faqAnswer} ${faqOpen === index ? styles.faqAnswerOpen : ''}`}
                aria-hidden={faqOpen !== index}
              >
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.blog}`}>
        <div className={styles.sectionHead}>
          <span className="section-kicker">инсайты</span>
          <h2>Свежие материалы блога</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <header>
                <span className={styles.blogCategory}>{post.category}</span>
                <h3>{post.title}</h3>
                <time dateTime={post.date}>{post.date}</time>
              </header>
              <p>{post.excerpt}</p>
              <a href={post.link} className={styles.blogLink}>
                Читать далее →
              </a>
            </article>
          ))}
        </div>
        <div className={styles.blogCta}>
          <Link to="/blog" className="btn btn--ghost">
            Все публикации
          </Link>
        </div>
      </section>

      <section className={`${styles.section} ${styles.cta}`}>
        <div className={styles.ctaCard}>
          <div className={styles.ctaContent}>
            <span className="section-kicker">связаться</span>
            <h2>Получите персональное юридическое решение</h2>
            <p>
              Заполните форму — и партнёр Advocate Solutions свяжется с вами, чтобы уточнить детали, предложить
              стратегию и согласовать первые шаги.
            </p>
            <ul className={styles.ctaList}>
              <li>Первичная консультация онлайн или в офисе на Тверской, 15.</li>
              <li>Оценка рисков и предложений в течение 48 часов.</li>
              <li>Персональный менеджер и защищённый канал коммуникаций.</li>
            </ul>
          </div>
          <form className={styles.ctaForm} onSubmit={handleCtaSubmit} noValidate>
            <label htmlFor="cta-name">Имя</label>
            <input
              id="cta-name"
              name="name"
              type="text"
              placeholder="Ваше имя"
              value={ctaForm.name}
              onChange={handleCtaChange}
              aria-invalid={ctaErrors.name ? 'true' : 'false'}
            />
            {ctaErrors.name && <span className={styles.error}>{ctaErrors.name}</span>}

            <label htmlFor="cta-email">Рабочий email</label>
            <input
              id="cta-email"
              name="email"
              type="email"
              placeholder="company@domain.ru"
              value={ctaForm.email}
              onChange={handleCtaChange}
              aria-invalid={ctaErrors.email ? 'true' : 'false'}
            />
            {ctaErrors.email && <span className={styles.error}>{ctaErrors.email}</span>}

            <label htmlFor="cta-message">Запрос</label>
            <textarea
              id="cta-message"
              name="message"
              rows="4"
              placeholder="Опишите суть задачи или проблему"
              value={ctaForm.message}
              onChange={handleCtaChange}
              aria-invalid={ctaErrors.message ? 'true' : 'false'}
            />
            {ctaErrors.message && <span className={styles.error}>{ctaErrors.message}</span>}

            <button type="submit" className="btn btn--primary">
              Отправить запрос
            </button>
            {ctaSuccess && <p className={styles.success}>{ctaSuccess}</p>}
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;