import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = useState({ name: '', company: '', email: '', phone: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Введите ваше имя';
    if (!form.company.trim()) newErrors.company = 'Укажите компанию или статус';
    if (!form.email.trim()) newErrors.email = 'Укажите email';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) newErrors.email = 'Некорректный email';
    if (!form.message.trim()) newErrors.message = 'Опишите задачу';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = validate();
    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      setStatus('Спасибо! Мы получили ваш запрос и свяжемся с вами.');
      setForm({ name: '', company: '', email: '', phone: '', message: '' });
      setTimeout(() => setStatus(''), 6000);
    } else {
      setStatus('');
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты Advocate Solutions — юридическая фирма в Москве</title>
        <meta
          name="description"
          content="Свяжитесь с юридической фирмой Advocate Solutions: телефон, адрес офиса на Тверской в Москве, электронная почта, форма обратной связи."
        />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <h1>Контактная информация</h1>
          <p>Готовы обсудить вашу задачу в формате онлайн-встречи или в нашем офисе.</p>
        </div>
      </section>

      <section className={styles.contacts}>
        <div className={styles.info}>
          <h2>Офис Advocate Solutions</h2>
          <p>ул. Тверская, д. 15, Москва, 125009</p>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:info@advocate-solutions.ru">info@advocate-solutions.ru</a>
          <div className={styles.schedule}>
            <p><strong>График работы:</strong></p>
            <p>Пн–Пт: 09:30 — 19:00</p>
            <p>Сб: по предварительной записи</p>
          </div>
        </div>
        <div className={styles.mapWrapper} aria-label="Карта расположения офиса">
          <iframe
            title="Офис Advocate Solutions на карте"
            src="https://yandex.ru/map-widget/v1/?um=constructor%3A8f6d7326e46d9f228aa0eb2a03598313d8b15f2d4dec8aaf3c1ebea4bf7a1e33&amp;source=constructor"
            width="100%"
            height="100%"
            frameBorder="0"
          />
        </div>
      </section>

      <section className={styles.formSection}>
        <div className={styles.formIntro}>
          <span className="section-kicker">обратная связь</span>
          <h2>Расскажите о задаче</h2>
          <p>
            Мы предложим формат сотрудничества и отправим перечень документов для первичного анализа. Используем
            защищённые каналы связи и NDA по требованию.
          </p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="contact-name">Имя</label>
          <input
            id="contact-name"
            name="name"
            type="text"
            value={form.name}
            onChange={handleChange}
            aria-invalid={errors.name ? 'true' : 'false'}
          />
          {errors.name && <span className={styles.error}>{errors.name}</span>}

          <label htmlFor="contact-company">Компания или статус</label>
          <input
            id="contact-company"
            name="company"
            type="text"
            value={form.company}
            onChange={handleChange}
            aria-invalid={errors.company ? 'true' : 'false'}
          />
          {errors.company && <span className={styles.error}>{errors.company}</span>}

          <label htmlFor="contact-email">Email</label>
          <input
            id="contact-email"
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            aria-invalid={errors.email ? 'true' : 'false'}
          />
          {errors.email && <span className={styles.error}>{errors.email}</span>}

          <label htmlFor="contact-phone">Телефон (по желанию)</label>
          <input
            id="contact-phone"
            name="phone"
            type="tel"
            value={form.phone}
            onChange={handleChange}
          />

          <label htmlFor="contact-message">Сообщение</label>
          <textarea
            id="contact-message"
            name="message"
            rows="5"
            value={form.message}
            onChange={handleChange}
            aria-invalid={errors.message ? 'true' : 'false'}
          />
          {errors.message && <span className={styles.error}>{errors.message}</span>}

          <button type="submit" className="btn btn--primary">
            Отправить сообщение
          </button>
          {status && <p className={styles.success}>{status}</p>}
        </form>
      </section>
    </>
  );
};

export default Contact;