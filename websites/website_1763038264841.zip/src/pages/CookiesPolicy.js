import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiesPolicy.module.css';

const CookiesPolicy = () => (
  <>
    <Helmet>
      <title>Политика cookies — Advocate Solutions</title>
      <meta
        name="description"
        content="Политика использования cookies на сайте Advocate Solutions: типы файлов, цели сбора и управление настройками."
      />
    </Helmet>

    <section className={styles.hero}>
      <h1>Политика использования cookies</h1>
      <p>Описание использования файлов cookies и способы управления предпочтениями.</p>
    </section>

    <section className={styles.content}>
      <h2>1. Что такое cookies</h2>
      <p>
        Cookies — небольшие текстовые файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают
        нам анализировать работу ресурса и улучшать пользовательский опыт.
      </p>

      <h2>2. Как мы используем cookies</h2>
      <ul>
        <li>Функциональные cookies — обеспечивают корректную работу сайта.</li>
        <li>Аналитические cookies — помогают оценивать посещаемость и эффективность разделов.</li>
        <li>Маркетинговые cookies — применяются для отображения релевантного контента.</li>
      </ul>

      <h2>3. Управление cookies</h2>
      <p>
        Вы можете самостоятельно управлять cookies через настройки браузера: блокировать их, удалять или настраивать
        уведомления. Учтите, что отключение cookies может ограничить функциональность сайта.
      </p>

      <h2>4. Обновления политики</h2>
      <p>
        Мы периодически пересматриваем Политику cookies. Актуальная версия доступна на странице /politika-cookies.
      </p>

      <h2>5. Контакты</h2>
      <p>По вопросам использования cookies обращайтесь на privacy@advocate-solutions.ru.</p>
    </section>
  </>
);

export default CookiesPolicy;