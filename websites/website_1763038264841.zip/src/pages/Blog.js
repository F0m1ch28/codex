import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Проверка контрагентов: чек-лист 2024',
    date: '2 апреля 2024',
    category: 'Практика',
    excerpt: 'Ключевые шаги проверки партнёров: корпоративные данные, налоговый анализ, судебные кейсы.',
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    title: 'LegalTech: как автоматизация меняет юридические отделы',
    date: '18 марта 2024',
    category: 'Исследование',
    excerpt: 'Разбираем инструменты автоматизации и их влияние на эффективность юридической функции.',
    image: 'https://picsum.photos/800/600?random=62'
  },
  {
    title: 'Медиация как альтернатива суду',
    date: '5 марта 2024',
    category: 'Комментарий',
    excerpt: 'Когда медиативное соглашение эффективнее судебной тяжбы, и как подготовиться к процессу.',
    image: 'https://picsum.photos/800/600?random=72'
  },
  {
    title: 'Новые требования к персональным данным',
    date: '20 февраля 2024',
    category: 'Обновления',
    excerpt: 'Что изменилось в требованиях Роскомнадзора и как адаптировать внутренние политики.',
    image: 'https://picsum.photos/800/600?random=82'
  }
];

const Blog = () => (
  <>
    <Helmet>
      <title>Блог Advocate Solutions — юридические инсайты и аналитика</title>
      <meta
        name="description"
        content="Читаете блог Advocate Solutions: аналитика, рекомендации и новости в сферах корпоративного права, судебной практики и комплаенс."
      />
    </Helmet>

    <section className={styles.hero}>
      <h1>Блог и новости</h1>
      <p>Аналитика, комментарии и практические рекомендации команды Advocate Solutions.</p>
    </section>

    <section className={styles.posts}>
      {posts.map((post) => (
        <article key={post.title} className={styles.postCard}>
          <div className={styles.postImageWrapper}>
            <img src={post.image} alt={post.title} loading="lazy" />
          </div>
          <div className={styles.postContent}>
            <span className={styles.category}>{post.category}</span>
            <h2>{post.title}</h2>
            <time>{post.date}</time>
            <p>{post.excerpt}</p>
            <a href="#" className={styles.readMore}>
              Читать материал →
            </a>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default Blog;