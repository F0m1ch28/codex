import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const historyMilestones = [
  {
    year: '2010',
    title: 'Старт бутик-бюро на Тверской',
    description: 'Команда адвокатов объединилась для сопровождения первых проектов в сфере сложных судебных споров.'
  },
  {
    year: '2014',
    title: 'Выход на корпоративный рынок',
    description: 'Подписаны первые сервисные договоры с крупными холдингами, сформирована практика комплаенс.'
  },
  {
    year: '2018',
    title: 'Цифровая трансформация процессов',
    description: 'Внедрили LegalTech-инструменты для управления задачами, контроля за сроками и коммуникациями с клиентами.'
  },
  {
    year: '2022',
    title: 'Advocate Solutions сегодня',
    description: 'Междисциплинарная команда из 30 экспертов, офис с VR-залом для моделирования переговоров и судебных процессов.'
  }
];

const competencies = [
  { name: 'Корпоративное право и реструктуризация', description: 'Поддерживаем M&A-сделки, выстраиваем корпоративные структуры и внутренние регламенты.' },
  { name: 'Судебная практика и арбитраж', description: 'Готовим стратегию спора, управляем доказательствами, ведём переговоры и представляем интересы в суде.' },
  { name: 'Комплаенс и управление рисками', description: 'Настраиваем процедуры мониторинга, обучаем персонал и подключаемся к внутренним аудитам.' }
];

const values = [
  { title: 'Ответственность', text: 'Мы честно оцениваем риски, не обещаем невозможного и всегда предлагаем альтернативы.' },
  { title: 'Прозрачность', text: 'Каждый этап проекта сопровождается понятной статистикой, подотчётностью и контрольными точками.' },
  { title: 'Инновации', text: 'Используем LegalTech-инструменты, автоматизированные скрипты и аналитические панели для клиентов.' }
];

const leadership = [
  {
    name: 'Илья Романов',
    title: 'Партнёр по развитию бизнеса',
    bio: 'Отвечает за стратегию роста, взаимодействие с ключевыми клиентами и развитие консалтинговых сервисов.',
    focus: 'Бизнес-модели юридической поддержки, digital-экосистемы и ESG-повестка.'
  },
  {
    name: 'Ксения Соколова',
    title: 'Директор по правовой аналитике',
    bio: 'Развивает аналитическое направление, отвечает за подготовку исследований и инсайтов для клиентов.',
    focus: 'Правовые тренды, регуляторные изменения и LegalTech-решения.'
  }
];

const About = () => {
  const [activeTab, setActiveTab] = useState('миссия');

  return (
    <>
      <Helmet>
        <title>Advocate Solutions — история и команда юридической фирмы</title>
        <meta
          name="description"
          content="Узнайте больше об Advocate Solutions: история юридической фирмы, ключевые ценности, команда партнёров и экспертов, подход к работе."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className="section-kicker">о компании</span>
          <h1>Наша история и философия работы</h1>
          <p>
            Мы создали Advocate Solutions, чтобы соединить точность юридической экспертизы, гибкость проектных команд
            и прогрессивный опыт взаимодействия с бизнесом. Всё, что мы делаем, направлено на усиление позиции клиента.
          </p>
        </div>
      </section>

      <section className={styles.mission}>
        <div className={styles.tabs}>
          <button
            type="button"
            className={activeTab === 'миссия' ? styles.tabActive : ''}
            onClick={() => setActiveTab('миссия')}
            aria-pressed={activeTab === 'миссия'}
          >
            Миссия
          </button>
          <button
            type="button"
            className={activeTab === 'подход' ? styles.tabActive : ''}
            onClick={() => setActiveTab('подход')}
            aria-pressed={activeTab === 'подход'}
          >
            Подход
          </button>
          <button
            type="button"
            className={activeTab === 'ценности' ? styles.tabActive : ''}
            onClick={() => setActiveTab('ценности')}
            aria-pressed={activeTab === 'ценности'}
          >
            Ценности
          </button>
        </div>
        <div className={styles.tabContent}>
          {activeTab === 'миссия' && (
            <article>
              <h2>Миссия Advocate Solutions</h2>
              <p>
                Помогаем компаниям и лидерам принимать смелые решения, обеспечивая правовую безопасность и стратегическую
                поддержку. Мы строим долгосрочные партнёрства, основанные на доверии, цифровой прозрачности и глубокой экспертизе.
              </p>
            </article>
          )}
          {activeTab === 'подход' && (
            <article>
              <h2>Подход к работе</h2>
              <ul>
                <li>Команды под конкретные задачи с вовлечением отраслевых экспертов.</li>
                <li>Цифровые инструменты: защищённые кабинеты клиентов, аналитика в реальном времени.</li>
                <li>Дизайн-мышление в юридических услугах: изучаем пользовательский опыт ваших сотрудников и клиентов.</li>
              </ul>
            </article>
          )}
          {activeTab === 'ценности' && (
            <article className={styles.valuesGrid}>
              {values.map((value) => (
                <div key={value.title} className={styles.valueCard}>
                  <h3>{value.title}</h3>
                  <p>{value.text}</p>
                </div>
              ))}
            </article>
          )}
        </div>
      </section>

      <section className={styles.history}>
        <div className="section-head">
          <span className="section-kicker">этапы</span>
          <h2>Ключевые вехи развития</h2>
        </div>
        <div className={styles.timeline}>
          {historyMilestones.map((item) => (
            <div key={item.year} className={styles.milestone}>
              <div className={styles.year}>{item.year}</div>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.competencies}>
        <div className="section-head">
          <span className="section-kicker">компетенции</span>
          <h2>Ключевые направления</h2>
        </div>
        <div className={styles.competencyGrid}>
          {competencies.map((item) => (
            <article key={item.name} className={styles.competencyCard}>
              <h3>{item.name}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.leadership}>
        <div className="section-head">
          <span className="section-kicker">лидерство</span>
          <h2>Партнёры и лидеры практик</h2>
        </div>
        <div className={styles.leadershipGrid}>
          {leadership.map((leader) => (
            <article key={leader.name} className={styles.leaderCard}>
              <h3>{leader.name}</h3>
              <p className={styles.leaderTitle}>{leader.title}</p>
              <p>{leader.bio}</p>
              <div className={styles.focus}>
                <span>Фокус:</span>
                <p>{leader.focus}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default About;