import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const serviceGroups = [
  {
    title: 'Сопровождение бизнеса',
    items: [
      'Правовой аудит и построение юридической функции',
      'Разработка уставных документов, договоров и регламентов',
      'Поддержка инвестиционных проектов и due diligence',
      'Консультирование по вопросам корпоративного управления'
    ],
    image: 'https://picsum.photos/800/600?random=2'
  },
  {
    title: 'Судебная и досудебная защита',
    items: [
      'Арбитражные споры и взыскание задолженности',
      'Судебные процессы в сфере недвижимости и строительства',
      'Защита бизнеса на стадии проверок и расследований',
      'Медиация, переговоры, мировые соглашения'
    ],
    image: 'https://picsum.photos/800/600?random=12'
  },
  {
    title: 'Комплаенс и риск-менеджмент',
    items: [
      'Антикоррупционные и санкционные комплаенс-программы',
      'Налоговый комплаенс и взаимодействие с контролирующими органами',
      'Обучение сотрудников и разработка кодексов поведения',
      'Мониторинг регуляторных изменений и внедрение новых правил'
    ],
    image: 'https://picsum.photos/800/600?random=22'
  }
];

const quickConsult = [
  'Оценка перспектив судебного спора',
  'Проверка договоров и сделок',
  'Правовые риски при выходе на новые рынки',
  'Защита интеллектуальных прав и персональных данных'
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>Услуги юридической фирмы Advocate Solutions</title>
        <meta
          name="description"
          content="Юридические услуги Advocate Solutions: сопровождение бизнеса, судебная защита, комплаенс, стратегические консультации для компаний и предпринимателей."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Юридические практики и экспертиза</h1>
          <p>
            Мы выстраиваем комплексную правовую поддержку: от ежедневной консультационной помощи до стратегических
            проектов, требующих участия партнёров и отраслевых экспертов.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.tabs} role="tablist">
          {serviceGroups.map((group, index) => (
            <button
              key={group.title}
              role="tab"
              aria-selected={activeIndex === index}
              type="button"
              className={`${styles.tab} ${activeIndex === index ? styles.tabActive : ''}`}
              onClick={() => setActiveIndex(index)}
            >
              {group.title}
            </button>
          ))}
        </div>
        <div className={styles.tabPanels}>
          {serviceGroups.map((group, index) => (
            <article
              key={group.title}
              role="tabpanel"
              hidden={activeIndex !== index}
              className={`${styles.panel} ${activeIndex === index ? styles.panelActive : ''}`}
            >
              <div className={styles.panelContent}>
                <h2>{group.title}</h2>
                <ul>
                  {group.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <a href="/kontakty" className="btn btn--primary">
                  Обсудить проект
                </a>
              </div>
              <div className={styles.panelImageWrapper}>
                <img src={group.image} alt={group.title} loading="lazy" />
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.consult}>
        <div className="section-head">
          <span className="section-kicker">консультации</span>
          <h2>Быстрые консультации экспертов</h2>
        </div>
        <div className={styles.consultGrid}>
          {quickConsult.map((item) => (
            <div key={item} className={styles.consultCard}>
              <p>{item}</p>
              <a href="/kontakty" className={styles.consultLink}>
                Запросить консультацию →
              </a>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className="section-head">
          <span className="section-kicker">форматы сотрудничества</span>
          <h2>Подбираем гибкие модели работы</h2>
        </div>
        <div className={styles.processGrid}>
          <article>
            <h3>Legal subscription</h3>
            <p>Юридическая поддержка по подписке с фиксированным количеством часов или задач в месяц.</p>
          </article>
          <article>
            <h3>Проектная команда</h3>
            <p>Формируем междисциплинарную команду под конкретный проект и управляем сроками и результатом.</p>
          </article>
          <article>
            <h3>Партнёрская сессия</h3>
            <p>Проводим стратегические сессии с партнёром, чтобы определить дорожную карту действий и KPI.</p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Services;