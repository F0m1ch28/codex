import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Blog from './pages/Blog';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiesPolicy from './pages/CookiesPolicy';

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
};

const AppLayout = () => (
  <div className="app-shell">
    <Header />
    <main className="main-content" id="main-content">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/o-kompanii" element={<About />} />
        <Route path="/uslugi" element={<Services />} />
        <Route path="/kontakty" element={<Contact />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/usloviya-ispolzovaniya" element={<Terms />} />
        <Route path="/politika-konfidencialnosti" element={<Privacy />} />
        <Route path="/politika-cookies" element={<CookiesPolicy />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

const App = () => (
  <Router>
    <ScrollToTopOnRoute />
    <AppLayout />
  </Router>
);

export default App;