import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMobileMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`} role="banner">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="На главную Advocate Solutions">
          <span className={styles.logoMark}>AS</span>
          <span className={styles.logoText}>Advocate Solutions</span>
        </NavLink>
        <button
          className={`${styles.menuToggle} ${isMobileMenuOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          aria-expanded={isMobileMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Переключение навигации"
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isMobileMenuOpen ? styles.navOpen : ''}`}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            <li>
              <NavLink to="/" end className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink to="/uslugi" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink to="/o-kompanii" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                О компании
              </NavLink>
            </li>
            <li>
              <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                Блог
              </NavLink>
            </li>
            <li>
              <NavLink to="/kontakty" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                Контакты
              </NavLink>
            </li>
          </ul>
          <div className={styles.navCta}>
            <a className="btn btn--primary" href="/kontakty" onClick={closeMenu}>
              Записаться на консультацию
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;