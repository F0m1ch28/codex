import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.grid}>
      <div className={styles.brandCol}>
        <div className={styles.brand}>
          <span className={styles.brandMark}>AS</span>
          <div>
            <p className={styles.brandName}>Advocate Solutions</p>
            <p className={styles.tagline}>Современная правовая поддержка в Москве</p>
          </div>
        </div>
        <p className={styles.description}>
          Мы помогаем бизнесу и частным лицам уверенно двигаться вперёд, сочетая глубокую юридическую экспертизу,
          стратегический взгляд и цифровой подход к коммуникациям.
        </p>
      </div>
      <div className={styles.linksCol}>
        <h4>Навигация</h4>
        <ul>
          <li><NavLink to="/">Главная</NavLink></li>
          <li><NavLink to="/uslugi">Услуги</NavLink></li>
          <li><NavLink to="/o-kompanii">О компании</NavLink></li>
          <li><NavLink to="/blog">Блог</NavLink></li>
          <li><NavLink to="/kontakty">Контакты</NavLink></li>
        </ul>
      </div>
      <div className={styles.linksCol}>
        <h4>Правовая информация</h4>
        <ul>
          <li><NavLink to="/usloviya-ispolzovaniya">Условия использования</NavLink></li>
          <li><NavLink to="/politika-konfidencialnosti">Политика конфиденциальности</NavLink></li>
          <li><NavLink to="/politika-cookies">Политика cookies</NavLink></li>
        </ul>
      </div>
      <div className={styles.contactCol}>
        <h4>Контакты</h4>
        <p>ул. Тверская, д. 15, Москва, 125009</p>
        <a href="tel:+74951234567" className={styles.contactLink}>+7 (495) 123-45-67</a>
        <a href="mailto:info@advocate-solutions.ru" className={styles.contactLink}>info@advocate-solutions.ru</a>
        <div className={styles.socials} aria-label="Социальные сети">
          <a href="#" aria-label="LinkedIn" className={styles.socialLink}>in</a>
          <a href="#" aria-label="Telegram" className={styles.socialLink}>tg</a>
          <a href="#" aria-label="YouTube" className={styles.socialLink}>yt</a>
        </div>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>© {new Date().getFullYear()} Advocate Solutions. Все права защищены.</p>
      <p className={styles.motto}>Доверие, точность, стратегия.</p>
    </div>
  </footer>
);

export default Footer;