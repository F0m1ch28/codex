import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('cookieConsent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookies">
      <div className={styles.content}>
        <h4>Мы используем cookies</h4>
        <p>
          Cookies помогают нам улучшить работу сайта и адаптировать материалы под ваши интересы. Оставаясь на сайте,
          вы соглашаетесь с использованием файлов cookies.
        </p>
        <div className={styles.actions}>
          <button type="button" className="btn btn--primary" onClick={handleAccept}>
            Принять
          </button>
          <button type="button" className="btn btn--ghost" onClick={handleDecline}>
            Отклонить
          </button>
        </div>
        <a className={styles.link} href="/politika-cookies">
          Подробнее о cookies
        </a>
      </div>
    </aside>
  );
};

export default CookieBanner;