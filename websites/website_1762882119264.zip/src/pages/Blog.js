import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Blog | Optrivora</title>
        <meta
          name="description"
          content="Insights zu Mitarbeiter-Produktivität, OKR, Habit Tracking, Fokus-Timer und Workload Analytics. Bleiben Sie auf dem Laufenden."
        />
        <meta
          name="keywords"
          content="mitarbeiter produktivität, okr software, zielmanagement, habit tracker, fokus timer, zeit tracking dsgvo, workload analytics, 1:1 check-ins"
        />
        <link rel="canonical" href="https://www.optrivora.com/blog" />
        <meta property="og:title" content="Blog | Optrivora" />
        <meta
          property="og:description"
          content="Aktuelle Artikel rund um Zielmanagement, Fokus-Kultur und Habit Tracking."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Optrivora Blog</h1>
          <p>
            Aktuelle Perspektiven für People Leads, Führungskräfte und Produktteams. Wir teilen Erfahrungen aus
            Implementierungen, Forschung und Community-Events.
          </p>
        </div>
      </section>
      <section className={styles.posts}>
        <div className="container">
          <div className={styles.grid}>
            {[1, 2, 3, 4].map((index) => (
              <article key={index} className={styles.card}>
                <img
                  src={`https://picsum.photos/800/600?random=${50 + index}`}
                  alt="Blog Illustration"
                  loading="lazy"
                />
                <div>
                  <span>Publiziert am {10 + index}. Dezember 2023</span>
                  <h2>Guided Focus: Rituale für High-Performance Teams</h2>
                  <p>
                    Fünf Rituale, die Fokus-Zeit sichern, ohne Kollaboration einzuschränken. Inklusive Moderationsleitfäden
                    und Checklisten für Weekly Syncs.
                  </p>
                  <a href="/blog">Weiterlesen</a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;