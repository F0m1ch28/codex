import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Impressum.module.css';

const Impressum = () => {
  return (
    <>
      <Helmet>
        <title>Impressum | Optrivora</title>
        <meta name="description" content="Impressum der Optrivora GmbH mit Sitz in Berlin." />
        <link rel="canonical" href="https://www.optrivora.com/impressum" />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <h1>Impressum</h1>
          <p>Angaben gemäß § 5 TMG</p>
          <p>
            Optrivora GmbH
            <br />
            Friedrichstraße 88
            <br />
            10117 Berlin
          </p>
          <p>
            Telefon: +49 30 1234 5678
            <br />
            E-Mail: info@optrivora.com
          </p>
          <p>
            Vertreten durch die Geschäftsführung:
            <br />
            Lina Bergmann
          </p>
          <p>Registergericht: Amtsgericht Charlottenburg (Berlin)</p>
          <p>Handelsregisternummer: HRB 123456 B</p>
          <p>Umsatzsteuer-Identifikationsnummer gemäß §27a UStG: DE123456789</p>
        </div>
      </section>
    </>
  );
};

export default Impressum;