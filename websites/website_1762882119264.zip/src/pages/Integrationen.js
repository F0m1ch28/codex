import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Integrationen.module.css';

const integrationCategories = [
  {
    title: 'Kalender & Zeitplanung',
    items: ['Google Calendar', 'Microsoft Outlook', 'Apple Calendar']
  },
  {
    title: 'Kollaboration & Kommunikation',
    items: ['Slack', 'Microsoft Teams', 'Zoom']
  },
  {
    title: 'Projekt- & Aufgabenmanagement',
    items: ['Jira', 'Asana', 'Trello', 'Notion']
  },
  {
    title: 'Sales & CRM',
    items: ['Salesforce', 'HubSpot', 'Pipedrive']
  }
];

const Integrationen = () => {
  return (
    <>
      <Helmet>
        <title>Integrationen | Optrivora</title>
        <meta
          name="description"
          content="Optrivora verbindet sich mit führenden Tools wie Google Calendar, Microsoft 365, Slack, Teams und Jira. Erweitern Sie Ihre Workflows nahtlos."
        />
        <meta
          name="keywords"
          content="mitarbeiter produktivität, okr software, zielmanagement, habit tracker, fokus timer, zeit tracking dsgvo, workload analytics, 1:1 check-ins"
        />
        <link rel="canonical" href="https://www.optrivora.com/integrationen" />
        <meta property="og:title" content="Integrationen | Optrivora" />
        <meta
          property="og:description"
          content="Synchronisieren Sie Optrivora mit Ihrer Tool-Landschaft für maximale Produktivität."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Integrationen für einen durchgängigen Flow</h1>
          <p>
            Optrivora fügt sich nahtlos in Ihre bestehende Tool-Landschaft ein. Daten fließen bidirektional, um
            Prozesse zu vereinfachen und Silos aufzulösen.
          </p>
        </div>
      </section>
      <section className={styles.integrations}>
        <div className="container">
          <div className={styles.grid}>
            {integrationCategories.map((category) => (
              <article key={category.title} className={styles.card}>
                <h2>{category.title}</h2>
                <ul>
                  {category.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <div className={styles.api}>
            <h3>API &amp; Webhooks</h3>
            <p>
              Nutzen Sie unsere REST-API, Webhooks und SCIM-Provisioning, um Integrationen für individuelle Prozesse zu
              realisieren. Wir unterstützen SSO via SAML und OpenID Connect.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Integrationen;