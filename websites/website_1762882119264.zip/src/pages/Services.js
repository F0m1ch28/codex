import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Funktionen | Optrivora</title>
        <meta
          name="description"
          content="Entdecken Sie alle Funktionen von Optrivora: Ziele & OKR, Wochenplanung, Habit Tracking, Fokus-Timer, Zeit-Tracking und Workload Analytics."
        />
        <meta
          name="keywords"
          content="mitarbeiter produktivität, okr software, zielmanagement, habit tracker, fokus timer, zeit tracking dsgvo, workload analytics, 1:1 check-ins"
        />
        <link rel="canonical" href="https://www.optrivora.com/funktionen" />
        <meta property="og:title" content="Funktionen | Optrivora" />
        <meta
          property="og:description"
          content="Optrivora vereint Zielmanagement, Wochenplanung, Habit Tracking und Fokus-Timer in einer Plattform."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Funktionen, die Mitarbeiter-Effektivität zum Standard machen</h1>
          <p>
            Optrivora verknüpft Objectives, tägliche Routinen und Fokus-Zonen mit aussagekräftigen Insights.
            Jede Funktion ist darauf ausgerichtet, Transparenz zu schaffen und Teams zu empowern.
          </p>
        </div>
      </section>
      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            <article>
              <h2>Ziele &amp; OKR</h2>
              <p>
                Planen Sie Objectives und Key Results mit Templates, Scorecards und automatisierten Review-Erinnerungen.
                Status-Updates lassen sich per Slack oder Microsoft Teams auslösen.
              </p>
              <ul>
                <li>Intelligente Alignment-Ansichten für Teams</li>
                <li>Fortschritt via Workload und Fokus-Zeit verknüpfen</li>
                <li>Messbare Erfolgsmetriken inklusive Trendanalysen</li>
              </ul>
            </article>
            <article>
              <h2>Wochenplanung</h2>
              <p>
                Priorisieren Sie Aufgaben mit Fokus-Blöcken, Kalenderevents und Ritualen. Die Planungs-Oberfläche ist
                mobile-first gestaltet und bietet adaptive Empfehlungen.
              </p>
              <ul>
                <li>Deep-Work-Fenster mit Fokus-Timer</li>
                <li>Sync mit Google Calendar &amp; Microsoft 365</li>
                <li>Automatisierte Review-Pulse zum Wochenende</li>
              </ul>
            </article>
            <article>
              <h2>Habit Tracking</h2>
              <p>
                Gewohnheiten verbinden persönliche Ziele mit Teamkultur. Visualisieren Sie Adoption-Raten und unterstützen
                Mitarbeitende mit Micro-Coaching.
              </p>
              <ul>
                <li>Adaptive Habit-Pläne nach Skill-Level</li>
                <li>Reflexionsfragen und Stimmungsindikatoren</li>
                <li>Nudges für Teams via Slack oder E-Mail</li>
              </ul>
            </article>
            <article>
              <h2>Fokus-Timer &amp; Deep Work</h2>
              <p>
                Der Fokus-Timer unterstützt Flow-Zustände mit personalisierten Intervallen und Pausen. Workload Analytics
                liefern Insights zu Unterbrechungen.
              </p>
              <ul>
                <li>Pomodoro &amp; Custom Intervalle</li>
                <li>Unterbrechungen dokumentieren &amp; reflektieren</li>
                <li>Teamweite Fokus-Heatmaps</li>
              </ul>
            </article>
            <article>
              <h2>Zeit-Tracking DSGVO-konform</h2>
              <p>
                Zeiterfassung erfolgt transparent, datensparsam und auditierbar. Nur autorisierte Personen erhalten Zugriff
                auf aggregierte Reports.
              </p>
              <ul>
                <li>Audit-Logs und Rollenrechte</li>
                <li>Export nach CSV oder API</li>
                <li>Anonymisierte Team-Insights möglich</li>
              </ul>
            </article>
            <article>
              <h2>Workload Analytics</h2>
              <p>
                Visualisieren Sie Auslastung, Meeting-Intensität und Habit-Adoption. Frühwarnsysteme helfen People Leads,
                rechtzeitig zu handeln.
              </p>
              <ul>
                <li>Lead-Dashboards mit Benchmarks</li>
                <li>Signals für Überlastung in Echtzeit</li>
                <li>Korrelationen mit 1:1 Check-ins</li>
              </ul>
            </article>
          </div>
        </div>
      </section>
      <section className={styles.cta}>
        <div className="container">
          <h2>Funktionen in Aktion erleben?</h2>
          <p>
            Wir zeigen Ihnen Live, wie OKR, Wochenplanung und Workload Analytics zusammenspielen – abgestimmt auf Ihre
            Prozesse.
          </p>
          <a className="button-primary" href="/kontakt">
            Demo anfordern
          </a>
        </div>
      </section>
    </>
  );
};

export default Services;