import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Datenschutz | Optrivora</title>
        <meta
          name="description"
          content="Datenschutzerklärung der Optrivora GmbH. Informationen zu Datenverarbeitung, Cookies, Analytics und Betroffenenrechten."
        />
        <link rel="canonical" href="https://www.optrivora.com/datenschutz" />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <h1>Datenschutzerklärung</h1>
          <p>
            Wir nehmen den Schutz Ihrer persönlichen Daten sehr ernst. Nachfolgend informieren wir Sie darüber, welche
            Daten verarbeitet werden und welche Rechte Ihnen zustehen.
          </p>
          <h2>Verantwortliche Stelle</h2>
          <p>
            Optrivora GmbH
            <br />
            Friedrichstraße 88, 10117 Berlin
            <br />
            E-Mail: info@optrivora.com
          </p>
          <h2>Verarbeitungszwecke</h2>
          <ul>
            <li>Bereitstellung der Plattform und Vertragsdurchführung</li>
            <li>Analyse anonymisierter Nutzungsdaten zur Produktverbesserung</li>
            <li>Kommunikation im Rahmen von Support und Double-Opt-In Benachrichtigungen</li>
          </ul>
          <h2>Rechtsgrundlage</h2>
          <p>
            Die Datenverarbeitung erfolgt auf Grundlage von Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung) sowie Art. 6
            Abs. 1 lit. f DSGVO (berechtigtes Interesse an Produktoptimierung). Für Newsletter wenden wir Art. 6 Abs. 1
            lit. a DSGVO (Einwilligung) an.
          </p>
          <h2>Rechte der Betroffenen</h2>
          <p>
            Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung sowie Datenübertragbarkeit.
            Wenden Sie sich hierzu an info@optrivora.com.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;