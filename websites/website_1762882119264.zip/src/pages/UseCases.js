import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './UseCases.module.css';

const UseCases = () => {
  return (
    <>
      <Helmet>
        <title>Use Cases | Optrivora</title>
        <meta
          name="description"
          content="Erfahren Sie, wie verschiedene Teams Optrivora einsetzen: People & Culture, Vertrieb, Produktteams und Führungsteams."
        />
        <meta
          name="keywords"
          content="mitarbeiter produktivität, okr software, zielmanagement, habit tracker, fokus timer, zeit tracking dsgvo, workload analytics, 1:1 check-ins"
        />
        <link rel="canonical" href="https://www.optrivora.com/use-cases" />
        <meta property="og:title" content="Use Cases | Optrivora" />
        <meta
          property="og:description"
          content="Best Practices für den Einsatz von Optrivora in unterschiedlichen Teams und Branchen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Use Cases für fokussierte, menschenzentrierte Teams</h1>
          <p>
            Optrivora skaliert mit Ihrer Organisation. Vom ersten Alignment bis zur laufenden Optimierung decken wir
            unterschiedliche Branchen, Teamgrößen und Reifegrade ab.
          </p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article className={styles.case}>
            <div className={styles.caseText}>
              <h2>People &amp; Culture</h2>
              <p>
                Etablieren Sie Rituale für Feedback, Entwicklung und Wellbeing. Optrivora liefert Vorlagen für 1:1
                Check-ins, Pulsfragen und Lernpfade. Workload Analytics bieten Frühindikatoren für Überlastung.
              </p>
              <ul>
                <li>Check-in Leitfäden mit Fortschrittsverlauf</li>
                <li>Skill-Matrix und Lerngewohnheiten verbinden</li>
                <li>DSGVO-konforme Dokumentation von Gesprächen</li>
              </ul>
            </div>
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="People & Culture Dashboard"
              loading="lazy"
            />
          </article>
          <article className={styles.case}>
            <div className={styles.caseText}>
              <h2>Vertrieb</h2>
              <p>
                Verknüpfen Sie Pipeline-Ziele mit persönlichen Fokus-Blöcken. Automatisierte Reminder sorgen dafür, dass
                relevante Opportunities im Blick bleiben. Forecast-Meetings basieren auf aktuellen Daten.
              </p>
              <ul>
                <li>Salesforce Sync &amp; Deal Reviews</li>
                <li>Motivierende Habit-Loops für Outreach</li>
                <li>Storytelling-Dashboards für Revenue-Teams</li>
              </ul>
            </div>
            <img
              src="https://picsum.photos/800/600?random=23"
              alt="Vertriebsteam analysiert Pipeline"
              loading="lazy"
            />
          </article>
          <article className={styles.case}>
            <div className={styles.caseText}>
              <h2>Produktteams</h2>
              <p>
                Verbinden Sie Produktstrategie, OKRs und Sprintplanung. Fokus-Tage werden mit Kalendern synchronisiert,
                um Deep Work zu schützen. Feedback fließt aus Jira oder Azure DevOps in Reflexionsrunden.
              </p>
              <ul>
                <li>Objectives bis zu User Stories nachverfolgen</li>
                <li>Fokus-Zonen für Research, Build, QA</li>
                <li>Retros mit Habit-Insights kombinieren</li>
              </ul>
            </div>
            <img
              src="https://picsum.photos/800/600?random=24"
              alt="Produktteam im Workshop"
              loading="lazy"
            />
          </article>
        </div>
      </section>
    </>
  );
};

export default UseCases;