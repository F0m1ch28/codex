import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <Helmet>
        <title>Ressourcen | Optrivora</title>
        <meta
          name="description"
          content="Zugang zu Whitepapern, Playbooks und Webinaren rund um Mitarbeiter-Produktivität, OKR, Habit Tracking und Fokus-Kultur."
        />
        <meta
          name="keywords"
          content="mitarbeiter produktivität, okr software, zielmanagement, habit tracker, fokus timer, zeit tracking dsgvo, workload analytics, 1:1 check-ins"
        />
        <link rel="canonical" href="https://www.optrivora.com/ressourcen" />
        <meta property="og:title" content="Ressourcen | Optrivora" />
        <meta
          property="og:description"
          content="Playbooks, Leitfäden und Webinare für nachhaltige Mitarbeiter-Produktivität."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Ressourcen für nachhaltige Produktivität</h1>
          <p>
            Unser Ressourcen-Hub kombiniert praktische Vorlagen, Playbooks und Experten-Talks. Entwickeln Sie eine
            fokussierte Organisationskultur Schritt für Schritt weiter.
          </p>
        </div>
      </section>
      <section className={styles.resources}>
        <div className="container">
          <div className={styles.grid}>
            <article>
              <h2>Playbooks</h2>
              <p>
                Von Kick-off Sessions bis zu Quarterly Reviews: Unsere Playbooks liefern Timeboxed-Agenda, Moderationstipps
                und Templates für Teams.
              </p>
            </article>
            <article>
              <h2>Webinare</h2>
              <p>
                Live-Sessions mit Expertinnen zu OKR-Design, Habit Adoption und Workload Analytics. Jede Session inklusive
                Q&amp;A und Follow-up Materialien.
              </p>
            </article>
            <article>
              <h2>Whitepaper</h2>
              <p>
                Tiefgehende Analysen zu Fokus-Kultur, 1:1 Check-in Best Practices und DSGVO-konformem Zeit-Tracking.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;