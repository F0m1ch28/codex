import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '', consent: false });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) currentErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    if (!formData.email.trim()) {
      currentErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      currentErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) currentErrors.message = 'Bitte beschreiben Sie Ihr Anliegen.';
    if (!formData.consent) currentErrors.consent = 'Bitte bestätigen Sie das Double-Opt-In.';
    return currentErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const currentErrors = validate();
    setErrors(currentErrors);
    if (Object.keys(currentErrors).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Optrivora</title>
        <meta
          name="description"
          content="Nehmen Sie Kontakt zu Optrivora auf. Vereinbaren Sie eine Demo oder sprechen Sie mit unserem Team in Berlin."
        />
        <meta
          name="keywords"
          content="mitarbeiter produktivität, okr software, zielmanagement, habit tracker, fokus timer, zeit tracking dsgvo, workload analytics, 1:1 check-ins"
        />
        <link rel="canonical" href="https://www.optrivora.com/kontakt" />
        <meta property="og:title" content="Kontakt | Optrivora" />
        <meta
          property="og:description"
          content="Besuchen Sie uns in Berlin oder fordern Sie eine Demo der Optrivora Plattform an."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt</h1>
          <p>
            Sie möchten eine Demo vereinbaren oder offene Fragen klären? Wir freuen uns auf Ihre Nachricht. Unser Team
            meldet sich via Double-Opt-In, um Ihre Anfrage DSGVO-konform zu bestätigen.
          </p>
        </div>
      </section>
      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Kontaktinformationen</h2>
              <p>
                Optrivora
                <br />
                Friedrichstraße 88, 10117 Berlin, Deutschland
              </p>
              <p>
                <a href="tel:+493012345678">+49 30 1234 5678</a>
                <br />
                <a href="mailto:info@optrivora.com">info@optrivora.com</a>
              </p>
              <div className={styles.map}>
                <iframe
                  title="Optrivora Standort Berlin"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.672927571934!2d13.389859415806393!3d52.51453607981209!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851ca7705d2b5%3A0x84f30dee1ab2a165!2sFriedrichstra%C3%9Fe%2088%2C%2010117%20Berlin!5e0!3m2!1sde!2sde!4v1704978000000"
                  loading="lazy"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Demo anfragen</h2>
              {submitted ? (
                <div className={styles.success}>
                  <p>
                    Vielen Dank! Wir haben Ihre Anfrage erhalten. Bitte bestätigen Sie die Double-Opt-In E-Mail, damit wir
                    Ihre Anfrage bearbeiten dürfen.
                  </p>
                </div>
              ) : (
                <>
                  <div className={styles.field}>
                    <label htmlFor="name">Name</label>
                    <input
                      id="name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? 'name-error' : undefined}
                      required
                    />
                    {errors.name && <span id="name-error">{errors.name}</span>}
                  </div>
                  <div className={styles.field}>
                    <label htmlFor="email">E-Mail</label>
                    <input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      aria-invalid={Boolean(errors.email)}
                      aria-describedby={errors.email ? 'email-error' : undefined}
                      required
                    />
                    {errors.email && <span id="email-error">{errors.email}</span>}
                  </div>
                  <div className={styles.field}>
                    <label htmlFor="company">Unternehmen</label>
                    <input
                      id="company"
                      type="text"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    />
                  </div>
                  <div className={styles.field}>
                    <label htmlFor="message">Nachricht</label>
                    <textarea
                      id="message"
                      rows="5"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      aria-invalid={Boolean(errors.message)}
                      aria-describedby={errors.message ? 'message-error' : undefined}
                      required
                    ></textarea>
                    {errors.message && <span id="message-error">{errors.message}</span>}
                  </div>
                  <div className={styles.fieldCheckbox}>
                    <input
                      id="consent"
                      type="checkbox"
                      checked={formData.consent}
                      onChange={(e) => setFormData({ ...formData, consent: e.target.checked })}
                      aria-invalid={Boolean(errors.consent)}
                    />
                    <label htmlFor="consent">
                      Ich stimme dem Double-Opt-In sowie der Verarbeitung meiner Daten gemäß{' '}
                      <a href="/datenschutz">Datenschutzerklärung</a> zu.
                    </label>
                  </div>
                  {errors.consent && <span className={styles.checkboxError}>{errors.consent}</span>}
                  <div className="g-recaptcha" data-sitekey="YOUR_RECAPTCHA_SITE_KEY"></div>
                  <button type="submit">Absenden</button>
                </>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;