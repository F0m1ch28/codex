import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>AGB | Optrivora</title>
        <meta
          name="description"
          content="Allgemeine Geschäftsbedingungen der Optrivora GmbH für die Nutzung der SaaS-Plattform."
        />
        <link rel="canonical" href="https://www.optrivora.com/agb" />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <h1>Allgemeine Geschäftsbedingungen</h1>
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Allgemeinen Geschäftsbedingungen gelten für sämtliche Leistungen der Optrivora GmbH im Zusammenhang
            mit der Bereitstellung der SaaS-Plattform Optrivora.
          </p>
          <h2>2. Leistungsumfang</h2>
          <p>
            Optrivora stellt die Plattform mit Funktionen für Zielmanagement, Habit Tracking, Fokus-Timer und
            Workload-Analysen bereit. Der konkrete Leistungsumfang ergibt sich aus dem jeweiligen Vertrag.
          </p>
          <h2>3. Pflichten der Kund:innen</h2>
          <p>
            Kund:innen verpflichten sich, Zugangsdaten vertraulich zu behandeln und die Plattform nicht zweckfremd zu
            nutzen. Rechtswidrige Inhalte sind untersagt.
          </p>
          <h2>4. Verfügbarkeit</h2>
          <p>
            Optrivora strebt eine hohe Verfügbarkeit an und informiert rechtzeitig über Wartungsarbeiten. Ereignisse
            höherer Gewalt sind ausgeschlossen.
          </p>
          <h2>5. Datenschutz</h2>
          <p>
            Die Verarbeitung personenbezogener Daten erfolgt gemäß unserer Datenschutzerklärung. Kund:innen erhalten die
            Möglichkeit, Auftragsverarbeitungsverträge abzuschließen.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;