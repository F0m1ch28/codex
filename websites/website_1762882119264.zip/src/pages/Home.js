import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { value: 32, suffix: '%', label: 'höhere Zielerreichung in 6 Monaten' },
  { value: 18, suffix: ' Std.', label: 'Zeitgewinn pro Mitarbeitenden im Monat' },
  { value: 94, suffix: '%', label: 'aktivierte 1:1 Check-ins pro Quartal' }
];

const benefits = [
  {
    title: 'Transparente Prioritäten',
    description:
      'Verbinden Sie strategische Ziele mit persönlichen Prioritäten und schaffen Sie Klarheit über Fokusbereiche.'
  },
  {
    title: 'Gewohnheiten konsolidieren',
    description:
      'Ein Habit Tracker, der mit Wochenplanung und Reflexion verbunden ist, fördert nachhaltige Routinen.'
  },
  {
    title: 'Workload im Blick',
    description:
      'Workload Analytics verhindern stille Überlastung und ermöglichen frühzeitige Anpassungen in Teams.'
  }
];

const features = [
  {
    title: 'Ziele & OKR',
    description: 'Planen, aktualisieren und bewerten Sie OKRs mit wöchentlichen Check-ins und Scorecards.'
  },
  {
    title: 'Wochenplanung',
    description:
      'Modulare Wochenansicht mit Fokus-Timer, Kalendersynchronisation und persönlichen Fokus-Zonen.'
  },
  {
    title: 'Gewohnheiten',
    description:
      'Leitlinien, Mikroschritte und Reflexionsfragen unterstützen nachhaltige Gewohnheiten im Teamalltag.'
  },
  {
    title: 'Fokus-Timer',
    description:
      'Flexible Fokus-Blöcke mit Analytics, um Deep Work gezielt zu fördern – inklusive Pausenmanagement.'
  }
];

const useCases = [
  {
    title: 'People & Culture',
    description:
      'Etabliert regelmäßige 1:1 Check-ins, Pulsbefragungen und Entwicklungspläne für Mitarbeitende.'
  },
  {
    title: 'Vertrieb',
    description:
      'Verbindet Pipeline-Ziele mit Tagesprioritäten, Forecast-Remindern und kollaborativen Review-Ritualen.'
  },
  {
    title: 'Produktteams',
    description:
      'Sorgt für abgestimmte Objectives, strukturierte Sprints und synchronisierte Roadmaps mit Fokus auf Outcomes.'
  },
  {
    title: 'Führungsteams',
    description:
      'Kombiniert Exec Dashboards, Leadership Habit Tracking und Alignment-Signale für bessere Steuerung.'
  }
];

const integrations = [
  'Google Calendar',
  'Microsoft 365',
  'Slack',
  'Microsoft Teams',
  'Jira',
  'Notion',
  'Asana',
  'HubSpot'
];

const testimonials = [
  {
    quote:
      'Optrivora hat unsere OKR-Routinen neu belebt. Der Fokus-Timer in Kombination mit Workload Analytics sorgt für spürbare Entlastung.',
    name: 'Saskia Werner',
    role: 'Head of People, BrightLayer'
  },
  {
    quote:
      'Wir verbinden Salesforce-Ziele mit Wochenplanung. Die Ergebnisqualität im Vertrieb ist deutlich gestiegen.',
    name: 'Paul Hoffmann',
    role: 'VP Sales, Metricraft'
  },
  {
    quote:
      'Durch die Gewohnheiten-Module werden Lernziele und Teamrituale konsequent umgesetzt – ohne zusätzlichen Aufwand.',
    name: 'Leonie Adler',
    role: 'Director Product, Framewize'
  }
];

const teamMembers = [
  {
    name: 'Lina Bergmann',
    role: 'Chief Product Officer',
    description: 'Leitet Produktvision & Research. Priorisiert Flow-Erlebnisse und strategische Alignment-Features.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Arne Voigt',
    role: 'Head of Customer Success',
    description:
      'Entwickelt Enablement-Programme, erleichtert Roll-outs und etabliert datenbasierte Check-in-Routinen.',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Mira Schulte',
    role: 'Lead Data Strategist',
    description: 'Verantwortet Workload Analytics und sorgt für DSGVO-konforme Datenmodelle.',
    image: 'https://picsum.photos/400/400?random=33'
  }
];

const projects = [
  {
    title: 'Leadership Rituals',
    category: 'People & Culture',
    image: 'https://picsum.photos/1200/800?random=41',
    description: 'Roll-out von Fokus-Tagen, Check-in Leitfäden und Zieltransparenz bei einem Scale-up.'
  },
  {
    title: 'Vertrieb Alignment',
    category: 'Vertrieb',
    image: 'https://picsum.photos/1200/800?random=42',
    description: 'Verknüpfung von Pipeline-Reviews mit Wochenplanung und Forecast-Rhythmus.'
  },
  {
    title: 'Produkt Sprint Flow',
    category: 'Produkt',
    image: 'https://picsum.photos/1200/800?random=43',
    description: 'Grenzenlose Sichtbarkeit von OKRs bis zu User Stories mit Fokus-Analysen.'
  },
  {
    title: 'Hybrid Collaboration',
    category: 'Hybrid Work',
    image: 'https://picsum.photos/1200/800?random=44',
    description: 'Asynchrone Sync-Rituale mit Teams & Slack für global verteilte Einheiten.'
  }
];

const faqs = [
  {
    question: 'Wie unterstützt Optrivora 1:1 Check-ins?',
    answer:
      'Führungskräfte erhalten strukturierte Check-in-Vorlagen, Signalfragen und Follow-up-Automationen. Protokolle lassen sich sicher teilen und nachverfolgen.'
  },
  {
    question: 'Sind Daten DSGVO-konform geschützt?',
    answer:
      'Ja, Optrivora hostet ausschließlich in der EU, verschlüsselt Daten in Ruhe und während der Übertragung und bietet granulare Rollenrechte inklusive Audit-Logs.'
  },
  {
    question: 'Wie funktioniert das Zielmanagement?',
    answer:
      'Objectives, Key Results und Initiativen sind beliebig hierarchisch verknüpfbar. Fortschritte werden automatisch mit Gewohnheiten, Fokus-Zeit und Workload korreliert.'
  },
  {
    question: 'Welche Analytics stehen zur Verfügung?',
    answer:
      'Workload Analytics, Fokus-Intensität, Habit-Adoption und 1:1 Check-in Frequenz liefern handlungsrelevante Insights für People Lead und Teams.'
  }
];

const blogPosts = [
  {
    title: 'Fünf Signale für nachhaltige Fokus-Kultur',
    excerpt:
      'Welche Metriken zeigen wirklich, ob Teams konzentriert arbeiten? Wir teilen Benchmarks aus Kundenteams und Moderationsideen für Retros.',
    date: '03. Januar 2024'
  },
  {
    title: '1:1 Check-ins neu denken: Leitfaden für Führungskräfte',
    excerpt:
      'Strukturierte Fragen, Feedback-Schleifen und Dokumentation – so gelingt produktive Entwicklung im Arbeitsalltag.',
    date: '14. Dezember 2023'
  },
  {
    title: 'OKRs und Habit Tracking kombinieren',
    excerpt:
      'Warum Mikroroutinen den Unterschied machen und wie Optrivora Reflexion mit Zielerreichung verknüpft.',
    date: '28. November 2023'
  }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const statsRef = useRef(null);
  const [faqOpen, setFaqOpen] = useState(null);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const node = statsRef.current;
    if (!node) return;

    let started = false;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started) {
            started = true;
            statsData.forEach((stat, index) => {
              const duration = 1200;
              const start = performance.now();
              const animate = (now) => {
                const progress = Math.min((now - start) / duration, 1);
                const value = Math.floor(progress * stat.value);
                setAnimatedStats((prev) => {
                  const copy = [...prev];
                  copy[index] = value;
                  return copy;
                });
                if (progress < 1) {
                  requestAnimationFrame(animate);
                } else {
                  setAnimatedStats((prev) => {
                    const copy = [...prev];
                    copy[index] = stat.value;
                    return copy;
                  });
                }
              };
              requestAnimationFrame(animate);
            });
            observer.disconnect();
          }
        });
      },
      { threshold: 0.4 }
    );

    observer.observe(node);

    return () => observer.disconnect();
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Alle') return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Optrivora',
    url: 'https://www.optrivora.com',
    description:
      'Optrivora ist die SaaS-Plattform für Mitarbeiter-Produktivität, OKR-Management, Habit Tracking und Fokus-Zeitsteuerung.',
    telephone: '+49 30 1234 5678',
    email: 'info@optrivora.com',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Friedrichstraße 88',
      addressLocality: 'Berlin',
      postalCode: '10117',
      addressCountry: 'DE'
    },
    sameAs: ['https://www.linkedin.com/company/optrivora']
  };

  return (
    <>
      <Helmet>
        <title>Optrivora – Persönliche Effektivität für moderne Teams</title>
        <meta
          name="description"
          content="Optrivora bündelt Ziele, Wochenplanung, Habit Tracking und Fokus-Timer in einer Plattform. Stärken Sie Mitarbeiter-Produktivität mit DSGVO-konformer SaaS."
        />
        <meta
          name="keywords"
          content="mitarbeiter produktivität, okr software, zielmanagement, habit tracker, fokus timer, zeit tracking dsgvo, workload analytics, 1:1 check-ins"
        />
        <link rel="canonical" href="https://www.optrivora.com/" />
        <meta property="og:title" content="Optrivora – Persönliche Effektivität für moderne Teams" />
        <meta
          property="og:description"
          content="Steigern Sie Zielklarheit, Fokus und Gewohnheiten mit Optrivora – der Plattform für moderne Mitarbeiter-Effektivität."
        />
        <meta property="og:url" content="https://www.optrivora.com/" />
        <meta property="og:image" content="https://picsum.photos/1600/900?random=1" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content="https://picsum.photos/1600/900?random=1" />
        <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <span className={styles.pill}>Produktivität, neu gedacht</span>
              <h1>
                Persönliche Effektivität für Teams, die Ziele, Gewohnheiten und Fokus intelligent verbinden.
              </h1>
              <p>
                Optrivora führt Ziele &amp; OKR, Wochenplanung, Habit Tracking, Fokus-Timer und Workload Analytics
                in einer intuitiven Plattform zusammen. So entsteht Klarheit, Verbindlichkeit und nachhaltige
                Performance – inklusive DSGVO-sicherem Zeit-Tracking.
              </p>
              <div className={styles.heroActions}>
                <Link className={styles.primaryCta} to="/kontakt">
                  Demo anfordern
                </Link>
                <Link className={styles.secondaryCta} to="/funktionen">
                  Funktionen entdecken
                </Link>
              </div>
            </div>
            <div className={styles.heroVisual}>
              <div className={styles.heroCard}>
                <img
                  src="https://picsum.photos/1600/900?random=1"
                  alt="Dashboard mit Fokus-Analysen und OKR-Übersicht"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
          <div className={styles.stats} ref={statsRef}>
            {statsData.map((stat, index) => (
              <div className={styles.statItem} key={stat.label}>
                <span className={styles.statValue}>
                  {animatedStats[index]}
                  {stat.suffix}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits} id="benefits">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span>Nutzen</span>
            <h2>Warum Teams mit Optrivora produktiver arbeiten</h2>
            <p>
              Ausgewogene Produktivität bedeutet Fokus, Transparenz und gesunde Arbeitsroutinen. Optrivora verbindet
              diese Komponenten zu einem ganzheitlichen Flow.
            </p>
          </div>
          <div className={styles.benefitGrid}>
            {benefits.map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.features}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span>Funktionen</span>
            <h2>Alle Werkzeuge für Zielmanagement, Routinen und Fokus in einem Flow</h2>
          </div>
          <div className={styles.featuresContent}>
            <div className={styles.featuresList}>
              {features.map((feature) => (
                <article key={feature.title} className={styles.featureCard}>
                  <h3>{feature.title}</h3>
                  <p>{feature.description}</p>
                  <Link to="/funktionen" className={styles.featureLink}>
                    Mehr erfahren →
                  </Link>
                </article>
              ))}
            </div>
            <div className={styles.process}>
              <h3>So läuft Ihr Enablement mit Optrivora</h3>
              <div className={styles.processSteps}>
                <div>
                  <span>1</span>
                  <div>
                    <h4>Kick-off &amp; Alignment</h4>
                    <p>Gemeinsames Set-up von Objektiven, Workflows und zentralen Integrationen.</p>
                  </div>
                </div>
                <div>
                  <span>2</span>
                  <div>
                    <h4>Enablement &amp; Rituale</h4>
                    <p>Team-Trainings, Playbooks und Moderationsleitfäden für 1:1 Check-ins sowie Fokus-Zonen.</p>
                  </div>
                </div>
                <div>
                  <span>3</span>
                  <div>
                    <h4>Analytics &amp; Optimierung</h4>
                    <p>Verbesserungsschleifen mit Workload Analytics, Habit Adoption und Meeting-Free Days.</p>
                  </div>
                </div>
              </div>
              <Link to="/use-cases" className={styles.processCta}>
                Erfolgsstories lesen
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.useCases}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span>Use Cases</span>
            <h2>Passgenau für unterschiedliche Teams und Rollen</h2>
          </div>
          <div className={styles.useCaseGrid}>
            {useCases.map((useCase) => (
              <article key={useCase.title} className={styles.useCaseCard}>
                <h3>{useCase.title}</h3>
                <p>{useCase.description}</p>
              </article>
            ))}
          </div>
          <div className={styles.projects}>
            <div className={styles.projectsHeader}>
              <h3>Projekte &amp; Best Practices</h3>
              <div className={styles.projectFilters} role="tablist" aria-label="Projektfilter">
                {['Alle', 'People & Culture', 'Vertrieb', 'Produkt', 'Hybrid Work'].map((category) => (
                  <button
                    key={category}
                    type="button"
                    className={projectFilter === category ? styles.activeFilter : ''}
                    onClick={() => setProjectFilter(category)}
                    role="tab"
                    aria-selected={projectFilter === category}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.projectGrid}>
              {filteredProjects.map((project) => (
                <article key={project.title} className={styles.projectCard}>
                  <div className={styles.projectImage}>
                    <img src={project.image} alt={`Projektbeispiel: ${project.title}`} loading="lazy" />
                    <span>{project.category}</span>
                  </div>
                  <div className={styles.projectBody}>
                    <h4>{project.title}</h4>
                    <p>{project.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.integrations}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span>Integrationen</span>
            <h2>Verbinden Sie Optrivora mit Ihrer bestehenden Tool-Landschaft</h2>
            <p>
              Synchronisieren Sie Kalender, Kommunikation, Projektmanagement und CRM. Events, To-dos und Check-ins
              fließen automatisch in Ihre Workflows.
            </p>
          </div>
          <div className={styles.integrationGrid}>
            {integrations.map((name) => (
              <div key={name} className={styles.integrationItem}>
                {name}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialLayout}>
            <div className={styles.sectionHeader}>
              <span>Stimmen aus Kundenprojekten</span>
              <h2>Wie Teams Optrivora erlebten</h2>
              <p>
                Von Scale-Ups bis Enterprise: Optrivora schafft Klarheit, Fokus und verbindet Menschen mit ihren
                Zielen.
              </p>
            </div>
            <div className={styles.testimonialCarousel} aria-live="polite">
              {testimonials.map((testimonial, index) => (
                <article
                  key={testimonial.name}
                  className={`${styles.testimonialCard} ${
                    index === activeTestimonial ? styles.testimonialActive : ''
                  }`}
                >
                  <p>“{testimonial.quote}”</p>
                  <div>
                    <span>{testimonial.name}</span>
                    <small>{testimonial.role}</small>
                  </div>
                </article>
              ))}
              <div className={styles.carouselDots}>
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    type="button"
                    className={index === activeTestimonial ? styles.dotActive : ''}
                    onClick={() => setActiveTestimonial(index)}
                    aria-label={`Testimonial ${index + 1} anzeigen`}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className={styles.teamSection}>
            <h3>Team hinter Optrivora</h3>
            <div className={styles.teamGrid}>
              {teamMembers.map((member) => (
                <article key={member.name} className={styles.teamCard}>
                  <div className={styles.teamImage}>
                    <img src={member.image} alt={`${member.name} – ${member.role}`} loading="lazy" />
                  </div>
                  <div className={styles.teamInfo}>
                    <h4>{member.name}</h4>
                    <span>{member.role}</span>
                    <p>{member.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.faqContent}>
            <div className={styles.sectionHeader}>
              <span>Ressourcen</span>
              <h2>Antworten auf häufige Fragen</h2>
              <p>
                Alle Datenflüsse, Funktionen und Integrationen werden transparent dokumentiert. Weitere Details finden
                Sie in unserem Ressourcenbereich.
              </p>
              <Link to="/ressourcen" className={styles.resourcesLink}>
                Zum Ressourcen-Hub →
              </Link>
            </div>
            <div className={styles.faqList}>
              {faqs.map((faqItem, index) => (
                <div key={faqItem.question} className={styles.faqItem}>
                  <button
                    type="button"
                    onClick={() => setFaqOpen(faqOpen === index ? null : index)}
                    aria-expanded={faqOpen === index}
                  >
                    {faqItem.question}
                    <span>{faqOpen === index ? '−' : '+'}</span>
                  </button>
                  {faqOpen === index && <p>{faqItem.answer}</p>}
                </div>
              ))}
            </div>
          </div>
          <div className={styles.blogPreview}>
            <h3>Aktuelle Insights</h3>
            <div className={styles.blogGrid}>
              {blogPosts.map((post) => (
                <article key={post.title} className={styles.blogCard}>
                  <span>{post.date}</span>
                  <h4>{post.title}</h4>
                  <p>{post.excerpt}</p>
                  <Link to="/blog">Weiterlesen</Link>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Bereit für neue Energie in Ihren Teams?</h2>
              <p>
                Lassen Sie sich in einer Demo zeigen, wie Optrivora Ziele, Fokus-Zeit, Habit Tracking und Workload
                Insights verbindet – adaptierbar auf Ihre Prozesse.
              </p>
            </div>
            <Link to="/kontakt" className={styles.primaryCta}>
              Demo anfordern
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;