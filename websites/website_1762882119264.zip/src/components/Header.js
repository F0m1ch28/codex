import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Start' },
  { path: '/funktionen', label: 'Funktionen' },
  { path: '/use-cases', label: 'Use Cases' },
  { path: '/integrationen', label: 'Integrationen' },
  { path: '/ressourcen', label: 'Ressourcen' },
  { path: '/blog', label: 'Blog' },
  { path: '/kontakt', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="Optrivora Startseite">
            <span className={styles.logoMark}>Optrivora</span>
          </Link>
          <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Hauptnavigation">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className={styles.actions}>
            <Link className={styles.cta} to="/kontakt">
              Demo anfordern
            </Link>
            <button
              className={`${styles.menuButton} ${menuOpen ? styles.menuOpen : ''}`}
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-label="Navigation umschalten"
              aria-expanded={menuOpen}
            >
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;