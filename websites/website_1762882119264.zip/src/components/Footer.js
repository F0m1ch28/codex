import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <span className={styles.logo}>Optrivora</span>
            <p>
              Die Plattform für ganzheitliche Mitarbeiter-Effektivität: Ziele, Fokus, Gewohnheiten und
              transparente Workload-Analysen in einem leistungsstarken Hub.
            </p>
            <div className={styles.contact}>
              <a href="tel:+493012345678">+49 30 1234 5678</a>
              <a href="mailto:info@optrivora.com">info@optrivora.com</a>
              <address>Friedrichstraße 88, 10117 Berlin, Deutschland</address>
            </div>
          </div>
          <div>
            <h4>Navigation</h4>
            <ul>
              <li>
                <Link to="/">Start</Link>
              </li>
              <li>
                <Link to="/funktionen">Funktionen</Link>
              </li>
              <li>
                <Link to="/use-cases">Use Cases</Link>
              </li>
              <li>
                <Link to="/integrationen">Integrationen</Link>
              </li>
              <li>
                <Link to="/ressourcen">Ressourcen</Link>
              </li>
              <li>
                <Link to="/blog">Blog</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>Support</h4>
            <ul>
              <li>
                <Link to="/kontakt">Kontakt</Link>
              </li>
              <li>
                <Link to="/agb">AGB</Link>
              </li>
              <li>
                <Link to="/datenschutz">Datenschutz</Link>
              </li>
              <li>
                <Link to="/impressum">Impressum</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>Newsletter</h4>
            <p>
              Erhalten Sie regelmäßig Impulse zu OKR-Praxis, Habit Building und 1:1 Check-ins. Double-Opt-In
              inklusive.
            </p>
            <form className={styles.newsletter} aria-label="Newsletter Anmeldung">
              <label htmlFor="newsletter-email" className="sr-only">
                E-Mail-Adresse
              </label>
              <input id="newsletter-email" type="email" placeholder="E-Mail-Adresse" required />
              <button type="submit">Anmelden</button>
            </form>
            <small>
              Mit der Anmeldung stimmen Sie dem Double-Opt-In sowie unseren{' '}
              <Link to="/datenschutz">Datenschutzrichtlinien</Link> zu.
            </small>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} Optrivora. Alle Rechte vorbehalten.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;