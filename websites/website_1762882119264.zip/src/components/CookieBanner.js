import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('optrivoraCookieConsent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem('optrivoraCookieConsent', value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um Nutzungsmuster anonymisiert zu analysieren und das Erlebnis in Optrivora
          kontinuierlich zu verbessern. Sie können jederzeit Ihre Entscheidung anpassen.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleConsent('declined')}>
            Ablehnen
          </button>
          <button
            className={styles.primary}
            type="button"
            onClick={() => handleConsent('accepted')}
          >
            Akzeptieren
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;