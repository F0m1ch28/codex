document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    const scrollTopBtn = document.getElementById("scrollTop");
    const cookieBanner = document.getElementById("cookie-banner");
    const cookieAccept = document.getElementById("cookie-accept");
    const contactForm = document.querySelector(".contact-form");
    const newsletterForm = document.querySelector(".newsletter-form");
    const currentYearSpan = document.getElementById("current-year");

    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navMenu.classList.toggle("open");
        });

        navMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    if (scrollTopBtn) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 400) {
                scrollTopBtn.classList.add("show");
            } else {
                scrollTopBtn.classList.remove("show");
            }
        });

        scrollTopBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (cookieBanner && cookieAccept) {
        const consent = localStorage.getItem("micCookieConsent");
        if (consent === "true") {
            cookieBanner.style.display = "none";
        }

        cookieAccept.addEventListener("click", () => {
            localStorage.setItem("micCookieConsent", "true");
            cookieBanner.style.display = "none";
        });
    }

    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const status = contactForm.querySelector(".form-status");
            status.textContent = "Thank you. Our team will reach out within two business days.";
            contactForm.reset();
        });
    }

    if (newsletterForm) {
        newsletterForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const emailField = newsletterForm.querySelector("input[type='email']");
            if (emailField) {
                emailField.value = "";
            }
            const helper = newsletterForm.nextElementSibling;
            if (helper && helper.classList.contains("form-helper")) {
                helper.textContent = "Subscribed! Look for the next Signal Ledger dispatch soon.";
            }
        });
    }
});