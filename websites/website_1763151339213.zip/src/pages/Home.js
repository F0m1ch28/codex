import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const services = [
  {
    title: 'Айдентика и брендинг',
    description:
      'Создаём выразительные визуальные языки, которые раскрывают характер бренда и формируют эмоциональную связь с аудиторией.'
  },
  {
    title: 'Дизайн цифровых продуктов',
    description:
      'Проектируем интерфейсы и визуальные концепции для веба и мобильных приложений с акцентом на интерактивность и эстетику.'
  },
  {
    title: 'Иллюстрация и визуальные истории',
    description:
      'Работаем с авторскими иллюстрациями, арт-дирекшном и визуальными нарративами для кампаний и медиа проектов.'
  }
];

const featuredProjects = [
  {
    title: 'Серия плакатов «Орбита света»',
    category: 'Иллюстрация',
    description: 'Цифровые картины о взаимодействии света и архитектуры.',
    image: 'https://picsum.photos/id/1011/640/480'
  },
  {
    title: 'Новый образ Studio Lumen',
    category: 'Брендинг',
    description: 'Полное обновление идентики творческого пространства.',
    image: 'https://picsum.photos/id/1025/640/480'
  },
  {
    title: 'Инсталляция «Город отражений»',
    category: 'Инсталляция',
    description: 'Иммерсивный опыт с дополненной реальностью и звуком.',
    image: 'https://picsum.photos/id/1035/640/480'
  }
];

const blogPosts = [
  {
    title: 'Как цвет задаёт динамику бренда',
    description:
      'Исследуем психологию цвета, чтобы тонко настроить восприятие и настроение визуального образа.',
    date: '12 марта 2024',
    readingTime: '7 минут',
    image: 'https://picsum.photos/id/1041/640/400'
  },
  {
    title: 'Тренды иллюстрации в digital-среде',
    description:
      'Рассказываем о техниках и подходах, которые формируют современную визуальную культуру.',
    date: '28 февраля 2024',
    readingTime: '5 минут',
    image: 'https://picsum.photos/id/1050/640/400'
  }
];

const Home = () => (
  <>
    <Helmet>
      <title>ArtVista — художественная студия и творческое агентство</title>
      <meta
        name="description"
        content="ArtVista — студия визуального искусства в Москве. Брендинг, дизайн, иллюстрация и арт-проекты, которые вдохновляют аудиторию."
      />
      <meta
        name="keywords"
        content="искусство, дизайн, креатив, портфолио, творческая студия, визуальное искусство, брендинг"
      />
    </Helmet>
    <section className={`${styles.heroSection} container`}>
      <div className={styles.heroContent}>
        <p className={styles.smallTitle}>Творческая студия полного цикла</p>
        <h1 className={styles.heroTitle}>
          Мы создаём визуальные истории, которые заставляют бренды звучать громче.
        </h1>
        <p className={styles.heroSubtitle}>
          ArtVista соединяет искусство, стратегию и технологии, чтобы превращать идеи в впечатляющие
          визуальные продукты. Мы работаем на стыке дизайна, цифровых медиа и пространственных
          решений.
        </p>
        <div className={styles.heroCtas}>
          <Link to="/contact" className={styles.primaryButton}>
            Обсудить проект
          </Link>
          <Link to="/portfolio" className={styles.secondaryButton}>
            Смотреть портфолио
          </Link>
        </div>
        <div className={styles.heroStats}>
          <div>
            <span>120+</span>
            реализованных проектов
          </div>
          <div>
            <span>15</span>
            творческих специалистов
          </div>
          <div>
            <span>10 лет</span>
            в визуальном искусстве
          </div>
        </div>
      </div>
      <div className={styles.heroVisual}>
        <img
          src="https://picsum.photos/id/1015/640/640"
          alt="Динамичная арт-композиция студии ArtVista"
        />
      </div>
    </section>

    <section className={`${styles.servicesSection} container`}>
      <div className={styles.sectionHeader}>
        <p className={styles.sectionTag}>Что мы делаем</p>
        <h2>Экспертиза ArtVista</h2>
        <p>
          Мы объединяем стратегическое мышление и художественную выразительность. Создаём решения
          для брендов, арт-проектов, культурных институций и цифровых продуктов.
        </p>
      </div>
      <div className={styles.servicesGrid}>
        {services.map((service) => (
          <article key={service.title} className={styles.serviceCard}>
            <h3>{service.title}</h3>
            <p>{service.description}</p>
            <Link to="/services">Подробнее</Link>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.portfolioSection} container`}>
      <div className={styles.sectionHeader}>
        <p className={styles.sectionTag}>Портфолио</p>
        <h2>Избранные проекты</h2>
        <p>
          Каждая работа — это замысел, воплощённый через свет, фактуры и эмоции. Наведите курсор,
          чтобы прочитать историю проекта.
        </p>
      </div>
      <div className={styles.portfolioGrid}>
        {featuredProjects.map((project) => (
          <figure key={project.title} className={styles.projectCard}>
            <img src={project.image} alt={`Проект ArtVista: ${project.title}`} />
            <figcaption className={styles.projectInfo}>
              <span>{project.category}</span>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
            </figcaption>
          </figure>
        ))}
      </div>
      <div className={styles.sectionFooter}>
        <Link to="/portfolio" className={styles.primaryButton}>
          Смотреть все проекты
        </Link>
      </div>
    </section>

    <section className={`${styles.aboutPreview} container`}>
      <div className={styles.sectionHeader}>
        <p className={styles.sectionTag}>О студии</p>
        <h2>Команда визуальных исследователей</h2>
        <p>
          Мы влюблены в детали, вдохновляемся городом и природой, комбинируем классические техники с
          цифровыми инновациями. ArtVista — это синергия художников, дизайнеров, стратегов и
          продюсеров.
        </p>
      </div>
      <div className={styles.aboutContent}>
        <ul>
          <li>Командная работа с прозрачной коммуникацией на каждом этапе проекта.</li>
          <li>Экспериментальные подходы к визуальному сторителлингу и инсталляциям.</li>
          <li>Собственная арт-резиденция и лаборатория для тестирования новых идей.</li>
        </ul>
        <Link to="/about" className={styles.secondaryButton}>
          Узнать больше о нас
        </Link>
      </div>
    </section>

    <section className={`${styles.blogSection} container`}>
      <div className={styles.sectionHeader}>
        <p className={styles.sectionTag}>Блог</p>
        <h2>Замечаем тренды, делимся взглядами</h2>
        <p>
          Мы анализируем новые тенденции, исследуем техники и рассказываем о backstage наших
          проектов.
        </p>
      </div>
      <div className={styles.blogGrid}>
        {blogPosts.map((post) => (
          <article key={post.title} className={styles.blogCard}>
            <div className={styles.blogImageWrap}>
              <img src={post.image} alt={`Превью статьи: ${post.title}`} />
            </div>
            <div className={styles.blogContent}>
              <p className={styles.blogMeta}>
                {post.date} · {post.readingTime}
              </p>
              <h3>{post.title}</h3>
              <p>{post.description}</p>
              <Link to="/blog">Читать в блоге</Link>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className="container">
        <div className={styles.ctaCard}>
          <h2>Готовы создать что-то незабываемое?</h2>
          <p>
            Расскажите о вашем проекте, и мы предложим визуальную стратегию, которая усилит вашу
            идею.
          </p>
          <div className={styles.heroCtas}>
            <Link to="/contact" className={styles.primaryButton}>
              Связаться со студией
            </Link>
            <Link to="/services" className={styles.secondaryButton}>
              Наши услуги
            </Link>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Home;