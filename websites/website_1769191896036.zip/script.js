document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const siteNav = document.querySelector("[data-site-nav]");
  const yearTarget = document.querySelector("[data-year]");
  const observerTargets = document.querySelectorAll(".animate-on-scroll");
  const toast = document.querySelector(".global-toast");
  const forms = document.querySelectorAll("form[data-form]");
  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const cookieStorageKey = "arkaLogisticsCookieChoice";

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", siteNav.classList.contains("is-open"));
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  if (yearTarget) {
    yearTarget.textContent = new Date().getFullYear();
  }

  if (observerTargets.length > 0) {
    const io = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.18 }
    );

    observerTargets.forEach((target) => io.observe(target));
  }

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 2400);
  }

  if (forms.length > 0) {
    forms.forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const successMessage = form.getAttribute("data-success-msg") || "Submission received. Redirecting.";
        showToast(successMessage);
        setTimeout(() => {
          window.location.href = form.getAttribute("action");
        }, 1500);
      });
    });
  }

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieStorageKey);
    if (storedChoice) {
      cookieBanner.style.display = "none";
    }

    const handleChoice = (choice) => {
      localStorage.setItem(cookieStorageKey, choice);
      cookieBanner.style.display = "none";
      showToast(choice === "accepted" ? "Cookies enabled for improved analytics." : "Cookies declined. Preferences saved.");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    }

    if (declineBtn) {
      declineBtn.addEventListener("click", () => handleChoice("declined"));
    }
  }
});