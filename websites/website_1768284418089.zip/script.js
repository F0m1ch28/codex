document.addEventListener('DOMContentLoaded', function () {
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-buttons .accept');
    const declineBtn = document.querySelector('.cookie-buttons .decline');

    if (cookieBanner) {
        const consent = localStorage.getItem('ccgr_cookie_consent');
        if (!consent) {
            cookieBanner.classList.add('active');
        }
        const storeConsent = (value) => {
            localStorage.setItem('ccgr_cookie_consent', value);
            cookieBanner.classList.remove('active');
        };
        acceptBtn?.addEventListener('click', () => storeConsent('accepted'));
        declineBtn?.addEventListener('click', () => storeConsent('declined'));
    }

    const mapRegions = document.querySelectorAll('.map-region');
    const mapDetails = document.querySelector('.map-details');
    if (mapRegions.length && mapDetails) {
        mapRegions.forEach(region => {
            region.addEventListener('click', () => {
                mapRegions.forEach(btn => btn.classList.remove('active'));
                region.classList.add('active');
                const title = region.dataset.title;
                const description = region.dataset.description;
                const dishes = region.dataset.dishes ? region.dataset.dishes.split('|') : [];
                mapDetails.innerHTML = `
                    <h3>${title}</h3>
                    <p>${description}</p>
                    <h4>Preparatele reprezentative</h4>
                    <ul class="card-list">
                        ${dishes.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                `;
            });
        });
        const firstRegion = mapRegions[0];
        if (firstRegion) {
            firstRegion.click();
        }
    }

    const filterButtons = document.querySelectorAll('.filter-button');
    const festivalCards = document.querySelectorAll('.festival-card');
    if (filterButtons.length && festivalCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const season = button.dataset.filter;
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                festivalCards.forEach(card => {
                    if (season === 'all' || card.dataset.season === season) {
                        card.style.display = 'grid';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
        const allButton = document.querySelector('.filter-button[data-filter="all"]');
        allButton?.click();
    }

    const chefCards = document.querySelectorAll('.chef-card');
    const modal = document.querySelector('.modal');
    const modalContent = document.querySelector('.modal-content');
    if (chefCards.length && modal && modalContent) {
        const modalTitle = modalContent.querySelector('.modal-title');
        const modalBody = modalContent.querySelector('.modal-body');
        chefCards.forEach(card => {
            card.addEventListener('click', () => {
                const title = card.dataset.name;
                const biography = card.dataset.biography;
                const highlights = card.dataset.highlights ? card.dataset.highlights.split('|') : [];
                modalTitle.textContent = title;
                modalBody.innerHTML = `
                    <p>${biography}</p>
                    <h4>Repere culinare</h4>
                    <ul class="card-list">
                        ${highlights.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                `;
                modal.classList.add('open');
            });
        });
        const closeModal = () => modal.classList.remove('open');
        modal.querySelector('.modal-close')?.addEventListener('click', closeModal);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal();
            }
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    }

    const galleryItems = document.querySelectorAll('.gallery-item');
    const lightbox = document.querySelector('.lightbox');
    if (galleryItems.length && lightbox) {
        const lightboxImage = lightbox.querySelector('img');
        const lightboxCaption = lightbox.querySelector('.lightbox-caption');
        const closeLightbox = () => lightbox.classList.remove('open');

        galleryItems.forEach(item => {
            item.addEventListener('click', () => {
                const src = item.querySelector('img').src;
                const caption = item.dataset.caption || '';
                lightboxImage.src = src;
                lightboxCaption.textContent = caption;
                lightbox.classList.add('open');
            });
        });

        lightbox.querySelector('.lightbox-close')?.addEventListener('click', closeLightbox);
        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox) {
                closeLightbox();
            }
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeLightbox();
            }
        });
    }

    const accordionHeaders = document.querySelectorAll('.accordion-header');
    if (accordionHeaders.length) {
        accordionHeaders.forEach(header => {
            header.addEventListener('click', () => {
                const item = header.parentElement;
                const isOpen = item.classList.contains('open');
                accordionHeaders.forEach(h => h.parentElement.classList.remove('open'));
                if (!isOpen) {
                    item.classList.add('open');
                }
            });
        });
    }
});