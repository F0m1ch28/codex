document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-accept');
    const declineButton = document.querySelector('.cookie-decline');
    const consentKey = 'greaterksb_cookie_consent';

    if (cookieBanner) {
        const consentValue = localStorage.getItem(consentKey);
        if (!consentValue) {
            setTimeout(() => {
                cookieBanner.classList.add('is-visible');
            }, 800);
        }

        if (acceptButton) {
            acceptButton.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'accepted');
                cookieBanner.classList.remove('is-visible');
            });
        }

        if (declineButton) {
            declineButton.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'declined');
                cookieBanner.classList.remove('is-visible');
            });
        }
    }
});