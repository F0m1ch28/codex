document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.getElementById("navToggle");
  const menuPrincipal = document.getElementById("menu-principal");

  if (navToggle && menuPrincipal) {
    navToggle.addEventListener("click", () => {
      const isOpen = menuPrincipal.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen);
    });
  }

  const header = document.querySelector(".site-header");
  if (header) {
    window.addEventListener("scroll", () => {
      header.classList.toggle("header-scrolled", window.scrollY > 20);
    });
  }

  const yearSpan = document.getElementById("year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const cookieButtons = document.querySelectorAll("[data-cookie-consent]");
  const consentKey = "luminestravioConsent";

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      setTimeout(() => {
        cookieBanner.classList.add("active");
      }, 800);
    }

    cookieButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const action = button.dataset.cookieConsent;
        localStorage.setItem(consentKey, action);
        cookieBanner.classList.remove("active");
      });
    });
  }

  document.querySelectorAll("[data-reveal-target]").forEach((button) => {
    button.addEventListener("click", () => {
      const target = document.querySelector(button.dataset.revealTarget);
      if (target) {
        target.classList.toggle("visible");
        if (target.classList.contains("visible")) {
          button.textContent = "Ocultar detalles";
        } else {
          button.textContent = "Ver pistas";
        }
      }
    });
  });
});