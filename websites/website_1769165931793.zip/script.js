document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      siteNav.classList.toggle("active");
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("active")) {
          siteNav.classList.remove("active");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
    const closeBtn = siteNav.querySelector(".nav-close");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        siteNav.classList.remove("active");
        navToggle.setAttribute("aria-expanded", "false");
      });
    }
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll(".animate-on-scroll").forEach((el) => observer.observe(el));
  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("cookieConsent");
    if (!storedChoice) {
      cookieBanner.classList.add("active");
    }
    cookieBanner.addEventListener("click", (event) => {
      const action = event.target.getAttribute("data-cookie-action");
      if (!action) return;
      if (action === "accept") {
        localStorage.setItem("cookieConsent", "accepted");
      }
      if (action === "decline") {
        localStorage.setItem("cookieConsent", "declined");
      }
      cookieBanner.classList.remove("active");
    });
  }
  const toast = document.getElementById("form-toast");
  document.querySelectorAll("form[data-redirect]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (toast) {
        toast.classList.add("active");
        setTimeout(() => {
          toast.classList.remove("active");
        }, 2000);
      }
      const target = form.getAttribute("data-redirect") || "thank-you.html";
      setTimeout(() => {
        window.location.href = target;
      }, 1600);
    });
  });
  const yearNodes = document.querySelectorAll("[data-current-year]");
  const currentYear = new Date().getFullYear();
  yearNodes.forEach((node) => {
    node.textContent = currentYear;
  });
});