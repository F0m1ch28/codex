export const blogPosts = [
  {
    slug: 'wertschaetzend-kommunizieren-im-alltag',
    title: 'Wertschätzend kommunizieren im Alltag',
    category: 'Alltag',
    readingTime: '6 Min.',
    teaser: 'Wie Du mit kleinen Veränderungen mehr Wärme und Klarheit in Deine Gespräche bringst.',
    cover: 'https://picsum.photos/1200/800?random=11',
    content: [
      'Im Alltag reagieren wir oft automatisch – und merken erst hinterher, dass unser Ton nicht so liebevoll war, wie wir es uns wünschen. Wertschätzende Kommunikation beginnt damit, Dir Deiner eigenen Muster bewusst zu werden.',
      'Starte mit kurzen Check-ins: Eine Pause von drei Atemzügen, bevor Du antwortest, kann Wunder wirken. Frage Dich, welches Bedürfnis gerade bei Dir aktiv ist und ob Du es offen kommunizieren kannst.',
      'Benutze konkrete Beispiele statt Vorwürfen. Beschreibe Situationen, wie sie waren, und teile, was Du dabei gefühlt hast. So steigt die Wahrscheinlichkeit, dass Dein Gegenüber Dich wirklich hört.'
    ],
    highlights: [
      'Kurze Pausen nutzen, um nicht impulsiv zu reagieren',
      'Bedürfnisse offen teilen statt Interpretationen',
      'Konkrete Situationen beschreiben statt zu verallgemeinern'
    ],
    publishedAt: '2023-11-18'
  },
  {
    slug: 'konflikte-im-team-souveraen-anpacken',
    title: 'Konflikte im Team souverän anpacken',
    category: 'Arbeit & Team',
    readingTime: '7 Min.',
    teaser: 'Mit klaren Strukturen und Empathie zu einem wirksamen Miteinander im Job.',
    cover: 'https://picsum.photos/1200/800?random=12',
    content: [
      'Teamkonflikte entstehen häufig aus Missverständnissen oder nicht ausgesprochenen Erwartungen. Ein guter Einstieg ist ein gemeinsamer Wahrnehmungsabgleich: Was sehe ich? Was sehe ich nicht? Was vermute ich?',
      'Schaffe in Meetings Raum für Feedback, ohne dass jemand unterbrochen wird. Die Redestab-Methode oder Runden mit festgelegter Zeit helfen, dass alle gehört werden.',
      'Halte Vereinbarungen schriftlich fest. So bleibt klar, was ihr miteinander vereinbart und wie ihr den Fortschritt überprüft.'
    ],
    highlights: [
      'Gemeinsame Wahrnehmung prüfen statt vorschnell urteilen',
      'Zeitlich strukturierte Feedbackrunden etablieren',
      'Vereinbarungen dokumentieren und nachhalten'
    ],
    publishedAt: '2024-02-02'
  },
  {
    slug: 'eigene-grenzen-ernst-nehmen',
    title: 'Eigene Grenzen ernst nehmen',
    category: 'Selbstfürsorge',
    readingTime: '5 Min.',
    teaser: 'Warum Grenzen wichtig sind und wie Du sie klar und freundlich kommunizierst.',
    cover: 'https://picsum.photos/1200/800?random=13',
    content: [
      'Grenzen zu spüren und auszusprechen ist kein Egoismus. Es ist Selbstfürsorge und die Basis eines gesunden Miteinanders. Beginne damit, Deine Warnsignale zu kennen: Wo im Körper spürst Du Anspannung, bevor es zu viel wird?',
      'Formuliere Deine Grenzen respektvoll und konkret. Statt „Du nervst mich“: „Ich merke, dass ich nach einem langen Tag Ruhe brauche. Lass uns morgen weiterreden.“',
      'Grenzen brauchen Pflege. Je öfter Du sie klar kommunizierst, desto leichter wird es – und desto verlässlicher wirst Du von anderen wahrgenommen.'
    ],
    highlights: [
      'Körperliche Signale wahrnehmen und ernst nehmen',
      'Ich-Botschaften nutzen, um Grenzen zu formulieren',
      'Dranbleiben und Grenzen regelmäßig überprüfen'
    ],
    publishedAt: '2024-04-15'
  },
  {
    slug: 'kritik-gelassen-annehmen',
    title: 'Kritik gelassen annehmen',
    category: 'Persönliche Entwicklung',
    readingTime: '6 Min.',
    teaser: 'Mit Atem, Struktur und Nachfragen sorgst Du dafür, dass Kritik nicht verletzt, sondern weiterhilft.',
    cover: 'https://picsum.photos/1200/800?random=14',
    content: [
      'Kritik fühlt sich selten angenehm an. Hilfreich ist, zwischen Inhalt und Emotion zu unterscheiden. Höre bewusst zu, atme ruhig und fasse das Gesagte kurz zusammen.',
      'Frage nach Beispielen und Lösungen. So zeigst Du, dass Du Verantwortung übernimmst, und bekommst konkret, was Dein Gegenüber sich wünscht.',
      'Nimm Dir Zeit für Reflexion. Nicht jede Kritik passt zu Dir. Prüfe in Ruhe, was Du mitnehmen möchtest – und danke für die Offenheit, auch wenn Du nicht alles übernimmst.'
    ],
    highlights: [
      'Ruhe bewahren durch bewusstes Atmen',
      'Nach Beispielen fragen statt zu rechtfertigen',
      'Reflektieren, was wirklich passt – und Rückmeldung geben'
    ],
    publishedAt: '2024-06-04'
  }
];