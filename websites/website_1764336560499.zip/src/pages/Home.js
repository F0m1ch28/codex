import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { blogPosts } from '../data/blogPosts';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Teilnehmende, die mehr Klarheit spüren', target: 94, suffix: '%', prefix: '' },
  { label: 'Begleitete Gespräche & Workshops', target: 1280, suffix: '+', prefix: '' },
  { label: 'Tage mit praktischen Übungsformaten', target: 365, suffix: '/Jahr', prefix: '' }
];

const testimonials = [
  {
    name: 'Lena, 36',
    role: 'Teamleitung Marketing',
    quote:
      '„Durch Silaventino habe ich endlich einen Gesprächsrahmen, der meine Meetings ruhig und gleichzeitig verbindlich hält. Mein Team bedankt sich spürbar.“'
  },
  {
    name: 'Amir, 42',
    role: 'Pflegebereichsleitung',
    quote:
      '„Die Tools sind praxisnah, verständlich und lassen sich sofort umsetzen. Besonders die Leitfragen zur Vorbereitung sind Gold wert.“'
  },
  {
    name: 'Eva, 29',
    role: 'Mediatorin in Ausbildung',
    quote:
      '„Ich nutze die Programme, um mich vorzubereiten – und gewinne unglaublich viel Sicherheit für schwierige Gespräche mit Familien.“'
  }
];

const teamMembers = [
  {
    name: 'Mira Hoffmann',
    role: 'Gründerin & Coach',
    description: 'Systemische Coachin, spezialisiert auf Alltagskommunikation und Konfliktmoderation in Familien.',
    image: 'https://picsum.photos/400/400?random=21'
  },
  {
    name: 'Jonas Kühn',
    role: 'Trainer für Teamdialoge',
    description: 'Facilitator für Teamprozesse, arbeitet mit Unternehmen zu Feedbackkultur und respektvollem Miteinander.',
    image: 'https://picsum.photos/400/400?random=22'
  },
  {
    name: 'Sibel Kaya',
    role: 'Kommunikationsdesignerin',
    description: 'Sorgt dafür, dass Übungen visuell verständlich, gut strukturiert und für Dich leicht nutzbar sind.',
    image: 'https://picsum.photos/400/400?random=23'
  }
];

const projectCases = [
  {
    title: 'Workshop „Fair sprechen im Schichtdienst“',
    category: 'Gesundheitswesen',
    description: 'Strukturiertere Übergabegespräche und weniger Missverständnisse zwischen Tag- und Nachtdienst.',
    image: 'https://picsum.photos/800/600?random=31'
  },
  {
    title: 'Teamoffsite „Feedback, das ankommt“',
    category: 'Unternehmen',
    description: 'Klare Feedback-Routinen für ein wachsendes Start-up mit 40 Mitarbeitenden.',
    image: 'https://picsum.photos/800/600?random=32'
  },
  {
    title: 'Moderation „Familienrat“',
    category: 'Privatpersonen',
    description: 'Wertschätzende Kommunikationsabsprachen für Patchwork-Familie mit Jugendlichen.',
    image: 'https://picsum.photos/800/600?random=33'
  },
  {
    title: 'Training „Kritik gelassen annehmen“',
    category: 'Unternehmen',
    description: 'Modulares Training für Führungskräfte mit Rollenspielen und Transferplänen.',
    image: 'https://picsum.photos/800/600?random=34'
  }
];

const faqItems = [
  {
    question: 'Für wen ist Silaventino gedacht?',
    answer:
      'Für Menschen in Deutschland, die ihre Gespräche achtsamer und klarer führen möchten – ob privat, beruflich oder in ehrenamtlichen Rollen.'
  },
  {
    question: 'Brauche ich Vorkenntnisse?',
    answer:
      'Nein. Die Inhalte sind alltagstauglich erklärt, mit Beispielen, Reflexionsfragen und praktischen Übungen, die Du sofort testen kannst.'
  },
  {
    question: 'Sind die Angebote als Therapie gedacht?',
    answer:
      'Silaventino unterstützt Dich präventiv und praktisch im Alltag. Es ersetzt keine psychotherapeutische oder rechtliche Beratung.'
  },
  {
    question: 'Wie lange habe ich Zugriff auf Programme?',
    answer:
      'Alle Programme und Tools stehen Dir dauerhaft zur Verfügung, damit Du sie immer wieder nutzen und vertiefen kannst.'
  }
];

const Home = () => {
  const [currentStats, setCurrentStats] = useState(statsConfig.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const statsRef = useRef(null);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [openFaqIndex, setOpenFaqIndex] = useState(null);

  const categories = useMemo(() => ['Alle', ...new Set(projectCases.map(project => project.category))], []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting && !statsAnimated) {
            setStatsAnimated(true);
          }
        });
      },
      { threshold: 0.3 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, [statsAnimated]);

  useEffect(() => {
    if (statsAnimated) {
      const duration = 1400;
      const start = performance.now();
      const initialValues = statsConfig.map(() => 0);

      const animate = now => {
        const progress = Math.min((now - start) / duration, 1);
        const updatedValues = statsConfig.map((stat, index) =>
          Math.floor(initialValues[index] + progress * stat.target)
        );
        setCurrentStats(updatedValues);
        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };
      requestAnimationFrame(animate);
    }
  }, [statsAnimated]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex(index => (index + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === 'Alle' ? projectCases : projectCases.filter(project => project.category === projectFilter);

  const latestBlogPosts = useMemo(() => blogPosts.slice(0, 3), []);

  const handleFaqToggle = index => {
    setOpenFaqIndex(prev => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Silaventino – Besser reden. Konflikte fair lösen.</title>
        <meta
          name="description"
          content="Praktische Programme, Tools und Impulse für klare, respektvolle Kommunikation im Alltag, in der Familie und im Job."
        />
      </Helmet>
      <section className={`${styles.hero} section-spacing`}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>Kommunikation neu gedacht</span>
              <h1>Besser reden. Konflikte fair lösen.</h1>
              <p>
                Silaventino begleitet Dich dabei, Gespräche bewusster zu führen – mit klaren Schritt-für-Schritt-Guides,
                alltagstauglichen Tools und motivierenden Challenges. Für weniger Streit, mehr Verständnis und ein sicheres Auftreten.
              </p>
              <div className={styles.heroActions}>
                <Link to="/programs" className="btn-primary" aria-label="Programme entdecken">
                  Programme erkunden
                </Link>
                <Link to="/contact" className="btn-secondary" aria-label="Kontakt aufnehmen">
                  Persönlich anfragen
                </Link>
              </div>
              <div className={styles.heroNote}>
                <span className={styles.heroNoteIcon} aria-hidden="true">★</span>
                <div>
                  <strong>Über 1.200 Menschen</strong> nutzen Silaventino für souveräne Gespräche in Alltag und Beruf.
                </div>
              </div>
            </div>
            <div className={styles.heroVisual}>
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Professionelles Gespräch in vertrauensvoller Atmosphäre"
                loading="lazy"
              />
              <div className={styles.heroCard}>
                <h3>Dein Gesprächs-Kompass</h3>
                <p>Reflexion, Ich-Botschaften, klare Grenzen &amp; gemeinsame Lösungen.</p>
                <Link to="/guide" className={styles.heroLink}>
                  Leitfaden ansehen →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section ref={statsRef} className="section-spacing bg-muted">
        <div className="container">
          <div className={styles.stats}>
            {statsConfig.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {stat.prefix}
                  {currentStats[index]}
                  {stat.suffix}
                </span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-spacing">
        <div className="container">
          <div className={styles.benefitsIntro}>
            <h2>Was sich durch starke Kommunikation verändert</h2>
            <p>
              Kommunikation ist kein Zufall. Silaventino zeigt Dir, wie Du Deine Gesprächsführung Schritt für Schritt
              verbesserst – ohne harte Theorie, dafür mit empathischen Übungen und klarer Struktur.
            </p>
          </div>
          <div className={styles.benefitGrid}>
            {[
              {
                title: 'Weniger Streit, mehr Verbindung',
                description: 'Du erkennst Muster und steuerst Gespräche aktiv – dadurch entstehen öfter Momente des Miteinanders.'
              },
              {
                title: 'Mehr Verständnis, auch bei Kritik',
                description: 'Du lernst, Kritik zuzuhören, ohne Dich angegriffen zu fühlen, und formulierst eigene Ansichten klar.'
              },
              {
                title: 'Klarere Worte, sichere Wirkung',
                description: 'Ich-Botschaften, respektvolle Grenzen und Fragen auf Augenhöhe sorgen für mehr Resonanz.'
              },
              {
                title: 'Selbstbewusst auftreten',
                description: 'Mit Vorbereitungstools, Checklisten und Übungen gehst Du auch in schwierige Gespräche souverän hinein.'
              }
            ].map(benefit => (
              <article key={benefit.title} className={styles.benefitCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-spacing highlight-section">
        <div className="container">
          <div className={styles.themesHeader}>
            <h2>Deine Themenfelder</h2>
            <p>Trainiere Kommunikation für die Bereiche, die Dir gerade am wichtigsten sind.</p>
          </div>
          <div className={styles.themeGrid}>
            {[
              {
                title: 'Gespräche im Alltag',
                description: 'Vom kurzen Check-in bis zur Wochenplanung – bleib freundlich und klar.',
                image: 'https://picsum.photos/800/600?random=2'
              },
              {
                title: 'Familie & Partnerschaft',
                description: 'Sensible Themen und wiederkehrende Konflikte fair besprechen.',
                image: 'https://picsum.photos/800/600?random=3'
              },
              {
                title: 'Job & Team',
                description: 'Feedback geben, Meetings moderieren, Konflikte im Team konstruktiv lösen.',
                image: 'https://picsum.photos/800/600?random=4'
              },
              {
                title: 'Schwierige Situationen',
                description: 'Wenn es emotional wird oder viel auf dem Spiel steht – ruhig und respektvoll bleiben.',
                image: 'https://picsum.photos/800/600?random=5'
              }
            ].map(theme => (
              <article key={theme.title} className={styles.themeCard}>
                <img src={theme.image} alt={`${theme.title} – Beispielbild`} loading="lazy" />
                <div>
                  <h3>{theme.title}</h3>
                  <p>{theme.description}</p>
                  <Link to="/programs" className={styles.themeLink}>
                    Passende Programme →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-spacing">
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <h2>Warum Silaventino?</h2>
              <p>
                Wir übersetzen Kommunikationswissen in kurze, greifbare Einheiten. So kannst Du jederzeit nachlesen,
                üben und reflektieren – allein, zu zweit oder mit Deinem Team.
              </p>
              <ul className={styles.checkList}>
                <li>Mobile-first aufbereitet – üben, wann immer Du willst</li>
                <li>Emotionale, kognitive und körperliche Ebene im Blick</li>
                <li>Seriös, respektvoll, ohne leere Versprechen</li>
                <li>Für Deutschland entwickelt – kulturell und rechtlich passend</li>
              </ul>
              <Link to="/about" className="btn-tertiary">
                Mehr über unsere Haltung
              </Link>
            </div>
            <div className={styles.processCard}>
              <h3>Unser Prozess</h3>
              <ol>
                <li>
                  <strong>1. Wahrnehmen:</strong> Du verstehst Situationen und Muster.
                </li>
                <li>
                  <strong>2. Strukturieren:</strong> Du planst Deine Gesprächsschritte.
                </li>
                <li>
                  <strong>3. Üben:</strong> Du trainierst kurze Sequenzen in Deinem Tempo.
                </li>
                <li>
                  <strong>4. Anwenden:</strong> Du gehst vorbereitet ins Gespräch.
                </li>
                <li>
                  <strong>5. Reflektieren:</strong> Du analysierst, was gut lief – und was Du nachschärfen möchtest.
                </li>
              </ol>
            </div>
          </div>
        </div>
      </section>

      <section className="section-spacing bg-muted">
        <div className="container">
          <div className={styles.programPreview}>
            <div>
              <h2>Schritt-für-Schritt durch Deinen Leitfaden</h2>
              <p>
                Unser 5-Schritte-Leitfaden führt Dich vom ersten Reflexionsmoment bis zur gemeinsamen Lösung. Jeder Schritt ist mit Reflexionsfragen, Beispielen und Formulierungshilfen ausgestattet.
              </p>
              <Link to="/guide" className="btn-primary">
                Leitfaden entdecken
              </Link>
            </div>
            <ul className={styles.stepsList}>
              {[
                'Eigene Muster erkennen',
                'Aktiv zuhören',
                'Ich-Botschaften nutzen',
                'Grenzen klar und respektvoll ausdrücken',
                'Gemeinsame Lösungen finden'
              ].map(step => (
                <li key={step}>
                  <span aria-hidden="true">✓</span>
                  {step}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="section-spacing">
        <div className="container">
          <div className={styles.testimonials}>
            <div className={styles.testimonialHeader}>
              <h2>Stimmen aus der Community</h2>
              <p>Menschen aus ganz Deutschland berichten, wie Silaventino sie auf ihrem Kommunikationsweg unterstützt.</p>
            </div>
            <div className={styles.testimonialCarousel}>
              <p className={styles.testimonialQuote}>{testimonials[testimonialIndex].quote}</p>
              <div className={styles.testimonialMeta}>
                <span className={styles.testimonialName}>{testimonials[testimonialIndex].name}</span>
                <span className={styles.testimonialRole}>{testimonials[testimonialIndex].role}</span>
              </div>
              <div className={styles.carouselControls}>
                <button
                  type="button"
                  onClick={() =>
                    setTestimonialIndex(index => (index - 1 + testimonials.length) % testimonials.length)
                  }
                  aria-label="Vorheriges Testimonial"
                >
                  ←
                </button>
                <button
                  type="button"
                  onClick={() => setTestimonialIndex(index => (index + 1) % testimonials.length)}
                  aria-label="Nächstes Testimonial"
                >
                  →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section-spacing bg-muted">
        <div className="container">
          <div className={styles.teamSection}>
            <div className={styles.teamIntro}>
              <h2>Das Team hinter Silaventino</h2>
              <p>
                Wir verbinden Coaching, Training und Gestaltung. So entstehen Inhalte, die fachlich fundiert, empathisch
                formuliert und visuell klar sind.
              </p>
            </div>
            <div className={styles.teamGrid}>
              {teamMembers.map(member => (
                <article key={member.name} className={styles.teamCard}>
                  <div className={styles.teamImageWrapper}>
                    <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                    <div className={styles.teamOverlay}>
                      <p>{member.description}</p>
                    </div>
                  </div>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section-spacing">
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2>Erprobte Formate &amp; Projekte</h2>
            <div className={styles.filterButtons} role="tablist" aria-label="Projektfilter">
              {categories.map(category => (
                <button
                  key={category}
                  className={projectFilter === category ? styles.filterActive : undefined}
                  onClick={() => setProjectFilter(category)}
                  role="tab"
                  aria-selected={projectFilter === category}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map(project => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={`Projekt: ${project.title}`} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-spacing bg-muted">
        <div className="container">
          <div className={styles.faq}>
            <div className={styles.faqIntro}>
              <h2>Häufige Fragen</h2>
              <p>Wir möchten, dass Du Dich sicher fühlst, bevor Du startest. Hier findest Du Antworten auf die wichtigsten Fragen.</p>
            </div>
            <div className={styles.faqList}>
              {faqItems.map((item, index) => (
                <div key={item.question} className={styles.faqItem}>
                  <button
                    onClick={() => handleFaqToggle(index)}
                    aria-expanded={openFaqIndex === index}
                    aria-controls={`faq-panel-${index}`}
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true">{openFaqIndex === index ? '–' : '+'}</span>
                  </button>
                  <div
                    id={`faq-panel-${index}`}
                    className={`${styles.faqContent} ${openFaqIndex === index ? styles.faqOpen : ''}`}
                  >
                    <p>{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section-spacing">
        <div className="container">
          <div className={styles.blogPreview}>
            <div className={styles.blogIntro}>
              <h2>Aktuelle Impulse aus dem Blog</h2>
              <p>Kurze Artikel mit konkreten Beispielen, die Dir helfen, sofort etwas Neues auszuprobieren.</p>
            </div>
            <div className={styles.blogGrid}>
              {latestBlogPosts.map(post => (
                <article key={post.slug} className={styles.blogCard}>
                  <img src={post.cover} alt={post.title} loading="lazy" />
                  <div>
                    <span className={styles.blogMeta}>
                      {post.category} · {post.readingTime}
                    </span>
                    <h3>{post.title}</h3>
                    <p>{post.teaser}</p>
                    <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                      Weiterlesen →
                    </Link>
                  </div>
                </article>
              ))}
            </div>
            <div className={styles.blogCTA}>
              <Link to="/blog" className="btn-tertiary">
                Alle Artikel ansehen
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} section-spacing`}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Bereit, Deine Kommunikation zu stärken?</h2>
              <p>
                Starte mit unserem Leitfaden, wähle ein Programm oder lass Dich persönlich begleiten. Silaventino macht
                Dich sicherer – Schritt für Schritt.
              </p>
            </div>
            <div className={styles.ctaButtons}>
              <Link to="/programs" className="btn-primary">
                Programm wählen
              </Link>
              <Link to="/contact" className="btn-secondary">
                Beratung anfragen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;