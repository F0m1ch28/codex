import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Website Fußbereich">
    <div className="container">
      <div className={styles.grid}>
        <div>
          <div className={styles.brand}>
            <span className={styles.logoAccent}>Sila</span>ventino
          </div>
          <p>
            Silaventino stärkt Dich dabei, Gespräche klar, respektvoll und sicher zu führen – im Alltag, in Familien
            und im Job.
          </p>
          <ul className={styles.contactList}>
            <li>
              <a href="mailto:hallo@silaventino.de">hallo@silaventino.de</a>
            </li>
            <li><a href="tel:+49301234567">+49 (0)30 123 4567</a></li>
            <li>Silaventino Kommunikation, Musterstraße 12, 10115 Berlin</li>
          </ul>
        </div>
        <div>
          <h4>Entdecken</h4>
          <ul>
            <li><Link to="/guide">Leitfaden</Link></li>
            <li><Link to="/programs">Programme</Link></li>
            <li><Link to="/tools">Tools</Link></li>
            <li><Link to="/blog">Blog &amp; Impulse</Link></li>
          </ul>
        </div>
        <div>
          <h4>Unternehmen</h4>
          <ul>
            <li><Link to="/about">Über Silaventino</Link></li>
            <li><Link to="/services">Angebote</Link></li>
            <li><Link to="/contact">Kontakt</Link></li>
          </ul>
        </div>
        <div>
          <h4>Rechtliches</h4>
          <ul>
            <li><Link to="/imprint">Impressum</Link></li>
            <li><Link to="/privacy">Datenschutz</Link></li>
            <li><Link to="/legal">AGB</Link></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Silaventino. Alle Rechte vorbehalten.</span>
        <div className={styles.socials} aria-label="Social Media">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            <span aria-hidden="true">in</span>
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
            <span aria-hidden="true">IG</span>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
            <span aria-hidden="true">YT</span>
          </a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;