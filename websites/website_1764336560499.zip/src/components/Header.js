import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="Silaventino Startseite">
            <span className={styles.logoAccent}>Sila</span>ventino
          </Link>
          <button
            className={styles.burger}
            onClick={() => setMenuOpen(prev => !prev)}
            aria-label={menuOpen ? 'Navigation schließen' : 'Navigation öffnen'}
            aria-expanded={menuOpen}
          >
            <span />
            <span />
            <span />
          </button>
          <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Hauptnavigation">
            <NavLink to="/" end className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Start
            </NavLink>
            <NavLink to="/guide" className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Leitfaden
            </NavLink>
            <NavLink to="/programs" className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Programme
            </NavLink>
            <NavLink to="/tools" className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Tools
            </NavLink>
            <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Blog
            </NavLink>
            <NavLink to="/services" className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Angebote
            </NavLink>
            <NavLink to="/about" className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Über uns
            </NavLink>
            <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.active : undefined)}>
              Kontakt
            </NavLink>
            <Link to="/programs" className={`${styles.cta} btn-primary`}>
              Jetzt starten
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;