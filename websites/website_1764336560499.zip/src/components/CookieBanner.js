import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'silaventino-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = value => {
    window.localStorage.setItem(COOKIE_KEY, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Cookies &amp; Privatsphäre</h4>
        <p>
          Wir verwenden technisch erforderliche Cookies, um Dir eine sichere Nutzung zu ermöglichen. Weitere Infos findest Du in unserer{' '}
          <a href="/privacy">Datenschutzerklärung</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button className="btn-secondary" onClick={() => handleConsent('necessary')}>
          Verstanden
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;