document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            navToggle.classList.toggle('is-active');
            document.body.classList.toggle('nav-open');
        });

        siteNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                document.body.classList.remove('nav-open');
                navToggle.classList.remove('is-active');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');

    if (cookieBanner) {
        const consent = localStorage.getItem('cookieConsent');
        if (consent === 'accepted' || consent === 'declined') {
            cookieBanner.classList.add('is-hidden');
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                localStorage.setItem('cookieConsent', 'accepted');
                cookieBanner.classList.add('is-hidden');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                localStorage.setItem('cookieConsent', 'declined');
                cookieBanner.classList.add('is-hidden');
            });
        }
    }
});