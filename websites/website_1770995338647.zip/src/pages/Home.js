import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const Home = () => {
  const services = [
    {
      title: 'Информационные гайды',
      description:
        'Подготовленные экспертами материалы о правах, здоровье и безопасном общении для ЛГБТК+ людей и их союзников.',
      link: '/resources',
      color: '#5BCEFA',
    },
    {
      title: 'Психологическая поддержка',
      description:
        'Проверенные психологи, горячие линии и чаты взаимопомощи. Получите поддержку от людей, которым можно доверять.',
      link: '/support',
      color: '#F5A9B8',
    },
    {
      title: 'Сообщество и мероприятия',
      description:
        'Онлайн и оффлайн события, встречи, воркшопы, арт-проекты и безопасные пространства для обмена опытом.',
      link: '/events',
      color: '#FFED00',
    },
  ];

  const testimonials = [
    {
      name: 'Катя, 23 года (она/она)',
      quote:
        '«На Пространстве Rainbow я впервые встретила людей, которые понимают и не осуждают. Особенно помогли материалы о коминг-ауте и разговоры с психологом.»',
      avatar:
        'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80',
    },
    {
      name: 'Марк, 28 лет (он/они)',
      quote:
        '«Благодаря вебинарам и встречам я нашёл друзей и почувствовал силы действовать. Здесь действительно безопасно и вдохновляюще.»',
      avatar:
        'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=120&q=80',
    },
    {
      name: 'Амина, 31 год (она/они)',
      quote:
        '«Команда помогает оперативно и бережно, а подборка юристов стала настоящим спасением. Спасибо за ваше дело!»',
      avatar:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=120&q=80',
    },
  ];

  const highlights = [
    {
      title: '80+ материалов',
      description: 'Экспертные статьи, исследования и практические рекомендации.',
    },
    {
      title: '24/7 поддержка',
      description: 'Доступ к чату взаимной помощи и проверенным горячим линиям.',
    },
    {
      title: 'Сообщество в 12 городах',
      description: 'Регулярные мероприятия по всей России и в онлайн-формате.',
    },
  ];

  const upcomingEvents = [
    {
      title: 'Онлайн-встреча «Квир-среда»',
      date: '15 мая 2024',
      format: 'онлайн',
      description: 'Час безопасного общения и взаимной поддержки в небольших группах.',
    },
    {
      title: 'Воркшоп «Права и защита»',
      date: '22 мая 2024',
      format: 'Москва',
      description: 'Практикум с юристами по защите прав ЛГБТК+ людей и их союзников.',
    },
    {
      title: 'Лекторий «Истории видимости»',
      date: '30 мая 2024',
      format: 'онлайн',
      description: 'Истории активизма, искусства и научных исследований в ЛГБТК+ сообществе.',
    },
  ];

  const blogPosts = [
    {
      title: 'Как заботиться о себе в период повышенного стресса',
      link: '/blog',
      category: 'Саморазвитие',
      image:
        'https://images.unsplash.com/photo-1527631746610-bca00a040d60?auto=format&fit=crop&w=500&q=80',
    },
    {
      title: 'Гайд по безопасному коминг-ауту в российской реальности',
      link: '/blog',
      category: 'Права и безопасность',
      image:
        'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=500&q=80',
    },
    {
      title: 'История сообщества: как мы поддерживаем друг друга',
      link: '/blog',
      category: 'Сообщество',
      image:
        'https://images.unsplash.com/photo-1497493292307-31c376b6e479?auto=format&fit=crop&w=500&q=80',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Пространство Rainbow — поддержка и ресурсы для ЛГБТК+</title>
        <meta
          name="description"
          content="Пространство Rainbow — информационный и поддерживающий ресурс для ЛГБТК+ сообщества в России. Материалы, психологическая помощь, мероприятия и безопасное общение."
        />
        <meta
          name="keywords"
          content="ЛГБТ, ЛГБТК+, гей, лесбиянка, бисексуал, трансгендер, квир, поддержка, ресурсы, безопасность"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.hero}>
          <div className={styles.heroContent}>
            <p className={styles.heroTagline}>Инклюзивное пространство</p>
            <h1 className={styles.heroTitle}>
              Пространство Rainbow — безопасная поддержка ЛГБТК+ сообщества на русском языке
            </h1>
            <p className={styles.heroDescription}>
              Мы объединяем тех, кто ценит разнообразие. Здесь вы найдёте проверенные ресурсы,
              психологическую и юридическую помощь, события и людей, готовых поддержать.
            </p>
            <div className={styles.heroActions}>
              <Link to="/support" className={"${styles.heroButton} ${styles.heroButtonPrimary}"}>
                Найти поддержку
              </Link>
              <Link to="/events" className={"${styles.heroButton} ${styles.heroButtonSecondary}"}>
                Присоединиться к событиям
              </Link>
            </div>
            <ul className={styles.heroHighlights}>
              <li>
                <span>Безопасность</span> — этичные модераторы и проверенные специалисты
              </li>
              <li>
                <span>Видимость</span> — пространство для рассказов, знаний и творчества
              </li>
              <li>
                <span>Сопричастность</span> — сообщество, в котором слышат и принимают
              </li>
            </ul>
          </div>
          <div className={styles.heroVisual} aria-hidden="true">
            <div className={styles.heroGradient} />
            <img
              src="https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=80"
              alt="Люди с радужным флагом"
            />
          </div>
        </section>

        <section className={styles.services} id="services">
          <header className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Что мы предлагаем</p>
            <h2 className={styles.sectionTitle}>Поддержка, которой можно доверять</h2>
            <p className={styles.sectionDescription}>
              Сочетание практических знаний, живого общения и профессиональной помощи. Всё, чтобы вы
              чувствовали себя уверенно, где бы ни были.
            </p>
          </header>
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div
                  className={styles.serviceIcon}
                  style={{ backgroundColor: service.color }}
                  aria-hidden="true"
                />
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to={service.link} className={styles.serviceLink}>
                  Подробнее →
                </Link>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.aboutPreview}>
          <div className={styles.aboutContent}>
            <p className={styles.sectionEyebrow}>О сообществе</p>
            <h2 className={styles.sectionTitle}>Миссия — заботиться, просвещать, объединять</h2>
            <p className={styles.sectionDescription}>
              Пространство создают активисты, психологи, юристы и просто неравнодушные люди.
              Вместе с партнёрами мы развиваем сеть взаимной помощи, делимся знаниями и создаём
              события, где каждый может быть собой.
            </p>
            <Link to="/about" className={styles.primaryLink}>
              Узнать нашу историю
            </Link>
          </div>
          <div className={styles.aboutVisual} aria-hidden="true">
            <img
              src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=700&q=80"
              alt="Улыбающиеся люди"
            />
          </div>
        </section>

        <section className={styles.resourcesPreview}>
          <header className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Подборка ресурсов</p>
            <h2 className={styles.sectionTitle}>Начните с важного</h2>
          </header>
          <div className={styles.resourceGrid}>
            <article className={styles.resourceCard}>
              <h3>Права и безопасность</h3>
              <p>
                Пошаговые инструкции, как действовать в сложных ситуациях, памятки по взаимодействию
                с организациями и советы юристов.
              </p>
              <Link to="/resources">Все материалы →</Link>
            </article>
            <article className={styles.resourceCard}>
              <h3>Здоровье и благополучие</h3>
              <p>
                Руководства по психическому и физическому здоровью, список дружелюбных специалистов
                и клиник.
              </p>
              <Link to="/support">Перейти к поддержке →</Link>
            </article>
            <article className={styles.resourceCard}>
              <h3>Союзники и семьи</h3>
              <p>
                Вспомогательные статьи для родителей, коллег и друзей, которые хотят поддержать
                близких и стать союзниками.
              </p>
              <Link to="/blog">Читать блог →</Link>
            </article>
          </div>
        </section>

        <section className={styles.testimonials}>
          <header className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Голоса сообщества</p>
            <h2 className={styles.sectionTitle}>Каждый опыт важен</h2>
          </header>
          <div className={styles.testimonialGrid}>
            {testimonials.map((item) => (
              <article key={item.name} className={styles.testimonialCard}>
                <div className={styles.testimonialProfile}>
                  <img src={item.avatar} alt={item.name} />
                  <div>
                    <p className={styles.testimonialName}>{item.name}</p>
                    <span className={styles.testimonialBadge}>Участница/участник сообщества</span>
                  </div>
                </div>
                <p className={styles.testimonialQuote}>{item.quote}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.events}>
          <header className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Ближайшие события</p>
            <h2 className={styles.sectionTitle}>Присоединяйтесь и будьте на связи</h2>
          </header>
          <div className={styles.eventsGrid}>
            {upcomingEvents.map((event) => (
              <article key={event.title} className={styles.eventCard}>
                <div className={styles.eventHeader}>
                  <span className={styles.eventDate}>{event.date}</span>
                  <span className={styles.eventFormat}>{event.format}</span>
                </div>
                <h3>{event.title}</h3>
                <p>{event.description}</p>
                <Link to="/events" className={styles.eventLink}>
                  Все события →
                </Link>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.blog}>
          <header className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Истории и знания</p>
            <h2 className={styles.sectionTitle}>Свежие публикации блога</h2>
          </header>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img src={post.image} alt={post.title} />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogCategory}>{post.category}</span>
                  <h3>{post.title}</h3>
                  <Link to={post.link} className={styles.blogLink}>
                    Читать →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.highlights}>
          <div className={styles.highlightGrid}>
            {highlights.map((item) => (
              <article key={item.title} className={styles.highlightCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.cta}>
          <div className={styles.ctaContent}>
            <h2>Готовы сделать шаг навстречу поддержке?</h2>
            <p>
              Делитесь историей, задавайте вопросы, вступайте в комьюнити. Вместе мы создаём
              пространство, основанное на уважении, безопасности и честности.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contact" className={"${styles.heroButton} ${styles.heroButtonPrimary}"}>
                Написать нам
              </Link>
              <Link to="/resources" className={"${styles.heroButton} ${styles.heroButtonSecondary}"}>
                Изучить материалы
              </Link>
            </div>
          </div>
        </section>

        <section className={styles.contactPreview}>
          <div className={styles.contactCard}>
            <h2>Нужна срочная поддержка?</h2>
            <p>
              Напишите нам по адресу{' '}
              <a href="mailto:info@rainbowspace.ru">info@rainbowspace.ru</a> или позвоните по номеру{' '}
              <a href="tel:+79991234567">+7 (999) 123-45-67</a>. Мы поможем найти психолога,
              юриста или тематическое сообщество.
            </p>
            <Link to="/support" className={styles.contactLink}>
              Перейти в раздел поддержки →
            </Link>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;