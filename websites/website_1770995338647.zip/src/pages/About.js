import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const About = () => {
  const values = [
    {
      title: 'Безопасность и доверие',
      description:
        'Мы создаём пространство, где каждый может быть услышан. Команда модераторов гарантирует этичное взаимодействие и защиту от дискриминации.',
    },
    {
      title: 'Расширение прав и возможностей',
      description:
        'Продвигаем знания о правах человека, о доступе к медицинским и образовательным ресурсам. Поддерживаем инициативы, которые делают сообщество сильнее.',
    },
    {
      title: 'Солидарность и взаимопомощь',
      description:
        'Мы объединяем людей, чтобы они могли делиться опытом, оказывать поддержку и чувствовать сопричастность к большому сообществу.',
    },
  ];

  const team = [
    {
      name: 'Антон Лебедев',
      role: 'Куратор сообщества, он/он',
      description:
        'Отвечает за стратегию развития, поддерживает региональные инициативы и координирует работу волонтёров.',
      image:
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=320&q=80',
    },
    {
      name: 'Мария Ким',
      role: 'Психологиня, она/она',
      description:
        'Специализируется на работе с ЛГБТК+ людьми и их семьями. Координирует программу психологической поддержки.',
      image:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=320&q=80',
    },
    {
      name: 'Дана Серебрякова',
      role: 'Юристка, она/они',
      description:
        'Экспертка по правам человека и антидискриминационному законодательству. Ведёт вебинары и индивидуальные консультации.',
      image:
        'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=320&q=80',
    },
  ];

  return (
    <>
      <Helmet>
        <title>О нас — Пространство Rainbow</title>
        <meta
          name="description"
          content="Узнайте о миссии, ценностях и команде Пространства Rainbow — безопасного ресурса для ЛГБТК+ сообщества."
        />
        <meta
          name="keywords"
          content="ЛГБТ, ЛГБТК+, миссия, команда, поддержка, ценности, безопасность"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.intro}>
          <p className={styles.eyebrow}>О проекте</p>
          <h1>Мы создаём пространство, где ценят разнообразие</h1>
          <p>
            Пространство Rainbow появилось как ответ на запрос о поддержке, достоверной информации и
            безопасном общении для ЛГБТК+ людей в России и других русскоязычных странах. Мы верим, что
            знание и солидарность делают сообщество сильнее, а взаимное уважение помогает каждому
            чувствовать себя значимым.
          </p>
        </section>

        <section className={styles.mission}>
          <div className={styles.missionCard}>
            <h2>Наша миссия</h2>
            <p>
              Поддерживать ЛГБТК+ людей, их семьи и союзников, создавая доступ к знаниям, помощи и
              ресурсам. Мы стремимся к будущему, где каждый может быть собой без страха и
              дискриминации.
            </p>
            <p>
              За каждым разделом сайта стоит команда волонтёров, экспертов и союзников. Мы работаем с
              психологами, юристами, врачами и активистами, чтобы предоставлять только проверенную и
              полезную информацию.
            </p>
          </div>
          <div className={styles.missionCard}>
            <h2>Что мы делаем</h2>
            <ul>
              <li>Публикуем материалы о правах, здоровье, образовании и самоопределении.</li>
              <li>Запускаем программы психологической и юридической поддержки.</li>
              <li>Организуем мероприятия и сети взаимопомощи в онлайн- и оффлайн-форматах.</li>
              <li>Поддерживаем семьи и союзников, которые хотят лучше понимать ЛГБТК+ людей.</li>
            </ul>
          </div>
        </section>

        <section className={styles.values}>
          <header className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Ценности</p>
            <h2>Наши принципы</h2>
          </header>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.team}>
          <header className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Команда</p>
            <h2>Люди, которые делают пространство живым</h2>
            <p>
              Мы объединяем профессионалов и волонтёров, которые разделяют ценности уважения и
              солидарности. Команда постоянно растёт — присоединяйтесь к нам!
            </p>
          </header>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default About;