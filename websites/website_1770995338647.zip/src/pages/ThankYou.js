import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation, Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYou = () => {
  const location = useLocation();
  const personName = location.state?.name || 'друг';

  return (
    <>
      <Helmet>
        <title>Спасибо за обращение — Пространство Rainbow</title>
        <meta
          name="description"
          content="Спасибо, что связались с команде Пространства Rainbow. Мы ответим в ближайшее время."
        />
      </Helmet>
      <div className={styles.page}>
        <div className={styles.card}>
          <h1>Спасибо, {personName}!</h1>
          <p>
            Мы получили ваше сообщение и ответим на него в течение двух рабочих дней. Если вопрос
            срочный, напишите нам по адресу{' '}
            <a href="mailto:info@rainbowspace.ru">info@rainbowspace.ru</a> или позвоните по номеру{' '}
            <a href="tel:+79991234567">+7 (999) 123-45-67</a>.
          </p>
          <div className={styles.actions}>
            <Link to="/" className={styles.actionButton}>
              Вернуться на главную
            </Link>
            <Link to="/resources" className={styles.secondaryButton}>
              Посмотреть ресурсы
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default ThankYou;