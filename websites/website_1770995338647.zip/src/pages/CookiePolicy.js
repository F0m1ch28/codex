import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика использования файлов cookie — Пространство Rainbow</title>
      <meta
        name="description"
        content="Узнайте, какие файлы cookie использует Пространство Rainbow и как вы можете управлять ими."
      />
    </Helmet>
    <div className={styles.page}>
      <h1>Политика использования файлов cookie</h1>
      <p>
        Cookies помогают нам обеспечить стабильную работу сайта и улучшать пользовательский опыт.
        Ниже описано, какие cookies мы применяем и как вы можете управлять ими.
      </p>

      <section>
        <h2>1. Что такое cookies</h2>
        <p>
          Cookies — это небольшие файлы, которые сохраняются на вашем устройстве. Они позволяют запомнить
          ваши настройки и анализировать посещаемость.
        </p>
      </section>

      <section>
        <h2>2. Какие cookies мы используем</h2>
        <ul>
          <li>
            <strong>Обязательные cookies:</strong> необходимы для работы сайта (согласие на использование
            cookies, настройки языка).
          </li>
          <li>
            <strong>Аналитические cookies:</strong> помогают понять, какие страницы самые популярные и как
            пользователи взаимодействуют с сайтом.
          </li>
        </ul>
      </section>

      <section>
        <h2>3. Управление cookies</h2>
        <p>
          Вы можете настроить или удалить cookies в настройках своего браузера. Обратите внимание, что
          отключение обязательных cookies может повлиять на работу сайта.
        </p>
      </section>

      <section>
        <h2>4. Обновления политики</h2>
        <p>
          Мы можем обновлять политику cookies. Изменения вступают в силу с момента публикации на этой
          странице.
        </p>
      </section>

      <section>
        <h2>5. Контакты</h2>
        <p>По вопросам использования cookies пишите на info@rainbowspace.ru.</p>
      </section>
    </div>
  </>
);

export default CookiePolicy;