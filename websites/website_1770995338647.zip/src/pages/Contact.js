import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const sanitizeInput = (value) => value.replace(/[<>]/g, '');

const Contact = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    message: '',
  });
  const [errors, setErrors] = React.useState({});
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: sanitizeInput(value),
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите своё имя.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите электронную почту.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Проверьте, корректно ли указан адрес электронной почты.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите, как мы можем помочь.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Сообщение должно содержать не менее 10 символов.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      navigate('/thank-you', { replace: true, state: { name: formData.name.trim() } });
    }, 600);
  };

  return (
    <>
      <Helmet>
        <title>Контакты — Пространство Rainbow</title>
        <meta
          name="description"
          content="Свяжитесь с командой Пространства Rainbow: email, телефон, форма обратной связи."
        />
        <meta
          name="keywords"
          content="контакты, ЛГБТ поддержка, обратная связь, email, телефон"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.contactInfo}>
          <h1>Свяжитесь с нами</h1>
          <p>
            Мы открыты к вопросам, предложениям и обратной связи. Напишите нам, и мы обязательно
            ответим в течение двух рабочих дней.
          </p>
          <div className={styles.details}>
            <div>
              <h2>Email</h2>
              <a href="mailto:info@rainbowspace.ru">info@rainbowspace.ru</a>
            </div>
            <div>
              <h2>Телефон</h2>
              <a href="tel:+79991234567">+7 (999) 123-45-67</a>
            </div>
            <div>
              <h2>Адрес</h2>
              <p>123456, г. Москва, ул. Примерная, д. 1, офис 10</p>
            </div>
          </div>
        </section>

        <section className={styles.formSection}>
          <h2>Форма обратной связи</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Имя</label>
              <input
                id="name"
                name="name"
                type="text"
                autoComplete="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Например, Алина"
                required
              />
              {errors.name && <p className={styles.error}>{errors.name}</p>}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Электронная почта</label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="example@mail.com"
                required
              />
              {errors.email && <p className={styles.error}>{errors.email}</p>}
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                placeholder="Расскажите кратко, чем мы можем помочь."
                required
              />
              {errors.message && <p className={styles.error}>{errors.message}</p>}
            </div>

            <button type="submit" className={styles.submitButton} disabled={isSubmitting}>
              {isSubmitting ? 'Отправка…' : 'Отправить сообщение'}
            </button>
          </form>
        </section>
      </div>
    </>
  );
};

export default Contact;