import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Resources.module.css';

const Resources = () => {
  const guides = [
    {
      title: 'Юридические права и защита',
      items: [
        'Памятка: общение с органами власти и силовыми структурами',
        'Инструкция: что делать при дискриминации на работе',
        'Советы юристов по оформлению доверенностей и документов',
      ],
    },
    {
      title: 'Здоровье и благополучие',
      items: [
        'Список ЛГБТК+-дружественных врачей и клиник в крупных городах',
        'Гид по ментальному здоровью: как распознать признаки кризиса',
        'Подкасты и вебинары о заботе о себе и устойчивости',
      ],
    },
    {
      title: 'Семьи и союзники',
      items: [
        'Как разговаривать с родителями о своей идентичности',
        'Ресурсы для педагогов и HR-специалистов о недискриминации',
        'Подборка книг и фильмов, которые помогают понять близких',
      ],
    },
  ];

  const organisations = [
    {
      name: 'ЛГБТК+ дружелюбные инициативы',
      description:
        'Список проверенных организаций и инициатив по всей стране, которые оказывают помощь в юридических и социальных вопросах.',
      link: 'https://www.lgbt-initiative.example',
    },
    {
      name: 'Психологическая помощь онлайн',
      description:
        'Каталог психологов и психотерапевтов, проходящих супервизию и работающих с ЛГБТК+ клиентами в безопасном формате.',
      link: 'https://www.lgbt-psychology.example',
    },
    {
      name: 'Сообщество родителей и союзников',
      description:
        'Поддерживающие группы для родителей и родственников ЛГБТК+ людей. Совместные встречи, обучение и обмен опытом.',
      link: 'https://www.ally-community.example',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Ресурсы — Пространство Rainbow</title>
        <meta
          name="description"
          content="Полезные материалы, организации и гайды для ЛГБТК+ людей, их семей и союзников. Проверенные ресурсы о здоровье, правах и безопасности."
        />
        <meta
          name="keywords"
          content="ЛГБТ ресурсы, гайды, поддержка, права, здоровье, безопасность, ЛГБТК+ организации"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.intro}>
          <p className={styles.eyebrow}>Ресурсы</p>
          <h1>Подборка проверенных материалов и организаций</h1>
          <p>
            Мы собрали статьи, руководства и базы контактов, которые прошли экспертную проверку.
            Все материалы обновляются и адаптируются под текущий контекст в России и других
            русскоязычных странах.
          </p>
        </section>

        <section className={styles.guides}>
          {guides.map((guide) => (
            <article key={guide.title} className={styles.guideCard}>
              <h2>{guide.title}</h2>
              <ul>
                {guide.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </section>

        <section className={styles.organisations}>
          <header>
            <p className={styles.eyebrow}>Организации</p>
            <h2>С кем мы сотрудничаем</h2>
          </header>
          <div className={styles.orgGrid}>
            {organisations.map((org) => (
              <article key={org.name} className={styles.orgCard}>
                <h3>{org.name}</h3>
                <p>{org.description}</p>
                <a href={org.link} target="_blank" rel="noopener noreferrer">
                  Перейти на сайт →
                </a>
              </article>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Resources;