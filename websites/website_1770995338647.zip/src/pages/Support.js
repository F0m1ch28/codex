import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Support.module.css';

const Support = () => {
  const hotlines = [
    {
      name: 'Проект доверия «Разговор»',
      description: 'Анонимная поддержка, консультации психологов и волонтёров, работающих с ЛГБТК+ людьми.',
      phone: '+7 (800) 000-00-00',
      schedule: 'Круглосуточно',
    },
    {
      name: 'Чат взаимопомощи «Слышать»',
      description:
        'Наш собственный чат, где круглосуточно дежурят модераторы. Безопасное пространство для общения и поддержки.',
      phone: 'Телеграм-чат',
      schedule: '24/7',
    },
  ];

  const specialists = [
    {
      name: 'Анастасия Костина',
      role: 'Психологиня, работает с ЛГБТК+ молодёжью, она/она',
      contact: 'anastasia-therapy@example.com',
    },
    {
      name: 'Алексей Воронов',
      role: 'Клинический психолог, специалист по работе с семьями, он/он',
      contact: 'voronov-support@example.com',
    },
    {
      name: 'Элина Куат',
      role: 'Психотерапевтка, специализация: гендерная идентичность, она/они',
      contact: 'kuat-therapy@example.com',
    },
  ];

  const legal = [
    {
      title: 'Консультации юристов',
      description:
        'Команда волонтёров-юристов помогает разобраться с вопросами трудового и семейного права, а также с дискриминацией в учебных заведениях.',
    },
    {
      title: 'Памятки по безопасности',
      description:
        'Инструкции об общении с силовыми структурами, алгоритмы действий при угрозах и рекомендации по цифровой безопасности.',
    },
    {
      title: 'Поддержка в кейсах каминг-аута',
      description:
        'Как подготовиться к разговору с близкими, где найти медиатора и как защитить себя эмоционально и юридически.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Поддержка — Пространство Rainbow</title>
        <meta
          name="description"
          content="Психологическая и юридическая поддержка для ЛГБТК+ людей. Горячие линии, специалисты, ресурсы для безопасного общения."
        />
        <meta
          name="keywords"
          content="ЛГБТ поддержка, горячая линия, психолог, юрист, ЛГБТК+, помощь, безопасность"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.intro}>
          <p className={styles.eyebrow}>Поддержка</p>
          <h1>Психологическая и юридическая помощь рядом</h1>
          <p>
            Не оставайтесь один на один с трудностями. Мы собрали горячие линии, специалистов и
            ресурсы, которые работают этично, конфиденциально и поддерживают ЛГБТК+ людей.
          </p>
        </section>

        <section className={styles.hotlines}>
          <header>
            <h2>Горячие линии и чаты</h2>
            <p>Позвоните или напишите, если вам нужна срочная эмоциональная поддержка.</p>
          </header>
          <div className={styles.hotlineList}>
            {hotlines.map((item) => (
              <article key={item.name} className={styles.hotlineCard}>
                <h3>{item.name}</h3>
                <p>{item.description}</p>
                <div className={styles.hotlineInfo}>
                  <span>{item.phone}</span>
                  <span>{item.schedule}</span>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.specialists}>
          <header>
            <h2>Психологи и терапевты</h2>
            <p>
              Каждый специалист прошёл собеседование с нашей командой и имеет опыт работы с ЛГБТК+
              клиентами. Свяжитесь напрямую, чтобы договориться о консультации.
            </p>
          </header>
          <div className={styles.specialistGrid}>
            {specialists.map((person) => (
              <article key={person.name} className={styles.specialistCard}>
                <h3>{person.name}</h3>
                <p className={styles.role}>{person.role}</p>
                <p className={styles.contact}>{person.contact}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.legal}>
          <header>
            <h2>Юридическая поддержка</h2>
          </header>
          <div className={styles.legalGrid}>
            {legal.map((item) => (
              <article key={item.title} className={styles.legalCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Support;