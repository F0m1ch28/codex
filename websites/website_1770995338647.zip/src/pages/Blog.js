import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Blog.module.css';

const Blog = () => {
  const posts = [
    {
      title: 'Как говорить о своей идентичности на работе',
      excerpt:
        'Простые шаги, которые помогут рассказать о себе безопасно и сохранить эмоциональное равновесие.',
      author: 'Команда Пространства Rainbow',
      date: '26 апреля 2024',
      category: 'Работа и учёба',
      image:
        'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=500&q=80',
    },
    {
      title: 'Квир-искусство как способ самоисследования',
      excerpt:
        'Мы собрали подборку проектов художников и художниц, которые переосмысляют опыт ЛГБТК+ и создают новое пространство видимости.',
      author: 'Дарья Ш.',
      date: '19 апреля 2024',
      category: 'Культура',
      image:
        'https://images.unsplash.com/photo-1487412720507-3e6551218c12?auto=format&fit=crop&w=500&q=80',
    },
    {
      title: 'Как поддержать друга в период кризиса',
      excerpt:
        'Советы психологов о том, как говорить, слушать и поддерживать, не нарушая собственные границы.',
      author: 'Мария Ким',
      date: '9 апреля 2024',
      category: 'Поддержка',
      image:
        'https://images.unsplash.com/photo-1453928582365-b6ad33cbcf64?auto=format&fit=crop&w=500&q=80',
    },
    {
      title: 'Гайд по цифровой безопасности для активистов',
      excerpt:
        'Что делать, если аккаунт взломали, как хранить переписки и как безопасно вести социальные сети.',
      author: 'Алексей В.',
      date: '31 марта 2024',
      category: 'Безопасность',
      image:
        'https://images.unsplash.com/photo-1504280390368-3971f536b2c4?auto=format&fit=crop&w=500&q=80',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Блог — Пространство Rainbow</title>
        <meta
          name="description"
          content="Истории, практические советы и новости ЛГБТК+ сообщества. Блог Пространства Rainbow."
        />
        <meta
          name="keywords"
          content="ЛГБТ блог, истории, новости, поддержка, опыт, квир культура"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.intro}>
          <p className={styles.eyebrow}>Блог</p>
          <h1>Истории, которые вдохновляют и поддерживают</h1>
          <p>
            Наш блог — это место, где мы делимся реальными историями, экспертными советами и новостями
            сообщества. Здесь вы найдёте опыт людей из разных городов, подборки ресурсов и практики
            заботы о себе.
          </p>
        </section>

        <section className={styles.grid}>
          {posts.map((post) => (
            <article key={post.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={post.image} alt={post.title} />
              </div>
              <div className={styles.content}>
                <span className={styles.category}>{post.category}</span>
                <h2>{post.title}</h2>
                <p>{post.excerpt}</p>
                <div className={styles.meta}>
                  <span>{post.author}</span>
                  <time dateTime={post.date}>{post.date}</time>
                </div>
              </div>
            </article>
          ))}
        </section>
      </div>
    </>
  );
};

export default Blog;