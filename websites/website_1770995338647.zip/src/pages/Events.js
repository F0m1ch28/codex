import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Events.module.css';

const Events = () => {
  const events = [
    {
      title: 'Лекторий «Истории видимости»',
      date: '30 мая 2024',
      location: 'Онлайн',
      description:
        'Онлайн-лекции о квир-истории России, опыте активизма и вдохновляющих инициативах. Формат: короткие выступления и Q&A.',
      type: 'онлайн',
    },
    {
      title: 'Сообщество родителей «Поддерживаю»',
      date: '4 июня 2024',
      location: 'Санкт-Петербург',
      description:
        'Теплая встреча для родителей ЛГБТК+ людей. Общение, практические советы, кейсы принятия и поддержки.',
      type: 'оффлайн',
    },
    {
      title: 'Онлайн-группа «Квир-среда»',
      date: '12 июня 2024',
      location: 'Zoom',
      description:
        'Небольшие группы, модерация психолога, возможность поговорить о тревогах, победах и планах. Предварительная регистрация обязательна.',
      type: 'онлайн',
    },
    {
      title: 'Воркшоп «Права и защита»',
      date: '18 июня 2024',
      location: 'Москва',
      description:
        'Практический тренинг с юристами. Обсудим актуальные кейсы защиты прав, алгоритмы действий и важные контакты.',
      type: 'оффлайн',
    },
  ];

  return (
    <>
      <Helmet>
        <title>События — Пространство Rainbow</title>
        <meta
          name="description"
          content="Календарь событий Пространства Rainbow: онлайн-встречи, воркшопы, группы поддержки для ЛГБТК+ людей и союзников."
        />
        <meta
          name="keywords"
          content="ЛГБТ события, встречи, воркшоп, группа поддержки, ЛГБТК+ мероприятия"
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.intro}>
          <p className={styles.eyebrow}>События</p>
          <h1>Будьте на связи с сообществом</h1>
          <p>
            Мы проводим регулярные онлайн и оффлайн встречи, чтобы у каждого была возможность найти
            поддержку, поделиться опытом и вдохновиться. Все события модерируются и соблюдают
            принципы безопасности.
          </p>
        </section>

        <section className={styles.list}>
          {events.map((event) => (
            <article key={event.title} className={styles.eventCard}>
              <header className={styles.eventHeader}>
                <p className={styles.date}>{event.date}</p>
                <span
                  className={styles.badge}
                  data-type={event.type}
                >
                  {event.type === 'онлайн' ? 'Онлайн' : 'Оффлайн'}
                </span>
              </header>
              <h2>{event.title}</h2>
              <p className={styles.location}>{event.location}</p>
              <p>{event.description}</p>
              <button type="button" className={styles.registerButton}>
                Записаться
              </button>
            </article>
          ))}
        </section>
      </div>
    </>
  );
};

export default Events;