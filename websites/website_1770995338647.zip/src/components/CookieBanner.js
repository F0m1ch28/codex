import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem('rainbowspace_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 900);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem('rainbowspace_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.inner}>
        <p className={styles.text}>
          Мы используем cookies, чтобы сделать работу сайта стабильной и безопасной. Продолжая
          пользоваться сайтом, вы соглашаетесь с{' '}
          <Link to="/cookie-policy" className={styles.link}>
            политикой использования cookies
          </Link>
          .
        </p>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;