import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const navigate = useNavigate();

  const handleNavigateContact = () => {
    navigate('/contact');
  };

  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.top}>
        <div className={styles.brandBlock}>
          <p className={styles.brandName}>Пространство Rainbow</p>
          <p className={styles.brandText}>
            Безопасное и инклюзивное пространство для людей ЛГБТК+, их семей и друзей.
            Источники знаний, поддержка и комьюнити, основанное на уважении и взаимопомощи.
          </p>
          <div className={styles.socials} aria-label="Социальные сети">
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
            >
              Instagram
            </a>
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
            >
              Facebook
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
            >
              YouTube
            </a>
          </div>
        </div>

        <div className={styles.columns}>
          <div>
            <h3 className={styles.columnTitle}>Навигация</h3>
            <ul className={styles.links}>
              <li>
                <Link to="/">Главная</Link>
              </li>
              <li>
                <Link to="/about">О нас</Link>
              </li>
              <li>
                <Link to="/resources">Ресурсы</Link>
              </li>
              <li>
                <Link to="/support">Поддержка</Link>
              </li>
              <li>
                <Link to="/events">События</Link>
              </li>
              <li>
                <Link to="/blog">Блог</Link>
              </li>
              <li>
                <Link to="/contact">Контакты</Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className={styles.columnTitle}>Политики</h3>
            <ul className={styles.links}>
              <li>
                <Link to="/terms">Условия использования</Link>
              </li>
              <li>
                <Link to="/privacy">Политика конфиденциальности</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Политика cookies</Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className={styles.columnTitle}>Контакты</h3>
            <div className={styles.contactBlock}>
              <button
                type="button"
                onClick={handleNavigateContact}
                className={styles.contactButton}
              >
                Перейти на страницу контактов
              </button>
              <a className={styles.contactLink} href="mailto:info@rainbowspace.ru">
                info@rainbowspace.ru
              </a>
              <a className={styles.contactLink} href="tel:+79991234567">
                +7 (999) 123-45-67
              </a>
              <p className={styles.address}>
                123456, г. Москва, ул. Примерная, д. 1, офис 10
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Пространство Rainbow. Все права защищены.</p>
        <p className={styles.bottomText}>
          Сайт создан для информационной и эмоциональной поддержки ЛГБТК+ людей и союзников.
        </p>
      </div>
    </footer>
  );
};

export default Footer;