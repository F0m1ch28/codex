import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoAccent}>Пространство</span> Rainbow
        </Link>
        <button
          type="button"
          className={styles.burger}
          onClick={toggleMenu}
          aria-controls="primary-navigation"
          aria-expanded={isMenuOpen}
        >
          <span className={styles.burgerLine} />
          <span className={styles.burgerLine} />
          <span className={styles.burgerLine} />
          <span className="sr-only">Меню</span>
        </button>
        <nav
          className={"${styles.nav} ${isMenuOpen ? styles.navOpen : ''}"}
          id="primary-navigation"
          aria-label="Главное меню"
        >
          <ul className={styles.navList}>
            <li>
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={closeMenu}
              >
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/about"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={closeMenu}
              >
                О нас
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/resources"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={closeMenu}
              >
                Ресурсы
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/support"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={closeMenu}
              >
                Поддержка
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/events"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={closeMenu}
              >
                События
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/blog"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={closeMenu}
              >
                Блог
              </NavLink>
            </li>
            <li className={styles.highlightItem}>
              <NavLink
                to="/contact"
                className={({ isActive }) =>
                  isActive
                    ? "${styles.navLink} ${styles.highlight} ${styles.active}"
                    : "${styles.navLink} ${styles.highlight}"
                }
                onClick={closeMenu}
              >
                Контакты
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;