document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('nav-open');
    });

    siteNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          siteNav.classList.remove('nav-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('pfbcCookiePreference');
    if (storedPreference) {
      cookieBanner.classList.add('is-hidden');
    }

    const acceptButton = cookieBanner.querySelector('[data-accept-cookies]');
    const declineButton = cookieBanner.querySelector('[data-decline-cookies]');

    const setPreference = (value) => {
      localStorage.setItem('pfbcCookiePreference', value);
      cookieBanner.classList.add('is-hidden');
    };

    if (acceptButton) {
      acceptButton.addEventListener('click', () => setPreference('accepted'));
    }
    if (declineButton) {
      declineButton.addEventListener('click', () => setPreference('declined'));
    }
  }
});