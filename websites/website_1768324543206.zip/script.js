document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var navLinks = document.getElementById('primary-navigation');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            var expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navLinks.classList.toggle('open');
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navLinks.classList.contains('open')) {
                    navLinks.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    var yearEl = document.getElementById('current-year');
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }

    var cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        var cookieChoice = localStorage.getItem('tipstaksdtCookieChoice');
        if (cookieChoice) {
            cookieBanner.classList.add('hidden');
        }

        cookieBanner.querySelectorAll('.cookie-action').forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                var choice = btn.dataset.choice || 'accepted';
                localStorage.setItem('tipstaksdtCookieChoice', choice);
                cookieBanner.classList.add('hidden');
                window.open(btn.getAttribute('href'), '_blank');
            });
        });
    }
});