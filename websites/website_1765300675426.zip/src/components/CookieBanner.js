```javascript
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(true);

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.message}>
        Ce site utilise des cookies fonctionnels et de mesure d'audience. Pour en savoir plus, consultez la{' '}
        <Link to="/politique-de-cookies">politique de cookies</Link>.
      </p>
      <button type="button" className={styles.button} onClick={() => setVisible(false)}>
        Accepter
      </button>
    </div>
  );
};

export default CookieBanner;
```