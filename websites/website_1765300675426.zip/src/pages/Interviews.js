```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { interviewArticles } from '../data/content';
import styles from './Interviews.module.css';

const Interviews = () => {
  const sortedInterviews = [...interviewArticles].sort((a, b) => new Date(b.dateISO) - new Date(a.dateISO));

  return (
    <>
      <Seo
        title="Interviews | French Automotive Sector Analysis"
        description="Entretiens approfondis avec des ingénieurs, designers et spécialistes de l'industrie automobile française."
        keywords="interviews, ingénieurs automobile, design, batteries, industrie automobile française"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Interviews</h1>
          <p>
            Entretiens réalisés avec des spécialistes du secteur automobile français. Chaque échange est conduit selon une grille
            méthodique afin de documenter les choix techniques, organisationnels et réglementaires.
          </p>
        </div>
      </section>
      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            {sortedInterviews.map((interview) => (
              <article key={interview.id} className="card">
                <div className="metaLine">
                  <span>{interview.date}</span>
                  <span>Rubrique Interview</span>
                </div>
                <h2 className={styles.title}>
                  <Link to={`/interviews/${interview.slug}`}>{interview.title}</Link>
                </h2>
                <p className={styles.subtitle}>{interview.subtitle}</p>
                <p className={styles.summary}>{interview.summary}</p>
                <div className={styles.tags}>
                  {interview.tags.map((tag) => (
                    <span className="tag" key={tag}>
                      {tag}
                    </span>
                  ))}
                </div>
                <Link to={`/interviews/${interview.slug}`} className={styles.readMore}>
                  Lire l’entretien complet
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Interviews;
```