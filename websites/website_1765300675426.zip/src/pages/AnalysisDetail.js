```javascript
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { analysisArticles } from '../data/content';
import styles from './AnalysisDetail.module.css';

const AnalysisDetail = () => {
  const { slug } = useParams();
  const article = analysisArticles.find((item) => item.slug === slug);

  if (!article) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Analyse non trouvée</h1>
          <p>La ressource demandée n’est plus disponible ou a changé de localisation.</p>
          <Link to="/analyse" className={styles.backLink}>
            Retourner aux analyses
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Seo
        title={`${article.title} | French Automotive Sector Analysis`}
        description={article.summary}
        keywords={article.tags.join(', ')}
      />
      <article className={styles.article}>
        <div className="container">
          <header className={styles.header}>
            <p className={styles.meta}>
              <span>{article.date}</span>
              <span>Rubrique Analyse</span>
            </p>
            <h1>{article.title}</h1>
            <p className={styles.subtitle}>{article.subtitle}</p>
            <div className={styles.tags}>
              {article.tags.map((tag) => (
                <span className="tag" key={tag}>
                  {tag}
                </span>
              ))}
            </div>
          </header>
          <section className={styles.content}>
            <p className={styles.intro}>{article.intro}</p>
            {article.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
            <p className={styles.conclusion}>{article.conclusion}</p>
          </section>
          <footer className={styles.footer}>
            <Link to="/analyse" className={styles.backLink}>
              Retour à la liste des analyses
            </Link>
          </footer>
        </div>
      </article>
    </>
  );
};

export default AnalysisDetail;
```