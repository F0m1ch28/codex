```javascript
import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <Seo
      title="Conditions d’utilisation | French Automotive Sector Analysis"
      description="Conditions générales d’utilisation du site French Automotive Sector Analysis."
      keywords="conditions d'utilisation, mentions légales, French Automotive Sector Analysis"
    />
    <section className={styles.legal}>
      <div className="container">
        <h1>Conditions d’utilisation</h1>
        <p>Dernière mise à jour : 10 mars 2024</p>

        <h2>1. Objet</h2>
        <p>
          Les présentes conditions d’utilisation encadrent l’accès et la consultation du site « French Automotive Sector Analysis »
          (ci-après « le Site »). En naviguant sur le Site, l’utilisateur accepte de respecter l’ensemble des dispositions décrites
          ci-dessous.
        </p>

        <h2>2. Informations éditeur</h2>
        <p>
          Éditeur : French Automotive Sector Analysis – Le Carrefour de l'Analyse, 45 Avenue de la Grande Armée, 75116 Paris,
          France.
          <br />
          Contact : redaction@french-auto-analysis.fr – +33 (0)1 45 00 12 34.
        </p>

        <h2>3. Accès au site</h2>
        <p>
          L’accès au Site est gratuit. L’éditeur s’efforce de maintenir un accès continu, sans garantir pour autant l’absence
          d’interruption, notamment lors des opérations de maintenance ou en cas de force majeure.
        </p>

        <h2>4. Contenus publiés</h2>
        <p>
          Le Site diffuse des analyses, entretiens et dossiers consacrés à l’industrie automobile française. Les contenus sont
          élaborés à partir de sources considérées comme fiables. Malgré le soin apporté à la vérification des informations,
          l’éditeur ne peut garantir l’absence totale d’erreurs ou d’omissions. Toute utilisation ou citation doit mentionner la
          source « French Automotive Sector Analysis ».
        </p>

        <h2>5. Responsabilité</h2>
        <p>
          L’éditeur ne pourra être tenu responsable d’un dommage direct ou indirect résultant de l’utilisation du Site, notamment
          en cas d’inexactitude, de manque de disponibilité ou de présence de liens externes. L’utilisateur reste seul responsable
          de l’interprétation des informations consultées.
        </p>

        <h2>6. Propriété intellectuelle</h2>
        <p>
          L’ensemble des textes, visuels et éléments graphiques figurant sur le Site est protégé par la législation française et
          internationale relative à la propriété intellectuelle. Toute reproduction ou diffusion non autorisée est interdite.
        </p>

        <h2>7. Liens hypertextes</h2>
        <p>
          Le Site peut contenir des liens vers d’autres ressources afin de documenter les sujets traités. L’éditeur ne dispose d’aucun
          contrôle sur ces ressources externes et décline toute responsabilité quant à leur contenu.
        </p>

        <h2>8. Modifications</h2>
        <p>
          Les présentes conditions peuvent être modifiées à tout moment pour tenir compte de l’évolution du Site ou des exigences
          légales. L’utilisateur est invité à consulter cette page régulièrement.
        </p>

        <h2>9. Contact</h2>
        <p>
          Toute question relative aux conditions d’utilisation peut être adressée par email à l’adresse suivante :
          redaction@french-auto-analysis.fr.
        </p>
      </div>
    </section>
  </>
);

export default Terms;
```