```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { analysisArticles, interviewArticles } from '../data/content';
import styles from './Home.module.css';

const topics = [
  'industrie automobile française',
  'constructeurs nationaux',
  'ingénierie et innovation technologique',
  'moteurs thermiques hybrides et électriques',
  'batteries et électrification',
  'infrastructures de recharge',
  'chaîne d’approvisionnement et logistique industrielle',
  'normes environnementales et directives européennes',
  'réduction des émissions et transition énergétique',
  'robotisation et automatisation',
  "systèmes d’aide à la conduite et conduite autonome",
  'R&D et laboratoires industriels',
  'marché intérieur et tendances de consommation',
  'exportations françaises',
  'compétitivité en Europe et dans le monde',
  'évolution du design automobile',
  "histoire de l’automobile en France"
];

const Home = () => {
  const latestAnalysis = [...analysisArticles].sort((a, b) => new Date(b.dateISO) - new Date(a.dateISO))[0];
  const latestInterview = [...interviewArticles].sort((a, b) => new Date(b.dateISO) - new Date(a.dateISO))[0];

  return (
    <>
      <Seo
        title="French Automotive Sector Analysis | Observatoire de l'industrie automobile française"
        description="Analyses neutres, interviews spécialisées et suivi documenté des transformations de l'industrie automobile française : électrification, innovation, logistique, design."
        keywords="industrie automobile française, analyses, électrification, innovation, batteries, interviews, logistique"
      />
      <div className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroLabel}>Observatoire indépendant</p>
          <h1 className={styles.heroTitle}>French Automotive Sector Analysis</h1>
          <p className={styles.heroText}>
            Publication analytique dédiée aux stratégies des constructeurs français, à l’évolution des motorisations, à la
            mutation des chaînes d’approvisionnement et aux dynamiques de design. Les enquêtes sont menées selon une
            méthodologie rigoureuse, fondée sur des sources vérifiées et des entretiens avec les acteurs du secteur.
          </p>
          <div className={styles.heroLinks}>
            <Link to="/analyse" className={styles.heroLink}>
              Rubrique Analyse
            </Link>
            <Link to="/interviews" className={styles.heroLinkSecondary}>
              Dernières interviews
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=101"
            alt="Chaîne d’assemblage automobile en France"
            loading="lazy"
          />
        </div>
      </div>

      <section className={`${styles.section} fadeInUp`}>
        <div className="container">
          <h2 className="sectionTitle">Indicateurs suivis en continu</h2>
          <p className="sectionIntro">
            Synthèse des principaux paramètres que la rédaction documente chaque trimestre pour mesurer la progression de la
            filière.
          </p>
          <div className={styles.statsGrid}>
            <article className={styles.statCard}>
              <span className={styles.statValue}>24</span>
              <p>Sites de production observés en 2024 sur le territoire national</p>
            </article>
            <article className={styles.statCard}>
              <span className={styles.statValue}>36</span>
              <p>Entretiens réalisés avec des ingénieurs, designers et spécialistes réglementaires</p>
            </article>
            <article className={styles.statCard}>
              <span className={styles.statValue}>18</span>
              <p>Programmes technologiques suivis : batteries, logiciels, robotisation, infrastructures</p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.section} fadeInUp`}>
        <div className="container">
          <div className={styles.gridTwo}>
            <article className="card">
              <div className={styles.cardHeader}>
                <h2 className={styles.cardTitle}>Dernier dossier d’analyse</h2>
                <span className={styles.cardBadge}>Analyse</span>
              </div>
              <h3 className={styles.cardItemTitle}>{latestAnalysis.title}</h3>
              <p className={styles.cardSubtitle}>{latestAnalysis.subtitle}</p>
              <div className="metaLine">
                <span>{latestAnalysis.date}</span>
                <span>Lecture approfondie</span>
              </div>
              <p className={styles.cardExcerpt}>{latestAnalysis.summary}</p>
              <Link to={`/analyse/${latestAnalysis.slug}`} className={styles.cardLink}>
                Consulter l’article
              </Link>
            </article>

            <article className="card">
              <div className={styles.cardHeader}>
                <h2 className={styles.cardTitle}>Interview mise en avant</h2>
                <span className={`${styles.cardBadge} ${styles.badgeInterview}`}>Interview</span>
              </div>
              <h3 className={styles.cardItemTitle}>{latestInterview.title}</h3>
              <p className={styles.cardSubtitle}>{latestInterview.subtitle}</p>
              <div className="metaLine">
                <span>{latestInterview.date}</span>
                <span>Approche qualitative</span>
              </div>
              <p className={styles.cardExcerpt}>{latestInterview.summary}</p>
              <Link to={`/interviews/${latestInterview.slug}`} className={styles.cardLink}>
                Lire l’entretien
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.themeSection}`}>
        <div className="container">
          <h2 className="sectionTitle">Thématiques clés de l’observatoire</h2>
          <p className="sectionIntro">
            Les sujets traités couvrent l’ensemble de la chaîne de valeur automobile, des laboratoires de recherche aux réseaux
            de distribution.
          </p>
          <div className={styles.topicsGrid}>
            {topics.map((topic) => (
              <span className={styles.topicTag} key={topic}>
                {topic}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} fadeInUp`}>
        <div className="container">
          <div className={styles.methodology}>
            <div>
              <h2 className="sectionTitle">Méthodologie éditoriale</h2>
              <p className="sectionIntro">
                Chaque publication s’appuie sur des sources vérifiées, des documents techniques, des règlements européens et des
                entretiens structurés. Les contenus sont relus par un comité éditorial afin de garantir un ton neutre et la
                précision des faits.
              </p>
              <ul className={styles.methodList}>
                <li>Veille quotidienne des communiqués industriels, rapports institutionnels et publications scientifiques.</li>
                <li>Entretiens semi-directifs réalisés avec des ingénieurs, designers, économistes et responsables logistiques.</li>
                <li>Analyse croisée avec les données publiques sur les immatriculations, les normes environnementales et la
                  transition énergétique.</li>
                <li>Relecture systématique par la rédaction pour assurer cohérence, clarté et contextualisation.</li>
              </ul>
            </div>
            <div className={styles.methodImage}>
              <img
                src="https://picsum.photos/800/600?random=202"
                alt="Table ronde d’analystes spécialisés dans l’automobile"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} fadeInUp`}>
        <div className="container">
          <div className={styles.archiveBlock}>
            <div>
              <h2 className="sectionTitle">Archives structurées</h2>
              <p className="sectionIntro">
                L’ensemble des analyses, chronologies et entretiens est indexé par année et thématique afin de faciliter la
                consultation des évolutions majeures du secteur.
              </p>
            </div>
            <Link to="/archives" className={styles.archiveLink}>
              Accéder aux archives
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.contactSection}`}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div>
              <h2 className="sectionTitle">Coordonnées de la rédaction</h2>
              <p className="sectionIntro">
                Les demandes d’information, propositions d’interview ou suggestions éditoriales peuvent être adressées aux
                coordonnées ci-dessous. Chaque message fait l’objet d’un suivi méthodique.
              </p>
              <ul className={styles.contactList}>
                <li>
                  <strong>Adresse :</strong> Le Carrefour de l'Analyse, 45 Avenue de la Grande Armée, 75116 Paris, France
                </li>
                <li>
                  <strong>Téléphone :</strong> +33 (0)1 45 00 12 34
                </li>
                <li>
                  <strong>Email :</strong>{' '}
                  <a href="mailto:redaction@french-auto-analysis.fr">redaction@french-auto-analysis.fr</a>
                </li>
              </ul>
            </div>
            <div className={styles.contactCard}>
              <h3>Suivi éditorial continu</h3>
              <p>
                Les publications sont mises à jour régulièrement afin de refléter l’état réel des projets industriels et des
                travaux de recherche. Les corrections majeures sont tracées et publiées dans la rubrique Archives.
              </p>
              <Link to="/contact" className={styles.cardLink}>
                Formulaire de contact
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
```