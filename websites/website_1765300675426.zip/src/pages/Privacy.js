```javascript
import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Seo
      title="Politique de confidentialité | French Automotive Sector Analysis"
      description="Politique de confidentialité appliquée par French Automotive Sector Analysis."
      keywords="politique de confidentialité, données personnelles, French Automotive Sector Analysis"
    />
    <section className={styles.legal}>
      <div className="container">
        <h1>Politique de confidentialité</h1>
        <p>Dernière mise à jour : 10 mars 2024</p>

        <h2>1. Responsable de traitement</h2>
        <p>
          Le responsable de traitement des données collectées via le Site est French Automotive Sector Analysis, Le Carrefour de
          l'Analyse, 45 Avenue de la Grande Armée, 75116 Paris, France. Contact : redaction@french-auto-analysis.fr.
        </p>

        <h2>2. Données collectées</h2>
        <p>
          Les informations collectées via le formulaire de contact (nom, organisation, adresse email, sujet, message) sont utilisées
          pour répondre aux sollicitations. Aucune donnée sensible n’est demandée. Les journaux techniques du serveur peuvent
          enregistrer l’adresse IP, le type de navigateur et l’heure de consultation à des fins de sécurité.
        </p>

        <h2>3. Finalités</h2>
        <p>
          Les données collectées servent exclusivement à traiter les demandes envoyées via le formulaire de contact ou par email. Le
          Site n’effectue aucune prospection commerciale ni profilage. Les statistiques de fréquentation sont anonymisées.
        </p>

        <h2>4. Durée de conservation</h2>
        <p>
          Les messages reçus sont conservés le temps nécessaire à leur traitement puis archivés pendant une durée maximale de deux
          ans. Les données techniques anonymisées sont conservées pour améliorer la sécurité du Site.
        </p>

        <h2>5. Partage des données</h2>
        <p>
          Les données ne sont transmises à aucun tiers, sauf obligation légale ou requête d’une autorité compétente. Les prestataires
          techniques chargés de l’hébergement sont soumis à une obligation contractuelle de confidentialité.
        </p>

        <h2>6. Sécurité</h2>
        <p>
          Des mesures techniques et organisationnelles sont mises en œuvre pour préserver la confidentialité des données collectées,
          notamment via des accès restreints, le chiffrement des communications et la surveillance du serveur.
        </p>

        <h2>7. Droits des personnes</h2>
        <p>
          Conformément au Règlement européen 2016/679, chaque personne dispose d’un droit d’accès, de rectification, d’effacement,
          de limitation et de portabilité concernant ses données. Toute demande doit être adressée par email à
          redaction@french-auto-analysis.fr. Une réponse sera apportée dans un délai raisonnable.
        </p>

        <h2>8. Cookies</h2>
        <p>
          Le Site utilise des cookies techniques nécessaires à son fonctionnement et des cookies de mesure d’audience anonymisés.
          Pour plus d’informations, consultez la Politique de cookies.
        </p>

        <h2>9. Modifications</h2>
        <p>
          La présente politique peut évoluer pour tenir compte des changements réglementaires ou techniques. En cas de modification
          majeure, une notification sera affichée sur le Site.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;
```