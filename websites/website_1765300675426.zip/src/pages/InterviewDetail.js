```javascript
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { interviewArticles } from '../data/content';
import styles from './InterviewDetail.module.css';

const InterviewDetail = () => {
  const { slug } = useParams();
  const interview = interviewArticles.find((item) => item.slug === slug);

  if (!interview) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Interview non trouvée</h1>
          <p>La ressource demandée n’est plus disponible ou a été déplacée.</p>
          <Link to="/interviews" className={styles.backLink}>
            Retourner aux interviews
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Seo
        title={`${interview.title} | French Automotive Sector Analysis`}
        description={interview.summary}
        keywords={interview.tags.join(', ')}
      />
      <article className={styles.article}>
        <div className="container">
          <header className={styles.header}>
            <p className={styles.meta}>
              <span>{interview.date}</span>
              <span>Rubrique Interview</span>
            </p>
            <h1>{interview.title}</h1>
            <p className={styles.subtitle}>{interview.subtitle}</p>
            <div className={styles.tags}>
              {interview.tags.map((tag) => (
                <span className="tag" key={tag}>
                  {tag}
                </span>
              ))}
            </div>
          </header>
          <section className={styles.content}>
            <p className={styles.intro}>{interview.intro}</p>
            {interview.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
            <p className={styles.conclusion}>{interview.conclusion}</p>
          </section>
          <footer className={styles.footer}>
            <Link to="/interviews" className={styles.backLink}>
              Retour à la liste des interviews
            </Link>
          </footer>
        </div>
      </article>
    </>
  );
};

export default InterviewDetail;
```