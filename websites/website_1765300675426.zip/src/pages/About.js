```javascript
import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const About = () => (
  <>
    <Seo
      title="À propos | French Automotive Sector Analysis"
      description="Présentation de la mission, de la méthodologie et de l’équipe éditoriale de French Automotive Sector Analysis."
      keywords="à propos, méthodologie, rédaction, observatoire automobile"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>À propos de French Automotive Sector Analysis</h1>
        <p>
          French Automotive Sector Analysis est un projet éditorial indépendant dédié au suivi neutre de l'industrie automobile
          française. La rédaction documente les dynamiques industrielles, technologiques et réglementaires à partir de sources
          qualifiées et d’entretiens menés auprès d’experts reconnus.
        </p>
      </div>
    </section>
    <section className={styles.section}>
      <div className="container">
        <div className={styles.grid}>
          <article className="card">
            <h2>Mission éditoriale</h2>
            <p>
              La mission principale est de fournir des analyses factuelles sur les transformations de la filière automobile : nouvelles
              motorisations, évolution des chaînes de production, exigences réglementaires, impact des technologies logicielles et
              du design. Chaque publication est cadrée par un processus de vérification croisée afin de garantir précision et
              neutralité.
            </p>
          </article>
          <article className="card">
            <h2>Périmètre de couverture</h2>
            <p>
              La rédaction couvre l’ensemble de la filière nationale, depuis les constructeurs et équipementiers jusqu’aux laboratoires
              de recherche, en passant par les réseaux logistiques et les plateformes de services. Les enjeux européens sont
              systématiquement pris en compte pour offrir une lecture contextualisée.
            </p>
          </article>
          <article className="card">
            <h2>Principes méthodologiques</h2>
            <ul className={styles.list}>
              <li>Collecte systématique de documents techniques, rapports institutionnels et données publiques.</li>
              <li>Entretiens semi-directifs avec des professionnels du secteur, menés selon un guide d’entretien transparent.</li>
              <li>Relecture collégiale et vérification des citations par les personnes interviewées lorsque nécessaire.</li>
              <li>Traçabilité des mises à jour via la rubrique Archives.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>
    <section className={styles.section}>
      <div className="container">
        <div className={styles.timeline}>
          <div className={styles.timelineItem}>
            <div className={styles.timelineDate}>2021</div>
            <div>
              <h3>Lancement du projet</h3>
              <p>
                Mise en place de l’équipe éditoriale et rédaction des premiers dossiers consacrés aux stratégies d’électrification
                des constructeurs français.
              </p>
            </div>
          </div>
          <div className={styles.timelineItem}>
            <div className={styles.timelineDate}>2022</div>
            <div>
              <h3>Structuration des interviews</h3>
              <p>
                Formalisation d’un protocole d’entretien avec les ingénieurs et experts du secteur, publication de premiers dialogues
                thématiques.
              </p>
            </div>
          </div>
          <div className={styles.timelineItem}>
            <div className={styles.timelineDate}>2023</div>
            <div>
              <h3>Extension logistique et R&D</h3>
              <p>
                Développement d’un suivi spécifique des chaînes d’approvisionnement, de la robotisation et des laboratoires
                industriels français.
              </p>
            </div>
          </div>
          <div className={styles.timelineItem}>
            <div className={styles.timelineDate}>2024</div>
            <div>
              <h3>Nouvelle plateforme éditoriale</h3>
              <p>
                Refonte du site pour offrir une navigation optimisée, une indexation complète des archives et des fiches thématiques
                claires.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;
```