```javascript
import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const Cookies = () => (
  <>
    <Seo
      title="Politique de cookies | French Automotive Sector Analysis"
      description="Politique d’utilisation des cookies sur le site French Automotive Sector Analysis."
      keywords="cookies, politique de cookies, French Automotive Sector Analysis"
    />
    <section className={styles.legal}>
      <div className="container">
        <h1>Politique de cookies</h1>
        <p>Dernière mise à jour : 10 mars 2024</p>

        <h2>1. Définition</h2>
        <p>
          Un cookie est un fichier texte susceptible d’être enregistré sur votre terminal lors de la consultation du Site. Il permet
          notamment de faciliter la navigation et de mesurer l’audience.
        </p>

        <h2>2. Cookies utilisés</h2>
        <ul>
          <li>
            Cookies techniques : indispensables au bon fonctionnement du Site. Ils gèrent par exemple l’affichage du bandeau
            d’information et la sécurité des formulaires.
          </li>
          <li>
            Cookies de mesure d’audience : utilisés pour obtenir des statistiques anonymes sur la fréquentation (pages consultées,
            durée de visite, périphériques utilisés).
          </li>
        </ul>

        <h2>3. Paramétrage</h2>
        <p>
          Lors de la première visite, un bandeau informe l’utilisateur de la présence de cookies et propose une action d’acceptation.
          Les paramètres du navigateur permettent également de contrôler ou de supprimer les cookies installés.
        </p>

        <h2>4. Gestion via le navigateur</h2>
        <p>
          Il est possible de configurer le navigateur pour accepter ou refuser les cookies. Les procédures varient selon les
          navigateurs (Chrome, Firefox, Safari, Edge, etc.). Les instructions sont consultables sur leurs pages d’assistance.
        </p>

        <h2>5. Mise à jour</h2>
        <p>
          La présente politique peut être complétée ou modifiée afin de refléter l’évolution des pratiques. Les utilisateurs sont
          invités à consulter régulièrement cette page.
        </p>

        <h2>6. Contact</h2>
        <p>
          Toute question relative aux cookies peut être adressée à l’adresse suivante :
          redaction@french-auto-analysis.fr.
        </p>
      </div>
    </section>
  </>
);

export default Cookies;
```