```javascript
import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import Analysis from './pages/Analysis';
import AnalysisDetail from './pages/AnalysisDetail';
import Interviews from './pages/Interviews';
import InterviewDetail from './pages/InterviewDetail';
import Archives from './pages/Archives';
import About from './pages/About';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className="appShell">
      <Header />
      <ScrollToTopOnRoute />
      <main className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/analyse" element={<Analysis />} />
          <Route path="/analyse/:slug" element={<AnalysisDetail />} />
          <Route path="/interviews" element={<Interviews />} />
          <Route path="/interviews/:slug" element={<InterviewDetail />} />
          <Route path="/archives" element={<Archives />} />
          <Route path="/a-propos" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/conditions-utilisation" element={<Terms />} />
          <Route path="/politique-de-confidentialite" element={<Privacy />} />
          <Route path="/politique-de-cookies" element={<Cookies />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;
```