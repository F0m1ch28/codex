document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const navMenu = document.querySelector('[data-nav-menu]');
  const scrollTopBtn = document.getElementById('scrollTop');
  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const contactForm = document.getElementById('contact-form');
  const formStatus = document.getElementById('form-status');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen);
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 400) {
        scrollTopBtn.classList.add('show');
      } else {
        scrollTopBtn.classList.remove('show');
      }
    });

    scrollTopBtn.addEventListener('click', event => {
      event.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  const cookieKey = 'fyneltoCookieConsent';
  if (cookieBanner && cookieAccept) {
    const consent = localStorage.getItem(cookieKey);
    if (!consent) {
      cookieBanner.classList.add('show');
    }

    cookieAccept.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'accepted');
      cookieBanner.classList.remove('show');
    });
  }

  if (contactForm && formStatus) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      if (!contactForm.checkValidity()) {
        formStatus.textContent = 'Bitte fülle alle Pflichtfelder korrekt aus.';
        formStatus.style.color = '#ff6f61';
        return;
      }
      formStatus.textContent = 'Vielen Dank! Deine Nachricht wurde übermittelt. Wir melden uns in Kürze.';
      formStatus.style.color = '#2c3a8c';
      contactForm.reset();
    });
  }
});