document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = siteNav.classList.toggle('nav-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen);
        });
        document.querySelectorAll('.site-nav a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (siteNav.classList.contains('nav-open')) {
                    siteNav.classList.remove('nav-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const acceptBtn = document.getElementById('cookie-accept');
        const declineBtn = document.getElementById('cookie-decline');
        const pref = localStorage.getItem('cookiePreference');
        if (!pref) {
            setTimeout(function () {
                cookieBanner.classList.add('is-visible');
            }, 600);
        }
        function hideBanner(choice) {
            cookieBanner.classList.remove('is-visible');
            localStorage.setItem('cookiePreference', choice);
        }
        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                hideBanner('accepted');
            });
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                hideBanner('declined');
            });
        }
    }
});