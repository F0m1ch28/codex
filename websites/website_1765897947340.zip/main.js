(function () {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");
    const navLinks = document.querySelectorAll(".nav-link");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            primaryNav.classList.toggle("active");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (primaryNav.classList.contains("active")) {
                    primaryNav.classList.remove("active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const banner = document.querySelector(".cookie-banner[data-component='cookie-banner']");
    const acceptBtn = banner ? banner.querySelector("[data-action='accept-cookies']") : null;
    const declineBtn = banner ? banner.querySelector("[data-action='decline-cookies']") : null;
    const consentKey = "tidesCookieConsent";

    function hideBanner() {
        if (banner) {
            banner.classList.remove("active");
        }
    }

    function showBanner() {
        if (banner) {
            banner.classList.add("active");
        }
    }

    function setConsent(value) {
        try {
            localStorage.setItem(consentKey, value);
        } catch (err) {
            console.warn("Unable to store cookie consent:", err);
        }
    }

    function getConsent() {
        try {
            return localStorage.getItem(consentKey);
        } catch (err) {
            console.warn("Unable to retrieve cookie consent:", err);
            return null;
        }
    }

    if (banner && acceptBtn && declineBtn) {
        const currentConsent = getConsent();
        if (!currentConsent) {
            showBanner();
        }

        acceptBtn.addEventListener("click", () => {
            setConsent("accepted");
            hideBanner();
        });

        declineBtn.addEventListener("click", () => {
            setConsent("declined");
            hideBanner();
        });
    }
})();