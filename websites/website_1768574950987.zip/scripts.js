document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".site-nav");
    const cookieBanner = document.querySelector("[data-cookie-banner]");
    const acceptButton = document.querySelector("[data-cookie-accept]");
    const declineButton = document.querySelector("[data-cookie-decline]");
    const consentKey = "vitamiaowxCookieConsent";

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!expanded).toString());
            nav.classList.toggle("open");
        });

        nav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768 && nav.classList.contains("open")) {
                    nav.classList.remove("open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const existingConsent = localStorage.getItem(consentKey);
    if (!existingConsent && cookieBanner) {
        cookieBanner.classList.add("show");
    }

    if (acceptButton) {
        acceptButton.addEventListener("click", () => {
            localStorage.setItem(consentKey, "accepted");
            cookieBanner.classList.remove("show");
        });
    }

    if (declineButton) {
        declineButton.addEventListener("click", () => {
            localStorage.setItem(consentKey, "declined");
            cookieBanner.classList.remove("show");
        });
    }
});