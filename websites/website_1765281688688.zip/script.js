document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  const navLinks = document.querySelectorAll('.site-nav a');

  if (navToggle && siteNav) {
    const toggleNav = () => {
      const isOpen = siteNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    };

    navToggle.addEventListener('click', toggleNav);

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('open')) {
          siteNav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && siteNav.classList.contains('open')) {
        siteNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  const STORAGE_KEY = 'nas-cookie-consent';
  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');

  if (banner) {
    const storedDecision = localStorage.getItem(STORAGE_KEY);

    if (!storedDecision) {
      setTimeout(() => {
        banner.classList.add('visible');
        banner.setAttribute('aria-hidden', 'false');
      }, 800);
    } else {
      banner.setAttribute('aria-hidden', 'true');
    }

    const handleDecision = (decision) => {
      localStorage.setItem(STORAGE_KEY, decision);
      banner.classList.remove('visible');
      banner.setAttribute('aria-hidden', 'true');
    };

    acceptBtn?.addEventListener('click', () => handleDecision('accepted'));
    declineBtn?.addEventListener('click', () => handleDecision('declined'));
  }
});