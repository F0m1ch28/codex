import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [status, setStatus] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('Спасибо! Мы свяжемся с вами в ближайшее время.');
    event.target.reset();
  };

  return (
    <>
      <Helmet>
        <title>Контакты ArtVista — свяжитесь с нашей студией</title>
        <meta
          name="description"
          content="Свяжитесь со студией ArtVista: форма обратной связи, телефон, email и адрес в Москве."
        />
      </Helmet>
      <section className={`${styles.hero} container`}>
        <h1>Давайте обсудим вашу идею</h1>
        <p>
          Расскажите о проекте, и мы подготовим визуальное решение. Мы открыты к экспериментам,
          коллаборациям и долгосрочным партнёрствам.
        </p>
      </section>

      <section className={`${styles.grid} container`}>
        <form className={styles.form} onSubmit={handleSubmit}>
          <label htmlFor="name">
            Имя
            <input type="text" id="name" name="name" placeholder="Как к вам обращаться?" required />
          </label>
          <label htmlFor="email">
            Email
            <input
              type="email"
              id="email"
              name="email"
              placeholder="name@example.com"
              required
            />
          </label>
          <label htmlFor="phone">
            Телефон
            <input
              type="tel"
              id="phone"
              name="phone"
              placeholder="+7 (___) ___-__-__"
              required
            />
          </label>
          <label htmlFor="message">
            Опишите задачу
            <textarea
              id="message"
              name="message"
              placeholder="Какая идея вас вдохновляет? Что важно учесть?"
              rows="5"
            />
          </label>
          <button type="submit">Отправить сообщение</button>
          {status && <p className={styles.status}>{status}</p>}
        </form>
        <div className={styles.info}>
          <div>
            <h2>Контакты студии</h2>
            <p>
              ул. Творческая, 15, Москва, Россия
              <br />
              <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              <br />
              <a href="mailto:hello@artstudio.ru">hello@artstudio.ru</a>
            </p>
          </div>
          <div>
            <h3>Часы работы</h3>
            <p>Понедельник – Пятница: 10:00 — 19:00</p>
          </div>
          <div>
            <h3>Социальные сети</h3>
            <p>
              <a href="#instagram">Instagram</a> · <a href="#behance">Behance</a> ·{' '}
              <a href="#dribbble">Dribbble</a>
            </p>
          </div>
          <div className={styles.map}>
            <img
              src="https://picsum.photos/id/1016/600/400"
              alt="Схема расположения студии ArtVista в Москве"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;