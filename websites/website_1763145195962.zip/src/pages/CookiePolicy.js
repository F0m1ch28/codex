import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика Cookie ArtVista</title>
      <meta
        name="description"
        content="Политика использования файлов cookie студии ArtVista. Узнайте, какие данные собираются и для чего они применяются."
      />
    </Helmet>
    <section className={`${styles.legal} container`}>
      <h1>Политика Cookie</h1>
      <p>
        Cookie — это небольшие файлы, которые сохраняются на вашем устройстве для улучшения работы
        сайта. Мы используем cookie для аналитики и персонализации контента.
      </p>

      <h2>1. Типы cookie</h2>
      <ul>
        <li>Функциональные cookie для корректной работы сайта.</li>
        <li>Аналитические cookie для понимания поведения пользователей.</li>
      </ul>

      <h2>2. Управление cookie</h2>
      <p>
        Вы можете изменить настройки cookie в своём браузере или отказаться от их использования,
        однако это может ограничить функциональность сайта.
      </p>

      <h2>3. Срок хранения</h2>
      <p>
        Срок хранения cookie зависит от типа файла и не превышает периода, необходимого для
        достижения целей их обработки.
      </p>
    </section>
  </>
);

export default CookiePolicy;