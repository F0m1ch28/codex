import React from "react";
import { Link } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="footer" role="contentinfo">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="logo" aria-label="Tu Progreso Hoy">
              <span className="logo-badge">TP</span>
              Tu Progreso Hoy
            </div>
            <p>
              Datos verificados para planificar tu presupuesto. Conocimiento financiero impulsado por tendencias.
              Pasos acertados hoy, mejor futuro mañana.
            </p>
            <div className="meta-badges" aria-label="Key commitments">
              <span className="meta-badge">Argentina inflation intelligence</span>
              <span className="meta-badge">Personal finance starter course</span>
            </div>
          </div>
          <div>
            <h4 className="footer-heading">{t("footer.about")}</h4>
            <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
              <li>
                <Link to="/inflation">Methodology</Link>
              </li>
              <li>
                <Link to="/course">Syllabus</Link>
              </li>
              <li>
                <Link to="/resources">Knowledge hub</Link>
              </li>
              <li>
                <Link to="/contact">Get support</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="footer-heading">{t("footer.legal")}</h4>
            <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cookies">Cookie Policy</Link>
              </li>
              <li>
                <Link to="/terms">Terms of Service</Link>
              </li>
              <li>
                <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="footer-heading">{t("footer.follow")}</h4>
            <p>
              Análisis transparentes y datos de mercado para decidir con seguridad. Información confiable que respalda
              elecciones responsables sobre tu dinero. Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
            </p>
            <p className="micro-tag">Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
            <address style={{ fontStyle: "normal", marginTop: "1rem" }}>
              Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
              <br />
              +54 11 5555-1234
            </address>
          </div>
        </div>
        <div className="footer-note">
          {t("footer.rights")}
        </div>
      </div>
    </footer>
  );
};

export default Footer;