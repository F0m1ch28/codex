import React, { useEffect } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "./Header";
import Footer from "./Footer";
import CookieBanner from "./CookieBanner";
import DisclaimerModal from "./DisclaimerModal";
import { useLanguage } from "../contexts/LanguageContext";

const Layout = () => {
  const { language } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get("lang") !== language) {
      params.set("lang", language);
      navigate({ pathname: location.pathname, search: params.toString() }, { replace: true });
    }
  }, [language, location.pathname, location.search, navigate]);

  return (
    <>
      <Helmet>
        <html lang={language === "es" ? "es-AR" : "en"} />
      </Helmet>
      <div>
        <a className="skip-link" href="#main-content">
          Tu Progreso Hoy
        </a>
        <Header />
        <main id="main-content">
          <Outlet />
        </main>
        <Footer />
        <CookieBanner />
        <DisclaimerModal />
      </div>
    </>
  );
};

export default Layout;