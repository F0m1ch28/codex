import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import LanguageSwitcher from "./LanguageSwitcher";
import { useLanguage } from "../contexts/LanguageContext";

const Header = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  return (
    <header>
      <div className="container header-inner" role="navigation" aria-label="Main navigation">
        <motion.div
          className="logo"
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="logo-badge" aria-hidden="true">
            TP
          </span>
          Tu Progreso Hoy
        </motion.div>
        <nav className="nav-links">
          <NavLink to="/">{t("nav.home")}</NavLink>
          <NavLink to="/inflation">{t("nav.inflation")}</NavLink>
          <NavLink to="/course">{t("nav.course")}</NavLink>
          <NavLink to="/resources">{t("nav.resources")}</NavLink>
          <NavLink to="/contact">{t("nav.contact")}</NavLink>
          <button
            type="button"
            className="btn-secondary"
            onClick={() => navigate("/contact")}
            aria-label={t("actions.contact")}
          >
            {t("actions.contact")}
          </button>
          <LanguageSwitcher />
        </nav>
      </div>
    </header>
  );
};

export default Header;