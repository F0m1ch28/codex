import React, { useState } from "react";

export const AccordionItem = ({ question, answer }) => {
  const [open, setOpen] = useState(false);
  const toggle = () => setOpen((prev) => !prev);

  return (
    <div className={`accordion-item ${open ? "open" : ""}`}>
      <button
        type="button"
        className="accordion-header"
        onClick={toggle}
        aria-expanded={open}
        aria-controls={`panel-${question}`}
      >
        {question}
        <span aria-hidden="true">{open ? "−" : "+"}</span>
      </button>
      {open && (
        <div className="accordion-content" id={`panel-${question}`}>
          {typeof answer === "string" ? <p>{answer}</p> : answer}
        </div>
      )}
    </div>
  );
};

const Accordion = ({ items }) => (
  <div className="accordion">
    {items.map((item) => (
      <AccordionItem key={item.question} {...item} />
    ))}
  </div>
);

export default Accordion;