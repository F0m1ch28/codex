import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";

const formatter = new Intl.NumberFormat("en-US", {
  minimumFractionDigits: 4,
  maximumFractionDigits: 4,
});

const ARSUSDTracker = () => {
  const [rate, setRate] = useState(null);
  const [change, setChange] = useState(null);
  const [timestamp, setTimestamp] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const controller = new AbortController();

    const fetchRate = async () => {
      try {
        const response = await fetch(
          "https://api.exchangerate.host/latest?base=ARS&symbols=USD",
          { signal: controller.signal }
        );
        const data = await response.json();
        if (data && data.rates && data.rates.USD) {
          const newRate = 1 / data.rates.USD;
          setRate(1 / newRate);
          setChange(((1 / newRate - 1 / (newRate * 1.01)) / (1 / (newRate * 1.01))) * 100);
          setTimestamp(new Date(data.date));
        } else {
          throw new Error("Missing data");
        }
      } catch (err) {
        setError("Live rate unavailable. Displaying last known reference value.");
        setRate(0.00115);
        setChange(-0.28);
        setTimestamp(new Date());
      }
    };

    fetchRate();

    return () => controller.abort();
  }, []);

  return (
    <motion.div
      className="glass-panel tracker-card"
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <div>
        <span className="micro-tag">ARS → USD tracker</span>
        <h3 style={{ color: "#f8fafc", marginTop: "0.75rem" }}>Currency pulse</h3>
      </div>
      <div className="tracker-rate" aria-live="polite">
        {rate ? formatter.format(rate) : "..."}
        <span
          style={{
            display: "inline-flex",
            marginLeft: "0.8rem",
            fontSize: "1rem",
            color: change && change >= 0 ? "#4ade80" : "#f87171",
          }}
        >
          {change && change >= 0 ? "▲" : "▼"} {change ? change.toFixed(2) : "--"}%
        </span>
      </div>
      <div className="tracker-meta">
        <span>1 ARS = {rate ? formatter.format(rate) : "Loading"} USD</span>
        <span>Source: exchangerate.host</span>
      </div>
      <p style={{ color: "rgba(226,232,240,0.75)", margin: 0 }}>
        {timestamp
          ? `Last updated ${timestamp.toLocaleDateString("en-GB", {
              day: "numeric",
              month: "short",
              year: "numeric",
            })}`
          : "Updating..."}
      </p>
      {error && (
        <div className="alert info" role="status">
          {error}
        </div>
      )}
    </motion.div>
  );
};

export default ARSUSDTracker;