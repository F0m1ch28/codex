import React, { useEffect, useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";

const DisclaimerModal = () => {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const acknowledged = window.sessionStorage.getItem("tph_disclaimer_ack");
    if (!acknowledged) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const acknowledge = () => {
    window.sessionStorage.setItem("tph_disclaimer_ack", "true");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="disclaimer-modal" role="dialog" aria-modal="true">
      <div className="disclaimer-content">
        <h3>{t("disclaimer.title")}</h3>
        <p>{t("disclaimer.description")}</p>
        <ul className="disclaimer-list">
          <li>Мы не предоставляем финансовые услуги.</li>
          <li>We do not provide financial services.</li>
          <li>No brindamos servicios financieros.</li>
        </ul>
        <button type="button" className="btn-primary disclaimer-close" onClick={acknowledge}>
          {t("disclaimer.acknowledge")}
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;