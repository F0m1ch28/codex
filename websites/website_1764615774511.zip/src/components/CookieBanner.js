import React, { useEffect, useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";

const CookieBanner = () => {
  const { t } = useLanguage();
  const [show, setShow] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem("tph_cookie_consent");
    if (!storedConsent) {
      const timer = setTimeout(() => setShow(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem("tph_cookie_consent", value);
    setShow(false);
  };

  if (!show) return null;

  return (
    <aside className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie banner">
      <strong>{t("cookie.title")}</strong>
      <p style={{ marginTop: "0.75rem" }}>{t("cookie.description")}</p>
      <div className="cookie-actions">
        <button type="button" className="accept" onClick={() => handleConsent("accepted")}>
          {t("cookie.accept")}
        </button>
        <button type="button" className="decline" onClick={() => handleConsent("declined")}>
          {t("cookie.decline")}
        </button>
      </div>
    </aside>
  );
};

export default CookieBanner;