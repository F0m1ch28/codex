import React from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import { useLanguage } from "../contexts/LanguageContext";
import { BASE_URL } from "../utils/constants";

const Privacy = () => {
  const { language } = useLanguage();
  const path = "/privacy";

  return (
    <PageTransition>
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Tu Progreso Hoy privacy policy detailing data collection, consent procedures, and rights for users in Argentina and beyond."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">Privacy Policy</h1>
          <p className="hero-subtitle">
            We handle personal data with transparency, minimal collection, and lawful bases aligned with Argentine and international standards.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <h2 style={{ color: "#1f3a6f" }}>1. Controller</h2>
          <p>
            Tu Progreso Hoy, Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina, is the data controller for the information collected through this platform.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>2. Data collected</h2>
          <p>
            We collect minimal personal information: name, email, language preference, and learning goals submitted through forms. Analytics data is anonymized when optional cookies are accepted.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>3. Purpose and legal basis</h2>
          <ul>
            <li>Provide educational content and respond to inquiries (contractual necessity).</li>
            <li>Send double opt-in communications and course updates (consent).</li>
            <li>Maintain security of the platform (legitimate interests).</li>
          </ul>

          <h2 style={{ color: "#1f3a6f" }}>4. Double opt-in commitment</h2>
          <p>
            Every form submission triggers a confirmation email. Only after explicit confirmation will we process your request or send educational materials.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>5. Data sharing</h2>
          <p>
            Data is not sold. We share information only with trusted processors required to deliver email confirmations or analytics, bound by confidentiality agreements.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>6. International transfers</h2>
          <p>
            If data is processed outside Argentina, we ensure adequate safeguards in line with GDPR and local regulations.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>7. Retention</h2>
          <p>
            Records are retained for as long as necessary to deliver educational services or until you revoke consent. Unconfirmed opt-ins are purged automatically after 30 days.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>8. Your rights</h2>
          <p>
            You may request access, rectification, deletion, or portability. Contact hola@tuprogresohoy.com. You may also lodge a complaint with the Agencia de Acceso a la Información Pública.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>9. Contact</h2>
          <p>
            For privacy questions, reach out to privacy@tuprogresohoy.com or write to our Buenos Aires office. This policy is reviewed annually.
          </p>
        </div>
      </section>
    </PageTransition>
  );
};

export default Privacy;