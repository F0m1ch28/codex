import React from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import { BASE_URL } from "../utils/constants";

const Terms = () => {
  const path = "/terms";

  return (
    <PageTransition>
      <Helmet>
        <title>Terms of Service | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Tu Progreso Hoy terms of service describing acceptable use, educational commitments, disclaimers, and governing law."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">Terms of Service</h1>
          <p className="hero-subtitle">
            Review the legal terms governing access to Tu Progreso Hoy, our educational SaaS platform.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <h2 style={{ color: "#1f3a6f" }}>1. Agreement</h2>
          <p>
            By accessing Tu Progreso Hoy, you agree to these Terms of Service. If you do not agree, please refrain from using our platform.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>2. Educational purpose</h2>
          <p>
            Tu Progreso Hoy provides educational content, argentina inflation insights, and personal finance learning tools. Мы не предоставляем финансовые услуги. We do not provide financial services. No brindamos servicios financieros.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>3. Eligibility</h2>
          <p>
            Users must be at least 18 years old or have consent from a legal guardian. Access requires double opt-in confirmation.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>4. Acceptable use</h2>
          <ul>
            <li>No misuse of data or attempt to breach security.</li>
            <li>No redistribution of copyrighted material without permission.</li>
            <li>No misleading claims about receiving advisory services.</li>
          </ul>

          <h2 style={{ color: "#1f3a6f" }}>5. Intellectual property</h2>
          <p>
            All content, branding, and course materials remain the property of Tu Progreso Hoy. Limited personal use is granted; commercial use is prohibited without written authorization.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>6. Limitation of liability</h2>
          <p>
            Content is provided “as is.” We do not guarantee outcomes. Users retain responsibility for financial decisions and must consult professional advisors where necessary.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>7. Governing law</h2>
          <p>
            These terms are governed by the laws of Argentina. Any dispute shall be resolved in the courts of Buenos Aires.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>8. Updates</h2>
          <p>
            We may revise these terms and will notify registered users via email. Continued use constitutes acceptance of the updated terms.
          </p>

          <h2 style={{ color: "#1f3a6f" }}>9. Contact</h2>
          <p>
            For legal inquiries, contact legal@tuprogresohoy.com or mail us at Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina.
          </p>
        </div>
      </section>
    </PageTransition>
  );
};

export default Terms;