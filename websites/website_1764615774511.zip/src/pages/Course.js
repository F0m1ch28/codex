import React from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import { useLanguage } from "../contexts/LanguageContext";
import { BASE_URL } from "../utils/constants";

const modules = [
  {
    title: "Module 1 · Inflation decoder",
    summary:
      "Understand CPI math, categories, and how Argentina inflation diverges from regional peers. Identify lagging indicators vs leading signals.",
    outcomes: ["CPI structure", "Inflation scenario planning", "Risk language"],
  },
  {
    title: "Module 2 · ARS→USD resilience",
    summary:
      "Track currency volatility, design protective buffers, and rehearse what-ifs for different FX regimes without speculation.",
    outcomes: ["Exchange rate map", "Emergency fund layering", "Scenario worksheets"],
  },
  {
    title: "Module 3 · Budgeting Argentina",
    summary:
      "Hands-on budgeting sprints with inflation-adjusted categories, essential vs flexible spending, and digital tools for accountability.",
    outcomes: ["Adaptive budget", "Category prioritization", "Expense review ritual"],
  },
  {
    title: "Module 4 · Financial literacy lab",
    summary:
      "Participatory sessions to translate data into decisions: interest rates, debt management, and introduction to responsible investing literacy.",
    outcomes: ["Interest rate impact", "Debt triage", "Long-term planning basics"],
  },
];

const Course = () => {
  const { language } = useLanguage();
  const path = "/course";

  return (
    <PageTransition>
      <Helmet>
        <title>Course syllabus | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore the Tu Progreso Hoy personal finance starter course: modules, target audience, and responsible learning outcomes for budgeting Argentina under inflation."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">Personal finance starter course syllabus.</h1>
          <p className="hero-subtitle">
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso, conectando datos confiables con prácticas sostenibles.
          </p>
          <div className="meta-badges">
            <span className="meta-badge">Live cohort welcome</span>
            <span className="meta-badge">Data + action labs</span>
            <span className="meta-badge">Double opt-in community</span>
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <h2 style={{ color: "#1f3a6f" }}>Syllabus overview</h2>
          <p>
            The course blends argentina inflation realities, budgeting Argentina exercises, and literacy labs that prioritize responsibility. Each module is delivered in English with Spanish support, featuring templates and reflections aligned with economic trends.
          </p>
          <div className="grid">
            {modules.map((module) => (
              <div key={module.title} className="card light">
                <h3>{module.title}</h3>
                <p>{module.summary}</p>
                <strong>Key outcomes</strong>
                <ul>
                  {module.outcomes.map((item) => (
                    <li key={item} style={{ color: "rgba(15, 23, 42, 0.75)" }}>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section darkwave">
        <div className="container">
          <div className="grid grid-2">
            <div className="glass-panel">
              <span className="micro-tag">Who is this for?</span>
              <h2 style={{ color: "#f8fafc" }}>Target audience</h2>
              <ul className="hero-list">
                <li>
                  <span aria-hidden="true">•</span> Professionals aligning salary negotiations with argentina inflation data.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Households building budgeting Argentina routines with transparency.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Entrepreneurs interpreting ARS→USD volatility for day-to-day planning.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Students seeking Conocimiento financiero impulsado por tendencias.
                </li>
              </ul>
            </div>
            <div className="card">
              <h3>Learning commitments</h3>
              <p>
                You will receive weekly briefings, structured feedback, and accountability prompts. Every participant must confirm via double opt-in, ensuring intentional engagement.
              </p>
              <p>
                Análisis transparentes y datos de mercado para decidir con seguridad. No speculation, no unrealistic promises—only responsible paths underpinned by argentina inflation context.
              </p>
              <a className="btn-primary" href="/#trial-form">
                {language === "es" ? "Reservar módulo de prueba" : "Reserve trial module"}
              </a>
            </div>
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Course;