import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import PageTransition from "../components/PageTransition";
import ARSUSDTracker from "../components/ARSUSDTracker";
import { useLanguage } from "../contexts/LanguageContext";
import { BASE_URL } from "../utils/constants";

const Home = () => {
  const { language, t } = useLanguage();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    goal: "",
    consent: false,
  });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.consent) {
      setError(t("form.errorConsent"));
      return;
    }
    window.localStorage.setItem(
      "tph_trial_request",
      JSON.stringify({
        ...formData,
        timestamp: new Date().toISOString(),
      })
    );
    window.sessionStorage.setItem(
      "tph_double_opt_in_notice",
      language === "es"
        ? "Revisa tu correo y confirma la suscripción para activar el acceso."
        : "Check your inbox and confirm the subscription to activate access."
    );
    navigate("/thank-you");
  };

  const altUrl = `${BASE_URL}${language === "es" ? "/?lang=es" : "/?lang=en"}`;

  return (
    <PageTransition>
      <Helmet>
        <title>Tu Progreso Hoy | Argentina inflation data & finance learning</title>
        <meta
          name="description"
          content="Argentina inflation insights, ARS to USD tracker, and a personal finance starter course designed for responsible budgeting and trend-driven knowledge."
        />
        <link rel="canonical" href={`${BASE_URL}/`} />
        <link rel="alternate" href={`${BASE_URL}/?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}/?lang=es`} hrefLang="es-AR" />
        <link rel="alternate" href={altUrl} hrefLang="x-default" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <div className="hero-grid">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <div className="hero-badges" aria-label="Key highlights">
                <span className="hero-badge">Argentina inflation intelligence</span>
                <span className="hero-badge">Economic trends decoded</span>
                <span className="hero-badge">Finanzas personales</span>
              </div>
              <h1 className="hero-title">
                Tu Progreso Hoy — clarity for argentina inflation and personal finance journeys.
              </h1>
              <p className="hero-subtitle">
                Decisiones responsables, objetivos nítidos. De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
              </p>
              <ul className="hero-list">
                <li>
                  <span aria-hidden="true">•</span> Datos verificados para planificar tu presupuesto.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Conocimiento financiero impulsado por tendencias.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Análisis transparentes y datos de mercado para decidir con seguridad.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
                </li>
              </ul>
            </motion.div>
            <ARSUSDTracker />
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <motion.div
            className="grid grid-3"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: { opacity: 0, y: 32 },
              visible: {
                opacity: 1,
                y: 0,
                transition: { staggerChildren: 0.18, delayChildren: 0.1 },
              },
            }}
          >
            {[
              {
                title: "Argentina inflation in context",
                body:
                  "Daily ARS→USD movements integrated with local CPI releases, curated for people building resilient plans.",
                icon: "📊",
              },
              {
                title: "Responsible financial pathways",
                body:
                  "Budgeting Argentina scenarios enriched with scenario planning, without speculative promises or shortcuts.",
                icon: "🧭",
              },
              {
                title: "Course + data synergy",
                body:
                  "Consolidated insight to transition from knowledge to action with evidence-backed learning sequences.",
                icon: "🎓",
              },
            ].map((item) => (
              <motion.div
                className="card light"
                key={item.title}
                variants={{ hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } }}
              >
                <span className="micro-tag" aria-hidden="true">
                  {item.icon} Premium insight
                </span>
                <h3>{item.title}</h3>
                <p>{item.body}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid grid-2">
            <motion.div
              className="glass-panel"
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              <span className="micro-tag">Insight tiles</span>
              <h2 style={{ color: "#f8fafc" }}>Economic trends without noise</h2>
              <p>
                We source argentina inflation, official CPI, and Bank of Argentina bulletins to decode macro indicators.
                Our methodology emphasizes transparent context so you can interpret volatility and adapt your budget.
              </p>
              <div className="timeline">
                <div className="timeline-item">
                  <strong>Regulated data flows</strong>
                  <p>Official CPI releases aligned with short-term FX workshops to spot inflection points.</p>
                </div>
                <div className="timeline-item">
                  <strong>Scenario mapping</strong>
                  <p>Budgeting Argentina templates that react to weekly ARS→USD movements and inflation expectations.</p>
                </div>
                <div className="timeline-item">
                  <strong>Confidence-first narratives</strong>
                  <p>Información confiable que respalda elecciones responsables sobre tu dinero.</p>
                </div>
              </div>
            </motion.div>
            <motion.div
              className="card"
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, ease: "easeOut", delay: 0.1 }}
            >
              <img
                src="https://cdn.pixabay.com/photo/2016/11/22/19/15/printer-1850475_1280.jpg"
                alt="Analyst reviewing financial data on a modern dashboard"
                style={{ width: "100%", borderRadius: "18px", marginBottom: "1.25rem", maxHeight: "200px", objectFit: "cover" }}
              />
              <h3>Weekly insight briefings</h3>
              <p>
                We publish digestible recaps to help you focus on signal, not noise. Each briefing includes highlight charts, macro interpretations, and practice prompts from the course.
              </p>
              <ul className="hero-list">
                <li>
                  <span aria-hidden="true">•</span> Argentina inflation, ARS→USD, and regional economic trends.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Budgeting Argentina tools curated for high inflation environments.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Economic trends to transform data into daily decisions.
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section darkwave">
        <div className="container">
          <div className="grid grid-2">
            <motion.div
              initial={{ opacity: 0, x: -32 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              <span className="micro-tag">Course overview</span>
              <h2 style={{ color: "#f8fafc" }}>Personal finance starter course</h2>
              <p>
                Step-by-step learning journey anchored in argentina inflation realities. Each module fuses data with practical exercises so you can make firm, responsible decisions.
              </p>
              <p>Pasos acertados hoy, mejor futuro mañana.</p>
              <div className="meta-badges">
                <span className="meta-badge">Live data lab</span>
                <span className="meta-badge">Interactive exercises</span>
                <span className="meta-badge">Community briefings</span>
              </div>
            </motion.div>
            <motion.div
              className="glass-panel"
              initial={{ opacity: 0, x: 32 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, ease: "easeOut", delay: 0.1 }}
            >
              <h3 style={{ color: "#f8fafc" }}>From data to application</h3>
              <ul className="hero-list">
                <li>
                  <span aria-hidden="true">•</span> Inflation mechanics: CPI, FX spreads, wage adjustments.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Budget reboot: high-inflation templates, ARS→USD buffers.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Responsible investing literacy basics with data awareness.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Double opt-in community check-ins for accountability.
                </li>
              </ul>
              <button type="button" className="btn-primary" onClick={() => navigate("/course")}>
                {language === "es" ? "Ver el temario completo" : "View full syllabus"}
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <h2 style={{ color: "#1f3a6f" }}>Voices from our learners</h2>
          <div className="testimonials">
            {[
              {
                quote:
                  "Tu Progreso Hoy me dio lenguaje y datos para explicar la inflación en mi empresa sin caer en suposiciones. El curso es directo y aplicable.",
                name: "Mariana R.",
                role: "Financial coordinator, Córdoba",
              },
              {
                quote:
                  "The ARS to USD tracker paired with budgeting tools helped me redefine savings goals under volatile conditions. No hype, just clarity.",
                name: "Ignacio L.",
                role: "Product designer, Buenos Aires",
              },
              {
                quote:
                  "Sigo cada briefing porque conecta indicadores oficiales con ejercicios accionables. Información confiable que respalda elecciones responsables.",
                name: "Valeria M.",
                role: "Entrepreneur, Mendoza",
              },
            ].map((item) => (
              <motion.div
                className="testimonial-card"
                key={item.name}
                initial={{ opacity: 0, y: 32 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              >
                <p style={{ color: "rgba(226, 232, 240, 0.9)" }}>{item.quote}</p>
                <strong>{item.name}</strong>
                <span style={{ color: "rgba(148, 163, 184, 0.85)", fontSize: "0.9rem" }}>{item.role}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="trial-form">
        <div className="container">
          <motion.div
            className="glass-panel"
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <span className="micro-tag">Double opt-in access</span>
            <h2 style={{ color: "#f8fafc" }}>
              {language === "es"
                ? "Solicita un módulo de prueba gratuito"
                : "Request a complimentary trial module"}
            </h2>
            <p>
              {language === "es"
                ? "Recibirás un correo de confirmación. Solo al confirmar podrás acceder al contenido inicial y a los datos premium."
                : "You will receive a confirmation email. Access activates only after you confirm your subscription to uphold consent-first standards."}
            </p>
            {error && (
              <div className="alert error" role="alert">
                {error}
              </div>
            )}
            <form className="form" onSubmit={handleSubmit}>
              <div className="form-row double">
                <div>
                  <label htmlFor="name">{t("form.name")}</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    autoComplete="name"
                  />
                </div>
                <div>
                  <label htmlFor="email">{t("form.email")}</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    autoComplete="email"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="goal">{t("form.goal")}</label>
                <select
                  id="goal"
                  name="goal"
                  value={formData.goal}
                  onChange={handleChange}
                  required
                >
                  <option value="">{t("form.selectOption")}</option>
                  <option value="budgeting">{t("formOptions.budgeting")}</option>
                  <option value="inflation">{t("formOptions.inflation")}</option>
                  <option value="investing">{t("formOptions.investing")}</option>
                  <option value="course">{t("formOptions.course")}</option>
                </select>
              </div>
              <label className="checkbox-inline">
                <input
                  type="checkbox"
                  name="consent"
                  checked={formData.consent}
                  onChange={handleChange}
                />
                {t("form.consent")}
              </label>
              <button type="submit" className="btn-primary">
                Получить бесплатный пробный урок
              </button>
            </form>
          </motion.div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Home;