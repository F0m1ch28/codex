import React from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import Accordion from "../components/Accordion";
import { useLanguage } from "../contexts/LanguageContext";
import { BASE_URL } from "../utils/constants";

const Inflation = () => {
  const { language } = useLanguage();
  const path = "/inflation";

  const faqItems = [
    {
      question: language === "es" ? "¿De dónde provienen los datos?" : "Where do your data sources come from?",
      answer:
        language === "es"
          ? "Integración automática con el INDEC, comunicados del Banco Central de la República Argentina y tasas de mercado oficiales. Complementamos con reportes del FMI para contexto regional."
          : "Automated integration with INDEC, Central Bank of Argentina releases, and official market rates. We complement with IMF regional context reports.",
    },
    {
      question: language === "es" ? "¿Cada cuánto se actualiza el tracker?" : "How frequently is the tracker updated?",
      answer:
        language === "es"
          ? "Actualizamos las tasas ARS→USD en tiempo casi real y las tablas de inflación tan pronto se publican los datos oficiales. Los análisis se resumen semanalmente."
          : "ARS→USD rates refresh near real time and inflation tables update immediately after official releases. Summaries are compiled weekly.",
    },
    {
      question: language === "es" ? "¿El contenido es asesoramiento financiero?" : "Is the content financial advice?",
      answer:
        language === "es"
          ? "No. Proveemos información y educación financiera. Plataforma educativa con datos esenciales, sin asesoría financiera directa."
          : "No. We provide information and financial education. Educational platform only, no direct financial advisory services.",
    },
    {
      question: language === "es" ? "¿Cómo manejan la incertidumbre?" : "How do you tackle uncertainty?",
      answer:
        language === "es"
          ? "Aplicamos escenarios y sensibilidad. Mostramos rangos con supuestos explícitos para que puedas comparar y decidir con responsabilidad."
          : "We apply scenarios and sensitivity analysis. Ranges with explicit assumptions allow responsible decision-making.",
    },
  ];

  return (
    <PageTransition>
      <Helmet>
        <title>Argentina inflation methodology | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Understand the research methodology behind Argentina inflation insights, CPI / FX context, and responsible FAQ guidance for ARS to USD data."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">
            Methodology for argentina inflation & ARS→USD context.
          </h1>
          <p className="hero-subtitle">
            Evidence-backed processes translate macroeconomic signals into actionable knowledge for budgeting Argentina in a high-volatility environment.
          </p>
          <div className="meta-badges">
            <span className="meta-badge">INDEC + BCRA + IMF</span>
            <span className="meta-badge">Scenario modelling</span>
            <span className="meta-badge">Transparency first</span>
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <span className="micro-tag">Research stack</span>
          <h2 style={{ color: "#1f3a6f" }}>How we produce argentina inflation insights</h2>
          <div className="grid grid-3" style={{ marginTop: "2rem" }}>
            {[
              {
                title: "Data ingestion",
                body:
                  "INDEC CPI bulletins parsed automatically with cross-validation against market consensus. Weighted to highlight essential consumption baskets.",
              },
              {
                title: "FX alignment",
                body:
                  "ARS→USD rates sourced from regulated feeds. Spread analysis compares official, MEP, and blue-chip swap for risk awareness.",
              },
              {
                title: "Narrative synthesis",
                body:
                  "Qualitative cues from government releases and private sector surveys build broader economic trends without sensationalism.",
              },
            ].map((item) => (
              <div key={item.title} className="card light">
                <h3>{item.title}</h3>
                <p>{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section darkwave">
        <div className="container">
          <div className="grid grid-2">
            <div className="glass-panel">
              <span className="micro-tag">CPI / FX context</span>
              <h2 style={{ color: "#f8fafc" }}>Connecting CPI releases with ARS→USD dynamics</h2>
              <p>
                We track inflation across essential categories to expose pressure points on household budgets. Each CPI release is paired with ARS→USD volatility windows to reveal when currency adjustments intensify cost of living.
              </p>
              <ul className="hero-list">
                <li>
                  <span aria-hidden="true">•</span> Weighted CPI dashboards for transportation, food, housing, education.
                </li>
                <li>
                  <span aria-hidden="true">•</span> ARS→USD delta overlays to highlight devaluation risk windows.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Scenario comparisons: optimistic, base, and stress case budgeting outlines.
                </li>
                <li>
                  <span aria-hidden="true">•</span> Conocimiento financiero impulsado por tendencias, construido sin promesas vacías.
                </li>
              </ul>
            </div>
            <div className="card">
              <h3>Transparency commitments</h3>
              <p>
                We document every assumption, formula, and limitation so decisions stay grounded. Each chart is downloadable with metadata and release references.
              </p>
              <div className="timeline">
                <div className="timeline-item">
                  <strong>Sources disclosed</strong>
                  <p>Each dataset includes official links and retrieval timestamps.</p>
                </div>
                <div className="timeline-item">
                  <strong>Method notes</strong>
                  <p>Scenario files list inflation differentials, exchange rate elasticity, and smoothing windows.</p>
                </div>
                <div className="timeline-item">
                  <strong>Review cadence</strong>
                  <p>Quarterly audits ensure consistency with Argentina inflation benchmarks and peer-reviewed studies.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <h2 style={{ color: "#1f3a6f" }}>Frequently asked questions</h2>
          <Accordion items={faqItems} />
        </div>
      </section>
    </PageTransition>
  );
};

export default Inflation;