import React from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import { useLanguage } from "../contexts/LanguageContext";
import { BASE_URL } from "../utils/constants";

const articles = [
  {
    title: "Argentina inflation: interpreting monthly CPI releases",
    language: "EN",
    summary:
      "Step-by-step reading guide for INDEC bulletins with emphasis on household spending categories and what to monitor each month.",
    link: "#",
    image: "https://cdn.pixabay.com/photo/2015/05/31/13/08/analysis-791049_1280.jpg",
  },
  {
    title: "Guía rápida: Presupuestar en inflación alta",
    language: "ES",
    summary:
      "Fórmulas sencillas para ajustar categorías, montar colchones en dólares y planificar pagos de servicios sin estrés.",
    link: "#",
    image: "https://cdn.pixabay.com/photo/2015/01/21/14/14/apple-606761_1280.jpg",
  },
  {
    title: "Economic trends radar — Latin America & Argentina",
    language: "EN/ES",
    summary:
      "Contextualizes argentina inflation with regional peers, highlighting supply shocks, currency adjustments, and policy announcements.",
    link: "#",
    image: "https://cdn.pixabay.com/photo/2016/11/29/09/16/stock-1863880_1280.jpg",
  },
  {
    title: "Glosario bilingüe: finanzas personales + inflación",
    language: "ES/EN",
    summary:
      "Términos clave en inglés y español: tasa de interés, crawling peg, pass-through, and fiscal anchors explained for everyday decisions.",
    link: "#",
    image: "https://cdn.pixabay.com/photo/2015/12/05/23/58/reading-1071328_1280.jpg",
  },
];

const Resources = () => {
  const { language } = useLanguage();
  const path = "/resources";

  return (
    <PageTransition>
      <Helmet>
        <title>Resources & glossaries | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Curated articles, glossaries, and resources in English and Spanish for argentina inflation, ARS to USD insights, and personal finance literacy."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">Resources to deepen your argentina inflation literacy.</h1>
          <p className="hero-subtitle">
            Información confiable que respalda elecciones responsables sobre tu dinero. Discover how budgeting Argentina, economic trends, and ARS→USD insights intersect.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <div className="resources-list">
            {articles.map((article) => (
              <article key={article.title} className="resource-card">
                <img src={article.image} alt={article.title} />
                <span className="tag-pill">{article.language}</span>
                <h3 style={{ color: "#1f3a6f" }}>{article.title}</h3>
                <p style={{ color: "rgba(15,23,42,0.7)" }}>{article.summary}</p>
                <a className="btn-secondary" href={article.link}>
                  {language === "es" ? "Leer recurso" : "Read resource"}
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Resources;