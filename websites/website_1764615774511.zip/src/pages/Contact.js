import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import { useLanguage } from "../contexts/LanguageContext";
import { BASE_URL } from "../utils/constants";

const Contact = () => {
  const { language, t } = useLanguage();
  const [status, setStatus] = useState("idle");
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    message: "",
    consent: false,
  });
  const [error, setError] = useState("");

  const path = "/contact";

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormState((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formState.consent) {
      setError(t("form.errorConsent"));
      return;
    }
    setError("");
    window.localStorage.setItem(
      "tph_contact_request",
      JSON.stringify({ ...formState, timestamp: new Date().toISOString() })
    );
    setStatus("submitted");
  };

  return (
    <PageTransition>
      <Helmet>
        <title>Contact Tu Progreso Hoy | Buenos Aires</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy in Buenos Aires, Argentina. Reach out for argentina inflation insights and responsible personal finance education."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">Connect with Tu Progreso Hoy</h1>
          <p className="hero-subtitle">
            Our team in Buenos Aires is ready to help you interpret argentina inflation updates and progress through the course with clarity.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <div className="grid grid-2">
            <div>
              <h2 style={{ color: "#1f3a6f" }}>Office & contact details</h2>
              <p>
                Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
                <br />
                +54 11 5555-1234
                <br />
                hola@tuprogresohoy.com
              </p>
              <div className="map-wrapper" aria-label="Map of Tu Progreso Hoy location">
                <iframe
                  title="Tu Progreso Hoy office"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.197972890357!2d-58.380148223525315!3d-34.61707835876944!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccadc265a6805%3A0xff17787886d51d5!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1712345678901!5m2!1sen!2sar"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
            <div className="glass-panel">
              <span className="micro-tag">Double opt-in form</span>
              <h2 style={{ color: "#f8fafc" }}>{language === "es" ? "Envíanos tu consulta" : "Send us your request"}</h2>
              {error && (
                <div className="alert error" role="alert">
                  {error}
                </div>
              )}
              {status === "submitted" ? (
                <div className="alert success" role="status">
                  {t("contact.submitted")}
                </div>
              ) : (
                <form className="form" onSubmit={handleSubmit}>
                  <div className="form-row">
                    <div>
                      <label htmlFor="contact-name">{t("form.name")}</label>
                      <input
                        id="contact-name"
                        name="name"
                        type="text"
                        value={formState.name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="contact-email">{t("form.email")}</label>
                      <input
                        id="contact-email"
                        name="email"
                        type="email"
                        value={formState.email}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="contact-message">{t("contact.message")}</label>
                    <textarea
                      id="contact-message"
                      name="message"
                      value={formState.message}
                      onChange={handleChange}
                      required
                      rows={5}
                    ></textarea>
                  </div>
                  <label className="checkbox-inline">
                    <input
                      type="checkbox"
                      name="consent"
                      checked={formState.consent}
                      onChange={handleChange}
                    />
                    {t("form.consent")}
                  </label>
                  <button type="submit" className="btn-primary">
                    {t("contact.send")}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Contact;