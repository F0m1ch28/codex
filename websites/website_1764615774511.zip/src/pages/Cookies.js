import React from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import { BASE_URL } from "../utils/constants";

const Cookies = () => {
  const path = "/cookies";

  return (
    <PageTransition>
      <Helmet>
        <title>Cookie Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Tu Progreso Hoy cookie policy describing essential and optional cookies, consent choices, and how to manage preferences."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">Cookie Policy</h1>
          <p className="hero-subtitle">
            Learn how Tu Progreso Hoy uses cookies to maintain essential functionality and optional analytics respectful of your choices.
          </p>
        </div>
      </section>
      <section className="section light">
        <div className="container">
          <h2 style={{ color: "#1f3a6f" }}>1. Essential cookies</h2>
          <p>
            These cookies are required to operate the website, manage sessions, remember language preferences, and protect against fraudulent requests.
          </p>
          <h2 style={{ color: "#1f3a6f" }}>2. Optional analytics</h2>
          <p>
            Analytics cookies help us understand aggregated usage. They are only activated if you click “Accept cookies” in our banner. Declining will not limit access to content.
          </p>
          <h2 style={{ color: "#1f3a6f" }}>3. Third-party services</h2>
          <p>
            We may use privacy-friendly analytics platforms. They receive anonymized data and cannot identify individuals.
          </p>
          <h2 style={{ color: "#1f3a6f" }}>4. Managing preferences</h2>
          <p>
            You can revisit your choice by clearing browser cookies or contacting hola@tuprogresohoy.com. Browser settings allow further control.
          </p>
        </div>
      </section>
    </PageTransition>
  );
};

export default Cookies;