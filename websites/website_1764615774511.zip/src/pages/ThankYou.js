import React from "react";
import { Helmet } from "react-helmet-async";
import PageTransition from "../components/PageTransition";
import { useLanguage } from "../contexts/LanguageContext";
import { BASE_URL } from "../utils/constants";

const ThankYou = () => {
  const { language } = useLanguage();
  const notice =
    window.sessionStorage.getItem("tph_double_opt_in_notice") ||
    (language === "es"
      ? "Revisa tu correo electrónico para confirmar la suscripción."
      : "Check your email inbox to confirm the subscription.");

  const path = "/thank-you";

  return (
    <PageTransition>
      <Helmet>
        <title>Thank you | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Thank you for requesting access to Tu Progreso Hoy. Confirm the double opt-in email to activate your complimentary module."
        />
        <link rel="canonical" href={`${BASE_URL}${path}`} />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=en`} hrefLang="en" />
        <link rel="alternate" href={`${BASE_URL}${path}?lang=es`} hrefLang="es-AR" />
      </Helmet>
      <section className="hero">
        <div className="container">
          <h1 className="hero-title">{language === "es" ? "¡Gracias!" : "Thank you!"}</h1>
          <p className="hero-subtitle">{notice}</p>
          <p>
            {language === "es"
              ? "Tu solicitud se activará cuando confirmes el enlace de doble opt-in. Así mantenemos tus datos seguros y respetamos tu consentimiento."
              : "Your request activates once you confirm the double opt-in link. This keeps your data safe and ensures we communicate with full consent."}
          </p>
          <a className="btn-secondary" href="/">
            {language === "es" ? "Volver al inicio" : "Return home"}
          </a>
        </div>
      </section>
    </PageTransition>
  );
};

export default ThankYou;