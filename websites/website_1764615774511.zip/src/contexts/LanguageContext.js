import React, { createContext, useContext, useMemo, useState, useEffect } from "react";

const LanguageContext = createContext();

const translations = {
  en: {
    nav: {
      home: "Home",
      inflation: "Inflation Insights",
      course: "Course",
      resources: "Resources",
      contact: "Contact",
    },
    actions: {
      contact: "Talk with us",
      exploreCourse: "Explore syllabus",
    },
    footer: {
      about: "About",
      legal: "Legal",
      follow: "Follow",
      rights: "© Tu Progreso Hoy. All rights reserved.",
    },
    accessibility: {
      skipToContent: "Skip to main content",
    },
    cookie: {
      title: "Cookies & analytics",
      description:
        "We use cookies to analyze engagement and tailor content. You can accept or decline optional cookies.",
      accept: "Accept cookies",
      decline: "Decline",
    },
    disclaimer: {
      title: "Important notice",
      description:
        "Access to this educational platform requires acknowledging that Tu Progreso Hoy does not provide financial services.",
      acknowledge: "I understand and wish to continue",
    },
    form: {
      name: "Full name",
      email: "Email address",
      goal: "What financial focus interests you most?",
      selectOption: "Select an option",
      consent:
        "I agree to receive the double opt-in email and confirm I have read the privacy notice.",
      submit: "Submit",
      success: "Please check your inbox to confirm your request.",
      errorConsent: "Please agree to the consent statement to continue.",
    },
    formOptions: {
      budgeting: "Budgeting in Argentina",
      inflation: "ARS→USD inflation scenarios",
      investing: "Foundations of investing literacy",
      course: "Course modules overview",
    },
    contact: {
      message: "How can we support your financial learning goals?",
      send: "Send request",
      submitted:
        "Double opt-in email dispatched. Confirm your inbox to activate the conversation.",
    },
  },
  es: {
    nav: {
      home: "Inicio",
      inflation: "Inflación",
      course: "Curso",
      resources: "Recursos",
      contact: "Contacto",
    },
    actions: {
      contact: "Hablemos",
      exploreCourse: "Ver temario",
    },
    footer: {
      about: "Acerca",
      legal: "Legal",
      follow: "Redes",
      rights: "© Tu Progreso Hoy. Todos los derechos reservados.",
    },
    accessibility: {
      skipToContent: "Ir al contenido principal",
    },
    cookie: {
      title: "Cookies y analítica",
      description:
        "Utilizamos cookies para analizar el uso y personalizar contenidos. Puedes aceptar o rechazar las cookies opcionales.",
      accept: "Aceptar cookies",
      decline: "Rechazar",
    },
    disclaimer: {
      title: "Aviso importante",
      description:
        "Acceder a esta plataforma educativa implica reconocer que Tu Progreso Hoy no brinda servicios financieros.",
      acknowledge: "Entiendo y deseo continuar",
    },
    form: {
      name: "Nombre completo",
      email: "Correo electrónico",
      goal: "¿Qué enfoque financiero te interesa más?",
      selectOption: "Selecciona una opción",
      consent:
        "Acepto recibir el correo de doble confirmación y afirmo haber leído la política de privacidad.",
      submit: "Enviar",
      success: "Revisa tu bandeja de entrada para confirmar la solicitud.",
      errorConsent: "Por favor acepta la declaración de consentimiento para continuar.",
    },
    formOptions: {
      budgeting: "Presupuestar en Argentina",
      inflation: "Escenarios de inflación ARS→USD",
      investing: "Fundamentos de cultura inversora",
      course: "Resumen de módulos del curso",
    },
    contact: {
      message: "¿Cómo podemos apoyar tus objetivos de aprendizaje financiero?",
      send: "Enviar solicitud",
      submitted:
        "Correo de doble confirmación enviado. Confirma en tu bandeja para activar la conversación.",
    },
  },
};

const getInitialLanguage = () => {
  if (typeof window === "undefined") return "en";
  const stored = window.localStorage.getItem("tph_language");
  if (stored && translations[stored]) return stored;
  const urlLang = new URLSearchParams(window.location.search).get("lang");
  if (urlLang && translations[urlLang]) return urlLang;
  return "en";
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(getInitialLanguage);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("tph_language", language);
      document.documentElement.lang = language === "es" ? "es-AR" : "en";
    }
  }, [language]);

  const value = useMemo(() => {
    const t = (path) => {
      const keys = path.split(".");
      return keys.reduce((acc, key) => (acc ? acc[key] : undefined), translations[language]) ?? path;
    };
    return {
      language,
      setLanguage,
      t,
      translations,
    };
  }, [language]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => useContext(LanguageContext);