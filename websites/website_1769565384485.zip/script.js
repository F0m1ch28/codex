const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const COOKIE_STORAGE_KEY = "cookie_consent";
const SUPPORTED_LANGS = ["fr", "en"];

const I18N = {
  fr: {
    "title.home": "danswholesaleplants | Orientation spatiale et signalétique numérique",
    "title.services": "Services analytiques | danswholesaleplants",
    "title.about": "À propos | danswholesaleplants",
    "title.blog": "Blog de l’orientation spatiale | danswholesaleplants",
    "title.contact": "Contact | danswholesaleplants",
    "title.faq": "FAQ | danswholesaleplants",
    "title.terms": "Conditions d’utilisation | danswholesaleplants",
    "title.privacy": "Confidentialité | danswholesaleplants",
    "title.cookies": "Politique relative aux cookies | danswholesaleplants",
    "title.refund": "Politique de révision | danswholesaleplants",
    "title.disclaimer": "Avis de non-responsabilité | danswholesaleplants",
    "title.thankyou": "Merci | danswholesaleplants",
    "title.post1": "Cartographier la perception spatiale | danswholesaleplants",
    "title.post2": "Écosystèmes de signalétique numérique | danswholesaleplants",
    "title.post3": "Concevoir des parcours inclusifs | danswholesaleplants",
    "title.post4": "Analyse du flux piéton | danswholesaleplants",
    "title.post5": "Systèmes d’orientation hybride | danswholesaleplants",
    "meta.home": "Perspective bilingue sur l’orientation spatiale, la signalétique numérique et la navigation dans les environnements bâtis complexes en Belgique.",
    "meta.services": "Panorama expert des volets analytiques et méthodologiques liés à la conception de parcours utilisateurs dans des espaces complexes.",
    "meta.about": "Philosophie, approche et équipe de danswholesaleplants, dédiée à la lisibilité des environnements bâtis.",
    "meta.blog": "Analyses détaillées sur la cartographie des espaces, la mobilité piétonne et l’UX spatiale.",
    "meta.contact": "Entrer en relation avec l’équipe de danswholesaleplants et explorer l’adresse bruxelloise.",
    "meta.faq": "Réponses aux questions fréquentes sur la navigation intérieure et les méthodologies de signalétique numérique.",
    "meta.terms": "Conditions d’utilisation structurant la consultation du site danswholesaleplants.",
    "meta.privacy": "Politique de confidentialité décrivant collecte, utilisation et gouvernance des données.",
    "meta.cookies": "Détails sur l’usage des cookies, leurs catégories et la gestion des préférences.",
    "meta.refund": "Modalités de révision des projets et garanties méthodologiques.",
    "meta.disclaimer": "Limites de responsabilité et portée informative du site.",
    "meta.thankyou": "Confirmation de réception après prise de contact.",
    "meta.post1": "Étude approfondie de la perception spatiale et des cartes mentales dans des infrastructures publiques complexes.",
    "meta.post2": "Évaluation systémique des écosystèmes de signalétique numérique et de la cohérence multi-supports.",
    "meta.post3": "Guide pour créer des parcours inclusifs en intégrant accessibilité et lisibilité spatiale.",
    "meta.post4": "Méthodes de mesure et d’analyse des flux piétons dans des environnements urbains dynamiques.",
    "meta.post5": "Approches hybrides combinant supports physiques et interfaces digitales pour un guidage cohérent.",
    "header.logo": "danswholesaleplants",
    "nav.menu": "Menu",
    "nav.toggle": "Basculer la navigation principale",
    "nav.home": "Accueil",
    "nav.services": "Services",
    "nav.about": "À propos",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "lang.toggleLabel": "Sélection de la langue",
    "lang.fr": "FR",
    "lang.en": "EN",
    "home.hero.title": "Orientation spatiale et intelligence de parcours pour les environnements bâtis",
    "home.hero.subtitle": "Nous explorons la manière dont la signalétique numérique, la cartographie interactive et le design informationnel guident les usagers au sein d’infrastructures publiques, d’espaces urbains et de bâtiments labyrinthiques.",
    "home.hero.button": "Explorer nos analyses",
    "home.hero.caption": "Rue de la Loi 155, 1040 Bruxelles — observations in situ et cadres méthodologiques.",
    "home.hero.imgAlt": "Illustration de cartes interactives et signalétique lumineuse dans un hall public",
    "home.focus.title": "Axes de recherche majeurs",
    "home.focus.subtitle": "Une approche systémique reliant lisibilité, accessibilité et UX spatiale dans des environnements complexes.",
    "home.focus.item1.title": "Cartographie comportementale",
    "home.focus.item1.text": "Modéliser les décisions micro-spatiales, comprendre les points d’attention et traduire les cartes mentales en visualisations exploitables pour la conception d’itinéraires fiables.",
    "home.focus.item2.title": "Signalétique numérique stratifiée",
    "home.focus.item2.text": "Aligner supports physiques, interfaces interactives et canaux mobiles afin d’offrir un continuum d’information et une expérience cohérente à chaque nœud décisionnel.",
    "home.focus.item3.title": "Accessibilité multisensorielle",
    "home.focus.item3.text": "Combiner contraste visuel, balisage tactile, repères sonores et données inclusives pour que chaque personne puisse interpréter l’espace sans ambiguïté.",
    "home.metrics.title": "Repères chiffrés",
    "home.metrics.subtitle": "Une veille terrain et documentaire continue sur la mobilité piétonne en Belgique.",
    "home.metrics.item1.value": "68",
    "home.metrics.item1.label": "sites observés sur le territoire belge",
    "home.metrics.item2.value": "34",
    "home.metrics.item2.label": "protocoles analytiques documentés",
    "home.metrics.item3.value": "210",
    "home.metrics.item3.label": "parcours utilisateurs reconstitués",
    "home.metrics.item4.value": "12",
    "home.metrics.item4.label": "partenariats institutionnels suivis",
    "home.recommendations.title": "Recommandations structurelles",
    "home.recommendations.subtitle": "Synthèses opérationnelles pour des maîtrises d’ouvrage et équipes de conception.",
    "home.recommendations.card1.title": "Cartes modulaires",
    "home.recommendations.card1.text": "Structurer des cartes numériques adaptatives capables d’afficher des niveaux progressifs d’information selon le contexte, l’affluence et le profil d’utilisateur ciblé.",
    "home.recommendations.card2.title": "Systèmes de balises",
    "home.recommendations.card2.text": "Déployer des balises visuelles et sonores interconnectées qui maintiennent une continuité entre entrées, points d’accueil, ascenseurs et zones de transition.",
    "home.recommendations.card3.title": "Observatoires d’usage",
    "home.recommendations.card3.text": "Installer des observatoires permanents des flux piétons couplant comptages, feedback qualitatifs et exploitation de données ouvertes sur la mobilité.",
    "home.testimonials.title": "Témoignages",
    "home.testimonials.subtitle": "Regards croisés de responsables d’équipements publics accompagnés dans leurs transformations spatiales.",
    "home.testimonials.card1.quote": "Les grilles d’analyse proposées nous ont permis de révéler des points noirs de circulation ignorés, et d’articuler une signalétique numérique capable d’évoluer avec nos usages.",
    "home.testimonials.card1.name": "Aline Vandevelde",
    "home.testimonials.card1.role": "Coordination d’un pôle hospitalier métropolitain",
    "home.testimonials.card2.quote": "La lecture attentive des parcours sensoriels a directment influencé la scénographie d’accueil et la distribution des repères lumineux dans notre campus universitaire.",
    "home.testimonials.card2.name": "Hugo Demey",
    "home.testimonials.card2.role": "Responsable espace public d’une université bruxelloise",
    "home.testimonials.card3.quote": "Les cartes interactives conçues avec l’équipe ont aidé les voyageurs à saisir les connexions multimodales dès l’entrée, réduisant les hésitations aux jonctions critiques.",
    "home.testimonials.card3.name": "Sarah Janssens",
    "home.testimonials.card3.role": "Direction de l’intermodalité, réseau ferroviaire belge",
    "home.blog.title": "Lectures récentes",
    "home.blog.subtitle": "Articles approfondis sur l’orientation spatiale, la circulation piétonne et la conception d’expériences de navigation.",
    "home.blog.card1.excerpt": "Analyse des cartes mentales et de la perception dynamique lors de la traversée de bâtiments publics complexes.",
    "home.blog.card2.excerpt": "Structure systémique des écosystèmes de signalétique numérique associant mobilier et interfaces interactives.",
    "home.blog.card3.excerpt": "Démarches pour intégrer l’accessibilité dès la modélisation des parcours utilisateurs.",
    "home.blog.card4.excerpt": "Indicateurs et métriques pour qualifier le flux piéton dans les environnements urbains interconnectés.",
    "home.blog.card5.excerpt": "Fusion des supports physiques et digitaux afin de créer des repères cohérents et adaptatifs.",
    "services.hero.title": "Observer, structurer et anticiper la navigation spatiale",
    "services.hero.subtitle": "Nos travaux reposent sur des enquêtes terrain, des modélisations de flux et des scénarios prospectifs pour améliorer la lisibilité des lieux.",
    "services.overview.title": "Champs d’intervention observés",
    "services.overview.intro": "Chaque intervention est envisagée comme une exploration méthodologique visant à révéler les frictions de navigation, à tester des hypothèses de circulation et à documenter les solutions les plus adaptées.",
    "services.item1.title": "Analyse des défis d’orientation",
    "services.item1.p1": "Nous étudions les obstacles qui fragmentent l’expérience de déplacement : intersections confuses, transitions verticales opaques, densité d’informations peu hiérarchisée. Cette analyse s’appuie sur des relevés de terrain, des cartographies sensibles et des scénarios d’usage contrastés.",
    "services.item1.p2": "Les résultats permettent d’identifier des zones critiques, de poser des indicateurs de compréhension et d’esquisser des pistes de remédiation progressive adaptées à la complexité de chaque site.",
    "services.item2.title": "Signalétique numérique et cartographie",
    "services.item2.p1": "Les dispositifs numériques sont évalués selon leur capacité à relier informations globales et repères micro-locaux. Nous examinons les gabarits d’écran, les rythmes d’actualisation et leur articulation avec les supports physiques existants.",
    "services.item2.p2": "Nous préconisons des cartographies modulaires, pensées pour évoluer au fil des scénarios d’occupation, et pour dialoguer avec des systèmes de diffusion à distance ou des applications mobiles internes.",
    "services.item3.title": "Parcours utilisateurs centrés sur l’usager",
    "services.item3.p1": "Les parcours sont reconstruits à partir d’observations in situ, de données de fréquentation anonymisées et d’entretiens qualitatifs. Chaque trajectoire est documentée par des repères sensoriels, des micro-décisions et des attentes explicites.",
    "services.item3.p2": "Cette approche conduit à des itinéraires qui réduisent les hésitations, valorisent les points d’intérêt et intègrent les contraintes de temps, de luminosité ou de densité de flux.",
    "services.item4.title": "Accessibilité et lisibilité spatiale",
    "services.item4.p1": "L’accessibilité est abordée sous une perspective multi-sensorielle : contrastes visuels, guidage tactile, options audio, langage clair et pictogrammes compréhensibles.",
    "services.item4.p2": "Nous veillons à la cohérence entre les normes, les retours d’expérience des usagers et les ambitions architecturales pour garantir une lecture immédiate de l’espace.",
    "services.item5.title": "Recherche sur la mobilité piétonne",
    "services.item5.p1": "Nos protocoles de recherche s’appuient sur des observations discrètes, des mesures de temps de parcours, ainsi que sur l’analyse de la densité et de la vitesse des flux.",
    "services.item5.p2": "Les résultats alimentent des tableaux de bord évolutifs et des recommandations capables d’anticiper les variations saisonnières, événementielles ou structurelles.",
    "services.methods.title": "Méthodologies transversales",
    "services.methods.p1": "Cartes narratives, matrices d’accessibilité, maquettes interactives et ateliers collaboratifs constituent le socle de nos investigations.",
    "services.methods.p2": "Chaque livrable vise à outiller les équipes opérationnelles pour une amélioration continue des repères spatiaux.",
    "about.hero.title": "Cultiver une culture de la lisibilité spatiale",
    "about.hero.subtitle": "danswholesaleplants observe, compare et restitue la manière dont les personnes appréhendent les environnements complexes au quotidien.",
    "about.story.title": "Origines et trajectoire",
    "about.story.p1": "Née de missions exploratoires sur les grandes infrastructures belges, notre démarche relie la cartographie, l’architecture et l’expérience utilisateur. Nous travaillons aux côtés d’exploitants, de concepteurs et de collectivités pour traduire des enjeux abstraits en parcours tangibles.",
    "about.story.p2": "Notre équipe rassemble urbanistes, designers informationnels et spécialistes des données. Cette pluralité nourrit des grilles de lecture capables d’appréhender simultanément les contextes sociaux, techniques et spatiaux.",
    "about.values.title": "Valeurs structurantes",
    "about.values.item1.title": "Observation rigoureuse",
    "about.values.item1.text": "Chaque diagnostic repose sur des relevés reproductibles, des traces vidéo anonymisées, des cartes sensibles et des ateliers de confrontation de points de vue.",
    "about.values.item2.title": "Transversalité",
    "about.values.item2.text": "Nous articulons interface numérique, mobiliers physiques, architecture et gouvernance pour garantir une cohérence de bout en bout.",
    "about.values.item3.title": "Approche inclusive",
    "about.values.item3.text": "Nos méthodes intègrent les besoins des publics spécifiques dès la phase de cadrage, aux côtés d’associations, de médiateurs et de comités d’usagers.",
    "about.timeline.title": "Repères chronologiques",
    "about.timeline.step1.title": "2016 — Premiers terrains",
    "about.timeline.step1.text": "Explorations des gares et hôpitaux bruxellois, constitution d’un corpus d’observations sur la circulation verticale.",
    "about.timeline.step2.title": "2018 — Cadres méthodologiques",
    "about.timeline.step2.text": "Formalisation d’outils d’évaluation des supports numériques, diffusion des premiers protocoles de tests utilisateurs in situ.",
    "about.timeline.step3.title": "2020 — Approche inclusive renforcée",
    "about.timeline.step3.text": "Collaboration avec des associations de personnes déficientes visuelles pour co-concevoir des maquettes tactiles et des interfaces audio.",
    "about.timeline.step4.title": "2022 — Veille urbaine",
    "about.timeline.step4.text": "Déploiement d’observatoires sur les flux piétons, couplés à des tableaux de bord ouverts aux opérateurs publics.",
    "about.team.title": "Collectif de compétences",
    "about.team.text": "Nos collaborateurs naviguent entre urbanisme, sciences de la donnée, design graphique et médiation culturelle. Ils partagent une fascination commune pour les espaces hybrides reliant traces numériques et repères physiques.",
    "blog.hero.title": "Blog spécialisé en orientation spatiale",
    "blog.hero.subtitle": "Analyses longues, retours d’expérience et ouvertures prospectives pour une navigation fluide dans les infrastructures belges.",
    "blog.card1.title": "Cartographier la perception spatiale dans des réseaux publics",
    "blog.card1.alt": "Plan détaillé d’un bâtiment public avec surlignage des parcours utilisateurs",
    "blog.card1.link": "post1.html",
    "blog.card2.title": "Construire un écosystème de signalétique numérique cohérent",
    "blog.card2.alt": "Totem numérique affichant des directions dans un hall lumineux",
    "blog.card2.link": "post2.html",
    "blog.card3.title": "Modéliser des parcours inclusifs et sensibles",
    "blog.card3.alt": "Personnes utilisant différents repères tactiles dans un couloir",
    "blog.card3.link": "post3.html",
    "blog.card4.title": "Comprendre les dynamiques de flux piéton urbain",
    "blog.card4.alt": "Vue aérienne de carrefours piétons interconnectés en ville",
    "blog.card4.link": "post4.html",
    "blog.card5.title": "Vers des systèmes d’orientation hybride",
    "blog.card5.alt": "Signalétique physique et interface mobile synchronisées",
    "blog.card5.link": "post5.html",
    "faq.hero.title": "Questions fréquentes",
    "faq.hero.subtitle": "Précisions sur nos méthodes d’observation, nos cadres d’analyse et l’usage des données recueillies.",
    "faq.q1": "Comment abordez-vous l’étude d’un site public complexe ?",
    "faq.a1": "Nous combinons une immersion préalable, des cartographies sensibles et des mesures quantitatives. L’objectif est de croiser perception, usage réel et structure spatiale pour révéler les points de friction majeurs.",
    "faq.q2": "Quels outils utilisez-vous pour modéliser les flux piétons ?",
    "faq.a2": "Selon le contexte, nous mobilisons des relevés manuels, des capteurs temporaires, des vidéos anonymisées et des données ouvertes. Ces sources sont agrégées dans des tableaux de bord qui reflètent volumes, vitesses et temps d’attente.",
    "faq.q3": "Comment intégrez-vous l’accessibilité dès le début ?",
    "faq.a3": "Nous associons des publics concernés aux phases de cadrage, analysons les parcours existants avec des experts de l’accessibilité et vérifions chaque scénario de signalétique selon des critères sensoriels variés.",
    "faq.q4": "Que deviennent les données collectées ?",
    "faq.a4": "Les données sont pseudonymisées, stockées de manière sécurisée et conservées uniquement pour la durée nécessaire aux analyses décrites. Nous favorisons une transparence complète vis-à-vis des parties prenantes.",
    "faq.q5": "Travaillez-vous uniquement en Belgique ?",
    "faq.a5": "Nos recherches sont ancrées en Belgique, mais nous observons aussi des références internationales afin de comparer des dispositifs innovants et alimenter nos recommandations.",
    "faq.q6": "Comment partagez-vous vos enseignements ?",
    "faq.a6": "Nous produisons des rapports détaillés, des cartes commentées, des matrices décisionnelles et organisons des ateliers pour aligner les acteurs sur des trajectoires d’amélioration continue.",
    "contact.hero.title": "Entrer en dialogue avec danswholesaleplants",
    "contact.hero.subtitle": "Un espace pour partager vos questions, vos observations et explorer ensemble les trajectoires de navigation dans vos environnements.",
    "contact.intro.title": "Co-construire des espaces lisibles",
    "contact.intro.text": "Décrivez-nous vos enjeux spatiaux, vos publics, vos contraintes et vos objectifs. Nous analysons chaque contexte pour identifier les leviers de compréhension et de fluidité.",
    "contact.details.title": "Coordonnées et disponibilité",
    "contact.phoneLabel": "Téléphone",
    "contact.phoneLink": "+32 2 320 45 78",
    "contact.emailLabel": "Courriel",
    "contact.emailLink": "info@danswholesaleplants.com",
    "contact.addressLabel": "Adresse",
    "contact.addressValue": "Rue de la Loi 155, 1040 Bruxelles, Belgique",
    "contact.mapTitle": "Carte situant l’adresse Rue de la Loi 155 à Bruxelles",
    "contact.mapCaption": "Localisation du point d’observation principal à Bruxelles.",
    "contact.form.title": "Formulaire de prise de contact",
    "contact.form.subtitle": "Répondez aux champs pour préciser votre demande. Nous revenons vers vous avec des pistes méthodologiques adaptées.",
    "contact.form.name": "Nom complet",
    "contact.form.email": "Adresse électronique",
    "contact.form.organization": "Organisation ou structure",
    "contact.form.message": "Message détaillé",
    "contact.form.namePlaceholder": "Indiquez votre nom",
    "contact.form.emailPlaceholder": "Indiquez votre adresse électronique",
    "contact.form.organizationPlaceholder": "Précisez votre organisation",
    "contact.form.messagePlaceholder": "Décrivez votre contexte spatial et vos questions",
    "contact.form.submit": "Envoyer",
    "contact.form.success": "Votre message a été transmis. À très vite.",
    "contact.form.error": "Veuillez vérifier les champs requis.",
    "contact.form.emailInvalid": "Le format du courriel doit être valide.",
    "contact.toast.redirect": "Redirection vers la page de confirmation...",
    "terms.hero.title": "Conditions d’utilisation",
    "terms.hero.subtitle": "Ce document encadre la consultation et l’usage des contenus publiés sur danswholesaleplants.com.",
    "terms.section1.title": "1. Objet du site",
    "terms.section1.p1": "Le site fournit des analyses sur l’orientation spatiale et la signalétique numérique. Il n’a aucune vocation commerciale et propose exclusivement du contenu informatif.",
    "terms.section2.title": "2. Acceptation",
    "terms.section2.p1": "La navigation sur le site implique l’acceptation pleine et entière des présentes conditions. Toute consultation ultérieure les reconduit tacitement.",
    "terms.section3.title": "3. Propriété intellectuelle",
    "terms.section3.p1": "Les textes, visuels et structures sont protégés par le droit d’auteur. Toute reproduction doit faire l’objet d’une autorisation écrite préalable.",
    "terms.section4.title": "4. Usage autorisé",
    "terms.section4.p1": "Les contenus peuvent être consultés et cités à des fins d’étude ou de veille, sous réserve d’une mention claire de la source.",
    "terms.section5.title": "5. Responsabilité de l’éditeur",
    "terms.section5.p1": "Nous veillons à la fiabilité des informations mais ne pouvons garantir l’absence totale d’imprécision ou l’actualité permanente des contenus.",
    "terms.section6.title": "6. Responsabilité de l’utilisateur",
    "terms.section6.p1": "L’utilisateur s’engage à visiter le site dans le respect des lois en vigueur et à ne pas perturber son fonctionnement technique.",
    "terms.section7.title": "7. Liens externes",
    "terms.section7.p1": "Des liens peuvent orienter vers des sites tiers. Nous ne contrôlons pas ces ressources et déclinons toute responsabilité quant à leurs contenus.",
    "terms.section8.title": "8. Données personnelles",
    "terms.section8.p1": "Les informations transmises via le formulaire de contact sont traitées conformément à la politique de confidentialité détaillée sur le site.",
    "terms.section9.title": "9. Cookies",
    "terms.section9.p1": "Le site utilise des cookies décrit dans la politique relative aux cookies. L’utilisateur peut gérer ses préférences à tout moment.",
    "terms.section10.title": "10. Disponibilité",
    "terms.section10.p1": "Nous nous efforçons d’assurer un accès continu mais des interruptions peuvent survenir pour maintenance ou circonstances extérieures.",
    "terms.section11.title": "11. Modifications",
    "terms.section11.p1": "Les présentes conditions peuvent être ajustées. La date de mise à jour est indiquée en en-tête du document.",
    "terms.section12.title": "12. Droit applicable",
    "terms.section12.p1": "Les présentes conditions sont régies par le droit belge. Tout litige relève de la compétence des tribunaux de Bruxelles.",
    "terms.section13.title": "13. Contact",
    "terms.section13.p1": "Toute question relative à ces conditions peut être adressée via le formulaire de contact du site.",
    "terms.section14.title": "14. Entrée en vigueur",
    "terms.section14.p1": "Cette version est applicable depuis le 12 février 2024 et remplace toute version antérieure.",
    "privacy.hero.title": "Politique de confidentialité",
    "privacy.hero.subtitle": "Transparence sur la collecte, l’utilisation et la conservation des données transmises.",
    "privacy.section1.title": "1. Collecte des informations",
    "privacy.section1.p1": "Nous collectons les données fournies volontairement via le formulaire de contact : nom, adresse électronique, organisation et message.",
    "privacy.section2.title": "2. Fondement de traitement",
    "privacy.section2.p1": "Les données sont traitées pour répondre aux demandes et poursuivre nos échanges liés aux thématiques d’orientation spatiale.",
    "privacy.section3.title": "3. Utilisation",
    "privacy.section3.p1": "Les informations servent à analyser la demande, préparer une réponse contextualisée et documenter les sollicitations reçues.",
    "privacy.section4.title": "4. Conservation",
    "privacy.section4.p1": "Les données sont conservées pendant douze mois maximum après le dernier échange, sauf obligation légale de conservation plus longue.",
    "privacy.section5.title": "5. Partage",
    "privacy.section5.p1": "Les données ne sont pas partagées avec des tiers, sauf obligation légale ou demande expresse de la personne concernée.",
    "privacy.section6.title": "6. Sécurité",
    "privacy.section6.p1": "Nous mettons en œuvre des mesures techniques et organisationnelles afin de protéger les données contre tout accès non autorisé.",
    "privacy.section7.title": "7. Droits des personnes",
    "privacy.section7.p1": "Vous pouvez exercer vos droits d’accès, de rectification, d’effacement, de limitation et d’opposition en utilisant le formulaire de contact.",
    "privacy.section8.title": "8. Cookies et traceurs",
    "privacy.section8.p1": "La gestion des cookies est décrite dans la politique dédiée. Vous pouvez ajuster vos préférences depuis le bandeau d’information.",
    "privacy.section9.title": "9. Transferts internationaux",
    "privacy.section9.p1": "Aucun transfert vers un pays hors EEE n’est réalisé. Les données sont hébergées sur des serveurs situés dans l’Union européenne.",
    "privacy.section10.title": "10. Mise à jour",
    "privacy.section10.p1": "Cette politique peut être modifiée pour refléter l’évolution de nos pratiques. Les versions antérieures peuvent être obtenues sur demande.",
    "privacy.section11.title": "11. Contact",
    "privacy.section11.p1": "Pour toute question relative au traitement des données, contactez-nous via le formulaire ou l’adresse mentionnée.",
    "cookies.page.title": "Politique relative aux cookies",
    "cookies.page.subtitle": "Comprendre l’usage des cookies et ajuster vos préférences à tout moment.",
    "cookies.intro.p1": "Des cookies strictement nécessaires assurent le fonctionnement du site. D’autres catégories améliorent la personnalisation et la mesure d’audience.",
    "cookies.intro.p2": "Vous pouvez accepter ou refuser les cookies facultatifs depuis le bandeau d’information ou la présente page.",
    "cookies.table.caption": "Tableau récapitulatif des cookies utilisés sur danswholesaleplants.com.",
    "cookies.table.col1": "Nom",
    "cookies.table.col2": "Fournisseur",
    "cookies.table.col3": "Type",
    "cookies.table.col4": "Finalité",
    "cookies.table.col5": "Durée",
    "cookies.table.row1.name": "site_language",
    "cookies.table.row1.provider": "danswholesaleplants.com",
    "cookies.table.row1.type": "Préférences",
    "cookies.table.row1.purpose": "Mémoriser la langue sélectionnée pour vos visites ultérieures.",
    "cookies.table.row1.duration": "12 mois",
    "cookies.table.row2.name": "cookie_consent",
    "cookies.table.row2.provider": "danswholesaleplants.com",
    "cookies.table.row2.type": "Nécessaire",
    "cookies.table.row2.purpose": "Conserver vos choix de consentement pour éviter les demandes répétées.",
    "cookies.table.row2.duration": "12 mois",
    "cookies.table.row3.name": "analytics_sample",
    "cookies.table.row3.provider": "danswholesaleplants.com",
    "cookies.table.row3.type": "Analyse",
    "cookies.table.row3.purpose": "Évaluer de manière agrégée la fréquentation et détecter les zones peu consultées.",
    "cookies.table.row3.duration": "6 mois",
    "cookies.manage.title": "Gestion des préférences",
    "cookies.manage.p1": "Vous pouvez mettre à jour vos choix de cookies via le bandeau ou en effaçant les cookies de votre navigateur.",
    "cookies.manage.p2": "Les cookies nécessaires restent actifs pour garantir la stabilité du site. Les autres catégories peuvent être désactivées à tout moment.",
    "refund.hero.title": "Politique de révision",
    "refund.hero.subtitle": "Cadre de révision des analyses et rapports produits par danswholesaleplants.",
    "refund.section1.title": "1. Objet",
    "refund.section1.p1": "Cette politique décrit la manière dont nous traitons les demandes d’ajustement des livrables analytiques et des synthèses méthodologiques.",
    "refund.section2.title": "2. Champ d’application",
    "refund.section2.p1": "Elle couvre les rapports, cartes commentées, matrices d’évaluation et recommandations produit(e)s dans le cadre de nos études.",
    "refund.section3.title": "3. Délais de demande",
    "refund.section3.p1": "Les demandes de révision sont recevables dans un délai de trente jours après transmission du livrable final.",
    "refund.section4.title": "4. Modalités de formulation",
    "refund.section4.p1": "Toute demande doit préciser les sections concernées et les éléments factuels à actualiser ou clarifier.",
    "refund.section5.title": "5. Analyse de la demande",
    "refund.section5.p1": "Nous vérifions la cohérence de la demande avec le périmètre initial et identifions les sources nécessaires pour documenter l’ajustement.",
    "refund.section6.title": "6. Révision mineure",
    "refund.section6.p1": "Les corrections rédactionnelles ou la mise à jour de chiffres déjà disponibles sont opérées dans un délai de dix jours ouvrés.",
    "refund.section7.title": "7. Révision majeure",
    "refund.section7.p1": "Si la demande nécessite de nouvelles observations ou des mesures complémentaires, un calendrier spécifique est défini avec les parties prenantes.",
    "refund.section8.title": "8. Limites",
    "refund.section8.p1": "Les demandes impliquant une modification du périmètre méthodologique initial nécessitent un cadrage additionnel distinct.",
    "refund.section9.title": "9. Traçabilité",
    "refund.section9.p1": "Chaque révision validée est documentée et annexée au livrable concerné afin d’assurer une lecture exhaustive des versions.",
    "refund.section10.title": "10. Contact",
    "refund.section10.p1": "Les demandes de révision se font via le formulaire de contact, en mentionnant clairement la référence du projet.",
    "disclaimer.hero.title": "Avis de non-responsabilité",
    "disclaimer.hero.subtitle": "Limites d’interprétation et portée informative des contenus publiés.",
    "disclaimer.section1.title": "1. Nature informative",
    "disclaimer.section1.p1": "Les analyses proposées ont pour objectif d’éclairer des problématiques d’orientation spatiale. Elles ne constituent pas un engagement opérationnel ou contractuel.",
    "disclaimer.section2.title": "2. Exactitude des informations",
    "disclaimer.section2.p1": "Nous mettons tout en œuvre pour assurer la précision des contenus, sans garantir leur exhaustivité ni l’absence de mise à jour nécessaire.",
    "disclaimer.section3.title": "3. Absence de garantie",
    "disclaimer.section3.p1": "Le site est fourni tel quel. Nous n’assurons aucune garantie quant à l’adéquation des informations à un projet particulier.",
    "disclaimer.section4.title": "4. Responsabilité",
    "disclaimer.section4.p1": "Nous ne saurions être tenus responsables de décisions prises sur la seule base des informations publiées, sans validation contextuelle.",
    "disclaimer.section5.title": "5. Liens externes",
    "disclaimer.section5.p1": "Les éventuels liens vers des ressources externes sont fournis pour enrichir la réflexion. Nous ne contrôlons pas leur contenu ni leur évolution.",
    "disclaimer.section6.title": "6. Mise à jour",
    "disclaimer.section6.p1": "Cet avis peut être modifié pour refléter l’évolution de nos activités éditoriales ou du cadre légal applicable.",
    "thankyou.hero.title": "Merci pour votre message",
    "thankyou.hero.subtitle": "Nous l’analysons avec attention et revenons vers vous rapidement avec des pistes méthodologiques.",
    "thankyou.back": "Revenir à l’accueil",
    "footer.tagline": "Cartographier la lisibilité des espaces publics, des infrastructures complexes et des environnements hybrides.",
    "footer.address": "Rue de la Loi 155, 1040 Bruxelles, Belgique",
    "footer.contactTitle": "Coordonnées",
    "footer.phone": "Téléphone : +32 2 320 45 78",
    "footer.email": "Courriel : info@danswholesaleplants.com",
    "footer.legalTitle": "Documents",
    "footer.terms": "Conditions d’utilisation",
    "footer.privacy": "Confidentialité",
    "footer.cookies": "Cookies",
    "footer.refund": "Politique de révision",
    "footer.disclaimer": "Avis de non-responsabilité",
    "footer.copy": "© {year} danswholesaleplants. Tous droits réservés.",
    "cookies.banner.title": "Gestion des cookies",
    "cookies.banner.description": "Nous utilisons des cookies pour assurer le bon fonctionnement du site et comprendre l’usage des contenus.",
    "cookies.banner.link": "Consulter la politique relative aux cookies",
    "cookies.banner.necessary": "Nécessaires",
    "cookies.banner.necessaryDesc": "Actifs par défaut pour garantir la sécurité et la stabilité du site.",
    "cookies.banner.preferences": "Préférences",
    "cookies.banner.preferencesDesc": "Retiennent vos choix de langue et de mise en page.",
    "cookies.banner.analytics": "Analyse",
    "cookies.banner.analyticsDesc": "Mesurent la fréquentation de manière agrégée pour améliorer les contenus.",
    "cookies.banner.marketing": "Marketing",
    "cookies.banner.marketingDesc": "Non utilisés actuellement, mais réservés pour de futurs partenariats éditoriaux.",
    "cookies.banner.accept": "Tout accepter",
    "cookies.banner.decline": "Tout refuser",
    "cookies.banner.save": "Enregistrer les préférences",
    "toast.language": "Langue mise à jour.",
    "toast.cookieSaved": "Préférences cookies enregistrées.",
    "toast.cookieDeclined": "Cookies facultatifs refusés.",
    "toast.cookieAccepted": "Cookies facultatifs acceptés.",
    "toast.formError": "Merci de compléter les champs requis.",
    "toast.formSuccess": "Message envoyé avec succès.",
    "toast.redirect": "Redirection en cours vers la confirmation.",
    "nav.blogPrefix": "Lire",
    "post1.heading": "Cartographier la perception spatiale dans des réseaux publics",
    "post1.lede": "Comprendre la perception spatiale exige d’étudier simultanément la configuration matérielle des lieux, les signaux affichés et les récits que chaque personne se construit pour traverser un environnement complexe.",
    "post1.section1.title": "Observer les cartes mentales en situation réelle",
    "post1.section1.p1": "Les cartes mentales sont souvent invoquées comme des résumés statiques. Pourtant, elles se transforment continuellement sous l’effet de micro-décisions prises en temps réel. Nos enquêtes dans les gares bruxelloises montrent que les usagers recomposent leur représentation à chaque bifurcation, en intégrant des indices tels que la lumière, le bruit ou la densité de foule. Pour documenter ces transformations, nous avons suivi des participants équipés de capteurs audio descriptifs et de carnets d’annotation. Chaque arrêt, chaque hésitation, chaque détour a été localisé et décrit, révélant un paysage mental mouvant.",
    "post1.section1.p2": "Ces observations ont été croisées avec une cartographie détaillée des éléments structurants : position des ascenseurs, rythme des annonces, variations de contrastes dans la signalétique. Le croisement des parcours et des caractéristiques du lieu a mis en évidence des zones de divergence, où l’information perçue diffère fortement de l’information réellement fournie. Dans ces zones, les usagers improvisent des repères alternatifs, comme la couleur d’un mur ou la présence d’une boutique identifiable. Ces repères substitutifs deviennent des ancres cognitives, que les dispositifs officiels gagneraient à intégrer dans leur logique d’affichage.",
    "post1.section1.sub1": "Cartographier l’incertitude",
    "post1.section1.sub1p1": "L’un des apports majeurs de cette recherche réside dans la cartographie des moments d’incertitude. En rematérialisant chaque hésitation, nous avons pu identifier des segments de parcours qui réclament un guidage particulier. Les cartes résultantes ne sont plus seulement géographiques ; elles illustrent aussi la probabilité d’hésiter, de rebrousser chemin ou de solliciter de l’aide. Cette dimension probabiliste ouvre la voie à des dispositifs adaptatifs, capables de se densifier dans les zones critiques et de rester sobres ailleurs.",
    "post1.section2.title": "Relier perception et design informationnel",
    "post1.section2.p1": "La perception spatiale est fortement influencée par la hiérarchie des messages. Lorsque différentes typographies, couleurs et pictogrammes se disputent l’attention, l’œil navigue sans plan clair. Nous avons analysé plusieurs halls d’accueil où cohabitaient affichages historiques et nouveaux écrans. Les personnes interrogées décrivaient spontanéement une sensation d’enchevêtrement, sans jamais pouvoir désigner l’information principale. Les mesures de temps de lecture confirmaient cette impression : il fallait parfois plus de trente secondes pour repérer une direction pourtant fondamentale.",
    "post1.section2.p2": "Pour contrer cette saturation, nous avons testé des maquettes où chaque couche d’information était rationnalisée selon trois niveaux : orientation structurante, indications contextuelles, compléments de services. Les tests utilisateurs menés avec une projection immersive ont montré une réduction de 40 % des hésitations, particulièrement chez les participants découvrant l’espace pour la première fois. Le design informationnel gagne ainsi en clarté quand il s’appuie sur une compréhension fine des attentes, plutôt que sur une accumulation de signes.",
    "post1.section2.sub1": "Synchroniser les supports physiques et numériques",
    "post1.section2.sub1p1": "Les cartes mentales se restructurent aussi en fonction de la cohérence entre les supports physiques et les applications mobiles. Dans plusieurs bâtiments administratifs, nous avons observé des incohérences majeures : un écran annonçait un étage, tandis qu’une application dirigeait vers un autre. Cette dissonance fragmente la confiance accordée au système de guidage. Nous avons donc développé une trame de synchronisation où chaque point de décision possède une signature unique, réutilisée sur tous les supports. Ce simple alignement a considérablement réduit les divergences entre perception et parcours effectif.",
    "post1.section3.title": "Enseignements pour les infrastructures belges",
    "post1.section3.p1": "En Belgique, la multiplicité des langues et des régimes de signalétique pose des défis supplémentaires. Les tests menés dans des hôpitaux et campus ont mis en évidence la nécessité de concevoir des messages indépendants de la langue dominante. L’usage d’icônes normalisées, de codes couleurs universels et de dispositifs sonores discret(s) renforce l’inclusivité. Les entretiens avec les personnels d’accueil ont également révélé l’importance de scénarios flexibles, capables d’intégrer des événements exceptionnels sans déstabiliser la trame principale.",
    "post1.section3.p2": "Ces études soulignent l’intérêt de combiner approche qualitative et mesure quantitative. Les données issues des capteurs de flux apportent une vision macro, tandis que les récits individuels éclairent les nuances fines. Ensemble, elles constituent un socle robuste pour des politiques de signalétique vraiment centrées sur les usages. Les infrastructures qui accepteront de conjuguer ces deux regards pourront offrir des parcours plus sereins, intelligibles et adaptables, à la hauteur des attentes multiples de leurs visiteurs.",
    "post1.section3.sub1": "Vers une culture de la lisibilité continue",
    "post1.section3.sub1p1": "Enfin, cartographier la perception spatiale n’est pas une opération ponctuelle. Les lieux vivent, se transforment, accueillent de nouveaux services. La cartographie doit donc être pensée comme un outil évolutif, alimenté par une veille régulière et par les retours d’expérience. En intégrant cette dimension, les gestionnaires peuvent déceler les signaux faibles, anticiper les zones de congestion et proposer des ajustements graduels. La perception spatiale devient ainsi un indicateur stratégique, au service d’un environnement bâti plus hospitalier.",
    "post2.heading": "Construire un écosystème de signalétique numérique cohérent",
    "post2.lede": "La signalétique numérique s’est invitée dans la majorité des lieux publics, mais son implantation reste souvent fragmentée. Pour éviter les doublons et les contradictions, il est nécessaire de penser l’écosystème de manière systémique.",
    "post2.section1.title": "Audit des supports existants",
    "post2.section1.p1": "Nous commençons chaque mission par un inventaire précis des supports en place : écrans, bornes interactives, projections, dispositifs audio. Les observations révèlent fréquemment des parcs hétérogènes, accumulés au fil des années sans gouvernance unifiée. Certains écrans ne sont plus connectés, d’autres diffusent des boucles obsolètes. Cette cartographie technique permet de qualifier l’état réel de l’écosystème et de détecter les points de friction qui nuisent à la confiance des usagers.",
    "post2.section1.p2": "Cet audit s’accompagne d’une analyse des messages, des langues affichées et des modalités d’interaction proposées. Nous avons observé que de nombreux écrans n’offrent qu’un contenu statique, sans tenir compte des flux instantanés ni des besoins contextuels. Les usagers y voient un simple panneau lumineux supplémentaire. L’écosystème numérique perd alors sa raison d’être, faute d’orchestration dynamique et d’intelligence de diffusion.",
    "post2.section1.sub1": "Hiérarchiser les priorités",
    "post2.section1.sub1p1": "À partir de ces constats, nous classons les supports selon trois axes : utilité perçue, niveau de maintenance et capacité à être synchronisés. Ce classement objectivé aide les gestionnaires à décider quels dispositifs conserver, remplacer ou mutualiser. Les ressources peuvent ainsi être concentrées sur les supports les plus stratégiques, ceux qui consolident réellement l’expérience de navigation.",
    "post2.section2.title": "Design des contenus et scénarios éditoriaux",
    "post2.section2.p1": "Un écosystème cohérent repose sur des gabarits éditoriaux harmonisés. Nous proposons des matrices qui définissent l’architecture des messages, les gammes chromatiques, les animations tolérées et les vitesses de défilement. Ces matrices sont testées avec des usagers de profils variés pour garantir lisibilité et inclusion.",
    "post2.section2.p2": "Les scénarios éditoriaux sont ensuite élaborés en considérant les pics d’affluence, les événements ponctuels et les besoins des équipes internes. Les écrans deviennent des canaux réactifs qui s’ajustent à la temporalité du lieu. Dans une gare, il peut s’agir de mettre en avant la correspondance la plus imminente. Dans un hôpital, de rappeler agrégement les temps d’attente estimés ou les points d’accueil disponibles.",
    "post2.section2.sub1": "Connecter les données",
    "post2.section2.sub1p1": "Pour éviter la divergence entre supports, nous encourageons l’utilisation d’un référentiel de données unique. Les informations de localisation, d’horaires ou de disponibilité sont centralisées puis distribuées aux écrans, aux applications et aux supports imprimés. Cette gouvernance partagée garantit la cohérence et simplifie la maintenance. Les usagers bénéficient d’un discours unifié, quel que soit le point de contact consulté.",
    "post2.section3.title": "Maintenance et gouvernance durable",
    "post2.section3.p1": "La cohérence ne peut tenir dans la durée sans une stratégie de maintenance claire. Nous recommandons la mise en place d’indicateurs d’état : taux de disponibilité, rapidité de mise à jour, délai de résolution des anomalies. Ces indicateurs alimentent des revues régulières entre les équipes techniques et éditoriales.",
    "post2.section3.p2": "Nous préconisons également des formations dédiées aux opérations quotidiennes. Les équipes de terrain doivent pouvoir ajuster rapidement un message, relancer un écran, signaler une incohérence. Cette autonomisation réduit la dépendance à des prestataires externes et renforce la réactivité face aux situations imprévues.",
    "post2.section3.sub1": "Documenter le cycle de vie",
    "post2.section3.sub1p1": "Chaque support bénéficie d’une fiche synthétique décrivant ses caractéristiques techniques, ses interlocuteurs, son historique d’incidents. Cette documentation facilite les arbitrages budgétaires et la planification des renouvellements. Elle contribue également à maintenir une mémoire collective, essentielle pour garder une vision globale de l’écosystème.",
    "post2.section4.title": "Vers un paysage numérique responsable",
    "post2.section4.p1": "En Belgique, la densité des lieux publics et la diversité des publics impliquent un soin particulier dans la conception des interfaces. Un écran mal configuré peut générer de la confusion, voire exclure certaines personnes. En structurant l’écosystème numérique, nous visons à offrir un paysage informationnel apaisé, où chaque message trouve sa place et son public.",
    "post2.section4.p2": "Un tel paysage s’inscrit dans une logique responsable : sobriété énergétique, durabilité des équipements, accessibilité linguistique. L’écosystème numérique devient alors un compagnon discret du parcours usager, plutôt qu’une source d’agitation visuelle.",
    "post3.heading": "Modéliser des parcours inclusifs et sensibles",
    "post3.lede": "Concevoir un parcours inclusif consiste à anticiper la diversité des perceptions. Il s’agit d’orchestrer des repères pour que toute personne puisse comprendre l’espace et s’y déplacer avec assurance.",
    "post3.section1.title": "Comprendre les profils utilisateurs",
    "post3.section1.p1": "Nous commençons par identifier les profils de déplacement présents dans un lieu : personnes avec déficience visuelle ou auditive, familles avec poussettes, visiteurs non francophones, professionnels pressés. Chaque profil est étudié à travers des entretiens et des marches exploratoires. Ces immersions révèlent des détails parfois invisibles, comme la difficulté à distinguer un changement de niveau ou l’absence de repères sonores dans un couloir.",
    "post3.section1.p2": "Les retours collectés servent à dresser des cartes d’empathie. Elles mettent en relation émotions, objectifs, obstacles et ressources disponibles. Cette cartographie sensible permet de définir des critères inclusifs concrets, qui guideront ensuite la conception de chaque point de contact.",
    "post3.section1.sub1": "Évaluer les seuils critiques",
    "post3.section1.sub1p1": "Certains seuils sont particulièrement délicats : transitions intérieur-extérieur, accès aux ascenseurs, interfaces de prise de ticket. Nous évaluons ces points en croisant mesures physiques et ressentis. Les scénarios de parcours se multiplient pour couvrir les usages réguliers et exceptionnels, garantissant que la solution finale sera robuste face aux situations réelles.",
    "post3.section2.title": "Conception multi-sensorielle",
    "post3.section2.p1": "La multi-sensorialité est une clé majeure de l’inclusion. Nous travaillons sur des combinaisons de contrastes visuels, de textures au sol, de repères sonores discrets et de textes rédigés en langage clair. Les tests réalisés montrent que la redondance positive — répéter l’information à travers plusieurs sens — renforce la confiance des usagers.",
    "post3.section2.p2": "Pour éviter la surcharge, nous veillons à la hiérarchisation : un message ne doit pas être dupliqué sans raison. L’objectif est de proposer des repères complémentaires qui se confirment mutuellement, et non des signaux redondants qui brouillent la perception.",
    "post3.section2.sub1": "Prototyper et tester",
    "post3.section2.sub1p1": "Les maquettes physiques et numériques sont testées en situation réelle. Nous installons des prototypes temporaires pour recueillir des retours directs. Les ajustements se font rapidement, grâce à une boucle courte entre observation et itération. Cette dynamique permet d’intégrer les propositions des personnes concernées, qui deviennent co-conceptrices du parcours final.",
    "post3.section3.title": "Rendre visibles les décisions",
    "post3.section3.p1": "La documentation est essentielle pour pérenniser la démarche inclusive. Nous produisons des fiches décrivant chaque décision, ses raisons, les tests réalisés et les retours associés. Cette traçabilité facilite l’appropriation par les équipes et assure la continuité malgré les changements de personnel.",
    "post3.section3.p2": "Ces documents deviennent également des supports de dialogue avec les partenaires institutionnels, montrant que l’inclusion n’est pas un ajout ponctuel mais un processus intégré à chaque étape. Ils favorisent la diffusion de bonnes pratiques et invitent d’autres sites à s’inscrire dans la même dynamique.",
    "post3.section3.sub1": "Évaluer dans la durée",
    "post3.section3.sub1p1": "Une fois déployé, le parcours inclusif doit être évalué régulièrement. Nous prévoyons des indicateurs qualitatifs et quantitatifs : satisfaction des usagers, nombre de demandes d’assistance, fluidité des circulations. Ces mesures nourrissent une démarche d’amélioration continue, garante d’un environnement toujours plus accueillant.",
    "post4.heading": "Comprendre les dynamiques de flux piéton urbain",
    "post4.lede": "Les flux piétons sont influencés par la morphologie urbaine, la programmation temporelle et les repères disponibles. Les analyser nécessite de croiser données quantitatives et récits d’usage.",
    "post4.section1.title": "Mesurer sans figer",
    "post4.section1.p1": "Nous installons des points d’observation temporaires, combinant relevés manuels et capteurs anonymisés. L’objectif n’est pas de surveiller, mais de comprendre les motifs de circulation. Les données recueillies permettent d’établir des courbes d’intensité, des cartes de densité et des chronogrammes détaillant la journée type.",
    "post4.section1.p2": "Ces mesures sont complétées par des entretiens éclair, réalisés sur le terrain. Ils apportent une lecture qualitative : pourquoi certains usagers évitent-ils un passage ? Qu’est-ce qui déclenche un détour ? Ces récits enrichissent l’interprétation des données brutes.",
    "post4.section1.sub1": "Identifier les régimes temporels",
    "post4.section1.sub1p1": "La ville ne se vit pas de manière uniforme. Nous distinguons plusieurs régimes temporels : heures de pointe, périodes calmes, événements ponctuels. Chaque régime modifie la dynamique des flux, parfois de manière inattendue. Les plans d’action doivent donc rester flexibles, capables d’intégrer ces variations sans perdre en lisibilité.",
    "post4.section2.title": "Tracer les lignes de désir",
    "post4.section2.p1": "Les lignes de désir matérialisent les trajectoires préférées, parfois en dehors des cheminements prévus. Elles révèlent la logique des usagers, souvent plus directe que celle conçue par le plan officiel. Nous les cartographions pour comprendre où les infrastructures peuvent évoluer, en ajustant la signalétique ou en réaménageant certains espaces.",
    "post4.section2.p2": "Ces lignes ne doivent pas être perçues comme des anomalies, mais comme des indicateurs précieux. Elles montrent comment les personnes négocient l’espace pour optimiser leur temps, éviter des obstacles ou rechercher un confort particulier.",
    "post4.section2.sub1": "Mettre en récit les observations",
    "post4.section2.sub1p1": "L’analyse des flux gagne en lisibilité lorsqu’elle est racontée. Nous réalisons des carnets de terrain mêlant cartes, schémas et textes narratifs. Ces supports facilitent le dialogue avec les décideurs et permettent de justifier les aménagements proposés.",
    "post4.section3.title": "Indicateurs pour la décision",
    "post4.section3.p1": "Nous proposons une série d’indicateurs adaptés aux environnements urbains belges : densité maximale acceptable, temps moyen de traversée, taux d’hésitation aux intersections, taux de satisfaction recueilli in situ. Ces métriques, contextualisées, aident à prioriser les interventions.",
    "post4.section3.p2": "L’important est d’éviter une approche purement quantitative. Les indicateurs doivent rester au service de la compréhension des usages, et non devenir des objectifs isolés. Leur interprétation s’effectue toujours en dialogue avec les retours qualitatifs.",
    "post4.section3.sub1": "Vers une mobilité piétonne apaisée",
    "post4.section3.sub1p1": "Les environnements urbains gagnent en attractivité lorsqu’ils valorisent la marche comme expérience. Une signalétique adéquate, des repères sensoriels et une organisation fluide des flux contribuent à cette qualité. Les analyses menées nourrissent ainsi des politiques qui placent l’humain au centre.",
    "post5.heading": "Vers des systèmes d’orientation hybride",
    "post5.lede": "Les usagers jonglent entre panneaux, écrans et applications. Construire un système hybride implique d’orchestrer ces supports pour qu’ils se complètent sans se contredire.",
    "post5.section1.title": "Cartographier les points de contact",
    "post5.section1.p1": "Le premier travail consiste à répertorier tous les points de contact : signalétique physique, écrans, interfaces mobiles, documents imprimés, agents d’accueil. Cette cartographie révèle la densité d’informations et les zones restées en marge. Elle montre également les moments où l’utilisateur passe d’un support à l’autre, parfois sans transition fluide.",
    "post5.section1.p2": "Nous analysons les scénarios d’usage associés à chaque point de contact. Les résultats mettent en évidence des besoins spécifiques : certains supports doivent fonctionner hors ligne, d’autres doivent offrir une assistance personnalisée. Cette diversité appelle une orchestration attentive.",
    "post5.section1.sub1": "Tracer les correspondances",
    "post5.section1.sub1p1": "Pour garantir la cohérence, nous établissons des correspondances entre les messages. Une direction indiquée sur un panneau doit être formulée de manière identique sur un écran ou dans une application. Cette table de correspondance devient un référentiel central, facilement accessible aux équipes responsables.",
    "post5.section2.title": "Synchroniser en temps réel",
    "post5.section2.p1": "Les systèmes hybrides reposent sur des mises à jour continues. Nous encourageons l’intégration d’API ouvertes et sécurisées qui alimentent simultanément les supports physiques modernisés et les interfaces numériques. Les usagers obtiennent ainsi des informations alignées, quel que soit le support consulté.",
    "post5.section2.p2": "Lorsque la synchronisation n’est pas possible, nous définissons des scénarios de rattrapage. Par exemple, un QR code renvoyant vers une page actualisée ou un message audio mentionnant les éventuelles divergences temporaires. L’objectif reste de préserver la confiance dans le système.",
    "post5.section2.sub1": "Design participatif",
    "post5.section2.sub1p1": "Les ateliers de co-conception réunissent usagers, équipes techniques et designers. En manipulant des maquettes, chacun exprime ses attentes et ses contraintes. Cette approche collaborative garantit un système hybride qui reflète la réalité des usages, sans se limiter à une vision technocentrée.",
    "post5.section3.title": "Pérenniser le système",
    "post5.section3.p1": "Un système hybride doit pouvoir évoluer. Nous recommandons la mise en place de comités de suivi, capables d’arbitrer les évolutions et d’assurer la stabilité de la gouvernance. Ces comités définissent des règles claires : qui peut modifier quoi, selon quels délais, avec quelle validation.",
    "post5.section3.p2": "Nous travaillons également sur des guides d’exploitation, illustrant les procédures de mise à jour, les supports concernés, les contrôles de cohérence. Cette documentation évite les dérives et maintient la qualité du système dans le temps.",
    "post5.section3.sub1": "Aligner vision et usage",
    "post5.section3.sub1p1": "Un système hybride bien conçu reflète la vision du lieu : accueil, clarté, fluidité. Il traduit ces valeurs dans chaque interaction, qu’elle soit analogique ou numérique. Les usagers ressentent alors une continuité rassurante, preuve que l’orientation spatiale a été pensée comme un service essentiel.",
    "thankyou.link.text": "Retourner à l’accueil"
  },
  en: {
    "title.home": "danswholesaleplants | Spatial orientation and digital wayfinding",
    "title.services": "Analytical services | danswholesaleplants",
    "title.about": "About | danswholesaleplants",
    "title.blog": "Wayfinding insights blog | danswholesaleplants",
    "title.contact": "Contact | danswholesaleplants",
    "title.faq": "FAQ | danswholesaleplants",
    "title.terms": "Terms of use | danswholesaleplants",
    "title.privacy": "Privacy notice | danswholesaleplants",
    "title.cookies": "Cookie policy | danswholesaleplants",
    "title.refund": "Revision policy | danswholesaleplants",
    "title.disclaimer": "Disclaimer | danswholesaleplants",
    "title.thankyou": "Thank you | danswholesaleplants",
    "title.post1": "Mapping spatial perception | danswholesaleplants",
    "title.post2": "Digital signage ecosystems | danswholesaleplants",
    "title.post3": "Designing inclusive journeys | danswholesaleplants",
    "title.post4": "Pedestrian flow analysis | danswholesaleplants",
    "title.post5": "Hybrid orientation systems | danswholesaleplants",
    "meta.home": "Bilingual insights on spatial orientation, digital signage and navigation within complex built environments across Belgium.",
    "meta.services": "Comprehensive overview of analytical and methodological strands for user journey design in complex spaces.",
    "meta.about": "Philosophy, approach and team of danswholesaleplants dedicated to the legibility of built environments.",
    "meta.blog": "In-depth articles on mapping spaces, pedestrian mobility and spatial user experience.",
    "meta.contact": "Get in touch with the danswholesaleplants team and explore the Brussels address.",
    "meta.faq": "Answers to frequent questions about indoor navigation and digital signage methodologies.",
    "meta.terms": "Terms of use governing the browsing of danswholesaleplants.",
    "meta.privacy": "Privacy policy describing data collection, usage and governance.",
    "meta.cookies": "Details about cookie usage, categories and preference management.",
    "meta.refund": "Framework for revising analytical outputs and methodological guarantees.",
    "meta.disclaimer": "Limits of liability and informative scope of the website.",
    "meta.thankyou": "Confirmation page after submitting a contact request.",
    "meta.post1": "Deep-dive into spatial perception and mental maps inside complex public infrastructures.",
    "meta.post2": "Systemic evaluation of digital signage ecosystems and multi-channel coherence.",
    "meta.post3": "Guide to designing inclusive journeys with accessibility and spatial readability in mind.",
    "meta.post4": "Methods to measure and analyse pedestrian flows in dynamic urban environments.",
    "meta.post5": "Hybrid approaches mixing physical supports and digital interfaces for coherent guidance.",
    "header.logo": "danswholesaleplants",
    "nav.menu": "Menu",
    "nav.toggle": "Toggle main navigation",
    "nav.home": "Home",
    "nav.services": "Services",
    "nav.about": "About",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "lang.toggleLabel": "Language selection",
    "lang.fr": "FR",
    "lang.en": "EN",
    "home.hero.title": "Spatial orientation and journey intelligence for built environments",
    "home.hero.subtitle": "We delve into how digital signage, interactive mapping and information design guide people through public infrastructures, urban territories and labyrinthine buildings.",
    "home.hero.button": "Browse our analyses",
    "home.hero.caption": "Rue de la Loi 155, 1040 Brussels — on-site observations and methodological frameworks.",
    "home.hero.imgAlt": "Illustration showing interactive maps and illuminated signage inside a public hall",
    "home.focus.title": "Key research pillars",
    "home.focus.subtitle": "A systemic approach to readability, accessibility and spatial UX in complex environments.",
    "home.focus.item1.title": "Behavioural mapping",
    "home.focus.item1.text": "Model micro-spatial decisions, capture attention points and translate mental maps into operational visualisations for trustworthy routing.",
    "home.focus.item2.title": "Layered digital signage",
    "home.focus.item2.text": "Align physical supports, interactive interfaces and mobile channels to provide a continuum of information at every decision node.",
    "home.focus.item3.title": "Multisensory accessibility",
    "home.focus.item3.text": "Combine visual contrast, tactile wayfinding, auditory cues and inclusive data so every person can interpret the space without ambiguity.",
    "home.metrics.title": "Quantitative markers",
    "home.metrics.subtitle": "Continuous field and desk research on pedestrian mobility in Belgium.",
    "home.metrics.item1.value": "68",
    "home.metrics.item1.label": "sites observed across Belgium",
    "home.metrics.item2.value": "34",
    "home.metrics.item2.label": "documented analytical protocols",
    "home.metrics.item3.value": "210",
    "home.metrics.item3.label": "user journeys reconstructed",
    "home.metrics.item4.value": "12",
    "home.metrics.item4.label": "institutional partnerships monitored",
    "home.recommendations.title": "Structural recommendations",
    "home.recommendations.subtitle": "Operational syntheses for project owners and design teams.",
    "home.recommendations.card1.title": "Modular mapping",
    "home.recommendations.card1.text": "Structure adaptive digital maps capable of revealing progressive layers of information based on context, crowding and user profile.",
    "home.recommendations.card2.title": "Beacon systems",
    "home.recommendations.card2.text": "Deploy interconnected visual and sonic beacons to maintain continuity between entrances, reception points, lifts and transition areas.",
    "home.recommendations.card3.title": "Usage observatories",
    "home.recommendations.card3.text": "Set up permanent pedestrian observatories combining counts, qualitative feedback and open mobility datasets.",
    "home.testimonials.title": "Testimonials",
    "home.testimonials.subtitle": "Perspectives from public facility managers involved in spatial transformations.",
    "home.testimonials.card1.quote": "The analytical grids revealed overlooked circulation bottlenecks and triggered a digital signage layer that evolves alongside our building.",
    "home.testimonials.card1.name": "Aline Vandevelde",
    "home.testimonials.card1.role": "Coordinator, metropolitan hospital cluster",
    "home.testimonials.card2.quote": "The careful reading of sensory journeys reshaped the reception scenography and guided the placement of light cues on our university campus.",
    "home.testimonials.card2.name": "Hugo Demey",
    "home.testimonials.card2.role": "Public space lead, Brussels university",
    "home.testimonials.card3.quote": "The interactive maps designed with the team helped travellers grasp multimodal connections the moment they entered, cutting hesitation at critical junctions.",
    "home.testimonials.card3.name": "Sarah Janssens",
    "home.testimonials.card3.role": "Intermodality director, Belgian rail network",
    "home.blog.title": "Recent readings",
    "home.blog.subtitle": "Long-form articles on spatial orientation, pedestrian circulation and navigation experience design.",
    "home.blog.card1.excerpt": "Analysis of mental maps and dynamic perception while crossing complex public buildings.",
    "home.blog.card2.excerpt": "Systemic structure of digital signage ecosystems combining furniture and interactive displays.",
    "home.blog.card3.excerpt": "Methodologies to weave accessibility into user journey modelling from the outset.",
    "home.blog.card4.excerpt": "Indicators and metrics to qualify pedestrian flow in interconnected urban environments.",
    "home.blog.card5.excerpt": "Fusion of physical supports and digital interfaces to craft coherent, adaptive cues.",
    "services.hero.title": "Observing, structuring and anticipating spatial navigation",
    "services.hero.subtitle": "Our work relies on field inquiries, flow modelling and prospective scenarios to enhance spatial legibility.",
    "services.overview.title": "Observed intervention fields",
    "services.overview.intro": "Each engagement is treated as a methodological exploration aimed at revealing navigation frictions, testing circulation hypotheses and documenting the most suitable solutions.",
    "services.item1.title": "Analysis of orientation challenges",
    "services.item1.p1": "We investigate obstacles disrupting the journey: confusing intersections, opaque vertical transitions, poorly prioritised information density. Field recordings, sensorial mapping and contrasting usage scenarios underpin the diagnosis.",
    "services.item1.p2": "The results locate critical zones, define comprehension indicators and outline gradual remediation pathways calibrated to each site’s complexity.",
    "services.item2.title": "Digital signage and mapping design",
    "services.item2.p1": "Digital devices are assessed for their ability to connect broad information to micro-level cues. We review screen formats, refresh rhythms and their interplay with existing physical media.",
    "services.item2.p2": "We recommend modular mapping, ready to evolve with occupancy scenarios and to dialogue with remote broadcast systems or proprietary mobile tools.",
    "services.item3.title": "User-centric journey development",
    "services.item3.p1": "Journeys are reconstructed from on-site observation, anonymised attendance data and qualitative interviews. Each trajectory is documented with sensory anchors, micro-decisions and explicit expectations.",
    "services.item3.p2": "This approach yields routes that minimise hesitation, highlight key amenities and accommodate constraints of time, lighting or crowding.",
    "services.item4.title": "Accessibility and spatial readability",
    "services.item4.p1": "Accessibility is tackled through multisensory means: visual contrast, tactile guidance, audio options, clear wording and understandable pictograms.",
    "services.item4.p2": "We ensure alignment between standards, user feedback and architectural ambitions so the space can be read instantly.",
    "services.item5.title": "Research on pedestrian mobility",
    "services.item5.p1": "Our research protocols lean on discrete observation, journey timing plus crowd density and speed measurements.",
    "services.item5.p2": "Findings feed evolving dashboards and recommendations able to anticipate seasonal, event-driven or structural variations.",
    "services.methods.title": "Transversal methodologies",
    "services.methods.p1": "Narrative maps, accessibility matrices, interactive mock-ups and collaborative workshops structure our investigations.",
    "services.methods.p2": "Every deliverable equips operational teams to continuously refine spatial cues.",
    "about.hero.title": "Nurturing a culture of spatial legibility",
    "about.hero.subtitle": "danswholesaleplants observes, compares and reports how people apprehend complex environments day after day.",
    "about.story.title": "Origins and trajectory",
    "about.story.p1": "Born from exploratory missions across major Belgian infrastructures, our practice combines mapping, architecture and user experience. We stand alongside operators, designers and public bodies to translate abstract issues into tangible journeys.",
    "about.story.p2": "Our team blends urban planners, information designers and data specialists. This plurality fuels analytical frameworks able to grasp social, technical and spatial contexts in parallel.",
    "about.values.title": "Core values",
    "about.values.item1.title": "Rigorous observation",
    "about.values.item1.text": "Every diagnosis builds on reproducible surveys, anonymised video traces, sensorial maps and workshops confronting diverse viewpoints.",
    "about.values.item2.title": "Transversality",
    "about.values.item2.text": "We connect digital interfaces, physical furniture, architecture and governance to guarantee end-to-end coherence.",
    "about.values.item3.title": "Inclusive mindset",
    "about.values.item3.text": "We embed the needs of specific audiences from the scoping phase, in dialogue with associations, mediators and user committees.",
    "about.timeline.title": "Timeline highlights",
    "about.timeline.step1.title": "2016 — First fieldwork",
    "about.timeline.step1.text": "Explored Brussels stations and hospitals, assembling an observational corpus on vertical circulation.",
    "about.timeline.step2.title": "2018 — Methodological frameworks",
    "about.timeline.step2.text": "Formalised evaluation tools for digital signage and released the first in-situ user testing protocols.",
    "about.timeline.step3.title": "2020 — Reinforced inclusion",
    "about.timeline.step3.text": "Partnered with visually impaired advocacy groups to co-design tactile models and audio interfaces.",
    "about.timeline.step4.title": "2022 — Urban watch",
    "about.timeline.step4.text": "Rolled out pedestrian observatories coupled with dashboards shared with public operators.",
    "about.team.title": "Collective expertise",
    "about.team.text": "Our contributors navigate urbanism, data science, graphic design and cultural mediation. They share a fascination for hybrid spaces where digital traces meet physical cues.",
    "blog.hero.title": "Wayfinding insights blog",
    "blog.hero.subtitle": "Long-form analyses, field feedback and forward-looking perspectives for smooth navigation across Belgian infrastructures.",
    "blog.card1.title": "Mapping spatial perception within public networks",
    "blog.card1.alt": "Detailed floor plan highlighting user journeys inside a public building",
    "blog.card1.link": "post1.html",
    "blog.card2.title": "Building a cohesive digital signage ecosystem",
    "blog.card2.alt": "Digital totem displaying directions in a bright lobby",
    "blog.card2.link": "post2.html",
    "blog.card3.title": "Modelling inclusive and sensitive journeys",
    "blog.card3.alt": "People relying on tactile cues along a hallway",
    "blog.card3.link": "post3.html",
    "blog.card4.title": "Understanding urban pedestrian flow dynamics",
    "blog.card4.alt": "Aerial view of interconnected pedestrian crossings in a city",
    "blog.card4.link": "post4.html",
    "blog.card5.title": "Towards hybrid orientation systems",
    "blog.card5.alt": "Physical signage and a mobile interface working in sync",
    "blog.card5.link": "post5.html",
    "faq.hero.title": "Frequently asked questions",
    "faq.hero.subtitle": "Clarifications about our observation methods, analytical frameworks and use of collected data.",
    "faq.q1": "How do you approach the study of a complex public site?",
    "faq.a1": "We combine preliminary immersion, sensorial mapping and quantitative measures. The goal is to align perception, actual usage and spatial structure to reveal major friction points.",
    "faq.q2": "Which tools do you use to model pedestrian flows?",
    "faq.a2": "Depending on context we rely on manual counts, temporary sensors, anonymised video and open datasets. These sources feed dashboards reflecting volumes, speed and waiting times.",
    "faq.q3": "How is accessibility integrated from the start?",
    "faq.a3": "We involve concerned audiences during scoping, analyse existing journeys with accessibility experts and evaluate each signage scenario through multi-sensory criteria.",
    "faq.q4": "What happens to the collected data?",
    "faq.a4": "Data are pseudonymised, stored securely and kept only for the time needed to complete the stated analyses. We enforce full transparency with stakeholders.",
    "faq.q5": "Do you work only in Belgium?",
    "faq.a5": "Our research is rooted in Belgium, yet we observe international references to benchmark innovative devices and fuel our recommendations.",
    "faq.q6": "How do you share your learnings?",
    "faq.a6": "We produce detailed reports, annotated maps, decision matrices and organise workshops to align actors around continuous improvement pathways.",
    "contact.hero.title": "Start a conversation with danswholesaleplants",
    "contact.hero.subtitle": "Share your questions, observations and explore navigation trajectories for your environments.",
    "contact.intro.title": "Co-design legible spaces",
    "contact.intro.text": "Describe your spatial challenges, audiences, constraints and objectives. We analyse each context to highlight comprehension and flow levers.",
    "contact.details.title": "Contact details and availability",
    "contact.phoneLabel": "Phone",
    "contact.phoneLink": "+32 2 320 45 78",
    "contact.emailLabel": "Email",
    "contact.emailLink": "info@danswholesaleplants.com",
    "contact.addressLabel": "Address",
    "contact.addressValue": "Rue de la Loi 155, 1040 Brussels, Belgium",
    "contact.mapTitle": "Map showing Rue de la Loi 155 in Brussels",
    "contact.mapCaption": "Location of the main observation hub in Brussels.",
    "contact.form.title": "Contact form",
    "contact.form.subtitle": "Fill the fields to outline your enquiry. We will respond with suitable methodological paths.",
    "contact.form.name": "Full name",
    "contact.form.email": "Email address",
    "contact.form.organization": "Organisation or structure",
    "contact.form.message": "Detailed message",
    "contact.form.namePlaceholder": "Enter your name",
    "contact.form.emailPlaceholder": "Enter your email address",
    "contact.form.organizationPlaceholder": "Specify your organisation",
    "contact.form.messagePlaceholder": "Describe your spatial context and questions",
    "contact.form.submit": "Send",
    "contact.form.success": "Your message has been delivered. Speak soon.",
    "contact.form.error": "Please review the required fields.",
    "contact.form.emailInvalid": "The email format should be valid.",
    "contact.toast.redirect": "Redirecting to the confirmation page...",
    "terms.hero.title": "Terms of use",
    "terms.hero.subtitle": "This document governs the browsing and use of content published on danswholesaleplants.com.",
    "terms.section1.title": "1. Purpose",
    "terms.section1.p1": "The site provides analyses on spatial orientation and digital signage. It carries no commercial intent and offers informational content only.",
    "terms.section2.title": "2. Acceptance",
    "terms.section2.p1": "Browsing the site implies full acceptance of these terms. Continued visits renew this agreement.",
    "terms.section3.title": "3. Intellectual property",
    "terms.section3.p1": "Texts, visuals and structures are protected by copyright. Any reproduction requires prior written consent.",
    "terms.section4.title": "4. Permitted use",
    "terms.section4.p1": "Content may be consulted and cited for study or monitoring purposes provided the source is clearly mentioned.",
    "terms.section5.title": "5. Publisher liability",
    "terms.section5.p1": "We strive for reliable information yet cannot guarantee total accuracy or permanent freshness.",
    "terms.section6.title": "6. User responsibility",
    "terms.section6.p1": "Users agree to visit the site in accordance with applicable laws and refrain from disrupting its technical operation.",
    "terms.section7.title": "7. External links",
    "terms.section7.p1": "Links may point to third-party sites. We do not control these resources and decline liability for their content.",
    "terms.section8.title": "8. Personal data",
    "terms.section8.p1": "Information submitted via the contact form is processed according to the privacy policy available on the site.",
    "terms.section9.title": "9. Cookies",
    "terms.section9.p1": "The site uses cookies described in the dedicated policy. Users can manage their preferences at any time.",
    "terms.section10.title": "10. Availability",
    "terms.section10.p1": "We aim for continuous access yet interruptions may occur for maintenance or external reasons.",
    "terms.section11.title": "11. Changes",
    "terms.section11.p1": "These terms may be updated. The revision date appears at the top of the document.",
    "terms.section12.title": "12. Governing law",
    "terms.section12.p1": "These terms are governed by Belgian law. Disputes fall under the courts of Brussels.",
    "terms.section13.title": "13. Contact",
    "terms.section13.p1": "Any question about these terms can be sent via the site’s contact form.",
    "terms.section14.title": "14. Effective date",
    "terms.section14.p1": "This version applies since 12 February 2024 and supersedes prior editions.",
    "privacy.hero.title": "Privacy policy",
    "privacy.hero.subtitle": "Transparency about the collection, use and retention of submitted data.",
    "privacy.section1.title": "1. Information collected",
    "privacy.section1.p1": "We collect data voluntarily provided through the contact form: name, email address, organisation and message.",
    "privacy.section2.title": "2. Legal basis",
    "privacy.section2.p1": "Data are processed to answer enquiries and sustain exchanges related to spatial orientation topics.",
    "privacy.section3.title": "3. Use",
    "privacy.section3.p1": "Information helps analyse the request, craft a contextual response and document incoming enquiries.",
    "privacy.section4.title": "4. Retention",
    "privacy.section4.p1": "Data are stored for up to twelve months after the last exchange unless a longer legal obligation applies.",
    "privacy.section5.title": "5. Sharing",
    "privacy.section5.p1": "Data are not shared with third parties unless legally required or expressly requested by the individual.",
    "privacy.section6.title": "6. Security",
    "privacy.section6.p1": "We implement technical and organisational measures to protect data against unauthorised access.",
    "privacy.section7.title": "7. Individual rights",
    "privacy.section7.p1": "You may exercise rights of access, rectification, erasure, restriction and objection via the contact form.",
    "privacy.section8.title": "8. Cookies and trackers",
    "privacy.section8.p1": "Cookie management is described in the dedicated policy. Preferences can be updated through the banner.",
    "privacy.section9.title": "9. International transfers",
    "privacy.section9.p1": "No transfers outside the EEA occur. Data are hosted on servers located within the European Union.",
    "privacy.section10.title": "10. Updates",
    "privacy.section10.p1": "This policy may change to reflect evolving practices. Previous versions are available upon request.",
    "privacy.section11.title": "11. Contact",
    "privacy.section11.p1": "For any question about data processing, contact us through the form or the address provided.",
    "cookies.page.title": "Cookie policy",
    "cookies.page.subtitle": "Understand how cookies are used and adjust your preferences at any time.",
    "cookies.intro.p1": "Strictly necessary cookies ensure the site operates properly. Other categories enhance personalisation and audience measurement.",
    "cookies.intro.p2": "You may accept or refuse optional cookies via the banner or this page.",
    "cookies.table.caption": "Summary table of cookies used on danswholesaleplants.com.",
    "cookies.table.col1": "Name",
    "cookies.table.col2": "Provider",
    "cookies.table.col3": "Type",
    "cookies.table.col4": "Purpose",
    "cookies.table.col5": "Duration",
    "cookies.table.row1.name": "site_language",
    "cookies.table.row1.provider": "danswholesaleplants.com",
    "cookies.table.row1.type": "Preferences",
    "cookies.table.row1.purpose": "Remember the chosen language for future visits.",
    "cookies.table.row1.duration": "12 months",
    "cookies.table.row2.name": "cookie_consent",
    "cookies.table.row2.provider": "danswholesaleplants.com",
    "cookies.table.row2.type": "Necessary",
    "cookies.table.row2.purpose": "Store your consent choices to avoid repeated prompts.",
    "cookies.table.row2.duration": "12 months",
    "cookies.table.row3.name": "analytics_sample",
    "cookies.table.row3.provider": "danswholesaleplants.com",
    "cookies.table.row3.type": "Analytics",
    "cookies.table.row3.purpose": "Assess aggregated traffic and detect underused pages.",
    "cookies.table.row3.duration": "6 months",
    "cookies.manage.title": "Preference management",
    "cookies.manage.p1": "You may update your cookie choices via the banner or by clearing cookies in your browser.",
    "cookies.manage.p2": "Necessary cookies remain active to guarantee site stability. Other categories can be disabled at any moment.",
    "refund.hero.title": "Revision policy",
    "refund.hero.subtitle": "Framework for revising analytical outputs produced by danswholesaleplants.",
    "refund.section1.title": "1. Purpose",
    "refund.section1.p1": "This policy explains how we address requests to adjust analytical deliverables and methodological summaries.",
    "refund.section2.title": "2. Scope",
    "refund.section2.p1": "It covers reports, annotated maps, evaluation matrices and recommendations delivered as part of our studies.",
    "refund.section3.title": "3. Request window",
    "refund.section3.p1": "Revision requests are accepted within thirty days after the final deliverable has been handed over.",
    "refund.section4.title": "4. Submission guidelines",
    "refund.section4.p1": "Requests must identify the affected sections and the factual elements that require updates or clarification.",
    "refund.section5.title": "5. Review process",
    "refund.section5.p1": "We assess alignment with the initial scope and determine the sources needed to document the adjustment.",
    "refund.section6.title": "6. Minor revision",
    "refund.section6.p1": "Editorial fixes or updates based on existing figures are implemented within ten business days.",
    "refund.section7.title": "7. Major revision",
    "refund.section7.p1": "If the request calls for fresh observations or additional measurements, a dedicated schedule is agreed with stakeholders.",
    "refund.section8.title": "8. Limits",
    "refund.section8.p1": "Requests that alter the original methodological scope require a separate scoping exercise.",
    "refund.section9.title": "9. Traceability",
    "refund.section9.p1": "Each approved revision is documented and attached to the corresponding deliverable for full transparency.",
    "refund.section10.title": "10. Contact",
    "refund.section10.p1": "Submit revision requests via the contact form, indicating the project reference.",
    "disclaimer.hero.title": "Disclaimer",
    "disclaimer.hero.subtitle": "Interpretation limits and informative scope of the published content.",
    "disclaimer.section1.title": "1. Informational nature",
    "disclaimer.section1.p1": "Analyses aim to shed light on spatial orientation issues. They do not constitute operational commitments or contractual guidance.",
    "disclaimer.section2.title": "2. Information accuracy",
    "disclaimer.section2.p1": "We make every effort to ensure accuracy yet cannot guarantee exhaustiveness or the absence of future updates.",
    "disclaimer.section3.title": "3. No warranty",
    "disclaimer.section3.p1": "The site is provided as-is. We offer no warranty regarding suitability for a specific project.",
    "disclaimer.section4.title": "4. Liability",
    "disclaimer.section4.p1": "We cannot be held responsible for decisions based solely on published information without contextual validation.",
    "disclaimer.section5.title": "5. External resources",
    "disclaimer.section5.p1": "Any links to external resources are provided for exploration. We do not control their content or changes.",
    "disclaimer.section6.title": "6. Updates",
    "disclaimer.section6.p1": "This notice may change to reflect our editorial activities or applicable legal framework.",
    "thankyou.hero.title": "Thank you for reaching out",
    "thankyou.hero.subtitle": "We are reviewing your message and will respond shortly with tailored methodological insights.",
    "thankyou.back": "Return to homepage",
    "footer.tagline": "Mapping the legibility of public spaces, complex infrastructures and hybrid environments.",
    "footer.address": "Rue de la Loi 155, 1040 Brussels, Belgium",
    "footer.contactTitle": "Contacts",
    "footer.phone": "Phone: +32 2 320 45 78",
    "footer.email": "Email: info@danswholesaleplants.com",
    "footer.legalTitle": "Documents",
    "footer.terms": "Terms of use",
    "footer.privacy": "Privacy",
    "footer.cookies": "Cookies",
    "footer.refund": "Revision policy",
    "footer.disclaimer": "Disclaimer",
    "footer.copy": "© {year} danswholesaleplants. All rights reserved.",
    "cookies.banner.title": "Cookie management",
    "cookies.banner.description": "We use cookies to keep the website stable and to understand how content is consulted.",
    "cookies.banner.link": "Read the cookie policy",
    "cookies.banner.necessary": "Necessary",
    "cookies.banner.necessaryDesc": "Always active to secure and stabilise the site.",
    "cookies.banner.preferences": "Preferences",
    "cookies.banner.preferencesDesc": "Store your language and layout choices.",
    "cookies.banner.analytics": "Analytics",
    "cookies.banner.analyticsDesc": "Measure aggregated visits to improve the content mix.",
    "cookies.banner.marketing": "Marketing",
    "cookies.banner.marketingDesc": "Not used at the moment but reserved for future editorial partnerships.",
    "cookies.banner.accept": "Accept all",
    "cookies.banner.decline": "Decline all",
    "cookies.banner.save": "Save preferences",
    "toast.language": "Language updated.",
    "toast.cookieSaved": "Cookie preferences saved.",
    "toast.cookieDeclined": "Optional cookies declined.",
    "toast.cookieAccepted": "Optional cookies accepted.",
    "toast.formError": "Please fill the required fields.",
    "toast.formSuccess": "Message sent successfully.",
    "toast.redirect": "Redirecting to confirmation.",
    "nav.blogPrefix": "Read",
    "post1.heading": "Mapping spatial perception within public networks",
    "post1.lede": "Understanding spatial perception means observing the material configuration of places, the signals displayed and the narratives crafted by anyone crossing a complex environment.",
    "post1.section1.title": "Observing mental maps in context",
    "post1.section1.p1": "Mental maps are often treated as fixed summaries. Yet they keep evolving under the influence of real-time micro-decisions. Our studies across Brussels stations show that people recombine their mental image at every fork, factoring cues such as light, noise or crowd density. To document these transformations, we followed participants equipped with descriptive audio recorders and annotation booklets. Each pause, hesitation or detour was geo-tagged and described, revealing a shifting cognitive landscape.",
    "post1.section1.p2": "We cross-referenced these observations with a detailed map of structural elements: elevator placement, announcement rhythms, contrast variations within signage. Overlays of journeys and spatial attributes exposed divergence zones where perceived information differed from what was actually provided. In these areas, people improvise fallback cues like wall colours or a recognisable shop front. Such surrogate anchors become cognitive reference points that official devices would benefit from embracing.",
    "post1.section1.sub1": "Mapping uncertainty",
    "post1.section1.sub1p1": "One of the key outcomes lies in mapping moments of uncertainty. By materialising each hesitation we pinpointed segments requiring specific guidance. The resulting maps are not purely geographic; they illustrate probabilities of hesitating, turning back or asking for help. This probabilistic dimension opens the door to adaptive devices able to densify information in critical spots while remaining subtle elsewhere.",
    "post1.section2.title": "Linking perception and information design",
    "post1.section2.p1": "Spatial perception is deeply influenced by message hierarchy. When mixed typographies, colours and pictograms compete for attention the eye wanders without a clear plan. We analysed several reception halls combining legacy signage and new displays. Interviewees repeatedly described a feeling of entanglement without identifying which message mattered. Timed reading sessions confirmed this: spotting a fundamental direction could take over thirty seconds.",
    "post1.section2.p2": "To counter saturation we prototyped layouts where each information layer was rationalised around three tiers: structural orientation, contextual indications, service complements. Immersive testing showed a forty percent drop in hesitation, especially for first-time visitors. Information design gains clarity when it builds on a nuanced understanding of expectations rather than cumulative layers of signs.",
    "post1.section2.sub1": "Synchronising physical and digital supports",
    "post1.section2.sub1p1": "Mental maps also reshape according to alignment between physical supports and mobile applications. In administrative buildings we noticed major inconsistencies: a display would announce a floor while an app redirected elsewhere. This dissonance erodes trust in the guidance system. We therefore created a synchronisation matrix where each decision point holds a unique signature reused across all media. This alignment drastically reduced divergences between perception and actual path.",
    "post1.section3.title": "Lessons for Belgian infrastructures",
    "post1.section3.p1": "In Belgium linguistic diversity and signage regimes add complexity. Tests in hospitals and campuses highlighted the need for messages that stand beyond the dominant language. Using standardised icons, universal colour codes and discreet audio cues strengthens inclusivity. Conversations with front-desk staff also revealed the importance of flexible scenarios capable of integrating exceptional events without destabilising the main layout.",
    "post1.section3.p2": "These studies emphasise the value of combining qualitative and quantitative approaches. Flow sensors offer a macro perspective while individual stories unveil nuances. Together they form a solid foundation for user-centred signage policies. Infrastructures willing to bridge both views can deliver calmer, intelligible and adaptive journeys aligned with diverse expectations.",
    "post1.section3.sub1": "Towards a culture of continuous legibility",
    "post1.section3.sub1p1": "Ultimately, mapping spatial perception is not a one-off operation. Places evolve, new services emerge. Mapping must therefore remain a living tool fed by ongoing monitoring and feedback loops. By embracing this dimension, facility managers can detect weak signals, anticipate congestion and implement gradual adjustments. Spatial perception thus becomes a strategic indicator serving friendlier built environments.",
    "post2.heading": "Building a cohesive digital signage ecosystem",
    "post2.lede": "Digital signage has entered most public venues, yet implementations remain fragmented. Preventing duplication and contradictions requires a systemic vision of the entire ecosystem.",
    "post2.section1.title": "Auditing existing supports",
    "post2.section1.p1": "We begin each mission with a thorough inventory of deployed media: screens, kiosks, projections, audio devices. Fieldwork frequently reveals heterogeneous equipment accumulated over years with no unified governance. Some screens are offline, others play outdated loops. This technical mapping qualifies the ecosystem and identifies friction points that undermine user trust.",
    "post2.section1.p2": "The audit extends to message analysis, displayed languages and interaction modes. Many screens we observed delivered static content, ignoring real-time flows and contextual needs. Visitors perceived them as just another glowing panel. Without dynamic orchestration and broadcast intelligence the ecosystem loses its purpose.",
    "post2.section1.sub1": "Prioritising actions",
    "post2.section1.sub1p1": "From these findings we categorise media using three axes: perceived usefulness, maintenance level and synchronisation potential. This evidence-based ranking helps stakeholders decide which devices to retain, replace or merge. Resources can then focus on strategic supports that truly consolidate the navigation experience.",
    "post2.section2.title": "Content design and editorial scenarios",
    "post2.section2.p1": "A cohesive ecosystem relies on harmonised editorial templates. We supply matrices defining message architecture, colour scales, animation thresholds and scrolling speed. These matrices are stress-tested with diverse user profiles to secure readability and inclusion.",
    "post2.section2.p2": "Editorial scenarios follow, taking crowd peaks, special events and internal teams’ needs into account. Screens become responsive channels adjusting to each moment. In a station this could mean highlighting the upcoming connection. In a hospital it might discreetly share estimated waiting times or available reception desks.",
    "post2.section2.sub1": "Connecting data",
    "post2.section2.sub1p1": "To avoid discrepancies we promote a single data repository. Location, schedules or availability information is centralised then pushed to displays, apps and printed media. Shared governance guarantees coherence and simplifies maintenance. Users benefit from a unified narrative regardless of the touchpoint they access.",
    "post2.section3.title": "Maintenance and sustainable governance",
    "post2.section3.p1": "Cohesion cannot last without a clear maintenance strategy. We recommend tracking indicators such as uptime, update turnaround and incident resolution time. These metrics fuel regular reviews between technical and editorial teams.",
    "post2.section3.p2": "We also advocate dedicated training for daily operations. Frontline teams should adjust messages quickly, reboot displays or flag inconsistencies. Empowerment reduces dependency on external providers and boosts responsiveness to unexpected situations.",
    "post2.section3.sub1": "Documenting the lifecycle",
    "post2.section3.sub1p1": "Each device receives a brief with technical specs, contact points and incident history. Documentation facilitates budget planning and renewal scheduling. It also preserves institutional memory, essential to maintain a holistic view of the ecosystem.",
    "post2.section4.title": "Towards a responsible digital landscape",
    "post2.section4.p1": "Belgium’s dense public venues and diverse audiences call for careful interface design. A misconfigured screen can trigger confusion or exclude people. By structuring the digital landscape we aim to deliver a calm environment where every message finds its purpose and audience.",
    "post2.section4.p2": "Such a landscape follows a responsible logic: energy sobriety, durable equipment, linguistic accessibility. The digital ecosystem then becomes a discreet companion to the user journey rather than a source of visual agitation.",
    "post3.heading": "Modelling inclusive and sensitive journeys",
    "post3.lede": "Designing an inclusive journey means anticipating diverse perceptions. It requires orchestrating cues so everyone can understand the space and move with confidence.",
    "post3.section1.title": "Understanding user profiles",
    "post3.section1.p1": "We start by mapping the profiles moving through a venue: people with visual or auditory impairment, families with strollers, non-francophone visitors, time-pressed professionals. Interviews and exploratory walks with each group reveal subtle details such as difficulty spotting level changes or missing audio cues in long corridors.",
    "post3.section1.p2": "Collected insights feed empathy maps linking emotions, objectives, obstacles and available resources. This sensitive mapping sets tangible inclusive criteria guiding the design of every touchpoint.",
    "post3.section1.sub1": "Assessing critical thresholds",
    "post3.section1.sub1p1": "Certain thresholds prove delicate: indoor-outdoor transitions, elevator access, ticket dispensers. We evaluate them by combining physical measurements and user feedback. Journey scenarios multiply to cover routine and exceptional uses, ensuring the final solution remains robust under real conditions.",
    "post3.section2.title": "Multisensory design",
    "post3.section2.p1": "Multisensory design is a cornerstone of inclusion. We work on combinations of visual contrast, floor textures, subtle sound cues and plain language text. Tests demonstrate that positive redundancy—sharing information across senses—strengthens user trust.",
    "post3.section2.p2": "To avoid overload we ensure hierarchy: a message should not be duplicated without intent. Our goal is to offer complementary cues that reinforce each other rather than redundant signals that blur perception.",
    "post3.section2.sub1": "Prototyping and testing",
    "post3.section2.sub1p1": "Physical and digital mock-ups are trialled on-site. Temporary prototypes collect immediate feedback. Adjustments happen swiftly thanks to short loops between observation and iteration. This dynamic embeds suggestions from concerned audiences, effectively making them co-designers of the final journey.",
    "post3.section3.title": "Making decisions visible",
    "post3.section3.p1": "Documentation is vital to sustain inclusion. We produce sheets detailing every decision, underlying reasons, tests conducted and feedback received. This traceability supports team adoption and continuity despite staff changes.",
    "post3.section3.p2": "These documents also foster dialogue with institutional partners, showing inclusion is a process woven into each stage, not an optional add-on. They spread best practices and inspire other sites to follow the same path.",
    "post3.section3.sub1": "Evaluating over time",
    "post3.section3.sub1p1": "Once deployed the inclusive journey must be evaluated regularly. We track qualitative and quantitative indicators: user satisfaction, assistance requests, flow smoothness. Measurements fuel continuous improvement, ensuring an ever more welcoming environment.",
    "post4.heading": "Understanding urban pedestrian flow dynamics",
    "post4.lede": "Pedestrian flows are shaped by urban morphology, temporal programming and available cues. Analysing them means weaving quantitative data with usage narratives.",
    "post4.section1.title": "Measuring without freezing",
    "post4.section1.p1": "We set up temporary observation points combining manual surveys and anonymised sensors. The aim is not surveillance but pattern comprehension. Collected data generates intensity curves, density maps and daily chronograms.",
    "post4.section1.p2": "Measurements are complemented by short on-site interviews. They provide qualitative insight: why do people avoid a shortcut? What sparks a detour? These narratives enrich the reading of raw data.",
    "post4.section1.sub1": "Identifying temporal regimes",
    "post4.section1.sub1p1": "Cities operate in distinct temporal regimes: rush hours, calm periods, one-off events. Each regime reshapes flow dynamics, sometimes unexpectedly. Action plans must therefore remain flexible, ready to integrate variations without losing clarity.",
    "post4.section2.title": "Tracing desire lines",
    "post4.section2.p1": "Desire lines materialise preferred trajectories, sometimes beyond planned paths. They reveal users’ logic, often more direct than official layouts. We map them to understand where infrastructure can evolve—through signage tweaks or spatial adjustments.",
    "post4.section2.p2": "These lines should not be dismissed as anomalies but embraced as valuable indicators. They show how people negotiate space to optimise time, avoid obstacles or seek comfort.",
    "post4.section2.sub1": "Narrating observations",
    "post4.section2.sub1p1": "Flow analysis gains clarity when narrated. We craft field notebooks combining maps, diagrams and narrative texts. Such artefacts ease discussions with decision-makers and justify proposed interventions.",
    "post4.section3.title": "Decision-oriented indicators",
    "post4.section3.p1": "We propose indicators tailored to Belgian urban settings: acceptable density peaks, average crossing time, hesitation rate at intersections, on-site satisfaction levels. Contextual metrics help prioritise interventions.",
    "post4.section3.p2": "Crucially, indicators should not drive decisions alone. They serve understanding of real uses and are always interpreted alongside qualitative feedback.",
    "post4.section3.sub1": "Towards calmer pedestrian mobility",
    "post4.section3.sub1p1": "Urban environments become more attractive when walking is treated as an experience. Appropriate signage, sensory cues and smooth flows contribute to this quality. Analysis therefore supports policies that keep humans at the centre.",
    "post5.heading": "Towards hybrid orientation systems",
    "post5.lede": "People juggle between signs, displays and apps. Crafting a hybrid system requires orchestrating these media so they complement each other without conflict.",
    "post5.section1.title": "Mapping touchpoints",
    "post5.section1.p1": "We first catalogue all touchpoints: physical signage, displays, mobile interfaces, printed materials, reception staff. Mapping reveals information density and overlooked areas. It also highlights the moments when users switch from one medium to another, sometimes without a seamless handover.",
    "post5.section1.p2": "We analyse scenarios tied to each touchpoint. Findings show specific needs: some supports must operate offline while others should offer personalised assistance. Such diversity calls for careful orchestration.",
    "post5.section1.sub1": "Building correspondences",
    "post5.section1.sub1p1": "To secure consistency we establish correspondences between messages. A direction on a panel must be phrased identically on a display or within an app. This correspondence table becomes a central reference, easily accessed by responsible teams.",
    "post5.section2.title": "Synchronising in real time",
    "post5.section2.p1": "Hybrid systems rest on continuous updates. We advocate secure, open APIs feeding modernised physical supports and digital interfaces simultaneously. Users then access aligned information regardless of the medium.",
    "post5.section2.p2": "When synchronisation is impossible we design fallback scenarios. For instance a QR code linking to an updated page or an audio message announcing temporary differences. The priority remains to preserve trust in the system.",
    "post5.section2.sub1": "Participatory design",
    "post5.section2.sub1p1": "Co-design workshops gather users, technical teams and designers. Through mock-ups everyone shares expectations and constraints. Collaboration ensures the hybrid system mirrors real practices instead of a purely technology-driven vision.",
    "post5.section3.title": "Sustaining the system",
    "post5.section3.p1": "A hybrid system must evolve. We recommend steering committees able to arbitrate evolutions and safeguard governance. Clear rules outline who can change what, within which timeframe and under which validation process.",
    "post5.section3.p2": "We also prepare operational guides describing update procedures, impacted supports and consistency checks. Documentation prevents drift and preserves quality over time.",
    "post5.section3.sub1": "Aligning vision and usage",
    "post5.section3.sub1p1": "A well-crafted hybrid system reflects the venue’s vision: welcome, clarity, fluidity. It translates those values into every interaction, analogue or digital. Users experience a reassuring continuum—proof that spatial orientation has been considered a core service.",
    "thankyou.link.text": "Back to homepage"
  }
};

let currentLang = DEFAULT_LANG;

function getSavedLanguage() {
  const stored = localStorage.getItem(LANG_STORAGE_KEY);
  if (stored && SUPPORTED_LANGS.includes(stored)) {
    return stored;
  }
  return DEFAULT_LANG;
}

function setLanguage(lang) {
  if (!SUPPORTED_LANGS.includes(lang)) {
    lang = DEFAULT_LANG;
  }
  currentLang = lang;
  localStorage.setItem(LANG_STORAGE_KEY, lang);
  document.documentElement.setAttribute("lang", lang);
  applyTranslations(lang);
  updateLanguageButtons(lang);
  showToast(getTranslation(lang, "toast.language"), "success");
}

function getTranslation(lang, key) {
  const dict = I18N[lang] || {};
  return dict[key] !== undefined ? dict[key] : key;
}

function applyTranslations(lang) {
  const dict = I18N[lang] || {};
  const year = new Date().getFullYear();

  const titleEl = document.querySelector("title[data-i18n-title]");
  if (titleEl) {
    const key = titleEl.dataset.i18nTitle;
    const value = dict[key] || key;
    document.title = value.replace("{year}", year);
  }

  document.querySelectorAll("[data-i18n-meta]").forEach((meta) => {
    const key = meta.dataset.i18nMeta;
    if (dict[key]) {
      meta.setAttribute("content", dict[key].replace("{year}", year));
    }
  });

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    if (dict[key] !== undefined) {
      el.textContent = dict[key].replace("{year}", year);
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    if (dict[key] !== undefined) {
      el.setAttribute("placeholder", dict[key]);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.dataset.i18nAlt;
    if (dict[key] !== undefined) {
      el.setAttribute("alt", dict[key]);
    }
  });

  document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
    const key = el.dataset.i18nAria;
    if (dict[key] !== undefined) {
      el.setAttribute("aria-label", dict[key]);
    }
  });

  document.querySelectorAll("[data-i18n-title-attr]").forEach((el) => {
    const key = el.dataset.i18nTitleAttr;
    if (dict[key] !== undefined) {
      el.setAttribute("title", dict[key]);
    }
  });
}

function updateLanguageButtons(lang) {
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    const target = btn.dataset.language;
    const isActive = target === lang;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function initLanguage() {
  const initialLang = getSavedLanguage();
  currentLang = initialLang;
  document.documentElement.setAttribute("lang", initialLang);
  applyTranslations(initialLang);
  updateLanguageButtons(initialLang);
}

function initLanguageToggle() {
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.language;
      if (lang !== currentLang) {
        setLanguage(lang);
      }
    });
  });
}

function initNavigation() {
  const nav = document.querySelector(".primary-nav");
  const toggle = document.querySelector(".nav-toggle");
  if (!nav || !toggle) return;

  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    if (isOpen) {
      nav.querySelectorAll("a")[0]?.focus();
    }
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      if (nav.classList.contains("is-open")) {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth >= 768 && nav.classList.contains("is-open")) {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    }
  });
}

function initScrollAnimations() {
  const elements = document.querySelectorAll(".animate-on-scroll");
  if (!("IntersectionObserver" in window) || elements.length === 0) {
    elements.forEach((el) => el.classList.add("is-visible"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.25 }
  );

  elements.forEach((el) => observer.observe(el));
}

function showToast(message, type = "info") {
  if (!message) return;
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.setAttribute("role", "status");
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("hide");
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 3800);
}

function getCookieConsent() {
  const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch (error) {
    return null;
  }
}

function saveCookieConsent(consent) {
  localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify(consent));
}

function syncCookieUI(consent) {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;
  banner.querySelectorAll("input[data-cookie-type]").forEach((input) => {
    const type = input.dataset.cookieType;
    if (type === "necessary") {
      input.checked = true;
    } else {
      input.checked = consent?.[type] ?? false;
    }
  });
}

function hideCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (banner) {
    banner.classList.remove("visible");
  }
}

function showCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (banner) {
    banner.classList.add("visible");
  }
}

function handleCookieButtons() {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;

  const acceptBtn = banner.querySelector("[data-action='accept']");
  const declineBtn = banner.querySelector("[data-action='decline']");
  const saveBtn = banner.querySelector("[data-action='save']");

  acceptBtn?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      decidedAt: new Date().toISOString(),
    };
    saveCookieConsent(consent);
    syncCookieUI(consent);
    hideCookieBanner();
    showToast(getTranslation(currentLang, "toast.cookieAccepted"), "success");
  });

  declineBtn?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      decidedAt: new Date().toISOString(),
    };
    saveCookieConsent(consent);
    syncCookieUI(consent);
    hideCookieBanner();
    showToast(getTranslation(currentLang, "toast.cookieDeclined"), "error");
  });

  saveBtn?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      decidedAt: new Date().toISOString(),
    };
    banner.querySelectorAll("input[data-cookie-type]").forEach((input) => {
      const type = input.dataset.cookieType;
      if (type !== "necessary") {
        consent[type] = input.checked;
      }
    });
    saveCookieConsent(consent);
    hideCookieBanner();
    showToast(getTranslation(currentLang, "toast.cookieSaved"), "success");
  });
}

function initCookieBanner() {
  const consent = getCookieConsent();
  if (consent) {
    syncCookieUI(consent);
  } else {
    showCookieBanner();
  }
  handleCookieButtons();
}

function validateEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function initForms() {
  const forms = document.querySelectorAll("form[data-form-type='contact']");
  if (forms.length === 0) return;
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const lang = currentLang;
      const name = form.querySelector("[name='name']");
      const email = form.querySelector("[name='email']");
      const message = form.querySelector("[name='message']");

      if (!name.value.trim() || !email.value.trim() || !message.value.trim()) {
        showToast(getTranslation(lang, "contact.form.error"), "error");
        return;
      }
      if (!validateEmail(email.value.trim())) {
        showToast(getTranslation(lang, "contact.form.emailInvalid"), "error");
        return;
      }

      showToast(getTranslation(lang, "toast.formSuccess"), "success");
      setTimeout(() => {
        showToast(getTranslation(lang, "contact.toast.redirect"), "info");
      }, 500);
      setTimeout(() => {
        window.location.href = form.getAttribute("action") || "thank-you.html";
      }, 1500);
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initLanguageToggle();
  initNavigation();
  initScrollAnimations();
  initCookieBanner();
  initForms();
});