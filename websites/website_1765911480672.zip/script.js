const STORAGE_KEYS = {
  leaderboard: "ikvy-leaderboard-records",
  cookieConsent: "ikvy-cookie-consent"
};

const GAME_CONFIG = {
  roundDuration: 90,
  correctScore: 25,
  relevantScore: 10,
  streakBonus: 15,
  speedBonusThreshold: 5,
  difficultyMultiplier: {
    standard: 1,
    complex: 1.3
  }
};

document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const currentPage = body.dataset.page || "";

  initNav();
  updateCurrentYear();
  initCookieBanner();

  if (currentPage === "game") {
    ensureLeaderboardSeed();
    initGamePage();
  } else if (currentPage === "leaderboard") {
    ensureLeaderboardSeed();
    renderLeaderboardTable(document.querySelector("[data-role='leaderboard-body']"));
  } else {
    ensureLeaderboardSeed();
  }

  if (currentPage === "game" || currentPage === "leaderboard") {
    renderLeaderboardPreview();
  }

  if (currentPage === "contact") {
    initContactForm();
  }
});

function initNav() {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelectorAll(".nav-link[data-page-target]");
  const currentPage = body.dataset.page || "";

  if (navToggle) {
    navToggle.addEventListener("click", () => {
      const isOpen = body.getAttribute("data-nav-open") === "true";
      body.setAttribute("data-nav-open", isOpen ? "false" : "true");
      navToggle.setAttribute("aria-expanded", (!isOpen).toString());
    });
  }

  navLinks.forEach((link) => {
    if (link.dataset.pageTarget === currentPage) {
      link.classList.add("is-active");
    }
    link.addEventListener("click", () => {
      body.setAttribute("data-nav-open", "false");
      if (navToggle) {
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth >= 900) {
      body.setAttribute("data-nav-open", "false");
      if (navToggle) {
        navToggle.setAttribute("aria-expanded", "false");
      }
    }
  });
}

function updateCurrentYear() {
  const yearNodes = document.querySelectorAll("[data-role='current-year']");
  const now = new Date();
  yearNodes.forEach((node) => {
    node.textContent = now.getFullYear();
  });
}

function initCookieBanner() {
  const banner = document.querySelector("[data-role='cookie-banner']");
  if (!banner) {
    return;
  }
  const stored = readStorage(STORAGE_KEYS.cookieConsent, null);
  if (stored) {
    hideCookieBanner(banner, true);
    return;
  }

  const acceptBtn = banner.querySelector("[data-action='accept-cookies']");
  const declineBtn = banner.querySelector("[data-action='decline-cookies']");

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      writeStorage(STORAGE_KEYS.cookieConsent, { status: "accepted", timestamp: Date.now() });
      hideCookieBanner(banner);
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      writeStorage(STORAGE_KEYS.cookieConsent, { status: "declined", timestamp: Date.now() });
      hideCookieBanner(banner);
    });
  }
}

function hideCookieBanner(banner, instant = false) {
  if (instant) {
    banner.classList.add("is-hidden");
    return;
  }
  banner.classList.add("is-hidden");
  setTimeout(() => {
    if (banner.parentElement) {
      banner.parentElement.removeChild(banner);
    }
  }, 400);
}

function ensureLeaderboardSeed() {
  const stored = readStorage(STORAGE_KEYS.leaderboard, null);
  if (stored && Array.isArray(stored) && stored.length > 0) {
    return;
  }
  const sampleRecords = [
    { name: "Наталья М.", score: 215, accuracy: 92, date: "2024-05-21T10:00:00Z" },
    { name: "Алексей S.", score: 198, accuracy: 88, date: "2024-06-03T15:30:00Z" },
    { name: "digital_kid", score: 182, accuracy: 84, date: "2024-07-12T18:45:00Z" },
    { name: "Мария L.", score: 176, accuracy: 80, date: "2024-08-04T09:20:00Z" },
    { name: "rank_master", score: 172, accuracy: 78, date: "2024-09-15T12:10:00Z" }
  ];
  writeStorage(STORAGE_KEYS.leaderboard, sampleRecords);
}

function renderLeaderboardPreview() {
  const previewBody = document.querySelector("[data-role='leaderboard-preview']");
  if (!previewBody) {
    return;
  }
  renderLeaderboardTable(previewBody, 5);
}

function renderLeaderboardTable(tbody, limit = null) {
  if (!tbody) {
    return;
  }
  const records = getSortedLeaderboardRecords();
  tbody.innerHTML = "";
  if (records.length === 0) {
    tbody.innerHTML = "<tr><td colspan='5'>Пока нет результатов — сыграйте первым!</td></tr>";
    return;
  }
  const rows = limit ? records.slice(0, limit) : records;
  rows.forEach((record, index) => {
    const tr = document.createElement("tr");
    const place = index + 1;
    tr.innerHTML = `
      <td>${place}</td>
      <td>${escapeHTML(record.name)}</td>
      <td>${record.score}</td>
      <td>${record.accuracy}%</td>
      <td>${formatDate(record.date)}</td>
    `;
    tbody.appendChild(tr);
  });
}

function getSortedLeaderboardRecords() {
  const records = readStorage(STORAGE_KEYS.leaderboard, []);
  if (!Array.isArray(records)) {
    return [];
  }
  return records
    .slice()
    .sort((a, b) => {
      if (b.score === a.score) {
        return (b.accuracy || 0) - (a.accuracy || 0);
      }
      return (b.score || 0) - (a.score || 0);
    });
}

function initGamePage() {
  const state = {
    isRunning: false,
    canSave: false,
    timerId: null,
    timeLeft: GAME_CONFIG.roundDuration,
    score: 0,
    rounds: 0,
    correct: 0,
    streak: 0,
    activeTask: null,
    lastSelectionTime: null
  };

  const elements = {
    startBtn: document.querySelector("[data-action='start-game']"),
    skipBtn: document.querySelector("[data-action='skip-task']"),
    optionsContainer: document.querySelector("[data-role='options']"),
    currentQuery: document.querySelector("[data-role='current-query']"),
    hint: document.querySelector("[data-role='hint']"),
    feedback: document.querySelector("[data-role='feedback']"),
    resultsList: document.querySelector("[data-role='results']"),
    scoreValue: document.querySelector("[data-role='score-value']"),
    accuracyValue: document.querySelector("[data-role='accuracy-value']"),
    timeLeft: document.querySelector("[data-role='time-left']"),
    correctCounter: document.querySelector("[data-role='correct-counter']"),
    roundCounter: document.querySelector("[data-role='round-counter']"),
    streakCounter: document.querySelector("[data-role='streak-counter']"),
    scoreForm: document.querySelector("[data-role='score-form']"),
    saveStatus: document.querySelector("[data-role='save-status']")
  };

  if (!elements.startBtn || !elements.optionsContainer) {
    return;
  }

  elements.startBtn.addEventListener("click", () => {
    if (state.isRunning) {
      return;
    }
    startRound(state, elements);
  });

  elements.skipBtn.addEventListener("click", () => {
    if (!state.isRunning) {
      elements.feedback.textContent = "Запустите раунд, чтобы пропускать запросы.";
      return;
    }
    setFeedback(elements.feedback, "Запрос пропущен. Вперёд к следующему!", "warning");
    nextTask(state, elements);
  });

  if (elements.scoreForm) {
    elements.scoreForm.addEventListener("submit", (event) => {
      event.preventDefault();
      saveGameResult(state, elements);
    });
  }
}

function startRound(state, elements) {
  resetState(state, elements);
  state.isRunning = true;
  state.lastSelectionTime = Date.now();
  elements.feedback.textContent = "Раунд начался! Сделайте прогноз по текущему запросу.";
  elements.startBtn.classList.add("btn-secondary");
  elements.startBtn.classList.remove("btn-primary");
  elements.startBtn.textContent = "Раунд активен";
  elements.startBtn.disabled = true;
  startTimer(state, elements);
  nextTask(state, elements);
}

function resetState(state, elements) {
  state.timeLeft = GAME_CONFIG.roundDuration;
  state.score = 0;
  state.rounds = 0;
  state.correct = 0;
  state.streak = 0;
  state.canSave = false;
  elements.scoreValue.textContent = "0";
  elements.accuracyValue.textContent = "0%";
  elements.correctCounter.textContent = "0";
  elements.roundCounter.textContent = "0";
  elements.streakCounter.textContent = "0";
  elements.resultsList.innerHTML = "<li class='result-item'>Результаты появятся после вашего выбора.</li>";
  elements.saveStatus.textContent = "Сохраните результат после завершения раунда.";
  elements.saveStatus.classList.remove("success", "error");
}

function startTimer(state, elements) {
  updateTimeLeft(state, elements);
  state.timerId = setInterval(() => {
    state.timeLeft -= 1;
    updateTimeLeft(state, elements);
    if (state.timeLeft <= 0) {
      endRound(state, elements, "Время вышло! Сохраните результат и попробуйте ещё раз.");
    }
  }, 1000);
}

function updateTimeLeft(state, elements) {
  if (elements.timeLeft) {
    elements.timeLeft.textContent = Math.max(state.timeLeft, 0);
  }
  if (state.timeLeft <= 10) {
    const timer = elements.timeLeft && elements.timeLeft.closest(".timer");
    if (timer) {
      timer.style.backgroundColor = "rgba(217,48,37,0.12)";
      timer.style.color = "#d93025";
    }
  }
}

function nextTask(state, elements) {
  const task = pickRandomTask();
  state.activeTask = task;
  state.lastSelectionTime = Date.now();
  renderTask(state, elements);
}

function pickRandomTask() {
  const tasks = [
    {
      query: "Лучшие кафе Москвы",
      hint: "Учитывайте геолокацию и пользовательские оценки.",
      difficulty: "complex",
      correctIndex: 0,
      options: [
        "Яндекс.Карты — рейтинг кофеен поблизости",
        "Afisha — подборка кофеен в центре",
        "TimeOut — гид по кофейням Арбата"
      ],
      results: [
        {
          title: "Яндекс.Карты — рейтинг кафе и кофеен",
          description: "Реальные отзывы людей, фильтры по кухне и рейтингу.",
          url: "yandex.ru/maps"
        },
        {
          title: "Afisha — 25 кофеен, откуда не хочется уходить",
          description: "Подборка редакции с авторскими напитками.",
          url: "afisha.ru"
        },
        {
          title: "TimeOut — гид по кофейням Арбата",
          description: "Атмосферные места с десертами и завтраками.",
          url: "timeout.ru"
        }
      ]
    },
    {
      query: "Как настроить Яндекс.Браузер",
      hint: "Навигационный запрос — брендовый сайт в приоритете.",
      difficulty: "standard",
      correctIndex: 0,
      options: [
        "Браузер от Яндекса — официальная страница",
        "YouTube — видеообзор настроек",
        "VC.ru — статья с лайфхаками"
      ],
      results: [
        {
          title: "Яндекс.Браузер — официальная страница",
          description: "Скачайте и настройте браузер под себя.",
          url: "browser.yandex.ru"
        },
        {
          title: "YouTube — 10 скрытых настроек Яндекс.Браузера",
          description: "Видеоинструкция с демонстрацией интерфейса.",
          url: "youtube.com"
        },
        {
          title: "VC.ru — лайфхаки по настройке браузера",
          description: "Сообщество делится полезными расширениями.",
          url: "vc.ru"
        }
      ]
    },
    {
      query: "Погода в Санкт-Петербурге",
      hint: "Колдунщики и собственный сервис показываются первыми.",
      difficulty: "standard",
      correctIndex: 0,
      options: [
        "Погода в Санкт-Петербурге — Яндекс.Погода",
        "Gismeteo — прогноз на неделю",
        "RP5 — подробный метеорадар"
      ],
      results: [
        {
          title: "Яндекс.Погода — прогноз на 10 дней",
          description: "Температура, ветер и вероятность осадков.",
          url: "yandex.ru/pogoda"
        },
        {
          title: "Gismeteo — погода в Петербурге",
          description: "Прогноз на неделю с графиками.",
          url: "gismeteo.ru"
        },
        {
          title: "RP5 — метеорадар",
          description: "Подробные карты осадков по часам.",
          url: "rp5.ru"
        }
      ]
    },
    {
      query: "Новости технологий сегодня",
      hint: "Свежесть публикаций и авторитет источника важнее всего.",
      difficulty: "complex",
      correctIndex: 1,
      options: [
        "YouTube — подборка техноновостей",
        "Хабр — дайджест технологий",
        "VC.ru — новости стартапов"
      ],
      results: [
        {
          title: "YouTube — Tech Digest 24h",
          description: "Видео-дайджест с главными новостями.",
          url: "youtube.com"
        },
        {
          title: "Хабр — новости технологий",
          description: "Свежие публикации от разработчиков и аналитиков.",
          url: "habr.com"
        },
        {
          title: "VC.ru — свежие новости стартапов",
          description: "Инвестиции, запуск проектов и аналитика рынка.",
          url: "vc.ru"
        }
      ]
    },
    {
      query: "Что посмотреть на выходных",
      hint: "Тематика развлечений — учитывайте персонализацию и подборки.",
      difficulty: "standard",
      correctIndex: 2,
      options: [
        "Википедия — список фильмов 2024",
        "Кинопоиск — подборка премьер недели",
        "Яндекс.Афиша — мероприятия рядом"
      ],
      results: [
        {
          title: "Википедия — премьеры кино 2024",
          description: "Справочник фильмов по датам выхода.",
          url: "ru.wikipedia.org"
        },
        {
          title: "Кинопоиск — премьеры недели",
          description: "Подборка фильмов и сериалов для вечера.",
          url: "kinopoisk.ru"
        },
        {
          title: "Яндекс.Афиша — события в городе",
          description: "Выставки, концерты и спектакли поблизости.",
          url: "afisha.yandex.ru"
        }
      ]
    },
    {
      query: "Тарифы Яндекс Плюс",
      hint: "Коммерческий запрос — приоритет у продукта бренда.",
      difficulty: "standard",
      correctIndex: 0,
      options: [
        "Яндекс Плюс — официальный сайт",
        "Отзовик — отзывы о тарифах",
        "VC.ru — сравнение подписок"
      ],
      results: [
        {
          title: "Яндекс Плюс — все тарифы и условия",
          description: "Сравнение подписок, бонусы и акции.",
          url: "plus.yandex.ru"
        },
        {
          title: "Отзовик — впечатления пользователей",
          description: "Отзывы о подписке и лайфхаки экономии.",
          url: "otzovik.com"
        },
        {
          title: "VC.ru — стоит ли оформлять Яндекс Плюс",
          description: "Разбор преимуществ и ограничений подписки.",
          url: "vc.ru"
        }
      ]
    }
  ];
  const index = Math.floor(Math.random() * tasks.length);
  return tasks[index];
}

function renderTask(state, elements) {
  const task = state.activeTask;
  if (!task) {
    return;
  }
  elements.currentQuery.textContent = task.query;
  elements.hint.textContent = task.hint;
  elements.hint.classList.remove("success", "error");
  elements.hint.classList.add("warning");

  elements.optionsContainer.innerHTML = "";
  task.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "option-button";
    button.textContent = option;
    button.dataset.optionIndex = index.toString();
    button.addEventListener("click", () => handleAnswer(state, elements, index));
    elements.optionsContainer.appendChild(button);
  });

  elements.resultsList.innerHTML = "<li class='result-item'>Сделайте выбор, чтобы увидеть позицию результатов.</li>";
}

function handleAnswer(state, elements, selectedIndex) {
  if (!state.isRunning || state.activeTask === null) {
    return;
  }
  const task = state.activeTask;
  const buttons = elements.optionsContainer.querySelectorAll(".option-button");
  buttons.forEach((btn) => {
    btn.disabled = true;
  });

  const selectionTime = (Date.now() - state.lastSelectionTime) / 1000;
  const isCorrect = selectedIndex === task.correctIndex;
  const isRelevant = !isCorrect && task.correctIndex !== undefined;
  let pointsEarned = 0;

  if (isCorrect) {
    state.correct += 1;
    state.streak += 1;
    pointsEarned += GAME_CONFIG.correctScore;
    if (task.difficulty === "complex") {
      pointsEarned = Math.round(pointsEarned * GAME_CONFIG.difficultyMultiplier.complex);
    }
    if (selectionTime <= GAME_CONFIG.speedBonusThreshold) {
      pointsEarned += 5;
    }
    if (state.streak > 0 && state.streak % 3 === 0) {
      pointsEarned += GAME_CONFIG.streakBonus;
    }
    setFeedback(elements.feedback, `Верно! Вы опередили алгоритм на ${selectionTime.toFixed(1)} с. +${pointsEarned} очков.`, "success");
  } else if (isRelevant) {
    state.streak = 0;
    pointsEarned += GAME_CONFIG.relevantScore;
    setFeedback(elements.feedback, `Почти! Этот результат в топе, но не на первом месте. Вы получаете ${pointsEarned} очков.`, "warning");
  } else {
    state.streak = 0;
    setFeedback(elements.feedback, "На этот раз мимо. Проанализируйте подсказку и попробуйте снова!", "error");
  }

  if (pointsEarned > 0) {
    state.score += pointsEarned;
  }

  state.rounds += 1;
  updateScoreboard(state, elements);
  highlightAnswers(buttons, task.correctIndex, selectedIndex);
  renderResultsList(elements.resultsList, task.results, selectedIndex, task.correctIndex);
  setTimeout(() => {
    if (state.isRunning) {
      state.lastSelectionTime = Date.now();
      nextTask(state, elements);
    }
  }, 1600);
}

function setFeedback(element, message, type) {
  if (!element) {
    return;
  }
  element.textContent = message;
  element.classList.remove("success", "error", "warning");
  if (type === "success") {
    element.classList.add("success");
  } else if (type === "error") {
    element.classList.add("error");
  } else if (type === "warning") {
    element.classList.add("warning");
  }
}

function highlightAnswers(buttons, correctIndex, selectedIndex) {
  buttons.forEach((btn) => {
    const index = parseInt(btn.dataset.optionIndex || "-1", 10);
    if (index === correctIndex) {
      btn.classList.add("is-correct");
    }
    if (index === selectedIndex && index !== correctIndex) {
      btn.classList.add("is-incorrect");
    }
  });
}

function renderResultsList(listElement, results, selectedIndex, correctIndex) {
  if (!listElement) {
    return;
  }
  listElement.innerHTML = "";
  results.forEach((result, index) => {
    const li = document.createElement("li");
    li.className = "result-item";
    const badge = index === correctIndex ? "<span class='badge success'>1 место</span>" : `<span class='badge'>${index + 1} место</span>`;
    const selectionMark = index === selectedIndex ? " (ваш выбор)" : "";
    li.innerHTML = `
      <strong>${result.title}${selectionMark}</strong>
      <p>${result.description}</p>
      <span>${badge} · ${result.url}</span>
    `;
    listElement.appendChild(li);
  });
}

function updateScoreboard(state, elements) {
  const accuracy = state.rounds > 0 ? Math.round((state.correct / state.rounds) * 100) : 0;
  if (elements.scoreValue) {
    elements.scoreValue.textContent = state.score;
  }
  if (elements.accuracyValue) {
    elements.accuracyValue.textContent = `${accuracy}%`;
  }
  if (elements.correctCounter) {
    elements.correctCounter.textContent = state.correct;
  }
  if (elements.roundCounter) {
    elements.roundCounter.textContent = state.rounds;
  }
  if (elements.streakCounter) {
    elements.streakCounter.textContent = state.streak;
  }
  state.canSave = true;
}

function endRound(state, elements, message) {
  clearInterval(state.timerId);
  state.timerId = null;
  state.isRunning = false;
  setFeedback(elements.feedback, message, "warning");
  elements.startBtn.classList.remove("btn-secondary");
  elements.startBtn.classList.add("btn-primary");
  elements.startBtn.textContent = "Начать новый раунд";
  elements.startBtn.disabled = false;
  state.activeTask = null;
  state.canSave = state.rounds > 0;
  if (state.canSave) {
    elements.saveStatus.textContent = "Раунд завершён! Введите ник и сохраните результат.";
    elements.saveStatus.classList.remove("error");
    elements.saveStatus.classList.add("success");
  } else {
    elements.saveStatus.textContent = "Раунд завершён без попыток. Сыграйте ещё раз.";
    elements.saveStatus.classList.remove("success");
    elements.saveStatus.classList.add("error");
  }
}

function saveGameResult(state, elements) {
  if (!state.canSave) {
    elements.saveStatus.textContent = "Сначала завершите раунд, чтобы сохранить результат.";
    elements.saveStatus.classList.remove("success");
    elements.saveStatus.classList.add("error");
    return;
  }
  const form = elements.scoreForm;
  const nameInput = form.querySelector("#player-name");
  const name = nameInput.value.trim();
  if (name.length < 2) {
    elements.saveStatus.textContent = "Введите никнейм не короче двух символов.";
    elements.saveStatus.classList.remove("success");
    elements.saveStatus.classList.add("error");
    return;
  }
  const accuracy = state.rounds > 0 ? Math.round((state.correct / state.rounds) * 100) : 0;
  const record = {
    name: name,
    score: state.score,
    accuracy: accuracy,
    date: new Date().toISOString()
  };
  const records = readStorage(STORAGE_KEYS.leaderboard, []);
  records.push(record);
  writeStorage(STORAGE_KEYS.leaderboard, records);
  elements.saveStatus.textContent = "Результат сохранён! Загляните в таблицу лидеров.";
  elements.saveStatus.classList.remove("error");
  elements.saveStatus.classList.add("success");
  renderLeaderboardPreview();
  nameInput.value = "";
  state.canSave = false;
}

function initContactForm() {
  const form = document.querySelector("[data-role='contact-form']");
  if (!form) {
    return;
  }
  const status = form.querySelector("[data-role='form-status']");
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    status.textContent = "Сообщение отправлено! Мы свяжемся с вами в ближайшее время.";
    status.classList.add("success");
    status.classList.remove("error");
    form.reset();
  });
}

function readStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) {
      return fallback;
    }
    return JSON.parse(raw);
  } catch (error) {
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.warn("Не удалось сохранить данные в localStorage", error);
  }
}

function formatDate(value) {
  try {
    const date = new Date(value);
    return date.toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });
  } catch (error) {
    return value;
  }
}

function escapeHTML(string) {
  return string
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}