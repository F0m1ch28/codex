document.addEventListener("DOMContentLoaded", () => {
  const nav = document.querySelector("[data-nav]");
  const toggle = document.querySelector("[data-nav-toggle]");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      nav.classList.toggle("is-open");
      toggle.classList.toggle("is-active");
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", (!expanded).toString());
    });
  }

  const yearTarget = document.querySelector("[data-current-year]");
  if (yearTarget) {
    const formattedYear = new Intl.DateTimeFormat("fa-IR", { year: "numeric" }).format(new Date());
    yearTarget.textContent = formattedYear;
  }

  const banner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const consentKey = "taeid-cookie-consent";

  const hideBanner = () => {
    if (banner) {
      banner.setAttribute("data-visible", "false");
      setTimeout(() => banner.setAttribute("hidden", "true"), 320);
    }
  };

  const showBanner = () => {
    if (banner) {
      banner.removeAttribute("hidden");
      requestAnimationFrame(() => banner.setAttribute("data-visible", "true"));
    }
  };

  const storedConsent = localStorage.getItem(consentKey);
  if (!storedConsent) {
    showBanner();
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      hideBanner();
    });
  }
});