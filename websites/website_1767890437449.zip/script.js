(function () {
    document.addEventListener("DOMContentLoaded", function () {
        const navToggle = document.querySelector(".mobile-nav-toggle");
        const navList = document.querySelector(".nav-list");
        if (navToggle && navList) {
            navToggle.addEventListener("click", function () {
                const isOpen = navList.classList.toggle("is-active");
                navToggle.setAttribute("aria-expanded", String(isOpen));
            });
            const navLinks = navList.querySelectorAll(".nav-link");
            navLinks.forEach((link) => {
                link.addEventListener("click", () => {
                    navList.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                });
            });
        }

        const banner = document.getElementById("cookie-banner");
        const storedChoice = localStorage.getItem("bhjCookieChoice");
        if (banner && !storedChoice) {
            banner.classList.add("visible");
        }

        const cookieButtons = document.querySelectorAll(".cookie-btn[data-choice]");
        cookieButtons.forEach((btn) => {
            btn.addEventListener("click", function () {
                const choice = this.dataset.choice || "undecided";
                localStorage.setItem("bhjCookieChoice", choice);
                if (banner) {
                    banner.classList.remove("visible");
                }
            });
        });
    });
})();