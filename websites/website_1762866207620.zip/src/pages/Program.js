import React from 'react';
import { Helmet } from 'react-helmet';
import shared from '../styles/Shared.module.css';
import styles from '../styles/Program.module.css';

const modules = [
  {
    title: 'Модуль 1. Диагностика и голос',
    duration: '2 недели',
    elements: [
      'Постановка целей и определение индивидуальных задач',
      'Разбор дыхательных техник, работа с резонаторами',
      'Упражнения на темп, артикуляцию и паузы'
    ]
  },
  {
    title: 'Модуль 2. Структура и сторителлинг',
    duration: '3 недели',
    elements: [
      'Создание авторского сценария выступления',
      'Работа с интригой, открытием и завершением',
      'Трансформация сложных данных в понятные истории'
    ]
  },
  {
    title: 'Модуль 3. Работа с презентацией',
    duration: '2 недели',
    elements: [
      'Логика слайдов, визуальные акценты, расстановка текста',
      'Использование визуальных средств и интерактивных инструментов',
      'Репетиции слайд за слайдом с таймером'
    ]
  },
  {
    title: 'Модуль 4. Психология выступления',
    duration: '2 недели',
    elements: [
      'Техники управления волнением и концентрацией',
      'Ответы на вопросы из аудитории, работа с возражениями',
      'Телесные практики для устойчивости и энергии'
    ]
  },
  {
    title: 'Модуль 5. Финальные выступления и сертификация',
    duration: '1 неделя',
    elements: [
      'Подготовка итогового выступления в выбранном формате',
      'Видеоразбор и индивидуальные рекомендации',
      'Выдача сертификата Aivora с описанием освоенных навыков'
    ]
  }
];

const Program = () => {
  return (
    <>
      <Helmet>
        <title>Программа курса Aivora — структура модулей</title>
        <meta
          name="description"
          content="Программа курса Aivora: модули по голосу, структуре речи, презентациям, психологии выступления и сертификация."
        />
        <meta
          name="keywords"
          content="структура курса ораторского мастерства, программа обучения речи, модули Aivora"
        />
        <link rel="canonical" href="https://aivora.eu/programma" />
      </Helmet>
      <section className={`${shared.section} ${styles.programSection}`}>
        <div className={styles.programIntro}>
          <h1 className={shared.sectionTitle}>Программа курса</h1>
          <p className={shared.sectionSubtitle}>
            Программа включает пять модулей и продолжается восемь недель. Мы объединяем теорию,
            практику, упражнения и видеоразборы, чтобы закрепить навыки.
          </p>
        </div>
        <div className={styles.moduleTimeline}>
          {modules.map((module, index) => (
            <article key={module.title} className={styles.moduleCard}>
              <span className={styles.moduleIndex}>{index + 1}</span>
              <div className={styles.moduleHeader}>
                <h2>{module.title}</h2>
                <span className={styles.moduleDuration}>{module.duration}</span>
              </div>
              <ul className={styles.moduleList}>
                {module.elements.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className={styles.programExtra}>
          <div className={styles.extraCard}>
            <h3>Практические упражнения</h3>
            <p>
              Каждое задание сопровождается видеоинструкцией и примерами. Вы загружаете запись, получаете обратную связь и рекомендации.
            </p>
          </div>
          <div className={styles.extraCard}>
            <h3>Видеоразборы</h3>
            <p>
              Финальные выступления фиксируются на видео. Преподаватель анализирует голос, мимику, структуру и дает дорожную карту развития.
            </p>
          </div>
          <div className={styles.extraCard}>
            <h3>Сертификация</h3>
            <p>
              По завершении курса слушатель получает сертификат Aivora с описанием освоенных навыков и рекомендациями по дальнейшему росту.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Program;