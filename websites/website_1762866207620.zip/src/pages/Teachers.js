import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import shared from '../styles/Shared.module.css';
import styles from '../styles/Teachers.module.css';

const teachers = [
  {
    name: 'Алина Морозова',
    specialization: 'Ораторское мастерство, сценическая речь',
    experience: '15 лет преподавания, сотрудничество с театрами Берлина и Варшавы.',
    achievements: [
      'Подготовила спикеров для TEDxBerlin и Startupnight',
      'Автор курса по выразительному чтению для международных школ'
    ],
    image: 'https://picsum.photos/400/400?random=61'
  },
  {
    name: 'Игорь Шульц',
    specialization: 'Риторика, сторителлинг',
    experience: 'Бывший журналист и модератор панельных обсуждений на европейских форумах.',
    achievements: [
      'Наставник в программе Creative Bureaucracy Festival',
      'Создает сценарии и помогает спикерам структурировать выступления'
    ],
    image: 'https://picsum.photos/400/400?random=62'
  },
  {
    name: 'София Даннен',
    specialization: 'Техника речи, голос',
    experience: 'Сценическая и радиоведущая практика, музыкальное образование.',
    achievements: [
      'Сертифицированный тренер голоса по методике Estill Voice Training',
      'Работает с тележурналистами и преподавателями университетов'
    ],
    image: 'https://picsum.photos/400/400?random=63'
  },
  {
    name: 'Даниэль Фогель',
    specialization: 'Презентации, визуальные коммуникации',
    experience: 'Консультант по презентациям для технологических компаний в ЕС.',
    achievements: [
      'Помогал командам выигрывать гранты Horizon Europe',
      'Разрабатывает презентационные структуры для продуктовых питчей'
    ],
    image: 'https://picsum.photos/400/400?random=64'
  }
];

const Teachers = () => {
  const [selected, setSelected] = useState(teachers[0].name);

  const current = teachers.find((teacher) => teacher.name === selected);

  return (
    <>
      <Helmet>
        <title>Преподаватели Aivora — команда наставников</title>
        <meta
          name="description"
          content="Познакомьтесь с преподавателями Aivora. Наставники по голосу, риторике и презентациям с опытом подготовки спикеров в Европе."
        />
        <meta
          name="keywords"
          content="преподаватели ораторского мастерства, наставники Aivora, тренеры публичных выступлений"
        />
        <link rel="canonical" href="https://aivora.eu/prepodavateli" />
      </Helmet>
      <section className={`${shared.section} ${styles.teachersSection}`}>
        <div className={styles.teachersIntro}>
          <h1 className={shared.sectionTitle}>Преподаватели Aivora</h1>
          <p className={shared.sectionSubtitle}>
            Мы собрали команду специалистов, которые помогают раскрыть голос, отточить структуру и подготовить выступление для любой аудитории.
          </p>
        </div>
        <div className={styles.teachersLayout}>
          <div className={styles.teacherList} role="tablist" aria-label="Преподаватели">
            {teachers.map((teacher) => (
              <button
                key={teacher.name}
                className={`${styles.teacherButton} ${
                  selected === teacher.name ? styles.teacherButtonActive : ''
                }`}
                type="button"
                role="tab"
                aria-selected={selected === teacher.name}
                onClick={() => setSelected(teacher.name)}
              >
                <span>{teacher.name}</span>
                <small>{teacher.specialization}</small>
              </button>
            ))}
          </div>
          {current && (
            <article className={styles.teacherDetail} role="tabpanel">
              <div className={styles.teacherImageWrapper}>
                <img src={current.image} alt={current.name} loading="lazy" />
              </div>
              <div className={styles.teacherInfo}>
                <h2>{current.name}</h2>
                <p className={styles.teacherSpec}>{current.specialization}</p>
                <p>{current.experience}</p>
                <ul className={styles.teacherAchievements}>
                  {current.achievements.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <a href="/kontakty" className={shared.buttonPrimary}>
                  Связаться с Aivora
                </a>
              </div>
            </article>
          )}
        </div>
      </section>
    </>
  );
};

export default Teachers;