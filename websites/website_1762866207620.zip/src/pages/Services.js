import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import shared from '../styles/Shared.module.css';
import styles from '../styles/Services.module.css';

const courses = [
  {
    id: 'basics',
    title: 'Основы ораторского мастерства',
    level: 'Стартовый уровень',
    description:
      'Разбираем структуру выступления, работу с текстом, управление страхом аудитории. Подходит тем, кто только начинает выступать.',
    highlights: [
      'Практика простых речевых конструкций',
      'Отработка вступления и завершения',
      'Домашние задания с видеообратной связью'
    ]
  },
  {
    id: 'voice',
    title: 'Техника речи',
    level: 'Голос и звук',
    description:
      'Работаем с дыханием, артикуляцией и тембром. Занятия помогают звучать уверенно в онлайне и офлайне.',
    highlights: [
      'Комплекс дыхательных упражнений',
      'Проработка дикции и ударений',
      'Настройка темпа и музыкальности речи'
    ]
  },
  {
    id: 'fear',
    title: 'Работа со страхом',
    level: 'Психологическая устойчивость',
    description:
      'Фокус на управлении волнением, подготовке тела и ментальных стратегий перед выходом на сцену.',
    highlights: [
      'Телесные практики и голосовые ритуалы',
      'Сценарии ответа на сложные вопросы',
      'Техники концентрации и визуализации'
    ]
  },
  {
    id: 'business',
    title: 'Деловые презентации',
    level: 'Корпоративный формат',
    description:
      'Учимся создавать убедительные презентации для совещаний, питчей и клиентских встреч.',
    highlights: [
      'Логика слайдов и сторителлинг',
      'Работа с графиками и данными',
      'Репетиции с обратной связью от группы'
    ]
  }
];

const Services = () => {
  const [activeCourse, setActiveCourse] = useState(courses[0].id);

  const currentCourse = courses.find((course) => course.id === activeCourse);

  return (
    <>
      <Helmet>
        <title>Курсы Aivora — публичные выступления и техника речи</title>
        <meta
          name="description"
          content="Курсы Aivora: основы ораторского мастерства, техника речи, работа со страхом и деловые презентации. Формат обучения для жителей ЕС."
        />
        <meta
          name="keywords"
          content="курсы публичных выступлений, риторика онлайн обучение, техника речи Европа"
        />
        <link rel="canonical" href="https://aivora.eu/kursy" />
      </Helmet>
      <section className={`${shared.section} ${styles.servicesHero}`}>
        <div className={styles.servicesIntro}>
          <h1 className={shared.sectionTitle}>Курсы Aivora</h1>
          <p className={shared.sectionSubtitle}>
            Выберите направление, которое поможет вам говорить уверенно перед коллегами, клиентами или большой аудиторией.
          </p>
        </div>
        <div className={styles.servicesTabs}>
          {courses.map((course) => (
            <button
              key={course.id}
              type="button"
              className={`${styles.serviceTab} ${
                activeCourse === course.id ? styles.serviceTabActive : ''
              }`}
              onClick={() => setActiveCourse(course.id)}
            >
              {course.title}
            </button>
          ))}
        </div>
        <article className={styles.serviceContent} aria-live="polite">
          <div className={styles.serviceInfo}>
            <span className={styles.courseLevel}>{currentCourse.level}</span>
            <h2>{currentCourse.title}</h2>
            <p>{currentCourse.description}</p>
            <ul className={styles.serviceList}>
              {currentCourse.highlights.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <a href="/programma" className={shared.buttonPrimary}>
              Посмотреть программу
            </a>
          </div>
          <div className={styles.serviceVisual}>
            <img
              src={`https://picsum.photos/800/600?random=${currentCourse.id.length * 7 + 60}`}
              alt={currentCourse.title}
              loading="lazy"
            />
          </div>
        </article>
      </section>
    </>
  );
};

export default Services;