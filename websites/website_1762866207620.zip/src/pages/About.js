import React from 'react';
import { Helmet } from 'react-helmet';
import shared from '../styles/Shared.module.css';
import styles from '../styles/About.module.css';

const teamMembers = [
  {
    name: 'Алина Морозова',
    role: 'Руководитель школы',
    description:
      '15 лет преподает сценическую речь, работала с театральными студиями Варшавы и студиями TEDx.',
    image: 'https://picsum.photos/400/400?random=21'
  },
  {
    name: 'Игорь Шульц',
    role: 'Преподаватель риторики',
    description:
      'Специализируется на логике аргументации и сторителлинге. Наставляет спикеров технологических конференций.',
    image: 'https://picsum.photos/400/400?random=22'
  },
  {
    name: 'София Даннен',
    role: 'Практик голосовых техник',
    description:
      'Курирует занятия по дыханию, дикции и тембру. Музыкальное образование и опыт выступлений в радиостудиях Берлина.',
    image: 'https://picsum.photos/400/400?random=23'
  },
  {
    name: 'Даниэль Фогель',
    role: 'Методист презентаций',
    description:
      'Помогает спикерам собирать визуальные истории и управлять вниманием аудитории в гибридных форматах.',
    image: 'https://picsum.photos/400/400?random=24'
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>Aivora — о школе и команде преподавателей</title>
        <meta
          name="description"
          content="Узнайте историю онлайн-школы Aivora, познакомьтесь с командой преподавателей и философией обучения публичным выступлениям."
        />
        <meta
          name="keywords"
          content="история школы ораторского мастерства, преподаватели Aivora, методология публичных выступлений"
        />
        <link rel="canonical" href="https://aivora.eu/o-nas" />
      </Helmet>
      <section className={`${shared.section} ${styles.aboutHero}`}>
        <div className={styles.aboutIntro}>
          <h1 className={shared.sectionTitle}>История Aivora</h1>
          <p className={shared.sectionSubtitle}>
            Aivora появилась в 2016 году, когда группа преподавателей из Берлина и Варшавы создала
            программу для подготовки русскоязычных спикеров к международным выступлениям. Сегодня мы объединяем
            методики театра, журналистики и деловых тренингов, чтобы помочь каждому звучать уверенно.
          </p>
        </div>
        <div className={styles.aboutImageWrapper}>
          <img
            src="https://picsum.photos/800/600?random=31"
            alt="Команда Aivora на рабочей встрече"
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${shared.section} ${styles.valuesSection}`}>
        <div className={styles.valuesGrid}>
          <article className={styles.valueCard}>
            <h3>Философия школы</h3>
            <p>
              Мы верим, что сильное выступление — это сочетание мыслей, эмоций и технологии подачи.
              Поэтому уделяем внимание голосу, структуре, визуальной поддержке и взаимодействию со слушателем.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Методология</h3>
            <p>
              Слушатели проходят диагностику, получают индивидуальный план и участвуют в живых сессиях.
              Мы записываем выступления, анализируем их и формируем персональные рекомендации.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Сообщество</h3>
            <p>
              Выпускники продолжают тренировки в клубе Aivora: участвуют в дебатах, готовят совместные проекты и
              обсуждают новые выступления в международных командах.
            </p>
          </article>
        </div>
      </section>

      <section className={`${shared.section} ${styles.teamSection}`}>
        <h2 className={shared.sectionTitle}>Команда преподавателей</h2>
        <p className={shared.sectionSubtitle}>
          Нас объединяет любовь к слову и желание делиться практиками, которые делают выступление живым и выразительным.
        </p>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImageWrapper}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamOverlay}>
                  <p>{member.description}</p>
                </div>
              </div>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${shared.section} ${styles.timelineSection}`}>
        <h2 className={shared.sectionTitle}>Ключевые этапы развития</h2>
        <div className={styles.timeline}>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2016</span>
            <p>Запуск пилотной программы в Берлине с участием десяти слушателей и театральных наставников.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2018</span>
            <p>Создание онлайн-платформы и библиотеки видеоразборов, расширение программы для бизнес-команд.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2020</span>
            <p>Переход на гибридный формат с живыми встречами в Берлине, Вене и Праге.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2023</span>
            <p>Запуск модулей по сторителлингу и международной коммуникации, сотрудничество с европейскими конференциями.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;