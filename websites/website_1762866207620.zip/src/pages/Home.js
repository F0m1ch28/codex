import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Home.module.css';
import shared from '../styles/Shared.module.css';

const countersData = [
  { id: 1, label: 'Структурированных модулей', endValue: 12 },
  { id: 2, label: 'Практических встреч в месяц', endValue: 8 },
  { id: 3, label: 'Видеоразборов в библиотеке', endValue: 54 },
  { id: 4, label: 'Выпускников из стран ЕС', endValue: 320 }
];

const directions = [
  {
    title: 'Публичные выступления',
    text: 'Развиваем уверенность в большом зале, создаем ритм и управляем вниманием аудитории.',
    icon: '🎤'
  },
  {
    title: 'Риторика',
    text: 'Отбираем аргументы, усиливаем структуру речи и выстраиваем выразительную подачу.',
    icon: '🧭'
  },
  {
    title: 'Презентации',
    text: 'Работаем с визуальными материалами, сторителлингом и логикой pitch-докладов.',
    icon: '🧠'
  },
  {
    title: 'Техника речи',
    text: 'Развиваем голос, дыхание, артикуляцию и управляем темпом, чтобы быть услышанными.',
    icon: '🎧'
  }
];

const advantages = [
  {
    title: 'Европейский контекст',
    description:
      'Разбираем кейсы международных конференций, встречи с мультикультурной аудиторией и гибридные форматы общения.'
  },
  {
    title: 'Практика каждую неделю',
    description:
      'Каждый модуль заканчивается интерактивной сессией с видеоразбором и обратной связью от преподавателей.'
  },
  {
    title: 'Гибкая платформа',
    description:
      'Доступ к вебинарам, библиотеке упражнений и заметкам на нескольких языках, удобное расписание для резидентов ЕС.'
  }
];

const testimonials = [
  {
    name: 'Марина Г.',
    role: 'Берлин',
    quote:
      'После курса я впервые выступила перед международной командой без лишнего напряжения. Aivora помогла продумать структуру и голос.'
  },
  {
    name: 'Антон К.',
    role: 'Вена',
    quote:
      'Понравилось сочетание теории и практики. Упражнения на дыхание и работа над паузами сделали мои презентации уверенными и выразительными.'
  },
  {
    name: 'Людмила С.',
    role: 'Прага',
    quote:
      'Занятия в небольших группах и персональные рекомендации помогли мне говорить яснее и удерживать внимание аудитории.'
  }
];

const projects = [
  {
    id: 1,
    title: 'Программа для продуктовых менеджеров',
    category: 'Корпоративное обучение',
    image: 'https://picsum.photos/1200/800?random=41',
    description:
      'Интенсив для команды европейского стартапа с упором на питчинг перед инвесткомитетами и демо-днями.'
  },
  {
    id: 2,
    title: 'Подготовка к выступлению на конференции',
    category: 'Индивидуальная работа',
    image: 'https://picsum.photos/1200/800?random=42',
    description:
      'Персональный план для технического лидера: проработка сценария, управление голосом и работа с вопросами из зала.'
  },
  {
    id: 3,
    title: 'Коммуникация в гибридных командах',
    category: 'Корпоративное обучение',
    image: 'https://picsum.photos/1200/800?random=43',
    description:
      'Серия сессий для международной компании: краткие форматы презентаций, онлайн-риторика и digital-навыки.'
  },
  {
    id: 4,
    title: 'Подготовка к TEDx выступлению',
    category: 'Индивидуальная работа',
    image: 'https://picsum.photos/1200/800?random=44',
    description:
      'Создание сторителлинга, тренировка жестов и репетиции на сцене с учетом требований организаторов.'
  }
];

const faqItems = [
  {
    question: 'Как проходит обучение в Aivora?',
    answer:
      'Мы совмещаем живые онлайн-сессии, практические задания, видеолекции и индивидуальную обратную связь. Каждая неделя завершается закрепляющей встречей с анализом выступлений.'
  },
  {
    question: 'Можно ли совмещать обучение с работой?',
    answer:
      'Да. Мы придерживаемся концепции microlearning. Занятия проходят вечером по расписанию CET, а дополнительные материалы доступны в записи.'
  },
  {
    question: 'Нужен ли опыт выступлений?',
    answer:
      'Нет. Мы формируем группы по уровню, чтобы дать комфортный старт новичкам и продвинутые задачи тем, кто уже выступает регулярно.'
  },
  {
    question: 'Какие материалы я получу после курса?',
    answer:
      'Вы сохраняете доступ к библиотеке шаблонов, чек-листов, видеоразборов и персональному плану дальнейших тренировок.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Как создавать сильное вступление для любой презентации',
    excerpt:
      'Делимся структурой hook–контекст–обещание и упражнениями, которые помогают завладеть вниманием с первых секунд.',
    link: '#',
    image: 'https://picsum.photos/800/600?random=51'
  },
  {
    id: 2,
    title: '5 дыхательных техник для стабильного голоса',
    excerpt:
      'Показываем, как работать с диафрагмой, экономить воздух и звучать выразительно даже в стрессовых ситуациях.',
    link: '#',
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    id: 3,
    title: 'Как адаптировать речь для международной аудитории',
    excerpt:
      'Разбираем, как управлять темпом, использовать метафоры и проверять понятность терминов в гибридных командах.',
    link: '#',
    image: 'https://picsum.photos/800/600?random=53'
  }
];

const Home = () => {
  const statsRef = useRef(null);
  const [animatedValues, setAnimatedValues] = useState(
    countersData.map(() => 0)
  );
  const [started, setStarted] = useState(false);
  const [projectFilter, setProjectFilter] = useState('Все');
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Все') return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!statsRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started) {
            setStarted(true);
          }
        });
      },
      { threshold: 0.4 }
    );
    observer.observe(statsRef.current);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;

    const duration = 1800;
    const startTime = performance.now();

    const step = (currentTime) => {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const newValues = countersData.map((counter, index) =>
        Math.floor(progress * counter.endValue)
      );
      setAnimatedValues(newValues);
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };

    requestAnimationFrame(step);
  }, [started]);

  return (
    <>
      <Helmet>
        <title>Aivora — курс ораторского мастерства онлайн</title>
        <meta
          name="description"
          content="Онлайн-школа Aivora помогает уверенно выступать на русском языке в Европейском союзе: риторика, публичные выступления, техника речи и презентации."
        />
        <meta
          name="keywords"
          content="курс ораторского мастерства Европа, публичные выступления обучение, риторика онлайн, техника речи курс, уверенность в выступлениях, презентации обучение"
        />
        <link rel="canonical" href="https://aivora.eu/" />
      </Helmet>
      <section className={`${shared.section} ${styles.heroSection}`}>
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Онлайн-школа ораторского мастерства</span>
          <h1 className={styles.heroTitle}>Говорите убедительно и вдохновляйте</h1>
          <p className={styles.heroText}>
            Aivora — пространство для подготовки публичных выступлений, деловых презентаций и переговоров.
            Мы поддерживаем жителей ЕС, которые стремятся звучать ясно и управлять вниманием аудитории на русском языке.
          </p>
          <div className={styles.heroActions}>
            <a href="#cta" className={shared.buttonPrimary}>
              Начать обучение
            </a>
            <a href="/programma" className={styles.heroSecondary}>
              Смотреть программу
            </a>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Оратор выступает перед аудиторией"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${shared.section} ${styles.introSection}`}>
        <div className={styles.introContent}>
          <h2 className={shared.sectionTitle}>Aivora — школа уверенной речи</h2>
          <p className={shared.sectionSubtitle}>
            Мы объединяем методики театральной педагогики, журналистики и деловой риторики, чтобы вы могли вести встречи,
            презентовать идеи и отвечать на вопросы уверенно.
          </p>
          <div className={styles.introGrid}>
            <div className={styles.introCard}>
              <h3>Погружение в практику</h3>
              <p>
                Каждое занятие заканчивается выступлением и анализом. Вы видите свой прогресс, фиксируете сильные стороны и уточняете задачи.
              </p>
            </div>
            <div className={styles.introCard}>
              <h3>Поддержка наставника</h3>
              <p>
                Преподаватель Aivora помогает адаптировать упражнения под ваш голос, акценты и культурный контекст аудитории.
              </p>
            </div>
            <div className={styles.introCard}>
              <h3>Онлайн-сообщество</h3>
              <p>
                Закрытый клуб выпускников с живыми встречами, где можно отрабатывать новые темы и тестировать сценарии.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.directionsSection}`}>
        <h2 className={shared.sectionTitle}>Направления обучения</h2>
        <p className={shared.sectionSubtitle}>
          Мы помогаем прокачать ключевые навыки коммуникации — от подготовки сценария до финального выступления в аудитории.
        </p>
        <div className={styles.directionsGrid}>
          {directions.map((direction) => (
            <article key={direction.title} className={styles.directionCard}>
              <span className={styles.directionIcon}>{direction.icon}</span>
              <h3>{direction.title}</h3>
              <p>{direction.text}</p>
              <a className={styles.directionLink} href="/kursy">
                Узнать подробнее →
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className={`${shared.section} ${styles.statsSection}`} ref={statsRef}>
        <div className={styles.statsInner}>
          {countersData.map((counter, index) => (
            <div key={counter.id} className={styles.statCard}>
              <span className={styles.statNumber}>{animatedValues[index]}+</span>
              <span className={styles.statLabel}>{counter.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={`${shared.section} ${styles.methodSection}`}>
        <div className={styles.methodText}>
          <h2 className={shared.sectionTitle}>Методика Aivora</h2>
          <p className={shared.sectionSubtitle}>
            Наш подход сочетает гибкие форматы обучения и глубокую практику. Мы строим занятия вокруг реальных задач слушателей.
          </p>
          <ul className={styles.methodList}>
            <li>
              <strong>Диагностика голоса и речи.</strong> Понимаем ваши цели, определяем зоны роста, подбираем упражнения.
            </li>
            <li>
              <strong>Тренировка структуры выступления.</strong> Работаем с логикой, аргументами, сторителлингом и темпоритмом.
            </li>
            <li>
              <strong>Имитация сценических условий.</strong> Репетируем с камерой, микрофоном, анализируем жесты и взгляд.
            </li>
            <li>
              <strong>Адаптация под формат.</strong> Учитываем особенности онлайн и офлайн-площадок, гетерогенных команд, гибридных митингов.
            </li>
          </ul>
        </div>
        <div className={styles.methodVisual}>
          <img
            src="https://picsum.photos/800/600?random=12"
            alt="Онлайн-занятие по техникам речи"
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${shared.section} ${styles.featuresSection}`}>
        <h2 className={shared.sectionTitle}>Почему выбирают Aivora</h2>
        <div className={styles.featuresGrid}>
          {advantages.map((advantage) => (
            <article key={advantage.title} className={styles.featureCard}>
              <h3>{advantage.title}</h3>
              <p>{advantage.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`${shared.section} ${styles.processSection}`}>
        <div className={styles.processHeader}>
          <h2 className={shared.sectionTitle}>Как проходит обучение</h2>
          <p className={shared.sectionSubtitle}>
            Мы ведём слушателя от диагностики к публичному выступлению через последовательные шаги.
          </p>
        </div>
        <div className={styles.processGrid}>
          <div className={styles.processStep}>
            <span className={styles.processNumber}>01</span>
            <h3>Знакомство и цели</h3>
            <p>Вы заполняете анкету, встречаетесь с преподавателем, формируете личную траекторию.</p>
          </div>
          <div className={styles.processStep}>
            <span className={styles.processNumber}>02</span>
            <h3>Работа с голосом</h3>
            <p>Выполняем упражнения на дыхание, резонаторы и тембр, чтобы звучать выразительно и спокойно.</p>
          </div>
          <div className={styles.processStep}>
            <span className={styles.processNumber}>03</span>
            <h3>Структура и сценарий</h3>
            <p>Создаем тезисы, строим визуальную поддержку, тренируем подачу сложных данных.</p>
          </div>
          <div className={styles.processStep}>
            <span className={styles.processNumber}>04</span>
            <h3>Репетиции и обратная связь</h3>
            <p>Оттачиваем выступление с камерой, разбираем запись, получаем рекомендации по улучшению.</p>
          </div>
          <div className={styles.processStep}>
            <span className={styles.processNumber}>05</span>
            <h3>Финальные выступления</h3>
            <p>Проводим завершающее выступление и фиксируем стратегию дальнейшей практики.</p>
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.testimonialsSection}`}>
        <div className={styles.testimonialContent}>
          <h2 className={shared.sectionTitle}>Отзывы выпускников</h2>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>"{testimonial.quote}"</p>
                <span className={styles.testimonialAuthor}>{testimonial.name}</span>
                <span className={styles.testimonialRole}>{testimonial.role}</span>
              </article>
            ))}
          </div>
          <div className={styles.testimonialDots} role="tablist">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.testimonialDot} ${
                  index === activeTestimonial ? styles.dotActive : ''
                }`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Показать отзыв ${index + 1}`}
              />
            ))}
          </div>
        </div>
        <div className={styles.testimonialImageWrapper}>
          <img
            src="https://picsum.photos/800/600?random=13"
            alt="Студенты Aivora во время онлайн-занятия"
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${shared.section} ${styles.projectsSection}`}>
        <div className={styles.projectsHeader}>
          <h2 className={shared.sectionTitle}>Кейсы и проекты</h2>
          <div className={styles.projectFilters}>
            {['Все', 'Корпоративное обучение', 'Индивидуальная работа'].map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setProjectFilter(filter)}
                className={`${styles.projectFilterButton} ${
                  projectFilter === filter ? styles.projectFilterActive : ''
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${shared.section} ${styles.faqSection}`}>
        <div className={styles.faqHeader}>
          <h2 className={shared.sectionTitle}>Частые вопросы</h2>
          <p className={shared.sectionSubtitle}>
            Мы собрали ответы на вопросы о формате обучения, расписании и поддержке.
          </p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <details key={index} className={styles.faqItem}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={`${shared.section} ${styles.blogSection}`}>
        <div className={styles.blogHeader}>
          <h2 className={shared.sectionTitle}>Блог Aivora</h2>
          <p className={shared.sectionSubtitle}>
            Советы по подготовке к публичным выступлениям, технике речи и работе с голосом.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <div className={styles.blogImageWrapper}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href={post.link} className={styles.blogLink}>
                  Читать заметку →
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="cta" className={`${shared.section} ${styles.ctaSection}`}>
        <div className={styles.ctaContent}>
          <h2 className={styles.ctaTitle}>Готовы уверенно выступать?</h2>
          <p className={styles.ctaText}>
            Оставьте заявку, и мы поможем подобрать учебный трек под ваши цели: выступление на конференции,
            запуск презентации или развитие команды.
          </p>
          <a href="/kontakty" className={shared.buttonPrimary}>
            Записаться на консультацию
          </a>
        </div>
        <div className={styles.ctaVisual}>
          <img
            src="https://picsum.photos/800/600?random=14"
            alt="Подготовка к выступлению"
            loading="lazy"
          />
        </div>
      </section>
    </>
  );
};

export default Home;