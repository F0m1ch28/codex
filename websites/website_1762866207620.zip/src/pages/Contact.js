import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import shared from '../styles/Shared.module.css';
import styles from '../styles/Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Укажите ваше имя.';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Введите корректный email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Расскажите о цели обращения.';
    return newErrors;
  };

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
    setErrors((prev) => ({ ...prev, [e.target.name]: undefined }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты Aivora — онлайн-школа ораторского мастерства</title>
        <meta
          name="description"
          content="Свяжитесь с Aivora: адрес в Берлине, телефон, форма обратной связи и социальные сети."
        />
        <meta
          name="keywords"
          content="контакты школы ораторского мастерства, записаться на курс речи, Aivora Berlin"
        />
        <link rel="canonical" href="https://aivora.eu/kontakty" />
      </Helmet>
      <section className={`${shared.section} ${styles.contactSection}`}>
        <div className={styles.contactInfo}>
          <h1 className={shared.sectionTitle}>Свяжитесь с Aivora</h1>
          <p className={shared.sectionSubtitle}>
            Расскажите о задачах, и мы предложим подходящий формат обучения: индивидуальные занятия, корпоративные программы или групповую работу.
          </p>
          <div className={styles.contactDetails}>
            <div>
              <h2>Адрес</h2>
              <p>Potsdamer Platz 10, 10785 Berlin, Germany</p>
            </div>
            <div>
              <h2>Телефон</h2>
              <a href="tel:+493023456789">+49 30 2345 6789</a>
            </div>
            <div>
              <h2>Email</h2>
              <p>[будет добавлен позже]</p>
            </div>
            <div>
              <h2>Социальные сети</h2>
              <ul className={styles.socialList}>
                <li>
                  <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                    LinkedIn
                  </a>
                </li>
                <li>
                  <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">
                    YouTube
                  </a>
                </li>
                <li>
                  <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
                    Instagram
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className={styles.contactFormWrapper}>
          <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
            <label htmlFor="name">Имя*</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Как к вам обращаться"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}

            <label htmlFor="email">Email*</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="name@example.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}

            <label htmlFor="phone">Телефон</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              placeholder="+49 ..."
              value={formData.phone}
              onChange={handleChange}
            />

            <label htmlFor="message">Сообщение*</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Расскажите о цели обучения и формате выступления"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}

            <button type="submit" className={shared.buttonPrimary}>
              Отправить сообщение
            </button>
            {submitted && (
              <p className={styles.successMessage}>
                Спасибо! Мы свяжемся с вами, чтобы обсудить детали обучения.
              </p>
            )}
          </form>
        </div>
      </section>
      <section className={styles.mapSection} aria-label="Карта расположения офиса Aivora">
        <iframe
          title="Aivora Berlin"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.613939516562!2d13.372295477337429!3d52.509648872089636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c27c0fe05b%3A0x21d0e7830f8f9e5d!2sPotsdamer%20Platz%2010%2C%2010785%20Berlin!5e0!3m2!1sru!2sde!4v1699777777777!5m2!1sru!2sde"
          loading="lazy"
          allowFullScreen
          referrerPolicy="no-referrer-when-downgrade"
        />
      </section>
    </>
  );
};

export default Contact;