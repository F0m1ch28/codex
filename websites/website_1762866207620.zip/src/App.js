import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Program from './pages/Program';
import Teachers from './pages/Teachers';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import styles from './styles/Layout.module.css';

const App = () => {
  return (
    <div className={styles.appWrapper}>
      <Header />
      <main className={styles.mainContent} role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/o-nas" element={<About />} />
          <Route path="/kursy" element={<Services />} />
          <Route path="/programma" element={<Program />} />
          <Route path="/prepodavateli" element={<Teachers />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/usloviya" element={<Terms />} />
          <Route path="/konfidentsialnost" element={<Privacy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;