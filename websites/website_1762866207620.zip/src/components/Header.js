import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from '../styles/Layout.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen((prev) => !prev);
  const closeMenu = () => setOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.headerInner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Aivora">
          Aivora
        </NavLink>
        <nav className={styles.nav} aria-label="Основная навигация">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink
            }
          >
            Главная
          </NavLink>
          <NavLink
            to="/o-nas"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink
            }
          >
            О школе
          </NavLink>
          <NavLink
            to="/kursy"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink
            }
          >
            Курсы
          </NavLink>
          <NavLink
            to="/programma"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink
            }
          >
            Программа
          </NavLink>
          <NavLink
            to="/prepodavateli"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink
            }
          >
            Преподаватели
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink
            }
          >
            Контакты
          </NavLink>
        </nav>
        <button
          className={`${styles.mobileToggle} ${open ? styles.mobileToggleActive : ''}`}
          onClick={toggleMenu}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label="Меню"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
      <div
        id="mobile-menu"
        className={`${styles.mobileMenu} ${open ? styles.mobileMenuOpen : ''}`}
      >
        <nav className={styles.mobileNav} aria-label="Мобильная навигация">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              isActive ? `${styles.mobileLink} ${styles.activeLink}` : styles.mobileLink
            }
            onClick={closeMenu}
          >
            Главная
          </NavLink>
          <NavLink
            to="/o-nas"
            className={({ isActive }) =>
              isActive ? `${styles.mobileLink} ${styles.activeLink}` : styles.mobileLink
            }
            onClick={closeMenu}
          >
            О школе
          </NavLink>
          <NavLink
            to="/kursy"
            className={({ isActive }) =>
              isActive ? `${styles.mobileLink} ${styles.activeLink}` : styles.mobileLink
            }
            onClick={closeMenu}
          >
            Курсы
          </NavLink>
          <NavLink
            to="/programma"
            className={({ isActive }) =>
              isActive ? `${styles.mobileLink} ${styles.activeLink}` : styles.mobileLink
            }
            onClick={closeMenu}
          >
            Программа
          </NavLink>
          <NavLink
            to="/prepodavateli"
            className={({ isActive }) =>
              isActive ? `${styles.mobileLink} ${styles.activeLink}` : styles.mobileLink
            }
            onClick={closeMenu}
          >
            Преподаватели
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) =>
              isActive ? `${styles.mobileLink} ${styles.activeLink}` : styles.mobileLink
            }
            onClick={closeMenu}
          >
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;