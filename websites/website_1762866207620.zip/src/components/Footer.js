import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from '../styles/Layout.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.footerTop}>
        <div className={styles.footerCol}>
          <h3 className={styles.footerTitle}>Aivora</h3>
          <p className={styles.footerText}>
            Онлайн-школа ораторского мастерства и эффективной коммуникации для жителей Европейского союза.
          </p>
        </div>
        <div className={styles.footerCol}>
          <h4 className={styles.footerSubtitle}>Навигация</h4>
          <ul className={styles.footerList}>
            <li>
              <NavLink to="/" className={styles.footerLink}>
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink to="/o-nas" className={styles.footerLink}>
                О школе
              </NavLink>
            </li>
            <li>
              <NavLink to="/kursy" className={styles.footerLink}>
                Курсы
              </NavLink>
            </li>
            <li>
              <NavLink to="/programma" className={styles.footerLink}>
                Программа
              </NavLink>
            </li>
            <li>
              <NavLink to="/prepodavateli" className={styles.footerLink}>
                Преподаватели
              </NavLink>
            </li>
            <li>
              <NavLink to="/kontakty" className={styles.footerLink}>
                Контакты
              </NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.footerCol}>
          <h4 className={styles.footerSubtitle}>Контакты</h4>
          <address className={styles.footerAddress}>
            <span>Potsdamer Platz 10, 10785 Berlin, Germany</span>
            <a href="tel:+493023456789" className={styles.footerLink}>
              +49 30 2345 6789
            </a>
            <span>Email: [будет добавлен позже]</span>
          </address>
          <div className={styles.footerSocials}>
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.footerSocialLink}
            >
              LinkedIn
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.footerSocialLink}
            >
              YouTube
            </a>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.footerSocialLink}
            >
              Instagram
            </a>
          </div>
        </div>
      </div>
      <div className={styles.footerBottom}>
        <p className={styles.footerCopy}>© {new Date().getFullYear()} Aivora. Все права защищены.</p>
        <div className={styles.footerLegal}>
          <NavLink to="/usloviya" className={styles.footerLink}>
            Пользовательское соглашение
          </NavLink>
          <NavLink to="/konfidentsialnost" className={styles.footerLink}>
            Политика конфиденциальности
          </NavLink>
        </div>
      </div>
    </footer>
  );
};

export default Footer;