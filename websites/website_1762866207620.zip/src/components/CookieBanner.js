import React, { useState, useEffect } from 'react';
import styles from '../styles/Layout.module.css';

const COOKIE_KEY = 'aivora_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.cookieBanner} role="dialog" aria-live="polite">
      <p className={styles.cookieText}>
        Мы используем файлы cookie для анализа взаимодействия с сайтом и персонализации контента.
        Продолжая пользоваться сайтом Aivora, вы соглашаетесь с нашей политикой обработки данных.
      </p>
      <div className={styles.cookieButtons}>
        <button type="button" className={styles.cookieButton} onClick={acceptCookies}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;