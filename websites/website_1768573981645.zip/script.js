const navigation = (() => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('primary-navigation');

    if (!navToggle || !navMenu) {
        return;
    }

    const toggleNav = () => {
        const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!isExpanded));
        navMenu.classList.toggle('is-open');
    };

    navToggle.addEventListener('click', toggleNav);

    navMenu.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
            if (navMenu.classList.contains('is-open')) {
                navMenu.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });

    window.addEventListener('resize', () => {
        if (window.innerWidth > 880 && navMenu.classList.contains('is-open')) {
            navMenu.classList.remove('is-open');
            navToggle.setAttribute('aria-expanded', 'false');
        }
    });
})();

const footerYear = (() => {
    const yearTargets = document.querySelectorAll('#currentYear');
    const currentYear = new Date().getFullYear();
    yearTargets.forEach((el) => {
        el.textContent = currentYear;
    });
})();

const cookieBanner = (() => {
    const banner = document.getElementById('cookieBanner');
    if (!banner) {
        return;
    }

    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const customizeBtn = document.getElementById('cookieCustomize');
    const storageKey = 'hypoprwavr_cookie_preference';

    const hideBanner = () => {
        banner.classList.add('is-hidden');
    };

    const setPreference = (value) => {
        localStorage.setItem(storageKey, JSON.stringify({
            value,
            updatedAt: new Date().toISOString()
        }));
    };

    const storedPreference = localStorage.getItem(storageKey);
    if (storedPreference) {
        hideBanner();
        return;
    }

    acceptBtn?.addEventListener('click', () => {
        setPreference('accepted');
        hideBanner();
    });

    declineBtn?.addEventListener('click', () => {
        setPreference('declined');
        hideBanner();
    });

    customizeBtn?.addEventListener('click', () => {
        window.location.href = 'cookies.html';
    });
})();