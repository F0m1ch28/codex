document.addEventListener("DOMContentLoaded", () => {
  const pageBody = document.body;

  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      siteNav.classList.toggle("is-open");
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        siteNav.classList.remove("is-open");
      });
    });
  }

  const yearTargets = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearTargets.forEach((tag) => {
    tag.textContent = currentYear;
  });

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const cookieStorageKey = "regeneracion-cookie-choice";
  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieStorageKey);
    if (!storedChoice) {
      cookieBanner.removeAttribute("hidden");
    }
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const closeBanner = (choice) => {
      localStorage.setItem(cookieStorageKey, choice);
      cookieBanner.setAttribute("hidden", "hidden");
    };
    acceptBtn?.addEventListener("click", () => closeBanner("accept"));
    declineBtn?.addEventListener("click", () => closeBanner("decline"));
  }

  const diagram = document.querySelector("[data-circular-diagram]");
  if (diagram) {
    const nodes = diagram.querySelectorAll("[data-node]");
    let activeIndex = 0;
    const circularVisual = document.querySelector(".circular-flow-visual");

    const activateNode = (index) => {
      nodes.forEach((node) => node.classList.remove("is-active"));
      if (nodes[index]) {
        nodes[index].classList.add("is-active");
      }
      if (circularVisual) {
        if (nodes[index]) {
          circularVisual.dataset.current = nodes[index].dataset.nodeTitle || "";
        }
        circularVisual.classList.add("is-active");
        window.setTimeout(() => {
          circularVisual.classList.remove("is-active");
        }, 1800);
      }
      activeIndex = index;
    };

    activateNode(activeIndex);

    nodes.forEach((node, idx) => {
      node.addEventListener("mouseenter", () => activateNode(idx));
      node.addEventListener("focus", () => activateNode(idx));
    });

    window.setInterval(() => {
      const nextIndex = (activeIndex + 1) % nodes.length;
      activateNode(nextIndex);
    }, 3800);
  }

  const calcForm = document.querySelector("[data-circular-calculator]");
  if (calcForm) {
    const residueInput = calcForm.querySelector("input[name='residuos']");
    const conversionInput = calcForm.querySelector("input[name='conversion']");
    const hoursInput = calcForm.querySelector("input[name='horas']");
    const resultBox = calcForm.querySelector("[data-calculator-result]");

    const computePotential = () => {
      const residues = parseFloat(residueInput.value) || 0;
      const conversion = parseFloat(conversionInput.value) || 0;
      const hours = parseFloat(hoursInput.value) || 0;
      const energyDensity = 2.4;
      const conversionRatio = Math.max(0, Math.min(conversion, 99.9)) / 100;
      const hourlyPotential = residues * conversionRatio * energyDensity;
      const dailyPotential = hourlyPotential * hours;
      const annualPotential = dailyPotential * 312;
      resultBox.textContent = `Potencial energético estimado: ${dailyPotential.toFixed(2)} kWh diarios y ${annualPotential.toFixed(0)} kWh anuales con la combinación introducida.`;
    };

    calcForm.addEventListener("input", computePotential);
    calcForm.addEventListener("submit", (event) => {
      event.preventDefault();
      computePotential();
      resultBox.classList.add("highlight");
      window.setTimeout(() => resultBox.classList.remove("highlight"), 1200);
    });

    computePotential();
  }

  const tracker = document.querySelector("[data-impact-tracker]");
  if (tracker) {
    const items = tracker.querySelectorAll("[data-impact-item]");
    const animateItem = (item) => {
      const targetValue = parseFloat(item.dataset.target) || 0;
      let current = 0;
      const increment = targetValue / 120;
      const counter = item.querySelector("strong");
      const suffix = item.dataset.suffix || "";
      const fps = 16;

      const tick = () => {
        current += increment;
        if (current >= targetValue) {
          current = targetValue;
          counter.textContent = `${targetValue.toLocaleString("es-ES")}${suffix}`;
        } else {
          counter.textContent = `${Math.round(current).toLocaleString("es-ES")}${suffix}`;
          window.setTimeout(tick, fps);
        }
      };
      tick();
    };

    const trackerObserver = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateItem(entry.target);
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.4 }
    );

    items.forEach((item) => trackerObserver.observe(item));
  }

  const toast = document.querySelector("[data-toast]");
  const forms = document.querySelectorAll("form[data-redirect='thank-you']");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (toast) {
        toast.textContent = form.dataset.toastMessage || "Solicitud registrada. Redirigiendo...";
        toast.classList.add("is-visible");
        window.setTimeout(() => toast.classList.remove("is-visible"), 1600);
      }
      window.setTimeout(() => {
        window.location.href = form.getAttribute("action") || "thank-you.html";
      }, 1550);
    });
  });

  const animatedBlocks = document.querySelectorAll("[data-animate]");
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.25 }
  );
  animatedBlocks.forEach((block) => revealObserver.observe(block));
});