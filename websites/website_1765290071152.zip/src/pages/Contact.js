```javascript
import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    nom: '',
    organisation: '',
    email: '',
    sujet: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.nom.trim()) newErrors.nom = 'Merci de renseigner un nom.';
    if (!formData.email.trim()) {
      newErrors.email = 'Merci de renseigner une adresse email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Le format de l’adresse email doit être valide.';
    }
    if (!formData.message.trim()) newErrors.message = 'Merci de préciser votre demande.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <>
      <Seo
        title="Contact | French Automotive Sector Analysis"
        description="Coordonnées complètes de la rédaction et formulaire de contact pour French Automotive Sector Analysis."
        keywords="contact, rédaction, industrie automobile française"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact</h1>
          <p>
            La rédaction répond aux sollicitations relatives aux dossiers analytiques, aux interviews et aux demandes de précision.
            Les informations transmises sont traitées de manière confidentielle.
          </p>
        </div>
      </section>
      <section className={styles.section}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.details}>
              <h2>Coordonnées officielles</h2>
              <ul className={styles.infoList}>
                <li>
                  <strong>Adresse :</strong> Le Carrefour de l'Analyse, 45 Avenue de la Grande Armée, 75116 Paris, France
                </li>
                <li>
                  <strong>Téléphone :</strong> +33 (0)1 45 00 12 34
                </li>
                <li>
                  <strong>Email :</strong>{' '}
                  <a href="mailto:redaction@french-auto-analysis.fr">redaction@french-auto-analysis.fr</a>
                </li>
              </ul>
              <p>
                Un délai de réponse cible de deux jours ouvrés est appliqué pour chaque message. Les demandes complexes peuvent
                nécessiter des vérifications complémentaires avant retour.
              </p>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Formulaire de contact</h2>
              <div className={styles.field}>
                <label htmlFor="nom">Nom et prénom</label>
                <input
                  type="text"
                  id="nom"
                  name="nom"
                  value={formData.nom}
                  onChange={handleChange}
                  aria-invalid={errors.nom ? 'true' : 'false'}
                />
                {errors.nom && <span className={styles.error}>{errors.nom}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="organisation">Organisation (optionnel)</label>
                <input
                  type="text"
                  id="organisation"
                  name="organisation"
                  value={formData.organisation}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Adresse email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="sujet">Sujet</label>
                <input
                  type="text"
                  id="sujet"
                  name="sujet"
                  value={formData.sujet}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={errors.message ? 'true' : 'false'}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submitButton}>
                Envoyer
              </button>
              {submitted && (
                <p className={styles.success}>
                  Merci. Le message a été enregistré. Un membre de la rédaction vous répondra via redaction@french-auto-analysis.fr.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
```