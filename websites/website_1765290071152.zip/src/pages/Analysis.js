```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { analysisArticles } from '../data/content';
import styles from './Analysis.module.css';

const Analysis = () => {
  const sortedArticles = [...analysisArticles].sort((a, b) => new Date(b.dateISO) - new Date(a.dateISO));

  return (
    <>
      <Seo
        title="Analyses | French Automotive Sector Analysis"
        description="Analyses approfondies sur l'industrie automobile française : stratégies des constructeurs, électrification, logistique, design."
        keywords="analyse automobile, constructeurs français, électrification, logistique industrielle, transition énergétique"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Analyses approfondies</h1>
          <p>
            Dossiers transversaux dédiés aux stratégies industrielles, à la recherche technologique, à la logistique et aux
            interactions réglementaires qui façonnent l'industrie automobile française.
          </p>
        </div>
      </section>
      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            {sortedArticles.map((article) => (
              <article key={article.id} className="card">
                <div className="metaLine">
                  <span>{article.date}</span>
                  <span>Rubrique Analyse</span>
                </div>
                <h2 className={styles.title}>
                  <Link to={`/analyse/${article.slug}`}>{article.title}</Link>
                </h2>
                <p className={styles.subtitle}>{article.subtitle}</p>
                <p className={styles.summary}>{article.summary}</p>
                <div className={styles.tags}>
                  {article.tags.map((tag) => (
                    <span className="tag" key={tag}>
                      {tag}
                    </span>
                  ))}
                </div>
                <Link to={`/analyse/${article.slug}`} className={styles.readMore}>
                  Continuer vers l’analyse
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Analysis;
```