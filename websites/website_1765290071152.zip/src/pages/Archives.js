```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import { analysisArticles, interviewArticles } from '../data/content';
import styles from './Archives.module.css';

const Archives = () => {
  const archiveItems = [
    ...analysisArticles.map((item) => ({ ...item, type: 'Analyse' })),
    ...interviewArticles.map((item) => ({ ...item, type: 'Interview' }))
  ].sort((a, b) => new Date(b.dateISO) - new Date(a.dateISO));

  const groupedByYear = archiveItems.reduce((acc, item) => {
    const year = new Date(item.dateISO).getFullYear();
    if (!acc[year]) {
      acc[year] = [];
    }
    acc[year].push(item);
    return acc;
  }, {});

  const years = Object.keys(groupedByYear).sort((a, b) => Number(b) - Number(a));

  return (
    <>
      <Seo
        title="Archives | French Automotive Sector Analysis"
        description="Index chronologique des analyses, interviews et dossiers publiés par French Automotive Sector Analysis."
        keywords="archives automobile, dossiers, interviews, analyses, industrie française"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Archives</h1>
          <p>
            Les archives regroupent l’ensemble des contenus publiés, classés par année et par typologie. Chaque entrée renvoie vers
            l’article détaillé afin de faciliter la consultation et le suivi temporel des transformations du secteur.
          </p>
        </div>
      </section>
      <section className={styles.archiveSection}>
        <div className="container">
          <div className={styles.timeline}>
            {years.map((year) => (
              <div key={year} className={styles.yearBlock}>
                <div className={styles.yearLabel}>{year}</div>
                <div className={styles.entries}>
                  {groupedByYear[year].map((item) => (
                    <article key={item.slug} className={styles.entry}>
                      <span className={item.type === 'Analyse' ? styles.badgeAnalysis : styles.badgeInterview}>
                        {item.type}
                      </span>
                      <div>
                        <Link to={`/${item.type === 'Analyse' ? 'analyse' : 'interviews'}/${item.slug}`} className={styles.entryTitle}>
                          {item.title}
                        </Link>
                        <p className={styles.entryInfo}>
                          {item.date} — {item.subtitle}
                        </p>
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Archives;
```