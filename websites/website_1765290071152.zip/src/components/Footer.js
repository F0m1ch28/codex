```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className="container">
      <div className={styles.grid}>
        <div>
          <h3 className={styles.heading}>French Automotive Sector Analysis</h3>
          <p className={styles.text}>
            Publication analytique dédiée à l'industrie automobile française, à la transition énergétique et aux dynamiques
            d'innovation. Les contenus sont élaborés selon une méthodologie indépendante et documentée.
          </p>
        </div>
        <div>
          <h4 className={styles.subheading}>Navigation</h4>
          <ul className={styles.list}>
            <li>
              <Link to="/analyse">Analyses</Link>
            </li>
            <li>
              <Link to="/interviews">Interviews</Link>
            </li>
            <li>
              <Link to="/archives">Archives</Link>
            </li>
            <li>
              <Link to="/a-propos">À propos</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.subheading}>Références légales</h4>
          <ul className={styles.list}>
            <li>
              <Link to="/conditions-utilisation">Conditions d'utilisation</Link>
            </li>
            <li>
              <Link to="/politique-de-confidentialite">Politique de confidentialité</Link>
            </li>
            <li>
              <Link to="/politique-de-cookies">Politique de cookies</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.subheading}>Contact rédaction</h4>
          <address className={styles.address}>
            Le Carrefour de l'Analyse
            <br />
            45 Avenue de la Grande Armée
            <br />
            75116 Paris, France
            <br />
            Tél. : +33 (0)1 45 00 12 34
            <br />
            <a href="mailto:redaction@french-auto-analysis.fr">redaction@french-auto-analysis.fr</a>
          </address>
        </div>
      </div>
      <div className={styles.bottomLine}>
        © {new Date().getFullYear()} French Automotive Sector Analysis. Tous droits réservés.
      </div>
    </div>
  </footer>
);

export default Footer;
```