```javascript
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          French Automotive Sector Analysis
        </NavLink>
        <button
          className={styles.mobileToggle}
          type="button"
          onClick={toggleMenu}
          aria-label="Ouvrir le menu principal"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Navigation principale">
          <NavLink
            to="/"
            end
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Accueil
          </NavLink>
          <NavLink
            to="/analyse"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Analyse
          </NavLink>
          <NavLink
            to="/interviews"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Interviews
          </NavLink>
          <NavLink
            to="/archives"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Archives
          </NavLink>
          <NavLink
            to="/a-propos"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            À propos
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
            onClick={closeMenu}
          >
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;
```