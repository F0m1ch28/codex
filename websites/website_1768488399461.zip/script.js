document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteNav.classList.toggle('is-open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 900) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    siteNav.classList.remove('is-open');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('[data-component="cookie-banner"]');
    const acceptBtn = cookieBanner ? cookieBanner.querySelector('[data-cookie-accept]') : null;
    const declineBtn = cookieBanner ? cookieBanner.querySelector('[data-cookie-decline]') : null;
    const consentKey = 'lpqCookieConsent';

    const setConsent = (value) => {
        localStorage.setItem(consentKey, value);
        if (cookieBanner) {
            cookieBanner.classList.remove('is-visible');
        }
    };

    if (cookieBanner) {
        const currentConsent = localStorage.getItem(consentKey);
        if (!currentConsent) {
            cookieBanner.classList.add('is-visible');
        }
        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => setConsent('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => setConsent('declined'));
        }
    }

    const footerYear = document.getElementById('footer-year');
    if (footerYear) {
        footerYear.textContent = new Date().getFullYear().toString();
    }
});