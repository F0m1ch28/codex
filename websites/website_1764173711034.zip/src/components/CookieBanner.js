import React, { useState, useEffect } from "react";

const STORAGE_KEY = "apexMomentumCookieConsent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <h4>We Value Your Privacy</h4>
        <p>
          We use cookies to personalize content and analyze our traffic. By clicking “Accept”, you consent to our cookie policy.
        </p>
      </div>
      <div className="cookie-banner__actions">
        <button className="btn btn--outline btn--sm" onClick={() => setVisible(false)}>
          Maybe Later
        </button>
        <button className="btn btn--primary btn--sm" onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;