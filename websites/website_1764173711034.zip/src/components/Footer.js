import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <NavLink to="/" className="footer-logo">
            <span className="logo-mark">A</span>
            <span className="logo-text">
              Apex <span>Momentum</span>
            </span>
          </NavLink>
          <p className="footer-subtitle">
            Apex Momentum empowers ambitious organizations with strategy, design, and technology that fuel measurable growth.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Company</h4>
          <ul className="footer-links">
            <li>
              <NavLink to="/about">About</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Contact</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="footer-heading">Resources</h4>
          <ul className="footer-links">
            <li>
              <NavLink to="/terms">Terms &amp; Conditions</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Privacy Policy</NavLink>
            </li>
            <li>
              <a href="#faq-section">FAQs</a>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="footer-heading">Stay in the Loop</h4>
          <p className="footer-subtitle">Subscribe for actionable insights and curated digital trends.</p>
          <form
            className="footer-form"
            onSubmit={(e) => {
              e.preventDefault();
              alert("Thank you for subscribing! Expect our next insight soon.");
            }}
          >
            <label htmlFor="footer-email" className="sr-only">
              Email address
            </label>
            <input id="footer-email" type="email" placeholder="you@company.com" required />
            <button type="submit" className="btn btn--primary btn--sm">
              Join
            </button>
          </form>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; {currentYear} Apex Momentum. All rights reserved.</p>
        <div className="footer-bottom-links">
          <NavLink to="/privacy">Privacy</NavLink>
          <NavLink to="/terms">Terms</NavLink>
        </div>
      </div>
    </footer>
  );
};

export default Footer;