import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
      <div className="container header-container">
        <div className="logo-group">
          <NavLink to="/" className="logo-link" aria-label="Apex Momentum Home">
            <span className="logo-mark">A</span>
            <span className="logo-text">
              Apex <span>Momentum</span>
            </span>
          </NavLink>
        </div>
        <nav className={`main-nav ${menuOpen ? "main-nav--open" : ""}`} aria-label="Primary">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/about" className="nav-link">
            About
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact
          </NavLink>
        </nav>
        <div className="header-cta">
          <NavLink to="/contact" className="btn btn--sm btn--primary">
            Start a Project
          </NavLink>
        </div>
        <button
          className={`menu-toggle ${menuOpen ? "menu-toggle--open" : ""}`}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-label="Toggle navigation menu"
        >
          <span />
          <span />
          <span />
        </button>
        <div className={`mobile-overlay ${menuOpen ? "mobile-overlay--visible" : ""}`} />
      </div>
    </header>
  );
};

export default Header;