import React, { useState } from "react";

const services = [
  {
    title: "Executive Alignment Sprints",
    description:
      "Four-week sprints aligning leadership on goals, success metrics, and prioritized initiatives.",
    deliverables: ["Strategic narrative", "Opportunity backlog", "Measurement framework", "Roadmap & playbooks"],
  },
  {
    title: "Experience Design Lab",
    description:
      "Immersive design engagements focused on human-centered research, prototyping, and validation.",
    deliverables: ["Journeys & personas", "Experience architecture", "Design system updates", "Prototype testing"],
  },
  {
    title: "Product Acceleration",
    description:
      "Dedicated pods to launch or scale digital products with rapid iteration and aligned governance.",
    deliverables: ["Product roadmap", "Sprint execution", "Quality assurance", "Launch enablement"],
  },
  {
    title: "Automation & AI Integration",
    description:
      "Identify automation opportunities and embed AI assistants to streamline workflows and insights.",
    deliverables: ["Automation roadmap", "AI use-case modeling", "Integration architecture", "Change management"],
  },
];

const Services = () => {
  const [activeService, setActiveService] = useState(0);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container page-hero__content">
          <p className="eyebrow">Services</p>
          <h1>Momentum-building services engineered for impact</h1>
          <p>
            Whether you need to modernize customer journeys, launch new products, or operationalize AI, our cross-functional team brings clarity and speed to every engagement.
          </p>
        </div>
      </section>

      <section className="services-tabs-section">
        <div className="container">
          <div className="services-tabs">
            <aside className="services-tabs__list" role="tablist" aria-orientation="vertical">
              {services.map((service, index) => (
                <button
                  key={service.title}
                  role="tab"
                  className={`services-tab ${activeService === index ? "services-tab--active" : ""}`}
                  onClick={() => setActiveService(index)}
                  aria-selected={activeService === index}
                >
                  {service.title}
                </button>
              ))}
            </aside>
            <div className="services-tab__content" role="tabpanel">
              <h2>{services[activeService].title}</h2>
              <p>{services[activeService].description}</p>
              <h3>Key deliverables</h3>
              <ul className="deliverables-list">
                {services[activeService].deliverables.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <button className="btn btn--primary btn--lg">Book a discovery call</button>
            </div>
          </div>
        </div>
      </section>

      <section className="capabilities-section">
        <div className="container capabilities-grid">
          <article>
            <h2>Transformation catalysts</h2>
            <p>
              We embed alongside your teams, bringing the governance, rituals, and insights required to keep work aligned—and moving at the pace of change.
            </p>
          </article>
          <article className="capability-card">
            <h3>Embedded squads</h3>
            <p>Cross-functional pods that deliver end-to-end experiences with continuous optimization.</p>
          </article>
          <article className="capability-card">
            <h3>Data & analytics</h3>
            <p>Instrument performance dashboards, customer intelligence, and predictive modeling.</p>
          </article>
          <article className="capability-card">
            <h3>Change enablement</h3>
            <p>Stakeholder communication, training, and adoption plans that ensure sustained momentum.</p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Services;