import React from "react";

const Terms = () => (
  <div className="page legal-page">
    <section className="page-hero">
      <div className="container page-hero__content">
        <p className="eyebrow">Legal</p>
        <h1>Terms &amp; Conditions</h1>
        <p>Effective January 2024</p>
      </div>
    </section>

    <section className="legal-section">
      <div className="container legal-content">
        <h2>1. Acceptance of terms</h2>
        <p>
          By accessing Apex Momentum’s website or engaging our services, you agree to comply with these Terms &amp; Conditions and all applicable laws. If you do not agree, please refrain from using our site.
        </p>

        <h2>2. Services</h2>
        <p>
          Project scope, deliverables, and fees are defined in engagement agreements. Any modifications require written approval by both parties.
        </p>

        <h2>3. Intellectual property</h2>
        <p>
          We retain intellectual property rights to proprietary methodologies. Client-owned assets developed during engagements will be outlined in the signed agreement.
        </p>

        <h2>4. Confidentiality</h2>
        <p>
          Both parties agree to safeguard confidential information shared during the engagement, except where disclosure is required by law.
        </p>

        <h2>5. Limitation of liability</h2>
        <p>
          Apex Momentum is not liable for indirect or consequential damages arising from the use of our services or website.
        </p>

        <h2>6. Governing law</h2>
        <p>
          These terms are governed by the laws of the State of New York, without regard to conflict of law principles.
        </p>
      </div>
    </section>
  </div>
);

export default Terms;