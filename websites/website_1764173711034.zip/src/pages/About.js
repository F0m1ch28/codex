import React from "react";

const teamMembers = [
  {
    name: "Jordan Patel",
    role: "Managing Partner",
    bio: "Former Fortune 100 digital leader with 15+ years driving transformation across global enterprises.",
    image: "https://picsum.photos/400/400?random=61",
  },
  {
    name: "Maya Adkins",
    role: "Head of Experience Design",
    bio: "Designs human-centered systems that elevate customer experience and brand equity.",
    image: "https://picsum.photos/400/400?random=62",
  },
  {
    name: "Ethan Rivera",
    role: "Director of Engineering",
    bio: "Architects scalable platforms and leads high-performing engineering squads.",
    image: "https://picsum.photos/400/400?random=63",
  },
  {
    name: "Nina Forester",
    role: "VP, Growth Strategy",
    bio: "Partners with C-suites to map growth opportunities and unlock revenue potential.",
    image: "https://picsum.photos/400/400?random=64",
  },
];

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container page-hero__content">
          <p className="eyebrow">About Apex Momentum</p>
          <h1>Dedicated to compounding growth for ambitious brands</h1>
          <p>
            We are a collective of strategists, designers, and builders who have led digital transformation within some of the world’s most admired organizations. Our mission is to help executive teams unlock their next wave of momentum by pairing clarity of vision with precision execution.
          </p>
        </div>
      </section>

      <section className="mission-section">
        <div className="container mission-grid">
          <article>
            <h2>Why we exist</h2>
            <p>
              Apex Momentum was founded to bridge the gap between strategy and execution. We believe every customer touchpoint should be purposeful, data-infused, and crafted with empathy. Our work is anchored in measurable outcomes, transparent collaboration, and relentless curiosity.
            </p>
          </article>
          <article>
            <h3>Our core values</h3>
            <ul className="values-list">
              <li>
                <strong>Clarity:</strong> We simplify complexity and align teams around shared outcomes.
              </li>
              <li>
                <strong>Momentum:</strong> We operate with disciplined speed to build lasting advantage.
              </li>
              <li>
                <strong>Craft:</strong> We sweat the details, ensuring excellence across strategy, design, and code.
              </li>
              <li>
                <strong>Integrity:</strong> We earn trust through transparency, accountability, and partnership.
              </li>
            </ul>
          </article>
        </div>
      </section>

      <section className="team-section page-team">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Leadership Team</p>
            <h2>The minds guiding digital momentum</h2>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <article key={member.name} className="team-card">
                <div className="team-image-wrap">
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </div>
                <h3>{member.name}</h3>
                <p className="team-role">{member.role}</p>
                <p>{member.bio}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="impact-section">
        <div className="container impact-grid">
          <article>
            <h2>Impact pillars</h2>
            <p>
              We drive transformation across three pillars—strategy, experience, and technology. Each engagement blends these disciplines to deliver measurable value.
            </p>
          </article>
          <article className="impact-card">
            <h3>Strategy Enablement</h3>
            <p>Market assessments, product roadmaps, growth modeling, and executive alignment sessions.</p>
          </article>
          <article className="impact-card">
            <h3>Experience Design</h3>
            <p>Research, journey mapping, UX/UI design, and brand systems that inspire enduring loyalty.</p>
          </article>
          <article className="impact-card">
            <h3>Technology Delivery</h3>
            <p>Cloud-native builds, integration, data architecture, AI automation, and performance optimization.</p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default About;