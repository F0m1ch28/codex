import React from "react";

const Privacy = () => (
  <div className="page legal-page">
    <section className="page-hero">
      <div className="container page-hero__content">
        <p className="eyebrow">Legal</p>
        <h1>Privacy Policy</h1>
        <p>Effective January 2024</p>
      </div>
    </section>

    <section className="legal-section">
      <div className="container legal-content">
        <h2>1. Information we collect</h2>
        <p>
          We collect personal information you voluntarily provide (such as name, email, company) and analytics data captured via cookies and similar technologies.
        </p>

        <h2>2. How we use information</h2>
        <p>
          Information enables us to respond to inquiries, customize experiences, deliver services, and improve our offerings.
        </p>

        <h2>3. Sharing &amp; disclosure</h2>
        <p>
          We do not sell personal data. We may share information with trusted partners who assist in delivering our services, subject to confidentiality obligations.
        </p>

        <h2>4. Data retention</h2>
        <p>
          We retain data only as long as necessary for legitimate business purposes or as required by law.
        </p>

        <h2>5. Your rights</h2>
        <p>
          You may request access, correction, or deletion of your personal information by contacting privacy@apexmomentum.com.
        </p>

        <h2>6. Updates</h2>
        <p>
          We may update this policy periodically. Continued use of our site after changes constitutes acceptance of the updated policy.
        </p>
      </div>
    </section>
  </div>
);

export default Privacy;