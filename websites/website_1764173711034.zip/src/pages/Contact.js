import React, { useState } from "react";

const initialState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your full name.";
    if (!formData.email.trim()) {
      newErrors.email = "Please provide a valid email address.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "This email address is not valid.";
    }
    if (!formData.company.trim()) newErrors.company = "Enter your company or organization name.";
    if (!formData.message.trim() || formData.message.length < 20) {
      newErrors.message = "Share a brief overview of your goals (at least 20 characters).";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container page-hero__content">
          <p className="eyebrow">Contact</p>
          <h1>Let’s create unstoppable momentum together</h1>
          <p>
            Share a quick overview of your goals. A partner director will respond within one business day with next steps.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <div>
            <h2>Start the conversation</h2>
            <p>
              We collaborate with executive teams, product leaders, and founders to build enduring digital capabilities. From diagnostics to full-scale delivery, we are ready to help.
            </p>
            <div className="contact-details">
              <p><strong>Email:</strong> hello@apexmomentum.com</p>
              <p><strong>Headquarters:</strong> 845 Momentum Drive, Suite 600, New York, NY</p>
              <p><strong>Office Hours:</strong> Monday - Friday, 8:30am - 6:00pm ET</p>
            </div>
          </div>
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Full name</label>
              <input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                aria-invalid={!!errors.name}
                aria-describedby="name-error"
              />
              {errors.name && <span id="name-error" className="form-error">{errors.name}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Email address</label>
              <input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                aria-invalid={!!errors.email}
                aria-describedby="email-error"
              />
              {errors.email && <span id="email-error" className="form-error">{errors.email}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="company">Company / Organization</label>
              <input
                id="company"
                type="text"
                value={formData.company}
                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                aria-invalid={!!errors.company}
                aria-describedby="company-error"
              />
              {errors.company && <span id="company-error" className="form-error">{errors.company}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="message">What are you looking to achieve?</label>
              <textarea
                id="message"
                rows="5"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                aria-invalid={!!errors.message}
                aria-describedby="message-error"
              />
              {errors.message && <span id="message-error" className="form-error">{errors.message}</span>}
            </div>
            <button type="submit" className="btn btn--primary btn--lg">
              Submit inquiry
            </button>
            {submitted && (
              <p className="form-success">
                Thank you! We’ve received your inquiry and will be in touch shortly.
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;