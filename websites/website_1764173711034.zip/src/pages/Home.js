import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";

const statsData = [
  { label: "Projects Delivered", value: 240 },
  { label: "Client Satisfaction", value: 98 },
  { label: "Revenue Growth Enabled", value: 320, suffix: "%" },
  { label: "Countries Supported", value: 14 },
];

const servicesData = [
  {
    title: "Digital Strategy",
    description: "Align your organization around data-backed growth roadmaps and measurable KPIs.",
    icon: "🎯",
  },
  {
    title: "Brand Experience",
    description: "Design unified brand systems that translate seamlessly across every touchpoint.",
    icon: "✨",
  },
  {
    title: "Product Innovation",
    description: "Launch human-centered digital products with rapid experimentation and prototyping.",
    icon: "🚀",
  },
  {
    title: "Automation & AI",
    description: "Unlock efficiency with intelligent workflows and AI-assisted customer experiences.",
    icon: "🤖",
  },
];

const processSteps = [
  {
    step: "01",
    title: "Discover & Align",
    description: "We begin with immersive workshops to distill objectives, audiences, and success indicators.",
  },
  {
    step: "02",
    title: "Design & Prototype",
    description: "Our strategists and designers co-create high fidelity experiences ready for stakeholder validation.",
  },
  {
    step: "03",
    title: "Build & Integrate",
    description: "Engineers deliver scalable, accessible solutions with enterprise-grade security at the core.",
  },
  {
    step: "04",
    title: "Optimize & Scale",
    description: "Continuous insights, growth experiments, and lifecycle management keep momentum alive.",
  },
];

const testimonials = [
  {
    quote:
      "Apex Momentum transformed our digital ecosystem. We saw a 3x uplift in conversions within the first 90 days.",
    name: "Leila Armstrong",
    role: "Chief Growth Officer, Stratos Labs",
  },
  {
    quote:
      "Their team became an extension of ours—strategic, proactive, and laser-focused on outcomes.",
    name: "Marcus Chen",
    role: "VP Digital, Horizon Global",
  },
  {
    quote:
      "From discovery to launch, Apex Momentum delivered flawless execution and measurable ROI.",
    name: "Amelia Wright",
    role: "Director of Product, NovaCore",
  },
];

const teamPreview = [
  {
    name: "Jordan Patel",
    role: "Managing Partner",
    image: "https://picsum.photos/400/400?random=31",
  },
  {
    name: "Maya Adkins",
    role: "Head of Experience Design",
    image: "https://picsum.photos/400/400?random=32",
  },
  {
    name: "Ethan Rivera",
    role: "Director of Engineering",
    image: "https://picsum.photos/400/400?random=33",
  },
];

const projectsData = [
  {
    id: 1,
    title: "Stratos Labs Platform",
    category: "Product",
    image: "https://picsum.photos/1200/800?random=41",
  },
  {
    id: 2,
    title: "NovaCore AI Suite",
    category: "Innovation",
    image: "https://picsum.photos/1200/800?random=42",
  },
  {
    id: 3,
    title: "Horizon Global Rebrand",
    category: "Branding",
    image: "https://picsum.photos/1200/800?random=43",
  },
  {
    id: 4,
    title: "Velocity Marketing Engine",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=44",
  },
];

const faqItems = [
  {
    question: "How do you tailor solutions for different industries?",
    answer:
      "We partner closely with internal teams to uncover industry nuances and customer behaviors, then craft modular frameworks that flex across markets.",
  },
  {
    question: "What does engagement look like after launch?",
    answer:
      "Our optimization squad tracks performance, conducts experiments, and provides ongoing roadmap leadership to sustain momentum.",
  },
  {
    question: "Do you work with existing platforms or only new builds?",
    answer:
      "Both. We modernize legacy systems, integrate cloud-native solutions, and build net-new products depending on business objectives.",
  },
  {
    question: "What is your typical project timeline?",
    answer:
      "Most engagements range from 8 to 20 weeks depending on scope. We define clear milestones, deliverables, and success metrics from day one.",
  },
];

const blogPosts = [
  {
    title: "Designing Adaptive Customer Journeys in 2024",
    excerpt: "How to pair behavioral data with predictive insights to orchestrate personalized moments at scale.",
    image: "https://picsum.photos/800/600?random=51",
  },
  {
    title: "The Automation Flywheel: Building Momentum with AI",
    excerpt: "Discover a pragmatic framework for capturing value through AI-assisted automation.",
    image: "https://picsum.photos/800/600?random=52",
  },
  {
    title: "Reimagining KPIs for Product-Led Growth",
    excerpt: "Move beyond vanity metrics with a modern measurement stack for product organizations.",
    image: "https://picsum.photos/800/600?random=53",
  },
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("All");
  const [activeFAQ, setActiveFAQ] = useState(null);
  const [counterValues, setCounterValues] = useState(statsData.map(() => 0));

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const target = stat.value;
      const duration = 1200;
      const increment = target / (duration / 16);
      return setInterval(() => {
        setCounterValues((prev) => {
          const updated = [...prev];
          if (updated[index] < target) {
            updated[index] = Math.min(Math.round(updated[index] + increment), target);
          }
          return updated;
        });
      }, 16);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === "All"
      ? projectsData
      : projectsData.filter((project) => project.category === projectFilter);

  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="container hero-grid">
          <div className="hero-text">
            <p className="eyebrow">Strategic Transformation &amp; Execution</p>
            <h1>
              Accelerate growth with a partner built for <span>digital momentum</span>.
            </h1>
            <p className="lead">
              Apex Momentum powers organizations to launch, optimize, and scale digital products with clarity and conviction. From strategy sprints to enterprise-grade builds—momentum starts here.
            </p>
            <div className="hero-actions">
              <NavLink to="/contact" className="btn btn--primary btn--lg hero-cta">
                Book a Strategy Call
              </NavLink>
              <NavLink to="/services" className="btn btn--ghost btn--lg">
                Explore Services
              </NavLink>
            </div>
            <div className="hero-meta">
              <div>
                <span className="hero-meta__value">4.9/5</span>
                <span className="hero-meta__label">Client Experience</span>
              </div>
              <div>
                <span className="hero-meta__value">Top 10</span>
                <span className="hero-meta__label">Growth Partner</span>
              </div>
            </div>
          </div>
          <div className="hero-media">
            <div className="hero-image-wrap">
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Business leaders collaborating on digital transformation strategy"
                loading="lazy"
              />
              <div className="hero-badge">
                <span>Trusted by teams shaping the next decade of digital.</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stats-section">
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <article key={stat.label} className="stat-card">
              <span className="stat-value">
                {counterValues[index]}
                {stat.suffix || "+"}
              </span>
              <span className="stat-label">{stat.label}</span>
            </article>
          ))}
        </div>
      </section>

      <section className="services-section" id="services">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Capabilities</p>
            <h2>Integrated services engineered for outcomes</h2>
            <p>
              Every engagement blends research, design, and technology so you can launch with confidence and scale with resilience.
            </p>
          </div>
          <div className="services-grid">
            {servicesData.map((service) => (
              <article key={service.title} className="service-card">
                <div className="service-icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <NavLink to="/services" className="service-link">
                  Learn more
                </NavLink>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process-section">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">How We Work</p>
            <h2>Momentum framework from discovery to scale</h2>
            <p>
              Our proven methodology orchestrates discovery, execution, and optimization to deliver sustainable competitive advantage.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step) => (
              <article key={step.step} className="process-card">
                <span className="process-step">{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials-section">
        <div className="container testimonials-container">
          <div className="section-header">
            <p className="eyebrow">Client Stories</p>
            <h2>Momentum realized through partnership</h2>
          </div>
          <div className="testimonial-carousel">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`testimonial-card ${activeTestimonial === index ? "testimonial-card--active" : ""}`}
                aria-hidden={activeTestimonial !== index}
              >
                <p className="testimonial-quote">“{testimonial.quote}”</p>
                <div className="testimonial-meta">
                  <span className="testimonial-name">{testimonial.name}</span>
                  <span className="testimonial-role">{testimonial.role}</span>
                </div>
              </article>
            ))}
          </div>
          <div className="testimonial-controls">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`dot ${activeTestimonial === index ? "dot--active" : ""}`}
                aria-label={`Show testimonial ${index + 1}`}
                onClick={() => setActiveTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="team-section">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Leadership</p>
            <h2>An elite team of strategists, makers, and optimizers</h2>
            <p>
              We are former founders, growth leaders, and design thinkers dedicated to maximizing impact for modern organizations.
            </p>
          </div>
          <div className="team-grid">
            {teamPreview.map((member) => (
              <article key={member.name} className="team-card">
                <div className="team-image-wrap">
                  <img
                    src={member.image}
                    alt={`${member.name}, ${member.role}`}
                    loading="lazy"
                  />
                </div>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </article>
            ))}
          </div>
          <div className="team-cta">
            <NavLink to="/about" className="btn btn--outline">
              Meet the full team
            </NavLink>
          </div>
        </div>
      </section>

      <section className="projects-section" id="projects">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Selected Work</p>
            <h2>Proof that momentum scales</h2>
            <p>
              Explore how we empower industry leaders to break through inertia and deliver customer-first experiences.
            </p>
          </div>
          <div className="project-filters">
            {["All", "Strategy", "Branding", "Product", "Innovation"].map((category) => (
              <button
                key={category}
                className={`filter-chip ${projectFilter === category ? "filter-chip--active" : ""}`}
                onClick={() => setProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article key={project.id} className="project-card">
                <div className="project-image-wrap">
                  <img
                    src={project.image}
                    alt={`${project.title} - ${project.category} case study`}
                    loading="lazy"
                  />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <NavLink to="/services" className="project-link">
                    View case study
                  </NavLink>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section" id="faq-section">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">FAQ</p>
            <h2>Answers for decision makers</h2>
            <p>
              We ensure clarity before engagements begin. If you have specific questions, our team is ready to help.
            </p>
          </div>
          <div className="faq-accordion">
            {faqItems.map((item, index) => (
              <article key={item.question} className={`faq-item ${activeFAQ === index ? "faq-item--open" : ""}`}>
                <button
                  className="faq-question"
                  onClick={() => setActiveFAQ(activeFAQ === index ? null : index)}
                  aria-expanded={activeFAQ === index}
                >
                  <span>{item.question}</span>
                  <span className="faq-icon">{activeFAQ === index ? "−" : "+"}</span>
                </button>
                <div className="faq-answer">
                  <p>{item.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Insights</p>
            <h2>Fresh momentum intelligence</h2>
            <p>
              Stay ahead of what’s next in growth strategy, experience design, and AI-enabled execution.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article key={post.title} className="blog-card">
                <div className="blog-image-wrap">
                  <img
                    src={post.image}
                    alt={`${post.title} article preview`}
                    loading="lazy"
                  />
                </div>
                <div className="blog-content">
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a className="blog-link" href="#!">
                    Read article
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-container">
          <div className="cta-text">
            <h2>Ready to amplify your digital momentum?</h2>
            <p>
              Book a 30-minute strategy session and walk away with tangible opportunities to accelerate revenue, retention, and brand loyalty.
            </p>
          </div>
          <div className="cta-actions">
            <NavLink to="/contact" className="btn btn--primary btn--lg">
              Schedule Strategy Session
            </NavLink>
            <NavLink to="/services" className="btn btn--ghost btn--lg">
              Download Capabilities Deck
            </NavLink>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;