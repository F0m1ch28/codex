import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Portfolio.module.css';

const projects = [
  {
    title: 'Эстетика света',
    category: 'Брендинг',
    description: 'Айдентика для сети салонов света: типографика, упаковка, digital.',
    image: 'https://picsum.photos/id/111/720/520'
  },
  {
    title: 'Пульс мегаполиса',
    category: 'Иллюстрация',
    description: 'Серия иллюстраций для журнала о городской культуре.',
    image: 'https://picsum.photos/id/120/720/520'
  },
  {
    title: 'Глобальный форум',
    category: 'Инсталляция',
    description: 'Интерактивная выставка о будущем креативных индустрий.',
    image: 'https://picsum.photos/id/121/720/520'
  },
  {
    title: 'Sea Breeze',
    category: 'Брендинг',
    description: 'Визуальный язык для курортного отеля, мерч и digital-среда.',
    image: 'https://picsum.photos/id/130/720/520'
  },
  {
    title: 'Analog Future',
    category: 'Motion',
    description: 'Серия motion-видеороликов для технологической конференции.',
    image: 'https://picsum.photos/id/140/720/520'
  },
  {
    title: 'Эхо природы',
    category: 'Иллюстрация',
    description: 'Коллекция постеров, вдохновлённая природными формами и текстурами.',
    image: 'https://picsum.photos/id/150/720/520'
  }
];

const categories = ['Все', 'Брендинг', 'Иллюстрация', 'Инсталляция', 'Motion'];

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState('Все');

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Все') return projects;
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>Портфолио ArtVista — визуальные проекты и арт-работы</title>
        <meta
          name="description"
          content="Галерея проектов ArtVista: брендинг, иллюстрация, инсталляции и motion графика. Изучите наши визуальные решения."
        />
      </Helmet>
      <section className={`${styles.hero} container`}>
        <h1>Портфолио ArtVista</h1>
        <p>
          Мы создаём выразительные визуальные миры — от минималистичных айдентик до иммерсивных
          инсталляций. Выберите направление, чтобы посмотреть подборку проектов.
        </p>
      </section>

      <section className="container">
        <div className={styles.filters}>
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${
                activeCategory === category ? styles.active : ''
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.grid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.card}>
              <div className={styles.imageWrap}>
                <img src={project.image} alt={`Портфолио ArtVista: ${project.title}`} />
                <div className={styles.overlay}>
                  <p>{project.description}</p>
                </div>
              </div>
              <div className={styles.cardBody}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Portfolio;