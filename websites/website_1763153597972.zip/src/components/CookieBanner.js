import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'artvista-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Мы используем cookie, чтобы улучшить ваш опыт и вдохновение на сайте. Подробнее в{' '}
        <a href="/cookie-policy">Политике Cookie</a>.
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Согласен(а)
      </button>
    </div>
  );
};

export default CookieBanner;