document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('is-open')) {
          navToggle.setAttribute('aria-expanded', 'false');
          siteNav.classList.remove('is-open');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    const userChoice = localStorage.getItem('maple-cookie-choice');

    if (userChoice) {
      cookieBanner.dataset.hidden = 'true';
    }

    const handleChoice = (choice) => {
      localStorage.setItem('maple-cookie-choice', choice);
      cookieBanner.dataset.hidden = 'true';
    };

    acceptBtn?.addEventListener('click', () => handleChoice('accepted'));
    declineBtn?.addEventListener('click', () => handleChoice('declined'));
  }

  document.querySelectorAll('[data-tab-group]').forEach(group => {
    const buttons = group.querySelectorAll('[data-tab]');
    const panels = group.querySelectorAll('[data-tab-panel]');
    if (!buttons.length || !panels.length) return;

    const activateTab = (targetId) => {
      buttons.forEach(btn => {
        const isActive = btn.dataset.tab === targetId;
        btn.setAttribute('aria-selected', String(isActive));
        btn.setAttribute('tabindex', isActive ? '0' : '-1');
      });
      panels.forEach(panel => {
        panel.hidden = panel.id !== targetId;
      });
    };

    buttons.forEach(button => {
      button.addEventListener('click', () => {
        activateTab(button.dataset.tab);
      });
      button.addEventListener('keydown', (event) => {
        if (['ArrowLeft', 'ArrowRight'].includes(event.key)) {
          event.preventDefault();
          const currentIndex = Array.from(buttons).indexOf(button);
          const delta = event.key === 'ArrowRight' ? 1 : -1;
          const nextIndex = (currentIndex + delta + buttons.length) % buttons.length;
          buttons[nextIndex].focus();
          buttons[nextIndex].click();
        }
      });
    });

    activateTab(buttons[0].dataset.tab);
  });

  document.querySelectorAll('.accordion button').forEach(button => {
    const panel = button.nextElementSibling;
    if (panel) panel.hidden = true;

    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!expanded));
      if (panel) {
        panel.hidden = expanded;
      }
    });
  });

  const contactForm = document.querySelector('#contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      if (!contactForm.checkValidity()) {
        contactForm.classList.add('form-invalid');
        return;
      }
      event.preventDefault();
      contactForm.reset();
      alert('Thank you. Our analytics advisors will respond within one business day.');
    });
  }
});