document.addEventListener('DOMContentLoaded', function () {
  var navToggle = document.querySelector('.nav-toggle');
  var siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      var isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    siteNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (siteNav.classList.contains('is-open')) {
          siteNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  var cookieBanner = document.querySelector('.cookie-banner');
  var acceptBtn = document.querySelector('.cookie-accept');
  var declineBtn = document.querySelector('.cookie-decline');
  var consent = localStorage.getItem('fineduCookieConsent');

  if (cookieBanner) {
    if (consent === 'accepted' || consent === 'declined') {
      cookieBanner.classList.add('hidden');
    } else {
      cookieBanner.classList.remove('hidden');
    }

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        localStorage.setItem('fineduCookieConsent', 'accepted');
        cookieBanner.classList.add('hidden');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        localStorage.setItem('fineduCookieConsent', 'declined');
        cookieBanner.classList.add('hidden');
      });
    }
  }

  var categoryButtons = document.querySelectorAll('.category-button');
  var newsCards = document.querySelectorAll('.news-card[data-category]');

  if (categoryButtons.length && newsCards.length) {
    categoryButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        var selected = button.getAttribute('data-category');

        categoryButtons.forEach(function (btn) {
          btn.classList.remove('is-active');
        });
        button.classList.add('is-active');

        newsCards.forEach(function (card) {
          var cardCategory = card.getAttribute('data-category');
          if (selected === 'all' || cardCategory === selected) {
            card.classList.remove('is-hidden');
          } else {
            card.classList.add('is-hidden');
          }
        });
      });
    });
  }

  var contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (event) {
      if (!contactForm.checkValidity()) {
        event.preventDefault();
        contactForm.classList.add('show-errors');
      }
    });
  }
});