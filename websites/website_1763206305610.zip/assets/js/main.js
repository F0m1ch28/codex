document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.getElementById('primaryNavigation');
    const scrollButton = document.getElementById('scrollToTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesButton = document.getElementById('acceptCookies');
    const navLinks = document.querySelectorAll('.main-navigation a');
    const yearSpan = document.getElementById('currentYear');
    const contactForm = document.getElementById('contactForm');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    // Mobile navigation
    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            navigation.classList.toggle('active');
        });
    }

    // Scroll to top button
    const toggleScrollButton = () => {
        if (window.scrollY > 400) {
            scrollButton.style.display = 'flex';
        } else {
            scrollButton.style.display = 'none';
        }
    };

    window.addEventListener('scroll', toggleScrollButton);

    if (scrollButton) {
        scrollButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Reset scroll on navigation link click
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // Cookie banner
    if (cookieBanner && acceptCookiesButton) {
        const cookiesAccepted = localStorage.getItem('naCookiesAccepted');
        if (!cookiesAccepted) {
            cookieBanner.classList.add('active');
        }

        acceptCookiesButton.addEventListener('click', () => {
            localStorage.setItem('naCookiesAccepted', 'true');
            cookieBanner.classList.remove('active');
        });
    }

    // Contact form submission handling
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const responseElement = contactForm.querySelector('.form-response');
            responseElement.textContent = 'Thank you for connecting with Northern Analytix. A consultant will reach out within one business day.';
            contactForm.reset();
        });
    }
});