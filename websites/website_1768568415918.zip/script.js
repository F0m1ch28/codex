document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-links a');

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (nav.classList.contains('is-open')) {
                    nav.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('halfliwhqc-consent');
        if (!storedConsent) {
            cookieBanner.classList.add('visible');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-btn');
        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const state = button.dataset.state || 'dismissed';
                localStorage.setItem('halfliwhqc-consent', state);
                cookieBanner.classList.remove('visible');

                const redirect = button.dataset.link;
                if (redirect) {
                    setTimeout(() => {
                        window.location.href = redirect;
                    }, 160);
                }
            });
        });
    }
});