document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("is-active");
      siteNav.classList.toggle("is-open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("is-open")) {
          siteNav.classList.remove("is-open");
          navToggle.classList.remove("is-active");
        }
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const consentKey = "assista_cookie_consent";

  const shouldShowCookieBanner = () => {
    return !localStorage.getItem(consentKey);
  };

  const hideCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.remove("show");
    }
  };

  if (cookieBanner && shouldShowCookieBanner()) {
    cookieBanner.classList.add("show");
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      hideCookieBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      hideCookieBanner();
    });
  }

  const searchInput = document.querySelector("[data-video-search]");
  const filterSelect = document.querySelector("[data-video-filter]");
  const videoCards = Array.from(document.querySelectorAll("[data-video-card]"));
  const emptyState = document.querySelector("[data-video-empty]");

  const applyVideoFilters = () => {
    if (!videoCards.length) {
      return;
    }

    const query = (searchInput?.value || "").trim().toLowerCase();
    const category = filterSelect?.value || "todas";

    let visibleCount = 0;

    videoCards.forEach((card) => {
      const title = card.dataset.title?.toLowerCase() || "";
      const topics = card.dataset.topics?.toLowerCase() || "";
      const cardCategory = card.dataset.category?.toLowerCase() || "";
      const matchesQuery = title.includes(query) || topics.includes(query);
      const matchesCategory = category === "todas" || category === cardCategory;

      if (matchesQuery && matchesCategory) {
        card.classList.remove("is-hidden");
        visibleCount += 1;
      } else {
        card.classList.add("is-hidden");
      }
    });

    if (emptyState) {
      if (visibleCount === 0) {
        emptyState.classList.remove("is-hidden");
      } else {
        emptyState.classList.add("is-hidden");
      }
    }
  };

  if (searchInput) {
    searchInput.addEventListener("input", applyVideoFilters);
  }

  if (filterSelect) {
    filterSelect.addEventListener("change", applyVideoFilters);
  }

  if (searchInput || filterSelect) {
    applyVideoFilters();
  }
});