document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    if (navToggle && navbar) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navbar.classList.toggle('open');
        });
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navbar.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieDecline = document.getElementById('cookieDecline');
    const storageKey = 'androgopgsCookieDecision';

    if (cookieBanner && cookieAccept && cookieDecline) {
        const decision = localStorage.getItem(storageKey);
        if (!decision) {
            cookieBanner.classList.add('active');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'accepted');
            cookieBanner.classList.remove('active');
        });

        cookieDecline.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});