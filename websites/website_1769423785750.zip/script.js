document.addEventListener('DOMContentLoaded', () => {
  const currentYear = new Date().getFullYear();
  document.querySelectorAll('[data-year]').forEach((el) => {
    el.textContent = currentYear;
  });

  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('is-open');
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        nav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (prefersReducedMotion.matches) {
    document.documentElement.classList.add('reduced-motion');
  }

  const observer = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18 }
  );

  document.querySelectorAll('.reveal').forEach((element) => {
    observer.observe(element);
  });

  const toast = document.querySelector('[data-toast]');
  let toastTimeout;
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 3200);
  }

  document.querySelectorAll('form.site-form').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Message received. Redirecting...');
      const action = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = action;
      }, 1400);
    });
  });

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  if (cookieBanner) {
    const storageKey = 'mh-cookie-consent';
    const savedConsent = localStorage.getItem(storageKey);
    if (savedConsent) {
      cookieBanner.classList.add('is-hidden');
    } else {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    }

    const acceptButton = cookieBanner.querySelector('[data-cookie-accept]');
    const declineButton = cookieBanner.querySelector('[data-cookie-decline]');
    const handleChoice = (value) => {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.remove('is-visible');
      cookieBanner.classList.add('is-hidden');
      showToast('Your preference has been saved.');
    };

    acceptButton?.addEventListener('click', () => handleChoice('accepted'));
    declineButton?.addEventListener('click', () => handleChoice('declined'));
  }
});