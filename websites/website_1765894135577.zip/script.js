document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navList = document.querySelector(".nav-list");
    if (navToggle && navList) {
        navToggle.addEventListener("click", function () {
            const isOpen = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isOpen));
            navList.classList.toggle("is-collapsed");
        });
        navList.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (window.innerWidth < 900) {
                    navToggle.setAttribute("aria-expanded", "false");
                    navList.classList.add("is-collapsed");
                }
            });
        });
    }

    const banner = document.querySelector("[data-cookie-banner]");
    const acceptButton = document.querySelector("[data-cookie-accept]");
    const declineButton = document.querySelector("[data-cookie-decline]");
    const storageKey = "dotstudio-cookie-consent";

    function hideBanner() {
        if (banner) {
            banner.classList.add("is-hidden");
        }
    }

    function showBanner() {
        if (banner) {
            banner.classList.remove("is-hidden");
        }
    }

    function setConsent(value) {
        try {
            localStorage.setItem(storageKey, value);
        } catch (error) {
            console.warn("Не удалось сохранить выбор cookie", error);
        }
    }

    if (banner && acceptButton && declineButton) {
        const storedPreference = localStorage.getItem(storageKey);
        if (storedPreference === "accepted" || storedPreference === "declined") {
            hideBanner();
        } else {
            showBanner();
        }

        acceptButton.addEventListener("click", function () {
            setConsent("accepted");
            hideBanner();
        });

        declineButton.addEventListener("click", function () {
            setConsent("declined");
            hideBanner();
        });
    }
});