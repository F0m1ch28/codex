export const contactInfo = {
  address: '[Адрес будет указан клиентом]',
  phone: '[Телефон будет указан клиентом]',
  email: '[Email будет указан клиентом]',
};