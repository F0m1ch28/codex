import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const AboutPage = () => {
  const pillars = [
    {
      title: 'Миссия',
      text: 'Создавать для компаний пространство уверенного роста, в котором стратегии реализуются, команды вовлечены, а цифры подтверждают результат.',
    },
    {
      title: 'Видение',
      text: 'Стать консалтинговым партнером первого выбора для компаний, которые стремятся к масштабированию и технологическому лидерству.',
    },
    {
      title: 'Подход',
      text: 'Мы соединяем бизнес-аналитику, дизайн мышление и гибкие методологии, чтобы формировать решения, проверенные практикой.',
    },
  ];

  const team = [
    {
      name: 'Максим Руднев',
      role: 'Управляющий партнер',
      bio: '15+ лет управленческого опыта в международных корпорациях, лидер проектов стратегического развития и организационных трансформаций.',
      photo: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=facearea&w=320&h=320&q=80',
    },
    {
      name: 'Анна Ковалёва',
      role: 'Партнер по инновациям',
      bio: 'Создает цифровые продукты и платформы роста. Эксперт по построению продуктовых команд и customer experience.',
      photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=facearea&w=320&h=320&q=80',
    },
    {
      name: 'Дмитрий Бочаров',
      role: 'Партнер по операционной эффективности',
      bio: 'Специализируется на операционной модели, Lean-подходах и управлении цепями поставок в промышленности и ритейле.',
      photo: 'https://images.unsplash.com/photo-1544723795-4325371f1d9d?auto=format&fit=facearea&w=320&h=320&q=80',
    },
  ];

  return (
    <>
      <Helmet>
        <title>О компании Valentor Amicado — миссия и команда</title>
        <meta
          name="description"
          content="Узнайте о миссии, видении и команде Valentor Amicado. Мы объединяем стратегию, инновации и культуру изменений."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>О компании Valentor Amicado</h1>
          <p>
            Мы создали консалтинговое партнерство, которое помогает компаниям быстро переходить от стратегии к действию.
            Мы верим, что сильные решения рождаются там, где аналитика соединяется с эмпатией к людям и вниманием к деталям.
          </p>
        </div>
        <div className={styles.heroImage} role="presentation" />
      </section>

      <section className={styles.pillars}>
        <div className={styles.pillarsGrid}>
          {pillars.map((pillar) => (
            <article key={pillar.title} className={styles.pillarCard}>
              <h2>{pillar.title}</h2>
              <p>{pillar.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.story}>
        <div className={styles.storyText}>
          <h2>История основания</h2>
          <p>
            Valentor Amicado появилась как ответ на запрос руководителей на практичных партнеров, которые умеют видеть картину целиком. 
            Вместо дежурных рекомендаций мы собираем данные, разговариваем с командами и строим решения, которые можно внедрять уже завтра.
          </p>
          <p>
            За последние годы мы сопровождали производственные компании, ритейл, IT и финансовые организации. В каждом проекте мы
            выстраиваем общий язык между собственниками и менеджментом, а также помогаем сформировать внутренние компетенции для поддержания изменений.
          </p>
        </div>
        <div className={styles.storyHighlights}>
          <div className={styles.highlightCard}>
            <span className={styles.highlightNumber}>28%</span>
            <p>Средний рост EBITDA у клиентов спустя год совместной работы.</p>
          </div>
          <div className={styles.highlightCard}>
            <span className={styles.highlightNumber}>75%</span>
            <p>Проектов приходят по рекомендациям действующих клиентов.</p>
          </div>
          <div className={styles.highlightCard}>
            <span className={styles.highlightNumber}>3 континента</span>
            <p>География проектов — Европа, Азия, Северная Америка.</p>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.sectionHeader}>
          <h2>Команда партнеров</h2>
          <p>Мультидисциплинарная экспертиза и опыт внедрения изменений в компаниях мирового уровня.</p>
        </div>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.photo} alt={`Фото: ${member.name}`} className={styles.teamPhoto} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span className={styles.teamRole}>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.values}>
        <div className={styles.valuesContent}>
          <h2>Что отличает нас</h2>
          <ul className={styles.valuesList}>
            <li>Каждый проект ведет партнер и отвечает за результат лично.</li>
            <li>Мы передаём знания командам клиента, чтобы эффект сохранялся после завершения проекта.</li>
            <li>Строим прозрачность — от roadmap до метрик эффективности.</li>
            <li>Уважаем культуру компании и помогаем трансформировать её мягко, но последовательно.</li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default AboutPage;