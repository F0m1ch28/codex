import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';
import { contactInfo } from '../data/contactInfo';

const initialFormState = {
  name: '',
  email: '',
  subject: '',
  message: '',
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [statusMessage, setStatusMessage] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите ваше имя.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Пожалуйста, оставьте адрес электронной почты.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Похоже, что email указан неверно.';
    }
    if (!formData.subject.trim()) {
      newErrors.subject = 'Сформулируйте тему обращения.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Опишите задачу или вопрос.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setStatusMessage('');
      return;
    }

    setErrors({});
    setStatusMessage('Спасибо! Ваше сообщение подготовлено к отправке. Наш консультант свяжется с вами в ближайшее время.');
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Свяжитесь с Valentor Amicado — консультация и сотрудничество</title>
        <meta
          name="description"
          content="Контакты Valentor Amicado. Оставьте заявку через форму, и мы обсудим задачу вашей компании."
        />
      </Helmet>
      <section className={styles.contact}>
        <div className={styles.contactContent}>
          <h1>Свяжитесь с нами</h1>
          <p>
            Расскажите о своей задаче — команда Valentor Amicado предложит возможные сценарии решения и сформирует
            подходящую для вас команду проекта.
          </p>
          <div className={styles.contactInfo}>
            <p><strong>Адрес:</strong> {contactInfo.address}</p>
            <p><strong>Телефон:</strong> <a href={`tel:${contactInfo.phone}`} className={styles.infoLink}>{contactInfo.phone}</a></p>
            <p><strong>Email:</strong> <a href={`mailto:${contactInfo.email}`} className={styles.infoLink}>{contactInfo.email}</a></p>
          </div>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formGroup}>
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Как к вам обращаться?"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && (
              <span id="name-error" className={styles.errorText}>
                {errors.name}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="example@company.ru"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && (
              <span id="email-error" className={styles.errorText}>
                {errors.email}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="subject">Тема сообщения</label>
            <input
              id="subject"
              name="subject"
              type="text"
              placeholder="Стратегия, операционная эффективность и др."
              value={formData.subject}
              onChange={handleChange}
              aria-invalid={Boolean(errors.subject)}
              aria-describedby={errors.subject ? 'subject-error' : undefined}
            />
            {errors.subject && (
              <span id="subject-error" className={styles.errorText}>
                {errors.subject}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Кратко опишите контекст и цель вашего проекта."
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && (
              <span id="message-error" className={styles.errorText}>
                {errors.message}
              </span>
            )}
          </div>
          <button type="submit" className={styles.submitButton}>
            Отправить сообщение
          </button>
          {statusMessage && (
            <p className={styles.statusMessage} role="status" aria-live="polite">
              {statusMessage}
            </p>
          )}
        </form>
      </section>

      <section className={styles.mapSection}>
        <div className={styles.mapPlaceholder} role="img" aria-label="Интерактивная карта будет добавлена позже">
          Карта появится здесь после уточнения адреса
        </div>
      </section>
    </>
  );
};

export default ContactPage;