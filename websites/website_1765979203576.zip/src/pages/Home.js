import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const HomePage = () => {
  const services = [
    {
      title: 'Стратегическое развитие',
      description: 'Выстраиваем дорожные карты роста, соединяя цифры, инсайты рынка и потенциал команды.',
      icon: '📈',
    },
    {
      title: 'Операционная эффективность',
      description: 'Оптимизируем процессы, внедряем KPI и прозрачность, чтобы компании работали быстрее и прибыльнее.',
      icon: '⚙️',
    },
    {
      title: 'Цифровая трансформация',
      description: 'Выбираем и внедряем технологии, которые раскрывают данные и помогают принимать точные решения.',
      icon: '💡',
    },
    {
      title: 'Управление изменениями',
      description: 'Помогаем командам адаптироваться к новому, сохраняя мотивацию и вовлеченность каждого.',
      icon: '🤝',
    },
  ];

  const values = [
    'Работаем с мерами успеха, понятными акционерам и командам.',
    'Всегда начинаем с анализа и верификации данных клиента.',
    'Фокусируемся на устойчивом результате без скрытых издержек.',
    'Собираем мультидисциплинарные проектные команды под задачу.',
  ];

  const steps = [
    { number: '01', title: 'Диагностика', text: 'Погружаемся в бизнес-модель, анализируем показатели и карту процессов.' },
    { number: '02', title: 'Стратегия', text: 'Формируем сценарии развития и выбираем инструменты, которые дадут максимальный эффект.' },
    { number: '03', title: 'Внедрение', text: 'Сопровождаем реализацию, координируем команды и контролируем сроки.' },
    { number: '04', title: 'Поддержка', text: 'Передаем знания, отслеживаем метрики и помогаем корректировать курс.' },
  ];

  const testimonials = [
    {
      name: 'Екатерина Баранова',
      role: 'Генеральный директор, Finex Group',
      text: 'Команда Valentor Amicado помогла нам выстроить управленческую отчетность и наладить культуру решений на основе данных. За 6 месяцев мы ускорили вывод новых продуктов на рынок в полтора раза.',
      avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=facearea&w=120&h=120&q=80',
    },
    {
      name: 'Андрей Кирсанов',
      role: 'COO, Nova Logistics',
      text: 'Потрясающая дисциплина и вовлеченность. Мы сняли узкие места в операционной цепочке и сократили издержки на 18% без потери скорости сервиса.',
      avatar: 'https://images.unsplash.com/photo-1544723795-3fb272b4278b?auto=format&fit=facearea&w=120&h=120&q=80',
    },
    {
      name: 'Марина Журавлева',
      role: 'HRD, Insight Media',
      text: 'Не только автоматизация, но и работа с людьми. После программы изменений снизили текучесть ключевых специалистов и запустили культуру непрерывного обучения.',
      avatar: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=facearea&w=120&h=120&q=80',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Valentor Amicado — стратегический консалтинг и трансформация бизнеса</title>
        <meta
          name="description"
          content="Valentor Amicado помогает компаниям выстраивать стратегию роста, цифровую трансформацию и операционную устойчивость."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <div className={styles.heroContent}>
            <p className={styles.heroTag}>Партнерство для устойчивого роста</p>
            <h1 className={styles.heroTitle}>
              Valentor Amicado — архитекторы преобразований для бизнеса, который стремится к большему.
            </h1>
            <p className={styles.heroSubtitle}>
              Мы проектируем стратегии, трансформируем процессы и выстраиваем культуру изменений, чтобы усиливать результат уже сегодня.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryButton}>
                Запланировать консультацию
              </Link>
              <Link to="/uslugi" className={styles.secondaryButton}>
                Смотреть услуги
              </Link>
            </div>
            <div className={styles.heroMetrics} aria-label="Ключевые показатели">
              <div>
                <span className={styles.metricValue}>120+</span>
                <span className={styles.metricLabel}>реализованных проектов</span>
              </div>
              <div>
                <span className={styles.metricValue}>16</span>
                <span className={styles.metricLabel}>отраслей в портфеле</span>
              </div>
              <div>
                <span className={styles.metricValue}>4.9/5</span>
                <span className={styles.metricLabel}>оценка клиентов</span>
              </div>
            </div>
          </div>
          <div className={styles.heroVisual} role="presentation">
            <div className={styles.heroImage} />
          </div>
        </div>
      </section>

      <section className={styles.about}>
        <div className={styles.sectionHeader}>
          <h2>О нас</h2>
          <p>
            Valentor Amicado — стратегическое консалтинговое бюро, которое помогает компаниям обрести ясность целей,
            структурировать процессы и создавать инновации, способные масштабироваться.
          </p>
        </div>
        <div className={styles.aboutGrid}>
          <div className={styles.aboutCard}>
            <h3>Фокус на результате</h3>
            <p>
              Работая с нами, вы получаете не набор презентаций, а дорожную карту внедрения и команду, которая ведет
              проект до измеримого результата.
            </p>
          </div>
          <div className={styles.aboutCard}>
            <h3>Экспертность</h3>
            <p>
              Наши консультанты — бывшие руководители направлений, финансовые аналитики, product-менеджеры и операционные директора.
            </p>
          </div>
          <div className={styles.aboutCard}>
            <h3>Партнерский подход</h3>
            <p>
              Мы интегрируемся в команду клиента, разделяем ответственность и удерживаем фокус на приоритетах бизнеса.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.servicesPreview}>
        <div className={styles.sectionHeader}>
          <h2>Наши ключевые направления</h2>
          <p>Выбираем инструменты трансформации, которые действительно работают для вашей компании и отрасли.</p>
        </div>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
        <div className={styles.servicesCta}>
          <Link to="/uslugi" className={styles.primaryButton}>
            Подробнее об услугах
          </Link>
        </div>
      </section>

      <section className={styles.values}>
        <div className={styles.sectionHeader}>
          <h2>Наши ценности</h2>
          <p>Мы выстраиваем доверие и прозрачность, чтобы каждая инициатива приносила компании измеримую пользу.</p>
        </div>
        <ul className={styles.valuesList}>
          {values.map((value) => (
            <li key={value} className={styles.valueItem}>
              {value}
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Как мы работаем</h2>
          <p>Вы получаете структурированный проект, контроль исполнения и поддержку после завершения трансформации.</p>
        </div>
        <div className={styles.processGrid}>
          {steps.map((step) => (
            <div key={step.number} className={styles.processCard}>
              <span className={styles.processNumber}>{step.number}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Отзывы клиентов</h2>
          <p>Компании, которые стали сильнее с Valentor Amicado.</p>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((item) => (
            <figure key={item.name} className={styles.testimonialCard}>
              <img src={item.avatar} alt={`Фото: ${item.name}`} className={styles.testimonialAvatar} />
              <blockquote className={styles.testimonialText}>“{item.text}”</blockquote>
              <figcaption className={styles.testimonialAuthor}>
                <strong>{item.name}</strong>
                <span>{item.role}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Пора обсудить ваш следующий шаг</h2>
          <p>
            Запланируйте встречу с командой Valentor Amicado, чтобы оценить потенциал трансформации вашего бизнеса и получить персональную рекомендацию.
          </p>
          <Link to="/kontakty" className={styles.ctaButton}>
            Связаться с нами
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;