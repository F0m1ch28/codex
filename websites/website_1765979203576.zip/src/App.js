import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import ServicesPage from './pages/Services';
import AboutPage from './pages/About';
import ContactPage from './pages/Contact';
import TermsOfServicePage from './pages/TermsOfService';
import PrivacyPolicyPage, { CookiePolicyPage } from './pages/PrivacyPolicy';
import styles from './App.module.css';

const App = () => {
  return (
    <div className={styles.app}>
      <Header />
      <main className={styles.mainContent}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/uslugi" element={<ServicesPage />} />
          <Route path="/o-kompanii" element={<AboutPage />} />
          <Route path="/kontakty" element={<ContactPage />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsOfServicePage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPolicyPage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;