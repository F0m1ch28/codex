import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'valentor-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive">
      <p className={styles.message}>
        Мы используем файлы cookie, чтобы сайт работал корректно и помогал нам улучшать сервис. Продолжая пользоваться сайтом, вы соглашаетесь с нашей{' '}
        <a className={styles.link} href="/politika-cookie">политикой использования cookie</a>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;