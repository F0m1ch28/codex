import React, { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        <Link to="/" className={styles.brand} aria-label="На главную">
          <span className={styles.brandAccent}>Valentor</span> Amicado
        </Link>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`} aria-label="Основная навигация">
          <NavLink
            to="/"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink)}
          >
            Главная
          </NavLink>
          <NavLink
            to="/uslugi"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink)}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/o-kompanii"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink)}
          >
            О компании
          </NavLink>
          <NavLink
            to="/kontakty"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeLink}` : styles.navLink)}
          >
            Контакты
          </NavLink>
        </nav>
        <button
          type="button"
          className={styles.mobileToggle}
          onClick={handleToggle}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Переключить меню"
        >
          <span className={styles.toggleLine} />
          <span className={styles.toggleLine} />
          <span className={styles.toggleLine} />
        </button>
      </div>
    </header>
  );
};

export default Header;