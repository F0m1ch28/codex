import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';
import { contactInfo } from '../data/contactInfo';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Подвал сайта">
      <div className={styles.container}>
        <div className={styles.column}>
          <h3 className={styles.title}>Valentor Amicado</h3>
          <p className={styles.text}>
            Мы объединяем стратегическое видение, креативное мышление и технологичную экспертизу для быстрого и устойчивого роста наших клиентов.
          </p>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subtitle}>Навигация</h4>
          <ul className={styles.navList}>
            <li><Link to="/" className={styles.link}>Главная</Link></li>
            <li><Link to="/uslugi" className={styles.link}>Услуги</Link></li>
            <li><Link to="/o-kompanii" className={styles.link}>О компании</Link></li>
            <li><Link to="/kontakty" className={styles.link}>Контакты</Link></li>
            <li><Link to="/usloviya-ispolzovaniya" className={styles.link}>Условия использования</Link></li>
            <li><Link to="/politika-konfidencialnosti" className={styles.link}>Конфиденциальность</Link></li>
            <li><Link to="/politika-cookie" className={styles.link}>Cookie политика</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subtitle}>Контакты</h4>
          <p className={styles.text}><strong>Адрес:</strong> {contactInfo.address}</p>
          <p className={styles.text}><strong>Телефон:</strong> {contactInfo.phone}</p>
          <p className={styles.text}><strong>Email:</strong> {contactInfo.email}</p>
          <div className={styles.socials} aria-label="Социальные сети">
            <a className={styles.socialLink} href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              <span aria-hidden="true">in</span>
            </a>
            <a className={styles.socialLink} href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook">
              <span aria-hidden="true">f</span>
            </a>
            <a className={styles.socialLink} href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
              <span aria-hidden="true">IG</span>
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p className={styles.bottomText}>© {new Date().getFullYear()} Valentor Amicado. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;