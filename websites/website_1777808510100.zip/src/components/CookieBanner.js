import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('casino_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('casino_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__text">
        <strong>Мы используем cookie.</strong> Они помогают улучшать сервис, анализировать посещаемость
        и показывать актуальные материалы. Продолжая пользоваться сайтом, вы соглашаетесь с обработкой данных.
      </div>
      <div className="cookie-banner__actions">
        <a className="btn btn--outline btn--sm" href="/cookies">
          Подробнее
        </a>
        <button type="button" className="btn btn--primary btn--sm" onClick={handleAccept}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;