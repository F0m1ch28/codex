import React from 'react';

const HeroBlock = () => (
  <section className="hero" aria-label="Лучшие онлайн-казино 2024">
    <div className="container hero__inner">
      <div className="hero__content">
        <p className="hero__eyebrow">Независимый рейтинг</p>
        <h1>Лучшие онлайн-казино 2024</h1>
        <p>
          Сравниваем лицензии, бонусные программы, сроки вывода средств и уровень поддержки верифицированных
          брендов. Все обзоры подготовлены экспертами с многолетним опытом в iGaming.
        </p>
        <div className="hero__actions">
          <a href="#top-casinos" className="btn btn--primary">
            Смотреть рейтинг
          </a>
          <a href="#comparison" className="btn btn--outline">
            Сравнить условия
          </a>
        </div>
        <div className="hero__meta">
          <span>Обновлено: май 2024</span>
          <span>Команда экспертов Casino Review Hub</span>
        </div>
      </div>
      <div className="hero__art" role="presentation">
        <img
          src="https://picsum.photos/1600/900?random=1"
          alt="Аналитик оценивает показатели казино"
          loading="lazy"
        />
      </div>
    </div>
  </section>
);

export default HeroBlock;