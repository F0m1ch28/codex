import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="container">
      <div className="site-footer__inner">
        <div className="site-footer__column">
          <h3 className="footer__title">Casino Review Hub</h3>
          <p className="footer__description">
            Независимые обзоры онлайн-казино, проверка бонусов и условий вывода средств.
            Мы публикуем честные исследования и обновляем рейтинг каждый месяц.
          </p>
          <p className="footer__disclaimer">
            Азартные игры предназначены для лиц старше 18 лет. Играйте ответственно.
          </p>
        </div>
        <div className="site-footer__column">
          <h4 className="footer__title">Контакты</h4>
          <ul className="footer__list footer__contact">
            <li>
              <a href="tel:+74951234567">+7 495 123-45-67</a>
            </li>
            <li>
              <a href="mailto:support@gamblingsite.com">support@gamblingsite.com</a>
            </li>
            <li>123456, Москва, ул. Примерная, д. 1, офис 10</li>
          </ul>
        </div>
        <div className="site-footer__column">
          <h4 className="footer__title">Документы</h4>
          <ul className="footer__list footer__legal">
            <li>
              <Link to="/terms">Пользовательское соглашение</Link>
            </li>
            <li>
              <Link to="/privacy">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/cookies">Политика Cookie</Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="site-footer__bottom">
        <p>© 2024 Casino Review Hub. Все права защищены.</p>
        <span className="footer__age">18+</span>
      </div>
    </div>
  </footer>
);

export default Footer;