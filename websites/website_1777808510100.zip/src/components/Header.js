import React, { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { path: '/', label: 'Главная' },
    { path: '/about', label: 'О нас' },
    { path: '/services', label: 'Услуги' },
    { path: '/contact', label: 'Контакты' }
  ];

  return (
    <header className={`site-header ${isScrolled ? 'site-header--scrolled' : ''}`}>
      <div className="container">
        <div className="site-header__inner">
          <NavLink to="/" className="logo" aria-label="Перейти на главную страницу">
            <span className="logo__mark">G-</span>
            <span className="logo__text">Casino Review</span>
          </NavLink>
          <nav className={`nav ${menuOpen ? 'nav--open' : ''}`} aria-label="Основная навигация">
            <ul className="nav__list">
              {navLinks.map((link) => (
                <li key={link.path} className="nav__item">
                  <NavLink
                    to={link.path}
                    className={({ isActive }) =>
                      isActive ? 'nav__link nav__link--active' : 'nav__link'
                    }
                  >
                    {link.label}
                  </NavLink>
                </li>
              ))}
              <li className="nav__item nav__item--cta">
                <NavLink to="/contact" className="btn btn--primary btn--sm">
                  Связаться
                </NavLink>
              </li>
            </ul>
          </nav>
          <button
            className={`mobile-toggle ${menuOpen ? 'mobile-toggle--open' : ''}`}
            aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((prev) => !prev)}
            type="button"
          >
            <span className="mobile-toggle__bar" />
            <span className="mobile-toggle__bar" />
            <span className="mobile-toggle__bar" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;