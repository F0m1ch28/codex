import React from 'react';
import MetaHelmet from '../components/MetaHelmet';

const teamMembers = [
  {
    name: 'Мария Соколова',
    role: 'Главный редактор',
    expertise: '10 лет в финансовой журналистике и аналитике iGaming.',
    image: 'https://picsum.photos/400/400?random=11'
  },
  {
    name: 'Илья Котов',
    role: 'Аналитик лицензий',
    expertise: 'Специалист по правовому регулированию азартных игр в ЕС и СНГ.',
    image: 'https://picsum.photos/400/400?random=12'
  },
  {
    name: 'Екатерина Орлова',
    role: 'Эксперт по UX',
    expertise: 'Исследует пользовательский опыт и ответственные инструменты казино.',
    image: 'https://picsum.photos/400/400?random=13'
  },
  {
    name: 'Виталий Серов',
    role: 'Редактор по выплатам',
    expertise: 'Проводит тестовые депозиты и выводы, ведет базу рекламаций и кейсов.',
    image: 'https://picsum.photos/400/400?random=14'
  }
];

const timeline = [
  {
    year: '2018',
    title: 'Запуск проекта',
    description:
      'Создали блог о добросовестных казино, публиковали первые инструкции по безопасности и верификации.'
  },
  {
    year: '2019',
    title: 'Расширение методологии',
    description:
      'Добавили чек-листы по лицензиям и тестирование скоростей выплат. Начали работать с экспертами по AML.'
  },
  {
    year: '2021',
    title: 'Формирование независимой команды',
    description:
      'Построили редакцию из аналитиков, журналистов и UX-специалистов. Запустили ежемесячное обновление рейтинга.'
  },
  {
    year: '2023',
    title: 'Публичный рейтинг и база кейсов',
    description:
      'Вышли на международный уровень, внедрили мониторинг регуляторов, собираем подтвержденные отзывы игроков.'
  }
];

const About = () => (
  <>
    <MetaHelmet
      title="О проекте"
      description="Casino Review Hub — миссия, экспертиза и команда. Узнайте, как мы проверяем онлайн-казино и формируем независимый рейтинг."
      keywords="о проекте, команда, методология, рейтинг казино, экспертиза iGaming"
    />
    <section className="section about animate-on-scroll">
      <div className="container">
        <div className="section__header">
          <h1 className="section__title">О нас</h1>
          <p className="section__subtitle">
            Casino Review Hub — независимая команда аналитиков, журналистов и compliance-специалистов.
            Мы исследуем азартные площадки, чтобы игроки могли принимать взвешенные решения.
          </p>
        </div>
        <div className="about__grid">
          <article className="about__card">
            <h2>Миссия</h2>
            <p>
              Мы стремимся повысить прозрачность рынка азартных игр и помочь игрокам минимизировать риски.
              Создаем понятные обзоры, раскрываем сложные юридические формулировки и даем рекомендации по ответственной игре.
            </p>
          </article>
          <article className="about__card">
            <h2>Экспертиза</h2>
            <p>
              В нашей команде есть бывшие сотрудники операторов, журналисты и аналитики платежных систем.
              Мы знаем, как устроены процессы изнутри, и умеем быстро находить слабые места в условиях казино.
            </p>
          </article>
          <article className="about__card">
            <h2>Прозрачность</h2>
            <p>
              Каждый обзор сопровождается чек-листом критериев и указанием источников. Если мы получаем партнерскую комиссию,
              обязательно сообщаем об этом и не снижаем объективность оценки.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className="section section--alt animate-on-scroll">
      <div className="container">
        <div className="section__header">
          <h2 className="section__title">Команда экспертов</h2>
          <p className="section__subtitle">
            Познакомьтесь с людьми, которые ежедневно тестируют сервисы, общаются с игроками и обновляют рейтинг.
          </p>
        </div>
        <div className="team-grid">
          {teamMembers.map((member) => (
            <article className="team-card" key={member.name}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div className="team-card__body">
                <h3>{member.name}</h3>
                <p className="team-card__role">{member.role}</p>
                <p>{member.expertise}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section animate-on-scroll">
      <div className="container">
        <div className="section__header">
          <h2 className="section__title">Наш путь</h2>
          <p className="section__subtitle">
            Развитие проекта в ключевых датах. Ведем отчетность, чтобы читатели видели, как эволюционирует методология.
          </p>
        </div>
        <div className="timeline">
          {timeline.map((item) => (
            <article className="timeline__item" key={item.year}>
              <span className="timeline__year">{item.year}</span>
              <div className="timeline__content">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section section--alt animate-on-scroll">
      <div className="container">
        <div className="section__header">
          <h2 className="section__title">Методология обзоров</h2>
          <p className="section__subtitle">
            Мы придерживаемся четырех принципов: достоверность данных, независимость, регулярное обновление и акцент на безопасности.
          </p>
        </div>
        <div className="methodology">
          <article>
            <h3>Достоверность</h3>
            <p>
              Используем подтвержденные источники: регуляторы, аудиторы RNG, отзывы с доказательствами.
              Верифицируем информацию через тестовые депозиты и обращения в поддержку.
            </p>
          </article>
          <article>
            <h3>Независимость</h3>
            <p>
              Отдельный отдел отвечает за партнерские отношения и не влияет на оценки. Вся редакция следует внутреннему кодексу прозрачности.
            </p>
          </article>
          <article>
            <h3>Регулярность</h3>
            <p>
              Обновляем ключевые рейтинги ежемесячно, а при критичных изменениях публикуем внеплановые апдейты и уведомления.
            </p>
          </article>
          <article>
            <h3>Безопасность</h3>
            <p>
              Пропагандируем ответственный подход, публикуем гайды по самоконтролю и подборку инструментов ограничения игры.
            </p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default About;