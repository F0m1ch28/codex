import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import HeroBlock from '../components/HeroBlock';
import MetaHelmet from '../components/MetaHelmet';

const ShieldIcon = () => (
  <svg aria-hidden="true" viewBox="0 0 24 24" className="icon">
    <path
      d="M12 3l7 3v6c0 5-3.5 8.5-7 9-3.5-.5-7-4-7-9V6l7-3z"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const WalletIcon = () => (
  <svg aria-hidden="true" viewBox="0 0 24 24" className="icon">
    <rect
      x="3"
      y="7"
      width="18"
      height="12"
      rx="2"
      ry="2"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
    />
    <path
      d="M16 11h4v4h-4a2 2 0 010-4z"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const HeadsetIcon = () => (
  <svg aria-hidden="true" viewBox="0 0 24 24" className="icon">
    <path
      d="M4 15v-3a8 8 0 0116 0v3"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M4 15a2 2 0 002 2h1v-4H6a2 2 0 00-2 2zm16 0a2 2 0 01-2 2h-1v-4h1a2 2 0 012 2z"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
    />
    <path d="M12 21v-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const ClockIcon = () => (
  <svg aria-hidden="true" viewBox="0 0 24 24" className="icon">
    <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.5" />
    <path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const StarIcon = () => (
  <svg aria-hidden="true" viewBox="0 0 24 24" className="icon">
    <path
      d="M12 4l2.6 5.3 5.8.8-4.2 4.1 1 5.8L12 17.8 6.8 20l1-5.8-4.2-4.1 5.8-.8z"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
  </svg>
);

const LayersIcon = () => (
  <svg aria-hidden="true" viewBox="0 0 24 24" className="icon">
    <path
      d="M12 3l9 5-9 5-9-5 9-5zm-9 8l9 5 9-5m-9 5v6"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const statsData = [
  { label: 'Проверенных брендов в базе', value: 128 },
  { label: 'Обновлений рейтинга за 2024 год', value: 312 },
  { label: 'Средний скоринговый балл', value: 92, suffix: '%' },
  { label: 'Часов ручного тестирования', value: 1670 }
];

const casinos = [
  {
    id: 'aurora-play',
    name: 'Aurora Play',
    rating: 4.8,
    bonus: 'Бонус до 120 000 ₽ + 150 FS',
    wagering: 'x35',
    deposit: 'от 500 ₽',
    license: 'Curacao eGaming',
    image: 'https://via.placeholder.com/300x200?text=Казино+Aurora',
    description:
      'Платформа с моментальными выплатами на карты и удобными лимитами. Прошла повторную проверку весной 2024 года.',
    features: ['Вывод до 15 минут', 'Поддержка 24/7 на русском', 'Мобильное приложение']
  },
  {
    id: 'nordic-spin',
    name: 'Nordic Spin',
    rating: 4.6,
    bonus: 'Приветственный пакет до €1000 + 200 FS',
    wagering: 'x40',
    deposit: 'от 20 €',
    license: 'MGA (Malta)',
    image: 'https://via.placeholder.com/300x200?text=Казино+Nordic',
    description:
      'Европейская платформа с лицензией MGA, усиленной верификацией и прозрачными лимитами на бонусы.',
    features: ['Игры от 40+ провайдеров', 'Поддержка мультивалют', 'Двухфакторная авторизация']
  },
  {
    id: 'metropolis-slots',
    name: 'Metropolis Slots',
    rating: 4.5,
    bonus: 'Кэшбэк до 20% каждую неделю',
    wagering: 'x25',
    deposit: 'от 700 ₽',
    license: 'Kahnawake',
    image: 'https://via.placeholder.com/300x200?text=Казино+Metropolis',
    description:
      'Фокус на возврате средств и регулярных турнирах. Проверены условия лояльности и лимиты на вывод.',
    features: ['Кэшбэк без вейджера', 'Слоты и live-игры', 'Собственная академия ответственной игры']
  },
  {
    id: 'greenriver',
    name: 'GreenRiver Casino',
    rating: 4.4,
    bonus: 'До 250 бесплатных вращений',
    wagering: 'x30',
    deposit: 'от 10 $',
    license: 'Isle of Man',
    image: 'https://via.placeholder.com/300x200?text=Казино+GreenRiver',
    description:
      'Бренд с ориентиром на игроков из СНГ: понятные условия KYC и быстрый ответ службы поддержки.',
    features: ['Верификация за 2 часа', 'Прозрачные турниры', 'Программа лояльности из 7 уровней']
  }
];

const comparisonData = [
  {
    name: 'Aurora Play',
    bonus: 'до 120 000 ₽ + 150 FS',
    wagering: 'x35',
    deposit: '500 ₽',
    license: 'Curacao eGaming'
  },
  {
    name: 'Nordic Spin',
    bonus: 'до €1000 + 200 FS',
    wagering: 'x40',
    deposit: '20 €',
    license: 'MGA'
  },
  {
    name: 'Metropolis Slots',
    bonus: 'кэшбэк до 20%',
    wagering: 'x25',
    deposit: '700 ₽',
    license: 'Kahnawake'
  },
  {
    name: 'GreenRiver Casino',
    bonus: '250 FS',
    wagering: 'x30',
    deposit: '10 $',
    license: 'Isle of Man'
  },
  {
    name: 'Vegas Pulse',
    bonus: 'до 500% на первые 5 депозита',
    wagering: 'x45',
    deposit: '1000 ₽',
    license: 'Curacao'
  },
  {
    name: 'SkyLine Club',
    bonus: '150% + 100 FS',
    wagering: 'x30',
    deposit: '15 $',
    license: 'Gibraltar'
  }
];

const processSteps = [
  {
    title: 'Проверяем лицензии',
    description: 'Изучаем реестр регулятора, проверяем валидность лицензии и юридический адрес оператора.'
  },
  {
    title: 'Тестируем платежи',
    description: 'Делаем реальные депозиты и запросы на вывод, фиксируем сроки и комиссии.'
  },
  {
    title: 'Оцениваем UX и поддержку',
    description: 'Проверяем работу саппорта, скорость ответа и качество решения запросов игроков.'
  },
  {
    title: 'Моделируем риск',
    description: 'Анализируем провайдеров, RTP игр и наличие инструментов ответственной игры.'
  }
];

const criteriaItems = [
  {
    title: 'Лицензия и репутация',
    text: 'Принимаем к рейтингу только проекты с действующей лицензией и прозрачной историей выплат.',
    icon: ShieldIcon
  },
  {
    title: 'Финансовая прозрачность',
    text: 'Сравниваем методы пополнения и вывода, лимиты, комиссии и время обработки запросов.',
    icon: WalletIcon
  },
  {
    title: 'Служба поддержки',
    text: 'Проводим тайные обращения в саппорт, оцениваем скорость, компетентность и наличие русскоязычной команды.',
    icon: HeadsetIcon
  },
  {
    title: 'Скорость проверок',
    text: 'Отслеживаем, сколько времени уходит на KYC, подтверждение документов и разблокировку аккаунтов.',
    icon: ClockIcon
  }
];

const serviceHighlights = [
  {
    title: 'Аналитика бонусов',
    description: 'Разбираем правила поинтов, вейджеры и скрытые ограничения на бесплатные вращения.',
    icon: StarIcon
  },
  {
    title: 'Контроль выплат',
    description: 'Мониторим реальные кейсы вывода, проверяем лимиты на карты и электронные кошельки.',
    icon: WalletIcon
  },
  {
    title: 'Обзор интерфейса',
    description: 'Составляем отчеты по навигации, мобильной версии и доступности ответственной игры.',
    icon: LayersIcon
  }
];

const testimonials = [
  {
    name: 'Александр К.',
    city: 'Казань',
    date: 'апрель 2024',
    text: 'Благодаря рейтингу выбрал казино с быстрым выводом на банковскую карту. Проверенные данные по срокам помогли избежать задержек.'
  },
  {
    name: 'Дарья М.',
    city: 'Новосибирск',
    date: 'март 2024',
    text: 'Подробный разбор бонусов спас от сложного вейджера. Теперь изучаю раздел «Как мы выбираем» перед регистрацией.'
  },
  {
    name: 'Игорь П.',
    city: 'Москва',
    date: 'май 2024',
    text: 'Команда действительно тестирует саппорт. Проверил Nordic Spin — ответы пришли за пару минут, как и описано.'
  },
  {
    name: 'Лилия С.',
    city: 'Санкт-Петербург',
    date: 'февраль 2024',
    text: 'Отличная подборка инструментов ответственной игры. В обзоре нашла ограничения по депозитам и советы по контролю банкролла.'
  }
];

const faqItems = [
  {
    question: 'Как формируется рейтинг казино на сайте?',
    answer:
      'Мы используем систему из 60+ критериев: лицензия, прозрачность выплат, качество бонусов, наличие ответственной игры, отзывы реальных игроков. Каждый бренд проходит ручную проверку.'
  },
  {
    question: 'Сколько времени занимает вывод средств?',
    answer:
      'Средние сроки зависят от метода. Мы фиксируем фактические результаты тестовых выплат, средний показатель топ-5 казино — до 24 часов на карты и до 15 минут на электронные кошельки.'
  },
  {
    question: 'Вы сотрудничаете с казино напрямую?',
    answer:
      'Мы сохраняем независимость. Если есть партнерские ссылки, они не влияют на итоговую оценку. Все материалы отмечены дополнительными пометками прозрачности.'
  },
  {
    question: 'Можно ли доверять отзывам игроков?',
    answer:
      'Мы модерируем отзывы и запрашиваем подтверждение игры. В отчеты включаем только проверенные комментарии, подкрепленные скриншотами или подтвержденными транзакциями.'
  },
  {
    question: 'Как часто обновляются обзоры?',
    answer:
      'Каждый месяц мы пересматриваем ключевые рейтинги, а при серьезных изменениях условий выводим экстренные обновления в разделе «Новости» и email-рассылке.'
  },
  {
    question: 'Что делать при спорной ситуации с казино?',
    answer:
      'Воспользуйтесь чек-листом в разделе «Контакты»: соберите документацию, обратитесь в саппорт казино, затем напишите регулятору и нам — мы поможем подготовить претензию.'
  }
];

const portfolioItems = [
  {
    id: 'case-aurora',
    category: 'Лицензия',
    title: 'Повторная проверка лицензии Aurora Play',
    description: 'Проанализировали актуальность сертификатов Curacao, проверили юридический адрес и жалобы игроков.',
    image: 'https://picsum.photos/1200/800?random=4'
  },
  {
    id: 'case-nordic',
    category: 'Бонусы',
    title: 'Аудит бонусной программы Nordic Spin',
    description: 'Выявили скрытые условия по ставкам и подсчитали реальную эффективность приветственного пакета.',
    image: 'https://picsum.photos/1200/800?random=5'
  },
  {
    id: 'case-metropolis',
    category: 'UX',
    title: 'Исследование интерфейса Metropolis Slots',
    description: 'Провели UX-тесты мобильной версии, создали рекомендации по улучшению навигации и поиску игр.',
    image: 'https://picsum.photos/1200/800?random=6'
  },
  {
    id: 'case-greenriver',
    category: 'Бонусы',
    title: 'Сравнение кэшбэк-программ GreenRiver и конкурентов',
    description: 'Собрали метрики по реальному возврату средств и прозрачности условий начисления.',
    image: 'https://picsum.photos/1200/800?random=7'
  }
];

const blogPosts = [
  {
    id: 'blog-aml',
    title: 'Как проходит AML-проверка в онлайн-казино: пошаговый разбор',
    excerpt: 'Разбираем, почему казино запрашивают документы, как хранится персональная информация и что делать при задержке вывода.',
    image: 'https://picsum.photos/800/600?random=21',
    date: '10 мая 2024'
  },
  {
    id: 'blog-rng',
    title: 'RNG и провайдеры: на что смотреть при выборе площадки',
    excerpt: 'Объясняем, почему важно наличие независимых аудиторов RNG и как проверить провайдера на честность.',
    image: 'https://picsum.photos/800/600?random=22',
    date: '2 мая 2024'
  },
  {
    id: 'blog-promotions',
    title: 'Бонусные правила без сюрпризов: читаем условия вместе',
    excerpt: 'Показываем реальные примеры сложных правил, переводим юридические формулировки на понятный язык.',
    image: 'https://picsum.photos/800/600?random=23',
    date: '24 апреля 2024'
  }
];

const categories = ['Все', 'Лицензия', 'Бонусы', 'UX'];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [faqOpenIndex, setFaqOpenIndex] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [showTopButton, setShowTopButton] = useState(false);

  useEffect(() => {
    let startTime;
    let frameId;

    const duration = 1800;

    const animate = (timestamp) => {
      if (!startTime) {
        startTime = timestamp;
      }
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setAnimatedStats(
        statsData.map((item) =>
          progress === 1 ? item.value : Math.floor(item.value * progress)
        )
      );
      if (progress < 1) {
        frameId = requestAnimationFrame(animate);
      }
    };

    frameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameId);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setShowTopButton(window.scrollY > 400);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const elements = document.querySelectorAll('.animate-on-scroll');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      {
        threshold: 0.2
      }
    );

    elements.forEach((el) => observer.observe(el));
    return () => {
      elements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  const filteredPortfolio = useMemo(() => {
    if (selectedCategory === 'Все') {
      return portfolioItems;
    }
    return portfolioItems.filter((item) => item.category === selectedCategory);
  }, [selectedCategory]);

  const handleFaqToggle = (index) => {
    setFaqOpenIndex((prev) => (prev === index ? null : index));
  };

  const handleScrollTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <>
      <MetaHelmet
        title="Обзоры казино 2024"
        description="Актуальные обзоры онлайн-казино 2024 года: лицензии, бонусы, сроки вывода средств, условия ставок и поддержка. Независимый рейтинг и сравнение условий."
        keywords="гэмблинг, казино, бонусы, обзор, сравнение, условия, рейтинг казино 2024"
      />
      <HeroBlock />

      <section className="section stats animate-on-scroll" aria-label="Ключевые показатели проекта">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Наша статистика в цифрах</h2>
            <p className="section__subtitle">
              Мы фиксируем каждый шаг проверки, чтобы читатели понимали, насколько глубоко проработан рейтинг.
            </p>
          </div>
          <div className="stats__grid">
            {statsData.map((item, index) => (
              <article className="stat-card" key={item.label}>
                <div className="stat-card__value">
                  {animatedStats[index]}
                  {item.suffix ? <span>{item.suffix}</span> : null}
                </div>
                <p className="stat-card__label">{item.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="top-casinos" className="section animate-on-scroll" aria-label="Топ казино месяца">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Топ казино месяца</h2>
            <p className="section__subtitle">
              Рейтинг составлен с учетом свежих отзывов, тестов выплат и подтвержденных лицензий. Мы не обещаем выигрыш,
              но помогаем выбрать площадку с прозрачными условиями.
            </p>
          </div>
          <div className="cards-grid">
            {casinos.map((casino) => (
              <article className="casino-card" key={casino.id}>
                <div className="casino-card__header">
                  <img src={casino.image} alt={`Обложка ${casino.name}`} loading="lazy" />
                  <div className="casino-card__rating" aria-label={`Рейтинг ${casino.rating} из 5`}>
                    <span>{casino.rating.toFixed(1)}</span>
                  </div>
                </div>
                <div className="casino-card__body">
                  <h3>{casino.name}</h3>
                  <p className="casino-card__description">{casino.description}</p>
                  <ul className="casino-card__features">
                    <li className="casino-card__feature">
                      <strong>Бонус:</strong> {casino.bonus}
                    </li>
                    <li className="casino-card__feature">
                      <strong>Вейджер:</strong> {casino.wagering}
                    </li>
                    <li className="casino-card__feature">
                      <strong>Депозит:</strong> {casino.deposit}
                    </li>
                    <li className="casino-card__feature">
                      <strong>Лицензия:</strong> {casino.license}
                    </li>
                  </ul>
                  <ul className="casino-card__tags">
                    {casino.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                </div>
                <div className="casino-card__actions">
                  <a
                    href="https://via.placeholder.com/150x50?text=Играть"
                    className="btn btn--primary"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Играть
                  </a>
                  <Link to="/services" className="btn btn--outline">
                    Читать обзор
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section section--alt animate-on-scroll">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Что входит в наши обзоры</h2>
            <p className="section__subtitle">
              Мы анализируем ключевые блоки казино и даем рекомендации по минимизации рисков для игроков.
            </p>
          </div>
          <div className="highlight-grid">
            {serviceHighlights.map((item) => (
              <article className="highlight-card" key={item.title}>
                <div className="highlight-card__icon">
                  <item.icon />
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="comparison" className="section animate-on-scroll" aria-label="Сравнение условий казино">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Сравнение условий</h2>
            <p className="section__subtitle">
              Таблица позволяет быстро оценить ключевые параметры перед регистрацией. Для детальной аналитики перейдите к полным обзорам.
            </p>
          </div>
          <div className="comparison-table-wrapper" role="group" aria-label="Таблица сравнения казино">
            <table className="comparison-table">
              <thead>
                <tr>
                  <th scope="col">Казино</th>
                  <th scope="col">Бонус</th>
                  <th scope="col">Вейджер</th>
                  <th scope="col">Мин. депозит</th>
                  <th scope="col">Лицензия</th>
                </tr>
              </thead>
              <tbody>
                {comparisonData.map((row) => (
                  <tr key={row.name}>
                    <th scope="row">{row.name}</th>
                    <td>{row.bonus}</td>
                    <td>{row.wagering}</td>
                    <td>{row.deposit}</td>
                    <td>{row.license}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="section animate-on-scroll" aria-label="Процесс оценки казино">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Как мы проводим оценку</h2>
            <p className="section__subtitle">
              Каждый шаг фиксируется в чек-листах и помогает нам сохранять объективность. Мы не публикуем обзоры без полного цикла проверки.
            </p>
          </div>
          <div className="process__grid">
            {processSteps.map((step, index) => (
              <article className="process-step" key={step.title}>
                <span className="process-step__number">{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section section--alt animate-on-scroll" aria-label="Критерии отбора казино">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Как мы выбираем казино для рейтинга</h2>
            <p className="section__subtitle">
              Отметки выставляются по итогам детальной проверки — лицензия, финансовая прозрачность, качество саппорта и скорость операций.
            </p>
          </div>
          <div className="criteria-grid">
            {criteriaItems.map((item) => (
              <article className="criteria-card" key={item.title}>
                <div className="criteria-card__icon">
                  <item.icon />
                </div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section animate-on-scroll" aria-label="Наши исследования">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Проекты и исследования</h2>
            <p className="section__subtitle">
              Публикуем кейсы, где подробно описываем ход проверки и выводы. Выберите категорию, чтобы увидеть релевантные материалы.
            </p>
          </div>
          <div className="portfolio">
            <div className="portfolio__filters" role="tablist" aria-label="Фильтр проектов">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  className={selectedCategory === category ? 'active' : ''}
                  onClick={() => setSelectedCategory(category)}
                  role="tab"
                  aria-selected={selectedCategory === category}
                >
                  {category}
                </button>
              ))}
            </div>
            <div className="portfolio__grid">
              {filteredPortfolio.map((item) => (
                <article className="portfolio-card" key={item.id}>
                  <img src={item.image} alt={item.title} loading="lazy" />
                  <div className="portfolio-card__body">
                    <span className="portfolio-card__category">{item.category}</span>
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                    <Link to="/services" className="btn btn--outline btn--sm">
                      Смотреть детали
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="reviews" className="section section--alt animate-on-scroll" aria-label="Отзывы игроков">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Отзывы игроков</h2>
            <p className="section__subtitle">
              Реальные комментарии читателей, которые воспользовались нашими рекомендациями. Каждый отзыв подтвержден.
            </p>
          </div>
          <div className="testimonials" aria-live="polite">
            <article className="testimonial">
              <div className="testimonial__content">
                <p>“{testimonials[activeTestimonial].text}”</p>
              </div>
              <div className="testimonial__meta">
                <strong>{testimonials[activeTestimonial].name}</strong>
                <span>
                  {testimonials[activeTestimonial].city} · {testimonials[activeTestimonial].date}
                </span>
              </div>
              <div className="testimonial__controls" role="group" aria-label="Навигация по отзывам">
                <button
                  type="button"
                  className="btn btn--outline btn--sm"
                  onClick={() =>
                    setActiveTestimonial(
                      (activeTestimonial - 1 + testimonials.length) % testimonials.length
                    )
                  }
                >
                  Назад
                </button>
                <button
                  type="button"
                  className="btn btn--primary btn--sm"
                  onClick={() => setActiveTestimonial((activeTestimonial + 1) % testimonials.length)}
                >
                  Далее
                </button>
              </div>
              <div className="testimonial__progress">
                {testimonials.map((_, index) => (
                  <span
                    key={index}
                    className={`testimonial__bullet ${
                      index === activeTestimonial ? 'testimonial__bullet--active' : ''
                    }`}
                    aria-hidden="true"
                  />
                ))}
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="section animate-on-scroll" aria-label="Свежие публикации">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Свежие аналитические материалы</h2>
            <p className="section__subtitle">
              Статьи помогают глубже разобраться в механике бонусов, работе регуляторов и методах защиты игроков.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.id}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className="blog-card__body">
                  <span className="blog-card__date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/about" className="btn btn--ghost btn--sm">
                    Читать
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="section section--alt animate-on-scroll" aria-label="Часто задаваемые вопросы">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">FAQ</h2>
            <p className="section__subtitle">
              Сборник ответов на популярные вопросы читателей. Если не нашли ответ, напишите нам — поможем разобраться.
            </p>
          </div>
          <div className="faq">
            {faqItems.map((item, index) => (
              <div className={`faq-item ${faqOpenIndex === index ? 'faq-item--open' : ''}`} key={item.question}>
                <button
                  type="button"
                  className="faq-item__question"
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={faqOpenIndex === index}
                >
                  {item.question}
                </button>
                <div
                  className="faq-item__answer"
                  aria-hidden={faqOpenIndex === index ? 'false' : 'true'}
                >
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section cta animate-on-scroll" aria-label="Призыв к действию">
        <div className="container">
          <div className="cta__content">
            <h2>Нужна помощь с выбором платформы?</h2>
            <p>
              Подготовим индивидуальный подбор с учетом ваших приоритетов: быстрые выплаты, лайв-казино, бонусные программы или мобильный опыт.
              Расскажем о рисках и предложим альтернативы.
            </p>
            <div className="cta__actions">
              <Link to="/contact" className="btn btn--primary">
                Получить консультацию
              </Link>
              <Link to="/services" className="btn btn--outline">
                Изучить методологию
              </Link>
            </div>
          </div>
        </div>
      </section>

      {showTopButton && (
        <button className="back-to-top" type="button" onClick={handleScrollTop} aria-label="Вернуться наверх страницы">
          ↑
        </button>
      )}
    </>
  );
};

export default Home;