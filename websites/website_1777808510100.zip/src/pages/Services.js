import React, { useState } from 'react';
import MetaHelmet from '../components/MetaHelmet';

const servicePackages = [
  {
    id: 'compliance-audit',
    title: 'Комплексный аудит казино',
    summary: 'Полный анализ лицензии, платежных методов, провайдеров и истории жалоб.',
    details: [
      'Проверка регистрационных данных компании и регулятора',
      'Тестирование депозитов и выводов на разные методы',
      'Оценка лимитов, скрытых комиссий и правил KYC',
      'Подготовка заключения с рекомендациями'
    ]
  },
  {
    id: 'bonus-monitoring',
    title: 'Мониторинг бонусных программ',
    summary: 'Сравнение вейджеров, ограничений по провайдерам, временных рамок акций.',
    details: [
      'Анализ приветственных пакетов и сезонных промо',
      'Расчет реального ожидания по кэшбэку и кеш-дропам',
      'Отслеживание изменений условий и уведомления подписчиков',
      'Подготовка отчетов по эффективности бонусов'
    ]
  },
  {
    id: 'support-review',
    title: 'Аудит службы поддержки',
    summary: 'Тестируем скорость и качество ответов сотрудников на разных каналах.',
    details: [
      'Тайные обращения в чат, email и мессенджеры',
      'Оценка знания регламента и готовности решать спорные случаи',
      'Проверка наличия инструментов для ответственной игры',
      'Рекомендации по улучшению клиентского сервиса'
    ]
  }
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicePackages[0].id);

  return (
    <>
      <MetaHelmet
        title="Услуги Casino Review Hub"
        description="Комплексный аудит онлайн-казино: проверка лицензий, мониторинг бонусов, анализ службы поддержки и UX."
        keywords="услуги, аудит казино, анализ бонусов, мониторинг выплат, проверка лицензии"
      />
      <section className="section services animate-on-scroll">
        <div className="container">
          <div className="section__header">
            <h1 className="section__title">Наши услуги</h1>
            <p className="section__subtitle">
              Предлагаем аналитические услуги для игроков, партнеров и регуляторов. Работая с нами, вы получаете объективный взгляд на состояние бренда.
            </p>
          </div>
          <div className="services__grid">
            <aside className="services__list" aria-label="Список услуг">
              {servicePackages.map((service) => (
                <button
                  key={service.id}
                  type="button"
                  className={`service-card ${activeService === service.id ? 'service-card--active' : ''}`}
                  onClick={() => setActiveService(service.id)}
                  aria-pressed={activeService === service.id}
                >
                  <h2 className="service-card__title">{service.title}</h2>
                  <p className="service-card__summary">{service.summary}</p>
                </button>
              ))}
            </aside>
            <div className="service-detail">
              {servicePackages
                .filter((service) => service.id === activeService)
                .map((service) => (
                  <article key={service.id}>
                    <h2>{service.title}</h2>
                    <p>{service.summary}</p>
                    <ul>
                      {service.details.map((detail) => (
                        <li key={detail}>{detail}</li>
                      ))}
                    </ul>
                    <p className="service-detail__note">
                      Все отчеты сопровождаются рекомендациями по улучшению и сравнением с бенчмарками рынка.
                      Мы не гарантируем выигрыш, но помогаем сделать условия игры понятными и безопасными.
                    </p>
                  </article>
                ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section section--alt animate-on-scroll">
        <div className="container">
          <div className="section__header">
            <h2 className="section__title">Форматы сотрудничества</h2>
            <p className="section__subtitle">
              Индивидуальные консультации, ежемесячные подписки на мониторинг и разовые запросы по спорным ситуациям.
            </p>
          </div>
          <div className="services__formats">
            <article>
              <h3>Игрокам</h3>
              <p>
                Помогаем выбрать площадку по вашим приоритетам: быстрые выплаты, live-дилеры, бонусы.
                Разъясняем правила и подсказываем, как действовать при споре.
              </p>
            </article>
            <article>
              <h3>Партнерам</h3>
              <p>
                Предоставляем white-label отчеты, анализируем трафик и совместимость офферов с целевой аудиторией.
                Помогаем выстроить честную коммуникацию.
              </p>
            </article>
            <article>
              <h3>Регуляторам</h3>
              <p>
                Готовим аналитические записки, собираем жалобы и статистику, консультируем по вопросам responsible gaming.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;