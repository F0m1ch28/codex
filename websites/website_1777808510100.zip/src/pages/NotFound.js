import React from 'react';
import { Link } from 'react-router-dom';
import MetaHelmet from '../components/MetaHelmet';

const NotFound = () => (
  <>
    <MetaHelmet
      title="Страница не найдена"
      description="Ошибка 404 — страница не найдена. Вернитесь на главную Casino Review Hub."
      keywords="404, страница не найдена"
    />
    <section className="section not-found animate-on-scroll">
      <div className="container">
        <h1 className="section__title">Страница не найдена</h1>
        <p className="section__subtitle">
          Возможно, страница была перенесена или удалена. Проверьте адрес или вернитесь на главную.
        </p>
        <Link to="/" className="btn btn--primary">
          На главную
        </Link>
      </div>
    </section>
  </>
);

export default NotFound;