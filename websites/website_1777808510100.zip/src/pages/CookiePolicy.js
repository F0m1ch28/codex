import React from 'react';
import MetaHelmet from '../components/MetaHelmet';

const CookiePolicy = () => (
  <>
    <MetaHelmet
      title="Политика Cookie"
      description="Политика использования файлов cookie на сайте Casino Review Hub: типы, цели и управление настройками."
      keywords="cookie, политика cookie, файлы cookie"
    />
    <section className="section legal animate-on-scroll">
      <div className="container">
        <h1 className="section__title">Политика использования cookie</h1>
        <p className="legal__intro">
          Файлы cookie помогают предоставлять удобный сервис и сохранять настройки пользователя. Ниже описано, какие cookie мы применяем и как их отключить.
        </p>

        <h2>1. Что такое cookie</h2>
        <p>
          Cookie — небольшие файлы, которые сохраняются на вашем устройстве при посещении сайта. Они позволяют запоминать настройки и анализировать использование ресурса.
        </p>

        <h2>2. Какие cookie мы используем</h2>
        <p>
          2.1. Технические cookie — обеспечивают корректную работу сайта (сессии, язык интерфейса, уведомления).
        </p>
        <p>
          2.2. Аналитические cookie — помогают нам понимать, как пользователи взаимодействуют с контентом. Данные обезличены.
        </p>

        <h2>3. Управление cookie</h2>
        <p>
          Вы можете удалить или заблокировать cookie в настройках браузера. Обратите внимание: после отключения некоторых cookie функциональность сайта может быть ограничена.
        </p>

        <h2>4. Согласие</h2>
        <p>
          Продолжая пользоваться сайтом после отображения баннера, вы соглашаетесь на использование cookie. Вы можете отозвать согласие,
          изменив настройки браузера и уведомив нас через контактную форму.
        </p>

        <p className="legal__footer">
          Вопросы по политике cookie направляйте на{' '}
          <a href="mailto:support@gamblingsite.com">support@gamblingsite.com</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;