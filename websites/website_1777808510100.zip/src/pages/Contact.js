import React, { useState } from 'react';
import MetaHelmet from '../components/MetaHelmet';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Введите ваше имя.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email.trim())) {
      newErrors.email = 'Введите корректный email.';
    }
    if (!formData.subject.trim()) {
      newErrors.subject = 'Укажите тему обращения.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Напишите сообщение.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: undefined
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setSubmitted(true);
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  return (
    <>
      <MetaHelmet
        title="Контакты"
        description="Связаться с командой Casino Review Hub: консультации по выбору казино, сообщения о спорных ситуациях, предложения по сотрудничеству."
        keywords="контакты, обратная связь, поддержка, консультация по казино"
      />
      <section className="section contact animate-on-scroll">
        <div className="container">
          <div className="section__header">
            <h1 className="section__title">Связаться с нами</h1>
            <p className="section__subtitle">
              Оставьте сообщение — мы ответим в течение рабочего дня. Консультации бесплатны, но не заменяют финансовый совет.
            </p>
          </div>
          <div className="contact__grid">
            <form className="contact__form" onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label htmlFor="name">Имя</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  required
                />
                {errors.name && (
                  <span id="name-error" className="form-error" role="alert">
                    {errors.name}
                  </span>
                )}
              </div>
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  required
                />
                {errors.email && (
                  <span id="email-error" className="form-error" role="alert">
                    {errors.email}
                  </span>
                )}
              </div>
              <div className="form-group">
                <label htmlFor="subject">Тема</label>
                <input
                  id="subject"
                  name="subject"
                  type="text"
                  value={formData.subject}
                  onChange={handleChange}
                  aria-describedby={errors.subject ? 'subject-error' : undefined}
                  required
                />
                {errors.subject && (
                  <span id="subject-error" className="form-error" role="alert">
                    {errors.subject}
                  </span>
                )}
              </div>
              <div className="form-group">
                <label htmlFor="message">Сообщение</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  required
                />
                {errors.message && (
                  <span id="message-error" className="form-error" role="alert">
                    {errors.message}
                  </span>
                )}
              </div>
              <button type="submit" className="btn btn--primary">
                Отправить
              </button>
              {submitted && (
                <p className="form-success" role="status">
                  Спасибо! Мы получили ваше сообщение и ответим на указанный email.
                </p>
              )}
            </form>
            <aside className="contact__info">
              <h2>Наши контакты</h2>
              <ul>
                <li>
                  <strong>Адрес:</strong> 123456, Москва, ул. Примерная, д. 1, офис 10
                </li>
                <li>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+74951234567">+7 495 123-45-67</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:support@gamblingsite.com">support@gamblingsite.com</a>
                </li>
              </ul>
              <p>
                Режим работы: понедельник — пятница, 10:00–19:00 (по московскому времени). В выходные и праздники
                мониторим входящие и отвечаем на срочные обращения по спорным ситуациям.
              </p>
              <p>
                Мы не оказываем финансовых услуг и не храним платежные данные. Все консультации направлены на повышение
                информированности игроков и поддержку ответственной игры.
              </p>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;