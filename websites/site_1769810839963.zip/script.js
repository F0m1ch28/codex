const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";

const I18N = {
  fr: {
    brand: {
      name: "Laboratoire des Dynamiques Territoriales",
      tagline: "Cartographier les interactions spatiales pour renforcer l’action publique."
    },
    nav: {
      home: "Accueil",
      services: "Axes d’analyse",
      about: "Gouvernance",
      blog: "Carnet d’études",
      faq: "FAQ",
      contact: "Coordonnées",
      menuToggle: "Menu",
      skipToContent: "Aller au contenu principal"
    },
    language: {
      fr: "FR",
      en: "EN"
    },
    footer: {
      phone: "Téléphone : +32 2 320 45 67",
      email: "Courriel : contact@ldt-insights.be",
      addressLabel: "Adresse",
      addressValue: "Laboratoire des Dynamiques Territoriales · Rue des Colonies 36, 1000 Bruxelles, Belgique",
      legalTitle: "Documents de référence",
      copy: "© {year} Laboratoire des Dynamiques Territoriales. Diffusion sous licence Creative Commons BY-NC."
    },
    legalLinks: {
      terms: "Conditions d’utilisation",
      privacy: "Politique de confidentialité",
      cookies: "Gestion des cookies",
      refund: "Politique de remboursement",
      disclaimer: "Mentions de non-responsabilité"
    },
    cookie: {
      title: "Gestion des préférences de cookies",
      body: "Nous utilisons des cookies pour assurer le fonctionnement du site et analyser de manière agrégée l’usage des ressources. Ajustez vos préférences ci-dessous.",
      acceptAll: "Tout accepter",
      declineAll: "Tout refuser",
      manage: "Gérer les préférences",
      save: "Enregistrer les choix",
      toggles: {
        necessary: "Nécessaires (toujours actifs)",
        preferences: "Préférences",
        analytics: "Analytique",
        marketing: "Communication"
      },
      descriptions: {
        necessary: "Garantissent la disponibilité des fonctionnalités essentielles, telles que la sauvegarde de la langue.",
        preferences: "Conservent vos préférences de navigation non essentielles.",
        analytics: "Mesurent l’audience agrégée pour améliorer nos publications.",
        marketing: "Suivent l’engagement avec nos notes externes."
      },
      toastSaved: "Vos préférences de cookies ont été enregistrées.",
      toastDeclined: "Les cookies non essentiels sont désactivés."
    },
    toasts: {
      newsletterSuccess: "Merci de votre inscription à la lettre d’information.",
      formInvalid: "Veuillez compléter l’ensemble des champs requis avant de soumettre.",
      formSubmitted: "Votre formulaire a été transmis. Redirection en cours."
    },
    forms: {
      requiredNote: "Tous les champs marqués d’un astérisque sont obligatoires.",
      nameLabel: "Nom complet *",
      namePlaceholder: "Exemple : Léa Dubois",
      emailLabel: "Adresse électronique *",
      emailPlaceholder: "prenom.nom@example.org",
      organisationLabel: "Organisation",
      organisationPlaceholder: "Institution ou réseau de rattachement",
      messageLabel: "Message *",
      messagePlaceholder: "Indiquez le contexte et vos attentes.",
      submit: "Transmettre",
      newsletterLabel: "Recevoir les synthèses trimestrielles",
      newsletterPlaceholder: "Votre adresse électronique",
      newsletterButton: "S’inscrire",
      consent: "En envoyant ce formulaire, vous acceptez que vos données soient traitées aux fins de prise de contact conformément à la politique de confidentialité."
    },
    meta: {
      index: {
        title: "Laboratoire des Dynamiques Territoriales | Observatoire spatial belge",
        description: "Plateforme d’observation territoriale basée à Bruxelles. Analyses géospatiales, études de mobilité, diagnostics territoriaux et veille sur les transitions urbaines belges."
      },
      services: {
        title: "Axes d’analyse | Laboratoire des Dynamiques Territoriales",
        description: "Panorama des analyses réalisées : modélisation spatiale, études de mobilité, observation socio-économique, diagnostics territoriaux pour la Belgique."
      },
      about: {
        title: "Gouvernance et équipe | Laboratoire des Dynamiques Territoriales",
        description: "Présentation de l’équipe, du cadre méthodologique et du réseau de partenariats du Laboratoire des Dynamiques Territoriales basé à Bruxelles."
      },
      blog: {
        title: "Carnet d’études | Laboratoire des Dynamiques Territoriales",
        description: "Articles techniques et notes de recherche sur les dynamiques territoriales belges, la mobilité, l’aménagement et les indicateurs urbains."
      },
      faq: {
        title: "FAQ | Laboratoire des Dynamiques Territoriales",
        description: "Réponses aux questions fréquentes sur les méthodes, les sources et la diffusion des résultats du Laboratoire des Dynamiques Territoriales."
      },
      contact: {
        title: "Coordonnées et formulaire | Laboratoire des Dynamiques Territoriales",
        description: "Contactez le Laboratoire des Dynamiques Territoriales à Bruxelles, consultez les disponibilités, accédez à la carte et envoyez un message sécurisé."
      },
      terms: {
        title: "Conditions d’utilisation | Laboratoire des Dynamiques Territoriales",
        description: "Conditions d’utilisation du site du Laboratoire des Dynamiques Territoriales couvrant responsabilités, accès aux contenus et mises à jour."
      },
      privacy: {
        title: "Politique de confidentialité | Laboratoire des Dynamiques Territoriales",
        description: "Informations sur la collecte, l’usage, le stockage et les droits relatifs aux données traitées par le Laboratoire des Dynamiques Territoriales."
      },
      cookies: {
        title: "Gestion des cookies | Laboratoire des Dynamiques Territoriales",
        description: "Description des cookies utilisés, des finalités associées et des durées de conservation par le Laboratoire des Dynamiques Territoriales."
      },
      refund: {
        title: "Politique de remboursement | Laboratoire des Dynamiques Territoriales",
        description: "Procédure de contestation et de correction des livrables diffusés par le Laboratoire des Dynamiques Territoriales."
      },
      disclaimer: {
        title: "Mentions de non-responsabilité | Laboratoire des Dynamiques Territoriales",
        description: "Mentions précisant les limites de responsabilité et l’absence de garantie du Laboratoire des Dynamiques Territoriales."
      },
      thankyou: {
        title: "Confirmation d’envoi | Laboratoire des Dynamiques Territoriales",
        description: "Merci pour votre message. Le Laboratoire des Dynamiques Territoriales confirme la bonne réception des informations."
      },
      notfound: {
        title: "Page introuvable | Laboratoire des Dynamiques Territoriales",
        description: "La ressource demandée est introuvable sur le site du Laboratoire des Dynamiques Territoriales."
      },
      post1: {
        title: "Indicateurs composites pour suivre les transitions régionales",
        description: "Analyse de la construction d’indicateurs composites pour évaluer les transitions territoriales en Belgique, de la collecte à l’interprétation."
      },
      post2: {
        title: "Cartographie des mobilités pendulaires belges",
        description: "Méthodologie pour cartographier les mobilités pendulaires et éclairer l’articulation entre emploi et habitat dans les régions belges."
      },
      post3: {
        title: "Résilience énergétique des territoires urbains belges",
        description: "Étude de la résilience énergétique urbaine belge, indicateurs de vulnérabilité et recommandations méthodologiques."
      },
      post4: {
        title: "Effets de la densification douce sur les services essentiels",
        description: "Retour d’expérience sur les effets de la densification douce en Belgique et sa compatibilité avec l’accès aux services essentiels."
      },
      post5: {
        title: "Intégrer l’observation citoyenne dans les diagnostics",
        description: "Méthodes pour intégrer l’observation citoyenne aux diagnostics territoriaux en Belgique."
      }
    },
    home: {
      hero: {
        title: "Observer les interactions territoriales pour éclairer la décision publique belge.",
        subtitle: "Le Laboratoire des Dynamiques Territoriales assemble données géospatiales, corpus qualitatifs et séries temporelles afin de documenter les transformations socio-spatiales du pays.",
        ctaPrimary: "Explorer la méthodologie",
        ctaSecondary: "Consulter les notes récentes",
        imageAlt: "Vue aérienne d’un quartier bruxellois et couches de données cartographiques superposées.",
        stats: {
          s1: {
            value: "215",
            label: "territoires étudiés depuis 2018"
          },
          s2: {
            value: "48",
            label: "indicateurs composites maintenus trimestriellement"
          },
          s3: {
            value: "62",
            label: "partenariats institutionnels documentés"
          }
        }
      },
      featured: {
        title: "Chantiers analytiques prioritaires",
        intro: "Nos productions s’inscrivent dans une logique d’observation régulière et documentée des dynamiques territoriales belges.",
        item1: {
          title: "Veille des transitions territoriales",
          body: "Agrégation d’indicateurs relatifs aux usages du sol, à la performance énergétique et aux profils démographiques afin d’anticiper les zones de tension ou d’opportunité."
        },
        item2: {
          title: "Analyse multi-échelles",
          body: "Couverture simultanée des échelles locale, intercommunale et régionale, avec des jeux de données harmonisés et comparables."
        },
        item3: {
          title: "Documentation ouverte",
          body: "Mise à disposition de fiches méthodologiques et de dictionnaires de données accompagnant chaque publication pour assurer la transparence."
        }
      },
      method: {
        title: "Un protocole reproductible",
        step1: {
          title: "Inventaire des sources",
          body: "Sélection de bases de données institutionnelles, relevés de terrain et contributions citoyennes, évaluées selon leur granularité et fiabilité."
        },
        step2: {
          title: "Traitements et harmonisation",
          body: "Nettoyage, géocodage et normalisation statistique pour garantir la comparabilité spatiale et temporelle."
        },
        step3: {
          title: "Modélisation",
          body: "Application de modèles exploratoires, d’analyses de réseaux et de simulations pour projeter différents scénarios territoriaux."
        },
        step4: {
          title: "Restitution",
          body: "Production de synthèses cartographiques, récits de données et tableaux de bord téléchargeables pour chaque bassin d’étude."
        }
      },
      recommendations: {
        title: "Recommandations opérationnelles",
        intro: "Les synthèses thématiques débouchent sur des recommandations vérifiables et contextualisées.",
        item1: {
          title: "Spatialiser les investissements publics",
          body: "Associer des indicateurs de vulnérabilité territoriale à la programmation budgétaire afin de réduire les disparités infrarégionales."
        },
        item2: {
          title: "Ancrer les politiques de mobilité",
          body: "Croiser horaires, fréquentations et profils socio-économiques pour adapter les dessertes multimodales."
        },
        item3: {
          title: "Fabriquer des indicateurs partagés",
          body: "Mettre en place des nomenclatures inter-administrations facilitant la comparaison et la mutualisation des diagnostics."
        }
      },
      testimonials: {
        title: "Retours d’utilisateurs",
        item1: {
          quote: "Les jeux de données du laboratoire ont permis d’objectiver la hiérarchisation des opérations de rénovation dans notre pacte territorial.",
          author: "Claire G., coordinatrice d’un contrat de quartier à Bruxelles"
        },
        item2: {
          quote: "La documentation méthodologique facilite l’appropriation par les services internes et réduit le temps de vérification.",
          author: "Martin S., analyste à la Région wallonne"
        },
        item3: {
          quote: "Les restitutions trimestrielles éclairent les débats locaux sur la densification tout en gardant une approche mesurée.",
          author: "Dominique L., urbaniste communal"
        }
      },
      blogPreview: {
        title: "Dernières notes du carnet d’études",
        intro: "Cinq articles récents explorent les transitions régionales, la mobilité, l’énergie, la densification douce et l’observation citoyenne.",
        readMore: "Lire le carnet complet",
        card1: {
          title: "Suivre les transitions régionales",
          excerpt: "Construction d’un indice composite pour comparer la progression des transitions territoriales entre provinces belges."
        },
        card2: {
          title: "Mobilités pendulaires",
          excerpt: "Cartographier les flux domicile-travail et comprendre les interrelations fonctionnelles."
        },
        card3: {
          title: "Résilience énergétique",
          excerpt: "Évaluer la capacité des quartiers urbains à absorber les chocs énergétiques."
        }
      },
      newsletter: {
        title: "Lettre d’information trimestrielle",
        description: "Recevez une sélection de tableaux de bord, d’analyses et de graphiques récapitulatifs directement par courrier électronique.",
        consent: "Vous pouvez vous désinscrire à tout moment via le lien présent dans chaque message."
      },
      ctaInsights: {
        title: "Accéder aux ressources techniques",
        description: "Téléchargez les dictionnaires de données, fiches sources et scripts reproductibles associés aux notes de recherche.",
        link: "Parcourir la médiathèque documentaire"
      }
    },
    services: {
      hero: {
        title: "Axes prioritaires d’analyse territoriale",
        subtitle: "Quatre axes structurent le socle de connaissances : morphologie spatiale, mobilités, sociodémographie et transitions économiques.",
        imageAlt: "Analyste manipulant des couches de données sur un écran géospatial."
      },
      intro: "Chaque axe associe données quantitatives, observations qualitatives et protocoles de validation pour produire des diagnostics argumentés.",
      list: {
        title: "Axes détaillés",
        item1: {
          title: "1. Modélisation morphologique",
          body: "Mesure de la densité bâtie, identification des fronts urbains et surveillance de l’artificialisation des sols."
        },
        item2: {
          title: "2. Mobilités quotidiennes",
          body: "Analyse des flux, des temps de parcours et de la connectivité multimodale en semaine et le week-end."
        },
        item3: {
          title: "3. Structures socio-économiques",
          body: "Suivi des revenus, des dynamiques résidentielles et des indicateurs d’inclusion à l’échelle infra-communale."
        },
        item4: {
          title: "4. Transitions productives",
          body: "Cartographie des filières, des pôles d’activités émergents et des besoins en compétences par bassin de vie."
        }
      },
      methodology: {
        title: "Méthode d’assemblage",
        p1: "Chaque axe mobilise un dictionnaire de données versionné, des scripts reproductibles et une revue annuelle des hypothèses.",
        p2: "Les analyses sont documentées dans un registre commun garantissant la traçabilité des transformations et corrections successives."
      },
      outputs: {
        title: "Formats de restitution",
        item1: "Notices synthétiques de 6 pages accompagnées de cartes annotées.",
        item2: "Tableaux de bord interactifs publiés en accès libre.",
        item3: "Kits de jeux de données normalisés prêts à être intégrés dans les SIG institutionnels."
      }
    },
    about: {
      hero: {
        title: "Une structure ancrée à Bruxelles et ouverte sur les territoires",
        subtitle: "Le laboratoire fonctionne comme une plateforme coopérative réunissant analystes, géomaticiens et observateurs locaux.",
        imageAlt: "Réunion de travail autour d’une table avec cartes et ordinateurs."
      },
      mission: {
        title: "Mission",
        paragraph: "Documenter les dynamiques territoriales belges et fournir des analyses reproductibles aux organismes publics, aux collectifs et aux réseaux associatifs."
      },
      timeline: {
        title: "Repères chronologiques",
        item1: {
          title: "2016 — Constitution",
          body: "Création du noyau bruxellois autour d’urbanistes et de statisticiens partageant un référentiel commun."
        },
        item2: {
          title: "2018 — Harmonisation",
          body: "Déploiement d’une infrastructure de données partagée pour consolider les séries temporelles régionales."
        },
        item3: {
          title: "2020 — Participation citoyenne",
          body: "Intégration de dispositifs de collecte contributive via des ateliers et plateformes collaboratives."
        },
        item4: {
          title: "2023 — Diffusion ouverte",
          body: "Publication des scripts de transformation et des dictionnaires de données sous licence ouverte."
        }
      },
      values: {
        title: "Principes structurants",
        item1: {
          title: "Transparence méthodologique",
          body: "Publication systématique des choix de traitement, limites et marges d’erreur."
        },
        item2: {
          title: "Collaboration",
          body: "Co-construction des diagnostics avec les acteurs institutionnels et associatifs."
        },
        item3: {
          title: "Pérennité des données",
          body: "Archivage versionné et aligné sur les standards européens d’interopérabilité."
        }
      },
      team: {
        title: "Gouvernance",
        item1: "Coordination scientifique : Nora Verstraete, géographe.",
        item2: "Responsable données : Karel Aerts, analyste SIG.",
        item3: "Animation réseau local : Salma Benali, urbaniste."
      }
    },
    blog: {
      hero: {
        title: "Carnet d’études territoriales",
        subtitle: "Notes techniques, retours d’expérience et explorations de données sur les dynamiques belges."
      },
      intro: "Les billets disponibles ci-dessous documentent des méthodes appliquées, des jeux de données spécifiques et des recommandations opérationnelles.",
      card1: {
        title: "Indicateurs composites pour suivre les transitions régionales",
        excerpt: "Définition d’un cadre méthodologique pour agréger des dimensions énergétiques, sociales et environnementales."
      },
      card2: {
        title: "Cartographie des mobilités pendulaires belges",
        excerpt: "Analyse des flux domicile-travail et des variations infra-annuelles."
      },
      card3: {
        title: "Résilience énergétique des territoires urbains belges",
        excerpt: "Mesure des vulnérabilités énergétiques et scénarios de résilience locale."
      },
      card4: {
        title: "Effets de la densification douce sur les services essentiels",
        excerpt: "Observation des impacts territoriaux d’une densification graduelle."
      },
      card5: {
        title: "Intégrer l’observation citoyenne dans les diagnostics",
        excerpt: "Protocole pour intégrer des contributions citoyennes vérifiées."
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        subtitle: "Clarifications sur les sources, les fréquences de mise à jour et les formats de diffusion."
      },
      items: {
        q1: {
          question: "Quelles sources alimentez-vous prioritairement ?",
          answer: "Le laboratoire mobilise des données ouvertes régionales, des séries statistiques fédérales et des relevés locaux collectés via des partenaires."
        },
        q2: {
          question: "À quelle fréquence vos indicateurs sont-ils mis à jour ?",
          answer: "La majorité des indicateurs sont rafraîchis trimestriellement, avec des révisions intermédiaires si une source majeure est corrigée."
        },
        q3: {
          question: "Comment validez-vous les contributions citoyennes ?",
          answer: "Chaque contribution est vérifiée par triangulation avec des données officielles ou des observations croisées avant diffusion."
        },
        q4: {
          question: "Proposez-vous des fichiers téléchargeables ?",
          answer: "Oui, chaque note publie un jeu de données au format ouvert accompagné d’une description des champs."
        },
        q5: {
          question: "Quels outils utilisez-vous ?",
          answer: "Les traitements reposent sur des outils libres, principalement QGIS, PostGIS et Python pour les scripts de transformation."
        },
        q6: {
          question: "Comment citer vos travaux ?",
          answer: "Nous fournissons une référence bibliographique type sur chaque fiche, comprenant la date et l’identifiant de version."
        },
        q7: {
          question: "Peut-on proposer un terrain d’étude ?",
          answer: "Oui, un formulaire dédié permet de suggérer un périmètre d’analyse accompagné d’éléments contextuels."
        },
        q8: {
          question: "Comment accéder aux archives ?",
          answer: "Les archives sont consultables via la médiathèque, classées par millésime et par axe thématique."
        }
      }
    },
    contact: {
      hero: {
        title: "Coordonnées et prise de contact",
        subtitle: "Le laboratoire est basé à Bruxelles, avec des permanences hebdomadaires et un suivi par courrier électronique.",
        imageAlt: "Carte stylisée de Bruxelles avec repères géographiques."
      },
      intro: "Nous privilégions des échanges préparés en amont : précisez votre demande et les documents utiles.",
      slots: {
        title: "Disponibilités",
        item1: "Réponses aux courriels : sous 3 jours ouvrés.",
        item2: "Permanences physiques : mercredi 09h30 - 12h30, sur rendez-vous.",
        item3: "Sessions de travail à distance : jeudi après-midi, réservation requise."
      },
      contactCard: {
        title: "Informations directes",
        phone: "Téléphone",
        email: "Courriel",
        address: "Adresse"
      },
      formTitle: "Formulaire de contact",
      mapCaption: "Localisation : Rue des Colonies 36, 1000 Bruxelles.",
      notice: "Les informations transmises sont uniquement utilisées pour répondre à votre message."
    },
    thankyou: {
      title: "Merci pour votre message",
      body: "Votre demande a été transmise. L’équipe du Laboratoire des Dynamiques Territoriales vous répondra dans les meilleurs délais.",
      link: "Retour à l’accueil"
    },
    notfound: {
      title: "Ressource introuvable",
      body: "La page recherchée n’est plus disponible ou l’adresse saisie est incorrecte.",
      link: "Revenir à l’accueil"
    },
    legal: {
      terms: {
        title: "Conditions d’utilisation",
        sections: [
          {
            heading: "1. Objet",
            body: "Les présentes conditions régissent l’accès au site du Laboratoire des Dynamiques Territoriales et l’usage des contenus publiés."
          },
          {
            heading: "2. Définitions",
            body: "Le terme « site » désigne l’ensemble des pages et ressources. « Utilisateur » désigne toute personne consultant ces contenus."
          },
          {
            heading: "3. Acceptation",
            body: "En naviguant sur le site, vous acceptez sans réserve les présentes conditions. En cas de désaccord, cessez votre consultation."
          },
          {
            heading: "4. Accès",
            body: "Le site est accessible gratuitement. Nous pouvons suspendre l’accès pour maintenance ou mise à jour sans préavis."
          },
          {
            heading: "5. Contenus",
            body: "Les contenus textuels, graphiques et cartographiques sont fournis à titre informatif. Les sources sont mentionnées lorsque disponible."
          },
          {
            heading: "6. Responsabilité",
            body: "Nous mettons tout en œuvre pour assurer l’exactitude des informations, sans garantir leur exhaustivité ou leur actualité permanente."
          },
          {
            heading: "7. Contributions externes",
            body: "Les contributions tierces sont intégrées après vérification. Les contributeurs demeurent responsables de leurs propos."
          },
          {
            heading: "8. Hyperliens",
            body: "Le site peut contenir des liens vers des ressources externes. Nous ne contrôlons pas ces contenus et déclinons toute responsabilité."
          },
          {
            heading: "9. Propriété intellectuelle",
            body: "Sauf mention contraire, les contenus sont diffusés sous licence Creative Commons BY-NC. Merci de citer la source."
          },
          {
            heading: "10. Données personnelles",
            body: "Le traitement des données est décrit dans la politique de confidentialité. Aucune donnée n’est cédée à des tiers."
          },
          {
            heading: "11. Sécurité",
            body: "Les utilisateurs s’engagent à ne pas perturber le fonctionnement du site ni tenter d’accéder aux zones non autorisées."
          },
          {
            heading: "12. Modification",
            body: "Nous pouvons modifier les présentes conditions. La date de mise à jour est indiquée en bas de page."
          },
          {
            heading: "13. Droit applicable",
            body: "Les présentes conditions sont régies par le droit belge. Tout litige relève des juridictions de Bruxelles."
          },
          {
            heading: "14. Contact",
            body: "Pour toute question relative à ces conditions, écrivez à contact@ldt-insights.be."
          }
        ]
      },
      privacy: {
        title: "Politique de confidentialité",
        sections: [
          {
            heading: "1. Responsable du traitement",
            body: "Le Laboratoire des Dynamiques Territoriales, basé à Bruxelles, est responsable du traitement des données collectées sur ce site."
          },
          {
            heading: "2. Données collectées",
            body: "Nous collectons les informations fournies via les formulaires (identité, coordonnées, organisation, message) et les préférences cookies."
          },
          {
            heading: "3. Finalités",
            body: "Les données sont utilisées pour répondre aux messages, diffuser les lettres d’information et améliorer nos publications."
          },
          {
            heading: "4. Base légale",
            body: "Le traitement repose sur l’intérêt légitime lié à la gestion des demandes et sur le consentement pour la lettre d’information."
          },
          {
            heading: "5. Durée de conservation",
            body: "Les messages sont conservés trois ans. Les inscriptions à la lettre sont conservées jusqu’à désinscription. Les préférences cookies 12 mois."
          },
          {
            heading: "6. Destinataires",
            body: "Les données ne sont partagées qu’avec les membres habilités du laboratoire et ne sont pas transférées hors de l’Union européenne."
          },
          {
            heading: "7. Sécurité",
            body: "Nous utilisons des protocoles chiffrés et contrôlons les accès internes pour limiter les risques de divulgation."
          },
          {
            heading: "8. Droits des personnes",
            body: "Vous pouvez demander l’accès, la rectification, l’effacement ou la limitation du traitement de vos données."
          },
          {
            heading: "9. Exercice des droits",
            body: "Adressez vos demandes à contact@ldt-insights.be en précisant l’objet et en justifiant de votre identité."
          },
          {
            heading: "10. Autorité de contrôle",
            body: "Vous pouvez introduire une réclamation auprès de l’Autorité de protection des données (Rue de la Presse 35, 1000 Bruxelles)."
          }
        ]
      },
      cookies: {
        title: "Gestion des cookies",
        intro: "Ce tableau présente les cookies utilisés sur le site, leur fournisseur, leur finalité et leur durée.",
        table: {
          headers: {
            name: "Nom",
            provider: "Fournisseur",
            type: "Type",
            purpose: "Finalité",
            duration: "Durée"
          },
          rows: [
            {
              name: "site_lang",
              provider: "ldt-insights.be",
              type: "Nécessaire",
              purpose: "Sauvegarde de la langue sélectionnée.",
              duration: "12 mois"
            },
            {
              name: "cookie_consent",
              provider: "ldt-insights.be",
              type: "Préférences",
              purpose: "Conservation des choix exprimés sur les cookies.",
              duration: "12 mois"
            },
            {
              name: "analytics_session",
              provider: "ldt-insights.be",
              type: "Analytique",
              purpose: "Mesure d’audience agrégée et anonymisée.",
              duration: "6 mois"
            },
            {
              name: "outreach_token",
              provider: "ldt-insights.be",
              type: "Communication",
              purpose: "Suivi des interactions avec les notes partagées par courriel.",
              duration: "3 mois"
            }
          ]
        },
        update: "Dernière mise à jour : janvier 2024."
      },
      refund: {
        title: "Politique de remboursement",
        intro: "Cette procédure détaille la manière de signaler une erreur ou de demander une correction relative aux livrables diffusés.",
        sections: [
          { heading: "1. Champ d’application", body: "La présente politique couvre les livrables numériques mis à disposition par le laboratoire." },
          { heading: "2. Notification", body: "Toute demande doit être adressée par écrit en précisant la ressource concernée et la nature de l’erreur." },
          { heading: "3. Délai de signalement", body: "Les demandes sont recevables dans un délai de 30 jours suivant la diffusion officielle du livrable." },
          { heading: "4. Accusé de réception", body: "Un accusé de réception est envoyé dans les 5 jours ouvrés avec un numéro de suivi." },
          { heading: "5. Analyse", body: "L’équipe vérifie la demande, reproduit la situation et identifie l’origine de l’anomalie." },
          { heading: "6. Correctifs", body: "Lorsque l’erreur est avérée, une version corrigée est publiée et référencée." },
          { heading: "7. Notification des parties", body: "Les personnes ayant téléchargé le livrable sont averties de la correction par courrier électronique." },
          { heading: "8. Limites", body: "Les demandes portant sur des usages détournés ou des interprétations erronées ne sont pas couvertes." },
          { heading: "9. Suivi", body: "Chaque dossier est consigné dans un registre interne pour assurer la traçabilité." },
          { heading: "10. Contact", body: "Adressez vos demandes à correction@ldt-insights.be en mentionnant le numéro de version." }
        ]
      },
      disclaimer: {
        title: "Mentions de non-responsabilité",
        sections: [
          {
            heading: "1. Généralités",
            body: "Les informations publiées sont fournies à titre informatif sans constituer un avis professionnel."
          },
          {
            heading: "2. Exactitude",
            body: "Malgré le soin apporté, des erreurs peuvent subsister. Les utilisateurs doivent vérifier les données avant toute utilisation."
          },
          {
            heading: "3. Responsabilité",
            body: "Le laboratoire ne saurait être tenu responsable des décisions prises sur la base des contenus publiés."
          },
          {
            heading: "4. Liens externes",
            body: "Nous déclinons toute responsabilité concernant les contenus des sites externes référencés."
          },
          {
            heading: "5. Continuité",
            body: "La disponibilité du site peut être suspendue sans préavis pour maintenance ou mise à jour."
          },
          {
            heading: "6. Évolution",
            body: "Ces mentions peuvent être modifiées à tout moment pour refléter l’évolution de nos pratiques."
          }
        ]
      }
    },
    posts: {
      post1: {
        heroAlt: "Cartes thématiques colorées affichant des indicateurs régionaux.",
        title: "Indicateurs composites pour suivre les transitions régionales",
        intro: "Les transitions territoriales impliquent des dimensions multiples qu’un seul indicateur ne peut résumer. Ce billet décrit la construction d’un indice composite destiné à comparer les dynamiques régionales belges sur la période 2015-2023.",
        section1: {
          h2: "Définir un périmètre et des hypothèses",
          p1: "La première étape consiste à fixer les critères de sélection des dimensions. Nous avons retenu quatre piliers : sobriété énergétique, inclusion sociale, dynamisme économique et préservation environnementale. Chaque pilier regroupe plusieurs variables issues de sources fédérales et régionales.",
          p2: "Pour garantir la comparabilité temporelle, la série est limitée à 2015-2023, période au cours de laquelle la majorité des bases de données possède une couverture homogène. Les valeurs manquantes sont imputées par moyenne mobile lorsqu’au moins trois observations sont disponibles."
        },
        section2: {
          h2: "Normalisation et pondération",
          p1: "Les variables étant exprimées dans des unités différentes, la normalisation par score z a été privilégiée. Cette méthode maintient la distribution relative des données sans imposer de bornes arbitraires.",
          p2: "La pondération a été élaborée avec un panel d’experts représentant les régions et plusieurs villes centres. Chaque pilier reçoit un poids identique afin de ne pas favoriser un champ spécifique. Au sein des piliers, les variables sont pondérées selon leur fiabilité et leur sensibilité aux évolutions conjoncturelles.",
          p3: "Une analyse de sensibilité a été conduite pour vérifier l’influence de chaque variable. Les scénarios alternatifs ont montré une stabilité des classements, ce qui valide la pondération retenue."
        },
        section3: {
          h2: "Validation et interprétation",
          h3: "Tests de robustesse",
          p1: "Plusieurs tests de robustesse ont été appliqués : suppression d’une variable à la fois, modification des périodes de référence et comparaison avec des indicateurs européens. Les écarts observés restent contenus, ce qui conforte la structure de l’indice.",
          p2: "La cartographie finale révèle des trajectoires différenciées entre provinces. Certaines combinent un progrès net sur l’énergie et l’environnement mais stagnent sur l’inclusion sociale. L’indice composite met en lumière ces contrastes et facilite les discussions interrégionales.",
          p3: "L’exercice démontre la nécessité de documenter chaque étape de construction. Les métadonnées sont intégrées dans notre médiathèque, accompagnées des scripts reproductibles et des seuils d’alerte utilisés pour les analyses trimestrielles."
        }
      },
      post2: {
        heroAlt: "Visualisation des flux de déplacement entre villes belges.",
        title: "Cartographie des mobilités pendulaires belges",
        intro: "Comprendre les mobilités pendulaires demeure crucial pour ajuster les politiques de transport et d’aménagement. Cette étude s’appuie sur des données anonymisées de déplacements domicile-travail couvrant l’ensemble du territoire belge.",
        section1: {
          h2: "Sources et granularité",
          p1: "Les données proviennent des déclarations sociales, croisées avec des enquêtes ménages. Les flux sont agrégés au niveau des bassins de vie pour concilier précision et respect de la confidentialité.",
          p2: "Une attention particulière est portée aux temporalités : plages horaires de pointe, jours de semaine, saisonnalité. Les variations saisonnières influencent les réseaux, notamment dans les provinces touristiques."
        },
        section2: {
          h2: "Méthodes de cartographie",
          p1: "Les flux sont modélisés via des matrices origine-destination. Nous utilisons ensuite une représentation graphique en arcs pondérés, complétée par des cartes de chaleur pour les densités.",
          p2: "Pour éviter la confusion visuelle, les flux faibles sont regroupés et représentés par des gradients subtils. Les cartes interactives permettent d’activer ou désactiver des catégories de flux selon le mode de transport principal.",
          p3: "Les résultats soulignent l’importance des interrelations interprovinciales, notamment entre Brabant flamand et Brabant wallon. Les gares périphériques jouent un rôle d’interface qu’il convient d’intégrer aux scénarios d’évolution."
        },
        section3: {
          h2: "Implications pour les politiques publiques",
          h3: "Éclairages opérationnels",
          p1: "Les analyses confirment la nécessité de renforcer les dessertes multimodales dans les zones périurbaines où l’automobile reste dominante. Les données mettent aussi en évidence des flux émergents liés aux nouvelles polarités d’emploi.",
          p2: "En articulant ces résultats avec les indicateurs d’accessibilité aux services, les décideurs peuvent prioriser les investissements et coordonner les calendriers de travaux.",
          p3: "Nous fournissons en annexe un guide de lecture des cartes, rappelant les limites méthodologiques et les précautions d’interprétation sur les flux de courte distance."
        }
      },
      post3: {
        heroAlt: "Réseau électrique schématisé superposé à un plan urbain.",
        title: "Résilience énergétique des territoires urbains belges",
        intro: "La résilience énergétique interroge la capacité des quartiers urbains à absorber des perturbations. Cette analyse examine des indicateurs de vulnérabilité et de capacité d’adaptation pour plusieurs villes belges.",
        section1: {
          h2: "Construire un cadre d’évaluation",
          p1: "Nous avons retenu trois dimensions : dépendance énergétique, diversification des sources et capacité de flexibilité. Chaque dimension est nourrie par des données issues des opérateurs et des inventaires locaux.",
          p2: "Les données sont ajustées pour tenir compte des spécificités climatiques régionales. Les quartiers étudiés couvrent des typologies variées, de la cité-jardin au tissu hyperdense."
        },
        section2: {
          h2: "Résultats principaux",
          p1: "Les cartes d’exposition révèlent des vulnérabilités concentrées dans les tissus anciens peu rénovés. Les quartiers récents affichent une meilleure performance mais restent dépendants des réseaux externes.",
          p2: "La diversification énergétique progresse, notamment via des installations photovoltaïques collectives. Cependant, la flexibilité reste limitée faute d’infrastructures de stockage.",
          p3: "L’analyse suggère de renforcer les programmes de rénovation énergétique ciblés et d’accompagner les copropriétés dans la gestion collective des équipements."
        },
        section3: {
          h2: "Perspectives de suivi",
          h3: "Indicateurs à consolider",
          p1: "Nous proposons un tableau de bord minimal comprenant la consommation finale, la part d’énergie renouvelable et la capacité de délestage. Ces indicateurs sont suivis trimestriellement.",
          p2: "Les données sont croisées avec les trajectoires climatiques régionales pour mesurer la cohérence entre objectifs et réalisations.",
          p3: "La transparence des opérateurs reste déterminante : un dialogue régulier est engagé pour améliorer la granularité des données partagées."
        }
      },
      post4: {
        heroAlt: "Rue résidentielle verdoyante illustrant la densification douce.",
        title: "Effets de la densification douce sur les services essentiels",
        intro: "La densification douce, addition modérée de logements dans le tissu existant, soulève des interrogations sur les services essentiels. Nous analysons plusieurs cas belges pour mesurer les impacts concrets.",
        section1: {
          h2: "Cadre d’observation",
          p1: "L’étude porte sur quatre communes ayant adopté des dispositifs d’encadrement de la densification. Les critères portent sur le nombre d’unités ajoutées, la qualité architecturale et la disponibilité des services.",
          p2: "Des entretiens menés avec les gestionnaires locaux complètent les données quantitatives. Les observations s’étendent sur cinq ans afin de capter les effets progressifs."
        },
        section2: {
          h2: "Effets sur les services",
          p1: "L’augmentation de population reste maîtrisée, ce qui limite la pression sur les écoles et les transports. Des ajustements ponctuels ont toutefois été nécessaires pour les équipements de santé.",
          p2: "Les commerces de proximité bénéficient d’une clientèle élargie, à condition que la mixité fonctionnelle soit préservée. Les communes ont renforcé les règlements pour maintenir des rez-de-chaussée actifs.",
          p3: "La densification douce s’avère compatible avec la protection des espaces verts, lorsque des exigences de végétalisation accompagnent les projets."
        },
        section3: {
          h2: "Recommandations",
          h3: "Pistes opérationnelles",
          p1: "Mettre en place des observatoires locaux associant habitants, opérateurs et services techniques pour suivre l’évolution des indicateurs clés.",
          p2: "Adopter des chartes qualitatives définissant des seuils de densité, d’espaces partagés et de performance énergétique.",
          p3: "Assurer un financement pérenne pour les services essentiels via des mécanismes redistributifs alignés sur la croissance démographique."
        }
      },
      post5: {
        heroAlt: "Citoyens recueillant des informations dans l’espace public.",
        title: "Intégrer l’observation citoyenne dans les diagnostics",
        intro: "L’observation citoyenne apporte un complément qualitatif aux données institutionnelles. Ce billet décrit un protocole pour intégrer ces contributions dans les diagnostics territoriaux belges.",
        section1: {
          h2: "Cadre participatif",
          p1: "Le dispositif repose sur des ateliers locaux, des formulaires en ligne et des parcours commentés. Chaque contribution est structurée selon une grille commune pour faciliter l’analyse.",
          p2: "Les participants reçoivent un retour sur la prise en compte de leurs observations, ce qui renforce la confiance et la qualité des contributions."
        },
        section2: {
          h2: "Validation et agrégation",
          p1: "Les observations sont géolocalisées et croisées avec des données existantes. Une grille d’évaluation mesure la cohérence, la précision et la fréquence.",
          p2: "Les contributions validées alimentent une base partagée accessible aux partenaires. Les éléments contestés font l’objet d’investigations supplémentaires.",
          p3: "Ce processus garantit que les contributions enrichissent le diagnostic sans introduire de biais majeurs."
        },
        section3: {
          h2: "Valorisation opérationnelle",
          h3: "Mise en récit",
          p1: "Les données citoyennes sont intégrées dans les récits de territoire sous forme de cartographies interactives et de verbatim contextualisés.",
          p2: "Les décideurs disposent ainsi d’une vision qualitative qui complète les analyses statistiques.",
          p3: "La démarche favorise aussi l’appropriation locale des diagnostics et la construction de plans d’action concertés."
        }
      }
    },
    thankYouPage: {
      button: "Retourner au site"
    }
  },
  en: {
    brand: {
      name: "Laboratory for Territorial Dynamics",
      tagline: "Mapping spatial interactions to support public decision-making."
    },
    nav: {
      home: "Home",
      services: "Analysis Axes",
      about: "Governance",
      blog: "Study Notebook",
      faq: "FAQ",
      contact: "Contact",
      menuToggle: "Menu",
      skipToContent: "Skip to main content"
    },
    language: {
      fr: "FR",
      en: "EN"
    },
    footer: {
      phone: "Phone: +32 2 320 45 67",
      email: "Email: contact@ldt-insights.be",
      addressLabel: "Address",
      addressValue: "Laboratory for Territorial Dynamics · Rue des Colonies 36, 1000 Brussels, Belgium",
      legalTitle: "Reference documents",
      copy: "© {year} Laboratory for Territorial Dynamics. Released under Creative Commons BY-NC."
    },
    legalLinks: {
      terms: "Terms of use",
      privacy: "Privacy policy",
      cookies: "Cookie management",
      refund: "Refund policy",
      disclaimer: "Disclaimer"
    },
    cookie: {
      title: "Cookie preference management",
      body: "We use cookies to keep the site running and to analyse aggregate usage. Adjust your preferences below.",
      acceptAll: "Accept all",
      declineAll: "Decline all",
      manage: "Manage preferences",
      save: "Save choices",
      toggles: {
        necessary: "Necessary (always on)",
        preferences: "Preferences",
        analytics: "Analytics",
        marketing: "Outreach"
      },
      descriptions: {
        necessary: "Ensure availability of essential features such as language storage.",
        preferences: "Keep non-essential browsing preferences.",
        analytics: "Measure aggregate audience to improve publications.",
        marketing: "Track engagement with shared briefs."
      },
      toastSaved: "Your cookie preferences have been saved.",
      toastDeclined: "Non-essential cookies are disabled."
    },
    toasts: {
      newsletterSuccess: "Thank you for subscribing to the briefing letter.",
      formInvalid: "Please complete all required fields before submitting.",
      formSubmitted: "Your form has been sent. Redirecting shortly."
    },
    forms: {
      requiredNote: "All fields marked with an asterisk are mandatory.",
      nameLabel: "Full name *",
      namePlaceholder: "Example: Lea Dubois",
      emailLabel: "Email address *",
      emailPlaceholder: "firstname.lastname@example.org",
      organisationLabel: "Organisation",
      organisationPlaceholder: "Affiliated institution or network",
      messageLabel: "Message *",
      messagePlaceholder: "Describe the context and your expectations.",
      submit: "Send",
      newsletterLabel: "Receive quarterly briefings",
      newsletterPlaceholder: "Your email address",
      newsletterButton: "Subscribe",
      consent: "By submitting this form you agree that your data will be processed to answer your request in line with the privacy policy."
    },
    meta: {
      index: {
        title: "Laboratory for Territorial Dynamics | Belgian spatial observatory",
        description: "Brussels-based territorial observatory. Geospatial assessments, mobility studies, territorial diagnostics and monitoring of Belgian urban transitions."
      },
      services: {
        title: "Analysis axes | Laboratory for Territorial Dynamics",
        description: "Overview of analytical focuses: spatial modelling, mobility studies, socio-economic observation and territorial diagnostics in Belgium."
      },
      about: {
        title: "Governance and team | Laboratory for Territorial Dynamics",
        description: "Team structure, methodological framework and partnership network of the Brussels-based Laboratory for Territorial Dynamics."
      },
      blog: {
        title: "Study notebook | Laboratory for Territorial Dynamics",
        description: "Technical articles and research notes on Belgian territorial dynamics, mobility, planning and urban indicators."
      },
      faq: {
        title: "FAQ | Laboratory for Territorial Dynamics",
        description: "Answers to frequent questions about the methods, sources and dissemination of the Laboratory for Territorial Dynamics."
      },
      contact: {
        title: "Contact details and form | Laboratory for Territorial Dynamics",
        description: "Reach the Laboratory for Territorial Dynamics in Brussels, check availability, access the map and send a secure message."
      },
      terms: {
        title: "Terms of use | Laboratory for Territorial Dynamics",
        description: "Terms governing the use of the Laboratory for Territorial Dynamics website, covering responsibilities, content access and updates."
      },
      privacy: {
        title: "Privacy policy | Laboratory for Territorial Dynamics",
        description: "Information about collection, usage, storage and rights related to data processed by the Laboratory for Territorial Dynamics."
      },
      cookies: {
        title: "Cookie management | Laboratory for Territorial Dynamics",
        description: "Description of the cookies used, associated purposes and retention periods by the Laboratory for Territorial Dynamics."
      },
      refund: {
        title: "Refund policy | Laboratory for Territorial Dynamics",
        description: "Procedure to report issues or request corrections for releases issued by the Laboratory for Territorial Dynamics."
      },
      disclaimer: {
        title: "Disclaimer | Laboratory for Territorial Dynamics",
        description: "Statements outlining the liability limits and absence of guarantees from the Laboratory for Territorial Dynamics."
      },
      thankyou: {
        title: "Submission confirmed | Laboratory for Territorial Dynamics",
        description: "Thank you for your message. The Laboratory for Territorial Dynamics confirms receipt of the submitted information."
      },
      notfound: {
        title: "Page not found | Laboratory for Territorial Dynamics",
        description: "The requested resource could not be found on the Laboratory for Territorial Dynamics website."
      },
      post1: {
        title: "Composite indicators for tracking regional transitions",
        description: "Analysis of how composite indicators are built to assess territorial transitions across Belgium, from collection to interpretation."
      },
      post2: {
        title: "Mapping Belgian commuter flows",
        description: "Methodology to map commuter mobility and clarify the interplay between jobs and housing for Belgian regions."
      },
      post3: {
        title: "Energy resilience of Belgian urban territories",
        description: "Study on Belgian urban energy resilience, vulnerability indicators and methodological recommendations."
      },
      post4: {
        title: "Soft densification and essential services",
        description: "Lessons learned on the effects of gentle densification in Belgium and its compatibility with access to essential services."
      },
      post5: {
        title: "Integrating citizen observation into diagnostics",
        description: "Methods to weave citizen observation into territorial diagnostics in Belgium."
      }
    },
    home: {
      hero: {
        title: "Monitoring territorial interactions to inform Belgian public action.",
        subtitle: "The Laboratory for Territorial Dynamics combines geospatial data, qualitative corpora and time series to document the country’s socio-spatial shifts.",
        ctaPrimary: "Explore the methodology",
        ctaSecondary: "Review recent notes",
        imageAlt: "Aerial view of a Brussels district with layered cartographic data.",
        stats: {
          s1: {
            value: "215",
            label: "territorial clusters analysed since 2018"
          },
          s2: {
            value: "48",
            label: "composite indicators maintained quarterly"
          },
          s3: {
            value: "62",
            label: "documented institutional partnerships"
          }
        }
      },
      featured: {
        title: "Priority analytical streams",
        intro: "Our outputs follow a consistent observation protocol to keep track of Belgian territorial dynamics.",
        item1: {
          title: "Transition monitoring",
          body: "Aggregating indicators related to land use, energy performance and demographic profiles to anticipate areas of stress or opportunity."
        },
        item2: {
          title: "Multi-scale analysis",
          body: "Simultaneous coverage of local, inter-municipal and regional scales with harmonised and comparable datasets."
        },
        item3: {
          title: "Open documentation",
          body: "Each publication includes methodological briefs and data dictionaries to ensure transparency."
        }
      },
      method: {
        title: "A reproducible protocol",
        step1: {
          title: "Source inventory",
          body: "Selecting institutional datasets, field surveys and citizen contributions assessed for granularity and reliability."
        },
        step2: {
          title: "Processing and harmonisation",
          body: "Cleaning, geocoding and statistical normalisation to guarantee spatial and temporal comparability."
        },
        step3: {
          title: "Modelling",
          body: "Applying exploratory models, network analyses and simulations to project territorial scenarios."
        },
        step4: {
          title: "Dissemination",
          body: "Publishing cartographic summaries, data stories and downloadable dashboards for each study area."
        }
      },
      recommendations: {
        title: "Operational recommendations",
        intro: "The thematic syntheses produce verifiable and contextualised guidance.",
        item1: {
          title: "Spatialise public investment",
          body: "Link territorial vulnerability indicators with budget programming to reduce sub-regional disparities."
        },
        item2: {
          title: "Anchor mobility policies",
          body: "Cross schedules, usage levels and socio-economic profiles to adjust multimodal services."
        },
        item3: {
          title: "Build shared indicators",
          body: "Set inter-administration nomenclatures to facilitate comparison and mutualisation of diagnostics."
        }
      },
      testimonials: {
        title: "User feedback",
        item1: {
          quote: "The lab’s datasets helped us rank renovation operations within our territorial pact on a solid evidence base.",
          author: "Claire G., Brussels neighbourhood contract coordinator"
        },
        item2: {
          quote: "The methodological notes make internal adoption smoother and reduce cross-checking time.",
          author: "Martin S., Walloon Region analyst"
        },
        item3: {
          quote: "Quarterly updates clarify local debates on densification while keeping a balanced approach.",
          author: "Dominique L., municipal planner"
        }
      },
      blogPreview: {
        title: "Latest notebook entries",
        intro: "Five recent articles explore regional transitions, mobility, energy, soft densification and citizen observation.",
        readMore: "Read the full notebook",
        card1: {
          title: "Tracking regional transitions",
          excerpt: "Building a composite index to compare territorial transitions across Belgian provinces."
        },
        card2: {
          title: "Commuter mobility",
          excerpt: "Mapping home-to-work flows and decoding functional interrelations."
        },
        card3: {
          title: "Energy resilience",
          excerpt: "Assessing neighbourhood capacity to absorb energy shocks."
        }
      },
      newsletter: {
        title: "Quarterly briefing letter",
        description: "Receive a selection of dashboards, analyses and summary charts straight to your inbox.",
        consent: "You may unsubscribe at any time using the link provided in each message."
      },
      ctaInsights: {
        title: "Access technical resources",
        description: "Download data dictionaries, source sheets and reproducible scripts linked to the research notes.",
        link: "Browse the documentation hub"
      }
    },
    services: {
      hero: {
        title: "Core territorial analysis axes",
        subtitle: "Four axes structure the knowledge base: spatial morphology, mobility, socio-demographics and economic transitions.",
        imageAlt: "Analyst manipulating layers of data on a geospatial screen."
      },
      intro: "Each axis combines quantitative data, qualitative observations and validation protocols to produce evidenced diagnostics.",
      list: {
        title: "Detailed axes",
        item1: {
          title: "1. Morphological modelling",
          body: "Measuring built density, detecting urban fronts and monitoring land artificialisation."
        },
        item2: {
          title: "2. Daily mobility",
          body: "Analysing flows, travel times and multimodal connectivity on weekdays and weekends."
        },
        item3: {
          title: "3. Socio-economic structures",
          body: "Tracking income, residential dynamics and inclusion indicators at sub-municipal level."
        },
        item4: {
          title: "4. Productive transitions",
          body: "Mapping emerging clusters, activity poles and skills needs per living area."
        }
      },
      methodology: {
        title: "Assembly method",
        p1: "Each axis relies on versioned data dictionaries, reproducible scripts and an annual review of assumptions.",
        p2: "Analyses are documented within a shared register to guarantee traceability of transformations and corrections."
      },
      outputs: {
        title: "Output formats",
        item1: "Six-page briefs with annotated maps.",
        item2: "Interactive dashboards released openly.",
        item3: "Normalised datasets ready for institutional GIS integration."
      }
    },
    about: {
      hero: {
        title: "A Brussels-based structure open to territories",
        subtitle: "The laboratory acts as a cooperative platform bringing together analysts, geomaticians and local observers.",
        imageAlt: "Work meeting around a table with maps and laptops."
      },
      mission: {
        title: "Mission",
        paragraph: "Document Belgian territorial dynamics and provide reproducible analyses to public bodies, collectives and civic networks."
      },
      timeline: {
        title: "Key milestones",
        item1: {
          title: "2016 — Foundation",
          body: "Creation of the Brussels core by urban planners and statisticians sharing a common framework."
        },
        item2: {
          title: "2018 — Harmonisation",
          body: "Deployment of a shared data infrastructure to consolidate regional time series."
        },
        item3: {
          title: "2020 — Citizen participation",
          body: "Integration of contributive collection through workshops and collaborative platforms."
        },
        item4: {
          title: "2023 — Open dissemination",
          body: "Publication of processing scripts and data dictionaries under an open licence."
        }
      },
      values: {
        title: "Core principles",
        item1: {
          title: "Methodological transparency",
          body: "Systematically publishing processing choices, limits and margins of error."
        },
        item2: {
          title: "Collaboration",
          body: "Co-designing diagnostics with institutional and civic actors."
        },
        item3: {
          title: "Data durability",
          body: "Versioned archiving aligned with European interoperability standards."
        }
      },
      team: {
        title: "Governance",
        item1: "Scientific coordination: Nora Verstraete, geographer.",
        item2: "Data lead: Karel Aerts, GIS analyst.",
        item3: "Local network facilitation: Salma Benali, urban planner."
      }
    },
    blog: {
      hero: {
        title: "Territorial study notebook",
        subtitle: "Technical notes, feedback and data explorations on Belgian dynamics."
      },
      intro: "The articles below document applied methods, specific datasets and operational recommendations.",
      card1: {
        title: "Composite indicators for tracking regional transitions",
        excerpt: "Designing a methodological framework to aggregate energy, social and environmental dimensions."
      },
      card2: {
        title: "Mapping Belgian commuter flows",
        excerpt: "Analysing home-to-work flows and infra-annual variations."
      },
      card3: {
        title: "Energy resilience of Belgian urban territories",
        excerpt: "Measuring energy vulnerabilities and local resilience scenarios."
      },
      card4: {
        title: "Soft densification and essential services",
        excerpt: "Observing territorial impacts of gradual densification."
      },
      card5: {
        title: "Integrating citizen observation into diagnostics",
        excerpt: "Protocol for integrating verified citizen contributions."
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        subtitle: "Clarifications about sources, update frequency and dissemination formats."
      },
      items: {
        q1: {
          question: "Which sources do you prioritise?",
          answer: "We rely on regional open data, federal statistical series and locally collected records through partners."
        },
        q2: {
          question: "How often are indicators updated?",
          answer: "Most indicators are refreshed quarterly, with interim revisions when major sources are corrected."
        },
        q3: {
          question: "How are citizen contributions validated?",
          answer: "Each contribution is cross-checked with official data or corroborated observations before publication."
        },
        q4: {
          question: "Do you provide downloadable files?",
          answer: "Yes, every note publishes an open format dataset along with a field description."
        },
        q5: {
          question: "Which tools are used?",
          answer: "Processing relies on open-source tools, mainly QGIS, PostGIS and Python for transformation scripts."
        },
        q6: {
          question: "How should your work be cited?",
          answer: "Each brief includes a citation template with date and version identifier."
        },
        q7: {
          question: "Can new study areas be suggested?",
          answer: "Yes, a dedicated form allows proposals including contextual information."
        },
        q8: {
          question: "How to access archives?",
          answer: "Archives are available through the media library, sorted by year and thematic axis."
        }
      }
    },
    contact: {
      hero: {
        title: "Contact and coordination",
        subtitle: "The laboratory operates from Brussels, with weekly office hours and email follow-up.",
        imageAlt: "Stylised map of Brussels with location markers."
      },
      intro: "We encourage prepared exchanges: provide context and relevant documents in advance.",
      slots: {
        title: "Availability",
        item1: "Email replies: within 3 working days.",
        item2: "On-site office hours: Wednesday 09:30 - 12:30, upon appointment.",
        item3: "Remote working sessions: Thursday afternoon, booking required."
      },
      contactCard: {
        title: "Direct information",
        phone: "Phone",
        email: "Email",
        address: "Address"
      },
      formTitle: "Contact form",
      mapCaption: "Location: Rue des Colonies 36, 1000 Brussels.",
      notice: "Information submitted is only used to answer your request."
    },
    thankyou: {
      title: "Thank you for your message",
      body: "Your request has been received. The Laboratory for Territorial Dynamics will get back to you shortly.",
      link: "Back to home"
    },
    notfound: {
      title: "Resource not found",
      body: "The page you were looking for is not available or the address was incorrect.",
      link: "Return to home"
    },
    legal: {
      terms: {
        title: "Terms of use",
        sections: [
          {
            heading: "1. Purpose",
            body: "These terms govern access to the Laboratory for Territorial Dynamics website and use of the published content."
          },
          {
            heading: "2. Definitions",
            body: "“Site” refers to all pages and resources. “User” refers to any person consulting these materials."
          },
          {
            heading: "3. Acceptance",
            body: "By browsing the site you accept these terms without reservation. If you disagree, stop browsing."
          },
          {
            heading: "4. Access",
            body: "The site is freely accessible. We may suspend access for maintenance or updates without notice."
          },
          {
            heading: "5. Content",
            body: "Textual, graphic and cartographic materials are provided for information. Sources are cited whenever available."
          },
          {
            heading: "6. Liability",
            body: "We strive for accuracy but cannot guarantee exhaustive or permanently up-to-date information."
          },
          {
            heading: "7. External contributions",
            body: "Third-party contributions are integrated after verification. Contributors remain responsible for their statements."
          },
          {
            heading: "8. Hyperlinks",
            body: "The site may contain links to external resources. We do not control those contents and accept no responsibility."
          },
          {
            heading: "9. Intellectual property",
            body: "Unless stated otherwise, contents are released under Creative Commons BY-NC. Please cite the source."
          },
          {
            heading: "10. Personal data",
            body: "Data processing is described in the privacy policy. No data is transferred to third parties."
          },
          {
            heading: "11. Security",
            body: "Users agree not to disrupt site operations or attempt to access unauthorised areas."
          },
          {
            heading: "12. Changes",
            body: "We may amend these terms. The update date is shown at the bottom of the page."
          },
          {
            heading: "13. Governing law",
            body: "These terms are governed by Belgian law. Courts of Brussels have jurisdiction."
          },
          {
            heading: "14. Contact",
            body: "Questions regarding these terms can be sent to contact@ldt-insights.be."
          }
        ]
      },
      privacy: {
        title: "Privacy policy",
        sections: [
          {
            heading: "1. Data controller",
            body: "The Laboratory for Territorial Dynamics, based in Brussels, is the controller for data collected on this site."
          },
          {
            heading: "2. Data collected",
            body: "We collect information provided through forms (identity, contact details, organisation, message) and cookie preferences."
          },
          {
            heading: "3. Purposes",
            body: "Data is used to answer messages, send the briefing letter and improve our publications."
          },
          {
            heading: "4. Legal basis",
            body: "Processing relies on legitimate interest for handling requests and on consent for the briefing letter."
          },
          {
            heading: "5. Retention",
            body: "Messages are stored for three years. Newsletter records stay until unsubscribe. Cookie preferences for 12 months."
          },
          {
            heading: "6. Recipients",
            body: "Data is shared only with authorised team members and is not transferred outside the European Union."
          },
          {
            heading: "7. Security",
            body: "We use encrypted protocols and manage internal access to reduce disclosure risks."
          },
          {
            heading: "8. Rights",
            body: "You may request access, rectification, erasure or restriction of your data."
          },
          {
            heading: "9. Exercising rights",
            body: "Send your requests to contact@ldt-insights.be with the subject and proof of identity."
          },
          {
            heading: "10. Supervisory authority",
            body: "Complaints can be lodged with the Data Protection Authority (Rue de la Presse 35, 1000 Brussels)."
          }
        ]
      },
      cookies: {
        title: "Cookie management",
        intro: "The table lists the cookies used on this site, their provider, purpose and duration.",
        table: {
          headers: {
            name: "Name",
            provider: "Provider",
            type: "Type",
            purpose: "Purpose",
            duration: "Duration"
          },
          rows: [
            {
              name: "site_lang",
              provider: "ldt-insights.be",
              type: "Necessary",
              purpose: "Stores the chosen language.",
              duration: "12 months"
            },
            {
              name: "cookie_consent",
              provider: "ldt-insights.be",
              type: "Preferences",
              purpose: "Keeps the expressed cookie choices.",
              duration: "12 months"
            },
            {
              name: "analytics_session",
              provider: "ldt-insights.be",
              type: "Analytics",
              purpose: "Measures anonymised aggregated audience.",
              duration: "6 months"
            },
            {
              name: "outreach_token",
              provider: "ldt-insights.be",
              type: "Outreach",
              purpose: "Tracks interactions with shared briefs by email.",
              duration: "3 months"
            }
          ]
        },
        update: "Last update: January 2024."
      },
      refund: {
        title: "Refund policy",
        intro: "This procedure explains how to report an error or request a correction regarding published deliverables.",
        sections: [
          { heading: "1. Scope", body: "This policy covers digital deliverables made available by the laboratory." },
          { heading: "2. Notification", body: "Requests must be sent in writing, specifying the resource and nature of the issue." },
          { heading: "3. Reporting window", body: "Requests are accepted within 30 days after the official release of the deliverable." },
          { heading: "4. Acknowledgement", body: "An acknowledgement is sent within 5 working days with a tracking number." },
          { heading: "5. Review", body: "The team verifies the request, reproduces the situation and identifies the root cause." },
          { heading: "6. Corrections", body: "When an error is confirmed, a corrected version is released and referenced." },
          { heading: "7. Notification", body: "Stakeholders who downloaded the deliverable are informed about the correction by email." },
          { heading: "8. Limits", body: "Requests related to misuse or misinterpretation are not covered." },
          { heading: "9. Tracking", body: "Each case is logged internally to ensure traceability." },
          { heading: "10. Contact", body: "Send requests to correction@ldt-insights.be including the version number." }
        ]
      },
      disclaimer: {
        title: "Disclaimer",
        sections: [
          {
            heading: "1. General",
            body: "Information is provided for informational purposes only and does not constitute professional advice."
          },
          {
            heading: "2. Accuracy",
            body: "Despite careful work, errors may remain. Users should verify data before any use."
          },
          {
            heading: "3. Liability",
            body: "The laboratory cannot be held liable for decisions based on the published materials."
          },
          {
            heading: "4. External links",
            body: "We decline responsibility for the content of external sites referenced."
          },
          {
            heading: "5. Availability",
            body: "Site availability may be interrupted without notice for maintenance or updates."
          },
          {
            heading: "6. Changes",
            body: "These statements may be updated at any time to reflect evolving practices."
          }
        ]
      }
    },
    posts: {
      post1: {
        heroAlt: "Thematic maps showing coloured regional indicators.",
        title: "Composite indicators for tracking regional transitions",
        intro: "Territorial transitions involve multiple dimensions that no single indicator can summarise. This article outlines the composite index built to compare Belgian regional dynamics for 2015-2023.",
        section1: {
          h2: "Defining scope and assumptions",
          p1: "We first select the dimensions. Four pillars were kept: energy sobriety, social inclusion, economic dynamism and environmental preservation. Each pillar groups several variables from federal and regional sources.",
          p2: "To ensure temporal comparability, the series covers 2015-2023, when most datasets share consistent coverage. Missing values are imputed by moving average provided that at least three observations exist."
        },
        section2: {
          h2: "Normalisation and weighting",
          p1: "Variables expressed in different units require standardisation; z-scores keep relative distribution without artificial bounds.",
          p2: "Weighting was shaped with an expert panel representing the regions and several core cities. Each pillar receives the same weight to avoid bias. Within pillars, variables are weighted according to reliability and sensitivity to short-term changes.",
          p3: "Sensitivity analysis tested the influence of each variable. Alternative scenarios showed stable rankings, validating the chosen weighting."
        },
        section3: {
          h2: "Validation and interpretation",
          h3: "Robustness tests",
          p1: "Several checks were applied: removing variables one at a time, adjusting reference periods and comparing with European indicators. Deviations remained limited, supporting the index structure.",
          p2: "Mapping reveals contrasted trajectories between provinces. Some progress strongly on energy and environment but stagnate on inclusion. The composite index highlights these contrasts and supports interregional dialogue.",
          p3: "Documenting every construction stage is essential. Metadata are stored in our media hub, together with reproducible scripts and alert thresholds used for quarterly analyses."
        }
      },
      post2: {
        heroAlt: "Visualisation of travel flows between Belgian cities.",
        title: "Mapping Belgian commuter flows",
        intro: "Understanding commuter mobility is vital to adjust transport and planning policies. This study relies on anonymised home-to-work data covering the entire Belgian territory.",
        section1: {
          h2: "Sources and granularity",
          p1: "Data stem from social declarations cross-referenced with household surveys. Flows are aggregated at living area level to balance precision and confidentiality.",
          p2: "Temporal aspects are key: peak hours, weekdays, seasonality. Seasonal changes affect networks, notably in tourist provinces."
        },
        section2: {
          h2: "Mapping methods",
          p1: "Flows are modelled using origin-destination matrices. We then build weighted arc representations complemented by heatmaps for densities.",
          p2: "To avoid clutter, weaker flows are clustered and shown through soft gradients. Interactive maps let readers toggle flow categories by main transport mode.",
          p3: "Results emphasise strong interprovincial interrelations, particularly between Flemish and Walloon Brabant. Peripheral stations act as key interfaces for future scenarios."
        },
        section3: {
          h2: "Policy implications",
          h3: "Operational insights",
          p1: "Analyses confirm the need to reinforce multimodal services in peri-urban areas where cars still dominate. Data also reveal emerging flows linked to new employment poles.",
          p2: "Combining these results with service accessibility indicators enables decision-makers to prioritise investments and coordinate work schedules.",
          p3: "We provide a reading guide reminding methodological limits and caution regarding short-distance flows."
        }
      },
      post3: {
        heroAlt: "Schematic electric grid layered over a city plan.",
        title: "Energy resilience of Belgian urban territories",
        intro: "Energy resilience questions the capacity of urban districts to withstand disruptions. This analysis reviews vulnerability and adaptation indicators for several Belgian cities.",
        section1: {
          h2: "Building the assessment framework",
          p1: "We considered three dimensions: energy dependency, diversification of sources and flexibility capacity. Data come from operators and local inventories.",
          p2: "Adjustments are made to account for regional climate specificities. The studied districts span various typologies, from garden cities to dense cores."
        },
        section2: {
          h2: "Key findings",
          p1: "Exposure maps highlight vulnerabilities in older building stocks with limited retrofitting. Newer areas perform better but remain reliant on external grids.",
          p2: "Energy diversification is progressing, notably via shared photovoltaic installations. Flexibility remains limited due to scarce storage infrastructures.",
          p3: "The analysis suggests targeted renovation programmes and support for co-owned assets to manage shared equipment."
        },
        section3: {
          h2: "Monitoring perspectives",
          h3: "Indicators to consolidate",
          p1: "We suggest a minimal dashboard combining final consumption, renewable share and load-shedding capacity. These are tracked quarterly.",
          p2: "Data are compared with regional climate pathways to measure coherence between objectives and achievements.",
          p3: "Operator transparency is vital: ongoing dialogue aims to enhance data granularity."
        }
      },
      post4: {
        heroAlt: "Leafy residential street illustrating gentle densification.",
        title: "Soft densification and essential services",
        intro: "Gentle densification—adding moderate housing within existing fabric—raises questions about essential services. We analyse Belgian cases to measure tangible impacts.",
        section1: {
          h2: "Observation framework",
          p1: "The study covers four municipalities implementing densification guidelines. Criteria include added units, architectural quality and service availability.",
          p2: "Interviews with local managers complement quantitative data. Observations span five years to capture gradual effects."
        },
        section2: {
          h2: "Service impacts",
          p1: "Population increase remains controlled, limiting pressure on schools and transport. Adjustments were nonetheless needed for healthcare facilities.",
          p2: "Local shops benefit from a larger customer base, provided functional mix is maintained. Municipalities strengthened regulations to keep active ground floors.",
          p3: "Soft densification can coexist with green space preservation when greening requirements accompany projects."
        },
        section3: {
          h2: "Recommendations",
          h3: "Operational paths",
          p1: "Set up local observatories bringing residents, operators and technical services together to track key indicators.",
          p2: "Adopt qualitative charters defining density thresholds, shared spaces and energy performance.",
          p3: "Secure sustainable funding for essential services through redistributive mechanisms aligned with demographic growth."
        }
      },
      post5: {
        heroAlt: "Citizens collecting information in public space.",
        title: "Integrating citizen observation into diagnostics",
        intro: "Citizen observation adds qualitative depth to institutional data. This article details the protocol to integrate such contributions into Belgian territorial diagnostics.",
        section1: {
          h2: "Participatory framework",
          p1: "The scheme relies on local workshops, online forms and annotated walks. Each contribution follows a shared template for analysis.",
          p2: "Participants receive feedback on how their observations are incorporated, strengthening trust and data quality."
        },
        section2: {
          h2: "Validation and aggregation",
          p1: "Observations are geolocated and cross-referenced with existing data. An assessment grid measures coherence, precision and frequency.",
          p2: "Validated contributions feed a shared database accessible to partners. Contested items trigger additional investigations.",
          p3: "This process ensures contributions enrich the diagnostic without introducing major bias."
        },
        section3: {
          h2: "Operational use",
          h3: "Narrative integration",
          p1: "Citizen data is embedded in territorial storytelling through interactive maps and contextualised quotes.",
          p2: "Decision-makers gain a qualitative perspective complementing statistical analyses.",
          p3: "The approach fosters local ownership of diagnostics and co-designed action plans."
        }
      }
    },
    thankYouPage: {
      button: "Return to site"
    }
  }
};

const selectors = {
  text: "[data-i18n]",
  placeholder: "[data-i18n-placeholder]",
  aria: "[data-i18n-aria]",
  alt: "[data-i18n-alt]",
  title: "[data-i18n-title]",
  meta: "[data-i18n-meta]"
};

function resolve(dict, key) {
  return key.split(".").reduce((acc, part) => (acc && acc[part] !== undefined ? acc[part] : null), dict);
}

function applyTranslations(lang) {
  const dict = I18N[lang] || I18N[DEFAULT_LANG];
  document.documentElement.setAttribute("lang", lang);

  document.querySelectorAll(selectors.text).forEach((el) => {
    const key = el.dataset.i18n;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      el.innerHTML = String(value).replace("{year}", new Date().getFullYear());
    }
  });

  document.querySelectorAll(selectors.placeholder).forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("placeholder", String(value));
    }
  });

  document.querySelectorAll(selectors.aria).forEach((el) => {
    const key = el.dataset.i18nAria;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("aria-label", String(value));
    }
  });

  document.querySelectorAll(selectors.alt).forEach((el) => {
    const key = el.dataset.i18nAlt;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("alt", String(value));
    }
  });

  document.querySelectorAll(selectors.title).forEach((el) => {
    const key = el.dataset.i18nTitle;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      if (el.tagName.toLowerCase() === "title") {
        el.textContent = String(value);
      } else {
        el.setAttribute("title", String(value));
      }
    }
  });

  document.querySelectorAll(selectors.meta).forEach((el) => {
    const key = el.dataset.i18nMeta;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("content", String(value));
    }
  });

  document.querySelectorAll("[data-i18n-value]").forEach((el) => {
    const key = el.dataset.i18nValue;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("value", String(value));
    }
  });

  document.querySelectorAll("[data-i18n-href]").forEach((el) => {
    const key = el.dataset.i18nHref;
    const value = resolve(dict, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("href", String(value));
    }
  });

  updateActiveLanguage(lang);
}

function updateActiveLanguage(lang) {
  document.querySelectorAll("[data-lang-switch]").forEach((btn) => {
    const isActive = btn.dataset.langSwitch === lang;
    btn.setAttribute("aria-pressed", String(isActive));
  });
}

function getCurrentLang() {
  const stored = localStorage.getItem(LANG_KEY);
  if (stored && I18N[stored]) {
    return stored;
  }
  return DEFAULT_LANG;
}

function setLanguage(lang) {
  if (!I18N[lang]) return;
  localStorage.setItem(LANG_KEY, lang);
  applyTranslations(lang);
  document.body.dispatchEvent(new CustomEvent("languagechange", { detail: { lang } }));
}

function initLanguageToggle() {
  document.querySelectorAll("[data-lang-switch]").forEach((button) => {
    button.addEventListener("click", () => setLanguage(button.dataset.langSwitch));
  });
}

function initNavToggle() {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    nav.classList.toggle("is-open");
    const expanded = nav.classList.contains("is-open");
    toggle.setAttribute("aria-expanded", String(expanded));
  });
  document.addEventListener("click", (event) => {
    if (!nav.classList.contains("is-open")) return;
    if (!nav.contains(event.target) && event.target !== toggle) {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    }
  });
}

function initReveal() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  document.querySelectorAll(".reveal, [data-reveal]").forEach((el) => observer.observe(el));
}

const toastQueue = [];

function showToast(message, lang) {
  const container = document.querySelector("[data-toast-container]");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "toast reveal";
  toast.textContent = message;
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("is-visible"));
  const timeout = setTimeout(() => {
    toast.classList.remove("is-visible");
    setTimeout(() => toast.remove(), 220);
  }, 4600);
  toastQueue.push({ toast, timeout });
}

function getCookieState() {
  try {
    const stored = localStorage.getItem("cookie_consent");
    return stored ? JSON.parse(stored) : null;
  } catch (error) {
    return null;
  }
}

function saveCookieState(state) {
  localStorage.setItem("cookie_consent", JSON.stringify(state));
}

function applyCookieState(state) {
  document.querySelectorAll("[data-consent-toggle]").forEach((toggle) => {
    const key = toggle.dataset.consentToggle;
    if (state[key] !== undefined && !toggle.disabled) {
      toggle.checked = Boolean(state[key]);
    }
  });
}

function initCookieBanner(lang) {
  const banner = document.querySelector("[data-cookie-banner]");
  if (!banner) return;
  const manageBtn = banner.querySelector("[data-action='manage']");
  const acceptBtn = banner.querySelector("[data-action='accept']");
  const declineBtn = banner.querySelector("[data-action='decline']");
  const saveBtn = banner.querySelector("[data-action='save']");
  const panel = banner.querySelector(".cookie-preferences");

  const defaultState = {
    necessary: true,
    preferences: false,
    analytics: false,
    marketing: false
  };

  let state = { ...defaultState };
  const stored = getCookieState();
  if (stored) {
    state = { ...state, ...stored };
    applyCookieState(state);
  } else {
    banner.classList.add("is-visible");
  }

  manageBtn?.addEventListener("click", () => {
    panel.hidden = !panel.hidden;
  });

  banner.querySelectorAll("[data-consent-toggle]").forEach((input) => {
    input.addEventListener("change", () => {
      const key = input.dataset.consentToggle;
      if (!input.disabled) {
        state[key] = input.checked;
        saveCookieState(state);
      }
    });
  });

  acceptBtn?.addEventListener("click", () => {
    state = { necessary: true, preferences: true, analytics: true, marketing: true };
    applyCookieState(state);
    saveCookieState(state);
    banner.classList.remove("is-visible");
    const dict = I18N[getCurrentLang()] || I18N[DEFAULT_LANG];
    showToast(resolve(dict, "cookie.toastSaved"), getCurrentLang());
  });

  declineBtn?.addEventListener("click", () => {
    state = { necessary: true, preferences: false, analytics: false, marketing: false };
    applyCookieState(state);
    saveCookieState(state);
    banner.classList.remove("is-visible");
    const dict = I18N[getCurrentLang()] || I18N[DEFAULT_LANG];
    showToast(resolve(dict, "cookie.toastDeclined"), getCurrentLang());
  });

  saveBtn?.addEventListener("click", () => {
    saveCookieState(state);
    banner.classList.remove("is-visible");
    const dict = I18N[getCurrentLang()] || I18N[DEFAULT_LANG];
    showToast(resolve(dict, "cookie.toastSaved"), getCurrentLang());
  });

  document.body.addEventListener("languagechange", () => {
    if (!getCookieState()) {
      banner.classList.add("is-visible");
    }
  });
}

function validateForm(form, lang) {
  const dict = I18N[lang] || I18N[DEFAULT_LANG];
  const requiredFields = form.querySelectorAll("[required]");
  let valid = true;
  requiredFields.forEach((field) => {
    if (!field.value.trim()) {
      valid = false;
    }
  });
  if (!valid) {
    showToast(resolve(dict, "toasts.formInvalid"), lang);
  }
  return valid;
}

function initForms() {
  const newsletterForms = document.querySelectorAll("[data-submit-toast='newsletter']");
  newsletterForms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const lang = getCurrentLang();
      if (!validateForm(form, lang)) {
        return;
      }
      form.reset();
      const dict = I18N[lang] || I18N[DEFAULT_LANG];
      showToast(resolve(dict, "toasts.newsletterSuccess"), lang);
    });
  });

  const contactForm = document.querySelector("[data-contact-form]");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      const lang = getCurrentLang();
      if (!validateForm(contactForm, lang)) {
        event.preventDefault();
        return;
      }
      if (!contactForm.dataset.allowRedirect) {
        event.preventDefault();
        const dict = I18N[lang] || I18N[DEFAULT_LANG];
        showToast(resolve(dict, "toasts.formSubmitted"), lang);
        contactForm.dataset.allowRedirect = "true";
        setTimeout(() => contactForm.submit(), 600);
      }
    });
  }
}

function initActiveLinks() {
  const current = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".main-nav a").forEach((link) => {
    const href = link.getAttribute("href");
    if (href === current) {
      link.classList.add("is-active");
    }
  });
}

function initYear() {
  document.querySelectorAll("[data-current-year]").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });
}

function initSkipLink() {
  const skip = document.querySelector("[data-skip]");
  if (!skip) return;
  skip.addEventListener("click", (event) => {
    const targetId = skip.getAttribute("href").replace("#", "");
    const target = document.getElementById(targetId);
    if (target) {
      event.preventDefault();
      target.setAttribute("tabindex", "-1");
      target.focus();
      target.removeAttribute("tabindex");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const initialLang = getCurrentLang();
  applyTranslations(initialLang);
  initLanguageToggle();
  initNavToggle();
  initReveal();
  initCookieBanner(initialLang);
  initForms();
  initActiveLinks();
  initYear();
  initSkipLink();
});