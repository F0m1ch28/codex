import React, { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Casinos from './pages/Casinos';
import Offers from './pages/Offers';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';

const COOKIE_KEY = 'gamblingoffer_cookie_choice';

function App() {
  const [cookieChoice, setCookieChoice] = useState(null);
  const [bannerVisible, setBannerVisible] = useState(false);
  const [preferenceMode, setPreferenceMode] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedChoice = window.localStorage.getItem(COOKIE_KEY);
      if (savedChoice) {
        setCookieChoice(JSON.parse(savedChoice));
        setBannerVisible(false);
      } else {
        setBannerVisible(true);
      }
    }
  }, []);

  const handleAcceptAll = () => {
    const choice = { necessary: true, analytics: true, marketing: true };
    setCookieChoice(choice);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(COOKIE_KEY, JSON.stringify(choice));
    }
    setBannerVisible(false);
  };

  const handleSavePreferences = (preferences) => {
    const choice = { necessary: true, ...preferences };
    setCookieChoice(choice);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(COOKIE_KEY, JSON.stringify(choice));
    }
    setBannerVisible(false);
    setPreferenceMode(false);
  };

  const handleCustomize = () => {
    setPreferenceMode(true);
  };

  const handleDecline = () => {
    const choice = { necessary: true, analytics: false, marketing: false };
    setCookieChoice(choice);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(COOKIE_KEY, JSON.stringify(choice));
    }
    setBannerVisible(false);
    setPreferenceMode(false);
  };

  return (
    <div className="app-shell">
      <Header />
      <main className="main-content" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/casinos" element={<Casinos />} />
          <Route path="/offers" element={<Offers />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/cookies" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      {bannerVisible && (
        <CookieBanner
          onAccept={handleAcceptAll}
          onCustomize={handleCustomize}
          onDecline={handleDecline}
          preferenceMode={preferenceMode}
          onSavePreferences={handleSavePreferences}
          onClose={() => setBannerVisible(false)}
        />
      )}
    </div>
  );
}

export default App;