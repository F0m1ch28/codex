import React, { useEffect } from 'react';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Ева Нортон',
    role: 'Главный аналитик офферов',
    bio: '10 лет опыта в iGaming. Специализируется на оценке бонусных условий и скоринге казино.',
    avatar: 'https://picsum.photos/400/400?random=201',
  },
  {
    name: 'Лео Санчес',
    role: 'Эксперт по ответственности',
    bio: 'Обеспечивает соблюдение стандартов Responsible Gambling и проводит аудит лицензий.',
    avatar: 'https://picsum.photos/400/400?random=202',
  },
  {
    name: 'Ханна Ли',
    role: 'Редактор контента',
    bio: 'Следит за актуальностью обзоров, готовит руководства и сравнения для игроков.',
    avatar: 'https://picsum.photos/400/400?random=203',
  },
];

function About() {
  useEffect(() => {
    document.title = 'О нас — команда GamblingOffer';
  }, []);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div>
          <h1>О GamblingOffer</h1>
          <p>
            Мы начали как небольшая команда энтузиастов гемблинга, решившая создать прозрачный и
            честный гид по офферам. Сегодня GamblingOffer — это международный ресурс с детальными
            обзорами, аналитикой и рекомендациями по ответственной игре.
          </p>
        </div>
        <img
          src="https://picsum.photos/900/600?random=204"
          alt="Команда GamblingOffer обсуждает аналитику офферов"
          loading="lazy"
        />
      </header>

      <section className={styles.mission}>
        <article>
          <h2>Наша миссия</h2>
          <p>
            Продвигать прозрачность на рынке онлайн-казино и помогать игрокам принимать взвешенные
            решения. Мы публикуем только проверенные и честные предложения, указывая каждую деталь
            условий.
          </p>
        </article>
        <article>
          <h2>Подход</h2>
          <p>
            Мы анализируем лицензии, финансовые показатели, UX казино и поддержку. Команда
            работает в разных часовых поясах, чтобы проверять обновления офферов круглосуточно.
          </p>
        </article>
        <article>
          <h2>Ответственность</h2>
          <p>
            GamblingOffer продвигает принципы ответственной игры. Мы предоставляем рекомендации по
            лимитам, самоисключению и инструментам контроля.
          </p>
        </article>
      </section>

      <section className={styles.timeline}>
        <h2>Ключевые этапы</h2>
        <div className={styles.timelineGrid}>
          <div>
            <span className={styles.year}>2018</span>
            <p>Старт проекта с 25 обзорами европейских казино.</p>
          </div>
          <div>
            <span className={styles.year}>2020</span>
            <p>Расширение на рынки Латинской Америки и запуск фильтров по валютам.</p>
          </div>
          <div>
            <span className={styles.year}>2022</span>
            <p>Интеграция аналитики по бонусам и запуск ежегодного рейтинга GamblingOffer Awards.</p>
          </div>
          <div>
            <span className={styles.year}>2024</span>
            <p>Покрытие 40+ географий, запуск рекомендательного движка на основе предпочтений.</p>
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team">
        <div className="section-header">
          <h2 id="team">Команда GamblingOffer</h2>
          <p>Люди, которые ежедневно проверяют и обновляют офферы для игроков по всему миру.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.avatar} alt={member.name} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

export default About;