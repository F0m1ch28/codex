import React, { useEffect, useMemo, useState } from 'react';
import styles from './Services.module.css';

const services = [
  {
    title: 'Аналитика офферов',
    description:
      'Системный аудит бонусных пакетов: вейджер, вклад игр, лимиты и ограничения по странам.',
    benefit: 'Еженедельные актуализации',
    icon: '📊',
  },
  {
    title: 'Рейтинг казино',
    description:
      'Скоринг по лицензии, скорости выплат, отзывам и поддержке. Индивидуальные рекомендации.',
    benefit: 'Проверка лицензий вручную',
    icon: '🏆',
  },
  {
    title: 'Эксклюзивные предложения',
    description:
      'Договоренности с операторами о закрытых бонусах и VIP-кэшбеке для игроков GamblingOffer.',
    benefit: 'Доступ по заявке',
    icon: '🎯',
  },
];

const projectsList = [
  { name: 'LATAM Expansion', category: 'Региональные подборки', detail: 'Запуск локализованных обзоров для Бразилии, Мексики и Чили.' },
  { name: 'Crypto Insights', category: 'Крипто', detail: 'Сравнение криптовалютных казино с упором на безопасность кошельков.' },
  { name: 'VIP Matrix', category: 'VIP', detail: 'Создание алгоритма скоринга VIP-программ по 35 параметрам.' },
  { name: 'Responsible Hub', category: 'Compliance', detail: 'Сбор инструментов самоисключения и лимитов по всем лицензиям.' },
];

const processSteps = [
  { title: 'Сбор данных', text: 'Получаем условия бонусов и проверяем доступность в каждой юрисдикции.' },
  { title: 'Анализ и скоринг', text: 'Оцениваем бонус по 20+ метрикам, включая сложность отыгрыша и срок действия.' },
  { title: 'Публикация обзора', text: 'Подготавливаем понятный обзор с плюсами и зонами риска.' },
  { title: 'Мониторинг', text: 'Отслеживаем изменения условий и оперативно обновляем карточку оффера.' },
];

function Services() {
  const categories = useMemo(
    () => ['Все', ...new Set(projectsList.map((project) => project.category))],
    []
  );
  const [activeCategory, setActiveCategory] = useState('Все');

  useEffect(() => {
    document.title = 'Услуги GamblingOffer — аналитика и эксклюзивы';
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Все') return projectsList;
    return projectsList.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Услуги GamblingOffer</h1>
        <p>
          Мы помогаем операторам и игрокам получать максимальную пользу от гемблинг индустрии.
          От детальной аналитики бонусов до медиа-сопровождения эксклюзивных предложений.
        </p>
      </header>

      <section className={styles.servicesGrid}>
        {services.map((service) => (
          <article key={service.title} className={styles.card}>
            <span className={styles.icon} aria-hidden="true">
              {service.icon}
            </span>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <div className={styles.badge}>{service.benefit}</div>
          </article>
        ))}
      </section>

      <section className={styles.process}>
        <h2>Как мы работаем</h2>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <article key={step.title}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.projectsHeader}>
          <h2>Кейсы и проекты</h2>
          <div className={styles.filters}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.name} className={styles.projectCard}>
              <span className={styles.projectCategory}>{project.category}</span>
              <h3>{project.name}</h3>
              <p>{project.detail}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Services;