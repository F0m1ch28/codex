import React, { useEffect } from 'react';
import styles from './CookiePolicy.module.css';

function CookiePolicy() {
  useEffect(() => {
    document.title = 'Cookie политика — GamblingOffer';
  }, []);

  return (
    <div className={styles.page}>
      <h1>Cookie политика GamblingOffer</h1>
      <p className={styles.updated}>Актуально на 04 марта 2025 года</p>

      <section>
        <h2>1. Что такое cookie</h2>
        <p>
          Cookie — это небольшие файлы, которые сохраняются в вашем браузере при посещении сайта.
          Они помогают нам анализировать трафик и улучшать опыт пользователя.
        </p>
      </section>

      <section>
        <h2>2. Типы cookie</h2>
        <ul>
          <li>
            <strong>Необходимые</strong> — обеспечивают работу сайта и настроек. Отключить их
            невозможно.
          </li>
          <li>
            <strong>Аналитические</strong> — помогают понять, как пользователи взаимодействуют с
            контентом. Мы используем агрегированные отчеты.
          </li>
          <li>
            <strong>Маркетинговые</strong> — позволяют отображать релевантные предложения. Включаются
            только с вашего согласия.
          </li>
        </ul>
      </section>

      <section>
        <h2>3. Управление cookie</h2>
        <p>
          Вы можете изменить настройки в баннере cookie или в параметрах браузера. Отзывая согласие,
          помните, что некоторые функции сайта могут работать ограниченно.
        </p>
      </section>

      <section>
        <h2>4. Сторонние инструменты</h2>
        <p>
          Мы можем использовать аналитические платформы для оценки эффективности контента. Эти сервисы
          получают обезличенные данные и действуют в соответствии со своими политиками.
        </p>
      </section>

      <section>
        <h2>5. Контакты</h2>
        <p>
          Вопросы о cookie направляйте на{' '}
          <a href="mailto:feedback@gamblingoffer.com">feedback@gamblingoffer.com</a>.
        </p>
      </section>
    </div>
  );
}

export default CookiePolicy;