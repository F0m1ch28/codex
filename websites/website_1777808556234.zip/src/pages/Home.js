import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Покрытие географий', target: 42, suffix: ' стран' },
  { label: 'Актуальных офферов', target: 128, suffix: '+' },
  { label: 'Проверенных казино', target: 36, suffix: '' },
  { label: 'Счастливых игроков', target: 9500, suffix: '+' },
];

const advantages = [
  {
    title: 'Честные обзоры',
    description:
      'Мы проводим независимый анализ лицензионных казино и публикуем только прозрачные условия.',
    icon: '🛡️',
  },
  {
    title: 'Сравнение бонусов',
    description:
      'Собираем ключевые параметры: размер приветственных пакетов, фриспины и эксклюзивные награды.',
    icon: '🎁',
  },
  {
    title: 'Актуальные условия',
    description:
      'Каждый оффер регулярно перепроверяется, чтобы вы всегда получали свежие данные без сюрпризов.',
    icon: '⏱️',
  },
  {
    title: 'Умные фильтры',
    description:
      'Сортируйте по вейджеру, валютам и играм. Нужный оффер находится за секунды.',
    icon: '🔍',
  },
];

const casinos = [
  {
    name: 'Aurora Spins',
    rating: 4.9,
    bonus: '150% до 500€ + 150 фриспинов',
    wager: 'x35',
    highlights: ['Моментальные выплаты', 'VIP-программа'],
  },
  {
    name: 'Ocean Luck',
    rating: 4.7,
    bonus: '100% до 400€ + 50 фриспинов',
    wager: 'x30',
    highlights: ['Турниры с джекпотами', 'Поддержка 24/7'],
  },
  {
    name: 'Galaxy Bets',
    rating: 4.6,
    bonus: '200% до 600€',
    wager: 'x40',
    highlights: ['Крипто-платежи', 'Кешбек каждую неделю'],
  },
];

const comparisonRows = [
  {
    title: 'Aurora Spins',
    bonus: '150% до 500€',
    wager: 'x35',
    limits: 'Вывод до 10 000€/мес.',
    games: 'NetEnt, Play’n GO, Pragmatic',
  },
  {
    title: 'Ocean Luck',
    bonus: '100% до 400€ + 50 FS',
    wager: 'x30',
    limits: 'Вывод до 7 500€/мес.',
    games: 'Evolution, Yggdrasil, Microgaming',
  },
  {
    title: 'Galaxy Bets',
    bonus: '200% до 600€',
    wager: 'x40',
    limits: 'Вывод до 12 000€/мес.',
    games: 'BTG, Quickspin, Red Tiger',
  },
];

const testimonials = [
  {
    name: 'Алина, Канада',
    quote:
      'GamblingOffer помог мне найти казино с честным вейджером и быстрым выводом. Теперь тестирую только проверенные платформы.',
  },
  {
    name: 'Марко, Италия',
    quote:
      'Полезные фильтры и понятные обзоры. Особенно нравится, что вы сразу пишете про лимиты и скрытые условия.',
  },
  {
    name: 'Даниэль, Бразилия',
    quote:
      'Нашёл эксклюзивный оффер с дополнительными фриспинами. Поддержка подсказывала каждый шаг. Отличный сервис!',
  },
];

const faqItems = [
  {
    question: 'Как выбирать оффер?',
    answer:
      'Сравнивайте бонус по размеру, типу и вейджеру. Проверьте доступные методы пополнения и ограничения по странам. Воспользуйтесь нашими фильтрами, чтобы выбрать комфортные условия.',
  },
  {
    question: 'Что такое вейджер?',
    answer:
      'Вейджер — это множитель, определяющий, сколько раз нужно проставить сумму бонуса (или бонус+депозит), прежде чем вы сможете вывести выигрыш. Чем ниже вейджер, тем проще отыгрыш.',
  },
  {
    question: 'Почему важно читать условия?',
    answer:
      'В условиях указаны лимиты ставок, сроки отыгрыша, вклад разных игр и ограничения по странам. Невнимательность к деталям часто приводит к потере бонуса.',
  },
  {
    question: 'Поддерживаете ли вы мобильные казино?',
    answer:
      'Да, в карточках мы отмечаем наличие мобильных приложений и адаптивной версии. Также указываем, какие игры доступны на смартфоне.',
  },
];

function Home() {
  const [counterValues, setCounterValues] = useState(statsConfig.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [openFaqIndex, setOpenFaqIndex] = useState(0);

  useEffect(() => {
    document.title = 'GamblingOffer — ваш гид по топовым казино офферам';
  }, []);

  useEffect(() => {
    let frame = null;
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / 2000, 1);
      setCounterValues(
        statsConfig.map((item) => Math.floor(item.target * progress))
      );
      if (progress < 1) {
        frame = requestAnimationFrame(animate);
      }
    };

    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const handleFaqToggle = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? -1 : index));
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={styles.heroContent}>
          <h1 id="hero-title" className={styles.heroTitle}>
            Открой для себя лучшие офферы от топовых казино
          </h1>
          <p className={styles.heroSubtitle}>
            Мы сравниваем бонусы, вейджеры и лимиты, чтобы ты сделал правильный выбор и
            наслаждался безопасной игрой с эксклюзивными преимуществами.
          </p>
          <div className={styles.heroActions}>
            <Link to="/offers" className="btn btn-primary">
              Начни сравнивать сейчас
            </Link>
            <Link to="/casinos" className="btn btn-outline">
              Смотреть топ казино
            </Link>
          </div>
          <div className={styles.heroStats} aria-label="Ключевые показатели GamblingOffer">
            {statsConfig.map((item, index) => (
              <div key={item.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {counterValues[index]}
                  {item.suffix}
                </span>
                <span className={styles.statLabel}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img
            src="https://picsum.photos/1600/900?random=101"
            alt="Игрок оценивает предложения казино на планшете"
            loading="lazy"
          />
          <div className={styles.heroBadge}>
            <span>Premium Picks</span>
            <strong>Обновление каждую неделю</strong>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="advantages">
        <div className="section-header">
          <h2 id="advantages">Преимущества GamblingOffer</h2>
          <p>Выбирайте только проверенные предложения благодаря нашей аналитике.</p>
        </div>
        <div className={styles.advantagesGrid}>
          {advantages.map((item) => (
            <article key={item.title} className={styles.advantageCard}>
              <span className={styles.advantageIcon} aria-hidden="true">
                {item.icon}
              </span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section" aria-labelledby="top-casinos">
        <div className="section-header">
          <h2 id="top-casinos">Топ-3 казино этой недели</h2>
          <p>Подборка составлена по скорости выплат, бонусам и отзывам игроков.</p>
        </div>
        <div className={styles.casinosList}>
          {casinos.map((casino) => (
            <article key={casino.name} className={styles.casinoCard}>
              <header>
                <h3>{casino.name}</h3>
                <span className={styles.rating} aria-label={`Рейтинг ${casino.rating}`}>
                  ★ {casino.rating}
                </span>
              </header>
              <div className={styles.casinoBonus}>
                <strong>Приветственный бонус:</strong>
                <span>{casino.bonus}</span>
              </div>
              <div className={styles.casinoDetails}>
                <span>
                  <strong>Вейджер:</strong> {casino.wager}
                </span>
                <ul>
                  {casino.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
              </div>
              <Link to="/casinos" className={styles.moreLink}>
                Смотреть обзор
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="section" aria-labelledby="comparison">
        <div className="section-header">
          <h2 id="comparison">Сравнение условий</h2>
          <p>Выбирайте офферы по ключевым параметрам: бонус, вейджер, лимиты и игры.</p>
        </div>
        <div className={styles.tableWrapper}>
          <table className={styles.comparisonTable}>
            <thead>
              <tr>
                <th scope="col">Казино</th>
                <th scope="col">Бонус</th>
                <th scope="col">Вейджер</th>
                <th scope="col">Лимиты</th>
                <th scope="col">Игры</th>
              </tr>
            </thead>
            <tbody>
              {comparisonRows.map((row) => (
                <tr key={row.title}>
                  <th scope="row">{row.title}</th>
                  <td>{row.bonus}</td>
                  <td>{row.wager}</td>
                  <td>{row.limits}</td>
                  <td>{row.games}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className={`${styles.testimonials} section`} aria-labelledby="testimonials">
        <div className="section-header">
          <h2 id="testimonials">Отзывы игроков</h2>
          <p>Опыт сообщества помогает принимать уверенные решения.</p>
        </div>
        <div className={styles.testimonialContent}>
          <button
            type="button"
            className={styles.carouselControl}
            onClick={() =>
              setActiveTestimonial(
                (activeTestimonial - 1 + testimonials.length) % testimonials.length
              )
            }
            aria-label="Предыдущий отзыв"
          >
            ‹
          </button>
          <article className={styles.testimonialCard}>
            <p className={styles.quote}>
              “{testimonials[activeTestimonial].quote}”
            </p>
            <span className={styles.author}>{testimonials[activeTestimonial].name}</span>
          </article>
          <button
            type="button"
            className={styles.carouselControl}
            onClick={() =>
              setActiveTestimonial((activeTestimonial + 1) % testimonials.length)
            }
            aria-label="Следующий отзыв"
          >
            ›
          </button>
        </div>
        <div className={styles.dots} role="tablist">
          {testimonials.map((testimonial, index) => (
            <button
              key={testimonial.name}
              type="button"
              className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
              onClick={() => setActiveTestimonial(index)}
              aria-label={`Показать отзыв ${testimonial.name}`}
            />
          ))}
        </div>
      </section>

      <section className="section" aria-labelledby="cta-block">
        <div className={styles.cta}>
          <div>
            <h2 id="cta-block">Готов начать сравнение офферов?</h2>
            <p>
              Мы собрали для тебя готовые подборки по странам, валютам и видам игр.
              Настрой фильтры и найди бонус, который соответствует твоему стилю игры.
            </p>
          </div>
          <Link to="/offers" className="btn btn-primary">
            Перейти к офферам
          </Link>
        </div>
      </section>

      <section className="section" aria-labelledby="faq">
        <div className="section-header">
          <h2 id="faq">FAQ</h2>
          <p>Ответы на частые вопросы о бонусах, вейджерах и выборе платформ.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div
              key={item.question}
              className={`${styles.faqItem} ${openFaqIndex === index ? styles.faqOpen : ''}`}
            >
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => handleFaqToggle(index)}
                aria-expanded={openFaqIndex === index}
              >
                <span>{item.question}</span>
                <span>{openFaqIndex === index ? '−' : '+'}</span>
              </button>
              <div className={styles.faqAnswer}>
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Home;