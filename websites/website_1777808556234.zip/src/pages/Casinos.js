import React, { useEffect, useMemo, useState } from 'react';
import styles from './Casinos.module.css';

const casinosData = [
  {
    name: 'Aurora Spins',
    rating: 4.9,
    bonus: '150% до 500€ + 150 фриспинов',
    wager: 'x35',
    payments: 'Visa, Mastercard, Skrill, Crypto',
    license: 'MGA',
    regions: ['Европа', 'Северная Америка'],
    tags: ['VIP', 'Быстрые выплаты'],
  },
  {
    name: 'Ocean Luck',
    rating: 4.7,
    bonus: '100% до 400€ + 50 фриспинов',
    wager: 'x30',
    payments: 'PayPal, Neteller, Trustly',
    license: 'UKGC',
    regions: ['Европа'],
    tags: ['Турниры', 'Live-игры'],
  },
  {
    name: 'Galaxy Bets',
    rating: 4.6,
    bonus: '200% до 600€',
    wager: 'x40',
    payments: 'Crypto, Revolut, Skrill',
    license: 'Curacao',
    regions: ['Глобально'],
    tags: ['Крипто', 'Кешбек'],
  },
  {
    name: 'Royal Peak',
    rating: 4.5,
    bonus: '50% до 300€ + 75 фриспинов',
    wager: 'x25',
    payments: 'Visa, Apple Pay, Google Pay',
    license: 'MGA',
    regions: ['Европа', 'Азия'],
    tags: ['Программа лояльности'],
  },
  {
    name: 'Desert Wins',
    rating: 4.4,
    bonus: '100% до 200€ + 20 фриспинов',
    wager: 'x32',
    payments: 'Skrill, Neteller, Paysafecard',
    license: 'Curacao',
    regions: ['Латинская Америка', 'Глобально'],
    tags: ['Крипто', 'Слоты'],
  },
];

function Casinos() {
  const [search, setSearch] = useState('');
  const [regionFilter, setRegionFilter] = useState('Все');
  const [tagFilter, setTagFilter] = useState('Все');
  const [sortKey, setSortKey] = useState('rating');

  useEffect(() => {
    document.title = 'Casinos — Подбор лицензированных казино | GamblingOffer';
  }, []);

  const regions = useMemo(() => {
    const list = new Set(['Все']);
    casinosData.forEach((casino) => casino.regions.forEach((region) => list.add(region)));
    return Array.from(list);
  }, []);

  const tags = useMemo(() => {
    const list = new Set(['Все']);
    casinosData.forEach((casino) => casino.tags.forEach((tag) => list.add(tag)));
    return Array.from(list);
  }, []);

  const filteredCasinos = useMemo(() => {
    let items = [...casinosData];
    if (search.trim()) {
      items = items.filter((casino) =>
        casino.name.toLowerCase().includes(search.trim().toLowerCase())
      );
    }
    if (regionFilter !== 'Все') {
      items = items.filter((casino) => casino.regions.includes(regionFilter));
    }
    if (tagFilter !== 'Все') {
      items = items.filter((casino) => casino.tags.includes(tagFilter));
    }
    items.sort((a, b) => (sortKey === 'rating' ? b.rating - a.rating : a.name.localeCompare(b.name)));
    return items;
  }, [search, regionFilter, tagFilter, sortKey]);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div>
          <h1>Casinos: международная подборка лицензированных площадок</h1>
          <p>
            Сравните преимущества казино: бонусы, лицензии, платежи и рейтинг игроков. Отфильтруйте
            результаты по региону или любимому формату игры.
          </p>
        </div>
        <img
          src="https://picsum.photos/800/600?random=102"
          alt="Игровые столы и лицензированные казино"
          loading="lazy"
        />
      </header>

      <section className={styles.filters} aria-label="Фильтры казино">
        <div className={styles.filterGroup}>
          <label htmlFor="search">Название</label>
          <input
            id="search"
            type="search"
            placeholder="Введите название казино"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
        <div className={styles.filterGroup}>
          <label htmlFor="region">Регион</label>
          <select
            id="region"
            value={regionFilter}
            onChange={(event) => setRegionFilter(event.target.value)}
          >
            {regions.map((region) => (
              <option key={region}>{region}</option>
            ))}
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label htmlFor="tag">Особенность</label>
          <select
            id="tag"
            value={tagFilter}
            onChange={(event) => setTagFilter(event.target.value)}
          >
            {tags.map((tag) => (
              <option key={tag}>{tag}</option>
            ))}
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label htmlFor="sort">Сортировка</label>
          <select id="sort" value={sortKey} onChange={(e) => setSortKey(e.target.value)}>
            <option value="rating">По рейтингу</option>
            <option value="name">По названию</option>
          </select>
        </div>
      </section>

      <section className={styles.list} aria-live="polite">
        {filteredCasinos.map((casino) => (
          <article key={casino.name} className={styles.card}>
            <header className={styles.cardHeader}>
              <div>
                <h2>{casino.name}</h2>
                <span className={styles.license}>Лицензия: {casino.license}</span>
              </div>
              <div className={styles.rating}>
                <span>★</span>
                <strong>{casino.rating}</strong>
              </div>
            </header>
            <div className={styles.cardBody}>
              <div>
                <h3>Приветственный бонус</h3>
                <p>{casino.bonus}</p>
              </div>
              <div>
                <h3>Вейджер</h3>
                <p>{casino.wager}</p>
              </div>
              <div>
                <h3>Платежные методы</h3>
                <p>{casino.payments}</p>
              </div>
            </div>
            <footer className={styles.cardFooter}>
              <div className={styles.tags}>
                {casino.tags.map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
              <div className={styles.regions} aria-label="Доступные регионы">
                {casino.regions.map((region) => (
                  <span key={region}>{region}</span>
                ))}
              </div>
            </footer>
          </article>
        ))}
        {filteredCasinos.length === 0 && (
          <div className={styles.empty}>
            <h3>По запросу ничего не найдено</h3>
            <p>Попробуйте изменить фильтры или убрать часть условий.</p>
          </div>
        )}
      </section>
    </div>
  );
}

export default Casinos;