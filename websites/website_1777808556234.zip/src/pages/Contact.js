import React, { useEffect, useState } from 'react';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: '',
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    document.title = 'Контакт — обратная связь | GamblingOffer';
  }, []);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Введите ваше имя';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Укажите корректный email';
    }
    if (formData.message.trim().length < 20) {
      newErrors.message = 'Сообщение должно быть не короче 20 символов';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Свяжитесь с GamblingOffer</h1>
        <p>
          Расскажите о своём опыте взаимодействия с офферами или предложите сотрудничество.
          Мы внимательно читаем каждое сообщение и отвечаем в течение двух рабочих дней.
        </p>
      </header>

      <section className={styles.contact}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Как к вам обращаться?"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@example.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Опишите ваш вопрос или предложение"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit" className="btn btn-primary">
            Отправить сообщение
          </button>
          {submitted && (
            <p className={styles.success}>
              Спасибо! Сообщение отправлено. Мы ответим на feedback@gamblingoffer.com как можно скорее.
            </p>
          )}
        </form>

        <aside className={styles.info}>
          <div className={styles.infoCard}>
            <h2>Обратная связь</h2>
            <p>
              Мы собираем предложения по улучшению обзоров, принимаем запросы на сотрудничество и
              отвечаем на вопросы по условиям офферов.
            </p>
            <a href="mailto:feedback@gamblingoffer.com">feedback@gamblingoffer.com</a>
          </div>
          <div className={styles.infoImage}>
            <img
              src="https://picsum.photos/800/600?random=205"
              alt="Служба поддержки GamblingOffer"
              loading="lazy"
            />
          </div>
        </aside>
      </section>
    </div>
  );
}

export default Contact;