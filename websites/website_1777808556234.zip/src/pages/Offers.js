import React, { useEffect, useMemo, useState } from 'react';
import styles from './Offers.module.css';

const offersData = [
  {
    casino: 'Aurora Spins',
    bonus: '150% до 500€ + 150 фриспинов',
    wager: 'x35',
    minDeposit: '20€',
    maxBet: '5€',
    feature: 'VIP кешбек',
    type: 'Приветственный пакет',
  },
  {
    casino: 'Ocean Luck',
    bonus: '100% до 400€ + 50 фриспинов',
    wager: 'x30',
    minDeposit: '10€',
    maxBet: '4€',
    feature: 'Турниры с призами',
    type: 'Приветственный пакет',
  },
  {
    casino: 'Galaxy Bets',
    bonus: '200% до 600€',
    wager: 'x40',
    minDeposit: '25€',
    maxBet: '6€',
    feature: 'Крипто-бонус',
    type: 'Крипто',
  },
  {
    casino: 'Royal Peak',
    bonus: '50% до 300€ + 75 фриспинов',
    wager: 'x25',
    minDeposit: '15€',
    maxBet: '4€',
    feature: 'Кешбек выходного дня',
    type: 'Релоад',
  },
  {
    casino: 'Desert Wins',
    bonus: '100% до 200€ + 20 фриспинов',
    wager: 'x32',
    minDeposit: '10€',
    maxBet: '5€',
    feature: 'Джекпот турниры',
    type: 'Приветственный пакет',
  },
];

function Offers() {
  const [typeFilter, setTypeFilter] = useState('Все');
  const [maxWager, setMaxWager] = useState('x40');

  useEffect(() => {
    document.title = 'Offers — сравнение гемблинг офферов | GamblingOffer';
  }, []);

  const offers = useMemo(() => {
    let filtered = [...offersData];
    if (typeFilter !== 'Все') {
      filtered = filtered.filter((offer) => offer.type === typeFilter);
    }
    if (maxWager !== 'Любой') {
      const threshold = Number(maxWager.replace(/x/, ''));
      filtered = filtered.filter((offer) => Number(offer.wager.replace(/x/, '')) <= threshold);
    }
    return filtered;
  }, [typeFilter, maxWager]);

  const uniqueTypes = useMemo(() => ['Все', ...new Set(offersData.map((offer) => offer.type))], []);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div>
          <h1>Offers: сравнение условий по бонусам и вейджерам</h1>
          <p>
            Настрой фильтры по типу бонуса и уровню вейджера. Сравнивай депозиты, максимальные ставки
            и эксклюзивные опции, чтобы выбрать оптимальный оффер.
          </p>
        </div>
        <div className={styles.filterPanel}>
          <div className={styles.filter}>
            <label htmlFor="type">Тип оффера</label>
            <select
              id="type"
              value={typeFilter}
              onChange={(event) => setTypeFilter(event.target.value)}
            >
              {uniqueTypes.map((type) => (
                <option key={type}>{type}</option>
              ))}
            </select>
          </div>
          <div className={styles.filter}>
            <label htmlFor="wager">Максимальный вейджер</label>
            <select
              id="wager"
              value={maxWager}
              onChange={(event) => setMaxWager(event.target.value)}
            >
              <option>Любой</option>
              <option>x25</option>
              <option>x30</option>
              <option>x35</option>
              <option>x40</option>
            </select>
          </div>
        </div>
      </header>

      <section className={styles.tableWrapper} aria-live="polite">
        <table className={styles.table}>
          <thead>
            <tr>
              <th scope="col">Казино</th>
              <th scope="col">Бонус</th>
              <th scope="col">Вейджер</th>
              <th scope="col">Минимальный депозит</th>
              <th scope="col">Максимальная ставка</th>
              <th scope="col">Особенность</th>
              <th scope="col">Тип</th>
            </tr>
          </thead>
          <tbody>
            {offers.map((offer) => (
              <tr key={offer.casino}>
                <th scope="row">{offer.casino}</th>
                <td>{offer.bonus}</td>
                <td>{offer.wager}</td>
                <td>{offer.minDeposit}</td>
                <td>{offer.maxBet}</td>
                <td>{offer.feature}</td>
                <td>
                  <span className={styles.typeBadge}>{offer.type}</span>
                </td>
              </tr>
            ))}
            {offers.length === 0 && (
              <tr>
                <td colSpan="7" className={styles.empty}>
                  По выбранным фильтрам офферы отсутствуют. Измените параметры и попробуйте снова.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>

      <section className={styles.tips}>
        <h2>Советы по выбору оффера</h2>
        <div className={styles.tipsGrid}>
          <article>
            <h3>Сопоставляйте вейджер и размер бонуса</h3>
            <p>
              Высокий бонус не всегда выгоден, если вейджер слишком большой. Рассчитайте, сколько
              раз нужно отыграть сумму и хватит ли времени.
            </p>
          </article>
          <article>
            <h3>Проверяйте вклад игр</h3>
            <p>
              Некоторые игры засчитывают лишь часть ставок. Если вы предпочитаете live-казино,
              убедитесь, что они участвуют в отыгрыше.
            </p>
          </article>
          <article>
            <h3>Следите за лимитами ставок</h3>
            <p>
              Превышение максимальной ставки может аннулировать бонус. Всегда сверяйтесь с условиями,
              прежде чем запускать слот или рулетку.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
}

export default Offers;