import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

function CookieBanner({
  onAccept,
  onCustomize,
  onDecline,
  preferenceMode,
  onSavePreferences,
}) {
  const [preferences, setPreferences] = useState({
    analytics: true,
    marketing: false,
  });

  const handleToggle = (key) => {
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    onSavePreferences(preferences);
  };

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Сообщение о куки">
      <div className={styles.content}>
        <h2 className={styles.title}>Мы используем куки для анализа</h2>
        <p className={styles.text}>
          GamblingOffer применяет cookies для обеспечения стабильной работы сайта, аналитики и
          персонализации офферов. Подробнее читайте в{' '}
          <Link to="/cookies" className={styles.link}>
            Cookie политике
          </Link>
          .
        </p>

        {preferenceMode ? (
          <form className={styles.preferences} onSubmit={handleSubmit}>
            <div className={styles.preferenceItem}>
              <span className={styles.preferenceLabel}>Необходимые</span>
              <span className={styles.preferenceStatus}>Всегда активно</span>
            </div>
            <label className={styles.preferenceItem}>
              <span className={styles.preferenceLabel}>Аналитика</span>
              <span className={styles.preferenceSwitch}>
                <input
                  type="checkbox"
                  checked={preferences.analytics}
                  onChange={() => handleToggle('analytics')}
                />
                <span className={styles.slider} />
              </span>
            </label>
            <label className={styles.preferenceItem}>
              <span className={styles.preferenceLabel}>Маркетинг</span>
              <span className={styles.preferenceSwitch}>
                <input
                  type="checkbox"
                  checked={preferences.marketing}
                  onChange={() => handleToggle('marketing')}
                />
                <span className={styles.slider} />
              </span>
            </label>
            <div className={styles.actions}>
              <button type="submit" className={styles.primaryButton}>
                Сохранить выбор
              </button>
              <button
                type="button"
                className={styles.secondaryButton}
                onClick={onDecline}
              >
                Только необходимые
              </button>
            </div>
          </form>
        ) : (
          <div className={styles.actions}>
            <button type="button" className={styles.primaryButton} onClick={onAccept}>
              Принять все
            </button>
            <button
              type="button"
              className={styles.secondaryButton}
              onClick={onCustomize}
            >
              Настроить
            </button>
            <button type="button" className={styles.minorButton} onClick={onDecline}>
              Только необходимые
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default CookieBanner;