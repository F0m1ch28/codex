import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Подвал сайта">
      <div className={styles.inner}>
        <div className={styles.column}>
          <h3 className={styles.heading}>GamblingOffer</h3>
          <p className={styles.text}>
            Международный путеводитель по гемблинг офферам. Мы анализируем
            бонусы, вейджеры и лимиты, чтобы вы принимали взвешенные решения и
            наслаждались честной игрой.
          </p>
          <p className={styles.disclaimer}>
            GamblingOffer — обзорный проект. Мы не проводим азартные игры и не
            принимаем платежи. Перед участием проверяйте законы вашей
            юрисдикции.
          </p>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subheading}>Навигация</h4>
          <nav className={styles.links} aria-label="Навигация в подвале">
            <NavLink to="/">Главная</NavLink>
            <NavLink to="/casinos">Casinos</NavLink>
            <NavLink to="/offers">Offers</NavLink>
            <NavLink to="/services">Услуги</NavLink>
            <NavLink to="/about">О нас</NavLink>
            <NavLink to="/contact">Контакт</NavLink>
          </nav>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subheading}>Правовая информация</h4>
          <nav className={styles.links} aria-label="Правовые ссылки">
            <NavLink to="/terms">Условия использования</NavLink>
            <NavLink to="/privacy">Политика конфиденциальности</NavLink>
            <NavLink to="/cookies">Cookie политика</NavLink>
          </nav>
          <div className={styles.contactBox}>
            <p className={styles.contactLabel}>Поделиться обратной связью</p>
            <a className={styles.contactLink} href="mailto:feedback@gamblingoffer.com">
              feedback@gamblingoffer.com
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} GamblingOffer. Все права защищены.</p>
      </div>
    </footer>
  );
}

export default Footer;