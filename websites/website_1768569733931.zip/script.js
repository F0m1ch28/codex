document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!expanded).toString());
            siteNav.classList.toggle("open");
        });

        siteNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute("aria-expanded", "false");
                    siteNav.classList.remove("open");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptCookies = document.getElementById("accept-cookies");
    const declineCookies = document.getElementById("decline-cookies");
    const consentStatus = localStorage.getItem("trotueeuCookieConsent");

    if (cookieBanner && !consentStatus) {
        cookieBanner.classList.add("active");
    }

    const handleConsent = (status) => {
        localStorage.setItem("trotueeuCookieConsent", status);
        cookieBanner.classList.remove("active");
    };

    if (acceptCookies) {
        acceptCookies.addEventListener("click", () => handleConsent("accepted"));
    }

    if (declineCookies) {
        declineCookies.addEventListener("click", () => handleConsent("declined"));
    }
});