document.addEventListener('DOMContentLoaded', () => {
  const yearSpan = document.getElementById('year');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.getElementById('nav-menu');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
    });
  }

  const banner = document.querySelector('[data-cookie-banner]');
  if (!banner) return;

  const choice = localStorage.getItem('adc-cookie-choice');
  if (!choice) {
    banner.removeAttribute('hidden');
  }

  const acceptBtn = banner.querySelector('[data-accept-cookies]');
  const declineBtn = banner.querySelector('[data-decline-cookies]');

  const closeBanner = (value) => {
    localStorage.setItem('adc-cookie-choice', value);
    banner.classList.add('hidden');
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => closeBanner('accepted'));
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => closeBanner('declined'));
  }
});