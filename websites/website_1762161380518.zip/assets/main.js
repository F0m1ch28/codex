document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navMenu.classList.toggle('open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const scrollBtn = document.getElementById('scrollTopBtn');
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 200) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');

    if (cookieBanner && cookieAccept) {
        if (localStorage.getItem('qmediaCookieConsent') === 'accepted') {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.remove('hidden');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem('qmediaCookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    const forms = document.querySelectorAll('form[data-form]');
    forms.forEach(form => {
        const messageBox = form.querySelector('.form-message');
        form.addEventListener('submit', event => {
            event.preventDefault();

            if (!form.checkValidity()) {
                form.reportValidity();
                if (messageBox) {
                    messageBox.textContent = 'Барлық міндетті өрістерді толтырыңыз.';
                    messageBox.classList.remove('success');
                }
                return;
            }

            if (messageBox) {
                messageBox.textContent = 'Рақмет! Хабарламаңыз қабылданды.';
                messageBox.classList.add('success');
            }

            form.reset();
        });
    });
});