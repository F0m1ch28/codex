document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    const navClose = document.querySelector(".nav-close");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navMenu.classList.add("open");
            document.body.style.overflow = "hidden";
        });

        if (navClose) {
            navClose.addEventListener("click", () => {
                navMenu.classList.remove("open");
                document.body.style.overflow = "";
            });
        }

        navMenu.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("open");
                document.body.style.overflow = "";
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");
    const consentStatus = localStorage.getItem("traverhvmiCookieConsent");

    if (cookieBanner) {
        if (consentStatus === "accepted" || consentStatus === "declined") {
            cookieBanner.classList.add("hidden");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem("traverhvmiCookieConsent", "accepted");
                cookieBanner.classList.add("hidden");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem("traverhvmiCookieConsent", "declined");
                cookieBanner.classList.add("hidden");
            });
        }
    }
});