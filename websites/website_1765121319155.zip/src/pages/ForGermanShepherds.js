import Meta from '../components/Meta';
import styles from './ForGermanShepherds.module.css';

const trainingFocus = [
  {
    title: 'Контроль енергії та драйву',
    description:
      'Переводимо потужний інстинкт у керовану роботу. Навчаємо стабільності в динамічних ситуаціях.',
  },
  {
    title: 'Соціалізація та адаптація',
    description:
      'Відпрацьовуємо реакції на людей, тварин, транспорт. Формуємо впевненість, а не тривогу.',
  },
  {
    title: 'Захист і службові сценарії',
    description:
      'Розвиваємо правильне хватання, затримання, охорону предметів. Працюємо з фігурантом.',
  },
  {
    title: 'Розумове навантаження',
    description:
      'Впроваджуємо nose work, пошукові завдання, вправи на кмітливість — вівчарка має працювати не лише силою.',
  },
];

const successStories = [
  {
    title: 'Грей: від гіперактивності до керованої служби',
    description:
      'Молодий кобель із надмірним збудженням. За 16 тижнів — контроль на прогулянках, охорона складу, стабільність у парі з охоронцем.',
  },
  {
    title: 'Міла: подолання страху транспорту',
    description:
      'Сука після травматичного досвіду боялася метро. Поступове занурення, ігрові вправи, підтримка власника — через 8 тижнів гуляє в центрі міста.',
  },
  {
    title: 'Гектор: команди для сімейного собаки',
    description:
      'Сімейна вівчарка з маленькими дітьми. Зробили акцент на слухняність, м’який контакт із дитиною, контроль охоронного інстинкту.',
  },
];

const equipment = [
  'Професійні фігурантські костюми та нарукавники',
  'Довгі та короткі повідці, капронові лінії, слідові шнури',
  'Платформи для балансу та вправ на фокус',
  'Службова екіпіровка для охоронних сценаріїв',
];

const ForGermanShepherdsPage = () => {
  return (
    <>
      <Meta
        title="Програми для німецьких вівчарок"
        description="Спеціалізоване дресирування німецьких вівчарок: слухняність, службова підготовка, робота з емоціями. Виїзди у Варшаві та Кракові."
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <h1>Програма, створена саме для німецьких вівчарок</h1>
            <p>
              Враховуємо потужний робочий потенціал, швидкість навчання та
              чутливість до лідера. Кожен блок — це баланс дисципліни та
              здорового драйву.
            </p>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://picsum.photos/1200/800?random=7"
              alt="Німецька вівчарка під час вправи"
            />
          </div>
        </div>
      </section>

      <section className={styles.focusSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Ключові напрями роботи</h2>
            <p>
              Надаємо собаці структуровану активність і навчаємо власника
              керувати цією енергією з повагою та впевненістю.
            </p>
          </header>
          <div className={styles.focusGrid}>
            {trainingFocus.map((item) => (
              <article key={item.title} className={styles.focusCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.storySection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Випадки успіху</h2>
            <p>Кожна історія — це тандем із власником, підтримка та системність.</p>
          </header>
          <div className={styles.storyGrid}>
            {successStories.map((story) => (
              <article key={story.title} className={styles.storyCard}>
                <div className={styles.storyImage}>
                  <img
                    src={`https://picsum.photos/800/600?random=${Math.floor(
                      Math.random() * 50 + 120
                    )}`}
                    alt={story.title}
                  />
                </div>
                <div className={styles.storyContent}>
                  <h3>{story.title}</h3>
                  <p>{story.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.equipmentSection}>
        <div className={`container ${styles.equipmentInner}`}>
          <div className={styles.equipmentContent}>
            <h2>Сучасне оснащення</h2>
            <p>
              Використовуємо сертифіковані інструменти, щоб собака працювала
              безпечно і з максимальною віддачею.
            </p>
            <ul className={styles.equipmentList}>
              {equipment.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div className={styles.equipmentImage}>
            <img
              src="https://picsum.photos/1200/800?random=17"
              alt="Оснащення для тренувань німецьких вівчарок"
            />
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={`container ${styles.ctaInner}`}>
          <div>
            <h2>Почнімо із тест-дня</h2>
            <p>
              Кінолог приїде до вас, проведе діагностику та покаже, як
              працюємо. Разом складемо маршрут розвитку вашої вівчарки.
            </p>
          </div>
          <a href="tel:+48123456789" className={styles.ctaButton}>
            Зателефонувати кінологу
          </a>
        </div>
      </section>
    </>
  );
};

export default ForGermanShepherdsPage;