import { useState } from 'react';
import Meta from '../components/Meta';
import styles from './Contacts.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  city: '',
  message: '',
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) {
      currentErrors.name = "Вкажіть ім'я";
    }
    if (!formData.email.trim()) {
      currentErrors.email = 'Вкажіть email';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      currentErrors.email = 'Невірний формат email';
    }
    if (!formData.phone.trim()) {
      currentErrors.phone = 'Вкажіть телефон';
    }
    if (!formData.city.trim()) {
      currentErrors.city = 'Оберіть місто';
    }
    if (!formData.message.trim()) {
      currentErrors.message = 'Опишіть ваш запит';
    }
    return currentErrors;
  };

  const handleChange = (field) => (event) => {
    setFormData((prev) => ({
      ...prev,
      [field]: event.target.value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialFormState);
    }
  };

  return (
    <>
      <Meta
        title="Контакти | Професійне дресерування собак"
        description="Зв’яжіться з кінологами у Варшаві та Кракові. Виїзні заняття, консультації, діагностика німецьких вівчарок."
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div>
            <h1>Зв’яжіться з нашою командою</h1>
            <p>
              Розкажіть про свою ситуацію — підготуємо пропозицію та узгодимо
              тест-день. Працюємо у Варшаві та Кракові, можливі виїзди в
              передмістя.
            </p>
            <ul className={styles.contactList}>
              <li>
                <strong>Адреса:</strong> Варшава, вул. Тренувальна, 10 / Краків,
                вул. Собача, 5 (працюємо за виїздом)
              </li>
              <li>
                <strong>Телефон:</strong>{' '}
                <a href="tel:+48123456789">+48 123 456 789</a>
              </li>
              <li>
                <strong>Email:</strong>{' '}
                <a href="mailto:trainer@dog-training.pl">
                  trainer@dog-training.pl
                </a>
              </li>
            </ul>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://picsum.photos/1200/800?random=8"
              alt="Кінолог консультує клієнта"
            />
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className={`container ${styles.formGrid}`}>
          <div className={styles.formInfo}>
            <h2>Заплануйте дзвінок або виїзд кінолога</h2>
            <p>
              Заповніть форму — ми зв’яжемося протягом робочого дня, узгодимо
              час зустрічі та підготуємо попередній план.
            </p>
            <div className={styles.schedule}>
              <h3>Графік роботи</h3>
              <p>Пн–Сб: 08:00–20:00</p>
              <p>Нд: консультації за попередньою домовленістю</p>
            </div>
          </div>

          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="name">Ім’я та прізвище</label>
              <input
                id="name"
                type="text"
                value={formData.name}
                onChange={handleChange('name')}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && (
                <span className={styles.error}>{errors.name}</span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                value={formData.email}
                onChange={handleChange('email')}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && (
                <span className={styles.error}>{errors.email}</span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="phone">Телефон</label>
              <input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange('phone')}
                aria-invalid={Boolean(errors.phone)}
              />
              {errors.phone && (
                <span className={styles.error}>{errors.phone}</span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="city">Місто</label>
              <select
                id="city"
                value={formData.city}
                onChange={handleChange('city')}
                aria-invalid={Boolean(errors.city)}
              >
                <option value="">Оберіть місто</option>
                <option value="Варшава">Варшава</option>
                <option value="Краків">Краків</option>
                <option value="Інше">Передмістя / інше</option>
              </select>
              {errors.city && (
                <span className={styles.error}>{errors.city}</span>
              )}
            </div>

            <div className={styles.formGroupFull}>
              <label htmlFor="message">Опишіть ваш запит</label>
              <textarea
                id="message"
                rows="4"
                value={formData.message}
                onChange={handleChange('message')}
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && (
                <span className={styles.error}>{errors.message}</span>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Відправити заявку
            </button>

            {submitted && (
              <p className={styles.success} role="status">
                Дякуємо! Ми зв’яжемося з вами протягом найближчого робочого дня.
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default ContactsPage;