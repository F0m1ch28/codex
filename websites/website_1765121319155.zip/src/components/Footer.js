import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.top}`}>
      <div className={styles.brand}>
        <h2 className={styles.title}>Професійне дресерування собак</h2>
        <p className={styles.subtitle}>
          Кінологічна команда, що понад десять років розкриває потенціал
          німецьких вівчарок у Варшаві та Кракові.
        </p>
        <p className={styles.legal}>
          Варшава, вул. Тренувальна, 10 / Краків, вул. Собача, 5 (працюємо за
          виїздом)
        </p>
      </div>

      <div className={styles.linksGroup}>
        <h3 className={styles.heading}>Сторінки</h3>
        <ul className={styles.list}>
          <li>
            <NavLink to="/pro-nas" className={styles.link}>
              Про нас
            </NavLink>
          </li>
          <li>
            <NavLink to="/posluhy" className={styles.link}>
              Послуги
            </NavLink>
          </li>
          <li>
            <NavLink to="/dlya-nimeckyh-vivcharok" className={styles.link}>
              Для німецьких вівчарок
            </NavLink>
          </li>
          <li>
            <NavLink to="/kontakty" className={styles.link}>
              Контакти
            </NavLink>
          </li>
        </ul>
      </div>

      <div className={styles.linksGroup}>
        <h3 className={styles.heading}>Правова інформація</h3>
        <ul className={styles.list}>
          <li>
            <NavLink to="/umovy-vykorystannya" className={styles.link}>
              Умови використання
            </NavLink>
          </li>
          <li>
            <NavLink to="/polityka-konfidentsiinosti" className={styles.link}>
              Політика конфіденційності
            </NavLink>
          </li>
          <li>
            <NavLink to="/polityka-cookie" className={styles.link}>
              Політика щодо cookie
            </NavLink>
          </li>
        </ul>
      </div>

      <div className={styles.contactGroup}>
        <h3 className={styles.heading}>Контакти</h3>
        <p className={styles.contactLine}>
          <a href="tel:+48123456789" className={styles.contactLink}>
            +48 123 456 789
          </a>
        </p>
        <p className={styles.contactLine}>
          <a href="mailto:trainer@dog-training.pl" className={styles.contactLink}>
            trainer@dog-training.pl
          </a>
        </p>
        <p className={styles.caption}>
          Працюємо у форматі виїзних занять та персональних консультацій.
        </p>
      </div>
    </div>

    <div className={styles.bottom}>
      <p className={styles.bottomText}>
        © {new Date().getFullYear()} Професійне дресерування собак. Усі права
        захищено.
      </p>
    </div>
  </footer>
);

export default Footer;