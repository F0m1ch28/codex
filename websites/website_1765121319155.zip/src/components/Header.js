import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { label: 'Головна', to: '/' },
  { label: 'Про нас', to: '/pro-nas' },
  { label: 'Послуги', to: '/posluhy' },
  { label: 'Для німецьких вівчарок', to: '/dlya-nimeckyh-vivcharok' },
  { label: 'Контакти', to: '/kontakty' },
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 16);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [isMenuOpen]);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header
      className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}
    >
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          Професійне дресерування собак
        </NavLink>

        <button
          type="button"
          className={`${styles.menuButton} ${
            isMenuOpen ? styles.menuButtonOpen : ''
          }`}
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Перемкнути навігацію"
        >
          <span className={styles.menuIcon} />
        </button>

        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`}
          aria-label="Основна навігація"
        >
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.to} className={styles.navItem}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                  onClick={closeMenu}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className={styles.contact}>
            <a href="tel:+48123456789" className={styles.contactLink}>
              +48 123 456 789
            </a>
            <a
              href="mailto:trainer@dog-training.pl"
              className={styles.contactLink}
            >
              trainer@dog-training.pl
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;