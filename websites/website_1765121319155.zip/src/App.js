import { useEffect } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import ForGermanShepherdsPage from './pages/ForGermanShepherds';
import ContactsPage from './pages/Contacts';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';

const RouteChangeHandler = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className="app-shell">
      <a href="#main-content" className="skip-link">
        Пропустити до основного контенту
      </a>
      <Header />
      <RouteChangeHandler />
      <main id="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/pro-nas" element={<AboutPage />} />
          <Route path="/posluhy" element={<ServicesPage />} />
          <Route
            path="/dlya-nimeckyh-vivcharok"
            element={<ForGermanShepherdsPage />}
          />
          <Route path="/kontakty" element={<ContactsPage />} />
          <Route path="/umovy-vykorystannya" element={<TermsPage />} />
          <Route
            path="/polityka-konfidentsiinosti"
            element={<PrivacyPage />}
          />
          <Route path="/polityka-cookie" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;