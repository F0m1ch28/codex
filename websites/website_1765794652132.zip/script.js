document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");
  const toast = document.querySelector(".toast");

  // Mobile navigation toggle
  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", !expanded);
      navLinks.classList.toggle("open");
      navToggle.innerText = expanded ? "Menu" : "Close";
    });

    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.innerText = "Menu";
      });
    });
  }

  // Cookie banner
  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const cookiePref = localStorage.getItem("cc-cookie-preference");

    if (!cookiePref) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add("show");
      });
    }

    const handleCookie = (value) => {
      localStorage.setItem("cc-cookie-preference", value);
      cookieBanner.classList.remove("show");
      if (toast) {
        toast.innerText = value === "accepted" ? "Cookie tracking enabled. Tailored hash optimizations unlocked." : "Cookie tracking declined. Default hash flow applied.";
        toast.classList.add("show");
        setTimeout(() => toast.classList.remove("show"), 3200);
      }
    };

    acceptBtn?.addEventListener("click", () => handleCookie("accepted"));
    declineBtn?.addEventListener("click", () => handleCookie("declined"));
  }

  // Plan calculator (plans page)
  const planSelector = document.getElementById("planSelector");
  const planSummary = document.getElementById("planSummary");

  if (planSelector && planSummary) {
    const planDetails = {
      basic: { label: "Plan 1 · Pulse 10", amount: 10, speed: "1.5 GH/s", bonus: "5% Intro Hash Boost" },
      ascent: { label: "Plan 2 · Vector 50", amount: 50, speed: "8 GH/s", bonus: "12% Intro Hash Boost" },
      quantum: { label: "Plan 3 · Quantum 200", amount: 200, speed: "38 GH/s", bonus: "18% Intro Hash Boost" },
      apex: { label: "Plan 4 · Apex 500", amount: 500, speed: "96 GH/s", bonus: "25% Intro Hash Boost" },
      custom: { label: "Plan 5 · Custom Allocation", amount: 0, speed: "Variable", bonus: "Custom Bonus Negotiated" },
    };

    const updatePlanSummary = () => {
      const value = planSelector.value;
      const detail = planDetails[value];
      if (!detail) return;
      planSummary.querySelector("[data-plan-label]").innerText = detail.label;
      planSummary.querySelector("[data-plan-amount]").innerText = detail.amount ? `${detail.amount} USDT` : "Tailored";
      planSummary.querySelector("[data-plan-speed]").innerText = detail.speed;
      planSummary.querySelector("[data-plan-bonus]").innerText = detail.bonus;
    };

    planSelector.addEventListener("change", updatePlanSummary);
    updatePlanSummary();
  }

  // Registration form validation
  const registrationForm = document.getElementById("registrationForm");
  if (registrationForm) {
    const feedback = registrationForm.querySelector(".form-feedback");
    registrationForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(registrationForm);
      const requiredFields = ["fullName", "email", "country", "plan"];
      const invalid = requiredFields.some((field) => !formData.get(field)?.trim());

      if (invalid) {
        feedback.classList.remove("success");
        feedback.classList.add("error");
        feedback.innerText = "Please complete all required fields before requesting partial hash allocation.";
        return;
      }

      feedback.classList.remove("error");
      feedback.classList.add("success");
      feedback.innerText = "Registration received. Expect allocation instructions within 15 minutes.";
      registrationForm.reset();
    });
  }

  // Copy wallet button
  const copyBtn = document.querySelector(".copy-btn");
  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      const address = copyBtn.dataset.address;
      if (!address) return;
      try {
        await navigator.clipboard.writeText(address);
        copyBtn.innerText = "Wallet Address Copied";
        setTimeout(() => (copyBtn.innerText = "Copy Address"), 1800);
      } catch (err) {
        copyBtn.innerText = "Press CTRL+C to copy";
        setTimeout(() => (copyBtn.innerText = "Copy Address"), 1800);
      }
    });
  }

  // Dashboard counters
  const counters = document.querySelectorAll("[data-count]");
  if (counters.length) {
    const animateCounters = () => {
      counters.forEach((counter) => {
        const target = parseFloat(counter.dataset.count);
        const duration = 1600;
        const start = performance.now();

        const tick = (now) => {
          const progress = Math.min((now - start) / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          const value = (target * eased).toFixed(counter.dataset.decimals || 0);
          counter.innerText = value;
          if (progress < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });

      document.querySelectorAll(".progress-bar").forEach((bar) => {
        const value = bar.dataset.progress || 0;
        requestAnimationFrame(() => {
          bar.style.transform = `scaleX(${value})`;
        });
      });
    };
    animateCounters();
  }
});