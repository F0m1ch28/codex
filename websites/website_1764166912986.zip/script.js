document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  const navBackdrop = document.querySelector("[data-nav-backdrop]");
  const navLinks = document.querySelectorAll(".main-nav a");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const contactForm = document.querySelector(".contact-form");
  const yearHolder = document.querySelectorAll("#current-year");

  // Current year
  const currentYear = new Date().getFullYear();
  yearHolder.forEach(el => el.textContent = currentYear);

  // Mobile nav handling
  const closeNav = () => {
    mainNav?.classList.remove("is-open");
    navBackdrop?.classList.remove("is-visible");
    document.body.classList.remove("nav-open");
    navToggle?.setAttribute("aria-expanded", "false");
  };

  const toggleNav = () => {
    const isOpen = mainNav?.classList.toggle("is-open");
    if (isOpen) {
      document.body.classList.add("nav-open");
      navBackdrop?.classList.add("is-visible");
    } else {
      document.body.classList.remove("nav-open");
      navBackdrop?.classList.remove("is-visible");
    }
    navToggle?.setAttribute("aria-expanded", String(isOpen));
  };

  navToggle?.addEventListener("click", toggleNav);
  navBackdrop?.addEventListener("click", closeNav);
  navLinks.forEach(link => link.addEventListener("click", closeNav));

  window.addEventListener("resize", () => {
    if (window.innerWidth >= 960) {
      closeNav();
    }
  });

  // Active nav
  const pathname = window.location.pathname.split("/").pop() || "index.html";
  navLinks.forEach(link => {
    if (link.getAttribute("href") === pathname) {
      link.classList.add("is-active");
      link.setAttribute("aria-current", "page");
    }
  });

  // Reveal animations
  const revealElements = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  revealElements.forEach(el => observer.observe(el));

  // Cookie banner
  const cookieChoice = localStorage.getItem("vorenshira-cookie-consent");
  if (!cookieChoice && cookieBanner) {
    setTimeout(() => cookieBanner.classList.add("show"), 1200);
  }

  const setCookieChoice = (value) => {
    localStorage.setItem("vorenshira-cookie-consent", value);
    cookieBanner?.classList.remove("show");
  };

  acceptBtn?.addEventListener("click", () => setCookieChoice("accepted"));
  declineBtn?.addEventListener("click", () => setCookieChoice("declined"));

  // Contact form simulated submit
  contactForm?.addEventListener("submit", (event) => {
    event.preventDefault();
    const response = contactForm.querySelector(".form-response");
    response.textContent = "Gracias por escribirnos. Te responderemos muy pronto.";
    contactForm.reset();
  });
});