import React from 'react';
import styles from './ContactForm.module.css';

const initialState = {
  name: '',
  email: '',
  phone: '',
  message: '',
  consent: false,
};

const ContactForm = () => {
  const [formData, setFormData] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, представьтесь.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите электронную почту для связи.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Введите корректный адрес электронной почты.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Опишите ваш запрос.';
    }
    if (!formData.consent) {
      newErrors.consent = 'Необходимо согласие на обработку данных.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        setSubmitted(true);
        setFormData(initialState);
      }, 1200);
    }
  };

  return (
    <section className={styles.formSection} aria-labelledby="contact-form-title">
      <h2 id="contact-form-title" className={styles.title}>Записаться на консультацию</h2>
      <p className={styles.subtitle}>
        Оставьте контакты, и наш координатор свяжется с вами, чтобы подобрать программу и ответить на вопросы.
      </p>
      <form className={styles.form} onSubmit={handleSubmit} noValidate>
        <label className={styles.label}>
          Имя и фамилия
          <input
            className={`${styles.input} ${errors.name ? styles.invalid : ''}`}
            type="text"
            name="name"
            autoComplete="name"
            value={formData.name}
            onChange={handleChange}
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? 'name-error' : undefined}
          />
          {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
        </label>

        <label className={styles.label}>
          Электронная почта
          <input
            className={`${styles.input} ${errors.email ? styles.invalid : ''}`}
            type="email"
            name="email"
            autoComplete="email"
            value={formData.email}
            onChange={handleChange}
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? 'email-error' : undefined}
          />
          {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
        </label>

        <label className={styles.label}>
          Телефон (опционально)
          <input
            className={styles.input}
            type="tel"
            name="phone"
            autoComplete="tel"
            value={formData.phone}
            onChange={handleChange}
          />
        </label>

        <label className={styles.label}>
          Ваш запрос
          <textarea
            className={`${styles.textarea} ${errors.message ? styles.invalid : ''}`}
            name="message"
            rows="4"
            value={formData.message}
            onChange={handleChange}
            aria-invalid={!!errors.message}
            aria-describedby={errors.message ? 'message-error' : undefined}
          />
          {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
        </label>

        <label className={styles.checkboxLabel}>
          <input
            type="checkbox"
            name="consent"
            checked={formData.consent}
            onChange={handleChange}
            aria-invalid={!!errors.consent}
          />
          <span>Я согласен(а) на обработку персональных данных согласно политике конфиденциальности.</span>
        </label>
        {errors.consent && <span className={styles.error}>{errors.consent}</span>}

        <button className={styles.submit} type="submit" disabled={loading}>
          {loading ? 'Отправка...' : 'Отправить заявку'}
        </button>

        {submitted && (
          <div className={styles.success} role="status">
            Спасибо! Мы получили заявку и свяжемся с вами в ближайшее время.
          </div>
        )}
      </form>
    </section>
  );
};

export default ContactForm;