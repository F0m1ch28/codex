import React from 'react';
import styles from './CourseCard.module.css';

const CourseCard = ({ title, description, duration, focus }) => (
  <article className={styles.card}>
    <div className={styles.content}>
      <h3 className={styles.title}>{title}</h3>
      <p className={styles.description}>{description}</p>
      <ul className={styles.list}>
        {focus.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
    <div className={styles.footer}>
      <span className={styles.duration}>{duration}</span>
      <button type="button" className={styles.button}>
        Узнать подробнее
      </button>
    </div>
  </article>
);

export default CourseCard;