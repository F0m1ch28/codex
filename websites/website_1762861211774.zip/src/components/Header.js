import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  const toggleMenu = () => setIsOpen((prev) => !prev);
  const closeMenu = () => setIsOpen(false);

  React.useEffect(() => {
    if (isOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [isOpen]);

  return (
    <header className={styles.header}>
      <div className={styles.wrapper}>
        <NavLink to="/" className={styles.logo} aria-label="Braventy Family Academy">
          Braventy<span>Family</span>
        </NavLink>
        <nav className={`${styles.nav} ${isOpen ? styles.open : ''}`} aria-label="Основная навигация">
          <NavLink onClick={closeMenu} to="/" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}>
            Главная
          </NavLink>
          <NavLink onClick={closeMenu} to="/o-nas" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}>
            О нас
          </NavLink>
          <NavLink onClick={closeMenu} to="/kursy" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}>
            Курсы
          </NavLink>
          <NavLink onClick={closeMenu} to="/programma" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}>
            Программа
          </NavLink>
          <NavLink onClick={closeMenu} to="/specialisty" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}>
            Специалисты
          </NavLink>
          <NavLink onClick={closeMenu} to="/kontakty" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}>
            Контакты
          </NavLink>
        </nav>
        <button
          type="button"
          className={`${styles.burger} ${isOpen ? styles.burgerOpen : ''}`}
          onClick={toggleMenu}
          aria-label={isOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={isOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;