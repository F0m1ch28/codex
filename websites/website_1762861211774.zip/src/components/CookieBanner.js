import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem('braventy-cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('braventy-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Информация об использовании файлов cookie">
      <p className={styles.text}>
        Мы используем файлы cookie для персонализации контента и анализа взаимодействия. Продолжая пользоваться сайтом, вы соглашаетесь с нашей политикой cookies.
      </p>
      <a className={styles.link} href="/cookie-policy">Подробнее</a>
      <button type="button" className={styles.button} onClick={acceptCookies}>
        Согласиться
      </button>
    </div>
  );
};

export default CookieBanner;