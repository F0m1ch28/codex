import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.wrapper}>
      <div className={styles.column}>
        <h3 className={styles.title}>Braventy Family Academy</h3>
        <p className={styles.text}>
          Мы помогаем русскоязычным семьям в Европе выстраивать устойчивые отношения, понимать детей и открывать новые горизонты семейного счастья.
        </p>
      </div>
      <div className={styles.column}>
        <h4 className={styles.subtitle}>Навигация</h4>
        <ul className={styles.list}>
          <li><NavLink to="/o-nas" className={styles.link}>О нас</NavLink></li>
          <li><NavLink to="/kursy" className={styles.link}>Курсы</NavLink></li>
          <li><NavLink to="/programma" className={styles.link}>Программа</NavLink></li>
          <li><NavLink to="/specialisty" className={styles.link}>Команда</NavLink></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4 className={styles.subtitle}>Контакты</h4>
        <address className={styles.address} aria-label="Контактные данные">
          <span>Kurfürstendamm 156,<br />10709 Berlin, Germany</span>
          <a className={styles.phone} href="tel:+493056789012">+49 30 5678 9012</a>
          <p>Для связи заполните форму обратной связи на сайте.</p>
        </address>
      </div>
      <div className={styles.column}>
        <h4 className={styles.subtitle}>Юридическая информация</h4>
        <ul className={styles.list}>
          <li><NavLink to="/usloviya" className={styles.link}>Пользовательское соглашение</NavLink></li>
          <li><NavLink to="/konfidentsialnost" className={styles.link}>Политика конфиденциальности</NavLink></li>
          <li><NavLink to="/cookie-policy" className={styles.link}>Политика cookies</NavLink></li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} Braventy Family Academy. Все права защищены.</span>
    </div>
  </footer>
);

export default Footer;