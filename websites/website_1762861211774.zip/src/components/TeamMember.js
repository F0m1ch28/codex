import React from 'react';
import styles from './TeamMember.module.css';

const TeamMember = ({ name, role, bio, experience, image }) => (
  <article className={styles.card}>
    <div className={styles.avatarWrapper}>
      <img className={styles.avatar} src={image} alt={`Психолог ${name}`} loading="lazy" />
    </div>
    <div className={styles.content}>
      <h3 className={styles.name}>{name}</h3>
      <span className={styles.role}>{role}</span>
      <p className={styles.bio}>{bio}</p>
      <p className={styles.experience}>{experience}</p>
    </div>
  </article>
);

export default TeamMember;