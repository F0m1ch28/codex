import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>О Braventy Family Academy — философия и подход</title>
      <meta name="description" content="Узнайте историю Braventy Family Academy, наш подход к семейной психологии и ценности, которые помогают создавать гармонию в семьях." />
      <meta name="keywords" content="семейная психология онлайн, курсы для семей Европа, отношения в паре" />
    </Helmet>
    <section className={styles.hero}>
      <h1>О нас</h1>
      <p>
        Braventy Family Academy появилась из идеи объединить лучшие практики семейной психологии со знаниями о жизни русскоязычных семей в Европе. Мы создаём пространство, где можно учиться понимать себя, партнёра и детей, сохраняя идентичность и чувство дома.
      </p>
    </section>

    <section className={styles.story}>
      <div className={styles.sectionHeader}>
        <span className={styles.eyebrow}>История</span>
        <h2>Как всё началось</h2>
      </div>
      <div className={styles.storyGrid}>
        <article className={styles.storyCard}>
          <h3>Переезд и новые вызовы</h3>
          <p>
            Команда платформы — семьи, прошедшие путь адаптации за рубежом. Мы почувствовали, как важно иметь поддержку и ресурсы, когда привычные ориентиры меняются.
          </p>
        </article>
        <article className={styles.storyCard}>
          <h3>Синергия специалистов</h3>
          <p>
            Мы объединили психологов, системных терапевтов, коучей и педагогов, чтобы смотреть на семью целостно и предлагать решения, которые работают.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.values}>
      <div className={styles.sectionHeader}>
        <span className={styles.eyebrow}>Философия</span>
        <h2>Наши ценности</h2>
      </div>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Доверие</h3>
          <p>Мы создаём безопасную среду, где можно говорить о сложном и находить поддержку.</p>
        </article>
        <article>
          <h3>Осознанность</h3>
          <p>Учимся замечать эмоции и потребности, чтобы строить уважительные отношения.</p>
        </article>
        <article>
          <h3>Системность</h3>
          <p>Рассматриваем семью как живую систему и предлагаем комплексные решения.</p>
        </article>
      </div>
    </section>

    <section className={styles.approach}>
      <div className={styles.content}>
        <h2>Подход</h2>
        <p>
          Мы работаем с доказательными методами, сочетая эмоционально-фокусированную терапию, позитивную дисциплину, коучинговые инструменты и элементы семейной медиации. Это позволяет не просто решать текущий запрос, а формировать устойчивые навыки взаимодействия.
        </p>
        <p>
          Каждый курс включает диагностику, практику и рефлексию. Платформа поддерживает участников через живые встречи, тематические мастер-классы и сообщество семей, которые вместе развивают культуру диалога.
        </p>
      </div>
      <div className={styles.imageWrapper}>
        <img src="https://picsum.photos/800/600?random=11&family" alt="Команда Braventy Family Academy в процессе работы" loading="lazy" />
      </div>
    </section>
  </>
);

export default About;