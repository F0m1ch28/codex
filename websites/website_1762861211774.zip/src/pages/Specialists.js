import React from 'react';
import { Helmet } from 'react-helmet';
import TeamMember from '../components/TeamMember';
import styles from './Specialists.module.css';

const specialists = [
  {
    name: 'Екатерина Власова',
    role: 'Семейный психолог, EFT-терапевт',
    bio: 'Работает с парами и семьями в контексте эмиграции, помогает восстанавливать доверие и эмоциональную связь.',
    experience: '12 лет практики, член Европейской ассоциации семейной терапии.',
    image: 'https://picsum.photos/400/400?random=3&family',
  },
  {
    name: 'Алексей Иванов',
    role: 'Психолог, медиатор',
    bio: 'Специализируется на семейной медиации, помогает договариваться о правилах и выстраивать взаимодействие с подростками.',
    experience: '10 лет практики, сертифицированный медиатор EUCON.',
    image: 'https://picsum.photos/400/400?random=13&family',
  },
  {
    name: 'Мария Гордеева',
    role: 'Детский психолог',
    bio: 'Работает с эмоциональным развитием детей и подростков, поддерживает родителей в период адаптации.',
    experience: '8 лет практики, магистр детской психологии.',
    image: 'https://picsum.photos/400/400?random=14&family',
  },
  {
    name: 'София Литвинова',
    role: 'Коуч семейной динамики',
    bio: 'Помогает формировать семейные ритуалы, распределять роли и создавать систему поддержки в доме.',
    experience: '9 лет практики, коуч ICF PCC.',
    image: 'https://picsum.photos/400/400?random=15&family',
  },
];

const Specialists = () => (
  <>
    <Helmet>
      <title>Специалисты Braventy Family Academy</title>
      <meta name="description" content="Познакомьтесь с командой специалистов Braventy Family Academy: семейные психологи, коучи и медиаторы." />
      <meta name="keywords" content="семейная психология онлайн, специалисты, отношения в паре" />
    </Helmet>
    <section className={styles.hero}>
      <h1>Команда специалистов</h1>
      <p>
        Каждый из наших экспертов — практикующий специалист с международным образованием. Мы работаем в связке, чтобы вы получали поддержку с разных сторон.
      </p>
    </section>
    <section className={styles.grid}>
      {specialists.map((item) => (
        <TeamMember key={item.name} {...item} />
      ))}
    </section>
  </>
);

export default Specialists;