import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика использования cookies Braventy Family Academy</title>
      <meta name="description" content="Политика использования cookies на сайте Braventy Family Academy: виды файлов, цели и управление предпочтениями." />
    </Helmet>
    <section className={styles.section}>
      <h1>Политика использования cookies</h1>
      <p>
        Файлы cookies помогают нам улучшать работу сайта и предоставлять персонализированный опыт.
      </p>

      <h2>Что такое cookies</h2>
      <p>
        Cookies — небольшие текстовые файлы, которые сохраняются в вашем браузере. Они не содержат личной информации, но помогают узнавать посетителей.
      </p>

      <h2>Как мы используем cookies</h2>
      <ul>
        <li>Функциональные cookies — обеспечивают работу формы и навигации;</li>
        <li>Аналитические cookies — помогают понимать, как пользователи взаимодействуют с сайтом;</li>
        <li>Настроечные cookies — запоминают ваши предпочтения.</li>
      </ul>

      <h2>Управление cookies</h2>
      <p>
        Вы можете изменить настройки браузера или использовать баннер согласия, чтобы отключить ненужные cookies. Обратите внимание, что это может повлиять на функциональность сайта.
      </p>
    </section>
  </>
);

export default CookiePolicy;