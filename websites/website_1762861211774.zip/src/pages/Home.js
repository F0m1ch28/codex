import React from 'react';
import { Helmet } from 'react-helmet';
import { NavLink } from 'react-router-dom';
import CourseCard from '../components/CourseCard';
import ContactForm from '../components/ContactForm';
import styles from './Home.module.css';

const statsData = [
  { label: 'семей прошли наши курсы', value: 870 },
  { label: 'часов живых встреч и вебинаров', value: 3200 },
  { label: 'сертифицированных специалистов', value: 18 },
];

const programs = [
  {
    title: 'Отношения в паре',
    description: 'Глубокая работа с эмоциями, доверием и совместной поддержкой в разных жизненных циклах пары.',
    duration: '8 недель',
    focus: ['Ресурсные практики', 'Навыки диалога', 'Решение конфликтов'],
  },
  {
    title: 'Воспитание детей',
    description: 'Поддержка родителей с фокусом на возрастные кризисы, экологичную дисциплину и эмоциональную грамотность.',
    duration: '10 недель',
    focus: ['Возрастная психология', 'Эмоциональная регуляция', 'Семейные договорённости'],
  },
  {
    title: 'Коммуникация в семье',
    description: 'Формируем привычки уважительного общения, взаимного слушания и общей системы ценностей.',
    duration: '6 недель',
    focus: ['Структура общения', 'Семейные ритуалы', 'Превенция конфликтов'],
  },
];

const testimonials = [
  {
    family: 'Анна и Михаил, Вена',
    quote: 'Впервые почувствовали, что общаемся как команда. Поддержка кураторов и домашние задания сделали чудо.',
  },
  {
    family: 'Наталья, Барселона',
    quote: 'На курсе по воспитанию я научилась слышать сына-подростка. Теперь у нас есть семейные встречи по пятницам.',
  },
  {
    family: 'Ольга и Дмитрий, Берлин',
    quote: 'Программа помогла мягко пройти период переезда и перестройки семейных ролей. Чувствуем опору друг в друге.',
  },
];

const processSteps = [
  {
    title: 'Диагностика и запрос',
    description: 'Мы изучаем контекст вашей семьи, задачи и ожидания. Это помогает подобрать оптимальный формат обучения.',
  },
  {
    title: 'Модули и живые сессии',
    description: 'Вы проходите видеоуроки, выполняете практику и участвуете во встречах с психологами.',
  },
  {
    title: 'Поддержка и результат',
    description: 'После завершения программы вы получаете план действий и доступ к сообществу выпускников.',
  },
];

const projects = [
  { id: 1, category: 'отношения', title: 'Перезапуск диалога в паре', image: 'https://picsum.photos/1200/800?random=4&family', description: '12-недельный трек для пары, проживающей кризис после переезда.' },
  { id: 2, category: 'воспитание', title: 'Настройка границ с подростком', image: 'https://picsum.photos/1200/800?random=5&family', description: 'Работа с гибкими правилами, доверительной коммуникацией и эмоциональным интеллектом.' },
  { id: 3, category: 'коммуникация', title: 'Семейные советы', image: 'https://picsum.photos/1200/800?random=6&family', description: 'Создание еженедельных семейных встреч и ритуалов поддержки.' },
  { id: 4, category: 'отношения', title: 'Эмоциональная грамотность пары', image: 'https://picsum.photos/1200/800?random=7&family', description: 'Обучение выражению чувств без обвинений и формирование общей стратегии.' },
];

const faqs = [
  {
    question: 'Как проходит обучение на платформе?',
    answer: 'Обучение сочетает видеоматериалы, живые встречи в Zoom и чат с психологом. Вы получаете материалы каждую неделю и выполняете практики.',
  },
  {
    question: 'Подходят ли курсы для семей из разных городов Европы?',
    answer: 'Да, мы работаем онлайн и учитываем культурные и законодательные особенности разных стран ЕС.',
  },
  {
    question: 'Можно ли присоединиться к программе уже идущей группы?',
    answer: 'Да, мы регулярно запускаем новые потоки и помогаем мягко включиться в процесс с персональным куратором.',
  },
];

const blogPosts = [
  {
    title: 'Как сохранить близость в новой стране',
    excerpt: 'Пять практик для пар, которые переехали и заново выстраивают быт и поддержку.',
    image: 'https://picsum.photos/800/600?random=8&family',
    link: '/blog/blizost-v-novoy-strane',
  },
  {
    title: 'Эмоциональный словарь для всей семьи',
    excerpt: 'Учимся говорить о чувствах на одном языке с детьми и партнёром.',
    image: 'https://picsum.photos/800/600?random=9&family',
    link: '/blog/emocionalnyy-slovar',
  },
  {
    title: 'Семейные встречи как ритуал',
    excerpt: 'Как создать традицию еженедельных семейных собраний и не превратить их в скучное обязательство.',
    image: 'https://picsum.photos/800/600?random=10&family',
    link: '/blog/semeinye-vstrechi',
  },
];

const Home = () => {
  const [currentTestimonial, setCurrentTestimonial] = React.useState(0);
  const [projectsFilter, setProjectsFilter] = React.useState('all');
  const [visibleStats, setVisibleStats] = React.useState([0, 0, 0]);
  const statsRef = React.useRef(null);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            statsData.forEach((stat, index) => {
              const increment = Math.ceil(stat.value / 60);
              let current = 0;
              const interval = setInterval(() => {
                current += increment;
                if (current >= stat.value) {
                  current = stat.value;
                  clearInterval(interval);
                }
                setVisibleStats((prev) => {
                  const updated = [...prev];
                  updated[index] = current;
                  return updated;
                });
              }, 40);
            });
            observer.disconnect();
          }
        });
      },
      { threshold: 0.3 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
  }, []);

  const filteredProjects = projectsFilter === 'all'
    ? projects
    : projects.filter((project) => project.category === projectsFilter);

  return (
    <>
      <Helmet>
        <title>Braventy Family Academy — семейные курсы в Европе</title>
        <meta name="description" content="Braventy Family Academy — семейная психология онлайн. Курсы для семей в Европе: отношения в паре, воспитание детей, коммуникация и семейная динамика." />
        <meta name="keywords" content="курсы для семей Европа, семейная психология онлайн, отношения в паре, воспитание детей" />
      </Helmet>
      <div className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Braventy Family Academy</span>
          <h1 className={styles.heroTitle}>Строим крепкие семейные связи</h1>
          <p className={styles.heroText}>
            Помогаем развивать уважительный диалог, эмоциональную близость и устойчивые семейные ритуалы — онлайн и в живом общении от ведущих психологов Европы.
          </p>
          <div className={styles.heroActions}>
            <NavLink className={styles.heroPrimary} to="/kursy">Выбрать курс</NavLink>
            <NavLink className={styles.heroSecondary} to="/kontakty">Получить консультацию</NavLink>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            className={styles.heroImage}
            src="https://picsum.photos/1600/900?random=1&family"
            alt="Счастливая семья обнимается на диване"
            loading="lazy"
          />
        </div>
      </div>

      <section className={styles.intro}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>О платформе</span>
          <h2 className={styles.sectionTitle}>Braventy Family Academy</h2>
          <p className={styles.sectionDescription}>
            Мы объединили психологов, коучей и экспертов в семейной динамике, чтобы поддерживать русскоязычные семьи в Европе. Наши курсы сочетают научный подход, практические задания и живое сопровождение.
          </p>
        </div>
        <div className={styles.features}>
          <article className={styles.feature}>
            <h3>Для семейного счастья</h3>
            <p>Программы выстроены вокруг ключевых запросов: гармония в паре, воспитание детей и тёплая семейная культура.</p>
          </article>
          <article className={styles.feature}>
            <h3>Европейский контекст</h3>
            <p>Мы учитываем особенности жизни в разных странах ЕС, культурные различия и правовые нюансы.</p>
          </article>
          <article className={styles.feature}>
            <h3>Онлайн и офлайн</h3>
            <p>Удобный формат обучения дополнен живыми встречами и событиями сообщества выпускников.</p>
          </article>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef}>
        {statsData.map((stat, index) => (
          <div key={stat.label} className={styles.statItem}>
            <span className={styles.statValue}>{visibleStats[index]}</span>
            <p className={styles.statLabel}>{stat.label}</p>
          </div>
        ))}
      </section>

      <section className={styles.programs}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Наши программы</span>
          <h2 className={styles.sectionTitle}>Три направления, меняющие семейную динамику</h2>
          <p className={styles.sectionDescription}>
            Курсы для семей Европы адаптированы под плотный график и дают конкретные шаги к гармонии. Каждый модуль — результат практики семейной психологии онлайн.
          </p>
        </div>
        <div className={styles.programGrid}>
          {programs.map((program) => (
            <CourseCard key={program.title} {...program} />
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Как это работает</span>
          <h2 className={styles.sectionTitle}>Методология обучения</h2>
          <p className={styles.sectionDescription}>
            Каждый этап программы выстроен так, чтобы семья чувствовала поддержку и видела результат.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <article key={step.title} className={styles.processCard}>
              <div className={styles.processNumber}>{index + 1}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.why}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Почему выбирают нас</span>
          <h2 className={styles.sectionTitle}>Преимущества Braventy</h2>
        </div>
        <div className={styles.whyGrid}>
          <article className={styles.whyCard}>
            <h3>Сильные специалисты</h3>
            <p>Команда из практикующих семейных психологов, коучей и медиаторов с международными сертификациями.</p>
          </article>
          <article className={styles.whyCard}>
            <h3>Личная траектория</h3>
            <p>Каждой семье подбираем персональный маршрут, учитывая запрос, семейный состав и географию.</p>
          </article>
          <article className={styles.whyCard}>
            <h3>Поддержка после курса</h3>
            <p>Чаты выпускников, встречи клуба и дополнительные материалы помогают закрепить полученные навыки.</p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Истории семей</span>
          <h2 className={styles.sectionTitle}>Отзывы и кейсы</h2>
        </div>
        <div className={styles.testimonialCard}>
          <blockquote className={styles.testimonialQuote}>
            “{testimonials[currentTestimonial].quote}”
          </blockquote>
          <p className={styles.testimonialFamily}>{testimonials[currentTestimonial].family}</p>
          <div className={styles.testimonialNav}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${index === currentTestimonial ? styles.activeDot : ''}`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Показать отзыв ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Практика</span>
          <h2 className={styles.sectionTitle}>Реальные кейсы обучения</h2>
        </div>
        <div className={styles.filters}>
          <button
            type="button"
            className={`${styles.filterButton} ${projectsFilter === 'all' ? styles.filterActive : ''}`}
            onClick={() => setProjectsFilter('all')}
          >
            Все
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${projectsFilter === 'отношения' ? styles.filterActive : ''}`}
            onClick={() => setProjectsFilter('отношения')}
          >
            Отношения
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${projectsFilter === 'воспитание' ? styles.filterActive : ''}`}
            onClick={() => setProjectsFilter('воспитание')}
          >
            Воспитание
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${projectsFilter === 'коммуникация' ? styles.filterActive : ''}`}
            onClick={() => setProjectsFilter('коммуникация')}
          >
            Коммуникация
          </button>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Вопросы</span>
          <h2 className={styles.sectionTitle}>Часто спрашивают</h2>
        </div>
        <div className={styles.accordion}>
          {faqs.map((item, index) => {
            const [open, setOpen] = React.useState(false);
            return (
              <details key={item.question} className={styles.accordionItem} open={open} onToggle={() => setOpen(!open)}>
                <summary className={styles.accordionSummary}>
                  <span>{item.question}</span>
                  <span className={styles.accordionIcon}>{open ? '−' : '+'}</span>
                </summary>
                <p className={styles.accordionContent}>{item.answer}</p>
              </details>
            );
          })}
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Блог</span>
          <h2 className={styles.sectionTitle}>Последние материалы</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImageWrapper}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <NavLink to={post.link} className={styles.blogLink}>Читать далее</NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Присоединиться к курсу</h2>
          <p>
            Готовы сделать следующий шаг? Выберите программу, которая откликается вашей семье, и мы поможем воплотить изменения.
          </p>
          <NavLink to="/kontakty" className={styles.ctaButton}>Записаться</NavLink>
        </div>
        <div className={styles.ctaImageWrapper}>
          <img
            src="https://picsum.photos/800/600?random=2&family"
            alt="Совместная работа с психологом"
            loading="lazy"
          />
        </div>
      </section>

      <div className={styles.contactSection}>
        <ContactForm />
      </div>
    </>
  );
};

export default Home;