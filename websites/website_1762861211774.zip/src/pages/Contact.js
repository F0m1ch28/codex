import React from 'react';
import { Helmet } from 'react-helmet';
import ContactForm from '../components/ContactForm';
import styles from './Contact.module.css';

const Contact = () => (
  <>
    <Helmet>
      <title>Контакты Braventy Family Academy</title>
      <meta name="description" content="Свяжитесь с Braventy Family Academy: адрес в Берлине, телефон и форма записи на консультацию." />
      <meta name="keywords" content="курсы для семей Европа, семейная психология онлайн, контакт" />
    </Helmet>
    <section className={styles.hero}>
      <h1>Контакты</h1>
      <p>Мы будем рады обсудить вашу ситуацию и подобрать курс или индивидуальное сопровождение.</p>
    </section>
    <section className={styles.wrap}>
      <div className={styles.info}>
        <h2>Как нас найти</h2>
        <ul>
          <li><strong>Адрес:</strong> Kurfürstendamm 156, 10709 Berlin, Germany</li>
          <li><strong>Телефон:</strong> <a href="tel:+493056789012">+49 30 5678 9012</a></li>
          <li><strong>Онлайн-запись:</strong> заполните форму, и координатор свяжется с вами.</li>
        </ul>
        <div className={styles.mapWrapper} aria-label="Карта расположения офиса в Берлине">
          <iframe
            title="Карта Braventy Family Academy"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.649054506072!2d13.308689176272336!3d52.49774333892139!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851718c0538ab%3A0x8d257a7b82d49f683!2sKurfürstendamm%20156%2C%2010709%20Berlin%2C%20Germany!5e0!3m2!1sru!2sde!4v1709999999999!5m2!1sru!2sde"
            width="100%"
            height="260"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
      <div className={styles.formWrapper}>
        <ContactForm />
      </div>
    </section>
  </>
);

export default Contact;