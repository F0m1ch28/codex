import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Program.module.css';

const modules = [
  {
    title: 'Модуль 1. Диагностика и цели',
    description: 'Совместно формулируем запрос, определяем точки роста и создаём карту целей семьи.',
  },
  {
    title: 'Модуль 2. Эмоциональная грамотность',
    description: 'Осваиваем язык эмоций, учимся говорить о потребностях и строим ритуалы поддержки.',
  },
  {
    title: 'Модуль 3. Коммуникация и границы',
    description: 'Развиваем активное слушание, договариваемся о правилах и учимся решать конфликты элегантно.',
  },
  {
    title: 'Модуль 4. Детско-родительские отношения',
    description: 'Внедряем позитивную дисциплину, обсуждаем возрастные особенности и семейные договорённости.',
  },
  {
    title: 'Модуль 5. Совместное планирование',
    description: 'Проектируем семейные цели, распределяем ответственность и создаём план поддержки друг друга.',
  },
  {
    title: 'Модуль 6. Закрепление и сопровождение',
    description: 'Подготавливаем индивидуальный маршрут и остаёмся на связи в клубе выпускников.',
  },
];

const Program = () => (
  <>
    <Helmet>
      <title>Программа обучения — модули Braventy Family Academy</title>
      <meta name="description" content="Подробная структура программы Braventy Family Academy: модули, продолжительность и формат сопровождения." />
      <meta name="keywords" content="семейная психология онлайн, программа обучения, курсы для семей Европа" />
    </Helmet>
    <section className={styles.hero}>
      <h1>Программа</h1>
      <p>
        Каждая программа состоит из модулей, которые последовательно выстраивают новые навыки. Вы получаете материалы, практику и поддержку кураторов.
      </p>
    </section>
    <section className={styles.modules}>
      {modules.map((module) => (
        <article key={module.title} className={styles.module}>
          <h2>{module.title}</h2>
          <p>{module.description}</p>
        </article>
      ))}
    </section>
    <section className={styles.format}>
      <div>
        <h2>Формат</h2>
        <ul>
          <li>Видео-уроки в удобном формате и адаптивном расписании.</li>
          <li>Живые вебинары с практикующими психологами и коучами.</li>
          <li>Обратная связь по домашним заданиям и чек-листы.</li>
          <li>Супервизии и дополнительные встречи клуба выпускников.</li>
        </ul>
      </div>
      <div className={styles.imageWrapper}>
        <img src="https://picsum.photos/800/600?random=12&family" alt="Онлайн обучение семейной психологии" loading="lazy" />
      </div>
    </section>
  </>
);

export default Program;