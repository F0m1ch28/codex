document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navList = document.querySelector(".nav-list");

    if (navToggle && navList) {
        navToggle.addEventListener("click", () => {
            const isOpen = navList.classList.toggle("is-open");
            navToggle.classList.toggle("is-active", isOpen);
            navToggle.setAttribute("aria-expanded", isOpen);
        });

        navList.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (navList.classList.contains("is-open")) {
                    navList.classList.remove("is-open");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const consentStorageKey = "dogtagyxrjCookieConsent";
    const cookieBanner = document.querySelector(".cookie-banner");

    if (cookieBanner) {
        let storedConsent = null;
        try {
            storedConsent = localStorage.getItem(consentStorageKey);
        } catch (error) {
            storedConsent = null;
        }

        if (!storedConsent) {
            cookieBanner.classList.add("is-visible");
        }

        const handleConsent = (value) => {
            try {
                localStorage.setItem(consentStorageKey, value);
            } catch (error) {
                // Storage might be unavailable; ignore silently
            }
            cookieBanner.classList.remove("is-visible");
        };

        const acceptButton = cookieBanner.querySelector("[data-cookie-accept]");
        const declineButton = cookieBanner.querySelector("[data-cookie-decline]");

        if (acceptButton) {
            acceptButton.addEventListener("click", () => handleConsent("accepted"));
        }

        if (declineButton) {
            declineButton.addEventListener("click", () => handleConsent("declined"));
        }
    }
});