document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.primary-nav');
    const scrollButton = document.querySelector('.scroll-to-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButton = document.querySelector('#acceptCookies');
    const cookieKey = 'familyixfeCookieConsent';

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });

        const navLinks = navMenu.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, left: 0 });
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 768) {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (scrollButton) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollButton.classList.add('visible');
            } else {
                scrollButton.classList.remove('visible');
            }
        });

        scrollButton.addEventListener('click', (event) => {
            event.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieButton) {
        const consent = localStorage.getItem(cookieKey);
        if (consent === 'accepted') {
            cookieBanner.classList.add('hidden');
        }

        cookieButton.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    const currentYear = document.querySelector('#currentYear');
    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }
});