document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            const isOpen = navLinks.classList.toggle('nav-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navLinks.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('#cookie-accept');
    const declineBtn = document.querySelector('#cookie-decline');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('genusCookieChoice');
        if (storedPreference) {
            cookieBanner.classList.add('hidden');
        }
        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                localStorage.setItem('genusCookieChoice', 'accepted');
                cookieBanner.classList.add('hidden');
            });
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                localStorage.setItem('genusCookieChoice', 'declined');
                cookieBanner.classList.add('hidden');
            });
        }
    }
});