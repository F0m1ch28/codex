import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>Chi Siamo | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Scopri la storia, la missione e la metodologia dell’Accademia Europea di Comunicazione Digitale. Innoviamo il branding online a Milano."
      />
      <meta name="keywords" content="chi siamo accademia digitale, comunicazione digitale Milano" />
      <link rel="canonical" href="https://www.aecdigital.it/chi-siamo" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Chi Siamo</h1>
        <p>
          Alimentiamo la cultura digitale in Europa con un hub formativo incentrato su branding, strategia e innovazione tecnologica.
        </p>
      </div>
    </section>

    <section className={`${styles.history} container`} aria-labelledby="history-title">
      <h2 id="history-title">La Nostra Storia</h2>
      <p>
        L’Accademia Europea di Comunicazione Digitale nasce a Milano dall’incontro tra professionisti del marketing,
        storyteller e developer. Cresciuta negli anni attraverso collaborazioni con agenzie e imprese italiane,
        l’accademia è oggi un punto di riferimento per chi desidera unire visione strategica e competenze tecniche
        nel panorama digitale europeo.
      </p>
      <div className={styles.milestones}>
        <article>
          <h3>Fondazione</h3>
          <p>Avvio dei primi laboratori in presenza con focus su content strategy e brand identity.</p>
        </article>
        <article>
          <h3>Espansione</h3>
          <p>Introduzione di moduli dedicati a marketing automation, coding e misurazione dati.</p>
        </article>
        <article>
          <h3>Community</h3>
          <p>Costruzione di una rete di alumni, mentor aziendali e partnership con realtà internazionali.</p>
        </article>
      </div>
    </section>

    <section className={styles.mission} aria-labelledby="mission-title">
      <div className="container">
        <h2 id="mission-title">Missione e Valori</h2>
        <div className={styles.missionGrid}>
          <article>
            <h3>Approccio Umano</h3>
            <p>Promuoviamo percorsi personalizzati, ascolto attivo e collaborazione costante tra studenti e docenti.</p>
          </article>
          <article>
            <h3>Innovazione Costante</h3>
            <p>Aggiorniamo i contenuti didattici con trend e strumenti emergenti per restare un passo avanti.</p>
          </article>
          <article>
            <h3>Impatto Misurabile</h3>
            <p>Ogni progetto include metriche precise per valutare risultati, migliorare e dare prova di valore.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={`${styles.method} container`} aria-labelledby="method-title">
      <h2 id="method-title">Metodo e Didattica</h2>
      <div className={styles.methodGrid}>
        <article>
          <h3>Laboratori immersivi</h3>
          <p>Lezioni interattive con esercitazioni pratiche, simulazioni e lavori di gruppo su casi reali.</p>
        </article>
        <article>
          <h3>Mentorship personalizzata</h3>
          <p>Ogni partecipante è affiancato da un mentor che segue progressi, obiettivi e portfolio.</p>
        </article>
        <article>
          <h3>Knowledge sharing</h3>
          <p>Spazi digitali e incontri periodici per condividere best practice e sperimentazioni con la community.</p>
        </article>
      </div>
    </section>

    <section className={styles.imageSection}>
      <img src="https://picsum.photos/1200/700?random=12" alt="Workshop di comunicazione digitale in accademia" loading="lazy" />
    </section>
  </>
);

export default About;