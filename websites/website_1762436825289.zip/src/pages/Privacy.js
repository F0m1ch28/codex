import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Informativa privacy GDPR dell’Accademia Europea di Comunicazione Digitale."
      />
      <link rel="canonical" href="https://www.aecdigital.it/privacy" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Informativa Privacy</h1>
      </div>
    </section>

    <section className={`${styles.content} container`} aria-labelledby="privacy-title">
      <h2 id="privacy-title">Titolare del trattamento</h2>
      <p>
        Il titolare del trattamento dei dati personali è l’Accademia Europea di Comunicazione Digitale con sede in Via Milano, 22, 20121 Milano MI.
      </p>

      <h3>Dati trattati</h3>
      <p>
        Raccogliamo dati identificativi e di contatto forniti tramite moduli informativi, nonché dati di navigazione necessari per garantire
        il corretto funzionamento del sito.
      </p>

      <h3>Finalità</h3>
      <p>
        I dati sono utilizzati per rispondere alle richieste degli utenti, inviare comunicazioni relative ai servizi formativi
        e analizzare l’utilizzo del sito per migliorare l’esperienza di navigazione.
      </p>

      <h3>Diritti dell’interessato</h3>
      <p>
        In qualsiasi momento è possibile esercitare i diritti previsti dal GDPR contattando il titolare all’indirizzo Email: [будет добавлен позже].
      </p>
    </section>
  </>
);

export default Privacy;