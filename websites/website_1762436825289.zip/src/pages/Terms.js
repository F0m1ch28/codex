import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Termini di Utilizzo | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Leggi i termini di utilizzo del sito Accademia Europea di Comunicazione Digitale."
      />
      <link rel="canonical" href="https://www.aecdigital.it/termini" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Termini di Utilizzo</h1>
      </div>
    </section>

    <section className={`${styles.content} container`} aria-labelledby="terms-title">
      <h2 id="terms-title">Condizioni generali</h2>
      <p>
        L’accesso e l’utilizzo del sito dell’Accademia Europea di Comunicazione Digitale implicano l’accettazione integrale delle presenti condizioni.
        Il contenuto del sito è fornito al fine di presentare i percorsi formativi e le attività dell’accademia.
      </p>

      <h3>Uso corretto del sito</h3>
      <p>
        Gli utenti si impegnano a utilizzare il sito nel rispetto delle normative vigenti, evitando comportamenti che possano compromettere
        la sicurezza o l’accessibilità dei servizi digitali forniti.
      </p>

      <h3>Proprietà intellettuale</h3>
      <p>
        Testi, immagini e materiali multimediali presenti sul sito sono di proprietà dell’accademia o utilizzati con licenze appropriate.
        Ogni riproduzione o distribuzione deve essere autorizzata.
      </p>

      <h3>Aggiornamenti</h3>
      <p>
        L’accademia si riserva di modificare in qualsiasi momento le presenti condizioni, pubblicando la versione aggiornata sul sito.
      </p>
    </section>
  </>
);

export default Terms;