import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Informativa sull’utilizzo dei cookie per il sito dell’Accademia Europea di Comunicazione Digitale."
      />
      <link rel="canonical" href="https://www.aecdigital.it/cookie-policy" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Cookie Policy</h1>
      </div>
    </section>

    <section className={`${styles.content} container`} aria-labelledby="cookie-title">
      <h2 id="cookie-title">Tipologie di cookie</h2>
      <p>
        Il sito utilizza cookie tecnici necessari al funzionamento, cookie di preferenza per memorizzare impostazioni e cookie analitici
        anonimizzati per monitorare il traffico.
      </p>

      <h3>Gestione dei cookie</h3>
      <p>
        È possibile gestire le preferenze sui cookie tramite il banner dedicato o attraverso le impostazioni del browser.
      </p>

      <h3>Durata</h3>
      <p>
        La durata dei cookie varia da sessioni temporanee a periodi più lunghi, comunque conformi alla normativa vigente.
      </p>

      <h3>Contatti</h3>
      <p>
        Per ulteriori informazioni scrivere a Email: [будет добавлен позже].
      </p>
    </section>
  </>
);

export default CookiePolicy;