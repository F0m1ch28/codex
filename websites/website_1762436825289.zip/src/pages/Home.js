import React from 'react';
import { Helmet } from 'react-helmet';
import { NavLink } from 'react-router-dom';
import { FiArrowRight, FiCheckCircle } from 'react-icons/fi';
import styles from './Home.module.css';

const Home = () => {
  const stats = [
    { label: 'Partecipanti soddisfatti', value: 320 },
    { label: 'Ore di formazione', value: 480 },
    { label: 'Mentor attivi', value: 24 },
    { label: 'Progetti consegnati', value: 98 },
  ];

  const [animatedValues, setAnimatedValues] = React.useState(stats.map(() => 0));

  React.useEffect(() => {
    const intervals = stats.map((stat, index) => {
      const increment = Math.ceil(stat.value / 80);
      return setInterval(() => {
        setAnimatedValues((prev) => {
          const next = [...prev];
          if (next[index] < stat.value) {
            next[index] = Math.min(next[index] + increment, stat.value);
          }
          return next;
        });
      }, 30);
    });
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  const courses = [
    {
      title: 'Pubblicità Targetizzata',
      description: 'Strategie avanzate su Facebook e Google Ads per generare campagne performanti e tracciabili.',
      features: ['Analisi audience', 'Monitoraggio KPI', 'Creatività data-driven'],
      icon: '🎯',
    },
    {
      title: 'Coding',
      description: 'Dallo sviluppo front-end all’automazione in Python con progetti concreti in linguaggi moderni.',
      features: ['HTML, CSS, JavaScript', 'Introduzione a React', 'Script Python'],
      icon: '💻',
    },
    {
      title: 'Social Media Marketing',
      description: 'Storytelling, community management e performance su Instagram e TikTok.',
      features: ['Content calendar', 'Partnership strategiche', 'Analisi insight'],
      icon: '📱',
    },
  ];

  const steps = [
    { step: '01', title: 'Orientamento personalizzato', text: 'Definiamo obiettivi di crescita digitale insieme al team di tutor.' },
    { step: '02', title: 'Laboratori immersivi', text: 'Lezioni live, workshop pratici e casi studio su progetti reali.' },
    { step: '03', title: 'Mentorship continua', text: 'Check-in con i docenti, feedback puntuali e revisione dei deliverable.' },
    { step: '04', title: 'Portfolio certificato', text: 'Valorizziamo i risultati con attestati e presentazioni professionali.' },
  ];

  const testimonials = [
    {
      quote: 'Il percorso di branding digitale ha trasformato la nostra presenza online. Metodologia, dati e creatività si incontrano davvero.',
      name: 'Giulia Romano',
      role: 'Digital Strategist, Torino',
    },
    {
      quote: 'La forza di questa accademia è il supporto costante. I mentor mi hanno guidato nella realizzazione del mio primo progetto cross-channel.',
      name: 'Alessandro Conti',
      role: 'Content Designer, Milano',
    },
    {
      quote: 'Coding e marketing finalmente dialogano: ho imparato a leggere i dati e a migliorare ogni campagna in autonomia.',
      name: 'Sara Leoni',
      role: 'Marketing Technologist, Bologna',
    },
  ];
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const projects = [
    { id: 1, title: 'Lancio Brand Moda', category: 'Branding', image: 'https://picsum.photos/1200/800?random=4', description: 'Posizionamento omnicanale per un marchio fashion emergente.' },
    { id: 2, title: 'Dashboard Analytics', category: 'Data', image: 'https://picsum.photos/1200/800?random=5', description: 'Raccolta e visualizzazione di metriche marketing in tempo reale.' },
    { id: 3, title: 'Campagna TikTok', category: 'Social', image: 'https://picsum.photos/1200/800?random=6', description: 'Serie di contenuti verticali per ingaggiare community under 25.' },
    { id: 4, title: 'Automation Funnel', category: 'Coding', image: 'https://picsum.photos/1200/800?random=7', description: 'Script Python per automatizzare report settimanali del team marketing.' },
  ];
  const [activeFilter, setActiveFilter] = React.useState('Tutti');

  const filteredProjects = activeFilter === 'Tutti'
    ? projects
    : projects.filter((project) => project.category === activeFilter);

  const faqs = [
    {
      question: 'Qual è l’approccio didattico dell’accademia?',
      answer: 'Combiniamo teoria, pratica e confronto continuo con docenti senior, integrando project work multidisciplinari e sessioni di mentorship individuali.',
    },
    {
      question: 'Sono previsti progetti reali durante il corso?',
      answer: 'Sì, ogni modulo prevede consegne ispirate a scenari reali con feedback puntuali. I progetti entrano nel tuo portfolio professionale.',
    },
    {
      question: 'Che tipo di supporto riceverò dopo le lezioni?',
      answer: 'L’accesso alla community online resta attivo per condividere risorse, opportunità professionali e aggiornamenti sulle best practice digitali.',
    },
  ];
  const [openFaq, setOpenFaq] = React.useState(0);

  const blogPosts = [
    {
      title: 'Strategie di Content Design per il 2024',
      excerpt: 'Storyframe, analisi dei micro-momenti e sperimentazione con formati brevi: ecco come costruire narrazioni efficaci.',
      date: '12 Marzo 2024',
      image: 'https://picsum.photos/800/600?random=8',
    },
    {
      title: 'UX Writing e Branding Consistente',
      excerpt: 'Dalla scelta del tono di voce alla microcopy: allineare i contenuti alle aspettative dell’utente.',
      date: '28 Febbraio 2024',
      image: 'https://picsum.photos/800/600?random=9',
    },
    {
      title: 'Advertising Data-Driven su Meta',
      excerpt: 'Segmentazione avanzata, test A/B e monitoraggio delle conversioni per campagne sempre più pertinenti.',
      date: '14 Febbraio 2024',
      image: 'https://picsum.photos/800/600?random=10',
    },
  ];

  return (
    <>
      <Helmet>
        <title>AE Comunicazione Digitale | Corso Avanzato di Branding Online</title>
        <meta
          name="description"
          content="Scopri l’Accademia Europea di Comunicazione Digitale: corsi avanzati di branding online, content strategy, coding e social media marketing a Milano."
        />
        <meta
          name="keywords"
          content="corsi online Italia, pubblicità targetizzata, corso coding Milano, social media marketing, content strategy"
        />
        <link rel="canonical" href="https://www.aecdigital.it/" />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay} aria-hidden="true" />
        <img
          src="https://picsum.photos/1600/900?random=1"
          alt="Studenti in aula digitale con computer portatili"
          className={styles.heroImage}
        />
        <div className={`${styles.heroContent} container`}>
          <p className={styles.pretitle}>Accademia Europea di Comunicazione Digitale</p>
          <h1>Trasforma la Tua Carriera Digitale</h1>
          <p className={styles.subtitle}>
            Costruisci strategie di branding e contenuti supportate da dati reali, tecnologia e storytelling contemporaneo.
          </p>
          <div className={styles.heroActions}>
            <NavLink to="/contatti" className={styles.primaryCta}>
              Prenota un orientamento
            </NavLink>
            <NavLink to="/corsi" className={styles.secondaryCta}>
              Esplora i corsi
            </NavLink>
          </div>
        </div>
      </section>

      <section className={`${styles.intro} container`} aria-labelledby="intro-title">
        <div>
          <h2 id="intro-title">Visione Europea, Cuore Italiano</h2>
          <p>
            L’Accademia Europea di Comunicazione Digitale unisce analisi, creatività e tecnologia per formare professionisti in grado di guidare brand e organizzazioni nell’ecosistema digitale.
          </p>
        </div>
        <div className={styles.introGrid}>
          <article>
            <h3>Missione</h3>
            <p>
              Elevare la cultura digitale in Italia attraverso un percorso pratico che collega branding, advertising, coding e social media con progetti reali.
            </p>
          </article>
          <article>
            <h3>Metodo</h3>
            <p>
              Lezioni immersive, mentorship, laboratori e un ecosistema di strumenti professionali per consolidare competenze orientate all’impatto.
            </p>
          </article>
          <article>
            <h3>Community</h3>
            <p>
              Una rete di alumni, aziende partner e docenti senior che co-creano opportunità e condividono visioni di crescita sostenibile.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.stats} aria-label="Risultati dell’accademia">
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{animatedValues[index]}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.courses} container`} aria-labelledby="corsi-title">
        <div className={styles.sectionHeader}>
          <h2 id="corsi-title">I Nostri Corsi</h2>
          <p>Percorsi specialistici per padroneggiare comunicazione digitale, coding e campagne data-driven.</p>
        </div>
        <div className={styles.courseGrid}>
          {courses.map((course) => (
            <article key={course.title} className={styles.courseCard}>
              <div className={styles.courseIcon} aria-hidden="true">{course.icon}</div>
              <h3>{course.title}</h3>
              <p>{course.description}</p>
              <ul>
                {course.features.map((feature) => (
                  <li key={feature}><FiCheckCircle aria-hidden="true" /> {feature}</li>
                ))}
              </ul>
              <NavLink to="/corsi" className={styles.learnMore}>
                Scopri di più <FiArrowRight aria-hidden="true" />
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="process-title">Come Funziona</h2>
            <p>Un percorso strutturato in quattro fasi, pensato per accompagnarti dal primo giorno all’ottenimento della certificazione finale.</p>
          </div>
          <div className={styles.processTimeline}>
            {steps.map((step) => (
              <div key={step.title} className={styles.processStep}>
                <span className={styles.stepNumber}>{step.step}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.why} container`} aria-labelledby="perche-title">
        <div className={styles.sectionHeader}>
          <h2 id="perche-title">Perché Sceglierci</h2>
          <p>Integriamo competenze trasversali e strumenti professionali per dare concretezza alla tua evoluzione.</p>
        </div>
        <div className={styles.whyGrid}>
          <article>
            <h3>Docenti senior</h3>
            <p>Professionisti attivi nel settore con esperienza in corporate, agenzie e startup europee.</p>
          </article>
          <article>
            <h3>Laboratori ibridi</h3>
            <p>Lezioni live, on demand e workshop in presenza a Milano con infrastrutture d’avanguardia.</p>
          </article>
          <article>
            <h3>Portfolio e certificazioni</h3>
            <p>Ogni modulo termina con progetti e attestazioni riconosciute dalle aziende partner.</p>
          </article>
          <article>
            <h3>Community dinamica</h3>
            <p>Accesso a eventi esclusivi, mentorship e aggiornamenti continui sulle tendenze digitali.</p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="testimonials-title">Testimonianze</h2>
            <p>Le esperienze dei nostri partecipanti raccontano il valore del percorso formativo.</p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`${styles.testimonialCard} ${index === testimonialIndex ? styles.active : ''}`}
                aria-hidden={index !== testimonialIndex}
              >
                <p className={styles.quote}>“{testimonial.quote}”</p>
                <p className={styles.name}>{testimonial.name}</p>
                <p className={styles.role}>{testimonial.role}</p>
              </div>
            ))}
            <div className={styles.carouselControls} role="tablist" aria-label="Seleziona testimonianza">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  aria-label={`Mostra testimonianza ${index + 1}`}
                  className={`${styles.dot} ${index === testimonialIndex ? styles.dotActive : ''}`}
                  onClick={() => setTestimonialIndex(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.projects} container`} aria-labelledby="projects-title">
        <div className={styles.sectionHeader}>
          <h2 id="projects-title">Progetti in Evidenza</h2>
          <p>Dai uno sguardo ad alcuni lavori realizzati durante i project work dell’accademia.</p>
        </div>
        <div className={styles.filterControls} role="tablist" aria-label="Filtra progetti">
          {['Tutti', 'Branding', 'Data', 'Social', 'Coding'].map((filter) => (
            <button
              key={filter}
              type="button"
              role="tab"
              aria-selected={activeFilter === filter}
              className={activeFilter === filter ? styles.filterActive : ''}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <img src={project.image} alt={`Esempio di ${project.title}`} loading="lazy" />
              <div className={styles.projectContent}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.teamPreview} container`} aria-labelledby="team-title">
        <div className={styles.sectionHeader}>
          <h2 id="team-title">Mentor e Facilitatori</h2>
          <p>Un team multidisciplinare sempre al tuo fianco.</p>
        </div>
        <div className={styles.teamGrid}>
          {[1, 2, 3].map((id) => (
            <article key={id} className={styles.teamCard}>
              <img src={`https://picsum.photos/400/400?random=${id + 10}`} alt="Docente dell’accademia" loading="lazy" />
              <div>
                <h3>Mentor dedicato</h3>
                <p>Esperto di branding, content e performance marketing con focus sull’innovazione digitale.</p>
              </div>
            </article>
          ))}
        </div>
        <NavLink to="/docenti" className={styles.learnMore}>
          Conosci l’intero team <FiArrowRight aria-hidden="true" />
        </NavLink>
      </section>

      <section className={`${styles.faq} container`} aria-labelledby="faq-title">
        <div className={styles.sectionHeader}>
          <h2 id="faq-title">Domande Frequenti</h2>
          <p>Trova rapidamente le risposte prima di parlare con il nostro team.</p>
        </div>
        <div className={styles.faqList}>
          {faqs.map((faq, index) => (
            <div key={faq.question} className={styles.faqItem}>
              <button
                type="button"
                onClick={() => setOpenFaq(index === openFaq ? null : index)}
                aria-expanded={openFaq === index}
              >
                <span>{faq.question}</span>
                <span className={styles.toggle}>{openFaq === index ? '−' : '+'}</span>
              </button>
              {openFaq === index && <p>{faq.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog-title">Approfondimenti dal Blog</h2>
            <p>Insight, metodologie e casi studio curati dalla faculty dell’accademia.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={`Copertina articolo: ${post.title}`} loading="lazy" />
                <div className={styles.blogContent}>
                  <span>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href="/#" aria-label={`Leggi l'articolo ${post.title}`}>
                    Continua a leggere <FiArrowRight aria-hidden="true" />
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={`${styles.ctaContent} container`}>
          <h2>Pronto a dare voce al tuo brand digitale?</h2>
          <p>Richiedi un colloquio con il nostro team di orientamento e scopri come integrare strategia, tecnologia e creatività nel tuo lavoro quotidiano.</p>
          <NavLink to="/contatti" className={styles.primaryCta}>
            Inizia Oggi
          </NavLink>
        </div>
      </section>
    </>
  );
};

export default Home;