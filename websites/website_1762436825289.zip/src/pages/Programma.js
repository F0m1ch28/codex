import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programma.module.css';

const Programma = () => (
  <>
    <Helmet>
      <title>Programma | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Scopri la struttura dei moduli, la durata dei corsi, i progetti pratici e le certificazioni dell’Accademia Europea di Comunicazione Digitale."
      />
      <meta name="keywords" content="programma corso digitale, moduli comunicazione digitale, certificazioni branding online" />
      <link rel="canonical" href="https://www.aecdigital.it/programma" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Programma Didattico</h1>
        <p>Un percorso modulare pensato per consolidare competenze in modo progressivo e coinvolgente.</p>
      </div>
    </section>

    <section className={`${styles.modules} container`} aria-labelledby="modules-title">
      <h2 id="modules-title">Struttura dei Moduli</h2>
      <div className={styles.moduleGrid}>
        <article>
          <h3>Modulo 1 · Fondamenti di Branding Digitale</h3>
          <p>Definizione del posizionamento, analisi competitor e costruzione della brand voice cross-channel.</p>
        </article>
        <article>
          <h3>Modulo 2 · Content Strategy e UX Copy</h3>
          <p>Pianificazione editoriale, microcopy, design system e accessibilità dei contenuti.</p>
        </article>
        <article>
          <h3>Modulo 3 · Advertising Data-Driven</h3>
          <p>Targeting, creatività dinamiche, ottimizzazione budget e lettura delle metriche.</p>
        </article>
        <article>
          <h3>Modulo 4 · Coding e Automazione</h3>
          <p>Componenti reattivi, integrazione API, script Python per workflow di marketing.</p>
        </article>
        <article>
          <h3>Modulo 5 · Social Media e Community</h3>
          <p>Format verticali, collaborazione con creator e gestione di community attive.</p>
        </article>
        <article>
          <h3>Modulo 6 · Progetto Finale</h3>
          <p>Team multidisciplinari, consegna di un progetto completo e presentazione davanti alla commissione.</p>
        </article>
      </div>
    </section>

    <section className={styles.details} aria-labelledby="details-title">
      <div className="container">
        <h2 id="details-title">Durata, Progetti e Certificazioni</h2>
        <div className={styles.detailsGrid}>
          <article>
            <h3>Durata del percorso</h3>
            <p>Il corso avanzato si sviluppa su dodici settimane con incontri live, sessioni on demand e workshop intensivi a Milano.</p>
          </article>
          <article>
            <h3>Project Work</h3>
            <p>Ogni modulo termina con un project work guidato dai docenti: deliverable concreti per arricchire il portfolio.</p>
          </article>
          <article>
            <h3>Certificazioni</h3>
            <p>Al completamento del percorso ricevi attestati digitali e badge condivisibili sui profili professionali.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.timeline}>
      <div className="container">
        <h2>Percorso Settimana per Settimana</h2>
        <ul>
          <li><span>Settimana 1-2</span> Analisi brand, definizione target e basi di content design.</li>
          <li><span>Settimana 3-4</span> Pianificazione cross-canale, UX copy e storytelling visivo.</li>
          <li><span>Settimana 5-6</span> Advertising su Meta e Google, misurazione performance.</li>
          <li><span>Settimana 7-8</span> Fondamenti di coding, creazione di componenti e automazioni.</li>
          <li><span>Settimana 9-10</span> Strategie social, community management e live content.</li>
          <li><span>Settimana 11-12</span> Mentorship intensiva, revisione portfolio e pitch finale.</li>
        </ul>
      </div>
    </section>
  </>
);

export default Programma;