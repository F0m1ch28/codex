import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    role: '',
    message: '',
  });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Inserisci il tuo nome.';
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) newErrors.email = 'Inserisci un indirizzo email valido.';
    if (!formData.role.trim()) newErrors.role = 'Indica il tuo ruolo professionale.';
    if (formData.message.trim().length < 20) newErrors.message = 'Il messaggio deve contenere almeno 20 caratteri.';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
  };

  return (
    <>
      <Helmet>
        <title>Contatti | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Contatta l’Accademia Europea di Comunicazione Digitale a Milano. Richiedi informazioni sui corsi di branding e content strategy."
        />
        <meta
          name="keywords"
          content="contatti accademia digitale Milano, orientamento comunicazione digitale, branding online Italia"
        />
        <link rel="canonical" href="https://www.aecdigital.it/contatti" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Contattaci</h1>
          <p>Scrivici per ricevere informazioni sul percorso formativo e sulle prossime sessioni.</p>
        </div>
      </section>

      <section className={`${styles.contactSection} container`} aria-labelledby="contact-title">
        <div className={styles.info}>
          <h2 id="contact-title">Sede di Milano</h2>
          <p>Via Milano, 22, 20121 Milano MI</p>
          <p>Telefono: +39 02 9456 8113</p>
          <p>Email: [будет добавлен позже]</p>
          <p>Italia</p>
          <div className={styles.mapWrapper}>
            <iframe
              title="Mappa Accademia Europea di Comunicazione Digitale"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2796.7100869300303!2d9.189982015636063!3d45.46924957910067!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4786c6a55f692e9b%3A0xb7d03246d8f5b5d2!2sVia%20Milano%2C%2022%2C%2020121%20Milano%20MI!5e0!3m2!1sit!2sit!4v1709735400000"
              allowFullScreen
              loading="lazy"
            ></iframe>
          </div>
        </div>

        <div className={styles.formWrapper}>
          <h2>Richiedi informazioni</h2>
          {submitted ? (
            <div className={styles.success} role="status">
              Grazie! Ti contatteremo al più presto con tutte le informazioni richieste.
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Nome e cognome</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Il tuo nome"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={!!errors.name}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="nome@azienda.it"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="role">Ruolo professionale</label>
                <input
                  type="text"
                  id="role"
                  name="role"
                  placeholder="Esempio: Digital Strategist"
                  value={formData.role}
                  onChange={handleChange}
                  aria-invalid={!!errors.role}
                />
                {errors.role && <span className={styles.error}>{errors.role}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Messaggio</label>
                <textarea
                  id="message"
                  name="message"
                  placeholder="Raccontaci i tuoi obiettivi e domande."
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={!!errors.message}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submit}>
                Invia richiesta
              </button>
            </form>
          )}
        </div>
      </section>
    </>
  );
};

export default Contact;