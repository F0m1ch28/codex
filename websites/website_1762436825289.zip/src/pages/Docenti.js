import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Docenti.module.css';

const faculty = [
  {
    name: 'Elena Bianchi',
    role: 'Head of Branding',
    bio: 'Specialista in brand strategy e transizioni omnicanale per PMI e multinazionali europee.',
    image: 'https://picsum.photos/400/400?random=15',
  },
  {
    name: 'Marco Greco',
    role: 'Lead Data Strategist',
    bio: 'Esperto di advertising data-driven, dashboard personalizzate e growth marketing.',
    image: 'https://picsum.photos/400/400?random=16',
  },
  {
    name: 'Francesca De Luca',
    role: 'Senior Content Designer',
    bio: 'Si occupa di content design, UX writing e format digitali per brand internazionali.',
    image: 'https://picsum.photos/400/400?random=17',
  },
  {
    name: 'Giuseppe Ferri',
    role: 'Coding Mentor',
    bio: 'Developer con esperienza in React, Python e automazione di workflow per il marketing.',
    image: 'https://picsum.photos/400/400?random=18',
  },
];

const Docenti = () => (
  <>
    <Helmet>
      <title>Docenti | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Conosci i docenti dell’Accademia Europea di Comunicazione Digitale: professionisti senior con esperienza internazionale."
      />
      <meta name="keywords" content="docenti comunicazione digitale, mentor branding Milano, esperti digitali" />
      <link rel="canonical" href="https://www.aecdigital.it/docenti" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Docenti e Mentor</h1>
        <p>Professionisti in prima linea nel digitale, pronti a condividere metodi e strumenti operativi.</p>
      </div>
    </section>

    <section className={`${styles.faculty} container`} aria-labelledby="faculty-title">
      <h2 id="faculty-title">La Nostra Faculty</h2>
      <div className={styles.facultyGrid}>
        {faculty.map((member) => (
          <article key={member.name} className={styles.facultyCard}>
            <img src={member.image} alt={`Ritratto di ${member.name}`} loading="lazy" />
            <div>
              <h3>{member.name}</h3>
              <p className={styles.role}>{member.role}</p>
              <p>{member.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Docenti;