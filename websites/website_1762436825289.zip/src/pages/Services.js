import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Corsi | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Dettaglio dei corsi AE Comunicazione Digitale: Pubblicità Targetizzata, Coding e Social Media Marketing con moduli avanzati."
      />
      <meta
        name="keywords"
        content="corsi comunicazione digitale, pubblicità online Milano, coding per marketer, social media marketing Italia"
      />
      <link rel="canonical" href="https://www.aecdigital.it/corsi" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Corsi e Specializzazioni</h1>
        <p>Percorsi intensivi pensati per unire strategia, creatività e competenze tecniche.</p>
      </div>
    </section>

    <section className={`${styles.courseSection} container`} aria-labelledby="pubblicita-title">
      <div className={styles.courseCard}>
        <div>
          <h2 id="pubblicita-title">Pubblicità Targetizzata</h2>
          <p>
            Dalla pianificazione all’ottimizzazione: impari a costruire campagne su Facebook Ads e Google Ads,
            interpretare i segnali dell’audience e migliorare le performance grazie a dashboard personalizzate.
          </p>
          <ul>
            <li>Strutturazione di campagne full funnel</li>
            <li>Configurazione e lettura dei pixel di tracciamento</li>
            <li>Reporting avanzato e storytelling dei dati</li>
          </ul>
        </div>
        <img src="https://picsum.photos/800/600?random=2" alt="Analisi di campagne pubblicitarie digitali" loading="lazy" />
      </div>

      <div className={styles.courseCard}>
        <div>
          <h2>Coding per la Comunicazione</h2>
          <p>
            Un percorso che integra HTML, CSS, JavaScript e Python per creare landing page performanti, automatizzare flussi
            di lavoro e collaborare con team tecnici con un linguaggio comune.
          </p>
          <ul>
            <li>Fondamenti di sviluppo front-end</li>
            <li>Introduzione a React per componenti interattivi</li>
            <li>Script Python per data cleaning e automazione</li>
          </ul>
        </div>
        <img src="https://picsum.photos/800/600?random=13" alt="Schermo con codice e interfacce digitali" loading="lazy" />
      </div>

      <div className={styles.courseCard}>
        <div>
          <h2>Social Media Marketing</h2>
          <p>
            Pianificazione, produzione e misurazione di contenuti per Instagram e TikTok con focus su crescita organica,
            gestione community e collaborazioni con creator.
          </p>
          <ul>
            <li>Content strategy e calendari editoriali</li>
            <li>Format short-form video e storytelling visivo</li>
            <li>Analisi insight e ottimizzazione continua</li>
          </ul>
        </div>
        <img src="https://picsum.photos/800/600?random=14" alt="Team che progetta contenuti social media" loading="lazy" />
      </div>
    </section>
  </>
);

export default Services;