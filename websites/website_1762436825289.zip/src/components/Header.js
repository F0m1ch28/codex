import React from 'react';
import { NavLink } from 'react-router-dom';
import { FiMenu, FiX } from 'react-icons/fi';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = React.useState(false);

  const toggleMenu = () => setOpen((prev) => !prev);

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 1024) {
        setOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className={styles.header} role="banner">
      <div className={`${styles.container} container`}>
        <NavLink to="/" className={styles.logo} aria-label="Accademia Europea di Comunicazione Digitale">
          <span className={styles.logoAccent}>AE</span>
          <span>Comunicazione Digitale</span>
        </NavLink>
        <nav className={`${styles.nav} ${open ? styles.open : ''}`} aria-label="Navigazione principale">
          <NavLink to="/" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>Home</NavLink>
          <NavLink to="/chi-siamo" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>Chi Siamo</NavLink>
          <NavLink to="/corsi" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>Corsi</NavLink>
          <NavLink to="/programma" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>Programma</NavLink>
          <NavLink to="/docenti" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>Docenti</NavLink>
          <NavLink to="/contatti" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} className="">{({ isActive }) => (isActive ? styles.activeLink : styles.link)}</NavLink>
        </nav>
        <NavLink to="/contatti" className={styles.ctaDesktop}>
          Inizia Ora
        </NavLink>
        <button
          className={styles.mobileToggle}
          onClick={toggleMenu}
          aria-expanded={open}
          aria-label="Apri menù di navigazione"
        >
          {open ? <FiX /> : <FiMenu />}
        </button>
      </div>
    </header>
  );
};

export default Header;