import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem('aecdigital-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('aecdigital-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Gestione dei Cookie</h4>
        <p>
          Utilizziamo cookie per migliorare la tua esperienza di navigazione e analizzare il traffico. Puoi proseguire
          accettando la nostra informativa sui cookie.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={handleAccept}>
          Accetto
        </button>
        <a className={styles.link} href="/cookie-policy">
          Scopri di più
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;