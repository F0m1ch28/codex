import React from 'react';
import { NavLink } from 'react-router-dom';
import { FiFacebook, FiInstagram, FiLinkedin } from 'react-icons/fi';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`${styles.footerContainer} container`}>
      <div className={styles.col}>
        <h3>Accademia Europea di Comunicazione Digitale</h3>
        <p>
          Formiamo professionisti che guidano strategie digitali, branding e contenuti con impatto reale.
        </p>
        <div className={styles.socials} aria-label="Social media">
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook Accademia">
            <FiFacebook />
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram Accademia">
            <FiInstagram />
          </a>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn Accademia">
            <FiLinkedin />
          </a>
        </div>
      </div>
      <div className={styles.col}>
        <h4>Link Rapidi</h4>
        <ul>
          <li><NavLink to="/chi-siamo">Chi Siamo</NavLink></li>
          <li><NavLink to="/corsi">Corsi</NavLink></li>
          <li><NavLink to="/programma">Programma</NavLink></li>
          <li><NavLink to="/docenti">Docenti</NavLink></li>
        </ul>
      </div>
      <div className={styles.col}>
        <h4>Supporto</h4>
        <ul>
          <li><NavLink to="/termini">Termini di Utilizzo</NavLink></li>
          <li><NavLink to="/privacy">Privacy</NavLink></li>
          <li><NavLink to="/cookie-policy">Cookie Policy</NavLink></li>
          <li><NavLink to="/contatti">Contatti</NavLink></li>
        </ul>
      </div>
      <div className={styles.col}>
        <h4>Contatti</h4>
        <p>Via Milano, 22, 20121 Milano MI</p>
        <p>Telefono: +39 02 9456 8113</p>
        <p>Email: [будет добавлен позже]</p>
        <p>Italia</p>
      </div>
    </div>
    <div className={styles.bottom}>
      © {new Date().getFullYear()} Accademia Europea di Comunicazione Digitale. Tutti i diritti riservati.
    </div>
  </footer>
);

export default Footer;