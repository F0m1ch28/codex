'use strict';

document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            primaryNav.classList.toggle('is-open');
            const expanded = primaryNav.classList.contains('is-open');
            navToggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        });

        const navLinks = primaryNav.querySelectorAll('a');
        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                if (primaryNav.classList.contains('is-open')) {
                    primaryNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('randomqfet_cookie_preference');
        if (storedPreference) {
            cookieBanner.classList.add('is-hidden');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-btn');
        cookieButtons.forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const choice = button.dataset.choice || 'undecided';
                localStorage.setItem('randomqfet_cookie_preference', choice);
                cookieBanner.classList.add('is-hidden');
            });
        });
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            let isValid = true;
            const fields = [
                { id: 'fullName', type: 'text' },
                { id: 'email', type: 'email' },
                { id: 'organization', type: 'text' },
                { id: 'subject', type: 'text' },
                { id: 'message', type: 'textarea' }
            ];

            fields.forEach((fieldConfig) => {
                const field = contactForm.querySelector(`#${fieldConfig.id}`);
                if (!field) {
                    return;
                }
                const value = field.value.trim();
                let errorMessage = '';
                if (value.length === 0) {
                    errorMessage = 'This field is required.';
                } else if (fieldConfig.type === 'email') {
                    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailPattern.test(value)) {
                        errorMessage = 'Please enter a valid email address.';
                    }
                } else if (value.length < 2) {
                    errorMessage = 'Please provide additional detail.';
                }

                const fieldWrapper = field.closest('.form-field');
                const errorEl = fieldWrapper ? fieldWrapper.querySelector('.form-error') : null;
                if (errorEl) {
                    if (errorMessage) {
                        errorEl.textContent = errorMessage;
                        fieldWrapper.classList.add('has-error');
                        isValid = false;
                    } else {
                        errorEl.textContent = '';
                        fieldWrapper.classList.remove('has-error');
                    }
                }
            });

            if (!isValid) {
                event.preventDefault();
            }
        });
    }

    const searchInput = document.getElementById('post-search');
    const categoryFilter = document.getElementById('category-filter');
    const postCards = document.querySelectorAll('[data-post-card]');
    const noResults = document.getElementById('no-results');

    const filterPosts = () => {
        if (!postCards.length) {
            return;
        }
        const searchTerm = searchInput ? searchInput.value.trim().toLowerCase() : '';
        const categoryValue = categoryFilter ? categoryFilter.value : 'all';
        let visibleCount = 0;

        postCards.forEach((card) => {
            const titleElement = card.querySelector('h3');
            const textElement = card.querySelector('p');
            const titleText = titleElement ? titleElement.textContent.toLowerCase() : '';
            const descriptionText = textElement ? textElement.textContent.toLowerCase() : '';
            const matchesSearch = !searchTerm || titleText.includes(searchTerm) || descriptionText.includes(searchTerm);
            const matchesCategory = categoryValue === 'all' || card.dataset.category === categoryValue;

            if (matchesSearch && matchesCategory) {
                card.removeAttribute('hidden');
                card.classList.remove('is-hidden');
                visibleCount += 1;
            } else {
                card.setAttribute('hidden', 'hidden');
                card.classList.add('is-hidden');
            }
        });

        if (noResults) {
            if (visibleCount === 0) {
                noResults.removeAttribute('hidden');
            } else {
                noResults.setAttribute('hidden', 'hidden');
            }
        }
    };

    if (searchInput) {
        searchInput.addEventListener('input', filterPosts);
    }
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterPosts);
    }
});