document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('is-open');
            navToggle.classList.toggle('is-active');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('is-open');
                navToggle.classList.remove('is-active');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('button[data-cookie="accept"]');
        const declineBtn = cookieBanner.querySelector('button[data-cookie="decline"]');
        const storedChoice = localStorage.getItem('genusCookieChoice');

        const hideBanner = () => cookieBanner.classList.add('is-hidden');

        if (storedChoice) {
            hideBanner();
        }

        const handleCookieChoice = (choice) => {
            localStorage.setItem('genusCookieChoice', choice);
            hideBanner();
            window.open('cookies.html', '_blank', 'noopener');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleCookieChoice('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleCookieChoice('declined'));
        }
    }
});