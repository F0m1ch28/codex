document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.mobile-nav-toggle');
    const navMenu = document.querySelector('.main-navigation');
    const scrollBtn = document.getElementById('scrollToTop');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAcceptBtn = document.getElementById('cookieAccept');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('open')) {
                    navMenu.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollBtn.style.display = 'block';
            } else {
                scrollBtn.style.display = 'none';
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAcceptBtn) {
        const consentKey = 'zavendoryxa_cookie_consent';
        const hasConsent = localStorage.getItem(consentKey) === 'true';

        if (!hasConsent) {
            cookieBanner.style.display = 'block';
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'true');
            cookieBanner.style.display = 'none';
        });
    }
});