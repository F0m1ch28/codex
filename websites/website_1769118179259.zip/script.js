document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const pageIdentifier = body.dataset.page || '';
  const storedLanguage = localStorage.getItem('jtpay-lang');

  if (pageIdentifier === 'root-redirect') {
    const targetLanguage = storedLanguage === 'en' ? 'en' : 'nl';
    const targetUrl = '/' + targetLanguage + '/index.html';
    if (window.location.pathname !== targetUrl) {
      window.location.replace(targetUrl);
    }
    return;
  }

  const currentLanguage = body.dataset.lang || 'nl';
  localStorage.setItem('jtpay-lang', currentLanguage);

  const navToggle = document.querySelector('[data-mobile-toggle]');
  const navigation = document.querySelector('[data-primary-nav]');
  if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      document.documentElement.classList.toggle('nav-open');
    });

    const navLinks = navigation.querySelectorAll('a');
    navLinks.forEach((link) => {
      if (link.dataset.pageTarget === pageIdentifier) {
        link.classList.add('is-active');
        link.setAttribute('aria-current', 'page');
      }
      link.addEventListener('click', () => {
        document.documentElement.classList.remove('nav-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const languageSwitcher = document.querySelector('[data-language-switcher]');
  if (languageSwitcher) {
    languageSwitcher.value = currentLanguage;
    languageSwitcher.addEventListener('change', (event) => {
      const selected = event.target.value;
      if (!selected || selected === currentLanguage) {
        return;
      }
      const targetPage = pageIdentifier || 'index';
      const filename = targetPage + '.html';
      localStorage.setItem('jtpay-lang', selected);
      window.location.href = '/' + selected + '/' + filename;
    });
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  const cookieAccept = document.querySelector('[data-cookie-accept]');
  const cookieKey = 'jtpay-cookie-consent';
  if (cookieBanner && cookieAccept) {
    if (!localStorage.getItem(cookieKey)) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('active');
      });
    }
    cookieAccept.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'accepted');
      cookieBanner.classList.remove('active');
    });
  }

  const yearTarget = document.querySelectorAll('[data-current-year]');
  const currentYear = String(new Date().getFullYear());
  yearTarget.forEach((el) => {
    el.textContent = currentYear;
  });
});