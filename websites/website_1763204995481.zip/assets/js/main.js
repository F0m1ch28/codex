document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".site-nav");
    const scrollTopBtn = document.getElementById("scrollTop");
    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");
    const form = document.getElementById("contactForm");
    const formStatus = document.getElementById("formStatus");
    const currentYearEl = document.getElementById("current-year");

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (navToggle) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", !expanded);
            nav.classList.toggle("open");
        });

        document.addEventListener("click", (event) => {
            if (!nav.contains(event.target) && !navToggle.contains(event.target)) {
                nav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    if (scrollTopBtn) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 300) {
                scrollTopBtn.style.display = "flex";
            } else {
                scrollTopBtn.style.display = "none";
            }
        });

        scrollTopBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    const cookieConsentKey = "tsd_cookie_consent";
    if (cookieBanner && acceptCookiesBtn) {
        const hasConsent = localStorage.getItem(cookieConsentKey);
        if (hasConsent) {
            cookieBanner.style.display = "none";
        }

        acceptCookiesBtn.addEventListener("click", () => {
            localStorage.setItem(cookieConsentKey, "accepted");
            cookieBanner.style.display = "none";
        });
    }

    if (form && formStatus) {
        form.addEventListener("submit", (event) => {
            event.preventDefault();
            const formData = new FormData(form);
            if (!formData.get("name") || !formData.get("email") || !formData.get("message") || !formData.get("consent")) {
                formStatus.textContent = "Please complete the required fields.";
                formStatus.style.color = "#d1495b";
                return;
            }
            formStatus.textContent = "Sending...";
            formStatus.style.color = "#6c7a89";

            setTimeout(() => {
                form.reset();
                formStatus.textContent = "Thank you. Your message has been sent.";
                formStatus.style.color = "#2f5673";
            }, 1000);
        });
    }
});