(function () {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            primaryNav.classList.toggle("open");
        });

        primaryNav.addEventListener("click", (event) => {
            if (event.target.tagName === "A") {
                navToggle.classList.remove("active");
                primaryNav.classList.remove("open");
            }
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const cookieConsent = localStorage.getItem("straigojipCookiePreference");

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
    }

    if (!cookieConsent && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => {
            localStorage.setItem("straigojipCookiePreference", "accepted");
            hideCookieBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => {
            localStorage.setItem("straigojipCookiePreference", "declined");
            hideCookieBanner();
        });
    }
})();