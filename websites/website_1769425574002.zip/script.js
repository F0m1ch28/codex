document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("is-open");
    });
  }

  const fadeElements = document.querySelectorAll(".fade-up");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    fadeElements.forEach((el) => observer.observe(el));
  } else {
    fadeElements.forEach((el) => el.classList.add("is-visible"));
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieChoice = localStorage.getItem("pr-cookie-choice");
  if (cookieBanner && !cookieChoice) {
    cookieBanner.classList.add("visible");
    cookieBanner.querySelectorAll("[data-cookie-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        const value = button.getAttribute("data-cookie-choice");
        localStorage.setItem("pr-cookie-choice", value);
        cookieBanner.classList.remove("visible");
      });
    });
  }

  const yearSpan = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearSpan.forEach((el) => (el.textContent = String(currentYear)));

  const formToast = document.querySelector(".form-toast");
  const forms = document.querySelectorAll("form[data-form]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (formToast) {
        formToast.textContent = "Message prepared. Redirecting to confirmation...";
        formToast.classList.add("visible");
        setTimeout(() => {
          formToast.classList.remove("visible");
        }, 2800);
      }
      setTimeout(() => {
        window.location.href = form.action;
      }, 1500);
    });
  });
});