import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const featuredAgencies = [
  {
    name: 'Studio Éclat',
    focus: 'Integrated Campaigns',
    location: 'Antwerp',
    image: 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1000&q=80',
  },
  {
    name: 'Wavefront Creative',
    focus: 'Digital Storytelling',
    location: 'Brussels',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1000&q=80',
  },
  {
    name: 'Maison Impact',
    focus: 'Brand Strategy',
    location: 'Ghent',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1000&q=80',
  },
];

const testimonials = [
  {
    quote:
      'AdAgencyHub guided us toward a partner that immediately understood our ambition for a countrywide launch. The collaboration has been seamless from day one.',
    name: 'Charlotte De Wilde',
    title: 'Head of Marketing, Urban Bloom',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
  },
  {
    quote:
      'The platform combines thorough research with practical advice. We discovered a creative powerhouse that helped us reposition our brand across Belgium.',
    name: 'Jeroen Maes',
    title: 'Brand Director, NorthSea Foods',
    image: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=400&q=80',
  },
  {
    quote:
      'From the brief builder to benchmarking tools, every step felt intuitive. AdAgencyHub kept us aligned with measurable goals.',
    name: 'Sofia Laurent',
    title: 'Communications Lead, Lumière Events',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=400&q=80',
  },
];

const blogHighlights = [
  {
    slug: '2024-ad-trends',
    title: '2024 Advertising Trends Across Belgium',
    excerpt: 'From immersive retail to audio-first storytelling, explore the momentum shaping Belgian campaigns this year.',
    date: 'May 14, 2024',
  },
  {
    slug: 'success-story-leo-burnett',
    title: 'Success Story: Leo Burnett & Brussels Metro',
    excerpt: 'Behind the ideas connecting commuters with a revitalised brand narrative built for the city rhythm.',
    date: 'April 27, 2024',
  },
  {
    slug: 'agency-culture-insights',
    title: 'Inside Agency Culture: Leading for Creativity',
    excerpt: 'Principles that keep Belgian agency teams inventive, inclusive, and aligned around purpose-driven outcomes.',
    date: 'March 30, 2024',
  },
];

const Home = () => {
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>AdAgencyHub | Belgium’s Advertising Agency Platform</title>
        <meta
          name="description"
          content="Discover Belgium’s advertising agencies, collaborative programs, tools, and expert guidance with AdAgencyHub."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className={styles.heroContent}>
          <p className={styles.tag}>Belgium’s Creative Compass</p>
          <h1 id="hero-heading">Connect with agencies that elevate your brand voice</h1>
          <p className={styles.heroText}>
            AdAgencyHub curates data-backed insights to help marketing teams evaluate, shortlist, and collaborate with
            advertising specialists throughout Belgium.
          </p>
          <form className={styles.searchForm} onSubmit={(e) => e.preventDefault()}>
            <label htmlFor="agency-search" className="sr-only">
              Search for agencies
            </label>
            <input
              id="agency-search"
              type="text"
              placeholder="Search by specialty, city, or project goal"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button type="submit">Explore agencies</button>
          </form>
          <div className={styles.heroLinks}>
            <NavLink to="/guide" className={styles.primaryCta}>
              Read the guide
            </NavLink>
            <NavLink to="/programs" className={styles.secondaryCta}>
              Join a program
            </NavLink>
          </div>
        </div>
      </section>

      <section className={styles.features} aria-labelledby="feature-heading">
        <div className={styles.sectionHeader}>
          <h2 id="feature-heading">Why teams choose AdAgencyHub</h2>
          <p>Structured decision support tailored to the Belgian market.</p>
        </div>
        <div className={styles.featureGrid}>
          <article>
            <h3>Curated agency intelligence</h3>
            <p>
              Evaluate agencies with verified portfolios, sector expertise, and collaboration styles to match your brand’s identity.
            </p>
          </article>
          <article>
            <h3>Brief builder & benchmarking</h3>
            <p>
              Shape a strategic brief backed by performance indicators, benchmarks, and cultural insights for the region.
            </p>
          </article>
          <article>
            <h3>Relationship navigation</h3>
            <p>
              Access frameworks for kickoff sessions, feedback cycles, and governance to keep partnerships productive.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.featuredAgencies} aria-labelledby="agency-heading">
        <div className={styles.sectionHeader}>
          <h2 id="agency-heading">Featured agencies this quarter</h2>
          <p>Handpicked studios excelling in cross-channel storytelling and measurable results.</p>
        </div>
        <div className={styles.agencyGrid}>
          {featuredAgencies.map((agency) => (
            <article key={agency.name} className={styles.agencyCard}>
              <img src={agency.image} alt={`${agency.name} office`} loading="lazy" />
              <div className={styles.agencyBody}>
                <h3>{agency.name}</h3>
                <p className={styles.location}>{agency.location}, Belgium</p>
                <p>{agency.focus}</p>
                <NavLink to="/guide" className={styles.cardLink}>
                  View profile
                </NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.stats} aria-label="Impact statistics">
        <div className={styles.statsItem}>
          <span>260+</span>
          <p>Agencies reviewed across Belgium</p>
        </div>
        <div className={styles.statsItem}>
          <span>180</span>
          <p>Brand-agency collaborations facilitated</p>
        </div>
        <div className={styles.statsItem}>
          <span>94%</span>
          <p>Client satisfaction score from partner surveys</p>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-heading">
        <div className={styles.sectionHeader}>
          <h2 id="process-heading">How it works</h2>
          <p>From discovery to delivery, our process keeps your vision centred.</p>
        </div>
        <div className={styles.processGrid}>
          <div className={styles.step}>
            <span className={styles.stepNumber}>1</span>
            <h3>Define ambition</h3>
            <p>Align objectives, desired outcomes, and budget considerations through guided workshops.</p>
          </div>
          <div className={styles.step}>
            <span className={styles.stepNumber}>2</span>
            <h3>Shortlist agencies</h3>
            <p>Leverage our data engine to identify agencies with proven success in your sector and audience.</p>
          </div>
          <div className={styles.step}>
            <span className={styles.stepNumber}>3</span>
            <h3>Collaborate confidently</h3>
            <p>Receive playbooks, milestone templates, and retrospectives to keep collaboration transparent.</p>
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonial-heading">
        <h2 id="testimonial-heading">Voices from marketing leaders</h2>
        <div className={styles.testimonialCard}>
          <img
            src={testimonials[testimonialIndex].image}
            alt={`${testimonials[testimonialIndex].name} portrait`}
            loading="lazy"
          />
          <blockquote>
            <p>“{testimonials[testimonialIndex].quote}”</p>
            <footer>
              {testimonials[testimonialIndex].name} · <span>{testimonials[testimonialIndex].title}</span>
            </footer>
          </blockquote>
        </div>
        <div className={styles.dots} role="tablist" aria-label="Testimonial selector">
          {testimonials.map((_, index) => (
            <button
              key={index}
              className={`${styles.dot} ${index === testimonialIndex ? styles.activeDot : ''}`}
              aria-label={`View testimonial ${index + 1}`}
              onClick={() => setTestimonialIndex(index)}
              type="button"
            />
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-labelledby="blog-heading">
        <div className={styles.sectionHeader}>
          <h2 id="blog-heading">Latest from the Hub</h2>
          <p>Insights, interviews, and actionable resources for brand leaders across Belgium.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogHighlights.map((post) => (
            <article key={post.slug} className={styles.blogCard}>
              <span className={styles.blogDate}>{post.date}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <NavLink to={`/blog/${post.slug}`} className={styles.cardLink}>
                Read article
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-heading">
        <div className={styles.ctaContent}>
          <h2 id="cta-heading">Start your agency discovery journey today</h2>
          <p>
            Build a partnership playbook tailored to your marketing goals and connect with Belgian agencies ready to co-create your next campaign.
          </p>
          <NavLink to="/contact" className={styles.primaryCta}>
            Contact the team
          </NavLink>
        </div>
        <div className={styles.ctaImage} role="presentation" />
      </section>
    </div>
  );
};

export default Home;