import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LegalText.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Service | AdAgencyHub</title>
      <meta
        name="description"
        content="Review the Terms of Service for AdAgencyHub, outlining platform usage, responsibilities, and obligations."
      />
    </Helmet>
    <article className={styles.article}>
      <h1>Terms of Service</h1>
      <p>Last updated: 1 May 2024</p>

      <h2>1. Introduction</h2>
      <p>
        These Terms of Service (“Terms”) govern your access to and use of the AdAgencyHub platform, located at
        ad-agencyhub.com (“Platform”). By visiting or using the Platform, you agree to comply with these Terms.
      </p>

      <h2>2. Services</h2>
      <p>
        AdAgencyHub provides curated information about advertising agencies in Belgium, insights, and collaboration
        guidance. We do not represent agencies or guarantee outcomes of any partnership established through our Platform.
      </p>

      <h2>3. Eligibility</h2>
      <p>
        You must be at least 18 years old and authorised to act on behalf of your organisation to use the Platform. By
        using the Platform, you confirm you meet this requirement.
      </p>

      <h2>4. User responsibilities</h2>
      <ul>
        <li>Provide accurate information when submitting enquiries or requests.</li>
        <li>Use the Platform only for lawful purposes and in accordance with these Terms.</li>
        <li>Respect intellectual property rights associated with Platform content and third-party materials.</li>
      </ul>

      <h2>5. Intellectual property</h2>
      <p>
        The Platform and its content, including text, design elements, and graphics, are owned by AdAgencyHub or our
        licensors. You may not reproduce or distribute content without prior written consent.
      </p>

      <h2>6. Third-party links</h2>
      <p>
        Our Platform may reference external websites. We are not responsible for the content or practices of those sites.
        Access them at your own discretion.
      </p>

      <h2>7. Disclaimers</h2>
      <p>
        The Platform is provided on an “as is” basis. We make no warranties regarding the accuracy or completeness of
        information provided. Decisions based on Platform content are your responsibility.
      </p>

      <h2>8. Limitation of liability</h2>
      <p>
        To the maximum extent permitted by Belgian law, AdAgencyHub shall not be liable for indirect, incidental, or
        consequential damages arising from your use of the Platform.
      </p>

      <h2>9. Changes to these Terms</h2>
      <p>
        We may update these Terms to reflect operational, legal, or regulatory changes. Significant updates will be
        communicated on the Platform with a revised effective date.
      </p>

      <h2>10. Contact</h2>
      <p>
        Questions about these Terms can be directed to contact@ad-agencyhub.com. Please include “Terms of Service” in the
        subject line for a prompt response.
      </p>
    </article>
  </div>
);

export default Terms;