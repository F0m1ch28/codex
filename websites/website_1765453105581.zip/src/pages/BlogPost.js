import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './BlogPost.module.css';

const posts = {
  'success-story-leo-burnett': {
    title: 'Success Story: Leo Burnett & Brussels Metro',
    date: 'April 27, 2024',
    heroImage: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=80',
    sections: [
      {
        heading: 'The challenge',
        content:
          'Brussels Metro needed a refreshed identity that resonated with commuters in a bustling, multilingual city. The objective was to build an experience that felt relevant, inclusive, and energising while encouraging sustainable mobility.',
      },
      {
        heading: 'The partnership',
        content:
          'Leo Burnett Belgium led the strategic positioning with extensive field research, observations, and panel sessions across Brussels neighbourhoods. AdAgencyHub facilitated alignment workshops that clarified key personas and brand territories.',
      },
      {
        heading: 'Crafting the solution',
        content:
          'The agency created a campaign anchored in human stories—spotlighting commuters who pursue their passions thanks to reliable transport. Visuals blended bold typography with playful illustrations inspired by metro routes.',
      },
      {
        heading: 'Results that matter',
        content:
          'Ridership sentiment scores improved by 18%, and the brand’s social channels saw a 140% increase in community-driven content. The partnership continues with a focus on long-term loyalty initiatives.',
      },
    ],
  },
  '2024-ad-trends': {
    title: '2024 Advertising Trends Across Belgium',
    date: 'May 14, 2024',
    heroImage: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=1600&q=80',
    sections: [
      {
        heading: 'Immersive retail experiences',
        content:
          'Belgian retailers are weaving digital layers into their physical environments. Augmented discovery kiosks now appear in flagship stores while mobile-exclusive drops drive queues with purpose.',
      },
      {
        heading: 'Audio-first storytelling',
        content:
          'Brands collaborate with local podcasts and audio collectives to produce city narratives, reaching commuters with intimate, on-the-go experiences.',
      },
      {
        heading: 'Sustainable production commitments',
        content:
          'Agencies are investing in greener production workflows, from local sourcing of materials to energy-efficient studio practices, meeting procurement standards and consumer expectations.',
      },
      {
        heading: 'Data as a creative compass',
        content:
          'First-party insights and cultural listening platforms provide team-wide dashboards, helping creative directors respond quickly to shifting behaviours while maintaining brand integrity.',
      },
    ],
  },
  'agency-culture-insights': {
    title: 'Inside Agency Culture: Leading for Creativity',
    date: 'March 30, 2024',
    heroImage: 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1600&q=80',
    sections: [
      {
        heading: 'Curiosity as a team ritual',
        content:
          'Belgian agencies embrace cross-disciplinary critiques where strategists, designers, and technologists explore briefs together, nurturing mutual respect and curiosity.',
      },
      {
        heading: 'Psychological safety in practice',
        content:
          'Leaders prioritise transparent feedback channels, dedicated wellness support, and flexible work rhythms to keep minds open and inventive.',
      },
      {
        heading: 'Scaling culture across borders',
        content:
          'As agencies collaborate internationally, they invest time in cultural onboarding, multilingual facilitation, and shared learnings to keep teams cohesive.',
      },
      {
        heading: 'Continuous learning loops',
        content:
          'Creative guilds, mentorship programs, and guest lectures from Belgium’s universities keep teams inspired and future-ready.',
      },
    ],
  },
};

const BlogPost = () => {
  const { slug } = useParams();
  const post = posts[slug];

  if (!post) {
    return (
      <div className={styles.page}>
        <Helmet>
          <title>Article Not Found | AdAgencyHub</title>
        </Helmet>
        <div className={styles.notFound}>
          <h1>Article not found</h1>
          <p>The article you are looking for may have been archived.</p>
          <Link to="/blog" className={styles.link}>
            Back to all articles
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Helmet>
        <title>{post.title} | AdAgencyHub Blog</title>
        <meta name="description" content={`${post.title} - An insight from AdAgencyHub.`} />
      </Helmet>
      <header className={styles.hero}>
        <div className={styles.overlay} />
        <img src={post.heroImage} alt={`${post.title} hero`} />
        <div className={styles.heroContent}>
          <span>{post.date}</span>
          <h1>{post.title}</h1>
        </div>
      </header>
      <article className={styles.article}>
        {post.sections.map((section) => (
          <section key={section.heading} className={styles.section}>
            <h2>{section.heading}</h2>
            <p>{section.content}</p>
          </section>
        ))}
      </article>
      <div className={styles.backLinkWrapper}>
        <Link to="/blog" className={styles.link}>
          ← Back to insights
        </Link>
      </div>
    </div>
  );
};

export default BlogPost;