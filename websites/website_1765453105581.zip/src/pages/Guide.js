import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Guide.module.css';

const Guide = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Agency Selection Guide | AdAgencyHub</title>
      <meta
        name="description"
        content="Discover practical steps to select the right advertising agency in Belgium with AdAgencyHub’s comprehensive guide."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Agency Selection Guide</h1>
      <p>
        Navigate the Belgian agency landscape with confidence. Our guide distills insights from hundreds of projects to
        help you recognise the right partner at every stage.
      </p>
    </header>

    <section className={styles.section}>
      <h2>1. Clarify your ambition</h2>
      <ul>
        <li>Frame the business challenge, marketing objective, and key audience segments.</li>
        <li>Gather existing assets, research, and performance data to share with potential partners.</li>
        <li>Define decision-makers, stakeholders, and approval timelines within your organisation.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>2. Outline the creative scope</h2>
      <ul>
        <li>Identify the channels and formats you expect to prioritise, such as out-of-home or social video.</li>
        <li>Specify whether you need strategic planning, production, media, or all three components.</li>
        <li>Set expectations around deliverables, reporting cadence, and resource availability.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>3. Build a shortlist</h2>
      <p>
        Combine AdAgencyHub’s curated data with peer recommendations to create a shortlist of agencies aligned with your
        needs.
      </p>
      <ol>
        <li>Filter by sector experience, award recognition, and team composition.</li>
        <li>Pay attention to agency culture, language fluency, and collaboration style.</li>
        <li>Prepare discovery sessions that focus on capabilities and chemistry rather than pricing alone.</li>
      </ol>
    </section>

    <section className={styles.section}>
      <h2>4. Evaluate chemistry & fit</h2>
      <ul>
        <li>Host working sessions to test problem-solving approaches on real scenarios.</li>
        <li>Assess the agency’s transparency, curiosity, and ability to communicate complex ideas clearly.</li>
        <li>Request references relevant to your industry and scale, then follow up thoughtfully.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>5. Define success metrics</h2>
      <ul>
        <li>Align on KPIs that blend brand building with performance indicators.</li>
        <li>Set milestone reviews and retrospectives to maintain accountability on both sides.</li>
        <li>Document how learnings will be shared and embedded across your internal teams.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>Checklist before onboarding</h2>
      <div className={styles.checklist}>
        <div>
          <h3>Strategic readiness</h3>
          <p>Do you have a clear brand narrative, value proposition, and audience insights to share?</p>
        </div>
        <div>
          <h3>Operational alignment</h3>
          <p>Have you agreed on project governance, tools, and collaboration rituals?</p>
        </div>
        <div>
          <h3>Measurement clarity</h3>
          <p>Are KPIs, data access, and reporting responsibilities well-defined?</p>
        </div>
      </div>
    </section>
  </div>
);

export default Guide;