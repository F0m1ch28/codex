import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LegalText.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | AdAgencyHub</title>
      <meta
        name="description"
        content="Learn how AdAgencyHub collects, uses, and protects your personal data when you use our platform."
      />
    </Helmet>
    <article className={styles.article}>
      <h1>Privacy Policy</h1>
      <p>Last updated: 1 May 2024</p>

      <h2>1. Overview</h2>
      <p>
        AdAgencyHub respects your privacy. This policy explains what personal data we collect, how we use it, and your
        rights under applicable Belgian and EU data protection laws.
      </p>

      <h2>2. Data we collect</h2>
      <ul>
        <li>Contact information submitted through forms, such as name, email, company, and project details.</li>
        <li>Usage data, including pages visited, engagement metrics, and cookies for analytics.</li>
        <li>Voluntary feedback and survey responses that help us improve our services.</li>
      </ul>

      <h2>3. How we use data</h2>
      <ul>
        <li>To respond to enquiries and provide tailored agency recommendations.</li>
        <li>To analyse Platform usage and enhance user experience.</li>
        <li>To send relevant updates and resources when you opt in.</li>
      </ul>

      <h2>4. Legal basis</h2>
      <p>
        We process personal data under legitimate interest, contractual necessity, and, where required, consent. You may
        withdraw consent at any time by contacting us.
      </p>

      <h2>5. Sharing of data</h2>
      <p>
        We may share your information with trusted partners assisting us in delivering services, subject to confidentiality agreements. We do not sell personal data.
      </p>

      <h2>6. International transfers</h2>
      <p>
        If data is transferred outside the European Economic Area, we ensure appropriate safeguards are in place,
        including standard contractual clauses.
      </p>

      <h2>7. Retention</h2>
      <p>
        Personal data is retained only as long as necessary to fulfil the purposes outlined above or to comply with legal obligations.
      </p>

      <h2>8. Your rights</h2>
      <ul>
        <li>Access, rectify, or erase your personal data.</li>
        <li>Restrict or object to processing in certain circumstances.</li>
        <li>Request data portability for information you provided.</li>
        <li>Lodge a complaint with the Belgian Data Protection Authority.</li>
      </ul>

      <h2>9. Security</h2>
      <p>
        We implement technical and organisational measures to safeguard your information, including encryption, access
        controls, and regular reviews of our security practices.
      </p>

      <h2>10. Updates</h2>
      <p>
        We may revise this Privacy Policy from time to time. Material changes will be highlighted on the Platform with an
        updated effective date.
      </p>

      <h2>11. Contact</h2>
      <p>
        For privacy-related questions, email contact@ad-agencyhub.com with “Privacy Request” in the subject line.
      </p>
    </article>
  </div>
);

export default Privacy;