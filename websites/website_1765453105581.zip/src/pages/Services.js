import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const services = [
  {
    title: 'Discovery Workshops',
    description:
      'Tailored sessions to align stakeholders, map customer journeys, and prepare briefs that inspire agency partners.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Agency Vetting & Shortlisting',
    description:
      'We evaluate agencies against your criteria, from cultural fit to sector expertise, creating a shortlist you can trust.',
    image: 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Collaboration Playbooks',
    description:
      'Structured governance models, feedback loops, and milestone templates to keep your campaign workflow on track.',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Performance & Learning Reviews',
    description:
      'Quarterly assessments translating campaign data into actionable insights for future creative investments.',
    image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=80',
  },
];

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Services | AdAgencyHub</title>
      <meta
        name="description"
        content="Explore the tailored services offered by AdAgencyHub to support brands working with Belgian advertising agencies."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Services designed for partnership success</h1>
      <p>
        We work alongside marketing leaders to provide strategic clarity, operational excellence, and inspired
        collaboration with agencies across Belgium.
      </p>
    </header>
    <section className={styles.grid}>
      {services.map((service) => (
        <article key={service.title} className={styles.card}>
          <img src={service.image} alt={`${service.title} visual`} loading="lazy" />
          <div className={styles.content}>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <a href="/contact" className={styles.link}>
              Connect with our team
            </a>
          </div>
        </article>
      ))}
    </section>
  </div>
);

export default Services;