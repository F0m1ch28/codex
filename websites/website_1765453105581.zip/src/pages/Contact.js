import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = useState({
    name: '',
    company: '',
    email: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    setFormState((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact AdAgencyHub | Let’s Collaborate</title>
        <meta
          name="description"
          content="Contact AdAgencyHub for partnership inquiries, support, or to start your agency discovery journey."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Contact AdAgencyHub</h1>
        <p>
          We’re here to help you navigate agency partnerships across Belgium. Share your goals and our advisors will be
          in touch.
        </p>
      </header>
      <section className={styles.content}>
        <div className={styles.details}>
          <h2>Reach out</h2>
          <p>Use the form to start a conversation or explore guided support options below.</p>
          <div className={styles.infoBlock}>
            <h3>General enquiries</h3>
            <span>contact@ad-agencyhub.com</span>
          </div>
          <div className={styles.infoBlock}>
            <h3>Phone</h3>
            <span>+32 456 78 90 12</span>
          </div>
          <div className={styles.infoBlock}>
            <h3>Location</h3>
            <span>Brussels, Belgium</span>
          </div>
          <div className={styles.social}>
            <h3>Connect with us</h3>
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer">
              Twitter / X
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer">
              Instagram
            </a>
          </div>
          <div className={styles.support}>
            <h3>Help &amp; Support</h3>
            <ul>
              <li>Guided onboarding for marketing teams</li>
              <li>Assistance selecting the right program</li>
              <li>Access to collaboration templates</li>
              <li>Answers to platform and data questions</li>
            </ul>
          </div>
        </div>
        <form className={styles.form} onSubmit={handleSubmit}>
          <h2>Send us a message</h2>
          <div className={styles.field}>
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formState.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="company">Company</label>
            <input
              id="company"
              name="company"
              type="text"
              value={formState.company}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Work email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formState.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Project goals</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formState.message}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit">Submit message</button>
          {submitted && (
            <p className={styles.confirmation} role="status">
              Thank you for reaching out. Our team will respond shortly.
            </p>
          )}
        </form>
      </section>
    </div>
  );
};

export default Contact;