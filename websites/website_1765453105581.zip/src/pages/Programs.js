import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Programs.module.css';

const programs = [
  {
    title: 'Emerging Brands Track',
    description:
      'A guided accelerator helping young brands connect with boutique agencies for launch campaigns across Belgium’s urban centres.',
    focus: ['Brand positioning sessions', 'Creative sprints', 'Campaign roadmap'],
    image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Scale-Up Collaboration Labs',
    description:
      'For scale-ups aiming to accelerate growth, this program pairs you with multidisciplinary agencies experienced in rapid iteration.',
    focus: ['Performance rituals', 'Cross-channel analytics', 'Agile creative production'],
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Public Impact Initiative',
    description:
      'Designed for public sector and non-profit teams seeking partners who can build trust, clarity, and community engagement.',
    focus: ['Stakeholder co-creation', 'Inclusive storytelling', 'Measurement frameworks'],
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=800&q=80',
  },
];

const Programs = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Programs & Partnerships | AdAgencyHub</title>
      <meta
        name="description"
        content="Explore collaborative programs and partnership opportunities facilitated by AdAgencyHub across Belgium."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Collaborative Programs</h1>
      <p>
        Structured initiatives that bring brands and agencies together with clarity, momentum, and measurable outcomes.
      </p>
    </header>
    <section className={styles.grid}>
      {programs.map((program) => (
        <article key={program.title} className={styles.card}>
          <div className={styles.imageWrapper}>
            <img src={program.image} alt={`${program.title} illustration`} loading="lazy" />
          </div>
          <div className={styles.content}>
            <h2>{program.title}</h2>
            <p>{program.description}</p>
            <ul>
              {program.focus.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </article>
      ))}
    </section>
  </div>
);

export default Programs;