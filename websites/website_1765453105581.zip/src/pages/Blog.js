import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Blog.module.css';

const blogPosts = [
  {
    slug: 'success-story-leo-burnett',
    title: 'Success Story: Leo Burnett & Brussels Metro',
    date: 'April 27, 2024',
    summary:
      'How one iconic agency brought a fresh narrative to Brussels commuters through human-centred storytelling and data-led placements.',
  },
  {
    slug: '2024-ad-trends',
    title: '2024 Advertising Trends Across Belgium',
    date: 'May 14, 2024',
    summary:
      'From immersive retail experiences to new creative-tech collaborations, discover the trends guiding Belgian campaigns this year.',
  },
  {
    slug: 'agency-culture-insights',
    title: 'Inside Agency Culture: Leading for Creativity',
    date: 'March 30, 2024',
    summary:
      'Explore practices that nurture inventive teams, psychological safety, and collaborative rituals inside Belgian agencies.',
  },
];

const Blog = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Insights & Stories | AdAgencyHub Blog</title>
      <meta
        name="description"
        content="Stay up to date with the latest advertising news, success stories, and agency interviews from AdAgencyHub."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Insights & Stories</h1>
      <p>Ideas, interviews, and perspectives from Belgium’s advertising ecosystem.</p>
    </header>
    <section className={styles.grid}>
      {blogPosts.map((post) => (
        <article key={post.slug} className={styles.card}>
          <span className={styles.date}>{post.date}</span>
          <h2>{post.title}</h2>
          <p>{post.summary}</p>
          <Link to={`/blog/${post.slug}`} className={styles.link}>
            Read article
          </Link>
        </article>
      ))}
    </section>
  </div>
);

export default Blog;