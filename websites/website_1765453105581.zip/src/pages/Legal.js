import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Legal.module.css';

const Legal = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Legal Information | AdAgencyHub</title>
      <meta
        name="description"
        content="Review AdAgencyHub’s legal documentation, including terms of service, privacy policy, and cookie policy."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Legal Information</h1>
      <p>Understand how we operate, protect your data, and use cookies across AdAgencyHub.</p>
    </header>
    <section className={styles.links}>
      <article>
        <h2>Terms of Service</h2>
        <p>Read the conditions that govern your use of the AdAgencyHub platform and services.</p>
        <Link to="/terms">View Terms</Link>
      </article>
      <article>
        <h2>Privacy Policy</h2>
        <p>Learn how we process, store, and safeguard personal data collected through our platform.</p>
        <Link to="/privacy">View Privacy Policy</Link>
      </article>
      <article>
        <h2>Cookie Policy</h2>
        <p>Discover how cookies and similar technologies support functionality and analytics on our site.</p>
        <Link to="/cookie-policy">View Cookie Policy</Link>
      </article>
    </section>
  </div>
);

export default Legal;