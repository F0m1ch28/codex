import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Brief Architect',
    description:
      'A guided briefing environment that aligns stakeholders, defines tone, and captures essential campaign requirements.',
    benefits: ['Collaboration-ready template', 'Automated prompts', 'Market benchmarks'],
  },
  {
    title: 'Agency Match Index',
    description:
      'An intelligent scoring system aggregating expertise, cultural fit, and performance history for agencies across Belgium.',
    benefits: ['Custom filters', 'Shortlist reports', 'Comparison dashboard'],
  },
  {
    title: 'Collaboration Console',
    description:
      'Keep every milestone on track with shared workstreams, review cycles, and governance frameworks built for agility.',
    benefits: ['Ritual planning', 'Feedback loops', 'Shared documentation'],
  },
  {
    title: 'Impact Measurement Hub',
    description:
      'Connect campaign outcomes to strategic KPIs with adaptable scorecards and trend tracking.',
    benefits: ['Cross-channel analytics', 'Quarterly retrospectives', 'Stakeholder summaries'],
  },
];

const Tools = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Tools & Resources | AdAgencyHub</title>
      <meta
        name="description"
        content="Discover practical tools, templates, and technology offered by AdAgencyHub to enhance your agency partnerships."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Tools & Resources</h1>
      <p>
        Empower your team with curated frameworks, digital utilities, and scorecards that keep agency collaborations
        measurable and inspiring.
      </p>
    </header>
    <section className={styles.toolGrid}>
      {tools.map((tool) => (
        <article key={tool.title} className={styles.card}>
          <h2>{tool.title}</h2>
          <p>{tool.description}</p>
          <h3>What you gain</h3>
          <ul>
            {tool.benefits.map((benefit) => (
              <li key={benefit}>{benefit}</li>
            ))}
          </ul>
        </article>
      ))}
    </section>
    <section className={styles.banner}>
      <div className={styles.bannerText}>
        <h2>Need customised support?</h2>
        <p>
          Our team can tailor these tools to match your governance needs, workflow, and data sources across Belgian
          markets.
        </p>
      </div>
      <a href="/contact" className={styles.bannerLink}>
        Talk with an advisor
      </a>
    </section>
  </div>
);

export default Tools;