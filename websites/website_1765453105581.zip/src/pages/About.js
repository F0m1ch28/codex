import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Nathalie Verbeeck',
    role: 'Founder & Strategy Lead',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
    bio: 'Former agency strategist with 15 years of experience guiding integrated campaigns across Belgium and the Netherlands.',
  },
  {
    name: 'Ruben De Clercq',
    role: 'Partnerships Director',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80',
    bio: 'Specialist in brand-agency matchmaking, Ruben navigates collaborations that balance creativity with governance.',
  },
  {
    name: 'Sarah Dumont',
    role: 'Insights & Research Lead',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=600&q=80',
    bio: 'Sarah manages our research lab, analysing campaign outcomes, cultural shifts, and audience behaviours across Belgium.',
  },
];

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About AdAgencyHub | Mission & Team</title>
      <meta
        name="description"
        content="Learn about AdAgencyHub’s mission to connect brands with Belgian advertising agencies and meet the team behind the platform."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Our mission is to champion impactful agency partnerships</h1>
        <p>
          AdAgencyHub was created to give marketing teams a reliable compass for navigating the rich Belgian agency
          landscape. We combine human expertise with curated intelligence to remove guesswork and build long-term trust.
        </p>
      </div>
      <div className={styles.heroImage}>
        <img
          src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80"
          alt="Collaborative workshop in progress"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.values}>
      <h2>What we stand for</h2>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Transparency</h3>
          <p>We equip teams with clear assessments, defined expectations, and open dialogue frameworks.</p>
        </article>
        <article>
          <h3>Collaboration</h3>
          <p>We believe in partnerships where creativity, strategy, and operations move in sync.</p>
        </article>
        <article>
          <h3>Growth</h3>
          <p>We nurture enduring relationships that unlock brand growth and inspire purposeful work.</p>
        </article>
      </div>
    </section>

    <section className={styles.team}>
      <h2>Meet the team</h2>
      <div className={styles.teamGrid}>
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.card}>
            <img src={member.image} alt={`${member.name} portrait`} loading="lazy" />
            <div className={styles.cardContent}>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.story}>
      <div className={styles.storyText}>
        <h2>Our story</h2>
        <p>
          After years of working inside creative agencies and client-side marketing teams, our founders noticed a common
          pattern: brilliant ideas were often lost in translation. AdAgencyHub emerged as a platform to bridge strategy,
          creative execution, and measurable impact.
        </p>
        <p>
          Today we collaborate with agencies from Brussels to Liège, fostering ecosystems where ambition, empathy, and
          originality thrive together.
        </p>
      </div>
      <div className={styles.storyImage}>
        <img
          src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=1200&q=80"
          alt="Creative team collaborating around laptops"
          loading="lazy"
        />
      </div>
    </section>
  </div>
);

export default About;