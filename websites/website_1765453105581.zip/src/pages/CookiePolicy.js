import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LegalText.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | AdAgencyHub</title>
      <meta
        name="description"
        content="Understand how AdAgencyHub uses cookies to deliver functionality and analytics on our platform."
      />
    </Helmet>
    <article className={styles.article}>
      <h1>Cookie Policy</h1>
      <p>Last updated: 1 May 2024</p>

      <h2>1. What are cookies?</h2>
      <p>
        Cookies are small text files stored on your device when you visit our Platform. They help us remember preferences,
        understand engagement, and improve usability.
      </p>

      <h2>2. Types of cookies we use</h2>
      <ul>
        <li>
          <strong>Essential cookies:</strong> Required for core functionality such as navigation and secure sessions.
        </li>
        <li>
          <strong>Analytics cookies:</strong> Provide aggregated statistics on how visitors interact with our content.
        </li>
        <li>
          <strong>Preference cookies:</strong> Remember your language and cookie consent choices.
        </li>
      </ul>

      <h2>3. Managing cookies</h2>
      <p>
        You can adjust cookie settings in your browser to block or delete cookies. Note that disabling certain cookies may
        impact your experience on the Platform.
      </p>

      <h2>4. Third-party technologies</h2>
      <p>
        We may use trusted third-party analytics tools that set their own cookies. These providers are contractually
        bound to use data only for agreed purposes and in accordance with applicable laws.
      </p>

      <h2>5. Updates</h2>
      <p>
        We will update this policy if we introduce new cookies or modify existing ones. The latest version will always be
        available on this page.
      </p>

      <h2>6. Contact</h2>
      <p>
        Questions about cookies can be sent to contact@ad-agencyhub.com with “Cookie Policy” in the subject line.
      </p>
    </article>
  </div>
);

export default CookiePolicy;