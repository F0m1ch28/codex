import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <span className={styles.logo}>AdAgencyHub</span>
        <p>
          Your trusted gateway to the creative advertising landscape across Belgium. We build meaningful
          bridges between ambitious brands and visionary agency teams.
        </p>
        <div className={styles.contactInfo}>
          <span>Brussels, Belgium</span>
          <span>+32 456 78 90 12</span>
          <span>contact@ad-agencyhub.com</span>
        </div>
      </div>
      <div className={styles.links}>
        <h4>Explore</h4>
        <NavLink to="/guide">Agency Guide</NavLink>
        <NavLink to="/programs">Programs</NavLink>
        <NavLink to="/tools">Tools</NavLink>
        <NavLink to="/blog">Blog</NavLink>
      </div>
      <div className={styles.links}>
        <h4>Company</h4>
        <NavLink to="/about">About</NavLink>
        <NavLink to="/services">Services</NavLink>
        <NavLink to="/legal">Legal</NavLink>
        <NavLink to="/contact">Contact</NavLink>
      </div>
      <div className={styles.social}>
        <h4>Social</h4>
        <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
          LinkedIn
        </a>
        <a href="https://twitter.com" target="_blank" rel="noreferrer">
          Twitter / X
        </a>
        <a href="https://www.instagram.com" target="_blank" rel="noreferrer">
          Instagram
        </a>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} AdAgencyHub. All rights reserved.</span>
    </div>
  </footer>
);

export default Footer;