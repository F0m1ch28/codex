import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(() => {
    const stored = typeof window !== 'undefined' ? localStorage.getItem('aah_cookie_consent') : null;
    return stored !== 'accepted';
  });

  const handleAccept = () => {
    localStorage.setItem('aah_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <p>
        We use cookies to enhance your browsing experience and understand engagement. Review our{' '}
        <Link to="/cookie-policy">Cookie Policy</Link> to learn more.
      </p>
      <button onClick={handleAccept} className={styles.button} type="button">
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;