import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoAccent}>Ad</span>AgencyHub
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Main navigation">
          <NavLink onClick={closeMenu} to="/" className={({ isActive }) => (isActive ? styles.active : '')}>
            Home
          </NavLink>
          <NavLink onClick={closeMenu} to="/guide" className={({ isActive }) => (isActive ? styles.active : '')}>
            Guide
          </NavLink>
          <NavLink onClick={closeMenu} to="/programs" className={({ isActive }) => (isActive ? styles.active : '')}>
            Programs
          </NavLink>
          <NavLink onClick={closeMenu} to="/tools" className={({ isActive }) => (isActive ? styles.active : '')}>
            Tools
          </NavLink>
          <NavLink onClick={closeMenu} to="/blog" className={({ isActive }) => (isActive ? styles.active : '')}>
            Blog
          </NavLink>
          <NavLink onClick={closeMenu} to="/services" className={({ isActive }) => (isActive ? styles.active : '')}>
            Services
          </NavLink>
          <NavLink onClick={closeMenu} to="/about" className={({ isActive }) => (isActive ? styles.active : '')}>
            About
          </NavLink>
          <NavLink onClick={closeMenu} to="/contact" className={({ isActive }) => (isActive ? styles.active : '')}>
            Contact
          </NavLink>
          <NavLink onClick={closeMenu} to="/legal" className={({ isActive }) => (isActive ? styles.active : '')}>
            Legal
          </NavLink>
        </nav>
        <button
          className={`${styles.burger} ${menuOpen ? styles.burgerOpen : ''}`}
          onClick={toggleMenu}
          aria-label="Toggle navigation menu"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;