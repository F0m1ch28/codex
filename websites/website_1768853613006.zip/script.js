document.addEventListener('DOMContentLoaded', function () {
  var navToggle = document.querySelector('.nav-toggle');
  var navigation = document.getElementById('primary-navigation');
  if (navToggle && navigation) {
    navToggle.addEventListener('click', function () {
      var expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navigation.classList.toggle('open');
    });
  }

  var cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    var consent = localStorage.getItem('fe_cookie_consent');
    if (consent === 'accepted' || consent === 'declined') {
      cookieBanner.classList.add('hidden');
    }

    cookieBanner.addEventListener('click', function (event) {
      var target = event.target;
      if (!(target instanceof HTMLElement)) {
        return;
      }
      var choice = target.getAttribute('data-cookie-consent');
      if (!choice) {
        return;
      }
      if (choice === 'accept') {
        localStorage.setItem('fe_cookie_consent', 'accepted');
      } else if (choice === 'decline') {
        localStorage.setItem('fe_cookie_consent', 'declined');
      }
      cookieBanner.classList.add('hidden');
    });
  }

  var yearSpan = document.getElementById('current-year');
  if (yearSpan) {
    yearSpan.textContent = String(new Date().getFullYear());
  }
});