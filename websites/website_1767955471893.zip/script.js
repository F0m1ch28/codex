document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('.site-header');
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-link');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');

    function handleScroll() {
        if (window.scrollY > 30) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    }

    window.addEventListener('scroll', handleScroll);
    handleScroll();

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            siteNav.classList.toggle('open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('open')) {
                    siteNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner && acceptBtn && declineBtn) {
        const storedChoice = localStorage.getItem('pitcheejoz-cookie-choice');
        if (storedChoice) {
            cookieBanner.classList.add('hidden');
        }

        const handleCookieChoice = (choice) => {
            localStorage.setItem('pitcheejoz-cookie-choice', choice);
            cookieBanner.classList.add('hidden');
            window.open('cookies.html', '_blank');
        };

        acceptBtn.addEventListener('click', () => handleCookieChoice('accepted'));
        declineBtn.addEventListener('click', () => handleCookieChoice('declined'));
    }
});