import { useEffect } from "react";

const setMetaTag = (attribute, key, value) => {
  let element = document.head.querySelector(`meta[${attribute}=`${key}"]");
  if (!element) {
    element = document.createElement("meta");
    element.setAttribute(attribute, key);
    document.head.appendChild(element);
  }
  element.setAttribute("content", value);
};

const usePageMeta = (title, description) => {
  useEffect(() => {
    document.title = title;
    setMetaTag("name", "description", description);
    setMetaTag("property", "og:title", title);
    setMetaTag("property", "og:description", description);
    setMetaTag("property", "og:type", "website");
    setMetaTag("property", "og:locale", "en_CA");
  }, [title, description]);
};

export default usePageMeta;