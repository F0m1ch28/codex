import React, { useEffect, useState } from "react";

const STORAGE_KEY = "talentscope-cookie-consent";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 bg-white shadow-xl">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4 px-6 py-4">
        <p className="text-sm text-gray-700">
          TalentScope Diagnostics uses essential cookies to support site
          functionality and to understand aggregate usage. No personal data is
          sold or shared beyond analytics tools.
        </p>
        <div className="flex flex-shrink-0 items-center gap-3">
          <button
            onClick={handleDecline}
            className="rounded-md border border-gray-300 px-4 py-2 text-xs font-semibold text-gray-700 transition hover:bg-gray-100"
          >
            Decline
          </button>
          <button
            onClick={handleAccept}
            className="rounded-md px-4 py-2 text-xs font-semibold text-white transition"
            style={{ backgroundColor: "#1B5E20" }}
          >
            Accept
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;