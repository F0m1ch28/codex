import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer
      className="border-t border-gray-200"
      style={{ backgroundColor: "#F5F5DC" }}
    >
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <h3 className="text-lg font-semibold text-green-900">
              TalentScope Diagnostics
            </h3>
            <p className="mt-3 text-sm text-gray-700">
              Workforce development diagnostics, training needs analysis, and
              professional growth monitoring designed for Canadian teams.
            </p>
            <div className="mt-4 text-sm text-gray-800">
              <p>123 Scope St</p>
              <p>Edmonton, AB T5J 3R8, Canada</p>
              <p className="mt-3">Phone: +1 780 555 7890</p>
              <p>Email: Please use the contact form</p>
            </div>
          </div>
          <div>
            <h4 className="text-base font-semibold text-green-900">
              Explore
            </h4>
            <ul className="mt-3 space-y-2 text-sm text-gray-700">
              <li>
                <Link className="hover:text-green-800" to="/services">
                  Services
                </Link>
              </li>
              <li>
                <Link className="hover:text-green-800" to="/solutions">
                  Solutions
                </Link>
              </li>
              <li>
                <Link className="hover:text-green-800" to="/case-studies">
                  Case Studies
                </Link>
              </li>
              <li>
                <Link className="hover:text-green-800" to="/contact">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-base font-semibold text-green-900">
              Compliance
            </h4>
            <ul className="mt-3 space-y-2 text-sm text-gray-700">
              <li>
                <Link className="hover:text-green-800" to="/privacy-policy">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link className="hover:text-green-800" to="/cookie-policy">
                  Cookie Policy
                </Link>
              </li>
              <li>
                <Link className="hover:text-green-800" to="/terms-of-service">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <p className="mt-10 text-center text-xs text-gray-600">
          © {new Date().getFullYear()} TalentScope Diagnostics. All rights
          reserved.
        </p>
      </div>
    </footer>
  );
}

export default Footer;