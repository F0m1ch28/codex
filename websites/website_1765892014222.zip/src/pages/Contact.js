import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import usePageMeta from "../hooks/usePageMeta";

function Contact() {
  usePageMeta(
    "Contact TalentScope Diagnostics",
    "Contact TalentScope Diagnostics in Edmonton, Alberta to discuss workforce development diagnostics, training needs analysis, and retention insights."
  );

  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Name is required.";
    if (!formData.email.trim()) newErrors.email = "Email is required.";
    if (
      formData.email &&
      !/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(formData.email)
    ) {
      newErrors.email = "Enter a valid email.";
    }
    if (!formData.company.trim()) newErrors.company = "Company is required.";
    if (!formData.message.trim()) newErrors.message = "Message is required.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;

    navigate("/thank-you", {
      state: {
        name: formData.name,
      },
    });
  };

  return (
    <div className="bg-white">
      <section className="py-16">
        <div className="mx-auto max-w-5xl px-6">
          <h1 className="text-4xl font-semibold text-green-900">Contact Us</h1>
          <p className="mt-4 text-base text-gray-700">
            Share your workforce priorities and our Edmonton-based team will
            respond with a tailored diagnostic approach.
          </p>
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-12 md:grid-cols-2">
            <form
              onSubmit={handleSubmit}
              className="rounded-3xl border border-gray-100 bg-white p-8 shadow-lg"
            >
              <h2 className="text-2xl font-semibold text-green-900">
                Consultation Request
              </h2>
              <p className="mt-2 text-sm text-gray-600">
                Complete the form and we will reach out to schedule a
                conversation.
              </p>

              <div className="mt-6 space-y-4">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-semibold text-gray-700"
                  >
                    Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-md border border-gray-300 px-4 py-3 text-sm focus:border-green-900 focus:outline-none focus:ring-1 focus:ring-green-900"
                    placeholder="Your full name"
                    required
                  />
                  {errors.name && (
                    <p className="mt-1 text-xs text-red-600">{errors.name}</p>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-semibold text-gray-700"
                  >
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-md border border-gray-300 px-4 py-3 text-sm focus:border-green-900 focus:outline-none focus:ring-1 focus:ring-green-900"
                    placeholder="you@example.com"
                    required
                  />
                  {errors.email && (
                    <p className="mt-1 text-xs text-red-600">{errors.email}</p>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="company"
                    className="block text-sm font-semibold text-gray-700"
                  >
                    Company / Organization
                  </label>
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-md border border-gray-300 px-4 py-3 text-sm focus:border-green-900 focus:outline-none focus:ring-1 focus:ring-green-900"
                    placeholder="Organization name"
                    required
                  />
                  {errors.company && (
                    <p className="mt-1 text-xs text-red-600">
                      {errors.company}
                    </p>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-semibold text-gray-700"
                  >
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-md border border-gray-300 px-4 py-3 text-sm focus:border-green-900 focus:outline-none focus:ring-1 focus:ring-green-900"
                    placeholder="Describe your workforce context and priorities"
                    required
                  />
                  {errors.message && (
                    <p className="mt-1 text-xs text-red-600">
                      {errors.message}
                    </p>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="mt-6 w-full rounded-md px-6 py-3 text-sm font-semibold text-white transition hover:shadow-lg"
                style={{ backgroundColor: "#1B5E20" }}
              >
                Submit request
              </button>
            </form>

            <div className="rounded-3xl bg-white p-8 shadow-sm">
              <h2 className="text-2xl font-semibold text-green-900">
                Contact Details
              </h2>
              <p className="mt-4 text-sm text-gray-700">
                TalentScope Diagnostics is headquartered in Edmonton, Alberta.
                We collaborate with organizations across Canada through onsite
                visits and secure virtual sessions.
              </p>
              <div className="mt-6 space-y-4 text-sm text-gray-800">
                <div>
                  <h3 className="font-semibold text-green-900">Address</h3>
                  <p>123 Scope St</p>
                  <p>Edmonton, AB T5J 3R8, Canada</p>
                </div>
                <div>
                  <h3 className="font-semibold text-green-900">Phone</h3>
                  <p>+1 780 555 7890</p>
                </div>
                <div>
                  <h3 className="font-semibold text-green-900">Email</h3>
                  <p>Use the contact form to connect with our team.</p>
                </div>
              </div>
              <div className="mt-8 rounded-2xl border border-gray-200 bg-gray-50 p-6">
                <h3 className="text-base font-semibold text-green-900">
                  Office Hours
                </h3>
                <p className="mt-3 text-sm text-gray-700">
                  Monday to Friday, 8:30 AM – 5:00 PM Mountain Time. Virtual
                  sessions available upon request.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;