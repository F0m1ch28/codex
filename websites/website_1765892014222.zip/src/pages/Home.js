import React from "react";
import { Link } from "react-router-dom";
import usePageMeta from "../hooks/usePageMeta";

function Home() {
  usePageMeta(
    "TalentScope Diagnostics | Workforce Development Diagnostics in Canada",
    "Evidence-based workforce development diagnostics, training needs analysis, employee retention insights, and professional growth monitoring tailored for Canadian teams."
  );

  const features = [
    {
      title: "Training Needs Analysis",
      description:
        "Structured diagnostics uncover competency gaps, readiness levels, and program alignment for varied Canadian workforce segments.",
      icon: "https://cdn-icons-png.flaticon.com/512/992/992700.png",
    },
    {
      title: "Employee Retention Insights",
      description:
        "Retention analytics reveal engagement indicators, churn triggers, and intervention priorities by department or region.",
      icon: "https://cdn-icons-png.flaticon.com/512/3523/3523063.png",
    },
    {
      title: "Professional Growth Monitoring",
      description:
        "Longitudinal dashboards monitor certification status, skill progression, and role preparedness across teams.",
      icon: "https://cdn-icons-png.flaticon.com/512/747/747376.png",
    },
  ];

  const testimonials = [
    {
      quote:
        "“Our operations division used TalentScope Diagnostics to map skill proficiency across shift teams, leading to precise training plans that aligned with regulated standards.”",
      name: "Director of Workforce Planning",
      company: "Western Infrastructure Cooperative",
    },
    {
      quote:
        "“The retention dashboards clarified turnover indicators by location, helping us stage timely coaching programs and mentorship scheduling.”",
      name: "People Development Lead",
      company: "Prairie Health Consortium",
    },
  ];

  const dataHighlights = [
    {
      title: "Skills Benchmarking",
      text: "Compare team capability against national occupational standards and track recurring compliance requirements.",
      image:
        "https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "Engagement Analytics",
      text: "Visualize sentiment patterns and retention indicators with clean, interactive dashboards suitable for executive briefings.",
      image:
        "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "Capability Pathways",
      text: "Model task readiness and succession pipelines using synthesized survey data, performance audits, and credential milestones.",
      image:
        "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80",
    },
  ];

  return (
    <div>
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              'url("https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80")',
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-black opacity-40" />
        <div className="relative mx-auto flex max-w-6xl flex-col gap-10 px-6 py-24 text-white md:flex-row md:items-center">
          <div className="md:w-3/5">
            <span className="inline-flex items-center rounded-full px-4 py-1 text-xs font-semibold uppercase tracking-widest text-white"
              style={{ backgroundColor: "#1B5E20" }}
            >
              Workforce development diagnostics
            </span>
            <h1 className="mt-6 text-4xl font-bold leading-tight md:text-5xl">
              Data-informed diagnostics for sustainable workforce capability.
            </h1>
            <p className="mt-4 max-w-xl text-lg text-gray-100">
              TalentScope Diagnostics equips Canadian organizations with
              training needs analysis, employee retention insights, and
              professional growth monitoring backed by precise, repeatable
              methodology.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                to="/contact"
                className="rounded-md px-6 py-3 text-sm font-semibold text-white transition hover:shadow-lg"
                style={{ backgroundColor: "#1B5E20" }}
              >
                Request a consultation
              </Link>
              <Link
                to="/case-studies"
                className="rounded-md border border-white px-6 py-3 text-sm font-semibold text-white transition hover:bg-white hover:text-green-900"
              >
                Explore case studies
              </Link>
            </div>
          </div>
          <div className="md:w-2/5">
            <div className="space-y-4 rounded-xl bg-white/10 p-6 backdrop-blur">
              <h2 className="text-xl font-semibold">Canadian insight snapshot</h2>
              <ul className="space-y-3 text-sm text-gray-100">
                <li className="flex items-start gap-3">
                  <span className="mt-1 h-2 w-2 rounded-full" style={{ backgroundColor: "#F5F5DC" }} />
                  120+ diagnostic modules tailored for provincial regulatory
                  frameworks.
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 h-2 w-2 rounded-full" style={{ backgroundColor: "#F5F5DC" }} />
                  Configurable dashboards for leadership, HR, and departmental
                  managers.
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 h-2 w-2 rounded-full" style={{ backgroundColor: "#F5F5DC" }} />
                  Longitudinal tracking that aligns workforce goals with
                  professional development plans.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-8 md:grid-cols-3">
            {features.map((feature) => (
              <article
                key={feature.title}
                className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <img
                  src={feature.icon}
                  alt={`${feature.title} icon`}
                  className="h-12 w-12"
                />
                <h3 className="mt-6 text-xl font-semibold text-green-900">
                  {feature.title}
                </h3>
                <p className="mt-3 text-sm text-gray-700">
                  {feature.description}
                </p>
                <Link
                  to="/services"
                  className="mt-5 inline-flex items-center text-sm font-semibold text-green-900 hover:underline"
                >
                  Learn more
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className="py-20"
        style={{ backgroundColor: "#F5F5DC" }}
      >
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-10 md:grid-cols-2 md:items-center">
            <div>
              <h2 className="text-3xl font-semibold text-green-900">
                Workforce development diagnostics overview
              </h2>
              <p className="mt-4 text-base text-gray-700">
                Our diagnostic framework combines quantitative assessments,
                qualitative interviews, and compliance audits. We produce
                structured summaries that identify skill priorities, training
                readiness, and retention considerations. Dashboards highlight
                scenario planning, role-based competencies, and certification
                status.
              </p>
              <p className="mt-4 text-base text-gray-700">
                TalentScope Diagnostics maintains alignment with Canadian
                employment standards, sector-specific accreditation, and
                provincial workforce strategies. Every recommendation is
                grounded in measurable indicators and transparent methodologies.
              </p>
            </div>
            <div className="rounded-2xl bg-white p-6 shadow-lg">
              <h3 className="text-xl font-semibold text-green-900">
                Diagnostic stages
              </h3>
              <ul className="mt-4 space-y-4 text-sm text-gray-700">
                <li className="flex items-start gap-3">
                  <span
                    className="mt-1 inline-flex h-3 w-3 flex-shrink-0 rounded-full"
                    style={{ backgroundColor: "#1B5E20" }}
                  />
                  Workforce pulse survey: gauge skill confidence, engagement,
                  and key retention signals.
                </li>
                <li className="flex items-start gap-3">
                  <span
                    className="mt-1 inline-flex h-3 w-3 flex-shrink-0 rounded-full"
                    style={{ backgroundColor: "#1B5E20" }}
                  />
                  Capability assessment: map competencies against role
                  requirements and regulatory expectations.
                </li>
                <li className="flex items-start gap-3">
                  <span
                    className="mt-1 inline-flex h-3 w-3 flex-shrink-0 rounded-full"
                    style={{ backgroundColor: "#1B5E20" }}
                  />
                  Insights synthesis: deliver prioritised actions, visual
                  dashboards, and progress tracking plans.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-6">
          <div className="flex flex-col gap-16">
            {dataHighlights.map((item, index) => (
              <div
                key={item.title}
                className={`grid gap-8 md:grid-cols-2 md:items-center ${
                  index % 2 === 1 ? "md:flex-row-reverse" : ""
                }`}
              >
                <div>
                  <img
                    src={item.image}
                    alt={item.title}
                    className="h-full w-full rounded-3xl object-cover shadow-lg"
                  />
                </div>
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-green-800">
                    Visual Analytics
                  </span>
                  <h3 className="mt-3 text-2xl font-semibold text-green-900">
                    {item.title}
                  </h3>
                  <p className="mt-4 text-base text-gray-700">{item.text}</p>
                  <Link
                    to="/solutions"
                    className="mt-5 inline-flex items-center text-sm font-semibold text-green-900 hover:underline"
                  >
                    View diagnostic solutions
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className="py-20"
        style={{ backgroundColor: "#F5F5DC" }}
      >
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-10 md:grid-cols-2 md:items-center">
            <div>
              <h2 className="text-3xl font-semibold text-green-900">
                Canadian workforce focus
              </h2>
              <p className="mt-4 text-base text-gray-700">
                TalentScope Diagnostics collaborates with national, provincial,
                and municipal organizations across Canada. Our datasets capture
                labour market trends, remote work requirements, and bilingual
                capability planning where relevant.
              </p>
              <p className="mt-4 text-base text-gray-700">
                Edmonton-based specialists coordinate fieldwork, virtual
                workshops, and stakeholder consultations. Reports incorporate
                accessible language and structured data visuals for quick
                adoption by leadership teams.
              </p>
            </div>
            <div className="rounded-3xl bg-white p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-green-900">
                Regional engagement summary
              </h3>
              <div className="mt-6 grid grid-cols-2 gap-6 text-sm text-gray-700">
                <div>
                  <p className="text-4xl font-semibold text-green-900">8</p>
                  <p className="mt-2">
                    Provinces represented in recent diagnostics projects.
                  </p>
                </div>
                <div>
                  <p className="text-4xl font-semibold text-green-900">36</p>
                  <p className="mt-2">
                    Sector-specific benchmarking libraries available for
                    customization.
                  </p>
                </div>
                <div>
                  <p className="text-4xl font-semibold text-green-900">120</p>
                  <p className="mt-2">
                    Custom dashboards produced over the past two planning
                    cycles.
                  </p>
                </div>
                <div>
                  <p className="text-4xl font-semibold text-green-900">24</p>
                  <p className="mt-2">
                    Facilitation toolkits covering coaching, mentorship, and
                    professional growth.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-8 md:grid-cols-2">
            {testimonials.map((testimonial, index) => (
              <blockquote
                key={index}
                className="rounded-2xl border border-gray-100 bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-md"
              >
                <p className="text-base text-gray-700">{testimonial.quote}</p>
                <footer className="mt-6 text-sm font-semibold text-green-900">
                  {testimonial.name}
                  <span className="block text-xs font-normal text-gray-500">
                    {testimonial.company}
                  </span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section
        className="py-20"
        style={{ backgroundColor: "#1B5E20" }}
      >
        <div className="mx-auto max-w-5xl px-6 text-center text-white">
          <h2 className="text-3xl font-semibold">
            Plan your workforce diagnostics engagement
          </h2>
          <p className="mt-4 text-base text-white/90">
            Connect with our Edmonton team to review your workforce context,
            identify diagnostic modules, and schedule a scoped assessment plan.
            We collaborate with HR leaders, operational managers, and learning
            specialists across Canada.
          </p>
          <div className="mt-8">
            <Link
              to="/contact"
              className="inline-flex items-center rounded-md bg-white px-6 py-3 text-sm font-semibold text-green-900 transition hover:-translate-y-1 hover:shadow-lg"
            >
              Start the conversation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;