import React from "react";
import usePageMeta from "../hooks/usePageMeta";

function About() {
  usePageMeta(
    "About TalentScope Diagnostics",
    "Learn about TalentScope Diagnostics, an Edmonton-based workforce diagnostics partner supporting Canadian organizations with training, retention, and professional growth insights."
  );

  return (
    <div className="bg-white">
      <section className="relative bg-gray-900 py-20 text-white">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=80"
            alt="Edmonton skyline abstract"
            className="h-full w-full object-cover opacity-30"
          />
        </div>
        <div className="relative mx-auto max-w-5xl px-6 text-center">
          <h1 className="text-4xl font-semibold">About TalentScope Diagnostics</h1>
          <p className="mt-4 text-lg text-white/80">
            We equip Canadian organizations with adept workforce diagnostics,
            translating complex data into actionable training pathways and
            retention strategies.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-5xl px-6">
          <h2 className="text-3xl font-semibold text-green-900">Our Story</h2>
          <p className="mt-4 text-base text-gray-700">
            TalentScope Diagnostics was founded in Edmonton to address the
            growing need for clear, evidence-based workforce insights across
            Canada. Our specialists combine expertise in organizational
            psychology, adult learning, analytics, and change management. We
            translate workforce data into structured narratives, ensuring teams
            across industries can navigate skill development, retention, and
            professional growth with confidence.
          </p>
          <p className="mt-4 text-base text-gray-700">
            We operate from 123 Scope St, Edmonton, AB, serving clients across
            provinces and territories. Our engagements span public agencies,
            regulated utilities, healthcare networks, and technology firms with
            distributed teams.
          </p>

          <div className="mt-12 grid gap-8 md:grid-cols-2">
            <div className="rounded-2xl border border-gray-100 p-8 shadow-sm">
              <h3 className="text-xl font-semibold text-green-900">
                Diagnostic Philosophy
              </h3>
              <p className="mt-4 text-sm text-gray-700">
                Diagnostics should be rigorous without being opaque. We design
                processes that are transparent, inclusive, and adaptable for
                each workforce environment. By capturing qualitative narratives
                alongside quantitative metrics, we provide comprehensive insight
                into capability, engagement, and progression.
              </p>
            </div>
            <div className="rounded-2xl border border-gray-100 p-8 shadow-sm">
              <h3 className="text-xl font-semibold text-green-900">
                Multidisciplinary Team
              </h3>
              <p className="mt-4 text-sm text-gray-700">
                Our consultants bring backgrounds in labour relations, data
                science, adult education, and leadership development. Each
                diagnostic engagement pairs analysts with facilitators to ensure
                findings translate into clear implementation steps for managers
                and learning coordinators.
              </p>
            </div>
          </div>

          <div className="mt-16 grid gap-10 md:grid-cols-3">
            <div>
              <h4 className="text-sm font-semibold uppercase tracking-wide text-green-900">
                Purpose
              </h4>
              <p className="mt-4 text-sm text-gray-700">
                Provide accessible workforce intelligence that supports the
                development of resilient, capable teams in Canadian
                organizations.
              </p>
            </div>
            <div>
              <h4 className="text-sm font-semibold uppercase tracking-wide text-green-900">
                Approach
              </h4>
              <p className="mt-4 text-sm text-gray-700">
                Facilitate inclusive engagement, leverage robust analytics, and
                deliver clear narratives that align stakeholders on next steps.
              </p>
            </div>
            <div>
              <h4 className="text-sm font-semibold uppercase tracking-wide text-green-900">
                Values
              </h4>
              <p className="mt-4 text-sm text-gray-700">
                Integrity, collaboration, cultural awareness, and measurable
                outcomes grounded in evidence.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section
        className="py-16"
        style={{ backgroundColor: "#F5F5DC" }}
      >
        <div className="mx-auto max-w-5xl px-6">
          <h2 className="text-3xl font-semibold text-green-900">
            Our Diagnostics Leadership
          </h2>
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-green-900">
                Caroline Singh, Principal Diagnostic Strategist
              </h3>
              <p className="mt-3 text-sm text-gray-700">
                Caroline guides cross-province diagnostic initiatives with a
                focus on compliance-sensitive sectors. Her expertise in adult
                learning ensures talent development recommendations are practical
                and measurable.
              </p>
            </div>
            <div className="rounded-2xl bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-green-900">
                Andre Pelletier, Workforce Analytics Lead
              </h3>
              <p className="mt-3 text-sm text-gray-700">
                Andre designs analytic models that align workforce metrics with
                organizational objectives. He brings a background in labour
                market analysis and data architecture for enterprise clients.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl px-6 text-center">
          <h2 className="text-3xl font-semibold text-green-900">
            Collaboration Across Canada
          </h2>
          <p className="mt-4 text-base text-gray-700">
            TalentScope Diagnostics partners with leaders in human resources,
            operations, academic institutions, and sector councils. Our approach
            adapts to remote, hybrid, and site-based environments, ensuring
            insights stay relevant amid workforce shifts.
          </p>
        </div>
      </section>
    </div>
  );
}

export default About;