import React from "react";
import usePageMeta from "../hooks/usePageMeta";

function PrivacyPolicy() {
  usePageMeta(
    "Privacy Policy | TalentScope Diagnostics",
    "Read the privacy policy for TalentScope Diagnostics covering data handling, confidentiality, and user rights."
  );

  return (
    <div className="bg-white">
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-6">
          <h1 className="text-4xl font-semibold text-green-900">
            Privacy Policy
          </h1>
          <p className="mt-4 text-sm text-gray-700">
            Effective date: {new Date().getFullYear()}
          </p>

          <div className="mt-8 space-y-6 text-sm text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Overview
              </h2>
              <p className="mt-3">
                TalentScope Diagnostics respects your privacy. This policy
                explains how we collect, use, and protect personal information
                provided through our website and during diagnostic engagements.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Data Collection
              </h2>
              <p className="mt-3">
                We collect personal information supplied voluntarily through
                contact forms, email correspondence, or diagnostic project
                activities. This may include contact details, organizational
                information, and project-specific data required for workforce
                analysis.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Use of Information
              </h2>
              <p className="mt-3">
                Information is used to respond to inquiries, provide diagnostic
                services, and meet contractual obligations. We may anonymize
                data for aggregate reporting and benchmarking while ensuring no
                individual is identifiable.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Data Sharing
              </h2>
              <p className="mt-3">
                We do not sell personal information. Data may be shared with
                trusted partners engaged to deliver diagnostics or technology
                services, subject to confidentiality agreements. Disclosure may
                occur if required by law or to protect our rights.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Security
              </h2>
              <p className="mt-3">
                We implement technical and organizational measures to safeguard
                information, including secure storage, access controls, and
                encryption during transfer where appropriate. While no system is
                entirely immune to risk, we continuously review our safeguards.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Cookies
              </h2>
              <p className="mt-3">
                We use essential cookies to enable website functionality and
                collect anonymized usage data. You may manage cookie preferences
                through your browser settings. See our Cookie Policy for more
                details.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Your Rights
              </h2>
              <p className="mt-3">
                You may request access to your information, ask for corrections,
                or withdraw consent by contacting us. We will respond within
                reasonable timelines consistent with Canadian privacy laws.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Contact
              </h2>
              <p className="mt-3">
                For privacy inquiries, please contact us at 123 Scope St,
                Edmonton, AB T5J 3R8, Canada or by phone at +1 780 555 7890.
                Alternatively, submit a request through our contact form.
              </p>
            </section>
          </div>
        </div>
      </section>
    </div>
  );
}

export default PrivacyPolicy;