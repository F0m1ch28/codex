import React from "react";
import { useLocation, Link } from "react-router-dom";
import usePageMeta from "../hooks/usePageMeta";

function ThankYou() {
  usePageMeta(
    "Thank You | TalentScope Diagnostics",
    "Thank you for contacting TalentScope Diagnostics. A specialist will connect with you soon."
  );

  const { state } = useLocation();
  const name = state?.name || "Thank you";

  return (
    <div
      className="flex min-h-[60vh] items-center justify-center px-6"
      style={{ backgroundColor: "#F5F5DC" }}
    >
      <div className="max-w-xl rounded-3xl bg-white p-10 text-center shadow-lg">
        <h1 className="text-3xl font-semibold text-green-900">{name}!</h1>
        <p className="mt-4 text-base text-gray-700">
          We appreciate your message. A TalentScope Diagnostics specialist will
          review your request and respond shortly with next steps.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex items-center rounded-md px-6 py-3 text-sm font-semibold text-white transition hover:shadow-lg"
          style={{ backgroundColor: "#1B5E20" }}
        >
          Return to homepage
        </Link>
      </div>
    </div>
  );
}

export default ThankYou;