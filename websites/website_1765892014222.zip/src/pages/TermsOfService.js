import React from "react";
import usePageMeta from "../hooks/usePageMeta";

function TermsOfService() {
  usePageMeta(
    "Terms of Service | TalentScope Diagnostics",
    "Read the terms governing use of the TalentScope Diagnostics website and services."
  );

  return (
    <div className="bg-white">
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-6">
          <h1 className="text-4xl font-semibold text-green-900">
            Terms of Service
          </h1>
          <p className="mt-4 text-sm text-gray-700">
            Effective date: {new Date().getFullYear()}
          </p>

          <div className="mt-8 space-y-6 text-sm text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Acceptance of Terms
              </h2>
              <p className="mt-3">
                By accessing the TalentScope Diagnostics website, you agree to
                these Terms of Service. If you do not agree, please refrain from
                using the site.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Services
              </h2>
              <p className="mt-3">
                Information on this site describes workforce diagnostics,
                training analysis, retention insights, and professional growth
                monitoring services. Details may change without notice. Specific
                engagements are subject to written agreements.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Intellectual Property
              </h2>
              <p className="mt-3">
                Content on this site, including text, graphics, and layouts, is
                owned or licensed by TalentScope Diagnostics. Unauthorized use
                is prohibited. You may download or print content for personal or
                organizational reference.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                User Responsibilities
              </h2>
              <p className="mt-3">
                You agree to use the site lawfully and not to interfere with its
                operation. Submissions through the contact form must be accurate
                and not infringe on the rights of others.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Limitation of Liability
              </h2>
              <p className="mt-3">
                TalentScope Diagnostics provides the site “as is” without
                warranties. We are not liable for damages arising from use of
                the site, except as required by law. Diagnostic outcomes depend
                on data accuracy and collaboration with organizational
                stakeholders.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Third-Party Links
              </h2>
              <p className="mt-3">
                Our site may link to third-party resources. We do not control
                those sites and are not responsible for their content or
                practices.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Changes to Terms
              </h2>
              <p className="mt-3">
                We may update these Terms of Service periodically. Continued use
                of the site constitutes acceptance of the revised terms.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Contact Information
              </h2>
              <p className="mt-3">
                Questions about these terms may be directed to TalentScope
                Diagnostics, 123 Scope St, Edmonton, AB T5J 3R8, Canada, or via
                phone at +1 780 555 7890.
              </p>
            </section>
          </div>
        </div>
      </section>
    </div>
  );
}

export default TermsOfService;