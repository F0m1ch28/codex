import React from "react";
import usePageMeta from "../hooks/usePageMeta";

function Services() {
  usePageMeta(
    "TalentScope Diagnostics Services",
    "Discover workforce development services from TalentScope Diagnostics, including training needs analysis, retention insights, and professional growth monitoring for Canadian teams."
  );

  const serviceGroups = [
    {
      title: "Training Needs Analysis",
      description:
        "Layered diagnostics covering competency mapping, role readiness, and learning pathway alignment.",
      items: [
        "Capability benchmarking against Canadian industry standards.",
        "Learning resource mapping with modality recommendations.",
        "Scenario-based action plans for prioritized roles.",
        "Training impact indicators to validate progression.",
      ],
    },
    {
      title: "Employee Retention Insights",
      description:
        "Sentiment reporting, exit pattern analysis, and predictive retention indicators for proactive planning.",
      items: [
        "Pulse survey design aligned with workforce segments.",
        "Retention risk dashboards by team, location, and tenure.",
        "Action planning guides covering mentorship and recognition.",
        "Comparative analysis with sector benchmarks when available.",
      ],
    },
    {
      title: "Professional Growth Monitoring",
      description:
        "Longitudinal tracking of certifications, coaching milestones, and performance outcomes.",
      items: [
        "Individual learning journeys integrating micro-credentials.",
        "Succession pipeline visibility across departments.",
        "Coaching frameworks for supervisors and team leads.",
        "Progress reports aligned to organizational competencies.",
      ],
    },
    {
      title: "Workforce Performance Assessment",
      description:
        "Comprehensive evaluation of workforce performance trends linked to strategic objectives.",
      items: [
        "Balanced scorecards with workforce metrics.",
        "Operational readiness checks for transformation programs.",
        "Capacity planning models for expansion or transition.",
        "Governance guidance for talent development compliance.",
      ],
    },
  ];

  return (
    <div className="bg-white">
      <section className="bg-gray-900 py-16 text-white">
        <div className="mx-auto max-w-5xl px-6">
          <h1 className="text-4xl font-semibold">Services Overview</h1>
          <p className="mt-4 text-lg text-white/75">
            TalentScope Diagnostics delivers modular services that connect
            workforce data to actionable development plans. Each engagement is
            rooted in rigorous analysis and collaborative implementation.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-10 md:grid-cols-2">
            {serviceGroups.map((service) => (
              <div
                key={service.title}
                className="flex flex-col rounded-3xl border border-gray-100 bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <h2 className="text-2xl font-semibold text-green-900">
                  {service.title}
                </h2>
                <p className="mt-4 text-sm text-gray-700">
                  {service.description}
                </p>
                <ul className="mt-6 space-y-3 text-sm text-gray-700">
                  {service.items.map((item) => (
                    <li key={item} className="flex items-start gap-3">
                      <span
                        className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full"
                        style={{ backgroundColor: "#1B5E20" }}
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className="py-16"
        style={{ backgroundColor: "#F5F5DC" }}
      >
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-8 md:grid-cols-2 md:items-center">
            <div>
              <h3 className="text-3xl font-semibold text-green-900">
                Engagement Model
              </h3>
              <p className="mt-4 text-base text-gray-700">
                Each service is delivered through a structured engagement model:
                discovery workshops, diagnostic fieldwork, synthesis and
                validation, and implementation coaching. We build alignment with
                HR teams, leadership sponsors, and front-line managers to ensure
                insights translate into action.
              </p>
            </div>
            <div className="rounded-3xl bg-white p-8 shadow-lg">
              <h4 className="text-xl font-semibold text-green-900">
                What to Expect
              </h4>
              <ul className="mt-4 space-y-3 text-sm text-gray-700">
                <li>Detailed project charter with milestones and success markers.</li>
                <li>Secure data handling practices that respect privacy obligations.</li>
                <li>Inclusive facilitation with bilingual options when required.</li>
                <li>Transferable playbooks to support long-term workforce planning.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl px-6 text-center">
          <h3 className="text-3xl font-semibold text-green-900">
            Ready to scope your workforce diagnostics program?
          </h3>
          <p className="mt-4 text-base text-gray-700">
            Connect with our Edmonton team to discuss timelines, stakeholders,
            and diagnostic modules that align with your organizational goals.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Services;