import React from "react";
import usePageMeta from "../hooks/usePageMeta";

function CookiePolicy() {
  usePageMeta(
    "Cookie Policy | TalentScope Diagnostics",
    "Review the cookie policy for TalentScope Diagnostics detailing essential and analytics cookies."
  );

  return (
    <div className="bg-white">
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-6">
          <h1 className="text-4xl font-semibold text-green-900">
            Cookie Policy
          </h1>
          <p className="mt-4 text-sm text-gray-700">
            Effective date: {new Date().getFullYear()}
          </p>

          <div className="mt-8 space-y-6 text-sm text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-green-900">
                What Are Cookies?
              </h2>
              <p className="mt-3">
                Cookies are small text files stored on your device when you
                visit our website. They help ensure the site functions properly
                and provide aggregated analytics on usage patterns.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Types of Cookies We Use
              </h2>
              <ul className="mt-3 space-y-2">
                <li>
                  <strong>Essential Cookies:</strong> Required for navigation,
                  security, and user preference management.
                </li>
                <li>
                  <strong>Analytics Cookies:</strong> Provide anonymized
                  insights into page visits and interaction trends, supporting
                  continuous improvement.
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Managing Cookies
              </h2>
              <p className="mt-3">
                You can manage or disable cookies through your browser settings.
                Some features may not function if essential cookies are
                disabled. Our cookie banner allows you to accept or decline
                optional cookies.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Updates
              </h2>
              <p className="mt-3">
                We may update this Cookie Policy as technologies evolve. Review
                this page periodically for the latest information.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-green-900">
                Contact
              </h2>
              <p className="mt-3">
                Questions regarding this policy can be directed to TalentScope
                Diagnostics, 123 Scope St, Edmonton, AB T5J 3R8, Canada, or by
                phone at +1 780 555 7890.
              </p>
            </section>
          </div>
        </div>
      </section>
    </div>
  );
}

export default CookiePolicy;