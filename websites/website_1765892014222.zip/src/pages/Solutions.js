import React from "react";
import usePageMeta from "../hooks/usePageMeta";

function Solutions() {
  usePageMeta(
    "TalentScope Diagnostics Solutions",
    "TalentScope Diagnostics offers data solutions for workforce development, including analytics playbooks, compliance dashboards, and professional growth tracking."
  );

  const solutionSets = [
    {
      category: "Analytics Frameworks",
      solutions: [
        "Competency radar charts comparing current and targeted proficiency levels.",
        "Attrition likelihood scoring with interpretive guidance for managers.",
        "Learning pathway simulators showing time-to-proficiency estimates.",
      ],
    },
    {
      category: "Interactive Dashboards",
      solutions: [
        "Role readiness dashboards tailored to provincial occupational standards.",
        "Professional development trackers with certification reminders.",
        "Engagement heatmaps segmented by tenure, location, and function.",
      ],
    },
    {
      category: "Implementation Toolkits",
      solutions: [
        "Facilitator guides for training alignment workshops.",
        "Retention conversation scripts and checklists for supervisors.",
        "Career progression templates integrating mentorship and coaching steps.",
      ],
    },
    {
      category: "Compliance Alignment",
      solutions: [
        "Audit-ready documentation for talent development compliance.",
        "Accessibility-focused content reviews and inclusive practice guidance.",
        "Reporting templates that map diagnostics to sector regulations.",
      ],
    },
  ];

  return (
    <div className="bg-white">
      <section className="relative py-20 text-white">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              'url("https://images.unsplash.com/photo-1483478550801-ceba5fe50e8e?auto=format&fit=crop&w=1600&q=80")',
          }}
        />
        <div className="absolute inset-0 bg-black/60" />
        <div className="relative mx-auto max-w-5xl px-6 text-center">
          <h1 className="text-4xl font-semibold">Solutions Architecture</h1>
          <p className="mt-4 text-lg text-white/80">
            Our solutions translate workforce diagnostics into accessible,
            repeatable tools that empower leadership, HR, and team supervisors.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-10 md:grid-cols-2">
            {solutionSets.map((set) => (
              <div
                key={set.category}
                className="rounded-3xl border border-gray-100 bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <h2 className="text-2xl font-semibold text-green-900">
                  {set.category}
                </h2>
                <ul className="mt-5 space-y-3 text-sm text-gray-700">
                  {set.solutions.map((solution) => (
                    <li key={solution} className="flex items-start gap-3">
                      <span
                        className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full"
                        style={{ backgroundColor: "#1B5E20" }}
                      />
                      {solution}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className="py-16"
        style={{ backgroundColor: "#F5F5DC" }}
      >
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-12 md:grid-cols-2 md:items-center">
            <div className="rounded-3xl bg-white p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-green-900">
                Integration with Existing Systems
              </h3>
              <p className="mt-4 text-sm text-gray-700">
                TalentScope Diagnostics designs outputs that integrate with
                existing HRIS, learning management systems, and analytics
                platforms. We provide data dictionaries, API recommendations,
                and change management support for smooth adoption.
              </p>
            </div>
            <div className="rounded-3xl bg-white p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-green-900">
                Continuous Improvement Loop
              </h3>
              <p className="mt-4 text-sm text-gray-700">
                After implementation, we facilitate review cycles to monitor
                workforce performance, adjust diagnostics, and ensure insights
                remain aligned with evolving objectives. This iterative model
                encourages sustained professional growth and retention stability.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl px-6 text-center">
          <h2 className="text-3xl font-semibold text-green-900">
            Build a diagnostics solution set tailored to your teams.
          </h2>
          <p className="mt-4 text-base text-gray-700">
            Let us know your workforce priorities and we will assemble a
            solution roadmap that connects diagnostics to measurable outcomes.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Solutions;