import React from "react";
import usePageMeta from "../hooks/usePageMeta";

function CaseStudies() {
  usePageMeta(
    "TalentScope Diagnostics Case Studies",
    "See how TalentScope Diagnostics supports Canadian organizations with workforce development diagnostics, training analysis, and retention insights."
  );

  const studies = [
    {
      title: "Municipal Services Workforce Renewal",
      context:
        "A western Canadian municipality needed clarity on succession planning and training requirements for critical infrastructure teams.",
      outcomes: [
        "Mapped 65 roles against competency frameworks with clear readiness indicators.",
        "Delivered retention dashboards highlighting mentorship opportunities.",
        "Implemented professional growth monitoring for technical apprentices.",
      ],
      image:
        "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=900&q=80",
    },
    {
      title: "Provincial Healthcare Talent Alignment",
      context:
        "A provincial healthcare network required a unified view of skill proficiency and training compliance across remote and urban sites.",
      outcomes: [
        "Consolidated training records and compliance tracking across 14 facilities.",
        "Produced engagement analysis that informed shift scheduling adjustments.",
        "Created development pathways integrating clinical and leadership modules.",
      ],
      image:
        "https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=900&q=80",
    },
    {
      title: "Technology Cooperative Retention Strategy",
      context:
        "A technology cooperative with distributed teams observed fluctuating retention metrics and uneven professional development access.",
      outcomes: [
        "Introduced pulse surveys and stay interview protocols with analytics.",
        "Developed capability dashboards highlighting advanced training needs.",
        "Launched coaching circles to sustain knowledge transfer and growth.",
      ],
      image:
        "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80",
    },
  ];

  return (
    <div className="bg-white">
      <section className="py-16">
        <div className="mx-auto max-w-5xl px-6">
          <h1 className="text-4xl font-semibold text-green-900">
            Case Studies
          </h1>
          <p className="mt-4 text-base text-gray-700">
            Explore how TalentScope Diagnostics collaborates with Canadian
            organizations to uncover workforce insights, align training, and
            support professional growth.
          </p>
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-10 md:grid-cols-3">
            {studies.map((study) => (
              <article
                key={study.title}
                className="flex flex-col rounded-3xl border border-gray-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <img
                  src={study.image}
                  alt={study.title}
                  className="h-52 w-full rounded-t-3xl object-cover"
                />
                <div className="flex flex-1 flex-col p-6">
                  <h2 className="text-xl font-semibold text-green-900">
                    {study.title}
                  </h2>
                  <p className="mt-4 text-sm text-gray-700">{study.context}</p>
                  <ul className="mt-6 space-y-3 text-sm text-gray-700">
                    {study.outcomes.map((outcome) => (
                      <li key={outcome} className="flex items-start gap-3">
                        <span
                          className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full"
                          style={{ backgroundColor: "#1B5E20" }}
                        />
                        {outcome}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className="py-16"
        style={{ backgroundColor: "#F5F5DC" }}
      >
        <div className="mx-auto max-w-5xl px-6 text-center">
          <h2 className="text-3xl font-semibold text-green-900">
            Plan a diagnostic that reflects your workforce reality.
          </h2>
          <p className="mt-4 text-base text-gray-700">
            Connect with us to design a diagnostic engagement that addresses
            training requirements, retention priorities, and professional growth
            pathways tailored to your teams.
          </p>
        </div>
      </section>
    </div>
  );
}

export default CaseStudies;