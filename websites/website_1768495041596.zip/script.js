document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            const isOpen = navLinks.classList.toggle('is-open');
            document.body.classList.toggle('nav-open', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen);
        });
        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navLinks.classList.remove('is-open');
                document.body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('[data-cookie-accept]');
    const declineBtn = document.querySelector('[data-cookie-decline]');
    const consent = localStorage.getItem('senefeutii_cookie_consent');

    function hideBanner() {
        if (cookieBanner) {
            cookieBanner.classList.add('is-hidden');
        }
    }

    if (consent === 'accepted' || consent === 'declined') {
        hideBanner();
    }

    if (acceptBtn) {
        acceptBtn.addEventListener('click', function () {
            localStorage.setItem('senefeutii_cookie_consent', 'accepted');
            hideBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', function () {
            localStorage.setItem('senefeutii_cookie_consent', 'declined');
            hideBanner();
        });
    }
});