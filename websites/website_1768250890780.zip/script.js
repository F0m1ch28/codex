document.addEventListener("DOMContentLoaded", function () {
    var banner = document.getElementById("cookie-banner");
    var acceptBtn = document.getElementById("cookie-accept");
    var declineBtn = document.getElementById("cookie-decline");
    var consentKey = "genusrkkrqCookieConsent";

    if (!banner || !acceptBtn || !declineBtn) {
        return;
    }

    var storedConsent = localStorage.getItem(consentKey);

    if (!storedConsent) {
        banner.classList.add("active");
    }

    acceptBtn.addEventListener("click", function () {
        localStorage.setItem(consentKey, "accepted");
        banner.classList.remove("active");
    });

    declineBtn.addEventListener("click", function () {
        localStorage.setItem(consentKey, "declined");
        banner.classList.remove("active");
    });
});