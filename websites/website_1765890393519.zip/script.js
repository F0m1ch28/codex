const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.querySelector('.nav-menu');

if (navToggle && navMenu) {
  navToggle.addEventListener('click', () => {
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    navMenu.classList.toggle('open');
  });

  navMenu.addEventListener('click', (event) => {
    if (event.target.tagName === 'A' && window.innerWidth < 720) {
      navToggle.setAttribute('aria-expanded', 'false');
      navMenu.classList.remove('open');
    }
  });
}

const cookieBanner = document.querySelector('.cookie-banner');
const cookieButtons = document.querySelectorAll('[data-cookie-action]');
const COOKIE_KEY = 'it-education-belgium-cookie-preference';

function setCookiePreference(value) {
  try {
    localStorage.setItem(COOKIE_KEY, value);
  } catch (error) {
    console.error('Cookie preference could not be saved.', error);
  }
}

function getCookiePreference() {
  try {
    return localStorage.getItem(COOKIE_KEY);
  } catch (error) {
    console.error('Cookie preference could not be retrieved.', error);
    return null;
  }
}

function handleCookieChoice(choice) {
  setCookiePreference(choice);
  if (cookieBanner) {
    cookieBanner.classList.remove('show');
  }
}

if (cookieBanner) {
  const preference = getCookiePreference();
  if (!preference) {
    setTimeout(() => {
      cookieBanner.classList.add('show');
    }, 600);
  }
}

cookieButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const action = button.dataset.cookieAction;
    handleCookieChoice(action);
  });
});