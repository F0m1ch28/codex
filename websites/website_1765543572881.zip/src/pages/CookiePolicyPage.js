```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Imagination Unleashed</title>
      <meta
        name="description"
        content="Read how Imagination Unleashed uses cookies to deliver a personalised and secure browsing experience."
      />
      <link rel="canonical" href="https://www.imaginationplaystore.nl/cookie-policy" />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p className={styles.updated}>Effective date: July 2023</p>

        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device that help us remember preferences and improve the
          performance of our website.
        </p>

        <h2>Types of Cookies We Use</h2>
        <ul>
          <li>
            <strong>Essential cookies:</strong> Required for basic site functionality, including secure checkout.
          </li>
          <li>
            <strong>Analytics cookies:</strong> Help us measure website usage and enhance the user experience.
          </li>
          <li>
            <strong>Preference cookies:</strong> Remember your language, location, and saved basket items.
          </li>
        </ul>

        <h2>Managing Cookies</h2>
        <p>
          You can adjust cookie settings within your browser. Disabling some cookies may impact website performance or
          prevent certain features from working correctly.
        </p>

        <h2>Contact</h2>
        <p>
          For questions about this policy, email us at <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;
```