```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const timeline = [
  {
    year: '2015',
    title: 'Idea takes shape',
    text: 'Founded by two Dutch educators who noticed classrooms needed joyful, durable play resources that inspire exploration beyond screens.'
  },
  {
    year: '2017',
    title: 'First collections launched',
    text: 'Introduced our first curated boxes for Amsterdam preschools, featuring sustainable wooden toys and storytelling bundles.'
  },
  {
    year: '2020',
    title: 'Nationwide shipping',
    text: 'Expanded to serve families and schools across the Netherlands with efficient delivery from our Amsterdam hub.'
  },
  {
    year: '2023',
    title: 'Imagination Unleashed today',
    text: 'A trusted online toy store delivering carefully selected ranges grounded in pedagogy, creativity, and joy.'
  }
];

const values = [
  {
    title: 'Child-centred design',
    description: 'We evaluate height, grip, texture, and interactive elements with guidance from occupational therapists.'
  },
  {
    title: 'Sustainable sourcing',
    description: 'Our partners prioritise recycled and responsibly harvested materials, reducing the ecological footprint of play.'
  },
  {
    title: 'Community engagement',
    description: 'We collaborate with Dutch libraries and museums to host pop-up play labs that ignite curiosity in every neighbourhood.'
  }
];

const AboutPage = () => (
  <>
    <Helmet>
      <title>About Imagination Unleashed | Premium Toy Curators</title>
      <meta
        name="description"
        content="Learn about Imagination Unleashed, our mission to inspire play in the Netherlands, and how we curate premium, safe, and sustainable toys."
      />
      <link rel="canonical" href="https://www.imaginationplaystore.nl/about" />
    </Helmet>
    <section className={styles.about}>
      <div className="container">
        <div className={styles.hero}>
          <div>
            <h1>About Imagination Unleashed</h1>
            <p>
              We are a Netherlands-based toy curator dedicated to celebrating play as the heart of childhood. Our team
              blends educational expertise with a love of storytelling to craft collections that feel magical and
              meaningful.
            </p>
          </div>
          <img
            src="https://images.unsplash.com/photo-1506045412240-22980140a405?auto=format&fit=crop&w=900&q=80"
            alt="Children playing with educational toys on a colorful rug."
            loading="lazy"
          />
        </div>

        <section className={styles.values}>
          <h2>Our Core Values</h2>
          <div className={styles.valueGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.timeline}>
          <h2>From a Classroom Vision to a National Playground</h2>
          <div className={styles.timelineGrid}>
            {timeline.map((item) => (
              <article key={item.year} className={styles.timelineCard}>
                <span className={styles.year}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </section>
  </>
);

export default AboutPage;
```