```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './NotFoundPage.module.css';

const NotFoundPage = () => (
  <>
    <Helmet>
      <title>Page Not Found | Imagination Unleashed</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <div className={styles.card}>
          <h1>404</h1>
          <p>Oops! We can&apos;t seem to find the page you&apos;re looking for.</p>
          <Link to="/" className={styles.link}>
            Back to playful discoveries
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default NotFoundPage;
```