```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './HomePage.module.css';

const categories = [
  {
    title: 'Educational Toys',
    description:
      'STEM kits, logic puzzles, and science experiments that transform curiosity into confident discovery.',
    icon: 'https://img.icons8.com/external-flaticons-flat-flat-icons/64/000000/external-education-toys-flaticons-flat-flat-icons-2.png'
  },
  {
    title: 'Toddler Games',
    description:
      'Soft, sensory-rich play companions perfect for little hands practicing their first coordination moves.',
    icon: 'https://img.icons8.com/color/64/000000/teddy-bear.png'
  },
  {
    title: 'Creative Playsets',
    description:
      'Role-play sets and craft workshops that encourage storytelling, collaboration, and big dreams.',
    icon: 'https://img.icons8.com/external-itim2101-flat-itim2101/64/000000/external-toy-back-to-school-itim2101-flat-itim2101.png'
  },
  {
    title: 'Outdoor Adventures',
    description:
      'Active play gear designed to get kids exploring parks, beaches, and back gardens across the Netherlands.',
    icon: 'https://img.icons8.com/color/64/000000/rocket--v1.png'
  }
];

const reasons = [
  {
    title: 'Premium Quality',
    text: 'We source sustainable materials and test every toy to outlast even the most energetic play sessions.',
    icon: '🌟'
  },
  {
    title: 'Safety First',
    text: 'Certified to EU standards, BPA-free, and rigorously reviewed by child development specialists.',
    icon: '🛡️'
  },
  {
    title: 'Imagination Driven',
    text: 'Every item is handpicked to nurture creativity, resilience, and collaborative play.',
    icon: '🎨'
  },
  {
    title: 'Nationwide Delivery',
    text: 'Swift, reliable shipping from Amsterdam to Groningen, Maastricht, and everywhere in between.',
    icon: '🚚'
  }
];

const spotlight = [
  {
    name: 'Rainbow Builder Blocks',
    description:
      'Vibrant wooden blocks that help children explore architecture, colour theory, and spatial awareness.',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
    alt: 'Colorful wooden building blocks stacked together.'
  },
  {
    name: 'Whisper Woods Plush Bear',
    description:
      'A cuddly companion sewn from organic cotton, offering comfort during bedtime stories and quiet moments.',
    image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=800&q=80',
    alt: 'Soft plush teddy bear sitting on a stack of books.'
  },
  {
    name: 'Young Artist Studio Kit',
    description:
      'A complete art station with eco-friendly paints and tools that let imaginations bloom without limits.',
    image: 'https://images.unsplash.com/photo-1523473827534-86c21ff0b2f7?auto=format&fit=crop&w=800&q=80',
    alt: 'Child painting with colorful art supplies on a table.'
  }
];

const testimonials = [
  {
    quote:
      'The educational kits sparked more curiosity during our family evenings than anything we have tried before. Shipping to Utrecht was quick and carefully packaged.',
    name: 'Sanne de Vries',
    location: 'Utrecht',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote:
      'Our toddler adores the sensory games. The quality is outstanding and I appreciate the thoughtful safety details.',
    name: 'Jeroen Bakker',
    location: 'Rotterdam',
    image: 'https://images.unsplash.com/photo-1504593811423-6dd665756598?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote:
      'Imagination Unleashed understands how to make play meaningful. The curated sets keep our twins engaged for hours.',
    name: 'Lotte van Rijn',
    location: 'Groningen',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
  }
];

const HomePage = () => (
  <>
    <Helmet>
      <title>Imagination Unleashed: Premium Quality Toys for Kids</title>
      <meta
        name="description"
        content="Discover premium quality toys at Imagination Unleashed. Explore educational toys, toddler games, and creative playsets with nationwide delivery across the Netherlands."
      />
      <meta
        name="keywords"
        content="kids toys, children's games, educational toys, Netherlands toy store, premium quality toys, toddler toys, toys online, learning toys, baby games, imagination play"
      />
      <link rel="canonical" href="https://www.imaginationplaystore.nl/" />
    </Helmet>

    <section className={styles.hero}>
      <div className={`container ${styles.heroContent}`}>
        <div className={styles.heroText}>
          <p className={styles.kicker}>Imagination Unleashed</p>
          <h1>Premium Quality Toys for Kids Across the Netherlands</h1>
          <p>
            Browse playful collections crafted to inspire creativity, curiosity, and laughter. From tender baby toys to
            STEM adventures, every item is chosen to enrich childhood moments at home.
          </p>
          <Link to="/categories" className={styles.heroButton} aria-label="Explore toy categories">
            Explore Toys
          </Link>
        </div>
        <div
          className={styles.heroImage}
          role="presentation"
          aria-hidden="true"
          style={{
            backgroundImage:
              'url("https://images.unsplash.com/photo-1516637090014-cb1ab0d08fc7?auto=format&fit=crop&w=1200&q=80")'
          }}
        />
      </div>
    </section>

    <section className={styles.featured}>
      <div className="container">
        <h2>Featured Categories</h2>
        <p className={styles.sectionIntro}>
          Discover collections made for every stage of early childhood, each chosen to encourage imaginative play.
        </p>
        <div className={styles.categoryGrid}>
          {categories.map((category) => (
            <article key={category.title} className={styles.categoryCard}>
              <img src={category.icon} alt="" aria-hidden="true" className={styles.categoryIcon} />
              <h3>{category.title}</h3>
              <p>{category.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.whyChoose}>
      <div className="container">
        <h2>Why Families Choose Us</h2>
        <div className={styles.reasonsGrid}>
          {reasons.map((reason) => (
            <article key={reason.title} className={styles.reasonCard}>
              <div className={styles.reasonIcon} aria-hidden="true">
                {reason.icon}
              </div>
              <h3>{reason.title}</h3>
              <p>{reason.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.spotlight}>
      <div className="container">
        <div className={styles.spotlightHead}>
          <h2>Imagination Spotlight</h2>
          <p>
            Each month, our toy curators highlight inspiring pieces that blend craftsmanship, learning, and endless fun.
          </p>
        </div>
        <div className={styles.spotlightGrid}>
          {spotlight.map((item) => (
            <article key={item.name} className={styles.spotlightCard}>
              <img src={item.image} alt={item.alt} loading="lazy" />
              <div className={styles.spotlightBody}>
                <h3>{item.name}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.testimonials}>
      <div className="container">
        <h2>What Dutch Parents Are Saying</h2>
        <div className={styles.testimonialGrid}>
          {testimonials.map((item) => (
            <figure key={item.name} className={styles.testimonialCard}>
              <img src={item.image} alt={`Portrait of ${item.name}`} loading="lazy" />
              <blockquote>“{item.quote}”</blockquote>
              <figcaption>
                <strong>{item.name}</strong>
                <span>{item.location}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.cta}>
      <div className="container">
        <div className={styles.ctaContent}>
          <h2>Ready to make playtime extraordinary?</h2>
          <p>
            Dive into our toy categories or reach out to our Amsterdam-based team for personalised recommendations.
            We love matching toys with the personalities of curious young minds.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/categories" className={styles.ctaButton} aria-label="See all toy categories">
              See All Categories
            </Link>
            <div className={styles.ctaContact}>
              <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a>
              <a href="tel:+31201234567">+31 20 123 4567</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default HomePage;
```