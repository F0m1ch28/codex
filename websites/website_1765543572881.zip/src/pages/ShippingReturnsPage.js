```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ShippingReturnsPage.module.css';

const ShippingReturnsPage = () => (
  <>
    <Helmet>
      <title>Shipping &amp; Returns | Imagination Unleashed</title>
      <meta
        name="description"
        content="Understand shipping times, delivery partners, and return policies for Imagination Unleashed, serving families across the Netherlands."
      />
      <link rel="canonical" href="https://www.imaginationplaystore.nl/shipping-returns" />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <header className={styles.header}>
          <h1>Shipping &amp; Returns</h1>
          <p>
            Our logistics partners ensure every parcel arrives promptly and safely, so your child’s next adventure never
            has to wait.
          </p>
        </header>

        <div className={styles.grid}>
          <article className={styles.card}>
            <h2>Shipping Across the Netherlands</h2>
            <p>
              Orders placed before 14:00 CET are prepared the same day from our Amsterdam fulfilment studio. Delivery
              typically takes 1-2 business days through PostNL or DHL, depending on your location.
            </p>
            <ul>
              <li>Real-time tracking details sent via email and SMS.</li>
              <li>Reusable, recyclable packaging designed for minimal waste.</li>
              <li>Optional gift wrapping featuring playful Dutch illustrations.</li>
            </ul>
          </article>

          <article className={styles.card}>
            <h2>Returns &amp; Exchanges</h2>
            <p>
              We accept returns within 30 days of delivery. Toys must be unused, in original packaging, and include the
              packing slip for swift processing.
            </p>
            <ul>
              <li>Email us at <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a> to initiate a return label.</li>
              <li>Refunds are issued within 5 business days after inspection.</li>
              <li>Received a faulty item? We will replace it immediately at our expense.</li>
            </ul>
          </article>

          <article className={styles.card}>
            <h2>Click &amp; Collect</h2>
            <p>
              Amsterdam-based families can choose Click &amp; Collect. We will notify you when the order is ready, and
              a dedicated play specialist will walk you through the items on pickup.
            </p>
            <ul>
              <li>Pickup hours: Monday to Saturday, 10:00 - 17:00.</li>
              <li>Located at Toy Street 123, 1011 AB Amsterdam.</li>
              <li>Parking for bikes and prams available right outside.</li>
            </ul>
          </article>
        </div>

        <section className={styles.support}>
          <h2>Need Assistance?</h2>
          <p>
            Our support team is available Monday to Friday, 09:00 - 18:00 CET. Call <a href="tel:+31201234567">+31 20 123 4567</a> or email{' '}
            <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a> for personalised help.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default ShippingReturnsPage;
```