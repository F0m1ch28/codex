```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsPage.module.css';

const TermsPage = () => (
  <>
    <Helmet>
      <title>Terms of Service | Imagination Unleashed</title>
      <meta
        name="description"
        content="Read the terms of service for Imagination Unleashed, covering purchases, shipping, returns, and website usage."
      />
      <link rel="canonical" href="https://www.imaginationplaystore.nl/terms" />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Terms of Service</h1>
        <p className={styles.updated}>Last updated: July 2023</p>

        <h2>1. Introduction</h2>
        <p>
          Welcome to Imagination Unleashed. By accessing our website and placing an order, you agree to the terms and
          conditions set out below. These terms are governed by Dutch law.
        </p>

        <h2>2. Orders &amp; Payment</h2>
        <p>
          Orders are confirmed once payment is received. We accept major Dutch debit cards, iDEAL, and recognised credit
          cards. All prices include VAT where applicable.
        </p>

        <h2>3. Shipping</h2>
        <p>
          We provide shipping throughout the Netherlands using selected couriers. Delivery times are estimates and may
          vary during public holidays or severe weather.
        </p>

        <h2>4. Returns</h2>
        <p>
          Products can be returned within 30 days of receipt provided they are in original condition. Please contact us
          before returning any item so we can issue a returns label.
        </p>

        <h2>5. Liability</h2>
        <p>
          Imagination Unleashed is not liable for indirect or consequential damages related to the use of our products.
          Our liability is limited to the purchase price of the item.
        </p>

        <h2>6. Intellectual Property</h2>
        <p>
          All content on this website, including text, images, and branding, remains the property of Imagination
          Unleashed and is protected under applicable copyright laws.
        </p>

        <h2>7. Contact</h2>
        <p>
          If you have any questions about these terms, reach out to us at <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a>.
        </p>
      </div>
    </section>
  </>
);

export default TermsPage;
```