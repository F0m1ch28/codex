```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoriesPage.module.css';

const categoryData = [
  {
    name: 'STEM Explorers',
    description:
      'Robotics kits, coding games, and hands-on science experiments that nurture analytical thinking and problem solving.',
    highlights: [
      'Interactive coding challenges for ages 6+',
      'Microscope adventure packs with Dutch wildlife guides',
      'Renewable energy sets featuring wind turbines inspired by the polder landscape'
    ]
  },
  {
    name: 'Baby & Toddler Play',
    description:
      'Gentle, sensory-led toys that support motor skills and early language through textures, shapes, and soothing sounds.',
    highlights: [
      'Organic cotton comforters with contrasting colours',
      'Stacking toys shaped like iconic Dutch canal houses',
      'Soft activity books with simple Dutch vocabulary rhymes'
    ]
  },
  {
    name: 'Creative Arts & Crafts',
    description:
      'Painting, sculpting, and crafting kits that transform the living room into a studio for limitless expression.',
    highlights: [
      'Eco-friendly finger paints derived from natural pigments',
      'DIY puppet theatre inspired by Amsterdam’s theatres',
      'Family craft boxes ideal for rainy Dutch afternoons'
    ]
  },
  {
    name: 'Outdoor Adventures',
    description:
      'Active play gear that invites children to explore parks, dunes, and coastlines with confidence and imagination.',
    highlights: [
      'Treasure-hunt explorer backpacks with nature journals',
      'Balance bikes with adjustable seats for growing riders',
      'Garden-friendly bug discovery sets with magnifying lenses'
    ]
  },
  {
    name: 'Family Game Night',
    description:
      'Board games and cooperative challenges that bring everyone together for laughter-filled evenings.',
    highlights: [
      'Story-building card decks featuring Dutch folklore',
      'Cooperative strategy games encouraging teamwork',
      'Quick-play dice games ideal for travel and sleepovers'
    ]
  }
];

const CategoriesPage = () => (
  <>
    <Helmet>
      <title>Product Categories | Imagination Unleashed</title>
      <meta
        name="description"
        content="Explore toy categories from Imagination Unleashed, including STEM kits, baby and toddler toys, creative arts, outdoor adventures, and family games."
      />
      <link rel="canonical" href="https://www.imaginationplaystore.nl/categories" />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <header className={styles.header}>
          <h1>Product Categories</h1>
          <p>
            Every category is curated to support different ages, interests, and learning styles. Dive in and find the
            perfect fit for your child’s next adventure.
          </p>
        </header>
        <div className={styles.cards}>
          {categoryData.map((category) => (
            <article key={category.name} className={styles.card}>
              <h2>{category.name}</h2>
              <p>{category.description}</p>
              <ul>
                {category.highlights.map((highlight) => (
                  <li key={highlight}>{highlight}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default CategoriesPage;
```