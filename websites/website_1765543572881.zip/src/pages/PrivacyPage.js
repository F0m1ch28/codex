```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Imagination Unleashed</title>
      <meta
        name="description"
        content="Learn how Imagination Unleashed collects, uses, and protects personal data for customers throughout the Netherlands."
      />
      <link rel="canonical" href="https://www.imaginationplaystore.nl/privacy" />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p className={styles.updated}>Effective date: July 2023</p>

        <h2>Information We Collect</h2>
        <p>
          We collect personal data when you place an order, subscribe to updates, or contact customer service. This may
          include your name, address, email, phone number, and payment details.
        </p>

        <h2>How We Use Data</h2>
        <p>
          Data is used to process orders, provide customer support, enhance our product range, and send optional
          communications with your consent.
        </p>

        <h2>Cookies</h2>
        <p>
          Cookies help us remember your preferences and understand how visitors interact with our website. You can
          manage cookie preferences via your browser settings.
        </p>

        <h2>Sharing of Information</h2>
        <p>
          We only share data with trusted service providers required to process payments, deliver orders, or maintain
          the website. These providers follow GDPR guidelines.
        </p>

        <h2>Your Rights</h2>
        <p>
          You have the right to request access, correction, or deletion of your personal data. Contact us at{' '}
          <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a> to submit a request.
        </p>

        <h2>Contact</h2>
        <p>
          Imagination Unleashed<br />
          Toy Street 123, 1011 AB Amsterdam, Netherlands
        </p>
      </div>
    </section>
  </>
);

export default PrivacyPage;
```