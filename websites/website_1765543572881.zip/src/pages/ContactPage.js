```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [status, setStatus] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    orderNumber: '',
    message: ''
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('Thank you! Your message has been received. Our team will respond within one business day.');
    setFormData({
      name: '',
      email: '',
      orderNumber: '',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>Contact Imagination Unleashed | Get in Touch</title>
        <meta
          name="description"
          content="Contact Imagination Unleashed for toy recommendations, order support, or partnership opportunities. Reach us by phone, email, or the contact form."
        />
        <link rel="canonical" href="https://www.imaginationplaystore.nl/contact" />
      </Helmet>
      <section className={styles.contact}>
        <div className="container">
          <div className={styles.wrapper}>
            <div className={styles.details}>
              <h1>Contact Us</h1>
              <p>
                Need help choosing a gift, requesting a restock, or tracking an order? Our Amsterdam-based team is ready
                to support you with personalised recommendations.
              </p>
              <div className={styles.info}>
                <div>
                  <h2>Visit</h2>
                  <p>
                    Toy Street 123<br />
                    1011 AB Amsterdam<br />
                    Netherlands
                  </p>
                </div>
                <div>
                  <h2>Call</h2>
                  <a href="tel:+31201234567">+31 20 123 4567</a>
                </div>
                <div>
                  <h2>Email</h2>
                  <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a>
                </div>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} aria-label="Contact form">
              <h2>Send us a message</h2>
              <label htmlFor="name">Name</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Your full name"
              />

              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="you@example.com"
              />

              <label htmlFor="orderNumber">Order number (optional)</label>
              <input
                id="orderNumber"
                name="orderNumber"
                type="text"
                value={formData.orderNumber}
                onChange={handleChange}
                placeholder="NL123456"
              />

              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                required
                placeholder="Tell us how we can help."
              />

              <button type="submit" className={styles.submitButton}>
                Submit
              </button>
              {status && <p className={styles.status} role="status">{status}</p>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;
```