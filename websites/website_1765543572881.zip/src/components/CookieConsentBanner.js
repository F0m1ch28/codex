```javascript
import React, { useEffect, useState } from 'react';
import styles from './CookieConsentBanner.module.css';

const STORAGE_KEY = 'imagination_cookie_consent';

const CookieConsentBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem(STORAGE_KEY);
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent message">
      <div className={styles.text}>
        We use cookies to ensure that playtime on our site is smooth and personalised. By clicking “Accept”, you agree
        to our use of cookies described in our Cookie Policy.
      </div>
      <button type="button" className={styles.button} onClick={handleAccept} aria-label="Accept cookies">
        Accept
      </button>
    </div>
  );
};

export default CookieConsentBanner;
```