```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.grid}`}>
      <div className={styles.brand}>
        <h3>Imagination Unleashed</h3>
        <p>Premium toys that spark joy and inspire lifelong curiosity.</p>
      </div>
      <div>
        <h4>Quick Links</h4>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/categories">Categories</Link>
          </li>
          <li>
            <Link to="/about">About Us</Link>
          </li>
          <li>
            <Link to="/shipping-returns">Shipping &amp; Returns</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </div>
      <div>
        <h4>Legal</h4>
        <ul>
          <li>
            <Link to="/terms">Terms of Service</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>
      <div className={styles.contact}>
        <h4>Contact</h4>
        <p>Toy Street 123<br />1011 AB Amsterdam, Netherlands</p>
        <p>Phone: <a href="tel:+31201234567">+31 20 123 4567</a></p>
        <p>Email: <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a></p>
      </div>
    </div>
    <div className={styles.copy}>
      © 2023 Imagination Unleashed. All rights reserved.
    </div>
  </footer>
);

export default Footer;
```