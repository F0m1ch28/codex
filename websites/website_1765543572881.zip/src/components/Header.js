```javascript
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.logo} aria-label="Imagination Unleashed logo">
          Imagination <span>Unleashed</span>
        </div>
        <button
          className={styles.menuToggle}
          onClick={handleToggle}
          aria-label="Toggle navigation menu"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          className={`${styles.navigation} ${menuOpen ? styles.open : ''}`}
          aria-label="Primary navigation"
        >
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Home
          </NavLink>
          <NavLink to="/categories" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Categories
          </NavLink>
          <NavLink to="/about" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            About Us
          </NavLink>
          <NavLink
            to="/shipping-returns"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.active : '')}
          >
            Shipping &amp; Returns
          </NavLink>
          <NavLink to="/contact" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Contact
          </NavLink>
          <NavLink to="/terms" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Terms
          </NavLink>
          <NavLink to="/privacy" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Privacy
          </NavLink>
          <NavLink
            to="/cookie-policy"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.active : '')}
          >
            Cookies
          </NavLink>
        </nav>
        <div className={styles.cartIcon} aria-hidden="true">
          🧺
        </div>
      </div>
    </header>
  );
};

export default Header;
```