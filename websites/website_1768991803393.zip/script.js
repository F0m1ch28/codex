document.addEventListener("DOMContentLoaded", function () {
  const menuToggle = document.querySelector(".menu-toggle");
  const siteNav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".nav-list a");
  if (menuToggle && siteNav) {
    menuToggle.addEventListener("click", () => {
      siteNav.classList.toggle("nav-open");
      menuToggle.classList.toggle("is-active");
    });
    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("nav-open")) {
          siteNav.classList.remove("nav-open");
          menuToggle.classList.remove("is-active");
        }
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const storageKey = "aflCookieConsent";
  if (cookieBanner) {
    const storedPreference = localStorage.getItem(storageKey);
    if (!storedPreference) {
      cookieBanner.classList.add("active");
    }
    const handleConsent = (value) => {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.remove("active");
    };
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => handleConsent("declined"));
    }
  }
});