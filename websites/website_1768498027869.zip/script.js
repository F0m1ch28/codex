document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            const isOpen = navLinks.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navLinks.classList.contains('open')) {
                    navLinks.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const choice = localStorage.getItem('playscidzeCookieConsent');
        if (!choice) {
            cookieBanner.classList.add('show');
        }

        cookieBanner.querySelectorAll('[data-choice]').forEach(function (anchor) {
            anchor.addEventListener('click', function (event) {
                event.preventDefault();
                const decision = anchor.getAttribute('data-choice');
                localStorage.setItem('playscidzeCookieConsent', decision);
                cookieBanner.classList.remove('show');
            });
        });
    }
});