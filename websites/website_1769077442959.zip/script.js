document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('navToggle');
  const nav = document.getElementById('primaryNav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      navToggle.classList.toggle('open', isOpen);
      navToggle.setAttribute('aria-expanded', String(isOpen));
      document.body.dataset.navOpen = isOpen ? 'true' : 'false';
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (nav.classList.contains('open')) {
          nav.classList.remove('open');
          navToggle.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
          document.body.dataset.navOpen = 'false';
        }
      });
    });
  }
  document.querySelectorAll('[data-current-year]').forEach(el => {
    el.textContent = new Date().getFullYear();
  });
  const observerTargets = document.querySelectorAll('.animate-on-scroll');
  if (observerTargets.length > 0) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    observerTargets.forEach(target => io.observe(target));
  }
  const toast = document.getElementById('toast');
  function showToast(message) {
    if (!toast) {
      return;
    }
    toast.textContent = message;
    toast.classList.add('is-active');
    setTimeout(() => {
      toast.classList.remove('is-active');
    }, 2200);
  }
  const forms = document.querySelectorAll('form[data-redirect]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      showToast('Formulario enviado. Redirigiendo.');
      setTimeout(() => {
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 1200);
    });
  });
  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const storageKey = 'dse-cookie-preference';
    let storedChoice = null;
    try {
      storedChoice = localStorage.getItem(storageKey);
    } catch (error) {
      storedChoice = null;
    }
    if (!storedChoice) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    }
    const acceptButton = cookieBanner.querySelector('[data-cookie-accept]');
    const declineButton = cookieBanner.querySelector('[data-cookie-decline]');
    const persistChoice = value => {
      try {
        localStorage.setItem(storageKey, value);
      } catch (error) {
        // no se puede almacenar
      }
      cookieBanner.classList.remove('is-visible');
    };
    if (acceptButton) {
      acceptButton.addEventListener('click', () => {
        persistChoice('accepted');
        showToast('Preferencias actualizadas.');
      });
    }
    if (declineButton) {
      declineButton.addEventListener('click', () => {
        persistChoice('declined');
        showToast('Preferencias registradas.');
      });
    }
  }
});