const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const CONSENT_KEY = "cookie_consent";

const I18N = {
  fr: {
    titles: {
      home: "danswholesaleplants — Orientation spatiale numérique",
      services: "Approches — danswholesaleplants",
      about: "Profil — danswholesaleplants",
      blog: "Analyses — danswholesaleplants",
      post1: "Modéliser les parcours multi-niveaux — danswholesaleplants",
      post2: "Synchroniser données capteurs et observation — danswholesaleplants",
      post3: "Mesurer la lisibilité des plans — danswholesaleplants",
      post4: "Signalétique adaptative multilingue — danswholesaleplants",
      post5: "Analytique spatiale pour situations d'urgence — danswholesaleplants",
      contact: "Contact — danswholesaleplants",
      faq: "FAQ — danswholesaleplants",
      terms: "Conditions d'utilisation — danswholesaleplants",
      privacy: "Politique de confidentialité — danswholesaleplants",
      cookies: "Politique relative aux cookies — danswholesaleplants",
      refund: "Politique de restitution — danswholesaleplants",
      disclaimer: "Clause de non-responsabilité — danswholesaleplants",
      thankyou: "Merci — danswholesaleplants"
    },
    meta: {
      home: "Études sur l'orientation spatiale, la signalétique numérique et la navigation piétonne dans les environnements complexes.",
      services: "Présentation des approches de danswholesaleplants pour analyser flux piétonniers, signalétique numérique et UX spatiale.",
      about: "Profil de danswholesaleplants, ses convictions et jalons autour de la lisibilité des espaces publics.",
      blog: "Analyses techniques sur la navigation intérieure, la cartographie des espaces et le guidage visuel.",
      post1: "Approche détaillée de la modélisation des parcours multi-niveaux dans les campus civiques.",
      post2: "Méthode pour combiner capteurs, observation et cartographie au service de la navigation intérieure.",
      post3: "Cadre d'indicateurs pour mesurer la lisibilité des plans et supports cartographiques.",
      post4: "Principes de signalétique adaptative pour des environnements multilingues et complexes.",
      post5: "Analytique spatiale appliquée aux scénarios d'urgence et aux flux à haute densité.",
      contact: "Entrer en relation avec danswholesaleplants pour des environnements complexes à Bruxelles et en Europe.",
      faq: "Questions fréquentes sur les méthodes d'orientation spatiale proposées par danswholesaleplants.",
      terms: "Conditions générales d'utilisation du site danswholesaleplants.com.",
      privacy: "Politique de confidentialité et engagements de danswholesaleplants concernant les données personnelles.",
      cookies: "Politique relative aux cookies et au stockage local sur danswholesaleplants.com.",
      refund: "Politique de restitution et modalités de traitement des demandes associées.",
      disclaimer: "Clause de non-responsabilité concernant les contenus publiés par danswholesaleplants.",
      thankyou: "Confirmation de réception de votre message par danswholesaleplants."
    },
    global: {
      companyName: "danswholesaleplants",
      skipToContent: "Aller au contenu principal",
      menuToggle: "Ouvrir ou fermer la navigation",
      primaryNav: "Navigation principale",
      languageToggleLabel: "Sélection de la langue",
      nav: {
        home: "Accueil",
        services: "Approches",
        about: "Profil",
        blog: "Analyses",
        faq: "FAQ",
        contact: "Contact"
      },
      footerTagline: "Études et diagnostics pour des parcours spatiaux compréhensibles.",
      footerAddress: "Rue de la Loi 200, 1040 Bruxelles, Belgique",
      footerContactTitle: "Coordonnées",
      footerPhoneLabel: "Téléphone :",
      footerPhoneNumber: "+32 2 123 45 67",
      footerEmailLabel: "Courriel :",
      footerEmailAddress: "contact@danswholesaleplants.com",
      footerLegalTitle: "Cadre documentaire",
      termsLink: "Conditions d'utilisation",
      privacyLink: "Politique de confidentialité",
      cookiesLink: "Politique relative aux cookies",
      refundLink: "Politique de restitution",
      disclaimerLink: "Clause de non-responsabilité",
      footerRights: "© danswholesaleplants. Tous droits réservés.",
      manageCookies: "Gérer les cookies",
      publishedOn: "Publication :",
      readingTime: "Temps de lecture :",
      minutes: "minutes",
      backToBlog: "Retour aux analyses",
      mapLabel: "Carte interactive"
    },
    home: {
      heroEyebrow: "Orientation spatiale numérique",
      heroTitle: "Cartographier les dynamiques de circulation dans les établissements publics pluriels",
      heroSubtitle: "Nous observons la manière dont les usagers perçoivent la signalétique, interprètent les plans et ajustent leurs trajets dans les environnements bâtis à forte densité. Nos corpus combinent relevés sur site, traces numériques et analyses d'accessibilité pour guider les décisions architecturales.",
      heroPrimary: "Explorer nos cadres méthodologiques",
      heroSecondary: "Consulter les analyses publiées",
      stat1Value: "28",
      stat1Label: "campagnes d'observation de flux piéton sur trois niveaux",
      stat2Value: "12",
      stat2Label: "référentiels urbains comparés dans notre observatoire",
      stat3Value: "6,4 km",
      stat3Label: "d'espaces cartographiés en continu",
      heroImageAlt: "Interface de guidage visuel sur un plan interactif",
      heroImageCaption: "Visualisation composite d'un circuit piéton.",
      featuresEyebrow: "Systèmes étudiés",
      featuresTitle: "Approches croisées pour lire et orienter les espaces complexes",
      featuresIntro: "Chaque diagnostic combine observation in situ, instrumentation numérique et retours utilisateurs. Les modèles élaborés décrivent la relation entre architecture, signalétique et perception.",
      featuresCard1Title: "Cartographie comportementale",
      featuresCard1Text: "Nous associons relevés vidéo anonymisés et journaux de parcours pour représenter les bifurcations, hésitations et rythmes de déplacement. L'objectif est d'isoler les zones critiques et d'évaluer la lisibilité des repères.",
      featuresCard2Title: "Signalétique adaptative",
      featuresCard2Text: "Les dispositifs numériques sont évalués selon leur capacité à contextualiser l'information. Nous étudions la hiérarchie des messages, les transitions d'écran et les contraintes de luminosité pour maintenir la cohérence visuelle.",
      featuresCard3Title: "Modélisation multi-niveaux",
      featuresCard3Text: "Les trajectoires sont simulées par grappes d'usagers afin de comprendre les interactions verticales et horizontales. L'analyse éclaire la distribution des flux et alimente les scénarios d'exploitation.",
      featuresCard4Title: "Accessibilité augmentée",
      featuresCard4Text: "Nous examinons la prise en compte des besoins diversifiés en matière de guidage. Les tests portent sur la compréhension tactile, sonore et visuelle des indications pour renforcer l'inclusivité du parcours.",
      matrixEyebrow: "Analyses croisées",
      matrixTitle: "Trois axes pour structurer les décisions spatiales",
      matrixIntro: "Les données récoltées sont compilées dans des rubriques complémentaires afin de conserver une vision systémique.",
      matrixCard1Title: "Lecture contextuelle",
      matrixCard1Text: "Chaque point d'information est relié aux intentions architecturales et aux contraintes du site. Cette dimension clarifie les interactions entre volumes bâtis et orientation.",
      matrixCard1Item1: "Analyse des champs visuels prioritaires",
      matrixCard1Item2: "Repérage des discordances de matériaux",
      matrixCard1Item3: "Scénarios d'usage selon les périodes",
      matrixCard2Title: "Comportements observés",
      matrixCard2Text: "Les observations issues des parcours témoin identifient les patterns de déplacement, les ralentissements et les points de friction.",
      matrixCard2Item1: "Cartes thermiques de densité piétonne",
      matrixCard2Item2: "Typologie des besoins d'information",
      matrixCard2Item3: "Moments clés de re-calibrage de trajet",
      matrixCard3Title: "Itérations numériques",
      matrixCard3Text: "Les interfaces interactives sont prototypées et testées en boucle courte pour ajuster la structure de l'information.",
      matrixCard3Item1: "Matrices de contenu multilingue",
      matrixCard3Item2: "Baromètre de reconnaissance iconographique",
      matrixCard3Item3: "Évaluation de la stabilité des données en temps réel",
      recommendationsEyebrow: "Recommandations",
      recommendationsTitle: "Bonnes pratiques extraites des sites observés",
      recommendationsIntro: "Ces recommandations synthétisent les éléments qui améliorent la navigation intérieure et la compréhension des usagers.",
      recommendation1Title: "Séquencer les prises de décision",
      recommendation1Text: "Placer les indications clés aux intersections précédant les bifurcations importantes réduit les retours en arrière et clarifie les options.",
      recommendation2Title: "Stabiliser la terminologie",
      recommendation2Text: "Employer la même dénomination pour les espaces dans tous les supports, qu'ils soient imprimés ou numériques, évite les ambiguïtés.",
      recommendation3Title: "Renforcer la lumière d'accompagnement",
      recommendation3Text: "Des contrastes calibrés entre ambiance lumineuse et panneaux permettent d'attirer l'œil sans créer d'éblouissement.",
      recommendation4Title: "Capitaliser sur les retours situés",
      recommendation4Text: "Les dispositifs qui recueillent les commentaires in situ, via QR codes ou bornes, offrent des insights actionnables pour ajuster les plans.",
      testimonialsEyebrow: "Témoignages",
      testimonialsTitle: "Retours sur nos dispositifs d'analyse",
      testimonialsIntro: "Institutions culturelles, pôles universitaires et administrations utilisent nos synthèses pour accompagner leurs projets.",
      testimonial1Quote: "La structure comparative proposée par danswholesaleplants nous a permis d'identifier les zones où les visiteurs perdaient le fil narratif du parcours. Les recommandations ont clarifié nos priorités d'aménagement.",
      testimonial1Name: "Lucie De Smet",
      testimonial1Role: "Responsable expérience usagers, Musée urbain",
      testimonial2Quote: "Les cartes de densité générées croisées avec les flux entrants ont rendu visibles des congestions inattendues. Nous avons pu réorganiser la signalétique temporaire avant la réouverture.",
      testimonial2Name: "Noah Verbeeck",
      testimonial2Role: "Coordinateur infrastructures, Campus civique",
      testimonial3Quote: "Les matrices multilingues proposent une vue très fine des écarts de traduction entre supports statiques et écrans. Cela a simplifié nos arbitrages avec les équipes de terrain.",
      testimonial3Name: "Clara Dardenne",
      testimonial3Role: "Cheffe de projet, Mobilité régionale",
      blogEyebrow: "Observatoire",
      blogTitle: "Analyses récentes",
      blogIntro: "Sélection de notes techniques consacrées aux mobilités piétonnes et à la lisibilité des espaces complexes.",
      blogCTA: "Voir toutes les analyses"
    },
    services: {
      heroEyebrow: "Approches",
      heroTitle: "Cadres opérationnels pour la navigation intérieure",
      heroSubtitle: "Nos interventions se concentrent sur l'analyse des flux, la conception de signalétiques numériques et la structuration des parcours dans les environnements bâtis complexes.",
      heroImageAlt: "Équipe analysant un plan de circulation",
      overviewTitle: "Domaines d'intervention",
      overviewIntro: "Les interventions combinent observation, prototypage et restitution structurée. Chaque volet peut être activé indépendamment ou intégré à une mission complète.",
      card1Title: "Analyse des flux piétonniers",
      card1Text: "Nous réalisons des observations synchrones et asynchrones pour documenter les trajectoires, vitesses et regroupements. Les résultats alimentent des plans de circulation adaptés aux contraintes du bâtiment.",
      card2Title: "Signalétique numérique et cartographie",
      card2Text: "Les supports interactifs sont conçus à partir de scénarios d'usage détaillés. Interfaces, légendes et hiérarchies d'information sont testées avant déploiement.",
      card3Title: "Cadres UX spatiale",
      card3Text: "Nous élaborons des référentiels d'expérience spatiale, intégrant confort de lecture, repères sensoriels et inclusivité. Ils servent de base aux décisions architecturales.",
      card4Title: "Design informationnel",
      card4Text: "Les schémas d'information traduisent les contraintes du site en messages lisibles. Chaque élément est associé à des paramètres visuels et verbaux pour garantir la cohérence.",
      card5Title: "Recherche sur le guidage visuel",
      card5Text: "Les dispositifs de guidage visuel sont évalués selon leur capacité à orienter des publics variés. Nous synthétisons les bonnes pratiques issues des expérimentations.",
      methodTitle: "Processus analytique",
      methodIntro: "Chaque mission suit une séquence modulable, ajustée aux spécificités du lieu étudié.",
      methodStep1Title: "Immersion et collecte",
      methodStep1Text: "Visites de terrain, inventaires signalétiques et entretiens courts forment la base documentaire.",
      methodStep2Title: "Modélisation et prototypage",
      methodStep2Text: "Croisement des données, réalisation de maquettes interactives, tests rapides auprès d'usagers.",
      methodStep3Title: "Restitution et suivi",
      methodStep3Text: "Synthèse cartographique, recommandations hiérarchisées et plan de suivi des ajustements.",
      deliverablesTitle: "Formes de restitution",
      deliverablesIntro: "Les livrables privilégient des formats actionnables, faciles à partager dans les organisations.",
      deliverable1: "Atlas de plans annotés avec zones de friction et leviers d'amélioration.",
      deliverable2: "Tableaux de priorisation pour la mise à jour des supports numériques et physiques.",
      deliverable3: "Tableaux de bord permettant de suivre les indicateurs de circulation et de lisibilité.",
      closingTitle: "Cadre de collaboration",
      closingText: "Les interventions sont construites en lien avec les équipes opérationnelles, de l'audit initial aux phases de déploiement progressif."
    },
    about: {
      heroEyebrow: "Profil",
      heroTitle: "Une cellule d'étude dédiée à la lisibilité des espaces bâtis",
      heroSubtitle: "Nous croisons expertise en architecture de l'information, design urbain et sciences comportementales pour éclairer les parcours usagers.",
      heroImageAlt: "Cartes et diagrammes d'orientation étalés sur une table",
      missionTitle: "Mission",
      missionText: "danswholesaleplants documente la manière dont les individus se déplacent dans les environnements complexes, afin de traduire ces comportements en recommandations concrètes pour les gestionnaires d'espaces publics.",
      valuesTitle: "Principes d'approche",
      valuesIntro: "Nos travaux s'articulent autour de principes structurants.",
      values1: "Observation située : combiner mesures quantitatives et récits vécus.",
      values2: "Lisibilité : privilégier la clarté des supports plutôt que la surinformation.",
      values3: "Inclusion : intégrer la diversité des capacités sensorielles et linguistiques.",
      values4: "Itération : ajuster les propositions à partir des retours du terrain.",
      timelineTitle: "Jalons",
      timelineIntro: "Quelques jalons marquants de notre trajectoire.",
      timeline1Date: "2016",
      timeline1Text: "Constitution des premiers protocoles d'observation pour les gares métropolitaines.",
      timeline2Date: "2018",
      timeline2Text: "Développement d'un laboratoire mobile pour tester la signalétique numérique in situ.",
      timeline3Date: "2020",
      timeline3Text: "Création d'une base de données comparative sur les dispositifs de guidage multilingues.",
      timeline4Date: "2023",
      timeline4Text: "Lancement d'un programme d'évaluation en continu des flux piétons dans les campus ouverts.",
      capabilitiesTitle: "Compétences mobilisées",
      capabilitiesIntro: "L'équipe réunit des profils complémentaires afin de couvrir toute la chaîne d'analyse.",
      capability1: "Architectes de l'information spécialisés en cartographie.",
      capability2: "Analystes de données urbaines et modélisation de flux.",
      capability3: "Designers d'interfaces centrées sur la navigation.",
      capability4: "Chercheurs en sciences du comportement et accessibilité.",
      cultureTitle: "Culture de travail",
      cultureText: "Nous favorisons les formats collaboratifs avec les parties prenantes : ateliers de co-lecture, revues de prototypes et dispositifs de suivi partagés garantissent que les décisions restent lisibles pour tous."
    },
    blog: {
      heroEyebrow: "Analyses",
      heroTitle: "Analyses et carnets d'observation",
      heroSubtitle: "Publications centrées sur l'orientation spatiale, la signalétique numérique et la navigation dans les environnements complexes.",
      heroImageAlt: "Tableau de plans avec annotations colorées",
      archiveNote: "Les articles sont classés par ordre chronologique inverse.",
      card1Date: "12 février 2024",
      card1Title: "Modéliser les parcours multi-niveaux dans les campus civiques",
      card1Excerpt: "Retour sur un programme d'observation dédié aux campus à volumes imbriqués. Focus sur les décalages entre trajets projetés et réels, et sur la coordination des repères verticaux.",
      card1Alt: "Écran de signalétique interactive dans un atrium",
      card2Date: "28 janvier 2024",
      card2Title: "Synchroniser capteurs et observation pour guider les usagers",
      card2Excerpt: "Comment combiner données de capteurs passifs, relevés qualitatifs et cartographie digitale pour maintenir une navigation fluide dans les bâtiments publics.",
      card2Alt: "Dispositif sensoriel installé sur un couloir",
      card3Date: "14 janvier 2024",
      card3Title: "Mesurer la lisibilité des plans à grande échelle",
      card3Excerpt: "Construction d'indicateurs de lisibilité destinés aux plans imprimés et aux cartes interactives, avec un accent sur la hiérarchisation des informations.",
      card3Alt: "Plan mural avec zones colorées et pictogrammes",
      card4Date: "20 décembre 2023",
      card4Title: "Signalétique adaptative pour espaces multilingues",
      card4Excerpt: "Étude des supports dynamiques capables de s'ajuster aux différents profils linguistiques et cognitifs dans un même bâtiment.",
      card4Alt: "Panneau numérique affichant plusieurs langues",
      card5Date: "5 décembre 2023",
      card5Title: "Analytique spatiale et scénarios d'urgence piétonne",
      card5Excerpt: "Analyse des flux en situation d'urgence et recommandations pour intégrer la résilience dans les dispositifs d'orientation.",
      card5Alt: "Plan d'évacuation rétroéclairé dans un couloir",
      readMore: "Lire l'analyse"
    },
    posts: {
      publishedLabel: "Publication :",
      readingTimeLabel: "Temps de lecture :",
      post1: {
        date: "12 février 2024",
        readingTime: "7",
        heroAlt: "Signalétique numérique dans un atrium multi-niveaux",
        heroCaption: "Synchronisation des repères verticaux sur un campus civique.",
        title: "Modéliser les parcours multi-niveaux dans les campus civiques",
        h2: "Interpréter les données de circulation au-delà des plans",
        h3: "Articuler signalétique numérique et navigation humaine",
        p1: "Les grands campus civiques associent fonctions administratives, culturelles et de mobilité, ce qui génère des trames de circulation superposées pour visiteurs et personnels. En phase d'arrivée, chacun concilie indications imprimées, repères architecturaux et écrans numériques tout en franchissant plusieurs niveaux. Notre programme d'observation a documenté l'écart entre les trajectoires projetées et les trajets effectifs. Ces premiers instants constituent un matériau critique pour évaluer la manière dont les dispositifs d'orientation traduisent les intentions de conception.",
        p2: "Le travail de cartographie a débuté par des marches synchronisées à différentes heures de la journée. Les équipes ont parcouru les mêmes paires origine-destination en notant obstacles, niveaux sonores et densité de repères visuels. Les données révèlent que les transitions verticales, mezzanines ou escaliers fractionnés provoquent davantage d'hésitation que la longueur des couloirs. Les participants s'appuient fortement sur l'ambiance lumineuse pour confirmer la continuité des circulations, indiquant la nécessité d'aligner les repères avec les gradients de lumière.",
        p3: "La signalétique numérique offre ses meilleures performances lorsque les messages épousent le champ visuel naturel. Des écrans positionnés perpendiculairement aux flux obligent les usagers à s'arrêter entièrement, créant des micro-bouchons. À l'inverse, des supports inclinés et hiérarchisés permettent des vérifications rapides. Les simulations montrent que la constance iconographique importe davantage que la palette chromatique : dès que les pictogrammes varient selon les niveaux, le réflexe est de solliciter une personne de référence plutôt que de s'appuyer sur le dispositif.",
        p4: "L'empilement des informations sur plusieurs niveaux impose de concilier les nomenclatures verticales avec les zones thématiques. De nombreux lieux nomment les mezzanines comme des demi-étages, ce qui perturbe les visiteurs habitués à une numérotation entière. Nous avons testé des descripteurs relationnels tels que « au-dessus du hall public » ou « sous l'aile archives ». Les entretiens révèlent que ces repères relatifs réduisent de dix-huit pour cent les demi-tours, preuve de l'efficacité d'un langage cohérent avec les représentations mentales.",
        p5: "Les comptages sensoriels complètent l'observation humaine en captant les dérives tardives. Des faisceaux infrarouges passifs mesurent l'intensité des circulations sans enregistrer de données personnelles. Le croisement de ces pics avec les cartes annotées éclaire les zones où la signalétique doit basculer en mode nocturne. L'orientation vers les sorties disposant d'un accueil après dix-neuf heures évite ainsi la congestion dans la rotonde principale.",
        p6: "Modéliser les parcours multi-niveaux revient à articuler architecture, langage et technologie. Harmoniser la signalétique numérique avec les repères physiques, la lumière et le vocabulaire crée un sentiment de confiance pour usagers occasionnels ou réguliers. Les campus civiques évoluent en permanence ; maintenir la qualité d'orientation implique de revisiter ces indicateurs à chaque mutation fonctionnelle. Le cadre proposé fixe des jalons pour que ce dialogue demeure actif."
      },
      post2: {
        date: "28 janvier 2024",
        readingTime: "6",
        heroAlt: "Capteurs lumineux au-dessus d'un couloir fréquenté",
        heroCaption: "Croisement de capteurs passifs et d'observations qualitatives.",
        title: "Synchroniser capteurs et observation pour guider les usagers",
        h2: "Assembler données instrumentées et lectures humaines",
        h3: "Structurer les restitutions pour des équipes pluridisciplinaires",
        p1: "Les capteurs passifs se multiplient dans les bâtiments publics modernes : portiques infrarouges, compteurs optiques ou balises Bluetooth documentent la fréquentation. Isolées, ces données restent pourtant difficiles à actionner pour la signalétique. L'enjeu consiste à les rapprocher des observations humaines qui décrivent motivations et perceptions. Notre laboratoire a mis au point un protocole qui marie les deux sources afin d'obtenir des recommandations opérationnelles.",
        p2: "La première étape consiste à cartographier précisément l'implantation des capteurs et à qualifier leur sensibilité. Chaque dispositif réagit différemment aux variations lumineuses, aux silhouettes ou aux vitesses de déplacement. Nous confrontons ces relevés à des parcours accompagnés où l'observateur note tâches à réaliser, attentes et points d'attention des usagers. Le croisement montre par exemple que certains pics détectés résultent de pauses volontaires face à un écran et non d'une congestion.",
        p3: "Les jeux de données sont ensuite harmonisés dans une table temporelle commune. Nous alignons les horodatages, neutralisons les variations de fuseau et intégrons des annotations contextuelles : fermeture exceptionnelle d'un escalator, événement culturel, conditions météorologiques. Cette couche contextuelle change la lecture : un même volume de flux peut être interprété comme satisfaisant ou problématique selon la disponibilité des alternatives directionnelles.",
        p4: "Les restitutions prennent la forme de cartes narratives composées de trois panneaux : vision capteur, vision observateur, synthèse. Ce format facilite la discussion entre équipes techniques, responsables d'exploitation et designers d'information. Chaque panneau expose ses limites : angle mort du champ sensoriel, biais d'interprétation, besoin de vérification terrain. Les décisions se basent alors sur une compréhension partagée des corpus et des incertitudes.",
        p5: "Nous avons également développé un indicateur composite qui pondère densité captée, degré d'hésitation observé et clarté perçue de la signalétique. Il s'agit d'un score de vigilance qui déclenche des ateliers ciblés lorsque le seuil est dépassé. Les ateliers réunissent responsables de site et agents d'accueil afin de tester en direct de nouvelles formulations ou repositionnements tactiques.",
        p6: "Au final, synchroniser capteurs et observation ne signifie pas faire converger toutes les données dans un tableau unique. Il s'agit plutôt de créer un dialogue rigoureux entre les instruments et l'expertise humaine. La valeur ajoutée naît de cette confrontation permanente qui nourrit la compréhension des parcours et l'adaptation continue des dispositifs d'orientation."
      },
      post3: {
        date: "14 janvier 2024",
        readingTime: "7",
        heroAlt: "Plan de bâtiment avec codes couleur et légende détaillée",
        heroCaption: "Matrice de lisibilité pour plans imprimés et numériques.",
        title: "Mesurer la lisibilité des plans à grande échelle",
        h2: "Construire un référentiel d'indicateurs",
        h3: "Appliquer la grille aux dispositifs hybrides",
        p1: "Les plans jouent un rôle central dans l'orientation, qu'ils soient affichés sur un mur, disponibles en brochure ou accessibles via un écran. Pourtant la notion de lisibilité reste souvent subjective. Nous avons conçu un référentiel d'indicateurs pour évaluer de manière structurée la qualité d'un plan à grande échelle et guider les itérations.",
        p2: "Le référentiel s'articule autour de trois familles : composition visuelle, hiérarchie de l'information et cohérence terminologique. Pour chaque famille, nous définissons des critères mesurables. Par exemple, la composition s'évalue via la densité de symboles par zone, la présence de marges respirantes ou l'alignement des repères principaux. Les tests utilisateurs viennent valider les seuils choisis.",
        p3: "Nous avons ensuite appliqué le référentiel à une série de plans existants dans des gares et campus universitaires. Les résultats ont montré que la plupart des difficultés proviennent de l'accumulation de niveaux d'information non différenciés. Lorsque les pictogrammes, textes et lignes partagent la même épaisseur visuelle, la lecture devient laborieuse. La recommandation prioritaire consiste à réintroduire des niveaux de contraste via couleurs, texture ou épaisseur.",
        p4: "L'analyse a également mis en avant l'importance de la cohérence terminologique. Un même espace baptisé « accueil » sur un plan, « réception » sur un autre support, désoriente les usagers. Le référentiel inclut donc un audit lexical comparant plan, signalétique et documents numériques. Cette étape assure que les appellations restent identiques, réduisant les ambiguïtés.",
        p5: "Pour les dispositifs hybrides, nous avons ajouté un volet dynamique : temps de réponse des écrans, animation des zooms, adaptation aux langues. La lisibilité numérique ne se limite pas à la résolution ; elle dépend aussi de la manière dont le contenu s'affiche et se réorganise. Les tests recommandent d'éviter les transitions trop rapides qui empêchent l'œil de suivre l'évolution du plan.",
        p6: "En synthèse, mesurer la lisibilité d'un plan revient à combiner métriques objectives et retours d'usage. Le référentiel proposé offre un langage commun aux cartographes, designers et responsables de site. Il permet de prioriser les actions, qu'il s'agisse de simplifier une légende, d'ajuster une palette ou de revoir la structure d'une carte interactive.",
        p7: "La méthodologie reste ouverte : chaque nouveau contexte apporte des spécificités qu'il faut intégrer. Les retours des équipes terrain alimentent ainsi le référentiel, assurant sa pertinence dans le temps et la diversité des environnements analysés."
      },
      post4: {
        date: "20 décembre 2023",
        readingTime: "6",
        heroAlt: "Panneau numérique affichant plusieurs langues",
        heroCaption: "Interface multilingue ajustable en temps réel.",
        title: "Signalétique adaptative pour espaces multilingues",
        h2: "Cartographier les besoins linguistiques",
        h3: "Configurer une hiérarchisation flexible",
        p1: "Dans les environnements publics, la diversité linguistique impose des dispositifs de signalétique capables de s'adapter rapidement. La traduction littérale ne suffit pas ; il faut intégrer les registres culturels, les contraintes typographiques et les supports existants. Notre étude se concentre sur les mécanismes qui rendent une signalétique réellement adaptative.",
        p2: "La première étape consiste à analyser finement les profils linguistiques du site. Nous combinons données démographiques, observations terrain et retours du personnel d'accueil. Cette cartographie permet d'identifier les langues prioritaires et les moments clés où l'adaptation est nécessaire, par exemple lors d'événements internationaux ou de pics touristiques.",
        p3: "Ensuite, nous définissons une architecture de contenu modulable. Les messages sont segmentés en unités réutilisables, ce qui facilite leur réorganisation selon la langue affichée. Chaque unité est associée à un pictogramme pour maintenir une reconnaissance visuelle même lorsque le texte change. Ce système garantit une cohérence globale tout en autorisant des ajustements rapides.",
        p4: "La hiérarchisation flexible s'appuie sur des règles de priorité : langue par défaut, ordre d'affichage alterné, mise en avant des informations critiques. Les tests montrent qu'une rotation automatique toutes les trente secondes reste acceptable si les messages essentiels demeurent visibles en permanence. Les écrans proposent également une option tactile pour sélectionner sa langue.",
        p5: "Pour accompagner les équipes techniques, nous fournissons un guide d'orchestration précisant les paramètres : sources de traduction, gabarits typographiques, seuils de bascule. Ce guide inclut un protocole de validation linguistique avec des représentants des communautés concernées afin de garantir la pertinence des formulations.",
        p6: "Enfin, l'adaptabilité s'étend au-delà des écrans. Les supports physiques intègrent des calques magnétiques ou des panneaux modulaires permettant de faire évoluer la langue principale selon les périodes. L'objectif reste de préserver la lisibilité sans multiplier les informations simultanées.",
        p7: "La signalétique adaptative constitue ainsi un équilibre entre flexibilité et stabilité. En documentant précisément les besoins et en fournissant des outils de pilotage, il devient possible d'offrir une expérience cohérente aux différents publics sans surcharger les espaces."
      },
      post5: {
        date: "5 décembre 2023",
        readingTime: "7",
        heroAlt: "Plan d'évacuation rétroéclairé dans un couloir",
        heroCaption: "Scénarios d'urgence et circulation piétonne maîtrisée.",
        title: "Analytique spatiale et scénarios d'urgence piétonne",
        h2: "Comprendre les réactions dynamiques",
        h3: "Intégrer la résilience dans les dispositifs d'orientation",
        p1: "Les scénarios d'urgence révèlent des comportements différents des circulations quotidiennes. Le stress, la recherche de sorties immédiates et l'effet de groupe modifient les trajectoires. Notre étude explore comment l'analytique spatiale peut anticiper ces réactions pour renforcer la résilience des dispositifs d'orientation.",
        p2: "Nous avons d'abord modélisé les flux à partir de simulations agent-based, en intégrant variables de densité, vitesse, visibilité et bruit. Les résultats soulignent que l'obscurité partielle et les angles morts provoquent des ralentissements abrupts. Les trajectoires se resserrent contre les parois, rendant les panneaux muraux moins visibles.",
        p3: "Les exercices grandeur nature complètent la modélisation. Des groupes hétérogènes suivent des scénarios simulant fumée, fermeture de sortie ou signal sonore défaillant. Les observateurs notent les hésitations et les renoncements à certaines sorties. Les participants privilégient les trajets connus, même plus longs, confirmant l'importance de repères familiers.",
        p4: "L'analytique spatiale permet ensuite d'associer ces observations à des données en temps réel : capteurs de foule, ouverture de portes, état des éclairages. Nous proposons une matrice de décision qui indique quand basculer vers un guidage lumineux dynamique, rediriger les flux ou activer des messages vocaux multilingues.",
        p5: "La résilience passe également par la préparation des supports. Les plans d'évacuation doivent être lisibles dans des conditions de visibilité réduite : contrastes renforcés, pictogrammes tactiles, positions stratégiques. Les écrans intègrent un mode dégradé qui privilégie des messages textuels simples et des flèches directionnelles animées.",
        p6: "Nous recommandons enfin d'organiser des revues périodiques des dispositifs d'orientation, incluant tests nocturnes et scénarios spécifiques (maintenance, événements). Chaque revue alimente une base de retours permettant d'ajuster les protocoles.",
        p7: "Grâce à cette approche, l'orientation ne se limite pas aux situations normales mais englobe les contextes critiques. Les usagers gagnent en confiance, et les équipes disposent d'outils pour piloter la signalétique en situation complexe."
      }
    },
    contact: {
      heroEyebrow: "Contact",
      heroTitle: "Dialoguer autour de vos environnements complexes",
      heroSubtitle: "Nous analysons les situations de circulation et de signalétique dans les bâtiments publics, campus ou réseaux multimodaux.",
      heroImageAlt: "Personne consultant une carte interactive",
      introTitle: "Entrer en relation",
      introText: "Partagez le contexte de votre site. Nous proposons des échanges exploratoires pour comprendre les besoins et cadrer les observations nécessaires.",
      infoAddressLabel: "Adresse",
      infoPhoneLabel: "Téléphone",
      infoEmailLabel: "Courriel",
      infoHoursLabel: "Créneaux de réponse",
      infoHoursText: "Du lundi au vendredi, 09:00 - 18:00 (UTC+1).",
      mapCaption: "Localisation du bureau à Bruxelles.",
      formTitle: "Formulaire de prise de contact",
      formDescription: "Merci de préciser le contexte, la typologie de bâtiment et les enjeux d'orientation identifiés.",
      formNameLabel: "Nom complet",
      formNamePlaceholder: "Ex. Dominique Dupont",
      formEmailLabel: "Adresse électronique",
      formEmailPlaceholder: "Ex. prenom.nom@example.com",
      formOrgLabel: "Organisation / Structure",
      formOrgPlaceholder: "Ex. Direction de l'aménagement",
      formTopicLabel: "Thématique principale",
      formTopicDefault: "Sélectionner une thématique",
      formTopicOption1: "Audit de flux piétonniers",
      formTopicOption2: "Signalétique numérique et cartographie",
      formTopicOption3: "Cadre UX spatiale",
      formMessageLabel: "Message",
      formMessagePlaceholder: "Décrivez les espaces concernés, les objectifs de lisibilité et les échéances.",
      formSubmit: "Envoyer la demande",
      formNote: "Les informations partagées sont utilisées uniquement pour organiser un premier échange.",
      followUpTitle: "Suite donnée",
      followUpText: "Nous revenons vers vous sous cinq jours ouvrés avec une proposition de cadrage méthodologique."
    },
    faq: {
      heroEyebrow: "FAQ",
      heroTitle: "Questions fréquentes",
      heroSubtitle: "Réponses aux interrogations récurrentes concernant nos protocoles d'analyse et de restitution.",
      heroImageAlt: "Documents et notes de réunion sur une table",
      q1: "Intervenez-vous uniquement en Belgique ?",
      a1: "Notre base est à Bruxelles mais nous travaillons sur des sites européens comparables. Les études peuvent être conduites en français, anglais ou néerlandais.",
      q2: "Comment se déroule une campagne d'observation ?",
      a2: "Une première phase décrit les points nodaux et les flux attendus. Des observateurs réalisent ensuite des relevés sur site complétés par des capteurs anonymisés.",
      q3: "Proposez-vous des outils numériques ?",
      a3: "Nous réalisons des prototypes de cartes interactives et de panneaux dynamiques, accompagnés de lignes directrices pour les équipes techniques.",
      q4: "Quelle est la durée moyenne d'une mission ?",
      a4: "Elle varie selon la complexité du site. Comptez entre quatre et douze semaines pour l'observation, la modélisation et les recommandations.",
      q5: "Comment travaillez-vous la question de l'accessibilité ?",
      a5: "Des ateliers dédiés regroupent des usagers aux profils sensoriels variés. Leurs retours sont intégrés dans les matrices d'orientation.",
      q6: "Fournissez-vous des supports de formation ?",
      a6: "Oui, nous préparons des supports pour faciliter le transfert des recommandations auprès des équipes internes."
    },
    terms: {
      heroEyebrow: "Conditions",
      heroTitle: "Conditions d'utilisation",
      heroSubtitle: "Cadre régissant l'accès et la consultation du site danswholesaleplants.com.",
      heroImageAlt: "Documents juridiques et ordinateur portable posés sur un bureau",
      intro: "En accédant au site danswholesaleplants.com, vous acceptez les présentes conditions d'utilisation.",
      section1Title: "1. Objet",
      section1Body: "Les présentes conditions définissent les modalités d'accès et d'utilisation des contenus publiés par danswholesaleplants.",
      section2Title: "2. Définitions",
      section2Body: "« Site » désigne la plateforme accessible à l'adresse danswholesaleplants.com. « Utilisateur » désigne toute personne consultant le site.",
      section3Title: "3. Acceptation des conditions",
      section3Body: "La consultation du site implique l'acceptation sans réserve des présentes conditions. En cas de désaccord, veuillez cesser votre navigation.",
      section4Title: "4. Modifications du site",
      section4Body: "danswholesaleplants se réserve le droit de modifier les contenus, fonctionnalités ou accès sans notification préalable.",
      section5Title: "5. Responsabilités de l'utilisateur",
      section5Body: "L'utilisateur s'engage à utiliser le site dans le respect des lois en vigueur et à ne pas perturber son bon fonctionnement.",
      section6Title: "6. Propriété intellectuelle",
      section6Body: "L'ensemble des contenus, textes, visuels et données sont la propriété exclusive de danswholesaleplants ou de ses partenaires et ne peuvent être reproduits sans autorisation écrite.",
      section7Title: "7. Utilisation correcte des contenus",
      section7Body: "Toute extraction ou réutilisation des contenus doit respecter leur intégrité et citer leur source.",
      section8Title: "8. Sources externes",
      section8Body: "Le site peut contenir des liens vers des ressources tierces. danswholesaleplants n'est pas responsable de leur contenu.",
      section9Title: "9. Exactitude des informations",
      section9Body: "Les informations sont fournies à titre indicatif. Nous mettons tout en œuvre pour garantir leur pertinence mais ne pouvons en assurer l'exhaustivité.",
      section10Title: "10. Accessibilité",
      section10Body: "Nous veillons à maintenir un niveau d'accessibilité élevé. Des maintenances ponctuelles peuvent toutefois limiter l'accès.",
      section11Title: "11. Protection des données",
      section11Body: "La politique de confidentialité détaille les pratiques de traitement des données personnelles.",
      section12Title: "12. Disponibilité du service",
      section12Body: "Le site est accessible 7j/7, sous réserve d'interruptions liées à la maintenance ou aux réseaux.",
      section13Title: "13. Droit applicable",
      section13Body: "Les présentes conditions sont régies par le droit belge. Tout litige relève de la compétence des tribunaux de Bruxelles.",
      section14Title: "14. Contact",
      section14Body: "Pour toute question relative aux conditions d'utilisation, contactez contact@danswholesaleplants.com."
    },
    privacy: {
      heroEyebrow: "Confidentialité",
      heroTitle: "Politique de confidentialité",
      heroSubtitle: "Nos engagements en matière de protection des données personnelles.",
      heroImageAlt: "Clavier, carnet et cadenas symbolisant la confidentialité",
      section1Title: "1. Introduction",
      section1Body: "La présente politique précise les modalités de collecte et de traitement des données personnelles lors de l'utilisation du site.",
      section2Title: "2. Responsable du traitement",
      section2Body: "Le responsable du traitement est danswholesaleplants, Rue de la Loi 200, 1040 Bruxelles.",
      section3Title: "3. Données collectées",
      section3Body: "Nous collectons uniquement les données transmises via le formulaire de contact (nom, adresse électronique, organisation, message).",
      section4Title: "4. Finalités",
      section4Body: "Les données sont utilisées pour répondre aux demandes reçues et préparer d'éventuels échanges.",
      section5Title: "5. Base juridique",
      section5Body: "Le traitement repose sur l'intérêt légitime de répondre aux sollicitations adressées à danswholesaleplants.",
      section6Title: "6. Durée de conservation",
      section6Body: "Les données sont conservées pendant douze mois à compter du dernier échange, sauf obligation légale contraire.",
      section7Title: "7. Partage des données",
      section7Body: "Les données ne sont partagées avec aucun tiers hors obligations légales ou demandes d'autorités compétentes.",
      section8Title: "8. Droits des personnes",
      section8Body: "Vous disposez d'un droit d'accès, de rectification, d'effacement et de limitation. Pour l'exercer, contactez contact@danswholesaleplants.com.",
      section9Title: "9. Sécurité",
      section9Body: "Nous mettons en place des mesures techniques et organisationnelles pour protéger les données contre toute divulgation non autorisée.",
      section10Title: "10. Transferts hors UE",
      section10Body: "Aucun transfert de données hors Union européenne n'est réalisé.",
      section11Title: "11. Mise à jour de la politique",
      section11Body: "La politique peut être modifiée pour refléter l'évolution des pratiques ou des exigences légales. La date de mise à jour la plus récente est indiquée en tête de document."
    },
    cookiesPage: {
      heroEyebrow: "Cookies",
      heroTitle: "Politique relative aux cookies",
      heroSubtitle: "Informations sur l'utilisation des cookies et du stockage local.",
      heroImageAlt: "Icône de cookies numériques sur un écran",
      intro: "Ce site utilise un stockage local minimal pour améliorer l'expérience utilisateur. Vous pouvez gérer vos préférences depuis la bannière dédiée.",
      usageTitle: "Usage des cookies",
      usageText: "Nous utilisons des cookies nécessaires pour assurer le fonctionnement du site et facultatifs pour enrichir l'expérience.",
      tableTitle: "Détails des cookies",
      tableName: "Nom",
      tableProvider: "Fournisseur",
      tableType: "Type",
      tablePurpose: "Finalité",
      tableDuration: "Durée",
      row1Name: "cookie_consent",
      row1Provider: "danswholesaleplants",
      row1Type: "Nécessaire",
      row1Purpose: "Stocke vos préférences en matière de cookies.",
      row1Duration: "12 mois",
      row2Name: "site_lang",
      row2Provider: "danswholesaleplants",
      row2Type: "Préférences",
      row2Purpose: "Mémorise la langue sélectionnée pour les visites ultérieures.",
      row2Duration: "12 mois",
      row3Name: "analytics_opt",
      row3Provider: "danswholesaleplants",
      row3Type: "Analytiques",
      row3Purpose: "Indique si les outils d'analyse peuvent être activés.",
      row3Duration: "6 mois",
      row4Name: "marketing_opt",
      row4Provider: "danswholesaleplants",
      row4Type: "Marketing",
      row4Purpose: "Enregistre le consentement pour d'éventuels contenus partenaires.",
      row4Duration: "6 mois",
      manageTitle: "Gestion des préférences",
      manageText: "Vous pouvez modifier à tout moment vos choix via la fonction « Gérer les cookies » située en pied de page.",
      updateTitle: "Mises à jour",
      updateText: "Cette politique peut être ajustée. Les changements seront publiés sur cette page avec la nouvelle date d'entrée en vigueur."
    },
    refund: {
      heroEyebrow: "Restitution",
      heroTitle: "Politique de restitution",
      heroSubtitle: "Modalités encadrant l'examen des demandes liées aux livrables ou échanges.",
      heroImageAlt: "Personne évaluant un dossier avec un stylo",
      section1Title: "1. Objectif du document",
      section1Body: "Clarifier la procédure de restitution applicable aux prestations intellectuelles réalisées par danswholesaleplants.",
      section2Title: "2. Champ d'application",
      section2Body: "Cette politique couvre les études, analyses et documents remis aux parties prenantes à l'issue des missions.",
      section3Title: "3. Principes généraux",
      section3Body: "Les restitutions sont réalisées selon les méthodologies définies conjointement. Les demandes de modification s'inscrivent dans ce cadre.",
      section4Title: "4. Annulation par le demandeur",
      section4Body: "Toute annulation doit être notifiée par écrit. Une synthèse des travaux réalisés est transmise pour arrêter la mission.",
      section5Title: "5. Annulation par danswholesaleplants",
      section5Body: "Nous pouvons interrompre une mission en cas de non-respect des engagements réciproques. Un état d'avancement détaillé est alors fourni.",
      section6Title: "6. Révisions de livrables",
      section6Body: "Les demandes de révision sont examinées à partir des objectifs initiaux et des éléments collectés. Un calendrier de correction est proposé.",
      section7Title: "7. Procédure de réclamation",
      section7Body: "Toute réclamation doit préciser le livrable concerné, les motifs et les attentes. Une réponse est apportée sous dix jours ouvrés.",
      section8Title: "8. Évaluation des demandes",
      section8Body: "Les demandes sont évaluées par l'équipe projet et, si nécessaire, par un référent externe afin de garantir l'objectivité de la réponse.",
      section9Title: "9. Données nécessaires",
      section9Body: "Le demandeur fournit les éléments complémentaires permettant de comprendre la situation et de proposer une solution.",
      section10Title: "10. Délais de traitement",
      section10Body: "Les délais peuvent varier selon la complexité du dossier. Ils sont communiqués au demandeur dès la réception de la requête.",
      section11Title: "11. Communication",
      section11Body: "Les échanges se déroulent par écrit afin de conserver une traçabilité complète des décisions et ajustements.",
      section12Title: "12. Mises à jour",
      section12Body: "Cette politique peut évoluer. Toute mise à jour est publiée sur le site avec mention de la date d'application."
    },
    disclaimer: {
      heroEyebrow: "Clause",
      heroTitle: "Clause de non-responsabilité",
      heroSubtitle: "Limites d'usage des informations publiées.",
      heroImageAlt: "Tour de dossiers avec un panneau attention",
      section1Title: "1. Informations fournies",
      section1Body: "Les contenus du site sont fournis à titre informatif et ne constituent pas une offre contractuelle.",
      section2Title: "2. Absence de garantie",
      section2Body: "danswholesaleplants ne garantit pas l'exactitude exhaustive des informations et décline toute responsabilité liée à leur utilisation.",
      section3Title: "3. Responsabilité",
      section3Body: "L'utilisateur assume seul les décisions prises sur la base des contenus consultés.",
      section4Title: "4. Révision des informations",
      section4Body: "Nous pouvons modifier les contenus sans préavis pour refléter l'évolution des projets ou des recherches.",
      section5Title: "5. Contact",
      section5Body: "Pour toute question relative à cette clause, contactez contact@danswholesaleplants.com."
    },
    thankyou: {
      heroEyebrow: "Confirmation",
      heroTitle: "Merci pour votre message",
      heroSubtitle: "Votre demande a été enregistrée. Nous reviendrons vers vous sous cinq jours ouvrés.",
      heroImageAlt: "Personne envoyant un message depuis un ordinateur",
      followUp: "Vous pouvez poursuivre la lecture de nos analyses pendant que nous étudions votre requête."
    },
    cookieBanner: {
      title: "Gestion des cookies",
      description: "Nous utilisons des cookies pour sécuriser le site, mémoriser votre langue et analyser la performance. Choisissez vos préférences.",
      manage: "Configurer",
      decline: "Tout refuser",
      accept: "Tout accepter",
      save: "Enregistrer",
      preferenceTitle: "Vos préférences de cookies",
      necessaryTitle: "Nécessaires",
      necessaryText: "Indispensables au fonctionnement du site.",
      alwaysOn: "Toujours actif",
      preferencesTitle: "Préférences",
      preferencesText: "Permettent de mémoriser vos choix de langue ou d'affichage.",
      analyticsTitle: "Analytiques",
      analyticsText: "Aident à comprendre l'utilisation du site pour améliorer les contenus.",
      marketingTitle: "Marketing",
      marketingText: "Autorisent la diffusion de contenus partenaires pertinents.",
      updated: "Préférences mises à jour."
    },
    forms: {
      success: "Demande envoyée. Nous reviendrons vers vous rapidement.",
      error: "Veuillez compléter les champs requis avant envoi."
    },
    toast: {
      cookieAccepted: "Préférences enregistrées.",
      cookieDeclined: "Les cookies non essentiels sont désactivés."
    }
  },
  en: {
    titles: {
      home: "danswholesaleplants — Digital spatial orientation",
      services: "Approaches — danswholesaleplants",
      about: "Profile — danswholesaleplants",
      blog: "Analyses — danswholesaleplants",
      post1: "Modeling multi-level journeys — danswholesaleplants",
      post2: "Synchronising sensors and observation — danswholesaleplants",
      post3: "Measuring map readability — danswholesaleplants",
      post4: "Adaptive signage for multilingual spaces — danswholesaleplants",
      post5: "Spatial analytics for emergency scenarios — danswholesaleplants",
      contact: "Contact — danswholesaleplants",
      faq: "FAQ — danswholesaleplants",
      terms: "Terms of use — danswholesaleplants",
      privacy: "Privacy policy — danswholesaleplants",
      cookies: "Cookie policy — danswholesaleplants",
      refund: "Restitution policy — danswholesaleplants",
      disclaimer: "Disclaimer — danswholesaleplants",
      thankyou: "Thank you — danswholesaleplants"
    },
    meta: {
      home: "Studies on spatial orientation, digital signage, and pedestrian navigation within complex environments.",
      services: "Overview of danswholesaleplants approaches for pedestrian flow analysis, digital signage, and spatial UX frameworks.",
      about: "Profile of danswholesaleplants, its convictions, and milestones around the readability of public spaces.",
      blog: "Technical analyses on indoor navigation, spatial mapping, and visual guidance systems.",
      post1: "Detailed method for modeling multi-level journeys across civic campuses.",
      post2: "How to combine sensor data, observation, and mapping to sustain indoor navigation.",
      post3: "Indicator framework to measure readability of large-scale maps and interactive charts.",
      post4: "Principles of adaptive signage for multilingual and complex environments.",
      post5: "Spatial analytics applied to pedestrian emergency scenarios and high-density flows.",
      contact: "Get in touch with danswholesaleplants regarding complex environments in Brussels and beyond.",
      faq: "Frequently asked questions about danswholesaleplants spatial orientation methods.",
      terms: "Terms governing the use of danswholesaleplants.com.",
      privacy: "Privacy policy detailing how danswholesaleplants processes personal data.",
      cookies: "Cookie and local storage practices on danswholesaleplants.com.",
      refund: "Restitution policy and procedures for handling related requests.",
      disclaimer: "Disclaimer covering the information published by danswholesaleplants.",
      thankyou: "Confirmation that your message reached danswholesaleplants."
    },
    global: {
      companyName: "danswholesaleplants",
      skipToContent: "Skip to main content",
      menuToggle: "Open or close navigation",
      primaryNav: "Main navigation",
      languageToggleLabel: "Language selection",
      nav: {
        home: "Home",
        services: "Approaches",
        about: "Profile",
        blog: "Analyses",
        faq: "FAQ",
        contact: "Contact"
      },
      footerTagline: "Studies and diagnostics for understandable spatial journeys.",
      footerAddress: "Rue de la Loi 200, 1040 Brussels, Belgium",
      footerContactTitle: "Contact details",
      footerPhoneLabel: "Phone:",
      footerPhoneNumber: "+32 2 123 45 67",
      footerEmailLabel: "Email:",
      footerEmailAddress: "contact@danswholesaleplants.com",
      footerLegalTitle: "Documentation framework",
      termsLink: "Terms of use",
      privacyLink: "Privacy policy",
      cookiesLink: "Cookie policy",
      refundLink: "Restitution policy",
      disclaimerLink: "Disclaimer",
      footerRights: "© danswholesaleplants. All rights reserved.",
      manageCookies: "Manage cookies",
      publishedOn: "Published:",
      readingTime: "Reading time:",
      minutes: "minutes",
      backToBlog: "Back to analyses",
      mapLabel: "Interactive map"
    },
    home: {
      heroEyebrow: "Digital spatial guidance",
      heroTitle: "Mapping circulation dynamics across complex public buildings",
      heroSubtitle: "We observe how people interpret signage, understand floor plans, and adapt their trajectories within dense built environments. Field logs, digital traces, and accessibility reviews combine to inform architectural decisions.",
      heroPrimary: "Explore our methodological frameworks",
      heroSecondary: "Review published analyses",
      stat1Value: "28",
      stat1Label: "pedestrian flow observation campaigns across three tiers",
      stat2Value: "12",
      stat2Label: "urban benchmarks compared in our observatory",
      stat3Value: "6.4 km",
      stat3Label: "of continuously mapped interior pathways",
      heroImageAlt: "Visual guidance interface on an interactive map",
      heroImageCaption: "Composite visualisation of a pedestrian circuit.",
      featuresEyebrow: "Systems studied",
      featuresTitle: "Combined approaches to read and orient complex spaces",
      featuresIntro: "Each diagnosis blends on-site observation, digital instrumentation, and user feedback. The resulting models describe the interplay between architecture, signage, and perception.",
      featuresCard1Title: "Behavioural cartography",
      featuresCard1Text: "We couple anonymised video readings with journey logs to represent branching, hesitation, and movement rhythms. The aim is to isolate critical zones and evaluate the readability of cues.",
      featuresCard2Title: "Adaptive signage",
      featuresCard2Text: "Digital devices are assessed for their capacity to contextualise information. We examine message hierarchy, screen transitions, and light constraints to maintain visual coherence.",
      featuresCard3Title: "Multi-level modelling",
      featuresCard3Text: "Trajectories are simulated by clusters of users to understand vertical and horizontal interactions. The analysis clarifies flow distribution and feeds operational scenarios.",
      featuresCard4Title: "Augmented accessibility",
      featuresCard4Text: "We review how diverse guidance needs are addressed. Tests focus on tactile, auditory, and visual comprehension to strengthen journey inclusiveness.",
      matrixEyebrow: "Cross-analysis",
      matrixTitle: "Three axes to structure spatial decisions",
      matrixIntro: "Collected data is compiled into complementary strands to preserve a systemic perspective.",
      matrixCard1Title: "Contextual reading",
      matrixCard1Text: "Every information point is connected to architectural intent and site constraints. This dimension clarifies interactions between built volumes and orientation.",
      matrixCard1Item1: "Analysis of priority sightlines",
      matrixCard1Item2: "Detection of material inconsistencies",
      matrixCard1Item3: "Usage scenarios over time cycles",
      matrixCard2Title: "Observed behaviours",
      matrixCard2Text: "Insights from companion walks identify movement patterns, slowdowns, and friction points.",
      matrixCard2Item1: "Pedestrian density heat maps",
      matrixCard2Item2: "Typology of information needs",
      matrixCard2Item3: "Key moments of route recalibration",
      matrixCard3Title: "Digital iterations",
      matrixCard3Text: "Interactive interfaces are prototyped and tested in short loops to refine information structure.",
      matrixCard3Item1: "Multilingual content matrices",
      matrixCard3Item2: "Icon recognition barometer",
      matrixCard3Item3: "Stability assessment of real-time data",
      recommendationsEyebrow: "Recommendations",
      recommendationsTitle: "Practices distilled from observed sites",
      recommendationsIntro: "These points synthesise what improves indoor navigation and user understanding.",
      recommendation1Title: "Sequence decision points",
      recommendation1Text: "Place crucial indications before major branches to reduce backtracking and clarify options.",
      recommendation2Title: "Stabilise terminology",
      recommendation2Text: "Use identical naming for spaces across printed and digital supports to avoid ambiguity.",
      recommendation3Title: "Support lighting guidance",
      recommendation3Text: "Calibrated contrasts between ambient light and signage help draw attention without glare.",
      recommendation4Title: "Leverage situated feedback",
      recommendation4Text: "Devices collecting on-site comments, via QR codes or kiosks, provide actionable insights to adjust layouts.",
      testimonialsEyebrow: "Testimonials",
      testimonialsTitle: "Feedback on our analysis devices",
      testimonialsIntro: "Cultural institutions, university hubs, and administrations rely on our syntheses to accompany their projects.",
      testimonial1Quote: "The comparative structure proposed by danswholesaleplants highlighted where visitors lost the narrative thread of the tour. The recommendations clarified which spatial upgrades to prioritise.",
      testimonial1Name: "Lucie De Smet",
      testimonial1Role: "User experience lead, Urban museum",
      testimonial2Quote: "Density maps combined with entrance flows exposed unexpected congestion. We reorganised temporary signage before reopening to keep movement reliable.",
      testimonial2Name: "Noah Verbeeck",
      testimonial2Role: "Infrastructure coordinator, Civic campus",
      testimonial3Quote: "The multilingual matrices offered a precise view of translation gaps between static supports and screens. It simplified negotiations with field teams.",
      testimonial3Name: "Clara Dardenne",
      testimonial3Role: "Project manager, Regional mobility",
      blogEyebrow: "Observatory",
      blogTitle: "Recent analyses",
      blogIntro: "Selection of technical notes focused on pedestrian mobility and the readability of complex environments.",
      blogCTA: "View all analyses"
    },
    services: {
      heroEyebrow: "Approaches",
      heroTitle: "Operational frameworks for indoor navigation",
      heroSubtitle: "Our work centres on flow analysis, digital signage design, and user journey structuring within complex built environments.",
      heroImageAlt: "Team analysing a circulation plan",
      overviewTitle: "Fields of intervention",
      overviewIntro: "Assignments combine observation, prototyping, and structured reporting. Each component can operate independently or within a comprehensive mission.",
      card1Title: "Pedestrian flow analysis",
      card1Text: "We conduct synchronous and asynchronous observations to document trajectories, speeds, and group formations. The outcomes support circulation plans tailored to the building's constraints.",
      card2Title: "Digital signage and mapping",
      card2Text: "Interactive supports are designed from detailed usage scenarios. Interfaces, legends, and information hierarchies are stress-tested before deployment.",
      card3Title: "Spatial UX frameworks",
      card3Text: "We craft spatial experience playbooks integrating readability, sensory anchors, and inclusivity. They ground architectural decision-making.",
      card4Title: "Information design",
      card4Text: "Information schemes translate site constraints into clear messages. Each element is tied to specific visual and verbal parameters to guarantee coherence.",
      card5Title: "Visual guidance research",
      card5Text: "Guidance devices are assessed for their ability to orient diverse audiences. We synthesise best practices from experimental programmes.",
      methodTitle: "Analytical process",
      methodIntro: "Every assignment follows a modular sequence adjusted to the site specificities.",
      methodStep1Title: "Immersion and collection",
      methodStep1Text: "On-site visits, signage inventories, and short interviews provide the baseline documentation.",
      methodStep2Title: "Modelling and prototyping",
      methodStep2Text: "Data triangulation, interactive mock-ups, rapid testing with users.",
      methodStep3Title: "Reporting and follow-up",
      methodStep3Text: "Mapped synthesis, prioritised recommendations, and follow-up monitoring plan.",
      deliverablesTitle: "Reporting formats",
      deliverablesIntro: "Deliverables favour actionable formats that circulate easily within organisations.",
      deliverable1: "Annotated atlas highlighting friction zones and improvement levers.",
      deliverable2: "Prioritisation tables for updating digital and physical supports.",
      deliverable3: "Dashboards to monitor circulation and readability indicators.",
      closingTitle: "Collaboration frame",
      closingText: "Assignments are co-built with operational teams, from preliminary audits to incremental deployment phases."
    },
    about: {
      heroEyebrow: "Profile",
      heroTitle: "A study unit dedicated to the readability of built spaces",
      heroSubtitle: "We combine expertise in information architecture, urban design, and behavioural sciences to illuminate user journeys.",
      heroImageAlt: "Orientation maps and diagrams spread on a table",
      missionTitle: "Mission",
      missionText: "danswholesaleplants documents how people move through complex environments and translates those behaviours into actionable guidance for public space managers.",
      valuesTitle: "Working principles",
      valuesIntro: "Our research is framed by foundational principles.",
      values1: "Situated observation: balance quantitative measures with lived stories.",
      values2: "Readability first: favour clarity over information overload.",
      values3: "Inclusion: address diverse sensory and linguistic capacities.",
      values4: "Iteration: refine proposals based on field feedback.",
      timelineTitle: "Milestones",
      timelineIntro: "Highlights shaping our trajectory.",
      timeline1Date: "2016",
      timeline1Text: "Drafted initial observation protocols for metropolitan stations.",
      timeline2Date: "2018",
      timeline2Text: "Developed a mobile lab to test digital signage in situ.",
      timeline3Date: "2020",
      timeline3Text: "Built a comparative database on multilingual guidance devices.",
      timeline4Date: "2023",
      timeline4Text: "Launched continuous pedestrian flow monitoring across open campuses.",
      capabilitiesTitle: "Capabilities",
      capabilitiesIntro: "The team gathers complementary skills covering the entire analytical chain.",
      capability1: "Information architects specialised in mapping.",
      capability2: "Urban data analysts and flow modellers.",
      capability3: "Interface designers focused on navigation.",
      capability4: "Behavioural researchers and accessibility specialists.",
      cultureTitle: "Working culture",
      cultureText: "We promote collaborative formats with stakeholders: co-reading workshops, prototype reviews, and shared monitoring tools secure transparent decisions."
    },
    blog: {
      heroEyebrow: "Analyses",
      heroTitle: "Analyses and observation journals",
      heroSubtitle: "Publications focused on spatial orientation, digital signage, and navigation within complex environments.",
      heroImageAlt: "Board with plans and colour annotations",
      archiveNote: "Articles are listed in reverse chronological order.",
      card1Date: "12 February 2024",
      card1Title: "Modeling multi-level journeys for civic campuses",
      card1Excerpt: "Insights from an observation programme dedicated to layered civic campuses. It explores the gap between intended and actual pathways and how vertical cues align.",
      card1Alt: "Interactive signage screen in an atrium",
      card2Date: "28 January 2024",
      card2Title: "Synchronising sensors and observation to guide users",
      card2Excerpt: "Ways to combine passive sensors, qualitative records, and digital mapping to preserve fluid navigation inside public buildings.",
      card2Alt: "Sensor device installed above a corridor",
      card3Date: "14 January 2024",
      card3Title: "Measuring large-scale map readability",
      card3Excerpt: "Building readability indicators for printed and interactive maps, with emphasis on information hierarchy.",
      card3Alt: "Wall map with coloured zones and pictograms",
      card4Date: "20 December 2023",
      card4Title: "Adaptive signage for multilingual spaces",
      card4Excerpt: "Study of dynamic supports that adjust to various linguistic and cognitive profiles within one building.",
      card4Alt: "Digital panel displaying multiple languages",
      card5Date: "5 December 2023",
      card5Title: "Spatial analytics for pedestrian emergency scenarios",
      card5Excerpt: "Analysis of flows under emergency conditions and recommendations to embed resilience into orientation systems.",
      card5Alt: "Backlit evacuation plan in a corridor",
      readMore: "Read the analysis"
    },
    posts: {
      publishedLabel: "Published:",
      readingTimeLabel: "Reading time:",
      post1: {
        date: "12 February 2024",
        readingTime: "7",
        heroAlt: "Digital signage in a multi-level atrium",
        heroCaption: "Synchronising vertical cues on a civic campus.",
        title: "Modeling multi-level journeys for civic campuses",
        h2: "Interpreting circulation data beyond floor plans",
        h3: "Synthesising digital signage with human wayfinding",
        p1: "Large civic campuses combine administrative, cultural, and mobility functions, creating layered circulation patterns for visitors and staff. When people arrive, they reconcile printed directions, architectural cues, and digital signage while moving across floors. Our observation programme documented divergence between intended and actual pathways. Capturing those first encounters is essential to evaluate how orientation systems translate design strategies into understandable routes.",
        p2: "Baseline mapping started with synchronised walks at different times of day. Teams traced identical origin-destination pairs, noting obstacles, noise levels, and the density of visual prompts. The data revealed that vertical transitions such as mezzanines or split stairs introduced more hesitation than corridor length. Participants relied heavily on ambient lighting to confirm corridor continuity, highlighting the need to coordinate cues with light gradients.",
        p3: "Digital signage performed best when messages mirrored the natural field of view. Screens positioned perpendicular to walking direction forced readers to stop completely, breaking flow. Angled content with clear hierarchy supported quick confirmation checks. Simulations showed that icon consistency mattered more than colour palettes; whenever icons shifted across floors, visitors reverted to asking staff instead of trusting the devices.",
        p4: "Layering information across floors required reconciling numbering schemes with thematic zones. Many campuses label mezzanines as interim levels, confusing visitors expecting whole-number floors. We experimented with relational descriptors such as “above public hall” or “below archive wing”. Wayfinding interviews indicated these relative references reduced backtracking by eighteen percent, underscoring the value of language aligned with mental models.",
        p5: "Sensor-based counts complemented human observation by capturing late-evening drifts. Passive infrared beams logged circulation intensity without storing personal data. Cross-referencing those peaks with annotated maps clarified where signage should pivot to night-mode layouts. Directing people towards exits staffed after nineteen hundred hours prevented bottlenecks in the main rotunda.",
        p6: "Ultimately, modelling multi-level journeys demands iterative negotiation between architecture, language, and technology. Aligning digital signage with physical markers, lighting, and vocabulary builds confidence for occasional and frequent users alike. Civic campuses evolve constantly; maintaining orientation quality requires revisiting these indicators whenever functions shift. Our framework offers checkpoints to keep that dialogue active."
      },
      post2: {
        date: "28 January 2024",
        readingTime: "6",
        heroAlt: "Light sensors above a busy corridor",
        heroCaption: "Cross-checking passive sensors with qualitative observation.",
        title: "Synchronising sensors and observation to guide users",
        h2: "Combining instrumented data with human readings",
        h3: "Structuring outputs for multidisciplinary teams",
        p1: "Passive sensors are increasingly common in contemporary public buildings: infrared gates, optical counters, and Bluetooth beacons measure attendance. On their own, these datasets remain difficult to activate for signage decisions. The challenge is to align them with human observations describing motivations and perception. Our lab designed a protocol that blends both sources to produce operational recommendations.",
        p2: "The first step is to map sensor positions accurately and qualify their sensitivity. Each device reacts differently to light variations, silhouettes, or walking speeds. We cross-check these records with companion tours where observers note tasks, expectations, and attention points. This reveals, for example, that some peaks correspond to deliberate pauses in front of a screen rather than congestion.",
        p3: "Datasets are then harmonised within a shared timeline. We align timestamps, normalise time zones, and incorporate contextual annotations: temporary escalator shutdowns, cultural events, weather conditions. This layer changes interpretation: identical flow volumes can be satisfactory or problematic depending on the availability of alternative routes.",
        p4: "Outputs take the form of narrative maps composed of three panels: sensor vision, observer vision, synthesis. The format fosters discussion among technicians, operations managers, and information designers. Each panel highlights its limits—sensor blind spots, interpretation bias, need for field verification—so decisions rely on a shared understanding of both assets and uncertainties.",
        p5: "We also developed a composite indicator weighting captured density, observed hesitation, and signage clarity. It produces a vigilance score that triggers targeted workshops when thresholds are exceeded. Workshops gather site managers and frontline teams to test new phrasings or tactical repositioning in real time.",
        p6: "Synchronising sensors and observation is not about merging every data point into a single spreadsheet. It is about fostering a rigorous dialogue between instruments and human expertise. The added value stems from continuously confronting both views, enriching knowledge of journeys, and sustaining adaptive orientation devices."
      },
      post3: {
        date: "14 January 2024",
        readingTime: "7",
        heroAlt: "Building map with colour-coded legend",
        heroCaption: "Readability matrix for printed and digital maps.",
        title: "Measuring large-scale map readability",
        h2: "Building an indicator framework",
        h3: "Applying the grid to hybrid devices",
        p1: "Maps are central to orientation, whether posted on walls, distributed as brochures, or accessed on screens. Yet readability often remains subjective. We designed an indicator framework to evaluate large-scale maps more systematically and guide iterations.",
        p2: "The framework covers three families: visual composition, information hierarchy, and terminological coherence. Each family includes measurable criteria. Composition looks at symbol density per zone, breathing margins, and alignment of key anchors. User testing validates the thresholds.",
        p3: "We applied the framework to maps from stations and university campuses. Findings showed many issues stem from stacking undifferentiated information layers. When pictograms, text, and lines share the same visual weight, reading slows down. Priority recommendations reintroduce contrast via colour, texture, or stroke thickness.",
        p4: "Analysis also emphasised terminological coherence. A space labelled “welcome desk” on one support and “reception” on another confuses users. The framework therefore includes a lexical audit comparing maps, signage, and digital documents. It ensures identical naming across channels to reduce ambiguity.",
        p5: "For hybrid devices we added a dynamic dimension: screen response time, zoom animation, language switching. Digital readability is not just about resolution; it depends on how content appears and reorganises. Tests advise avoiding transitions that move too fast for the eye to follow.",
        p6: "In summary, measuring map readability requires blending objective metrics with user feedback. The proposed framework gives cartographers, designers, and site managers a shared language. It helps prioritise actions, from simplifying a legend to refining an interactive layout.",
        p7: "The methodology stays open: each new context introduces specificities that must be integrated. Field feedback continuously feeds the framework, keeping it relevant across diverse environments."
      },
      post4: {
        date: "20 December 2023",
        readingTime: "6",
        heroAlt: "Digital panel displaying multiple languages",
        heroCaption: "Real-time adjustable multilingual interface.",
        title: "Adaptive signage for multilingual spaces",
        h2: "Mapping linguistic needs",
        h3: "Configuring flexible hierarchies",
        p1: "Public environments require signage capable of rapid language adjustments. Literal translation is not enough; cultural registers, typographic constraints, and existing supports matter. Our study focuses on mechanisms that make signage genuinely adaptive.",
        p2: "We start by analysing linguistic profiles in detail, combining demographic data, field observation, and frontline feedback. The mapping identifies priority languages and key moments for adaptation, such as international events or tourist peaks.",
        p3: "We then define a modular content architecture. Messages are segmented into reusable units, making it easier to reorganise them per language. Each unit is paired with a pictogram to maintain visual recognition even when text changes, ensuring overall coherence while allowing rapid updates.",
        p4: "Flexible hierarchy relies on priority rules: default language, alternated display order, emphasis on critical information. Tests show automatic rotation every thirty seconds is acceptable if essential messages remain permanently visible. Screens also provide a touch option to select a language.",
        p5: "To support technical teams, we supply an orchestration guide detailing parameters: translation sources, typographic templates, switching thresholds. It includes a linguistic validation protocol with community representatives to guarantee relevant phrasing.",
        p6: "Adaptability extends beyond screens. Physical supports integrate magnetic overlays or modular panels so primary language can shift over time. The goal is to preserve readability without flooding spaces with concurrent content.",
        p7: "Adaptive signage therefore balances flexibility and stability. Documenting needs precisely and providing management tools enables coherent experiences for varied audiences without overloading environments."
      },
      post5: {
        date: "5 December 2023",
        readingTime: "7",
        heroAlt: "Backlit evacuation plan in a corridor",
        heroCaption: "Emergency scenarios and controlled pedestrian flows.",
        title: "Spatial analytics for pedestrian emergency scenarios",
        h2: "Understanding dynamic reactions",
        h3: "Embedding resilience into orientation devices",
        p1: "Emergency scenarios trigger behaviours different from daily circulation. Stress, urgency, and group dynamics reshape trajectories. Our study explores how spatial analytics can anticipate such reactions to strengthen orientation resilience.",
        p2: "We first modelled flows using agent-based simulations including density, speed, visibility, and noise variables. Results highlight that partial darkness and blind corners cause abrupt slowdowns. Trajectories gravitate towards walls, making wall-mounted signage harder to read.",
        p3: "Full-scale drills complement modelling. Diverse groups follow scenarios featuring smoke, blocked exits, or failed alarms. Observers note hesitation patterns and avoided exits. Participants favour familiar routes, even longer ones, confirming the need for recognisable cues.",
        p4: "Spatial analytics ties observations to real-time data: crowd sensors, door status, lighting. We propose a decision matrix indicating when to switch to dynamic light guidance, redirect flows, or trigger multilingual audio messages.",
        p5: "Resilience also depends on prepared supports. Evacuation maps must remain readable under low visibility: strong contrast, tactile pictograms, strategic placement. Screens embed a degraded mode prioritising simple text and animated arrows.",
        p6: "We recommend periodic reviews of orientation devices, including night tests and specific scenarios (maintenance, events). Each review feeds a feedback base to adjust protocols.",
        p7: "With this approach, orientation covers both ordinary and critical contexts. Users gain confidence, and teams receive tools to steer signage under pressure."
      }
    },
    contact: {
      heroEyebrow: "Contact",
      heroTitle: "Discuss your complex environments",
      heroSubtitle: "We analyse circulation and signage situations within public buildings, campuses, or multimodal networks.",
      heroImageAlt: "Person reviewing an interactive map",
      introTitle: "Get in touch",
      introText: "Share your site context. We arrange exploratory conversations to understand your needs and scope the necessary observations.",
      infoAddressLabel: "Address",
      infoPhoneLabel: "Phone",
      infoEmailLabel: "Email",
      infoHoursLabel: "Response window",
      infoHoursText: "Monday to Friday, 09:00 - 18:00 (UTC+1).",
      mapCaption: "Office location in Brussels.",
      formTitle: "Contact form",
      formDescription: "Please outline the context, building typology, and navigation challenges you have identified.",
      formNameLabel: "Full name",
      formNamePlaceholder: "e.g. Dominique Dupont",
      formEmailLabel: "Email address",
      formEmailPlaceholder: "e.g. firstname.lastname@example.com",
      formOrgLabel: "Organisation / Department",
      formOrgPlaceholder: "e.g. Directorate of planning",
      formTopicLabel: "Main topic",
      formTopicDefault: "Select a topic",
      formTopicOption1: "Pedestrian flow audit",
      formTopicOption2: "Digital signage and mapping",
      formTopicOption3: "Spatial UX framework",
      formMessageLabel: "Message",
      formMessagePlaceholder: "Describe the areas involved, readability goals, and timelines.",
      formSubmit: "Send request",
      formNote: "Information shared is used solely to arrange an initial exchange.",
      followUpTitle: "Next steps",
      followUpText: "We respond within five working days with a methodological outline."
    },
    faq: {
      heroEyebrow: "FAQ",
      heroTitle: "Frequently asked questions",
      heroSubtitle: "Answers to recurring questions about our analysis and reporting protocols.",
      heroImageAlt: "Meeting notes spread across a desk",
      q1: "Do you operate only in Belgium?",
      a1: "We are based in Brussels but work on comparable European sites. Studies can be conducted in French, English, or Dutch.",
      q2: "How does an observation campaign unfold?",
      a2: "An initial phase maps key nodes and expected flows. Field observers then capture data, complemented by anonymised sensors.",
      q3: "Do you provide digital tools?",
      a3: "We prototype interactive maps and dynamic panels with implementation guidelines for technical teams.",
      q4: "What is the average mission duration?",
      a4: "It depends on site complexity. Expect four to twelve weeks covering observation, modelling, and recommendations.",
      q5: "How do you address accessibility?",
      a5: "Dedicated workshops gather users with varied sensory profiles. Their feedback feeds orientation matrices.",
      q6: "Do you deliver training material?",
      a6: "Yes, we craft supporting material to help internal teams adopt the recommendations."
    },
    terms: {
      heroEyebrow: "Terms",
      heroTitle: "Terms of use",
      heroSubtitle: "Framework governing access to danswholesaleplants.com.",
      heroImageAlt: "Legal documents and laptop on a desk",
      intro: "By accessing danswholesaleplants.com you agree to the following terms.",
      section1Title: "1. Purpose",
      section1Body: "These terms define access and usage rules for the content published by danswholesaleplants.",
      section2Title: "2. Definitions",
      section2Body: "\"Site\" refers to the platform available at danswholesaleplants.com. \"User\" refers to any person browsing the site.",
      section3Title: "3. Acceptance",
      section3Body: "Browsing the site implies full acceptance of these terms. If you disagree, please discontinue your visit.",
      section4Title: "4. Site changes",
      section4Body: "danswholesaleplants may modify content, features, or access without prior notice.",
      section5Title: "5. User responsibility",
      section5Body: "Users commit to lawful use of the site and to refraining from disrupting its proper operation.",
      section6Title: "6. Intellectual property",
      section6Body: "All content, texts, visuals, and data are the exclusive property of danswholesaleplants or its partners and cannot be reproduced without written consent.",
      section7Title: "7. Proper use of content",
      section7Body: "Any extraction or reuse must preserve content integrity and cite the source.",
      section8Title: "8. External sources",
      section8Body: "The site may link to third-party resources. danswholesaleplants is not responsible for their content.",
      section9Title: "9. Information accuracy",
      section9Body: "Information is provided for guidance. We strive for relevance but cannot guarantee completeness.",
      section10Title: "10. Accessibility",
      section10Body: "We maintain a high accessibility level. Maintenance may temporarily limit access.",
      section11Title: "11. Data protection",
      section11Body: "The privacy policy details how personal data is processed.",
      section12Title: "12. Service availability",
      section12Body: "The site is accessible seven days a week, subject to maintenance or network constraints.",
      section13Title: "13. Governing law",
      section13Body: "These terms are governed by Belgian law. Disputes fall under Brussels courts.",
      section14Title: "14. Contact",
      section14Body: "Questions about these terms? Contact contact@danswholesaleplants.com."
    },
    privacy: {
      heroEyebrow: "Privacy",
      heroTitle: "Privacy policy",
      heroSubtitle: "Our commitments regarding personal data protection.",
      heroImageAlt: "Keyboard, notepad, and lock symbolising confidentiality",
      section1Title: "1. Introduction",
      section1Body: "This policy explains how personal data is collected and processed when using the site.",
      section2Title: "2. Data controller",
      section2Body: "The controller is danswholesaleplants, Rue de la Loi 200, 1040 Brussels.",
      section3Title: "3. Data collected",
      section3Body: "We only collect data submitted through the contact form (name, email address, organisation, message).",
      section4Title: "4. Purposes",
      section4Body: "Data is used to respond to messages and prepare follow-up conversations.",
      section5Title: "5. Legal basis",
      section5Body: "Processing relies on the legitimate interest of answering requests addressed to danswholesaleplants.",
      section6Title: "6. Retention",
      section6Body: "Data is retained for twelve months after the last exchange, unless legal obligations require otherwise.",
      section7Title: "7. Data sharing",
      section7Body: "Data is not shared with third parties unless required by law or competent authorities.",
      section8Title: "8. Rights",
      section8Body: "You may access, rectify, erase, or restrict processing. Contact contact@danswholesaleplants.com to exercise your rights.",
      section9Title: "9. Security",
      section9Body: "We implement technical and organisational measures to protect data from unauthorised disclosure.",
      section10Title: "10. Transfers outside the EU",
      section10Body: "No data transfers outside the European Union are performed.",
      section11Title: "11. Updates",
      section11Body: "This policy may evolve. Updates appear on this page with the effective date."
    },
    cookiesPage: {
      heroEyebrow: "Cookies",
      heroTitle: "Cookie policy",
      heroSubtitle: "Details on cookie and local storage usage.",
      heroImageAlt: "Digital cookie icon on a screen",
      intro: "This site uses minimal local storage to enhance user experience. You can manage preferences through the dedicated banner.",
      usageTitle: "Cookie usage",
      usageText: "We use necessary cookies to operate the site and optional ones to enrich the experience.",
      tableTitle: "Cookie details",
      tableName: "Name",
      tableProvider: "Provider",
      tableType: "Type",
      tablePurpose: "Purpose",
      tableDuration: "Duration",
      row1Name: "cookie_consent",
      row1Provider: "danswholesaleplants",
      row1Type: "Necessary",
      row1Purpose: "Stores your cookie preferences.",
      row1Duration: "12 months",
      row2Name: "site_lang",
      row2Provider: "danswholesaleplants",
      row2Type: "Preferences",
      row2Purpose: "Remembers the language selected for future visits.",
      row2Duration: "12 months",
      row3Name: "analytics_opt",
      row3Provider: "danswholesaleplants",
      row3Type: "Analytics",
      row3Purpose: "Indicates whether analytical tools can be activated.",
      row3Duration: "6 months",
      row4Name: "marketing_opt",
      row4Provider: "danswholesaleplants",
      row4Type: "Marketing",
      row4Purpose: "Records consent for potential partner content.",
      row4Duration: "6 months",
      manageTitle: "Preference management",
      manageText: "You can revisit your choices anytime via the “Manage cookies” option in the footer.",
      updateTitle: "Updates",
      updateText: "This policy may change. Updates are posted here with the new effective date."
    },
    refund: {
      heroEyebrow: "Restitution",
      heroTitle: "Restitution policy",
      heroSubtitle: "Process governing requests related to deliverables or exchanges.",
      heroImageAlt: "Person reviewing a file with a pen",
      section1Title: "1. Purpose",
      section1Body: "Clarify the restitution procedure applicable to intellectual deliverables produced by danswholesaleplants.",
      section2Title: "2. Scope",
      section2Body: "The policy covers studies, analyses, and documents shared with stakeholders at mission completion.",
      section3Title: "3. Principles",
      section3Body: "Deliverables follow jointly agreed methodologies. Modification requests are handled within that framework.",
      section4Title: "4. Cancellation by requester",
      section4Body: "Cancellations must be submitted in writing. A progress summary is provided to close the assignment.",
      section5Title: "5. Cancellation by danswholesaleplants",
      section5Body: "We may halt an assignment if mutual commitments are not met. A detailed progress report is delivered.",
      section6Title: "6. Deliverable revisions",
      section6Body: "Revision requests are assessed against initial objectives and collected material. A correction schedule is proposed.",
      section7Title: "7. Claims process",
      section7Body: "Claims must specify the deliverable, rationale, and expectations. We answer within ten working days.",
      section8Title: "8. Request evaluation",
      section8Body: "Requests are reviewed by the project team and, if needed, an external advisor to secure objective responses.",
      section9Title: "9. Required data",
      section9Body: "The requester provides supporting elements to clarify the situation and help design a response.",
      section10Title: "10. Processing time",
      section10Body: "Timeframes vary with case complexity and are communicated upon receipt.",
      section11Title: "11. Communication",
      section11Body: "Exchanges occur in writing to maintain full traceability of decisions and adjustments.",
      section12Title: "12. Updates",
      section12Body: "This policy may evolve. Updates are posted on the site with the effective date."
    },
    disclaimer: {
      heroEyebrow: "Disclaimer",
      heroTitle: "Disclaimer",
      heroSubtitle: "Usage limits concerning published information.",
      heroImageAlt: "Stack of files with a caution sign",
      section1Title: "1. Information provided",
      section1Body: "Content on the site is shared for informational purposes and does not constitute a contractual offer.",
      section2Title: "2. No guarantee",
      section2Body: "danswholesaleplants does not guarantee exhaustive accuracy and declines responsibility for use of the information.",
      section3Title: "3. Responsibility",
      section3Body: "Users remain solely responsible for decisions taken based on the consulted content.",
      section4Title: "4. Information changes",
      section4Body: "Content may be updated without notice to reflect project or research developments.",
      section5Title: "5. Contact",
      section5Body: "Questions regarding this disclaimer? Contact contact@danswholesaleplants.com."
    },
    thankyou: {
      heroEyebrow: "Confirmation",
      heroTitle: "Thank you for your message",
      heroSubtitle: "Your request has been recorded. We will respond within five working days.",
      heroImageAlt: "Person sending a message from a laptop",
      followUp: "Feel free to explore our analyses while we review your request."
    },
    cookieBanner: {
      title: "Cookie preferences",
      description: "We use cookies to secure the site, remember your language, and analyse performance. Choose your settings.",
      manage: "Configure",
      decline: "Decline all",
      accept: "Accept all",
      save: "Save",
      preferenceTitle: "Your cookie settings",
      necessaryTitle: "Necessary",
      necessaryText: "Required for the site to function.",
      alwaysOn: "Always on",
      preferencesTitle: "Preferences",
      preferencesText: "Remember language choices or layout options.",
      analyticsTitle: "Analytics",
      analyticsText: "Help us understand usage and improve content.",
      marketingTitle: "Marketing",
      marketingText: "Enable potential partner content.",
      updated: "Preferences updated."
    },
    forms: {
      success: "Request sent. We will respond shortly.",
      error: "Please complete the required fields before sending."
    },
    toast: {
      cookieAccepted: "Preferences saved.",
      cookieDeclined: "Non-essential cookies are disabled."
    }
  }
};

let currentLang = getStoredLanguage();

function getStoredLanguage() {
  const stored = localStorage.getItem(LANG_KEY);
  if (stored && I18N[stored]) {
    return stored;
  }
  return DEFAULT_LANG;
}

function setLanguage(lang) {
  if (!I18N[lang]) return;
  currentLang = lang;
  localStorage.setItem(LANG_KEY, lang);
  applyTranslations(lang);
  updateLanguageButtons(lang);
}

function getTranslation(lang, key) {
  if (!I18N[lang]) return key;
  const parts = key.split(".");
  let result = I18N[lang];
  for (const part of parts) {
    if (result && Object.prototype.hasOwnProperty.call(result, part)) {
      result = result[part];
    } else {
      return key;
    }
  }
  return result;
}

function applyTranslations(lang) {
  const root = document.documentElement;
  root.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.textContent = translation;
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("placeholder", translation);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("alt", translation);
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      document.title = translation;
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.getAttribute("data-i18n-meta");
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      el.setAttribute("content", translation);
    }
  });

  document.querySelectorAll("[data-i18n-attr]").forEach((el) => {
    const attrMap = el.getAttribute("data-i18n-attr");
    if (!attrMap) return;
    attrMap.split(",").forEach((pair) => {
      const [attr, key] = pair.split(":").map((s) => s.trim());
      if (attr && key) {
        const translation = getTranslation(lang, key);
        if (translation !== undefined) {
          el.setAttribute(attr, translation);
        }
      }
    });
  });

  document.querySelectorAll("*").forEach((el) => {
    Object.keys(el.dataset).forEach((dataKey) => {
      if (dataKey.startsWith("i18nAttr") && dataKey !== "i18nAttr") {
        const attrKey = el.dataset[dataKey];
        const translation = getTranslation(lang, attrKey);
        const suffix = dataKey.replace("i18nAttr", "");
        if (!suffix) return;
        const finalName = suffix
          .replace(/^[A-Z]/, (m) => m.toLowerCase())
          .replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`);
        if (translation !== undefined) {
          el.setAttribute(finalName, translation);
        }
      }
    });
  });
}

function updateLanguageButtons(lang) {
  document.querySelectorAll(".language-button").forEach((btn) => {
    const btnLang = btn.getAttribute("data-lang");
    if (btnLang === lang) {
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
}

function setupLanguageSwitcher() {
  document.querySelectorAll(".language-button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.getAttribute("data-lang");
      setLanguage(lang);
    });
  });
  updateLanguageButtons(currentLang);
}

function setupNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".primary-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

function highlightActiveNav() {
  const page = document.documentElement.dataset.page;
  if (!page) return;
  document
    .querySelectorAll(`.primary-nav a[data-nav="${page}"]`)
    .forEach((link) => link.classList.add("is-active"));
}

function setupCurrentYear() {
  const yearEl = document.getElementById("currentYear");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

function setupScrollReveal() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  document.querySelectorAll(".reveal-on-scroll").forEach((el) => {
    observer.observe(el);
  });
}

function showToast(key) {
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const message = getTranslation(currentLang, key);
  if (!message) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.add("visible");
  });
  setTimeout(() => {
    toast.classList.remove("visible");
    setTimeout(() => toast.remove(), 600);
  }, 3600);
}

function getStoredConsent() {
  const stored = localStorage.getItem(CONSENT_KEY);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch (error) {
    return null;
  }
}

function storeConsent(consent) {
  const payload = {
    necessary: true,
    preferences: !!consent.preferences,
    analytics: !!consent.analytics,
    marketing: !!consent.marketing,
    updatedAt: new Date().toISOString()
  };
  localStorage.setItem(CONSENT_KEY, JSON.stringify(payload));
}

function applyConsentToToggles(consent, toggles) {
  if (!consent) return;
  if (toggles.preferences) toggles.preferences.checked = !!consent.preferences;
  if (toggles.analytics) toggles.analytics.checked = !!consent.analytics;
  if (toggles.marketing) toggles.marketing.checked = !!consent.marketing;
}

function setupCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  const manageBtn = document.getElementById("cookieManage");
  const acceptBtn = document.getElementById("cookieAccept");
  const declineBtn = document.getElementById("cookieDecline");
  const saveBtn = document.getElementById("cookieSave");
  const form = document.getElementById("cookieForm");
  const reopenBtn = document.getElementById("openCookiePreferences");

  if (!banner || !manageBtn || !acceptBtn || !declineBtn || !saveBtn || !form) {
    return;
  }

  const toggles = {
    preferences: document.getElementById("cookieTogglePreferences"),
    analytics: document.getElementById("cookieToggleAnalytics"),
    marketing: document.getElementById("cookieToggleMarketing")
  };

  const stored = getStoredConsent();
  if (stored) {
    applyConsentToToggles(stored, toggles);
  } else {
    banner.classList.add("visible");
  }

  function closeBanner() {
    banner.classList.remove("visible");
    banner.setAttribute("aria-hidden", "true");
  }

  function openBanner() {
    banner.classList.add("visible");
    banner.setAttribute("aria-hidden", "false");
  }

  manageBtn.addEventListener("click", () => {
    banner.classList.toggle("show-preferences");
  });

  acceptBtn.addEventListener("click", () => {
    const consent = { preferences: true, analytics: true, marketing: true };
    applyConsentToToggles(consent, toggles);
    storeConsent(consent);
    closeBanner();
    showToast("toast.cookieAccepted");
  });

  declineBtn.addEventListener("click", () => {
    const consent = { preferences: false, analytics: false, marketing: false };
    applyConsentToToggles(consent, toggles);
    storeConsent(consent);
    closeBanner();
    showToast("toast.cookieDeclined");
  });

  saveBtn.addEventListener("click", () => {
    const consent = {
      preferences: toggles.preferences.checked,
      analytics: toggles.analytics.checked,
      marketing: toggles.marketing.checked
    };
    storeConsent(consent);
    closeBanner();
    showToast("cookieBanner.updated");
  });

  form.addEventListener("change", () => {
    const consent = {
      preferences: toggles.preferences.checked,
      analytics: toggles.analytics.checked,
      marketing: toggles.marketing.checked
    };
    storeConsent(consent);
  });

  if (reopenBtn) {
    reopenBtn.addEventListener("click", openBanner);
  }
}

function setupContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = form.querySelector("[name='name']");
    const email = form.querySelector("[name='email']");
    const message = form.querySelector("[name='message']");
    if (!name.value.trim() || !email.value.trim() || !message.value.trim()) {
      showToast("forms.error");
      return;
    }
    showToast("forms.success");
    setTimeout(() => {
      window.location.href = form.getAttribute("action") || "thank-you.html";
    }, 900);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  applyTranslations(currentLang);
  setupLanguageSwitcher();
  setupNavToggle();
  highlightActiveNav();
  setupCurrentYear();
  setupScrollReveal();
  setupCookieBanner();
  setupContactForm();
});