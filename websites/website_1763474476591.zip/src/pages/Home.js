import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const statsData = [
  { label: 'geschützte Endgeräte', value: 960, suffix: '+' },
  { label: 'individuelle Sicherheitspläne', value: 420, suffix: '' },
  { label: 'durchgeführte Trainingsstunden', value: 1200, suffix: '+' }
];

const servicesData = [
  {
    title: 'Grundschutz-Check',
    description:
      'Wir prüfen Ihr digitales Umfeld und geben Ihnen klare Empfehlungen, wie Sie sich vor den gängigsten Bedrohungen schützen.',
    icon: '🛡️',
    benefits: ['Passwörter & Zugangssicherheit', 'Sicherheits-Updates koordinieren', 'Sicherheitsbewusstsein stärken']
  },
  {
    title: 'Datenschutz & Identität',
    description:
      'Wir zeigen, wie Sie persönliche Daten bewusst teilen, Datenspuren reduzieren und Identitätsdiebstahl verhindern.',
    icon: '🔒',
    benefits: ['Datenschutz-Scans', 'Identitätsmonitoring', 'Phishing-Resilienz']
  },
  {
    title: 'Privatsphäre in sozialen Medien',
    description:
      'Individuelle Strategien für Social Media, damit Sie sichtbar bleiben, ohne Ihre Privatsphäre zu riskieren.',
    icon: '👥',
    benefits: ['Profilhygiene', 'Sichtbarkeit steuern', 'Sicher kommunizieren']
  },
  {
    title: 'Gerätesicherung & Backup',
    description:
      'Wir richten Backups, Verschlüsselung und Kindersicherung so ein, dass Sie jederzeit auf der sicheren Seite sind.',
    icon: '📱',
    benefits: ['Backup-Konzepte', 'Gerätehärtung', 'Sicherheits-Apps konfigurieren']
  }
];

const testimonialData = [
  {
    name: 'Julia H. aus Hamburg',
    quote:
      'Solivarenta hat mir endlich das Gefühl gegeben, digitale Sicherheit selbst im Griff zu haben. Die Erklärungen waren klar und ohne Fachjargon.',
    role: 'Freiberufliche Fotografin'
  },
  {
    name: 'Markus T. aus Berlin',
    quote:
      'Seit dem Workshop weiß ich, wie ich meine Familie vor Betrugsmaschen schütze. Besonders die praktische Schritt-für-Schritt-Begleitung hat überzeugt.',
    role: 'Vater von zwei Kindern'
  },
  {
    name: 'Lena B. aus Köln',
    quote:
      'Die Privatsphäre-Einstellungen auf meinen Geräten sind jetzt perfekt abgestimmt. Ich fühle mich sicherer und souveräner im Netz.',
    role: 'Marketing Managerin'
  }
];

const teamMembers = [
  {
    id: 1,
    name: 'Kim Schneider',
    role: 'Lead Cyber Awareness',
    description:
      'Versteht sich als Übersetzerin zwischen Technik und Alltag. Entwickelt Lernpfade, die Wissen nachhaltig verankern.',
    focus: 'Sicherheitskompetenz stärken',
    image: 'https://picsum.photos/400/400?random=103'
  },
  {
    id: 2,
    name: 'Jonas Richter',
    role: 'Privacy Consultant',
    description:
      'Analysiert digitale Routinen und erstellt Privatsphäre-Konzepte, die wirklich in den Alltag passen.',
    focus: 'Datenschutz zum Mitmachen',
    image: 'https://picsum.photos/400/400?random=104'
  },
  {
    id: 3,
    name: 'Mira Afshar',
    role: 'Device Security Specialist',
    description:
      'Richtet Geräte, Backups und Sicherheits-Apps so ein, dass sie intuitiv genutzt werden können.',
    focus: 'Gerätesicherheit & Resilienz',
    image: 'https://picsum.photos/400/400?random=105'
  }
];

const projects = [
  {
    id: 1,
    title: 'Familien-Sicherheitskonzept',
    category: 'Privat',
    description: 'Mehrschichtiger Schutzplan für eine fünfköpfige Familie inklusive Kindersicherung.',
    image: 'https://picsum.photos/1200/800?random=205'
  },
  {
    id: 2,
    title: 'Digitale Sicherheit für Senior:innen',
    category: 'Training',
    description: 'Einfühlsame Begleitung beim sicheren Umgang mit Online-Banking und Messenger-Diensten.',
    image: 'https://picsum.photos/1200/800?random=206'
  },
  {
    id: 3,
    title: 'Freelance-Identität absichern',
    category: 'Privat',
    description: 'Maßgeschneiderte Sicherheitsmaßnahmen für sensible Kundendaten und mobile Geräte.',
    image: 'https://picsum.photos/1200/800?random=207'
  },
  {
    id: 4,
    title: 'Privatsphäre-Reset in Social Media',
    category: 'Training',
    description: 'Strategie-Workshop für mehr Sichtbarkeit ohne sensible Daten preiszugeben.',
    image: 'https://picsum.photos/1200/800?random=208'
  }
];

const faqItems = [
  {
    question: 'Wie läuft eine Beratung ab?',
    answer:
      'Wir starten immer mit einem kurzen Kennenlernen, analysieren Ihren aktuellen digitalen Alltag und definieren Ihre Ziele. Anschließend erhalten Sie einen verständlichen Maßnahmenplan und auf Wunsch eine persönliche Begleitung bei der Umsetzung.'
  },
  {
    question: 'Benötige ich technische Vorkenntnisse?',
    answer:
      'Nein. Wir erklären jedes Thema in klaren Worten, ohne Fachsprache. Unser Ziel ist, dass Sie selbst souveräne Entscheidungen treffen können.'
  },
  {
    question: 'Arbeiten Sie mit sensiblen Daten?',
    answer:
      'Ja, aber stets nach strengen Datenschutzprinzipien. Wir dokumentieren nur das Nötigste und verarbeiten keine Daten ohne ausdrückliche Zustimmung.'
  },
  {
    question: 'Gibt es Materialien zum Nachlesen?',
    answer:
      'Sie erhalten Leitfäden, Checklisten und kurze Video-Erklärungen, damit Sie das Gelernte jederzeit auffrischen können.'
  }
];

const blogPreviews = [
  {
    id: 1,
    title: 'Fünf Alltagsgewohnheiten für mehr digitale Resilienz',
    excerpt:
      'Sicherheit beginnt mit bewusstem Verhalten. Wir zeigen einfache Routinen, die sich ohne großen Aufwand etablieren lassen.',
    date: '02. Januar 2024',
    image: 'https://picsum.photos/800/600?random=302',
    tag: 'Digitaler Alltag'
  },
  {
    id: 2,
    title: 'Passwort-Manager: Worauf Privatpersonen achten sollten',
    excerpt:
      'Starke Passwörter müssen kein Rätsel sein. Wir vergleichen Strategien und zeigen, wie Sie den Überblick behalten.',
    date: '15. Dezember 2023',
    image: 'https://picsum.photos/800/600?random=303',
    tag: 'Grundschutz'
  },
  {
    id: 3,
    title: 'Geräte sicher einrichten: Die wichtigsten Basischecks',
    excerpt:
      'Ob Smartphone oder Laptop – mit wenigen Schritten schützen Sie Ihre Geräte wirksam vor Angriffen.',
    date: '22. November 2023',
    image: 'https://picsum.photos/800/600?random=304',
    tag: 'Geräteschutz'
  }
];

const Home = () => {
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const statsRef = useRef(null);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeTeamMember, setActiveTeamMember] = useState(teamMembers[0]);
  const [activeCategory, setActiveCategory] = useState('Alle');
  const [openFaq, setOpenFaq] = useState(null);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Alle') return projects;
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsAnimated) {
            setStatsAnimated(true);
          }
        });
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, [statsAnimated]);

  useEffect(() => {
    let animationFrame;
    if (statsAnimated) {
      const duration = 1600;
      const start = performance.now();

      const animate = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        const newCounts = statsData.map((stat) => Math.round(stat.value * progress));
        setCounts(newCounts);
        if (progress < 1) {
          animationFrame = requestAnimationFrame(animate);
        }
      };

      animationFrame = requestAnimationFrame(animate);
    }
    return () => cancelAnimationFrame(animationFrame);
  }, [statsAnimated]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonialData.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Solivarenta – Digitale Sicherheit für jeden verständlich</title>
        <meta
          name="description"
          content="Solivarenta begleitet Privatpersonen in Deutschland auf dem Weg zu mehr digitaler Sicherheit – mit verständlichen Tipps, praxisnahen Lösungen und persönlicher Beratung."
        />
        <link rel="canonical" href="https://www.solivarenta.site/" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <span className={styles.heroLabel}>Digitale Sicherheit für jeden verständlich</span>
              <h1>Wir machen Cybersicherheit greifbar – damit Sie selbstbestimmt bleiben.</h1>
              <p>
                Solivarenta begleitet Sie Schritt für Schritt: vom ersten Sicherheits-Check bis zur
                langfristigen Betreuung. Immer transparent, auf Augenhöhe und zugeschnitten auf Ihren
                Alltag.
              </p>
              <div className={styles.heroActions}>
                <Link to="/kontakt" className="btnPrimary">
                  Kostenlose Erstberatung sichern
                </Link>
                <Link to="/dienstleistungen" className="btnGhost">
                  Unser Ansatz
                </Link>
              </div>
              <div className={styles.heroAssurance}>
                <span>✓</span>
                <p>Vertraulich, unabhängig und in Deutschland entwickelt.</p>
              </div>
            </div>
            <div className={styles.heroVisual}>
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Person erhält digitale Sicherheitsberatung"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef} aria-labelledby="statistiken">
        <div className="container">
          <h2 id="statistiken" className="sectionTitle">
            Vertrauensvolle Zahlen aus unserer Arbeit
          </h2>
          <p className="sectionIntro">
            Wir messen den Erfolg daran, wie souverän sich Menschen im digitalen Raum bewegen. Jede
            Zahl steht für reale Erfolge.
          </p>
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <div className={styles.statValue}>
                  {counts[index]}
                  {stat.suffix}
                </div>
                <p>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.services} id="services" aria-labelledby="leistungen">
        <div className="container">
          <h2 id="leistungen" className="sectionTitle">
            Unsere Leistungen – verständlich, praxisnah, nachhaltig
          </h2>
          <p className="sectionIntro">
            Ob Einstieg oder Feinschliff: Wir entwickeln Sicherheitskonzepte, die sich an Ihren Alltag
            anpassen. Technische Tiefe nur dort, wo es wirklich hilft.
          </p>
          <div className={styles.serviceGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <ul>
                  {service.benefits.map((benefit) => (
                    <li key={benefit}>{benefit}</li>
                  ))}
                </ul>
                <Link to="/dienstleistungen" className={styles.serviceLink}>
                  Mehr erfahren
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.whyUs} aria-labelledby="warum-solivarenta">
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <h2 id="warum-solivarenta" className="sectionTitle">
                Warum Solivarenta?
              </h2>
              <p className="sectionIntro">
                Wir verbinden menschliche Empathie mit hochaktueller Cyber-Expertise. So entstehen
                Sicherheitslösungen, die wirklich gelebt werden können.
              </p>
              <div className={styles.bullets}>
                <div>
                  <h3>Einfache Erklärungen</h3>
                  <p>Wir übersetzen Fachsprache in verständliche Bilder und praxisnahe Storys.</p>
                </div>
                <div>
                  <h3>Praktische Lösungen</h3>
                  <p>Wir setzen gemeinsam um – Schritt für Schritt, ohne Überforderung.</p>
                </div>
                <div>
                  <h3>Persönliche Beratung</h3>
                  <p>Jeder Mensch hat andere Bedürfnisse. Wir hören zu und passen uns an.</p>
                </div>
              </div>
            </div>
            <div className={styles.whyImage}>
              <img
                src="https://picsum.photos/800/600?random=302"
                alt="Beratungssituation im Bereich Cybersicherheit"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="prozess">
        <div className="container">
          <h2 id="prozess" className="sectionTitle">
            So läuft unsere Zusammenarbeit
          </h2>
          <div className={styles.processSteps}>
            <article>
              <span>1</span>
              <h3>Aufnahme & Ziele</h3>
              <p>
                In einem Videocall oder vor Ort lernen wir Ihre digitale Welt kennen und klären, wo Sie
                Unterstützung wünschen.
              </p>
            </article>
            <article>
              <span>2</span>
              <h3>Individuelle Analyse</h3>
              <p>
                Wir prüfen Geräte, Konten und Routinen und bewerten Risiken nach Relevanz für Ihren Alltag.
              </p>
            </article>
            <article>
              <span>3</span>
              <h3>Handlungsplan & Umsetzung</h3>
              <p>
                Sie erhalten einen klaren Plan mit Prioritäten. Wir begleiten Sie bei der Umsetzung und
                beantworten alle Fragen.
              </p>
            </article>
            <article>
              <span>4</span>
              <h3>Begleitung & Training</h3>
              <p>
                Wir trainieren wichtige Skills, dokumentieren Einstellungen und bleiben auf Wunsch langfristig an Ihrer Seite.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="stimmen">
        <div className="container">
          <div className={styles.testimonialHeader}>
            <h2 id="stimmen" className="sectionTitle">
              Stimmen unserer Kundinnen und Kunden
            </h2>
            <div className={styles.testimonialControls} role="group" aria-label="Testimonials steuern">
              {testimonialData.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`${styles.dot} ${testimonialIndex === index ? styles.dotActive : ''}`}
                  onClick={() => setTestimonialIndex(index)}
                  aria-label={`Testimonial ${index + 1} von ${testimonialData.length}`}
                  aria-pressed={testimonialIndex === index}
                />
              ))}
            </div>
          </div>
          <div className={styles.testimonialSlider}>
            {testimonialData.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  testimonialIndex === index ? styles.testimonialVisible : ''
                }`}
                aria-hidden={testimonialIndex !== index}
              >
                <p className={styles.quote}>&ldquo;{testimonial.quote}&rdquo;</p>
                <div>
                  <p className={styles.person}>{testimonial.name}</p>
                  <p className={styles.role}>{testimonial.role}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team">
        <div className="container">
          <div className={styles.teamIntro}>
            <h2 id="team" className="sectionTitle">
              Ein Team, das zuhört und erklärt
            </h2>
            <p className="sectionIntro">
              Wir vereinen technisches Know-how mit pädagogischer Expertise. So entsteht ein geschützter Raum
              für Ihre Fragen.
            </p>
          </div>
          <div className={styles.teamLayout}>
            <div className={styles.teamCards} role="list">
              {teamMembers.map((member) => (
                <button
                  type="button"
                  key={member.id}
                  className={`${styles.teamCard} ${
                    activeTeamMember.id === member.id ? styles.teamActive : ''
                  }`}
                  onClick={() => setActiveTeamMember(member)}
                  role="listitem"
                  aria-pressed={activeTeamMember.id === member.id}
                >
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                  <div>
                    <h3>{member.name}</h3>
                    <p>{member.role}</p>
                  </div>
                </button>
              ))}
            </div>
            <div className={styles.teamDetail}>
              <h3>{activeTeamMember.name}</h3>
              <p className={styles.teamRole}>{activeTeamMember.role}</p>
              <p>{activeTeamMember.description}</p>
              <div className={styles.teamFocus}>
                <span>Schwerpunkt</span>
                <p>{activeTeamMember.focus}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projekte">
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2 id="projekte" className="sectionTitle">
              Bewährte Projekte aus der Praxis
            </h2>
            <div className={styles.projectFilter} role="group" aria-label="Projekte filtern">
              {['Alle', 'Privat', 'Training'].map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`${styles.filterButton} ${
                    activeCategory === category ? styles.filterActive : ''
                  }`}
                  onClick={() => setActiveCategory(category)}
                  aria-pressed={activeCategory === category}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectBody}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq">
        <div className="container">
          <div className={styles.faqLayout}>
            <div>
              <h2 id="faq" className="sectionTitle">
                Häufige Fragen
              </h2>
              <p className="sectionIntro">
                Transparenz steht für uns an erster Stelle. Hier beantworten wir die Fragen, die uns am
                häufigsten gestellt werden.
              </p>
              <Link to="/kontakt" className="btnGhost">
                Weitere Frage stellen
              </Link>
            </div>
            <div className={styles.faqItems}>
              {faqItems.map((item, index) => (
                <div key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    aria-expanded={openFaq === index}
                    aria-controls={`faq-panel-${index}`}
                    onClick={() => toggleFaq(index)}
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
                  </button>
                  <div
                    id={`faq-panel-${index}`}
                    className={`${styles.faqAnswer} ${openFaq === index ? styles.faqOpen : ''}`}
                  >
                    <p>{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.blogPreview} aria-labelledby="blog">
        <div className="container">
          <div className={styles.blogHeader}>
            <h2 id="blog" className="sectionTitle">
              Aktuelle Einblicke aus dem Ratgeber
            </h2>
            <Link to="/blog" className="btnLink">
              Zum Blog
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPreviews.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <div className={styles.blogImage}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogBody}>
                  <span>{post.tag}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <div className={styles.blogFooter}>
                    <time dateTime={post.date}>{post.date}</time>
                    <Link to="/blog">Weiterlesen</Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta">
        <div className="container">
          <div className={styles.ctaBox}>
            <div>
              <h2 id="cta">Bereit für mehr digitale Gelassenheit?</h2>
              <p>
                Buchen Sie eine kostenlose Erstberatung und lernen Sie, wie sichere Entscheidungen im
                digitalen Alltag gelingen.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/kontakt" className="btnPrimary">
                Erstgespräch vereinbaren
              </Link>
              <Link to="/dienstleistungen" className="btnGhost">
                Mehr über unseren Ansatz
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;