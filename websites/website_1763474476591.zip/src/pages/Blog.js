import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Blog.module.css';

const posts = [
  {
    id: 1,
    title: 'Wie Sie Phishing erkennen – fünf alltagstaugliche Signale',
    date: '08. Januar 2024',
    readTime: '6 Min.',
    tag: 'Awareness',
    excerpt:
      'Phishing versucht, Menschen zu emotionalen Schnellschüssen zu bewegen. Wir zeigen typische Muster und konkrete Schritte, die Sie sofort anwenden können.',
    body: [
      'Prüfen Sie Absenderadressen genau, achten Sie auf subtile Schreibfehler und lassen Sie sich nicht von künstlicher Dringlichkeit unter Druck setzen.',
      'Nutzen Sie Zwei-Faktor-Authentifizierung, um Konten auch dann zu schützen, wenn ein Passwort kompromittiert wurde. Halten Sie eine klare Routine für Passwort-Manager bereit.'
    ]
  },
  {
    id: 2,
    title: 'Digitaler Frühjahrsputz: Konten aufräumen und sichern',
    date: '12. Dezember 2023',
    readTime: '5 Min.',
    tag: 'Grundschutz',
    excerpt:
      'Veraltete Konten, ungenutzte Apps oder Berechtigungen können zu Einfallstoren werden. Unser Check hilft, Ordnung zu schaffen.',
    body: [
      'Inventarisieren Sie Ihre wichtigsten Dienste und entfernen Sie Zugänge, die Sie nicht mehr benötigen.',
      'Aktivieren Sie Benachrichtigungen für Sicherheitsmeldungen und setzen Sie ein Erinnerungsdatum, um Backups regelmäßig zu überprüfen.'
    ]
  },
  {
    id: 3,
    title: 'Privatsphäre auf Smartphones: Die Kern-Einstellungen',
    date: '28. November 2023',
    readTime: '7 Min.',
    tag: 'Mobile Sicherheit',
    excerpt:
      'Standortprotokolle, Tracking und Berechtigungen lassen sich gezielt steuern. Wir zeigen die wichtigsten Stellschrauben.',
    body: [
      'Überprüfen Sie App-Berechtigungen quartalsweise und deaktivieren Sie alles, was nicht nötig ist.',
      'Nutzen Sie Funktionen wie „Privates Relais“ oder sichere DNS-Dienste, um Ihren Datenverkehr besser zu schützen.'
    ]
  }
];

const Blog = () => (
  <>
    <Helmet>
      <title>Blog &amp; Ratgeber – Solivarenta</title>
      <meta
        name="description"
        content="Praktische Tipps, Checklisten und Hintergrundwissen zu digitaler Sicherheit, Datenschutz und Privatsphäre – verständlich für den Alltag erklärt."
      />
      <link rel="canonical" href="https://www.solivarenta.site/blog" />
    </Helmet>

    <section className={styles.intro}>
      <div className="container">
        <h1>Blog &amp; Ratgeber</h1>
        <p>
          Unser Ziel: Sicherheit bleibt kein Zufall. Wir veröffentlichen regelmäßig praxisnahe Impulse,
          damit Sie informierte Entscheidungen treffen können.
        </p>
      </div>
    </section>

    <section className={styles.posts}>
      <div className="container">
        <div className={styles.grid}>
          {posts.map((post) => (
            <article key={post.id} className={styles.card}>
              <header>
                <span className={styles.tag}>{post.tag}</span>
                <h2>{post.title}</h2>
                <div className={styles.meta}>
                  <time dateTime={post.date}>{post.date}</time>
                  <span>•</span>
                  <span>{post.readTime} Lesezeit</span>
                </div>
              </header>
              <p className={styles.excerpt}>{post.excerpt}</p>
              <div className={styles.body}>
                {post.body.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
              <footer>
                <p>
                  Sie möchten tiefer einsteigen? <a href="/kontakt">Wir beraten Sie individuell.</a>
                </p>
              </footer>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Blog;