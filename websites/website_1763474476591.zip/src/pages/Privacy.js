import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutzerklärung – Solivarenta</title>
      <meta
        name="description"
        content="Datenschutz hat für Solivarenta höchste Priorität. Lesen Sie, wie wir personenbezogene Daten verarbeiten und schützen."
      />
      <link rel="canonical" href="https://www.solivarenta.site/datenschutz" />
    </Helmet>

    <section className={styles.legal}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>Stand: Januar 2024</p>

        <h2>1. Verantwortliche Stelle</h2>
        <p>
          Solivarenta <br />
          Adresse: [WIRD NOCH BEKANNT GEGEBEN] <br />
          Telefon: [WIRD NOCH BEKANNT GEGEBEN] <br />
          E-Mail: [WIRD NOCH BEKANNT GEGEBEN]
        </p>

        <h2>2. Allgemeine Hinweise</h2>
        <p>
          Wir behandeln personenbezogene Daten vertraulich und entsprechend der gesetzlichen
          Datenschutzvorschriften sowie dieser Datenschutzerklärung. Personenbezogene Daten werden
          nur verarbeitet, wenn dies zur Bereitstellung unserer Leistungen erforderlich ist.
        </p>

        <h2>3. Server-Logfiles</h2>
        <p>
          Beim Aufruf dieser Website werden automatisch Informationen erfasst und temporär in Server-Logfiles
          gespeichert. Dazu gehören IP-Adresse, Datum und Uhrzeit des Zugriffs, Browsertyp und Betriebssystem.
          Diese Daten werden ausschließlich zur Sicherstellung eines störungsfreien Betriebs verarbeitet und
          nicht mit anderen Datenquellen zusammengeführt.
        </p>

        <h2>4. Kontaktaufnahme</h2>
        <p>
          Wenn Sie uns kontaktieren, speichern wir Ihre Angaben (Name, E-Mail, optional Telefonnummer) zur
          Bearbeitung Ihres Anliegens. Die Daten werden nicht ohne Ihre Zustimmung weitergegeben. Nach
          Abschluss des Vorgangs löschen wir die Daten, sofern keine gesetzlichen Aufbewahrungspflichten
          entgegenstehen.
        </p>

        <h2>5. Cookies</h2>
        <p>
          Wir verwenden ausschließlich technisch notwendige Cookies, um grundlegende Funktionen der Website
          zu ermöglichen. Weitere Informationen stehen in unserer{' '}
          <a href="/cookie-richtlinie">Cookie-Richtlinie</a>.
        </p>

        <h2>6. Ihre Rechte</h2>
        <p>
          Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung,
          Datenübertragbarkeit sowie Widerspruch. Bitte wenden Sie sich hierzu an die oben genannten
          Kontaktdaten.
        </p>

        <h2>7. Sicherheit</h2>
        <p>
          Wir setzen technische und organisatorische Maßnahmen ein, um Daten vor Manipulation, Verlust,
          unbefugtem Zugriff oder Offenlegung zu schützen. Unsere Sicherheitsmaßnahmen werden regelmäßig
          weiterentwickelt.
        </p>

        <h2>8. Änderungen</h2>
        <p>
          Wir behalten uns vor, diese Datenschutzerklärung anzupassen, damit sie stets den aktuellen
          rechtlichen Anforderungen entspricht.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;