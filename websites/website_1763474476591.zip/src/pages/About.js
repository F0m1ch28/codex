import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const milestones = [
  {
    year: '2020',
    title: 'Gründung von Solivarenta',
    description:
      'Aus der Überzeugung, dass digitale Sicherheit für alle Menschen zugänglich sein muss, entstand Solivarenta als unabhängige Beratung.'
  },
  {
    year: '2021',
    title: 'Aufbau des Awareness-Programms',
    description:
      'Wir entwickelten modulare Schulungen, die komplexe Themen in alltagsnahe Übungen übersetzen.'
  },
  {
    year: '2022',
    title: 'Zertifizierungen & Partnerschaften',
    description:
      'Unser Team erweiterte sein Know-how durch Datenschutz- und IT-Sicherheitszertifikate, um höchste Qualitätsstandards zu garantieren.'
  },
  {
    year: '2023',
    title: 'Begleitung von über 400 Haushalten',
    description:
      'Wir konnten Menschen in ganz Deutschland befähigen, eigene Sicherheitsstrategien aufzubauen und selbstbewusst anzuwenden.'
  }
];

const valueCards = [
  {
    title: 'Verständlichkeit',
    text: 'Wir erklären Sicherheit so, dass sie greifbar wird. Ohne Fachchinesisch, mit viel Geduld und Empathie.'
  },
  {
    title: 'Vertrauen',
    text: 'Diskretion und Transparenz sind unser Fundament. Wir sprechen offen über Risiken und Lösungen.'
  },
  {
    title: 'Wirksamkeit',
    text: 'Jede Empfehlung ist erprobt und alltagstauglich. Wir testen, messen und verbessern kontinuierlich.'
  }
];

const About = () => {
  const [expandedValue, setExpandedValue] = useState(null);

  const toggleValue = (index) => {
    setExpandedValue((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Über Solivarenta – Menschenzentrierte Cybersicherheit</title>
        <meta
          name="description"
          content="Lernen Sie das Team von Solivarenta kennen. Wir kombinieren pädagogische Erfahrung mit technischer Expertise, um digitale Sicherheit nahbar zu machen."
        />
        <link rel="canonical" href="https://www.solivarenta.site/ueber-uns" />
      </Helmet>

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <p className={styles.kicker}>Über Solivarenta</p>
              <h1>Digitale Sicherheit beginnt dort, wo Menschen verstanden werden.</h1>
              <p>
                Wir haben Solivarenta gegründet, weil wir überzeugt sind, dass Sicherheit kein Luxus sein darf.
                Unser Fokus liegt auf Menschen, die ihren digitalen Alltag bewusst gestalten möchten – ohne IT-Studium,
                aber mit dem Wunsch nach Klarheit und Kontrolle.
              </p>
              <p>
                Wir arbeiten unabhängig, transparent und mit einem hohen Anspruch an Datenschutz. Unsere Beratung ist
                persönlich, empathisch und konsequent lösungsorientiert.
              </p>
            </div>
            <div className={styles.introImage}>
              <img
                src="https://picsum.photos/800/600?random=312"
                alt="Solivarenta Team beim Workshop"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2 className="sectionTitle">Werte, die unser Handeln leiten</h2>
          <p className="sectionIntro">
            Unsere Prinzipien geben die Richtung vor – in jedem Gespräch, jeder Schulung und jedem Sicherheitskonzept.
          </p>
          <div className={styles.valueGrid}>
            {valueCards.map((value, index) => (
              <article key={value.title} className={styles.valueCard}>
                <button
                  type="button"
                  onClick={() => toggleValue(index)}
                  aria-expanded={expandedValue === index}
                >
                  <h3>{value.title}</h3>
                  <span aria-hidden="true">{expandedValue === index ? '−' : '+'}</span>
                </button>
                <div className={`${styles.valueBody} ${expandedValue === index ? styles.open : ''}`}>
                  <p>{value.text}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2>Unsere Mission</h2>
              <p>
                Wir wollen, dass digitale Sicherheit kein Angstthema mehr ist. Menschen sollen wissen, welche
                Entscheidungen sinnvoll sind, welche Risiken wirklich relevant sind und wie sie sich selbst schützen können.
              </p>
              <ul>
                <li>Begleitung mit Herz und Verstand</li>
                <li>Aufbereitete Informationen statt Überforderung</li>
                <li>Langfristige Entwicklung von Sicherheitskompetenz</li>
              </ul>
            </div>
            <div className={styles.missionCard}>
              <h3>Wir investieren in klare Sprache</h3>
              <p>
                Unser Team arbeitet kontinuierlich an neuen Lernformaten, Visualisierungen und Vergleichen, damit
                komplexe Inhalte intuitiv werden. Ob Online-Training oder persönlicher Termin – Transparenz hat Priorität.
              </p>
              <p>
                Wir stehen für praxisnahe Sicherheit, die sich in den Alltag integrieren lässt. Mit Freude am Lernen und
                einem klaren roten Faden.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.timeline} aria-labelledby="geschichte">
        <div className="container">
          <h2 id="geschichte" className="sectionTitle">
            Unsere Geschichte
          </h2>
          <div className={styles.timelineList}>
            {milestones.map((milestone) => (
              <article key={milestone.year}>
                <div className={styles.timelineYear}>{milestone.year}</div>
                <div className={styles.timelineContent}>
                  <h3>{milestone.title}</h3>
                  <p>{milestone.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.profiles}>
        <div className="container">
          <h2 className="sectionTitle">Menschen hinter Solivarenta</h2>
          <p className="sectionIntro">
            Wir bringen unterschiedliche Perspektiven zusammen und lernen auch selbst jeden Tag dazu – mit
            Weiterbildungen, Peer Reviews und offenem Austausch.
          </p>
          <div className={styles.profileGrid}>
            <article>
              <img src="https://picsum.photos/400/400?random=321" alt="Kim Schneider Portrait" loading="lazy" />
              <h3>Kim Schneider</h3>
              <p className={styles.role}>Gründerin &amp; Lead Cyber Awareness</p>
              <p>
                Kim entwickelte früh Bildungsformate für Cyber-Resilienz und legt Wert auf nachhaltige Lernprozesse.
                Ihre Spezialität sind interaktive Trainings, die nachhaltige Sicherheit vermitteln.
              </p>
            </article>
            <article>
              <img src="https://picsum.photos/400/400?random=322" alt="Jonas Richter Portrait" loading="lazy" />
              <h3>Jonas Richter</h3>
              <p className={styles.role}>Privacy Consultant</p>
              <p>
                Jonas verbindet juristisches Know-how mit technischer Umsetzung. Er sorgt dafür, dass Datenschutz
                handhabbar bleibt – auch für Menschen ohne IT-Hintergrund.
              </p>
            </article>
            <article>
              <img src="https://picsum.photos/400/400?random=323" alt="Mira Afshar Portrait" loading="lazy" />
              <h3>Mira Afshar</h3>
              <p className={styles.role}>Device Security Specialist</p>
              <p>
                Mira konzipiert Sicherheitsarchitekturen und richtet Geräte so ein, dass jede Einstellung nachvollziehbar
                bleibt. Geduld und Genauigkeit sind ihre Markenzeichen.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;