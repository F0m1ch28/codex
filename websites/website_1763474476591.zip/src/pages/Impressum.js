import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum – Solivarenta</title>
      <meta
        name="description"
        content="Impressum von Solivarenta – Angaben nach § 5 TMG."
      />
      <link rel="canonical" href="https://www.solivarenta.site/impressum" />
    </Helmet>

    <section className={styles.legal}>
      <div className="container">
        <h1>Impressum</h1>

        <h2>Angaben gemäß § 5 TMG</h2>
        <p>
          Solivarenta <br />
          Adresse: [WIRD NOCH BEKANNT GEGEBEN] <br />
          Telefon: [WIRD NOCH BEKANNT GEGEBEN] <br />
          E-Mail: [WIRD NOCH BEKANNT GEGEBEN]
        </p>

        <h2>Vertretungsberechtigte</h2>
        <p>Kim Schneider</p>

        <h2>Umsatzsteuer-ID</h2>
        <p>Wird nachgereicht.</p>

        <h2>Haftung für Inhalte</h2>
        <p>
          Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte verantwortlich. Nach §§ 8 bis 10
          TMG sind wir jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu
          überwachen. Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den
          allgemeinen Gesetzen bleiben hiervon unberührt.
        </p>

        <h2>Haftung für Links</h2>
        <p>
          Unser Angebot enthält Links zu externen Websites, auf deren Inhalte wir keinen Einfluss haben. Deshalb
          können wir für diese fremden Inhalte keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist
          stets der jeweilige Anbieter verantwortlich.
        </p>

        <h2>Urheberrecht</h2>
        <p>
          Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen
          Urheberrecht. Beiträge Dritter sind als solche gekennzeichnet. Die Vervielfältigung, Bearbeitung und
          Verbreitung außerhalb der Grenzen des Urheberrechts bedürfen der schriftlichen Zustimmung von Solivarenta.
        </p>
      </div>
    </section>
  </>
);

export default Impressum;