import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) {
      newErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    }
    if (!form.email.trim()) {
      newErrors.email = 'Eine E-Mail-Adresse ist erforderlich.';
    } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!form.message.trim()) {
      newErrors.message = 'Bitte beschreiben Sie Ihr Anliegen.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (submitted) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    setSubmitted(true);
    if (Object.keys(validation).length === 0) {
      setForm(initialFormState);
      setSubmitted(false);
      alert('Vielen Dank! Wir melden uns zeitnah bei Ihnen.');
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt – Solivarenta</title>
        <meta
          name="description"
          content="Nehmen Sie Kontakt zu Solivarenta auf. Gemeinsam finden wir den passenden Einstiegspunkt für mehr digitale Sicherheit."
        />
        <link rel="canonical" href="https://www.solivarenta.site/kontakt" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt aufnehmen</h1>
          <p>
            Beschreiben Sie uns Ihr Anliegen – wir melden uns innerhalb von zwei Werktagen und planen das
            weitere Vorgehen gemeinsam.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate aria-label="Kontaktformular">
              <div className={styles.field}>
                <label htmlFor="name">Ihr Name*</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  required
                />
                {errors.name && (
                  <span className={styles.error} role="alert">
                    {errors.name}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">E-Mail*</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  required
                />
                {errors.email && (
                  <span className={styles.error} role="alert">
                    {errors.email}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="phone">Telefon (optional)</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={form.phone}
                  onChange={handleChange}
                  placeholder="+49 ..."
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Ihr Anliegen*</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={form.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  required
                />
                {errors.message && (
                  <span className={styles.error} role="alert">
                    {errors.message}
                  </span>
                )}
              </div>
              <div className={styles.fieldCheckbox}>
                <input type="checkbox" id="privacy" required />
                <label htmlFor="privacy">
                  Ich habe die <a href="/datenschutz">Datenschutzhinweise</a> gelesen und stimme zu, dass
                  meine Angaben zur Kontaktaufnahme verwendet werden.
                </label>
              </div>
              <button type="submit" className="btnPrimary">
                Nachricht senden
              </button>
            </form>

            <aside className={styles.sidebar}>
              <div className={styles.contactBox}>
                <h2>Direkt erreichen</h2>
                <p>Adresse: [WIRD NOCH BEKANNT GEGEBEN]</p>
                <p>Telefon: [WIRD NOCH BEKANNT GEGEBEN]</p>
                <p>E-Mail: [WIRD NOCH BEKANNT GEGEBEN]</p>
              </div>
              <div className={styles.infoBox}>
                <h3>Sichere Zusammenarbeit</h3>
                <ul>
                  <li>Vertraulicher Umgang mit Ihren Informationen</li>
                  <li>Beratung per Video, vor Ort oder telefonisch</li>
                  <li>Individuelle Vorbereitung auf jedes Gespräch</li>
                </ul>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;