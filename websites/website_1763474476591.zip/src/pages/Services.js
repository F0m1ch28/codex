import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const services = [
  {
    title: 'Grundschutz-Programm',
    subtitle: 'Der solide Einstieg in digitale Sicherheit',
    description:
      'Gemeinsam identifizieren wir die wichtigsten Schutzmaßnahmen für Geräte, Konten und Daten. Sie erhalten einen klaren Plan mit Prioritäten.',
    highlights: [
      'Analyse Ihres Sicherheitsstatus',
      'Empfehlungen zu Passwörtern, Updates, Netzwerken',
      'Konkrete Maßnahmen für schnellen Schutz'
    ],
    outcome: 'Sie wissen, wo Risiken bestehen, und können sofort handeln.'
  },
  {
    title: 'Datenschutz & Privatsphäre',
    subtitle: 'Datenspuren verstehen und kontrollieren',
    description:
      'Wir zeigen, wie persönliche Informationen im Netz zirkulieren, und stärken Ihre digitale Identität mit praktischen Tools.',
    highlights: [
      'Privatsphäre-Check aller relevanten Konten',
      'Guidelines für Social Media & Cloud-Dienste',
      'Strategien gegen Identitätsdiebstahl'
    ],
    outcome:
      'Sie behalten die Kontrolle über Ihre Daten und treffen selbstbestimmte Entscheidungen.'
  },
  {
    title: 'Gerätesicherung & Backup',
    subtitle: 'Technik zuverlässig absichern',
    description:
      'Wir richten Sicherheitsfunktionen professionell ein, dokumentieren Einstellungen und vermitteln Hintergrundwissen.',
    highlights: [
      'Sichere Konfiguration von Smartphones, Tablets, Laptops',
      'Backup-Konzepte und Wiederherstellungspläne',
      'Kindersicherung & Familienkonten'
    ],
    outcome:
      'Ihre Geräte bleiben geschützt, Daten sind abgesichert und Wiederherstellung wird planbar.'
  },
  {
    title: 'Awareness-Training',
    subtitle: 'Wissen verankern, Routinen stärken',
    description:
      'Mit interaktiven Formaten lernt Ihr Umfeld, Bedrohungen zu erkennen und souverän zu reagieren.',
    highlights: [
      'Workshops online oder vor Ort',
      'Phishing-Simulationen & Lerntools',
      'Maßgeschneiderte Trainingspläne'
    ],
    outcome:
      'Sie bauen digitale Resilienz auf und entwickeln dauerhafte Sicherheitsgewohnheiten.'
  }
];

const Services = () => {
  const [selectedService, setSelectedService] = useState(services[0]);

  return (
    <>
      <Helmet>
        <title>Unsere Dienstleistungen – Solivarenta</title>
        <meta
          name="description"
          content="Solivarenta bietet Grundschutz, Datenschutz, Privatsphäre-Strategien und Gerätesicherung für Privatpersonen. Persönlich, verständlich, wirksam."
        />
        <link rel="canonical" href="https://www.solivarenta.site/dienstleistungen" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Unsere Leistungen für Ihren digitalen Alltag</h1>
          <p>
            Sicherheit ist kein Produkt, sondern ein Prozess. Wir begleiten Sie mit maßgeschneiderten
            Modulen, die sich flexibel kombinieren lassen – je nachdem, wo Sie gerade stehen.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.list} role="tablist" aria-label="Dienstleistungsübersicht">
              {services.map((service, index) => (
                <button
                  key={service.title}
                  type="button"
                  role="tab"
                  className={`${styles.listItem} ${
                    selectedService.title === service.title ? styles.active : ''
                  }`}
                  aria-selected={selectedService.title === service.title}
                  onClick={() => setSelectedService(service)}
                >
                  <h2>{service.title}</h2>
                  <p>{service.subtitle}</p>
                </button>
              ))}
            </div>
            <article className={styles.detail} role="tabpanel">
              <h2>{selectedService.title}</h2>
              <p className={styles.subtitle}>{selectedService.subtitle}</p>
              <p>{selectedService.description}</p>
              <h3>Ihre Vorteile auf einen Blick</h3>
              <ul>
                {selectedService.highlights.map((highlight) => (
                  <li key={highlight}>{highlight}</li>
                ))}
              </ul>
              <div className={styles.outcome}>
                <strong>Ergebnis:</strong>
                <p>{selectedService.outcome}</p>
              </div>
              <p className={styles.note}>
                Jede Begleitung beginnt mit einem unverbindlichen Erstgespräch. Wir stimmen Inhalte, Dauer und
                Umfang individuell mit Ihnen ab.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;