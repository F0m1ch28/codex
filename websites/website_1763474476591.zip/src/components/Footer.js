import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <h2>Solivarenta</h2>
          <p>
            Wir übersetzen komplexe Cybersicherheit in klare Handlungsempfehlungen für Menschen, die
            digitale Selbstbestimmung suchen.
          </p>
          <p className={styles.copy}>
            © {new Date().getFullYear()} Solivarenta. Alle Rechte vorbehalten.
          </p>
        </div>

        <div>
          <h3>Navigation</h3>
          <ul>
            <li>
              <Link to="/ueber-uns">Über uns</Link>
            </li>
            <li>
              <Link to="/dienstleistungen">Dienstleistungen</Link>
            </li>
            <li>
              <Link to="/blog">Blog &amp; Ratgeber</Link>
            </li>
            <li>
              <Link to="/kontakt">Kontakt</Link>
            </li>
          </ul>
        </div>

        <div>
          <h3>Kontakt</h3>
          <ul className={styles.contactList}>
            <li>
              Adresse: <span>[WIRD NOCH BEKANNT GEGEBEN]</span>
            </li>
            <li>
              Telefon: <span>[WIRD NOCH BEKANNT GEGEBEN]</span>
            </li>
            <li>
              E-Mail: <span>[WIRD NOCH BEKANNT GEGEBEN]</span>
            </li>
          </ul>
        </div>

        <div>
          <h3>Legal</h3>
          <ul>
            <li>
              <Link to="/impressum">Impressum</Link>
            </li>
            <li>
              <Link to="/datenschutz">Datenschutz</Link>
            </li>
            <li>
              <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>
            </li>
            <li>
              <Link to="/agb">AGB</Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;