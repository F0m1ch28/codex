import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'solivarenta_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setTimeout(() => setIsVisible(true), 1200);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive">
      <div className={styles.inner}>
        <div>
          <h2>Cookies &amp; Datenschutz</h2>
          <p>
            Wir verwenden nur technisch notwendige Cookies, um ein stabiles Nutzungserlebnis
            sicherzustellen. Weitere Informationen finden Sie in unserer{' '}
            <a href="/cookie-richtlinie">Cookie-Richtlinie</a>.
          </p>
        </div>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleConsent('declined')} className={styles.secondary}>
            Ablehnen
          </button>
          <button type="button" onClick={() => handleConsent('accepted')} className={styles.primary}>
            Akzeptieren
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;