import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Startseite' },
  { to: '/ueber-uns', label: 'Über uns' },
  { to: '/dienstleistungen', label: 'Dienstleistungen' },
  { to: '/blog', label: 'Blog & Ratgeber' },
  { to: '/kontakt', label: 'Kontakt' }
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMobile = () => setMobileOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.removeProperty('overflow');
    }
  }, [mobileOpen]);

  const closeMobile = () => setMobileOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} role="banner">
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="Solivarenta Startseite">
            <span className={styles.logoMark}>S</span>
            <span className={styles.logoText}>Solivarenta</span>
          </Link>
          <nav className={styles.nav} aria-label="Hauptnavigation">
            <ul className={styles.navList}>
              {navLinks.map((link) => (
                <li key={link.to}>
                  <NavLink
                    to={link.to}
                    className={({ isActive }) =>
                      isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                    }
                    onClick={closeMobile}
                  >
                    {link.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
          <button
            type="button"
            className={`${styles.burger} ${mobileOpen ? styles.open : ''}`}
            onClick={toggleMobile}
            aria-expanded={mobileOpen}
            aria-label="Menü öffnen oder schließen"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>

      <div
        className={`${styles.mobileMenu} ${mobileOpen ? styles.mobileOpen : ''}`}
        aria-hidden={!mobileOpen}
      >
        <nav aria-label="Mobile Navigation">
          <ul className={styles.mobileList}>
            {navLinks.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    isActive ? `${styles.mobileLink} ${styles.active}` : styles.mobileLink
                  }
                  onClick={closeMobile}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/kontakt" className={styles.mobileCta} onClick={closeMobile}>
            Kostenlose Erstberatung
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;