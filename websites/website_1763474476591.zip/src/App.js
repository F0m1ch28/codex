import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';

import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Blog from './pages/Blog';
import Contact from './pages/Contact';
import Privacy from './pages/Privacy';
import Impressum from './pages/Impressum';
import CookiePolicy from './pages/CookiePolicy';
import Terms from './pages/Terms';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className="app">
      <a className="skipLink" href="#hauptinhalt">
        Zum Inhalt springen
      </a>
      <Header />
      <ScrollToTopOnRouteChange />
      <main id="hauptinhalt">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/dienstleistungen" element={<Services />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
          <Route path="/agb" element={<Terms />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;