import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie – Solivarenta</title>
      <meta
        name="description"
        content="Informationen zur Verwendung von Cookies auf der Website von Solivarenta."
      />
      <link rel="canonical" href="https://www.solivarenta.site/cookie-richtlinie" />
    </Helmet>

    <section className={styles.legal}>
      <div className="container">
        <h1>Cookie-Richtlinie</h1>

        <p>Stand: Januar 2024</p>

        <h2>Was sind Cookies?</h2>
        <p>
          Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden, um bestimmte Informationen zu
          speichern. Sie richten keinen Schaden an und dienen dazu, unser Angebot nutzerfreundlicher zu gestalten.
        </p>

        <h2>Verwendung bei Solivarenta</h2>
        <p>
          Wir nutzen ausschließlich technisch notwendige Cookies. Diese sorgen dafür, dass Grundfunktionen wie
          Seitennavigation oder das Erinnern Ihrer Datenschutzeinstellungen funktionieren.
        </p>

        <h2>Verwaltung</h2>
        <p>
          Sie können Cookies jederzeit in Ihrem Browser löschen oder deaktivieren. In diesem Fall kann es sein,
          dass Teile der Website nicht vollständig nutzbar sind.
        </p>

        <h2>Weitere Informationen</h2>
        <p>
          Fragen zur Cookie-Nutzung beantworten wir gerne per E-Mail an{' '}
          <span>[WIRD NOCH BEKANNT GEGEBEN]</span>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;

<!-- correction: file path is incorrect. Need to ensure actual file path spelled properly. Should be src/pages/CookiePolicy.js with proper content spelled. fix** Undo previous mis type. Need to rewriting file.

We'll deliver correct file content.

We should re-provide proper file.

-->