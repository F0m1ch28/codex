import React, { useEffect } from 'react';
import styles from './ArchivesPage.module.css';

const archives = [
  {
    id: 'boulevard-saint-germain',
    title: 'Boulevard Saint-Germain : résonances civiques',
    date: 'Janvier 2024',
    location: 'Paris (7e, 6e et 5e arrondissements)',
    summary:
      "Analyse des grandes transformations du boulevard depuis la Troisième République, avec mise en perspective des projets urbains contemporains.",
    image: '/images/boulevard-saint-germain.jpg'
  },
  {
    id: 'faubourg-saint-antoine',
    title: 'Rue du Faubourg-Saint-Antoine : mémoires ouvrières',
    date: 'Décembre 2023',
    location: 'Paris (11e et 12e arrondissements)',
    summary:
      "Dossier consacré aux ateliers, passages et coopératives qui ont façonné l’identité artisanale de la rue.",
    image: '/images/rue-faubourg-saint-antoine.jpg'
  },
  {
    id: 'cours-mirabeau',
    title: 'Cours Mirabeau : promenade aixoise et sociabilités',
    date: 'Novembre 2023',
    location: 'Aix-en-Provence',
    summary:
      "Croisement des archives municipales et de témoignages pour décrire la construction du Cours comme scène urbaine majeure.",
    image: '/images/cours-mirabeau-aix.jpg'
  },
  {
    id: 'montee-gourguillon',
    title: 'Montée du Gourguillon : strates lyonnaises',
    date: 'Octobre 2023',
    location: 'Lyon (Vieux Lyon)',
    summary:
      "Enquête sur la persistance des tracés médiévaux et les dynamiques patrimoniales associées au secteur sauvegardé.",
    image: '/images/montee-gourguillon-lyon.jpg'
  },
  {
    id: 'rue-saint-jean-nancy',
    title: 'Rue Saint-Jean : transition commerçante à Nancy',
    date: 'Septembre 2023',
    location: 'Nancy',
    summary:
      "Étude des mutations commerciales et de la requalification piétonne dans une perspective de revitalisation du centre ancien.",
    image: '/images/rue-saint-jean-nancy.jpg'
  },
  {
    id: 'rue-sainte-catherine-bordeaux',
    title: 'Rue Sainte-Catherine : flux et héritages bordelais',
    date: 'Août 2023',
    location: 'Bordeaux',
    summary:
      "Analyse des flux piétonniers, des politiques d’aménagement et des enjeux de patrimoine dans la plus longue rue commerçante européenne.",
    image: '/images/rue-sainte-catherine-bordeaux.jpg'
  }
];

const ArchivesPage = () => {
  useEffect(() => {
    document.title = 'Archives | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Archives des études publiées par Historic Streets of France Review : un panorama des rues françaises analysées."
      );
    }
  }, []);

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Archives</span>
        <h1>Retrouver les analyses publiées</h1>
        <p className="lead">
          Cette archive présente les dossiers classés par ordre chronologique inversé. Chaque article
          conserve ses références documentaires et renvoie vers les sources utilisées.
        </p>
      </section>

      <section className={`${styles.grid} container`}>
        {archives.map((item) => (
          <article key={item.id} id={item.id} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={item.image} alt={item.title} loading="lazy" />
            </div>
            <div className={styles.meta}>
              <span>{item.date}</span>
              <span>{item.location}</span>
            </div>
            <h2>{item.title}</h2>
            <p>{item.summary}</p>
            <a className="highlight-link" href={`/archives/${item.id}`}>
              Consulter la fiche détaillée
            </a>
          </article>
        ))}
      </section>
    </div>
  );
};

export default ArchivesPage;