import React, { useEffect } from 'react';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  useEffect(() => {
    document.title = 'À propos | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Présentation du projet éditorial Historic Streets of France Review : mission, équipe et engagements méthodologiques."
      );
    }
  }, []);

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Présentation</span>
        <h1>Un observatoire éditorial dédié aux rues patrimoniales</h1>
        <p className="lead">
          Historic Streets of France Review est une revue en ligne qui documente, analyse et met en
          perspective les rues françaises à forte valeur patrimoniale. Chaque production éditoriale repose
          sur des sources identifiées et vérifiables, dans un cadre journalistique, culturel et
          scientifique.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionContent}>
          <h2>Mission et lignes éditoriales</h2>
          <p>
            La mission de la revue consiste à donner des clés de lecture sur les transformations urbaines,
            à valoriser les initiatives locales de conservation et à éclairer les débats qui traversent les
            quartiers historiques. L’ensemble des contenus est élaboré dans une perspective neutre,
            analytique et contextualisée.
          </p>
          <ul className={styles.list}>
            <li>Mettre en perspective l’histoire des rues et leur inscription dans le temps long.</li>
            <li>Documenter les usages contemporains en s’appuyant sur des données qualitatives.</li>
            <li>Identifier les enjeux patrimoniaux, sociaux et environnementaux émergents.</li>
          </ul>
        </div>
        <div className={styles.imagePanel} role="presentation" />
      </section>

      <section className={`${styles.values} container`}>
        <h2>Valeurs éditoriales</h2>
        <div className={styles.valuesGrid}>
          <div className={styles.valueCard}>
            <h3>Rigueur documentaire</h3>
            <p>
              Chaque article mentionne les fonds consultés, les entretiens menés et les références
              cartographiques afin de garantir la traçabilité des informations.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Pluralité des points de vue</h3>
            <p>
              Les rédacteurs associent témoignages d’experts, voix locales et matériaux scientifiques pour
              refléter la complexité des terrains étudiés.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Accessibilité des analyses</h3>
            <p>
              Les synthèses sont rédigées dans un langage clair, permettant aux chercheurs, étudiants,
              élus ou habitants de s’approprier les contenus.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.team} container`}>
        <h2>Équipe éditoriale et réseau</h2>
        <div className={styles.teamGrid}>
          <div className={styles.teamCard}>
            <h3>Coordination éditoriale</h3>
            <p>
              La coordination est assurée par une journaliste spécialisée en patrimoine urbain, responsable
              de la cohérence éditoriale et de la validation des sources.
            </p>
          </div>
          <div className={styles.teamCard}>
            <h3>Comité scientifique associé</h3>
            <p>
              Un comité composé d’historiens, d’urbanistes et de cartographes intervient en relecture pour
              chaque dossier thématique, assurant un regard critique et transversal.
            </p>
          </div>
          <div className={styles.teamCard}>
            <h3>Correspondants régionaux</h3>
            <p>
              Des correspondants basés à Lille, Lyon, Marseille, Toulouse et Strasbourg contribuent à la
              collecte d’informations locales et à la réalisation des reportages de terrain.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionContent}>
          <h2>Collaborations et partenariats</h2>
          <p>
            La revue coopère ponctuellement avec des institutions patrimoniales, des universités et des
            associations de quartier lorsque des projets communs de valorisation ou d’étude sont menés.
            Chaque collaboration est mentionnée dans les crédits des articles concernés.
          </p>
          <p>
            Historic Streets of France Review reste éditorialement indépendante et ne publie que des
            contenus validés par son comité scientifique, sans aucune prise de position partisane ni appel à
            l’action militante.
          </p>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;