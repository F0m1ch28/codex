import React, { useEffect, useState } from 'react';
import styles from './ContactPage.module.css';

const initialState = {
  nom: '',
  email: '',
  sujet: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  useEffect(() => {
    document.title = 'Contact | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Coordonnées de la rédaction de Historic Streets of France Review et formulaire de contact."
      );
    }
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
    setStatus('');
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.nom.trim()) newErrors.nom = 'Merci d’indiquer un nom.';
    if (!formData.email.trim()) {
      newErrors.email = 'Merci d’indiquer une adresse électronique.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Adresse électronique invalide.';
    }
    if (!formData.message.trim()) newErrors.message = 'Merci de préciser votre demande.';
    if (!formData.sujet.trim()) newErrors.sujet = 'Merci de choisir un sujet.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setStatus('');
      return;
    }
    setStatus('Votre message a été enregistré. La rédaction répondra dès que possible.');
    setFormData(initialState);
  };

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Contact</span>
        <h1>Écrire à la rédaction</h1>
        <p className="lead">
          La rédaction échange par voie électronique et ne dispose pas de bureau accessible au public.
          Pour toute question liée aux publications, aux demandes de reproduction ou aux collaborations,
          veuillez utiliser les coordonnées ci-dessous ou le formulaire.
        </p>
      </section>

      <section className={`${styles.info} container`}>
        <div className={styles.details}>
          <div className={styles.detailCard}>
            <h2>Coordonnées officielles</h2>
            <p>
              <strong>Email :</strong>{' '}
              <a href="mailto:redaction@historicstreets-fr-review.org">
                redaction@historicstreets-fr-review.org
              </a>
            </p>
            <p>
              <strong>Adresse de correspondance :</strong>
              <br />
              Boîte Postale 123
              <br />
              75001 Paris, France
            </p>
            <p className={styles.notice}>
              L’édition ne possède pas de bureau public. Toutes les communications se déroulent par voie
              électronique.
            </p>
          </div>
        </div>

        <div className={styles.formWrapper}>
          <h2>Formulaire de contact</h2>
          {status && <div className="alert success">{status}</div>}
          <form onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="nom">Nom</label>
              <input
                id="nom"
                name="nom"
                type="text"
                value={formData.nom}
                onChange={handleChange}
                aria-invalid={Boolean(errors.nom)}
                aria-describedby={errors.nom ? 'error-nom' : undefined}
              />
              {errors.nom && (
                <span id="error-nom" className={styles.error}>
                  {errors.nom}
                </span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="email">Adresse électronique</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'error-email' : undefined}
              />
              {errors.email && (
                <span id="error-email" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="sujet">Sujet</label>
              <input
                id="sujet"
                name="sujet"
                type="text"
                value={formData.sujet}
                onChange={handleChange}
                aria-invalid={Boolean(errors.sujet)}
                aria-describedby={errors.sujet ? 'error-sujet' : undefined}
              />
              {errors.sujet && (
                <span id="error-sujet" className={styles.error}>
                  {errors.sujet}
                </span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'error-message' : undefined}
              />
              {errors.message && (
                <span id="error-message" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>

            <button type="submit" className="primary">
              Envoyer
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;