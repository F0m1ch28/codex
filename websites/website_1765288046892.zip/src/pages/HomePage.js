import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './HomePage.module.css';

const latestStudies = [
  {
    id: 1,
    title: 'Boulevard Saint-Germain : résonances civiques',
    image: '/images/boulevard-saint-germain.jpg',
    excerpt:
      "Étude diachronique montrant comment le boulevard Saint-Germain cristallise les débats politiques et les pratiques quotidiennes depuis la Troisième République.",
    link: '/archives#boulevard-saint-germain'
  },
  {
    id: 2,
    title: 'Rue du Faubourg-Saint-Antoine : mémoires ouvrières',
    image: '/images/rue-faubourg-saint-antoine.jpg',
    excerpt:
      "Analyse des ateliers, passages et coopératives qui structurent la culture artisanale et les mobilisations sociales de l’est parisien.",
    link: '/archives#faubourg-saint-antoine'
  },
  {
    id: 3,
    title: 'Cours Mirabeau à Aix-en-Provence : sociabilités en mouvement',
    image: '/images/cours-mirabeau-aix.jpg',
    excerpt:
      "Lecture croisée des archives municipales et témoignages pour comprendre la mutation des usages du Cours entre promenades et manifestations culturelles.",
    link: '/archives#cours-mirabeau'
  },
  {
    id: 4,
    title: 'Montée du Gourguillon : strates lyonnaises',
    image: '/images/montee-gourguillon-lyon.jpg',
    excerpt:
      "Observation in situ et relevés cartographiques retraçant les continuités médiévales dans le tracé urbain et les formes bâties.",
    link: '/archives#montee-gourguillon'
  }
];

const researchTags = [
  'Rues historiques françaises',
  'Patrimoine urbain',
  'Évolution architecturale',
  'Cartographie ancienne',
  'Usages sociaux de l’espace',
  'Chronologies urbaines',
  'Mobilités piétonnes',
  'Transmissions mémorielles',
  'Photographie d’archives',
  'Politiques patrimoniales'
];

const HomePage = () => {
  useEffect(() => {
    const title = 'Historic Streets of France Review | Observatoire des rues patrimoniales';
    document.title = title;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Historic Streets of France Review documente les rues françaises à travers enquêtes historiques, cartographie et interviews d’experts."
      );
    }
  }, []);

  return (
    <div className={styles.home}>
      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className={`${styles.heroContent} container`}>
          <span className="badge">Analyse urbaine & patrimoniale</span>
          <h1>Historic Streets of France Review</h1>
          <p className="lead">
            La revue Historic Streets of France Review propose une lecture informée des rues françaises,
            croisant sources archivistiques, géographie historique et investigations de terrain afin de
            mettre en lumière les évolutions urbaines, sociales et culturelles.
          </p>
          <div className={styles.heroActions}>
            <Link to="/archives" className={styles.primaryButton}>
              Explorer les archives
            </Link>
            <Link to="/methodologie" className={styles.secondaryButton}>
              Comprendre la méthodologie
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.latest} container`}>
        <div className={styles.sectionHeader}>
          <span className="badge">Dernières études</span>
          <h2>Regards récents sur les rues françaises</h2>
          <p>
            Chaque dossier associe contextualisation historique, analyse des matériaux et lecture des
            pratiques habitantes afin d’esquisser une vision fine des continuités urbaines.
          </p>
        </div>
        <div className={styles.cards}>
          {latestStudies.map((study) => (
            <article key={study.id} className={`${styles.card} shadow-card fade-in`}>
              <div className={styles.cardImageWrapper}>
                <img src={study.image} alt={study.title} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <h3>{study.title}</h3>
                <p>{study.excerpt}</p>
                <Link to={study.link} className="highlight-link">
                  Lire l’étude
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.focus} container`}>
        <div className={styles.focusImage} role="presentation" />
        <div className={styles.focusContent}>
          <span className="badge">Focus du mois</span>
          <h2>Rue des Tanneurs, Strasbourg</h2>
          <p>
            Ce mois-ci, l’équipe éditoriale met en lumière la rue des Tanneurs, située au cœur du quartier
            de la Petite France. Les recherches ont mis en évidence la manière dont l’activité artisanale
            a façonné la morphologie de l’îlot, tout en laissant un héritage sensible dans les façades et
            dans la trame parcellaire.
          </p>
          <ul className={styles.focusList}>
            <li>Relecture des plans cadastraux de 1824 et 1925 pour retracer l’évolution des parcelles.</li>
            <li>Inventaire commenté des ateliers de tannerie conservés et des reconversions contemporaines.</li>
            <li>Entretien croisé entre une historienne locale et un architecte du patrimoine sur les enjeux de conservation.</li>
          </ul>
          <Link to="/themes-de-recherche" className="highlight-link">
            Découvrir les axes de recherche
          </Link>
        </div>
      </section>

      <section className={`${styles.method} container`}>
        <div className={styles.sectionHeader}>
          <span className="badge">Méthodologie en pratique</span>
          <h2>Approche multidisciplinaire et vérifiable</h2>
          <p>
            Les enquêtes associent dépouillement d’archives, analyses cartographiques et entretiens
            conduits auprès de professionnels et de chercheurs afin d’asseoir chaque publication sur des
            sources vérifiées.
          </p>
        </div>
        <div className={styles.methodGrid}>
          <div className={styles.methodCard}>
            <h3>Archives & iconographie</h3>
            <p>
              Consultation systématique des fonds municipaux et nationaux, complétée par l’étude de
              photographies anciennes et de cartes postales pour documenter les strates successives.
            </p>
          </div>
          <div className={styles.methodCard}>
            <h3>Cartographie comparative</h3>
            <p>
              Superposition de plans anciens, données SIG contemporaines et relevés topographiques pour
              visualiser les mutations spatiales et les continuités d’usage.
            </p>
          </div>
          <div className={styles.methodCard}>
            <h3>Entretiens d’experts</h3>
            <p>
              Recueil d’analyses auprès d’historiens, d’urbanistes et d’acteurs de terrain afin d’offrir un
              éclairage pluriel et contextualisé sur chaque dossier.
            </p>
          </div>
        </div>
        <div className={styles.statsBar}>
          <div>
            <strong>73</strong>
            <span>Corpus d’archives consultés en 2023</span>
          </div>
          <div>
            <strong>18</strong>
            <span>Entretiens d’experts réalisés</span>
          </div>
          <div>
            <strong>11</strong>
            <span>Cartes historiques géoréférencées</span>
          </div>
        </div>
      </section>

      <section className={`${styles.themes} container`}>
        <div className={styles.sectionHeader}>
          <span className="badge">Thématiques</span>
          <h2>Panorama des axes de recherche</h2>
          <p>
            Chaque thématique favorise une compréhension transversale des rues françaises en combinant la
            dimension patrimoniale à l’analyse sociale et urbaine.
          </p>
        </div>
        <div className="tag-list">
          {researchTags.map((tag) => (
            <span key={tag}>{tag}</span>
          ))}
        </div>
      </section>

      <section className={`${styles.quoteSection} container`}>
        <div className={styles.quoteCard}>
          <blockquote>
            « Les rues françaises ne sont pas seulement un assemblage de façades : elles forment des
            archives vivantes où se lisent les permanences, les ruptures et les négociations entre mémoire
            collective et usages présents. Historic Streets of France Review offre une grille de lecture
            rigoureuse de ces interactions. »
            <cite>Dr. Marianne Clavel — Historienne de l’urbanisme, Université de Strasbourg</cite>
          </blockquote>
        </div>
      </section>

      <section className={`${styles.aboutPreview} container`}>
        <div className={styles.aboutContent}>
          <span className="badge">À propos</span>
          <h2>Un projet éditorial documenté et indépendant</h2>
          <p>
            Historic Streets of France Review est porté par une équipe pluridisciplinaire, réunissant
            journalistes spécialisés, chercheurs associés et correspondants régionaux. L’objectif est
            d’offrir une veille structurée sur les mutations des rues patrimoniales, en valorisant les
            contributions locales et les démarches exemplaires de préservation.
          </p>
          <Link to="/a-propos" className="highlight-link">
            Lire la présentation de la revue
          </Link>
        </div>
        <div className={styles.aboutVisual} role="presentation" />
      </section>
    </div>
  );
};

export default HomePage;