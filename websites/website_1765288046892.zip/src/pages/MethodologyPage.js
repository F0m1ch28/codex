import React, { useEffect } from 'react';
import styles from './MethodologyPage.module.css';

const MethodologyPage = () => {
  useEffect(() => {
    document.title = 'Méthodologie | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Méthodologie de recherche : sources, protocoles et validations utilisés par Historic Streets of France Review."
      );
    }
  }, []);

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Méthodologie</span>
        <h1>Une démarche documentaire et analytique structurée</h1>
        <p className="lead">
          Les enquêtes publiées par Historic Streets of France Review s’appuient sur un protocole rigoureux
          articulant identification des sources, vérification croisée et restitution synthétique. Les étapes
          décrites ci-dessous garantissent la fiabilité des contenus.
        </p>
      </section>

      <section className={`${styles.steps} container`}>
        <div className={styles.stepCard}>
          <h2>1. Cadre de recherche</h2>
          <p>
            La rédaction délimite le périmètre d’étude (rue, quartier ou axe urbain) et définit les
            problématiques à explorer : contexte historique, morphologie, fonctions sociales ou
            transformations récentes.
          </p>
          <ul>
            <li>Analyse des sources secondaires disponibles (ouvrages, articles, rapports).</li>
            <li>Identification des acteurs locaux et experts susceptibles d’apporter un éclairage.</li>
            <li>Élaboration d’un calendrier de collecte et d’entretiens.</li>
          </ul>
        </div>

        <div className={styles.stepCard}>
          <h2>2. Collecte documentaire</h2>
          <p>
            Les rédacteurs procèdent au dépouillement des archives municipales, départementales et
            nationales, tout en réalisant une veille iconographique (plans, cartes, photographies).
          </p>
          <ul>
            <li>Consultation des séries cadastrales, plans d’alignement, permis de construire.</li>
            <li>Numérisation ou reproduction des documents pertinents avec référencement précis.</li>
            <li>Prise de notes structurée via une base de données interne.</li>
          </ul>
        </div>

        <div className={styles.stepCard}>
          <h2>3. Terrain et observation</h2>
          <p>
            Les correspondants se déplacent sur place pour relever l’état des bâtis, des usages et des
            circulations, photographier les détails significatifs et cartographier les parcours.
          </p>
          <ul>
            <li>Prises de vue géolocalisées et relevés topographiques simples.</li>
            <li>Croquis de façades en collaboration avec des architectes partenaires lorsque nécessaire.</li>
            <li>Entretiens semi-directifs auprès d’acteurs locaux dûment cités.</li>
          </ul>
        </div>

        <div className={styles.stepCard}>
          <h2>4. Analyse et mise en récit</h2>
          <p>
            Les données sont croisées pour construire un récit structuré, assorti d’intertitres et de
            cartes. Chaque citation est sourcée, chaque graphique est accompagné de sa méthodologie.
          </p>
          <ul>
            <li>Usage d’outils de cartographie (SIG) pour superposer les plans historiques et actuels.</li>
            <li>Validation croisée par le comité scientifique associé.</li>
            <li>Relecture journalistique pour garantir clarté et neutralité du propos.</li>
          </ul>
        </div>
      </section>

      <section className={`${styles.validation} container`}>
        <h2>Validation et transparence</h2>
        <p>
          Avant publication, chaque étude fait l’objet d’une double validation : une relecture par un
          membre du comité scientifique et une vérification factuelle par la coordination éditoriale. Les
          sources primaires et secondaires sont listées en fin d’article, accompagnées de liens vers les
          institutions custodiennes lorsque cela est possible.
        </p>
        <div className={styles.validationGrid}>
          <div className={styles.validationCard}>
            <h3>Traçabilité intégrale</h3>
            <p>
              Les lecteurs trouvent pour chaque article la référence des archives consultées, la date de
              consultation, ainsi que les conventions de citation appliquées.
            </p>
          </div>
          <div className={styles.validationCard}>
            <h3>Données cartographiques</h3>
            <p>
              Les cartes produites sont accompagnées d’une description de la méthode de géoréférencement et
              des sources de données utilisées (fonds anciens, cadastre moderne, relevés de terrain).
            </p>
          </div>
          <div className={styles.validationCard}>
            <h3>Entretiens documentés</h3>
            <p>
              Chaque entretien est retranscrit et validé par la personne interrogée avant publication, afin
              de respecter la précision de ses propos.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default MethodologyPage;