import React, { useEffect } from 'react';
import styles from './PrivacyPolicyPage.module.css';

const PrivacyPolicyPage = () => {
  useEffect(() => {
    document.title = 'Politique de confidentialité | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Politique de confidentialité de Historic Streets of France Review : gestion des données personnelles."
      );
    }
  }, []);

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Confidentialité</span>
        <h1>Protection des données personnelles</h1>
        <p>
          Historic Streets of France Review traite les informations personnelles avec soin et dans le
          respect du Règlement général sur la protection des données (RGPD) et de la législation française
          en vigueur.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>1. Responsable de traitement</h2>
        <p>
          Le responsable de traitement est la rédaction de Historic Streets of France Review, joignable à
          l’adresse électronique redaction@historicstreets-fr-review.org.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>2. Données collectées</h2>
        <p>
          Seules les données communiquées via le formulaire de contact sont collectées : nom, adresse
          électronique, sujet et contenu du message. Ces informations permettent de répondre aux demandes
          reçues.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>3. Base juridique et finalité</h2>
        <p>
          Le traitement repose sur l’intérêt légitime de la rédaction à répondre aux sollicitations.
          Aucune donnée n’est utilisée à des fins de prospection ou de ciblage.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>4. Durée de conservation</h2>
        <p>
          Les messages et leurs métadonnées sont conservés pour une durée maximale de douze mois à compter
          de leur réception, sauf obligation légale contraire.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>5. Droits des personnes</h2>
        <p>
          Conformément au RGPD, toute personne dispose d’un droit d’accès, de rectification, d’effacement,
          de limitation et d’opposition. Ces droits s’exercent en écrivant à l’adresse
          redaction@historicstreets-fr-review.org. Une réponse sera apportée dans un délai de trente jours.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>6. Sécurité</h2>
        <p>
          La rédaction met en œuvre des mesures techniques et organisationnelles pour protéger les données
          contre tout accès non autorisé, modification ou divulgation. Les messages sont stockés sur des
          serveurs sécurisés.
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicyPage;