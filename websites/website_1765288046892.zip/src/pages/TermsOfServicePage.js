import React, { useEffect } from 'react';
import styles from './TermsOfServicePage.module.css';

const TermsOfServicePage = () => {
  useEffect(() => {
    document.title = 'Conditions d’utilisation | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Conditions d’utilisation du site Historic Streets of France Review : accès, droits et responsabilités."
      );
    }
  }, []);

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Conditions d’utilisation</span>
        <h1>Cadre d’utilisation du site</h1>
        <p>
          Les présentes conditions définissent les modalités d’accès et d’utilisation du site Historic
          Streets of France Review. La consultation du site implique l’adhésion pleine et entière aux
          dispositions ci-dessous.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>1. Objet</h2>
        <p>
          Le site a pour vocation de publier des contenus journalistiques et de recherche portant sur les
          rues françaises. Les informations sont délivrées à titre documentaire. Elles ne constituent pas
          des recommandations opérationnelles ou juridiques.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>2. Accès au site</h2>
        <p>
          L’accès au site est libre. L’éditeur se réserve le droit de suspendre l’accès temporairement pour
          des raisons de maintenance ou de mises à jour techniques. Aucune compensation ne peut être
          réclamée en cas d’indisponibilité temporaire.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>3. Propriété intellectuelle</h2>
        <p>
          Les contenus rédactionnels, visuels et graphiques sont protégés par le droit d’auteur. Toute
          reproduction totale ou partielle nécessite une autorisation écrite de la rédaction, sauf mention
          particulière de licence libre. Les citations courtes sont autorisées à condition de mentionner la
          source complète.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>4. Responsabilité</h2>
        <p>
          L’éditeur s’efforce d’assurer l’exactitude des informations fournies. Toutefois, il ne peut être
          tenu responsable d’erreurs matérielles, d’omissions ou de résultats qui pourraient être obtenus
          par l’usage de ces informations. Le site contient des liens hypertextes vers d’autres ressources
          pour compléter un propos ; l’éditeur n’exerce aucun contrôle sur ces contenus externes.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>5. Données personnelles</h2>
        <p>
          La collecte de données via le formulaire de contact est limitée aux informations strictement
          nécessaires pour répondre aux messages. Ces données ne sont ni cédées ni partagées avec des tiers
          et sont conservées pendant la durée de traitement du message, conformément à la politique de
          confidentialité.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>6. Droit applicable</h2>
        <p>
          Les présentes conditions sont régies par le droit français. En cas de litige, les tribunaux
          compétents seront ceux du ressort de la Cour d’appel de Paris, sous réserve d’une disposition
          légale contraire.
        </p>
      </section>
    </div>
  );
};

export default TermsOfServicePage;