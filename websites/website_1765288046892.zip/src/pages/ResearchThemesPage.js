import React, { useEffect } from 'react';
import styles from './ResearchThemesPage.module.css';

const themes = [
  {
    title: 'Généalogie des tracés urbains',
    description:
      "Étude des plans anciens, des alignements et des percées successives pour comprendre la fabrique des rues depuis l'époque moderne."
  },
  {
    title: 'Patrimoine artisanal et industriel',
    description:
      "Analyse des métiers qui ont façonné les quartiers : corporations, ateliers, manufactures et leurs répercussions sociales."
  },
  {
    title: 'Morphologie architecturale',
    description:
      "Lecture comparée des typologies de façades, modénatures, matériaux et rythmes d’implantation pour identifier les strates historiques."
  },
  {
    title: 'Usages sociaux et culturels',
    description:
      "Observation des pratiques habitantes, des fêtes et des mobilités pour saisir les dynamiques contemporaines des rues."
  },
  {
    title: 'Politiques patrimoniales',
    description:
      "Suivi des dispositifs juridiques et des projets urbains influençant la conservation, la protection ou la transformation des rues."
  },
  {
    title: 'Imaginaire et iconographie',
    description:
      "Analyse des représentations littéraires, photographiques et cinématographiques qui contribuent à la notoriété des rues."
  }
];

const ResearchThemesPage = () => {
  useEffect(() => {
    document.title = 'Thèmes de recherche | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Thématiques principales étudiées par Historic Streets of France Review : patrimoine, usages sociaux, morphologies urbaines."
      );
    }
  }, []);

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Thématiques</span>
        <h1>Axes de recherche privilégiés</h1>
        <p className="lead">
          Les thèmes recensés ci-dessous guident la programmation éditoriale et alimentent le calendrier
          de publication. Chacun est traité selon des approches complémentaires, issues de l’histoire,
          l’urbanisme, la sociologie et la géographie culturelle.
        </p>
      </section>

      <section className={`${styles.grid} container`}>
        {themes.map((theme) => (
          <article key={theme.title} className={styles.card}>
            <h2>{theme.title}</h2>
            <p>{theme.description}</p>
          </article>
        ))}
      </section>
    </div>
  );
};

export default ResearchThemesPage;