import React, { useEffect } from 'react';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => {
  useEffect(() => {
    document.title = 'Politique des cookies | Historic Streets of France Review';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        "Politique des cookies de Historic Streets of France Review : types de cookies utilisés et modalités de gestion."
      );
    }
  }, []);

  return (
    <div className={styles.page}>
      <section className="container">
        <span className="badge">Cookies</span>
        <h1>Gestion des cookies</h1>
        <p>
          Cette politique décrit la manière dont Historic Streets of France Review utilise les cookies et
          autres traceurs lors de la navigation sur le site.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>1. Définition</h2>
        <p>
          Un cookie est un fichier texte susceptible d’être enregistré sur le terminal de l’utilisateur
          lors de la consultation du site. Il permet de reconnaître ce terminal pendant la durée de validité
          du cookie.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>2. Cookies utilisés</h2>
        <p>
          Le site n’utilise que des cookies strictement nécessaires et des cookies de mesure d’audience
          anonymisés. Ces cookies servent à améliorer la qualité du service et à évaluer la fréquentation
          globale.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>3. Paramétrage</h2>
        <p>
          L’utilisateur peut configurer son navigateur pour accepter ou refuser les cookies. Certains
          navigateurs permettent également de supprimer automatiquement les cookies à la fermeture.
        </p>
      </section>

      <section className={`${styles.section} container`}>
        <h2>4. Contact</h2>
        <p>
          Toute question relative aux cookies peut être adressée à
          redaction@historicstreets-fr-review.org.
        </p>
      </section>
    </div>
  );
};

export default CookiePolicyPage;