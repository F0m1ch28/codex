import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const LOCAL_STORAGE_KEY = 'hsfr-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!storedConsent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(LOCAL_STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <p>
          Historic Streets of France Review utilise des cookies fonctionnels pour mesurer la fréquentation
          anonyme et améliorer la navigation. Aucune donnée personnelle n’est exploitée à des fins
          commerciales.
        </p>
        <a className={styles.link} href="/politique-des-cookies">
          Consulter la politique des cookies
        </a>
      </div>
      <button className={styles.button} onClick={handleAccept}>
        Compris
      </button>
    </div>
  );
};

export default CookieBanner;