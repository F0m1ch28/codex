import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.branding}>
          <h4>Historic Streets of France Review</h4>
          <p>
            Plateforme éditoriale dédiée à l’analyse des dynamiques historiques, sociales et
            architecturales des rues françaises. Tous les contenus sont élaborés dans une perspective
            neutre et documentée.
          </p>
        </div>
        <div className={styles.links}>
          <h5>Navigation</h5>
          <ul>
            <li>
              <Link to="/">Accueil</Link>
            </li>
            <li>
              <Link to="/a-propos">À propos</Link>
            </li>
            <li>
              <Link to="/methodologie">Méthodologie</Link>
            </li>
            <li>
              <Link to="/themes-de-recherche">Thèmes de recherche</Link>
            </li>
            <li>
              <Link to="/archives">Archives</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div className={styles.legal}>
          <h5>Informations</h5>
          <ul>
            <li>
              <Link to="/conditions-d-utilisation">Conditions d’utilisation</Link>
            </li>
            <li>
              <Link to="/politique-de-confidentialite">Politique de confidentialité</Link>
            </li>
            <li>
              <Link to="/politique-des-cookies">Politique des cookies</Link>
            </li>
          </ul>
          <div className={styles.contact}>
            <span>Email :</span>
            <a href="mailto:redaction@historicstreets-fr-review.org">
              redaction@historicstreets-fr-review.org
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Historic Streets of France Review. Tous droits réservés.</p>
      </div>
    </footer>
  );
};

export default Footer;