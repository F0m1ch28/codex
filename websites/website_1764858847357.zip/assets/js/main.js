document.addEventListener('DOMContentLoaded', () => {
  // Navigation toggle for mobile
  document.querySelectorAll('.main-nav').forEach((nav) => {
    const toggle = nav.querySelector('.nav-toggle');
    if (!toggle) return;
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      nav.dataset.open = String(!expanded);
    });
    document.addEventListener('click', (event) => {
      if (!nav.contains(event.target)) {
        toggle.setAttribute('aria-expanded', 'false');
        delete nav.dataset.open;
      }
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        toggle.setAttribute('aria-expanded', 'false');
        delete nav.dataset.open;
      }
    });
  });

  // Cookie banner logic
  const banner = document.getElementById('cookieBanner');
  if (banner) {
    const choice = localStorage.getItem('mir-cookie-choice');
    if (!choice) {
      banner.classList.add('is-visible');
    }

    banner.querySelectorAll('[data-cookie-choice]').forEach((button) => {
      button.addEventListener('click', () => {
        const userChoice = button.getAttribute('data-cookie-choice') || 'decline';
        localStorage.setItem('mir-cookie-choice', userChoice);
        banner.classList.remove('is-visible');
      });
    });
  }
});