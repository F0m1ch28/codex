const COMPANY = {
  phone: "+32 472 63 58 20",
  email: "contact@atelier-reclame.fr",
  address: "123 Rue de la République, 75001 Paris, France"
};

const TOKENS = {
  year: new Date().getFullYear(),
  phone: COMPANY.phone,
  email: COMPANY.email,
  address: COMPANY.address
};

const I18N = {
  en: {
    "brand.initials": "AR",
    "brand.name": "Atelier Reclame",
    "brand.tagline": "Independent observatory for advertising ecosystems.",
    "nav.home": "Home",
    "nav.services": "Research",
    "nav.about": "About",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "lang.en": "EN",
    "lang.fr": "FR",
    "aria.navToggle": "Toggle navigation menu",
    "aria.languageSwitch": "Switch language",
    "aria.openCookiePreferences": "Open cookie preferences",
    "aria.closeBanner": "Close banner",
    "aria.submitContact": "Submit contact form",
    "footer.contactTitle": "Contact",
    "footer.addressTitle": "Location",
    "footer.legalTitle": "Legal",
    "footer.rights": "© {{year}} Atelier Reclame · All analytical materials reserved.",
    "footer.phone": "Phone · +32 472 63 58 20",
    "footer.email": "Email · contact@atelier-reclame.fr",
    "footer.address": "123 Rue de la République, 75001 Paris, France",
    "footer.manageCookies": "Cookie settings",
    "footer.tagline": "Researching advertising phenomena for teams across France and Europe.",
    "footer.terms": "Terms",
    "footer.privacy": "Privacy",
    "footer.cookies": "Cookie Policy",
    "footer.refund": "Refund Policy",
    "footer.disclaimer": "Disclaimer",
    "button.backHome": "Return to homepage",
    "button.contact": "Contact team",
    "meta.index.title": "Atelier Reclame · Advertising research collective",
    "meta.index.description": "Atelier Reclame documents advertising systems with bilingual research, offering neutral insights for teams across France and Europe.",
    "meta.services.title": "Research capabilities · Atelier Reclame",
    "meta.services.description": "Overview of Atelier Reclame methodologies including media system analysis, creative mapping, and diagnostics workflows.",
    "meta.about.title": "About Atelier Reclame · Research collective",
    "meta.about.description": "Learn about Atelier Reclame, a Franco-Belgian team exploring advertising phenomena through multilingual studies.",
    "meta.blog.title": "Insights blog · Atelier Reclame",
    "meta.blog.description": "Explore the Atelier Reclame blog featuring analyses on campaigns, culture metrics, and observational frameworks.",
    "meta.post1.title": "Interpreting multi-layer reach · Atelier Reclame",
    "meta.post1.description": "A technical review of streaming-first campaign reach models and segmentation heuristics by Atelier Reclame.",
    "meta.post2.title": "Semiotic layering in automotive narratives · Atelier Reclame",
    "meta.post2.description": "Examining semiotic choices in automotive advertising and their cultural resonances, by Atelier Reclame.",
    "meta.post3.title": "Attention taxonomy for out-of-home networks · Atelier Reclame",
    "meta.post3.description": "Defining attentive states for current out-of-home networks and diagnostic techniques.",
    "meta.post4.title": "Bilingual cultural adjacency measurement · Atelier Reclame",
    "meta.post4.description": "Methodologies for evaluating cultural adjacency across bilingual markets in France and Belgium.",
    "meta.post5.title": "Governance protocols for creative data rooms · Atelier Reclame",
    "meta.post5.description": "Operational guidance for teams managing creative data rooms and knowledge stewardship.",
    "meta.contact.title": "Contact Atelier Reclame",
    "meta.contact.description": "Reach Atelier Reclame for analytical questions, collaborations, or data access requests.",
    "meta.faq.title": "FAQ · Atelier Reclame",
    "meta.faq.description": "Frequently asked questions about Atelier Reclame’s research processes and data policies.",
    "meta.terms.title": "Terms of use · Atelier Reclame",
    "meta.terms.description": "Terms governing the usage of Atelier Reclame publications and digital resources.",
    "meta.privacy.title": "Privacy notice · Atelier Reclame",
    "meta.privacy.description": "Privacy practices for Atelier Reclame, including data collection, storage, and user rights.",
    "meta.cookies.title": "Cookie policy · Atelier Reclame",
    "meta.cookies.description": "Cookie usage, categories, and consent management at Atelier Reclame.",
    "meta.refund.title": "Refund policy · Atelier Reclame",
    "meta.refund.description": "Refund policy for Atelier Reclame’s informational materials and events.",
    "meta.disclaimer.title": "Disclaimer · Atelier Reclame",
    "meta.disclaimer.description": "Disclaimer outlining limitations of Atelier Reclame analyses and resources.",
    "meta.thankyou.title": "Thank you · Atelier Reclame",
    "meta.thankyou.description": "Confirmation of your message to Atelier Reclame.",
    "meta.404.title": "Page not found · Atelier Reclame",
    "meta.404.description": "The requested Atelier Reclame page was not found.",
    "index.hero.title": "Decoding advertising impact across European audiences",
    "index.hero.subtitle": "Atelier Reclame curates longitudinal research on media behaviours, creative narratives, and campaign ecologies for teams seeking verified insights.",
    "index.hero.cta": "Explore our knowledge base",
    "index.hero.secondary": "Review collaborative pathways",
    "index.hero.note": "Our analysts catalogue patterns from 112 multi-market initiatives each quarter.",
    "index.hero.metric1": "12+ years synthesising transnational campaign evidence",
    "index.hero.metric2": "90 empirical datasets monitored continuously",
    "index.hero.metric3": "4 research frameworks tested with partner labs",
    "index.hero.imageAlt": "Researchers reviewing layered media dashboards in a studio.",
    "index.featured.title": "Current insight frameworks",
    "index.featured.desc": "Each framework cross-references audience behaviour, creative craft, and media architecture to surface neutral recommendations.",
    "index.featured.card1.title": "Media System Cartography",
    "index.featured.card1.text": "Mapping channel ecosystems to understand overlap, reach decay, and opportunity gaps within fragmented media environments.",
    "index.featured.card2.title": "Creative Semiotic Benchmarks",
    "index.featured.card2.text": "Comparing narrative devices, pacing, and sensory cues across sectors to benchmark the signals audiences retain.",
    "index.featured.card3.title": "Outcome Resonance Ledger",
    "index.featured.card3.text": "Tracking attention residue, consideration cues, and cultural adjacency to clarify how campaigns perform beyond impressions.",
    "index.method.title": "How we structure observational work",
    "index.method.intro": "Our methodology emphasises reproducible metrics, transparent context notes, and multilingual validation cycles.",
    "index.method.list1": "Triangulated data capture across field studies, panel inputs, and archival media artefacts.",
    "index.method.list2": "Controlled annotation sprints to separate creative intent from observable impact.",
    "index.method.list3": "Peer review from independent specialists in narrative theory and channel planning.",
    "index.method.list4": "Versioned repositories ensuring every revision is trackable for collaborators.",
    "index.method.imageAlt": "Layered documents and annotations representing the Atelier Reclame workflow.",
    "index.recommendations.title": "Recommendations in focus",
    "index.recommendations.desc": "Key actions communication teams adopt after reviewing our dossiers.",
    "index.recommendations.card1.title": "Refresh channel purpose statements",
    "index.recommendations.card1.text": "Document the intention behind every channel touchpoint so that campaign teams maintain coherent story progression.",
    "index.recommendations.card2.title": "Document sensory cues deliberately",
    "index.recommendations.card2.text": "Audit audio, visual, and spatial cues to maintain recognisable signals across platforms and formats.",
    "index.recommendations.card3.title": "Align measurement with narrative arcs",
    "index.recommendations.card3.text": "Schedule evaluation milestones around storyline phases instead of calendar quarters alone.",
    "index.recommendations.imageAlt": "Researchers exchanging recommendations in a studio.",
    "index.testimonials.title": "Testimonials",
    "index.testimonials.desc": "Leaders from research, culture, and design communities describe how our compendiums inform their practice.",
    "index.testimonials.quote1.text": "The dossiers translate chaotic media patterns into structured hypotheses we can interrogate with our own fieldwork.",
    "index.testimonials.quote1.meta": "Élodie Marchand · Media Ethnographer",
    "index.testimonials.quote2.text": "Atelier Reclame keeps attention on the cultural signals that actually travel, not just the ones a dashboard counts.",
    "index.testimonials.quote2.meta": "Gareth Ellis · Creative Strategist",
    "index.testimonials.quote3.text": "Their bilingual notation lets our mixed teams debate findings without losing nuance or timing.",
    "index.testimonials.quote3.meta": "Nadia Belkacem · Communication Director",
    "index.blogpreview.title": "Latest publications",
    "index.blogpreview.desc": "Browse our analytical series covering campaign stewardship, cultural metrics, and attention diagnostics.",
    "index.blogpreview.cta": "Visit the blog",
    "index.contactprompt.title": "Share your analytical question",
    "index.contactprompt.text": "Send us the scenario you are mapping; we respond with relevant case notes and open data references.",
    "index.contactprompt.button": "Go to contact page",
    "services.hero.title": "Research capabilities overview",
    "services.hero.intro": "We examine advertising systems through independent studies, delivering documentation rather than executional services.",
    "services.service1.title": "Media Systems Analysis",
    "services.service1.text": "A structural review of channels, investments, and temporal rhythms to clarify how messages circulate through fragmented environments.",
    "services.service1.point1": "Channel adjacency modelling with frequency decay tracking.",
    "services.service1.point2": "Reach scenario testing for cross-border scheduling.",
    "services.service2.title": "Creative Pattern Mapping",
    "services.service2.text": "Evaluating sensory cues, narrative scaffolding, and brand semiotics across categories to identify distinctive signals.",
    "services.service2.point1": "Sequence decomposition of audio and motion assets.",
    "services.service2.point2": "Marker libraries for symbol, texture, and tone usage.",
    "services.service3.title": "Audience Insight Observatory",
    "services.service3.text": "Longitudinal observation of audience rituals, cultural anchors, and bilingual perception shifts across France and Belgium.",
    "services.service3.point1": "In-situ diaries and panel synthesis refreshed quarterly.",
    "services.service3.point2": "Geocultural clustering to surface regional contrasts.",
    "services.service4.title": "Campaign Diagnostics Stewardship",
    "services.service4.text": "Constructing neutral measurement ranges that account for narrative maturity, media saturation, and contextual volatility.",
    "services.service4.point1": "Performance baselines aligned with storyline phases.",
    "services.service4.point2": "Scenario simulations for planned or reactive interventions.",
    "services.method.title": "Method principles",
    "services.method.text": "Every program is underpinned by collaborative protocols that keep evidence auditable and adaptable.",
    "services.method.point1": "Shared glossaries harmonise terminology across teams.",
    "services.method.point2": "All observations retain citations and version timestamps.",
    "services.method.point3": "Data models remain portable for partner systems.",
    "services.frameworks.title": "Framework libraries",
    "services.frameworks.text": "Our frameworks are licensed for research purposes and can be remixed with internal taxonomies.",
    "services.frameworks.point1": "Narrative posture matrix linking tone with outcomes.",
    "services.frameworks.point2": "Attention residue heatmaps for multi-sensory assets.",
    "services.frameworks.point3": "Cultural adjacency index calibrated for bilingual markets.",
    "services.closing.title": "Engagement rhythm",
    "services.closing.text": "We coordinate periodic sessions to validate findings, co-write annotations, and adapt the repository as evidence evolves.",
    "services.imageAlt": "Collaborative workshop reviewing advertising frameworks.",
    "about.hero.title": "Who we are",
    "about.hero.intro": "Atelier Reclame emerged from a Franco-Belgian collaboration focused on translating advertising scholarship into practical observatories.",
    "about.story.title": "Origin story",
    "about.story.p1": "The collective began in Lyon and Liège, where researchers, planners, and cultural analysts compared the lived realities of campaigns with the narratives recorded in academic journals.",
    "about.story.p2": "Working bilingually from inception ensured that insights could circulate between metropolitan hubs and regional ecosystems without losing nuance.",
    "about.values.title": "Guiding values",
    "about.values.list1": "Integrity in evidence: every claim references a public or sharable source.",
    "about.values.list2": "Context before judgement: we chart why a signal appears before we assess its impact.",
    "about.values.list3": "Accessibility: findings are written for multilingual, cross-disciplinary teams.",
    "about.team.title": "Interdisciplinary team",
    "about.team.p1": "Our analysts rotate between qualitative fieldwork, quantitative modelling, and editorial synthesis to maintain a holistic outlook.",
    "about.team.p2": "Partners include semioticians, information designers, sociologists, and media buyers who co-author specialised annexes.",
    "about.timeline.title": "Milestones",
    "about.timeline.item1": "2012 · Established the first shared repository for Francophone and Anglophone campaign diaries.",
    "about.timeline.item2": "2016 · Introduced the cultural adjacency index after studying bilingual youth media habits.",
    "about.timeline.item3": "2021 · Launched the outcome resonance ledger with collaborative review cycles.",
    "about.resources.title": "Resources in circulation",
    "about.resources.p1": "We publish working papers, annotated dashboards, and workshop scripts so peers can replicate our approaches within their own organisations.",
    "about.imageAlt": "Team members discussing research boards.",
    "blog.hero.title": "Analytical dispatches",
    "blog.hero.intro": "Each post documents experiments, debates, and frameworks shaping contemporary advertising practice.",
    "blog.note": "Browse thematic filters below or scroll the complete archive.",
    "blog.readmore": "Read more",
    "blog.post1.title": "Interpreting multi-layer reach for streaming-first campaigns",
    "blog.post1.excerpt": "We examine how overlapping frequency layers distort audience perception when streaming video dominates the media mix.",
    "blog.post1.imageAlt": "Dashboard visualising streaming campaign reach layers.",
    "blog.post2.title": "Semiotic layering in automotive storytelling",
    "blog.post2.excerpt": "A close reading of sensory cues guiding automotive narratives across European markets.",
    "blog.post2.imageAlt": "Storyboard frames illustrating automotive narratives.",
    "blog.post3.title": "Attention taxonomy for out-of-home networks",
    "blog.post3.excerpt": "Defining attentive states for modular out-of-home systems and their diagnostic implications.",
    "blog.post3.imageAlt": "City out-of-home screens captured at night.",
    "blog.post4.title": "Measuring cultural adjacency across bilingual markets",
    "blog.post4.excerpt": "Methodologies for comparing resonance in French and English communication streams.",
    "blog.post4.imageAlt": "Notebook comparing bilingual cultural references.",
    "blog.post5.title": "Governance protocols for creative data rooms",
    "blog.post5.excerpt": "Structuring stewardship routines for interdisciplinary creative repositories.",
    "blog.post5.imageAlt": "Creative data room with organised files.",
    "blog.hero.imageAlt": "Printed reports and sticky notes illustrating research.",
    "post1.title": "Interpreting multi-layer reach for streaming-first campaigns",
    "post1.intro": "Streaming-first campaigns now produce overlapping exposures that behave unlike the traditional broadcast pyramid. Linear frequency metrics fail to describe how dynamic ad insertion, binge viewing, and device switching create layered reach. We reconstruct the reach footprint using temporal density, context adjacency, and device elasticity so analysts can compare campaigns with consistent references. The approach draws on mixed-method diaries from Lyon, Rotterdam, and Marseille, documenting how participants recall ads after navigating between French and English interfaces.",
    "post1.section1.title": "Reconstructing frequency footprints",
    "post1.section1.p1": "Instead of counting gross impressions, we map exposure clusters within ninety-minute windows and index them by narrative state. Streaming catalogues release episodes in bursts, so audiences stack exposures when they binge. We therefore measure the surface area of a cluster by combining episode duration, pause behaviour, and complementary device use. When the cluster surface exceeds a set threshold, we treat later exposures as reinforcement rather than fresh reach, which better aligns with participant recollection.",
    "post1.section1.p2": "Layered reach also depends on when audio or subtitles shift language. Our bilingual diaries show that switching to original-language audio suppresses recall of previously dubbed creative until a new cue reintroduces the brand. We record these inflection points as translation pivots. Analysts can then weight impressions that occur after a pivot differently, acknowledging that the brain resets attention when it decodes a new linguistic pattern.",
    "post1.section1.subheading": "Segment weighting heuristics",
    "post1.section1.p3": "To keep the model manageable, we segment audiences by session intention: discovery, continuation, or ambient viewing. Discovery segments assign higher value to early exposures because viewers actively evaluate catalogues; ambient segments treat exposures as background and therefore receive attenuation. Weighting by intention keeps qualitative observations aligned with quantitative estimates and prevents clutter from inflating impact scores.",
    "post1.section2.title": "Synchronising qualitative signals",
    "post1.section2.p1": "We stabilise the model with qualitative markers drawn from interviews. Participants described moments when an ad punctuated narrative flow, such as cliff-hangers or music bridges. We code these as resonance anchors and align them with the cluster timeline. An anchor that surfaces repeatedly across participants elevates that exposure cluster, even if the raw impression count is modest.",
    "post1.section2.p2": "Conversely, when participants noted fatigue with repetitive cues, we flagged the associated cluster for dampening. Fatigue often appears after three consecutive episodes within a franchise, particularly when creative versions vary only in end frames. Applying a dampening coefficient keeps reports realistic for planners who might otherwise chase artificially high reinforcement.",
    "post1.section2.subheading": "Operational dashboards",
    "post1.section2.p3": "Dashboards built on this model must allow analysts to toggle between raw counts and weighted reach. We recommend storing cluster definitions in a transparent table so stakeholders can audit decisions. Each entry includes session intention, language pivots, resonance anchors, and fatigue flags. Teams that adopt the structure report improved cross-market debates because the evidence translates into both English and French briefs without losing the nuance of the original diaries.",
    "post1.imageAlt": "Analyst examining streaming analytics on multiple monitors.",
    "post2.title": "Semiotic layering in automotive storytelling",
    "post2.intro": "Automotive storytelling increasingly relies on semiotic layering to reconcile electric innovation with heritage cues. We analysed twelve European campaigns spanning luxury, utility, and performance segments to understand how symbols travel between contexts. The review combines semiotic readings, motion capture analysis, and ethnographic interviews with drivers in Lille, Namur, and Bordeaux. We investigated how drivers interpret layered cues in both languages and how agencies orchestrate transitions between tradition and futurism.",
    "post2.section1.title": "Constructing the sensory spine",
    "post2.section1.p1": "Every campaign we observed used a consistent sensory spine anchoring the narrative. Luxury brands leaned on low-frequency engine hums even when showcasing silent electric models, creating a phantom resonance. Utility brands introduced tactile cues, placing microphones on doors and cargo surfaces. By mapping these sounds against visual motifs, we tracked how audiences associated each cue with distinct promises and how bilingual versions preserved those links.",
    "post2.section1.p2": "Visual motifs followed a similar pattern. Performance narratives used wide-angle sweeps of coastal roads, while sustainability stories favoured close shots of urban greenery. When we overlaid the footage with interview transcripts, participants connected wide sweeps with autonomy and narrow frames with social responsibility. The juxtaposition explains why some campaigns misfire when they mix both motif families without a clear transition or explanation.",
    "post2.section1.subheading": "Semiotic transitions",
    "post2.section1.p3": "Semiotic layering succeeds when transitions respect audience expectations. We catalogued bridge elements—gear shifts, lighting changes, or spoken pledges—that made transitions legible. Drivers reported confusion when a sequence jumped from dawn cities to nocturnal mountains without an audible cue. Marking each bridge in our timeline allowed strategists to ensure every transition carried a rationale visible in both languages and across media edits.",
    "post2.section2.title": "Aligning heritage with innovation",
    "post2.section2.p1": "Heritage references need not fight innovation messaging. We studied campaigns that reintroduced archival footage or historic slogans before unveiling electric platforms. The effective executions treated heritage as a memory anchor, then layered modern cues on top: updated typography, kinetic interface animations, or refreshed colour palettes. Participants described feeling reassured rather than nostalgic because the heritage cue contextualised the new technology.",
    "post2.section2.p2": "Campaigns that failed displayed heritage elements in isolation, leaving audiences to infer relevance. An archival rally scene without commentary made younger viewers feel excluded. To counter this, we recommend including micro-annotations—voiceover lines or on-screen captions—explaining why a legacy model matters in contemporary mobility debates.",
    "post2.section2.subheading": "Editorial implications",
    "post2.section2.p3": "Editors can apply our findings by plotting semiotic layers on a shared timeline. Each layer notes its sensory cue, intended meaning, and proof point. The timeline becomes a governance artefact for agencies and clients working across markets. French and English teams can debate which cues stay, which adapt, and which require additional context, ensuring the final film reads coherently for drivers navigating bilingual media.",
    "post2.imageAlt": "Designer arranging automotive campaign frames on a table.",
    "post3.title": "Attention taxonomy for out-of-home networks",
    "post3.intro": "Out-of-home networks now operate as responsive ecosystems, combining roadside LEDs, transport displays, and experiential surfaces. Traditional attention metrics treat these sites as static impressions, yet the reality involves overlapping dwell times and competing stimuli. Our taxonomy reclassifies attention into orientation, immersion, and resonance states based on field recordings across Paris, Brussels, and Lyon. The framework helps planners calibrate creative fit and rotation frequency.",
    "post3.section1.title": "Defining orientation states",
    "post3.section1.p1": "Orientation describes the moment a passerby recognises a surface. In transit hubs, orientation lasts under two seconds, with colour contrast and motion triggers dominating. Roadside panels offer longer orientation windows but suffer from glare. We logged sensor data capturing head turns and correlated it with luminance levels to determine the optimal trigger thresholds for each environment.",
    "post3.section1.p2": "Orientation decays quickly when consecutive creatives share identical colour palettes. Our observations show audiences disregard the second ad if it mimics the first, even when messaging is unrelated. Introducing micro-variations—pattern overlays or directional light—preserves orientation without disrupting campaign identity. These micro-variations become essential when multiple advertisers share a loop.",
    "post3.section1.subheading": "Heuristic scoring",
    "post3.section1.p3": "We built a heuristic score combining trigger strength, environmental clutter, and daypart variability. The score signals when to increase rotation or redesign assets. Networks adopting the score reduced wasted impressions by prioritising sites where orientation registered consistently across languages and commuter profiles.",
    "post3.section2.title": "Immersion and resonance",
    "post3.section2.p1": "Immersion measures the seconds after orientation when a viewer processes the message. Experiential screens in malls achieved high immersion when creative incorporated live data or ambient audio. Roadside panels required concise motion loops, otherwise immersion collapsed due to traffic demands. We recommend scripting loops around a narrative beat lasting no more than six seconds.",
    "post3.section2.p2": "Resonance extends beyond the physical site. We traced resonance by interviewing participants after their journey and tracking which cues they recalled. Campaigns that aligned visual metaphors with local culture scored higher, especially when copy appeared in both French and English. Bilingual delivery signalled inclusivity and boosted recall among cross-border commuters.",
    "post3.section2.subheading": "Network governance",
    "post3.section2.p3": "Applying the taxonomy requires governance tools. We developed a dashboard logging orientation, immersion, and resonance scores per site, along with qualitative notes. The dashboard guides asset placement, creative refresh cycles, and experimentation budgets. When teams share the taxonomy, debates shift from subjective taste to evidence-based adjustments.",
    "post3.imageAlt": "Observers recording data near digital billboards.",
    "post4.title": "Measuring cultural adjacency across bilingual markets",
    "post4.intro": "Cultural adjacency describes how messages travel between linguistic communities without losing relevance. In border regions of France and Belgium, campaigns often address audiences switching between French, Dutch, and English media. We constructed a measurement protocol that blends lexical analysis, community interviews, and social listening to evaluate adjacency. The protocol assists teams in selecting references that resonate on both sides of the language divide.",
    "post4.section1.title": "Lexical convergence mapping",
    "post4.section1.p1": "We begin by mapping shared vocabulary across languages. Rather than translating headlines literally, we identify concept clusters—mobility, sustainability, celebration—that appear in each language. When clusters align, creative teams gain freedom to adapt tone without diluting meaning. Misaligned clusters warning of cultural gaps prompt further research before launch.",
    "post4.section1.p2": "Lexical convergence analysis relies on corpora compiled from regional news, forums, and cultural programming. We annotate each occurrence with sentiment and context. The annotations reveal, for instance, that the word “transition” carries political weight in French but feels technical in Dutch. Knowing these nuances prevents inadvertent friction.",
    "post4.section1.subheading": "Adjacency indices",
    "post4.section1.p3": "The adjacency index scores how comfortably a message crosses linguistic borders. It factors lexical overlap, sentiment alignment, and historical associations. Scores below a threshold trigger creative rewrites or supplemental explanations such as subtitles or companion articles.",
    "post4.section2.title": "Community validation cycles",
    "post4.section2.p1": "Quantitative scores are strengthened through community validation. We organise bilingual discussion circles where participants react to scripts, storyboards, and mock-ups. Facilitators document where references land confidently and where clarification is required. These conversations often surface regional symbols we can incorporate into final assets.",
    "post4.section2.p2": "We also monitor cross-border social channels for spontaneous reactions. When audiences remix a campaign with local humour or add context in their own language, we log the behaviour as positive adjacency. Silence or corrective commentary signals misalignment that should inform subsequent iterations.",
    "post4.section2.subheading": "Reporting structures",
    "post4.section2.p3": "Final reports compile index scores, qualitative notes, and recommended guardrails. Teams receive bilingual summaries ensuring decision-makers on both sides interpret findings equally. The structure accelerates approvals and reduces the risk of late-stage objections from regional stakeholders.",
    "post4.imageAlt": "People discussing bilingual creative references.",
    "post5.title": "Governance protocols for creative data rooms",
    "post5.intro": "Creative data rooms host evolving artefacts—scripts, renders, soundtracks—that require careful governance. Without structure, evidence fragments and teams lose trust in the repository. We observed fifteen organisations coordinating multi-market campaigns and distilled governance protocols that keep data rooms reliable.",
    "post5.section1.title": "Establishing custodial roles",
    "post5.section1.p1": "Successful data rooms assign custodial roles to maintain clarity. A narrative custodian tracks storyline evolution, an evidence custodian validates research files, and a localisation custodian verifies bilingual accuracy. Each role has explicit permissions and escalation routes.",
    "post5.section1.p2": "Role clarity reduces duplication. When a localisation custodian uploads a translated script, the system alerts the narrative custodian to review tone consistency. These checks preserve coherence while maintaining agility for fast feedback loops.",
    "post5.section1.subheading": "Version discipline",
    "post5.section1.p3": "Version histories must be transparent. We recommend timestamped commits with short rationales written in both languages. Teams can trace why a change occurred, which reference supported it, and who approved the update. Transparency prevents disputes when campaigns enter regulatory review.",
    "post5.section2.title": "Curating access windows",
    "post5.section2.p1": "Creative data rooms should open and close access windows in sync with campaign milestones. During ideation, open access encourages contribution; as production nears, access narrows to responsible owners. This rhythm keeps the space collaborative without compromising accountability.",
    "post5.section2.p2": "We also advocate for reflection windows after each milestone. Teams annotate what worked, which assets need recycling, and where documentation fell short. These reflections feed future projects and maintain institutional memory.",
    "post5.section2.subheading": "Tooling and rituals",
    "post5.section2.p3": "Governance protocols thrive when paired with simple rituals: weekly check-ins, bilingual summaries, and automated alerts for stale files. Tooling should support metadata tagging, search in both languages, and exportable snapshots for auditors. With these rituals, creative data rooms become living archives rather than cluttered folders.",
    "post5.imageAlt": "Team stewarding a digital repository on screens.",
    "contact.hero.title": "Contact Atelier Reclame",
    "contact.hero.intro": "Use the form or reference details below to start a conversation about your analytical questions.",
    "contact.hero.imageAlt": "Workspace with notebook and laptop prepared for correspondence.",
    "contact.info.title": "Direct coordinates",
    "contact.info.subtitle": "We respond within two working days with references or clarifying questions.",
    "contact.info.phoneLabel": "Phone: +32 472 63 58 20",
    "contact.info.emailLabel": "Email: contact@atelier-reclame.fr",
    "contact.info.addressLabel": "Address: 123 Rue de la République, 75001 Paris, France",
    "contact.info.hours": "Office hours: Monday to Friday, 09:00–18:00 CET.",
    "contact.form.title": "Send us a note",
    "contact.form.name.label": "Full name",
    "contact.form.name.placeholder": "Enter your name",
    "contact.form.email.label": "Email address",
    "contact.form.email.placeholder": "Enter your email",
    "contact.form.org.label": "Organisation",
    "contact.form.org.placeholder": "Add your organisation or team",
    "contact.form.message.label": "Message",
    "contact.form.message.placeholder": "Share your context and questions",
    "contact.form.consent": "I agree to be contacted about this enquiry and understand my information will be used for response purposes.",
    "contact.form.submit": "Send message",
    "contact.map.title": "Find us in Paris",
    "contact.map.aria": "Interactive map highlighting our Paris location.",
    "faq.hero.title": "Frequently asked questions",
    "faq.hero.intro": "The responses below summarise how we organise research, collaborations, and data governance.",
    "faq.imageAlt": "Open notebook with research annotations.",
    "faq.q1": "Do you operate as an agency or a research lab?",
    "faq.a1": "Atelier Reclame functions as a research collective. We document advertising ecosystems, publish findings, and facilitate workshops, but we do not buy media or manage campaign execution.",
    "faq.q2": "How often do you update your frameworks?",
    "faq.a2": "Core frameworks receive quarterly reviews. When significant market shifts occur—new regulations, disruptive formats—we issue interim notes so collaborators stay aligned.",
    "faq.q3": "Can external teams contribute data?",
    "faq.a3": "Yes, provided the data includes collection methodology and consent information. We integrate external datasets after a validation sprint that ensures compatibility with our privacy protocols.",
    "faq.q4": "Do you provide reports in both English and French?",
    "faq.a4": "All publications include bilingual summaries. Longer dossiers may feature annexes in additional languages when local partners co-produce the work.",
    "faq.q5": "What happens to qualitative interviews after a project?",
    "faq.a5": "Interview recordings are catalogued in encrypted archives. Access is limited to researchers assigned to the project, and excerpts are anonymised before publication.",
    "faq.q6": "How can we request a workshop?",
    "faq.a6": "Use the contact form with your desired dates and objectives. We will respond with availability, suggested formats, and any prerequisite material.",
    "terms.section1.title": "1. Scope and acceptance",
    "terms.section1.body": "These terms govern the use of Atelier Reclame websites, publications, and shared repositories. Accessing our materials implies acceptance of these conditions.",
    "terms.section2.title": "2. Definitions",
    "terms.section2.body": "\"Materials\" refers to articles, datasets, templates, and recordings. \"Collaborators\" denotes individuals or organisations contributing to research with our consent.",
    "terms.section3.title": "3. Access",
    "terms.section3.body": "We provide access to materials on an informational basis. We may revoke access if usage jeopardises confidentiality, data integrity, or compliance obligations.",
    "terms.section4.title": "4. Intellectual property",
    "terms.section4.body": "Unless otherwise indicated, Atelier Reclame retains intellectual property rights over materials. Collaborators retain ownership of their original contributions.",
    "terms.section5.title": "5. Use of materials",
    "terms.section5.body": "Materials may be referenced for internal insights and academic discourse. Redistribution or public publication requires written permission.",
    "terms.section6.title": "6. Research contributions",
    "terms.section6.body": "Contributors must ensure shared data is accurate, lawful, and accompanied by consent documentation. We may decline materials that lack provenance.",
    "terms.section7.title": "7. Community conduct",
    "terms.section7.body": "We expect respectful dialogue across all channels. Harassment, discrimination, or misuse of collected evidence results in immediate suspension.",
    "terms.section8.title": "8. Third-party links",
    "terms.section8.body": "External links provided for context are not endorsements. We do not control third-party resources and bear no responsibility for their content.",
    "terms.section9.title": "9. Data accuracy",
    "terms.section9.body": "We strive to maintain accurate information but cannot guarantee completeness. Users should verify findings before applying them to critical decisions.",
    "terms.section10.title": "10. Disclaimer of warranties",
    "terms.section10.body": "Materials are provided \"as is\" without warranties. Insights represent observations at the time of publication and may evolve.",
    "terms.section11.title": "11. Limitation of liability",
    "terms.section11.body": "Atelier Reclame is not liable for direct or indirect damages arising from the use or inability to use our materials.",
    "terms.section12.title": "12. Updates to terms",
    "terms.section12.body": "We may revise these terms to reflect organisational or regulatory changes. Updates take effect upon publication on this page.",
    "terms.section13.title": "13. Governing law",
    "terms.section13.body": "These terms are governed by French law, with disputes submitted to the competent courts in Paris.",
    "terms.section14.title": "14. Contact information",
    "terms.section14.body": "Questions about these terms may be directed to contact@atelier-reclame.fr.",
    "privacy.section1.title": "1. Introduction",
    "privacy.section1.body": "This notice explains how Atelier Reclame collects, uses, and protects personal data when you interact with our website, publications, or research programs.",
    "privacy.section2.title": "2. Data we collect",
    "privacy.section2.body": "We collect contact details submitted via forms, correspondence records, research participation notes, and technical telemetry such as page analytics when permitted.",
    "privacy.section3.title": "3. Purpose of processing",
    "privacy.section3.body": "Data supports communication, project coordination, research analysis, security monitoring, and compliance with legal obligations.",
    "privacy.section4.title": "4. Legal basis",
    "privacy.section4.body": "Processing relies on consent, legitimate interest in delivering research services, or contractual necessity when agreements exist.",
    "privacy.section5.title": "5. Storage and security",
    "privacy.section5.body": "We store data on secure servers within the European Union, applying encryption, access controls, and regular audits.",
    "privacy.section6.title": "6. Data sharing",
    "privacy.section6.body": "We share personal data only with trusted processors assisting with hosting, communication, or research facilitation. All processors adhere to confidentiality agreements.",
    "privacy.section7.title": "7. International transfers",
    "privacy.section7.body": "If data leaves the European Union, we implement safeguards such as standard contractual clauses and ensure equivalent protection levels.",
    "privacy.section8.title": "8. Your rights",
    "privacy.section8.body": "You may request access, correction, deletion, restriction, or portability of your personal data. You also have the right to object to certain processing and to withdraw consent.",
    "privacy.section9.title": "9. Retention periods",
    "privacy.section9.body": "We retain data only as long as necessary for the stated purposes, legal requirements, or archival value. Non-essential data is periodically deleted.",
    "privacy.section10.title": "10. Contact",
    "privacy.section10.body": "For privacy enquiries, email contact@atelier-reclame.fr or write to 123 Rue de la République, 75001 Paris, France.",
    "cookies.hero.title": "Cookie policy",
    "cookies.hero.intro": "This policy describes how cookies and similar technologies support the Atelier Reclame experience.",
    "cookies.usage.title": "How we use cookies",
    "cookies.usage.body": "We employ cookies to maintain session security, remember language preferences, analyse aggregate behaviour, and deliver relevant content.",
    "cookies.table.title": "Cookie register",
    "cookies.table.description": "The table lists cookies currently set on this site.",
    "cookies.table.headingName": "Name",
    "cookies.table.headingProvider": "Provider",
    "cookies.table.headingType": "Type",
    "cookies.table.headingPurpose": "Purpose",
    "cookies.table.headingDuration": "Duration",
    "cookies.table.row1.name": "session_id",
    "cookies.table.row1.provider": "Atelier Reclame",
    "cookies.table.row1.type": "Necessary",
    "cookies.table.row1.purpose": "Maintains secure access between pages during a browsing session.",
    "cookies.table.row1.duration": "Session",
    "cookies.table.row2.name": "site_lang",
    "cookies.table.row2.provider": "Atelier Reclame",
    "cookies.table.row2.type": "Preferences",
    "cookies.table.row2.purpose": "Stores your selected language for subsequent visits.",
    "cookies.table.row2.duration": "12 months",
    "cookies.table.row3.name": "analytics_insight",
    "cookies.table.row3.provider": "Atelier Reclame",
    "cookies.table.row3.type": "Analytics",
    "cookies.table.row3.purpose": "Helps us understand aggregated page performance and navigation patterns.",
    "cookies.table.row3.duration": "6 months",
    "cookies.table.row4.name": "campaign_context",
    "cookies.table.row4.provider": "Atelier Reclame",
    "cookies.table.row4.type": "Marketing",
    "cookies.table.row4.purpose": "Records anonymised context to tailor research updates in newsletters.",
    "cookies.table.row4.duration": "6 months",
    "cookies.preferences.title": "Managing cookies",
    "cookies.preferences.body": "You can adjust cookie categories using the banner controls at any time. Declining non-essential cookies may reduce personalised insights, but core navigation remains available.",
    "refund.section1.title": "1. Purpose",
    "refund.section1.body": "This refund policy explains how Atelier Reclame handles requests related to informational resources, workshops, and events.",
    "refund.section2.title": "2. Eligibility",
    "refund.section2.body": "Refunds apply to paid registrations for workshops or access to extended research materials when terms specify a refundable option.",
    "refund.section3.title": "3. Notification window",
    "refund.section3.body": "Requests must arrive within ten working days of purchase or at least five working days before a scheduled session, whichever comes first.",
    "refund.section4.title": "4. Documentation",
    "refund.section4.body": "Please include proof of purchase, contact information, and a description of circumstances prompting the request.",
    "refund.section5.title": "5. Review process",
    "refund.section5.body": "We evaluate each request to confirm eligibility, verify attendance records, and review resource usage.",
    "refund.section6.title": "6. Outcomes",
    "refund.section6.body": "Approved refunds may result in credit notes, partial reimbursement, or alternative access arrangements depending on the context.",
    "refund.section7.title": "7. Non-refundable cases",
    "refund.section7.body": "Completed bespoke research, customised datasets, and sessions already delivered are not refundable.",
    "refund.section8.title": "8. Schedule adjustments",
    "refund.section8.body": "If we reschedule an event, you may accept the new date or request a refund within five working days.",
    "refund.section9.title": "9. Contact channel",
    "refund.section9.body": "Submit refund enquiries via contact@atelier-reclame.fr with the subject line \"Refund request\".",
    "refund.section10.title": "10. Policy updates",
    "refund.section10.body": "We may update this policy to reflect new offerings or regulations. Changes are effective upon publication.",
    "disclaimer.section1.title": "Purpose of content",
    "disclaimer.section1.body": "Atelier Reclame publishes analytical observations intended for informational purposes. The content does not constitute financial, legal, or professional advice.",
    "disclaimer.section2.title": "No guarantees",
    "disclaimer.section2.body": "We do not guarantee that outcomes described in case studies or forecasts will replicate in other contexts.",
    "disclaimer.section3.title": "Independent verification",
    "disclaimer.section3.body": "Readers should verify data and conduct independent assessment before applying insights to strategic decisions.",
    "disclaimer.section4.title": "Third-party sources",
    "disclaimer.section4.body": "References to third-party materials do not imply endorsement. We are not responsible for external content accuracy.",
    "disclaimer.section5.title": "Liability limitation",
    "disclaimer.section5.body": "Atelier Reclame is not liable for losses or damages arising from reliance on our publications or tools.",
    "disclaimer.section6.title": "Contact",
    "disclaimer.section6.body": "For clarification about this disclaimer, email contact@atelier-reclame.fr.",
    "thankyou.title": "Thank you for your message",
    "thankyou.message": "We have received your note and will reply within two working days. A confirmation has been sent to your inbox.",
    "thankyou.back": "Return to homepage",
    "thankyou.contact": "Send another message",
    "404.title": "Page not found",
    "404.message": "The page you requested is no longer available or has moved. Use the options below to continue exploring Atelier Reclame.",
    "404.home": "Go to homepage",
    "404.contact": "Reach our team",
    "cookies.banner.title": "We value your privacy",
    "cookies.banner.message": "Cookies help us understand how the site is used and keep your language preferences. Adjust categories below or accept all.",
    "cookies.banner.accept": "Accept all",
    "cookies.banner.decline": "Decline all",
    "cookies.banner.save": "Save preferences",
    "cookies.banner.manage": "Manage preferences",
    "cookies.banner.close": "Close banner",
    "cookies.banner.preferencesTitle": "Cookie categories",
    "cookies.banner.necessary": "Necessary",
    "cookies.banner.necessary.desc": "Required for security and core navigation. Cannot be disabled.",
    "cookies.banner.preferences": "Preferences",
    "cookies.banner.preferences.desc": "Remember settings such as language and accessibility choices.",
    "cookies.banner.analytics": "Analytics",
    "cookies.banner.analytics.desc": "Measure aggregate usage to improve content relevance.",
    "cookies.banner.marketing": "Marketing",
    "cookies.banner.marketing.desc": "Support contextual updates about our research releases.",
    "cookies.banner.respect": "We respect your choices and store them for future visits.",
    "toast.form.success": "Message ready to send. Redirecting to confirmation...",
    "toast.form.error": "Please complete required fields before submitting.",
    "toast.cookie.saved": "Your cookie preferences have been saved."
  },
  fr: {
    "brand.initials": "AR",
    "brand.name": "Atelier Reclame",
    "brand.tagline": "Observatoire indépendant des écosystèmes publicitaires.",
    "nav.home": "Accueil",
    "nav.services": "Recherches",
    "nav.about": "À propos",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "lang.en": "EN",
    "lang.fr": "FR",
    "aria.navToggle": "Ouvrir ou fermer le menu de navigation",
    "aria.languageSwitch": "Changer de langue",
    "aria.openCookiePreferences": "Ouvrir les préférences de cookies",
    "aria.closeBanner": "Fermer la bannière",
    "aria.submitContact": "Envoyer le formulaire de contact",
    "footer.contactTitle": "Contact",
    "footer.addressTitle": "Adresse",
    "footer.legalTitle": "Pôle juridique",
    "footer.rights": "© {{year}} Atelier Reclame · Tous droits d'analyse réservés.",
    "footer.phone": "Téléphone · +32 472 63 58 20",
    "footer.email": "Courriel · contact@atelier-reclame.fr",
    "footer.address": "123 Rue de la République, 75001 Paris, France",
    "footer.manageCookies": "Paramétrer les cookies",
    "footer.tagline": "Nous explorons les phénomènes publicitaires pour les équipes en France et en Europe.",
    "footer.terms": "Conditions d'utilisation",
    "footer.privacy": "Politique de confidentialité",
    "footer.cookies": "Politique de cookies",
    "footer.refund": "Politique de remboursement",
    "footer.disclaimer": "Avis de non-responsabilité",
    "button.backHome": "Retour à l'accueil",
    "button.contact": "Contacter l'équipe",
    "meta.index.title": "Atelier Reclame · Collectif de recherche publicitaire",
    "meta.index.description": "Atelier Reclame documente les systèmes publicitaires avec des recherches bilingues et fournit des analyses neutres pour les équipes en France et en Europe.",
    "meta.services.title": "Capacités de recherche · Atelier Reclame",
    "meta.services.description": "Panorama des méthodologies d'Atelier Reclame : analyse des systèmes médias, cartographie créative et dispositifs de diagnostic.",
    "meta.about.title": "À propos d'Atelier Reclame · Collectif de recherche",
    "meta.about.description": "Découvrez Atelier Reclame, une équipe franco-belge qui étudie les phénomènes publicitaires grâce à des travaux multilingues.",
    "meta.blog.title": "Blog d'analyses · Atelier Reclame",
    "meta.blog.description": "Explorez le blog d'Atelier Reclame consacré aux campagnes, aux métriques culturelles et aux cadres d'observation.",
    "meta.post1.title": "Interpréter la portée multilayer · Atelier Reclame",
    "meta.post1.description": "Revue technique des modèles de portée pour campagnes orientées streaming et des heuristiques de segmentation.",
    "meta.post2.title": "Strates sémiotiques dans l'automobile · Atelier Reclame",
    "meta.post2.description": "Analyse des choix sémiotiques en publicité automobile et de leurs résonances culturelles.",
    "meta.post3.title": "Taxonomie de l'attention pour l'OOH · Atelier Reclame",
    "meta.post3.description": "Définition des états d'attention dans les réseaux d'affichage et des techniques de diagnostic.",
    "meta.post4.title": "Mesurer l'adjacence culturelle bilingue · Atelier Reclame",
    "meta.post4.description": "Méthodologies pour évaluer l'adjacence culturelle entre marchés francophones et anglophones.",
    "meta.post5.title": "Gouvernance des data rooms créatives · Atelier Reclame",
    "meta.post5.description": "Guide opérationnel pour piloter des data rooms créatives et leur capital de connaissances.",
    "meta.contact.title": "Contacter Atelier Reclame",
    "meta.contact.description": "Contactez Atelier Reclame pour vos questions analytiques, collaborations ou accès aux données.",
    "meta.faq.title": "FAQ · Atelier Reclame",
    "meta.faq.description": "Questions fréquentes sur les processus de recherche et la gouvernance des données chez Atelier Reclame.",
    "meta.terms.title": "Conditions d'utilisation · Atelier Reclame",
    "meta.terms.description": "Conditions appliquées aux publications et ressources numériques d'Atelier Reclame.",
    "meta.privacy.title": "Politique de confidentialité · Atelier Reclame",
    "meta.privacy.description": "Pratiques de confidentialité d'Atelier Reclame : collecte, conservation et droits des utilisateurs.",
    "meta.cookies.title": "Politique de cookies · Atelier Reclame",
    "meta.cookies.description": "Utilisation des cookies, catégories et gestion du consentement chez Atelier Reclame.",
    "meta.refund.title": "Politique de remboursement · Atelier Reclame",
    "meta.refund.description": "Politique de remboursement pour les ressources et événements d'Atelier Reclame.",
    "meta.disclaimer.title": "Avertissement · Atelier Reclame",
    "meta.disclaimer.description": "Limites des analyses et ressources proposées par Atelier Reclame.",
    "meta.thankyou.title": "Merci · Atelier Reclame",
    "meta.thankyou.description": "Confirmation de votre message à Atelier Reclame.",
    "meta.404.title": "Page introuvable · Atelier Reclame",
    "meta.404.description": "La page demandée chez Atelier Reclame est introuvable.",
    "index.hero.title": "Décoder l'impact publicitaire auprès des audiences européennes",
    "index.hero.subtitle": "Atelier Reclame orchestre des recherches longitudinales sur les comportements médias, les narratifs créatifs et les écologies de campagne pour offrir des éclairages vérifiés.",
    "index.hero.cta": "Explorer notre base de connaissances",
    "index.hero.secondary": "Découvrir les modalités de collaboration",
    "index.hero.note": "Nos analystes répertorient chaque trimestre 112 initiatives multi-marchés.",
    "index.hero.metric1": "12+ ans à synthétiser des preuves de campagnes transnationales",
    "index.hero.metric2": "90 jeux de données empiriques suivis en continu",
    "index.hero.metric3": "4 cadres de recherche éprouvés avec des laboratoires partenaires",
    "index.hero.imageAlt": "Chercheurs examinant des tableaux de bord médias superposés dans un studio.",
    "index.featured.title": "Cadres d'analyse actuels",
    "index.featured.desc": "Chaque cadre croise comportements d'audience, finesse créative et architecture média afin de produire des recommandations neutres.",
    "index.featured.card1.title": "Cartographie des systèmes médias",
    "index.featured.card1.text": "Cartographier les écosystèmes de canaux pour comprendre les recouvrements, la décroissance de portée et les manques d'opportunités dans des environnements fragmentés.",
    "index.featured.card2.title": "Benchmarks sémiotiques créatifs",
    "index.featured.card2.text": "Comparer dispositifs narratifs, rythmes et indices sensoriels pour identifier les signaux que les audiences retiennent réellement.",
    "index.featured.card3.title": "Ledger de résonance des résultats",
    "index.featured.card3.text": "Suivre résidus d'attention, indices de considération et adjacence culturelle pour clarifier la performance au-delà des impressions.",
    "index.method.title": "Comment nous structurons l'observation",
    "index.method.intro": "Notre méthodologie valorise la reproductibilité des métriques, la transparence contextuelle et des validations multilingues.",
    "index.method.list1": "Capture de données triangulée entre terrains, panels et archives médiatiques.",
    "index.method.list2": "Sprints d'annotation contrôlés pour distinguer intention créative et impact observable.",
    "index.method.list3": "Relectures croisées par des spécialistes indépendants de la narration et du planning média.",
    "index.method.list4": "Référentiels versionnés afin que chaque révision reste traçable pour les collaborateurs.",
    "index.method.imageAlt": "Documents et annotations superposés illustrant le workflow d'Atelier Reclame.",
    "index.recommendations.title": "Recommandations à retenir",
    "index.recommendations.desc": "Actions clés adoptées par les équipes communication après lecture de nos dossiers.",
    "index.recommendations.card1.title": "Actualiser le rôle de chaque canal",
    "index.recommendations.card1.text": "Formuler l'intention derrière chaque point de contact pour conserver une progression narrative cohérente.",
    "index.recommendations.card2.title": "Documenter les indices sensoriels",
    "index.recommendations.card2.text": "Auditer sons, visuels et spatialisation pour maintenir des signaux reconnaissables sur tous supports.",
    "index.recommendations.card3.title": "Aligner mesure et arcs narratifs",
    "index.recommendations.card3.text": "Synchroniser les bilans avec les phases de récit plutôt qu'avec le seul calendrier.",
    "index.recommendations.imageAlt": "Chercheurs échangeant des recommandations dans un studio.",
    "index.testimonials.title": "Témoignages",
    "index.testimonials.desc": "Des acteurs de la recherche, de la culture et du design expliquent l'apport de nos compendiums.",
    "index.testimonials.quote1.text": "Les dossiers convertissent la complexité des médias en hypothèses structurées que nous pouvons tester sur le terrain.",
    "index.testimonials.quote1.meta": "Élodie Marchand · Ethnographe des médias",
    "index.testimonials.quote2.text": "Atelier Reclame reste concentré sur les signaux culturels réellement diffusés, pas uniquement ceux comptés par un tableau de bord.",
    "index.testimonials.quote2.meta": "Gareth Ellis · Stratège créatif",
    "index.testimonials.quote3.text": "Leur notation bilingue nous permet de débattre sans perdre en nuance ni en cadence.",
    "index.testimonials.quote3.meta": "Nadia Belkacem · Directrice de communication",
    "index.blogpreview.title": "Dernières publications",
    "index.blogpreview.desc": "Parcourez nos séries analytiques sur la gouvernance des campagnes, les métriques culturelles et le diagnostic de l'attention.",
    "index.blogpreview.cta": "Visiter le blog",
    "index.contactprompt.title": "Partagez votre question analytique",
    "index.contactprompt.text": "Exposez le scénario que vous cartographiez ; nous répondons avec des cas pertinents et des références ouvertes.",
    "index.contactprompt.button": "Aller vers la page contact",
    "services.hero.title": "Panorama de nos capacités de recherche",
    "services.hero.intro": "Nous examinons les systèmes publicitaires par des études indépendantes et fournissons de la documentation plutôt que des prestations d'exécution.",
    "services.service1.title": "Analyse des systèmes médias",
    "services.service1.text": "Revue structurelle des canaux, investissements et cadences pour clarifier la circulation des messages dans des environnements fragmentés.",
    "services.service1.point1": "Modélisation des adjacences de canaux avec suivi de décroissance de fréquence.",
    "services.service1.point2": "Tests de scénarios de portée pour des programmations transfrontalières.",
    "services.service2.title": "Cartographie des patterns créatifs",
    "services.service2.text": "Évaluer indices sensoriels, charpentes narratives et sémiotique de marque pour dégager des signaux distinctifs.",
    "services.service2.point1": "Décomposition des séquences audio et vidéo.",
    "services.service2.point2": "Bibliothèques d'indicateurs pour symboles, textures et tonalités.",
    "services.service3.title": "Observatoire des insights audience",
    "services.service3.text": "Observation longitudinale des rituels, repères culturels et perceptions bilingues en France et en Belgique.",
    "services.service3.point1": "Journaux in situ et synthèses de panels actualisés chaque trimestre.",
    "services.service3.point2": "Clustering géoculturel pour révéler les contrastes régionaux.",
    "services.service4.title": "Stewardship des diagnostics de campagne",
    "services.service4.text": "Construction de plages de mesure neutres tenant compte de la maturité narrative, de la saturation média et du contexte.",
    "services.service4.point1": "Référentiels de performance alignés sur les phases du récit.",
    "services.service4.point2": "Simulations de scénarios pour interventions planifiées ou réactives.",
    "services.method.title": "Principes méthodologiques",
    "services.method.text": "Chaque programme repose sur des protocoles collaboratifs garantissant l'auditabilité et l'adaptabilité des preuves.",
    "services.method.point1": "Glossaires partagés pour harmoniser la terminologie entre équipes.",
    "services.method.point2": "Chaque observation conserve citations et horodatages de version.",
    "services.method.point3": "Les modèles de données restent portables pour les systèmes partenaires.",
    "services.frameworks.title": "Bibliothèques de cadres",
    "services.frameworks.text": "Nos cadres sont licenciés pour la recherche et peuvent être réagencés avec vos taxonomies internes.",
    "services.frameworks.point1": "Matrice de posture narrative reliant ton et résultats.",
    "services.frameworks.point2": "Cartes thermiques de résidus d'attention pour les actifs multisensoriels.",
    "services.frameworks.point3": "Indice d'adjacence culturelle calibré pour les marchés bilingues.",
    "services.closing.title": "Rythme d'engagement",
    "services.closing.text": "Nous coordonnons des sessions périodiques pour valider les constats, co-rédiger des annotations et adapter le référentiel au fil des preuves.",
    "services.imageAlt": "Atelier collaboratif passant en revue des cadres publicitaires.",
    "about.hero.title": "Qui sommes-nous ?",
    "about.hero.intro": "Atelier Reclame est né d'une collaboration franco-belge visant à traduire la recherche publicitaire en observatoires opérationnels.",
    "about.story.title": "Origines",
    "about.story.p1": "Le collectif a démarré entre Lyon et Liège, où chercheurs, planneurs et analystes culturels ont croisé la réalité vécue des campagnes avec les récits académiques.",
    "about.story.p2": "Travailler en bilingue dès le départ a assuré une circulation fluide des insights entre métropoles et territoires sans perte de nuance.",
    "about.values.title": "Valeurs fondatrices",
    "about.values.list1": "Intégrité des preuves : chaque affirmation renvoie à une source publique ou partageable.",
    "about.values.list2": "Contexte avant jugement : nous expliquons l'apparition d'un signal avant d'en mesurer l'effet.",
    "about.values.list3": "Accessibilité : nos livrables sont écrits pour des équipes plurilingues et pluridisciplinaires.",
    "about.team.title": "Équipe interdisciplinaire",
    "about.team.p1": "Nos analystes alternent terrain qualitatif, modélisation quantitative et synthèse éditoriale pour conserver une vision holistique.",
    "about.team.p2": "Des partenaires sémioticiens, designers, sociologues et acheteurs média coécrivent des annexes spécialisées.",
    "about.timeline.title": " Jalons",
    "about.timeline.item1": "2012 · Création du premier référentiel commun pour journaux de campagnes franco- et anglophones.",
    "about.timeline.item2": "2016 · Lancement de l'indice d'adjacence culturelle après étude des pratiques médiatiques bilingues.",
    "about.timeline.item3": "2021 · Déploiement du ledger de résonance des résultats avec relectures collaboratives.",
    "about.resources.title": "Ressources en circulation",
    "about.resources.p1": "Nous publions working papers, tableaux de bord annotés et scripts d'ateliers pour permettre la reproduction de nos approches.",
    "about.imageAlt": "Membres de l'équipe discutant devant des panneaux de recherche.",
    "blog.hero.title": "Chroniques analytiques",
    "blog.hero.intro": "Chaque article documente expérimentations, débats et cadres qui façonnent la pratique publicitaire actuelle.",
    "blog.note": "Parcourez les filtres thématiques ou déroulez l'archive complète.",
    "blog.readmore": "Lire la suite",
    "blog.post1.title": "Interpréter la portée multilayer pour les campagnes streaming",
    "blog.post1.excerpt": "Analyse de la manière dont les couches de fréquence superposées modifient la perception quand la vidéo streaming domine le mix.",
    "blog.post1.imageAlt": "Tableau de bord visualisant les strates de portée d'une campagne streaming.",
    "blog.post2.title": "Strates sémiotiques dans les récits automobiles",
    "blog.post2.excerpt": "Lecture des indices sensoriels qui guident les narrations automobiles à travers les marchés européens.",
    "blog.post2.imageAlt": "Storyboard illustrant des récits automobiles.",
    "blog.post3.title": "Taxonomie de l'attention pour les réseaux OOH",
    "blog.post3.excerpt": "Définition des états d'attention dans les réseaux modulaires d'affichage et leurs implications de diagnostic.",
    "blog.post3.imageAlt": "Écrans d'affichage urbain capturés de nuit.",
    "blog.post4.title": "Mesurer l'adjacence culturelle sur des marchés bilingues",
    "blog.post4.excerpt": "Méthodologies comparant la résonance entre flux de communication français et anglais.",
    "blog.post4.imageAlt": "Carnet comparant des références culturelles bilingues.",
    "blog.post5.title": "Protocoles de gouvernance des data rooms créatives",
    "blog.post5.excerpt": "Structurer la stewardship des référentiels créatifs interdisciplinaires.",
    "blog.post5.imageAlt": "Data room créative avec dossiers organisés.",
    "blog.hero.imageAlt": "Rapports imprimés et notes illustrant une recherche.",
    "post1.title": "Interpréter la portée multilayer pour les campagnes streaming",
    "post1.intro": "Les campagnes conçues pour le streaming produisent désormais des expositions superposées qui ne ressemblent plus à la pyramide télévisuelle classique. Les indicateurs linéaires de fréquence ne décrivent pas comment l'insertion dynamique, le binge-watching et le changement d'appareil créent des couches de portée. Nous reconstituons l'empreinte de portée à partir de la densité temporelle, de l'adjacence contextuelle et de l'élasticité des appareils afin d'offrir des repères comparables. L'approche s'appuie sur des journaux mixtes menés à Lyon, Rotterdam et Marseille, suivant la manière dont les participants se souviennent des publicités après navigation entre interfaces française et anglaise.",
    "post1.section1.title": "Recomposer l'empreinte de fréquence",
    "post1.section1.p1": "Plutôt que d'additionner les impressions, nous cartographions des grappes d'exposition sur des fenêtres de quatre-vingt-dix minutes et les indexons par état narratif. Les catalogues streaming publient des épisodes en rafales, entraînant une superposition d'expositions lorsque l'audience binge. Nous mesurons donc la surface d'une grappe en combinant durée d'épisode, pauses et co-utilisation des appareils. Au-delà d'un seuil, les expositions tardives sont considérées comme du renfort et non comme de la portée fraîche, ce qui reflète mieux les souvenirs des répondants.",
    "post1.section1.p2": "La portée en couches dépend aussi des bascules audio et sous-titres. Nos journaux bilingues montrent que passer en audio original atténue le souvenir d'un message doublé jusqu'à l'apparition d'un nouveau signal. Nous consignons ces inflexions comme pivots de traduction. Les analystes pondèrent alors différemment les impressions post-pivot, reconnaissant que le cerveau réinitialise son attention lorsqu'il décrypte un nouveau pattern linguistique.",
    "post1.section1.subheading": "Heuristiques de pondération",
    "post1.section1.p3": "Pour rester gérable, le modèle segmente l'audience selon l'intention de session : découverte, continuation ou visionnage ambiant. La découverte valorise les expositions initiales car le public évalue activement le catalogue ; l'ambiance considère les expositions comme un arrière-plan et applique une atténuation. Cette pondération maintient l'alignement entre observations qualitatives et estimations quantitatives et évite de gonfler artificiellement l'impact.",
    "post1.section2.title": "Synchroniser les signaux qualitatifs",
    "post1.section2.p1": "Nous stabilisons le modèle grâce à des marqueurs qualitatifs issus d'entretiens. Les participants décrivent des moments où une publicité ponctue le récit, par exemple un cliffhanger ou un pont musical. Nous codons ces marqueurs comme ancres de résonance et les alignons sur la chronologie des grappes. Une ancre récurrente à travers les participants valorise la grappe concernée, même avec peu d'impressions brutes.",
    "post1.section2.p2": "À l'inverse, lorsque la fatigue face à des indices répétitifs est signalée, nous diminuons la pondération de la grappe associée. Cette fatigue apparaît souvent après trois épisodes consécutifs d'une franchise, surtout quand les variantes créatives ne modifient que la fin. Appliquer un coefficient d'atténuation rend les rapports plus réalistes pour les planificateurs qui pourraient sinon poursuivre des renforcements artificiellement élevés.",
    "post1.section2.subheading": "Tableaux de bord opérationnels",
    "post1.section2.p3": "Les tableaux de bord construits sur ce modèle doivent permettre de basculer entre volumes bruts et portée pondérée. Nous conseillons de stocker les définitions de grappe dans une table transparente afin que les parties prenantes puissent auditer les décisions. Chaque entrée mentionne l'intention de session, les pivots linguistiques, les ancres de résonance et les drapeaux de fatigue. Les équipes ayant adopté la structure constatent des débats transmarchés plus riches car les preuves se traduisent sans perte pour les briefs en français et en anglais.",
    "post1.imageAlt": "Analyste examinant des données de streaming sur plusieurs écrans.",
    "post2.title": "Strates sémiotiques dans les récits automobiles",
    "post2.intro": "La narration automobile s'appuie de plus en plus sur des strates sémiotiques pour concilier innovation électrique et héritage. Nous avons analysé douze campagnes européennes couvrant segments premium, utilitaires et performance afin de comprendre la circulation des symboles. L'étude combine lectures sémiotiques, motion capture et entretiens ethnographiques avec des conducteurs à Lille, Namur et Bordeaux. Nous observons comment les conducteurs perçoivent ces indices bilingues et comment les agences orchestrent la transition entre tradition et futurisme.",
    "post2.section1.title": "Construire l'épine sensorielle",
    "post2.section1.p1": "Chaque campagne étudiée s'ancre sur une épine sensorielle. Les marques premium conservent un grondement grave de moteur même pour des modèles électriques silencieux, créant une résonance fantôme. Les marques utilitaires ajoutent des textures tactiles, plaçant des micros sur portes et caisses. En croisant ces sons aux motifs visuels, nous suivons les promesses associées par l'audience et vérifions leur cohérence en version bilingue.",
    "post2.section1.p2": "Les motifs visuels suivent un schéma comparable. Les récits de performance privilégient les grands panoramas côtiers, tandis que les différentes promesses durables favorisent les plans serrés en ville. En reliant les images aux transcriptions, les participants associent les panoramas à l'autonomie et les plans serrés à la responsabilité sociale. Le mélange des deux familles sans transition claire explique l'échec de certaines campagnes.",
    "post2.section1.subheading": "Transitions sémiotiques",
    "post2.section1.p3": "La superposition sémiotique réussit lorsque les transitions respectent les attentes. Nous avons répertorié les éléments de pont — passages de vitesses, jeux de lumière, déclarations — qui rendent le changement lisible. Les conducteurs se disent perdus si une séquence passe d'une ville à l'aube à une montagne nocturne sans indice sonore. Les marquer dans la timeline permet aux stratèges de garantir une justification visible dans chaque langue et chaque montage.",
    "post2.section2.title": "Aligner héritage et innovation",
    "post2.section2.p1": "Les références patrimoniales n'entravent pas le discours d'innovation. Les campagnes efficaces utilisent des archives ou slogans historiques comme ancrage mémoriel avant d'introduire les plateformes électriques. Elles superposent ensuite indices contemporains : typographies actualisées, animations d'interfaces, palettes revisitées. Les participants se disent rassurés plutôt que nostalgiques car l'héritage contextualise la technologie.",
    "post2.section2.p2": "Les campagnes moins efficaces isolent l'héritage et laissent le public interpréter sa pertinence. Une séquence de rallye sans commentaire exclut les plus jeunes. Nous recommandons d'ajouter des micro-annotations — voix off ou sous-titres — qui expliquent la place du modèle historique dans le débat sur la mobilité.",
    "post2.section2.subheading": "Impacts éditoriaux",
    "post2.section2.p3": "Les monteurs peuvent tracer les strates sémiotiques sur une timeline partagée. Chaque strate indique son indice sensoriel, le sens visé et la preuve associée. Ce document devient un artefact de gouvernance pour agences et annonceurs multi-marchés. Les équipes françaises et anglaises décident ensemble quelles strates conserver, adapter ou enrichir pour garantir une lecture fluide des films.",
    "post2.imageAlt": "Designer disposant des cadres d'une campagne automobile sur une table.",
    "post3.title": "Taxonomie de l'attention pour les réseaux OOH",
    "post3.intro": "Les réseaux d'affichage fonctionnent comme des écosystèmes réactifs mêlant écrans routiers, transports et surfaces expérientielles. Les métriques traditionnelles considèrent ces supports comme des impressions statiques, alors que les temps de contact et stimuli se superposent. Notre taxonomie requalifie l'attention en états d'orientation, d'immersion et de résonance à partir d'observations à Paris, Bruxelles et Lyon. Elle guide l'ajustement des créations et de leur cadence.",
    "post3.section1.title": "Définir l'état d'orientation",
    "post3.section1.p1": "L'orientation correspond au moment où un passant identifie le support. Dans les hubs de transport, elle dure moins de deux secondes et dépend du contraste et du mouvement. Les panneaux routiers offrent une fenêtre plus longue mais subissent l'éblouissement. Nous avons corrélé les rotations de tête à la luminance pour établir des seuils optimaux par environnement.",
    "post3.section1.p2": "L'orientation s'érode vite lorsque deux créations consécutives partagent la même palette. L'audience ignore la seconde, même avec un message différent. Introduire des micro-variations — motifs, éclairages directionnels — maintient l'orientation sans briser l'identité. C'est crucial quand plusieurs annonceurs partagent une boucle.",
    "post3.section1.subheading": "Score heuristique",
    "post3.section1.p3": "Nous avons élaboré un score combinant intensité des déclencheurs, encombrement environnemental et variabilité par moments de la journée. Le score signale quand augmenter la rotation ou repenser l'actif. Les réseaux qui l'appliquent réduisent les impressions perdues en priorisant les sites où l'orientation reste stable quelle que soit la langue et le profil de navetteur.",
    "post3.section2.title": "Immersion et résonance",
    "post3.section2.p1": "L'immersion mesure les secondes suivant l'orientation pendant lesquelles le message est traité. Les écrans expérientiels en centre commercial obtiennent de fortes immersions grâce aux données temps réel ou à l'audio ambiant. Les panneaux routiers exigent des boucles courtes, sinon l'immersion chute à cause des contraintes de circulation. Nous recommandons des boucles autour d'un beat narratif de six secondes.",
    "post3.section2.p2": "La résonance dépasse le site physique. Nous l'avons suivie via des interviews post-parcours et la mémorisation des indices. Les campagnes alignées avec les métaphores locales obtiennent de meilleurs scores, surtout lorsque la copie existe en français et en anglais. Le bilinguisme renvoie un signal d'inclusion et renforce le rappel chez les navetteurs transfrontaliers.",
    "post3.section2.subheading": "Gouvernance du réseau",
    "post3.section2.p3": "Appliquer la taxonomie suppose des outils dédiés. Nous avons conçu un tableau de bord qui consigne par site les scores d'orientation, d'immersion et de résonance ainsi que les notes qualitatives. Il guide le placement, les rafraîchissements créatifs et les budgets d'expérimentation. Partagé entre équipes, il déplace les débats du terrain subjectif vers des ajustements fondés sur la preuve.",
    "post3.imageAlt": "Observateurs enregistrant des données près de panneaux numériques.",
    "post4.title": "Mesurer l'adjacence culturelle sur des marchés bilingues",
    "post4.intro": "L'adjacence culturelle décrit la capacité d'un message à circuler entre communautés linguistiques sans perdre sa pertinence. Dans les régions frontalières de France et de Belgique, les campagnes dialoguent avec des audiences qui alternent médias français, néerlandais et anglais. Nous avons construit un protocole mêlant analyse lexicale, entretiens communautaires et social listening pour évaluer cette adjacence et choisir des références valides des deux côtés.",
    "post4.section1.title": "Cartographie de convergence lexicale",
    "post4.section1.p1": "Nous débutons par cartographier les vocabulaires partagés. Plutôt que de traduire littéralement, nous identifions des clusters de concepts — mobilité, durabilité, célébration — présents dans chaque langue. Lorsque les clusters convergent, les créatifs gagnent en liberté pour adapter le ton. Les divergences signalent des risques culturels qui nécessitent des recherches complémentaires.",
    "post4.section1.p2": "L'analyse de convergence repose sur des corpus issus de la presse régionale, des forums et des programmes culturels. Chaque occurrence est annotée avec son sentiment et son contexte. On observe par exemple que « transition » porte une charge politique en français mais reste technique en néerlandais. Connaître ces nuances évite les frictions involontaires.",
    "post4.section1.subheading": "Indices d'adjacence",
    "post4.section1.p3": "L'indice d'adjacence mesure la facilité de circulation d'un message entre langues. Il agrège chevauchement lexical, alignement de sentiment et héritages historiques. Un score trop bas déclenche une réécriture créative ou l'ajout de sous-titres et contenus compagnons.",
    "post4.section2.title": "Cycles de validation communautaire",
    "post4.section2.p1": "Nous renforçons les scores par des validations communautaires. Des cercles bilingues discutent scripts, storyboards et maquettes. Les facilitateurs notent où les références sont comprises et où des clarifications s'imposent. Ces échanges révèlent souvent des symboles régionaux à intégrer.",
    "post4.section2.p2": "Nous surveillons également les canaux sociaux transfrontaliers. Lorsque l'audience détourne une campagne avec humour local ou ajoute du contexte dans sa langue, nous enregistrons un signe positif d'adjacence. Le silence ou les corrections publiques indiquent un décalage à corriger pour les itérations suivantes.",
    "post4.section2.subheading": "Structures de reporting",
    "post4.section2.p3": "Les rapports finals rassemblent indices, notes qualitatives et garde-fous recommandés. Les décideurs reçoivent des synthèses bilingues pour garantir une lecture équitable. Cette structure accélère les validations et limite les contestations tardives émanant d'acteurs régionaux.",
    "post4.imageAlt": "Personnes discutant de références créatives bilingues.",
    "post5.title": "Protocoles de gouvernance des data rooms créatives",
    "post5.intro": "Les data rooms créatives hébergent scripts, rendus et bandes-son en constante évolution. Sans gouvernance, les preuves se fragmentent et la confiance se délite. Nous avons observé quinze organisations pilotant des campagnes multi-marchés et en avons extrait des protocoles pour fiabiliser ces espaces.",
    "post5.section1.title": "Définir des rôles de custodians",
    "post5.section1.p1": "Les data rooms performantes attribuent des rôles : un custodian du récit suit les évolutions narratives, un custodian des preuves valide les fichiers de recherche et un custodian de localisation vérifie l'exactitude bilingue. Chacun dispose de permissions et circuits d'escalade clairs.",
    "post5.section1.p2": "Cette clarté réduit les doublons. Quand le custodian de localisation dépose un script traduit, le custodian du récit est alerté pour contrôler la cohérence du ton. Les allers-retours restent fluides sans perdre en rigueur.",
    "post5.section1.subheading": "Discipline de version",
    "post5.section1.p3": "L'historique doit rester transparent. Nous recommandons des commits horodatés accompagnés d'un court rationnel rédigé dans les deux langues. Chacun peut retracer l'origine d'un changement, la référence mobilisée et l'approbateur. Cette transparence évite les litiges lors des revues réglementaires.",
    "post5.section2.title": "Cadencer les fenêtres d'accès",
    "post5.section2.p1": "Les fenêtres d'accès doivent évoluer avec les jalons. En idéation, un accès large favorise les contributions ; à mesure que la production s'approche, l'accès se resserre autour des responsables. Ce rythme maintient la collaboration tout en assurant la responsabilité.",
    "post5.section2.p2": "Nous conseillons aussi des fenêtres de réflexion après chaque jalon. Les équipes y notent les réussites, les actifs à réutiliser et les manques documentaires. Ces retours alimentent les projets suivants et entretiennent la mémoire collective.",
    "post5.section2.subheading": "Outils et rituels",
    "post5.section2.p3": "Les protocoles prospèrent avec des rituels simples : points hebdomadaires, synthèses bilingues, alertes sur les fichiers inactifs. Les outils doivent gérer le tagging, la recherche dans les deux langues et l'export de snapshots pour audit. Les data rooms deviennent ainsi des archives vivantes plutôt que des dossiers chaotiques.",
    "post5.imageAlt": "Équipe gérant un référentiel numérique sur plusieurs écrans.",
    "contact.hero.title": "Contacter Atelier Reclame",
    "contact.hero.intro": "Utilisez le formulaire ou les coordonnées ci-dessous pour initier une conversation autour de vos questions analytiques.",
    "contact.hero.imageAlt": "Espace de travail avec carnet et ordinateur prêt pour une correspondance.",
    "contact.info.title": "Coordonnées directes",
    "contact.info.subtitle": "Nous répondons sous deux jours ouvrés avec des références ou des questions de précision.",
    "contact.info.phoneLabel": "Téléphone : +32 472 63 58 20",
    "contact.info.emailLabel": "Courriel : contact@atelier-reclame.fr",
    "contact.info.addressLabel": "Adresse : 123 Rue de la République, 75001 Paris, France",
    "contact.info.hours": "Horaires : du lundi au vendredi, 09h00–18h00 CET.",
    "contact.form.title": "Envoyez-nous un message",
    "contact.form.name.label": "Nom complet",
    "contact.form.name.placeholder": "Saisissez votre nom",
    "contact.form.email.label": "Adresse courriel",
    "contact.form.email.placeholder": "Saisissez votre courriel",
    "contact.form.org.label": "Organisation",
    "contact.form.org.placeholder": "Indiquez votre organisation ou équipe",
    "contact.form.message.label": "Message",
    "contact.form.message.placeholder": "Décrivez votre contexte et vos questions",
    "contact.form.consent": "J'accepte d'être recontacté concernant cette demande et comprends que mes informations sont utilisées pour y répondre.",
    "contact.form.submit": "Envoyer",
    "contact.map.title": "Nous trouver à Paris",
    "contact.map.aria": "Carte interactive situant notre adresse parisienne.",
    "faq.hero.title": "Questions fréquentes",
    "faq.hero.intro": "Les réponses suivantes résument notre organisation de la recherche, des collaborations et de la gouvernance des données.",
    "faq.imageAlt": "Carnet ouvert avec annotations de recherche.",
    "faq.q1": "Êtes-vous une agence ou un laboratoire de recherche ?",
    "faq.a1": "Atelier Reclame fonctionne comme un collectif de recherche. Nous documentons les écosystèmes publicitaires, publions nos constats et animons des ateliers, sans acheter d'espace ni piloter les campagnes.",
    "faq.q2": "À quelle fréquence mettez-vous à jour vos cadres ?",
    "faq.a2": "Les cadres principaux sont revus chaque trimestre. Lors de changements marchés majeurs — nouvelles réglementations, formats disruptifs — nous émettons des notes intermédiaires pour garder les collaborateurs alignés.",
    "faq.q3": "Des équipes externes peuvent-elles contribuer des données ?",
    "faq.a3": "Oui, si les données sont accompagnées de la méthodologie de collecte et des consentements. Après un sprint de validation, nous intégrons les jeux compatibles avec nos protocoles de confidentialité.",
    "faq.q4": "Fournissez-vous chaque rapport en français et en anglais ?",
    "faq.a4": "Chaque publication intègre des synthèses bilingues. Les dossiers longs peuvent proposer des annexes supplémentaires lorsque des partenaires locaux co-produisent l'étude.",
    "faq.q5": "Que deviennent les entretiens qualitatifs après un projet ?",
    "faq.a5": "Les enregistrements sont archivés de manière chiffrée. Seuls les chercheurs affectés au projet y ont accès et les extraits publiés sont anonymisés.",
    "faq.q6": "Comment demander un atelier ?",
    "faq.a6": "Utilisez le formulaire de contact en précisant vos dates et objectifs. Nous répondrons avec nos disponibilités, formats suggérés et prérequis éventuels.",
    "terms.section1.title": "1. Champ et acceptation",
    "terms.section1.body": "Ces conditions régissent l'utilisation des sites, publications et référentiels d'Atelier Reclame. Accéder à nos ressources implique leur acceptation.",
    "terms.section2.title": "2. Définitions",
    "terms.section2.body": "« Ressources » désigne articles, jeux de données, gabarits et enregistrements. « Collaborateurs » désigne les personnes ou organisations qui contribuent avec notre accord.",
    "terms.section3.title": "3. Accès",
    "terms.section3.body": "Nous fournissons un accès informatif aux ressources. Il peut être retiré si l'usage menace la confidentialité, l'intégrité des données ou nos obligations réglementaires.",
    "terms.section4.title": "4. Propriété intellectuelle",
    "terms.section4.body": "Sauf mention contraire, Atelier Reclame conserve les droits de propriété intellectuelle sur les ressources. Les collaborateurs restent propriétaires de leurs apports originaux.",
    "terms.section5.title": "5. Utilisation des ressources",
    "terms.section5.body": "Les ressources peuvent être utilisées pour des analyses internes ou académiques. Toute republication publique exige notre autorisation écrite.",
    "terms.section6.title": "6. Contributions de recherche",
    "terms.section6.body": "Les contributeurs garantissent que leurs données sont exactes, licites et assorties des consentements requis. Nous pouvons refuser des matériaux sans provenance claire.",
    "terms.section7.title": "7. Conduite communautaire",
    "terms.section7.body": "Nous attendons un dialogue respectueux sur l'ensemble des canaux. Harcèlement, discrimination ou usage abusif des preuves entraînent une suspension immédiate.",
    "terms.section8.title": "8. Liens externes",
    "terms.section8.body": "Les liens fournis pour contexte ne constituent pas une approbation. Nous ne contrôlons pas ces contenus et déclinons toute responsabilité à leur égard.",
    "terms.section9.title": "9. Exactitude des données",
    "terms.section9.body": "Nous visons la justesse des informations sans garantie d'exhaustivité. Les utilisateurs vérifient les constats avant toute décision critique.",
    "terms.section10.title": "10. Absence de garantie",
    "terms.section10.body": "Les ressources sont fournies « telles quelles ». Les insights reflètent des observations datées susceptibles d'évoluer.",
    "terms.section11.title": "11. Limitation de responsabilité",
    "terms.section11.body": "Atelier Reclame n'est pas responsable des dommages directs ou indirects liés à l'utilisation ou l'impossibilité d'utiliser nos ressources.",
    "terms.section12.title": "12. Mise à jour des conditions",
    "terms.section12.body": "Nous pouvons modifier ces conditions pour refléter des évolutions organisationnelles ou réglementaires. Les mises à jour s'appliquent dès leur publication.",
    "terms.section13.title": "13. Droit applicable",
    "terms.section13.body": "Les présentes conditions sont régies par le droit français. Les litiges relèvent des juridictions compétentes de Paris.",
    "terms.section14.title": "14. Contact",
    "terms.section14.body": "Toute question sur ces conditions peut être envoyée à contact@atelier-reclame.fr.",
    "privacy.section1.title": "1. Introduction",
    "privacy.section1.body": "Cette notice explique comment Atelier Reclame collecte, utilise et protège les données personnelles lors de vos interactions avec notre site, nos publications ou nos programmes de recherche.",
    "privacy.section2.title": "2. Données collectées",
    "privacy.section2.body": "Nous collectons les coordonnées saisies dans les formulaires, les échanges de correspondance, les notes de participation et, si autorisé, des mesures techniques comme l'analytics.",
    "privacy.section3.title": "3. Finalités du traitement",
    "privacy.section3.body": "Les données servent à la communication, la coordination de projets, l'analyse de recherche, la surveillance de sécurité et le respect de nos obligations légales.",
    "privacy.section4.title": "4. Bases légales",
    "privacy.section4.body": "Les traitements reposent sur le consentement, l'intérêt légitime à fournir nos travaux ou la nécessité contractuelle lorsqu'un accord nous lie.",
    "privacy.section5.title": "5. Stockage et sécurité",
    "privacy.section5.body": "Les données sont hébergées sur des serveurs sécurisés dans l'Union européenne avec chiffrement, contrôles d'accès et audits réguliers.",
    "privacy.section6.title": "6. Partage des données",
    "privacy.section6.body": "Nous partageons certaines données avec des sous-traitants de confiance pour l'hébergement, la communication ou l'appui recherche. Ils respectent des obligations de confidentialité.",
    "privacy.section7.title": "7. Transferts hors UE",
    "privacy.section7.body": "Si des données quittent l'UE, nous appliquons des clauses contractuelles types et veillons à un niveau de protection équivalent.",
    "privacy.section8.title": "8. Vos droits",
    "privacy.section8.body": "Vous pouvez demander l'accès, la rectification, l'effacement, la limitation ou la portabilité de vos données. Vous pouvez aussi vous opposer à certains traitements et retirer votre consentement.",
    "privacy.section9.title": "9. Durées de conservation",
    "privacy.section9.body": "Nous conservons les données aussi longtemps que nécessaire à nos objectifs, obligations légales ou valeur d'archive. Les données non essentielles sont supprimées périodiquement.",
    "privacy.section10.title": "10. Contact",
    "privacy.section10.body": "Pour toute question liée à la confidentialité, écrivez à contact@atelier-reclame.fr ou à 123 Rue de la République, 75001 Paris, France.",
    "cookies.hero.title": "Politique de cookies",
    "cookies.hero.intro": "Cette politique décrit l'usage des cookies et technologies similaires qui soutiennent l'expérience Atelier Reclame.",
    "cookies.usage.title": "Usage des cookies",
    "cookies.usage.body": "Nous utilisons les cookies pour sécuriser les sessions, mémoriser la langue, analyser l'audience agrégée et proposer des contenus pertinents.",
    "cookies.table.title": "Registre des cookies",
    "cookies.table.description": "Le tableau recense les cookies actuellement déposés sur ce site.",
    "cookies.table.headingName": "Nom",
    "cookies.table.headingProvider": "Fournisseur",
    "cookies.table.headingType": "Type",
    "cookies.table.headingPurpose": "Finalité",
    "cookies.table.headingDuration": "Durée",
    "cookies.table.row1.name": "session_id",
    "cookies.table.row1.provider": "Atelier Reclame",
    "cookies.table.row1.type": "Nécessaire",
    "cookies.table.row1.purpose": "Maintient un accès sécurisé entre les pages durant la session.",
    "cookies.table.row1.duration": "Session",
    "cookies.table.row2.name": "site_lang",
    "cookies.table.row2.provider": "Atelier Reclame",
    "cookies.table.row2.type": "Préférences",
    "cookies.table.row2.purpose": "Mémorise la langue choisie pour les visites futures.",
    "cookies.table.row2.duration": "12 mois",
    "cookies.table.row3.name": "analytics_insight",
    "cookies.table.row3.provider": "Atelier Reclame",
    "cookies.table.row3.type": "Analytics",
    "cookies.table.row3.purpose": "Mesure la performance agrégée des pages et les parcours de navigation.",
    "cookies.table.row3.duration": "6 mois",
    "cookies.table.row4.name": "campaign_context",
    "cookies.table.row4.provider": "Atelier Reclame",
    "cookies.table.row4.type": "Marketing",
    "cookies.table.row4.purpose": "Collecte un contexte anonymisé pour adapter nos mises à jour de recherche.",
    "cookies.table.row4.duration": "6 mois",
    "cookies.preferences.title": "Gérer les cookies",
    "cookies.preferences.body": "Vous pouvez ajuster les catégories via la bannière à tout moment. Refuser les cookies non essentiels peut réduire la personnalisation sans affecter la navigation principale.",
    "refund.section1.title": "1. Objet",
    "refund.section1.body": "La présente politique explique la gestion des demandes de remboursement liées à nos ressources, ateliers et événements.",
    "refund.section2.title": "2. Éligibilité",
    "refund.section2.body": "Les remboursements concernent les inscriptions aux ateliers ou accès prolongés aux ressources lorsque l'option est annoncée comme remboursable.",
    "refund.section3.title": "3. Délai de notification",
    "refund.section3.body": "Les demandes doivent parvenir dans les dix jours ouvrés suivant l'achat ou cinq jours ouvrés avant la session, selon la première échéance.",
    "refund.section4.title": "4. Dossier justificatif",
    "refund.section4.body": "Merci de fournir justificatif d'achat, coordonnées et description des circonstances motivant la demande.",
    "refund.section5.title": "5. Processus d'examen",
    "refund.section5.body": "Nous vérifions l'éligibilité, les traces de participation et l'utilisation des ressources avant décision.",
    "refund.section6.title": "6. Résultats possibles",
    "refund.section6.body": "Les demandes validées peuvent donner lieu à un avoir, un remboursement partiel ou un accès alternatif selon le contexte.",
    "refund.section7.title": "7. Cas non remboursables",
    "refund.section7.body": "Les recherches sur mesure, jeux de données personnalisés et sessions déjà réalisées ne sont pas remboursables.",
    "refund.section8.title": "8. Ajustements de planning",
    "refund.section8.body": "En cas de report par nos soins, vous pouvez accepter la nouvelle date ou demander un remboursement sous cinq jours ouvrés.",
    "refund.section9.title": "9. Canal de contact",
    "refund.section9.body": "Adressez votre demande à contact@atelier-reclame.fr avec l'objet « Demande de remboursement ».",
    "refund.section10.title": "10. Mise à jour de la politique",
    "refund.section10.body": "Nous pouvons ajuster cette politique pour refléter de nouvelles offres ou obligations. Les modifications s'appliquent dès publication.",
    "disclaimer.section1.title": "Finalité du contenu",
    "disclaimer.section1.body": "Atelier Reclame publie des observations analytiques à visée informative. Elles ne constituent pas un conseil financier, juridique ou professionnel.",
    "disclaimer.section2.title": "Absence de garantie",
    "disclaimer.section2.body": "Nous ne garantissons pas la reproduction des résultats évoqués dans d'autres contextes.",
    "disclaimer.section3.title": "Vérification indépendante",
    "disclaimer.section3.body": "Les lecteurs doivent vérifier les données et réaliser leur propre évaluation avant toute décision stratégique.",
    "disclaimer.section4.title": "Sources tierces",
    "disclaimer.section4.body": "Les références à des contenus externes n'impliquent pas d'approbation. Nous ne répondons pas de leur exactitude.",
    "disclaimer.section5.title": "Limitation de responsabilité",
    "disclaimer.section5.body": "Atelier Reclame décline toute responsabilité pour les pertes ou dommages résultant de l'usage de nos publications ou outils.",
    "disclaimer.section6.title": "Contact",
    "disclaimer.section6.body": "Pour toute précision liée à cet avertissement, écrivez à contact@atelier-reclame.fr.",
    "thankyou.title": "Merci pour votre message",
    "thankyou.message": "Nous avons bien reçu votre note et répondrons sous deux jours ouvrés. Une confirmation vous a été envoyée.",
    "thankyou.back": "Retour à l'accueil",
    "thankyou.contact": "Envoyer un nouveau message",
    "404.title": "Page introuvable",
    "404.message": "La page demandée n'existe plus ou a été déplacée. Utilisez les options ci-dessous pour poursuivre votre exploration d'Atelier Reclame.",
    "404.home": "Revenir à l'accueil",
    "404.contact": "Contacter notre équipe",
    "cookies.banner.title": "Nous respectons votre vie privée",
    "cookies.banner.message": "Les cookies nous aident à comprendre l'usage du site et à conserver vos préférences linguistiques. Ajustez les catégories ou acceptez l'ensemble.",
    "cookies.banner.accept": "Tout accepter",
    "cookies.banner.decline": "Tout refuser",
    "cookies.banner.save": "Enregistrer",
    "cookies.banner.manage": "Gérer les préférences",
    "cookies.banner.close": "Fermer",
    "cookies.banner.preferencesTitle": "Catégories de cookies",
    "cookies.banner.necessary": "Nécessaires",
    "cookies.banner.necessary.desc": "Assurent la sécurité et la navigation de base. Désactivation impossible.",
    "cookies.banner.preferences": "Préférences",
    "cookies.banner.preferences.desc": "Retiennent les paramètres de langue et d'accessibilité.",
    "cookies.banner.analytics": "Analytics",
    "cookies.banner.analytics.desc": "Mesurent l'audience agrégée pour améliorer la pertinence.",
    "cookies.banner.marketing": "Marketing",
    "cookies.banner.marketing.desc": "Soutiennent des actualités contextuelles sur nos recherches.",
    "cookies.banner.respect": "Vos choix sont respectés et conservés pour vos prochaines visites.",
    "toast.form.success": "Message prêt à partir. Redirection vers la confirmation...",
    "toast.form.error": "Merci de compléter les champs obligatoires avant l'envoi.",
    "toast.cookie.saved": "Vos préférences de cookies ont été enregistrées."
  }
};

const DEFAULT_LANG = "en";

document.addEventListener("DOMContentLoaded", () => {
  const savedLang = localStorage.getItem("site_lang") || DEFAULT_LANG;
  applyTranslations(savedLang);
  setupLanguageSwitch(savedLang);
  setupNavToggle();
  setupScrollAnimations();
  setupForms();
  setupCookieBanner();
});

function getTranslation(lang, key) {
  const langPack = I18N[lang] || I18N[DEFAULT_LANG];
  const fallbackPack = I18N[DEFAULT_LANG];
  const value = langPack[key] ?? fallbackPack[key] ?? "";
  return applyTokens(value);
}

function applyTokens(value) {
  return value.replace(/\{\{(.*?)\}\}/g, (match, token) => {
    const cleaned = token.trim();
    return Object.prototype.hasOwnProperty.call(TOKENS, cleaned) ? TOKENS[cleaned] : match;
  });
}

function applyTranslations(lang) {
  const root = document.documentElement;
  root.setAttribute("lang", lang);
  root.setAttribute("data-lang", lang);

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const value = getTranslation(lang, key);
    setElementText(el, value);
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const value = getTranslation(lang, key);
    el.setAttribute("placeholder", value);
  });

  document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria");
    const value = getTranslation(lang, key);
    el.setAttribute("aria-label", value);
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const value = getTranslation(lang, key);
    el.setAttribute("alt", value);
  });

  document.querySelectorAll("[data-i18n-title-attr]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title-attr");
    const value = getTranslation(lang, key);
    el.setAttribute("title", value);
  });

  const titleKey = document.querySelector("[data-i18n-title]");
  if (titleKey) {
    const key = titleKey.getAttribute("data-i18n-title");
    document.title = getTranslation(lang, key);
  }

  document.querySelectorAll("[data-i18n-meta]").forEach((meta) => {
    const key = meta.getAttribute("data-i18n-meta");
    const value = getTranslation(lang, key);
    meta.setAttribute("content", value);
  });

  updateLangButtons(lang);
}

function setElementText(element, value) {
  if (value.includes("<") && value.includes(">")) {
    element.innerHTML = value;
  } else {
    element.textContent = value;
  }
}

function setupLanguageSwitch(initialLang) {
  const buttons = document.querySelectorAll(".lang-button");
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.getAttribute("data-lang");
      if (lang) {
        localStorage.setItem("site_lang", lang);
        TOKENS.year = new Date().getFullYear();
        applyTranslations(lang);
        showToast("toast.cookie.saved", "success", true);
      }
    });
  });
  updateLangButtons(initialLang);
}

function updateLangButtons(activeLang) {
  document.querySelectorAll(".lang-button").forEach((btn) => {
    const lang = btn.getAttribute("data-lang");
    if (lang === activeLang) {
      btn.classList.add("is-active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("is-active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
}

function setupNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("[data-nav]");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", (!expanded).toString());
    nav.classList.toggle("is-open");
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      if (window.innerWidth <= 768) {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  });
}

function setupScrollAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.1 }
  );

  document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
}

function setupForms() {
  const forms = document.querySelectorAll("form[data-enhanced='true']");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!form.checkValidity()) {
        event.preventDefault();
        showToast("toast.form.error", "error");
        return;
      }
      event.preventDefault();
      showToast("toast.form.success", "success");
      setTimeout(() => {
        form.submit();
      }, 800);
    });
  });
}

function showToast(key, type = "info", silent = false) {
  const container = document.querySelector(".toast-stack");
  if (!container) return;
  const lang = document.documentElement.getAttribute("data-lang") || DEFAULT_LANG;
  const message = getTranslation(lang, key);
  if (!message) return;
  if (silent) {
    return;
  }
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("show"));
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 350);
  }, 3400);
}

function setupCookieBanner() {
  const banner = document.querySelector("[data-cookie-banner]");
  const manageButtons = document.querySelectorAll("[data-action='open-cookie-settings']");
  if (!banner) return;

  const toggles = banner.querySelectorAll("[data-cookie-toggle]");
  const closeBtn = banner.querySelector("[data-action='close-banner']");
  const acceptBtn = banner.querySelector("[data-action='accept-all']");
  const declineBtn = banner.querySelector("[data-action='decline-all']");
  const saveBtn = banner.querySelector("[data-action='save-preferences']");
  const manageBtn = banner.querySelector("[data-action='open-preferences']");

  let consent = readConsent();

  function applyState(state) {
    toggles.forEach((toggle) => {
      const key = toggle.getAttribute("data-cookie-toggle");
      if (!key) return;
      toggle.checked = !!state[key];
    });
  }

  function saveConsent(state) {
    localStorage.setItem("cookie_consent", JSON.stringify(state));
  }

  function readConsent() {
    try {
      const stored = localStorage.getItem("cookie_consent");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.warn("Unable to parse cookie consent", error);
    }
    return {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false
    };
  }

  if (consent.preferences || consent.analytics || consent.marketing || consent.necessary) {
    banner.classList.remove("is-visible");
    banner.setAttribute("aria-hidden", "true");
  } else {
    banner.classList.add("is-visible");
    banner.setAttribute("aria-hidden", "false");
  }

  applyState(consent);

  toggles.forEach((toggle) => {
    toggle.addEventListener("change", () => {
      const key = toggle.getAttribute("data-cookie-toggle");
      if (!key) return;
      consent[key] = toggle.checked;
    });
  });

  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      banner.classList.remove("show-preferences");
      banner.classList.remove("is-visible");
      banner.setAttribute("aria-hidden", "true");
    });
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      consent = {
        necessary: true,
        preferences: true,
        analytics: true,
        marketing: true
      };
      applyState(consent);
      saveConsent(consent);
      banner.classList.remove("show-preferences");
      banner.classList.remove("is-visible");
      banner.setAttribute("aria-hidden", "true");
      showToast("toast.cookie.saved", "success");
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      consent = {
        necessary: true,
        preferences: false,
        analytics: false,
        marketing: false
      };
      applyState(consent);
      saveConsent(consent);
      banner.classList.remove("show-preferences");
      banner.classList.remove("is-visible");
      banner.setAttribute("aria-hidden", "true");
      showToast("toast.cookie.saved", "success");
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      consent.necessary = true;
      applyState(consent);
      saveConsent(consent);
      banner.classList.remove("show-preferences");
      banner.classList.remove("is-visible");
      banner.setAttribute("aria-hidden", "true");
      showToast("toast.cookie.saved", "success");
    });
  }

  if (manageBtn) {
    manageBtn.addEventListener("click", () => {
      banner.classList.toggle("show-preferences");
    });
  }

  manageButtons.forEach((button) => {
    button.addEventListener("click", () => {
      banner.classList.add("is-visible");
      banner.classList.add("show-preferences");
      banner.setAttribute("aria-hidden", "false");
    });
  });
}