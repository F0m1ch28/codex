document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.getElementById("primaryNav");
    const scrollButton = document.getElementById("scrollTopButton");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");
    const declineCookiesBtn = document.getElementById("declineCookies");
    const contactForm = document.getElementById("contactForm");
    const currentYear = document.getElementById("currentYear");

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            nav.classList.toggle("open");
        });

        nav.querySelectorAll("a[data-scroll-top]").forEach((link) => {
            link.addEventListener("click", () => {
                nav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    if (scrollButton) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 300) {
                scrollButton.style.display = "flex";
            } else {
                scrollButton.style.display = "none";
            }
        });

        scrollButton.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    const cookieConsentKey = "limonaridaCookieConsent";

    const showCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.style.display = "block";
        }
    };

    const hideCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.style.display = "none";
        }
    };

    const storedConsent = localStorage.getItem(cookieConsentKey);
    if (!storedConsent) {
        showCookieBanner();
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener("click", () => {
            localStorage.setItem(cookieConsentKey, "accepted");
            hideCookieBanner();
        });
    }

    if (declineCookiesBtn) {
        declineCookiesBtn.addEventListener("click", () => {
            localStorage.setItem(cookieConsentKey, "declined");
            hideCookieBanner();
        });
    }

    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const feedback = contactForm.querySelector(".form-feedback");
            if (feedback) {
                feedback.textContent = "Vielen Dank! Ihre Nachricht wurde erfolgreich übermittelt.";
            }
            contactForm.reset();
        });
    }
});