document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    const scrollTopBtn = document.getElementById('scrollTop');
    const contactForm = document.getElementById('contact-form');
    const formStatus = document.getElementById('form-status');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAcceptBtn = document.getElementById('acceptCookies');
    const COOKIE_KEY = 'ordavisionCookieAccepted';

    // Mobile navigation toggle
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            primaryNav.classList.toggle('open');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                primaryNav.classList.remove('open');
            });
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', event => {
            const targetId = anchor.getAttribute('href');
            if (targetId.length > 1) {
                const target = document.querySelector(targetId);
                if (target) {
                    event.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });

    // Scroll to top button
    window.addEventListener('scroll', () => {
        if (window.scrollY > 280) {
            scrollTopBtn.style.display = 'flex';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    });

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Contact form submission
    if (contactForm && formStatus) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const requiredFields = ['name', 'email', 'message'];
            const missing = requiredFields.filter(field => !formData.get(field));

            if (missing.length) {
                formStatus.textContent = 'Қажетті өрістерді толтырыңыз.';
                formStatus.style.color = '#c0392b';
                return;
            }

            formStatus.textContent = 'Хабарламаңыз қабылданды. Біз жақын арада байланысамыз.';
            formStatus.style.color = '#18a999';
            contactForm.reset();
        });
    }

    // Cookie banner
    if (cookieBanner && cookieAcceptBtn) {
        const accepted = localStorage.getItem(COOKIE_KEY);
        if (!accepted) {
            cookieBanner.style.display = 'block';
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'true');
            cookieBanner.style.display = 'none';
        });
    }
});