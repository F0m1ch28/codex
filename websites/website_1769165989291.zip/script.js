document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
      navMenu.classList.toggle('is-open');
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('[data-year]').forEach(el => {
    el.textContent = new Date().getFullYear();
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  document.querySelectorAll('[data-animate]').forEach(el => {
    el.classList.add('animate-on-scroll');
    observer.observe(el);
  });

  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const storedChoice = localStorage.getItem('mkCookieChoice');
    if (!storedChoice) {
      cookieBanner.classList.add('is-active');
    } else {
      cookieBanner.remove();
    }
    cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(button => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-cookie-choice');
        localStorage.setItem('mkCookieChoice', choice);
        cookieBanner.classList.remove('is-active');
        setTimeout(() => {
          if (cookieBanner && cookieBanner.parentElement) {
            cookieBanner.parentElement.removeChild(cookieBanner);
          }
        }, 320);
      });
    });
  }

  const toast = document.getElementById('globalToast');

  const forms = document.querySelectorAll('form[data-behavior="contact-form"]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (toast) {
        toast.textContent = 'Message recorded. Redirecting shortly.';
        toast.classList.add('is-visible');
        setTimeout(() => toast.classList.remove('is-visible'), 1800);
      }
      setTimeout(() => {
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 1200);
    });
  });
});