document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const scrollBtn = document.querySelector('.scroll-top');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');
    const currentYearEl = document.getElementById('current-year');
    const contactForm = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('open');
        });
    }

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollBtn?.classList.add('visible');
        } else {
            scrollBtn?.classList.remove('visible');
        }
    });

    scrollBtn?.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    if (cookieBanner && cookieAccept) {
        const consent = localStorage.getItem('cap_cookie_consent');
        if (!consent) {
            cookieBanner.classList.remove('hidden');
            cookieBanner.setAttribute('aria-hidden', 'false');
        } else {
            cookieBanner.classList.add('hidden');
            cookieBanner.setAttribute('aria-hidden', 'true');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem('cap_cookie_consent', 'accepted');
            cookieBanner.classList.add('hidden');
            cookieBanner.setAttribute('aria-hidden', 'true');
        });
    }

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            formMessage.textContent = 'Thank you for reaching out. Our advisory team will respond within two business days.';
            contactForm.reset();
        });
    }

    window.onbeforeunload = () => {
        window.scrollTo(0, 0);
    };
});