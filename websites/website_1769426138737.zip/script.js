document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  const body = document.body;

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navToggle.classList.toggle('is-open');
      primaryNav.classList.toggle('is-open');
      body.classList.toggle('nav-open');
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (primaryNav.classList.contains('is-open')) {
          primaryNav.classList.remove('is-open');
          navToggle.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
          body.classList.remove('nav-open');
        }
      });
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        primaryNav.classList.remove('is-open');
        navToggle.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
        body.classList.remove('nav-open');
      }
    });
  }

  const observerTargets = document.querySelectorAll('.observe-item');
  if (observerTargets.length > 0) {
    const io = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    observerTargets.forEach(item => io.observe(item));
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptButton = document.querySelector('[data-cookie-accept]');
  const declineButton = document.querySelector('[data-cookie-decline]');
  const storedPreference = localStorage.getItem('anfaCookieChoice');

  if (cookieBanner) {
    if (storedPreference) {
      cookieBanner.classList.add('hidden');
    } else {
      cookieBanner.classList.remove('hidden');
    }
  }

  const handleCookieChoice = choice => {
    localStorage.setItem('anfaCookieChoice', choice);
    if (cookieBanner) {
      cookieBanner.classList.add('hidden');
    }
  };

  if (acceptButton) {
    acceptButton.addEventListener('click', () => handleCookieChoice('accepted'));
  }

  if (declineButton) {
    declineButton.addEventListener('click', () => handleCookieChoice('declined'));
  }

  const toast = document.getElementById('global-toast');
  const forms = document.querySelectorAll('form[data-form]');
  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 1600);
  };

  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      showToast('Message received. Redirecting…');
      const actionTarget = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = actionTarget;
      }, 1200);
    });
  });

  const faqButtons = document.querySelectorAll('[data-faq-toggle]');
  faqButtons.forEach(button => {
    button.addEventListener('click', () => {
      const parentItem = button.closest('.faq-item');
      if (!parentItem) return;
      const expanded = parentItem.classList.toggle('active');
      button.setAttribute('aria-expanded', String(expanded));
    });
  });
});