document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navigation = document.getElementById('primary-navigation');
  const scrollTopBtn = document.getElementById('scrollTopBtn');
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookiesBtn = document.getElementById('acceptCookies');
  const form = document.getElementById('contact-form');
  const formMessage = document.getElementById('form-message');
  const currentYearEl = document.getElementById('current-year');

  // Set current year
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  // Mobile navigation toggle
  if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
      navToggle.setAttribute('aria-expanded', !expanded);
      navigation.classList.toggle('open');
    });

    navigation.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navigation.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Scroll to top button
  const toggleScrollTopButton = () => {
    if (!scrollTopBtn) return;
    if (window.scrollY > 300) {
      scrollTopBtn.style.display = 'flex';
      scrollTopBtn.style.opacity = '1';
    } else {
      scrollTopBtn.style.opacity = '0';
      scrollTopBtn.style.display = 'none';
    }
  };

  if (scrollTopBtn) {
    window.addEventListener('scroll', toggleScrollTopButton);
    scrollTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Cookie banner logic
  if (cookieBanner && acceptCookiesBtn) {
    const consentKey = 'avintraCookieConsent';
    const hasConsent = localStorage.getItem(consentKey);

    if (!hasConsent) {
      cookieBanner.style.display = 'block';
    }

    acceptCookiesBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.style.display = 'none';
    });
  }

  // Contact form handling
  if (form && formMessage) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const formData = new FormData(form);
      const name = formData.get('name');
      const email = formData.get('email');
      const subject = formData.get('subject');
      const message = formData.get('message');

      if (!name || !email || !subject || !message) {
        formMessage.textContent = 'Bitte fülle alle Felder aus.';
        formMessage.style.color = '#d64545';
        return;
      }

      formMessage.textContent = 'Vielen Dank! Wir melden uns zeitnah bei dir.';
      formMessage.style.color = '#2c5d90';
      form.reset();
    });
  }

  // Ensure scroll position reset when navigating away
  window.addEventListener('beforeunload', () => {
    window.scrollTo(0, 0);
  });
});