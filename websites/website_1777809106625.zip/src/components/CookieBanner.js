import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CONSENT_KEY = 'gr-cookie-consent';

const defaultPreferences = {
  necessary: true,
  analytics: false,
  marketing: false
};

const CookieBanner = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [preferences, setPreferences] = useState(defaultPreferences);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (!stored) {
      setIsOpen(true);
    } else {
      setPreferences(JSON.parse(stored));
    }
  }, []);

  const savePreferences = (updated) => {
    setPreferences(updated);
    localStorage.setItem(CONSENT_KEY, JSON.stringify(updated));
    setIsOpen(false);
    setShowSettings(false);
  };

  if (!isOpen) {
    return null;
  }

  const handleToggle = (key) => {
    if (key === 'necessary') return;
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className={styles.banner} role="dialog" aria-modal="true" aria-label="Настройки файлов cookie">
      <div className={styles.content}>
        <h4>Мы используем файлы cookie</h4>
        <p>
          GamblingReviews применяет файлы cookie, чтобы улучшить работу сайта, понимать интересы читателей и бережно обращаться с контентом.
          Необязательные cookie можно отключить.
        </p>
        {showSettings && (
          <div className={styles.settings}>
            <label className={styles.option}>
              <input type="checkbox" checked readOnly aria-checked="true" />
              <span>Необходимые cookie (всегда активны)</span>
            </label>
            <label className={styles.option}>
              <input
                type="checkbox"
                checked={preferences.analytics}
                onChange={() => handleToggle('analytics')}
                aria-label="Включить аналитические cookie"
              />
              <span>Аналитика (анонимная статистика использования)</span>
            </label>
            <label className={styles.option}>
              <input
                type="checkbox"
                checked={preferences.marketing}
                onChange={() => handleToggle('marketing')}
                aria-label="Включить маркетинговые cookie"
              />
              <span>Маркетинг (персонализация и рекомендации)</span>
            </label>
          </div>
        )}
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.primary}
            onClick={() =>
              savePreferences({ necessary: true, analytics: true, marketing: true })
            }
          >
            Принять все
          </button>
          <button
            type="button"
            className={styles.secondary}
            onClick={() => savePreferences({ necessary: true, analytics: false, marketing: false })}
          >
            Отклонить необязательные
          </button>
          <button
            type="button"
            className={styles.ghost}
            onClick={() => setShowSettings((prev) => !prev)}
          >
            {showSettings ? 'Свернуть' : 'Настроить'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;