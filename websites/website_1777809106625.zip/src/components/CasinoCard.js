import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CasinoCard.module.css';

const CasinoCard = ({ casino }) => (
  <article className={styles.card}>
    <div className={styles.header}>
      <h3>{casino.name}</h3>
      <span className={styles.rating} aria-label={`Рейтинг ${casino.rating}`}>
        ★ {casino.rating.toFixed(1)}
      </span>
    </div>
    <p className={styles.bonus}>{casino.bonus}</p>
    <ul className={styles.meta}>
      <li><strong>Вейджер:</strong> {casino.wager}</li>
      <li><strong>Мин. депозит:</strong> {casino.minDeposit}</li>
      <li><strong>Игры:</strong> {casino.gamesCount}</li>
    </ul>
    <div className={styles.actions}>
      <Link to={`/casino-reviews/${casino.slug}`} className={styles.link} aria-label={`Подробнее о ${casino.name}`}>
        Подробнее
      </Link>
    </div>
  </article>
);

export default CasinoCard;