import React from 'react';
import styles from './ReviewCard.module.css';

const ReviewCard = ({ review }) => (
  <article className={styles.card}>
    <div className={styles.header}>
      <div>
        <h4>{review.name}</h4>
        <span>{review.city}</span>
      </div>
      <span className={styles.rating}>★ {review.rating.toFixed(1)}</span>
    </div>
    <p className={styles.text}>"{review.text}"</p>
    <span className={styles.date}>{review.date}</span>
  </article>
);

export default ReviewCard;