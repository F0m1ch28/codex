import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <h3>GamblingReviews</h3>
        <p>
          Независимая аналитика, честные обзоры и инструменты сравнения для тех,
          кто хочет понимать реальные условия казино.
        </p>
        <div className={styles.socials}>
          <span aria-label="Наш Telegram">TG</span>
          <span aria-label="Наш YouTube">YT</span>
          <span aria-label="Наш LinkedIn">IN</span>
        </div>
      </div>
      <div className={styles.links}>
        <h4>Навигация</h4>
        <NavLink to="/casino-reviews">Обзоры казино</NavLink>
        <NavLink to="/casino-comparison">Сравнение казино</NavLink>
        <NavLink to="/services">Сервисы</NavLink>
        <NavLink to="/about">О нас</NavLink>
        <NavLink to="/contact">Контакты</NavLink>
      </div>
      <div className={styles.legal}>
        <h4>Документы</h4>
        <NavLink to="/terms">Условия использования</NavLink>
        <NavLink to="/privacy">Политика конфиденциальности</NavLink>
        <NavLink to="/cookie-policy">Политика Cookie</NavLink>
        <p className={styles.disclaimer}>
          Мы не организуем азартные игры и не предлагаем гарантированный выигрыш. Контент носит информационный характер.
        </p>
      </div>
      <div className={styles.contacts}>
        <h4>Контакты</h4>
        <p>Адрес: 123 Gambling Street, City, Country</p>
        <p>Телефон: <a href="tel:+15551234567">+1 (555) 123-4567</a></p>
        <p>Email: <a href="mailto:info@gamblingreviews.com">info@gamblingreviews.com</a></p>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} GamblingReviews. Все права защищены.</span>
    </div>
  </footer>
);

export default Footer;