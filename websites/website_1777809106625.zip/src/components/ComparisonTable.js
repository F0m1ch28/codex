import React, { useState } from 'react';
import styles from './ComparisonTable.module.css';

const ComparisonTable = ({ casinos }) => {
  const initialSelection = casinos.slice(0, 3).map((casino) => casino.slug);
  const [selected, setSelected] = useState(initialSelection);

  const handleSelect = (columnIndex, newSlug) => {
    setSelected((prev) => {
      const updated = [...prev];
      updated[columnIndex] = newSlug;
      return updated;
    });
  };

  const selectedCasinos = selected
    .map((slug) => casinos.find((casino) => casino.slug === slug))
    .filter(Boolean);

  return (
    <div className={styles.wrapper}>
      <div className={styles.selectRow}>
        {selectedCasinos.map((casino, index) => (
          <label key={casino.id} className={styles.selector}>
            <span>Слот {index + 1}</span>
            <select
              value={selected[index]}
              onChange={(event) => handleSelect(index, event.target.value)}
              aria-label={`Выбор казино для столбца ${index + 1}`}
            >
              {casinos.map((option) => (
                <option key={option.id} value={option.slug}>
                  {option.name}
                </option>
              ))}
            </select>
          </label>
        ))}
      </div>
      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Параметр</th>
              {selectedCasinos.map((casino) => (
                <th key={casino.id}>{casino.name}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Приветственный бонус</td>
              {selectedCasinos.map((casino) => (
                <td key={`${casino.id}-bonus`}>{casino.bonus}</td>
              ))}
            </tr>
            <tr>
              <td>Вейджер</td>
              {selectedCasinos.map((casino) => (
                <td key={`${casino.id}-wager`}>{casino.wager}</td>
              ))}
            </tr>
            <tr>
              <td>Мин. депозит</td>
              {selectedCasinos.map((casino) => (
                <td key={`${casino.id}-deposit`}>{casino.minDeposit}</td>
              ))}
            </tr>
            <tr>
              <td>Количество игр</td>
              {selectedCasinos.map((casino) => (
                <td key={`${casino.id}-games`}>{casino.gamesCount}</td>
              ))}
            </tr>
            <tr>
              <td>Скорость вывода</td>
              {selectedCasinos.map((casino) => (
                <td key={`${casino.id}-withdrawal`}>{casino.withdrawalTime}</td>
              ))}
            </tr>
            <tr>
              <td>Рейтинг GamblingReviews</td>
              {selectedCasinos.map((casino) => (
                <td key={`${casino.id}-rating`}>★ {casino.rating.toFixed(1)}</td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ComparisonTable;