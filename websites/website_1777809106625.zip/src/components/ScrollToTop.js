import React, { useState, useEffect } from 'react';
import styles from './ScrollToTop.module.css';

const ScrollToTopButton = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShow(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!show) {
    return null;
  }

  return (
    <button
      className={styles.button}
      onClick={handleClick}
      aria-label="Прокрутить вверх"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;