import React, { useState } from 'react';
import styles from './FaqAccordion.module.css';

const FaqAccordion = ({ items }) => {
  const [activeId, setActiveId] = useState(null);

  const toggle = (id) => {
    setActiveId((prev) => (prev === id ? null : id));
  };

  return (
    <div className={styles.accordion}>
      {items.map((item) => {
        const isOpen = activeId === item.id;
        return (
          <div key={item.id} className={`${styles.item} ${isOpen ? styles.open : ''}`}>
            <button
              className={styles.control}
              onClick={() => toggle(item.id)}
              aria-expanded={isOpen}
              aria-controls={`faq-${item.id}`}
            >
              <span>{item.question}</span>
              <span className={styles.icon}>{isOpen ? '−' : '+'}</span>
            </button>
            <div
              id={`faq-${item.id}`}
              className={styles.body}
              role="region"
              aria-hidden={!isOpen}
            >
              <p>{item.answer}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default FaqAccordion;