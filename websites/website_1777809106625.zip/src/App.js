import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import CasinoReviews from './pages/CasinoReviews';
import CasinoDetail from './pages/CasinoDetail';
import CasinoComparison from './pages/CasinoComparison';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import usePageMeta from './hooks/usePageMeta';
import data from './data/content';
import themeVariables from './styles/variables.module.css';

const App = () => {
  usePageMeta({
    title: 'GamblingReviews — обзоры и сравнение казино',
    description: 'Актуальные и независимые обзоры казино, сравнение бонусов, вейджеров и условий выплат.',
    keywords: 'обзор казино, сравнение казино, бонусы казино, условия казино'
  });

  return (
    <div className={themeVariables.theme}>
      <Header />
      <main>
        <Routes>
          <Route
            path="/"
            element={
              <Home
                casinos={data.casinos}
                topRecommendations={data.topRecommendations}
                stats={data.stats}
                evaluationSteps={data.evaluationSteps}
                whyUs={data.whyUs}
                userReviews={data.userReviews}
                faqItems={data.faqItems}
                blogPosts={data.blogPosts}
              />
            }
          />
          <Route
            path="/casino-reviews"
            element={<CasinoReviews casinos={data.casinos} />}
          />
          <Route
            path="/casino-reviews/:slug"
            element={<CasinoDetail casinos={data.casinos} />}
          />
          <Route
            path="/casino-comparison"
            element={<CasinoComparison casinos={data.casinos} />}
          />
          <Route
            path="/about"
            element={<About stats={data.stats} team={data.teamMembers} milestones={data.milestones} />}
          />
          <Route
            path="/services"
            element={<Services services={data.services} approach={data.evaluationSteps} />}
          />
          <Route
            path="/contact"
            element={<Contact />}
          />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;