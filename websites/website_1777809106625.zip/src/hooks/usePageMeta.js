import { useEffect } from 'react';

const ensureMetaTag = (name) => {
  let tag = document.querySelector(`meta[name="${name}"]`);
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute('name', name);
    document.head.appendChild(tag);
  }
  return tag;
};

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      const descriptionTag = ensureMetaTag('description');
      descriptionTag.setAttribute('content', description);
    }
    if (keywords) {
      const keywordsTag = ensureMetaTag('keywords');
      keywordsTag.setAttribute('content', keywords);
    }
  }, [title, description, keywords]);
};

export default usePageMeta;