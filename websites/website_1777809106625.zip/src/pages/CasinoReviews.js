import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import CasinoCard from '../components/CasinoCard';
import styles from './CasinoReviews.module.css';

const CasinoReviews = ({ casinos }) => {
  usePageMeta({
    title: 'Обзоры казино — GamblingReviews',
    description: 'Подробные обзоры онлайн-казино: бонусы, вейджеры, платежные системы и скорость вывода.',
    keywords: 'обзор казино, рейтинг казино, бонусы казино, вывод средств'
  });

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <h1>Список обзоров казино</h1>
        <p>
          Каждый обзор включает проверку лицензии, условий по бонусам, лимитов и инструментов ответственной игры.
          Мы не размещаем реферальных ссылок и сохраняем независимость.
        </p>
      </header>
      <div className={styles.grid}>
        {casinos.map((casino) => (
          <CasinoCard key={casino.id} casino={casino} />
        ))}
      </div>
    </section>
  );
};

export default CasinoReviews;