import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  usePageMeta({
    title: 'Контакты — GamblingReviews',
    description: 'Свяжитесь с редакцией GamblingReviews: вопросы, предложения и обратная связь.',
    keywords: 'контакты GamblingReviews, обратная связь'
  });

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) newErrors.name = 'Укажите имя';
    if (!formState.email.trim()) newErrors.email = 'Укажите email';
    if (formState.email && !/^\S+@\S+\.\S+$/.test(formState.email)) newErrors.email = 'Неверный формат email';
    if (!formState.message.trim()) newErrors.message = 'Напишите сообщение';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <h1>Связаться с GamblingReviews</h1>
        <p>
          Поделитесь опытом, предложите тему для исследования или уточните детали по обзорам. Мы отвечаем в течение двух рабочих дней.
        </p>
      </header>

      <div className={styles.content}>
        <div className={styles.info}>
          <h2>Контактные данные</h2>
          <p>Адрес: 123 Gambling Street, City, Country</p>
          <p>Телефон: <a href="tel:+15551234567">+1 (555) 123-4567</a></p>
          <p>Email: <a href="mailto:info@gamblingreviews.com">info@gamblingreviews.com</a></p>
          <h3>Когда писать?</h3>
          <ul>
            <li>Нашли новое казино, которое стоит проверить.</li>
            <li>Столкнулись с непрозрачными условиями бонуса.</li>
            <li>Хотите поделиться отзывом или предложить улучшение сайта.</li>
          </ul>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label>
            Имя
            <input
              type="text"
              name="name"
              value={formState.name}
              onChange={handleChange}
              aria-label="Ваше имя"
              aria-required="true"
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </label>
          <label>
            Email
            <input
              type="email"
              name="email"
              value={formState.email}
              onChange={handleChange}
              aria-label="Ваш email"
              aria-required="true"
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </label>
          <label>
            Сообщение
            <textarea
              name="message"
              rows="5"
              value={formState.message}
              onChange={handleChange}
              aria-label="Ваше сообщение"
              aria-required="true"
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </label>
          <button type="submit">Отправить сообщение</button>
          {submitted && <p className={styles.success}>Спасибо! Мы получили ваше сообщение и свяжемся с вами.</p>}
        </form>
      </div>
    </section>
  );
};

export default Contact;