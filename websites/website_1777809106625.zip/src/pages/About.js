import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './About.module.css';

const About = ({ stats, team, milestones }) => {
  usePageMeta({
    title: 'О компании GamblingReviews',
    description: 'История GamblingReviews, команда экспертов и наш подход к честным обзорам казино.',
    keywords: 'GamblingReviews, команда, история, честные обзоры'
  });

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <h1>О нас</h1>
        <p>
          GamblingReviews появился из желания сделать индустрию прозрачнее. Мы не продаём иллюзии и не обещаем выигрыш —
          вместо этого собираем данные, изучаем правила и публикуем фактчекинг. Команда работает удалённо из разных стран,
          но объединена общими ценностями — ответственностью, честностью и уважением к игрокам.
        </p>
      </header>

      <div className={styles.mission}>
        <article>
          <h2>Наша миссия</h2>
          <p>
            Помогать игрокам принимать взвешенные решения. Мы анализируем казино так же, как аудиторы
            анализируют финансовые компании: проверяем лицензии, изучаем жалобы и тестируем условия.
          </p>
        </article>
        <article>
          <h2>Что отличает нас</h2>
          <ul>
            <li>GR-Score — собственная модель из 42 метрик.</li>
            <li>Никаких реферальных ссылок и скрытых партнёрств.</li>
            <li>Команда с опытом в комплаенсе, аналитике и медиа.</li>
            <li>Фокус на ответственном гэмблинге и финансовой грамотности.</li>
          </ul>
        </article>
      </div>

      <section className={styles.stats}>
        {stats.map((stat) => (
          <div key={stat.id} className={styles.statCard}>
            <span className={styles.statValue}>{stat.value}+</span>
            <span className={styles.statLabel}>{stat.label}</span>
          </div>
        ))}
      </section>

      <section className={styles.timeline}>
        <h2>Ключевые этапы</h2>
        <div className={styles.timelineGrid}>
          {milestones.map((item) => (
            <article key={item.id} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className={styles.teamHeader}>
          <h2>Команда GamblingReviews</h2>
          <p>Мы совмещаем редакторскую скрупулёзность и аналитический подход к данным.</p>
        </div>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.id} className={styles.teamCard}>
              <img src={member.image} alt={member.name} />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
                <div className={styles.expertise}>
                  {member.expertise.map((skill) => (
                    <span key={skill}>{skill}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <h2>Хотите поделиться опытом или задать вопрос?</h2>
        <p>Расскажите нам о новых казино, неожиданных ограничениях или интересных находках — мы рассмотрим каждое обращение.</p>
        <a href="/contact" className={styles.ctaLink} aria-label="Перейти на страницу контактов">
          Связаться с редакцией
        </a>
      </section>
    </section>
  );
};

export default About;