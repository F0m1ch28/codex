import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  usePageMeta({
    title: 'Политика Cookie — GamblingReviews',
    description: 'Информация о том, какие cookie использует GamblingReviews и как ими управлять.'
  });

  return (
    <section className={styles.page}>
      <h1>Политика Cookie</h1>
      <p>
        Cookie помогают нам анализировать статистику и улучшать удобство сайта. Ниже описаны категории cookie и способы управления.
      </p>
      <h2>1. Типы cookie</h2>
      <ul>
        <li><strong>Необходимые:</strong> обеспечивают работу сайта (навигация, безопасность, настройки языка).</li>
        <li><strong>Аналитические:</strong> собирают обезличенные данные о посещениях для улучшения контента.</li>
        <li><strong>Маркетинговые:</strong> используются для персональных рекомендаций (подключаются только при согласии).</li>
      </ul>
      <h2>2. Управление cookie</h2>
      <p>Вы можете изменить выбор в баннере на сайте или отключить cookie через настройки браузера.</p>
      <h2>3. Срок хранения</h2>
      <p>Необходимые cookie действуют в течение сессии. Аналитические — до 12 месяцев, затем обновляются.</p>
      <h2>4. Вопросы</h2>
      <p>Напишите нам на <a href="mailto:info@gamblingreviews.com">info@gamblingreviews.com</a>, если хотите уточнить детали.</p>
    </section>
  );
};

export default CookiePolicy;