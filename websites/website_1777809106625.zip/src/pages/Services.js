import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Services.module.css';

const Services = ({ services, approach }) => {
  usePageMeta({
    title: 'Наши сервисы — GamblingReviews',
    description: 'Обзор аналитических сервисов GamblingReviews: оценка казино, сравнения, обучающие материалы.',
    keywords: 'сервисы казино, аналитика казино, сравнение казино'
  });

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <h1>Что мы делаем для читателей</h1>
        <p>
          Наши сервисы помогают разобраться в сложных условиях казино. Здесь вы найдёте аналитические сравнения,
          шаблоны оценки и практические гайды по ответственной игре.
        </p>
      </header>

      <div className={styles.servicesGrid}>
        {services.map((service) => (
          <article key={service.id} className={styles.serviceCard}>
            <span className={styles.icon}>{service.icon}</span>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <span className={styles.benefit}>{service.benefit}</span>
          </article>
        ))}
      </div>

      <section className={styles.process}>
        <h2>Подход к аналитике</h2>
        <div className={styles.processGrid}>
          {approach.map((step, index) => (
            <article key={step.id} className={styles.processCard}>
              <span className={styles.stepIndex}>0{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <h2>Нужен индивидуальный разбор?</h2>
        <p>Напишите нам, если хотите получить персональный чек-лист по конкретному казино или бонусной программе.</p>
        <a href="/contact" className={styles.ctaLink}>
          Связаться с нами
        </a>
      </section>
    </section>
  );
};

export default Services;