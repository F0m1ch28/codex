import React from 'react';
import { useParams, Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import styles from './CasinoDetail.module.css';

const CasinoDetail = ({ casinos }) => {
  const { slug } = useParams();
  const casino = casinos.find((item) => item.slug === slug);

  usePageMeta({
    title: casino ? `${casino.name} — подробный обзор казино | GamblingReviews` : 'Казино не найдено | GamblingReviews',
    description: casino
      ? `Обзор ${casino.name}: бонус ${casino.bonus}, условия ${casino.wager}, скорость вывода ${casino.withdrawalTime}.`
      : 'Данный обзор казино недоступен.'
  });

  if (!casino) {
    return (
      <section className={styles.page}>
        <div className={styles.notFound}>
          <h1>Обзор не найден</h1>
          <p>Мы не нашли казино с указанным идентификатором. Попробуйте вернуться к списку обзоров.</p>
          <Link to="/casino-reviews" className={styles.backLink}>Вернуться к обзором</Link>
        </div>
      </section>
    );
  }

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <Link to="/casino-reviews" className={styles.breadcrumb}>← Ко всем обзорам</Link>
        <h1>{casino.name}</h1>
        <div className={styles.meta}>
          <span>Рейтинг GamblingReviews: ★ {casino.rating.toFixed(1)}</span>
          <span>Лицензия: {casino.license || 'уточняется'}</span>
          <span>Категории: {casino.categories.join(', ')}</span>
        </div>
      </header>

      <div className={styles.highlight}>
        <div>
          <h2>Приветственный бонус</h2>
          <p className={styles.highlightBonus}>{casino.welcomeOffer}</p>
          <p>{casino.bonusDetails}</p>
        </div>
        <div className={styles.highlightInfo}>
          <div>
            <span>Вейджер</span>
            <strong>{casino.wager}</strong>
          </div>
          <div>
            <span>Мин. депозит</span>
            <strong>{casino.minDeposit}</strong>
          </div>
          <div>
            <span>Скорость вывода</span>
            <strong>{casino.withdrawalTime}</strong>
          </div>
        </div>
      </div>

      <article className={styles.content}>
        <section>
          <h3>Общее впечатление</h3>
          <p>{casino.description}</p>
        </section>

        <section>
          <h3>Игры и провайдеры</h3>
          <ul>
            <li><strong>Количество игр:</strong> {casino.gamesCount}</li>
            <li><strong>Жанры:</strong> {casino.genres.join(', ')}</li>
            <li><strong>Провайдеры:</strong> {casino.providers.join(', ')}</li>
          </ul>
        </section>

        <section>
          <h3>Платежные системы</h3>
          <p>Доступные методы: {casino.paymentMethods.join(', ')}.</p>
          <p>Максимальный вывод: {casino.maxWithdrawal}. Проверка документов занимает до 24 часов.</p>
        </section>

        <section className={styles.prosCons}>
          <div>
            <h4>Плюсы</h4>
            <ul>
              {casino.pros.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div>
            <h4>Минусы</h4>
            <ul>
              {casino.cons.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </section>

        <section>
          <h3>Особенности</h3>
          <ul>
            {casino.featureHighlights.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </section>

        <section className={styles.notice}>
          <p>
            Помните: азартные игры несут риски. Устанавливайте лимиты и пользуйтесь инструментами самоконтроля.
            GamblingReviews не гарантирует выигрыш и не продвигает азартные услуги.
          </p>
        </section>
      </article>

      <div className={styles.cta}>
        <a
          href={casino.officialSite}
          target="_blank"
          rel="noopener noreferrer"
          className={styles.ctaLink}
        >
          Посетить официальный сайт
        </a>
        <span>Ссылка ведёт на информационную страницу без формы регистрации.</span>
      </div>
    </section>
  );
};

export default CasinoDetail;