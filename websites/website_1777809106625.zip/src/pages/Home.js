import React, { useState, useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import ReviewCard from '../components/ReviewCard';
import FaqAccordion from '../components/FaqAccordion';
import CasinoCard from '../components/CasinoCard';
import styles from './Home.module.css';

const Home = ({
  casinos,
  topRecommendations,
  stats,
  evaluationSteps,
  whyUs,
  userReviews,
  faqItems,
  blogPosts
}) => {
  const [activeReview, setActiveReview] = useState(0);
  const [filter, setFilter] = useState('Все');
  const [animatedStats, setAnimatedStats] = useState(stats.map(() => 0));
  const navigate = useNavigate();

  usePageMeta({
    title: 'Лучшие обзоры казино 2025 — GamblingReviews',
    description:
      'Независимые обзоры онлайн-казино 2025, сравнение бонусов, условий и скоростей выплат. Читайте честные рейтинги GamblingReviews.',
    keywords: 'обзор казино, сравнение казино, бонусы казино, честный рейтинг'
  });

  useEffect(() => {
    const duration = 1600;
    const startTime = performance.now();

    const step = (currentTime) => {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const updated = stats.map((stat, index) =>
        Math.floor(stat.value * progress)
      );
      setAnimatedStats(updated);
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };

    requestAnimationFrame(step);
  }, [stats]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveReview((prev) => (prev + 1) % userReviews.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [userReviews]);

  const popularCasinos = useMemo(() => casinos.slice(0, 3), [casinos]);
  const recommendationTags = useMemo(
    () => ['Все', ...new Set(topRecommendations.flatMap((item) => item.tags.filter((tag) => tag !== 'Все')))],
    [topRecommendations]
  );

  const filteredRecommendations = useMemo(() => {
    if (filter === 'Все') {
      return topRecommendations;
    }
    return topRecommendations.filter((item) => item.tags.includes(filter));
  }, [topRecommendations, filter]);

  const changeReview = (direction) => {
    setActiveReview((prev) => {
      if (direction === 'next') {
        return (prev + 1) % userReviews.length;
      }
      return (prev - 1 + userReviews.length) % userReviews.length;
    });
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <h1>Лучшие обзоры казино 2025</h1>
          <p>
            Мы проверяем лицензии, условия бонусов, скорость выплат и инструменты ответственной игры.
            Вы получаете честный рейтинг без украшений и рекламных слоганов.
          </p>
          <div className={styles.heroActions}>
            <button
              type="button"
              className={styles.ctaPrimary}
              onClick={() => navigate('/casino-reviews')}
              aria-label="Перейти к рейтингу казино"
            >
              Посмотреть рейтинг
            </button>
            <Link to="/casino-comparison" className={styles.ctaSecondary}>
              Сравнить казино
            </Link>
          </div>
          <div className={styles.statsGrid}>
            {stats.map((stat, index) => (
              <div key={stat.id} className={styles.statCard}>
                <span className={styles.statValue}>{animatedStats[index]}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Популярные казино месяца</h2>
          <p>Три площадки с самыми честными условиями по итогам независимого тестирования.</p>
        </div>
        <div className={styles.cardsGrid}>
          {popularCasinos.map((casino) => (
            <CasinoCard key={casino.id} casino={casino} />
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Почему нам доверяют</h2>
          <p>Глубокая экспертиза, открытые методики и акцент на безопасную игру.</p>
        </div>
        <div className={styles.whyGrid}>
          {whyUs.map((item) => (
            <article key={item.id} className={styles.whyCard}>
              <span className={styles.whyIcon} aria-hidden="true">{item.icon}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Как мы оцениваем казино</h2>
          <p>Пятишаговый процесс, который позволяет увидеть картину без иллюзий.</p>
        </div>
        <div className={styles.timeline}>
          {evaluationSteps.map((step, index) => (
            <div key={step.id} className={styles.timelineItem}>
              <span className={styles.timelineIndex}>0{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>ТОП-3 рекомендации GamblingReviews</h2>
          <p>Выбирайте под свой стиль игры — фильтр поможет быстро отсеять лишнее.</p>
        </div>
        <div className={styles.filters}>
          {recommendationTags.map((tag) => (
            <button
              key={tag}
              type="button"
              className={`${styles.filterButton} ${filter === tag ? styles.filterActive : ''}`}
              onClick={() => setFilter(tag)}
            >
              {tag}
            </button>
          ))}
        </div>
        <div className={styles.recommendations}>
          {filteredRecommendations.map((item) => (
            <article key={item.id} className={styles.recCard}>
              <img src={item.image} alt={`Иллюстрация к обзору ${item.title}`} />
              <div className={styles.recContent}>
                <h3>{item.title}</h3>
                <p className={styles.recSummary}>{item.summary}</p>
                <ul>
                  {item.reasons.map((reason) => (
                    <li key={reason}>{reason}</li>
                  ))}
                </ul>
                <div className={styles.recFooter}>
                  <span className={styles.recRating}>★ {item.rating.toFixed(1)}</span>
                  <span className={styles.recBonus}>{item.bonus}</span>
                  <Link to={`/casino-reviews/${item.slug}`} className={styles.recLink}>
                    Читать обзор
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Отзывы читателей</h2>
          <p>Поделитесь своим опытом — мы учитываем обратную связь в обновлениях рейтингов.</p>
        </div>
        <div className={styles.reviewCarousel}>
          <button
            type="button"
            className={styles.carouselControl}
            onClick={() => changeReview('prev')}
            aria-label="Предыдущий отзыв"
          >
            ←
          </button>
          <div className={styles.reviewViewport}>
            <ReviewCard review={userReviews[activeReview]} />
          </div>
          <button
            type="button"
            className={styles.carouselControl}
            onClick={() => changeReview('next')}
            aria-label="Следующий отзыв"
          >
            →
          </button>
        </div>
        <div className={styles.carouselDots} role="tablist" aria-label="Отзывы читателей">
          {userReviews.map((review, index) => (
            <button
              key={review.id}
              type="button"
              className={`${styles.dot} ${activeReview === index ? styles.dotActive : ''}`}
              onClick={() => setActiveReview(index)}
              aria-label={`Перейти к отзыву ${review.name}`}
              aria-selected={activeReview === index}
              role="tab"
            />
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>FAQ: частые вопросы</h2>
          <p>Собрали ответы на вопросы, которые чаще всего задают наши читатели.</p>
        </div>
        <FaqAccordion items={faqItems} />
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Блог и подписка</h2>
          <p>Последние материалы и дайджесты от редакции GamblingReviews.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <img src={post.image} alt={`Превью статьи: ${post.title}`} />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/services" className={styles.blogLink}>
                  Читать подробнее
                </Link>
              </div>
            </article>
          ))}
        </div>
        <form
          className={styles.subscribeForm}
          onSubmit={(event) => {
            event.preventDefault();
            const formData = new FormData(event.target);
            const name = formData.get('name');
            const email = formData.get('email');
            if (!name || !email) {
              alert('Пожалуйста, заполните имя и email.');
              return;
            }
            alert('Спасибо! Мы добавили вас в список рассылки.');
            event.target.reset();
          }}
        >
          <div className={styles.formFields}>
            <input
              type="text"
              name="name"
              placeholder="Ваше имя"
              aria-label="Ваше имя"
              aria-required="true"
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              aria-label="Ваш email"
              aria-required="true"
            />
            <button type="submit" className={styles.ctaPrimary}>
              Подписаться
            </button>
          </div>
          <p className={styles.formNote}>Отправляем только важные обновления рейтингов и новую аналитику.</p>
        </form>
      </section>
    </div>
  );
};

export default Home;