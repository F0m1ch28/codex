import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import ComparisonTable from '../components/ComparisonTable';
import styles from './CasinoComparison.module.css';

const CasinoComparison = ({ casinos }) => {
  usePageMeta({
    title: 'Сравнение казино — GamblingReviews',
    description: 'Сравните казино по бонусам, вейджерам, минимальному депозиту, количеству игр и скорости вывода.',
    keywords: 'сравнение казино, таблица казино, бонусы казино'
  });

  return (
    <section className={styles.page}>
      <header className={styles.header}>
        <h1>Сравнение казино</h1>
        <p>
          Выберите до трёх казино, чтобы сравнить приветственные бонусы, условия по отыгрышу,
          минимальный депозит, количество игр и среднее время вывода. Таблица обновляется автоматически.
        </p>
      </header>
      <ComparisonTable casinos={casinos} />
      <aside className={styles.hint}>
        <h2>Как читать таблицу</h2>
        <p>
          Значения подсвечиваются при наведении, чтобы было проще сопоставлять. Обращайте внимание на комбинацию
          вейджера, лимита ставок и скорости выплат — именно эти параметры чаще всего влияют на комфорт игры.
        </p>
      </aside>
    </section>
  );
};

export default CasinoComparison;