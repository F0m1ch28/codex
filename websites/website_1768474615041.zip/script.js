document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            navToggle.classList.toggle('is-active');
            primaryNav.classList.toggle('is-open');
        });

        primaryNav.querySelectorAll('.nav-link').forEach(function (link) {
            link.addEventListener('click', function () {
                navToggle.classList.remove('is-active');
                primaryNav.classList.remove('is-open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-actions .accept');
    const refuseBtn = document.querySelector('.cookie-actions .refuse');

    const hideCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.style.display = 'none';
        }
    };

    const storePreference = (value) => {
        localStorage.setItem('mte_cookie_preference', value);
    };

    if (cookieBanner) {
        const savedPreference = localStorage.getItem('mte_cookie_preference');
        if (savedPreference) {
            hideCookieBanner();
        }
    }

    if (acceptBtn) {
        acceptBtn.addEventListener('click', function () {
            storePreference('acceptat');
            hideCookieBanner();
        });
    }

    if (refuseBtn) {
        refuseBtn.addEventListener('click', function () {
            storePreference('refuzat');
            hideCookieBanner();
        });
    }
});