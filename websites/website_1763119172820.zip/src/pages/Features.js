import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Features.module.css';

const featureSections = [
  {
    title: 'Live sessions',
    description:
      'Broadcast high-definition streams with backstage controls, speaker green rooms, and interactive overlays for polls, Q&A, and reactions.'
  },
  {
    title: 'Agenda & tracks',
    description:
      'Build multi-track agendas with drag-and-drop scheduling, personalised itineraries, and timezone-conscious views.'
  },
  {
    title: 'Registration & check-in',
    description:
      'Configure branded registration flows, payment gateways, segmentation, QR check-in, and real-time attendee status.'
  },
  {
    title: 'Virtual networking',
    description:
      'Deliver 1:1 meetings, topic lounges, sponsor booths, and AI recommendations that connect the right attendees at the right moment.'
  },
  {
    title: 'Recordings & replays',
    description:
      'Auto-capture sessions, publish on-demand hubs, and control access windows for post-event engagement.'
  },
  {
    title: 'Analytics & reporting',
    description:
      'Access dashboards on engagement, retention, sponsor ROI, and attendee satisfaction with exportable insights.'
  },
  {
    title: 'Security & compliance',
    description:
      'Operate with EU hosting, SSO, MFA, granular permissions, audit logs, and GDPR-first data governance.'
  }
];

const Features = () => (
  <>
    <Helmet>
      <title>Platform Features | Conferizwm Conference Software</title>
      <meta
        name="description"
        content="Explore Conferizwm features including live streaming, agenda management, registration, virtual networking, recordings, analytics, and GDPR-compliant security."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Enterprise features for modern conferences.</h1>
      <p>
        Every module is crafted for scalability, security, and engagement — ensuring your teams orchestrate
        events with confidence.
      </p>
    </section>
    <section className={styles.featuresGrid}>
      {featureSections.map(section => (
        <article key={section.title}>
          <h2>{section.title}</h2>
          <p>{section.description}</p>
        </article>
      ))}
    </section>
  </>
);

export default Features;