import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use | Conferizwm</title>
      <meta
        name="description"
        content="Review the Conferizwm terms of use covering platform access, account responsibilities, acceptable usage, and governing law."
      />
    </Helmet>
    <section className={styles.legal}>
      <h1>Terms of use</h1>
      <p>Last updated: April 2024</p>
      <h2>1. Acceptance of terms</h2>
      <p>
        By accessing or using Conferizwm services you agree to be bound by these Terms. If you are using
        the platform on behalf of an organisation, you agree to these terms for that organisation.
      </p>
      <h2>2. Accounts & responsibilities</h2>
      <p>
        Account administrators are responsible for maintaining accurate information, managing user access,
        and ensuring compliance with data policies. You must promptly notify us of any unauthorised use.
      </p>
      <h2>3. Acceptable use</h2>
      <p>
        You agree not to misuse the platform, attempt to gain unauthorised access, or transmit malicious code.
        Conferizwm reserves the right to suspend accounts violating these terms.
      </p>
      <h2>4. Intellectual property</h2>
      <p>
        All platform components remain the property of Conferizwm Ltd. Customers retain ownership of their
        content streamed or uploaded within the platform.
      </p>
      <h2>5. Liability</h2>
      <p>
        To the maximum extent permitted by law, Conferizwm is not liable for indirect or consequential damages.
        Our total liability is limited to the fees paid for the services giving rise to the claim.
      </p>
      <h2>6. Governing law</h2>
      <p>
        These Terms are governed by the laws of Malta and disputes shall be subject to the exclusive jurisdiction
        of the Maltese courts.
      </p>
    </section>
  </>
);

export default Terms;