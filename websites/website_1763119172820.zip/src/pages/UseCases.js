import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './UseCases.module.css';

const cases = [
  {
    title: 'Tech conferences',
    details:
      'Launch developer-first stages with code demos, live Q&A, sandbox labs, and real-time release communication.'
  },
  {
    title: 'Corporate events',
    details:
      'Orchestrate regional kickoffs, leadership summits, and product launches with executive-grade polish.'
  },
  {
    title: 'Universities & training',
    details:
      'Scale executive education, digital alumni days, and blended learning cohorts with secure academic workflows.'
  },
  {
    title: 'Remote teams collaboration',
    details:
      'Design asynchronous and live collaboration weeks that connect distributed teams with purpose.'
  },
  {
    title: 'Events from Malta for global audiences',
    details:
      'Broadcast from Malta studios to engage audiences worldwide with multi-language and multi-timezone support.'
  }
];

const UseCases = () => (
  <>
    <Helmet>
      <title>Use Cases | Conferizwm Hybrid Conference Platform</title>
      <meta
        name="description"
        content="Conferizwm powers tech conferences, corporate events, university programs, remote collaboration, and global events broadcast from Malta."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Purpose-built for your conference mission.</h1>
      <p>
        Conferizwm adapts to industries with white-glove support, ensuring every stakeholder achieves their goals.
      </p>
    </section>
    <section className={styles.caseGrid}>
      {cases.map(item => (
        <article key={item.title}>
          <h2>{item.title}</h2>
          <p>{item.details}</p>
        </article>
      ))}
    </section>
  </>
);

export default UseCases;