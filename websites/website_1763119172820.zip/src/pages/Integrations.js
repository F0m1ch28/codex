import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Integrations.module.css';

const integrations = [
  {
    name: 'Zoom',
    description: 'Embed Zoom webinars & meetings with synchronized analytics and attendee pass-through.'
  },
  {
    name: 'Microsoft Teams',
    description: 'Connect your Teams ecosystem for internal town halls and enterprise collaboration.'
  },
  {
    name: 'Google Meet',
    description: 'Offer Meet-powered breakout rooms with seamless authentication and calendar sync.'
  },
  {
    name: 'Google & Outlook Calendar',
    description: 'Publish sessions and automate invites directly to attendee calendars.'
  },
  {
    name: 'Slack',
    description: 'Trigger conference updates, matchmaking alerts, and help desk support within Slack.'
  },
  {
    name: 'SSO',
    description: 'Authenticate attendees with SAML, OAuth, or OpenID providers to maintain governance.'
  },
  {
    name: 'API & webhooks',
    description: 'Integrate with marketing automation, CRM, and data warehouses for end-to-end analytics.'
  }
];

const Integrations = () => (
  <>
    <Helmet>
      <title>Integrations | Conferizwm Conference Ecosystem</title>
      <meta
        name="description"
        content="Conferizwm integrates with Zoom, Microsoft Teams, Google Meet, calendars, Slack, SSO, and APIs to fit into your enterprise event ecosystem."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Connect your conference stack.</h1>
      <p>
        Conferizwm plugs into leading collaboration, calendar, and identity platforms to maintain business continuity.
      </p>
    </section>
    <section className={styles.integrationList}>
      {integrations.map(integration => (
        <article key={integration.name}>
          <h2>{integration.name}</h2>
          <p>{integration.description}</p>
        </article>
      ))}
    </section>
  </>
);

export default Integrations;