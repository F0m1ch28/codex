import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Name is required.';
    if (!form.email.trim()) {
      newErrors.email = 'Email is required.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(form.email)) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (!form.company.trim()) newErrors.company = 'Company is required.';
    if (!form.message.trim()) newErrors.message = 'Please share how we can help.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = event => {
    const { name, value } = event.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = event => {
    event.preventDefault();
    if (validate()) {
      setSubmitted(true);
      setForm(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact Conferizwm | Book a Demo</title>
        <meta
          name="description"
          content="Book a demo with Conferizwm. Contact our Malta-based team to discuss hybrid conference software, services, and integrations."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Talk to our team.</h1>
        <p>
          Share your goals and our specialists will respond within one business day with an aligned plan.
        </p>
      </section>

      <section className={styles.contactSection}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Name</label>
            <input
              id="name"
              name="name"
              value={form.name}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="company">Company</label>
            <input
              id="company"
              name="company"
              value={form.company}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={Boolean(errors.company)}
            />
            {errors.company && <span className={styles.error}>{errors.company}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={form.message}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>

          <button type="submit" className={styles.submit}>
            Book a demo
          </button>
          {submitted && (
            <p className={styles.success}>
              Thank you! Our team will reach out within one business day.
            </p>
          )}
        </form>

        <aside className={styles.details}>
          <div className={styles.infoCard}>
            <h2>Contact details</h2>
            <p><strong>Address:</strong> Malta (EU)</p>
            <p><strong>Phone:</strong> <a href="tel:+35627781234">+356 2778 1234</a></p>
            <p><strong>Email:</strong> <a href="mailto:hello@conferizwm.com">hello@conferizwm.com</a></p>
          </div>
          <div className={styles.mapWrapper} aria-label="Map of Malta">
            <iframe
              title="Conferizwm Malta Office"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60233.12066465459!2d14.429556!3d35.895241!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x130e4525a61f8c6f%3A0x8a8ae2762d736f6f!2sMalta!5e0!3m2!1sen!2s!4v1683030390079!5m2!1sen!2s"
              loading="lazy"
              allowFullScreen
            />
          </div>
        </aside>
      </section>
    </>
  );
};

export default Contact;