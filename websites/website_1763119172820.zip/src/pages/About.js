import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>About Conferizwm | Malta’s Hybrid Conference Innovators</title>
      <meta
        name="description"
        content="Learn about Conferizwm, the Malta-based B2B SaaS team delivering hybrid conference software, concierge services, and secure infrastructure for global enterprises."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>We are Conferizwm.</h1>
      <p>
        Born on the island of Malta, we design software and services that allow ambitious teams to
        convene global communities without compromise.
      </p>
    </section>

    <section className={styles.story}>
      <div className={styles.storyCard}>
        <h2>Our story</h2>
        <p>
          Conferizwm was founded by event technologists and broadcast producers who saw a gap between
          traditional event platforms and the needs of modern, globally distributed audiences. From our
          Mediterranean headquarters, we bring together cultural empathy, rigorous operations, and
          engineering excellence.
        </p>
        <p>
          Today we partner with enterprises, universities, NGOs, and agencies to deliver secure, engaging,
          and insight-rich conferences that span time zones and formats.
        </p>
      </div>
      <div className={styles.storyCard}>
        <h2>Our promise</h2>
        <ul>
          <li>Human-first, concierge-level support from Malta-based specialists.</li>
          <li>Transparent collaboration with clear milestones and accountability.</li>
          <li>Enterprise-ready infrastructure built on EU compliance foundations.</li>
          <li>Relentless pursuit of attendee satisfaction and measurable outcomes.</li>
        </ul>
      </div>
    </section>

    <section className={styles.values}>
      <h2>Values that anchor every conference we power.</h2>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Integrity in delivery</h3>
          <p>We prioritise transparent communication, audit-ready processes, and responsible stewardship of data.</p>
        </article>
        <article>
          <h3>Creative engineering</h3>
          <p>Our teams blend code, design, and broadcast craft to create memorable, branded experiences.</p>
        </article>
        <article>
          <h3>Inclusive access</h3>
          <p>Accessibility, localisation, and sustainable practices are built into our playbooks from day one.</p>
        </article>
        <article>
          <h3>Mediterranean hospitality</h3>
          <p>We treat every client and attendee with the warmth, empathy, and care our island is known for.</p>
        </article>
      </div>
    </section>
  </>
);

export default About;