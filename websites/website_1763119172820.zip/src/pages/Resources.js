import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Resources.module.css';

const resources = [
  {
    title: 'Hybrid Conference Blueprint',
    description:
      'Step-by-step guide for designing hybrid events with production checklists and attendee engagement tactics.'
  },
  {
    title: 'Agenda Templates Library',
    description:
      'Download vetted agenda templates for leadership summits, technical showcases, and academia.'
  },
  {
    title: 'Webinar Replay Hub',
    description:
      'Watch expert sessions covering onboarding, networking best practices, and analytics walkthroughs.'
  },
  {
    title: 'Onboarding Playbook',
    description:
      'Accelerate platform adoption with structured training, role-specific guides, and success milestones.'
  }
];

const Resources = () => (
  <>
    <Helmet>
      <title>Resources | Conferizwm Guides & Templates</title>
      <meta
        name="description"
        content="Access Conferizwm resources including hybrid conference guides, agenda templates, webinar replays, and onboarding materials."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Resources to accelerate your conference strategy.</h1>
      <p>
        Explore curated guides, templates, and on-demand webinars that empower your teams to deliver transforming events.
      </p>
    </section>
    <section className={styles.resourcesGrid}>
      {resources.map(resource => (
        <article key={resource.title}>
          <h2>{resource.title}</h2>
          <p>{resource.description}</p>
          <a href="/contact" className={styles.resourceLink}>
            Request access
          </a>
        </article>
      ))}
    </section>
  </>
);

export default Resources;