import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Event strategy & design',
    description:
      'Translate your goals into attendee journeys, content formats, and production roadmaps tailored for hybrid delivery.'
  },
  {
    title: 'Production & broadcast',
    description:
      'Access Malta-based studios, remote directors, and AV experts who deliver polished live sessions and on-demand assets.'
  },
  {
    title: 'Attendee operations',
    description:
      'Let us manage registration, help desks, speaker onboarding, and sponsor enablement with multilingual specialists.'
  },
  {
    title: 'Data & analytics consulting',
    description:
      'Unlock dashboards, ROI analyses, and stakeholder reports that guide future decision-making and content cycles.'
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Services | Conferizwm Hybrid Conference Specialists</title>
      <meta
        name="description"
        content="Discover Conferizwm professional services including conference strategy, broadcast production, attendee operations, and analytics for hybrid and virtual events."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Professional services that extend your team.</h1>
      <p>
        Our Malta-based experts join your mission — co-creating strategy, delivering flawless production,
        and optimising every attendee touchpoint.
      </p>
    </section>

    <section className={styles.servicesGrid}>
      {services.map(service => (
        <article key={service.title}>
          <h2>{service.title}</h2>
          <p>{service.description}</p>
        </article>
      ))}
    </section>

    <section className={styles.support}>
      <div>
        <h2>Flexible engagement models.</h2>
        <p>
          Choose from launch accelerators, managed services, or event-by-event support. We align on KPIs
          and embed our specialists alongside your team across time zones.
        </p>
      </div>
      <a className={styles.supportCTA} href="/contact">
        Talk to our team
      </a>
    </section>
  </>
);

export default Services;