import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { label: 'Attendees orchestrated', value: 120000 },
  { label: 'Countries reached', value: 78 },
  { label: 'Hours streamed securely', value: 5400 },
  { label: 'Enterprise integrations', value: 36 }
];

const advantages = [
  {
    title: 'EU-grade compliance',
    description: 'Operate confidently with GDPR-first workflows, EU hosting, and meticulous privacy controls.'
  },
  {
    title: 'Hybrid-ready architecture',
    description: 'Deliver immersive experiences across in-person, online, and on-demand formats without silos.'
  },
  {
    title: 'Unified attendee journey',
    description: 'Registration, networking, live sessions, analytics — all stitched into a branded journey.'
  },
  {
    title: 'Malta-based concierge',
    description: 'Partner with our Mediterranean team for strategy, production, and 24/7 event operations.'
  }
];

const featureHighlights = [
  {
    title: 'Dynamic live sessions',
    text: 'Broadcast keynotes and breakouts via low-latency streaming, HD slidesync, and native Q&A tools.',
    link: '/features'
  },
  {
    title: 'Intelligent agendas',
    text: 'Curate multi-track schedules with timezone-aware views, AI room suggestions, and RSVP caps.',
    link: '/features'
  },
  {
    title: 'Immersive networking',
    text: 'Unlock matchmaking lounges, 1:1 video pods, sponsor booths, and AI-assisted meeting requests.',
    link: '/features'
  }
];

const useCaseCards = [
  {
    title: 'Tech conferences',
    text: 'Scale from developer meetups to global summits with streaming, release stages, and hackathons.'
  },
  {
    title: 'Corporate events',
    text: 'Launch products, run leadership off-sites, or host global kickoffs with branded digital venues.'
  },
  {
    title: 'Universities & training',
    text: 'Deliver digital graduations, blended learning days, and executive education from Malta to the world.'
  },
  {
    title: 'Remote teams collaboration',
    text: 'Fuel async & live collaboration with workshops, onboarding weeks, and cultural touchpoints.'
  }
];

const testimonials = [
  {
    quote:
      'Conferizwm helped us transform a 5,000-person fintech congress into a hybrid powerhouse with localized hubs in three continents.',
    name: 'Leah Mifsud',
    role: 'Head of Experience, BlueLedger',
    company: 'BlueLedger'
  },
  {
    quote:
      'From registration to post-event analytics, the platform offered us a single pane of glass. Our sponsors loved the lead intelligence.',
    name: 'Marco D’Alessandro',
    role: 'Global Events Lead, StratoSys',
    company: 'StratoSys'
  },
  {
    quote:
      'The Malta-based concierge team co-produced our digital university open day. Attendee satisfaction hit 97%.',
    name: 'Prof. Claire Bonello',
    role: 'Dean of Engagement, Global University',
    company: 'Global University'
  }
];

const partners = ['Zoom', 'Microsoft', 'Google', 'Slack', 'Stripe', 'HubSpot'];

const processSteps = [
  {
    step: '01',
    title: 'Discover & align',
    description: 'Co-design goals, personas, and success metrics with our Malta event strategists.'
  },
  {
    step: '02',
    title: 'Craft & configure',
    description: 'Set up branded environments, registration flows, and sponsor zones in days.'
  },
  {
    step: '03',
    title: 'Engage & broadcast',
    description: 'Deliver frictionless live sessions, networking, and support with real-time dashboards.'
  },
  {
    step: '04',
    title: 'Analyse & scale',
    description: 'Review attendee intelligence, ROI, and playbooks to level-up every event cycle.'
  }
];

const projectGallery = [
  {
    id: 1,
    title: 'Mediterranean Tech Week',
    category: 'Hybrid',
    image: 'https://picsum.photos/1200/800?random=40',
    description: '7 stages, 12,500 remote attendees, 4 hub cities.'
  },
  {
    id: 2,
    title: 'Global Finance Summit',
    category: 'Virtual',
    image: 'https://picsum.photos/1200/800?random=41',
    description: 'High-security broadcast with multi-language overlays.'
  },
  {
    id: 3,
    title: 'University Open Day',
    category: 'Education',
    image: 'https://picsum.photos/1200/800?random=42',
    description: 'Interactive campus hub with 47 live faculty sessions.'
  },
  {
    id: 4,
    title: 'Corporate Innovation Expo',
    category: 'Hybrid',
    image: 'https://picsum.photos/1200/800?random=43',
    description: 'Immersive sponsor booths and AI-powered matchmaking.'
  }
];

const faqItems = [
  {
    question: 'How quickly can we launch a hybrid conference on Conferizwm?',
    answer:
      'Our Malta launch team typically configures production-ready environments in under 10 business days, depending on integrations and complexity.'
  },
  {
    question: 'Do you support multi-language streaming and captioning?',
    answer:
      'Yes. Conferizwm integrates with real-time translation engines, human interpreters, and AI captioning to offer truly global experiences.'
  },
  {
    question: 'Can sponsors access lead analytics and engagement data?',
    answer:
      'Sponsor workspaces include dashboards on booth visits, session interactions, exported leads, and conversion benchmarks.'
  },
  {
    question: 'How does Conferizwm ensure GDPR compliance?',
    answer:
      'We host on EU infrastructure, apply least-privilege access, offer DPA agreements, and enable granular consent management across all attendee touchpoints.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Designing human-centric hybrid conferences in 2024',
    date: 'April 2, 2024',
    excerpt:
      'Discover how leading enterprises blend Malta-based studios with global hubs to deliver seamless hybrid experiences.',
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    id: 2,
    title: 'The analytics playbook for executive events',
    date: 'March 18, 2024',
    excerpt:
      'From attendance heatmaps to content ROI, learn the metrics that keep C-level stakeholders aligned.',
    image: 'https://picsum.photos/800/600?random=53'
  },
  {
    id: 3,
    title: 'Virtual networking that actually moves the needle',
    date: 'March 6, 2024',
    excerpt:
      'See how AI-powered matchmaking drives meaningful introductions and post-event deal flow.',
    image: 'https://picsum.photos/800/600?random=54'
  }
];

const teamMembers = [
  {
    name: 'Elena Borg',
    role: 'Chief Executive Officer',
    bio: 'Former global events director at a FTSE 100 firm, Elena leads Conferizwm’s vision and customer success.',
    image: 'https://picsum.photos/400/400?random=60'
  },
  {
    name: 'Samuel Vella',
    role: 'Head of Product',
    bio: 'Samuel designs frictionless event journeys blending UX excellence, accessibility, and security.',
    image: 'https://picsum.photos/400/400?random=61'
  },
  {
    name: 'Nina Camilleri',
    role: 'Director of Experience',
    bio: 'Nina orchestrates hybrid production studios and concierge services directly from Valletta.',
    image: 'https://picsum.photos/400/400?random=62'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    const stepTime = 60;
    const duration = 2000;
    const steps = duration / stepTime;
    const increments = statsData.map(item => item.value / steps);
    const interval = setInterval(() => {
      setStats(prev =>
        prev.map((value, idx) => {
          const next = value + increments[idx];
          return next >= statsData[idx].value
            ? statsData[idx].value
            : next;
        })
      );
    }, stepTime);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex(prev =>
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    activeCategory === 'All'
      ? projectGallery
      : projectGallery.filter(project => project.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Conferizwm | Hybrid Conference Platform from Malta</title>
        <meta
          name="description"
          content="Conferizwm is the leading Malta-based B2B SaaS platform for online and hybrid conferences. Power agendas, live sessions, networking, analytics, and EU-grade compliance."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroBadge}>Engineered in Malta • Trusted worldwide</p>
          <h1>
            Run unforgettable hybrid conferences
            <span> from one Mediterranean homebase.</span>
          </h1>
          <p className={styles.heroLead}>
            Conferizwm unifies broadcast-quality streaming, networking, registration,
            and analytics into a single EU-compliant platform. Launch immersive events
            that bridge physical and digital audiences — on-brand, on-time, on-budget.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryCTA}>
              Book a demo
            </Link>
            <Link to="/services" className={styles.secondaryCTA}>
              Talk to our team
            </Link>
          </div>
          <div className={styles.heroIndicators}>
            <div>
              <span>ISO-ready infrastructure</span>
              <span>24/7 live command centre</span>
            </div>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/1600/900?random=10"
            alt="Hybrid conference control centre in Malta"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.stats}>
        {statsData.map((item, index) => (
          <div className={styles.statCard} key={item.label}>
            <span className={styles.statNumber}>
              {Math.round(stats[index]).toLocaleString()}
            </span>
            <span className={styles.statLabel}>{item.label}</span>
          </div>
        ))}
      </section>

      <section className={styles.advantages}>
        <header className={styles.sectionHeader}>
          <span className={styles.sectionKicker}>Why Conferizwm</span>
          <h2>Set the standard for modern, data-rich conference experiences.</h2>
          <p>
            From Valletta to Vancouver, our customers orchestrate multi-format events with
            enterprise-grade governance and boutique concierge support.
          </p>
        </header>
        <div className={styles.advGrid}>
          {advantages.map(item => (
            <article key={item.title} className={styles.advCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.features}>
        <div className={styles.featuresIntro}>
          <span className={styles.sectionKicker}>Platform capabilities</span>
          <h2>Everything you need to design, launch, and scale conferences.</h2>
          <p>
            Configure complex agendas, stream in full HD, manage registrations, and surface analytics
            with a unified control panel that puts your team in sync.
          </p>
        </div>
        <div className={styles.featuresGrid}>
          {featureHighlights.map(feature => (
            <article key={feature.title} className={styles.featureCard}>
              <h3>{feature.title}</h3>
              <p>{feature.text}</p>
              <Link to={feature.link} className={styles.featureLink}>
                Explore feature
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.processHeader}>
          <span className={styles.sectionKicker}>Workflow</span>
          <h2>Our Malta-native process keeps your conference momentum high.</h2>
          <p>
            We partner from the first whiteboard sketch to the post-event debrief. Every step is anchored
            by proactive communication and measurable milestones.
          </p>
        </div>
        <div className={styles.processSteps}>
          {processSteps.map(step => (
            <div className={styles.processCard} key={step.step}>
              <span className={styles.processNumber}>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.useCases}>
        <div className={styles.useCasesHeader}>
          <span className={styles.sectionKicker}>Use cases</span>
          <h2>Purpose-built solutions for teams that convene global audiences.</h2>
        </div>
        <div className={styles.useCasesGrid}>
          {useCaseCards.map(card => (
            <article key={card.title} className={styles.useCasesCard}>
              <h3>{card.title}</h3>
              <p>{card.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.integrations}>
        <span className={styles.sectionKicker}>Integrations</span>
        <h2>Seamless with your conferencing and workplace stack.</h2>
        <div className={styles.partnerStrip} aria-label="Supported integrations">
          {partners.map(partner => (
            <span key={partner}>{partner}</span>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.teamIntro}>
          <span className={styles.sectionKicker}>Team</span>
          <h2>Experienced leaders delivering conference impact.</h2>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map(member => (
            <article className={styles.teamCard} key={member.name}>
              <div className={styles.teamImageWrapper}>
                <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              </div>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.projectsHeader}>
          <span className={styles.sectionKicker}>Showcase</span>
          <h2>Recent conferences delivered with Conferizwm.</h2>
          <div className={styles.filterControls} role="tablist" aria-label="Project filters">
            {['All', 'Hybrid', 'Virtual', 'Education'].map(category => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterActive : ''
                }`}
                aria-pressed={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map(project => (
            <figure key={project.id} className={styles.projectCard}>
              <img src={project.image} alt={`${project.title} hybrid conference`} loading="lazy" />
              <figcaption>
                <h3>{project.title}</h3>
                <span>{project.category}</span>
                <p>{project.description}</p>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.testimonialInner}>
          <span className={styles.sectionKicker}>Testimonials</span>
          <h2>Event teams worldwide trust Conferizwm from Malta.</h2>
          <div className={styles.testimonialContent}>
            <p>{testimonials[testimonialIndex].quote}</p>
            <div className={styles.testimonialMeta}>
              <span>{testimonials[testimonialIndex].name}</span>
              <span>{testimonials[testimonialIndex].role}</span>
            </div>
            <div className={styles.dots} role="tablist" aria-label="Customer stories">
              {testimonials.map((item, idx) => (
                <button
                  key={item.name}
                  className={`${styles.dot} ${idx === testimonialIndex ? styles.dotActive : ''}`}
                  aria-label={`Show testimonial ${idx + 1}`}
                  aria-pressed={idx === testimonialIndex}
                  onClick={() => setTestimonialIndex(idx)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.faqInner}>
          <span className={styles.sectionKicker}>FAQ</span>
          <h2>Frequently asked questions</h2>
          <div className={styles.faqList}>
            {faqItems.map(item => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.blogHeader}>
          <span className={styles.sectionKicker}>Insights</span>
          <h2>Latest perspectives from the Conferizwm team.</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map(post => (
            <article key={post.id} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/resources" className={styles.blogLink}>
                  Read more
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaInner}>
          <h2>Ready to deliver your next flagship conference?</h2>
          <p>
            Partner with Conferizwm for a Malta anchored, globally scalable platform that keeps attendees
            engaged before, during, and after every event.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/contact" className={styles.primaryCTA}>
              Book a demo
            </Link>
            <Link to="/contact" className={styles.secondaryCTA}>
              Talk to our team
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;