import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Conferizwm</title>
      <meta
        name="description"
        content="Read the Conferizwm privacy policy detailing GDPR compliance, data collection, usage, retention, and data subject rights."
      />
    </Helmet>
    <section className={styles.legal}>
      <h1>Privacy policy</h1>
      <p>Effective date: April 2024</p>
      <h2>Data controller</h2>
      <p>Conferizwm Ltd., Malta (EU), acts as the data controller for platform users and attendees.</p>
      <h2>Data collection</h2>
      <p>
        We collect contact details, session analytics, device data, and support interactions necessary to
        operate our services. Additional data is collected by customers acting as controllers for their events.
      </p>
      <h2>Lawful basis</h2>
      <p>
        We process data on the basis of contract performance, legitimate interest, and consent where required.
      </p>
      <h2>Data rights</h2>
      <p>
        You may request access, rectification, deletion, or portability of your personal data. Submit requests to
        hello@conferizwm.com. We respond within 30 days in accordance with GDPR.
      </p>
      <h2>Security</h2>
      <p>
        Conferizwm maintains encryption in transit and at rest, role-based access, auditing, and incident response
        protocols aligned with EU standards.
      </p>
      <h2>Retention</h2>
      <p>
        Personal data is retained only as long as required to deliver services or comply with legal obligations.
      </p>
      <h2>International transfers</h2>
      <p>
        Where data is transferred outside the EU, we apply standard contractual clauses or equivalent safeguards.
      </p>
    </section>
  </>
);

export default Privacy;