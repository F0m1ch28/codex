import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Conferizwm</title>
      <meta
        name="description"
        content="Learn about the cookies used on the Conferizwm platform, their purpose, and how to manage preferences."
      />
    </Helmet>
    <section className={styles.legal}>
      <h1>Cookie policy</h1>
      <p>Updated: April 2024</p>
      <h2>Essential cookies</h2>
      <p>
        Required for authentication, session stability, and security. These cookies cannot be disabled as they
        enable the core platform experience.
      </p>
      <h2>Analytics cookies</h2>
      <p>
        With consent, we use privacy-centric analytics to understand platform usage. Data is aggregated and anonymised.
      </p>
      <h2>Managing cookies</h2>
      <p>
        You can manage preferences via browser settings or by contacting hello@conferizwm.com. Declining certain
        cookies may impact functionality.
      </p>
    </section>
  </>
);

export default CookiePolicy;