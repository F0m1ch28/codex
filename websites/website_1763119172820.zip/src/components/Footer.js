import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.column}>
        <div className={styles.brand}>
          <span className={styles.logoMark}>C</span>
          <div>
            <h3>Conferizwm</h3>
            <p>Global conferences, engineered in Malta.</p>
          </div>
        </div>
        <p className={styles.description}>
          Deliver unforgettable online, hybrid, and in-person event experiences with a single, enterprise-ready platform designed for global audiences.
        </p>
      </div>
      <div className={styles.column}>
        <h4>Platform</h4>
        <Link to="/features">Features</Link>
        <Link to="/use-cases">Use cases</Link>
        <Link to="/integrations">Integrations</Link>
        <Link to="/resources">Resources</Link>
      </div>
      <div className={styles.column}>
        <h4>Company</h4>
        <Link to="/about">About</Link>
        <Link to="/services">Services</Link>
        <Link to="/privacy">Privacy</Link>
        <Link to="/terms">Terms</Link>
        <Link to="/cookie-policy">Cookie policy</Link>
      </div>
      <div className={styles.column}>
        <h4>Contact</h4>
        <p>Address: Malta (EU)</p>
        <p>Phone: <a href="tel:+35627781234">+356 2778 1234</a></p>
        <p>Email: <a href="mailto:hello@conferizwm.com">hello@conferizwm.com</a></p>
        <Link to="/contact" className={styles.footerCTA}>Talk to our team</Link>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <span>© {new Date().getFullYear()} Conferizwm Ltd. All rights reserved.</span>
      <div className={styles.links}>
        <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn">
          LinkedIn
        </a>
        <a href="https://twitter.com/" target="_blank" rel="noreferrer" aria-label="Twitter">
          X / Twitter
        </a>
      </div>
    </div>
  </footer>
);

export default Footer;