import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('conferizwm_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    window.localStorage.setItem('conferizwm_cookie_consent', 'accepted');
    setVisible(false);
  };

  const decline = () => {
    window.localStorage.setItem('conferizwm_cookie_consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        We use essential cookies to deliver secure conference experiences and understand platform usage.
        Read our <a href="/cookie-policy">cookie policy</a>.
      </p>
      <div className={styles.actions}>
        <button type="button" onClick={accept} className={styles.accept}>
          Accept
        </button>
        <button type="button" onClick={decline} className={styles.decline}>
          Decline
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;