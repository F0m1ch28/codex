document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('#nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('is-open');
    });

    navMenu.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute('aria-expanded', 'false');
          navMenu.classList.remove('is-open');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');

  if (cookieBanner) {
    try {
      const consent = localStorage.getItem('nmg-cookie-consent');
      if (!consent) {
        cookieBanner.classList.add('is-visible');
      }
      const setConsent = (value) => {
        localStorage.setItem('nmg-cookie-consent', value);
        cookieBanner.classList.remove('is-visible');
      };
      acceptBtn?.addEventListener('click', () => setConsent('accepted'));
      declineBtn?.addEventListener('click', () => setConsent('declined'));
    } catch (error) {
      cookieBanner.classList.add('is-visible');
    }
  }
});