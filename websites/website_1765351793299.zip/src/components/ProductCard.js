import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ProductCard.module.css';

const ProductCard = ({ title, description, image, tags = [] }) => {
  return (
    <article className={styles.card}>
      <div className={styles.imageWrapper}>
        <img src={image} alt={`Превью: ${title}`} loading="lazy" />
      </div>
      <div className={styles.content}>
        <h3>{title}</h3>
        <p>{description}</p>
        {tags.length > 0 && (
          <ul className={styles.tags}>
            {tags.map((tag) => (
              <li key={`${title}-${tag}`}>{tag}</li>
            ))}
          </ul>
        )}
        <Link to="/contacts" className={styles.button}>
          Подробнее
        </Link>
      </div>
    </article>
  );
};

export default ProductCard;