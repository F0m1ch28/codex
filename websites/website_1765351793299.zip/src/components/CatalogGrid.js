import React from 'react';
import ProductCard from './ProductCard';
import styles from './CatalogGrid.module.css';

const CatalogGrid = ({ title, description, items }) => {
  return (
    <section className={styles.section}>
      <div className={styles.header}>
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      <div className={styles.grid}>
        {items.map((item) => (
          <ProductCard key={item.id} {...item} />
        ))}
      </div>
    </section>
  );
};

export default CatalogGrid;