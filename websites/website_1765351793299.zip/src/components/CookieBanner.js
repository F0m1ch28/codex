import React from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'digitalcovers_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === 'undefined') return;
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEY, choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Мы используем cookies, чтобы сайт работал без сбоев и помогал вам находить нужные материалы. Вы можете изменить выбор в любой момент.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleChoice('declined')}>
            Отклонить
          </button>
          <button
            type="button"
            className={styles.primary}
            onClick={() => handleChoice('accepted')}
          >
            Принять
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;