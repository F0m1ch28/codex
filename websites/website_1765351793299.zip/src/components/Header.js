import React from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isCatalogOpen, setIsCatalogOpen] = React.useState(false);
  const location = useLocation();

  React.useEffect(() => {
    setIsMenuOpen(false);
    setIsCatalogOpen(false);
  }, [location]);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const toggleCatalog = () => setIsCatalogOpen((prev) => !prev);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <div className={styles.logo}>
          <Link to="/" aria-label="DigitalCovers — на главную">
            Digital<span>Covers</span>
          </Link>
        </div>

        <button
          type="button"
          className={styles.menuToggle}
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className="visuallyHidden">Меню</span>
        </button>

        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            <li className={styles.navItem}>
              <NavLink
                to="/"
                className={({ isActive }) =>
                  isActive ? `${styles.link} ${styles.active}` : styles.link
                }
              >
                Главная
              </NavLink>
            </li>
            <li
              className={`${styles.navItem} ${styles.catalog}`}
              onMouseEnter={() => setIsCatalogOpen(true)}
              onMouseLeave={() => setIsCatalogOpen(false)}
            >
              <button
                type="button"
                className={styles.catalogToggle}
                onClick={toggleCatalog}
                aria-expanded={isCatalogOpen}
              >
                Каталоги
                <span className={styles.arrow} aria-hidden="true">▾</span>
              </button>
              <ul
                className={`${styles.dropdown} ${
                  isCatalogOpen ? styles.dropdownOpen : ''
                }`}
              >
                <li>
                  <NavLink
                    to="/catalog/oblozhki"
                    className={({ isActive }) =>
                      isActive ? `${styles.link} ${styles.active}` : styles.link
                    }
                  >
                    Обложки для видео
                  </NavLink>
                </li>
                <li>
                  <NavLink
                    to="/catalog/avatarki"
                    className={({ isActive }) =>
                      isActive ? `${styles.link} ${styles.active}` : styles.link
                    }
                  >
                    Аватарки для соцсетей
                  </NavLink>
                </li>
                <li>
                  <NavLink
                    to="/catalog/shablony"
                    className={({ isActive }) =>
                      isActive ? `${styles.link} ${styles.active}` : styles.link
                    }
                  >
                    Готовые шаблоны
                  </NavLink>
                </li>
              </ul>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/info/license"
                className={({ isActive }) =>
                  isActive ? `${styles.link} ${styles.active}` : styles.link
                }
              >
                Лицензия
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/info/faq"
                className={({ isActive }) =>
                  isActive ? `${styles.link} ${styles.active}` : styles.link
                }
              >
                FAQ
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/contacts"
                className={({ isActive }) =>
                  isActive ? `${styles.link} ${styles.active}` : styles.link
                }
              >
                Контакты
              </NavLink>
            </li>
          </ul>
        </nav>

        <Link to="/contacts" className={styles.cartButton}>
          <span className={styles.cartIcon} aria-hidden="true">🛒</span>
          <span>Запрос</span>
        </Link>
      </div>
    </header>
  );
};

export default Header;