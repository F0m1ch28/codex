import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Подвал сайта">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <div className={styles.logo}>Digital<span>Covers</span></div>
          <p>
            Цифровые графические решения для стримеров, блогеров и бизнеса. Мы создаем визуальный стиль, который помогает выделяться.
          </p>
        </div>

        <div className={styles.column}>
          <h4>Навигация</h4>
          <ul>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/catalog/oblozhki">Каталог обложек</Link></li>
            <li><Link to="/catalog/avatarki">Каталог аватарок</Link></li>
            <li><Link to="/catalog/shablony">Каталог шаблонов</Link></li>
            <li><Link to="/info/license">Лицензия</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Поддержка</h4>
          <ul>
            <li><Link to="/info/faq">FAQ</Link></li>
            <li><Link to="/contacts">Контакты</Link></li>
            <li><Link to="/legal/terms">Условия использования</Link></li>
            <li><Link to="/legal/privacy">Политика конфиденциальности</Link></li>
            <li><Link to="/legal/cookies">Политика cookies</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Контакты</h4>
          <address>
            <span>г. Москва, ул. Цифровая, д. 42, офис 101</span>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a>
          </address>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;