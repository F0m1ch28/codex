import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/HomePage';
import CoversCatalogPage from './pages/CoversCatalogPage';
import AvatarsCatalogPage from './pages/AvatarsCatalogPage';
import TemplatesCatalogPage from './pages/TemplatesCatalogPage';
import LicensePage from './pages/LicensePage';
import FaqPage from './pages/FaqPage';
import ContactsPage from './pages/ContactsPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import styles from './App.module.css';

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'auto'
    });
  }, [pathname]);

  return null;
};

const AppLayout = () => (
  <div className={styles.app}>
    <Header />
    <main className={styles.main}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/catalog/oblozhki" element={<CoversCatalogPage />} />
        <Route path="/catalog/avatarki" element={<AvatarsCatalogPage />} />
        <Route path="/catalog/shablony" element={<TemplatesCatalogPage />} />
        <Route path="/info/license" element={<LicensePage />} />
        <Route path="/info/faq" element={<FaqPage />} />
        <Route path="/contacts" element={<ContactsPage />} />
        <Route path="/legal/terms" element={<TermsPage />} />
        <Route path="/legal/privacy" element={<PrivacyPage />} />
        <Route path="/legal/cookies" element={<CookiePolicyPage />} />
      </Routes>
    </main>
    <Footer />
    <ScrollToTopButton />
    <CookieBanner />
  </div>
);

function App() {
  return (
    <Router basename="/">
      <ScrollToTopOnRoute />
      <AppLayout />
    </Router>
  );
}

export default App;