import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Политика использования cookies — DigitalCovers</title>
      <meta
        name="description"
        content="Информация о том, как DigitalCovers использует cookies и как можно управлять настройками."
      />
    </Helmet>
    <h1>Политика использования cookies</h1>
    <p>Последнее обновление: 01 мая 2024 года.</p>

    <section>
      <h2>1. Что такое cookies</h2>
      <p>
        Cookies — небольшие текстовые файлы, которые сохраняются в браузере и помогают сайту запоминать ваши предпочтения.
      </p>
    </section>

    <section>
      <h2>2. Какие cookies мы используем</h2>
      <ul>
        <li>Функциональные — обеспечивают корректную работу форм и навигации.</li>
        <li>Аналитические — анонимная статистика посещений для улучшения сервиса.</li>
      </ul>
    </section>

    <section>
      <h2>3. Управление cookies</h2>
      <p>
        Вы можете изменить согласие в баннере или настроить браузер для блокировки файлов. Обратите внимание, что отключение функциональных cookies может ограничить работу сайта.
      </p>
    </section>

    <section>
      <h2>4. Контакты</h2>
      <p>
        Вопросы по cookies направляйте на{' '}
        <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a>.
      </p>
    </section>
  </div>
);

export default CookiePolicyPage;