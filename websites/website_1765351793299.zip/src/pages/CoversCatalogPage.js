import React from 'react';
import { Helmet } from 'react-helmet-async';
import CatalogGrid from '../components/CatalogGrid';

const coverItems = [
  {
    id: 'cover-neon-wave',
    title: 'Neon Wave Cover',
    description: 'Градиентная обложка с динамическими линиями и контрастной типографикой для роликов в жанре tech.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    tags: ['YouTube', '4K', 'PSD']
  },
  {
    id: 'cover-synth',
    title: 'Synth Skyline',
    description: 'Сочетание 3D-силуэтов и эффектов глитча для музыкальных и игровых каналов.',
    image: 'https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=1200&q=80',
    tags: ['Music', 'After Effects']
  },
  {
    id: 'cover-abstract',
    title: 'Abstract Pulse',
    description: 'Минималистичная композиция с воздушными формами и мягкими тенями для блогов о дизайне.',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80',
    tags: ['Creative', 'Figma']
  },
  {
    id: 'cover-digital',
    title: 'Digital Spectrum',
    description: 'Палитра глубоких оттенков и четкая сетка для образовательных и аналитических роликов.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80',
    tags: ['Education', 'Premiere']
  },
  {
    id: 'cover-future',
    title: 'Future Grid',
    description: 'Обложка с акцентом на технологичность, геометрией и неоновым свечением.',
    image: 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?auto=format&fit=crop&w=1200&q=80',
    tags: ['Tech', '4K']
  },
  {
    id: 'cover-calm',
    title: 'Calm Creator',
    description: 'Спокойная и чистая композиция, идеально подходящая для образовательных курсов и вебинаров.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    tags: ['Course', 'Keynote']
  }
];

const CoversCatalogPage = () => (
  <>
    <Helmet>
      <title>Каталог обложек — DigitalCovers</title>
      <meta
        name="description"
        content="Цифровые обложки для видео: неоновые, минималистичные и современные решения с готовыми слоями."
      />
    </Helmet>
    <CatalogGrid
      title="Каталог обложек"
      description="Готовые обложки для YouTube, Twitch и других видеоплатформ. Все элементы структурированы по слоям и готовы к настройке."
      items={coverItems}
    />
  </>
);

export default CoversCatalogPage;