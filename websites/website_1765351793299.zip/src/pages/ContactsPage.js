import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactsPage.module.css';

const ContactsPage = () => {
  const [formState, setFormState] = React.useState({
    name: '',
    email: '',
    message: ''
  });
  const [status, setStatus] = React.useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('Спасибо! Мы получили ваш запрос и свяжемся в ближайшее время.');
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Контакты — DigitalCovers</title>
        <meta
          name="description"
          content="Свяжитесь с DigitalCovers: адрес, телефон, email и форма обратной связи для обсуждения проектов."
        />
      </Helmet>

      <section className={styles.info}>
        <h1>Связаться с нами</h1>
        <p>
          Расскажите о вашем проекте, и мы подберём подходящую подборку или подготовим индивидуальные материалы.
        </p>
        <div className={styles.contacts}>
          <div>
            <span>Телефон</span>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          </div>
          <div>
            <span>Email</span>
            <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a>
          </div>
          <div>
            <span>Адрес</span>
            <p>г. Москва, ул. Цифровая, д. 42, офис 101</p>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Отправить запрос</h2>
        <form onSubmit={handleSubmit} className={styles.form}>
          <label>
            Имя
            <input
              type="text"
              name="name"
              value={formState.name}
              onChange={handleChange}
              placeholder="Введите ваше имя"
              required
            />
          </label>
          <label>
            Email
            <input
              type="email"
              name="email"
              value={formState.email}
              onChange={handleChange}
              placeholder="name@example.com"
              required
            />
          </label>
          <label>
            Сообщение
            <textarea
              name="message"
              value={formState.message}
              onChange={handleChange}
              placeholder="Опишите задачу или укажите интересующий набор"
              rows="5"
              required
            />
          </label>
          <button type="submit">Отправить</button>
          {status && <p className={styles.status}>{status}</p>}
        </form>
      </section>
    </div>
  );
};

export default ContactsPage;