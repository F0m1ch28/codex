import React from 'react';
import { Helmet } from 'react-helmet-async';
import CatalogGrid from '../components/CatalogGrid';

const avatarItems = [
  {
    id: 'avatar-gradient',
    title: 'Gradient Glow Pack',
    description: 'Серия аватарок с гладкими градиентами и мягкими бликами для социальных сетей.',
    image: 'https://images.unsplash.com/photo-1504593811423-6dd665756598?auto=format&fit=crop&w=900&q=80',
    tags: ['Telegram', 'PNG']
  },
  {
    id: 'avatar-portrait',
    title: 'Portrait Highlight',
    description: 'Акцент на портрет, художественные мазки и текстуры для персональных брендов.',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=900&q=80',
    tags: ['TikTok', 'PSD']
  },
  {
    id: 'avatar-cyber',
    title: 'Cyber Persona',
    description: 'Неоновая эстетика, цифровые паттерны и плотные цветовые блоки.',
    image: 'https://images.unsplash.com/photo-1502767089025-6572583495b0?auto=format&fit=crop&w=900&q=80',
    tags: ['Gaming', 'SVG']
  },
  {
    id: 'avatar-abstract',
    title: 'Abstract Lines',
    description: 'Минималистичные линии и объемные формы для бизнес-аккаунтов и стартапов.',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=900&q=80',
    tags: ['LinkedIn', 'Figma']
  },
  {
    id: 'avatar-illustration',
    title: 'Illustration Duo',
    description: 'Пара персонажей с различными эмоциями для IG, VK и Telegram каналов.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80',
    tags: ['Instagram', 'Procreate']
  },
  {
    id: 'avatar-metallic',
    title: 'Metallic Shine',
    description: 'Глянцевые эффекты и объемные бликовки, создающие премиальное ощущение.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80',
    tags: ['Discord', 'PNG']
  }
];

const AvatarsCatalogPage = () => (
  <>
    <Helmet>
      <title>Каталог аватарок — DigitalCovers</title>
      <meta
        name="description"
        content="Пакеты аватарок для соцсетей и стриминговых платформ. Готовые решения в форматах PNG, PSD, SVG."
      />
    </Helmet>
    <CatalogGrid
      title="Каталог аватарок"
      description="Подчеркните индивидуальность: аватарки для TikTok, Telegram, Discord и корпоративных профилей."
      items={avatarItems}
    />
  </>
);

export default AvatarsCatalogPage;