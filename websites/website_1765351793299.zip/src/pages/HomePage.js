import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import ProductCard from '../components/ProductCard';
import styles from './HomePage.module.css';

const categories = [
  {
    id: 'category-covers',
    title: 'Обложки для видео',
    description: 'Авторские цифровые обложки, которые усиливают ваш брендинг на YouTube, Twitch и VK Видео.',
    link: '/catalog/oblozhki',
    image: 'https://images.unsplash.com/photo-1618005198919-d3d4b5a92eee?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'category-avatars',
    title: 'Аватарки для соцсетей',
    description: 'Профессиональные аватарки для TikTok, Telegram, Discord и любых социальных сетей.',
    link: '/catalog/avatarki',
    image: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'category-templates',
    title: 'Готовые шаблоны',
    description: 'Слайды, шапки каналов и элементы для трансляций в адаптивных форматах PSD/FIG.',
    link: '/catalog/shablony',
    image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=800&q=80'
  }
];

const popularItems = [
  {
    id: 'popular-neon',
    title: 'Neon Stream Intro',
    description: 'Минималистичная обложка с неоновой подсветкой и контрастной типографикой.',
    image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=900&q=80',
    tags: ['YouTube', 'Full HD']
  },
  {
    id: 'popular-avatar',
    title: 'Creator Avatar Set',
    description: 'Набор из 5 вариаций аватарок для единого визуального стиля.',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80',
    tags: ['Telegram', 'Discord']
  },
  {
    id: 'popular-template',
    title: 'Live Overlay Kit',
    description: 'Универсальные оверлеи для стрим-платформ с адаптивными зонами.',
    image: 'https://images.unsplash.com/photo-1580894908361-967195033215?auto=format&fit=crop&w=900&q=80',
    tags: ['Twitch', 'Stream']
  },
  {
    id: 'popular-cover',
    title: 'Digital Pulse Cover',
    description: 'Динамичная композиция с 3D-элементами и глубокими тенями.',
    image: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=900&q=80',
    tags: ['YouTube', 'Premiere']
  }
];

const steps = [
  {
    id: 'step-01',
    title: 'Выберите дизайн',
    description: 'Откройте каталог и отберите решения, которые подходят вашему стилю.'
  },
  {
    id: 'step-02',
    title: 'Оформите запрос',
    description: 'Оставьте контакты и укажите, где планируете использовать материалы.'
  },
  {
    id: 'step-03',
    title: 'Получите файл',
    description: 'Мы отправим архив сразу после обработки запроса. Все файлы готовы к редактированию.'
  }
];

const benefits = [
  {
    id: 'benefit-quality',
    title: 'Высокое качество',
    description: 'Все макеты подготовлены в разрешении 4К и выше, аккуратные сетки и аккуратные слои.'
  },
  {
    id: 'benefit-speed',
    title: 'Мгновенная доставка',
    description: 'После подтверждения лицензии вы получаете ссылку на скачивание в течение нескольких минут.'
  },
  {
    id: 'benefit-license',
    title: 'Простая лицензия',
    description: 'Прозрачные условия использования для личных и коммерческих проектов без скрытых платежей.'
  }
];

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>DigitalCovers — обложки, аватарки и шаблоны для контента</title>
        <meta
          name="description"
          content="Профессиональные обложки для видео, аватарки и шаблоны DigitalCovers. Готовые графические решения для блогеров, стримеров и брендов."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Профессиональные обложки и аватарки для вашего контента</h1>
          <p>
            DigitalCovers помогает креаторам выделяться. Подберите готовые макеты или создайте единый визуальный стиль для всех площадок.
          </p>
          <div className={styles.heroActions}>
            <Link to="/catalog/oblozhki" className={styles.primaryButton}>
              Смотреть каталог
            </Link>
            <Link to="/info/license" className={styles.secondaryButton}>
              Условия лицензии
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.categories}>
        <div className={styles.sectionHeader}>
          <h2>Категории</h2>
          <p>Быстрая навигация по основным направлениям графики.</p>
        </div>
        <div className={styles.categoryGrid}>
          {categories.map((category) => (
            <article key={category.id} className={styles.categoryCard}>
              <div
                className={styles.categoryImage}
                style={{ backgroundImage: `url(${category.image})` }}
                role="img"
                aria-label={category.title}
              />
              <div className={styles.categoryContent}>
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <Link to={category.link}>Перейти</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.popular}>
        <div className={styles.sectionHeader}>
          <h2>Популярные подборки</h2>
          <p>Лучшие решения недели — уже подготовлены в форматах PSD, Figma и PNG.</p>
        </div>
        <div className={styles.popularGrid}>
          {popularItems.map((item) => (
            <ProductCard key={item.id} {...item} />
          ))}
        </div>
        <div className={styles.sectionFooter}>
          <Link to="/catalog/oblozhki" className={styles.primaryButton}>
            В каталог
          </Link>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Как это работает</h2>
          <p>Три простых шага, чтобы получить готовые материалы и сразу запустить проект.</p>
        </div>
        <div className={styles.stepGrid}>
          {steps.map((step, index) => (
            <div key={step.id} className={styles.stepCard}>
              <span className={styles.stepIndex}>0{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHeader}>
          <h2>Почему DigitalCovers</h2>
          <p>Мы объединяем дизайн, технологичность и поддержку.</p>
        </div>
        <div className={styles.benefitGrid}>
          {benefits.map((benefit) => (
            <article key={benefit.id} className={styles.benefitCard}>
              <h3>{benefit.title}</h3>
              <p>{benefit.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Нужен персональный стиль?</h2>
          <p>
            Расскажите о своем проекте, и мы предложим подборку материалов или подготовим эксклюзивные макеты под ваши задачи.
          </p>
          <Link to="/contacts" className={styles.primaryButton}>
            Связаться с нами
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;