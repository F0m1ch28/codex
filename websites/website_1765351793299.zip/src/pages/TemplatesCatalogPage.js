import React from 'react';
import { Helmet } from 'react-helmet-async';
import CatalogGrid from '../components/CatalogGrid';

const templateItems = [
  {
    id: 'template-presentation',
    title: 'Pitch Deck Flow',
    description: '20 слайдов с продуманной типографикой для стартап-презентаций.',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    tags: ['Keynote', 'Figma']
  },
  {
    id: 'template-stream',
    title: 'Streaming Overlay',
    description: 'Комплект сцен для стримов: старт, перерыв, основная трансляция.',
    image: 'https://images.unsplash.com/photo-1483478550801-ceba5fe50e8e?auto=format&fit=crop&w=1200&q=80',
    tags: ['OBS', 'PNG']
  },
  {
    id: 'template-social',
    title: 'Social Pulse Kit',
    description: 'Пакет постов и сторис для Instagram и VK с адаптивной сеткой.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    tags: ['Instagram', 'PSD']
  },
  {
    id: 'template-webinar',
    title: 'Webinar Promo',
    description: 'Шаблоны для продвижения вебинаров с различными блоками CTA.',
    image: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=1200&q=80',
    tags: ['Canva', 'PNG']
  },
  {
    id: 'template-brand',
    title: 'Brand Starter',
    description: 'Базовый брендбук: логотип, шаблоны постов, презентация.',
    image: 'https://images.unsplash.com/photo-1483478550801-ceba5fe50e8e?auto=format&fit=crop&w=1200&q=80',
    tags: ['Branding', 'Figma']
  },
  {
    id: 'template-podcast',
    title: 'Podcast Pack',
    description: 'Обложки и аудиограммы для подкастов, включающие версии для всех платформ.',
    image: 'https://images.unsplash.com/photo-1526402468533-4c8b5d5a2662?auto=format&fit=crop&w=1200&q=80',
    tags: ['Podcast', 'Premiere']
  }
];

const TemplatesCatalogPage = () => (
  <>
    <Helmet>
      <title>Каталог шаблонов — DigitalCovers</title>
      <meta
        name="description"
        content="Шаблоны презентаций, стрим-оверлеев и социального контента. Готовые наборы для быстрого запуска."
      />
    </Helmet>
    <CatalogGrid
      title="Каталог шаблонов"
      description="Комплексные пакеты: презентации, оверлеи, соцсети. Создано для ускорения вашей работы и единого стиля."
      items={templateItems}
    />
  </>
);

export default TemplatesCatalogPage;