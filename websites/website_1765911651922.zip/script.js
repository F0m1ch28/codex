document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('nav ul');

  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      navList.classList.toggle('open');
    });

    navList.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navList.classList.remove('open');
      });
    });
  }

  const banner = document.querySelector('[data-cookie-banner]');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const cookieKey = 'yandexGameCookiePreference';

  if (banner && acceptBtn && declineBtn) {
    const preference = localStorage.getItem(cookieKey);
    if (!preference) {
      banner.classList.add('active');
    }

    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'accepted');
      banner.classList.remove('active');
    });

    declineBtn.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'declined');
      banner.classList.remove('active');
    });
  }

  const gameRoot = document.querySelector('[data-game-root]');
  if (!gameRoot) {
    return;
  }

  const questions = [
    {
      question: 'Сценарий: вы отвечаете за главную страницу поиска. Какой сигнал вы усиливаете в ранжировании при росте мобильного трафика?',
      options: [
        'Увеличение веса коротких текстовых ответов и сниппетов',
        'Отдача приоритета длинным экспертным статьям',
        'Снижение роли локализации результатов',
        'Полный отказ от колдунщиков'
      ],
      correctIndex: 0,
      explanation: 'Мобильные пользователи ждут быстрых и ёмких ответов. Яндекс усиливает короткие текстовые блоки, быстрые сниппеты и колдунщики с мгновенными ответами.'
    },
    {
      question: 'Навигация в Яндекс.Картах: что в первую очередь влияет на выбор маршрута пользователю?',
      options: [
        'Количество поворотов и сложность маршрута',
        'Историческая предсказуемость пробок в этот же период',
        'Наличие платных дорог на пути',
        'Текущие оценки пользователей за конкретные участки'
      ],
      correctIndex: 1,
      explanation: 'Яндекс строит маршруты на основе прогноза пробок и аккумулированных данных о нагрузке дорог. Исторические данные критичны для точности ETA.'
    },
    {
      question: 'Алиса: какой подход поможет повысить удовлетворённость навыком?',
      options: [
        'Снижать количество запросов к серверу за счёт кеширования',
        'Сегментировать пользователей по тону речи и подстраивать ответы',
        'Использовать единый сценарий общения для всех',
        'Ограничить количество вариантов ответа для упрощения'
      ],
      correctIndex: 1,
      explanation: 'Контекстная персонализация и адаптация тона общения под пользователя — сильная сторона Алисы. Это повышает удовлетворённость и удержание.'
    },
    {
      question: 'Рекомендации в Дзене: какую метрику оптимизируем на первом этапе?',
      options: [
        'Глубину скролла материала',
        'Количество комментариев',
        'CTR карточки рекомендованного контента',
        'Количество подписок на автора'
      ],
      correctIndex: 2,
      explanation: 'CTR карточки — основной сигнал релевантности и качества выдачи в подписочной ленте. Остальные метрики подключаются позже.'
    },
    {
      question: 'Проводите A/B-тест в Маркете. Как обеспечить корректность?',
      options: [
        'Разделить пользователей по региону на две группы',
        'Запустить тест только на новых пользователей',
        'Использовать рандомизацию и проверку базовых метрик перед запуском',
        'Отбирать группу вручную из лояльных покупателей'
      ],
      correctIndex: 2,
      explanation: 'Строгая рандомизация и валидация контрольных метрик до запуска — золотой стандарт тестирования в Яндексе.'
    }
  ];

  const questionText = gameRoot.querySelector('[data-question-text]');
  const optionsContainer = gameRoot.querySelector('[data-options]');
  const nextButton = gameRoot.querySelector('[data-next]');
  const progressBar = gameRoot.querySelector('[data-progress-bar]');
  const questionIndexEl = gameRoot.querySelector('[data-question-index]');
  const questionTotalEl = gameRoot.querySelector('[data-question-total]');
  const scoreEl = gameRoot.querySelector('[data-score]');
  const accuracyEl = gameRoot.querySelector('[data-accuracy]');
  const streakEl = gameRoot.querySelector('[data-streak]');
  const resultPanel = gameRoot.querySelector('[data-result-panel]');
  const resultSummary = gameRoot.querySelector('[data-result-summary]');
  const restartButton = gameRoot.querySelector('[data-restart]');

  let shuffledQuestions = [];
  let currentIndex = 0;
  let score = 0;
  let correctAnswers = 0;
  let streak = 0;
  let bestStreak = 0;

  questionTotalEl.textContent = questions.length.toString();

  function shuffle(array) {
    return array
      .map(item => ({ sort: Math.random(), value: item }))
      .sort((a, b) => a.sort - b.sort)
      .map(item => item.value);
  }

  function resetGame() {
    shuffledQuestions = shuffle(questions);
    currentIndex = 0;
    score = 0;
    correctAnswers = 0;
    streak = 0;
    bestStreak = 0;
    resultPanel.classList.remove('active');
    nextButton.disabled = true;
    updateScoreboard();
    renderQuestion();
  }

  function updateScoreboard() {
    scoreEl.textContent = score.toString();
    questionIndexEl.textContent = (currentIndex + 1).toString();
    const accuracy = currentIndex === 0 ? 0 : Math.round((correctAnswers / currentIndex) * 100);
    accuracyEl.textContent = accuracy + '%';
    streakEl.textContent = streak.toString();
    const progressPercent = Math.round((currentIndex / questions.length) * 100);
    progressBar.style.width = progressPercent + '%';
  }

  function renderQuestion() {
    const currentQuestion = shuffledQuestions[currentIndex];
    questionText.textContent = currentQuestion.question;
    optionsContainer.innerHTML = '';

    currentQuestion.options.forEach((option, index) => {
      const button = document.createElement('button');
      button.className = 'option-button';
      button.type = 'button';
      button.textContent = option;
      button.dataset.optionIndex = index;
      button.addEventListener('click', handleOptionSelect);
      optionsContainer.appendChild(button);
    });
  }

  function handleOptionSelect(event) {
    const selectedButton = event.currentTarget;
    const selectedIndex = Number(selectedButton.dataset.optionIndex);
    const currentQuestion = shuffledQuestions[currentIndex];
    const isCorrect = selectedIndex === currentQuestion.correctIndex;

    optionsContainer.querySelectorAll('.option-button').forEach(button => {
      button.disabled = true;
      const optionIdx = Number(button.dataset.optionIndex);
      if (optionIdx === currentQuestion.correctIndex) {
        button.classList.add('correct');
      } else if (optionIdx === selectedIndex) {
        button.classList.add('incorrect');
      }
    });

    if (isCorrect) {
      correctAnswers += 1;
      streak += 1;
      bestStreak = Math.max(bestStreak, streak);
      score += 100 + Math.max(0, 20 - currentIndex * 2);
    } else {
      streak = 0;
    }

    nextButton.disabled = false;
    resultPanel.classList.remove('active');
    updateScoreboard();
  }

  nextButton.addEventListener('click', () => {
    currentIndex += 1;
    if (currentIndex >= shuffledQuestions.length) {
      finishGame();
      return;
    }
    nextButton.disabled = true;
    renderQuestion();
    updateScoreboard();
  });

  function finishGame() {
    const accuracy = Math.round((correctAnswers / questions.length) * 100);
    const summaryText = [
      `Вы набрали ${score} баллов из возможных ${questions.length * 100}.`,
      `Точность ответов — ${accuracy}% при лучшей серии ${bestStreak} вопросов подряд.`,
      `Главный инсайт: ${generateInsight(accuracy)}`
    ].join(' ');
    resultSummary.textContent = summaryText;
    resultPanel.classList.add('active');
    progressBar.style.width = '100%';
  }

  function generateInsight(accuracy) {
    if (accuracy >= 80) {
      return 'ваше мышление почти совпадает с продуктовым подходом Яндекса — отличная работа!';
    }
    if (accuracy >= 60) {
      return 'вы близки к идеалу, сосредоточьтесь на сценариях рекомендаций и персонализации.';
    }
    if (accuracy >= 40) {
      return 'стоит уделить внимание аналитике данных и A/B-тестам — это ускорит рост точности.';
    }
    return 'попробуйте ещё раз: изучите объяснения после игры и сравните свои решения с подходом Яндекса.';
  }

  if (restartButton) {
    restartButton.addEventListener('click', () => {
      resetGame();
      window.scrollTo({ top: gameRoot.offsetTop - 120, behavior: 'smooth' });
    });
  }

  resetGame();
});