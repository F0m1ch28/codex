import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | TechSolutions</title>
        <meta
          name="description"
          content="Review the TechSolutions terms of use governing our website, services, and engagement with clients."
        />
        <meta
          name="keywords"
          content="TechSolutions terms of use, legal terms, IT consulting terms"
        />
      </Helmet>
      <section className={styles.page}>
        <h1>Terms of Use</h1>
        <p>Last updated: March 1, 2024</p>
        <p>
          These Terms of Use (“Terms”) govern your access to and use of the TechSolutions website,
          content, and services (collectively, the “Services”). By accessing our Services, you agree to
          comply with these Terms. If you do not agree, do not use the Services.
        </p>
        <h2>1. Eligibility</h2>
        <p>
          You represent that you are authorized to enter into these Terms on behalf of yourself or the
          organization you represent. The Services are intended for business use and not for consumers
          acting outside their trade, business, or profession.
        </p>
        <h2>2. Intellectual property</h2>
        <p>
          All content, trademarks, and intellectual property featured on the Services are owned by
          TechSolutions or our licensors. You may not reproduce, distribute, or create derivative works
          without prior written consent.
        </p>
        <h2>3. Acceptable use</h2>
        <p>
          You agree not to misuse the Services, including by attempting unauthorized access, disrupting
          functionality, or transmitting malicious code. TechSolutions may suspend access for violations
          of these Terms.
        </p>
        <h2>4. Third-party links</h2>
        <p>
          The Services may reference third-party sites for convenience. TechSolutions is not responsible
          for the content or practices of such sites and encourages users to review their policies.
        </p>
        <h2>5. Disclaimer</h2>
        <p>
          The Services are provided “as is” without warranties of any kind. TechSolutions disclaims all
          implied warranties to the fullest extent permitted by law. We do not guarantee uninterrupted or
          error-free operation of the Services.
        </p>
        <h2>6. Limitation of liability</h2>
        <p>
          To the maximum extent permitted by law, TechSolutions shall not be liable for indirect,
          incidental, special, or consequential damages arising from your use of the Services.
        </p>
        <h2>7. Governing law</h2>
        <p>
          These Terms are governed by the laws of the jurisdiction where TechSolutions is headquartered,
          without regard to conflict of law provisions.
        </p>
        <h2>8. Changes</h2>
        <p>
          We may update these Terms from time to time. Continued use of the Services following changes
          constitutes acceptance of the revised Terms.
        </p>
        <h2>9. Contact</h2>
        <p>
          For questions about these Terms, contact TechSolutions at info@techsolutions.com or +1 (555)
          123-4567.
        </p>
      </section>
    </>
  );
};

export default Terms;