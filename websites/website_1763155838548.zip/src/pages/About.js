import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const About = () => {
  return (
    <>
      <Helmet>
        <title>About TechSolutions | IT Consulting Experts</title>
        <meta
          name="description"
          content="Learn about TechSolutions, our leadership approach, and how we deliver IT consulting, cybersecurity, and cloud solutions for global enterprises."
        />
        <meta
          name="keywords"
          content="About TechSolutions, IT consultants, cybersecurity experts, cloud consultants, technology leadership"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Technical excellence meets business accountability.</h1>
          <p>
            TechSolutions was founded to bridge the gap between visionary strategy and real-world
            execution. We bring seasoned practitioners who have navigated mission-critical programs,
            scaling initiatives across cloud, cyber, and data ecosystems.
          </p>
        </div>
      </section>

      <section className={styles.story}>
        <div className={styles.storyText}>
          <h2>Our story</h2>
          <p>
            We started as a small group of enterprise architects who believed transformation should be
            both ambitious and grounded. Today, we serve clients across North America and Europe,
            advising executives on how to modernize with resilience while building empowered teams.
          </p>
          <p>
            Our consultants thrive on complex environments—heavily regulated industries, global
            footprints, and advanced technologies that demand precision. By embedding alongside client
            teams, we co-create solutions that deliver immediate impact and lasting capability uplift.
          </p>
        </div>
        <img
          src="https://picsum.photos/800/600?random=32"
          alt="TechSolutions leadership team meeting"
          className={styles.storyImage}
        />
      </section>

      <section className={styles.values}>
        <h2>What guides our partnerships</h2>
        <div className={styles.valuesGrid}>
          <article className={styles.valueCard}>
            <h3>Integrity in delivery</h3>
            <p>
              Transparency, measurable goals, and an unwavering focus on business outcomes form the
              backbone of every engagement.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Engineering rigour</h3>
            <p>
              We apply robust design principles, peer reviews, and automation to reduce risk and
              accelerate results.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Capability transfer</h3>
            <p>
              By mentoring internal teams, we ensure organizations can sustain and evolve solutions
              long after go-live.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.focus}>
        <div className={styles.focusContent}>
          <h2>Focus sectors</h2>
          <p>
            We advise enterprises with demanding operating conditions and security requirements. Our
            consultants are specialized across:
          </p>
          <ul>
            <li>Financial services and fintech platforms</li>
            <li>Healthcare networks and life sciences innovators</li>
            <li>Manufacturing and smart industry ecosystems</li>
            <li>Digital-native scale-ups expanding globally</li>
          </ul>
        </div>
        <div className={styles.focusImageWrapper}>
          <img
            src="https://picsum.photos/700/650?random=42"
            alt="Technology infrastructure and digital networks"
            className={styles.focusImage}
          />
        </div>
      </section>
    </>
  );
};

export default About;