import React from "react";
import { Helmet } from "react-helmet";
import styles from "./CookiePolicy.module.css";

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | TechSolutions</title>
        <meta
          name="description"
          content="TechSolutions Cookie Policy explains how we use cookies and similar technologies to enhance your experience."
        />
        <meta
          name="keywords"
          content="TechSolutions cookie policy, cookies, tracking technologies"
        />
      </Helmet>
      <section className={styles.page}>
        <h1>Cookie Policy</h1>
        <p>Effective date: March 1, 2024</p>
        <p>
          This Cookie Policy explains how TechSolutions uses cookies and similar technologies when you
          visit our website. By continuing to browse, you accept the use of cookies as described here.
        </p>
        <h2>1. What are cookies?</h2>
        <p>
          Cookies are small text files stored on your device by your browser. They help us remember your
          preferences, understand site usage, and improve performance.
        </p>
        <h2>2. Types of cookies we use</h2>
        <ul>
          <li><strong>Essential cookies:</strong> Required for core site functionality.</li>
          <li><strong>Analytics cookies:</strong> Help us measure traffic and usage patterns.</li>
          <li><strong>Preference cookies:</strong> Remember language and layout choices.</li>
        </ul>
        <h2>3. Managing cookies</h2>
        <p>
          You can control cookies through your browser settings. Disabling cookies may affect certain
          functionalities. Visit <a href="https://www.allaboutcookies.org/">allaboutcookies.org</a> for
          guidance.
        </p>
        <h2>4. Third-party cookies</h2>
        <p>
          Our analytics partners may place cookies to provide aggregated metrics. These cookies do not
          identify individuals.
        </p>
        <h2>5. Updates</h2>
        <p>
          We may revise this policy periodically. Material changes will be communicated through the
          cookie banner or website notice.
        </p>
        <h2>6. Contact</h2>
        <p>
          For questions about cookies, contact info@techsolutions.com or +1 (555) 123-4567.
        </p>
      </section>
    </>
  );
};

export default CookiePolicy;