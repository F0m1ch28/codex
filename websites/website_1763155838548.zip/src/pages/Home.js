import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const Home = () => {
  return (
    <>
      <Helmet>
        <title>TechSolutions | IT Consulting & Digital Transformation</title>
        <meta
          name="description"
          content="TechSolutions delivers IT consulting, cloud modernization, cybersecurity, and digital transformation services that help enterprises scale with confidence."
        />
        <meta
          name="keywords"
          content="IT consulting, cloud modernization, cybersecurity, cyber resilience, digital transformation, technology strategy, TechSolutions"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1 className={styles.title}>
            Accelerate digital ambitions with a trusted IT consulting partner.
          </h1>
          <p className={styles.description}>
            We empower technology leaders with strategy, architecture, and execution across cloud,
            cybersecurity, and modern engineering so innovation happens faster and safer.
          </p>
          <div className={styles.ctaGroup}>
            <Link to="/contact" className={styles.ctaPrimary}>
              Start a Conversation
            </Link>
            <Link to="/services" className={styles.ctaSecondary}>
              Explore Services
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/800/600?grayscale&random=12"
            alt="Technology consultants collaborating on strategy"
            className={styles.heroImage}
          />
        </div>
      </section>

      <section className={styles.ribbon}>
        <p>Trusted expertise spanning technology strategy, enterprise security, and cloud adoption.</p>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Core Consulting Practices</h2>
          <p>
            Designed for CIOs and digital leaders navigating complex transformation agendas across regulated and high-growth industries.
          </p>
        </div>
        <div className={styles.cardGrid}>
          <article className={styles.card}>
            <div className={styles.icon}>🧭</div>
            <h3>Technology Strategy</h3>
            <p>
              Align operating models and platforms with business outcomes through clear roadmaps,
              value metrics, and executive-ready governance playbooks.
            </p>
          </article>
          <article className={styles.card}>
            <div className={styles.icon}>☁️</div>
            <h3>Cloud Enablement</h3>
            <p>
              Modernize workloads, optimize costs, and implement resilient cloud-native architectures for hybrid and multi-cloud environments.
            </p>
          </article>
          <article className={styles.card}>
            <div className={styles.icon}>🛡️</div>
            <h3>Cybersecurity Programs</h3>
            <p>
              Strengthen cyber posture with proactive assessments, zero-trust methodologies, and 24/7 threat operations enablement.
            </p>
          </article>
          <article className={styles.card}>
            <div className={styles.icon}>⚙️</div>
            <h3>Automation & Data</h3>
            <p>
              Unlock intelligent automation, data governance, and analytics pipelines that scale insights across the enterprise.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.metrics}>
        <div className={styles.metric}>
          <span className={styles.metricNumber}>96%</span>
          <p>Client satisfaction across transformation programs.</p>
        </div>
        <div className={styles.metric}>
          <span className={styles.metricNumber}>18+</span>
          <p>Industries served through advisory, delivery, and managed services.</p>
        </div>
        <div className={styles.metric}>
          <span className={styles.metricNumber}>24/7</span>
          <p>Operational coverage for mission-critical security initiatives.</p>
        </div>
      </section>

      <section className={styles.about}>
        <div className={styles.aboutContent}>
          <h2>Pragmatic consultants with enterprise delivery DNA.</h2>
          <p>
            TechSolutions blends seasoned architects, security specialists, and program leaders who
            have delivered hundreds of global initiatives. Our teams embed with your organization to
            accelerate adoption, streamline handoffs, and ensure measurable outcomes from day one.
          </p>
          <ul className={styles.list}>
            <li>Executive advisory paired with hands-on engineering expertise.</li>
            <li>Proven playbooks for regulated industries and high-availability platforms.</li>
            <li>Collaborative delivery built around transparency and shared ownership.</li>
          </ul>
          <Link to="/about" className={styles.aboutLink}>
            Learn more about our story →
          </Link>
        </div>
        <img
          src="https://picsum.photos/700/600?random=22"
          alt="Team discussing digital transformation roadmap"
          className={styles.aboutImage}
        />
      </section>

      <section className={styles.testimonial}>
        <blockquote>
          “TechSolutions helped our leadership team define a credible roadmap for zero-trust adoption.
          Their ability to translate strategy into execution unlocked value in the first quarter.”
        </blockquote>
        <cite>Chief Information Security Officer, Global Financial Services Firm</cite>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Ready to accelerate your next transformation milestone?</h2>
          <p>
            Partner with consultants who combine strategic insight with delivery excellence. Fill out
            our contact form and we will respond within one business day.
          </p>
          <Link to="/contact" className={styles.ctaPrimary}>
            Contact TechSolutions
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;