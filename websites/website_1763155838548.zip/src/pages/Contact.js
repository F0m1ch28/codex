import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    message: "",
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your full name.";
    if (!formData.company.trim()) newErrors.company = "Please share your company or organization.";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = "Enter a valid email address.";
    }
    if (!formData.message.trim()) newErrors.message = "Let us know how we can assist.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData({ name: "", company: "", email: "", message: "" });
  };

  return (
    <>
      <Helmet>
        <title>Contact TechSolutions | IT Consulting Partner</title>
        <meta
          name="description"
          content="Contact TechSolutions to discuss IT consulting, cybersecurity, and cloud transformation initiatives. Reach our team in Tech City."
        />
        <meta
          name="keywords"
          content="Contact TechSolutions, IT consulting contact, cybersecurity inquiry, cloud consulting contact"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Connect with TechSolutions</h1>
          <p>
            Share your priorities and we will align the right experts to collaborate. Expect a response within one business day.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.info}>
          <h2>Our office</h2>
          <p>
            123 Innovation Street<br />
            Tech City, TC 10101
          </p>
          <h3>Call or email</h3>
          <p>
            Tel: <a href="tel:+15551234567">+1 (555) 123-4567</a><br />
            Email: <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
          </p>
          <p className={styles.note}>
            We support clients across time zones and can schedule workshops virtually or onsite.
          </p>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Full name *</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Taylor Morgan"
              value={formData.name}
              onChange={handleChange}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="company">Company *</label>
            <input
              id="company"
              name="company"
              type="text"
              placeholder="Organization"
              value={formData.company}
              onChange={handleChange}
            />
            {errors.company && <span className={styles.error}>{errors.company}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email *</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="you@company.com"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="message">How can we help? *</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Describe your initiative, timeline, and success criteria."
              value={formData.message}
              onChange={handleChange}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit" className={styles.submit}>
            Submit inquiry
          </button>
          {submitted && (
            <p className={styles.success}>
              Thank you. Our consultants will reach out shortly to coordinate next steps.
            </p>
          )}
        </form>
      </section>
    </>
  );
};

export default Contact;