import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Services | TechSolutions IT Consulting</title>
        <meta
          name="description"
          content="Discover TechSolutions services across IT consulting, cloud solutions, cybersecurity operations, and digital transformation delivery."
        />
        <meta
          name="keywords"
          content="IT consulting services, cloud enablement, cybersecurity operations, digital transformation, TechSolutions services"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <h1>Services engineered for measurable outcomes.</h1>
          <p>
            Every engagement is grounded in strategic alignment, technical rigor, and transparent
            delivery. Explore our consulting, engineering, and managed service offerings designed for
            complex enterprise environments.
          </p>
        </div>
      </section>

      <section className={styles.gridSection}>
        <article className={styles.serviceCard}>
          <div className={styles.header}>
            <h2>IT Strategy & Advisory</h2>
            <span>01</span>
          </div>
          <p>
            Roadmaps, operating models, and technology portfolio assessments that align investment to
            business value. We partner with executives to establish guardrails, define KPIs, and build
            the governance needed for scalable transformation.
          </p>
          <ul>
            <li>Enterprise architecture modernization</li>
            <li>PMO and portfolio optimization</li>
            <li>Innovation labs and rapid prototyping</li>
          </ul>
        </article>

        <article className={styles.serviceCard}>
          <div className={styles.header}>
            <h2>Cloud & Platform Engineering</h2>
            <span>02</span>
          </div>
          <p>
            Accelerate migration, container adoption, and platform engineering initiatives with proven
            patterns, IaC blueprints, and SRE-aligned practices. We ensure security, resilience, and
            observability are integrated from day zero.
          </p>
          <ul>
            <li>Cloud migration and landing zones</li>
            <li>DevSecOps and CI/CD automation</li>
            <li>Platform reliability engineering</li>
          </ul>
        </article>

        <article className={styles.serviceCard}>
          <div className={styles.header}>
            <h2>Cybersecurity & Risk</h2>
            <span>03</span>
          </div>
          <p>
            Build a resilient security posture through maturity assessments, zero-trust frameworks,
            and MDR programs. Our teams integrate with security operations to deliver actionable
            intelligence and continuous validation.
          </p>
          <ul>
            <li>Security operations uplift</li>
            <li>Identity and access governance</li>
            <li>Compliance automation</li>
          </ul>
        </article>

        <article className={styles.serviceCard}>
          <div className={styles.header}>
            <h2>Data & Intelligent Automation</h2>
            <span>04</span>
          </div>
          <p>
            Unlock the power of data with robust governance, analytics, and automation toolkits.
            From data lake strategy to intelligent process automation, we help teams deliver insights
            faster and with higher fidelity.
          </p>
          <ul>
            <li>Data platform engineering</li>
            <li>Advanced analytics and AI enablement</li>
            <li>Intelligent automation design</li>
          </ul>
        </article>
      </section>

      <section className={styles.process}>
        <div className={styles.processContent}>
          <h2>How we work</h2>
          <p>
            TechSolutions combines business-first thinking with deep technical execution. Our delivery
            model is anchored in collaborative workshops, transparent sprints, and embedded coaching to
            empower your teams long after we engage.
          </p>
          <div className={styles.steps}>
            <div className={styles.step}>
              <span>1</span>
              <h3>Discovery & Assessment</h3>
              <p>
                We synthesize stakeholder insights, platform diagnostics, and risk analyses to define
                scope, outcomes, and the roadmap.
              </p>
            </div>
            <div className={styles.step}>
              <span>2</span>
              <h3>Design & Alignment</h3>
              <p>
                Solution blueprints, architectural decisions, and change management plans are validated
                with business and technical leaders.
              </p>
            </div>
            <div className={styles.step}>
              <span>3</span>
              <h3>Delivery & Enablement</h3>
              <p>
                Cross-functional teams execute with continuous feedback loops, measurable KPIs, and
                knowledge transfer woven into every sprint.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;