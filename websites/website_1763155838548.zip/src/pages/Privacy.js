import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | TechSolutions</title>
        <meta
          name="description"
          content="Read the TechSolutions Privacy Policy to understand how we handle personal data for our IT consulting services."
        />
        <meta
          name="keywords"
          content="TechSolutions privacy policy, data protection, personal data, IT consulting privacy"
        />
      </Helmet>
      <section className={styles.page}>
        <h1>Privacy Policy</h1>
        <p>Effective date: March 1, 2024</p>
        <p>
          This Privacy Policy describes how TechSolutions (“we,” “us,” “our”) collects, uses, and
          protects information when you engage with our Services. We are committed to safeguarding the
          confidentiality and integrity of personal data.
        </p>
        <h2>1. Information we collect</h2>
        <p>
          We may collect personal data such as name, business contact details, role, and any
          information you choose to provide when contacting us. We also collect technical information
          including IP addresses, browser type, and usage metrics through analytics tools.
        </p>
        <h2>2. How we use information</h2>
        <p>
          Personal data is used to respond to inquiries, deliver services, manage client relationships,
          and improve our offerings. We may also use aggregated data for analytics, provided it does not
          identify individuals.
        </p>
        <h2>3. Legal basis</h2>
        <p>
          We process personal data based on legitimate interests in delivering IT consulting services
          and, where applicable, with your consent or to fulfill contractual obligations.
        </p>
        <h2>4. Data sharing</h2>
        <p>
          We do not sell personal data. We may share information with trusted partners who assist in
          service delivery, subject to confidentiality agreements. Data may be transferred to other
          jurisdictions when necessary for global operations.
        </p>
        <h2>5. Security</h2>
        <p>
          TechSolutions implements administrative, technical, and physical safeguards to protect data
          against unauthorized access, alteration, or disclosure.
        </p>
        <h2>6. Retention</h2>
        <p>
          We retain personal data only as long as necessary to fulfill the purposes outlined in this
          policy or to meet legal requirements.
        </p>
        <h2>7. Your rights</h2>
        <p>
          Depending on your jurisdiction, you may have rights to access, correct, or delete personal
          data, or to object to certain processing. Contact us at info@techsolutions.com to exercise
          these rights.
        </p>
        <h2>8. Cookies</h2>
        <p>
          We use cookies and similar technologies to enhance user experience and analyze site usage.
          Learn more in our Cookie Policy.
        </p>
        <h2>9. Updates</h2>
        <p>
          We may update this policy periodically. Changes will be posted on this page with a revised
          effective date.
        </p>
        <h2>10. Contact</h2>
        <p>
          Questions regarding privacy can be directed to info@techsolutions.com or +1 (555) 123-4567.
        </p>
      </section>
    </>
  );
};

export default Privacy;