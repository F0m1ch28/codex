import React from "react";
import { Link, NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const Header = ({ isNavOpen, setIsNavOpen }) => {
  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} onClick={() => setIsNavOpen(false)}>
          <span className={styles.logoAccent}>Tech</span>Solutions
        </Link>
        <button
          aria-label="Toggle navigation"
          className={`${styles.burger} ${isNavOpen ? styles.burgerActive : ""}`}
          onClick={() => setIsNavOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${isNavOpen ? styles.navOpen : ""}`}>
          <NavLink
            to="/"
            end
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
            onClick={() => setIsNavOpen(false)}
          >
            Home
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
            onClick={() => setIsNavOpen(false)}
          >
            Services
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
            onClick={() => setIsNavOpen(false)}
          >
            About
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
            onClick={() => setIsNavOpen(false)}
          >
            Contact
          </NavLink>
          <NavLink
            to="/terms"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
            onClick={() => setIsNavOpen(false)}
          >
            Terms
          </NavLink>
          <NavLink
            to="/privacy"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
            onClick={() => setIsNavOpen(false)}
          >
            Privacy
          </NavLink>
          <NavLink
            to="/cookie-policy"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}
            onClick={() => setIsNavOpen(false)}
          >
            Cookies
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;