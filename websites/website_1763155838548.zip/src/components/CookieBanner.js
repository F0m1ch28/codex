import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("techsolutions_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("techsolutions_cookie_consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner}>
      <p className={styles.text}>
        We use cookies to enhance site navigation, analyze usage, and support our marketing efforts.
        Review our <Link to="/cookie-policy">Cookie Policy</Link> for details.
      </p>
      <button className={styles.button} onClick={acceptCookies}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;