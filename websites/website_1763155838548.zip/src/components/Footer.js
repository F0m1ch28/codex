import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div>
          <h3 className={styles.title}>
            <span className={styles.titleAccent}>Tech</span>Solutions
          </h3>
          <p className={styles.subtitle}>
            Trusted partner for IT consulting, cloud acceleration, and cyber resilience.
          </p>
        </div>
        <div>
          <h4 className={styles.heading}>Visit Us</h4>
          <p className={styles.text}>123 Innovation Street<br />Tech City, TC 10101</p>
        </div>
        <div>
          <h4 className={styles.heading}>Connect</h4>
          <p className={styles.text}>
            Tel: <a href="tel:+15551234567">+1 (555) 123-4567</a><br />
            Email: <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
          </p>
        </div>
        <div className={styles.links}>
          <Link to="/terms" className={styles.link}>Terms</Link>
          <Link to="/privacy" className={styles.link}>Privacy</Link>
          <Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {year} TechSolutions. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;