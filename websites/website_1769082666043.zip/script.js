document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const submenuToggles = document.querySelectorAll(".submenu-toggle");
  const cookieBanner = document.querySelector(".cookie-banner");
  const toast = document.querySelector(".global-toast");
  const currentYearSpan = document.querySelectorAll("[data-current-year]");

  currentYearSpan.forEach(span => span.textContent = new Date().getFullYear());

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("is-open");
    });
  }

  submenuToggles.forEach(button => {
    button.addEventListener("click", () => {
      const expanded = button.getAttribute("aria-expanded") === "true";
      submenuToggles.forEach(btn => {
        if (btn !== button) {
          btn.setAttribute("aria-expanded", "false");
          btn.parentElement.classList.remove("open");
        }
      });
      button.setAttribute("aria-expanded", String(!expanded));
      button.parentElement.classList.toggle("open");
    });
  });

  document.querySelectorAll(".js-form").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      showToast("Procesando solicitud...");
      setTimeout(() => {
        window.location.href = form.getAttribute("action") || "exito.html";
      }, 1400);
    });
  });

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => toast.classList.remove("is-visible"), 2000);
  }

  const cookieKey = "odse_cookie";
  if (cookieBanner) {
    const stored = localStorage.getItem(cookieKey);
    if (!stored) {
      requestAnimationFrame(() => cookieBanner.classList.add("is-visible"));
    }
    cookieBanner.querySelectorAll("[data-cookie-action]").forEach(button => {
      button.addEventListener("click", () => {
        const action = button.dataset.cookieAction;
        localStorage.setItem(cookieKey, action);
        cookieBanner.classList.remove("is-visible");
        showToast(action === "accept" ? "Preferencias guardadas" : "Se registró su preferencia");
      });
    });
  }

  const timelineHome = document.getElementById("timeline-home");
  if (timelineHome) {
    const events = [
      { year: 2005, title: "Primer plan de telemedicina energética", text: "Pilotaje de coordinación energética-sanitaria en Madrid." },
      { year: 2010, title: "Estrategia renovable hospitalaria", text: "Integración de fotovoltaica en hospitales públicos de España." },
      { year: 2015, title: "IA clínica temprana", text: "Modelos predictivos para urgencias conectados a redes inteligentes." },
      { year: 2020, title: "Microredes resilientes", text: "Expansión de microredes hospitalarias en zonas rurales." },
      { year: 2024, title: "Datos federados IA", text: "Implementación de arquitecturas federadas energía-salud en varias comunidades." }
    ];
    events.forEach((event, index) => {
      const item = document.createElement("div");
      item.className = "timeline-item";
      item.innerHTML = `<strong>${event.year}</strong><span>${event.title}</span><p>${event.text}</p>`;
      timelineHome.appendChild(item);
      setTimeout(() => item.classList.add("is-visible"), index * 220);
    });
  }

  const mapStats = document.getElementById("map-statistics");
  const mapData = {
    general: [
      { label: "Hospitales conectados", value: 58 },
      { label: "Microredes", value: 43 },
      { label: "Alertas IA mensuales", value: 920 }
    ],
    energia: [
      { label: "Capacidad renovable (MW)", value: 1240 },
      { label: "Almacenamiento (MWh)", value: 420 },
      { label: "Microredes activas", value: 43 }
    ],
    salud: [
      { label: "Teleconsultas diarias", value: 4800 },
      { label: "Equipos monitorizados", value: 18500 },
      { label: "Centros con IA", value: 116 }
    ],
    ia: [
      { label: "Modelos federados", value: 74 },
      { label: "Laboratorios IA", value: 28 },
      { label: "Ensayos en curso", value: 19 }
    ]
  };

  const filterButtons = document.querySelectorAll("[data-map-filter]");
  if (mapStats) {
    const renderMapStats = key => {
      mapStats.innerHTML = "";
      mapData[key].forEach(item => {
        const block = document.createElement("div");
        block.className = "data-cluster";
        block.innerHTML = `<h3>${item.label}</h3><p>${Number(item.value).toLocaleString("es-ES")}</p>`;
        mapStats.appendChild(block);
      });
    };
    renderMapStats("general");
    filterButtons.forEach(button => {
      button.addEventListener("click", () => {
        filterButtons.forEach(btn => btn.classList.remove("is-active"));
        button.classList.add("is-active");
        renderMapStats(button.dataset.mapFilter);
      });
    });
  }

  const barAnimations = document.querySelectorAll(".chart-bar-fill");
  const values = {
    fv: 72,
    respaldo: 34,
    alertas: 56,
    quirf: 68,
    h2: 32,
    logistica: 75,
    marina: 46,
    calor: 58,
    datos: 80,
    resiliencia: 62,
    autonomia: 36,
    recuperacion: 54,
    ciudadanos: 21,
    autoconsumo: 42,
    ia: 41,
    centros: 68
  };
  barAnimations.forEach(bar => {
    const key = bar.dataset.chartKey;
    const target = values[key] || 50;
    requestAnimationFrame(() => {
      bar.style.width = `${target}%`;
    });
  });

  function updateDynamicBars() {
    barAnimations.forEach(bar => {
      const key = bar.dataset.chartKey;
      const base = values[key] || 50;
      const variation = Math.random() * 6 - 3;
      const result = Math.max(5, Math.min(100, base + variation));
      bar.style.width = `${result}%`;
    });
  }
  setInterval(updateDynamicBars, 6000);

  document.querySelectorAll("[data-carousel]").forEach(carousel => {
    const track = carousel.querySelector(".carousel-track");
    const slides = Array.from(track.children);
    const prev = carousel.querySelector('[data-carousel-action="prev"]');
    const next = carousel.querySelector('[data-carousel-action="next"]');
    let index = 0;

    const setSlide = newIndex => {
      index = (newIndex + slides.length) % slides.length;
      track.style.transform = `translateX(-${index * 100}%)`;
    };

    prev.addEventListener("click", () => setSlide(index - 1));
    next.addEventListener("click", () => setSlide(index + 1));
    setInterval(() => setSlide(index + 1), 8000);
  });

  document.querySelectorAll(".accordion-header").forEach(header => {
    header.addEventListener("click", () => toggleAccordion(header));
    header.addEventListener("keydown", event => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        toggleAccordion(header);
      }
    });
  });

  function toggleAccordion(header) {
    const item = header.parentElement;
    const open = item.classList.contains("is-open");
    document.querySelectorAll(".accordion-item").forEach(i => {
      if (i !== item) {
        i.classList.remove("is-open");
      }
    });
    item.classList.toggle("is-open", !open);
  }
});