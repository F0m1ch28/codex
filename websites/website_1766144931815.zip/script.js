(function () {
  const banner = document.getElementById("cookie-banner");
  if (!banner) {
    return;
  }
  const acceptButton = banner.querySelector(".cookie-accept");
  const declineButton = banner.querySelector(".cookie-decline");
  const storageKey = "usenr-cookie-preference";

  function setPreference(value) {
    try {
      localStorage.setItem(storageKey, value);
    } catch (error) {
      document.cookie = storageKey + "=" + value + ";path=/;max-age=" + 60 * 60 * 24 * 180;
    }
  }

  function getPreference() {
    try {
      return localStorage.getItem(storageKey);
    } catch (error) {
      const match = document.cookie.match(new RegExp("(^| )" + storageKey + "=([^;]+)"));
      return match ? match[2] : null;
    }
  }

  function hideBanner() {
    banner.classList.remove("active");
  }

  function showBanner() {
    banner.classList.add("active");
  }

  const savedPreference = getPreference();
  if (!savedPreference) {
    showBanner();
  }

  if (acceptButton) {
    acceptButton.addEventListener("click", function () {
      setPreference("accepted");
      hideBanner();
    });
  }

  if (declineButton) {
    declineButton.addEventListener("click", function () {
      setPreference("declined");
      hideBanner();
    });
  }
})();