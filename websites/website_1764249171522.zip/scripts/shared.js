document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  if (year) {
    year.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const storageKey = "apexvision-cookie-consent";

  if (cookieBanner && acceptBtn && declineBtn) {
    const consent = localStorage.getItem(storageKey);
    if (!consent) {
      cookieBanner.classList.add("active");
    }

    const handleConsent = (value) => {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.remove("active");
    };

    acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    declineBtn.addEventListener("click", () => handleConsent("declined"));
  }
});