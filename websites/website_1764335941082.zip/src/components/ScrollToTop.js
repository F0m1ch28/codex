import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { ArrowUpIcon } from '@heroicons/react/24/solid'; // <-- remove? wait dependency? We don't have heroicons dependency. need adjust.

Hold up: heroicons not included. Should not import. Instead create inline svg.

Need to adjust.

Let's rewrite:

 Need to modify file.

Replace from heroicons to inline.

Redo.