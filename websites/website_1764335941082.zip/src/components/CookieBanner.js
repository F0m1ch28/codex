import React, { useEffect, useState } from 'react';
import styles from '../styles/CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('novaterium_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (choice) => {
    window.localStorage.setItem('novaterium_cookie_consent', choice);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <p>
        Wir verwenden Cookies, um Dein Erlebnis zu verbessern. Technisch notwendige Cookies setzen wir immer ein. Weitere
        Infos findest Du in unserer{' '}
        <a href="/privacy" className={styles.link}>
          Datenschutzerklärung
        </a>{' '}
        und in der{' '}
        <a href="/cookies" className={styles.link}>
          Cookie-Richtlinie
        </a>
        .
      </p>
      <div className={styles.actions}>
        <button type="button" className="secondaryButton" onClick={() => handleConsent('declined')}>
          Ablehnen
        </button>
        <button type="button" className="primaryButton" onClick={() => handleConsent('accepted')}>
          Akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;