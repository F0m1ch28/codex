import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from '../styles/Header.module.css';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen((prev) => !prev);
  const closeMenu = () => setIsOpen(false);

  return (
    <header className={styles.header} aria-label="Hauptnavigation">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoAccent}>Nova</span>terium
        </NavLink>
        <nav className={`${styles.nav} ${isOpen ? styles.open : ''}`} aria-label="Primäre Navigation">
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : undefined)}>
            Start
          </NavLink>
          <NavLink
            to="/about"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          >
            Über uns
          </NavLink>
          <NavLink
            to="/services"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          >
            Angebote
          </NavLink>
          <NavLink
            to="/guide"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          >
            Leitfaden
          </NavLink>
          <NavLink
            to="/programs"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          >
            Programme
          </NavLink>
          <NavLink
            to="/tools"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          >
            Tools
          </NavLink>
          <NavLink
            to="/blog"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          >
            Blog
          </NavLink>
          <NavLink
            to="/contact"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          >
            Kontakt
          </NavLink>
        </nav>
        <button
          className={`${styles.burger} ${isOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          type="button"
          aria-label="Navigation umschalten"
          aria-expanded={isOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;