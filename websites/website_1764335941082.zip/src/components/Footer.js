import React from 'react';
import { Link } from 'react-router-dom';
import styles from '../styles/Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Website Fußbereich">
      <div className={styles.container}>
        <div className={styles.brand}>
          <h3>Novaterium</h3>
          <p>
            Wir begleiten Dich empathisch und praxisnah durch Orientierung, Bewerbungsphase und Einstieg in den deutschen
            Arbeitsmarkt.
          </p>
          <p className={styles.disclaimer}>
            Kein Ersatz für rechtliche, finanzielle oder steuerliche Beratung. Wir geben keine Job-Garantie, sondern
            stärken Deine Chancen mit Wissen, Struktur und Motivation.
          </p>
        </div>
        <div className={styles.column}>
          <h4>Navigation</h4>
          <ul>
            <li>
              <Link to="/">Start</Link>
            </li>
            <li>
              <Link to="/about">Über uns</Link>
            </li>
            <li>
              <Link to="/services">Angebote</Link>
            </li>
            <li>
              <Link to="/guide">Leitfaden</Link>
            </li>
            <li>
              <Link to="/programs">Programme</Link>
            </li>
            <li>
              <Link to="/tools">Tools</Link>
            </li>
            <li>
              <Link to="/contact">Kontakt</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Rechtliches</h4>
          <ul>
            <li>
              <Link to="/legal">AGB</Link>
            </li>
            <li>
              <Link to="/privacy">Datenschutz</Link>
            </li>
            <li>
              <Link to="/imprint">Impressum</Link>
            </li>
            <li>
              <Link to="/cookies">Cookie-Richtlinie</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Kontakt</h4>
          <p>Novaterium GmbH i. Gr.</p>
          <p>Musterstraße 12, 10115 Berlin</p>
          <p>
            E-Mail:{' '}
            <a href="mailto:hallo@novaterium.de" className={styles.contactLink}>
              hallo@novaterium.de
            </a>
          </p>
          <p>Telefon: +49 (0)30 1234 5678</p>
          <div className={styles.ctaFooter}>
            <Link to="/contact" className="primaryButton">
              Nachricht senden
            </Link>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {year} Novaterium. Alle Rechte vorbehalten.</span>
      </div>
    </footer>
  );
};

export default Footer;