import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Guide from './pages/Guide';
import Programs from './pages/Programs';
import Tools from './pages/Tools';
import Blog from './pages/Blog';
import BlogDetail from './pages/BlogDetail';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Imprint from './pages/Imprint';
import CookiePolicy from './pages/CookiePolicy';
import NotFound from './pages/NotFound';

function App() {
  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Novaterium | Dein Weg in den deutschen Arbeitsmarkt</title>
        <meta
          name="description"
          content="Novaterium begleitet Dich mit klaren Leitfäden, Programmen und Tools, um Deinen Einstieg in den deutschen Arbeitsmarkt gut vorbereitet zu meistern."
        />
        <meta
          name="keywords"
          content="Integration Arbeitsmarkt Deutschland, Jobsuche Deutschland, Bewerbungen Deutschland, Novaterium"
        />
        <meta name="author" content="Novaterium" />
        <link rel="canonical" href="https://www.novaterium.de/" />
      </Helmet>
      <ScrollToTop />
      <Header />
      <main className="appMain" id="hauptinhalt">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/guide" element={<Guide />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/tools" element={<Tools />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogDetail />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/legal" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/imprint" element={<Imprint />} />
          <Route path="/cookies" element={<CookiePolicy />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </>
  );
}

export default App;