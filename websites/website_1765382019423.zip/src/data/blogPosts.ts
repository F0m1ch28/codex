export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  content: string[];
  date: string;
  author: string;
  tags: string[];
  heroImage: string;
  seoDescription: string;
}

export const blogPosts: BlogPost[] = [
  {
    slug: "estado-solido-red",
    title: "Estado sólido: despliegue en redes continentales",
    excerpt:
      "Una mirada práctica al salto de las baterías de estado sólido desde el laboratorio hasta la gestión de redes industriales ibéricas.",
    content: [
      "Las baterías de estado sólido han avanzado más allá de la etapa piloto gracias a nuevas cerámicas iónicas con conductividades superiores a 5 mS/cm. En Europa, los primeros ciclos a escala industrial ya superan las 5.000 iteraciones sin agrietamientos estructurales apreciables.",
      "En las redes continentales, la clave está siendo la integración del control térmico en cada rack. Los sensores distribuidos permiten ajustar la presión interna y evitar tensiones en las interfases. De este modo, los contenedores pueden soportar rampas de potencia superiores a 3C sin comprometer la uniformidad.",
      "Para las infraestructuras industriales de EnergíaVolta Iberia, la prioridad es garantizar comunicaciones seguras entre los sistemas de supervisión y los equipos en campo. El uso de gemelos digitales que replican en tiempo real el comportamiento electroquímico reduce la incertidumbre en las maniobras y mejora la previsibilidad operativa."
    ],
    date: "2023-12-18",
    author: "María Zamorano",
    tags: ["estado sólido", "redes", "innovación"],
    heroImage:
      "https://images.unsplash.com/photo-1618005198919-d3d4b5a92eee?auto=format&fit=crop&w=1600&q=80",
    seoDescription:
      "Cómo las baterías de estado sólido se integran en la red española con control térmico avanzado y gemelos digitales."
  },
  {
    slug: "almacenamiento-termico-industrial",
    title: "Almacenamiento térmico industrial: bancos de energía reutilizada",
    excerpt:
      "Los bancos térmicos se reposicionan como eje de la descarbonización industrial al recuperar calor residual y prolongar su uso.",
    content: [
      "El almacenamiento térmico se ha convertido en una herramienta estratégica para las industrias intensivas en calor. Las soluciones actuales aprovechan materiales de cambio de fase que mantienen una ventana térmica estable entre 120 °C y 450 °C, permitiendo alimentar procesos de secado, pasteurización o vapor auxiliar sin recurrir a combustibles fósiles.",
      "En España, la elevada penetración de cogeneraciones ofrece un terreno fértil para conectar bancos térmicos a infraestructuras existentes. EnergíaVolta Iberia ha desarrollado módulos que se acoplan a intercambiadores compactos y que pueden cargarse con excedentes eléctricos procedentes de renovables nocturnas.",
      "La digitalización de estos bancos es esencial: sensores de fibra óptica registran gradientes internos y aseguran la homogeneidad. De esta forma, se evita la estratificación y se prolonga la vida útil de los materiales confinados."
    ],
    date: "2024-02-02",
    author: "Daniel Herrera",
    tags: ["térmico", "industria", "reutilización"],
    heroImage:
      "https://images.unsplash.com/photo-1581090464634-6721de05e284?auto=format&fit=crop&w=1600&q=80",
    seoDescription:
      "Bancos térmicos inteligentes que recuperan calor industrial y se integran con excedentes renovables en España."
  },
  {
    slug: "reciclaje-circular-baterias",
    title: "Reciclaje circular de baterías en plataformas industriales",
    excerpt:
      "Nuevos procesos hidrometalúrgicos están elevando las tasas de recuperación de litio y níquel en la península.",
    content: [
      "El reciclaje circular ya no es un concepto de laboratorio: plantas ibéricas están alcanzando ratios de recuperación superiores al 92 % para níquel y 88 % para litio gracias a baños controlados de lixiviación suave combinados con resinas selectivas.",
      "EnergíaVolta Iberia colabora con operadores que clasifican celdas usando análisis espectrométricos en línea, lo que evita mezclar químicas incompatibles y reduce el consumo químico en la etapa de separación.",
      "El siguiente salto consiste en reintegrar los materiales recuperados en nuevas celdas fabricadas en territorio nacional. Las pruebas piloto demuestran que la utilización de litio secundario mantiene la conductividad iónica dentro de los rangos exigidos por los estándares de ciclo profundo industrial."
    ],
    date: "2024-01-15",
    author: "Lucía Maroto",
    tags: ["reciclaje", "circularidad", "materiales"],
    heroImage:
      "https://images.unsplash.com/photo-1580894908361-967195033215?auto=format&fit=crop&w=1600&q=80",
    seoDescription:
      "Procesos de reciclaje circular para baterías industriales con altas tasas de recuperación en la península ibérica."
  },
  {
    slug: "sincronizacion-digital",
    title: "Sincronización digital para reservas rápidas de red",
    excerpt:
      "Modelos predictivos basados en IA permiten coordinar reservas en segundos para amortiguar la variabilidad renovable.",
    content: [
      "La sincronización digital es la columna vertebral de los servicios de respuesta rápida. Los algoritmos de EnergíaVolta Iberia cruzan datos SCADA, previsiones meteorológicas y disponibilidad industrial para orquestar activos ubicados en diferentes regiones.",
      "La comunicación bidireccional se realiza a través de protocolos seguros IEC 60870-5-104 y API cifradas, garantizando integridad frente a ciberamenazas. Los sistemas implementan mecanismos de failover para mantener la operativa incluso ante interrupciones parciales.",
      "Los resultados muestran que las desviaciones de frecuencia se corrigen en menos de 300 milisegundos en escenarios de alta variabilidad, lo que demuestra la eficacia del modelo de agregación flexible."
    ],
    date: "2023-11-08",
    author: "Íñigo Baeza",
    tags: ["digitalización", "red", "respuesta"],
    heroImage:
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1600&q=80",
    seoDescription:
      "Sincronización digital y algoritmos predictivos para reservas rápidas de red en sistemas españoles."
  },
  {
    slug: "hidrogeno-integrado",
    title: "Hidrógeno integrado en hubs híbridos de almacenamiento",
    excerpt:
      "Electrolizadores, almacenamiento gaseoso y pilas reversibles convergen para cubrir servicios de larga duración.",
    content: [
      "Los hubs híbridos combinan electrolizadores PEM con cavernas de almacenamiento y pilas reversibles de óxido sólido. Esta arquitectura permite gestionar ventanas superiores a 200 horas, adecuadas para cubrir periodos largos de baja generación renovable.",
      "EnergíaVolta Iberia trabaja con operadores logísticos que aprovechan el hidrógeno para abastecer flotas internas y, simultáneamente, inyectar electricidad a la red en momentos críticos. La coordinación se basa en un sistema de contratación horaria con la distribuidora.",
      "El seguimiento analítico monitoriza pureza, presión y temperatura del hidrógeno a lo largo de toda la cadena. Los datos alimentan un gemelo energético que evalúa en tiempo real la eficiencia round-trip y anticipa mantenimientos."
    ],
    date: "2024-03-07",
    author: "Sofía Llorente",
    tags: ["hidrógeno", "larga duración", "híbridos"],
    heroImage:
      "https://images.unsplash.com/photo-1621905251918-48416bd8575a?auto=format&fit=crop&w=1600&q=80",
    seoDescription:
      "Hubs híbridos que combinan hidrógeno, almacenamiento gaseoso y pilas reversibles para servicios de larga duración."
  }
];