import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="border-t border-white/10 bg-primary">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2 font-display text-lg font-semibold">
              <span className="rounded-md bg-gradient-to-tr from-accent to-secondary px-2 py-1 text-sm font-mono uppercase tracking-widest text-primary">
                EV
              </span>
              EnergíaVolta Iberia
            </div>
            <p className="mt-4 text-sm text-slate-400">
              Arquitectura energética para industrias que necesitan acelerar la
              flexibilidad y la estabilidad de la red en España.
            </p>
          </div>
          <div>
            <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-slate-200">
              Navegación
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-400">
              <li>
                <Link to="/" className="hover:text-accent">
                  Inicio
                </Link>
              </li>
              <li>
                <Link to="/nosotros" className="hover:text-accent">
                  Nosotros
                </Link>
              </li>
              <li>
                <Link to="/tecnologias-almacenamiento" className="hover:text-accent">
                  Tecnologías
                </Link>
              </li>
              <li>
                <Link to="/investigacion" className="hover:text-accent">
                  Investigación
                </Link>
              </li>
              <li>
                <Link to="/blog" className="hover:text-accent">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/contacto" className="hover:text-accent">
                  Contacto
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-slate-200">
              Documentación
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-400">
              <li>
                <Link to="/terminos" className="hover:text-accent">
                  Términos de uso
                </Link>
              </li>
              <li>
                <Link to="/privacidad" className="hover:text-accent">
                  Política de privacidad
                </Link>
              </li>
              <li>
                <Link to="/politica-cookies" className="hover:text-accent">
                  Política de cookies
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-slate-200">
              Contacto
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-400">
              <li>
                Torre Picasso, Plaza Pablo Ruiz Picasso 1, 28020 Madrid
              </li>
              <li>
                Teléfono:{" "}
                <a href="tel:+34915678214" className="hover:text-accent">
                  +34 915 67 82 14
                </a>
              </li>
              <li>
                Email:{" "}
                <a
                  href="mailto:info@energiavolta.com"
                  className="hover:text-accent"
                >
                  info@energiavolta.com
                </a>
              </li>
              <li className="flex gap-3 pt-3">
                <a
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noreferrer"
                  aria-label="LinkedIn EnergíaVolta Iberia"
                  className="text-slate-400 transition hover:text-accent"
                >
                  <svg
                    className="h-5 w-5"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1 4.98 2.12 4.98 3.5zM0 8h5v16H0zM8 8h4.8v2.2h.07c.67-1.27 2.3-2.6 4.73-2.6 5.06 0 5.99 3.33 5.99 7.67V24h-5v-7.6c0-1.81-.03-4.14-2.52-4.14-2.52 0-2.91 1.97-2.91 4v7.74H8z" />
                  </svg>
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Twitter EnergíaVolta Iberia"
                  className="text-slate-400 transition hover:text-accent"
                >
                  <svg
                    className="h-5 w-5"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.15 4.15 0 001.82-2.29 8.27 8.27 0 01-2.62 1 4.12 4.12 0 00-7 3.75A11.68 11.68 0 013 4.9a4.11 4.11 0 001.27 5.49 4.07 4.07 0 01-1.86-.51v.05a4.13 4.13 0 003.3 4 4.1 4.1 0 01-1.85.07 4.13 4.13 0 003.85 2.86A8.3 8.3 0 012 19.54 11.74 11.74 0 008.29 21c7.55 0 11.68-6.26 11.68-11.68 0-.18 0-.35-.01-.53A8.36 8.36 0 0022.46 6z" />
                  </svg>
                </a>
                <a
                  href="https://www.youtube.com"
                  target="_blank"
                  rel="noreferrer"
                  aria-label="YouTube EnergíaVolta Iberia"
                  className="text-slate-400 transition hover:text-accent"
                >
                  <svg
                    className="h-5 w-5"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M23.5 6.2a3 3 0 00-2.12-2.12C19.3 3.5 12 3.5 12 3.5s-7.3 0-9.38.58A3 3 0 00.5 6.2 31.12 31.12 0 000 12a31.12 31.12 0 00.5 5.8 3 3 0 002.12 2.12c2.08.58 9.38.58 9.38.58s7.3 0 9.38-.58A3 3 0 0023.5 17.8 31.12 31.12 0 0024 12a31.12 31.12 0 00-.5-5.8zM9.75 15.5v-7l6 3.5z" />
                  </svg>
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-white/10 pt-6 text-center text-xs text-slate-500">
          © {new Date().getFullYear()} EnergíaVolta Iberia. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
};

export default Footer;