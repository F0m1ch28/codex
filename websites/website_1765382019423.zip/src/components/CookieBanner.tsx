import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const COOKIE_STORAGE_KEY = "energiavolta-cookie-consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value: "accepted" | "declined") => {
    localStorage.setItem(COOKIE_STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-primary/95 backdrop-blur border-t border-white/10">
      <div className="mx-auto flex max-w-4xl flex-col gap-4 px-6 py-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-slate-300">
          Utilizamos cookies técnicas y analíticas para mejorar la experiencia.
          Consulta la{" "}
          <Link
            to="/politica-cookies"
            className="underline decoration-dotted underline-offset-4 hover:text-accent"
          >
            política de cookies
          </Link>{" "}
          para conocer los detalles.
        </p>
        <div className="flex gap-2">
          <button
            onClick={() => handleConsent("declined")}
            className="rounded-full border border-white/20 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-200 transition hover:border-white/40 hover:text-accent"
            type="button"
          >
            Rechazar
          </button>
          <button
            onClick={() => handleConsent("accepted")}
            className="rounded-full bg-accent px-4 py-2 text-xs font-semibold uppercase tracking-wide text-primary transition hover:bg-secondary hover:text-light"
            type="button"
          >
            Aceptar
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;