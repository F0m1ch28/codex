import { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";

const navigationItems = [
  { name: "Inicio", to: "/" },
  { name: "Nosotros", to: "/nosotros" },
  { name: "Tecnologías", to: "/tecnologias-almacenamiento" },
  { name: "Investigación", to: "/investigacion" },
  { name: "Blog", to: "/blog" },
  { name: "Contacto", to: "/contacto" }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const renderNavLink = (name: string, to: string) => (
    <NavLink
      key={to}
      to={to}
      onClick={() => setMenuOpen(false)}
      className={({ isActive }) =>
        `text-sm font-medium transition-colors hover:text-accent ${
          isActive ? "text-accent" : "text-slate-200"
        }`
      }
    >
      {name}
    </NavLink>
  );

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-primary/80 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link
          to="/"
          className="flex items-center gap-3 font-display text-xl font-semibold text-light"
          aria-label="EnergíaVolta Iberia - Inicio"
        >
          <span className="rounded-md bg-gradient-to-tr from-accent to-secondary px-2 py-1 text-sm font-mono uppercase tracking-widest text-primary">
            EV
          </span>
          EnergíaVolta Iberia
        </Link>
        <nav
          aria-label="Navegación principal"
          className="hidden items-center gap-8 md:flex"
        >
          {navigationItems.map((item) => renderNavLink(item.name, item.to))}
        </nav>
        <Link
          to="/contacto"
          className="hidden rounded-full bg-accent px-4 py-2 text-sm font-semibold text-primary transition hover:bg-secondary hover:text-light md:inline-flex"
        >
          Agenda un diagnóstico
        </Link>
        <button
          type="button"
          className="inline-flex items-center justify-center rounded-md border border-white/10 p-2 text-slate-100 transition hover:bg-white/10 md:hidden"
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          aria-label="Abrir menú"
        >
          <span className="sr-only">Abrir menú</span>
          <svg
            className="h-5 w-5"
            viewBox="0 0 24 24"
            stroke="currentColor"
            fill="none"
          >
            {menuOpen ? (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
                d="M6 18L18 6M6 6l12 12"
              />
            ) : (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
                d="M4 6h16M4 12h16M4 18h16"
              />
            )}
          </svg>
        </button>
      </div>
      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            id="mobile-menu"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden"
          >
            <div className="space-y-4 border-t border-white/10 bg-primary px-6 py-4">
              {navigationItems.map((item) => renderNavLink(item.name, item.to))}
              <Link
                to="/contacto"
                onClick={() => setMenuOpen(false)}
                className="inline-flex w-full items-center justify-center rounded-full bg-accent px-4 py-2 text-sm font-semibold text-primary transition hover:bg-secondary hover:text-light"
              >
                Agenda un diagnóstico
              </Link>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;