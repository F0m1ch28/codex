import { Routes, Route } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import ScrollToTopButton from "./components/ScrollToTopButton";
import HomePage from "./pages/HomePage";
import AboutPage from "./pages/AboutPage";
import TechnologiesPage from "./pages/TechnologiesPage";
import ResearchPage from "./pages/ResearchPage";
import BlogPage from "./pages/BlogPage";
import BlogPostPage from "./pages/BlogPostPage";
import ContactPage from "./pages/ContactPage";
import TermsPage from "./pages/TermsPage";
import PrivacyPage from "./pages/PrivacyPage";
import CookiePolicyPage from "./pages/CookiePolicyPage";

const App = () => {
  const baseUrl = "https://www.energiavoltaiberia.com";
  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "EnergíaVolta Iberia",
    url: baseUrl,
    logo: "https://images.unsplash.com/photo-1581090700227-1e37b190418e?auto=format&fit=crop&w=200&q=80",
    contactPoint: [
      {
        "@type": "ContactPoint",
        telephone: "+34 915 67 82 14",
        contactType: "Servicio corporativo",
        areaServed: "ES",
        availableLanguage: ["es"]
      }
    ],
    address: {
      "@type": "PostalAddress",
      streetAddress: "Plaza Pablo Ruiz Picasso 1",
      addressLocality: "Madrid",
      postalCode: "28020",
      addressCountry: "ES"
    },
    sameAs: [
      "https://www.linkedin.com",
      "https://twitter.com",
      "https://www.youtube.com"
    ]
  };

  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    url: baseUrl,
    name: "EnergíaVolta Iberia",
    potentialAction: {
      "@type": "SearchAction",
      target: `${baseUrl}/buscar?query={search_term_string}`,
      "query-input": "required name=search_term_string"
    }
  };

  return (
    <>
      <Helmet>
        <html lang="es-ES" />
        <title>
          EnergíaVolta Iberia | Almacenamiento Energético Industrial en España
        </title>
        <meta
          name="description"
          content="EnergíaVolta Iberia implementa almacenamiento energético industrial, integra renovables y coordina activos flexibles en toda España."
        />
        <link rel="canonical" href={`${baseUrl}/`} />
        <meta property="og:type" content="website" />
        <meta
          property="og:title"
          content="EnergíaVolta Iberia | Almacenamiento Energético Industrial"
        />
        <meta
          property="og:description"
          content="Diseñamos sistemas avanzados de almacenamiento energético y transformamos la flexibilidad industrial en España."
        />
        <meta
          property="og:image"
          content="https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1600&q=80"
        />
        <meta property="og:url" content={`${baseUrl}/`} />
        <script type="application/ld+json">
          {JSON.stringify(organizationJsonLd)}
        </script>
        <script type="application/ld+json">
          {JSON.stringify(websiteJsonLd)}
        </script>
      </Helmet>
      <div className="min-h-screen flex flex-col bg-primary text-light">
        <ScrollToTop />
        <Header />
        <main className="flex-1 pt-16">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/nosotros" element={<AboutPage />} />
            <Route
              path="/tecnologias-almacenamiento"
              element={<TechnologiesPage />}
            />
            <Route path="/investigacion" element={<ResearchPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:slug" element={<BlogPostPage />} />
            <Route path="/contacto" element={<ContactPage />} />
            <Route path="/terminos" element={<TermsPage />} />
            <Route path="/privacidad" element={<PrivacyPage />} />
            <Route path="/politica-cookies" element={<CookiePolicyPage />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTopButton />
      </div>
    </>
  );
};

export default App;