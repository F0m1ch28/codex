import { useMemo } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useParams } from "react-router-dom";
import { blogPosts } from "../data/blogPosts";

const BlogPostPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const post = useMemo(
    () => blogPosts.find((item) => item.slug === slug),
    [slug]
  );

  if (!post) {
    return (
      <section className="section-padding">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="text-3xl font-semibold text-light">Artículo no encontrado</h1>
          <p className="mt-4 text-slate-300">
            El contenido que buscas no está disponible. Revisa otras publicaciones.
          </p>
          <Link
            to="/blog"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-primary transition hover:bg-secondary hover:text-light"
          >
            Volver al blog
          </Link>
        </div>
      </section>
    );
  }

  const publicationDate = new Date(post.date).toLocaleDateString("es-ES", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });

  return (
    <>
      <Helmet>
        <title>{post.title} | Blog EnergíaVolta Iberia</title>
        <meta name="description" content={post.seoDescription} />
        <link
          rel="canonical"
          href={`https://www.energiavoltaiberia.com/blog/${post.slug}`}
        />
        <meta property="og:title" content={`${post.title} | EnergíaVolta Iberia`} />
        <meta property="og:description" content={post.seoDescription} />
        <meta property="og:image" content={post.heroImage} />
      </Helmet>
      <article className="section-padding">
        <div className="mx-auto max-w-4xl">
          <span className="text-xs uppercase tracking-[0.3em] text-secondary">
            {publicationDate}
          </span>
          <h1 className="mt-4 text-4xl font-semibold text-light">{post.title}</h1>
          <p className="mt-3 text-sm uppercase tracking-widest text-slate-400">
            Por {post.author}
          </p>
          <img
            src={post.heroImage}
            alt={`Imagen destacada del artículo ${post.title}`}
            className="mt-8 h-80 w-full rounded-3xl object-cover"
            loading="lazy"
          />
          <div className="mt-8 space-y-6 text-base leading-relaxed text-slate-200">
            {post.content.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap gap-2 text-xs uppercase tracking-widest text-slate-400">
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full bg-primary/60 px-3 py-1 text-secondary"
              >
                {tag}
              </span>
            ))}
          </div>
          <Link
            to="/blog"
            className="mt-10 inline-flex items-center gap-2 text-sm font-semibold text-accent transition hover:text-secondary"
          >
            ← Volver al blog
          </Link>
        </div>
      </article>
    </>
  );
};

export default BlogPostPage;