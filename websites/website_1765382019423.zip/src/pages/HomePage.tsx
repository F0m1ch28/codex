import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

interface Metric {
  label: string;
  value: number;
  suffix?: string;
  description: string;
}

interface Installation {
  id: string;
  city: string;
  region: string;
  coords: {
    top: string;
    left: string;
  };
  storage: string;
  gridService: string;
}

interface TimelineEvent {
  year: string;
  title: string;
  description: string;
}

const metrics: Metric[] = [
  {
    label: "MWh gestionados en tiempo real",
    value: 185000,
    suffix: " MWh",
    description:
      "Capacidad agregada conectada a la plataforma EnergíaVolta para industrias españolas."
  },
  {
    label: "Proyectos industriales activos",
    value: 42,
    description:
      "Plantas en operación con sistemas híbridos ion-litio, flujo y térmicos."
  },
  {
    label: "Horas de flexibilidad entregadas",
    value: 126000,
    suffix: " h",
    description:
      "Servicios de regulación y reserva suministrados a operadores de red y distribuidores."
  },
  {
    label: "Toneladas de CO₂ evitadas",
    value: 89000,
    suffix: " t",
    description:
      "Emisiones evitadas gracias a la integración de almacenamiento y reutilización térmica."
  }
];

const installations: Installation[] = [
  {
    id: "bilbao-hub",
    city: "Bilbao",
    region: "Euskadi",
    coords: { top: "32%", left: "38%" },
    storage:
      "Nodo marítimo con 120 MWh en megapacks ion-litio y apoyo a industria portuaria.",
    gridService: "Reserva primaria y absorción de picos en terminales de GNL."
  },
  {
    id: "madrid-campus",
    city: "Madrid",
    region: "Comunidad de Madrid",
    coords: { top: "52%", left: "47%" },
    storage:
      "Campus corporativo con bancos térmicos y baterías de flujo para edificios inteligentes.",
    gridService: "Gestión de demanda y respaldo de micro-redes urbanas."
  },
  {
    id: "sevilla-sol",
    city: "Sevilla",
    region: "Andalucía",
    coords: { top: "71%", left: "40%" },
    storage:
      "Parque agroindustrial con 80 MWh térmicos acoplados a procesos de secado.",
    gridService: "Desplazamiento de calor y respuesta frente a olas de calor."
  },
  {
    id: "zaragoza-aire",
    city: "Zaragoza",
    region: "Aragón",
    coords: { top: "43%", left: "50%" },
    storage:
      "Instalación CAES con cavidades salinas que entrega 200 MW durante 8 horas.",
    gridService: "Apoyo a renovables y seguridad del suministro meseta norte."
  }
];

const timelineEvents: TimelineEvent[] = [
  {
    year: "2016",
    title: "Fundación y primer piloto",
    description:
      "Creación de EnergíaVolta Iberia y puesta en marcha del primer contenedor ion-litio para una planta química en Tarragona."
  },
  {
    year: "2018",
    title: "Plataforma de control flexible",
    description:
      "Lanzamiento del centro de operaciones digitales con conectividad 24/7 y despachos automáticos basados en IA."
  },
  {
    year: "2020",
    title: "Hibridación térmica-eléctrica",
    description:
      "Integración de bancos térmicos con excedentes fotovoltaicos y certificados de origen renovable."
  },
  {
    year: "2022",
    title: "Servicios a la red de transporte",
    description:
      "Acuerdo marco con operadores para servicios de regulación secundaria y terciaria desde activos industriales."
  },
  {
    year: "2023",
    title: "Centro I+D en sólido y hidrógeno",
    description:
      "Apertura de laboratorios en Madrid para caracterizar electrolitos sólidos y pilas reversibles de alta temperatura."
  }
];

const thermalGallery = [
  {
    src: "https://images.unsplash.com/photo-1542601098-8fc114e148e0?auto=format&fit=crop&w=1200&q=80",
    alt: "Vista superior de tanques térmicos industriales iluminados de noche",
    caption: "Sales fundidas estabilizadas con monitorización en fibra óptica."
  },
  {
    src: "https://images.unsplash.com/photo-1470549638415-0a0755be0619?auto=format&fit=crop&w=1200&q=80",
    alt: "Ingeniero supervisando tuberías de almacenamiento térmico en planta industrial",
    caption: "Integración de calor residual en procesos alimentarios."
  },
  {
    src: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80",
    alt: "Centro de control digital con múltiples pantallas supervisando energía",
    caption: "Centro de operaciones con gemelos térmicos y eléctricos."
  },
  {
    src: "https://images.unsplash.com/photo-1508873696983-2dfd5898f08b?auto=format&fit=crop&w=1200&q=80",
    alt: "Detalle de tubería y válvulas en sistemas térmicos industriales",
    caption: "Válvulas modulantes para ciclos de carga térmica flexible."
  }
];

const comparisonRows = [
  {
    aspect: "Densidad energética",
    ion: "Alta densidad, ideal para espacios reducidos y servicios rápidos.",
    flujo: "Escalable por volumen, estable para ciclos largos.",
    termico: "Aprovecha calor residual, densidad dependiente del medio."
  },
  {
    aspect: "Durabilidad",
    ion: "Más de 7.000 ciclos con control térmico activo.",
    flujo: "Casi ilimitada gracias a la separación del electrolito.",
    termico: "Sin degradación significativa si se evita la estratificación."
  },
  {
    aspect: "Tiempo de respuesta",
    ion: "Milisegundos, apto para regulación primaria.",
    flujo: "Segundos, adecuado para rampas medianas.",
    termico: "Minutos, perfecto para desplazamiento de calor."
  },
  {
    aspect: "Aplicaciones clave",
    ion: "Cuadros eléctricos industriales, micro-redes.",
    flujo: "Servicios de capacidad y respaldo prolongado.",
    termico: "Procesos térmicos continuos y almacenamiento excedente."
  }
];

const HomePage = () => {
  const [displayValues, setDisplayValues] = useState<number[]>(
    () => new Array(metrics.length).fill(0)
  );
  const [activeInstallation, setActiveInstallation] = useState<string | null>(
    null
  );
  const [newsletterName, setNewsletterName] = useState("");
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterStatus, setNewsletterStatus] = useState<
    "idle" | "success"
  >("idle");

  useEffect(() => {
    let animationFrame: number;
    const startTime = performance.now();
    const duration = 2200;

    const animate = (time: number) => {
      const progress = Math.min((time - startTime) / duration, 1);
      setDisplayValues(
        metrics.map((metric) => Math.round(metric.value * progress))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  const formattedMetrics = useMemo(
    () =>
      displayValues.map((value, index) => {
        const metric = metrics[index];
        return `${new Intl.NumberFormat("es-ES").format(value)}${
          metric.suffix ?? ""
        }`;
      }),
    [displayValues]
  );

  const handleNewsletterSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!newsletterEmail.trim()) {
      return;
    }
    setNewsletterStatus("success");
    setNewsletterName("");
    setNewsletterEmail("");
    setTimeout(() => setNewsletterStatus("idle"), 6000);
  };

  return (
    <>
      <Helmet>
        <title>
          Energía del Mañana | EnergíaVolta Iberia - Almacenamiento Energético
        </title>
        <meta
          name="description"
          content="Soluciones industriales de almacenamiento energético en toda España: ion-litio, flujo, térmico, hidrógeno y CAES, integrados con control digital."
        />
        <link rel="canonical" href="https://www.energiavoltaiberia.com/" />
        <meta
          property="og:title"
          content="Energía del Mañana | EnergíaVolta Iberia"
        />
        <meta
          property="og:description"
          content="EnergíaVolta Iberia impulsa el almacenamiento energético industrial con tecnologías híbridas y plataformas digitales."
        />
        <meta
          property="og:image"
          content="https://images.unsplash.com/photo-1468070454955-c5b6932bd08d?auto=format&fit=crop&w=1600&q=80"
        />
      </Helmet>

      <motion.section
        className="relative overflow-hidden bg-grid-pattern"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div
          className="absolute inset-0 opacity-60"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1521207418485-99c705420785?auto=format&fit=crop&w=1600&q=80')",
            backgroundPosition: "center",
            backgroundSize: "cover"
          }}
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-primary/60" />
        <div className="relative mx-auto flex max-w-7xl flex-col gap-10 px-6 py-28 md:flex-row md:items-center md:justify-between md:py-32">
          <div className="max-w-2xl">
            <motion.span
              className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.3em] text-accent"
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15, duration: 0.4 }}
            >
              Energía del Mañana
            </motion.span>
            <motion.h1
              className="mt-6 text-4xl font-semibold leading-tight text-light md:text-5xl lg:text-6xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25, duration: 0.6 }}
            >
              Almacenamiento energético industrial para una península flexible y
              resiliente
            </motion.h1>
            <motion.p
              className="mt-6 text-lg text-slate-200 md:text-xl"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35, duration: 0.6 }}
            >
              Diseñamos, construimos y operamos sistemas híbridos que combinan
              baterías avanzadas, bancos térmicos y vectores emergentes como el
              hidrógeno, conectados a una plataforma digital que coordina cada
              activo con la red.
            </motion.p>
            <motion.div
              className="mt-10 flex flex-col gap-4 sm:flex-row"
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45, duration: 0.6 }}
            >
              <Link
                to="/tecnologias-almacenamiento"
                className="inline-flex items-center justify-center rounded-full bg-accent px-6 py-3 text-sm font-semibold text-primary transition hover:bg-secondary hover:text-light"
              >
                Explorar tecnologías
              </Link>
              <Link
                to="/contacto"
                className="inline-flex items-center justify-center rounded-full border border-white/20 px-6 py-3 text-sm font-semibold text-slate-200 transition hover:border-accent hover:text-accent"
              >
                Conectar con el equipo
              </Link>
            </motion.div>
          </div>
          <motion.div
            className="relative mt-10 w-full max-w-md rounded-3xl border border-white/10 bg-primary/70 p-6 shadow-xl md:mt-0"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.55, duration: 0.6 }}
          >
            <h2 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
              Indicadores 2023
            </h2>
            <ul className="mt-6 space-y-5">
              {metrics.map((metric, index) => (
                <li key={metric.label} className="space-y-2">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs uppercase tracking-widest text-slate-400">
                      {metric.label}
                    </span>
                    <span className="font-mono text-lg text-accent">
                      {formattedMetrics[index]}
                    </span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                    <motion.div
                      className="h-full rounded-full bg-gradient-to-r from-accent via-secondary to-accent"
                      initial={{ width: "0%" }}
                      animate={{
                        width: `${Math.min(
                          100,
                          (displayValues[index] / (metrics[index].value || 1)) *
                            100
                        )}%`
                      }}
                      transition={{ duration: 1.5, delay: index * 0.1 }}
                    />
                  </div>
                  <p className="text-xs text-slate-400">{metric.description}</p>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </motion.section>

      <section className="section-padding">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-light">
                Mapa vivo de nuestras instalaciones en España
              </h2>
              <p className="mt-3 text-slate-300">
                Cada nodo está monitorizado desde nuestro centro de operaciones
                en Madrid. Los sistemas combinan almacenamiento eléctrico,
                térmico y control digital para alimentar procesos críticos.
              </p>
            </div>
            <span className="text-xs uppercase tracking-[0.3em] text-secondary">
              Cobertura peninsular
            </span>
          </div>
          <div className="relative mt-10 grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-primary">
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Spain_location_map.svg"
                  alt="Mapa de España con ubicaciones de EnergíaVolta Iberia"
                  className="h-full w-full object-contain"
                />
                {installations.map((installation) => (
                  <button
                    key={installation.id}
                    type="button"
                    className="absolute flex h-5 w-5 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-primary bg-accent/90 shadow-lg shadow-secondary/30 transition hover:scale-110 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                    style={{
                      top: installation.coords.top,
                      left: installation.coords.left
                    }}
                    aria-label={`Nodo ${installation.city}, ${installation.region}`}
                    onMouseEnter={() => setActiveInstallation(installation.id)}
                    onFocus={() => setActiveInstallation(installation.id)}
                    onMouseLeave={() => setActiveInstallation(null)}
                    onBlur={() => setActiveInstallation(null)}
                  >
                    <span className="sr-only">
                      {installation.city} {installation.storage}
                    </span>
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-4 overflow-y-auto rounded-3xl border border-white/10 bg-white/5 p-6 shadow-inner custom-scroll">
              {installations.map((installation) => {
                const isActive = activeInstallation === installation.id;
                return (
                  <motion.article
                    key={installation.id}
                    className={`rounded-2xl border p-4 transition ${
                      isActive
                        ? "border-secondary bg-secondary/20"
                        : "border-white/10 bg-primary/60"
                    }`}
                    initial={false}
                    animate={{
                      opacity: isActive ? 1 : 0.85,
                      scale: isActive ? 1.01 : 1
                    }}
                  >
                    <header className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-light">
                        {installation.city}, {installation.region}
                      </h3>
                      <span className="font-mono text-xs uppercase tracking-widest text-accent">
                        Sistema híbrido
                      </span>
                    </header>
                    <p className="mt-3 text-sm text-slate-300">
                      {installation.storage}
                    </p>
                    <p className="mt-2 text-xs text-slate-400">
                      {installation.gridService}
                    </p>
                  </motion.article>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding bg-primary/60">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-light">
                Tecnologías térmicas en acción
              </h2>
              <p className="mt-3 text-slate-300">
                Bancos térmicos de alta capacidad que estabilizan procesos industriales y almacenan energía renovable en forma de calor útil.
              </p>
            </div>
            <span className="text-xs uppercase tracking-[0.3em] text-secondary">
              Galería térmica
            </span>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {thermalGallery.map((item) => (
              <motion.figure
                key={item.src}
                className="overflow-hidden rounded-3xl border border-white/10 bg-white/5"
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.6 }}
              >
                <img
                  src={item.src}
                  alt={item.alt}
                  className="h-64 w-full object-cover"
                  loading="lazy"
                />
                <figcaption className="p-5 text-sm text-slate-200">
                  {item.caption}
                </figcaption>
              </motion.figure>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-light">
                Comparativa de sistemas de almacenamiento
              </h2>
              <p className="mt-3 text-slate-300">
                Seleccionamos la tecnología adecuada para cada industria combinando
                criterios de energía, respuesta, modularidad y temperatura.
              </p>
            </div>
            <span className="text-xs uppercase tracking-[0.3em] text-secondary">
              Evaluación tecnológica
            </span>
          </div>
          <div className="mt-10 overflow-hidden rounded-3xl border border-white/10 bg-white/5">
            <table className="w-full text-left text-sm text-slate-200">
              <thead className="bg-white/10 text-xs uppercase tracking-widest text-secondary">
                <tr>
                  <th className="px-6 py-4">Aspecto</th>
                  <th className="px-6 py-4">Ion-litio</th>
                  <th className="px-6 py-4">Flujo</th>
                  <th className="px-6 py-4">Térmico</th>
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row) => (
                  <tr
                    key={row.aspect}
                    className="border-t border-white/10 text-slate-300"
                  >
                    <th scope="row" className="px-6 py-5 font-semibold text-light">
                      {row.aspect}
                    </th>
                    <td className="px-6 py-5">{row.ion}</td>
                    <td className="px-6 py-5">{row.flujo}</td>
                    <td className="px-6 py-5">{row.termico}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="section-padding bg-primary/60">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-light">
                Hitos de desarrollo EnergíaVolta
              </h2>
              <p className="mt-3 text-slate-300">
                Innovación constante desde nuestra creación para consolidar un modelo
                de almacenamiento avanzado al servicio de la red y la industria.
              </p>
            </div>
            <span className="text-xs uppercase tracking-[0.3em] text-secondary">
              Línea temporal
            </span>
          </div>
          <ol className="mt-10 space-y-6 border-l border-secondary/40 pl-6">
            {timelineEvents.map((event) => (
              <motion.li
                key={event.year}
                className="relative rounded-3xl border border-white/10 bg-white/5 p-6"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.5 }}
              >
                <span className="absolute -left-[33px] flex h-6 w-6 items-center justify-center rounded-full border border-primary bg-secondary text-xs font-semibold text-primary shadow-lg">
                  {event.year}
                </span>
                <h3 className="font-display text-lg text-light">
                  {event.title}
                </h3>
                <p className="mt-2 text-sm text-slate-300">
                  {event.description}
                </p>
              </motion.li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto max-w-5xl rounded-3xl border border-white/10 bg-gradient-to-r from-primary via-primary/80 to-primary/60 p-8 md:p-12">
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-center">
            <div className="max-w-md">
              <span className="text-xs uppercase tracking-[0.3em] text-secondary">
                Newsletter técnica
              </span>
              <h2 className="mt-3 text-3xl font-semibold text-light">
                Únete a la red de innovación energética
              </h2>
              <p className="mt-3 text-sm text-slate-300">
                Recibe análisis, tendencias regulatorias y avances tecnológicos sobre
                almacenamiento industrial y flexibilidad de red en España.
              </p>
            </div>
            <form
              className="flex w-full max-w-md flex-col gap-3"
              onSubmit={handleNewsletterSubmit}
            >
              <label className="text-xs font-semibold uppercase tracking-widest text-slate-300">
                Nombre
                <input
                  type="text"
                  name="nombre"
                  value={newsletterName}
                  onChange={(event) => setNewsletterName(event.target.value)}
                  className="mt-1 w-full rounded-full border border-white/10 bg-white/10 px-4 py-3 text-sm text-light placeholder:text-slate-500 focus:border-secondary focus:outline-none"
                  placeholder="Tu nombre"
                  autoComplete="name"
                />
              </label>
              <label className="text-xs font-semibold uppercase tracking-widest text-slate-300">
                Correo electrónico
                <input
                  type="email"
                  name="email"
                  required
                  value={newsletterEmail}
                  onChange={(event) => setNewsletterEmail(event.target.value)}
                  className="mt-1 w-full rounded-full border border-white/10 bg-white/10 px-4 py-3 text-sm text-light placeholder:text-slate-500 focus:border-secondary focus:outline-none"
                  placeholder="tu@empresa.com"
                  autoComplete="email"
                />
              </label>
              <button
                type="submit"
                className="mt-2 inline-flex items-center justify-center rounded-full bg-accent px-6 py-3 text-sm font-semibold text-primary transition hover:bg-secondary hover:text-light"
              >
                Suscribirme
              </button>
              <p
                className="text-xs text-slate-400"
                aria-live="polite"
                role="status"
              >
                {newsletterStatus === "success"
                  ? "¡Gracias por unirte! En breve recibirás nuestro boletín técnico."
                  : "No enviamos mensajes irrelevantes. Puedes darte de baja en cualquier momento."}
              </p>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;