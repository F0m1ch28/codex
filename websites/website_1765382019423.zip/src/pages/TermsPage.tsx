import { Helmet } from "react-helmet-async";

const TermsPage = () => {
  return (
    <>
      <Helmet>
        <title>Términos de uso | EnergíaVolta Iberia</title>
        <meta
          name="description"
          content="Condiciones de uso del sitio web de EnergíaVolta Iberia y responsabilidades asociadas."
        />
        <link
          rel="canonical"
          href="https://www.energiavoltaiberia.com/terminos"
        />
      </Helmet>
      <section className="section-padding">
        <div className="mx-auto max-w-4xl space-y-6">
          <h1 className="text-3xl font-semibold text-light">Términos de uso</h1>
          <p className="text-sm text-slate-300">
            El acceso y uso del sitio web de EnergíaVolta Iberia está sujeto a las
            condiciones descritas a continuación. Al utilizar esta página aceptas las
            normas de navegación y los criterios de responsabilidad aquí establecidos.
          </p>
          <h2 className="text-xl font-semibold text-light">Uso permitido</h2>
          <p className="text-sm text-slate-300">
            Los contenidos se ofrecen para informar sobre soluciones de almacenamiento
            energético. No está autorizada la reproducción completa o parcial sin
            autorización expresa. Cualquier uso debe respetar la legislación española
            vigente.
          </p>
          <h2 className="text-xl font-semibold text-light">Información técnica</h2>
          <p className="text-sm text-slate-300">
            Los datos técnicos y casos mencionados pueden variar según las
            características de cada proyecto. Consultar con nuestro equipo es
            imprescindible antes de tomar decisiones de ingeniería o explotación.
          </p>
          <h2 className="text-xl font-semibold text-light">Responsabilidad</h2>
          <p className="text-sm text-slate-300">
            EnergíaVolta Iberia actualiza los contenidos con regularidad, pero no se
            responsabiliza de interpretaciones o usos ajenos a su control. El sitio
            puede enlazar a recursos externos gestionados por terceras entidades.
          </p>
          <h2 className="text-xl font-semibold text-light">Legislación aplicable</h2>
          <p className="text-sm text-slate-300">
            Las presentes condiciones se rigen por la legislación española. Cualquier
            disputa se resolverá ante los juzgados de Madrid, salvo normativa imperativa
            que indique otra cosa.
          </p>
        </div>
      </section>
    </>
  );
};

export default TermsPage;