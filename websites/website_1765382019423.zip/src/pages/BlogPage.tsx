import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { blogPosts } from "../data/blogPosts";

const BlogPage = () => {
  const sortedPosts = [...blogPosts].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <>
      <Helmet>
        <title>Perspectivas en Almacenamiento | Blog EnergíaVolta</title>
        <meta
          name="description"
          content="Análisis sobre tecnologías de almacenamiento, balance de red, normativa y economía circular elaborados por EnergíaVolta Iberia."
        />
        <link rel="canonical" href="https://www.energiavoltaiberia.com/blog" />
      </Helmet>
      <section className="relative overflow-hidden bg-primary/80">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/70 to-primary/30" />
        <div className="relative mx-auto max-w-5xl px-6 py-24 text-center">
          <span className="text-xs uppercase tracking-[0.3em] text-secondary">
            Perspectivas en Almacenamiento
          </span>
          <h1 className="mt-4 text-4xl font-semibold text-light md:text-5xl">
            Ideas, datos y aprendizajes desde la operación real de almacenamiento energético
          </h1>
          <p className="mt-6 text-slate-300">
            Compartimos conocimiento práctico sobre tecnologías, normativas y operaciones
            que están transformando la flexibilidad industrial.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto max-w-6xl grid gap-8 md:grid-cols-2">
          {sortedPosts.map((post, index) => (
            <motion.article
              key={post.slug}
              className="overflow-hidden rounded-3xl border border-white/10 bg-white/5"
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
            >
              <img
                src={post.heroImage}
                alt={`Imagen destacada del artículo ${post.title}`}
                className="h-56 w-full object-cover"
                loading="lazy"
              />
              <div className="p-6">
                <span className="text-xs uppercase tracking-widest text-secondary">
                  {new Date(post.date).toLocaleDateString("es-ES", {
                    year: "numeric",
                    month: "long",
                    day: "numeric"
                  })}
                </span>
                <h2 className="mt-3 text-2xl font-semibold text-light">
                  {post.title}
                </h2>
                <p className="mt-3 text-sm text-slate-300">{post.excerpt}</p>
                <div className="mt-4 flex flex-wrap gap-2 text-xs uppercase tracking-widest text-slate-400">
                  {post.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-primary/60 px-3 py-1 text-secondary"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <Link
                  to={`/blog/${post.slug}`}
                  className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-accent transition hover:text-secondary"
                >
                  Leer artículo completo
                  <svg
                    className="h-4 w-4"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M7 17L17 7M7 7h10v10" />
                  </svg>
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      </section>
    </>
  );
};

export default BlogPage;