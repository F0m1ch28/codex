import { useState } from "react";
import { Helmet } from "react-helmet-async";

type FormData = {
  nombre: string;
  email: string;
  empresa: string;
  mensaje: string;
};

const initialFormData: FormData = {
  nombre: "",
  email: "",
  empresa: "",
  mensaje: ""
};

const ContactPage = () => {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [formErrors, setFormErrors] = useState<Partial<FormData>>({});
  const [submitted, setSubmitted] = useState(false);

  const validate = (data: FormData) => {
    const errors: Partial<FormData> = {};
    if (!data.nombre.trim()) {
      errors.nombre = "Introduce tu nombre.";
    }
    if (!data.email.trim()) {
      errors.email = "Introduce un correo válido.";
    } else if (!/^\S+@\S+\.\S+$/.test(data.email)) {
      errors.email = "Formato de correo no válido.";
    }
    if (!data.mensaje.trim()) {
      errors.mensaje = "Detalla cómo podemos ayudarte.";
    }
    return errors;
  };

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name as keyof FormData]: value
    }));
    setFormErrors((prev) => ({
      ...prev,
      [name as keyof FormData]: undefined
    }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const errors = validate(formData);
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setSubmitted(true);
      setFormData(initialFormData);
      setTimeout(() => setSubmitted(false), 6000);
    }
  };

  return (
    <>
      <Helmet>
        <title>Conecta con EnergíaVolta | Contacto</title>
        <meta
          name="description"
          content="Contacta con EnergíaVolta Iberia para proyectos de almacenamiento energético industrial y soluciones híbridas."
        />
        <link rel="canonical" href="https://www.energiavoltaiberia.com/contacto" />
      </Helmet>
      <section className="relative overflow-hidden bg-primary/80">
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/70 to-primary/30" />
        <div className="relative mx-auto max-w-5xl px-6 py-24">
          <span className="text-xs uppercase tracking-[0.3em] text-secondary">
            Conecta con EnergíaVolta
          </span>
          <h1 className="mt-4 text-4xl font-semibold text-light md:text-5xl">
            Hablemos sobre cómo reforzar tu infraestructura energética
          </h1>
          <p className="mt-6 text-slate-300">
            Cuéntanos tus retos, analizaremos cargas eléctricas, oportunidades térmicas
            y escenarios de integración con la red.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[0.6fr_0.4fr]">
          <form
            className="space-y-6 rounded-3xl border border-white/10 bg-white/5 p-8"
            onSubmit={handleSubmit}
            noValidate
          >
            <div>
              <label
                htmlFor="nombre"
                className="text-xs font-semibold uppercase tracking-[0.3em] text-secondary"
              >
                Nombre
              </label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={formData.nombre}
                onChange={handleChange}
                className="mt-2 w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-light placeholder:text-slate-500 focus:border-secondary focus:outline-none"
                placeholder="Nombre y apellidos"
                aria-invalid={!!formErrors.nombre}
                aria-describedby={formErrors.nombre ? "error-nombre" : undefined}
              />
              {formErrors.nombre && (
                <p id="error-nombre" className="mt-1 text-xs text-accent">
                  {formErrors.nombre}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="email"
                className="text-xs font-semibold uppercase tracking-[0.3em] text-secondary"
              >
                Correo electrónico
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                className="mt-2 w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-light placeholder:text-slate-500 focus:border-secondary focus:outline-none"
                placeholder="nombre@empresa.com"
                aria-invalid={!!formErrors.email}
                aria-describedby={formErrors.email ? "error-email" : undefined}
              />
              {formErrors.email && (
                <p id="error-email" className="mt-1 text-xs text-accent">
                  {formErrors.email}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="empresa"
                className="text-xs font-semibold uppercase tracking-[0.3em] text-secondary"
              >
                Empresa
              </label>
              <input
                id="empresa"
                name="empresa"
                type="text"
                value={formData.empresa}
                onChange={handleChange}
                className="mt-2 w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-light placeholder:text-slate-500 focus:border-secondary focus:outline-none"
                placeholder="Nombre de la empresa"
              />
            </div>

            <div>
              <label
                htmlFor="mensaje"
                className="text-xs font-semibold uppercase tracking-[0.3em] text-secondary"
              >
                Mensaje
              </label>
              <textarea
                id="mensaje"
                name="mensaje"
                value={formData.mensaje}
                onChange={handleChange}
                className="mt-2 h-40 w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm text-light placeholder:text-slate-500 focus:border-secondary focus:outline-none"
                placeholder="Describe tu proyecto, objetivos y horizonte temporal."
                aria-invalid={!!formErrors.mensaje}
                aria-describedby={formErrors.mensaje ? "error-mensaje" : undefined}
              />
              {formErrors.mensaje && (
                <p id="error-mensaje" className="mt-1 text-xs text-accent">
                  {formErrors.mensaje}
                </p>
              )}
            </div>

            <button
              type="submit"
              className="inline-flex items-center justify-center rounded-full bg-accent px-6 py-3 text-sm font-semibold text-primary transition hover:bg-secondary hover:text-light"
            >
              Enviar consulta
            </button>
            {submitted && (
              <p className="text-sm text-secondary">
                Gracias por tu mensaje. Nuestro equipo te contactará en menos de 48 horas laborales.
              </p>
            )}
          </form>

          <aside className="space-y-6">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
              <h2 className="text-xl font-semibold text-light">
                Datos de contacto
              </h2>
              <ul className="mt-4 space-y-3 text-sm text-slate-300">
                <li>
                  <strong className="text-light">Dirección:</strong> Torre Picasso,
                  Plaza Pablo Ruiz Picasso 1, 28020 Madrid
                </li>
                <li>
                  <strong className="text-light">Teléfono:</strong>{" "}
                  <a
                    href="tel:+34915678214"
                    className="text-secondary hover:text-accent"
                  >
                    +34 915 67 82 14
                  </a>
                </li>
                <li>
                  <strong className="text-light">Correo:</strong>{" "}
                  <a
                    href="mailto:info@energiavolta.com"
                    className="text-secondary hover:text-accent"
                  >
                    info@energiavolta.com
                  </a>
                </li>
                <li>
                  <strong className="text-light">Horario:</strong> Lunes a viernes,
                  09:00 - 18:00 CET
                </li>
              </ul>
            </div>
            <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-2">
              <iframe
                title="Localización EnergíaVolta Iberia"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.407151904807!2d-3.693732123420088!3d40.44706497143461!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4228c4a84687c3%3A0x28df1318dd43259d!2sTorre%20Picasso!5e0!3m2!1ses!2ses!4v1707499999999!5m2!1ses!2ses"
                className="h-72 w-full rounded-3xl border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </aside>
        </div>
      </section>
    </>
  );
};

export default ContactPage;