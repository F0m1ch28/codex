import { Helmet } from "react-helmet-async";

const PrivacyPage = () => {
  return (
    <>
      <Helmet>
        <title>Política de privacidad | EnergíaVolta Iberia</title>
        <meta
          name="description"
          content="Política de privacidad y tratamiento de datos personales conforme al GDPR para EnergíaVolta Iberia."
        />
        <link
          rel="canonical"
          href="https://www.energiavoltaiberia.com/privacidad"
        />
      </Helmet>
      <section className="section-padding">
        <div className="mx-auto max-w-4xl space-y-6">
          <h1 className="text-3xl font-semibold text-light">
            Política de privacidad
          </h1>
          <p className="text-sm text-slate-300">
            En EnergíaVolta Iberia tratamos los datos personales con transparencia y en
            cumplimiento del Reglamento (UE) 2016/679 (GDPR) y la normativa española.
          </p>
          <h2 className="text-xl font-semibold text-light">Responsable</h2>
          <p className="text-sm text-slate-300">
            EnergíaVolta Iberia, con sede en Torre Picasso, Plaza Pablo Ruiz Picasso 1,
            28020 Madrid. Correo de contacto: info@energiavolta.com.
          </p>
          <h2 className="text-xl font-semibold text-light">Finalidades</h2>
          <ul className="list-disc space-y-2 pl-6 text-sm text-slate-300">
            <li>Atender consultas y solicitudes enviadas a través de formularios.</li>
            <li>
              Enviar comunicaciones técnicas, siempre que exista base legitimadora o
              consentimiento.
            </li>
            <li>
              Gestionar relaciones comerciales y contractuales con clientes y socios.
            </li>
          </ul>
          <h2 className="text-xl font-semibold text-light">Legitimación</h2>
          <p className="text-sm text-slate-300">
            El tratamiento se basa en el consentimiento del usuario o en la relación
            contractual previa. Puedes retirar el consentimiento en cualquier momento.
          </p>
          <h2 className="text-xl font-semibold text-light">Derechos</h2>
          <p className="text-sm text-slate-300">
            Puedes ejercer los derechos de acceso, rectificación, supresión, limitación,
            oposición y portabilidad escribiendo a info@energiavolta.com. También puedes
            acudir a la Agencia Española de Protección de Datos.
          </p>
          <h2 className="text-xl font-semibold text-light">Conservación</h2>
          <p className="text-sm text-slate-300">
            Los datos se conservarán durante el tiempo necesario para cumplir con las
            finalidades informadas y los requerimientos legales.
          </p>
          <h2 className="text-xl font-semibold text-light">Seguridad</h2>
          <p className="text-sm text-slate-300">
            Aplicamos medidas técnicas y organizativas para proteger la información frente
            a accesos no autorizados, de acuerdo con los estándares del sector.
          </p>
        </div>
      </section>
    </>
  );
};

export default PrivacyPage;