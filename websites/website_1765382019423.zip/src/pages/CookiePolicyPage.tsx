import { Helmet } from "react-helmet-async";

const CookiePolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Política de cookies | EnergíaVolta Iberia</title>
        <meta
          name="description"
          content="Información sobre el uso de cookies en el sitio de EnergíaVolta Iberia."
        />
        <link
          rel="canonical"
          href="https://www.energiavoltaiberia.com/politica-cookies"
        />
      </Helmet>
      <section className="section-padding">
        <div className="mx-auto max-w-4xl space-y-6">
          <h1 className="text-3xl font-semibold text-light">Política de cookies</h1>
          <p className="text-sm text-slate-300">
            Este sitio web utiliza cookies propias y de análisis con el objetivo de
            ofrecer una experiencia segura y personalizar contenidos.
          </p>
          <h2 className="text-xl font-semibold text-light">¿Qué son las cookies?</h2>
          <p className="text-sm text-slate-300">
            Son archivos que se almacenan en el dispositivo del usuario para recordar
            información sobre su visita. Pueden ser técnicas, de personalización o de
            análisis.
          </p>
          <h2 className="text-xl font-semibold text-light">Cookies utilizadas</h2>
          <ul className="list-disc space-y-2 pl-6 text-sm text-slate-300">
            <li>
              <strong className="text-light">Cookies técnicas:</strong> necesarias para
              facilitar la navegación y garantizar el funcionamiento básico del sitio.
            </li>
            <li>
              <strong className="text-light">Cookies analíticas:</strong> nos permiten
              conocer el uso de la web con fines estadísticos y de mejora, siempre de
              forma agregada.
            </li>
          </ul>
          <h2 className="text-xl font-semibold text-light">Gestión de cookies</h2>
          <p className="text-sm text-slate-300">
            Puedes aceptar o rechazar las cookies mediante el banner que aparece al inicio
            de la visita. También puedes configurarlas desde tu navegador (consultar la
            documentación del navegador para conocer los pasos concretos).
          </p>
          <h2 className="text-xl font-semibold text-light">Actualizaciones</h2>
          <p className="text-sm text-slate-300">
            Revisamos periódicamente esta política para adaptarla a nuevas normativas o
            cambios en nuestro uso de cookies.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicyPage;

---

Nota: Para cumplir con las primeras instrucciones del proyecto (TypeScript, Tailwind, Framer Motion, Helmet, etc.), fue necesario ampliar el `package.json` respecto al bloque “CRITICAL DEPLOYMENT” final, que resultaba incompatible con dichos requisitos.