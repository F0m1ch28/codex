import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const researchAreas = [
  {
    title: "Química en estado sólido",
    description:
      "Estudiamos electrolitos sulfídicos y óxidos estables que faciliten la manufactura en España con seguridad y densidad energética elevadas.",
    highlights: [
      "Colaboraciones con centros europeos para caracterización de interfaces.",
      "Análisis in situ con espectroscopía y microscopía electrónica.",
      "Prototipos modulares compatibles con producción industrial."
    ]
  },
  {
    title: "Degradación y vida útil",
    description:
      "Modelamos la degradación electroquímica y térmica con datos reales para definir estrategias de operación que prolonguen los ciclos.",
    highlights: [
      "Gemelos digitales que anticipan envejecimiento en celdas y memorias térmicas.",
      "Algoritmos que ajustan ventanas de operación en función de las condiciones.",
      "Programas de reacondicionamiento para segundas vidas industriales."
    ]
  },
  {
    title: "Integración en red",
    description:
      "Ensayamos configuraciones multi-tecnología para evaluar la robustez ante eventos de frecuencia y tensión en la red peninsular.",
    highlights: [
      "Bancos de pruebas con simuladores de red y variabilidad renovable.",
      "Análisis de servicios auxiliares, arranque autónomo y black-start.",
      "Validación en entornos reales con partners de distribución."
    ]
  },
  {
    title: "Gestión térmica",
    description:
      "Optimizamos el intercambio de calor y el uso de materiales de cambio de fase para reducir pérdidas y mejorar la disponibilidad.",
    highlights: [
      "Modelos CFD para evaluar gradientes en contenedores térmicos.",
      "Sensores de fibra óptica y algoritmos de balance energético.",
      "Integración con procesos industriales para aprovechar excedentes."
    ]
  }
];

const resourceLibrary = [
  {
    title: "Densidad energética en celdas de estado sólido (Libro blanco 2024)",
    link: "https://example.com/estado-solido-libro-blanco",
    description:
      "Metodologías de escalado y resultados experimentales con materiales desarrollados en colaboración europea."
  },
  {
    title: "Guía de operación híbrida ion-litio y térmico",
    link: "https://example.com/guia-operacion-hibrida",
    description:
      "Buenas prácticas de operación en plantas industriales con enfoque en eficiencia térmica y eléctrica."
  },
  {
    title: "Recomendaciones para integración en redes distribuidas",
    link: "https://example.com/integracion-red",
    description:
      "Modelos y casos de uso para coordinar almacenamiento y generación renovable en redes múltiples."
  },
  {
    title: "Estudio de degradación de bancos térmicos",
    link: "https://example.com/degradacion-bancos-termicos",
    description:
      "Análisis de materiales de cambio de fase y estrategias para mantener la homogeneidad energética."
  }
];

const ResearchPage = () => {
  return (
    <>
      <Helmet>
        <title>I+D en Almacenamiento | EnergíaVolta Iberia</title>
        <meta
          name="description"
          content="Descubre las líneas de investigación de EnergíaVolta Iberia en química de estado sólido, degradación, integración de red y gestión térmica."
        />
        <link
          rel="canonical"
          href="https://www.energiavoltaiberia.com/investigacion"
        />
      </Helmet>
      <section className="relative overflow-hidden bg-primary/80">
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/70 to-primary/40" />
        <div className="relative mx-auto max-w-6xl px-6 py-24">
          <span className="text-xs uppercase tracking-[0.3em] text-secondary">
            I+D en Almacenamiento
          </span>
          <h1 className="mt-4 text-4xl font-semibold text-light md:text-5xl">
            Investigación aplicada para desbloquear la nueva generación de
            almacenamiento energético
          </h1>
          <p className="mt-6 max-w-3xl text-slate-300">
            Nuestro laboratorio conecta química avanzada, ingeniería de sistemas y
            análisis de datos para acelerar la transición energética industrial.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto grid max-w-6xl gap-8 md:grid-cols-2">
          {researchAreas.map((area) => (
            <motion.article
              key={area.title}
              className="rounded-3xl border border-white/10 bg-white/5 p-8"
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-2xl font-semibold text-light">{area.title}</h2>
              <p className="mt-4 text-slate-300">{area.description}</p>
              <ul className="mt-6 space-y-3 text-sm text-slate-300">
                {area.highlights.map((highlight) => (
                  <li key={highlight} className="flex items-start gap-3">
                    <span className="mt-1 h-2 w-2 rounded-full bg-secondary" />
                    <span>{highlight}</span>
                  </li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section-padding bg-primary/60">
        <div className="mx-auto max-w-6xl">
          <h2 className="text-3xl font-semibold text-light">
            Programas de colaboración
          </h2>
          <p className="mt-4 text-slate-300">
            Participamos en consorcios nacionales y europeos para impulsar nuevas
            tecnologías de almacenamiento. Nuestros programas incluyen co-desarrollo
            con universidades, pymes tecnológicas y grandes operadores industriales.
          </p>
          <ul className="mt-6 grid gap-4 text-sm text-slate-300 md:grid-cols-2">
            <li className="rounded-3xl bg-primary/60 p-6">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Laboratorios compartidos
              </h3>
              <p className="mt-3">
                Espacios equipados con cámaras climáticas, caracterización electroquímica
                y bancos térmicos instrumentados.
              </p>
            </li>
            <li className="rounded-3xl bg-primary/60 p-6">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Programas de campo
              </h3>
              <p className="mt-3">
                Pilotos industriales que validan tecnologías emergentes en entornos
                reales con métricas operativas exigentes.
              </p>
            </li>
            <li className="rounded-3xl bg-primary/60 p-6">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Observatorio regulatorio
              </h3>
              <p className="mt-3">
                Seguimiento de marcos europeos y españoles para anticipar requisitos,
                permisos y estándares técnicos.
              </p>
            </li>
            <li className="rounded-3xl bg-primary/60 p-6">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Formación técnica
              </h3>
              <p className="mt-3">
                Capacitación en operación segura, análisis de datos y mantenimiento
                predictivo para equipos industriales.
              </p>
            </li>
          </ul>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto max-w-5xl">
          <h2 className="text-3xl font-semibold text-light">Biblioteca de recursos</h2>
          <div className="mt-8 space-y-6">
            {resourceLibrary.map((resource) => (
              <motion.article
                key={resource.title}
                className="rounded-3xl border border-white/10 bg-white/5 p-6"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.5 }}
              >
                <h3 className="text-xl font-semibold text-light">
                  {resource.title}
                </h3>
                <p className="mt-2 text-sm text-slate-300">{resource.description}</p>
                <a
                  href={resource.link}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-secondary transition hover:text-accent"
                >
                  Consultar recurso
                  <svg
                    className="h-4 w-4"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M7 17L17 7M7 7h10v10" />
                  </svg>
                </a>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding bg-primary/60">
        <div className="mx-auto max-w-6xl rounded-3xl border border-white/10 bg-white/5 p-8">
          <h2 className="text-3xl font-semibold text-light">
            Centro de visualización de datos
          </h2>
          <p className="mt-4 text-slate-300">
            Interpretamos la operación de los sistemas con indicadores que muestran la
            salud de cada activo y su contribución a la flexibilidad de la red.
          </p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            <div className="rounded-2xl bg-primary/60 p-6">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Salud de activos
              </h3>
              <p className="mt-3 text-sm text-slate-300">
                Índices de degradación inferior al 0.8% anual gracias a estrategias de
                operación adaptativa.
              </p>
            </div>
            <div className="rounded-2xl bg-primary/60 p-6">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Factor de disponibilidad
              </h3>
              <p className="mt-3 text-sm text-slate-300">
                Disponibilidad promedio superior al 97% con mantenimiento predictivo y
                monitorización continua.
              </p>
            </div>
            <div className="rounded-2xl bg-primary/60 p-6">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Flexibilidad aportada
              </h3>
              <p className="mt-3 text-sm text-slate-300">
                Más de 310 GWh modulados en 2023 para estabilizar la red y acompañar
                penetración renovable.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ResearchPage;