import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const technologies = [
  {
    title: "Megapacks ion-litio",
    description:
      "Contenedores con celdas LFP y NMC optimizadas para ciclos intensivos. Integran gestión térmica líquida y sistemas de contra-incendios inteligentes.",
    image:
      "https://images.unsplash.com/photo-1580894908361-967195033215?auto=format&fit=crop&w=1400&q=80",
    features: [
      "Respuesta sub-segundo para servicios de regulación primaria.",
      "Densidad energética elevada en footprint reducido.",
      "Control predictivo que ajusta estados de carga según mercado."
    ]
  },
  {
    title: "Baterías de flujo",
    description:
      "Sistemas de vanadio y zinc-bromo que separan la potencia de la energía. Perfectos para duraciones entre 4 y 12 horas sin degradación acelerada.",
    image:
      "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1400&q=80",
    features: [
      "Reservorios modulares sin límite práctico de energía.",
      "Electrolitos monitorizados para evitar cristalización.",
      "Electrónica bidireccional preparada para redes industriales."
    ]
  },
  {
    title: "Almacenamiento CAES",
    description:
      "Compresión de aire en cavernas o depósitos de hormigón reforzado con recuperación térmica integrada para mantener la eficiencia.",
    image:
      "https://images.unsplash.com/photo-1563861826100-9cb868fdbe1e?auto=format&fit=crop&w=1400&q=80",
    features: [
      "Entrega de potencia sostenida durante más de 8 horas.",
      "Ideal para integrar renovables a gran escala.",
      "Diseños adaptables a minas, acuíferos o estructuras industriales."
    ]
  },
  {
    title: "Bancos térmicos",
    description:
      "Aprovechan calor residual y excedentes eléctricos para cargar materiales de cambio de fase, sales fundidas o grafito.",
    image:
      "https://images.unsplash.com/photo-1509395062183-67c5ad6faff9?auto=format&fit=crop&w=1400&q=80",
    features: [
      "Temperaturas controladas entre 80 °C y 550 °C.",
      "Instrumentación con fibra óptica y válvulas electrónicas.",
      "Desplazamiento de calor en procesos agroalimentarios y químicos."
    ]
  },
  {
    title: "Hidrógeno verde",
    description:
      "Electrolizadores PEM y pilas reversibles integradas con almacenamiento gaseoso para servicios de larga duración.",
    image:
      "https://images.unsplash.com/photo-1618005198892-1102dcfffba4?auto=format&fit=crop&w=1400&q=80",
    features: [
      "Operación coordinada con tarifas horarias y excedentes renovables.",
      "Sistemas de compresión y almacenamiento modular.",
      "Producción de electricidad y calor mediante pilas reversibles."
    ]
  }
];

const analytics = [
  {
    metric: "Eficiencia cíclica",
    detail: "Ion-litio 92%, Flujo 86%, CAES 72%, Térmico 84%, Hidrógeno 55%"
  },
  {
    metric: "Ventana operativa",
    detail: "Ion-litio 0.5-4 h, Flujo 4-12 h, CAES 6-10 h, Térmico 2-24 h, Hidrógeno 24-200 h"
  },
  {
    metric: "Temperatura de trabajo",
    detail: "Ion-litio 15-35 °C, Flujo 10-40 °C, Térmico 80-550 °C, Hidrógeno -253 a 40 °C"
  }
];

const TechnologiesPage = () => {
  return (
    <>
      <Helmet>
        <title>Sistemas Avanzados | Tecnologías de Almacenamiento</title>
        <meta
          name="description"
          content="Conoce los sistemas avanzados de almacenamiento de EnergíaVolta Iberia: megapacks ion-litio, flujo, CAES, bancos térmicos e hidrógeno."
        />
        <link
          rel="canonical"
          href="https://www.energiavoltaiberia.com/tecnologias-almacenamiento"
        />
      </Helmet>

      <section className="relative overflow-hidden bg-primary/80">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/70 to-primary/30" />
        <div className="relative mx-auto flex max-w-6xl flex-col gap-10 px-6 py-24 md:flex-row md:items-center md:justify-between">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-secondary">
              Sistemas Avanzados
            </span>
            <h1 className="mt-4 text-4xl font-semibold text-light md:text-5xl">
              Portafolio de tecnologías diseñado para cada escenario industrial
            </h1>
            <p className="mt-6 text-slate-300">
              Seleccionamos, dimensionamos y operamos tecnologías de almacenamiento
              que responden a necesidades reales de potencia, duración, temperatura
              y sincronización con la red española.
            </p>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <h2 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
              Cobertura tecnológica
            </h2>
            <p className="mt-4 text-sm text-slate-300">
              Cada proyecto combina hardware avanzado con nuestra plataforma digital
              para asegurar rendimiento constante, monitorización y adaptación a
              mercados energéticos.
            </p>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto max-w-6xl space-y-12">
          {technologies.map((technology, index) => (
            <motion.article
              key={technology.title}
              className="grid gap-8 rounded-3xl border border-white/10 bg-white/5 p-6 md:grid-cols-2 md:p-10"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
            >
              <div className="space-y-4">
                <h2 className="text-2xl font-semibold text-light">
                  {technology.title}
                </h2>
                <p className="text-slate-300">{technology.description}</p>
                <ul className="space-y-3 text-sm text-slate-300">
                  {technology.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <span className="mt-1 h-2 w-2 rounded-full bg-secondary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="overflow-hidden rounded-3xl border border-white/10">
                <img
                  src={technology.image}
                  alt={`Sistema de ${technology.title}`}
                  className="h-full w-full object-cover"
                  loading="lazy"
                />
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section-padding bg-primary/60">
        <div className="mx-auto max-w-6xl grid gap-10 md:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <h2 className="text-3xl font-semibold text-light">
              Sincronización de red
            </h2>
            <p className="mt-4 text-slate-300">
              Nuestra plataforma coordina cada sistema con señales en tiempo real
              de la red española, garantizando estabilidad y aprovechando ventanas
              renovables. Integración con protocolos IEC, modbus seguro y ciberseguridad
              por diseño.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-300">
              <li>• Enlaces redundantes con latencia inferior a 80 ms.</li>
              <li>• Algoritmos de predicción que anticipan congestiones.</li>
              <li>• Automatización de arranque y parada coordinada con el operador.</li>
              <li>• Reportes en tiempo real con dashboards customizables.</li>
            </ul>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <h2 className="text-3xl font-semibold text-light">
              Panel analítico
            </h2>
            <p className="mt-4 text-slate-300">
              Datos integrados para evaluar eficiencia, duración y seguridad en cada
              tecnología desplegada. Visualizamos KPIs críticos para la toma de
              decisiones estratégicas.
            </p>
            <div className="mt-6 space-y-4">
              {analytics.map((item) => (
                <div key={item.metric} className="rounded-2xl bg-primary/60 p-4">
                  <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                    {item.metric}
                  </h3>
                  <p className="mt-2 text-sm text-slate-300">{item.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default TechnologiesPage;