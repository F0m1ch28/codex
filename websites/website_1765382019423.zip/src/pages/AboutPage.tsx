import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const teamMembers = [
  {
    name: "Claudia Ferrer",
    role: "Directora Técnica",
    bio: "Ingeniera industrial con 15 años de experiencia en almacenamiento con ion-litio y control térmico. Lidera la innovación en sistemas híbridos.",
    image:
      "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80",
    linkedin: "https://www.linkedin.com"
  },
  {
    name: "Sergio Molina",
    role: "Responsable de Integración Digital",
    bio: "Especialista en plataformas de gestión energética, desarrolló el gemelo digital utilizado para coordinar activos flexibles en 12 regiones.",
    image:
      "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80",
    linkedin: "https://www.linkedin.com"
  },
  {
    name: "Laura Vicens",
    role: "Líder de I+D Materiales",
    bio: "Doctora en química de materiales con foco en electrolitos sólidos y reciclaje circular, coordina alianzas con universidades.",
    image:
      "https://images.unsplash.com/photo-1544723795-3fb4686f5b31?auto=format&fit=crop&w=600&q=80",
    linkedin: "https://www.linkedin.com"
  },
  {
    name: "Álvaro Lafuente",
    role: "Arquitecto de Proyectos Industriales",
    bio: "Especialista en ingeniería de procesos, diseña la integración energética en sectores agroalimentarios, químicos y logística refrigerada.",
    image:
      "https://images.unsplash.com/photo-1511367461989-f85a21fda167?auto=format&fit=crop&w=600&q=80",
    linkedin: "https://www.linkedin.com"
  }
];

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>Ingeniería de la Transición | EnergíaVolta Iberia</title>
        <meta
          name="description"
          content="Conoce la misión, el origen y la metodología de EnergíaVolta Iberia, así como nuestra red colaborativa y el equipo técnico."
        />
        <link
          rel="canonical"
          href="https://www.energiavoltaiberia.com/nosotros"
        />
        <meta
          property="og:title"
          content="Ingeniería de la Transición | EnergíaVolta Iberia"
        />
        <meta
          property="og:description"
          content="Un equipo multidisciplinar especializado en almacenamiento energético industrial y economía circular."
        />
      </Helmet>
      <section className="relative overflow-hidden bg-primary/80">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/80 to-primary/40" />
        <div className="relative mx-auto flex max-w-6xl flex-col gap-10 px-6 py-24 md:flex-row md:items-center md:justify-between">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-secondary">
              Ingeniería de la Transición
            </span>
            <h1 className="mt-4 text-4xl font-semibold text-light md:text-5xl">
              Diseñamos arquitectura energética para industrias que se transforman
              hacia un modelo circular.
            </h1>
            <p className="mt-6 text-slate-300">
              EnergíaVolta Iberia nació para acompañar a las empresas que necesitan
              flexibilidad energética sin detener su producción. Integramos
              almacenamiento avanzado, análisis de datos y operaciones seguras.
            </p>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <p className="font-mono text-sm uppercase tracking-[0.3em] text-secondary">
              Cobertura
            </p>
            <p className="mt-4 text-lg text-slate-200">
              Más de 600 MW conectados en múltiples sectores industriales,
              coordinados desde Madrid con soporte regional en Bilbao, Sevilla y
              Zaragoza.
            </p>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto max-w-5xl space-y-12">
          <motion.article
            className="rounded-3xl border border-white/10 bg-white/5 p-8"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-2xl font-semibold text-light">Misión</h2>
            <p className="mt-4 text-slate-300">
              Crear ecosistemas energéticos resilientes para la industria española
              mediante soluciones de almacenamiento adaptadas a cada proceso
              productivo. Trabajamos con rigor técnico, apoyo en datos y visión a
              largo plazo.
            </p>
          </motion.article>

          <motion.article
            className="rounded-3xl border border-white/10 bg-white/5 p-8"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h2 className="text-2xl font-semibold text-light">
              Origen de la compañía
            </h2>
            <p className="mt-4 text-slate-300">
              EnergíaVolta Iberia se fundó en 2016 por especialistas en almacenamiento
              y automatización industrial con experiencia en mercados energéticos
              europeos. Desde el inicio combinamos ingeniería de campo y algoritmos
              de predicción para ofrecer soluciones integradas.
            </p>
          </motion.article>

          <motion.article
            className="rounded-3xl border border-white/10 bg-white/5 p-8"
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h2 className="text-2xl font-semibold text-light">
              Metodología de trabajo
            </h2>
            <ul className="mt-6 space-y-4 text-slate-300">
              <li>
                <strong className="text-light">1. Diagnóstico energético:</strong>{" "}
                análisis integral de cargas, perfiles térmicos y calidad de red.
              </li>
              <li>
                <strong className="text-light">2. Modelización:</strong> simulación con
                gemelos digitales para dimensionar sistemas híbridos y estimar su
                interacción con la red.
              </li>
              <li>
                <strong className="text-light">3. Implementación:</strong> despliegue
                modular de contenedores, bancos térmicos y plataformas digitales con
                protocolos seguros.
              </li>
              <li>
                <strong className="text-light">4. Operación continua:</strong> control
                en tiempo real, mantenimiento predictivo y optimización a lo largo del
                ciclo de vida.
              </li>
            </ul>
          </motion.article>
        </div>
      </section>

      <section className="section-padding bg-primary/60">
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-light">
                Red colaborativa de socios
              </h2>
              <p className="mt-3 text-slate-300">
                Trabajamos con empresas de ingeniería, operadores logísticos,
                universidades y centros tecnológicos para acelerar la adopción de
                almacenamiento energético. Esta red garantiza disponibilidad de
                componentes, respaldo técnico y conocimiento local en toda la península.
              </p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-sm text-slate-300">
              <h3 className="font-display text-sm uppercase tracking-[0.3em] text-secondary">
                Ámbitos clave
              </h3>
              <ul className="mt-4 space-y-2">
                <li>• Integradores industriales especializados por sector.</li>
                <li>• Centros de investigación en química y electrónica de potencia.</li>
                <li>• Operadores O&M y redes de servicios auxiliares.</li>
                <li>• Plataformas digitales y ciberseguridad energética.</li>
              </ul>
            </div>
          </div>

          <div className="mt-16">
            <h2 className="text-3xl font-semibold text-light">
              Equipo técnico
            </h2>
            <div className="mt-8 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
              {teamMembers.map((member) => (
                <motion.article
                  key={member.name}
                  className="rounded-3xl border border-white/10 bg-white/5 p-6 text-center"
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.5 }}
                >
                  <img
                    src={member.image}
                    alt={`Retrato de ${member.name}`}
                    className="mx-auto h-32 w-32 rounded-full object-cover"
                    loading="lazy"
                  />
                  <h3 className="mt-5 font-display text-lg text-light">
                    {member.name}
                  </h3>
                  <p className="text-xs uppercase tracking-widest text-secondary">
                    {member.role}
                  </p>
                  <p className="mt-3 text-sm text-slate-300">{member.bio}</p>
                  <a
                    href={member.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-4 inline-flex items-center justify-center rounded-full border border-white/10 px-4 py-2 text-xs font-semibold text-slate-200 transition hover:border-secondary hover:text-secondary"
                  >
                    Ver perfil profesional
                  </a>
                </motion.article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="mx-auto max-w-6xl rounded-3xl border border-white/10 bg-white/5 p-8">
          <h2 className="text-3xl font-semibold text-light">
            Principios de sostenibilidad y economía circular
          </h2>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            <div className="rounded-2xl bg-primary/60 p-6">
              <h3 className="font-display text-lg text-accent">Diseño modular</h3>
              <p className="mt-3 text-sm text-slate-300">
                Componentes intercambiables que prolongan la vida útil y permiten
                repotenciaciones sin detener la operación industrial.
              </p>
            </div>
            <div className="rounded-2xl bg-primary/60 p-6">
              <h3 className="font-display text-lg text-accent">Uso eficiente de recursos</h3>
              <p className="mt-3 text-sm text-slate-300">
                Integración de calor residual, electrolitos reutilizables y materiales
                certificados, con seguimiento de trazabilidad.
              </p>
            </div>
            <div className="rounded-2xl bg-primary/60 p-6">
              <h3 className="font-display text-lg text-accent">Reciclaje colaborativo</h3>
              <p className="mt-3 text-sm text-slate-300">
                Programas con partners para recuperar metales críticos y reincorporarlos
                a nuevas series de baterías y sistemas híbridos.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;