/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#0F172A",
        accent: "#F59E0B",
        secondary: "#8B5CF6",
        light: "#F1F5F9"
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui"],
        display: ["'Space Grotesk'", "sans-serif"],
        mono: ["'Roboto Mono'", "monospace"]
      },
      backgroundImage: {
        "grid-pattern": "radial-gradient(circle at center, rgba(139, 92, 246, 0.15), transparent 60%)"
      }
    }
  },
  plugins: []
};