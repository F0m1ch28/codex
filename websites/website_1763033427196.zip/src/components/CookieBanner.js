import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('cnn-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('cnn-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          We use cookies to personalize your Canada News Network experience and to understand our
          audience. Review our{' '}
          <a href="/cookie-policy" className={styles.link}>
            Cookie Policy
          </a>
          .
        </p>
      </div>
      <button className={styles.button} onClick={handleAccept}>
        Accept & Continue
      </button>
    </div>
  );
};

export default CookieBanner;