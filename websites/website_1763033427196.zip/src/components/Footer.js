import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.grid}>
        <div className={styles.brandBlock}>
          <h2 className={styles.heading}>Canada News Network</h2>
          <p className={styles.text}>
            Independent Canadian journalism delivering national conversations with regional depth,
            powered by correspondents across every province and territory.
          </p>
        </div>
        <div className={styles.column}>
          <h3 className={styles.subheading}>Editorial</h3>
          <nav aria-label="Editorial links">
            <ul className={styles.list}>
              <li>
                <NavLink to="/politics">Politics</NavLink>
              </li>
              <li>
                <NavLink to="/economy">Economy</NavLink>
              </li>
              <li>
                <NavLink to="/environment">Environment</NavLink>
              </li>
              <li>
                <NavLink to="/opinion">Opinion</NavLink>
              </li>
            </ul>
          </nav>
        </div>
        <div className={styles.column}>
          <h3 className={styles.subheading}>Company</h3>
          <nav aria-label="Company links">
            <ul className={styles.list}>
              <li>
                <NavLink to="/about">About</NavLink>
              </li>
              <li>
                <NavLink to="/services">Services</NavLink>
              </li>
              <li>
                <NavLink to="/contact">Contact</NavLink>
              </li>
              <li>
                <NavLink to="/privacy">Privacy Policy</NavLink>
              </li>
              <li>
                <NavLink to="/terms">Terms of Use</NavLink>
              </li>
              <li>
                <NavLink to="/cookie-policy">Cookie Policy</NavLink>
              </li>
            </ul>
          </nav>
        </div>
        <address className={styles.column} aria-label="Contact details">
          <h3 className={styles.subheading}>Connect</h3>
          <p className={styles.text}>123 Bay Street, Toronto, ON M5J 2S1, Canada</p>
          <p className={styles.text}>
            Phone: <a href="tel:+14165557890">+1 (416) 555-7890</a>
          </p>
          <p className={styles.text}>
            Email: <a href="mailto:info@canadanewsnetwork.ca">info@canadanewsnetwork.ca</a>
          </p>
        </address>
      </div>
      <div className={styles.bottomRow}>
        <p>© {new Date().getFullYear()} Canada News Network. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;