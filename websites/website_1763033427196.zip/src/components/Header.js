import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Top Stories' },
  { path: '/politics', label: 'Politics' },
  { path: '/economy', label: 'Economy' },
  { path: '/technology', label: 'Technology' },
  { path: '/health', label: 'Health' },
  { path: '/environment', label: 'Environment' },
  { path: '/culture', label: 'Culture' },
  { path: '/sports', label: 'Sports' },
  { path: '/opinion', label: 'Opinion' },
  { path: '/about', label: 'About' },
  { path: '/services', label: 'Services' },
  { path: '/contact', label: 'Contact' }
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [hasScrolled, setHasScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const onScroll = () => {
      setHasScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`${styles.header} ${hasScrolled ? styles.headerScrolled : ''}`}
      role="banner"
    >
      <div className={styles.brandRow}>
        <NavLink to="/" className={styles.brand} aria-label="Canada News Network home">
          <span className={styles.brandAccent}>Canada</span>
          <span className={styles.brandText}>News Network</span>
        </NavLink>
        <button
          className={styles.menuButton}
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-expanded={mobileOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
      <nav
        id="primary-navigation"
        className={`${styles.nav} ${mobileOpen ? styles.open : ''}`}
        aria-label="Primary navigation"
      >
        <ul className={styles.navList}>
          {navItems.map((item) => (
            <li key={item.path} className={styles.navItem}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                }
              >
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
        <div className={styles.navFooter}>
          <p className={styles.navTagline}>
            Trusted Canadian journalism from coast to coast to coast.
          </p>
          <a className={styles.supportLink} href="#newsletter">
            Subscribe to our briefing
          </a>
        </div>
      </nav>
    </header>
  );
};

export default Header;