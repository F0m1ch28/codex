import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Politics from './pages/Politics';
import Economy from './pages/Economy';
import Technology from './pages/Technology';
import Health from './pages/Health';
import Environment from './pages/Environment';
import Culture from './pages/Culture';
import Sports from './pages/Sports';
import Opinion from './pages/Opinion';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const App = () => {
  return (
    <BrowserRouter>
      <div className="appContainer">
        <Header />
        <div className="contentShell">
          <main className="appMain" id="main-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/politics" element={<Politics />} />
              <Route path="/economy" element={<Economy />} />
              <Route path="/technology" element={<Technology />} />
              <Route path="/health" element={<Health />} />
              <Route path="/environment" element={<Environment />} />
              <Route path="/culture" element={<Culture />} />
              <Route path="/sports" element={<Sports />} />
              <Route path="/opinion" element={<Opinion />} />
              <Route path="/about" element={<About />} />
              <Route path="/services" element={<Services />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/cookie-policy" element={<CookiePolicy />} />
            </Routes>
          </main>
          <Footer />
        </div>
        <CookieBanner />
        <ScrollToTop />
      </div>
    </BrowserRouter>
  );
};

export default App;