import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Environment = () => {
  const stories = [
    {
      title: 'Prairie water-sharing pact prepares for drought season',
      summary:
        'Provinces collaborate on conservation, supporting farmers and Indigenous guardianship programs.',
      image: 'https://picsum.photos/900/600?random=213'
    },
    {
      title: 'Marine protected area expands off Haida Gwaii',
      summary:
        'Co-management with Haida Nation strengthens biodiversity safeguards and sustainable harvest practices.',
      image: 'https://picsum.photos/900/600?random=214'
    },
    {
      title: 'Northern communities pilot climate-ready housing',
      summary:
        'New modular homes engineered in Yukon withstand permafrost thaw while lowering energy costs.',
      image: 'https://picsum.photos/900/600?random=215'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Environment & Climate | Canada News Network</title>
        <meta
          name="description"
          content="Canadian climate policy, conservation, and environmental stories with national impact."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Environment</p>
          <h1>Climate solutions rooted in Canadian landscapes</h1>
          <p>
            Our climate reporters spotlight adaptation, resilience, and the communities leading conservation efforts across the country.
          </p>
        </header>
        <div className={styles.grid}>
          {stories.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">View climate coverage</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Environment;