import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Technology = () => {
  const stories = [
    {
      title: 'Montreal AI consortium launches ethics-first incubator',
      summary:
        'Startups join forces with ethicists and Indigenous knowledge keepers to design inclusive algorithms.',
      image: 'https://picsum.photos/900/600?random=207'
    },
    {
      title: 'Atlantic Canada invests in ocean robotics network',
      summary:
        'A new lab in Halifax develops autonomous vessels to monitor marine ecosystems and fisheries health.',
      image: 'https://picsum.photos/900/600?random=208'
    },
    {
      title: 'Rural broadband leapfrogs with satellite initiatives',
      summary:
        'Northern communities gain reliable high-speed internet through partnerships with made-in-Canada satellite operators.',
      image: 'https://picsum.photos/900/600?random=209'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Technology & Innovation | Canada News Network</title>
        <meta
          name="description"
          content="Canadian technology breakthroughs and innovation trends covered by Canada News Network."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Technology</p>
          <h1>Innovation that keeps Canada competitive</h1>
          <p>
            We follow labs, startups, and researchers pushing boundaries in artificial intelligence,
            clean technology, aerospace, and digital equity across Canada.
          </p>
        </header>
        <div className={styles.grid}>
          {stories.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">Discover innovation</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Technology;