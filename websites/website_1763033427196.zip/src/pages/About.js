import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <Helmet>
        <title>About Canada News Network</title>
        <meta
          name="description"
          content="Learn more about the mission, vision, and team behind Canada News Network."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>About Us</p>
          <h1>Independent journalism devoted to Canada&apos;s stories</h1>
          <p>
            Canada News Network is a national newsroom founded by journalists, technologists, and
            community partners who believe Canadians deserve rigorous, inclusive reporting that
            connects every region.
          </p>
        </header>

        <div className={styles.missionGrid}>
          <article className={styles.card}>
            <h2>Our Mission</h2>
            <p>
              We deliver trustworthy journalism that reflects Canada&apos;s diversity, empowers civic
              engagement, and amplifies voices that shape the future. Our investigations drive change,
              our features deepen understanding, and our daily briefings keep decision-makers informed.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Our Values</h2>
            <ul>
              <li>Accuracy and accountability in every story.</li>
              <li>Diverse perspectives and equitable representation.</li>
              <li>Innovation in storytelling and audience engagement.</li>
              <li>Partnerships that strengthen democratic dialogue.</li>
            </ul>
          </article>
        </div>

        <section className={styles.timeline}>
          <h2>Milestones</h2>
          <div className={styles.timelineGrid}>
            <article>
              <span>2016</span>
              <p>Canada News Network launches with bureaus in Toronto, Vancouver, and Halifax.</p>
            </article>
            <article>
              <span>2019</span>
              <p>Indigenous Affairs desk established in partnership with Indigenous journalists.</p>
            </article>
            <article>
              <span>2021</span>
              <p>Data journalism lab debuts interactive explainers across climate and economics.</p>
            </article>
            <article>
              <span>2023</span>
              <p>Expanded northern coverage with correspondents based in Iqaluit and Yellowknife.</p>
            </article>
          </div>
        </section>

        <section className={styles.commitment}>
          <h2>Our Commitment to Canada</h2>
          <p>
            We are headquartered in Toronto with bureaus in Montréal, Halifax, Winnipeg, Saskatoon,
            Edmonton, Calgary, Vancouver, Whitehorse, and St. John’s. Collaborations with community
            reporters ensure that local context guides our national narratives.
          </p>
        </section>
      </section>
    </>
  );
};

export default About;