import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './StaticPage.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | Canada News Network</title>
        <meta
          name="description"
          content="Terms and conditions for using the Canada News Network website and services."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Legal</p>
          <h1>Terms of Use</h1>
        </header>
        <article className={styles.content}>
          <h2>1. Overview</h2>
          <p>
            These Terms of Use govern your access to Canada News Network digital platforms. By
            using our services, you agree to comply with all applicable laws and regulations.
          </p>

          <h2>2. Intellectual Property</h2>
          <p>
            All content, including articles, multimedia, and data visualizations, is the property of
            Canada News Network unless otherwise credited. Content may not be reproduced without
            written permission.
          </p>

          <h2>3. User Contributions</h2>
          <p>
            When submitting tips, comments, or materials, you grant Canada News Network permission
            to use and publish the content in accordance with our editorial standards.
          </p>

          <h2>4. Liability</h2>
          <p>
            Canada News Network strives for accuracy but does not guarantee the completeness of
            information provided. We are not liable for how external partners use our reporting.
          </p>
        </article>
      </section>
    </>
  );
};

export default Terms;