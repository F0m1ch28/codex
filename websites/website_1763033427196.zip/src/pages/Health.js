import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Health = () => {
  const stories = [
    {
      title: 'Community clinics expand culturally-safe care for urban Indigenous families',
      summary:
        'Toronto and Winnipeg teams integrate Elders, traditional healing, and language revitalization into primary care delivery.',
      image: 'https://picsum.photos/900/600?random=210'
    },
    {
      title: 'Atlantic researchers pioneer low-cost cardiac monitoring wearable',
      summary:
        'Dalhousie University engineers create an accessible device, now trialing in rural Nova Scotia and New Brunswick.',
      image: 'https://picsum.photos/900/600?random=211'
    },
    {
      title: 'Mental health supports scale across post-secondary campuses',
      summary:
        'Universities adopt rapid-access counsellor networks and peer support models shaped by student feedback.',
      image: 'https://picsum.photos/900/600?random=212'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Health | Canada News Network</title>
        <meta
          name="description"
          content="Health policy, research, and care innovation stories from Canada News Network."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Health</p>
          <h1>Care systems responding to Canadian needs</h1>
          <p>
            Our health desk covers public policy, frontline care, and groundbreaking research with a focus on accessibility and equity.
          </p>
        </header>
        <div className={styles.grid}>
          {stories.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">Explore health report</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Health;