import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Politics = () => {
  const stories = [
    {
      title: 'Federal-provincial housing pact reshapes urban planning',
      summary:
        'Premiers and Ottawa strike a multi-year accord to accelerate rental construction and empower municipalities with zoning flexibility.',
      image: 'https://picsum.photos/900/600?random=201'
    },
    {
      title: 'Indigenous self-governance bills advance with historic consensus',
      summary:
        'Legislation supporting self-determination in British Columbia and Yukon gains cross-party backing after extensive community consultations.',
      image: 'https://picsum.photos/900/600?random=202'
    },
    {
      title: 'Senate report urges modernization of emergency preparedness',
      summary:
        'A bipartisan panel calls for shared climate risk data, expedited disaster aid, and enhanced support for rural first responders.',
      image: 'https://picsum.photos/900/600?random=203'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Politics | Canada News Network</title>
        <meta
          name="description"
          content="Political reporting from Parliament Hill to provincial legislatures with analysis from Canada News Network."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Politics</p>
          <h1>Policy decisions shaping Canada&apos;s future</h1>
          <p>
            Canada News Network delivers balanced political reporting grounded in civic impact,
            tracking legislation, electoral dynamics, and governance in every province and territory.
          </p>
        </header>
        <div className={styles.grid}>
          {stories.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={`${story.title}`} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">Read full analysis</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Politics;