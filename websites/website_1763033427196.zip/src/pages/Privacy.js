import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './StaticPage.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Canada News Network</title>
        <meta
          name="description"
          content="How Canada News Network collects, uses, and protects your personal information."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Legal</p>
          <h1>Privacy Policy</h1>
        </header>
        <article className={styles.content}>
          <h2>Information we collect</h2>
          <p>
            We collect personal information you provide directly, such as newsletter sign-up
            details, and anonymous analytics data to improve our services.
          </p>

          <h2>How we use information</h2>
          <p>
            Data is used to personalize content, deliver newsletters, and analyze engagement. We do
            not sell personal information to third parties.
          </p>

          <h2>Security</h2>
          <p>
            We implement technical and organizational measures to protect data against unauthorized
            access. Contact privacy@canadanewsnetwork.ca with any concerns.
          </p>
        </article>
      </section>
    </>
  );
};

export default Privacy;