import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Culture = () => {
  const stories = [
    {
      title: 'Indigenous artists take centre stage at national festivals',
      summary:
        'New funding and curatorial leadership open prime stages for Indigenous performers across Canada.',
      image: 'https://picsum.photos/900/600?random=216'
    },
    {
      title: 'Francophone cinema renaissance shines at TIFF and FNC',
      summary:
        'Directors from Québec and New Brunswick earn international acclaim with bilingual storytelling.',
      image: 'https://picsum.photos/900/600?random=217'
    },
    {
      title: 'Calgary gallery reimagines public art for inclusive spaces',
      summary:
        'Designers collaborate with community groups to transform underutilized urban corners into cultural venues.',
      image: 'https://picsum.photos/900/600?random=218'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Culture & Arts | Canada News Network</title>
        <meta
          name="description"
          content="Arts, culture, and creative industry stories from every region in Canada."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Culture</p>
          <h1>Celebrating Canada&apos;s vibrant creative scene</h1>
          <p>
            We feature artists, festivals, and cultural movements that reflect the diverse identities of communities nationwide.
          </p>
        </header>
        <div className={styles.grid}>
          {stories.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">Meet the creators</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Culture;