import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Sports = () => {
  const stories = [
    {
      title: 'Winnipeg to host national curling trials with record attendance',
      summary:
        'Athletes prepare for an electric atmosphere as fans return to arenas in full force.',
      image: 'https://picsum.photos/900/600?random=219'
    },
    {
      title: 'Women’s soccer league launches with coast-to-coast franchises',
      summary:
        'A new professional league debuts in Halifax, Ottawa, Calgary, and Vancouver with homegrown talent.',
      image: 'https://picsum.photos/900/600?random=220'
    },
    {
      title: 'Para athletes secure funding boost ahead of winter games',
      summary:
        'Federal investment expands training facilities and cross-country competition opportunities.',
      image: 'https://picsum.photos/900/600?random=221'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Sports | Canada News Network</title>
        <meta
          name="description"
          content="Canadian sports updates, athlete profiles, and community athletics from Canada News Network."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Sports</p>
          <h1>Celebrating athletic excellence across Canada</h1>
          <p>
            Our sports bureau covers national leagues, grassroots programs, and inspiring athlete stories coast to coast.
          </p>
        </header>
        <div className={styles.grid}>
          {stories.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">Go to match report</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Sports;