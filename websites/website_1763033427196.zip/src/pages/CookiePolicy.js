import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './StaticPage.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Canada News Network</title>
        <meta
          name="description"
          content="Details about cookie usage on Canada News Network digital properties."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Legal</p>
          <h1>Cookie Policy</h1>
        </header>
        <article className={styles.content}>
          <h2>How we use cookies</h2>
          <p>
            Cookies help us remember preferences, understand usage patterns, and deliver relevant
            content. Essential cookies are required for site functionality.
          </p>

          <h2>Managing cookies</h2>
          <p>
            You may adjust browser settings to control cookies. Some features may not function
            properly if you disable essential cookies.
          </p>

          <h2>Third-party cookies</h2>
          <p>
            Analytics partners may set cookies on our behalf for performance measurement. These
            partners are contractually limited to using data for our purposes.
          </p>
        </article>
      </section>
    </>
  );
};

export default CookiePolicy;