import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    organization: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [statusMessage, setStatusMessage] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formState.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email))
      newErrors.email = 'Enter a valid email address.';
    if (!formState.message.trim()) newErrors.message = 'Let us know how we can help.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    setFormState((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    setErrors((prev) => ({ ...prev, [event.target.name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStatusMessage('Thanks for reaching out. Our team will respond within two business days.');
    setFormState({
      name: '',
      email: '',
      organization: '',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>Contact | Canada News Network</title>
        <meta
          name="description"
          content="Contact Canada News Network for media partnerships, editorial inquiries, or newsroom support."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Contact</p>
          <h1>We&apos;re listening</h1>
          <p>
            Connect with our newsroom for story tips, partnership opportunities, or speaking
            engagements. We value dialogue with readers in every region.
          </p>
        </header>

        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Name*</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formState.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby="name-error"
                required
              />
              {errors.name && (
                <p id="name-error" className={styles.error}>
                  {errors.name}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Email*</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formState.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby="email-error"
                required
              />
              {errors.email && (
                <p id="email-error" className={styles.error}>
                  {errors.email}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="organization">Organization</label>
              <input
                id="organization"
                name="organization"
                type="text"
                value={formState.organization}
                onChange={handleChange}
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="message">How can we help?*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formState.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby="message-error"
                required
              />
              {errors.message && (
                <p id="message-error" className={styles.error}>
                  {errors.message}
                </p>
              )}
            </div>

            <button type="submit" className={styles.submit}>
              Send message
            </button>
            {statusMessage && <p className={styles.success}>{statusMessage}</p>}
          </form>

          <aside className={styles.sidebar}>
            <div className={styles.contactCard}>
              <h2>Newsroom</h2>
              <p>
                Email:{' '}
                <a href="mailto:info@canadanewsnetwork.ca">info@canadanewsnetwork.ca</a>
              </p>
              <p>Phone: <a href="tel:+14165557890">+1 (416) 555-7890</a></p>
            </div>
            <div className={styles.contactCard}>
              <h2>Visit us</h2>
              <p>123 Bay Street, Toronto, ON M5J 2S1, Canada</p>
              <p>Hours: Monday – Friday, 8:30 a.m. – 6:00 p.m. ET</p>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
};

export default Contact;