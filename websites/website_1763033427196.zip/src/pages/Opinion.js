import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Opinion = () => {
  const commentaries = [
    {
      title: 'Why Atlantic offshore wind is a decisive moment for Canada',
      summary:
        'Energy analyst Rhea Boyle argues the east coast can lead Canada’s just transition while safeguarding fisheries.',
      image: 'https://picsum.photos/900/600?random=222'
    },
    {
      title: 'Investing in northern infrastructure is a sovereignty imperative',
      summary:
        'Former ambassador Mary Simon on how resilient northern communities anchor national security.',
      image: 'https://picsum.photos/900/600?random=223'
    },
    {
      title: 'Bilingual education as a bridge to reconciliation',
      summary:
        'Educator David Cardinal reflects on integrating Indigenous languages within French immersion programs.',
      image: 'https://picsum.photos/900/600?random=224'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Opinion & Analysis | Canada News Network</title>
        <meta
          name="description"
          content="Canadian perspectives, analysis, and opinion columns curated by Canada News Network."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Opinion</p>
          <h1>Canadian perspectives that challenge and inspire</h1>
          <p>
            Thought leaders from across the country offer insight and debate on policy, culture, and innovation, curated by our editorial board.
          </p>
        </header>
        <div className={styles.grid}>
          {commentaries.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">Read commentary</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Opinion;