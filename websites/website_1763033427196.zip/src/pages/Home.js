import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const Home = () => {
  const heroImage = 'https://picsum.photos/1600/900?random=101';
  const stats = useMemo(
    () => [
      { label: 'Regional bureaus', value: 12, suffix: '' },
      { label: 'Journalists nationwide', value: 148, suffix: '+' },
      { label: 'Daily readers', value: 2.6, suffix: 'M' },
      { label: 'Investigations published', value: 320, suffix: '+' }
    ],
    []
  );

  const latestNews = useMemo(
    () => [
      {
        title: 'Federal housing accord targets affordability breakthrough in cities',
        summary:
          'Ottawa and provincial leaders unveiled a bold plan to accelerate rental construction and protect tenants in the hottest urban markets.',
        region: 'National',
        image: 'https://picsum.photos/800/600?random=102'
      },
      {
        title: 'Atlantic Canada charts offshore wind roadmap for sustainable growth',
        summary:
          'Nova Scotia and Newfoundland consortiums align with Indigenous partners to accelerate renewable energy projects in coastal communities.',
        region: 'Atlantic',
        image: 'https://picsum.photos/800/600?random=103'
      },
      {
        title: 'Prairie growers pilot climate-smart grain network across Saskatchewan',
        summary:
          'Producers embrace regenerative agriculture, backed by new export incentives and local processing hubs.',
        region: 'Prairies',
        image: 'https://picsum.photos/800/600?random=104'
      },
      {
        title: 'Northern health teams expand culturally-safe care in Nunavut',
        summary:
          'A partnership with Inuit health practitioners is reshaping services and access in remote communities.',
        region: 'Northern',
        image: 'https://picsum.photos/800/600?random=105'
      },
      {
        title: 'Vancouver tech labs lead AI ethics coalition for responsible deployment',
        summary:
          'Startups and universities collaborate on an ethics framework that keeps Canadian innovators competitive and accountable.',
        region: 'West Coast',
        image: 'https://picsum.photos/800/600?random=106'
      },
      {
        title: 'Toronto arts scene elevates Indigenous creators on national stage',
        summary:
          'Galleries and festivals commit to long-term representation and cross-country touring partnerships.',
        region: 'Central',
        image: 'https://picsum.photos/800/600?random=107'
      }
    ],
    []
  );

  const regions = useMemo(
    () => [
      {
        name: 'Atlantic',
        description:
          'Stories from the Maritimes and Newfoundland & Labrador, covering fisheries, coastal resilience, and cultural resurgence.',
        image: 'https://picsum.photos/700/500?random=108'
      },
      {
        name: 'Québec',
        description:
          'Francophone perspectives on Québec’s political evolution, creative sectors, and technology corridors.',
        image: 'https://picsum.photos/700/500?random=109'
      },
      {
        name: 'Ontario',
        description:
          'Insightful reporting on policy, urban growth, finance, and community innovation across Canada’s largest province.',
        image: 'https://picsum.photos/700/500?random=110'
      },
      {
        name: 'Prairies',
        description:
          'Agriculture, energy transition, and grassroots movements from Manitoba, Saskatchewan, and Alberta.',
        image: 'https://picsum.photos/700/500?random=111'
      },
      {
        name: 'British Columbia',
        description:
          'Climate leadership, Pacific trade, and cultural voices shaping the West Coast.',
        image: 'https://picsum.photos/700/500?random=112'
      },
      {
        name: 'Northern Canada',
        description:
          'Reporting from Yukon, Northwest Territories, and Nunavut led by northern correspondents and Indigenous storytellers.',
        image: 'https://picsum.photos/700/500?random=113'
      }
    ],
    []
  );

  const multimediaItems = useMemo(
    () => [
      {
        title: 'Deep dive: The Arctic policy roundtable',
        type: 'Video',
        image: 'https://picsum.photos/900/600?random=114'
      },
      {
        title: 'Photo essay: Harvest season in the Annapolis Valley',
        type: 'Gallery',
        image: 'https://picsum.photos/900/600?random=115'
      },
      {
        title: 'Podcast: Building climate-resilient cities',
        type: 'Podcast',
        image: 'https://picsum.photos/900/600?random=116'
      }
    ],
    []
  );

  const serviceCards = useMemo(
    () => [
      {
        title: 'Investigative Desk',
        text: 'Long-form investigations uncovering accountability stories with national impact.',
        icon: '🧭'
      },
      {
        title: 'Community Reporting',
        text: 'Embedded local journalists amplifying voices at city councils, school boards, and grassroots forums.',
        icon: '🤝'
      },
      {
        title: 'Data Journalism',
        text: 'Interactive explainers and visualizations that unpack complex policy decisions.',
        icon: '📊'
      },
      {
        title: 'Indigenous Affairs',
        text: 'Coverage co-created with Indigenous reporters, respecting protocols and community priorities.',
        icon: '🪶'
      }
    ],
    []
  );

  const processSteps = useMemo(
    () => [
      {
        step: '1',
        title: 'Source verification',
        text: 'Every story begins with rigorous fact-checking and corroboration across trusted sources.'
      },
      {
        step: '2',
        title: 'Community consultation',
        text: 'We collaborate with community advisors to ensure context is accurate and respectful.'
      },
      {
        step: '3',
        title: 'Editorial review',
        text: 'Senior editors shape narratives for clarity, fairness, and public interest impact.'
      },
      {
        step: '4',
        title: 'Multiplatform delivery',
        text: 'Stories reach audiences where they are—web, video, audio, newsletters, and live events.'
      }
    ],
    []
  );

  const testimonials = useMemo(
    () => [
      {
        quote:
          'CNN (Canada News Network) consistently captures the nuance of regional issues with national relevance. It has become essential reading in our newsroom.',
        name: 'Marie Gagnon',
        role: 'Executive Producer, Télévision Montréal'
      },
      {
        quote:
          'From wildfire coverage to economic analysis, the team at Canada News Network brings depth and compassion to every story.',
        name: 'Jordan McLeod',
        role: 'Director, Northern Policy Forum'
      },
      {
        quote:
          'Their Indigenous Affairs desk sets a new standard for collaboration. It is thoughtful reporting that informs policy and builds understanding.',
        name: 'Chief Elenora Aglukkaq',
        role: 'Nunavut Community Leadership Council'
      }
    ],
    []
  );

  const teamMembers = useMemo(
    () => [
      {
        name: 'Amelia Chen',
        title: 'Editor-in-Chief',
        bio: 'Leads national editorial strategy with two decades of investigative experience.',
        image: 'https://picsum.photos/400/400?random=117'
      },
      {
        name: 'Kwasi Boateng',
        title: 'Director of Innovation',
        bio: 'Designs multimedia storytelling experiences and data-driven newsroom tools.',
        image: 'https://picsum.photos/400/400?random=118'
      },
      {
        name: 'Sophie Tremblay',
        title: 'Head of Audience',
        bio: 'Builds community partnerships and guides bilingual engagement initiatives.',
        image: 'https://picsum.photos/400/400?random=119'
      },
      {
        name: 'Logan Williams',
        title: 'Senior Correspondent, North',
        bio: 'Reports from the Arctic on sovereignty, environment, and infrastructure.',
        image: 'https://picsum.photos/400/400?random=120'
      }
    ],
    []
  );

  const projects = useMemo(
    () => [
      {
        title: 'Rebuilding Lytton',
        category: 'Climate',
        description:
          'A year-long multimedia project following wildfire recovery and resilience planning in British Columbia.',
        image: 'https://picsum.photos/1200/800?random=121'
      },
      {
        title: 'Arctic Youth Voices',
        category: 'Community',
        description:
          'Collaborative reporting labs training youth contributors across the North.',
        image: 'https://picsum.photos/1200/800?random=122'
      },
      {
        title: 'Inclusive Innovation',
        category: 'Economy',
        description:
          'Series tracking inclusive tech growth corridors in Waterloo, Montréal, and Vancouver.',
        image: 'https://picsum.photos/1200/800?random=123'
      },
      {
        title: 'Prairie Water Watch',
        category: 'Environment',
        description:
          'Data-driven project analyzing water stewardship policies during drought cycles.',
        image: 'https://picsum.photos/1200/800?random=124'
      }
    ],
    []
  );

  const blogPosts = useMemo(
    () => [
      {
        title: 'What Canadians want from climate policy in 2024',
        excerpt:
          'We surveyed readers across the provinces to understand priorities for adaptation, mitigation, and green jobs.',
        date: 'Jan 15, 2024',
        image: 'https://picsum.photos/800/600?random=125'
      },
      {
        title: 'Election readiness: Behind the scenes of our democracy lab',
        excerpt:
          'How we are preparing tools, explainers, and fact-check resources ahead of the next federal election.',
        date: 'Jan 12, 2024',
        image: 'https://picsum.photos/800/600?random=126'
      },
      {
        title: 'Inside the newsroom: Building bridges with rural communities',
        excerpt:
          'A look at our on-the-ground listening tour connecting editors with rural storytellers.',
        date: 'Jan 8, 2024',
        image: 'https://picsum.photos/800/600?random=127'
      }
    ],
    []
  );

  const faqItems = useMemo(
    () => [
      {
        question: 'How do you ensure regional equity in your coverage?',
        answer:
          'Each region has dedicated reporters and editorial advisors. Weekly cross-bureau meetings balance priorities so every province and territory is represented.'
      },
      {
        question: 'Can I pitch a story or share a tip?',
        answer:
          'Absolutely. Reach out via our secure form on the Contact page, or email tips@canadanewsnetwork.ca. We protect source confidentiality.'
      },
      {
        question: 'Do you offer bilingual reporting?',
        answer:
          'Yes. Our Québec bureau publishes reporting in French and English, and many national features are bilingual in collaboration with our translation team.'
      }
    ],
    []
  );

  const [activeProjectFilter, setActiveProjectFilter] = useState('All');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [statsValues, setStatsValues] = useState(stats.map(() => 0));
  const statsRef = useRef(null);
  const hasAnimatedStats = useRef(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterMessage, setNewsletterMessage] = useState('');
  const [activeFaqIndex, setActiveFaqIndex] = useState(null);

  useEffect(() => {
    const elements = document.querySelectorAll('[data-animate="fade"]');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.visible);
          }
        });
      },
      { threshold: 0.2 }
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  useEffect(() => {
    if (!statsRef.current || hasAnimatedStats.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          hasAnimatedStats.current = true;
          stats.forEach((stat, index) => {
            const target = stat.value;
            const duration = 2000;
            const startTime = performance.now();

            const animate = (currentTime) => {
              const elapsed = currentTime - startTime;
              const progress = Math.min(elapsed / duration, 1);
              const eased = progress < 0.5 ? 2 * progress * progress : -1 + (4 - 2 * progress) * progress;
              const currentValue = parseFloat((target * eased).toFixed(2));
              setStatsValues((prev) => {
                const next = [...prev];
                next[index] = parseFloat(target) >= 1 && stat.suffix === 'M'
                  ? parseFloat(currentValue.toFixed(1))
                  : Math.round(currentValue);
                return next;
              });

              if (progress < 1) {
                requestAnimationFrame(animate);
              } else {
                setStatsValues((prev) => {
                  const next = [...prev];
                  next[index] = target;
                  return next;
                });
              }
            };

            requestAnimationFrame(animate);
          });
        }
      },
      { threshold: 0.3 }
    );

    observer.observe(statsRef.current);
    return () => observer.disconnect();
  }, [stats]);

  const filteredProjects =
    activeProjectFilter === 'All'
      ? projects
      : projects.filter((project) => project.category === activeProjectFilter);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newsletterEmail)) {
      setNewsletterMessage('Please enter a valid email address.');
      return;
    }
    setNewsletterMessage('Thank you for subscribing! Check your inbox for confirmation.');
    setNewsletterEmail('');
  };

  return (
    <>
      <Helmet>
        <title>Canada News Network | Independent Canadian Journalism</title>
        <meta
          name="description"
          content="Discover the latest Canadian news, investigative reporting, and regional perspectives from Canada News Network."
        />
      </Helmet>
      <section className={styles.hero} style={{ backgroundImage: `url(${heroImage})` }}>
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Today in Canada</p>
          <h1 className={styles.heroTitle}>
            Journalism that connects Canada&apos;s communities in real time
          </h1>
          <p className={styles.heroSubtitle}>
            From Parliament Hill to Arctic hamlets, Canada News Network brings national issues into
            focus with regional depth, diverse voices, and multimedia storytelling.
          </p>
          <div className={styles.heroActions}>
            <a className={styles.heroButtonPrimary} href="#latest" aria-label="View latest stories">
              Explore Latest Stories
            </a>
            <a className={styles.heroButtonSecondary} href="#newsletter">
              Join Morning Briefing
            </a>
          </div>
        </div>
      </section>

      <section className={`${styles.stats} fade-section`} ref={statsRef} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Impact in Numbers</p>
          <h2 className={styles.sectionTitle}>Our newsroom by the metrics</h2>
        </div>
        <div className={styles.statsGrid}>
          {stats.map((stat, index) => (
            <article key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>
                {statsValues[index]}
                {stat.suffix}
              </span>
              <p className={styles.statLabel}>{stat.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="latest" className={styles.latest} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Latest</p>
          <h2 className={styles.sectionTitle}>Essential stories, updated hourly</h2>
        </div>
        <div className={styles.newsGrid}>
          {latestNews.map((story) => (
            <article key={story.title} className={styles.newsCard}>
              <div className={styles.newsImageWrapper}>
                <img src={story.image} alt={`${story.region} news - ${story.title}`} loading="lazy" />
              </div>
              <div className={styles.newsContent}>
                <span className={styles.newsRegion}>{story.region}</span>
                <h3>{story.title}</h3>
                <p>{story.summary}</p>
                <button className={styles.readMore} type="button">
                  Continue reading
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.services} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Newsroom desks</p>
          <h2 className={styles.sectionTitle}>Specialized teams powering coverage</h2>
        </div>
        <div className={styles.serviceGrid}>
          {serviceCards.map((card) => (
            <article key={card.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {card.icon}
              </span>
              <h3>{card.title}</h3>
              <p>{card.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>How we work</p>
          <h2 className={styles.sectionTitle}>Transparent editorial process</h2>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.step} className={styles.processCard}>
              <span className={styles.processStep}>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.regions} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Across Canada</p>
          <h2 className={styles.sectionTitle}>Regional desks delivering local nuance</h2>
        </div>
        <div className={styles.regionGrid}>
          {regions.map((region) => (
            <article key={region.name} className={styles.regionCard}>
              <img src={region.image} alt={`${region.name} regional coverage`} loading="lazy" />
              <div className={styles.regionContent}>
                <h3>{region.name}</h3>
                <p>{region.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.multimedia} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Multimedia</p>
          <h2 className={styles.sectionTitle}>Immersive storytelling experiences</h2>
        </div>
        <div className={styles.multimediaStrip}>
          {multimediaItems.map((item) => (
            <article key={item.title} className={styles.multimediaCard}>
              <img src={item.image} alt={`${item.type} presentation: ${item.title}`} loading="lazy" />
              <div>
                <span className={styles.multimediaType}>{item.type}</span>
                <h3>{item.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Testimonials</p>
          <h2 className={styles.sectionTitle}>What media leaders say about our reporting</h2>
        </div>
        <div className={styles.testimonialCarousel}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${
                index === testimonialIndex ? styles.testimonialActive : ''
              }`}
              aria-hidden={index !== testimonialIndex}
            >
              <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
              <p className={styles.testimonialAuthor}>
                {testimonial.name} <span>{testimonial.role}</span>
              </p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Editorial leadership</p>
          <h2 className={styles.sectionTitle}>Meet the team guiding coverage</h2>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImageWrapper}>
                <img src={member.image} alt={`${member.name}, ${member.title}`} loading="lazy" />
              </div>
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.title}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Special coverage</p>
          <h2 className={styles.sectionTitle}>Flagship projects & investigations</h2>
        </div>
        <div className={styles.projectFilters} role="group" aria-label="Project filters">
          {['All', 'Climate', 'Community', 'Economy', 'Environment'].map((filter) => (
            <button
              key={filter}
              type="button"
              className={`${styles.filterButton} ${
                activeProjectFilter === filter ? styles.filterActive : ''
              }`}
              onClick={() => setActiveProjectFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <img src={project.image} alt={`${project.category} project ${project.title}`} loading="lazy" />
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>FAQ</p>
          <h2 className={styles.sectionTitle}>Answering common questions</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <article key={item.question} className={styles.faqItem}>
              <button
                className={styles.faqToggle}
                onClick={() =>
                  setActiveFaqIndex((prev) => (prev === index ? null : index))
                }
                aria-expanded={activeFaqIndex === index}
              >
                <span>{item.question}</span>
                <span>{activeFaqIndex === index ? '−' : '+'}</span>
              </button>
              {activeFaqIndex === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blog} data-animate="fade">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Insights</p>
          <h2 className={styles.sectionTitle}>From our newsroom blog</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImageWrapper}>
                <img src={post.image} alt={`Blog post - ${post.title}`} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <button className={styles.readMore} type="button">
                  Read insight
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="newsletter" className={styles.newsletter} data-animate="fade">
        <div className={styles.newsletterContent}>
          <p className={styles.sectionKicker}>Morning Briefing</p>
          <h2 className={styles.sectionTitle}>Start your day with Canada in focus</h2>
          <p className={styles.newsletterText}>
            Our editors deliver a curated summary every weekday at 6 a.m. ET—highlighting stories,
            analysis, and context you need.
          </p>
          <form className={styles.newsletterForm} onSubmit={handleNewsletterSubmit}>
            <label htmlFor="newsletter-email" className="visually-hidden">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              placeholder="you@example.com"
              value={newsletterEmail}
              onChange={(event) => setNewsletterEmail(event.target.value)}
              required
              aria-label="Email address"
            />
            <button type="submit">Subscribe</button>
          </form>
          {newsletterMessage && <p className={styles.newsletterMessage}>{newsletterMessage}</p>}
        </div>
        <div className={styles.newsletterImage}>
          <img
            src="https://picsum.photos/900/700?random=128"
            alt="Journalists collaborating in Canadian newsroom"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.cta} data-animate="fade">
        <div className={styles.ctaContent}>
          <h2>
            Partner with Canada News Network to bring verified Canadian stories to your audience.
          </h2>
          <p>
            Commission a regional bureau, collaborate on investigations, or license our multimedia
            storytelling packages tailored for broadcasters, publishers, and civic organizations.
          </p>
          <a href="/contact" className={styles.heroButtonPrimary}>
            Connect with our team
          </a>
        </div>
      </section>
    </>
  );
};

export default Home;