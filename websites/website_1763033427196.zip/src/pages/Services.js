import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const Services = () => {
  const offerings = [
    {
      title: 'Custom News Packages',
      description:
        'Commission bilingual news packages tailored for broadcasters, streaming platforms, and municipal communications.'
    },
    {
      title: 'Licensing & Syndication',
      description:
        'License our video, audio, and data visualizations to enrich your digital or print channels.'
    },
    {
      title: 'Audience Insights',
      description:
        'Access analytics and audience listening reports to better understand Canadian sentiment.'
    },
    {
      title: 'Editorial Training',
      description:
        'Workshops for civic organizations and journalism students on data verification and multimedia storytelling.'
    }
  ];

  const partnerships = [
    {
      name: 'Public broadcasters',
      text: 'Weekly segments on regional priorities featuring local leaders and innovators.'
    },
    {
      name: 'Universities',
      text: 'Campus bureau collaborations that mentor student reporters and share investigative resources.'
    },
    {
      name: 'Non-profits',
      text: 'Storytelling labs that translate research into accessible narratives for broader audiences.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Services | Canada News Network</title>
        <meta
          name="description"
          content="Explore partnership and service opportunities with Canada News Network."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Services</p>
          <h1>Partner with us to amplify Canadian stories</h1>
          <p>
            Canada News Network collaborates with broadcasters, publishers, and civic organizations
            to deliver credible reporting, bespoke content, and newsroom expertise.
          </p>
        </header>

        <div className={styles.offeringsGrid}>
          {offerings.map((offering) => (
            <article key={offering.title} className={styles.card}>
              <h2>{offering.title}</h2>
              <p>{offering.description}</p>
              <button type="button">Request details</button>
            </article>
          ))}
        </div>

        <section className={styles.partners}>
          <h2>Strategic partnerships</h2>
          <div className={styles.partnerList}>
            {partnerships.map((partner) => (
              <article key={partner.name}>
                <h3>{partner.name}</h3>
                <p>{partner.text}</p>
              </article>
            ))}
          </div>
        </section>
      </section>
    </>
  );
};

export default Services;