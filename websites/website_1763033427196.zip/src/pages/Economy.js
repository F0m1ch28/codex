import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CategoryPage.module.css';

const Economy = () => {
  const stories = [
    {
      title: 'Clean tech hub announces national talent accelerator',
      summary:
        'Waterloo, Calgary, and Halifax link innovation districts with skill programs to fast-track sustainable manufacturing.',
      image: 'https://picsum.photos/900/600?random=204'
    },
    {
      title: 'Bank of Canada signals cautious optimism amid growth rebound',
      summary:
        'Governor Tiff Macklem points to resilient job numbers and easing inflation while monitoring household debt levels.',
      image: 'https://picsum.photos/900/600?random=205'
    },
    {
      title: 'Northern supply chain overhaul cuts grocery costs by 12%',
      summary:
        'Community-owned logistics in Nunavut partner with airlines and co-ops to stabilize essentials during winter months.',
      image: 'https://picsum.photos/900/600?random=206'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Economy & Business | Canada News Network</title>
        <meta
          name="description"
          content="Economic reporting on trade, finance, entrepreneurship, and innovation across Canada."
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.header}>
          <p className={styles.kicker}>Economy</p>
          <h1>Tracking Canada&apos;s economic pulse</h1>
          <p>
            From Bay Street to the Arctic Circle, our business team highlights resilient entrepreneurs,
            fiscal policy, and the global forces influencing Canadian prosperity.
          </p>
        </header>
        <div className={styles.grid}>
          {stories.map((story) => (
            <article key={story.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={story.image} alt={story.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{story.title}</h2>
                <p>{story.summary}</p>
                <button type="button">Watch market briefing</button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Economy;