```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import layoutStyles from '../styles/Layout.module.css';
import styles from './HomePage.module.css';

const services = [
  {
    title: 'Дизайн UI/UX',
    description: 'Создаем визуальные концепции и интерактивные интерфейсы, которые влюбляют в продукт с первого взаимодействия.',
    icon: '🎯'
  },
  {
    title: 'Веб-разработка',
    description: 'Верстаем адаптивно, подключаем динамику и интеграции, собираем надежные интерфейсы на актуальных технологиях.',
    icon: '💻'
  },
  {
    title: 'Консалтинг',
    description: 'Анализируем digital-экосистему компании и предлагаем стратегию развития: от аудита до планов по внедрению.',
    icon: '🧭'
  },
  {
    title: 'Поддержка',
    description: 'Берем на себя сопровождение проекта после запуска, следим за стабильностью и развиваем функциональность.',
    icon: '🤝'
  }
];

const advantages = [
  {
    title: 'Индивидуальный подход',
    description: 'Глубоко изучаем бренд и аудиторию, чтобы каждый проект отражал уникальность компании.'
  },
  {
    title: 'Современные технологии',
    description: 'Используем актуальные инструменты разработки и дизайн-системы, чтобы сайты оставались гибкими и быстрыми.'
  },
  {
    title: 'Прозрачный процесс',
    description: 'Фиксируем ключевые этапы и регулярно синхронизируемся, чтобы команда клиента видела прогресс.'
  },
  {
    title: 'Сроки и бюджет',
    description: 'Планируем реалистично и соблюдаем договоренности — без сюрпризов в календаре или смете.'
  }
];

const projects = [
  {
    title: 'Skyline Architects',
    description: 'Редизайн архитектурного бюро с акцентом на визуальные кейсы, адаптированный под мобильных пользователей.',
    image: 'https://images.unsplash.com/photo-1529429617124-aee711a6f812?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Nordic Coffee',
    description: 'Уютный e-commerce для кофеен: адаптивная витрина, личный кабинет, удобный конструктор подписок.',
    image: 'https://images.unsplash.com/photo-1504753793650-d4a2b783c15e?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Urban Stories Media',
    description: 'Мультимедийная платформа с интерактивными лонгридами и системой рекомендаций для читателей.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80'
  }
];

const steps = [
  { title: 'Обсуждение', text: 'Формируем задачу, погружаемся в контекст бизнеса и договариваемся о критериях успеха.' },
  { title: 'Прототип', text: 'Прорабатываем структуру, пользовательские сценарии и тестируем гипотезы на ранней стадии.' },
  { title: 'Разработка', text: 'Создаем дизайн-систему, верстаем и подключаем функциональность, интегрируемся с сервисами.' },
  { title: 'Запуск', text: 'Финальное тестирование, публикация проекта и сопровождение команды при выходе.' }
];

const HomePage = () => (
  <div className={styles.home}>
    <Helmet>
      <title>🎨 Сколько вариантов сайта создать? — Создаем уникальные сайты, которые работают</title>
      <meta
        name="description"
        content="Креативное агентство «🎨 Сколько вариантов сайта создать?» проектирует и разрабатывает современные сайты. Индивидуальный подход, сильный дизайн и технологичная разработка."
      />
      <meta
        name="keywords"
        content="дизайн сайтов, разработка, креативное агентство, веб-студия, UI UX, Москва"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={`${layoutStyles.container} ${styles.heroInner}`}>
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Креативная веб-студия из Москвы</span>
          <h1 className={styles.heroTitle}>Создаем уникальные сайты, которые работают</h1>
          <p className={styles.heroSubtitle}>
            Команда дизайнеров и разработчиков, которая превращает идеи в digital-опыт. Проектируем интерфейсы, продумываем сценарии и запускаем технологичные сайты.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.primaryButton}>
              Начать проект
            </Link>
            <Link to="/portfolio" className={styles.secondaryButton}>
              Посмотреть портфолио
            </Link>
          </div>
        </div>
        <div className={styles.heroCard} aria-hidden="true">
          <div className={styles.heroIllustration}>
            <span>UX Research</span>
            <span>Design System</span>
            <span>Front-end</span>
            <span>Brand Voice</span>
          </div>
          <div className={styles.heroStats}>
            <div>
              <strong>8+</strong>
              <span>лет опыта в digital</span>
            </div>
            <div>
              <strong>120</strong>
              <span>успешных запусков</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section className={`${layoutStyles.sectionPadding} ${styles.servicesSection}`}>
      <div className={layoutStyles.container}>
        <div className={layoutStyles.sectionHeader}>
          <h2 className={layoutStyles.sectionTitle}>Наши услуги</h2>
          <p className={layoutStyles.sectionSubtitle}>
            Выстраиваем полный цикл создания сайта: от стратегических сессий и прототипов до поддержки и развития проекта после запуска.
          </p>
        </div>
        <div className={styles.servicesGrid} role="list">
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard} role="listitem">
              <div className={styles.serviceIcon} aria-hidden="true">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
        <div className={styles.sectionLink}>
          <Link to="/uslugi">Все услуги →</Link>
        </div>
      </div>
    </section>

    <section className={`${layoutStyles.sectionPadding} ${styles.whySection}`}>
      <div className={layoutStyles.container}>
        <div className={layoutStyles.sectionHeader}>
          <h2 className={layoutStyles.sectionTitle}>Почему мы</h2>
          <p className={layoutStyles.sectionSubtitle}>
            Работаем по принципу партнерства и вкладываемся в результат так же, как и наша команда.
          </p>
        </div>
        <div className={styles.whyGrid}>
          {advantages.map((item) => (
            <article key={item.title} className={styles.advantageCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${layoutStyles.sectionPadding} ${styles.portfolioSection}`}>
      <div className={layoutStyles.container}>
        <div className={layoutStyles.sectionHeader}>
          <h2 className={layoutStyles.sectionTitle}>Избранные работы</h2>
          <p className={layoutStyles.sectionSubtitle}>
            Запускаем проекты для компаний из сфер девелопмента, ритейла, медиа, образования и стартапов.
          </p>
        </div>
        <div className={styles.portfolioGrid}>
          {projects.map((project) => (
            <article key={project.title} className={styles.portfolioCard}>
              <img src={project.image} alt={`Проект ${project.title}`} loading="lazy" />
              <div className={styles.portfolioContent}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
        <div className={styles.sectionLink}>
          <Link to="/portfolio">Все работы →</Link>
        </div>
      </div>
    </section>

    <section className={`${layoutStyles.sectionPadding} ${styles.processSection}`}>
      <div className={layoutStyles.container}>
        <div className={layoutStyles.sectionHeader}>
          <h2 className={layoutStyles.sectionTitle}>Процесс работы</h2>
          <p className={layoutStyles.sectionSubtitle}>
            Четкая структура помогает быстро достигать результата и держать команду клиента в курсе.
          </p>
        </div>
        <div className={styles.processGrid}>
          {steps.map((step, index) => (
            <article key={step.title} className={styles.processCard}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
        <div className={styles.sectionLink}>
          <Link to="/process">Подробнее →</Link>
        </div>
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className={layoutStyles.container}>
        <div className={styles.ctaInner}>
          <h2>Готовы создать ваш идеальный сайт?</h2>
          <p>
            Расскажите о задаче — подготовим индивидуальный план, подберем команду и предложим первые идеи уже на созвоне.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/kontakty" className={styles.primaryButton}>
              Обсудить проект
            </Link>
            <Link to="/portfolio" className={styles.secondaryButton}>
              Посмотреть портфолио
            </Link>
          </div>
        </div>
      </div>
    </section>
  </div>
);

export default HomePage;
```