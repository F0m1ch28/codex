document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("primary-nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("open");
    });
  }

  const sections = document.querySelectorAll("[data-animate]");
  if (sections.length) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animated");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    sections.forEach((section) => observer.observe(section));
  }

  const yearSpans = document.querySelectorAll(".js-current-year");
  const currentYear = new Date().getFullYear();
  yearSpans.forEach((span) => {
    span.textContent = String(currentYear);
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const cookieKey = "gracemccarthy-cookie-consent";

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedPreference = localStorage.getItem(cookieKey);
    if (!storedPreference) {
      cookieBanner.classList.add("active");
    }

    const handleChoice = (choice) => {
      localStorage.setItem(cookieKey, choice);
      cookieBanner.classList.remove("active");
    };

    acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    declineBtn.addEventListener("click", () => handleChoice("declined"));
  }

  const form = document.querySelector('form[data-enhanced="true"]');
  const toast = document.getElementById("form-toast");
  if (form && toast) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      toast.textContent = "Thank you. Redirecting...";
      toast.classList.add("visible");
      setTimeout(() => {
        toast.classList.remove("visible");
        window.location.href = form.getAttribute("action") || "thank-you.html";
      }, 1600);
    });
  }
});