document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.getElementById('navToggle');
    const siteNav = document.getElementById('siteNav');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = cookieBanner ? cookieBanner.querySelectorAll('[data-choice]') : [];
    const filterButtons = document.querySelectorAll('.filter-button');
    const courseCards = document.querySelectorAll('[data-category]');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('is-open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner) {
        const choice = localStorage.getItem('gsfyb-cookie-choice');
        if (!choice) {
            cookieBanner.classList.add('is-visible');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const value = button.getAttribute('data-choice');
                localStorage.setItem('gsfyb-cookie-choice', value);
                cookieBanner.classList.remove('is-visible');
                window.location.href = button.getAttribute('href');
            });
        });
    }

    if (filterButtons.length && courseCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const selected = button.getAttribute('data-filter');
                filterButtons.forEach(btn => btn.classList.remove('is-active'));
                button.classList.add('is-active');

                courseCards.forEach(card => {
                    const category = card.getAttribute('data-category');
                    if (selected === 'all' || category.includes(selected)) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
});