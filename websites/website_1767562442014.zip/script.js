document.addEventListener("DOMContentLoaded", () => {
  const banner = document.querySelector(".cookie-banner");
  if (!banner) {
    return;
  }

  const acceptBtn = banner.querySelector("[data-cookie-accept]");
  const declineBtn = banner.querySelector("[data-cookie-decline]");
  const COOKIE_KEY = "puteshestvieCookieChoice";

  const savedChoice = localStorage.getItem(COOKIE_KEY);
  if (savedChoice) {
    banner.classList.add("is-hidden");
  }

  const closeBanner = (choice) => {
    localStorage.setItem(COOKIE_KEY, choice);
    banner.classList.add("is-hidden");
  };

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => closeBanner("accepted"));
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => closeBanner("declined"));
  }
});