document.addEventListener("DOMContentLoaded", function () {
    const yearSpan = document.getElementById("current-year");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    const navToggle = document.getElementById("nav-toggle");
    const navMenu = document.getElementById("primary-navigation");
    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navMenu.classList.toggle("open");
            navToggle.setAttribute(
                "aria-expanded",
                navMenu.classList.contains("open").toString()
            );
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedPreference = localStorage.getItem("cao-cookie-consent");
        if (storedPreference) {
            cookieBanner.classList.add("hidden");
        }
        cookieBanner.querySelectorAll(".cookie-button").forEach((button) => {
            button.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = button.dataset.choice || "decline";
                localStorage.setItem("cao-cookie-consent", choice);
                cookieBanner.classList.add("hidden");
                window.location.href = "cookies.html";
            });
        });
    }

    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();
            window.location.href = "thanks.html";
        });
    }

    const searchInput = document.getElementById("post-search");
    const filterButtons = document.querySelectorAll(".filter-button");
    const paginationButtons = document.querySelectorAll(".pagination button");
    const postCards = Array.from(document.querySelectorAll(".post-card"));

    let activeCategory = "all";
    let activePage = "1";
    let searchTerm = "";

    function applyPostFilters() {
        const normalizedTerm = searchTerm.trim().toLowerCase();
        postCards.forEach((card) => {
            const category = card.dataset.category || "all";
            const page = card.dataset.page || "1";
            const title = card.dataset.title || "";
            const summary = card.dataset.summary || "";
            const matchesCategory = activeCategory === "all" || category === activeCategory;
            const matchesPage = page === activePage;
            const textComposite = `${title} ${summary}`.toLowerCase();
            const matchesSearch =
                normalizedTerm.length === 0 || textComposite.includes(normalizedTerm);
            if (matchesCategory && matchesPage && matchesSearch) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", (event) => {
            searchTerm = event.target.value;
            activePage = "1";
            paginationButtons.forEach((btn) => btn.classList.toggle("active", btn.dataset.page === activePage));
            applyPostFilters();
        });
    }

    if (filterButtons.length) {
        filterButtons.forEach((button) => {
            button.addEventListener("click", () => {
                activeCategory = button.dataset.category || "all";
                filterButtons.forEach((btn) => btn.classList.toggle("active", btn === button));
                activePage = "1";
                paginationButtons.forEach((btn) => btn.classList.toggle("active", btn.dataset.page === activePage));
                applyPostFilters();
            });
        });
    }

    if (paginationButtons.length) {
        paginationButtons.forEach((button) => {
            button.addEventListener("click", () => {
                activePage = button.dataset.page || "1";
                paginationButtons.forEach((btn) => btn.classList.toggle("active", btn === button));
                applyPostFilters();
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    applyPostFilters();
});