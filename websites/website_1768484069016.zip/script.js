document.addEventListener("DOMContentLoaded", function () {
    const header = document.querySelector(".site-header");
    const menuToggle = document.querySelector(".menu-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (header) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 40) {
                header.classList.add("scrolled");
            } else {
                header.classList.remove("scrolled");
            }
        });
    }

    if (menuToggle && navLinks) {
        menuToggle.addEventListener("click", () => {
            navLinks.classList.toggle("open");
            menuToggle.setAttribute("aria-expanded", navLinks.classList.contains("open"));
        });

        navLinks.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navLinks.classList.remove("open");
                menuToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptButton = document.getElementById("cookieAccept");
    const declineButton = document.getElementById("cookieDecline");

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove("visible");
        }
    }

    if (cookieBanner) {
        const storedPreference = localStorage.getItem("gc_cookie_preference");
        if (!storedPreference) {
            cookieBanner.classList.add("visible");
        }

        if (acceptButton) {
            acceptButton.addEventListener("click", () => {
                localStorage.setItem("gc_cookie_preference", "accepted");
                hideCookieBanner();
            });
        }

        if (declineButton) {
            declineButton.addEventListener("click", () => {
                localStorage.setItem("gc_cookie_preference", "declined");
                hideCookieBanner();
            });
        }
    }

    const faqItems = document.querySelectorAll(".faq-item");
    faqItems.forEach((item) => {
        const trigger = item.querySelector(".faq-question");
        if (trigger) {
            trigger.addEventListener("click", () => {
                const isOpen = item.classList.contains("open");
                faqItems.forEach((faq) => faq.classList.remove("open"));
                if (!isOpen) {
                    item.classList.add("open");
                }
            });
        }
    });
});