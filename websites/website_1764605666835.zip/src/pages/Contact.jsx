import { motion } from 'framer-motion';

function Contact() {
  return (
    <div className="container section">
      <div className="section-header">
        <span className="badge">Контакты</span>
        <h1 className="section-title">Свяжитесь с командой Компания</h1>
        <p className="section-subtitle">
          Расскажите о своей задаче, и мы подготовим персональное предложение с дорожной картой, сроками и ориентиром по инвестициям.
        </p>
      </div>

      <div className="contact-grid">
        <motion.div
          className="glass-panel"
          style={{ padding: '2.5rem' }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <form
            className="contact-form"
            name="contact"
            method="POST"
            data-netlify="true"
            netlify-honeypot="bot-field"
          >
            <input type="hidden" name="form-name" value="contact" />
            <p style={{ display: 'none' }}>
              <label>
                Не заполняйте это поле: <input name="bot-field" />
              </label>
            </p>
            <div className="form-row">
              <label>
                Ваше имя
                <input type="text" name="name" placeholder="Иван Иванов" required />
              </label>
              <label>
                Компания
                <input type="text" name="company" placeholder="Название компании" />
              </label>
            </div>
            <div className="form-row">
              <label>
                Email
                <input type="email" name="email" placeholder="you@company.ru" required />
              </label>
              <label>
                Телефон
                <input type="tel" name="phone" placeholder="+7 (___) ___-__-__" />
              </label>
            </div>
            <label>
              Интересующая услуга
              <select name="service">
                <option value="Комплексная цифровая трансформация">Комплексная цифровая трансформация</option>
                <option value="Разработка цифрового продукта">Разработка цифрового продукта</option>
                <option value="Data & AI">Data & AI</option>
                <option value="Интеграции и автоматизация">Интеграции и автоматизация</option>
                <option value="Кибербезопасность">Кибербезопасность</option>
                <option value="Другое">Другое</option>
              </select>
            </label>
            <label>
              Опишите задачу
              <textarea name="message" placeholder="Расскажите, что вы хотите улучшить или запустить" required />
            </label>
            <small className="form-helper">
              Отправляя форму, вы соглашаетесь с <a href="/privacy-policy">Политикой конфиденциальности</a> и <a href="/terms-of-service">Условиями использования</a>.
            </small>
            <button type="submit" className="primary-button">
              Отправить запрос
            </button>
          </form>
        </motion.div>

        <motion.div
          className="contact-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.1 }}
        >
          <div>
            <h3>Офис и каналы связи</h3>
            <p className="text-muted">
              Наши специалисты доступны для встреч онлайн и офлайн. Планируем визиты, стратегические сессии и воркшопы.
            </p>
          </div>
          <div className="contact-details">
            <a href="tel:+74951234567" aria-label="Позвонить по телефону +7 (495) 123-45-67">
              📞 +7 (495) 123-45-67
            </a>
            <a href="mailto:info@company.ru" aria-label="Написать на email info@company.ru">
              ✉️ info@company.ru
            </a>
            <span>📍 Москва, Пресненская набережная, 12</span>
            <a href="https://t.me" target="_blank" rel="noopener noreferrer">
              Telegram-канал для клиентов
            </a>
          </div>
          <div className="map-placeholder">
            <iframe
              title="Офис Компания в Москве"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2241.3706925124794!2d37.53392361592498!3d55.74888278055264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54bcd45b6e0df%3A0x8c2ec9af709c8c2!2z0J_RgNC-0YHRgdC40Y8g0JLQsNGA0LDRgNGF0LjQu9GM0L3Ri9C5INC90LAg0JzQsNC50LTQtdGA0L7QstCwLCAxMiwg0JzQvtGB0LrQstCwLCAxMjMud3Q!5e0!3m2!1sru!2sru!4v1709913848003"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default Contact;