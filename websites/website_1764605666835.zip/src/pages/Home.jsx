import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] }
};

function Home() {
  return (
    <div className="container section">
      <section className="hero">
        <motion.div className="hero-content" {...fadeIn}>
          <div className="badge">
            Премиальная цифровая трансформация
          </div>
          <h1 className="hero-title">
            Компания — цифровые решения премиум-класса для лидеров рынка
          </h1>
          <p className="hero-description">
            Создаём инновационные продукты, платформы и сервисы, которые помогают бизнесу расти быстрее, действовать гибче и прогнозировать будущее. Интеллект, дизайн и технологии — в одном решении.
          </p>
          <div className="hero-actions">
            <Link to="/contact" className="primary-button">
              Связаться с нами
              <span aria-hidden="true">→</span>
            </Link>
            <Link to="/services" className="secondary-button">
              Все услуги
            </Link>
          </div>
          <div className="integrations-strip">
            <span>Интеграция с ведущими платформами</span>
            <div className="integrations-logos">
              <div>1C</div>
              <div>BI</div>
              <div>AI</div>
              <div>ERP</div>
            </div>
          </div>
        </motion.div>
        <motion.div className="hero-media hover-tilt" {...fadeIn} transition={{ delay: 0.2, duration: 0.75 }}>
          <div className="hero-card">
            <img
              src="https://cdn.pixabay.com/photo/2017/03/26/21/47/business-2178565_1280.jpg"
              alt="Команда Компания за работой над цифровым продуктом"
            />
            <div className="cards-highlight">
              <div className="card">
                <strong>Цифровые экосистемы</strong>
                <span className="text-muted">Комплексное управление клиентами, данными и сервисами в едином пространстве.</span>
              </div>
              <div className="card">
                <strong>Интеллектуальная аналитика</strong>
                <span className="text-muted">Мгновенные решения на основе данных и прогнозных моделей с использованием AI.</span>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      <section className="section">
        <motion.div className="section-header" {...fadeIn}>
          <span className="badge">Почему выбирают Компания</span>
          <h2 className="section-title">
            Синергия стратегии, технологии и дизайна
          </h2>
          <p className="section-subtitle">
            Каждый проект сочетает глубокую отраслевую экспертизу, прогрессивную архитектуру и выдающийся пользовательский опыт. Мы создаём решения, которыми удобно пользоваться сегодня и легко масштабировать завтра.
          </p>
        </motion.div>
        <motion.div className="grid grid-cols-3" initial="initial" whileInView="animate" viewport={{ once: true, amount: 0.2 }}>
          {[
            {
              icon: '🚀',
              title: 'Инновационная стратегия',
              description:
                'Формируем цифровую стратегию, основанную на аналитике рынка, портретах клиентов и бизнес-целях.'
            },
            {
              icon: '🧠',
              title: 'AI & Data-инжиниринг',
              description:
                'Встраиваем машинное обучение, предиктивную аналитику и интеллектуальные помощники в процессы компании.'
            },
            {
              icon: '🎯',
              title: 'Дизайн премиального уровня',
              description:
                'Создаём продуктовый дизайн с микровзаимодействиями, стеклянными слоями и детализированной анимацией.'
            },
            {
              icon: '🔗',
              title: 'Интеграции без границ',
              description:
                'Подключаем решения к ERP, CRM, 1С, банковским системам и облачным сервисам через безопасные API.'
            },
            {
              icon: '🛡️',
              title: 'Безопасность enterprise-класса',
              description:
                'Шифрование, аудит и compliance. Соответствуем требованиям 152-ФЗ, ISO 27001 и корпоративным политикам клиентов.'
            },
            {
              icon: '🤝',
              title: 'Партнёрский подход',
              description:
                'Берём ответственность за результат на всех этапах: от концепции до поддержки и дальнейшего развития.'
            }
          ].map((feature, index) => (
            <motion.div
              key={feature.title}
              className="feature-card"
              variants={{
                initial: { opacity: 0, y: 28 },
                animate: { opacity: 1, y: 0 }
              }}
              transition={{ duration: 0.55, delay: index * 0.08, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="feature-icon" aria-hidden="true">
                {feature.icon}
              </div>
              <h3>{feature.title}</h3>
              <p className="text-muted">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      <section className="section">
        <motion.div className="glass-panel" {...fadeIn}>
          <div className="container" style={{ padding: '3.2rem' }}>
            <div className="section-header">
              <span className="badge">Измеримые результаты</span>
              <h2 className="section-title">Факты и цифры, подтверждённые нашими клиентами</h2>
              <p className="section-subtitle">
                Мы делаем ставку на измеримость и прозрачность. Каждая метрика — это конкретная история трансформации и роста бизнеса.
              </p>
            </div>
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-value">+48%</div>
                <div className="stat-label">Рост выручки клиентов в среднем за 12 месяцев</div>
              </div>
              <div className="stat-card">
                <div className="stat-value">92%</div>
                <div className="stat-label">Показатель удержания клиентов после внедрения</div>
              </div>
              <div className="stat-card">
                <div className="stat-value">3.4x</div>
                <div className="stat-label">Ускорение вывода новых продуктов на рынок</div>
              </div>
              <div className="stat-card">
                <div className="stat-value">24/7</div>
                <div className="stat-label">Сервис и поддержка с выделенной командой</div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      <section className="section">
        <motion.div className="section-header" {...fadeIn}>
          <span className="badge">От идеи до масштабирования</span>
          <h2 className="section-title">Экспертная вовлечённость на каждом шаге</h2>
          <p className="section-subtitle">
            Мы сопровождаем проекты на всей дистанции — от осмысления ценности продукта до оптимизации digital-экосистемы в масштабе международной компании.
          </p>
        </motion.div>
        <motion.div className="timeline" {...fadeIn} transition={{ delay: 0.15, duration: 0.65 }}>
          {[
            {
              step: '01. Стратегия и аналитика',
              text: 'Проводим исследование рынка, определяем CJM, формируем гипотезы и создаём дорожную карту.'
            },
            {
              step: '02. Проектирование и дизайн',
              text: 'Разрабатываем архитектуру, прототипы и дизайн-систему с учётом UX/UI трендов 2024.'
            },
            {
              step: '03. Разработка и интеграция',
              text: 'Реализуем backend, frontend, мобильные приложения и интеграции с корпоративными системами.'
            },
            {
              step: '04. Запуск и масштабирование',
              text: 'Запускаем, анализируем, оптимизируем и сопровождаем продукт, обеспечивая устойчивый рост.'
            }
          ].map((item) => (
            <div key={item.step} className="timeline-step">
              <h3>{item.step}</h3>
              <p className="text-muted">{item.text}</p>
            </div>
          ))}
        </motion.div>
      </section>

      <section className="section">
        <motion.div className="glass-panel" {...fadeIn}>
          <div className="container" style={{ padding: '3.2rem' }}>
            <div className="grid grid-cols-2">
              <div>
                <span className="badge">Отзывы</span>
                <h2 className="section-title">Лидеры отрасли о сотрудничестве с нами</h2>
                <p className="section-subtitle">
                  Наши клиенты — это амбициозные компании, для которых важно быстро реагировать на изменения рынка и создавать уникальный клиентский опыт.
                </p>
              </div>
              <div className="testimonial-card">
                <div className="quote-icon">“</div>
                <p>
                  Решения Компания позволили нам полностью перестроить цифровую экосистему и ускорить запуск новых сервисов. Команда глубоко вникает в бизнес и предлагает действительно стратегические решения.
                </p>
                <footer>
                  <strong>Анна Лебедева</strong>
                  <span>Директор по цифровой трансформации, Финансовый холдинг</span>
                </footer>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      <section className="section">
        <motion.div className="glass-panel" {...fadeIn}>
          <div className="container" style={{ padding: '3rem', display: 'grid', gap: '2rem' }}>
            <div>
              <span className="badge">Готовы к сотрудничеству</span>
              <h2 className="section-title">Запланируйте стратегическую сессию с экспертами Компания</h2>
              <p className="section-subtitle">
                Разберём вашу задачу, покажем лучшие практики по отрасли и предложим дорожную карту внедрения технологий.
              </p>
            </div>
            <div className="hero-actions">
              <Link to="/contact" className="primary-button">
                Запросить встречу
              </Link>
              <Link to="/services" className="secondary-button">
                Каталог услуг
              </Link>
            </div>
          </div>
        </motion.div>
      </section>
    </div>
  );
}

export default Home;