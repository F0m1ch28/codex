import { motion } from 'framer-motion';

function About() {
  return (
    <div className="container section">
      <motion.div
        className="section-header"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55 }}
      >
        <span className="badge">О компании</span>
        <h1 className="section-title">Компания — технологический партнер нового поколения</h1>
        <p className="section-subtitle">
          Наша миссия — помогать бизнесу переосмысливать процессы, продукты и клиентский опыт, используя возможности данных, искусственного интеллекта и дизайн-мышления. Мы объединяем стратегов, аналитиков, дизайнеров, инженеров и архитекторов, чтобы создавать решения, способные менять правила игры.
        </p>
      </motion.div>

      <section className="section glass-panel" style={{ padding: '3rem' }}>
        <div className="grid grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6 }}
          >
            <h2>Наше ДНК</h2>
            <p className="text-muted">
              Мы верим в силу данных, скорость инноваций и первоклассный пользовательский опыт. Все решения создаются с опорой на стратегию, гибкость методов разработки и глубокую отраслевую экспертизу.
            </p>
            <ul className="list-dotted">
              <li>Премиальный уровень сервиса и гарантированная управляемость проекта.</li>
              <li>Прозрачная коммуникация и синхронизация с бизнес-целями клиента на каждом этапе.</li>
              <li>Инвестируем в R&D и собственные продукты, чтобы делиться инновациями с клиентами.</li>
            </ul>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6, delay: 0.15 }}
          >
            <img
              src="https://cdn.pixabay.com/photo/2016/11/29/09/15/analysis-1869236_1280.jpg"
              alt="Стратегическая сессия команды Компания"
            />
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="glass-panel" style={{ padding: '3rem' }}>
          <div className="section-header">
            <span className="badge">Ценности</span>
            <h2 className="section-title">Пять принципов, которые определяют наш путь</h2>
          </div>
          <div className="grid grid-cols-2">
            {[
              {
                title: 'Ориентация на результат',
                description: 'Бизнес-метрики клиента — главный критерий нашего успеха. Мы следим за их динамикой и добиваемся устойчивого роста.'
              },
              {
                title: 'Прозрачность',
                description: 'Общая цифровая панель, регулярные отчёты, единое пространство задач и данных — всё открыто и доступно клиенту.'
              },
              {
                title: 'Инновации',
                description: 'Экспериментируем с AI, Web3, цифровыми двойниками и XR. Выбираем технологии, которые дают конкурентное преимущество.'
              },
              {
                title: 'Команда экспертов',
                description: 'У нас работают профессионалы с опытом в консалтинге, продуктовой разработке и enterprise-проектах.'
              },
              {
                title: 'Скорость и гибкость',
                description: 'Разрабатываем MVP за 6–12 недель, а затем масштабируем решения, сохраняя адаптивность архитектуры.'
              },
              {
                title: 'Ответственность',
                description: 'Соблюдаем стандарты безопасности, правовое регулирование и берем на себя ответственность за стабильность.'
              }
            ].map((value) => (
              <div key={value.title} className="feature-card">
                <h3>{value.title}</h3>
                <p className="text-muted">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="glass-panel" style={{ padding: '3rem' }}>
          <div className="section-header">
            <span className="badge">Команда</span>
            <h2 className="section-title">Эксперты, которые ведут проекты к успеху</h2>
            <p className="section-subtitle">
              В команду входят стратеги, аналитики данных, архитекторы, product-менеджеры, UX-дизайнеры, разработчики и DevOps-инженеры. Мы строим мультидисциплинарные группы под конкретные задачи бизнеса.
            </p>
          </div>
          <div className="grid grid-cols-3">
            {[
              {
                name: 'Михаил Орлов',
                role: 'Руководитель направления цифровой стратегии',
                img: 'https://cdn.pixabay.com/photo/2017/03/19/03/19/man-2150164_1280.jpg'
              },
              {
                name: 'Екатерина Соколова',
                role: 'Директор по продукту и клиентскому опыту',
                img: 'https://cdn.pixabay.com/photo/2017/08/07/00/07/woman-2593366_1280.jpg'
              },
              {
                name: 'Алексей Власов',
                role: 'Главный архитектор и руководитель R&D',
                img: 'https://cdn.pixabay.com/photo/2016/11/29/13/07/adult-1868750_1280.jpg'
              }
            ].map((member) => (
              <div key={member.name} className="feature-card">
                <img src={member.img} alt={member.name} />
                <h3>{member.name}</h3>
                <p className="text-muted">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="glass-panel" style={{ padding: '3rem' }}>
          <div className="section-header">
            <span className="badge">Партнёрства</span>
            <h2 className="section-title">Сотрудничество с лидерами индустрии</h2>
            <p className="section-subtitle">
              Мы являемся сертифицированными партнёрами технологических компаний и активно работаем с экосистемами, позволяющими ускорять цифровое развитие клиентов.
            </p>
          </div>
          <div className="integrations-logos">
            <div>Azure</div>
            <div>Google</div>
            <div>VK Cloud</div>
            <div>Yandex</div>
            <div>Oracle</div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;