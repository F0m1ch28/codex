import { motion } from 'framer-motion';

const services = [
  {
    title: 'Цифровая трансформация и консалтинг',
    description:
      'Комплексная стратегия цифрового развития: аудит процессов, выявление точек роста, дорожная карта цифровизации и внедрение технологий для повышения эффективности.',
    highlights: ['Цифровая стратегия', 'Оценка зрелости', 'Дорожная карта трансформации', 'PMO и change management']
  },
  {
    title: 'Разработка цифровых продуктов',
    description:
      'Создание веб- и мобильных продуктов, платформ, сервисов самообслуживания и клиентских кабинетов с современным UX и архитектурой.',
    highlights: ['Платформенные решения', 'UX/UI дизайн', 'Frontend/Backend', 'Мобильные приложения']
  },
  {
    title: 'Data & AI-инжиниринг',
    description:
      'Построение хранилищ данных, BI, внедрение машинного обучения, компьютерного зрения и интеллектуальных помощников для автоматизации решений.',
    highlights: ['Data Lake & Warehouse', 'BI-панели', 'ML-модели', 'NLP и чат-боты']
  },
  {
    title: 'Интеграции и автоматизация процессов',
    description:
      'Единый цифровой контур: интеграция ERP, CRM, 1С, систем лояльности, маркетинга и внутренних сервисов через шины данных и API.',
    highlights: ['API-шлюзы', 'ESB', 'RPA-боты', 'ETL/ELT-процессы']
  },
  {
    title: 'Кибербезопасность и compliance',
    description:
      'Комплексное обеспечение безопасности: аудит, построение процессов, внедрение SIEM/SOAR, тестирование на проникновение, управление доступами.',
    highlights: ['Security Audit', 'Penetration Test', 'SOC/SIEM', 'GDPR и 152-ФЗ']
  },
  {
    title: 'Цифровой маркетинг и рост',
    description:
      'Data-driven маркетинг, омниканальные коммуникации, персонализация, автоматизация воронок и аналитика эффективности продвижения.',
    highlights: ['CRM-маркетинг', 'CDP', 'Аналитика роста', 'Performance & SEO']
  }
];

function Services() {
  return (
    <div className="container section">
      <div className="section-header">
        <span className="badge">Услуги</span>
        <h1 className="section-title">Комплексные услуги для цифрового роста бизнеса</h1>
        <p className="section-subtitle">
          Компания объединяет стратегию, разработку и поддержку. Мы строим экосистемы, а не отдельные продукты. Каждое решение адаптировано под бизнес-цели клиента и интегрируется в цифровую инфраструктуру.
        </p>
      </div>

      <div className="grid grid-cols-2">
        {services.map((service, index) => (
          <motion.div
            key={service.title}
            className="feature-card"
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.55, delay: index * 0.08 }}
          >
            <div className="chip">Премиальный сервис</div>
            <h2>{service.title}</h2>
            <p className="text-muted">{service.description}</p>
            <ul className="list-dotted">
              {service.highlights.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>

      <section className="section glass-panel" style={{ padding: '3rem', marginTop: '4rem' }}>
        <div className="section-header">
          <span className="badge">Форматы сотрудничества</span>
          <h2 className="section-title">Гибкие модели, ориентированные на результат</h2>
          <p className="section-subtitle">
            Мы предлагаем несколько моделей работы, чтобы соответствовать организационной структуре и культуре вашей компании.
          </p>
        </div>
        <div className="grid grid-cols-3">
          {[
            {
              title: 'Стратегический партнёр',
              description: 'Полное сопровождение трансформации: от стратегии и внедрения до развития и поддержки.',
              extras: ['Выделенная команда', 'PMO и отчётность', 'Гибридные методологии']
            },
            {
              title: 'Продуктовая команда',
              description: 'Кросс-функциональная команда для запуска и развития цифровых продуктов.',
              extras: ['Product owner', 'UX/UI', 'DevOps и QA']
            },
            {
              title: 'Экспертная поддержка',
              description: 'Включаемся точечно: аудит, архитектура, безопасность, масштабирование.',
              extras: ['Аудит и консалтинг', 'Кооптация специалистов', 'Мастер-классы и обучение']
            }
          ].map((model) => (
            <div key={model.title} className="testimonial-card">
              <h3>{model.title}</h3>
              <p className="text-muted">{model.description}</p>
              <ul className="list-dotted">
                {model.extras.map((extra) => (
                  <li key={extra}>{extra}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Services;