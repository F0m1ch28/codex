import faqData from '../data/faqData.js';

function FAQ() {
  return (
    <div className="container section">
      <div className="section-header">
        <span className="badge">FAQ</span>
        <h1 className="section-title">Часто задаваемые вопросы</h1>
        <p className="section-subtitle">
          Мы собрали ответы на ключевые вопросы о процессах, технологиях и форматах работы Компания. Если вы не нашли ответ — свяжитесь с нами, и мы подготовим подробную консультацию.
        </p>
      </div>

      <div className="glass-panel" style={{ padding: '3rem' }}>
        <div className="accordion">
          {faqData.map((item) => (
            <details key={item.question} className="accordion-item">
              <summary className="accordion-summary">
                {item.question}
                <span aria-hidden="true">+</span>
              </summary>
              <div className="accordion-content">
                <p>{item.answer}</p>
              </div>
            </details>
          ))}
        </div>
      </div>

      <section className="section">
        <div className="glass-panel" style={{ padding: '3rem' }}>
          <div className="section-header">
            <h2 className="section-title">Нужна индивидуальная консультация?</h2>
            <p className="section-subtitle">
              Наши эксперты готовы провести стратегическую встречу, оценить ваш запрос и предложить оптимальный сценарий сотрудничества.
            </p>
          </div>
          <a href="/contact" className="primary-button">
            Задать вопрос напрямую
          </a>
        </div>
      </section>
    </div>
  );
}

export default FAQ;