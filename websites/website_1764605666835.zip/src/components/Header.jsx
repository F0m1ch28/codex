import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const navItems = [
  { path: '/', label: 'Главная' },
  { path: '/about', label: 'О компании' },
  { path: '/services', label: 'Услуги' },
  { path: '/contact', label: 'Контакты' },
  { path: '/faq', label: 'FAQ' }
];

function Header({ theme, onToggleTheme }) {
  const [open, setOpen] = useState(false);

  const handleNavClick = () => {
    setOpen(false);
  };

  return (
    <header className="header">
      <div className="header-inner">
        <NavLink to="/" className="brand" aria-label="Компания — на главную">
          <span className="brand-icon">К</span>
          Компания
        </NavLink>
        <nav className="nav" aria-label="Главное меню">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => (isActive ? 'active' : undefined)}
              end={item.path === '/'}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <button
            className="theme-toggle"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Включить светлую тему' : 'Включить тёмную тему'}
          >
            {theme === 'dark' ? '🌙' : '☀️'}
          </button>
          <button
            className="mobile-toggle"
            onClick={() => setOpen((prev) => !prev)}
            aria-label="Меню"
            aria-expanded={open}
          >
            {open ? '✕' : '☰'}
          </button>
        </div>
        <AnimatePresence>
          {open && (
            <motion.div
              className="mobile-nav"
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
            >
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) => (isActive ? 'active' : undefined)}
                  end={item.path === '/'}
                  onClick={handleNavClick}
                >
                  {item.label}
                </NavLink>
              ))}
              <NavLink to="/privacy-policy" onClick={handleNavClick}>
                Политика конфиденциальности
              </NavLink>
              <NavLink to="/terms-of-service" onClick={handleNavClick}>
                Условия использования
              </NavLink>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}

export default Header;