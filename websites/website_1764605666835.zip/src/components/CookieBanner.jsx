import { useEffect, useState } from 'react';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('cookie-consent');
    if (!storedConsent) {
      setVisible(true);
      document.body.setAttribute('data-overlay', 'visible');
    } else {
      document.body.setAttribute('data-overlay', 'hidden');
    }
  }, []);

  const handleChoice = (value) => {
    localStorage.setItem('cookie-consent', value);
    setVisible(false);
    document.body.setAttribute('data-overlay', 'hidden');
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Уведомление о cookies">
      <strong>Мы используем cookies</strong>
      <p className="text-muted">
        Мы применяем файлы cookies, чтобы повысить удобство использования сайта, персонализировать контент и анализировать трафик. Вы можете принять или отклонить использование необязательных cookies.
      </p>
      <div className="cookie-actions">
        <button className="primary-button" onClick={() => handleChoice('accepted')}>
          Принять все
        </button>
        <button className="secondary-button decline" onClick={() => handleChoice('declined')}>
          Отклонить
        </button>
      </div>
      <small className="text-muted">
        Подробнее читайте в <a href="/privacy-policy">Политике конфиденциальности</a>.
      </small>
    </div>
  );
}

export default CookieBanner;