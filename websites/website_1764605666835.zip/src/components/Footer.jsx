import { NavLink } from 'react-router-dom';

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="brand">
            <span className="brand-icon">К</span>
            Компания
          </div>
          <p>
            Премиальные цифровые решения, которые трансформируют бизнес и создают устойчивые конкурентные преимущества.
          </p>
          <div className="tag">Создаём будущее бизнеса сегодня</div>
        </div>
        <div>
          <h4>Навигация</h4>
          <div className="footer-links">
            <NavLink to="/">Главная</NavLink>
            <NavLink to="/about">О компании</NavLink>
            <NavLink to="/services">Услуги</NavLink>
            <NavLink to="/contact">Контакты</NavLink>
            <NavLink to="/faq">FAQ</NavLink>
          </div>
        </div>
        <div>
          <h4>Правовая информация</h4>
          <div className="footer-links">
            <NavLink to="/privacy-policy">Политика конфиденциальности</NavLink>
            <NavLink to="/terms-of-service">Условия использования</NavLink>
          </div>
        </div>
        <div>
          <h4>Контакты</h4>
          <div className="footer-links">
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:info@company.ru">info@company.ru</a>
            <span>Москва, Пресненская наб., 12</span>
          </div>
          <div className="social-links" aria-label="Социальные сети">
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              in
            </a>
            <a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Telegram">
              ✈️
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
              ▶️
            </a>
          </div>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Компания. Все права защищены.</span>
        <span>Сделано с вниманием к деталям и инновациям.</span>
      </div>
    </footer>
  );
}

export default Footer;