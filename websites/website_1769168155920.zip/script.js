document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      siteNav.classList.toggle("open");
    });
  }

  document.querySelectorAll(".fade-section").forEach((section) => {
    section.classList.add("observe");
  });
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll(".fade-section").forEach((section) => observer.observe(section));

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storageKey = "ml_cookie_choice";
    const storedChoice = localStorage.getItem(storageKey);
    if (!storedChoice) {
      cookieBanner.classList.remove("hidden");
    }
    cookieBanner.querySelectorAll("button").forEach((btn) => {
      btn.addEventListener("click", () => {
        localStorage.setItem(storageKey, btn.classList.contains("accept") ? "accepted" : "declined");
        cookieBanner.classList.add("hidden");
      });
    });
  }

  const forms = document.querySelectorAll("form[data-redirect]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const redirectTarget = form.getAttribute("data-redirect") || "thank-you.html";
      showToast("Message sent. Redirecting…");
      setTimeout(() => {
        window.location.href = redirectTarget;
      }, 1600);
    });
  });

  function showToast(message) {
    const existingToast = document.querySelector(".toast");
    if (existingToast) {
      existingToast.remove();
    }
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.transition = "opacity 0.4s ease, transform 0.4s ease";
      toast.style.opacity = "0";
      toast.style.transform = "translateY(20px)";
      setTimeout(() => toast.remove(), 400);
    }, 2200);
  }

  const yearSpan = document.querySelectorAll("#current-year");
  const currentYear = new Date().getFullYear();
  yearSpan.forEach((span) => {
    span.textContent = currentYear;
  });
});