document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.navigation');
    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navigation.classList.toggle('open');
        });
    }

    const timelineItems = document.querySelectorAll('.timeline-item');
    const timelineControls = document.querySelectorAll('[data-timeline-control]');
    let activeTimelineIndex = 0;

    const setActiveTimeline = (index) => {
        if (!timelineItems.length) return;
        activeTimelineIndex = (index + timelineItems.length) % timelineItems.length;
        timelineItems.forEach((item, idx) => {
            if (idx === activeTimelineIndex) {
                item.classList.add('active');
                item.setAttribute('aria-expanded', 'true');
                item.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
            } else {
                item.classList.remove('active');
                item.setAttribute('aria-expanded', 'false');
            }
        });
    };

    timelineItems.forEach((item, idx) => {
        item.addEventListener('click', () => setActiveTimeline(idx));
        item.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                setActiveTimeline(idx);
            }
        });
    });

    timelineControls.forEach((control) => {
        control.addEventListener('click', () => {
            const direction = control.getAttribute('data-timeline-control');
            if (direction === 'prev') {
                setActiveTimeline(activeTimelineIndex - 1);
            } else if (direction === 'next') {
                setActiveTimeline(activeTimelineIndex + 1);
            }
        });
    });

    if (timelineItems.length) {
        setActiveTimeline(0);
    }

    const modalTriggers = document.querySelectorAll('[data-modal-target]');
    const modals = document.querySelectorAll('.modal');
    modalTriggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const targetId = trigger.getAttribute('data-modal-target');
            const modal = document.getElementById(targetId);
            if (modal) {
                modal.classList.add('open');
                modal.setAttribute('aria-hidden', 'false');
                modal.querySelector('.modal-close').focus();
            }
        });
    });

    modals.forEach((modal) => {
        const closeBtn = modal.querySelector('.modal-close');
        closeBtn.addEventListener('click', () => {
            modal.classList.remove('open');
            modal.setAttribute('aria-hidden', 'true');
        });
        modal.addEventListener('click', (event) => {
            if (event.target === modal) {
                modal.classList.remove('open');
                modal.setAttribute('aria-hidden', 'true');
            }
        });
        modal.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                modal.classList.remove('open');
                modal.setAttribute('aria-hidden', 'true');
            }
        });
    });

    const accordionHeaders = document.querySelectorAll('.accordion-header');
    accordionHeaders.forEach((header) => {
        header.addEventListener('click', () => {
            const parent = header.parentElement;
            parent.classList.toggle('open');
        });

        header.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                const parent = header.parentElement;
                parent.classList.toggle('open');
            }
        });
    });

    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');
    const cookieDecline = document.getElementById('cookie-decline');
    const cookieChoice = localStorage.getItem('cronicaCookieChoice');

    if (!cookieChoice && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    const closeCookieBanner = (choice) => {
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
        localStorage.setItem('cronicaCookieChoice', choice);
    };

    if (cookieAccept) {
        cookieAccept.addEventListener('click', () => closeCookieBanner('acceptat'));
    }

    if (cookieDecline) {
        cookieDecline.addEventListener('click', () => closeCookieBanner('respins'));
    }

    const lightboxItems = document.querySelectorAll('.lightbox-item');
    lightboxItems.forEach((item) => {
        item.addEventListener('click', () => {
            const targetId = item.getAttribute('data-modal-target');
            if (targetId) {
                const modal = document.getElementById(targetId);
                if (modal) {
                    modal.classList.add('open');
                    modal.setAttribute('aria-hidden', 'false');
                }
            }
        });
    });
});