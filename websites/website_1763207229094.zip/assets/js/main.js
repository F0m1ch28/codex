document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    const scrollTopBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const body = document.body;

    // Mobile navigation
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
            body.classList.toggle('no-scroll', !expanded);
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
                body.classList.remove('no-scroll');
            });
        });
    }

    // Scroll to top button
    const toggleScrollButton = () => {
        if (window.scrollY > 320) {
            scrollTopBtn.style.display = 'flex';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    };

    window.addEventListener('scroll', toggleScrollButton);
    toggleScrollButton();

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    const consentKey = 'adiCookieConsent';

    const showCookieBanner = () => {
        if (!localStorage.getItem(consentKey) && cookieBanner) {
            cookieBanner.style.display = 'block';
        }
    };

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.style.display = 'none';
        });
    }

    showCookieBanner();

    // Update footer year
    const currentYearElement = document.getElementById('currentYear');
    if (currentYearElement) {
        currentYearElement.textContent = new Date().getFullYear();
    }

    // Ensure window resets scroll on page load
    window.scrollTo(0, 0);
});