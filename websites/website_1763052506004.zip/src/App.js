// @ts-check
import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Services = lazy(() => import('./pages/Services'));
const Workflows = lazy(() => import('./pages/Workflows'));
const Mindset = lazy(() => import('./pages/Mindset'));
const Notes = lazy(() => import('./pages/Notes'));
const ReadingQueue = lazy(() => import('./pages/ReadingQueue'));
const Archives = lazy(() => import('./pages/Archives'));
const BlogArchive = lazy(() => import('./pages/BlogArchive'));
const ContextSwitchingArticle = lazy(() => import('./pages/ContextSwitchingArticle'));
const CloudPatternsArticle = lazy(() => import('./pages/CloudPatternsArticle'));
const DevOpsEvolutionArticle = lazy(() => import('./pages/DevOpsEvolutionArticle'));
const Contact = lazy(() => import('./pages/Contact'));
const ContactThanks = lazy(() => import('./pages/ContactThanks'));
const PrivacyPolicy = lazy(() => import('./pages/PrivacyPolicy'));
const TermsOfService = lazy(() => import('./pages/TermsOfService'));

const LoadingScreen = () => (
  <div className="loading-screen" role="alert" aria-live="polite">
    <div className="loading-spinner" />
    <p className="loading-text">Preparing DevLayer insights…</p>
  </div>
);

const App = () => {
  return (
    <div className="app-shell">
      <Header />
      <Suspense fallback={<LoadingScreen />}>
        <main className="main-content" id="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/workflows" element={<Workflows />} />
            <Route path="/mindset" element={<Mindset />} />
            <Route path="/notes" element={<Notes />} />
            <Route path="/queue" element={<ReadingQueue />} />
            <Route path="/archives" element={<Archives />} />
            <Route path="/blog" element={<BlogArchive />} />
            <Route path="/blog/why-context-switching-kills-productivity" element={<ContextSwitchingArticle />} />
            <Route path="/blog/cloud-patterns-for-scale" element={<CloudPatternsArticle />} />
            <Route path="/blog/the-evolution-of-devops-culture" element={<DevOpsEvolutionArticle />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/contact/thanks" element={<ContactThanks />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/terms" element={<TermsOfService />} />
            <Route
              path="*"
              element={
                <div className="not-found">
                  <h1>Page not found</h1>
                  <p>The requested page is unavailable. Try a different path or return home.</p>
                </div>
              }
            />
          </Routes>
        </main>
      </Suspense>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;