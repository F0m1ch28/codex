// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const queueItems = [
  { title: 'Measuring Developer Experience', status: 'In Review', focus: 'Developer productivity frameworks within Canadian enterprises.' },
  { title: 'Service Ownership Blueprints', status: 'Editing', focus: 'Approaches to aligning SRE and product teams around service lifecycles.' },
  { title: 'Cognitive Load of Alerting', status: 'Researching', focus: 'Impact of alert noise on distributed on-call teams.' },
  { title: 'Composable Platform Teams', status: 'Drafting', focus: 'Structuring platform groups as internal product teams.' }
];

const ReadingQueue = () => {
  return (
    <motion.div
      className="page queue-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      <Helmet>
        <title>Reading Queue — DevLayer</title>
        <meta
          name="description"
          content="DevLayer's upcoming editorial queue featuring research on developer experience, service ownership, and cognitive load."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Reading Queue</h1>
          <p>
            Stay ahead with a preview of essays and reports currently in production. These pieces are informed by interviews with engineering teams across Canada.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container queue-list">
          {queueItems.map((item) => (
            <article key={item.title} className="queue-item">
              <div>
                <h2>{item.title}</h2>
                <p>{item.focus}</p>
              </div>
              <span className="queue-status">{item.status}</span>
            </article>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default ReadingQueue;