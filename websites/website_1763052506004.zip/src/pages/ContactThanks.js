// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const ContactThanks = () => {
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const name = params.get('name') || 'there';

  return (
    <motion.div
      className="page contact-thanks-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <Helmet>
        <title>Thank You — DevLayer</title>
        <meta
          name="description"
          content="Thank you message from DevLayer after receiving contact inquiries."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Thank You, {name}!</h1>
          <p>
            We received your message and will respond within two business days. In the meantime, explore our latest essays or workflow studies.
          </p>
          <div className="hero-actions">
            <Link to="/blog" className="btn btn-primary">
              Read the Latest Essays
            </Link>
            <Link to="/workflows" className="btn btn-secondary">
              Explore Workflows
            </Link>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default ContactThanks;