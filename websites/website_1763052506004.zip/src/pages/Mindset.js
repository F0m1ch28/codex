// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const Mindset = () => {
  return (
    <motion.div
      className="page mindset-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      <Helmet>
        <title>Developer Mindset — DevLayer</title>
        <meta
          name="description"
          content="DevLayer explores the developer mindset, covering cognitive load, team rituals, and psychological elements of engineering work."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Developer Mindset</h1>
          <p>
            Engineering excellence thrives when teams understand the psychological layers behind systems. DevLayer studies attention, trust, and learning patterns to help teams grow with intention.
          </p>
        </div>
      </section>

      <section className="section mindset-section">
        <div className="container mindset-columns">
          <article>
            <h2>Cognitive Load</h2>
            <p>
              We examine how developers manage competing stimuli: deployments, alerts, review requests, and ideation. Our studies highlight strategies that protect deep work.
            </p>
          </article>
          <article>
            <h2>Team Rituals</h2>
            <p>
              Rituals—standups, demos, retros—shape team culture. We observe how they evolve and how subtle adjustments can improve belonging and shared awareness.
            </p>
          </article>
          <article>
            <h2>Learning Networks</h2>
            <p>
              Growth depends on accessible knowledge flows. We document how mentorship, internal conferences, and guilds sustain learning with minimal friction.
            </p>
          </article>
        </div>
      </section>

      <section className="section">
        <div className="container insight-panel">
          <h2>Mindset Field Notes</h2>
          <ul>
            <li>Engineers who narrate decisions create resilient documentation trails.</li>
            <li>Psychological safety is visible in pull request comments and incident follow-ups.</li>
            <li>Balanced tooling ecosystems reduce context thrash and cognitive fatigue.</li>
          </ul>
        </div>
      </section>
    </motion.div>
  );
};

export default Mindset;