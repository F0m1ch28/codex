// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const posts = [
  {
    title: 'Why Context Switching Kills Productivity',
    excerpt: 'Exploring the cognitive toll of multitasking and how engineering teams reclaim focus.',
    link: '/blog/why-context-switching-kills-productivity',
    category: 'Developer Mindset',
    date: 'January 5, 2024'
  },
  {
    title: 'Cloud Patterns for Scale',
    excerpt: 'Mapping cloud architecture patterns that help distributed teams sustain resilience.',
    link: '/blog/cloud-patterns-for-scale',
    category: 'Cloud Infrastructure',
    date: 'December 11, 2023'
  },
  {
    title: 'The Evolution of DevOps Culture',
    excerpt: 'A timeline of how DevOps thinking matured into modern platform engineering.',
    link: '/blog/the-evolution-of-devops-culture',
    category: 'DevOps Culture',
    date: 'November 20, 2023'
  }
];

const BlogArchive = () => {
  return (
    <motion.div
      className="page blog-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
    >
      <Helmet>
        <title>DevLayer Blog</title>
        <meta
          name="description"
          content="Read DevLayer essays on developer workflows, cloud infrastructure, and platform engineering."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>DevLayer Blog</h1>
          <p>
            Essays combining engineering research and storytelling to illuminate systems, workflows, and human-centered practices.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container blog-grid">
          {posts.map((post) => (
            <article key={post.title} className="blog-card">
              <span className="blog-category">{post.category}</span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <div className="blog-meta">
                <span>{post.date}</span>
                <Link to={post.link} className="link-arrow">
                  Read →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default BlogArchive;