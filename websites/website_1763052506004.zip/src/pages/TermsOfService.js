// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';

const TermsOfService = () => {
  return (
    <div className="page legal-page">
      <Helmet>
        <title>Terms of Service — DevLayer</title>
        <meta
          name="description"
          content="DevLayer terms of service outlining usage guidelines for the devlayer.ca website."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Terms of Service</h1>
          <p>Last updated: January 2, 2024</p>
        </div>
      </section>

      <section className="section">
        <div className="container legal-content">
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing devlayer.ca you agree to these terms. If you do not agree, please do not use the site.
          </p>

          <h2>2. Use of Content</h2>
          <p>
            Content on DevLayer is provided for informational and educational purposes. You may share excerpts with attribution. Unauthorized duplication or distribution is prohibited.
          </p>

          <h2>3. Intellectual Property</h2>
          <p>
            All content, branding, graphics, and code are the property of DevLayer unless otherwise noted.
          </p>

          <h2>4. Third-Party Links</h2>
          <p>
            DevLayer may link to external resources. We are not responsible for the content or practices of those sites.
          </p>

          <h2>5. Liability</h2>
          <p>
            DevLayer provides content “as is.” We are not liable for decisions made based on our publications. Always evaluate within your organizational context.
          </p>

          <h2>6. Changes to Terms</h2>
          <p>
            We may update these terms periodically. Continued use of the site constitutes acceptance of the revised terms.
          </p>

          <h2>7. Contact</h2>
          <p>
            Questions about these terms can be directed to editorial@devlayer.ca or +1 (416) 905-6621.
          </p>
        </div>
      </section>
    </div>
  );
};

export default TermsOfService;