// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';

const PrivacyPolicy = () => {
  return (
    <div className="page legal-page">
      <Helmet>
        <title>Privacy Policy — DevLayer</title>
        <meta
          name="description"
          content="DevLayer privacy policy describing data collection, usage, and storage practices."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Privacy Policy</h1>
          <p>Last updated: January 2, 2024</p>
        </div>
      </section>

      <section className="section">
        <div className="container legal-content">
          <h2>1. Overview</h2>
          <p>
            DevLayer respects your privacy. This policy explains how we collect, store, and use information when you visit devlayer.ca or engage with our services.
          </p>

          <h2>2. Information We Collect</h2>
          <ul>
            <li>Contact details you share via forms (name, email, organization, message).</li>
            <li>Analytics data such as page views, browser type, and session duration.</li>
            <li>Any additional information you voluntarily provide during consultations.</li>
          </ul>

          <h2>3. How We Use Information</h2>
          <p>We use collected information to:</p>
          <ul>
            <li>Respond to inquiries and deliver requested services.</li>
            <li>Improve website performance and editorial offerings.</li>
            <li>Send optional editorial updates when you opt into communications.</li>
          </ul>

          <h2>4. Data Storage</h2>
          <p>
            Data is stored securely using reputable Canadian and international providers with appropriate safeguards. We retain information only as long as necessary to fulfill the purposes described above.
          </p>

          <h2>5. Cookies and Analytics</h2>
          <p>
            DevLayer uses essential cookies to understand site usage and improve content. You can manage cookie preferences in your browser settings.
          </p>

          <h2>6. Your Rights</h2>
          <p>
            You may request access, correction, or deletion of personal information at any time by contacting editorial@devlayer.ca.
          </p>

          <h2>7. Contact</h2>
          <p>
            For privacy questions, contact DevLayer at 333 Bay St, Toronto, ON M5H 2R2, Canada or call +1 (416) 905-6621.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicy;