// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const workflowPlays = [
  {
    name: 'Flow Alignment',
    summary: 'Visualize idea-to-production flow, balancing throughput with technical debt management.',
    points: ['Value stream analysis', 'Queue depth tracking', 'Dependency audits']
  },
  {
    name: 'Incident Storyboard',
    summary: 'Capture the anatomy of critical incidents, connecting alerts to human decisions.',
    points: ['Timeline reconstruction', 'Cognitive load review', 'Runbook refinement']
  },
  {
    name: 'Async Rhythm',
    summary: 'Design collaboration rhythms for distributed teams without overwhelming attention.',
    points: ['Communication canvas', 'Decision log practices', 'Meeting taxonomy']
  }
];

const Workflows = () => {
  return (
    <motion.div
      className="page workflows-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      <Helmet>
        <title>Workflows — DevLayer</title>
        <meta
          name="description"
          content="DevLayer examines developer workflows through flow alignment, incident storyboards, and asynchronous collaboration rhythms."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Workflows</h1>
          <p>
            We observe, map, and narrate the rhythms of software delivery. From build pipelines to retrospectives, DevLayer translates workflows into insight-rich stories.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container workflow-grid">
          {workflowPlays.map((play) => (
            <motion.article
              key={play.name}
              className="workflow-card"
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5 }}
            >
              <h2>{play.name}</h2>
              <p>{play.summary}</p>
              <ul>
                {play.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section workflow-insight">
        <div className="container">
          <h2>Workflow Signals We Track</h2>
          <div className="insight-grid">
            <article>
              <h3>Flow Metrics</h3>
              <p>Cycle time, lead time, and change volume reveal how ideas become features.</p>
            </article>
            <article>
              <h3>Collaboration Friction</h3>
              <p>We analyze handoffs, approvals, and review loops to see where work stalls.</p>
            </article>
            <article>
              <h3>Resilience Practices</h3>
              <p>Incident drills, post-incident learning, and on-call health indicators signal organizational vitality.</p>
            </article>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default Workflows;