// @ts-check
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const heroImage = 'https://picsum.photos/1600/900?random=401';
const featuredImage = 'https://picsum.photos/800/600?random=402';
const toolImage = 'https://picsum.photos/800/600?random=403';
const teamImage = 'https://picsum.photos/400/400?random=404';
const projectImageA = 'https://picsum.photos/1200/800?random=405';
const projectImageB = 'https://picsum.photos/1200/800?random=406';
const projectImageC = 'https://picsum.photos/1200/800?random=407';

const statsData = [
  { label: 'Workflow Playbooks', value: 72, suffix: '+' },
  { label: 'Cloud Patterns Mapped', value: 48, suffix: '' },
  { label: 'Engineer Conversations', value: 136, suffix: '+' }
];

const featuredEssays = [
  {
    title: 'Why Context Switching Kills Productivity',
    description:
      'Dissecting the cognitive overhead that fragments deep engineering work and how to regain durable focus.',
    link: '/blog/why-context-switching-kills-productivity'
  },
  {
    title: 'Cloud Patterns for Scale',
    description:
      'A layered look at distributed patterns that help Canadian teams scale without losing operational clarity.',
    link: '/blog/cloud-patterns-for-scale'
  },
  {
    title: 'The Evolution of DevOps Culture',
    description:
      'Tracing the narrative of DevOps as it becomes platform engineering and the next frontier of socio-technical maturity.',
    link: '/blog/the-evolution-of-devops-culture'
  }
];

const workflowServices = [
  {
    title: 'Workflow Diagnostics',
    description:
      'We map the flow of code, conversations, and deployments to reveal bottlenecks across your delivery stream.',
    highlights: ['Value stream mapping', 'Incident retrospectives', 'Flow metrics synthesis']
  },
  {
    title: 'Platform Narrative Maps',
    description:
      'We translate infrastructure strategy into stories that align engineering, product, and leadership decisions.',
    highlights: ['Service catalogs', 'Capability modeling', 'Alignment workshops']
  },
  {
    title: 'Runbook Storytelling',
    description:
      'We craft precision runbooks anchored in real incidents to solidify institutional knowledge.',
    highlights: ['Failure scenario drills', 'Resilience patterns', 'Human-centered documentation']
  }
];

const processSteps = [
  { step: '01', title: 'Observe', description: 'Shadow engineering rituals, deployments, and on-call rhythms.' },
  { step: '02', title: 'Synthesize', description: 'Translate observations into maps, scorecards, and shared language.' },
  { step: '03', title: 'Model', description: 'Design future-state workflows with tangible adoption pathways.' },
  { step: '04', title: 'Amplify', description: 'Publish editorial-grade narratives to keep change visible and sustained.' }
];

const toolSignals = [
  { title: 'Observability Signals', description: 'We collect metrics, traces, and logs to surface the story behind system drift.' },
  { title: 'Automation Footprints', description: 'We track pipeline latency, change failure rates, and recovery indicators.' },
  { title: 'Collaboration Pulse', description: 'We evaluate decision logs, runbooks, and messaging channels for clarity.' }
];

const testimonials = [
  {
    quote:
      'DevLayer translated a maze of platform initiatives into a clear plan. Their editorial voice brought our workflow goals to life.',
    name: 'Alicia Romero',
    role: 'Director of Platform Strategy, Vancouver'
  },
  {
    quote:
      'The team captured nuance across distributed services and gave us language to align SRE and product leadership.',
    name: 'Harper Chen',
    role: 'Principal Engineer, Calgary'
  },
  {
    quote:
      'Their synthesis of cognitive load research with real incident data reshaped how we design on-call rotations.',
    name: 'Morgan Patel',
    role: 'Engineering Manager, Montreal'
  }
];

const teamMembers = [
  {
    name: 'Sofia Bennett',
    role: 'Editor-in-Chief',
    focus: 'Leads investigative features on platform engineering culture.'
  },
  {
    name: 'Amir Khanna',
    role: 'Head of Research',
    focus: 'Curates distributed systems case studies across Canadian teams.'
  },
  {
    name: 'Chloe Martin',
    role: 'Senior Narrative Designer',
    focus: 'Architects runbooks and workflow animations.'
  }
];

const projects = [
  {
    title: 'Resilience Atlas',
    category: 'Observability',
    description: 'Interactive incident atlas showing blast radius containment strategies for hybrid clouds.',
    image: projectImageA
  },
  {
    title: 'Pipeline Cadence Board',
    category: 'Automation',
    description: 'Visualization of deployment rhythms across microservice squads to reduce queue buildups.',
    image: projectImageB
  },
  {
    title: 'Distributed Comm Stack',
    category: 'Architecture',
    description: 'Comparative analysis of asynchronous collaboration rituals for remote-first engineering groups.',
    image: projectImageC
  }
];

const faqs = [
  {
    question: 'What is DevLayer’s editorial focus?',
    answer:
      'We examine the interplay between software systems, human workflows, and platform engineering choices. Every feature blends research, interviews, and hands-on experimentation.'
  },
  {
    question: 'Who contributes to DevLayer?',
    answer:
      'Our core team collaborates with Canadian platform engineers, SRE leaders, and technical writers who bring first-hand stories from production environments.'
  },
  {
    question: 'Can DevLayer study our workflows?',
    answer:
      'Yes. We partner with engineering teams to observe delivery rituals, synthesize patterns, and publish narratives that guide transformation efforts.'
  }
];

const Home = () => {
  const [statValues, setStatValues] = useState(() => statsData.map(() => 0));
  const [statsVisible, setStatsVisible] = useState(false);
  const statsRef = useRef(null);

  const [activeCategory, setActiveCategory] = useState('All');
  const categories = useMemo(
    () => ['All', ...new Set(projects.map((project) => project.category))],
    []
  );

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'All') {
      return projects;
    }
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState('');
  const [openFaqIndex, setOpenFaqIndex] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStatsVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.4 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsVisible) return;
    const intervals = statsData.map((stat, index) => {
      let current = 0;
      const increment = stat.value / 32;
      return window.setInterval(() => {
        current += increment;
        if (current >= stat.value) {
          current = stat.value;
          window.clearInterval(intervals[index]);
        }
        setStatValues((prev) => {
          const nextValues = [...prev];
          nextValues[index] = Math.round(current);
          return nextValues;
        });
      }, 40);
    });
    return () => intervals.forEach((interval) => window.clearInterval(interval));
  }, [statsVisible]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => window.clearInterval(timer);
  }, []);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) {
      setNewsletterStatus('Add a valid email to receive upcoming issues.');
      return;
    }
    setNewsletterStatus('Thanks for joining our editorial signal. We will be in touch soon.');
    setNewsletterEmail('');
  };

  return (
    <motion.div
      className="home-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
    >
      <Helmet>
        <title>DevLayer — Every Layer Tells a Story</title>
        <meta
          name="description"
          content="DevLayer is an editorial platform based in Canada focused on developer workflows, software systems, and cloud infrastructure."
        />
        <meta property="og:title" content="DevLayer — Every Layer Tells a Story" />
        <meta
          property="og:description"
          content="Exploring workflows, platform engineering, and the cognitive practices shaping modern development."
        />
        <meta property="og:image" content={heroImage} />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Organization',
            name: 'DevLayer',
            url: 'https://www.devlayer.ca',
            logo: 'https://www.devlayer.ca/logo192.png',
            address: {
              '@type': 'PostalAddress',
              streetAddress: '333 Bay St',
              addressLocality: 'Toronto',
              addressRegion: 'ON',
              postalCode: 'M5H 2R2',
              addressCountry: 'Canada'
            },
            contactPoint: [
              {
                '@type': 'ContactPoint',
                telephone: '+1-416-905-6621',
                contactType: 'editorial support',
                areaServed: 'CA',
                availableLanguage: ['English']
              }
            ]
          })}
        </script>
      </Helmet>

      {/* Section 1: Hero */}
      <section className="hero-section">
        <div className="container hero-grid">
          <motion.div
            className="hero-copy"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <h1>Every Layer Tells a Story</h1>
            <p>
              DevLayer studies how engineers shape software systems, how workflows evolve inside Canadian teams, and how cloud platforms can be narrated with clarity. We give structure to the complexity so leaders and makers stay aligned.
            </p>
            <div className="hero-actions">
              <Link to="/services" className="btn btn-primary">
                Explore Editorial Services
              </Link>
              <Link to="/blog" className="btn btn-secondary">
                Browse Essays
              </Link>
            </div>
          </motion.div>
          <motion.div
            className="hero-visual"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, ease: 'easeOut', delay: 0.2 }}
          >
            <img src={heroImage} alt="Engineers collaborating around layered architecture diagrams" loading="eager" />
          </motion.div>
        </div>
        <div className="container hero-stats" ref={statsRef}>
          {statsData.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="hero-stat-card"
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, ease: 'easeOut', delay: index * 0.1 }}
            >
              <span className="hero-stat-value">
                {statValues[index]}
                {stat.suffix}
              </span>
              <span className="hero-stat-label">{stat.label}</span>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Section 2: What we explore */}
      <section className="section what-we-explore">
        <div className="container section-header">
          <h2>What We Explore</h2>
          <p>
            Our editorial research spans systems thinking, collaborative rituals, and the psychology of engineering teams navigating distributed environments.
          </p>
        </div>
        <div className="container explore-grid">
          <motion.article
            className="explore-card"
            whileHover={{ translateY: -6 }}
            transition={{ duration: 0.3 }}
          >
            <h3>Software Systems</h3>
            <p>
              We chart the architecture decisions and platform evolutions that let Canadian teams sustain high availability.
            </p>
            <ul>
              <li>Resilience architectures</li>
              <li>Service ownership patterns</li>
              <li>SLO storytelling</li>
            </ul>
          </motion.article>
          <motion.article
            className="explore-card"
            whileHover={{ translateY: -6 }}
            transition={{ duration: 0.3, delay: 0.05 }}
          >
            <h3>Workflows</h3>
            <p>
              We follow work from ideation to deploy, uncovering friction points and the rituals that keep delivery moving.
            </p>
            <ul>
              <li>Delivery cadences</li>
              <li>Incident play-by-plays</li>
              <li>Code review ethnography</li>
            </ul>
          </motion.article>
          <motion.article
            className="explore-card"
            whileHover={{ translateY: -6 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <h3>Cognitive Processes</h3>
            <p>
              We interpret how attention, memory, and trust influence the way engineers interact with tooling and documentation.
            </p>
            <ul>
              <li>Context management</li>
              <li>Team sensemaking</li>
              <li>On-call wellbeing</li>
            </ul>
          </motion.article>
        </div>
      </section>

      {/* Section 3: Featured Essays (Blog preview) */}
      <section className="section featured-essays">
        <div className="container section-header">
          <h2>Featured Essays</h2>
          <p>
            Weekly essays blending investigative reporting with practical models for platform teams.
          </p>
        </div>
        <div className="container essays-grid">
          {featuredEssays.map((essay) => (
            <motion.article
              key={essay.title}
              className="essay-card"
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
            >
              <img src={featuredImage} alt="Editorial workspace overview" loading="lazy" />
              <div className="essay-content">
                <h3>{essay.title}</h3>
                <p>{essay.description}</p>
                <Link to={essay.link} className="link-arrow">
                  Read the essay →
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* Section 4: Workflow Patterns & Services */}
      <section className="section workflow-patterns">
        <div className="container section-header">
          <h2>Workflow Patterns</h2>
          <p>
            We transform observations into tangible services that illuminate the flow of software creation.
          </p>
        </div>
        <div className="container services-grid">
          {workflowServices.map((service) => (
            <motion.article
              key={service.title}
              className="service-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.3 }}
            >
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <ul>
                {service.highlights.map((highlight) => (
                  <li key={highlight}>{highlight}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
        <div className="container process-grid">
          <div className="process-visual">
            <img src={toolImage} alt="Workflow diagrams illustrating editorial processes" loading="lazy" />
          </div>
          <div className="process-steps">
            <h3>Our Editorial Workflow</h3>
            <p>
              Structured discovery ensures every artifact we produce mirrors the reality inside your engineering environment.
            </p>
            <ol>
              {processSteps.map((step) => (
                <li key={step.step}>
                  <span className="process-step-number">{step.step}</span>
                  <div>
                    <h4>{step.title}</h4>
                    <p>{step.description}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* Section 5: Tool Signals & Projects */}
      <section className="section tool-signals">
        <div className="container section-header">
          <h2>Signals from Tools</h2>
          <p>
            Operational data becomes meaningful when linked with human decisions. We extract those signals and present them as narratives.
          </p>
        </div>
        <div className="container signal-grid">
          {toolSignals.map((signal) => (
            <motion.article
              key={signal.title}
              className="signal-card"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.55 }}
            >
              <h3>{signal.title}</h3>
              <p>{signal.description}</p>
            </motion.article>
          ))}
        </div>

        <div className="container projects-section">
          <div className="projects-header">
            <h3>Project Library</h3>
            <div className="project-filters" role="tablist" aria-label="Project categories">
              {categories.map((category) => (
                <button
                  key={category}
                  className={`chip ${activeCategory === category ? 'chip--active' : ''}`}
                  onClick={() => setActiveCategory(category)}
                  type="button"
                  role="tab"
                  aria-selected={activeCategory === category}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <motion.article
                key={project.title}
                className="project-card"
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.6 }}
              >
                <img src={project.image} alt={`${project.title} visual`} loading="lazy" />
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h4>{project.title}</h4>
                  <p>{project.description}</p>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      {/* Section 6: Developer Mindset & Testimonials */}
      <section className="section developer-mindset">
        <div className="container section-header">
          <h2>Developer Mindset</h2>
          <p>
            Understanding engineering psychology is essential to designing effective workflows. We surface the narratives that sustain resilient teams.
          </p>
        </div>
        <div className="container mindset-grid">
          <motion.article
            className="mindset-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6 }}
          >
            <h3>Attention Economics</h3>
            <p>
              We study how context windows shrink under notifications, handoffs, and tool overload—then map ways to restore deliberate practice.
            </p>
          </motion.article>
          <motion.article
            className="mindset-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h3>Team Signals</h3>
            <p>
              Psychological safety manifests in branching strategies, retro scripts, and incident language. We decode those signals to strengthen trust.
            </p>
          </motion.article>
          <motion.article
            className="mindset-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3>Learning Systems</h3>
            <p>
              From runbooks to internal conferences, we highlight practices that keep knowledge flowing across distributed squads.
            </p>
          </motion.article>
        </div>

        <div className="container testimonial-section">
          <div className="testimonial-content">
            <h3>Voices from the Community</h3>
            <p>
              Leaders across Canada share how DevLayer helped them understand the heartbeat of their engineering orgs.
            </p>
            <div className="testimonial-controls">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setActiveTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))}
              >
                Previous
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
              >
                Next
              </button>
            </div>
          </div>
          <motion.div
            key={testimonials[activeTestimonial].name}
            className="testimonial-card"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <p className="testimonial-quote">“{testimonials[activeTestimonial].quote}”</p>
            <span className="testimonial-name">{testimonials[activeTestimonial].name}</span>
            <span className="testimonial-role">{testimonials[activeTestimonial].role}</span>
          </motion.div>
        </div>
      </section>

      {/* Section 7: Code History & Team */}
      <section className="section code-history">
        <div className="container section-header">
          <h2>History in the Code</h2>
          <p>
            Every repository keeps a journal. We interpret that history and pair it with the people shaping each transformation.
          </p>
        </div>
        <div className="container history-grid">
          <div className="history-timeline">
            <div className="timeline-item">
              <span className="timeline-year">2018</span>
              <p>
                DevLayer launched with investigative pieces on monolith-to-microservice transitions within Ontario startups.
              </p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2020</span>
              <p>
                Expanded coverage to include cloud infrastructure patterns and platform engineering benchmarks.
              </p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2022</span>
              <p>
                Introduced immersive workflow diagnostics for remote-first teams navigating multi-region deployments.
              </p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2023</span>
              <p>
                Launched the DevLayer knowledge atlas, connecting code commits with narrative summaries for leadership teams.
              </p>
            </div>
          </div>
          <div className="team-showcase">
            <img src={teamImage} alt="DevLayer editorial team collaborating in studio" loading="lazy" />
            <div className="team-cards">
              {teamMembers.map((member) => (
                <motion.article
                  key={member.name}
                  className="team-card"
                  whileHover={{ translateY: -6 }}
                  transition={{ duration: 0.25 }}
                >
                  <h4>{member.name}</h4>
                  <span>{member.role}</span>
                  <p>{member.focus}</p>
                </motion.article>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 8: Editorial Materials & CTA with FAQ */}
      <section className="section editorial-cta">
        <div className="container editorial-grid">
          <div className="editorial-summary">
            <h2>Editorial Materials & Newsletter</h2>
            <p>
              Subscribe to our newsletter for dispatches on developer workflows, platform engineering experiments, and cognitive research shaping the next generation of Canadian software teams.
            </p>
            <form className="newsletter-form" onSubmit={handleNewsletterSubmit}>
              <label htmlFor="newsletter-email">Email</label>
              <input
                id="newsletter-email"
                type="email"
                name="email"
                placeholder="you@company.com"
                value={newsletterEmail}
                onChange={(event) => setNewsletterEmail(event.target.value)}
                required
              />
              <button type="submit" className="btn btn-primary">
                Join the Newsletter
              </button>
              {newsletterStatus && <p className="newsletter-status">{newsletterStatus}</p>}
            </form>
            <div className="cta-footer">
              <Link to="/contact" className="link-arrow">
                Start a workflow study →
              </Link>
            </div>
          </div>
          <div className="faq-panel">
            <h3>Frequently Asked Questions</h3>
            <ul className="faq-list">
              {faqs.map((faq, index) => (
                <li key={faq.question} className={`faq-item ${openFaqIndex === index ? 'faq-item--open' : ''}`}>
                  <button
                    type="button"
                    onClick={() => setOpenFaqIndex((prev) => (prev === index ? -1 : index))}
                    aria-expanded={openFaqIndex === index}
                  >
                    <span>{faq.question}</span>
                    <span className="faq-toggle">{openFaqIndex === index ? '−' : '+'}</span>
                  </button>
                  <div className="faq-answer">
                    <p>{faq.answer}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Section 9: Disclaimer */}
      <section className="section disclaimer">
        <div className="container">
          <p>
            DevLayer content is produced for educational purposes, supporting deliberate practice across engineering organizations. Always evaluate approaches within your regulatory, security, and operational context.
          </p>
        </div>
      </section>
    </motion.div>
  );
};

export default Home;