// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const services = [
  {
    title: 'Workflow Ethnography',
    description:
      'Immersive observation of delivery rituals, pairing, on-call, and incident response to reveal how work travels through your systems.',
    deliverables: ['Narrative workflow map', 'Friction inventory', 'Signal-to-noise report']
  },
  {
    title: 'Platform Narrative Blueprints',
    description:
      'Strategic storytelling that aligns platform roadmaps with product outcomes, supported by diagrams, journey maps, and leadership-ready decks.',
    deliverables: ['Vision document', 'Capability matrix', 'Executive brief']
  },
  {
    title: 'Runbook Experience Design',
    description:
      'Transformation of existing runbooks into clear, accessible guides rooted in cognitive research and operational practice.',
    deliverables: ['Annotated runbooks', 'Incident rehearsal scripts', 'Knowledge sharing kits']
  },
  {
    title: 'Cloud Infrastructure Storyboards',
    description:
      'Detailed visualizations of your cloud estate, illuminating dependencies, governance, and pathways for modernization.',
    deliverables: ['Cloud architecture atlas', 'Risk landscape', 'Migration playbook']
  }
];

const Services = () => {
  return (
    <motion.div
      className="page services-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      <Helmet>
        <title>DevLayer Services</title>
        <meta
          name="description"
          content="DevLayer services cover workflow ethnography, platform narratives, runbook experience design, and cloud infrastructure storyboards."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Editorial Services for Engineering Organizations</h1>
          <p>
            We blend research and storytelling to help engineering leaders see their systems in new ways. Every engagement uncovers insights that drive clarity, alignment, and better technical decisions.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container services-cards">
          {services.map((service) => (
            <motion.article
              key={service.title}
              className="service-detail-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.25 }}
            >
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <h3>Deliverables</h3>
              <ul>
                {service.deliverables.map((deliverable) => (
                  <li key={deliverable}>{deliverable}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section service-cta">
        <div className="container">
          <h2>Partner with DevLayer</h2>
          <p>
            Ready to uncover the narrative inside your workflows? Share your engineering challenges and we will build a research plan together.
          </p>
          <a href="/contact" className="btn btn-primary">
            Start the Conversation
          </a>
        </div>
      </section>
    </motion.div>
  );
};

export default Services;