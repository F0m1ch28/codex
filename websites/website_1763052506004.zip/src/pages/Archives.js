// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const archiveSections = [
  {
    title: 'Workflow Essays 2019–2020',
    description: 'Origins of DevLayer’s exploration into value streams, incident retros, and build pipelines.',
    items: ['Value Stream Diagnostics', 'Incident Choreography 101', 'Async Collaboration Playbook']
  },
  {
    title: 'Cloud Infrastructure Series 2021–2022',
    description: 'Deep dives into cloud modernization within Canadian enterprises, including hybrid strategies.',
    items: ['Cloud Governance Narratives', 'Multi-Region Readiness', 'SRE Patterns for Canadian Banks']
  },
  {
    title: 'Platform Engineering Dispatches 2023–Present',
    description: 'Coverage of platform teams, their operating models, and enabling developer experience.',
    items: ['Platform as Community', 'Internal Developer Portal Field Guide', 'SLO Storytelling']
  }
];

const Archives = () => {
  return (
    <motion.div
      className="page archives-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
    >
      <Helmet>
        <title>Archives — DevLayer</title>
        <meta
          name="description"
          content="Browse the DevLayer archives featuring workflow essays, cloud infrastructure series, and platform engineering dispatches."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Archives</h1>
          <p>
            The DevLayer archive collects years of reporting on software systems, dev culture, and cloud infrastructure across Canada.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container archive-grid">
          {archiveSections.map((section) => (
            <article key={section.title} className="archive-card">
              <h2>{section.title}</h2>
              <p>{section.description}</p>
              <ul>
                {section.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default Archives;