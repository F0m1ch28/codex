// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import teamImage from 'https://picsum.photos/1200/800?random=408';

const About = () => {
  return (
    <motion.div
      className="page about-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      <Helmet>
        <title>About DevLayer</title>
        <meta
          name="description"
          content="Learn about DevLayer, a Canadian editorial platform dedicated to developer workflows, software systems, and cloud infrastructure."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-grid">
          <div>
            <h1>About DevLayer</h1>
            <p>
              We are an editorial studio headquartered in Toronto, Canada. Our mission is to decode the systems, rituals, and human dynamics behind resilient software delivery. DevLayer stories are crafted by researchers and writers steeped in engineering practice.
            </p>
          </div>
          <div className="page-hero-image">
            <img src={teamImage} alt="DevLayer editorial team planning research roadmap" loading="lazy" />
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container section-header">
          <h2>Our Principles</h2>
          <p>
            DevLayer was founded on the belief that layered storytelling can help engineering teams navigate complex transformations. We align observations, data, and narrative craft to surface the signal in your workflow.
          </p>
        </div>
        <div className="container value-grid">
          <article className="value-card">
            <h3>Systems Literacy</h3>
            <p>
              We trace dependencies across application, platform, and cloud layers. That understanding fuels stories that resonate with both operators and strategists.
            </p>
          </article>
          <article className="value-card">
            <h3>Human-Centred Research</h3>
            <p>
              Ethnographic interviews, on-call shadowing, and collaborative retrospectives inform our findings. We listen first, then write.
            </p>
          </article>
          <article className="value-card">
            <h3>Bias Toward Clarity</h3>
            <p>
              Editorial voice matters. We translate complex technical insight into documents leaders can act on without diluting nuance.
            </p>
          </article>
        </div>
      </section>

      <section className="section">
        <div className="container section-header">
          <h2>Editorial Team</h2>
          <p>
            Our interdisciplinary team brings together platform engineers, technical writers, and cognitive scientists. We operate across Canada, partnering with teams in Toronto, Vancouver, Montreal, and beyond.
          </p>
        </div>
        <div className="container about-team-grid">
          <article>
            <h3>Sofia Bennett · Editor-in-Chief</h3>
            <p>
              Sofia leads narrative direction at DevLayer. With a background in platform engineering and investigative journalism, she ensures every story has both rigor and resonance.
            </p>
          </article>
          <article>
            <h3>Amir Khanna · Head of Research</h3>
            <p>
              Amir designs our research protocols—from workflow observation schedules to data instrumentation strategies. He focuses on distributed systems and socio-technical dynamics.
            </p>
          </article>
          <article>
            <h3>Chloe Martin · Senior Narrative Designer</h3>
            <p>
              Chloe translates complex concepts into visual and interactive artifacts. She previously led documentation strategy for a national cloud provider.
            </p>
          </article>
        </div>
      </section>

      <section className="section">
        <div className="container section-header">
          <h2>Our Studio in Toronto</h2>
          <p>
            We work out of 333 Bay St, Toronto, ON M5H 2R2. The studio hosts research sessions, architecture salons, and writing workshops that connect industry practitioners with academic perspectives.
          </p>
        </div>
        <div className="container timeline">
          <div className="timeline-item">
            <span className="timeline-year">2018</span>
            <p>DevLayer launches with a focus on software systems storytelling in Canada.</p>
          </div>
          <div className="timeline-item">
            <span className="timeline-year">2020</span>
            <p>We expand into workflow diagnostics, partnering with remote-first teams navigating distributed operations.</p>
          </div>
          <div className="timeline-item">
            <span className="timeline-year">2022</span>
            <p>Editorial services extend to platform engineering playbooks and incident retrospectives.</p>
          </div>
          <div className="timeline-item">
            <span className="timeline-year">2023</span>
            <p>Launched the Knowledge Atlas, linking repository history with narrative insights.</p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container contact-card">
          <h2>Connect with Us</h2>
          <p>
            Reach out at <a href="mailto:editorial@devlayer.ca">editorial@devlayer.ca</a> or call <a href="tel:+14169056621">+1 (416) 905-6621</a>.
          </p>
          <p>
            We partner with developers, platform engineers, architects, and leadership teams to capture the stories behind their systems.
          </p>
        </div>
      </section>
    </motion.div>
  );
};

export default About;