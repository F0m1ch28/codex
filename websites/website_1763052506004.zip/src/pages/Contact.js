// @ts-check
import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Contact = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '' });
  const [errors, setErrors] = useState({ name: '', email: '', message: '' });

  const validate = () => {
    const nextErrors = { name: '', email: '', message: '' };
    if (!formData.name.trim()) {
      nextErrors.name = 'Tell us who we are speaking with.';
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      nextErrors.email = 'Add a valid email address.';
    }
    if (!formData.message.trim()) {
      nextErrors.message = 'Share a short summary of your request.';
    }
    setErrors(nextErrors);
    return !nextErrors.name && !nextErrors.email && !nextErrors.message;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    navigate(`/contact/thanks?name=${encodeURIComponent(formData.name.trim())}`);
  };

  return (
    <motion.div
      className="page contact-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <Helmet>
        <title>Contact DevLayer</title>
        <meta
          name="description"
          content="Contact DevLayer in Toronto to discuss developer workflow research, platform narratives, and editorial collaborations."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Contact DevLayer</h1>
          <p>
            Share your workflow challenges, platform questions, or editorial ideas. Our team will respond within two business days.
          </p>
        </div>
      </section>

      <section className="section contact-section">
        <div className="container contact-grid">
          <div className="contact-details">
            <h2>Studio</h2>
            <p>
              333 Bay St<br />
              Toronto, ON M5H 2R2<br />
              Canada
            </p>
            <p>
              Phone: <a href="tel:+14169056621">+1 (416) 905-6621</a>
            </p>
            <p>
              Email: <a href="mailto:editorial@devlayer.ca">editorial@devlayer.ca</a>
            </p>
            <p>
              We work primarily in English and collaborate with teams across Canada.
            </p>
          </div>
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-field">
              <label htmlFor="name">Name *</label>
              <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} aria-required="true" />
              {errors.name && <span className="field-error">{errors.name}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="email">Work Email *</label>
              <input id="email" name="email" type="email" value={formData.email} onChange={handleChange} aria-required="true" />
              {errors.email && <span className="field-error">{errors.email}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="company">Company / Team</label>
              <input id="company" name="company" type="text" value={formData.company} onChange={handleChange} />
            </div>
            <div className="form-field">
              <label htmlFor="message">How can we help? *</label>
              <textarea id="message" name="message" rows={6} value={formData.message} onChange={handleChange} aria-required="true" />
              {errors.message && <span className="field-error">{errors.message}</span>}
            </div>
            <button type="submit" className="btn btn-primary">
              Send Message
            </button>
          </form>
        </div>
      </section>
    </motion.div>
  );
};

export default Contact;