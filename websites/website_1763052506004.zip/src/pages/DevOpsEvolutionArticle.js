// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const DevOpsEvolutionArticle = () => {
  return (
    <motion.article
      className="page article-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <Helmet>
        <title>The Evolution of DevOps Culture — DevLayer</title>
        <meta
          name="description"
          content="DevLayer traces the evolution of DevOps culture into modern platform engineering, exploring socio-technical lessons learned."
        />
      </Helmet>

      <header className="article-hero">
        <div className="container article-header">
          <div>
            <h1>The Evolution of DevOps Culture</h1>
            <p className="article-summary">
              DevOps began as a conversation between developers and operators. Today it manifests as platform engineering teams building internal products. Here is how the culture evolved.
            </p>
            <p className="article-meta">By Chloe Martin · November 20, 2023</p>
          </div>
        </div>
      </header>

      <section className="article-section container">
        <h2>From Ops Rooms to SLOs</h2>
        <p>
          Early DevOps stories focused on tearing down silos. By 2015, organizations embraced automation and shared ownership, leading to service level objectives that aligned business outcomes with operational resilience.
        </p>
      </section>

      <section className="article-section container">
        <h2>Platform Teams Emerge</h2>
        <p>
          As cloud complexity grew, teams formed dedicated platform groups. These teams build internal developer portals, integration pipelines, and governance frameworks that allow product squads to move faster without sacrificing reliability.
        </p>
      </section>

      <section className="article-section container">
        <h2>Culture as Infrastructure</h2>
        <p>
          Culture is infrastructure. DevLayer observed engineers treating rituals—post-incident reviews, design crits, planning syncs—as core components of the platform. They enable trust, clarity, and rapid learning.
        </p>
      </section>

      <section className="article-section container">
        <h2>Looking Ahead</h2>
        <p>
          The next chapter is experience engineering: ensuring developers have cohesive journeys across tools, documentation, and support. Platform engineers act as product designers, building experiences that empower others to ship confidently.
        </p>
      </section>
    </motion.article>
  );
};

export default DevOpsEvolutionArticle;