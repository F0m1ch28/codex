// @ts-check
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const notes = [
  {
    title: 'The Lens of Degenerative Debt',
    body: 'Debt is more than code—it’s knowledge, process, and infrastructure debt. Treat each as a separate thread with its own remediation strategy.'
  },
  {
    title: 'Incident Storytelling',
    body: 'When describing incidents, capture not only what failed but which signals engineers trusted, ignored, or missed entirely.'
  },
  {
    title: 'Platform as Product',
    body: 'Platform teams require product thinking: customer discovery interviews, feedback loops, and launch narratives.'
  },
  {
    title: 'Context Handshake',
    body: 'Shift handoffs from artifacts to conversations. A five-minute story beats a twenty-screen dashboard in transmitting intent.'
  }
];

const Notes = () => {
  return (
    <motion.div
      className="page notes-page"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <Helmet>
        <title>Notes — DevLayer</title>
        <meta
          name="description"
          content="Quick notes from the DevLayer editorial studio on platform engineering, workflows, and systems thinking."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container page-hero-content">
          <h1>Notes</h1>
          <p>
            Short reflections from our notebooks. Each note comes from field research, interviews, or long-form investigations currently underway.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container notes-grid">
          {notes.map((note) => (
            <motion.article
              key={note.title}
              className="note-card"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5 }}
            >
              <h2>{note.title}</h2>
              <p>{note.body}</p>
            </motion.article>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default Notes;