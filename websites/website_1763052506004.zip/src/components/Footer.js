// @ts-check
import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <h3 className="footer-heading">DevLayer</h3>
          <p className="footer-text">
            Canadian editorial platform distilling the craft of developer workflows, software systems, and cloud infrastructure.
          </p>
          <address className="footer-address">
            333 Bay St<br />
            Toronto, ON M5H 2R2<br />
            Canada
          </address>
          <a className="footer-contact" href="tel:+14169056621">+1 (416) 905-6621</a>
        </div>
        <div>
          <h4 className="footer-subheading">Navigate</h4>
          <ul className="footer-list">
            <li><NavLink to="/workflows">Workflows</NavLink></li>
            <li><NavLink to="/mindset">Developer Mindset</NavLink></li>
            <li><NavLink to="/notes">Notes</NavLink></li>
            <li><NavLink to="/queue">Reading Queue</NavLink></li>
            <li><NavLink to="/archives">Archives</NavLink></li>
          </ul>
        </div>
        <div>
          <h4 className="footer-subheading">Resources</h4>
          <ul className="footer-list">
            <li><NavLink to="/services">Editorial Services</NavLink></li>
            <li><NavLink to="/blog">Latest Essays</NavLink></li>
            <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
            <li><NavLink to="/terms">Terms of Service</NavLink></li>
            <li><a href="mailto:editorial@devlayer.ca">editorial@devlayer.ca</a></li>
          </ul>
        </div>
      </div>
      <div className="footer-meta">
        <p>© {new Date().getFullYear()} DevLayer. Crafted in Toronto for engineering leaders across Canada.</p>
      </div>
    </footer>
  );
};

export default Footer;