// @ts-check
import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('devlayer_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = () => {
    window.localStorage.setItem('devlayer_cookie_consent', 'granted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie notice">
      <p>
        DevLayer uses essential cookies for analytics and to refine our editorial experience. By continuing, you acknowledge this usage.
      </p>
      <button type="button" className="btn btn-primary" onClick={handleConsent}>
        Acknowledge
      </button>
    </div>
  );
};

export default CookieBanner;