(function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAccept = document.querySelector(".cookie-banner .accept");
    const cookieDecline = document.querySelector(".cookie-banner .decline");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", function () {
            navLinks.classList.toggle("open");
        });
    }

    function setCookiePreference(status) {
        try {
            localStorage.setItem("knickebczi_cookie_preference", status);
        } catch (error) {
            document.cookie = "knickebczi_cookie_preference=" + status + ";path=/;max-age=31536000";
        }
    }

    function getCookiePreference() {
        try {
            return localStorage.getItem("knickebczi_cookie_preference");
        } catch (error) {
            const match = document.cookie.match(/(?:^| )knickebczi_cookie_preference=([^;]+)/);
            return match ? match[1] : null;
        }
    }

    if (cookieBanner) {
        const storedPreference = getCookiePreference();
        if (!storedPreference) {
            cookieBanner.classList.add("active");
        }

        if (cookieAccept) {
            cookieAccept.addEventListener("click", function () {
                setCookiePreference("accepted");
            });
        }

        if (cookieDecline) {
            cookieDecline.addEventListener("click", function () {
                setCookiePreference("declined");
            });
        }
    }
})();