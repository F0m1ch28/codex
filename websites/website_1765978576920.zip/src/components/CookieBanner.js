import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const COOKIE_KEY = 'rrh_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => {
        setVisible(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
      <div className="cookie-banner__content">
        <p>
          Utilizamos cookies para comprender mejor tus necesidades y ofrecerte recomendaciones personalizadas.
          Consulta nuestra <Link to="/cookie-policy">Política de Cookies</Link> para más detalles.
        </p>
      </div>
      <div className="cookie-banner__actions">
        <button type="button" className="btn btn--primary" onClick={handleAccept}>
          Aceptar
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;