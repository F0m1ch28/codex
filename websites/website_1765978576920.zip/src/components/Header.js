import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  const navItems = [
    { to: '/', label: 'Inicio' },
    { to: '/guide', label: 'Guías' },
    { to: '/programs', label: 'Programas' },
    { to: '/tools', label: 'Herramientas' },
    { to: '/blog', label: 'Blog' },
    { to: '/about', label: 'Nosotros' },
    { to: '/contact', label: 'Contacto' },
    { to: '/legal', label: 'Aviso Legal' },
    { to: '/terms', label: 'Términos' },
    { to: '/cookie-policy', label: 'Política de Cookies' }
  ];

  return (
    <header className="site-header" role="banner">
      <div className="site-header__inner">
        <Link to="/" className="site-header__brand" onClick={closeMenu}>
          <div className="site-header__logo" aria-hidden="true">
            RR
          </div>
          <span className="site-header__name">Ramilo Raventura Homes</span>
        </Link>

        <button
          type="button"
          className={`site-header__toggle ${menuOpen ? 'is-active' : ''}`}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="navegacion-principal"
          aria-label="Abrir o cerrar menú de navegación"
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          id="navegacion-principal"
          className={`site-header__nav ${menuOpen ? 'is-open' : ''}`}
          aria-label="Navegación principal"
        >
          <ul className="site-header__list">
            {navItems.map((item) => (
              <li key={item.to} className="site-header__item">
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `site-header__link ${isActive ? 'is-active' : ''}`
                  }
                  onClick={closeMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;