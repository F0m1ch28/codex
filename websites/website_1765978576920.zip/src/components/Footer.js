import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="footer" role="contentinfo">
    <div className="footer__inner">
      <div className="footer__brand">
        <div className="footer__logo" aria-hidden="true">
          RR
        </div>
        <p>
          Ramilo Raventura Homes potencia cada hogar en México con soluciones integrales de eficiencia,
          bienestar y diseño consciente.
        </p>
      </div>

      <div className="footer__columns">
        <div className="footer__column">
          <h3>Contacto</h3>
          <address>
            Av. Paseo de la Reforma 505<br />
            Cuauhtémoc, 06500 Ciudad de México, CDMX, México
          </address>
          <a href="tel:+525512345678" className="footer__link">
            +52 55 1234 5678
          </a>
          <a href="mailto:hola@ramiloraventura.site" className="footer__link">
            hola@ramiloraventura.site
          </a>
        </div>

        <div className="footer__column">
          <h3>Explora</h3>
          <Link to="/guide" className="footer__link">
            Guías
          </Link>
          <Link to="/programs" className="footer__link">
            Programas
          </Link>
          <Link to="/tools" className="footer__link">
            Herramientas
          </Link>
          <Link to="/blog" className="footer__link">
            Blog
          </Link>
        </div>

        <div className="footer__column">
          <h3>Compañía</h3>
          <Link to="/about" className="footer__link">
            Nosotros
          </Link>
          <Link to="/contact" className="footer__link">
            Contacto
          </Link>
          <Link to="/legal" className="footer__link">
            Aviso Legal
          </Link>
          <Link to="/terms" className="footer__link">
            Términos
          </Link>
          <Link to="/cookie-policy" className="footer__link">
            Política de Cookies
          </Link>
        </div>
      </div>

      <div className="footer__bottom">
        <p>© {new Date().getFullYear()} Ramilo Raventura Homes. Todos los derechos reservados.</p>
        <div className="footer__social" aria-label="Redes sociales">
          <a href="https://www.facebook.com" aria-label="Facebook Ramilo Raventura Homes" className="footer__social-link">
            <svg width="20" height="20" viewBox="0 0 24 24" role="img" aria-hidden="true">
              <path
                fill="currentColor"
                d="M22 12.06C22 6.51 17.52 2 12 2S2 6.51 2 12.06c0 5 3.66 9.14 8.44 9.94v-7.03H7.9v-2.91h2.54V9.84c0-2.5 1.5-3.89 3.78-3.89 1.1 0 2.24.2 2.24.2v2.47h-1.26c-1.24 0-1.63.77-1.63 1.56v1.87h2.78l-.44 2.91h-2.34v7.03C18.34 21.2 22 17.06 22 12.06Z"
              />
            </svg>
          </a>
          <a href="https://www.instagram.com" aria-label="Instagram Ramilo Raventura Homes" className="footer__social-link">
            <svg width="20" height="20" viewBox="0 0 24 24" role="img" aria-hidden="true">
              <path
                fill="currentColor"
                d="M7 2C4.24 2 2 4.24 2 7v10c0 2.76 2.24 5 5 5h10c2.76 0 5-2.24 5-5V7c0-2.76-2.24-5-5-5H7Zm12 2c1.66 0 3 1.34 3 3v10c0 1.66-1.34 3-3 3H7c-1.66 0-3-1.34-3-3V7c0-1.66 1.34-3 3-3h12Zm-6 3.3A5.7 5.7 0 0 0 7.3 13c0 3.15 2.55 5.7 5.7 5.7 3.15 0 5.7-2.55 5.7-5.7 0-3.15-2.55-5.7-5.7-5.7Zm0 2a3.7 3.7 0 0 1 3.7 3.7 3.7 3.7 0 0 1-3.7 3.7 3.7 3.7 0 0 1-3.7-3.7 3.7 3.7 0 0 1 3.7-3.7Zm5.95-2.85a1.05 1.05 0 1 0 0 2.1 1.05 1.05 0 0 0 0-2.1Z"
              />
            </svg>
          </a>
          <a href="https://www.linkedin.com" aria-label="LinkedIn Ramilo Raventura Homes" className="footer__social-link">
            <svg width="20" height="20" viewBox="0 0 24 24" role="img" aria-hidden="true">
              <path
                fill="currentColor"
                d="M20.45 20.45h-3.56v-5.3c0-1.26-.02-2.89-1.76-2.89-1.77 0-2.04 1.38-2.04 2.8v5.39H9.53V9h3.42v1.56h.05c.48-.9 1.67-1.85 3.44-1.85 3.67 0 4.35 2.42 4.35 5.56v6.19ZM5.34 7.43a2.07 2.07 0 1 1 0-4.14 2.07 2.07 0 0 1 0 4.14Zm1.79 13.02H3.55V9h3.58v11.45Z"
              />
            </svg>
          </a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;