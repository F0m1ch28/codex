import React, { useEffect } from 'react';

const Services = () => {
  useEffect(() => {
    document.title = 'Programas de Transformación | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Explora los programas especializados de Ramilo Raventura Homes para optimizar la eficiencia y el confort de tu hogar.'
      );
    }
  }, []);

  const programs = [
    {
      name: 'Programa Esencial 360°',
      duration: '8 semanas',
      description:
        'Diagnóstico integral, plan maestro por zonas de la casa y acompañamiento para implementar mejoras energéticas, de organización y bienestar.',
      outcomes: ['Mapa de consumo detallado', 'Rutas semanales de orden', 'Monitoreo remoto quincenal']
    },
    {
      name: 'Programa Ritmo Vital',
      duration: '6 semanas',
      description:
        'Transforma dormitorios, baños y áreas de descanso con biofilia, aromaterapia y automatización ligera que acompaña tus ciclos.',
      outcomes: ['Análisis circadiano', 'Diseño multisensorial', 'Implementación de rutinas guiadas']
    },
    {
      name: 'Programa Seguridad Serenidad',
      duration: '5 semanas',
      description:
        'Instalación planificada de sistemas inteligentes de seguridad, control de accesos y monitoreo colaborativo con la familia.',
      outcomes: ['Auditoría de puntos críticos', 'Protocolos personalizados', 'Capacitación integral']
    },
    {
      name: 'Programa Vida en Movimiento',
      duration: '10 semanas',
      description:
        'Reorganiza espacios de trabajo, juego y ejercicio con soluciones modulares, iluminación dinámica y almacenamiento fluido.',
      outcomes: ['Estudio ergonómico', 'Zonificación flexible', 'Plan de mantenimiento anual']
    }
  ];

  const process = [
    {
      title: 'Descubrimiento profundo',
      detail:
        'Entrevistas, recorridos virtuales y análisis de hábitos que revelan oportunidades claras de mejora.'
    },
    {
      title: 'Co-diseño y simulaciones',
      detail:
        'Prototipamos soluciones con renders, moodboards y pruebas piloto para garantizar la adopción sin fricciones.'
    },
    {
      title: 'Implementación acompañada',
      detail:
        'Coordinamos proveedores, supervisamos instalaciones y ajustamos en tiempo real hasta lograr el resultado deseado.'
    },
    {
      title: 'Seguimiento continuo',
      detail:
        'Medimos indicadores, detectamos nuevas necesidades y ofrecemos soporte para evolucionar junto contigo.'
    }
  ];

  return (
    <div className="page services-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Programas</p>
        <h1 className="page-hero__title">Rutas integrales para reinventar tu hogar</h1>
        <p className="page-hero__subtitle">
          Diseñamos programas flexibles que alinean eficiencia, estética y bienestar.
          Cada proceso se construye contigo, priorizando resultados sostenibles y medibles.
        </p>
      </header>

      <section className="section">
        <div className="program-grid">
          {programs.map((program) => (
            <article key={program.name} className="program-card">
              <div className="program-card__header">
                <h2>{program.name}</h2>
                <span className="program-card__duration">{program.duration}</span>
              </div>
              <p>{program.description}</p>
              <ul>
                {program.outcomes.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="section__header">
          <h2 className="section__title">Nuestro proceso colaborativo</h2>
        </div>
        <div className="process-grid">
          {process.map((step, index) => (
            <article key={step.title} className="process-card">
              <span className="process-card__step">{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.detail}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Services;