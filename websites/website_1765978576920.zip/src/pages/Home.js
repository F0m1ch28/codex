import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  useEffect(() => {
    document.title = 'Ramilo Raventura Homes | Eficiencia y confort para tu hogar';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Ramilo Raventura Homes ofrece soluciones integrales en México para optimizar la eficiencia y el bienestar de cada hogar.'
      );
    }
  }, []);

  const highlights = [
    {
      title: 'Eficiencia inteligente',
      description: 'Mapeamos tu consumo real y activamos estrategias de ahorro que respetan tus rutinas.',
      icon: '🌱'
    },
    {
      title: 'Bienestar multisensorial',
      description: 'Definimos atmósferas de luz, temperatura y aromas que abrazan cada momento del día.',
      icon: '🛋️'
    },
    {
      title: 'Diseño sin fricciones',
      description: 'Simplificamos procesos domésticos para que cada actividad sea fluida, segura y placentera.',
      icon: '🧭'
    }
  ];

  const services = [
    {
      title: 'Reconversión energética total',
      description:
        'Auditoría térmica, rediseño de iluminación y automatización de consumo con planes escalonados por sectores de la casa.',
      image:
        'https://images.unsplash.com/photo-1565538810643-b5bdb714032a?auto=format&fit=crop&w=1200&q=80'
    },
    {
      title: 'Wellness residencial',
      description:
        'Plan maestro para integrar ventilación, biofilia y dinámica espacial que promueven descanso y productividad equilibrada.',
      image:
        'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1200&q=80'
    },
    {
      title: 'Automatización cotidiana',
      description:
        'Configuramos escenarios inteligentes para iluminación, persianas, sonido y seguridad adaptados a cada momento.',
      image:
        'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80'
    }
  ];

  const guides = [
    {
      title: 'Checklist de eficiencia antes de la temporada de lluvias',
      category: 'Guías',
      link: '/guide'
    },
    {
      title: 'Cómo crear un dormitorio que recupera energía',
      category: 'Wellness',
      link: '/guide'
    },
    {
      title: 'Plan de transición a domótica confiable en 6 semanas',
      category: 'Automatización',
      link: '/programs'
    }
  ];

  const testimonials = [
    {
      quote:
        'Nuestro departamento dejó de sentirse saturado. Hoy cada espacio tiene una intención clara y respiramos mejor.',
      name: 'Fernanda y Luis',
      location: 'Guadalajara, Jalisco'
    },
    {
      quote:
        'El consumo eléctrico bajó y, al mismo tiempo, la casa es más cómoda. Las rutinas automatizadas nos devolvieron horas libres.',
      name: 'María Teresa',
      location: 'Mérida, Yucatán'
    },
    {
      quote:
        'El equipo entendió nuestras tradiciones familiares y las potenció con tecnología flexible. La casa se siente viva.',
      name: 'Familia Ríos',
      location: 'Querétaro, Querétaro'
    }
  ];

  const blogPreview = [
    {
      title: 'Hogares que se adaptan a tu ritmo biológico',
      link: '/blog',
      tag: 'Bienestar'
    },
    {
      title: 'Los cinco sensores que marcan la diferencia en 2024',
      link: '/blog',
      tag: 'Innovación'
    },
    {
      title: 'Decoración cálida con materiales responsables',
      link: '/blog',
      tag: 'Diseño'
    }
  ];

  return (
    <div className="page home-page">
      <section
        className="hero"
        role="region"
        aria-label="Introducción Ramilo Raventura Homes"
        style={{
          backgroundImage:
            'linear-gradient(120deg, rgba(33, 49, 39, 0.75), rgba(33, 49, 39, 0.35)), url(https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=1600&q=80)'
        }}
      >
        <div className="hero__content">
          <span className="hero__kicker">Hogares que vibra con tu ritmo</span>
          <h1 className="hero__title">
            Diseñamos experiencias domésticas que equilibran energía, bienestar y calidez
          </h1>
          <p className="hero__text">
            Desde la Ciudad de México, acompañamos a familias y profesionales en todo el país para convertir su hogar
            en un ecosistema consciente: eficiente, saludable y profundamente personal.
          </p>
          <div className="hero__actions">
            <Link to="/contact" className="btn btn--primary">
              Agenda una sesión de descubrimiento
            </Link>
            <Link to="/programs" className="btn btn--outline">
              Conoce nuestros programas
            </Link>
          </div>
        </div>
      </section>

      <section className="section metrics">
        <div className="metrics__grid">
          <div className="metric">
            <strong>+450</strong>
            <span>Intervenciones domésticas completadas en México</span>
          </div>
          <div className="metric">
            <strong>87%</strong>
            <span>Reducción promedio en tareas repetitivas del hogar</span>
          </div>
          <div className="metric">
            <strong>4.9/5</strong>
            <span>Valoración de satisfacción de clientes Ramilo Raventura</span>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section__header">
          <h2 className="section__title">Tres pilares que guían cada proyecto</h2>
          <p className="section__subtitle">
            Diagnosticamos, rediseñamos y acompañamos la implementación para que tu casa fluya día y noche.
          </p>
        </div>
        <div className="cards-grid">
          {highlights.map((item) => (
            <article key={item.title} className="highlight-card">
              <div className="highlight-card__icon" aria-hidden="true">
                {item.icon}
              </div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="section__header">
          <h2 className="section__title">Servicios más elegidos</h2>
          <p className="section__subtitle">
            Programas hechos a medida que combinan consultoría, instalación y acompañamiento continuo.
          </p>
        </div>
        <div className="cards-grid cards-grid--services">
          {services.map((service) => (
            <article key={service.title} className="service-card">
              <div
                className="service-card__media"
                style={{ backgroundImage: `url(${service.image})` }}
                aria-hidden="true"
              />
              <div className="service-card__body">
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/programs" className="btn btn--ghost">
                  Descubrir programa
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section__header">
          <h2 className="section__title">Guías recomendadas para comenzar hoy</h2>
          <p className="section__subtitle">
            Seleccionamos recursos que te permiten dar los primeros pasos antes de un acompañamiento personalizado.
          </p>
        </div>
        <div className="guide-grid">
          {guides.map((guide) => (
            <article key={guide.title} className="guide-preview">
              <span className="guide-preview__tag">{guide.category}</span>
              <h3>{guide.title}</h3>
              <Link to={guide.link} className="guide-preview__link">
                Leer ahora
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="section__header">
          <h2 className="section__title">Lo que dicen quienes viven la transformación</h2>
          <p className="section__subtitle">
            Historias reales que demuestran cómo un hogar inteligente puede ser cálido, humano y eficiente.
          </p>
        </div>
        <div className="testimonial-grid">
          {testimonials.map((item) => (
            <blockquote key={item.name} className="testimonial-card">
              <p>“{item.quote}”</p>
              <footer>
                <strong>{item.name}</strong>
                <span>{item.location}</span>
              </footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section__header">
          <h2 className="section__title">Ideas frescas desde nuestro blog</h2>
          <p className="section__subtitle">
            Artículos elaborados por especialistas en confort y eficiencia para inspirarte cada semana.
          </p>
        </div>
        <div className="blog-preview-grid">
          {blogPreview.map((post) => (
            <article key={post.title} className="blog-preview">
              <span className="blog-preview__tag">{post.tag}</span>
              <h3>{post.title}</h3>
              <Link to={post.link} className="blog-preview__link">
                Ver artículo
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="section cta-section">
        <div className="cta-banner">
          <div>
            <h2>Co-creemos el plan perfecto para tu hogar</h2>
            <p>
              Agenda una reunión virtual con nuestro equipo de estrategia doméstica y recibe un mapa de acción personalizado.
            </p>
          </div>
          <Link to="/contact" className="btn btn--primary">
            Agendar reunión
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;