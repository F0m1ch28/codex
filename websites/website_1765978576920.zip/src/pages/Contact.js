import React, { useEffect, useState } from 'react';

const initialFormState = {
  nombre: '',
  email: '',
  asunto: '',
  mensaje: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  useEffect(() => {
    document.title = 'Contacto | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Comunícate con Ramilo Raventura Homes para descubrir cómo transformar la eficiencia y el confort de tu hogar.'
      );
    }
  }, []);

  const validate = () => {
    const newErrors = {};
    if (!form.nombre.trim()) {
      newErrors.nombre = 'Por favor ingresa tu nombre.';
    }
    if (!form.email.trim()) {
      newErrors.email = 'Por favor ingresa tu correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'El correo electrónico no es válido.';
    }
    if (!form.asunto.trim()) {
      newErrors.asunto = 'Indica el motivo de tu mensaje.';
    }
    if (!form.mensaje.trim()) {
      newErrors.mensaje = 'Cuéntanos cómo podemos ayudarte.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    setForm((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
    setErrors((prev) => ({
      ...prev,
      [event.target.name]: ''
    }));
    setStatus('');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus('');
      return;
    }
    setForm(initialFormState);
    setErrors({});
    setStatus('¡Gracias! Hemos recibido tu mensaje y te contactaremos muy pronto.');
  };

  return (
    <div className="page contact-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Contacto</p>
        <h1 className="page-hero__title">Diseñemos juntos la próxima versión de tu hogar</h1>
        <p className="page-hero__subtitle">
          Completa el formulario o llámanos para agendar una conversación inicial. Estamos listos para escuchar tus ideas y retos.
        </p>
      </header>

      <section className="section">
        <div className="contact__grid">
          <div className="contact__info">
            <h2>Estamos a una llamada de distancia</h2>
            <p>
              Av. Paseo de la Reforma 505,
              Cuauhtémoc, 06500 Ciudad de México, CDMX, México
            </p>
            <a href="tel:+525512345678" className="contact__link">
              +52 55 1234 5678
            </a>
            <a href="mailto:hola@ramiloraventura.site" className="contact__link">
              hola@ramiloraventura.site
            </a>
            <p>
              Horario de atención: lunes a viernes de 9:00 a 18:30 hrs.
            </p>
          </div>

          <form className="contact__form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="nombre">Nombre</label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={form.nombre}
                onChange={handleChange}
                aria-invalid={Boolean(errors.nombre)}
                aria-describedby={errors.nombre ? 'error-nombre' : undefined}
              />
              {errors.nombre && (
                <span id="error-nombre" className="error-message">
                  {errors.nombre}
                </span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="email">Correo Electrónico</label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'error-email' : undefined}
              />
              {errors.email && (
                <span id="error-email" className="error-message">
                  {errors.email}
                </span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="asunto">Asunto</label>
              <input
                id="asunto"
                name="asunto"
                type="text"
                value={form.asunto}
                onChange={handleChange}
                aria-invalid={Boolean(errors.asunto)}
                aria-describedby={errors.asunto ? 'error-asunto' : undefined}
              />
              {errors.asunto && (
                <span id="error-asunto" className="error-message">
                  {errors.asunto}
                </span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="mensaje">Mensaje</label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows="5"
                value={form.mensaje}
                onChange={handleChange}
                aria-invalid={Boolean(errors.mensaje)}
                aria-describedby={errors.mensaje ? 'error-mensaje' : undefined}
              />
              {errors.mensaje && (
                <span id="error-mensaje" className="error-message">
                  {errors.mensaje}
                </span>
              )}
            </div>

            <button type="submit" className="btn btn--primary">
              Enviar
            </button>

            {status && (
              <p className="success-message" role="status" aria-live="polite">
                {status}
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;