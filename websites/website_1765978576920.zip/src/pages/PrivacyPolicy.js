import React, { useEffect } from 'react';

const PrivacyPolicy = () => {
  useEffect(() => {
    document.title = 'Aviso Legal y Privacidad | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Revisa el aviso legal y políticas de privacidad de Ramilo Raventura Homes, responsables del sitio ramiloraventura.site.'
      );
    }
  }, []);

  return (
    <div className="page legal-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Aviso Legal</p>
        <h1 className="page-hero__title">Responsabilidad y protección de datos</h1>
        <p className="page-hero__subtitle">
          En Ramilo Raventura Homes protegemos tu información y aseguramos un uso responsable de nuestros contenidos digitales.
        </p>
      </header>

      <section className="section">
        <h2>1. Responsable</h2>
        <p>
          Ramilo Raventura Homes S.A. de C.V., con domicilio en Av. Paseo de la Reforma 505, Cuauhtémoc,
          06500 Ciudad de México, CDMX, México, es responsable del tratamiento de los datos personales que recopilamos en este sitio.
        </p>

        <h2>2. Finalidades del tratamiento</h2>
        <p>
          La información proporcionada se utiliza para atender consultas, ofrecer recursos personalizados, enviar comunicaciones
          informativas y mejorar nuestra plataforma. Nunca compartimos datos con terceros sin tu consentimiento expreso.
        </p>

        <h2>3. Derechos ARCO</h2>
        <p>
          Puedes ejercer los derechos de acceso, rectificación, cancelación y oposición enviando un correo a
          <a href="mailto:hola@ramiloraventura.site"> hola@ramiloraventura.site</a>. Responderemos en un plazo máximo de 10 días hábiles.
        </p>

        <h2>4. Seguridad de la información</h2>
        <p>
          Implementamos prácticas de cifrado y monitoreo constante para salvaguardar los datos. Actualizamos nuestros protocolos
          según estándares nacionales e internacionales de protección.
        </p>

        <h2>5. Enlaces externos</h2>
        <p>
          Nuestro sitio puede incluir enlaces a recursos de terceros. No somos responsables del contenido o políticas de esos sitios,
          por lo que te recomendamos revisar sus términos antes de compartir información.
        </p>

        <h2>6. Cambios al aviso</h2>
        <p>
          Podremos modificar este aviso para reflejar mejoras en nuestra gestión de datos. La fecha de la última actualización se mostrará
          en la parte inferior. Tu uso continuado del sitio implica la aceptación de cualquier modificación.
        </p>

        <p className="legal-update">Última actualización: 15 de junio de 2024.</p>
      </section>
    </div>
  );
};

export default PrivacyPolicy;