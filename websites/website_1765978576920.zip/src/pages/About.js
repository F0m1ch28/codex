import React, { useEffect } from 'react';

const About = () => {
  useEffect(() => {
    document.title = 'Nosotros | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Conoce la historia, misión y equipo detrás de Ramilo Raventura Homes, especialistas en confort y eficiencia doméstica en México.'
      );
    }
  }, []);

  const values = [
    {
      title: 'Humanizar la tecnología',
      description:
        'Seleccionamos herramientas inteligentes que respetan los ritmos familiares y celebran las tradiciones mexicanas.'
    },
    {
      title: 'Diseño consciente',
      description:
        'Cada proyecto parte de la identidad de quienes habitan el espacio, con soluciones funcionales y estéticas.'
    },
    {
      title: 'Aprendizaje continuo',
      description:
        'Medimos resultados, escuchamos retroalimentaciones y refinamos procesos para crear experiencias memorables.'
    }
  ];

  const timeline = [
    {
      year: '2012',
      title: 'Los primeros talleres caseros',
      description:
        'Ayudamos a vecinas y amigos a reorganizar sus casas después de reformas. Nació la idea de un acompañamiento integral.'
    },
    {
      year: '2016',
      title: 'Fundación oficial',
      description:
        'Ramilo Raventura Homes abre oficinas en la Ciudad de México y conforma un equipo multidisciplinario de arquitectos, ingenieros y diseñadores.'
    },
    {
      year: '2020',
      title: 'Expansión nacional',
      description:
        'Implementamos metodologías híbridas que permiten intervenir hogares en todo México combinando visitas y herramientas remotas.'
    },
    {
      year: '2023',
      title: 'Laboratorio de bienestar',
      description:
        'Creamos un centro de experimentación donde probamos tecnologías emergentes y materiales sostenibles con familias voluntarias.'
    }
  ];

  const team = [
    {
      name: 'Jimena Ramírez',
      role: 'Directora de Experiencia Doméstica',
      image:
        'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=800&q=80'
    },
    {
      name: 'Leonardo Ventura',
      role: 'Arquitecto de eficiencia energética',
      image:
        'https://images.unsplash.com/photo-1541233349642-6e425fe6190e?auto=format&fit=crop&w=800&q=80'
    },
    {
      name: 'Claudia Núñez',
      role: 'Líder de automatización y datos',
      image:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=80'
    },
    {
      name: 'Rafael Hernández',
      role: 'Coordinador de bienestar y hábitos',
      image:
        'https://images.unsplash.com/photo-1544723795-432537f7060d?auto=format&fit=crop&w=800&q=80'
    }
  ];

  return (
    <div className="page about-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Nuestro equipo</p>
        <h1 className="page-hero__title">Historias auténticas que inspiran hogares conectados</h1>
        <p className="page-hero__subtitle">
          Somos estrategas domésticos que combinan arquitectura, neurociencia, diseño de servicios y tecnología accesible.
          Nuestra misión es crear casas que cuidan a las personas y al planeta.
        </p>
      </header>

      <section className="section">
        <div className="section__header">
          <h2 className="section__title">Valores que guían nuestra labor</h2>
        </div>
        <div className="cards-grid">
          {values.map((value) => (
            <article key={value.title} className="value-card">
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="section__header">
          <h2 className="section__title">Nuestra evolución</h2>
          <p className="section__subtitle">
            Cada etapa ha reforzado nuestro compromiso con hogares mexicanos que abrazan el cambio sin perder su esencia.
          </p>
        </div>
        <div className="timeline">
          {timeline.map((item) => (
            <div key={item.year} className="timeline__item">
              <div className="timeline__year">{item.year}</div>
              <div className="timeline__content">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section__header">
          <h2 className="section__title">Personas detrás de cada proyecto</h2>
        </div>
        <div className="team-grid">
          {team.map((member) => (
            <article key={member.name} className="team-card">
              <div
                className="team-card__media"
                style={{ backgroundImage: `url(${member.image})` }}
                aria-hidden="true"
              />
              <div className="team-card__body">
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default About;