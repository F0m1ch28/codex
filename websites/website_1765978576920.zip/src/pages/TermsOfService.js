import React, { useEffect } from 'react';

const TermsOfService = () => {
  useEffect(() => {
    document.title = 'Términos de Servicio | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Consulta los términos de servicio de Ramilo Raventura Homes para el uso del sitio web y nuestras soluciones domésticas.'
      );
    }
  }, []);

  return (
    <div className="page legal-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Términos de Servicio</p>
        <h1 className="page-hero__title">Condiciones para utilizar nuestros recursos</h1>
        <p className="page-hero__subtitle">
          Este documento describe las reglas que rigen el acceso y uso del sitio web ramiloraventura.site,
          así como los servicios virtuales que ofrecemos.
        </p>
      </header>

      <section className="section">
        <h2>1. Aceptación de los términos</h2>
        <p>
          Al acceder a este sitio confirmas que has leído, entendido y aceptado las presentes condiciones. Si no estás de acuerdo,
          te invitamos a abstenerte de utilizar nuestros contenidos o servicios en línea.
        </p>

        <h2>2. Uso permitido</h2>
        <p>
          El material disponible tiene fines informativos y de acompañamiento. No está permitido copiar, redistribuir o utilizar
          nuestros contenidos con fines comerciales sin autorización escrita de Ramilo Raventura Homes.
        </p>

        <h2>3. Información proporcionada por usuarios</h2>
        <p>
          Cualquier información enviada a través de nuestros formularios debe ser veraz. Nos reservamos el derecho de suspender
          el acceso a quienes utilicen datos falsos o intenten interferir con la operación del sitio.
        </p>

        <h2>4. Propiedad intelectual</h2>
        <p>
          Todos los textos, imágenes, diagramas y recursos descargables son propiedad de Ramilo Raventura Homes,
          a menos que se indique lo contrario. Su reproducción requiere autorización previa.
        </p>

        <h2>5. Modificaciones</h2>
        <p>
          Podemos actualizar estos términos para reflejar cambios normativos o ajustes en nuestros servicios. Publicaremos
          la versión vigente con fecha de actualización. Te recomendamos revisarlos periódicamente.
        </p>

        <h2>6. Contacto legal</h2>
        <p>
          Para aclaraciones sobre estos términos escríbenos a <a href="mailto:hola@ramiloraventura.site">hola@ramiloraventura.site</a>.
        </p>
      </section>
    </div>
  );
};

export default TermsOfService;