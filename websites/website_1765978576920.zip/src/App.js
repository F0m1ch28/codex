import React, { useEffect } from 'react';
import { Routes, Route, useLocation, Link } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';

const GuidePage = () => {
  useEffect(() => {
    document.title = 'Guías Esenciales | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Explora guías completas de Ramilo Raventura Homes para mejorar la eficiencia, seguridad y confort de tu hogar en México.'
      );
    }
  }, []);

  const categories = [
    {
      title: 'Eficiencia Energética',
      description:
        'Pasos prácticos para reducir el consumo de energía sin sacrificar el confort, incluyendo recomendaciones de iluminación inteligente y aislamiento térmico.',
      image:
        'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1200&q=80',
      link: '/guide'
    },
    {
      title: 'Bienestar y Salud en Casa',
      description:
        'Transforma tus espacios en refugios saludables con ventilación adecuada, selección de materiales y rutinas de mantenimiento.',
      image:
        'https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80',
      link: '/guide'
    },
    {
      title: 'Seguridad Inteligente',
      description:
        'Configura sistemas de monitoreo, controla accesos y automatiza alertas para proteger a tu familia con soluciones accesibles.',
      image:
        'https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&w=1200&q=80',
      link: '/guide'
    }
  ];

  return (
    <div className="page guide-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Guías prácticas</p>
        <h1 className="page-hero__title">Recetarios de confort para cada hogar mexicano</h1>
        <p className="page-hero__subtitle">
          Profundiza en estrategias concretas para elevar el rendimiento de tu casa, desde proyectos rápidos
          hasta transformaciones profundas planificadas paso a paso.
        </p>
      </header>

      <section className="section">
        <div className="section__header">
          <h2 className="section__title">Categorías destacadas</h2>
          <p className="section__subtitle">
            Explora nuestras guías ilustradas, con listas de verificación descargables y recomendaciones de herramientas.
          </p>
        </div>
        <div className="cards-grid">
          {categories.map((category) => (
            <article key={category.title} className="guide-card">
              <div
                className="guide-card__media"
                style={{ backgroundImage: `url(${category.image})` }}
                aria-hidden="true"
              />
              <div className="guide-card__body">
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <Link to={category.link} className="btn btn--ghost">
                  Leer guía
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="section__header">
          <h2 className="section__title">Formatos disponibles</h2>
          <p className="section__subtitle">
            Te acompañamos con múltiples formatos para que avances a tu ritmo y según tu estilo de aprendizaje.
          </p>
        </div>
        <div className="benefits-grid">
          <div className="benefit">
            <h3>Rutas guiadas</h3>
            <p>
              Planes en cuatro semanas para objetivos clave como aislamiento, rediseño de cocinas o instalación de paneles
              solares domésticos.
            </p>
          </div>
          <div className="benefit">
            <h3>Listas interactivas</h3>
            <p>
              Listados descargables con recordatorios, estimación de tiempos y materiales sugeridos para cada tipo de tarea.
            </p>
          </div>
          <div className="benefit">
            <h3>Casos reales</h3>
            <p>
              Historias de hogares mexicanos que lograron optimizar horarios, temperatura y consumo gracias a nuestras metodologías.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

const ToolsPage = () => {
  useEffect(() => {
    document.title = 'Herramientas Recomendadas | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Descubre herramientas y productos sugeridos por Ramilo Raventura Homes para optimizar la eficiencia y el confort en tu hogar.'
      );
    }
  }, []);

  const tools = [
    {
      name: 'Sensor de calidad del aire',
      description:
        'Monitorea los niveles de humedad y partículas para mantener la ventilación óptima y prevenir alergias.',
      image:
        'https://images.unsplash.com/photo-1618005198919-d3d4b5a92eee?auto=format&fit=crop&w=1200&q=80',
      tags: ['Salud ambiental', 'Monitoreo continuo', 'Integración móvil']
    },
    {
      name: 'Panel de control energético',
      description:
        'Visualiza el consumo en tiempo real y recibe recomendaciones automáticas para equilibrar el uso de tus electrodomésticos.',
      image:
        'https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1200&q=80',
      tags: ['Ahorro energético', 'Datos inteligentes', 'Alertas personalizadas']
    },
    {
      name: 'Kit de iluminación inteligente',
      description:
        'Ilumina cada habitación con temperaturas regulables y sensores que siguen la luz natural durante el día.',
      image:
        'https://images.unsplash.com/photo-1505691723518-36a5ac3be353?auto=format&fit=crop&w=1200&q=80',
      tags: ['Ambiente', 'Automatización', 'Control remoto']
    },
    {
      name: 'Organizador modular',
      description:
        'Sistemas modulares para closets y bodegas que maximizan el almacenamiento con materiales sostenibles.',
      image:
        'https://images.unsplash.com/photo-1616594039964-1ba62c63d3cf?auto=format&fit=crop&w=1200&q=80',
      tags: ['Orden', 'Personalización', 'Sustentable']
    }
  ];

  return (
    <div className="page tools-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Herramientas</p>
        <h1 className="page-hero__title">Selección curada para transformar cada rincón</h1>
        <p className="page-hero__subtitle">
          Recomendaciones evaluadas por nuestro equipo para que inviertas de forma inteligente en equipos que suman confort,
          seguridad y eficiencia a tu día a día.
        </p>
      </header>

      <section className="section">
        <div className="tool-grid">
          {tools.map((tool) => (
            <article key={tool.name} className="tool-card">
              <div
                className="tool-card__media"
                style={{ backgroundImage: `url(${tool.image})` }}
                aria-hidden="true"
              />
              <div className="tool-card__body">
                <h3>{tool.name}</h3>
                <p>{tool.description}</p>
                <ul className="tag-list">
                  {tool.tags.map((tag) => (
                    <li key={tag}>{tag}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

const BlogPage = () => {
  useEffect(() => {
    document.title = 'Blog de Innovación Doméstica | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Lee las últimas ideas y tendencias sobre bienestar doméstico, automatización y diseño confortable en el blog de Ramilo Raventura Homes.'
      );
    }
  }, []);

  const posts = [
    {
      title: 'Claves para un verano fresco sin exceso de consumo',
      excerpt:
        'La ventilación cruzada, los materiales reflectantes y la domótica sencilla pueden equilibrar temperaturas sin comprometer el estilo.',
      date: '12 de junio de 2024',
      author: 'Equipo de Eficiencia Térmica',
      image:
        'https://images.unsplash.com/photo-1505692952047-1a78307da8f3?auto=format&fit=crop&w=1200&q=80'
    },
    {
      title: 'Rutinas matutinas que ordenan tu hogar automáticamente',
      excerpt:
        'Automatiza cortinas, aromas y listas de tareas para despertar cada día con espacios inspiradores y listos para la acción.',
      date: '29 de mayo de 2024',
      author: 'Coordinación de Experiencia Doméstica',
      image:
        'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=80'
    },
    {
      title: 'Materiales mexicanos que abrazan el confort sostenible',
      excerpt:
        'Desde barro cocido hasta fibras naturales tratadas, descubre opciones locales que regulan la temperatura y aportan carácter.',
      date: '10 de abril de 2024',
      author: 'Laboratorio de Diseño Biofílico',
      image:
        'https://images.unsplash.com/photo-1530731141654-5993c3016c77?auto=format&fit=crop&w=1200&q=80'
    }
  ];

  return (
    <div className="page blog-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Blog</p>
        <h1 className="page-hero__title">Historias y estrategias frescas para tu hogar</h1>
        <p className="page-hero__subtitle">
          Mantente al tanto de tendencias, experimentos y consejos prácticos que transforman los espacios en refugios llenos de calma y energía.
        </p>
      </header>

      <section className="section">
        <div className="blog-grid">
          {posts.map((post) => (
            <article key={post.title} className="blog-article">
              <div
                className="blog-article__media"
                style={{ backgroundImage: `url(${post.image})` }}
                aria-hidden="true"
              />
              <div className="blog-article__body">
                <h2>{post.title}</h2>
                <p className="blog-article__meta">
                  {post.author} · {post.date}
                </p>
                <p>{post.excerpt}</p>
                <button type="button" className="btn btn--ghost" aria-label={`Abrir artículo ${post.title}`}>
                  Seguir leyendo
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="cta-banner">
          <div>
            <h2>Recibe ideas personalizadas cada mes</h2>
            <p>
              Inscríbete a nuestro boletín y accede a guías inéditas, descuentos en workshops y retos mensuales para hogares vibrantes.
            </p>
          </div>
          <Link to="/contact" className="btn btn--primary">
            Unirme al boletín
          </Link>
        </div>
      </section>
    </div>
  );
};

const CookiePolicyPage = () => {
  useEffect(() => {
    document.title = 'Política de Cookies | Ramilo Raventura Homes';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'Consulta cómo Ramilo Raventura Homes utiliza cookies para ofrecer experiencias digitales personalizadas y seguras.'
      );
    }
  }, []);

  return (
    <div className="page legal-page">
      <header className="page-hero">
        <p className="page-hero__kicker">Política de Cookies</p>
        <h1 className="page-hero__title">Transparencia en el uso de datos de navegación</h1>
        <p className="page-hero__subtitle">
          Explicamos qué cookies empleamos, con qué fines y cómo puedes gestionar tus preferencias en cualquier momento.
        </p>
      </header>

      <section className="section">
        <h2>1. ¿Qué son las cookies?</h2>
        <p>
          Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo cuando navegas por nuestro sitio.
          Permiten recordar tus preferencias, comprender cómo interactúas con los contenidos y brindarte funcionalidades avanzadas.
        </p>

        <h2>2. Tipos de cookies que utilizamos</h2>
        <ul className="legal-list">
          <li>
            <strong>Cookies esenciales:</strong> Habilitan la navegación y el acceso a secciones seguras. Sin ellas, el sitio podría no funcionar correctamente.
          </li>
          <li>
            <strong>Cookies de personalización:</strong> Nos ayudan a adaptar recomendaciones y contenidos según tus preferencias previas.
          </li>
          <li>
            <strong>Cookies analíticas:</strong> Analizamos el rendimiento para mejorar continuamente la experiencia de nuestros visitantes.
          </li>
        </ul>

        <h2>3. Gestión de preferencias</h2>
        <p>
          Puedes ajustar tu configuración desde nuestro banner de consentimiento o a través de la configuración del navegador.
          Además, te ofrecemos actualizar tu consentimiento enviando una solicitud a <a href="mailto:hola@ramiloraventura.site">hola@ramiloraventura.site</a>.
        </p>

        <h2>4. Vigencia y actualizaciones</h2>
        <p>
          Revisamos esta política de manera trimestral para reflejar nuevas tecnologías o servicios. Publicaremos cualquier cambio significativo con antelación.
        </p>
      </section>
    </div>
  );
};

const RouteChangeHandler = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
};

const App = () => (
  <div className="app-shell">
    <Header />
    <RouteChangeHandler />
    <main className="main-content" id="contenido-principal">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/guide" element={<GuidePage />} />
        <Route path="/programs" element={<Services />} />
        <Route path="/tools" element={<ToolsPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/legal" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<TermsOfService />} />
        <Route path="/cookie-policy" element={<CookiePolicyPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

export default App;