import React from 'react';
import SEO from '../components/SEO';

const Robots = () => {
  const robotsTxt = `User-agent: *
Allow: /

Sitemap: https://tuprogresohoy.com/sitemap.xml`;

  return (
    <>
      <SEO
        title="Robots.txt · Tu Progreso Hoy"
        description="Robots directives for Tu Progreso Hoy."
        keywords="robots, crawling, tu progreso hoy"
        canonical="https://tuprogresohoy.com/robots.txt"
      />
      <section className="legal-page">
        <div className="container">
          <pre className="code-block" aria-label="Robots.txt directives">
            {robotsTxt}
          </pre>
        </div>
      </section>
    </>
  );
};

export default Robots;