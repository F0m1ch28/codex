import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import SEO from '../components/SEO';
import Button from '../components/Button';
import { useLanguage } from '../components/LanguageContext';

const ThankYou = () => {
  const location = useLocation();
  const { translations } = useLanguage();
  const state = location.state || {};

  return (
    <>
      <SEO
        title="Thank You · Tu Progreso Hoy"
        description="Thank you for connecting with Tu Progreso Hoy."
        keywords={translations.meta.keywords}
      />
      <section className="thank-you-page">
        <div className="container thankyou-container">
          <h1>Thank you!</h1>
          <p>
            We received your request{state.name ? `, ${state.name}` : ''}. A confirmation email has been sent to{' '}
            <strong>{state.email || 'your inbox'}</strong>.
          </p>
          <p className="thankyou-note">
            Please open the email and complete the double opt-in to activate access. This ensures you receive only the
            updates you choose.
          </p>
          <Button as={Link} to="/" variant="primary">
            Back to homepage
          </Button>
        </div>
      </section>
    </>
  );
};

export default ThankYou;