import React from 'react';
import SEO from '../components/SEO';
import { useLanguage } from '../components/LanguageContext';

const Terms = () => {
  const { translations } = useLanguage();

  return (
    <>
      <SEO
        title="Terms & Conditions · Tu Progreso Hoy"
        description="Terms and conditions for using Tu Progreso Hoy educational platform."
        keywords={translations.meta.keywords}
      />
      <section className="legal-page">
        <div className="container">
          <h1>{translations.nav.terms}</h1>
          <p>
            Tu Progreso Hoy provides educational dashboards, course materials, and resources focused on Argentina’s
            inflation and personal finance landscape. By accessing our platform, you agree to the following terms.
          </p>

          <h2>Use of service</h2>
          <p>
            The content is for educational purposes only. We do not offer investment, brokerage, or individual financial
            advisory services. You are responsible for evaluating how the insights apply to your own circumstances.
          </p>

          <h2>Account and subscriptions</h2>
          <p>
            Any subscription requires accurate personal information and adherence to anti-fraud practices. Access may be
            suspended if misuse is detected. Double opt-in is required for all email communications.
          </p>

          <h2>Intellectual property</h2>
          <p>
            All dashboards, course materials, and original content are owned by Tu Progreso Hoy. You may not reproduce,
            distribute, or resell the materials without explicit written permission.
          </p>

          <h2>Data accuracy</h2>
          <p>
            We strive for reliable and timely information. Nonetheless, market data can change rapidly. Tu Progreso Hoy
            is not liable for decisions made solely based on platform content.
          </p>

          <h2>Limitation of liability</h2>
          <p>
            To the extent permitted by law, Tu Progreso Hoy is not responsible for any indirect, incidental, or
            consequential damages resulting from the use of our platform.
          </p>

          <h2>Updates</h2>
          <p>
            Terms may change to align with regulatory requirements or service enhancements. Continued use constitutes
            acceptance of modifications. We encourage periodic review of this page.
          </p>

          <h2>Contact</h2>
          <p>
            For questions regarding these terms, contact us at <a href="mailto:legal@tuprogresohoy.com">legal@tuprogresohoy.com</a>.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;