import React from 'react';
import SEO from '../components/SEO';
import Card from '../components/Card';
import { useLanguage } from '../components/LanguageContext';

const Inflation = () => {
  const { translations } = useLanguage();

  return (
    <>
      <SEO
        title="Inflation Insights · Tu Progreso Hoy"
        description={translations.inflation.description}
        keywords={translations.meta.keywords}
      />
      <section className="page-hero inflation-hero">
        <div className="container">
          <h1>{translations.inflation.title}</h1>
          <p>{translations.inflation.description}</p>
        </div>
      </section>

      <section className="section">
        <div className="container methodology-grid">
          {translations.inflation.sections.map((section) => (
            <Card key={section.title} title={section.title}>
              {section.body.map((paragraph, index) => (
                <p key={index} className="secondary-text">
                  {paragraph}
                </p>
              ))}
            </Card>
          ))}
        </div>
      </section>

      <section className="section chart-section">
        <div className="container">
          <h2>{translations.inflation.chartTitle}</h2>
          <p>{translations.inflation.chartSubtitle}</p>
          <div className="chart-placeholder" role="img" aria-label="CPI vs ARS exchange rate chart placeholder">
            <div className="chart-lines">
              <span className="line legend-official">CPI</span>
              <span className="line legend-market">ARS→USD</span>
            </div>
            <div className="chart-grid">
              {Array.from({ length: 12 }).map((_, index) => (
                <div key={index} className="chart-bar" style={{ height: `${40 + index * 4}px` }} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section faq-section">
        <div className="container">
          <h2>{translations.inflation.faqTitle}</h2>
          <div className="faq-grid">
            {translations.inflation.faq.map((item) => (
              <details key={item.question} className="faq-item">
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Inflation;