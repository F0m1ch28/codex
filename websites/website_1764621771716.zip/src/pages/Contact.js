import React from 'react';
import SEO from '../components/SEO';
import ContactForm from '../components/ContactForm';
import { useLanguage } from '../components/LanguageContext';

const Contact = () => {
  const { translations } = useLanguage();

  const contactLabels = {
    name: translations.home.trialForm.nameLabel,
    email: translations.home.trialForm.emailLabel,
    phone: 'Phone',
    message: 'Message',
    submit: 'Send message',
    consent: translations.contact.confirmationNote,
    pending: 'Sending…',
    success: translations.forms.success,
    emailInvalid: translations.forms.emailInvalid,
    required: translations.forms.requiredField
  };

  if (translations.nav.contact === 'Contacto') {
    contactLabels.phone = 'Teléfono';
    contactLabels.message = 'Mensaje';
    contactLabels.submit = 'Enviar mensaje';
  }

  return (
    <>
      <SEO
        title="Contact · Tu Progreso Hoy"
        description={translations.contact.description}
        keywords={translations.meta.keywords}
      />
      <section className="page-hero contact-hero">
        <div className="container">
          <h1>{translations.contact.title}</h1>
          <p>{translations.contact.description}</p>
        </div>
      </section>

      <section className="section contact-section">
        <div className="container contact-grid">
          <div>
            <h2>{translations.contact.formHeading}</h2>
            <ContactForm labels={contactLabels} />
            <div className="contact-details">
              <p>
                <strong>{translations.contact.addressLabel}:</strong> {translations.footer.address}
              </p>
              <p>
                <strong>{translations.contact.phoneLabel}:</strong> {translations.footer.phone}
              </p>
              <p>
                <strong>{translations.contact.emailLabel}:</strong>{' '}
                <a href="mailto:info@tuprogresohoy.com">info@tuprogresohoy.com</a>
              </p>
            </div>
          </div>
          <div className="contact-map">
            <h3>{translations.contact.mapTitle}</h3>
            <iframe
              title="Tu Progreso Hoy Buenos Aires"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.062707940032!2d-58.3837596235582!3d-34.60373405949605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95a3352c67de6ccb%3A0x2d48d37d5d605b1!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA!5e0!3m2!1ses-419!2sar!4v1700000000000!5m2!1ses-419!2sar"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;