import React from 'react';
import SEO from '../components/SEO';
import { useLanguage } from '../components/LanguageContext';

const FAQ = () => {
  const { translations } = useLanguage();

  return (
    <>
      <SEO
        title="FAQ · Tu Progreso Hoy"
        description={translations.faq.intro}
        keywords={translations.meta.keywords}
      />
      <section className="page-hero faq-hero">
        <div className="container">
          <h1>{translations.faq.title}</h1>
          <p>{translations.faq.intro}</p>
        </div>
      </section>

      <section className="section faq-section">
        <div className="container faq-list">
          {translations.faq.items.map((item) => (
            <details key={item.question} className="faq-item">
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
};

export default FAQ;