import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useLanguage } from '../components/LanguageContext';
import Button from '../components/Button';
import Card from '../components/Card';
import ExchangeTracker from '../components/ExchangeTracker';
import SEO from '../components/SEO';

const Home = () => {
  const { translations, fixedStatements, language } = useLanguage();
  const navigate = useNavigate();
  const [trialData, setTrialData] = useState({ name: '', email: '' });
  const [trialErrors, setTrialErrors] = useState({});

  const handleTrialChange = (event) => {
    const { name, value } = event.target;
    setTrialData((prev) => ({ ...prev, [name]: value }));
    setTrialErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validateTrial = () => {
    const errors = {};
    if (!trialData.name.trim()) {
      errors.name = translations.home.trialForm.errors.name;
    }
    if (!trialData.email.trim()) {
      errors.email = translations.home.trialForm.errors.email;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trialData.email.trim())) {
      errors.email = translations.forms.emailInvalid;
    }
    setTrialErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleTrialSubmit = (event) => {
    event.preventDefault();
    if (!validateTrial()) return;
    navigate('/thank-you', {
      state: {
        name: trialData.name,
        email: trialData.email,
        origin: 'trial'
      }
    });
  };

  return (
    <>
      <SEO
        title="Tu Progreso Hoy · Argentina Inflation Intelligence & Finance Course"
        description={translations.meta.description}
        keywords={translations.meta.keywords}
      />
      <section className="hero">
        <div className="hero-overlay" aria-hidden="true" />
        <div className="container hero-container">
          <div className="hero-content">
            <span className="hero-badge">{translations.hero.badge}</span>
            <h1>{translations.hero.heading}</h1>
            <p className="hero-subtitle">{translations.hero.subheading}</p>
            <ul className="hero-points">
              {translations.home.heroBullets.map((bullet, index) => (
                <li key={index}>{bullet}</li>
              ))}
            </ul>
            <div className="hero-actions">
              <Button as={Link} to="/inflation" variant="primary" aria-label={translations.hero.ariaCtaPrimary}>
                {translations.hero.primaryCta}
              </Button>
              <Button as={Link} to="/course" variant="secondary" aria-label={translations.hero.ariaCtaSecondary}>
                {translations.hero.secondaryCta}
              </Button>
            </div>
          </div>
          <div className="hero-visual" role="presentation">
            <div className="hero-image-card">
              <img
                src="https://images.pexels.com/photos/258331/pexels-photo-258331.jpeg"
                alt="Argentina flag flowing in the wind"
              />
              <div className="hero-image-overlay" />
              <div className="hero-stat">
                <span>{translations.tracker.title}</span>
                <strong>880.50</strong>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section statements-section">
        <div className="container">
          <h2>{translations.home.statementsIntro}</h2>
          <div className="statements-grid">
            {fixedStatements.map((statement) => (
              <div key={statement} className="statement-card">
                <p className="statement-primary">{statement}</p>
                {language === 'en' && (
                  <p className="statement-secondary">
                    {translations.home.fixedStatementsTranslations[statement]}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section key-promises">
        <div className="container">
          <h2>{translations.home.keyPromiseTitle}</h2>
          <div className="cards-grid">
            {translations.home.keyPromises.map((promise) => (
              <Card key={promise.title} title={promise.title} description={promise.description} />
            ))}
          </div>
        </div>
      </section>

      <ExchangeTracker />

      <section className="section insights-section">
        <div className="container">
          <div className="section-heading">
            <h2>{translations.home.insightsHeadline}</h2>
            <p>{translations.home.insightsIntro}</p>
          </div>
          <div className="cards-grid">
            {translations.home.insightCards.map((card) => (
              <Card
                key={card.title}
                title={card.title}
                description={card.description}
                image={card.image}
                alt={card.alt}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section course-preview">
        <div className="container">
          <div className="course-preview-wrapper">
            <div className="course-copy">
              <h2>{translations.home.coursePreview.title}</h2>
              <p>{translations.home.coursePreview.description}</p>
              <p className="course-note">{translations.home.educationalNote}</p>
            </div>
            <div className="course-modules">
              {translations.home.coursePreview.modules.map((module) => (
                <div key={module.title} className="module-card">
                  <h3>{module.title}</h3>
                  <ul>
                    {module.points.map((point, index) => (
                      <li key={index}>{point}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section testimonials-section">
        <div className="container">
          <h2>{translations.home.testimonials.title}</h2>
          <div className="testimonials-grid">
            {translations.home.testimonials.list.map((item) => (
              <blockquote key={item.name} className="testimonial-card">
                <p>“{item.quote}”</p>
                <footer>
                  <strong>{item.name}</strong>
                  <span>{item.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="section trial-section" id="trial-form">
        <div className="container trial-container">
          <div className="trial-copy">
            <h2>{translations.home.trialForm.title}</h2>
            <p>{translations.home.trialForm.description}</p>
          </div>
          <form className="trial-form" onSubmit={handleTrialSubmit}>
            <div className="form-field">
              <label htmlFor="trial-name">{translations.home.trialForm.nameLabel}</label>
              <input
                id="trial-name"
                type="text"
                name="name"
                value={trialData.name}
                onChange={handleTrialChange}
                autoComplete="name"
              />
              {trialErrors.name && <span className="error-text">{trialErrors.name}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="trial-email">{translations.home.trialForm.emailLabel}</label>
              <input
                id="trial-email"
                type="email"
                name="email"
                value={trialData.email}
                onChange={handleTrialChange}
                autoComplete="email"
              />
              {trialErrors.email && <span className="error-text">{trialErrors.email}</span>}
            </div>
            <p className="form-note">{translations.home.trialForm.consent}</p>
            <Button type="submit" variant="primary">
              {translations.home.trialForm.submit}
            </Button>
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;