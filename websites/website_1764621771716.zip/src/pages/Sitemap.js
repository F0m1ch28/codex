import React from 'react';
import SEO from '../components/SEO';

const Sitemap = () => {
  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://tuprogresohoy.com/</loc></url>
  <url><loc>https://tuprogresohoy.com/inflation</loc></url>
  <url><loc>https://tuprogresohoy.com/course</loc></url>
  <url><loc>https://tuprogresohoy.com/resources</loc></url>
  <url><loc>https://tuprogresohoy.com/contact</loc></url>
  <url><loc>https://tuprogresohoy.com/faq</loc></url>
  <url><loc>https://tuprogresohoy.com/privacy</loc></url>
  <url><loc>https://tuprogresohoy.com/terms</loc></url>
  <url><loc>https://tuprogresohoy.com/cookies</loc></url>
  <url><loc>https://tuprogresohoy.com/thank-you</loc></url>
  <url><loc>https://tuprogresohoy.com/robots.txt</loc></url>
</urlset>`;

  return (
    <>
      <SEO
        title="Sitemap · Tu Progreso Hoy"
        description="XML sitemap for Tu Progreso Hoy."
        keywords="sitemap, tu progreso hoy"
        canonical="https://tuprogresohoy.com/sitemap.xml"
      />
      <section className="legal-page">
        <div className="container">
          <pre className="code-block" aria-label="XML sitemap">
            {sitemapXml}
          </pre>
        </div>
      </section>
    </>
  );
};

export default Sitemap;