import React from 'react';
import SEO from '../components/SEO';
import Card from '../components/Card';
import Button from '../components/Button';
import { useLanguage } from '../components/LanguageContext';

const Resources = () => {
  const { translations, language } = useLanguage();

  return (
    <>
      <SEO
        title="Resources & Glossary · Tu Progreso Hoy"
        description={translations.resources.description}
        keywords={translations.meta.keywords}
      />
      <section className="page-hero resources-hero">
        <div className="container">
          <h1>{translations.resources.title}</h1>
          <p>{translations.resources.description}</p>
        </div>
      </section>

      <section className="section">
        <div className="container cards-grid">
          {translations.resources.articles.map((article) => (
            <Card
              key={article.title}
              title={article.title}
              description={article.summary}
              image="https://images.pexels.com/photos/3184631/pexels-photo-3184631.jpeg"
              alt="People collaborating in a modern office"
            >
              <Button variant="secondary">{article.linkLabel}</Button>
            </Card>
          ))}
        </div>
      </section>

      <section className="section note-section">
        <div className="container">
          <div className="bilingual-note">
            <p>{translations.resources.bilingualNote}</p>
            {language === 'en' && (
              <p>
                {translations.home.fixedStatementsTranslations['Conocimiento financiero impulsado por tendencias.']}
              </p>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default Resources;