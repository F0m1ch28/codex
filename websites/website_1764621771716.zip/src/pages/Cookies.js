import React from 'react';
import SEO from '../components/SEO';
import { useLanguage } from '../components/LanguageContext';

const Cookies = () => {
  const { translations } = useLanguage();

  return (
    <>
      <SEO
        title="Cookie Policy · Tu Progreso Hoy"
        description="Cookie usage information for Tu Progreso Hoy."
        keywords={translations.meta.keywords}
      />
      <section className="legal-page">
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>
            Tu Progreso Hoy uses cookies to deliver an accessible and personalized learning experience. Cookies are
            small text files stored on your device that help remember preferences and measure engagement.
          </p>

          <h2>Types of cookies we use</h2>
          <ul>
            <li>
              <strong>Essential cookies:</strong> Required for site functionality such as secure login and language
              selection.
            </li>
            <li>
              <strong>Analytics cookies:</strong> Optional cookies that help us understand which dashboards and lessons
              are most valuable.
            </li>
            <li>
              <strong>Preference cookies:</strong> Store interface choices, including chart views and module progress.
            </li>
          </ul>

          <h2>Consent</h2>
          <p>
            You can accept or decline optional cookies via the banner. You may adjust your preference at any time by
            clearing cookies or visiting browser settings.
          </p>

          <h2>Managing cookies</h2>
          <p>
            Most browsers allow you to block or delete cookies. Note that disabling essential cookies may affect platform
            functionality. For guidance, consult your browser’s help pages.
          </p>

          <h2>Updates</h2>
          <p>
            This policy may be updated to reflect regulatory changes or new features. Revisit this page periodically for
            the latest information.
          </p>
        </div>
      </section>
    </>
  );
};

export default Cookies;