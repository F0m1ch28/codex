import React from 'react';
import SEO from '../components/SEO';
import { useLanguage } from '../components/LanguageContext';

const Privacy = () => {
  const { translations } = useLanguage();

  return (
    <>
      <SEO
        title="Privacy Policy · Tu Progreso Hoy"
        description="Privacy practices for Tu Progreso Hoy platform."
        keywords={translations.meta.keywords}
      />
      <section className="legal-page">
        <div className="container">
          <h1>{translations.nav.privacy}</h1>
          <p>
            Tu Progreso Hoy respects your privacy and is committed to protecting personal information in accordance with
            GDPR-ready principles and Argentina’s regulatory requirements.
          </p>

          <h2>Information we collect</h2>
          <ul>
            <li>Contact details provided during newsletter sign-ups or course registration.</li>
            <li>Usage analytics to improve platform performance (stored only with your cookie consent).</li>
            <li>Support inquiries and feedback messages.</li>
          </ul>

          <h2>How we use data</h2>
          <p>
            Data enables communication regarding platform updates, course content, and billing notifications. We never
            sell personal information. Access is limited to authorized team members.
          </p>

          <h2>Email communications</h2>
          <p>
            All communications follow a double opt-in process. You may unsubscribe at any time via the link provided in
            each email or by contacting our support team.
          </p>

          <h2>Cookies</h2>
          <p>
            Optional analytics cookies help us understand which dashboards are most useful. You can accept or decline
            these cookies at any point via the banner or browser settings.
          </p>

          <h2>Data retention</h2>
          <p>
            We store personal data only for as long as necessary to provide services or comply with legal obligations. We
            securely delete data upon account closure or verified request.
          </p>

          <h2>User rights</h2>
          <p>
            You may request access, correction, or deletion of your data. Write to{' '}
            <a href="mailto:privacy@tuprogresohoy.com">privacy@tuprogresohoy.com</a> and we will respond within 30 days.
          </p>

          <h2>International transfers</h2>
          <p>
            If data is processed outside Argentina, we ensure adequate safeguards and contractual protections to maintain
            privacy standards.
          </p>

          <h2>Contact</h2>
          <p>
            For privacy inquiries, reach out to <a href="mailto:privacy@tuprogresohoy.com">privacy@tuprogresohoy.com</a>.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;