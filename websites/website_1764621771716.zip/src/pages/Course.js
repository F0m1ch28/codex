import React from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import Card from '../components/Card';
import Button from '../components/Button';
import { useLanguage } from '../components/LanguageContext';

const Course = () => {
  const { translations } = useLanguage();

  return (
    <>
      <SEO
        title="Course Overview · Tu Progreso Hoy"
        description={translations.course.description}
        keywords={translations.meta.keywords}
      />
      <section className="page-hero course-hero">
        <div className="container">
          <h1>{translations.course.title}</h1>
          <p>{translations.course.description}</p>
        </div>
      </section>

      <section className="section">
        <div className="container course-modules-grid">
          {translations.course.modules.map((module) => (
            <Card key={module.title} title={module.title}>
              <ul className="card-list">
                {module.bullets.map((bullet, index) => (
                  <li key={index}>{bullet}</li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </section>

      <section className="section audience-section">
        <div className="container">
          <h2>{translations.course.targetAudienceTitle}</h2>
          <ul className="audience-list">
            {translations.course.audience.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section cta-section">
        <div className="container cta-container">
          <h3>{translations.home.trialForm.title}</h3>
          <p>{translations.home.trialForm.description}</p>
          <Button as={Link} to="/#trial-form" variant="primary" aria-label={translations.course.ctaAria}>
            {translations.course.cta}
          </Button>
        </div>
      </section>
    </>
  );
};

export default Course;