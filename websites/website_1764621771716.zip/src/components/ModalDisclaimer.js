import React, { useEffect, useState } from 'react';
import Button from './Button';

const DISCLAIMER_KEY = 'tph-disclaimer-ack';

const ModalDisclaimer = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(DISCLAIMER_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleClose = () => {
    window.localStorage.setItem(DISCLAIMER_KEY, 'acknowledged');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal-content">
        <h3>Disclaimer</h3>
        <p>Мы не предоставляем финансовые услуги.</p>
        <p>We do not provide financial services.</p>
        <p>No proporcionamos servicios financieros.</p>
        <Button variant="primary" onClick={handleClose}>
          Understood
        </Button>
      </div>
    </div>
  );
};

export default ModalDisclaimer;