import React, { useEffect, useState } from 'react';
import { useLanguage } from './LanguageContext';

const initialHistory = Array.from({ length: 7 }).map((_, index) => ({
  timestamp: `Day ${index + 1}`,
  value: 850 + Math.random() * 30
}));

const ExchangeTracker = () => {
  const { translations } = useLanguage();
  const [rate, setRate] = useState(880.5);
  const [history, setHistory] = useState(initialHistory);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setRate((prev) => {
        const next = prev + (Math.random() - 0.5) * 4;
        return Math.round(next * 100) / 100;
      });
      setHistory((prev) => {
        const updated = [...prev.slice(1), { timestamp: new Date().toLocaleTimeString(), value: rate }];
        return updated;
      });
      setLastUpdated(new Date());
    }, 15000);

    return () => clearInterval(interval);
  }, [rate]);

  const maxVal = Math.max(...history.map((item) => item.value));

  return (
    <section className="section tracker-section">
      <div className="container tracker-container">
        <div>
          <h2>{translations.tracker.title}</h2>
          <p>{translations.tracker.subtitle}</p>
          <div className="tracker-rate">
            <span className="tracker-label">ARS → USD</span>
            <span className="tracker-value">{rate.toFixed(2)}</span>
          </div>
          <p className="last-updated">
            {translations.tracker.lastUpdated}:{' '}
            <time dateTime={lastUpdated.toISOString()}>{lastUpdated.toLocaleTimeString()}</time>
          </p>
        </div>
        <div className="tracker-chart" role="img" aria-label="Simulated ARS to USD exchange rate history">
          {history.map((item, index) => (
            <div key={`${item.timestamp}-${index}`} className="tracker-bar">
              <div
                className="tracker-bar-fill"
                style={{ height: `${(item.value / maxVal) * 100}%` }}
                aria-hidden="true"
              />
              <span className="tracker-bar-label">{item.timestamp}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExchangeTracker;