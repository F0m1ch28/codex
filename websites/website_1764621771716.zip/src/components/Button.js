import React from 'react';
import { Link } from 'react-router-dom';

const Button = ({ variant = 'primary', children, className = '', as: Component = 'button', ...props }) => {
  const VariantComponent = Component === Link ? Link : Component;
  return (
    <VariantComponent className={`btn btn-${variant} ${className}`.trim()} {...props}>
      {children}
    </VariantComponent>
  );
};

export default Button;