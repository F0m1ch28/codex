import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

const LanguageContext = createContext();

const translations = {
  en: {
    brand: 'Tu Progreso Hoy',
    nav: {
      home: 'Home',
      inflation: 'Inflation',
      course: 'Course',
      resources: 'Resources',
      contact: 'Contact',
      privacy: 'Privacy',
      terms: 'Terms'
    },
    hero: {
      heading: 'Illuminate your financial path in Argentina',
      subheading:
        'Tu Progreso Hoy blends reliable ARS→USD intelligence with a practical starter course so you can make responsible, confident choices every day.',
      primaryCta: 'View Inflation Insights',
      secondaryCta: 'Explore the Course',
      ariaCtaPrimary: 'Navigate to the inflation insights page',
      ariaCtaSecondary: 'Navigate to the course overview page',
      badge: 'Trusted ARS→USD & budgeting dashboards'
    },
    home: {
      heroBullets: [
        'Transparent dashboards tracking ARS and USD movements in real time.',
        'Contextual trends that translate macro-economic shifts into clear steps.',
        'Personal finance fundamentals tailored for Argentina-based earners.'
      ],
      statementsIntro: 'Core commitments that shape Tu Progreso Hoy:',
      fixedStatementsTranslations: {
        'Datos verificados para planificar tu presupuesto.': 'Verified data to plan your budget.',
        'Decisiones responsables, objetivos nítidos.': 'Responsible decisions, crystal-clear objectives.',
        'Conocimiento financiero impulsado por tendencias.': 'Financial knowledge powered by trends.',
        'Pasos acertados hoy, mejor futuro mañana.': 'Smart steps today, a better future tomorrow.',
        'Análisis transparentes y datos de mercado para decidir con seguridad.':
          'Transparent analysis and market data to decide with confidence.',
        'Información confiable que respalda elecciones responsables sobre tu dinero.':
          'Reliable information supporting responsible choices about your money.',
        'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.':
          'Track trends, identify opportunities, and design your financial path.',
        'Plataforma educativa con datos esenciales, sin asesoría financiera directa.':
          'Educational platform with essential data, without direct financial advisory.',
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.':
          'From information to learning: strengthen your financial judgment step by step.'
      },
      keyPromiseTitle: 'Why Tu Progreso Hoy matters now',
      keyPromises: [
        {
          title: 'Daily ARS→USD panoramas',
          description:
            'Monitor weighted exchange references, parallel indicators, and sentiment in one command center designed for action.'
        },
        {
          title: 'Decision-first data storytelling',
          description:
            'Our dashboards highlight the movements that impact purchasing power and budgeting moments throughout the month.'
        },
        {
          title: 'Personal finance starter course',
          description:
            'Build confident habits with lessons that turn complex inflation dynamics into step-by-step budgeting routines.'
        }
      ],
      insightsHeadline: 'Insights crafted for clarity',
      insightsIntro:
        'Visual narratives connect CPI shifts, FX corridors, and household budgeting tactics so you can anticipate the month ahead.',
      insightCards: [
        {
          title: 'Interlinked CPI & FX timelines',
          description:
            'Explore CPI releases alongside the ARS→USD tracker to contextualize how price announcements ripple across the market.',
          image: 'https://images.pexels.com/photos/669610/pexels-photo-669610.jpeg',
          alt: 'Financial analyst reviewing charts on multiple monitors'
        },
        {
          title: 'Income resilience scenarios',
          description:
            'Simulated monthly cash-flow views show how different earning brackets adapt to inflationary pressure and exchange swings.',
          image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg',
          alt: 'Team collaborating over financial documents'
        },
        {
          title: 'Budget checkpoints',
          description:
            'Aligned reminders anchor each module with milestones for savings, expenses, and debt control under Argentine conditions.',
          image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg',
          alt: 'Close-up of a person working with charts and a laptop'
        }
      ],
      coursePreview: {
        title: 'From data to applied learning',
        description:
          'Progress through the starter course while leveraging current ARS→USD analytics, curated reading lists, and guided exercises for your household plan.',
        modules: [
          {
            title: 'Module 1 · Inflation essentials',
            points: [
              'Understand how monetary policy and supply routes shape CPI releases.',
              'Decode official vs. market-led exchange references.'
            ]
          },
          {
            title: 'Module 2 · Budgeting frameworks',
            points: [
              'Design a resilient monthly budget anchored in realistic ARS projections.',
              'Define priority categories and buffers for exchange volatility.'
            ]
          },
          {
            title: 'Module 3 · Savings alignment',
            points: [
              'Integrate savings objectives with FX trend alerts.',
              'Map short-, mid-, and long-term allocations using our dashboards.'
            ]
          }
        ]
      },
      testimonials: {
        title: 'Voices from our community',
        list: [
          {
            name: 'Lucía Fernández',
            role: 'Product Manager, Buenos Aires',
            quote:
              'The daily ARS→USD tracker finally gave me a consistent reference to renegotiate team budgets without guesswork.'
          },
          {
            name: 'Martín Silva',
            role: 'Freelance Designer, Rosario',
            quote:
              'I rebuilt my invoicing calendar thanks to the course exercises. Transparent data turned stress into a structured plan.'
          },
          {
            name: 'Agustina Romero',
            role: 'Hospitality Entrepreneur, Córdoba',
            quote:
              'Having CPI context with actionable checklists helps me communicate pricing updates to staff and clients calmly.'
          }
        ]
      },
      trialForm: {
        title: 'Получить бесплатный пробный урок',
        description:
          'Access our introductory lesson and receive a double opt-in confirmation email to activate your trial experience.',
        nameLabel: 'Your name',
        emailLabel: 'Business or personal email',
        submit: 'Activate my trial',
        consent:
          'By submitting you agree to receive a confirmation email. Complete the double opt-in to access the lesson.',
        success:
          'Submission received. You will be redirected shortly to confirm the next steps.',
        errors: {
          name: 'Please enter your name.',
          email: 'Please enter a valid email address.'
        }
      },
      educationalNote: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
    },
    tracker: {
      title: 'ARS→USD Tracker',
      subtitle:
        'Live indicators blend official references, market sentiment, and purchasing power proxies.',
      lastUpdated: 'Last updated'
    },
    inflation: {
      title: 'Inflation methodology & transparency',
      description:
        'Understand how Tu Progreso Hoy sources, cleans, and presents inflation data so you can rely on every chart.',
      sections: [
        {
          title: 'Integrated data methodology',
          body: [
            'We combine official CPI releases, currency board communications, and reputable private consultancies to build a blended ARS→USD signal.',
            'Market feeds are cross-checked with audited historical series, while anomalies trigger a manual review workflow documented in our public changelog.'
          ]
        },
        {
          title: 'Contextual dashboards',
          body: [
            'Dashboards articulate CPI, wholesale inflation, and various ARS corridors. Tooltips highlight the timeframe, sources, and calculation approach.',
            'Scenario layers let you simulate the impact of different FX paths on household budgets, including rent, groceries, and services.'
          ]
        },
        {
          title: 'Quality controls',
          body: [
            'Each dataset runs through validation scripts that compare against baseline thresholds to prevent outlier distortions.',
            'Community feedback is encouraged via our transparent issue tracker—every correction appears in the release notes.'
          ]
        }
      ],
      chartTitle: 'Visualize CPI vs ARS Corridors',
      chartSubtitle:
        'Overlay monthly CPI and ARS→USD variation to frame price dynamics with currency movements.',
      faqTitle: 'Frequently asked questions',
      faq: [
        {
          question: 'How often is the ARS→USD tracker updated?',
          answer:
            'The tracker refreshes key indicators multiple times per day. Aggregated dashboards publish an end-of-day summary for consistent decision-making.'
        },
        {
          question: 'Can I download the underlying datasets?',
          answer:
            'Yes. Subscribers can export CSV snapshots and access methodology notes that detail the source mix and transformations applied.'
        },
        {
          question: 'Do you provide individual financial advice?',
          answer:
            'No. Tu Progreso Hoy is an educational platform with essential data. We encourage consulting licensed professionals for personalised advice.'
        }
      ]
    },
    course: {
      title: 'Course overview & syllabus',
      description:
        'A modular learning path that translates the latest inflation indicators into practical personal finance routines.',
      modules: [
        {
          title: 'Module 1 · Mapping the landscape',
          bullets: [
            'Dissect the drivers behind ARS volatility and Argentina’s inflation patterns.',
            'Build a personal inflation dashboard with curated KPIs.'
          ]
        },
        {
          title: 'Module 2 · Budget architecture',
          bullets: [
            'Set spending caps tied to CPI release cycles.',
            'Design emergency buffers aligned with FX corridors.'
          ]
        },
        {
          title: 'Module 3 · Savings & currency strategy',
          bullets: [
            'Diversify savings buckets across currency exposures responsibly.',
            'Use trend alerts to time conversions aligned with your goals.'
          ]
        },
        {
          title: 'Module 4 · Communication & planning',
          bullets: [
            'Share budgeting updates with family or teams using our templates.',
            'Translate complex data into simple, actionable narratives.'
          ]
        }
      ],
      targetAudienceTitle: 'Who will benefit most?',
      audience: [
        'Professionals balancing salaries and expenses in ARS.',
        'Freelancers invoicing in multiple currencies who need stable planning signals.',
        'Households seeking structured routines grounded in transparent data.'
      ],
      cta: 'Jump to free trial form',
      ctaAria: 'Scroll to the trial form section on the home page'
    },
    resources: {
      title: 'Resources & glossary',
      description:
        'Dive deeper with curated explainers, bilingual glossaries, and actionable templates shaped by Argentina’s reality.',
      articles: [
        {
          title: 'Reading ARS dashboards without noise',
          summary:
            'A guide to interpreting official and alternative exchange references, spotlighting how to pair them with your monthly budget decisions.',
          linkLabel: 'Read article'
        },
        {
          title: 'Glossary · CPI and ARS essentials (EN / ES)',
          summary:
            'Key terminology in both languages so you can navigate news, dashboards, and policy updates with confidence.',
          linkLabel: 'Open glossary'
        },
        {
          title: 'Template · Monthly inflation briefing',
          summary:
            'Structure weekly check-ins using our template that blends ARS → USD signals with personal finance checkpoints.',
          linkLabel: 'Download template'
        }
      ],
      bilingualNote:
        'Conocimiento financiero impulsado por tendencias. Información confiable que respalda elecciones responsables sobre tu dinero.'
    },
    contact: {
      title: 'Connect with Tu Progreso Hoy',
      description:
        'We are based in Buenos Aires and ready to support your learning journey with transparent information.',
      addressLabel: 'Address',
      phoneLabel: 'Phone',
      emailLabel: 'Email',
      mapTitle: 'Map of Buenos Aires location',
      formHeading: 'Send us a message',
      confirmationNote:
        'All messages trigger a double opt-in email. Please confirm it to complete your inquiry.'
    },
    faq: {
      title: 'FAQ · Your questions answered',
      intro:
        'Build confidence by understanding how Tu Progreso Hoy supports you with data-driven insights and educational content.',
      items: [
        {
          question: 'What does the subscription include?',
          answer:
            'Access to interactive dashboards, the personal finance starter course, curated resources, and community Q&A sessions.'
        },
        {
          question: 'Is the content available in Spanish?',
          answer:
            'Yes. All dashboards and course materials are available in English and Spanish to support bilingual teams and households.'
        },
        {
          question: 'How is my data protected?',
          answer:
            'We apply encryption in transit, follow GDPR-ready practices, and only use your email for opt-in communication.'
        }
      ]
    },
    footer: {
      address: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
      phone: '+54 11 5555-1234',
      email: 'info@tuprogresohoy.com',
      followUs: 'Follow',
      trustedData: 'Datos verificados para planificar tu presupuesto.',
      rights: 'All rights reserved.',
      disclaimerEn: 'Educational platform with essential data, no direct financial advisory.',
      disclaimerEs: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
      disclaimerRu: 'Образовательная платформа с ключевыми данными, без прямых финансовых услуг.'
    },
    forms: {
      emailInvalid: 'Please provide a valid email address.',
      requiredField: 'This field is required.',
      success: 'Thank you! Check your inbox to confirm your request.'
    },
    meta: {
      description:
        'Tu Progreso Hoy delivers transparent ARS→USD dashboards, Argentina inflation insights, and a personal finance starter course.',
      keywords: 'argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, economic trends, datos confiables',
      ogTitle: 'Tu Progreso Hoy · Argentina Inflation Intelligence & Finance Course',
      ogDescription:
        'Transparent ARS→USD dashboards and a personal finance starter course to plan with confidence in Argentina.'
    }
  },
  es: {
    brand: 'Tu Progreso Hoy',
    nav: {
      home: 'Inicio',
      inflation: 'Inflación',
      course: 'Curso',
      resources: 'Recursos',
      contact: 'Contacto',
      privacy: 'Privacidad',
      terms: 'Términos'
    },
    hero: {
      heading: 'Iluminá tu ruta financiera en Argentina',
      subheading:
        'Tu Progreso Hoy integra inteligencia confiable ARS→USD con un curso inicial para que tomes decisiones responsables cada día.',
      primaryCta: 'Ver análisis de inflación',
      secondaryCta: 'Descubrir el curso',
      ariaCtaPrimary: 'Ir a la página de análisis de inflación',
      ariaCtaSecondary: 'Ir a la página del curso',
      badge: 'Tableros confiables de ARS→USD y presupuestos'
    },
    home: {
      heroBullets: [
        'Tableros transparentes que siguen ARS y USD en tiempo real.',
        'Tendencias contextualizadas que traducen movimientos macro en pasos claros.',
        'Fundamentos de finanzas personales diseñados para ingresos en Argentina.'
      ],
      statementsIntro: 'Compromisos que definen a Tu Progreso Hoy:',
      fixedStatementsTranslations: {
        'Datos verificados para planificar tu presupuesto.': 'Datos verificados para planificar tu presupuesto.',
        'Decisiones responsables, objetivos nítidos.': 'Decisiones responsables, objetivos nítidos.',
        'Conocimiento financiero impulsado por tendencias.': 'Conocimiento financiero impulsado por tendencias.',
        'Pasos acertados hoy, mejor futuro mañana.': 'Pasos acertados hoy, mejor futuro mañana.',
        'Análisis transparentes y datos de mercado para decidir con seguridad.':
          'Análisis transparentes y datos de mercado para decidir con seguridad.',
        'Información confiable que respalda elecciones responsables sobre tu dinero.':
          'Información confiable que respalda elecciones responsables sobre tu dinero.',
        'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.':
          'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
        'Plataforma educativa con datos esenciales, sin asesoría financiera directa.':
          'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.':
          'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
      },
      keyPromiseTitle: 'Por qué Tu Progreso Hoy es clave',
      keyPromises: [
        {
          title: 'Panoramas ARS→USD diarios',
          description:
            'Seguí referencias oficiales, indicadores paralelos y sentimiento de mercado en un centro de comando pensado para actuar.'
        },
        {
          title: 'Historias de datos orientadas a decisiones',
          description:
            'Los tableros destacan los movimientos que impactan tu poder de compra y tus hitos de presupuesto durante el mes.'
        },
        {
          title: 'Curso inicial de finanzas personales',
          description:
            'Construí hábitos con confianza gracias a lecciones que transforman la inflación en rutinas presupuestarias paso a paso.'
        }
      ],
      insightsHeadline: 'Información creada para la claridad',
      insightsIntro:
        'Narrativas visuales conectan variaciones del IPC, corredores de FX y tácticas de presupuesto para anticipar el mes que viene.',
      insightCards: [
        {
          title: 'Cronologías IPC & FX integradas',
          description:
            'Explorá publicaciones de IPC junto al tracker ARS→USD para contextualizar cómo se transmiten los anuncios de precios.',
          image: 'https://images.pexels.com/photos/669610/pexels-photo-669610.jpeg',
          alt: 'Analista financiero revisando gráficos en varios monitores'
        },
        {
          title: 'Escenarios de resiliencia de ingresos',
          description:
            'Simulaciones de flujo de caja mensual muestran cómo distintos niveles de ingresos se adaptan a la inflación y al tipo de cambio.',
          image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg',
          alt: 'Equipo colaborando sobre documentos financieros'
        },
        {
          title: 'Puntos de control del presupuesto',
          description:
            'Recordatorios alineados anclan cada módulo con hitos para ahorro, gastos y control de deudas en contexto argentino.',
          image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg',
          alt: 'Primer plano de persona trabajando con gráficos y laptop'
        }
      ],
      coursePreview: {
        title: 'De los datos al aprendizaje aplicado',
        description:
          'Avanzá en el curso inicial mientras aprovechás analíticas ARS→USD actualizadas, lecturas curadas y ejercicios guiados para tu hogar.',
        modules: [
          {
            title: 'Módulo 1 · Esenciales de inflación',
            points: [
              'Comprendé cómo la política monetaria y la logística influyen en el IPC.',
              'Descifrá referencias oficiales versus señales de mercado.'
            ]
          },
          {
            title: 'Módulo 2 · Arquitectura del presupuesto',
            points: [
              'Diseñá un presupuesto resiliente basado en proyecciones realistas en ARS.',
              'Definí categorías prioritarias y colchones para la volatilidad cambiaria.'
            ]
          },
          {
            title: 'Módulo 3 · Alineación del ahorro',
            points: [
              'Integra objetivos de ahorro con alertas de tendencia FX.',
              'Mapeá asignaciones a corto, mediano y largo plazo con nuestros tableros.'
            ]
          }
        ]
      },
      testimonials: {
        title: 'Testimonios de la comunidad',
        list: [
          {
            name: 'Lucía Fernández',
            role: 'Product Manager, Buenos Aires',
            quote:
              'El tracker diario ARS→USD me dio una referencia consistente para renegociar presupuestos sin suposiciones.'
          },
          {
            name: 'Martín Silva',
            role: 'Diseñador freelance, Rosario',
            quote:
              'Rearmé mi calendario de facturación gracias a los ejercicios del curso. Datos transparentes convirtieron el estrés en plan.'
          },
          {
            name: 'Agustina Romero',
            role: 'Emprendedora de hospitalidad, Córdoba',
            quote:
              'Tener contexto de IPC con checklists accionables me ayuda a comunicar ajustes de precios con calma.'
          }
        ]
      },
      trialForm: {
        title: 'Получить бесплатный пробный урок',
        description:
          'Accedé a la lección introductoria y recibí un correo de doble confirmación para activar tu experiencia.',
        nameLabel: 'Tu nombre',
        emailLabel: 'Email profesional o personal',
        submit: 'Activar mi prueba',
        consent:
          'Al enviar aceptás recibir un correo de confirmación. Completa el doble opt-in para acceder a la lección.',
        success:
          'Formulario enviado. Serás redirigido en instantes para continuar con la confirmación.',
        errors: {
          name: 'Por favor ingresá tu nombre.',
          email: 'Ingresá un email válido.'
        }
      },
      educationalNote: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
    },
    tracker: {
      title: 'Tracker ARS→USD',
      subtitle:
        'Indicadores combinados que integran referencias oficiales, sentimiento de mercado y poder de compra.',
      lastUpdated: 'Última actualización'
    },
    inflation: {
      title: 'Metodología de inflación y transparencia',
      description:
        'Conocé cómo Tu Progreso Hoy obtiene, depura y presenta la información para confiar en cada gráfico.',
      sections: [
        {
          title: 'Metodología de datos integrada',
          body: [
            'Combinamos publicaciones oficiales de IPC, comunicaciones cambiarias y consultoras privadas para construir una señal ARS→USD equilibrada.',
            'Los feeds de mercado se contrastan con series históricas auditadas; si detectamos anomalías activamos un protocolo de revisión manual documentado.'
          ]
        },
        {
          title: 'Tableros con contexto',
          body: [
            'Los dashboards articulan IPC, inflación mayorista y distintos corredores de ARS. Los tooltips señalan período, fuentes y cálculos.',
            'Capas de escenarios permiten simular el impacto de trayectorias FX en presupuestos de hogar: alquiler, alimentos y servicios.'
          ]
        },
        {
          title: 'Controles de calidad',
          body: [
            'Cada dataset pasa por scripts de validación que comparan contra umbrales base para evitar distorsiones por outliers.',
            'Fomentamos el feedback de la comunidad con un tablero público; cada corrección queda en nuestras notas de lanzamiento.'
          ]
        }
      ],
      chartTitle: 'Visualizá IPC vs corredores ARS',
      chartSubtitle:
        'Superponé IPC mensual y variación ARS→USD para enmarcar la dinámica de precios con el movimiento cambiario.',
      faqTitle: 'Preguntas frecuentes',
      faq: [
        {
          question: '¿Con qué frecuencia se actualiza el tracker ARS→USD?',
          answer:
            'Actualizamos los indicadores varias veces al día. Los tableros consolidados publican un resumen al cierre para decisiones consistentes.'
        },
        {
          question: '¿Puedo descargar los datasets?',
          answer:
            'Sí. Las personas suscritas pueden exportar CSV y acceder a notas metodológicas con fuentes y transformaciones aplicadas.'
        },
        {
          question: '¿Brindan asesoría financiera individual?',
          answer:
            'No. Tu Progreso Hoy es una plataforma educativa con datos esenciales. Recomendamos consultar profesionales habilitados para asesoría personalizada.'
        }
      ]
    },
    course: {
      title: 'Curso y plan de estudios',
      description:
        'Un recorrido modular que convierte los indicadores de inflación más recientes en rutinas prácticas de finanzas personales.',
      modules: [
        {
          title: 'Módulo 1 · Mapear el contexto',
          bullets: [
            'Analizá los impulsores de la volatilidad del ARS y la inflación argentina.',
            'Construí un dashboard personal de inflación con KPIs curados.'
          ]
        },
        {
          title: 'Módulo 2 · Arquitectura del presupuesto',
          bullets: [
            'Definí límites de gasto vinculados a calendarios de IPC.',
            'Diseñá colchones de emergencia alineados con corredores cambiarios.'
          ]
        },
        {
          title: 'Módulo 3 · Estrategias de ahorro y moneda',
          bullets: [
            'Diversificá tus ahorros entre exposiciones cambiarias de manera responsable.',
            'Utilizá alertas de tendencia para programar conversiones según tus metas.'
          ]
        },
        {
          title: 'Módulo 4 · Comunicación y planificación',
          bullets: [
            'Compartí actualizaciones de presupuesto con familia o equipos usando nuestros formatos.',
            'Convertí datos complejos en narrativas simples y accionables.'
          ]
        }
      ],
      targetAudienceTitle: '¿Para quién es ideal?',
      audience: [
        'Personas que cobran y planifican sus gastos en ARS.',
        'Freelancers que facturan en varias monedas y necesitan referencias estables.',
        'Hogares que buscan rutinas estructuradas basadas en datos transparentes.'
      ],
      cta: 'Ir al formulario de prueba gratis',
      ctaAria: 'Desplazarse al formulario de prueba gratuita en la página de inicio'
    },
    resources: {
      title: 'Recursos y glosario',
      description:
        'Profundizá con artículos, glosarios bilingües y plantillas accionables adaptadas a la realidad argentina.',
      articles: [
        {
          title: 'Cómo leer tableros ARS sin ruido',
          summary:
            'Guía para interpretar referencias cambiarias oficiales y alternativas y conectarlas con tus decisiones mensuales.',
          linkLabel: 'Leer recurso'
        },
        {
          title: 'Glosario · Claves de IPC y ARS (EN / ES)',
          summary:
            'Terminología imprescindible en ambos idiomas para navegar noticias, dashboards y comunicados de política.',
          linkLabel: 'Abrir glosario'
        },
        {
          title: 'Plantilla · Informe mensual de inflación',
          summary:
            'Estructurá seguimientos semanales con una plantilla que combina señales ARS→USD y checkpoints de finanzas personales.',
          linkLabel: 'Descargar plantilla'
        }
      ],
      bilingualNote:
        'Conocimiento financiero impulsado por tendencias. Información confiable que respalda elecciones responsables sobre tu dinero.'
    },
    contact: {
      title: 'Conectá con Tu Progreso Hoy',
      description:
        'Estamos en Buenos Aires y listos para acompañar tu aprendizaje con información transparente.',
      addressLabel: 'Dirección',
      phoneLabel: 'Teléfono',
      emailLabel: 'Email',
      mapTitle: 'Mapa de la ubicación en Buenos Aires',
      formHeading: 'Enviános un mensaje',
      confirmationNote:
        'Cada mensaje activa un email de doble confirmación. Revisá tu bandeja para completarlo.'
    },
    faq: {
      title: 'FAQ · Preguntas frecuentes',
      intro:
        'Descubrí cómo Tu Progreso Hoy te acompaña con insights basados en datos y contenido educativo.',
      items: [
        {
          question: '¿Qué incluye la suscripción?',
          answer:
            'Acceso a dashboards interactivos, curso inicial de finanzas personales, recursos curados y sesiones de preguntas y respuestas.'
        },
        {
          question: '¿El contenido está disponible en español?',
          answer:
            'Sí. Todo el material está disponible en inglés y español para equipos y hogares bilingües.'
        },
        {
          question: '¿Cómo protegen mis datos?',
          answer:
            'Aplicamos cifrado en tránsito, prácticas compatibles con GDPR y usamos tu email solo para comunicaciones opt-in.'
        }
      ]
    },
    footer: {
      address: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
      phone: '+54 11 5555-1234',
      email: 'info@tuprogresohoy.com',
      followUs: 'Redes',
      trustedData: 'Datos verificados para planificar tu presupuesto.',
      rights: 'Todos los derechos reservados.',
      disclaimerEn: 'Educational platform with essential data, no direct financial advisory.',
      disclaimerEs: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
      disclaimerRu: 'Образовательная платформа с ключевыми данными, без прямых финансовых услуг.'
    },
    forms: {
      emailInvalid: 'Ingresá un email válido.',
      requiredField: 'Este campo es obligatorio.',
      success: '¡Gracias! Revisá tu bandeja para confirmar la solicitud.'
    },
    meta: {
      description:
        'Tu Progreso Hoy ofrece dashboards ARS→USD transparentes, insights sobre inflación argentina y un curso inicial de finanzas personales.',
      keywords: 'argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, economic trends, datos confiables',
      ogTitle: 'Tu Progreso Hoy · Inteligencia de Inflación y Curso de Finanzas',
      ogDescription:
        'Dashboards ARS→USD transparentes y un curso de finanzas personales para planificar con confianza en Argentina.'
    }
  }
};

const fixedStatements = [
  'Datos verificados para planificar tu presupuesto.',
  'Decisiones responsables, objetivos nítidos.',
  'Conocimiento financiero impulsado por tendencias.',
  'Pasos acertados hoy, mejor futuro mañana.',
  'Análisis transparentes y datos de mercado para decidir con seguridad.',
  'Información confiable que respalda elecciones responsables sobre tu dinero.',
  'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
  'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
  'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
];

const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    const stored = window.localStorage.getItem('tph-language');
    return stored || 'en';
  });

  useEffect(() => {
    document.documentElement.lang = language === 'es' ? 'es-AR' : 'en';
    window.localStorage.setItem('tph-language', language);
  }, [language]);

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === 'en' ? 'es' : 'en'));
  };

  const value = useMemo(
    () => ({
      language,
      setLanguage,
      toggleLanguage,
      translations: translations[language],
      fixedStatements,
      allTranslations: translations
    }),
    [language]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => useContext(LanguageContext);

export { LanguageProvider };