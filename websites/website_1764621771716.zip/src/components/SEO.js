import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useLanguage } from './LanguageContext';

const domain = 'https://tuprogresohoy.com';

const SEO = ({ title, description, keywords, canonical }) => {
  const location = useLocation();
  const { allTranslations, language } = useLanguage();

  useEffect(() => {
    if (title) {
      document.title = title;
    }
  }, [title]);

  useEffect(() => {
    const setMeta = (name, content, attr = 'name') => {
      if (!content) return;
      let element = document.querySelector(`meta[${attr}="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    setMeta('description', description);
    setMeta('keywords', keywords);
    setMeta('og:title', title, 'property');
    setMeta('og:description', description, 'property');
    setMeta('og:url', canonical || `${domain}${location.pathname}`, 'property');
    setMeta('og:type', 'website', 'property');
    setMeta('twitter:card', 'summary_large_image', 'name');
    setMeta('twitter:title', title, 'name');
    setMeta('twitter:description', description, 'name');

    const canonicalHref = canonical || `${domain}${location.pathname}`;
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonicalHref);

    const ensureHrefLang = (hreflang, href) => {
      let link = document.querySelector(`link[rel="alternate"][hreflang="${hreflang}"]`);
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'alternate');
        link.setAttribute('hreflang', hreflang);
        document.head.appendChild(link);
      }
      link.setAttribute('href', href);
    };

    ensureHrefLang('en', `${domain}${location.pathname}`);
    ensureHrefLang('es-AR', `${domain}/es${location.pathname}`);
  }, [title, description, keywords, canonical, location.pathname]);

  useEffect(() => {
    const currentTranslations = Object.entries(allTranslations).map(([code, value]) => ({
      lang: code === 'es' ? 'es-AR' : 'en',
      description: value.meta.description,
      keywords: value.meta.keywords,
      ogTitle: value.meta.ogTitle,
      ogDescription: value.meta.ogDescription
    }));

    const setLangSpecific = () => {
      const current = currentTranslations.find((item) => item.lang === (language === 'es' ? 'es-AR' : 'en'));
      if (!current) return;
      const setMeta = (name, content, attr = 'name') => {
        if (!content) return;
        let element = document.querySelector(`meta[${attr}="${name}"]`);
        if (!element) {
          element = document.createElement('meta');
          element.setAttribute(attr, name);
          document.head.appendChild(element);
        }
        element.setAttribute('content', content);
      };
      setMeta('description', current.description);
      setMeta('keywords', current.keywords);
      setMeta('og:title', current.ogTitle, 'property');
      setMeta('og:description', current.ogDescription, 'property');
      setMeta('twitter:title', current.ogTitle, 'name');
      setMeta('twitter:description', current.ogDescription, 'name');
    };

    setLangSpecific();
  }, [language, allTranslations]);

  return null;
};

export default SEO;