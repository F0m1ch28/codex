import React from 'react';

const Card = ({ title, description, image, alt, children }) => {
  return (
    <article className="card">
      {image && (
        <div className="card-media">
          <img src={image} alt={alt || title} />
        </div>
      )}
      <div className="card-body">
        {title && <h3>{title}</h3>}
        {description && <p>{description}</p>}
        {children}
      </div>
    </article>
  );
};

export default Card;