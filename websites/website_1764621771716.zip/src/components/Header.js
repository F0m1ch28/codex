import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { useLanguage } from './LanguageContext';
import Button from './Button';

const Header = () => {
  const { translations, toggleLanguage, language } = useLanguage();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }

    return () => {
      document.body.classList.remove('no-scroll');
    };
  }, [menuOpen]);

  const navItems = [
    { to: '/', label: translations.nav.home },
    { to: '/inflation', label: translations.nav.inflation },
    { to: '/course', label: translations.nav.course },
    { to: '/resources', label: translations.nav.resources },
    { to: '/contact', label: translations.nav.contact }
  ];

  return (
    <header className="header">
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <div className="container header-container">
        <Link to="/" className="logo" aria-label="Tu Progreso Hoy Home">
          <div className="logo-mark">TPH</div>
          <div className="logo-text">
            <span>{translations.brand}</span>
            <small>{translations.hero.badge}</small>
          </div>
        </Link>

        <nav className="header-nav" aria-label="Primary navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
            >
              {item.label}
            </NavLink>
          ))}
          <NavLink to="/faq" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            FAQ
          </NavLink>
        </nav>

        <div className="header-actions">
          <Button
            variant="outline"
            aria-label={language === 'en' ? 'Switch to Spanish' : 'Cambiar a inglés'}
            onClick={toggleLanguage}
          >
            {language === 'en' ? 'ES' : 'EN'}
          </Button>
          <Button as={Link} to="/course" variant="primary" className="desktop-only">
            {translations.nav.course}
          </Button>
          <button
            className={`hamburger ${menuOpen ? 'is-active' : ''}`}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-label="Toggle navigation menu"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>

      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        {navItems.map((item) => (
          <NavLink key={item.to} to={item.to} className="mobile-link">
            {item.label}
          </NavLink>
        ))}
        <NavLink to="/faq" className="mobile-link">
          FAQ
        </NavLink>
        <Button as={Link} to="/course" variant="primary" className="mobile-cta">
          {translations.nav.course}
        </Button>
      </div>
    </header>
  );
};

export default Header;