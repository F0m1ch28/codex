import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from './LanguageContext';

const Footer = () => {
  const { translations } = useLanguage();

  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <h4>{translations.brand}</h4>
          <p className="footer-tagline">{translations.footer.trustedData}</p>
          <p className="footer-description">
            {translations.hero.subheading}
          </p>
        </div>

        <div>
          <h5>Navigate</h5>
          <ul>
            <li>
              <Link to="/">{translations.nav.home}</Link>
            </li>
            <li>
              <Link to="/inflation">{translations.nav.inflation}</Link>
            </li>
            <li>
              <Link to="/course">{translations.nav.course}</Link>
            </li>
            <li>
              <Link to="/resources">{translations.nav.resources}</Link>
            </li>
            <li>
              <Link to="/faq">FAQ</Link>
            </li>
          </ul>
        </div>

        <div>
          <h5>Compliance</h5>
          <ul>
            <li>
              <Link to="/privacy">{translations.nav.privacy}</Link>
            </li>
            <li>
              <Link to="/terms">{translations.nav.terms}</Link>
            </li>
            <li>
              <Link to="/cookies">Cookies</Link>
            </li>
            <li>
              <Link to="/sitemap.xml">Sitemap</Link>
            </li>
            <li>
              <Link to="/robots.txt">Robots</Link>
            </li>
          </ul>
        </div>

        <div>
          <h5>{translations.footer.followUs}</h5>
          <ul>
            <li>
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
                LinkedIn
              </a>
            </li>
            <li>
              <a href="https://twitter.com" target="_blank" rel="noreferrer">
                X / Twitter
              </a>
            </li>
            <li>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
                YouTube
              </a>
            </li>
          </ul>
          <div className="footer-contact">
            <p>{translations.footer.address}</p>
            <p>{translations.footer.phone}</p>
            <a href="mailto:info@tuprogresohoy.com">{translations.footer.email}</a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>
          © {currentYear} Tu Progreso Hoy · {translations.footer.rights}
        </p>
        <p>{translations.footer.disclaimerEn}</p>
        <p>{translations.footer.disclaimerEs}</p>
        <p>{translations.footer.disclaimerRu}</p>
      </div>
    </footer>
  );
};

export default Footer;