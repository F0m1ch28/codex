import React, { useState } from 'react';
import Button from './Button';

const emailRegex =
  /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\\.,;:\s@"]+\.)+[^<>()[\]\\.,;:\s@"]{2,})$/i;

const ContactForm = ({ labels }) => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) {
      currentErrors.name = labels.required;
    }
    if (!formData.email.trim()) {
      currentErrors.email = labels.required;
    } else if (!emailRegex.test(formData.email.trim())) {
      currentErrors.email = labels.emailInvalid;
    }
    if (!formData.message.trim()) {
      currentErrors.message = labels.required;
    }
    setErrors(currentErrors);
    return Object.keys(currentErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStatus('pending');
    setTimeout(() => {
      setStatus('success');
    }, 600);
  };

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    setErrors((prev) => ({ ...prev, [event.target.name]: '' }));
  };

  return (
    <form className="contact-form" onSubmit={handleSubmit} noValidate>
      <div className="form-field">
        <label htmlFor="contact-name">{labels.name}</label>
        <input
          id="contact-name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          autoComplete="name"
          required
        />
        {errors.name && <span className="error-text">{errors.name}</span>}
      </div>

      <div className="form-field">
        <label htmlFor="contact-email">{labels.email}</label>
        <input
          id="contact-email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          autoComplete="email"
          required
        />
        {errors.email && <span className="error-text">{errors.email}</span>}
      </div>

      <div className="form-field">
        <label htmlFor="contact-phone">{labels.phone}</label>
        <input
          id="contact-phone"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          autoComplete="tel"
        />
      </div>

      <div className="form-field">
        <label htmlFor="contact-message">{labels.message}</label>
        <textarea
          id="contact-message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          rows="5"
          required
        />
        {errors.message && <span className="error-text">{errors.message}</span>}
      </div>

      <p className="form-note">{labels.consent}</p>

      <Button type="submit" variant="primary">
        {labels.submit}
      </Button>

      <div className="form-feedback" aria-live="polite">
        {status === 'pending' && <p>{labels.pending}</p>}
        {status === 'success' && <p>{labels.success}</p>}
      </div>
    </form>
  );
};

export default ContactForm;