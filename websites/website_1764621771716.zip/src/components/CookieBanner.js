import React, { useEffect, useState } from 'react';
import Button from './Button';

const COOKIE_KEY = 'tph-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(COOKIE_KEY);
    if (!stored) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    window.localStorage.setItem(COOKIE_KEY, choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <h4>Cookies & analytics</h4>
        <p>
          We use cookies to understand how Tu Progreso Hoy is used and to improve the educational
          experience. You can accept or decline optional analytics cookies.
        </p>
        <div className="cookie-actions">
          <Button variant="secondary" onClick={() => handleChoice('declined')}>
            Decline
          </Button>
          <Button variant="primary" onClick={() => handleChoice('accepted')}>
            Accept
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;