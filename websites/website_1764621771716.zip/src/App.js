import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ModalDisclaimer from './components/ModalDisclaimer';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import ThankYou from './pages/ThankYou';
import Sitemap from './pages/Sitemap';
import Robots from './pages/Robots';
import FAQ from './pages/FAQ';

const App = () => {
  return (
    <div className="app-shell">
      <ScrollToTop />
      <Header />
      <main id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/inflation" element={<Inflation />} />
          <Route path="/course" element={<Course />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookies" element={<Cookies />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/sitemap.xml" element={<Sitemap />} />
          <Route path="/robots.txt" element={<Robots />} />
          <Route path="/faq" element={<FAQ />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ModalDisclaimer />
    </div>
  );
};

export default App;