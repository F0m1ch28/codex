import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './MethodologyPage.module.css';

const approach = [
  {
    title: 'Diagnostic onboarding',
    description:
      'We begin with a clarity session to understand your aspirations, learning style, and time availability. This informs a custom roadmap and recommended micro-prep modules.'
  },
  {
    title: 'Integrated delivery',
    description:
      'Mentors, career coaches, and learner success partners collaborate weekly to synchronise teaching, project feedback, and wellbeing support.'
  },
  {
    title: 'Evidence-based progression',
    description:
      'Every skill is assessed through tangible artefacts—code reviews, architecture diagrams, playbooks, or stakeholder presentations—ensuring evidence of mastery.'
  }
];

const processItems = [
  {
    title: 'Immersive learning labs',
    description:
      'Short lectures are followed by hands-on labs and code clinics so you can apply concepts immediately with mentor feedback.'
  },
  {
    title: 'Real-world projects',
    description:
      'Learners solve challenges sourced from our partner network. Deliverables are benchmarked against industry standards.'
  },
  {
    title: 'Reflection and iteration',
    description:
      'Weekly retrospectives help you reflect on growth areas, capture lessons learned, and plan the next sprint of development.'
  },
  {
    title: 'Career activation',
    description:
      'When you are ready, we support you with interview labs, portfolio coaching, and direct introductions to hiring partners.'
  }
];

const support = [
  {
    title: 'Career design lab',
    description:
      'Personal coaching sessions, CV refinement, and strategic job search planning aligned with Belgium’s regional tech ecosystems.'
  },
  {
    title: 'Mentor office hours',
    description:
      'Dedicated office hours with engineers, data scientists, and cloud architects so you never stay stuck for long.'
  },
  {
    title: 'Community platform',
    description:
      'A vibrant online campus with peer groups, alumni mentorship, resource libraries, and multilingual support.'
  }
];

const MethodologyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Our Methodology | IT Learning Hub Belgium</title>
      <meta
        name="description"
        content="Discover the learner-first methodology of IT Learning Hub Belgium, combining diagnostic onboarding, integrated delivery, and career activation."
      />
    </Helmet>
    <div className="container">
      <section className={styles.intro}>
        <h1 className="section-title">Learning designed for outcomes</h1>
        <p className={styles.introText}>
          Our methodology blends structured teaching, personalised coaching, and real-world challenges. We ensure
          every learner builds durable skills, confidence, and a portfolio that resonates with hiring managers.
        </p>
      </section>

      <section>
        <h2 className="section-title">How we work with you</h2>
        <div className={styles.approachGrid}>
          {approach.map((item) => (
            <article key={item.title} className={styles.approachCard}>
              <h3 className={styles.approachTitle}>{item.title}</h3>
              <p className={styles.approachDescription}>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection}>
        <h2 className="section-title">The IT Learning Hub experience</h2>
        <div className={styles.processList}>
          {processItems.map((item) => (
            <div key={item.title} className={styles.processItem}>
              <strong>{item.title}</strong>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="section-title">Support pillars</h2>
        <p className="section-subtitle">
          Guidance continues beyond the classroom. Our support structure keeps you focused, motivated, and connected.
        </p>
        <div className={styles.supportGrid}>
          {support.map((item) => (
            <article key={item.title} className={styles.supportCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  </div>
);

export default MethodologyPage;