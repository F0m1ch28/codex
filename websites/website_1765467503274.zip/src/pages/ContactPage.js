import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactPage.module.css';

const initialFormData = {
  name: '',
  email: '',
  phone: '',
  interest: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your full name.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.interest) {
      newErrors.interest = 'Select the area you are interested in.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Let us know how we can support you.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setIsSubmitted(true);
    setFormData(initialFormData);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact IT Learning Hub Belgium</title>
        <meta
          name="description"
          content="Contact IT Learning Hub Belgium to discuss IT courses, corporate training partnerships, or personalised coaching."
        />
      </Helmet>
      <div className="container">
        <section className={styles.wrapper}>
          <article className={styles.infoCard}>
            <h1 className="section-title">Let’s design your next learning step</h1>
            <p>
              Whether you are planning a career transition, upskilling your team, or exploring our corporate academies,
              our advisors are here to help.
            </p>
            <div className={styles.infoList}>
              <div className={styles.infoItem}>
                <span className={styles.infoLabel}>Address</span>
                <a
                  href="https://maps.google.com/?q=Avenue+de+la+Toison+d'Or+56,+1060+Brussels"
                  target="_blank"
                  rel="noreferrer"
                >
                  IT Learning Hub, Avenue de la Toison d'Or 56, 1060 Brussels, Belgium
                </a>
              </div>
              <div className={styles.infoItem}>
                <span className={styles.infoLabel}>Phone</span>
                <a href="tel:+3221234567">+32 2 123 45 67</a>
              </div>
              <div className={styles.infoItem}>
                <span className={styles.infoLabel}>Email</span>
                <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
              </div>
              <div className={styles.infoItem}>
                <span className={styles.infoLabel}>Office hours</span>
                <span>Monday to Friday · 09:00–18:00 CET</span>
              </div>
            </div>
            <p className={styles.note}>
              We aim to respond within two business days. For urgent enquiries, please call us directly.
            </p>
          </article>

          <article className={styles.formCard}>
            <h2 className="section-title">Send us a message</h2>
            {isSubmitted && (
              <div className={styles.successMessage}>
                Thank you! Your message has been received. A member of our team will reach out shortly.
              </div>
            )}
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.formRow}>
                <label className={styles.label} htmlFor="contact-name">
                  Full name *
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    className={styles.input}
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'contact-name-error' : undefined}
                  />
                  {errors.name && (
                    <span id="contact-name-error" className={styles.error}>
                      {errors.name}
                    </span>
                  )}
                </label>
                <label className={styles.label} htmlFor="contact-email">
                  Email *
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    className={styles.input}
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'contact-email-error' : undefined}
                  />
                  {errors.email && (
                    <span id="contact-email-error" className={styles.error}>
                      {errors.email}
                    </span>
                  )}
                </label>
              </div>
              <div className={styles.formRow}>
                <label className={styles.label} htmlFor="contact-phone">
                  Phone (optional)
                  <input
                    id="contact-phone"
                    name="phone"
                    type="tel"
                    className={styles.input}
                    value={formData.phone}
                    onChange={handleChange}
                  />
                </label>
                <label className={styles.label} htmlFor="contact-interest">
                  I’m interested in *
                  <select
                    id="contact-interest"
                    name="interest"
                    className={styles.select}
                    value={formData.interest}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.interest)}
                    aria-describedby={errors.interest ? 'contact-interest-error' : undefined}
                  >
                    <option value="" disabled>
                      Select an option
                    </option>
                    <option value="career-change">Career change programme</option>
                    <option value="skill-upgrade">Skill upgrade or certification</option>
                    <option value="corporate-training">Corporate training partnership</option>
                    <option value="other">Other enquiry</option>
                  </select>
                  {errors.interest && (
                    <span id="contact-interest-error" className={styles.error}>
                      {errors.interest}
                    </span>
                  )}
                </label>
              </div>
              <label className={styles.label} htmlFor="contact-message">
                Tell us about your goals *
                <textarea
                  id="contact-message"
                  name="message"
                  className={styles.textarea}
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'contact-message-error' : undefined}
                />
                {errors.message && (
                  <span id="contact-message-error" className={styles.error}>
                    {errors.message}
                  </span>
                )}
              </label>
              <button type="submit" className="btn btn-primary">
                Submit enquiry
              </button>
            </form>
          </article>
        </section>
      </div>
    </div>
  );
};

export default ContactPage;