import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | IT Learning Hub Belgium</title>
      <meta
        name="description"
        content="Privacy policy detailing how IT Learning Hub Belgium collects, processes, and protects personal data in line with GDPR."
      />
    </Helmet>
    <div className="container">
      <article className={styles.card}>
        <h1 className="section-title">Privacy Policy</h1>
        <p>Effective date: 5 June 2024</p>

        <div className={styles.section}>
          <h2>1. Data controller</h2>
          <p>
            IT Learning Hub Belgium (Avenue de la Toison d'Or 56, 1060 Brussels) is the data controller responsible for
            processing your personal data in accordance with the General Data Protection Regulation (GDPR).
          </p>
        </div>

        <div className={styles.section}>
          <h2>2. Data we collect</h2>
          <p>We collect and process the following categories of data:</p>
          <ul>
            <li>Identification details such as name, email address, and phone number.</li>
            <li>Professional information including role, skills, and learning objectives.</li>
            <li>Interaction data from learning platforms, mentoring sessions, and surveys.</li>
            <li>Technical data such as device type, browser, and usage analytics (via cookies).</li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>3. Purpose of processing</h2>
          <p>We use your data to:</p>
          <ul>
            <li>Manage programme enrolment and deliver personalised learning journeys.</li>
            <li>Facilitate mentoring, assessments, and certification support.</li>
            <li>Inform you about relevant events, resources, or updates based on expressed interests.</li>
            <li>Improve our services through analytics and learner feedback.</li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>4. Legal basis</h2>
          <p>
            Processing is based on your consent, legitimate interest in delivering education services, performance of a
            contract (programme participation), or compliance with legal obligations.
          </p>
        </div>

        <div className={styles.section}>
          <h2>5. Data retention</h2>
          <p>
            We retain learner records for up to five years after programme completion unless you request deletion earlier.
            Marketing preferences can be updated or withdrawn at any time.
          </p>
        </div>

        <div className={styles.section}>
          <h2>6. Data sharing</h2>
          <p>
            We only share personal data with trusted service providers (e.g., learning platforms, CRM solutions) under
            appropriate data processing agreements. Employer partners only receive information when you give explicit
            consent.
          </p>
        </div>

        <div className={styles.section}>
          <h2>7. International transfers</h2>
          <p>
            If data is transferred outside the European Economic Area, we ensure appropriate safeguards such as Standard
            Contractual Clauses or adequacy decisions are in place.
          </p>
        </div>

        <div className={styles.section}>
          <h2>8. Your rights</h2>
          <p>You may exercise the following rights at any time:</p>
          <ul>
            <li>Access, rectify, or delete your personal data.</li>
            <li>Restrict or object to processing.</li>
            <li>Data portability.</li>
            <li>Withdraw consent where processing is based on consent.</li>
            <li>Lodge a complaint with the Belgian Data Protection Authority.</li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>9. Contact</h2>
          <p>
            To exercise your rights or raise questions, email info@itlearninghub.be or write to IT Learning Hub Belgium,
            Avenue de la Toison d'Or 56, 1060 Brussels, Belgium.
          </p>
        </div>
      </article>
    </div>
  </div>
);

export default PrivacyPage;