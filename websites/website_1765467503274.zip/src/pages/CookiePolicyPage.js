import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | IT Learning Hub Belgium</title>
      <meta
        name="description"
        content="Cookie policy explaining how IT Learning Hub Belgium uses cookies and how you can manage your preferences."
      />
    </Helmet>
    <div className="container">
      <article className={styles.card}>
        <h1 className="section-title">Cookie Policy</h1>
        <p>Effective date: 5 June 2024</p>

        <div className={styles.section}>
          <h2>1. What are cookies?</h2>
          <p>
            Cookies are small text files placed on your device when you visit our website. They help us provide a secure
            and personalised experience.
          </p>
        </div>

        <div className={styles.section}>
          <h2>2. Cookies we use</h2>
          <ul>
            <li>
              <strong>Essential cookies</strong> enable core site functionality such as remembering your session and
              keeping forms secure.
            </li>
            <li>
              <strong>Analytics cookies</strong> help us understand how visitors interact with our site so we can improve
              content and usability.
            </li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>3. Managing cookies</h2>
          <p>
            You can accept or reject non-essential cookies through the banner on our site. Most browsers also allow you
            to control cookie settings, including deleting existing cookies or blocking future ones.
          </p>
        </div>

        <div className={styles.section}>
          <h2>4. Updates to this policy</h2>
          <p>
            We review this policy periodically. Updates will be published on this page with a revised effective date.
          </p>
        </div>

        <div className={styles.section}>
          <h2>5. Contact</h2>
          <p>
            For questions about our cookie usage, email info@itlearninghub.be or write to IT Learning Hub Belgium, Avenue
            de la Toison d'Or 56, 1060 Brussels, Belgium.
          </p>
        </div>
      </article>
    </div>
  </div>
);

export default CookiePolicyPage;