import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './HomePage.module.css';

const heroImageUrl =
  'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80';

const stats = [
  { value: '4,500+', label: 'Learners empowered across Belgium' },
  { value: '92%', label: 'Career transitions within 6 months' },
  { value: '18', label: 'Active industry alliances' }
];

const reasons = [
  {
    title: 'Seasoned IT mentors',
    description:
      'Learn directly from senior engineers and solution architects who design platforms for Belgium’s leading organisations.',
    icon: '01'
  },
  {
    title: 'Project-led mastery',
    description:
      'Deliver production-ready assignments with multidisciplinary squads, sprint rituals, and code reviews that mirror modern teams.',
    icon: '02'
  },
  {
    title: 'Career design lab',
    description:
      'Access personal coaching, interview studios, and curated networking events with employers seeking specialised tech talent.',
    icon: '03'
  },
  {
    title: 'Future-proof curriculum',
    description:
      'Stay ahead with modules aligned to EU digital frameworks, updated quarterly to reflect the realities of AI, cloud, and cyber domains.',
    icon: '04'
  }
];

const learningPaths = [
  {
    title: 'Full-Stack Development',
    tag: 'Career accelerator',
    description:
      'Master modern JavaScript tooling, micro frontends, resilient REST and GraphQL APIs, and collaborative delivery practices.'
  },
  {
    title: 'Data Science & AI Studio',
    tag: 'Specialisation',
    description:
      'Shape data-driven products with applied machine learning, MLOps pipelines, and responsible AI governance.'
  },
  {
    title: 'Cybersecurity Operations',
    tag: 'Professional track',
    description:
      'Design security architectures, monitor threat landscapes, and respond with playbooks trusted by Belgian SOC teams.'
  },
  {
    title: 'Cloud Engineering',
    tag: 'Certification-ready',
    description:
      'Architect secure deployments across Azure, AWS, and Google Cloud with infrastructure as code and observability essentials.'
  },
  {
    title: 'DevOps Automation',
    tag: 'Advanced practicum',
    description:
      'Implement CI/CD, container orchestration, and site reliability workflows aligned with ITIL and agile governance.'
  },
  {
    title: 'Digital Product Analytics',
    tag: 'Upskilling sprint',
    description:
      'Blend marketing data, product metrics, and experimentation to inform growth strategies for digital products.'
  }
];

const successStories = [
  {
    quote:
      'The coaching model made the transition from teaching to full-stack development achievable. Pair programming sessions and architecture critiques reflected the expectations of my new role.',
    name: 'Sophie Dumont',
    role: 'Junior Full-Stack Developer, Ghent',
    image: 'https://picsum.photos/200/200?random=310'
  },
  {
    quote:
      'Weekly labs on Splunk, Azure Sentinel, and incident simulations prepared me for the pace of a SOC. The career team opened doors to interviews I never thought possible.',
    name: 'Laurens Peeters',
    role: 'Security Analyst, Antwerp',
    image: 'https://picsum.photos/200/200?random=311'
  },
  {
    quote:
      'Combining cloud architecture mentoring with soft-skill coaching helped me lead client conversations confidently. Within months, I was guiding migration projects across Brussels.',
    name: 'Amira Haddad',
    role: 'Cloud Consultant, Brussels',
    image: 'https://picsum.photos/200/200?random=312'
  }
];

const processSteps = [
  {
    title: 'Discover',
    description:
      'We map your current capabilities, motivations, and sector trends to co-create a personalised learning plan.'
  },
  {
    title: 'Upskill',
    description:
      'Deep-dive into expert-led sessions, labs, and hackathons designed around real Belgian use cases and tooling.'
  },
  {
    title: 'Apply',
    description:
      'Build assessment-ready artefacts, showcase portfolios, and rehearse technical storytelling with mentors.'
  },
  {
    title: 'Accelerate',
    description:
      'Connect with employers, alumni mentors, and certification pathways that amplify your momentum.'
  }
];

const faqs = [
  {
    question: 'Who are your programmes designed for?',
    answer:
      'We support both early-career professionals and experienced specialists who want to reskill or deepen their expertise in areas such as software engineering, cloud, data, or cyber. Each cohort blends diverse backgrounds to mirror real-world teams.'
  },
  {
    question: 'Do I need prior technical experience?',
    answer:
      'Our diagnostic onboarding assesses your current skill set and recommends preparation resources where needed. Foundation modules, peer mentoring, and scaffolded projects ensure you can progress at a sustainable pace.'
  },
  {
    question: 'How are learning outcomes measured?',
    answer:
      'Outcomes are verified through project reviews, live demonstrations, code audits, scenario-based assessments, and feedback from industry partners. You receive detailed rubrics and guidance to iterate toward mastery.'
  },
  {
    question: 'What support is available after graduation?',
    answer:
      'Graduates gain lifetime access to our digital campus, job intelligence briefings, alumni networking events, and optional continued coaching to help navigate promotions or new responsibilities.'
  }
];

const blogPosts = [
  {
    title: 'Reskilling into tech roles across Belgium',
    date: 'May 28, 2024',
    excerpt: 'Five actionable steps to reposition your career for the Flemish and Walloon tech ecosystems.',
    slug: 'reskilling-in-belgium'
  },
  {
    title: 'Navigating multicloud certifications in 2024',
    date: 'May 14, 2024',
    excerpt: 'How to sequence Azure, AWS, and Google Cloud certifications based on your current role ambitions.',
    slug: 'navigating-cloud-certifications'
  },
  {
    title: 'Building a cyber resilience mindset',
    date: 'April 30, 2024',
    excerpt: 'Key practices to embed secure thinking into every sprint, even before you join a security team.',
    slug: 'building-cybersecurity-mindset'
  }
];

const partners = [
  {
    name: 'Microsoft Learn Partner',
    logo: 'https://dummyimage.com/160x80/2563eb/ffffff&text=Microsoft',
    alt: 'Microsoft Learn Partner logo'
  },
  {
    name: 'AWS Academy Belgium',
    logo: 'https://dummyimage.com/160x80/1d4ed8/ffffff&text=AWS+Academy',
    alt: 'AWS Academy Belgium logo'
  },
  {
    name: 'Google Cloud Skills Boost',
    logo: 'https://dummyimage.com/160x80/0e7490/ffffff&text=Google+Cloud',
    alt: 'Google Cloud Skills Boost logo'
  },
  {
    name: 'Cisco Networking Academy',
    logo: 'https://dummyimage.com/160x80/0f172a/ffffff&text=Cisco+NetAcad',
    alt: 'Cisco Networking Academy logo'
  },
  {
    name: 'VMware IT Academy',
    logo: 'https://dummyimage.com/160x80/1f2937/ffffff&text=VMware',
    alt: 'VMware IT Academy logo'
  }
];

const workshop = {
  title: 'Free Virtual Masterclass: Cloud Foundations for Modern Teams',
  date: '27 June 2024',
  time: '18:00 CET',
  facilitator: 'Hosted by Amira Haddad, Cloud Consultant and lead mentor',
  description:
    'A 90-minute live session that breaks down multicloud design principles, certification pathways, and migration checklists. Receive a practical toolkit and an invite to our cloud sandbox.'
};

const HomePage = () => {
  const [activeStoryIndex, setActiveStoryIndex] = useState(0);
  const [openFaqIndex, setOpenFaqIndex] = useState(null);

  useEffect(() => {
    const interval = setInterval(
      () => setActiveStoryIndex((prev) => (prev + 1) % successStories.length),
      9000
    );
    return () => clearInterval(interval);
  }, []);

  const handleFaqToggle = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const activeStory = successStories[activeStoryIndex];

  const handleBlogClick = (event) => {
    event.preventDefault();
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>IT Learning Hub Belgium | Future-Ready IT Education</title>
        <meta
          name="description"
          content="IT Learning Hub Belgium helps professionals master in-demand skills through industry-led IT courses, bootcamps, and personalised coaching across Belgium."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroText}>
              <span className={styles.heroEyebrow}>Empowering tech talent across Belgium</span>
              <h1 className={styles.heroTitle}>Transform Your Career with Future-Ready IT Education</h1>
              <p className={styles.heroDescription}>
                IT Learning Hub Belgium connects ambitious professionals with the coaching, projects, and
                community required to lead digital transformation. We combine world-class mentors with
                local industry partnerships to accelerate your impact.
              </p>
              <div className={styles.heroActions}>
                <Link to="/courses" className="btn btn-primary" aria-label="Explore our IT courses">
                  Explore Courses
                </Link>
                <Link to="/contact" className="btn btn-ghost" aria-label="Speak with a learning advisor">
                  Talk to an Advisor
                </Link>
              </div>
              <div className={styles.heroStats}>
                {stats.map((stat) => (
                  <div key={stat.label} className={styles.statCard}>
                    <p className={styles.statValue}>{stat.value}</p>
                    <p className={styles.statLabel}>{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className={styles.heroMedia}>
              <div className={styles.heroImage}>
                <img src={heroImageUrl} alt="Learners collaborating during an IT training session" />
              </div>
              <div className={styles.heroBadge}>Accredited by trusted global tech partners</div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <h2 className="section-title">Why learners choose IT Learning Hub</h2>
          <p className="section-subtitle">
            We blend Belgian market insight with international best practices to help you progress with clarity,
            confidence, and measurable outcomes.
          </p>
          <div className={styles.whyGrid}>
            {reasons.map((reason) => (
              <article key={reason.title} className={styles.whyCard}>
                <div className={styles.whyIcon}>{reason.icon}</div>
                <h3>{reason.title}</h3>
                <p>{reason.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.learningPaths}>
        <div className="container">
          <h2 className="section-title">Popular learning paths</h2>
          <p className="section-subtitle">
            Choose the pathway that matches your ambitions. Each track includes personal coaching, live labs,
            and employer-aligned projects.
          </p>
          <div className={styles.learningGrid}>
            {learningPaths.map((path) => (
              <article key={path.title} className={styles.learningCard}>
                <span className={styles.learningTag}>{path.tag}</span>
                <h3 className={styles.learningTitle}>{path.title}</h3>
                <p>{path.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <h2 className="section-title">Success stories from Belgium</h2>
          <p className="section-subtitle">
            Our alumni build meaningful careers in software, cloud, data, and cybersecurity roles across Brussels,
            Antwerp, Ghent, and beyond.
          </p>
          <article className={styles.testimonialCard}>
            <div className={styles.testimonialHeader}>
              <img
                className={styles.testimonialImage}
                src={activeStory.image}
                alt={`${activeStory.name} portrait`}
                loading="lazy"
              />
              <div>
                <p className={styles.testimonialAuthor}>{activeStory.name}</p>
                <p className={styles.testimonialRole}>{activeStory.role}</p>
              </div>
            </div>
            <p className={styles.testimonialQuote}>&ldquo;{activeStory.quote}&rdquo;</p>
            <div className={styles.testimonialNav}>
              <button
                type="button"
                className={styles.navButton}
                onClick={() =>
                  setActiveStoryIndex(
                    (prev) => (prev - 1 + successStories.length) % successStories.length
                  )
                }
                aria-label="View previous success story"
              >
                ‹
              </button>
              <button
                type="button"
                className={styles.navButton}
                onClick={() => setActiveStoryIndex((prev) => (prev + 1) % successStories.length)}
                aria-label="View next success story"
              >
                ›
              </button>
            </div>
          </article>
        </div>
      </section>

      <section className={styles.workshop}>
        <div className="container">
          <h2 className="section-title">Upcoming workshop</h2>
          <p className="section-subtitle">
            Join a complimentary session to sample our interactive format and meet our mentors.
          </p>
          <article className={styles.workshopCard}>
            <h3>{workshop.title}</h3>
            <div className={styles.workshopMeta}>
              <span>{workshop.date}</span>
              <span>{workshop.time}</span>
            </div>
            <p>{workshop.description}</p>
            <p className="section-subtitle" style={{ marginBottom: '0' }}>
              {workshop.facilitator}
            </p>
            <div className={styles.workshopMeta}>
              <Link to="/contact" className="btn btn-accent" aria-label="Register for the upcoming workshop">
                Reserve your seat
              </Link>
              <Link to="/courses" className="btn btn-ghost" aria-label="Explore related cloud courses">
                Explore cloud track
              </Link>
            </div>
          </article>
        </div>
      </section>

      <section className={styles.partners}>
        <div className="container">
          <h2 className="section-title">Trusted partners and accreditations</h2>
          <p className="section-subtitle">
            Our programmes align with international standards and are supported by respected technology organisations.
          </p>
          <div className={styles.partnersGrid}>
            {partners.map((partner) => (
              <div key={partner.name} className={styles.partnerCard}>
                <img src={partner.logo} alt={partner.alt} loading="lazy" />
                <p className={styles.partnerName}>{partner.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <h2 className="section-title">Your learning journey</h2>
          <p className="section-subtitle">
            A clear structure keeps you accountable while leaving space to personalise your pace and projects.
          </p>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.title} className={styles.processStep}>
                <span className={styles.stepNumber}>{step.title}</span>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <h2 className="section-title">Frequently asked questions</h2>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => (
              <div key={faq.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={openFaqIndex === index}
                >
                  <span>{faq.question}</span>
                  <span
                    className={`${styles.faqIcon} ${
                      openFaqIndex === index ? styles.faqIconOpen : ''
                    }`}
                    aria-hidden="true"
                  >
                    +
                  </span>
                </button>
                <div
                  className={`${styles.faqAnswer} ${
                    openFaqIndex === index ? styles.faqAnswerOpen : ''
                  }`}
                >
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <h2 className="section-title">Latest insights from our team</h2>
          <p className="section-subtitle">
            Stay informed with guidance on certifications, career transitions, and emerging technologies.
          </p>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.slug} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a
                  href={`/blog/${post.slug}`}
                  onClick={handleBlogClick}
                  className={styles.blogLink}
                  aria-label={`${post.title} article coming soon`}
                >
                  Article coming soon
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2 className={styles.ctaTitle}>Ready for a personalised course consultation?</h2>
            <p className={styles.ctaDescription}>
              Book a conversation with our learning advisors to assess your goals, clarify certification routes,
              and receive a tailored study plan aligned with the Belgian market.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contact" className="btn btn-primary" aria-label="Contact IT Learning Hub Belgium">
                Schedule a discovery call
              </Link>
              <Link to="/about" className="btn btn-ghost" aria-label="Learn more about IT Learning Hub Belgium">
                Discover our story
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;