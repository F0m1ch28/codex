import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TrainersPage.module.css';

const trainers = [
  {
    name: 'Lucas De Meyer',
    role: 'Lead Full-Stack Mentor',
    bio: 'Lucas is a senior software engineer specialising in modern JavaScript, microservices, and developer experience. He previously built enterprise applications for Brussels-based fintech scale-ups.',
    image: 'https://picsum.photos/200/200?random=420',
    badges: ['Microsoft Certified Trainer', 'AWS Community Builder']
  },
  {
    name: 'Ines Moreau',
    role: 'Head of Data Science Curriculum',
    bio: 'Ines combines experience in analytics consulting with a PhD in statistics. She guides learners through ethical and production-ready AI solutions.',
    image: 'https://picsum.photos/200/200?random=421',
    badges: ['TensorFlow Developer', 'European AI Ethics Advocate']
  },
  {
    name: 'Pieter Jacobs',
    role: 'Cybersecurity Mentor',
    bio: 'Pieter has led SOC teams across Belgium and Luxembourg. He coaches learners on threat hunting, incident response, and governance frameworks.',
    image: 'https://picsum.photos/200/200?random=422',
    badges: ['Cisco CCNP Security', 'ISC² CISSP']
  },
  {
    name: 'Sara Van Den Broeck',
    role: 'Cloud & DevOps Coach',
    bio: 'Sara designs multicloud architectures and automation frameworks for large enterprises. She mentors learners on infrastructure as code and reliability practices.',
    image: 'https://picsum.photos/200/200?random=423',
    badges: ['Azure Solutions Architect Expert', 'Certified Kubernetes Administrator']
  }
];

const TrainersPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Our Trainers | IT Learning Hub Belgium</title>
      <meta
        name="description"
        content="Meet the expert mentors guiding learners at IT Learning Hub Belgium across software, data, cybersecurity, and cloud disciplines."
      />
    </Helmet>
    <div className="container">
      <section>
        <h1 className="section-title">Mentors invested in your success</h1>
        <p className={styles.intro}>
          Our trainers have led complex digital initiatives across Belgium and beyond. They bring practical insight,
          constructive feedback, and a passion for inclusive education.
        </p>
        <div className={styles.trainerGrid}>
          {trainers.map((trainer) => (
            <article key={trainer.name} className={styles.trainerCard}>
              <div className={styles.trainerHeader}>
                <img
                  className={styles.trainerImage}
                  src={trainer.image}
                  alt={`${trainer.name} portrait`}
                  loading="lazy"
                />
                <div className={styles.trainerInfo}>
                  <h3 className={styles.trainerName}>{trainer.name}</h3>
                  <p className={styles.trainerRole}>{trainer.role}</p>
                </div>
              </div>
              <p className={styles.bio}>{trainer.bio}</p>
              <div className={styles.badgeList}>
                {trainer.badges.map((badge) => (
                  <span key={`${trainer.name}-${badge}`} className={styles.badge}>
                    {badge}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  </div>
);

export default TrainersPage;