import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const values = [
  {
    title: 'Learner-centric guidance',
    icon: '🎯',
    description:
      'We begin by understanding your ambitions, constraints, and prior experience. Every curriculum is modular so you can focus on the skills that accelerate your goals.'
  },
  {
    title: 'Industry alignment',
    icon: '🤝',
    description:
      'Our mentors, advisors, and employer partners shape each programme to reflect the real-world expectations of Belgian companies and European regulations.'
  },
  {
    title: 'Inclusive community',
    icon: '🌱',
    description:
      'We foster an environment where diverse perspectives thrive. Bilingual support and peer circles ensure everyone feels represented and heard.'
  },
  {
    title: 'Sustainable careers',
    icon: '⚙️',
    description:
      'Beyond landing a role, we equip you to stay relevant through continuous learning, ethical responsibility, and leadership readiness.'
  }
];

const timeline = [
  {
    year: '2016',
    description:
      'Founded in Brussels by educators and CTOs who wanted to close the digital skills gap between academia and industry.'
  },
  {
    year: '2018',
    description:
      'Launched our first bilingual bootcamp connecting Dutch- and French-speaking learners with shared projects.'
  },
  {
    year: '2020',
    description:
      'Rolled out a virtual campus, streaming labs, and remote coaching to maintain momentum during lockdown.'
  },
  {
    year: '2022',
    description:
      'Opened innovation labs in Antwerp and partnered with leading universities for applied research collaborations.'
  },
  {
    year: '2024',
    description:
      'Introduced AI governance and cyber range labs to respond to the fast-evolving needs of Belgian employers.'
  }
];

const team = [
  {
    name: 'Emma Verstraeten',
    role: 'Director of Learning Innovation',
    bio: 'Emma designs integrated curricula that bridge software engineering, data, and leadership capabilities. She previously led digital academies for a major Belgian bank.',
    image: 'https://picsum.photos/200/200?random=401'
  },
  {
    name: 'Jonas Maes',
    role: 'Head of Employer Partnerships',
    bio: 'Jonas connects our learner community with hiring managers across Brussels, Antwerp, and Ghent. He ensures every programme delivers tangible business value.',
    image: 'https://picsum.photos/200/200?random=402'
  },
  {
    name: 'Nadia Willems',
    role: 'Learner Experience Lead',
    bio: 'Nadia curates coaching, mental wellness resources, and alumni activities so learners feel supported from day one through long-term career growth.',
    image: 'https://picsum.photos/200/200?random=403'
  }
];

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About IT Learning Hub Belgium</title>
      <meta
        name="description"
        content="Discover how IT Learning Hub Belgium empowers professionals with industry-aligned IT education, supportive mentorship, and a vibrant community."
      />
    </Helmet>
    <div className="container">
      <section className={styles.section}>
        <article className={styles.introCard}>
          <h1 className="section-title">A community built to elevate Belgian tech talent</h1>
          <p className={styles.introText}>
            Founded in Brussels, IT Learning Hub Belgium brings together expert mentors, progressive employers,
            and learners who want to contribute meaningfully to the digital landscape. We believe education should be
            practical, inclusive, and designed around sustainable career journeys.
          </p>
          <p className={styles.introText}>
            Whether you are reskilling into software development or deepening expertise in cybersecurity,
            our programmes combine rigorous instruction with personalised coaching to unlock your full potential.
          </p>
        </article>
      </section>

      <section className={styles.section}>
        <h2 className="section-title">Our guiding principles</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <span className={styles.valueIcon} aria-hidden="true">{value.icon}</span>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className="section-title">Milestones that shaped our journey</h2>
        <article className={styles.timeline}>
          <p className={styles.introText}>
            Continuous iteration keeps our learning experience relevant. Here are a few highlights from our evolution.
          </p>
          <div className={styles.timelineList}>
            {timeline.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <div className={styles.timelineYear}>{item.year}</div>
                <div className={styles.timelineDescription}>{item.description}</div>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className={styles.section}>
        <h2 className="section-title">Leadership team</h2>
        <p className="section-subtitle">
          Our leadership team brings together strategic vision, educational expertise, and deep industry networks.
        </p>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img
                className={styles.teamImage}
                src={member.image}
                alt={`${member.name} portrait`}
                loading="lazy"
              />
              <h3 className={styles.teamName}>{member.name}</h3>
              <p className={styles.teamRole}>{member.role}</p>
              <p>{member.bio}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  </div>
);

export default AboutPage;