import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './TermsPage.module.css';

const TermsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Service | IT Learning Hub Belgium</title>
      <meta
        name="description"
        content="Terms of service governing the use of IT Learning Hub Belgium programmes, platforms, and community resources."
      />
    </Helmet>
    <div className="container">
      <article className={styles.card}>
        <h1 className="section-title">Terms of Service</h1>
        <p>Effective date: 5 June 2024</p>

        <div className={styles.section}>
          <h2>1. Agreement overview</h2>
          <p>
            These Terms of Service govern your access to and participation in IT Learning Hub Belgium programmes,
            digital platforms, and community events. By enrolling in a programme or using our resources, you agree to
            comply with these terms and any guidelines shared during your learning experience.
          </p>
        </div>

        <div className={styles.section}>
          <h2>2. Eligibility and enrolment</h2>
          <p>
            Learners must be at least 18 years old or have explicit parental consent. During enrolment you agree to
            provide accurate information regarding your background and learning objectives so we can support you
            effectively.
          </p>
        </div>

        <div className={styles.section}>
          <h2>3. Platform and community use</h2>
          <p>
            Access credentials for our learning platforms are personal and non-transferable. You agree not to share
            login details, distribute course materials externally, or engage in behaviour that may disrupt the learning
            experience of others.
          </p>
        </div>

        <div className={styles.section}>
          <h2>4. Intellectual property</h2>
          <p>
            All curriculum content, recordings, and documentation provided by IT Learning Hub Belgium remain our
            intellectual property or that of our partners. You may use resources for personal learning purposes only.
          </p>
        </div>

        <div className={styles.section}>
          <h2>5. Learner responsibilities</h2>
          <p>
            To ensure an inclusive and productive community, learners agree to:
          </p>
          <ul className={styles.list}>
            <li>Respect peers, mentors, and collaborators at all times.</li>
            <li>Submit original work and credit sources or collaborators where appropriate.</li>
            <li>Participate actively in sessions and communicate conflicts in advance.</li>
            <li>Maintain confidentiality regarding employer projects or sensitive data.</li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>6. Assessment, certifications, and outcomes</h2>
          <p>
            Programme completion is based on demonstrated competencies, project submissions, and mentor evaluations.
            We do not guarantee employment; however, we provide coaching, introductions, and resources to support your
            career goals.
          </p>
        </div>

        <div className={styles.section}>
          <h2>7. Limitation of liability</h2>
          <p>
            IT Learning Hub Belgium is not liable for indirect, incidental, or consequential damages arising from your
            participation. Our total liability is limited to the scope permitted by Belgian law.
          </p>
        </div>

        <div className={styles.section}>
          <h2>8. Governing law</h2>
          <p>
            These terms are governed by the laws of Belgium. Any disputes will be handled by the competent courts of
            Brussels.
          </p>
        </div>

        <div className={styles.section}>
          <h2>9. Contact</h2>
          <p>
            If you have questions about these terms, please <Link to="/contact">contact our team</Link> or email
            info@itlearninghub.be.
          </p>
        </div>
      </article>
    </div>
  </div>
);

export default TermsPage;