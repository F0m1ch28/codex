import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './CoursesPage.module.css';

const courses = [
  {
    title: 'Full-Stack Web Engineering Programme',
    badge: 'Career accelerator',
    meta: ['24-week hybrid', 'Project-based', 'Mentor-led'],
    description:
      'Build resilient web applications using TypeScript, React, Node.js, and automated testing. Collaborate with designers and product owners to deliver production-ready experiences.',
    skills: ['TypeScript & React', 'Node.js & GraphQL', 'Automated testing', 'CI/CD pipelines', 'Cloud deployment']
  },
  {
    title: 'Data Science & AI Innovation Lab',
    badge: 'Specialisation',
    meta: ['20-week blended', 'Industry dataset', 'Ethical AI'],
    description:
      'Transform data into strategic insight with Python, ML Ops, and responsible AI design. Engage with Belgian organisations tackling healthcare, finance, and sustainability challenges.',
    skills: ['Python & SQL', 'Machine learning', 'MLOps tooling', 'Data storytelling', 'AI ethics']
  },
  {
    title: 'Cybersecurity Operations & Resilience',
    badge: 'Professional track',
    meta: ['16-week immersive', 'Incident response', 'Blue-team labs'],
    description:
      'Master threat detection, security architecture, and governance. Practice playbooks aligned with ISO 27001 and NIS2 requirements through incident simulations.',
    skills: ['Security monitoring', 'Network defence', 'Incident response', 'Risk management', 'Compliance frameworks']
  },
  {
    title: 'Cloud Engineering & Architecture',
    badge: 'Certification-ready',
    meta: ['18-week hybrid', 'Multicloud', 'Hands-on labs'],
    description:
      'Design and optimise cloud solutions on Azure, AWS, and Google Cloud. Learn infrastructure as code, cost governance, and observability through guided labs.',
    skills: ['Azure/AWS/GCP', 'Terraform & IaC', 'Container orchestration', 'Observability', 'FinOps foundations']
  },
  {
    title: 'DevOps Automation Studio',
    badge: 'Advanced practicum',
    meta: ['12-week evening', 'Automation-first', 'Team coaching'],
    description:
      'Implement continuous delivery pipelines, monitoring, and SRE practices that enable high-performing engineering teams across Belgium.',
    skills: ['CI/CD', 'Kubernetes', 'Automation scripts', 'Platform reliability', 'SecDevOps']
  },
  {
    title: 'Digital Product Analytics Sprint',
    badge: 'Upskilling',
    meta: ['8-week evening', 'Cross-functional', 'Data storytelling'],
    description:
      'Align marketing, product, and engineering stakeholders with shared metrics and experimentation frameworks that drive adoption and retention.',
    skills: ['Product analytics', 'Customer journey mapping', 'Experiment design', 'Dashboarding', 'Stakeholder facilitation']
  }
];

const CoursesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>IT Courses & Learning Paths | IT Learning Hub Belgium</title>
      <meta
        name="description"
        content="Explore IT Learning Hub Belgium courses covering full-stack development, data science, cybersecurity, cloud engineering, DevOps, and digital product analytics."
      />
    </Helmet>
    <div className="container">
      <section>
        <h1 className="section-title">Programmes designed around real industry needs</h1>
        <p className={styles.intro}>
          Each pathway combines live expert sessions, guided labs, and portfolio projects that mirror the expectations
          of Belgian employers. Learners receive coaching, certification guidance, and access to our digital campus.
        </p>
        <div className={styles.courseGrid}>
          {courses.map((course) => (
            <article key={course.title} className={styles.courseCard}>
              <span className={styles.badge}>{course.badge}</span>
              <h3 className={styles.courseTitle}>{course.title}</h3>
              <div className={styles.courseMeta}>
                {course.meta.map((item) => (
                  <span key={`${course.title}-${item}`}>{item}</span>
                ))}
              </div>
              <p className={styles.courseDescription}>{course.description}</p>
              <div className={styles.tagList}>
                {course.skills.map((skill) => (
                  <span key={`${course.title}-${skill}`} className={styles.tag}>
                    {skill}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className={styles.ctaCard}>
        <h2 className="section-title">Need help selecting the right path?</h2>
        <p className={styles.courseDescription}>
          Our advisors analyse your goals, time commitment, and preferred learning style to recommend the perfect match.
        </p>
        <Link to="/contact" className="btn btn-primary" aria-label="Contact us to plan your course">
          Plan a course consultation
        </Link>
      </section>
    </div>
  </div>
);

export default CoursesPage;