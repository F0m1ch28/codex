import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem('itlhb-cookie-consent');
    if (!stored) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('itlhb-cookie-consent', 'accepted');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.bannerText}>
        We use cookies to personalise your learning experience, enhance site navigation, and analyse our traffic patterns.
        Review how we handle data in our cookie policy.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.acceptButton} onClick={handleAccept}>
          Accept
        </button>
        <Link to="/cookie-policy" className={styles.policyLink}>
          Review policy
        </Link>
      </div>
    </div>
  );
};

export default CookieBanner;