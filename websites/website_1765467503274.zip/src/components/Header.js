import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/about', label: 'About' },
  { path: '/courses', label: 'Courses' },
  { path: '/methodology', label: 'Methodology' },
  { path: '/trainers', label: 'Trainers' },
  { path: '/contact', label: 'Contact' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={styles.header}>
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="IT Learning Hub Belgium home">
            IT <span className={styles.logoStrong}>Learning Hub</span>
          </Link>
          <div className={styles.nav}>
            <button
              type="button"
              className={`${styles.navToggle} ${menuOpen ? styles.navToggleActive : ''}`}
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-expanded={menuOpen}
              aria-controls="primary-navigation"
              aria-label="Toggle primary navigation"
            >
              <span className={styles.navToggleIcon} />
            </button>
            <nav aria-label="Primary navigation">
              <ul
                id="primary-navigation"
                className={`${styles.navList} ${menuOpen ? styles.navListOpen : ''}`}
              >
                {navLinks.map((link) => (
                  <li key={link.path}>
                    <NavLink
                      end={link.path === '/'}
                      to={link.path}
                      className={({ isActive }) =>
                        `${styles.navLink} ${isActive ? styles.active : ''}`
                      }
                    >
                      {link.label}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;