import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.top}>
        <div className={styles.brand}>
          <div className={styles.brandTitle}>IT Learning Hub Belgium</div>
          <p className={styles.brandDescription}>
            We help aspiring and established professionals across Belgium gain the IT skills, certifications,
            and confidence required to thrive in a digital-first economy.
          </p>
          <p className={styles.brandDescription}>
            Avenue de la Toison d'Or 56, 1060 Brussels, Belgium
          </p>
          <div className={styles.socialList}>
            <a
              className={styles.socialButton}
              href="https://www.linkedin.com"
              target="_blank"
              rel="noreferrer"
              aria-label="IT Learning Hub Belgium on LinkedIn"
            >
              in
            </a>
            <a
              className={styles.socialButton}
              href="https://www.youtube.com"
              target="_blank"
              rel="noreferrer"
              aria-label="IT Learning Hub Belgium on YouTube"
            >
              ▶
            </a>
            <a
              className={styles.socialButton}
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              aria-label="IT Learning Hub Belgium on GitHub"
            >
              {"</>"}
            </a>
          </div>
        </div>
        <div>
          <h3 className={styles.linksTitle}>Navigate</h3>
          <div>
            <Link to="/" className={styles.link}>Home</Link>
            <Link to="/about" className={styles.link}>About</Link>
            <Link to="/courses" className={styles.link}>Courses</Link>
            <Link to="/methodology" className={styles.link}>Methodology</Link>
            <Link to="/trainers" className={styles.link}>Trainers</Link>
            <Link to="/contact" className={styles.link}>Contact</Link>
          </div>
        </div>
        <div>
          <h3 className={styles.linksTitle}>Policies & Support</h3>
          <div>
            <Link to="/terms" className={styles.link}>Terms of Service</Link>
            <Link to="/privacy" className={styles.link}>Privacy Policy</Link>
            <Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link>
            <a href="mailto:info@itlearninghub.be" className={styles.link}>info@itlearninghub.be</a>
            <a href="tel:+3221234567" className={styles.link}>+32 2 123 45 67</a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} IT Learning Hub Belgium. All rights reserved.</p>
        <div className={styles.bottomLinks}>
          <Link to="/terms">Terms</Link>
          <Link to="/privacy">Privacy</Link>
          <Link to="/cookie-policy">Cookies</Link>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;