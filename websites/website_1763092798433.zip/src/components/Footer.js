import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <h3>ArtVision Studio</h3>
          <p>
            Креативная дизайн-студия, создающая выразительный визуальный язык
            брендов и продуктов.
          </p>
        </div>

        <div className={styles.contact}>
          <h4>Контакты</h4>
          <ul>
            <li>ул. Творческая, 15, Москва</li>
            <li><a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
            <li><a href="mailto:hello@artvision.ru">hello@artvision.ru</a></li>
          </ul>
        </div>

        <div className={styles.links}>
          <h4>Информация</h4>
          <ul>
            <li>
              <Link to="/privacy">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/terms">Условия использования</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Политика cookies</Link>
            </li>
          </ul>
        </div>
      </div>

      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} ArtVision Studio. Все права защищены.</span>
      </div>
    </footer>
  );
}

export default Footer;