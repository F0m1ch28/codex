import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const handleClose = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <NavLink to="/" className={styles.logo} onClick={handleClose}>
          ArtVision Studio
        </NavLink>

        <button
          className={styles.navToggle}
          onClick={handleToggle}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Переключить меню"
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              isActive
                ? `${styles.navLink} ${styles.active}`
                : styles.navLink
            }
            onClick={handleClose}
          >
            Главная
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) =>
              isActive
                ? `${styles.navLink} ${styles.active}`
                : styles.navLink
            }
            onClick={handleClose}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) =>
              isActive
                ? `${styles.navLink} ${styles.active}`
                : styles.navLink
            }
            onClick={handleClose}
          >
            О нас
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) =>
              isActive
                ? `${styles.navLink} ${styles.active}`
                : styles.navLink
            }
            onClick={handleClose}
          >
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default Header;