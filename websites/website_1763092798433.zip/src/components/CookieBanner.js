import { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'artvision-cookie-consent';

const defaultPrefs = {
  necessary: true,
  analytics: false,
  marketing: false,
};

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState(defaultPrefs);

  useEffect(() => {
    const storedPrefs = localStorage.getItem(STORAGE_KEY);
    if (storedPrefs) {
      setIsVisible(false);
      setPreferences(JSON.parse(storedPrefs));
    } else {
      setIsVisible(true);
    }
  }, []);

  const handleAcceptAll = () => {
    const acceptedPrefs = { necessary: true, analytics: true, marketing: true };
    setPreferences(acceptedPrefs);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(acceptedPrefs));
    setIsVisible(false);
  };

  const handleSave = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
    setIsVisible(false);
    setShowSettings(false);
  };

  const handleTogglePreference = (key) => {
    if (key === 'necessary') return;
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <h4>Мы заботимся о ваших данных</h4>
        <p>
          Используем cookies для персонализации, аналитики и улучшения работы сайта.
          Вы можете настроить предпочтения или принять все cookies.
        </p>
        {showSettings && (
          <div className={styles.settings}>
            <label className={styles.option}>
              <input type="checkbox" checked disabled /> Необходимые cookies (обязательные)
            </label>
            <label className={styles.option}>
              <input
                type="checkbox"
                checked={preferences.analytics}
                onChange={() => handleTogglePreference('analytics')}
              />
              Аналитические cookies
            </label>
            <label className={styles.option}>
              <input
                type="checkbox"
                checked={preferences.marketing}
                onChange={() => handleTogglePreference('marketing')}
              />
              Маркетинговые cookies
            </label>
          </div>
        )}
      </div>

      <div className={styles.actions}>
        {!showSettings && (
          <button
            type="button"
            className={styles.secondaryButton}
            onClick={() => setShowSettings(true)}
          >
            Настроить
          </button>
        )}
        {showSettings ? (
          <button type="button" className={styles.primaryButton} onClick={handleSave}>
            Сохранить выбор
          </button>
        ) : (
          <button type="button" className={styles.primaryButton} onClick={handleAcceptAll}>
            Принять все
          </button>
        )}
      </div>
    </div>
  );
}

export default CookieBanner;