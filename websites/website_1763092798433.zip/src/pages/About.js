import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Анна Воронова',
    role: 'Креативный директор',
    bio: '10 лет в бренд-стратегиях, отвечает за визуальную концепцию и креатив.',
    image: 'https://picsum.photos/seed/team1/320/320',
  },
  {
    name: 'Дмитрий Лебедев',
    role: 'Директор по продукту',
    bio: 'Специалист по UX/UI и цифровым экосистемам. Авторитет в области сервис-дизайна.',
    image: 'https://picsum.photos/seed/team2/320/320',
  },
  {
    name: 'Мария Соколова',
    role: 'Арт-директор',
    bio: 'Занимается визуальной режиссурой проектов, отвечает за качество графики и motion.',
    image: 'https://picsum.photos/seed/team3/320/320',
  },
  {
    name: 'Игорь Богданов',
    role: 'Lead Designer',
    bio: 'Создает дизайн-системы и интерфейсы, курирует команду дизайнеров проекта.',
    image: 'https://picsum.photos/seed/team4/320/320',
  },
];

function About() {
  return (
    <>
      <Helmet>
        <title>О студии ArtVision — команда и философия</title>
        <meta
          name="description"
          content="История ArtVision Studio, подход к работе и команда дизайнеров, стратегов и продюсеров."
        />
      </Helmet>

      <section className={styles.intro}>
        <div className="container">
          <h1>О студии</h1>
          <p>
            ArtVision Studio появилась как коллаборация дизайнеров, стратегов и
            продюсеров, которые верят в силу визуальных историй. Мы создаем бренды и
            цифровые продукты, которые помогают компаниям выделяться и развивать
            отношения с аудиторией.
          </p>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2>Наш подход</h2>
              <p>
                Мы работаем на стыке аналитики и креатива. Уверены, что глубокое
                понимание бизнеса и пользователей — основа сильного дизайна. Поэтому мы
                начинаем с исследования, выстраиваем стратегию, а затем ищем наиболее
                выразительные визуальные формы.
              </p>
              <p>
                Прозрачность процессов, сокомандничество и внимательность к деталям
                помогают нам сохранять высокий стандарт качества и вовлеченности.
              </p>
            </div>
            <div className={styles.highlight}>
              <h3>Факты</h3>
              <ul>
                <li>Работаем с брендами от стартапов до корпораций</li>
                <li>Выстраиваем долгосрочные отношения и поддержку</li>
                <li>Создаем кастомные команды под проект</li>
                <li>Участвуем в международных фестивалях дизайна</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.teamHeader}>
            <span>Команда</span>
            <h2>Люди, которые создают дизайн ArtVision</h2>
            <p>
              Мы собрали мультидисциплинарную команду специалистов, которые умеют
              слушать бизнес, понимать аудиторию и создавать впечатляющие визуальные
              решения.
            </p>
          </div>

          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.card}>
                <img src={member.image} alt={`${member.name} — ${member.role}`} loading="lazy" />
                <div className={styles.cardContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default About;