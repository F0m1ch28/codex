import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Политика cookies — ArtVision Studio</title>
        <meta
          name="description"
          content="Политика использования файлов cookies на сайте ArtVision Studio."
        />
      </Helmet>

      <section className={styles.legal}>
        <div className="container">
          <h1>Политика cookies</h1>
          <p className={styles.updated}>Обновлено: 12 апреля 2024 года</p>

          <h2>1. Что такое cookies</h2>
          <p>
            Cookies — это небольшие текстовые файлы, которые сохраняются на вашем
            устройстве и помогают нам обеспечить корректную работу сайта, анализировать
            статистику и улучшать пользовательский опыт.
          </p>

          <h2>2. Какие cookies мы используем</h2>
          <ul>
            <li><strong>Необходимые:</strong> обеспечивают базовую функциональность сайта.</li>
            <li><strong>Аналитические:</strong> помогают анализировать посещаемость и поведение пользователей.</li>
            <li><strong>Маркетинговые:</strong> используются для персонализации коммуникаций (включаются только при согласии).</li>
          </ul>

          <h2>3. Управление cookies</h2>
          <p>
            Вы можете изменить настройки cookies в баннере на сайте или в настройках
            браузера. Обратите внимание, что отключение необходимых cookies может
            повлиять на функциональность ресурса.
          </p>

          <h2>4. Контакты</h2>
          <p>
            По вопросам использования cookies свяжитесь с нами по адресу{' '}
            <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;