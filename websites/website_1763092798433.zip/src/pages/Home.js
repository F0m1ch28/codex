import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

function Home() {
  return (
    <>
      <Helmet>
        <title>ArtVision Studio — дизайн, который усиливает бренды</title>
        <meta
          name="description"
          content="Главная страница ArtVision Studio. Портфолио, ключевые услуги и философия студии."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.tagline}>Креатив. Стратегия. Технологии.</span>
            <h1>
              Дизайн, который помогает брендам звучать громче и выглядеть смелее.
            </h1>
            <p>
              ArtVision Studio объединяет стратегию, эстетику и цифровой опыт, чтобы
              создавать комплексные решения — от айдентики и веб-дизайна до дизайн-систем
              и мультимедийных презентаций.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className={styles.primaryAction}>
                Обсудить проект
              </Link>
              <Link to="/services" className={styles.secondaryAction}>
                Все услуги
              </Link>
            </div>

            <dl className={styles.stats}>
              <div>
                <dt>120+</dt>
                <dd>реализованных проектов</dd>
              </div>
              <div>
                <dt>15</dt>
                <dd>отраслей в портфолио</dd>
              </div>
              <div>
                <dt>9</dt>
                <dd>лет опыта команды</dd>
              </div>
            </dl>
          </div>

          <div className={styles.heroGallery}>
            <img
              src="https://picsum.photos/seed/artvision1/540/760"
              alt="Пример стильного брендинга от ArtVision Studio"
              className={styles.heroImageLarge}
              loading="lazy"
            />
            <img
              src="https://picsum.photos/seed/artvision2/420/420"
              alt="Визуальная концепция веб-сайта"
              className={styles.heroImageSmall}
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span>Услуги</span>
            <h2>Комплексный дизайн, ориентированный на результат</h2>
            <p>
              Мы соединяем аналитику, эстетику и технологичность, чтобы создавать
              визуальные решения, которые делают бренды узнаваемыми и любимыми.
            </p>
          </div>

          <div className={styles.serviceGrid}>
            <article>
              <span className={styles.icon}>✨</span>
              <h3>Брендинг и айдентика</h3>
              <p>
                Разрабатываем стратегию бренда, визуальную айдентику и гайдлайны,
                которые помогают компаниям говорить одним убедительным голосом.
              </p>
            </article>

            <article>
              <span className={styles.icon}>🖥️</span>
              <h3>Цифровой продукт</h3>
              <p>
                Проектируем UX/UI для веб-сайтов, сервисов и мобильных приложений с
                акцентом на удобство, вовлечение и конверсию.
              </p>
            </article>

            <article>
              <span className={styles.icon}>🎨</span>
              <h3>Графика и контент</h3>
              <p>
                Создаем презентации, промо-материалы и визуальный контент, который
                поддерживает стратегию бренда в разных каналах.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.portfolio}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span>Портфолио</span>
            <h2>Истории наших клиентов</h2>
            <p>
              Каждый проект — это диалог бренда со своей аудиторией. Мы помогаем
              добавить в этот диалог смысл, эстетику и эмоцию.
            </p>
          </div>

          <div className={styles.portfolioGrid}>
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <figure key={item} className={styles.portfolioCard}>
                <img
                  src={`https://picsum.photos/seed/portfolio${item}/640/480`}
                  alt={`Дизайн-проект ArtVision Studio №${item}`}
                  loading="lazy"
                />
                <figcaption>
                  <h4>Проект #{item}</h4>
                  <p>Фирменный стиль и цифровой опыт для развивающегося бренда.</p>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.valuesContent}>
            <h2>Что делает нас сильнее</h2>
            <p>
              Команда ArtVision Studio — это дизайнеры, стратеги и продюсеры, которые
              объединяют опыт в бренд-коммуникациях, digital и визуальных искусствах.
              Мы погружаемся в задачи клиента, работаем прозрачно и говорим на языке
              бизнеса, сохраняя креативный драйв.
            </p>
            <ul>
              <li>Работаем в связке с командами маркетинга и продуктами</li>
              <li>Строим долгосрочные отношения с клиентами и партнерами</li>
              <li>Собираем мультидисциплинарные команды под проекты</li>
            </ul>
            <Link to="/about" className={styles.secondaryAction}>
              Узнать больше о студии
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;