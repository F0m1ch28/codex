import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

function Services() {
  return (
    <>
      <Helmet>
        <title>Услуги ArtVision Studio — брендинг, веб-дизайн, графика</title>
        <meta
          name="description"
          content="Подробный список услуг ArtVision Studio: брендинг, UX/UI, визуальные коммуникации и сопровождение проектов."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Услуги</h1>
          <p>
            Мы создаем комплексные дизайн-решения: от первичной стратегии бренда и
            цифровой архитектуры до сопровождения и развития визуальной системы.
          </p>
        </div>
      </section>

      <section className={styles.catalog}>
        <div className="container">
          <div className={styles.columns}>
            <article>
              <h2>Брендинг и стратегия</h2>
              <ul>
                <li>Исследования и позиционирование бренда</li>
                <li>Названия, вербальный стиль и tone of voice</li>
                <li>Фирменный стиль, логотип, визуальные коды</li>
                <li>Brand book, гайдлайны, дизайн-системы</li>
              </ul>
            </article>

            <article>
              <h2>Digital дизайн</h2>
              <ul>
                <li>UX-исследования и CJM</li>
                <li>Прототипирование и дизайн веб-сайтов</li>
                <li>UI для продуктов и сервисов</li>
                <li>Интерактивные презентации и концепты</li>
              </ul>
            </article>

            <article>
              <h2>Коммуникации и поддержка</h2>
              <ul>
                <li>Рекламные кампании и лендинги</li>
                <li>Дизайн печатных и цифровых материалов</li>
                <li>Моушн-графика и social media оформление</li>
                <li>Долгосрочное дизайн-сопровождение</li>
              </ul>
            </article>
          </div>

          <div className={styles.process}>
            <h3>Как мы работаем</h3>
            <ol>
              <li>
                <strong>Погружение в задачу.</strong> Анализируем цели, аудиторию,
                контекст рынка и существующие материалы.
              </li>
              <li>
                <strong>Стратегия и концепция.</strong> Формируем визуальный вектор,
                тестируем гипотезы, собираем референсы и moodboard.
              </li>
              <li>
                <strong>Дизайн и производство.</strong> Разрабатываем визуальные
                решения, согласуем итерации, подготавливаем гайды и материалы.
              </li>
              <li>
                <strong>Внедрение и поддержка.</strong> Передаем систему клиенту,
                обучаем команду и при необходимости сопровождаем запуск.
              </li>
            </ol>
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;