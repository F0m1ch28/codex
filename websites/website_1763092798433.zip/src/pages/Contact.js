import { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  subject: '',
  message: '',
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    setErrors((prev) => ({ ...prev, [event.target.name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Пожалуйста, укажите имя.';
    if (!formData.email.trim()) {
      newErrors.email = 'Введите email.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Укажите корректный email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Расскажите о задаче.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsSubmitted(true);
    setFormData(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Контакты ArtVision Studio — обсудить проект</title>
        <meta
          name="description"
          content="Свяжитесь с ArtVision Studio: адрес в Москве, телефон, email и форма обратной связи."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Свяжитесь с нами</h1>
          <p>
            Расскажите о своей задаче — соберём персональную команду, предложим решения
            и построим план реализации.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Контактные данные</h2>
              <ul>
                <li>
                  <strong>Адрес:</strong> ул. Творческая, 15, Москва, Россия
                </li>
                <li>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
                </li>
              </ul>
              <p>
                Мы открыты к сотрудничеству с брендами, стартапами и агентствами. Давайте
                создавать впечатляющие визуальные решения вместе.
              </p>
            </div>

            <div className={styles.formWrapper}>
              <h2>Форма обратной связи</h2>
              {isSubmitted && (
                <div className={styles.success}>
                  Спасибо! Мы получили ваше сообщение и скоро свяжемся.
                </div>
              )}
              <form onSubmit={handleSubmit} noValidate>
                <label>
                  Имя*
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Как к вам обращаться?"
                    aria-invalid={!!errors.name}
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </label>

                <label>
                  Email*
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="example@domain.ru"
                    aria-invalid={!!errors.email}
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </label>

                <label>
                  Тема
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Например, «Редизайн сайта»"
                  />
                </label>

                <label>
                  Сообщение*
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Расскажите о проекте, сроках и пожеланиях"
                    rows="5"
                    aria-invalid={!!errors.message}
                  />
                  {errors.message && (
                    <span className={styles.error}>{errors.message}</span>
                  )}
                </label>

                <button type="submit">Отправить</button>
              </form>
            </div>
          </div>

          <div className={styles.mapWrapper}>
            <iframe
              title="Карта ArtVision Studio"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.2172608812236!2d37.617494577129295!3d55.755825973099725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTXCsDQ1JzIxLjAiTiAzN8KwMzcnMDQuOSJF!5e0!3m2!1sru!2sru!4v1700000000000"
              loading="lazy"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;