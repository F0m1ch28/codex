import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import { archives } from "../data/articles";
import styles from "./Archives.module.css";

const Archives = () => {
  usePageMetadata(
    "Archives",
    "Index mensuel des publications de French Automotive Sector Analysis : dossiers, interviews et commentaires."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Archives éditoriales</h1>
        <p>
          Les archives regroupent les publications mensuelles, facilitant l’accès aux analyses par période.
          Chaque entrée renvoie aux dossiers, études techniques et entretiens diffusés durant le mois concerné.
        </p>
      </header>
      <ul className={styles.list}>
        {archives.map((entry) => (
          <li key={entry.month} className={styles.item}>
            <div>
              <h2>{entry.month}</h2>
              <p>{entry.items} publications indexées</p>
            </div>
            <span aria-hidden="true" className={styles.arrow}>→</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Archives;