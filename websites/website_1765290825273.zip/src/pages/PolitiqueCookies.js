import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import styles from "./PolitiqueCookies.module.css";

const PolitiqueCookies = () => {
  usePageMetadata(
    "Politique cookies",
    "Informations sur l’usage des cookies analytiques sur French Automotive Sector Analysis."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Politique d’utilisation des cookies</h1>
        <p>Dernière mise à jour : 10 avril 2024</p>
      </header>
      <section className={styles.section}>
        <h2>Nature des cookies</h2>
        <p>
          Le site utilise des cookies analytiques destinés à mesurer l’audience et à améliorer l’expérience utilisateur.
          Aucun cookie publicitaire n’est déposé.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Gestion du consentement</h2>
        <p>
          Lors de la première visite, un bandeau informe l’utilisateur de l’utilisation de cookies. Il peut accepter ou
          différer sa décision. Le choix est conservé pendant treize mois.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Paramétrage</h2>
        <p>
          L’utilisateur peut configurer son navigateur pour refuser les cookies ou être informé de leur dépôt. Cette
          configuration peut toutefois limiter l’accès à certaines fonctionnalités.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Contact</h2>
        <p>
          Toute question relative à l’usage des cookies peut être adressée à contact@french-auto-analysis.fr.
        </p>
      </section>
    </div>
  );
};

export default PolitiqueCookies;