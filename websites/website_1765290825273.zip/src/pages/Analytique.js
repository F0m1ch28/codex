import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import { analyticArticles } from "../data/articles";
import ArticleFull from "../components/ArticleFull";
import styles from "./Analytique.module.css";

const Analytique = () => {
  usePageMetadata(
    "Analytique",
    "Analyses approfondies sur la stratégie des constructeurs français, la chaîne d’approvisionnement et le positionnement international."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Dossiers analytiques</h1>
        <p>
          Chaque dossier présente une étude détaillée des leviers industriels et stratégiques activés par les
          acteurs français de l’automobile. Les articles combinent données statistiques, témoignages et
          décryptage réglementaire.
        </p>
      </header>
      <div className={styles.articleList}>
        {analyticArticles.map((article) => (
          <ArticleFull article={article} key={article.id} />
        ))}
      </div>
    </div>
  );
};

export default Analytique;