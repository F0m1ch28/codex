import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import { technologyArticles } from "../data/articles";
import ArticleFull from "../components/ArticleFull";
import styles from "./Technologie.module.css";

const Technologie = () => {
  usePageMetadata(
    "Technologie",
    "Études sur l’ingénierie française, les systèmes d’aide à la conduite, la cybersécurité et la gestion des données."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Technologies et ingénierie</h1>
        <p>
          La rubrique Technologie observe les évolutions du logiciel embarqué, de la cybersécurité et des
          partenariats de recherche qui façonnent les véhicules de nouvelle génération.
        </p>
      </header>
      <div className={styles.articleList}>
        {technologyArticles.map((article) => (
          <ArticleFull article={article} key={article.id} />
        ))}
      </div>
    </div>
  );
};

export default Technologie;