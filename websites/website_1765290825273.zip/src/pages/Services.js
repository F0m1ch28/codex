import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import styles from "./Services.module.css";

const Services = () => {
  usePageMetadata(
    "Services éditoriaux",
    "Panorama des formats éditoriaux, des processus de vérification et des livrables proposés par la rédaction."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Services éditoriaux</h1>
        <p>
          Les services éditoriaux regroupent l’ensemble des formats proposés par la rédaction : dossiers analytiques,
          synthèses technologiques, notes de conjoncture et veilles cartographiques. Chaque livrable est conçu selon
          un processus rigoureux garantissant traçabilité et neutralité.
        </p>
      </header>

      <section className={styles.servicesGrid}>
        <article className={styles.serviceCard}>
          <h2>Dossiers stratégiques</h2>
          <p>
            Analyse approfondie des stratégies industrielles, comparaisons internationales, cartographies d’usines
            et repères réglementaires.
          </p>
        </article>
        <article className={styles.serviceCard}>
          <h2>Bulletins technologiques</h2>
          <p>
            Suivi des innovations en logiciels embarqués, batteries, capteurs et infrastructures de recharge, avec
            des focus laboratoire.
          </p>
        </article>
        <article className={styles.serviceCard}>
          <h2>Notes territoriales</h2>
          <p>
            Études des écosystèmes régionaux, portraits de clusters, suivi des formations et des dynamiques emploi-compétences.
          </p>
        </article>
      </section>

      <section className={styles.processSection}>
        <h2>Processus éditorial</h2>
        <div className={styles.timeline}>
          <div>
            <span className={styles.timelineStep}>1</span>
            <h3>Qualification du sujet</h3>
            <p>Définition du périmètre, identification des sources primaires et cadrage des indicateurs.</p>
          </div>
          <div>
            <span className={styles.timelineStep}>2</span>
            <h3>Collecte et vérification</h3>
            <p>Entretiens, audits documentaires et validation croisée avec les bases statistiques publiques.</p>
          </div>
          <div>
            <span className={styles.timelineStep}>3</span>
            <h3>Analyse structurée</h3>
            <p>Rédaction en troisième personne, intégration de graphiques et scénarisation neutre des conclusions.</p>
          </div>
          <div>
            <span className={styles.timelineStep}>4</span>
            <h3>Relecture collégiale</h3>
            <p>Contrôle par le comité scientifique, vérification terminologique et publication dans l’archive.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;