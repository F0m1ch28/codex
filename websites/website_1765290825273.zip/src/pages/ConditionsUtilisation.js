import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import styles from "./ConditionsUtilisation.module.css";

const ConditionsUtilisation = () => {
  usePageMetadata(
    "Conditions d’utilisation",
    "Conditions générales d’utilisation du site French Automotive Sector Analysis."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Conditions d’utilisation</h1>
        <p>Dernière mise à jour : 10 avril 2024</p>
      </header>
      <section className={styles.section}>
        <h2>1. Objet</h2>
        <p>
          Les présentes conditions définissent les règles d’accès et d’utilisation du site French Automotive Sector
          Analysis. Toute consultation suppose l’acceptation pleine et entière des dispositions ci-après.
        </p>
      </section>
      <section className={styles.section}>
        <h2>2. Accès au site</h2>
        <p>
          Le site est accessible gratuitement. L’utilisateur s’assure de la compatibilité de son équipement et de son
          navigateur. La rédaction se réserve le droit de suspendre l’accès pour maintenance ou mise à jour.
        </p>
      </section>
      <section className={styles.section}>
        <h2>3. Propriété intellectuelle</h2>
        <p>
          Les contenus éditoriaux, graphiques et logos sont la propriété de French Automotive Sector Analysis.
          Toute reproduction ou diffusion nécessite l’autorisation écrite de la rédaction. Les citations courtes sont
          autorisées sous réserve de mentionner la source.
        </p>
      </section>
      <section className={styles.section}>
        <h2>4. Usage des informations</h2>
        <p>
          Les informations publiées sont fournies à titre documentaire. La rédaction veille à leur exactitude mais ne
          saurait être tenue responsable d’éventuelles erreurs ou omissions. Les utilisateurs demeurent responsables de
          l’interprétation des données présentées.
        </p>
      </section>
      <section className={styles.section}>
        <h2>5. Liens hypertextes</h2>
        <p>
          Le site peut contenir des liens vers des ressources externes. French Automotive Sector Analysis ne contrôle
          pas ces contenus et décline toute responsabilité quant à leur disponibilité ou leur pertinence.
        </p>
      </section>
      <section className={styles.section}>
        <h2>6. Données personnelles</h2>
        <p>
          Les données collectées via le formulaire de contact sont utilisées pour répondre aux sollicitations. Elles ne
          sont pas communiquées à des tiers sans autorisation expresse. Les modalités complètes figurent dans la
          Politique de confidentialité.
        </p>
      </section>
      <section className={styles.section}>
        <h2>7. Modification des conditions</h2>
        <p>
          French Automotive Sector Analysis peut modifier les présentes conditions à tout moment. Les utilisateurs sont
          invités à les consulter régulièrement pour prendre connaissance des mises à jour.
        </p>
      </section>
    </div>
  );
};

export default ConditionsUtilisation;