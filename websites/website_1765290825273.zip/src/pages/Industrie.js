import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import { industryArticles } from "../data/articles";
import ArticleFull from "../components/ArticleFull";
import styles from "./Industrie.module.css";

const Industrie = () => {
  usePageMetadata(
    "Industrie",
    "Analyse de la robotisation, de la logistique interne et de la transformation des sites automobiles français."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Organisation industrielle</h1>
        <p>
          Cette rubrique explore la façon dont les usines françaises s’adaptent à la transition énergétique,
          en intégrant robotique, digitalisation et nouvelles compétences.
        </p>
      </header>
      <div className={styles.articleList}>
        {industryArticles.map((article) => (
          <ArticleFull article={article} key={article.id} />
        ))}
      </div>
    </div>
  );
};

export default Industrie;