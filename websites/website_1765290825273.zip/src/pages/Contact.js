import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import styles from "./Contact.module.css";

const Contact = () => {
  usePageMetadata(
    "Contact",
    "Coordonnées de la rédaction de French Automotive Sector Analysis et formulaire de prise de contact."
  );

  const [formData, setFormData] = React.useState({
    name: "",
    email: "",
    organisation: "",
    message: ""
  });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Merci d’indiquer un nom complet.";
    if (!formData.email.trim()) {
      newErrors.email = "Merci d’indiquer une adresse électronique.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Format de courriel invalide.";
    }
    if (!formData.message.trim()) newErrors.message = "Merci de préciser votre demande.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
    setFormData({
      name: "",
      email: "",
      organisation: "",
      message: ""
    });
  };

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Contact rédaction</h1>
        <p>
          Pour toute précision sur un article, une demande d’entretien ou l’accès à nos bases documentaires,
          la rédaction est joignable via le formulaire ci-dessous ou par courriel à contact@french-auto-analysis.fr.
        </p>
      </header>
      <section className={styles.grid}>
        <div className={styles.info}>
          <h2>Coordonnées</h2>
          <p>Rédaction French Automotive Sector Analysis</p>
          <p>10 Rue de la Recherche, 75000 Paris, France</p>
          <p>contact@french-auto-analysis.fr</p>
          <p>Réponse assurée aux demandes vérifiées dans un délai maximum de cinq jours ouvrés.</p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Nom et prénom</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Adresse électronique</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="organisation">Organisation</label>
            <input
              id="organisation"
              name="organisation"
              type="text"
              value={formData.organisation}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
            ></textarea>
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit" className={styles.submit}>
            Transmettre à la rédaction
          </button>
          {submitted && (
            <p className={styles.success}>
              Le message a été transmis à la rédaction. Une réponse sera adressée dès que possible.
            </p>
          )}
        </form>
      </section>
    </div>
  );
};

export default Contact;