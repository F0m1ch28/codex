import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import { teamMembers } from "../data/articles";
import styles from "./About.module.css";

const About = () => {
  usePageMetadata(
    "À propos",
    "Présentation de la rédaction, de la gouvernance éditoriale et des engagements méthodologiques de French Automotive Sector Analysis."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">À propos de la rédaction</h1>
        <p>
          French Automotive Sector Analysis est une publication indépendante consacrée à la filière automobile
          française. L’équipe journalistique et analytique travaille en étroite collaboration avec un comité
          scientifique pour garantir la fiabilité des contenus.
        </p>
      </header>
      <section className={styles.mission}>
        <h2>Mission éditoriale</h2>
        <p>
          La publication offre une lecture structurée de la transformation industrielle et technologique.
          Chaque analyse repose sur des données vérifiées, des entretiens contradictoires et une mise en perspective
          internationale. La rédaction privilégie un ton neutre, en troisième personne, pour restituer les faits
          et les stratégies observées sans extrapolation.
        </p>
      </section>
      <section className={styles.teamSection}>
        <h2>Équipe de direction</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <div className={styles.teamCard} key={member.name}>
              <div className={styles.avatar} aria-hidden="true"></div>
              <h3>{member.name}</h3>
              <p className={styles.role}>{member.role}</p>
              <p>{member.focus}</p>
            </div>
          ))}
        </div>
      </section>
      <section className={styles.methods}>
        <h2>Engagements méthodologiques</h2>
        <ul className={styles.commitments}>
          <li>Validation systématique des chiffres auprès de sources officielles nationales et européennes.</li>
          <li>Relecture par un comité scientifique composé d’universitaires et de praticiens de l’industrie.</li>
          <li>Transparence sur les corrections apportées aux articles via l’espace archives.</li>
          <li>Archivage des entretiens et des documents de référence consultables sur demande.</li>
        </ul>
      </section>
    </div>
  );
};

export default About;