import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import styles from "./PolitiqueConfidentialite.module.css";

const PolitiqueConfidentialite = () => {
  usePageMetadata(
    "Politique de confidentialité",
    "Modalités de collecte et de traitement des données personnelles sur French Automotive Sector Analysis."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Politique de confidentialité</h1>
        <p>Dernière mise à jour : 10 avril 2024</p>
      </header>
      <section className={styles.section}>
        <h2>Données collectées</h2>
        <p>
          Les données personnelles collectées se limitent aux informations communiquées via le formulaire de contact :
          nom, adresse électronique, organisation et contenu du message. Ces données sont nécessaires au traitement des
          demandes adressées à la rédaction.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Finalités</h2>
        <p>
          Les informations sont utilisées exclusivement pour répondre aux sollicitations, organiser les entretiens et
          gérer les demandes de correction. Aucune donnée n’est exploitée à des fins commerciales.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Conservation</h2>
        <p>
          Les données sont conservées pour une durée maximale de douze mois à compter du dernier échange. Elles sont
          ensuite supprimées ou anonymisées.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Droits des personnes</h2>
        <p>
          Conformément à la réglementation en vigueur, toute personne peut exercer ses droits d’accès, de rectification,
          d’effacement et de limitation du traitement. Les demandes sont à adresser par courriel à
          contact@french-auto-analysis.fr.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Sécurité</h2>
        <p>
          Des mesures techniques et organisationnelles sont mises en place pour protéger les données contre l’accès non
          autorisé, la perte ou la divulgation. L’hébergement est assuré au sein de l’Union européenne.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Contact</h2>
        <p>
          Pour toute question relative à cette politique, la rédaction peut être jointe via le formulaire de contact ou
          par courriel à l’adresse mentionnée ci-dessus.
        </p>
      </section>
    </div>
  );
};

export default PolitiqueConfidentialite;