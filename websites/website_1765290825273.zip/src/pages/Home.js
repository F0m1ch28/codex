import React from "react";
import ArticleCard from "../components/ArticleCard";
import InterviewCard from "../components/InterviewCard";
import usePageMetadata from "../hooks/usePageMetadata";
import { analyticArticles, interviewsData, themes, trendStats, archives, faqs } from "../data/articles";
import styles from "./Home.module.css";

const Home = () => {
  usePageMetadata(
    "Accueil",
    "Panorama éditorial dédié à l’industrie automobile française : analyses, technologie, interviews et archives spécialisées."
  );

  return (
    <div className={styles.home}>
      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroBadge}>Observatoire neutre de la filière automobile française</div>
          <h1 className={styles.heroTitle}>
            Cartographier la transformation de l’industrie automobile française
          </h1>
          <p className={styles.heroDescription}>
            La rédaction analyse la structuration des constructeurs nationaux, l’évolution des technologies
            et les dynamiques industrielles qui dessinent la mobilité de demain. Les dossiers, entretiens
            et bases documentaires donnent une vision contextualisée des enjeux énergétiques, réglementaires
            et territoriaux.
          </p>
        </div>
      </section>

      <section className={styles.articlesSection}>
        <div className="container">
          <h2 className="section-title">Dernières analyses</h2>
          <div className={styles.articlesGrid}>
            {analyticArticles.slice(0, 3).map((article) => (
              <ArticleCard article={article} key={article.id} />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <h2 className="section-title">Indicateurs de tendance</h2>
          <div className={styles.statsGrid}>
            {trendStats.map((stat) => (
              <div className={styles.statCard} key={stat.id}>
                <span className={styles.statValue}>{stat.value}</span>
                <p className={styles.statLabel}>{stat.label}</p>
                <p className={styles.statContext}>{stat.context}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.themesSection}>
        <div className="container">
          <h2 className="section-title">Axes de recherche</h2>
          <div className={styles.themesGrid}>
            {themes.map((theme) => (
              <div className={styles.themeCard} key={theme.id}>
                <span className={styles.themeIcon} aria-hidden="true">{theme.icon}</span>
                <h3>{theme.title}</h3>
                <p>{theme.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.interviewsSection}>
        <div className="container">
          <h2 className="section-title">Regards d’experts</h2>
          <div className={styles.interviewsGrid}>
            {interviewsData.slice(0, 2).map((interview) => (
              <InterviewCard interview={interview} key={interview.id} />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.archiveSection}>
        <div className="container">
          <h2 className="section-title">Archives thématiques</h2>
          <ul className={styles.archiveList}>
            {archives.map((entry) => (
              <li key={entry.month} className={styles.archiveItem}>
                <span>{entry.month}</span>
                <span>{entry.items} publications</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={styles.methodologySection}>
        <div className="container">
          <h2 className="section-title">Méthodologie d’étude</h2>
          <div className={styles.methodologyContent}>
            <div>
              <h3>Processus analytique</h3>
              <ol className={styles.steps}>
                <li>Veille réglementaire et collecte de données officielles.</li>
                <li>Entretiens avec experts indépendants et responsables industriels.</li>
                <li>Traitement statistique et validation croisée des indicateurs.</li>
                <li>Relecture par le comité scientifique et publication contextualisée.</li>
              </ol>
            </div>
            <div>
              <h3>Questions fréquentes</h3>
              <div className={styles.faq}>
                {faqs.map((item, index) => (
                  <details key={index} className={styles.faqItem}>
                    <summary>{item.question}</summary>
                    <p>{item.answer}</p>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;