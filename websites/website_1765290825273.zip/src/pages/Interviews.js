import React from "react";
import usePageMetadata from "../hooks/usePageMetadata";
import { interviewsData } from "../data/articles";
import styles from "./Interviews.module.css";

const Interviews = () => {
  usePageMetadata(
    "Interviews",
    "Entretiens et synthèses d’échanges avec des experts des batteries, de la mobilité et de la recherche."
  );

  return (
    <div className="container">
      <header className={styles.header}>
        <h1 className="section-title">Entretiens et décryptages</h1>
        <p>
          Chaque entretien est retranscrit sous forme de synthèse en troisième personne afin de mettre en
          avant les points clés évoqués par les spécialistes interrogés.
        </p>
      </header>
      <div className={styles.interviewList}>
        {interviewsData.map((interview) => (
          <article key={interview.id} className={styles.card} id={interview.id}>
            <header>
              <p className={styles.meta}>{interview.date}</p>
              <h2>{interview.title}</h2>
              <p className={styles.subtitle}>{interview.subtitle}</p>
            </header>
            {interview.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </article>
        ))}
      </div>
    </div>
  );
};

export default Interviews;