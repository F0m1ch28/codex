import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";

import Home from "./pages/Home";
import Analytique from "./pages/Analytique";
import Technologie from "./pages/Technologie";
import Industrie from "./pages/Industrie";
import Interviews from "./pages/Interviews";
import Archives from "./pages/Archives";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import ConditionsUtilisation from "./pages/ConditionsUtilisation";
import PolitiqueConfidentialite from "./pages/PolitiqueConfidentialite";
import PolitiqueCookies from "./pages/PolitiqueCookies";

const ScrollOnRouteChange = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);
  return null;
};

const App = () => {
  return (
    <div className="app-shell">
      <ScrollOnRouteChange />
      <Header />
      <main className="app-main" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/analytique" element={<Analytique />} />
          <Route path="/technologie" element={<Technologie />} />
          <Route path="/industrie" element={<Industrie />} />
          <Route path="/interviews" element={<Interviews />} />
          <Route path="/archives" element={<Archives />} />
          <Route path="/services" element={<Services />} />
          <Route path="/a-propos" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/conditions-utilisation" element={<ConditionsUtilisation />} />
          <Route path="/politique-confidentialite" element={<PolitiqueConfidentialite />} />
          <Route path="/politique-cookies" element={<PolitiqueCookies />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;