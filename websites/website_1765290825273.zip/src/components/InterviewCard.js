import React from "react";
import { Link } from "react-router-dom";
import styles from "./InterviewCard.module.css";

const InterviewCard = ({ interview }) => {
  return (
    <article className={styles.card}>
      <header>
        <p className={styles.meta}>{interview.date}</p>
        <h3 className={styles.title}>{interview.title}</h3>
        {interview.subtitle && <p className={styles.subtitle}>{interview.subtitle}</p>}
      </header>
      <p className={styles.excerpt}>{interview.summary}</p>
      <Link to={`/interviews#${interview.id}`} className={styles.link}>
        Voir la synthèse
      </Link>
    </article>
  );
};

export default InterviewCard;