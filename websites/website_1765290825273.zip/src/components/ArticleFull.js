import React from "react";
import styles from "./ArticleFull.module.css";

const ArticleFull = ({ article }) => {
  return (
    <article className={styles.article} id={article.id}>
      <header className={styles.header}>
        <p className={styles.meta}>{article.date}</p>
        <h2 className={styles.title}>{article.title}</h2>
        {article.subtitle && <p className={styles.subtitle}>{article.subtitle}</p>}
      </header>
      <section className={styles.intro}>
        <p>{article.introduction}</p>
      </section>
      <section className={styles.body}>
        {article.body.map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </section>
      <section className={styles.conclusion}>
        <h3>Conclusion</h3>
        <p>{article.conclusion}</p>
      </section>
    </article>
  );
};

export default ArticleFull;