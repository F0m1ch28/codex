import React from "react";
import { NavLink, Link } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [searchOpen, setSearchOpen] = React.useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const toggleSearch = () => setSearchOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  const navLinks = [
    { to: "/", label: "Accueil" },
    { to: "/analytique", label: "Analytique" },
    { to: "/technologie", label: "Technologie" },
    { to: "/industrie", label: "Industrie" },
    { to: "/interviews", label: "Interviews" },
    { to: "/archives", label: "Archives" },
    { to: "/services", label: "Services" },
    { to: "/a-propos", label: "À propos" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <header className={styles.header}>
      <div className={`${styles.inner} container`}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          French Automotive Sector Analysis
        </Link>
        <button
          className={styles.mobileToggle}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="nav-list"
        >
          <span className="sr-only">Ouvrir ou fermer la navigation</span>
          <span className={styles.bar}></span>
          <span className={styles.bar}></span>
          <span className={styles.bar}></span>
        </button>
        <nav className={styles.nav}>
          <ul
            id="nav-list"
            className={`${styles.navList} ${menuOpen ? styles.navListOpen : ""}`}
          >
            {navLinks.map((link) => (
              <li key={link.to} className={styles.navItem}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ""}`
                  }
                  onClick={closeMenu}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <button
          className={styles.searchToggle}
          onClick={toggleSearch}
          aria-expanded={searchOpen}
          aria-controls="header-search"
        >
          <span className="sr-only">Afficher ou masquer la recherche</span>
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M11 4a7 7 0 015.56 11.27l4.08 4.09-1.42 1.41-4.08-4.08A7 7 0 1111 4zm0 2a5 5 0 100 10 5 5 0 000-10z"
              fill="currentColor"
            />
          </svg>
        </button>
      </div>
      {searchOpen && (
        <div className={styles.searchPanel} id="header-search">
          <div className="container">
            <label className="sr-only" htmlFor="search-input">
              Rechercher une analyse
            </label>
            <input
              id="search-input"
              className={styles.searchInput}
              type="search"
              placeholder="Rechercher une analyse, un dossier, un entretien..."
            />
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;