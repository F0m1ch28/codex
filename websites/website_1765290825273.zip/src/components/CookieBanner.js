import React from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const storedConsent = window.localStorage.getItem("cookie-consent");
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = () => {
    window.localStorage.setItem("cookie-consent", "accepted");
    setVisible(false);
  };

  const handleDismiss = () => {
    window.localStorage.setItem("cookie-consent", "dismissed");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Ce site utilise des cookies analytiques afin d’améliorer la compréhension des usages.
          Aucune donnée nominative n’est partagée avec des tiers non autorisés.
        </p>
        <div className={styles.actions}>
          <button className={styles.accept} onClick={handleConsent}>
            Accepter
          </button>
          <button className={styles.dismiss} onClick={handleDismiss}>
            Préférences ultérieures
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;