import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`${styles.top} container`}>
        <div className={styles.column}>
          <h4 className={styles.heading}>French Automotive Sector Analysis</h4>
          <p className={styles.text}>
            Plateforme éditoriale dédiée à l’étude structurelle de la filière automobile française,
            couvrant les dynamiques industrielles, technologiques et territoriales.
          </p>
          <p className={styles.text}>
            Siège éditorial : 10 Rue de la Recherche, 75000 Paris, France
          </p>
          <p className={styles.text}>
            contact@french-auto-analysis.fr
          </p>
        </div>
        <div className={styles.column}>
          <h5 className={styles.subheading}>Rubriques</h5>
          <ul className={styles.list}>
            <li><Link to="/analytique">Analytique</Link></li>
            <li><Link to="/technologie">Technologie</Link></li>
            <li><Link to="/industrie">Industrie</Link></li>
            <li><Link to="/interviews">Interviews</Link></li>
            <li><Link to="/archives">Archives</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h5 className={styles.subheading}>Informations</h5>
          <ul className={styles.list}>
            <li><Link to="/a-propos">À propos</Link></li>
            <li><Link to="/services">Services éditoriaux</Link></li>
            <li><Link to="/contact">Contact</Link></li>
            <li><Link to="/conditions-utilisation">Conditions d’utilisation</Link></li>
            <li><Link to="/politique-confidentialite">Politique de confidentialité</Link></li>
            <li><Link to="/politique-cookies">Politique cookies</Link></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className="container">
          <p>© {new Date().getFullYear()} French Automotive Sector Analysis. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;