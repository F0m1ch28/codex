import React from "react";
import { Link } from "react-router-dom";
import styles from "./ArticleCard.module.css";

const createExcerpt = (text, limit = 42) => {
  if (!text) return "";
  const words = text.split(" ");
  if (words.length <= limit) return text;
  return `${words.slice(0, limit).join(" ")}…`;
};

const ArticleCard = ({ article }) => {
  return (
    <article className={styles.card}>
      <header>
        <p className={styles.meta}>{article.date}</p>
        <h3 className={styles.title}>{article.title}</h3>
        {article.subtitle && <p className={styles.subtitle}>{article.subtitle}</p>}
      </header>
      <p className={styles.excerpt}>{createExcerpt(article.introduction, 42)}</p>
      <Link to={`/analytique#${article.id}`} className={styles.link}>
        Détails de l’analyse
      </Link>
    </article>
  );
};

export default ArticleCard;