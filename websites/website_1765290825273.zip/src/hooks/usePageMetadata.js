import { useEffect } from "react";

const DEFAULT_DESCRIPTION =
  "French Automotive Sector Analysis propose une lecture structurée de l’industrie automobile française.";

const usePageMetadata = (title, description) => {
  useEffect(() => {
    const fullTitle = title
      ? `${title} | French Automotive Sector Analysis`
      : "French Automotive Sector Analysis";
    document.title = fullTitle;

    const metaDescription = document.querySelector("meta[name='description']");
    if (metaDescription) {
      metaDescription.setAttribute("content", description || DEFAULT_DESCRIPTION);
    }

    const ogTitle = document.querySelector("meta[property='og:title']");
    if (ogTitle) {
      ogTitle.setAttribute("content", fullTitle);
    }

    const ogDescription = document.querySelector("meta[property='og:description']");
    if (ogDescription) {
      ogDescription.setAttribute("content", description || DEFAULT_DESCRIPTION);
    }
  }, [title, description]);
};

export default usePageMetadata;