document.addEventListener("DOMContentLoaded", function () {
  const header = document.querySelector(".site-header");
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  const cookieBanner = document.getElementById("cookie-banner");
  const footerYear = document.getElementById("footer-year");

  if (footerYear) {
    footerYear.textContent = new Date().getFullYear();
  }

  function handleScroll() {
    if (!header) return;
    if (window.scrollY > 12) {
      header.classList.add("is-scrolled");
    } else {
      header.classList.remove("is-scrolled");
    }
  }

  handleScroll();
  window.addEventListener("scroll", handleScroll);

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      siteNav.classList.toggle("is-open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll(".reveal").forEach((section) => observer.observe(section));

  function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.setAttribute("role", "status");
    toast.textContent = message;
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("visible"));
    setTimeout(() => {
      toast.classList.remove("visible");
      setTimeout(() => toast.remove(), 350);
    }, 2500);
  }

  document.querySelectorAll("form").forEach((form) => {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      const redirectUrl = form.getAttribute("action") || "thank-you.html";
      showToast("Mesajul a fost trimis. Te redirecționăm...");
      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 1800);
    });
  });

  const cookieKey = "skillbridgeCookieConsent";
  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  if (cookieBanner) {
    const stored = localStorage.getItem(cookieKey);
    if (!stored) {
      setTimeout(() => cookieBanner.classList.add("active"), 600);
    } else {
      hideCookieBanner();
    }

    cookieBanner.querySelectorAll("button[data-cookie-action]").forEach((button) => {
      button.addEventListener("click", () => {
        const action = button.getAttribute("data-cookie-action");
        localStorage.setItem(cookieKey, action);
        hideCookieBanner();
        showToast("Preferința ta pentru cookie-uri a fost salvată.");
      });
    });
  }
});