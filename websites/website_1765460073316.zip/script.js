document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("is-open");
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (nav.classList.contains("is-open")) {
          nav.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("pkts-cookie-choice");
    if (storedChoice) {
      cookieBanner.setAttribute("hidden", "");
    } else {
      cookieBanner.removeAttribute("hidden");
    }

    cookieBanner.querySelectorAll("button[data-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        localStorage.setItem("pkts-cookie-choice", button.dataset.choice);
        cookieBanner.classList.add("cookie-banner--hide");
        setTimeout(() => {
          cookieBanner.setAttribute("hidden", "");
        }, 400);
      });
    });
  }
});