document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.site-nav');
  const navLinks = document.querySelectorAll('.nav-menu a');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (navMenu) {
        navMenu.classList.remove('open');
      }
      if (navToggle) {
        navToggle.setAttribute('aria-expanded', 'false');
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });

  const scrollBtn = document.querySelector('.scroll-top');
  if (scrollBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 420) {
        scrollBtn.classList.add('show');
      } else {
        scrollBtn.classList.remove('show');
      }
    });

    scrollBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const cookieButton = document.getElementById('accept-cookies');
  const cookieStorageKey = 'pip-cookie-consent';

  if (cookieBanner && cookieButton) {
    const consent = localStorage.getItem(cookieStorageKey);
    if (consent === 'accepted') {
      cookieBanner.classList.add('hidden');
      cookieBanner.setAttribute('aria-hidden', 'true');
    }

    cookieButton.addEventListener('click', () => {
      localStorage.setItem(cookieStorageKey, 'accepted');
      cookieBanner.classList.add('hidden');
      cookieBanner.setAttribute('aria-hidden', 'true');
    });
  }

  const forms = document.querySelectorAll('.contact-form');
  forms.forEach(form => {
    const message = form.querySelector('.form-message');
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (form.checkValidity()) {
        if (message) {
          message.textContent = 'Grazie per il messaggio. Ti ricontatteremo a breve.';
          message.classList.add('visible');
        }
        form.reset();
      }
    });
  });
});