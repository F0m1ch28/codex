document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = siteNav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const consentStatus = localStorage.getItem('stoopeqohl-cookie-consent');

    if (cookieBanner) {
        if (!consentStatus) {
            cookieBanner.classList.add('is-visible');
        }

        cookieBanner.querySelectorAll('button[data-cookie-choice]').forEach(button => {
            button.addEventListener('click', () => {
                const choice = button.getAttribute('data-cookie-choice');
                localStorage.setItem('stoopeqohl-cookie-consent', choice);
                cookieBanner.classList.remove('is-visible');
            });
        });
    }
});