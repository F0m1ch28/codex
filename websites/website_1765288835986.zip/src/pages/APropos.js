import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './APropos.module.css';

const APropos = () => {
  return {
    $$typeof: Symbol.for('react.element'),
    type: 'div',
    key: null,
    ref: null,
    props: {
      className: styles.page,
      children: [
        {
          $$typeof: Symbol.for('react.element'),
          type: Helmet,
          key: 'helmet',
          ref: null,
          props: {
            children: [
              {
                $$typeof: Symbol.for('react.element'),
                type: 'title',
                key: '0',
                ref: null,
                props: {
                  children: 'À Propos — Historic Streets of France Review',
                },
                _owner: null,
              },
              {
                $$typeof: Symbol.for('react.element'),
                type: 'meta',
                key: '1',
                ref: null,
                props: {
                  name: 'description',
                  content:
                    'Présentation de l’équipe éditoriale et des objectifs scientifiques de Historic Streets of France Review.',
                },
                _owner: null,
              },
            ],
          },
          _owner: null,
        },
        {
          $$typeof: Symbol.for('react.element'),
          type: 'header',
          key: 'header',
          ref: null,
          props: {
            className: styles.header,
            children: [
              {
                $$typeof: Symbol.for('react.element'),
                type: 'p',
                key: 'lead',
                ref: null,
                props: {
                  className: styles.lead,
                  children:
                    "Historic Streets of France Review est une publication en ligne consacrée à l’étude approfondie des rues historiques françaises. Elle rassemble des chercheurs, urbanistes, architectes et médiateurs du patrimoine autour d’un objectif commun : documenter la manière dont les espaces publics façonnent l’identité des villes françaises.",
                },
                _owner: null,
              },
            ],
          },
          _owner: null,
        },
        {
          $$typeof: Symbol.for('react.element'),
          type: 'section',
          key: 'mission',
          ref: null,
          props: {
            className: styles.section,
            children: [
              {
                $$typeof: Symbol.for('react.element'),
                type: 'h2',
                key: 'title',
                ref: null,
                props: {
                  className: styles.title,
                  children: 'Mission éditoriale',
                },
                _owner: null,
              },
              {
                $$typeof: Symbol.for('react.element'),
                type: 'p',
                key: 'p1',
                ref: null,
                props: {
                  children:
                    "La rédaction privilégie une approche pluridisciplinaire. Chaque rue étudiée fait l’objet d’un travail croisé réunissant cartographies anciennes, relevés sur le terrain, entretiens avec les habitants et analyses d’archives. L’objectif est de restituer la complexité des transformations urbaines sans céder à la simplification ou au folklore.",
                },
                _owner: null,
              },
              {
                $$typeof: Symbol.for('react.element'),
                type: 'p',
                key: 'p2',
                ref: null,
                props: {
                  children:
                    "Le projet s’adresse aux chercheurs, aux professionnels de l’urbanisme, aux institutions patrimoniales et à toutes les personnes souhaitant comprendre les dynamiques qui façonnent les centres historiques. Les contenus sont publiés en français afin de valoriser les sources nationales et locales, mais ils s’inscrivent dans un dialogue européen de la recherche urbaine.",
                },
                _owner: null,
              },
            ],
          },
          _owner: null,
        },
        {
          $$typeof: Symbol.for('react.element'),
          type: 'section',
          key: 'team',
          ref: null,
          props: {
            className: styles.section,
            children: [
              {
                $$typeof: Symbol.for('react.element'),
                type: 'h2',
                key: 'title',
                ref: null,
                props: {
                  className: styles.title,
                  children: 'Équipe éditoriale',
                },
                _owner: null,
              },
              {
                $$typeof: Symbol.for('react.element'),
                type: 'ul',
                key: 'list',
                ref: null,
                props: {
                  className: styles.list,
                  children: [
                    {
                      $$typeof: Symbol.for('react.element'),
                      type: 'li',
                      key: '1',
                      ref: null,
                      props: {
                        children: [
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'h3',
                            key: 'name',
                            ref: null,
                            props: {
                              children: 'Julien Perrin — Direction éditoriale',
                            },
                            _owner: null,
                          },
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'p',
                            key: 'desc',
                            ref: null,
                            props: {
                              children:
                                "Historien de l’architecture, il supervise la cohérence scientifique des enquêtes et veille à l’articulation entre sources archivistiques et observations de terrain.",
                            },
                            _owner: null,
                          },
                        ],
                      },
                      _owner: null,
                    },
                    {
                      $$typeof: Symbol.for('react.element'),
                      type: 'li',
                      key: '2',
                      ref: null,
                      props: {
                        children: [
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'h3',
                            key: 'name',
                            ref: null,
                            props: {
                              children:
                                'Nadia Lefèvre — Coordination cartographique',
                            },
                            _owner: null,
                          },
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'p',
                            key: 'desc',
                            ref: null,
                            props: {
                              children:
                                "Géographe spécialisée dans l’analyse spatiale, elle orchestre la production de plans comparés et la restitution des évolutions morphologiques.",
                            },
                            _owner: null,
                          },
                        ],
                      },
                      _owner: null,
                    },
                    {
                      $$typeof: Symbol.for('react.element'),
                      type: 'li',
                      key: '3',
                      ref: null,
                      props: {
                        children: [
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'h3',
                            key: 'name',
                            ref: null,
                            props: {
                              children:
                                'Marc-André Rossi — Responsable enquêtes orales',
                            },
                            _owner: null,
                          },
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'p',
                            key: 'desc',
                            ref: null,
                            props: {
                              children:
                                "Sociologue urbain, il mène les entretiens avec les habitants, artisans et gestionnaires du patrimoine, garantissant une approche attentive aux usages quotidiens.",
                            },
                            _owner: null,
                          },
                        ],
                      },
                      _owner: null,
                    },
                    {
                      $$typeof: Symbol.for('react.element'),
                      type: 'li',
                      key: '4',
                      ref: null,
                      props: {
                        children: [
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'h3',
                            key: 'name',
                            ref: null,
                            props: {
                              children:
                                'Lucia Fernández — Médiation et iconographie',
                            },
                            _owner: null,
                          },
                          {
                            $$typeof: Symbol.for('react.element'),
                            type: 'p',
                            key: 'desc',
                            ref: null,
                            props: {
                              children:
                                "Spécialiste des patrimoines visuels, elle gère les collections photographiques, la scénographie numérique des dossiers et la description des sources iconographiques.",
                            },
                            _owner: null,
                          },
                        ],
                      },
                      _owner: null,
                    },
                  ],
                },
                _owner: null,
              },
            ],
          },
          _owner: null,
        },
        {
          $$typeof: Symbol.for('react.element'),
          type: 'section',
          key: 'approche',
          ref: null,
          props: {
            className: styles.section,
            children: [
              {
                $$typeof: Symbol.for('react.element'),
                type: 'h2',
                key: 'title',
                ref: null,
                props: {
                  className: styles.title,
                  children: 'Approche éditoriale',
                },
                _owner: null,
              },
              {
                $$typeof: Symbol.for('react.element'),
                type: 'p',
                key: 'p1',
                ref: null,
                props: {
                  children:
                    "Chaque dossier est conçu comme une monographie de rue articulée en plusieurs volets : chronologie, morphologie, usages sociaux, politiques publiques et mémoire collective. Cette structure assure une lecture comparable d’une ville à l’autre et facilite la consultation par thématique.",
                },
                _owner: null,
              },
              {
                $$typeof: Symbol.for('react.element'),
                type: 'p',
                key: 'p2',
                ref: null,
                props: {
                  children:
                    "La rédaction collabore régulièrement avec des laboratoires universitaires, des services municipaux du patrimoine et des associations locales. Ces partenariats garantissent la fiabilité des données et encouragent la circulation des savoirs entre recherche académique et expertise de terrain.",
                },
                _owner: null,
              },
            ],
          },
          _owner: null,
        },
        {
          $$typeof: Symbol.for('react.element'),
          type: 'section',
          key: 'engagements',
          ref: null,
          props: {
            className: styles.section,
            children: [
              {
                $$typeof: Symbol.for('react.element'),
                type: 'h2',
                key: 'title',
                ref: null,
                props: {
                  className: styles.title,
                  children: 'Engagements',
                },
                _owner: null,
              },
              {
                $$typeof: Symbol.for('react.element'),
                type: 'ul',
                key: 'list',
                ref: null,
                props: {
                  className: styles.commitments,
                  children: [
                    {
                      $$typeof: Symbol.for('react.element'),
                      type: 'li',
                      key: '1',
                      ref: null,
                      props: {
                        children:
                          'Transparence des sources : chaque article est accompagné d’une bibliographie et d’indications archivistiques.',
                      },
                      _owner: null,
                    },
                    {
                      $$typeof: Symbol.for('react.element'),
                      type: 'li',
                      key: '2',
                      ref: null,
                      props: {
                        children:
                          'Neutralité éditoriale : les analyses privilégient les faits documentés et les interprétations argumentées.',
                      },
                      _owner: null,
                    },
                    {
                      $$typeof: Symbol.for('react.element'),
                      type: 'li',
                      key: '3',
                      ref: null,
                      props: {
                        children:
                          'Accessibilité : attention portée à la lisibilité des contenus et à l’inclusion d’outils facilitant la consultation.',
                      },
                      _owner: null,
                    },
                  ],
                },
                _owner: null,
              },
            ],
          },
          _owner: null,
        },
      ],
    },
    _owner: null,
  };
};

export default APropos;