import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Merci d’indiquer un nom.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Merci d’indiquer une adresse email.';
    } else if (
      !/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(formData.email.trim())
    ) {
      newErrors.email = 'Adresse email invalide.';
    }
    if (!formData.subject.trim()) {
      newErrors.subject = 'Merci de préciser l’objet de votre message.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Merci de formuler votre demande.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    setSubmitted(true);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact — Historic Streets of France Review</title>
        <meta
          name="description"
          content="Coordonnées et formulaire de contact de la rédaction de Historic Streets of France Review."
        />
      </Helmet>

      <header className={styles.header}>
        <h1 className={styles.title}>Contact rédactionnel</h1>
        <p className={styles.intro}>
          Pour toute question relative aux publications, collaborations
          scientifiques ou demandes de précisions sur une étude, la rédaction
          est joignable via ce formulaire ou à l’adresse suivante :
          <a href="mailto:contact@historicstreets-fr-review.org">
            contact@historicstreets-fr-review.org
          </a>
          .
        </p>
      </header>

      <section className={styles.formSection}>
        {submitted ? (
          <div className={styles.confirmation} role="status">
            <p>
              Merci pour votre message. La rédaction l’a bien reçu et y répondra
              après analyse.
            </p>
          </div>
        ) : (
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="nom">Nom</label>
              <input
                id="nom"
                name="name"
                type="text"
                value={formData.name}
                onChange={(event) =>
                  setFormData({ ...formData, name: event.target.value })
                }
                aria-invalid={errors.name ? 'true' : 'false'}
              />
              {errors.name && (
                <p className={styles.error} role="alert">
                  {errors.name}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Adresse email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={(event) =>
                  setFormData({ ...formData, email: event.target.value })
                }
                aria-invalid={errors.email ? 'true' : 'false'}
              />
              {errors.email && (
                <p className={styles.error} role="alert">
                  {errors.email}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="objet">Objet</label>
              <input
                id="objet"
                name="subject"
                type="text"
                value={formData.subject}
                onChange={(event) =>
                  setFormData({ ...formData, subject: event.target.value })
                }
                aria-invalid={errors.subject ? 'true' : 'false'}
              />
              {errors.subject && (
                <p className={styles.error} role="alert">
                  {errors.subject}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                rows={6}
                value={formData.message}
                onChange={(event) =>
                  setFormData({ ...formData, message: event.target.value })
                }
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && (
                <p className={styles.error} role="alert">
                  {errors.message}
                </p>
              )}
            </div>

            <button type="submit" className={styles.submit}>
              Envoyer la demande
            </button>
          </form>
        )}
      </section>
    </div>
  );
};

export default Contact;