import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PolitiqueConfidentialite.module.css';

const PolitiqueConfidentialite = () => (
  <div className={styles.page}>
    <Helmet>
      <title>
        Politique de Confidentialité — Historic Streets of France Review
      </title>
    </Helmet>
    <h1 className={styles.title}>Politique de Confidentialité</h1>
    <p>
      Historic Streets of France Review respecte la vie privée de ses
      utilisateurs. Les principes suivants s’appliquent.
    </p>
    <section className={styles.section}>
      <h2>Données collectées</h2>
      <p>
        Le site ne collecte aucune donnée personnelle sans le consentement
        explicite de l’utilisateur. Le formulaire de contact recueille les
        informations nécessaires au traitement de la demande (nom, adresse
        email, objet, message). Ces données sont utilisées uniquement pour
        répondre à la sollicitation.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Conservation</h2>
      <p>
        Les messages envoyés via le formulaire sont conservés pour la durée
        nécessaire à leur traitement. Les utilisateurs peuvent demander la
        suppression de leurs données en écrivant à
        contact@historicstreets-fr-review.org.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Cookies</h2>
      <p>
        Seuls des cookies analytiques anonymisés sont utilisés pour mesurer la
        fréquentation du site. Les visiteurs peuvent accepter ou refuser ces
        cookies via le bandeau d’information.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Vos droits</h2>
      <p>
        Conformément à la réglementation, chaque personne dispose d’un droit
        d’accès, de rectification et de suppression de ses données. Pour toute
        demande, écrire à l’adresse mentionnée ci-dessus.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Contact</h2>
      <p>
        Pour toute question relative à cette politique, merci de contacter la
        rédaction : contact@historicstreets-fr-review.org.
      </p>
    </section>
  </div>
);

export default PolitiqueConfidentialite;