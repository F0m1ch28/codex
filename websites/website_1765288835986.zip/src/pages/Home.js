import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import ArticleCard from '../components/ArticleCard';
import ThemeCard from '../components/ThemeCard';
import ExpertQuote from '../components/ExpertQuote';
import articlesData from '../data/articles';
import themesData from '../data/themes';
import expertQuote from '../data/expertQuote';
import styles from './Home.module.css';

const Home = () => {
  const sortedArticles = [...articlesData].sort(
    (a, b) => new Date(b.date) - new Date(a.date)
  );
  const featuredArticle = sortedArticles.find((article) => article.featured);
  const latestArticles = sortedArticles.slice(0, 4);
  const axes = themesData.slice(0, 4);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Accueil — Historic Streets of France Review</title>
        <meta
          name="description"
          content="Plateforme d’analyse consacrée aux rues historiques françaises : études de cas, méthodologies et ressources documentaires."
        />
        <meta property="og:title" content="Historic Streets of France Review" />
        <meta
          property="og:description"
          content="Explorer la mémoire des pavés français à travers des enquêtes architecturales, sociales et cartographiques."
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.tagline}>Explorer la mémoire des pavés français</span>
          <h1 className={styles.heroTitle}>
            Historic Streets of France Review
          </h1>
          <p className={styles.heroText}>
            Publication de référence dédiée à l’étude des rues historiques,
            croisant archives, relevés morphologiques et témoignages pour
            éclairer l’évolution des villes françaises.
          </p>
        </div>
      </section>

      <section className={styles.latest} aria-labelledby="dernieres-etudes">
        <div className={styles.sectionHeader}>
          <h2 id="dernieres-etudes" className="section-title">
            Dernières études
          </h2>
          <p className={styles.sectionIntro}>
            Synthèses récentes des enquêtes menées dans les centres anciens et
            quartiers patrimoniaux de France.
          </p>
        </div>
        <div className={styles.articleGrid}>
          {latestArticles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      </section>

      {featuredArticle && (
        <section
          className={styles.featured}
          aria-labelledby="theme-a-la-une"
        >
          <div className={styles.featuredContent}>
            <div>
              <h2 id="theme-a-la-une" className="section-title">
                Thème à la une
              </h2>
              <p className={styles.sectionIntro}>
                Focus sur une étude approfondie croisant archives, analyses
                spatiales et entretiens.
              </p>
            </div>
            <article className={styles.featuredArticle}>
              <img
                src={featuredArticle.image}
                alt={featuredArticle.imageAlt}
                className={styles.featuredImage}
                loading="lazy"
              />
              <div className={styles.featuredText}>
                <p className={styles.featuredMeta}>
                  {featuredArticle.category} •{' '}
                  {new Date(featuredArticle.date).toLocaleDateString('fr-FR', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}
                </p>
                <h3 className={styles.featuredTitle}>
                  {featuredArticle.title}
                </h3>
                <p className={styles.featuredSubtitle}>
                  {featuredArticle.subtitle}
                </p>
                <p className={styles.featuredExcerpt}>
                  {featuredArticle.excerpt}
                </p>
                <Link
                  to={`/archives/${featuredArticle.slug}`}
                  className={styles.featuredLink}
                >
                  Lire l’étude complète
                </Link>
              </div>
            </article>
          </div>
        </section>
      )}

      <section className={styles.axes} aria-labelledby="axes-recherche">
        <div className={styles.sectionHeader}>
          <h2 id="axes-recherche" className="section-title">
            Axes de recherche
          </h2>
          <p className={styles.sectionIntro}>
            Les principaux champs d’investigation structurant les analyses de la
            rédaction.
          </p>
        </div>
        <div className={styles.themeGrid}>
          {axes.map((theme) => (
            <ThemeCard key={theme.id} theme={theme} />
          ))}
        </div>
      </section>

      <section className={styles.quoteSection} aria-labelledby="parole-expert">
        <h2 id="parole-expert" className="section-title">
          Parole d’expert
        </h2>
        <ExpertQuote quote={expertQuote} />
      </section>

      <section className={styles.archive} aria-labelledby="archives-visualisation">
        <div className={styles.archiveGrid}>
          <div>
            <h2 id="archives-visualisation" className="section-title">
              Des archives au terrain
            </h2>
            <p className={styles.sectionIntro}>
              Croiser cartes anciennes, photographies et relevés actuels permet
              de comprendre les déformations et les continuités du tissu urbain.
            </p>
            <p className={styles.archiveText}>
              Chaque enquête débute par une analyse cartographique appuyée sur
              les collections nationales et municipales. Ces sources sont
              confrontées aux observations in situ et aux entretiens avec les
              habitants pour restituer la dynamique de chaque rue.
            </p>
            <Link to="/methodologie" className={styles.archiveLink}>
              Consulter la méthodologie
            </Link>
          </div>
          <figure className={styles.archiveMedia}>
            <img
              src="/images/archives-map.jpg"
              alt="Reproduction d’une carte historique de rues françaises"
              loading="lazy"
            />
            <figcaption>
              Carte cadastrale de 1825, superposée aux relevés contemporains
              pour analyser les variations de gabarit.
            </figcaption>
          </figure>
        </div>
      </section>
    </div>
  );
};

export default Home;