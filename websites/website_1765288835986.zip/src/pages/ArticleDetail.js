import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import articlesData from '../data/articles';
import styles from './ArticleDetail.module.css';

const ArticleDetail = () => {
  const { slug } = useParams();
  const article = articlesData.find((item) => item.slug === slug);

  if (!article) {
    return (
      <div className={styles.page}>
        <Helmet>
          <title>Étude introuvable — Historic Streets of France Review</title>
        </Helmet>
        <p>Cette étude n’est pas disponible.</p>
        <Link to="/archives" className={styles.backLink}>
          Retour aux archives
        </Link>
      </div>
    );
  }

  return (
    <article className={styles.page}>
      <Helmet>
        <title>{article.title} — Historic Streets of France Review</title>
        <meta name="description" content={article.subtitle} />
        <meta property="og:title" content={article.title} />
        <meta property="og:description" content={article.excerpt} />
        <meta property="og:image" content={article.image} />
      </Helmet>

      <header className={styles.header}>
        <p className={styles.meta}>
          {article.category} •{' '}
          {new Date(article.date).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
          })}{' '}
          • {article.readingTime}
        </p>
        <h1 className={styles.title}>{article.title}</h1>
        <p className={styles.subtitle}>{article.subtitle}</p>
        <p className={styles.theme}>Thématique : {article.theme}</p>
      </header>

      <figure className={styles.cover}>
        <img src={article.image} alt={article.imageAlt} loading="lazy" />
        <figcaption>{article.imageAlt}</figcaption>
      </figure>

      <div className={styles.content}>
        {article.content.map((section, index) => (
          <section key={index} className={styles.section}>
            {section.heading && section.type !== 'introduction' && (
              <h2 className={styles.sectionTitle}>{section.heading}</h2>
            )}
            {section.text.split('\n\n').map((paragraph, idx) => (
              <p key={idx}>{paragraph}</p>
            ))}
          </section>
        ))}
      </div>

      <section className={styles.sources}>
        <h2>Sources et références</h2>
        <ul>
          {article.sources.map((source) => (
            <li key={source}>{source}</li>
          ))}
        </ul>
      </section>

      <Link to="/archives" className={styles.backLink}>
        Retour à la liste des archives
      </Link>
    </article>
  );
};

export default ArticleDetail;