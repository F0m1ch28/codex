import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ConditionsUtilisation.module.css';

const ConditionsUtilisation = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Conditions d’Utilisation — Historic Streets of France Review</title>
    </Helmet>
    <h1 className={styles.title}>Conditions d’Utilisation</h1>
    <p>
      La consultation du site Historic Streets of France Review implique
      l’acceptation pleine et entière des présentes conditions d’utilisation.
    </p>
    <section className={styles.section}>
      <h2>1. Objet du site</h2>
      <p>
        Le site diffuse des contenus journalistiques et scientifiques portant
        sur les rues historiques françaises. Les informations fournies sont
        destinées à partager des analyses et ne constituent pas des documents
        contractuels.
      </p>
    </section>
    <section className={styles.section}>
      <h2>2. Propriété intellectuelle</h2>
      <p>
        L’ensemble du contenu (textes, images, cartographies, mise en page) est
        protégé par le droit d’auteur. Toute reproduction nécessite une
        autorisation écrite de la rédaction, sous réserve des exceptions
        prévues par la législation.
      </p>
    </section>
    <section className={styles.section}>
      <h2>3. Responsabilité</h2>
      <p>
        La rédaction veille à la fiabilité des informations publiées. Toutefois,
        elle ne saurait être tenue responsable des erreurs ou omissions dans les
        données fournies. Les utilisateurs sont invités à vérifier les
        informations auprès des sources citées.
      </p>
    </section>
    <section className={styles.section}>
      <h2>4. Liens externes</h2>
      <p>
        Le site contient des liens vers d’autres ressources. La rédaction ne
        dispose d’aucun contrôle sur ces contenus externes et décline toute
        responsabilité quant à leur actualité ou exactitude.
      </p>
    </section>
    <section className={styles.section}>
      <h2>5. Modification des conditions</h2>
      <p>
        Les présentes conditions peuvent être modifiées afin de refléter
        l’évolution du site. Les utilisateurs sont invités à les consulter
        régulièrement.
      </p>
    </section>
  </div>
);

export default ConditionsUtilisation;