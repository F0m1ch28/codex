import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import articlesData from '../data/articles';
import styles from './Archives.module.css';

const Archives = () => {
  const [selectedTheme, setSelectedTheme] = useState('all');

  const themes = useMemo(() => {
    const set = new Set(articlesData.map((article) => article.theme));
    return ['all', ...Array.from(set)];
  }, []);

  const filteredArticles = useMemo(() => {
    if (selectedTheme === 'all') {
      return [...articlesData].sort(
        (a, b) => new Date(b.date) - new Date(a.date)
      );
    }
    return [...articlesData]
      .filter((article) => article.theme === selectedTheme)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [selectedTheme]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Archives — Historic Streets of France Review</title>
        <meta
          name="description"
          content="Consultez l’ensemble des études publiées par Historic Streets of France Review, classées par thèmes et par villes."
        />
      </Helmet>

      <header className={styles.header}>
        <h1 className={styles.title}>Archives des études</h1>
        <p className={styles.intro}>
          Ce répertoire rassemble les dossiers publiés depuis la création de la
          revue. Chaque entrée renvoie vers une monographie de rue comprenant
          analyse historique, description morphologique, enquêtes sociales et
          bibliographie commentée.
        </p>
      </header>

      <section className={styles.filters} aria-label="Filtrer les études">
        <label htmlFor="filtre-theme" className={styles.filterLabel}>
          Thématique
        </label>
        <select
          id="filtre-theme"
          className={styles.select}
          value={selectedTheme}
          onChange={(event) => setSelectedTheme(event.target.value)}
        >
          {themes.map((theme) => (
            <option key={theme} value={theme}>
              {theme === 'all' ? 'Toutes les thématiques' : theme}
            </option>
          ))}
        </select>
      </section>

      <section className={styles.list} aria-live="polite">
        {filteredArticles.map((article) => (
          <article key={article.id} className={styles.item}>
            <img
              src={article.image}
              alt={article.imageAlt}
              loading="lazy"
              className={styles.image}
            />
            <div className={styles.content}>
              <p className={styles.meta}>
                {article.category} •{' '}
                {new Date(article.date).toLocaleDateString('fr-FR', {
                  day: '2-digit',
                  month: 'long',
                  year: 'numeric',
                })}
              </p>
              <h2 className={styles.itemTitle}>
                <Link to={`/archives/${article.slug}`}>{article.title}</Link>
              </h2>
              <p className={styles.subtitle}>{article.subtitle}</p>
              <p className={styles.excerpt}>{article.excerpt}</p>
              <div className={styles.footer}>
                <span>{article.theme}</span>
                <Link to={`/archives/${article.slug}`} className={styles.link}>
                  Consulter l’étude
                </Link>
              </div>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Archives;