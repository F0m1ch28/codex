import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Ressources.module.css';

const resources = [
  {
    name: 'Gallica — Bibliothèque nationale de France',
    description:
      'Accès aux cartes anciennes, aux photographies de rues et aux plans cadastraux numérisés.',
    url: 'https://gallica.bnf.fr',
  },
  {
    name: 'Base Mérimée — Ministère de la Culture',
    description:
      'Inventaire des monuments historiques, comprenant de nombreuses fiches détaillées sur les façades urbaines.',
    url: 'https://www.pop.culture.gouv.fr/museo/Merimee',
  },
  {
    name: 'Archives Nationales — Salle des inventaires virtuelle',
    description:
      'Consultation des fonds d’urbanisme, des minutes notariales et des plans de lotissement.',
    url: 'https://www.siv.archives-nationales.culture.gouv.fr',
  },
  {
    name: 'Géoportail de l’Urbanisme',
    description:
      'Accès aux documents d’urbanisme en vigueur, notamment aux plans de sauvegarde et de mise en valeur.',
    url: 'https://www.geoportail-urbanisme.gouv.fr',
  },
  {
    name: 'Inventaire général du patrimoine culturel — bases régionales',
    description:
      'Études détaillées des édifices et ensembles urbains, disponibles via les portails régionaux.',
    url: 'https://inventaire.patrimoine.culture.gouv.fr',
  },
  {
    name: 'Archives municipales (Paris, Marseille, Lyon, Strasbourg, Bordeaux, Aix-en-Provence)',
    description:
      'Consultation sur place ou en ligne des plans, permis de construire, photographies et registres cadastraux.',
    url: 'https://www.archives-collectivites.fr',
  },
];

const Ressources = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Ressources — Historic Streets of France Review</title>
      <meta
        name="description"
        content="Sélection de ressources documentaires et archivistiques pour approfondir l’étude des rues historiques françaises."
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>Ressources documentaires</h1>
      <p className={styles.intro}>
        Cette sélection propose des portes d’entrée vers des fonds documentaires
        publics et des bases de données utiles pour l’analyse des rues
        historiques. Les liens renvoient vers des institutions reconnues pour la
        qualité de leurs collections.
      </p>
    </header>

    <section className={styles.list}>
      {resources.map((resource) => (
        <article key={resource.url} className={styles.card}>
          <h2 className={styles.cardTitle}>{resource.name}</h2>
          <p className={styles.description}>{resource.description}</p>
          <a
            href={resource.url}
            className={styles.link}
            target="_blank"
            rel="noreferrer"
          >
            Consulter la ressource
          </a>
        </article>
      ))}
    </section>
  </div>
);

export default Ressources;