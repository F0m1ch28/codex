import React from 'react';
import { Helmet } from 'react-helmet-async';
import themesData from '../data/themes';
import articlesData from '../data/articles';
import styles from './Thematiques.module.css';

const Thematiques = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Thématiques — Historic Streets of France Review</title>
      <meta
        name="description"
        content="Vue d’ensemble des axes de recherche et de la structuration thématique des enquêtes publiées."
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>Thématiques d’étude</h1>
      <p className={styles.intro}>
        Les recherches sont regroupées autour de plusieurs axes permettant
        d’aborder les rues historiques selon leurs spécificités matérielles,
        sociales et mémorielles. Chaque thématique s’accompagne d’une sélection
        d’articles publiés.
      </p>
    </header>

    <section className={styles.grid}>
      {themesData.map((theme) => {
        const related = articlesData.filter(
          (article) => article.theme === theme.title
        );

        return (
          <article key={theme.id} className={styles.card}>
            <div className={styles.icon} aria-hidden="true">
              {theme.icon}
            </div>
            <div>
              <h2 className={styles.cardTitle}>{theme.title}</h2>
              <p className={styles.description}>{theme.description}</p>
              <p className={styles.focus}>
                Approches menées dans : {theme.focusCities.join(', ')}
              </p>
              {related.length > 0 && (
                <ul className={styles.links}>
                  {related.map((article) => (
                    <li key={article.id}>
                      <a href={`/archives/${article.slug}`}>{article.title}</a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </article>
        );
      })}
    </section>
  </div>
);

export default Thematiques;