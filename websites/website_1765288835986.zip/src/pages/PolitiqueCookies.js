import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PolitiqueCookies.module.css';

const PolitiqueCookies = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Politique des Cookies — Historic Streets of France Review</title>
    </Helmet>
    <h1 className={styles.title}>Politique des Cookies</h1>
    <p>
      Cette page décrit l’usage des cookies sur le site Historic Streets of
      France Review.
    </p>
    <section className={styles.section}>
      <h2>Cookies fonctionnels</h2>
      <p>
        Le site utilise un cookie de préférence pour mémoriser la décision des
        visiteurs quant à l’acceptation des cookies analytiques. Ce cookie est
        indispensable au fonctionnement du bandeau d’information.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Cookies analytiques</h2>
      <p>
        Des cookies de mesure d’audience peuvent être déposés afin de suivre la
        fréquentation globale du site. Les données collectées sont anonymisées
        et ne permettent pas d’identifier les visiteurs.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Gestion des cookies</h2>
      <p>
        Les visiteurs peuvent accepter ou refuser les cookies analytiques via le
        bandeau dédié. Ils peuvent également supprimer les cookies depuis les
        paramètres de leur navigateur. En cas de changement d’avis, il suffit de
        vider les cookies du navigateur pour faire réapparaître le bandeau.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Contact</h2>
      <p>
        Pour toute question concernant cette politique, écrire à
        contact@historicstreets-fr-review.org.
      </p>
    </section>
  </div>
);

export default PolitiqueCookies;