import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Methodologie.module.css';

const Methodologie = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Méthodologie — Historic Streets of France Review</title>
      <meta
        name="description"
        content="Cadre méthodologique appliqué par la rédaction pour documenter les rues historiques françaises."
      />
    </Helmet>

    <header className={styles.header}>
      <p className={styles.lead}>
        La démarche méthodologique combine relevés de terrain, dépouillement
        d’archives, analyse des représentations et enquêtes qualitatives. Chaque
        publication repose sur un protocole commun garantissant la comparabilité
        des études et la fiabilité des données.
      </p>
    </header>

    <section className={styles.section}>
      <h2 className={styles.title}>1. Inventaire des sources</h2>
      <p>
        Les enquêtes débutent par la constitution d’un corpus documentaire :
        plans cadastraux, minutes notariales, photographies anciennes, fonds
        iconographiques et publications scientifiques. L’équipe dresse une fiche
        descriptive pour chaque rue, précisant les lacunes, les périodes
        documentées et la disponibilité des sources numériques.
      </p>
      <p>
        Une attention particulière est accordée aux archives municipales, aux
        fonds des services du patrimoine et aux collections de la Bibliothèque
        nationale de France. Les documents sont géoréférencés afin de faciliter
        la confrontation avec les relevés contemporains.
      </p>
    </section>

    <section className={styles.section}>
      <h2 className={styles.title}>2. Relevés morphologiques</h2>
      <p>
        Les équipes effectuent des relevés in situ, en s’appuyant sur des
        plans-topos et des observations photographiques systématiques. Les
        gabarits des façades, les matériaux, les hauteurs et les rythmes
        d’ouvertures sont consignés dans une grille commune. Cette approche
        permet d’identifier les strates de construction et les interventions
        récentes.
      </p>
      <p>
        Les relevés s’accompagnent de croquis d’ambiance et de repérages
        des espaces publics adjacents (placettes, escaliers, traboules, cours).
        Les discontinuités du revêtement, les dispositifs de gestion des flux et
        le mobilier urbain sont systématiquement notés.
      </p>
    </section>

    <section className={styles.section}>
      <h2 className={styles.title}>3. Entretiens et observations</h2>
      <p>
        Afin de rendre compte des usages, la rédaction mène des entretiens avec
        des habitants, des commerçants, des artisans et des responsables
        institutionnels. Les questions portent sur les trajectoires
        résidentielles, la perception des transformations et la relation au
        patrimoine.
      </p>
      <p>
        Des observations participantes sont également réalisées lors d’événements
        publics (journées du patrimoine, marchés, promenades guidées). Elles
        apportent un éclairage sur les temporalités d’usage et les dispositifs
        de médiation culturelle.
      </p>
    </section>

    <section className={styles.section}>
      <h2 className={styles.title}>4. Traitement et restitution</h2>
      <p>
        Les matériaux collectés sont synthétisés dans des dossiers thématiques.
        Chaque article est structuré en sections récurrentes : chronologie,
        morphologie, pratiques sociales, politiques de conservation et mémoire.
        Les citations d’archives sont contextualisées pour faciliter la lecture.
      </p>
      <p>
        Les visualisations (cartes, frises, diagrammes) sont produites à partir
        de logiciels libres, assurant la traçabilité des données. Les
        bibliographies détaillent l’ensemble des sources mobilisées, y compris
        les documents iconographiques.
      </p>
    </section>

    <section className={styles.section}>
      <h2 className={styles.title}>5. Relecture et validation</h2>
      <p>
        Avant publication, chaque dossier est relu par deux membres de la
        rédaction, appartenant à des disciplines différentes. Cette relecture
        croisée garantit la cohérence scientifique et la clarté rédactionnelle.
        Les partenaires locaux peuvent également formuler des commentaires pour
        vérifier l’exactitude des données.
      </p>
    </section>

    <section className={styles.section}>
      <h2 className={styles.title}>6. Mise à jour</h2>
      <p>
        Les rues évoluent au fil des projets urbains et des usages. Les articles
        sont donc régulièrement actualisés. Un système de veille recense les
        nouveaux documents d’archives, les travaux de restauration et les
        initiatives citoyennes pertinentes.
      </p>
    </section>
  </div>
);

export default Methodologie;