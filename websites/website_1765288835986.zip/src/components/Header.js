import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { label: 'Accueil', path: '/' },
  { label: 'À Propos', path: '/a-propos' },
  { label: 'Méthodologie', path: '/methodologie' },
  { label: 'Archives', path: '/archives' },
  { label: 'Thématiques', path: '/thematiques' },
  { label: 'Ressources', path: '/ressources' },
  { label: 'Contact', path: '/contact' },
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [elevated, setElevated] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setElevated(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = 'auto';
      };
    }
    document.body.style.overflow = 'auto';
    return undefined;
  }, [menuOpen]);

  return (
    <header className={`${styles.header} ${elevated ? styles.elevated : ''}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo}>
          <span className={styles.logoAccent}>Historic Streets</span>
          <span className={styles.logoSub}>of France Review</span>
        </NavLink>

        <button
          className={`${styles.burger} ${menuOpen ? styles.burgerOpen : ''}`}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="navigation-principale"
          aria-label="Ouvrir ou fermer la navigation principale"
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          id="navigation-principale"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                  onClick={() => setMenuOpen(false)}
                  end={item.path === '/'}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className={styles.actions}>
            <button
              type="button"
              className={styles.langButton}
              aria-label="Basculer la langue (fonctionnalité en préparation)"
              disabled
            >
              FR
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;