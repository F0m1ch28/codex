import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ArticleCard.module.css';

const ArticleCard = ({ article }) => {
  const publicationDate = new Date(article.date).toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  return (
    <article className={styles.card}>
      <Link to={`/archives/${article.slug}`} className={styles.mediaWrapper}>
        <img
          src={article.image}
          alt={article.imageAlt}
          className={styles.image}
          loading="lazy"
        />
      </Link>
      <div className={styles.content}>
        <p className={styles.meta}>
          <span className={styles.category}>{article.category}</span>
          <span aria-hidden="true">•</span>
          <span>{publicationDate}</span>
        </p>
        <h3 className={styles.title}>
          <Link to={`/archives/${article.slug}`}>{article.title}</Link>
        </h3>
        <p className={styles.subtitle}>{article.subtitle}</p>
        <p className={styles.excerpt}>{article.excerpt}</p>
        <div className={styles.footer}>
          <span className={styles.readingTime}>{article.readingTime}</span>
          <Link to={`/archives/${article.slug}`} className={styles.link}>
            Lire l’étude
          </Link>
        </div>
      </div>
    </article>
  );
};

export default ArticleCard;