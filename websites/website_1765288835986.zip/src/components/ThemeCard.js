import React from 'react';
import styles from './ThemeCard.module.css';

const ThemeCard = ({ theme }) => {
  return (
    <div className={styles.card}>
      <div className={styles.icon} aria-hidden="true">
        {theme.icon}
      </div>
      <div>
        <h3 className={styles.title}>{theme.title}</h3>
        <p className={styles.description}>{theme.description}</p>
        {theme.focusCities && (
          <p className={styles.cities}>
            Focus: {theme.focusCities.join(' • ')}
          </p>
        )}
      </div>
    </div>
  );
};

export default ThemeCard;