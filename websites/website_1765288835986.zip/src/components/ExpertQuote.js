import React from 'react';
import styles from './ExpertQuote.module.css';

const ExpertQuote = ({ quote }) => {
  return (
    <figure className={styles.wrapper}>
      <blockquote className={styles.quote}>
        <span className={styles.marks} aria-hidden="true">
          «
        </span>
        {quote.text}
        <span className={styles.marks} aria-hidden="true">
          »
        </span>
      </blockquote>
      <figcaption className={styles.caption}>
        <span className={styles.name}>{quote.name}</span>
        <span className={styles.role}>{quote.role}</span>
        <span className={styles.affiliation}>{quote.affiliation}</span>
      </figcaption>
    </figure>
  );
};

export default ExpertQuote;