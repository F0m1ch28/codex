import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-title">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <h2 id="footer-title" className={styles.title}>
            Historic Streets of France Review
          </h2>
          <p className={styles.description}>
            Publication d’analyse consacrée aux rues historiques françaises,
            explorant leurs dimensions architecturales, sociales et mémorielles.
          </p>
          <a
            className={styles.email}
            href="mailto:contact@historicstreets-fr-review.org"
          >
            contact@historicstreets-fr-review.org
          </a>
        </div>
        <div className={styles.links}>
          <div>
            <h3 className={styles.subtitle}>Navigation</h3>
            <ul>
              <li>
                <Link to="/">Accueil</Link>
              </li>
              <li>
                <Link to="/a-propos">À Propos</Link>
              </li>
              <li>
                <Link to="/methodologie">Méthodologie</Link>
              </li>
              <li>
                <Link to="/archives">Archives</Link>
              </li>
              <li>
                <Link to="/thematiques">Thématiques</Link>
              </li>
              <li>
                <Link to="/ressources">Ressources</Link>
              </li>
              <li>
                <Link to="/contact">Contact</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.subtitle}>Cadre juridique</h3>
            <ul>
              <li>
                <Link to="/conditions-utilisation">
                  Conditions d&apos;Utilisation
                </Link>
              </li>
              <li>
                <Link to="/politique-confidentialite">
                  Politique de Confidentialité
                </Link>
              </li>
              <li>
                <Link to="/politique-cookies">Politique des Cookies</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <p className={styles.copyright}>
        © {new Date().getFullYear()} Historic Streets of France Review. Tous
        droits réservés.
      </p>
    </footer>
  );
};

export default Footer;