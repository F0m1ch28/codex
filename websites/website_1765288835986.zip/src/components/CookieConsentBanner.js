import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './CookieConsentBanner.module.css';

const STORAGE_KEY = 'hsfr-cookie-consent';

const CookieConsentBanner = () => {
  const [visible, setVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ status: 'accepted', timestamp: Date.now() })
    );
    setVisible(false);
  };

  const handleCustomize = () => {
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ status: 'customize', timestamp: Date.now() })
    );
    setVisible(false);
    navigate('/politique-cookies');
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <p>
          Historic Streets of France Review utilise des cookies analytiques
          strictement destinés à suivre l’usage éditorial du site. Aucune donnée
          n’est exploitée à des fins commerciales.
        </p>
      </div>
      <div className={styles.actions}>
        <button
          type="button"
          onClick={handleCustomize}
          className={styles.secondary}
        >
          Personnaliser
        </button>
        <button type="button" onClick={handleAccept} className={styles.primary}>
          Accepter
        </button>
      </div>
    </div>
  );
};

export default CookieConsentBanner;