import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieConsentBanner from './components/CookieConsentBanner';
import ScrollToTop from './components/ScrollToTop';
import ScrollToTopButton from './components/ScrollToTopButton';
import Home from './pages/Home';
import APropos from './pages/APropos';
import Methodologie from './pages/Methodologie';
import Archives from './pages/Archives';
import ArticleDetail from './pages/ArticleDetail';
import Thematiques from './pages/Thematiques';
import Ressources from './pages/Ressources';
import Contact from './pages/Contact';
import ConditionsUtilisation from './pages/ConditionsUtilisation';
import PolitiqueConfidentialite from './pages/PolitiqueConfidentialite';
import PolitiqueCookies from './pages/PolitiqueCookies';
import styles from './App.module.css';

const App = () => {
  return (
    <div className={styles.app}>
      <ScrollToTop />
      <Header />
      <main className={styles.main} id="contenu-principal">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/a-propos" element={<APropos />} />
          <Route path="/methodologie" element={<Methodologie />} />
          <Route path="/archives" element={<Archives />} />
          <Route path="/archives/:slug" element={<ArticleDetail />} />
          <Route path="/thematiques" element={<Thematiques />} />
          <Route path="/ressources" element={<Ressources />} />
          <Route path="/contact" element={<Contact />} />
          <Route
            path="/conditions-utilisation"
            element={<ConditionsUtilisation />}
          />
          <Route
            path="/politique-confidentialite"
            element={<PolitiqueConfidentialite />}
          />
          <Route path="/politique-cookies" element={<PolitiqueCookies />} />
        </Routes>
      </main>
      <Footer />
      <CookieConsentBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;