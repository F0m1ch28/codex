const themes = [
  {
    id: 'evolution-architecturale',
    title: 'Évolution architecturale',
    description:
      'Études comparatives des strates constructives, des matériaux et des techniques employées sur la longue durée.',
    icon: '🏛️',
    focusCities: ['Paris', 'Strasbourg', 'Lyon'],
  },
  {
    id: 'histoires-sociales',
    title: 'Histoires sociales',
    description:
      'Analyse des usages quotidiens, des sociabilités urbaines et des trajectoires résidentielles le long des rues étudiées.',
    icon: '👥',
    focusCities: ['Marseille', 'Bordeaux', 'Paris'],
  },
  {
    id: 'patrimoine-et-risques',
    title: 'Patrimoine et risques',
    description:
      'Observation des politiques de conservation, de la gestion des risques et des dispositifs de résilience.',
    icon: '🛡️',
    focusCities: ['Lyon', 'Marseille', 'Paris'],
  },
  {
    id: 'cartographies-historiques',
    title: 'Cartographies historiques',
    description:
      'Croisement de plans anciens, de photographies et de modélisations contemporaines pour documenter les transformations.',
    icon: '🗺️',
    focusCities: ['Strasbourg', 'Bordeaux', 'Aix-en-Provence'],
  },
  {
    id: 'mediations-culturelles',
    title: 'Médiations culturelles',
    description:
      'Études des dispositifs pédagogiques et des parcours de valorisation mis en place autour des rues historiques.',
    icon: '🔎',
    focusCities: ['Strasbourg', 'Marseille', 'Lyon'],
  },
];

export default themes;