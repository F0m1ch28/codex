const expertQuote = {
  text: `Une rue historique ne se résume pas à un alignement patrimonial : elle constitue un palimpseste de décisions techniques, d’usages quotidiens et de récits collectifs. Examiner la rue dans la durée revient à comprendre comment une société organise sa mémoire et ses mobilités au fil des générations.`,
  name: 'Dr Claire Martin',
  role: 'Historienne de l’urbanisme',
  affiliation: 'CNRS – UMR 8546 “Morphologie des villes”',
};

export default expertQuote;