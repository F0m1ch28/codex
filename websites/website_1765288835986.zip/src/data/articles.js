const articles = [
  {
    id: 1,
    slug: 'rue-des-barres-paris',
    title: 'Rue des Barres : continuités médiévales au cœur du Marais',
    subtitle:
      'Analyse morphologique et sociale d’une rue parisienne préservée des percées haussmanniennes.',
    category: 'Paris',
    theme: 'Quartiers médiévaux',
    date: '2024-05-28',
    image: '/images/rue-des-barres.jpg',
    imageAlt:
      'Vue pavée de la rue des Barres dans le quartier du Marais à Paris',
    excerpt:
      'Les strates successives de la rue des Barres offrent un laboratoire pour comprendre les arbitrages entre conservation patrimoniale, usages quotidiens et mémoires collectives dans le centre historique parisien.',
    readingTime: '11 min',
    featured: true,
    content: [
      {
        type: 'introduction',
        text: `Située à deux pas de la Seine, la rue des Barres se glisse entre l’église Saint-Gervais-Saint-Protais et le bras du quai de l’Hôtel-de-Ville. Cette artère courte, pavée, conserve une largeur inégale héritée de l’époque médiévale. L’absence de gabarit uniforme attire l’attention des urbanistes, car elle témoigne d’une adaptation continue au relief et aux usages de proximité. Les façades à pans de bois, recalibrées au XVIIe siècle, cohabitent avec des immeubles reconstruits au XIXe siècle après les travaux de salubrité.

Les archives municipales indiquent l’existence de cette voie dès le XIVe siècle sous la forme d’un passage desservant les ateliers des couvreurs. Des plans dressés par l’abbaye de Saint-Gervais mentionnent des dénominations successives, révélant les négociations entre autorités religieuses et pouvoirs civils. L’étude des matrices paroissiales montre que la rue ne subit pas de percée haussmannienne, ce qui permet aujourd’hui de mesurer la densité originale des îlots médiévaux sur la rive droite.

Au début du XXe siècle, l’administration parisienne hésite entre la démolition totale du secteur, jugé insalubre, et une politique de restauration ciblée. Les photographies de Charles Marville, prises dans les années 1860, fournissent un matériau visuel précieux pour comparer l’état des façades avant la réforme des alignements. Les historiens du bâti observent que les transformations ont privilégié la consolidation intérieure plutôt que la reconstruction, ce qui explique la permanence d’un paysage urbain texturé.`,
      },
      {
        type: 'section',
        heading: 'Stratigraphie du bâti',
        text: `La stratigraphie constructive de la rue des Barres se lit dans l’enchevêtrement des charpentes, corniches et encorbellements. Les relevés réalisés par l’Atelier parisien d’urbanisme au début des années 2000 mettent en évidence trois campagnes majeures : un premier ensemble médiéval, une phase de consolidation postérieure à 1607 après l’effondrement du pont Notre-Dame, et un regain de réaménagements menés entre 1880 et 1910. Chaque campagne laisse une marque distincte sur la modulation des ouvertures et la profondeur des rez-de-chaussée.

Les maçonneries en pierre calcaire alternent avec des remplissages en briques introduits pour améliorer la résistance au feu. L’étude stylistique montre que les encadrements sculptés, bien que retouchés, conservent des motifs floraux typiques des ateliers parisiens du XVIe siècle. Les restaurations contemporaines se veulent réversibles : l’usage de mortiers à base de chaux et de pigments naturels permet de respecter la matérialité initiale tout en répondant aux normes actuelles d’isolation.

En sous-sol, la rue repose sur un réseau de caves voûtées que l’on peut rapprocher des anciens entrepôts viticoles installés le long de la Seine. Les sondages archéologiques menés lors des travaux de réseaux humides ont révélé des niveaux d’occupation successifs où se mêlent tessons médiévaux, fragments de faïence du XVIIIe siècle et conduits de chauffage moderne. Cette superposition matérialise l’adaptation continue des structures domestiques aux contraintes logistiques du centre-ville parisien.`,
      },
      {
        type: 'section',
        heading: 'Fonctions sociales et pratiques quotidiennes',
        text: `Les enquêtes menées par les sociologues urbains dans les années 1970 indiquent que la rue des Barres abritait encore un tissu mixte de logements ouvriers et de petits commerces. L’arrivée de la piétonnisation progressive, engagée en 1981, a modifié les flux de circulation et favorisé le développement d’activités culturelles. Toutefois, les données collectées par l’Observatoire parisien de la gentrification montrent que la fonction résidentielle demeure dominante, avec une majorité d’appartements occupés à l’année.

Les entretiens réalisés avec les habitants mettent en avant les usages quotidiens de la rue comme espace semi-public. Les seuils de boutiques anciennes servent de lieux de rencontre, tandis que les cours intérieures jouent un rôle de micro-jardins. Les gestionnaires du patrimoine bâti insistent sur la nécessité de préserver ces espaces intermédiaires, car ils participent à la convivialité qui caractérise les anciens quartiers paroissiaux.

Lors des Journées européennes du patrimoine, la rue des Barres devient une vitrine des pratiques de médiation culturelle. Des circuits guidés abordent la relation entre le bâti et les archives, tandis que des ateliers de cartographie participative invitent les visiteurs à retracer les évolutions des décors de façade. Cette appropriation temporaire souligne les enjeux de diffusion des savoirs historiques dans un quartier soumis à une forte pression touristique.`,
      },
      {
        type: 'section',
        heading: 'Mémoire et conservation',
        text: `La mémoire de la rue est étroitement liée aux épisodes de résistance pendant la Seconde Guerre mondiale. Les registres du Comité parisien de libération mentionnent des caches d’armes aménagées dans certaines caves. Cet aspect est aujourd’hui intégré à la signalétique patrimoniale via des plaques explicatives, élaborées en collaboration avec les familles descendantes. Le discours mémoriel veille à rester factuel, privilégiant la restitution documentaire.

Les politiques de conservation se concentrent sur la gestion de la lumière et de l’humidité, facteurs déterminants pour la durabilité des matériaux anciens. Des capteurs, installés depuis 2017, transmettent des données à l’EPA Paris. Ces informations orientent les décisions d’entretien, notamment pour le traitement des menuiseries. L’approche adoptée favorise des interventions ciblées plutôt que des restructurations globales.

La rue des Barres constitue enfin un laboratoire de réflexion sur la cohérence des itinéraires historiques du Marais. Les urbanistes y testent des dispositifs de signalétique tactile pour les visiteurs malvoyants, tandis que les historiens croisent les sources cartographiques anciennes avec des modélisations 3D. Ce travail approfondit la compréhension des dynamiques urbaines de longue durée, offrant un cadre rigoureux pour penser la conservation d’un patrimoine vivant.`,
      },
      {
        type: 'conclusion',
        heading: 'Conclusion',
        text: `Ce chemin pavé, bien qu’étroit, illustre la manière dont une rue peut concentrer des strates de vie quotidienne, de transformations techniques et de mémoire collective. La rue des Barres s’inscrit dans une continuité urbaine qui dépasse la simple esthétique médiévale : elle révèle les mécanismes d’arbitrage entre confort contemporain et héritage historique. En documentant minutieusement ses mutations, les chercheurs disposent d’un terrain d’observation privilégié pour analyser les équilibres complexes qui façonnent les centres anciens parisiens.`,
      },
    ],
    sources: [
      'Archives de Paris, série D1 142, plans du quartier Saint-Gervais (XIVe–XIXe siècles).',
      'Atelier parisien d’urbanisme, relevés morphologiques du Marais, campagne 2001-2005.',
      'Marville, Charles, Photographies de Paris, collection BnF, département des Estampes.',
    ],
  },
  {
    id: 2,
    slug: 'cours-mirabeau-aix-en-provence',
    title: 'Cours Mirabeau : promenade aixoise et gouvernance patrimoniale',
    subtitle:
      'Étude des alignements, des usages sociaux et des adaptations climatiques de la célèbre artère provençale.',
    category: 'Aix-en-Provence',
    theme: 'Tracés monumentaux',
    date: '2024-04-30',
    image: '/images/cours-mirabeau.jpg',
    imageAlt: 'Perspective du Cours Mirabeau à Aix-en-Provence avec ses platanes',
    excerpt:
      'Le Cours Mirabeau illustre la manière dont une ville provençale articule prestige historique, mobilités piétonnes et stratégies environnementales contemporaines.',
    readingTime: '10 min',
    featured: false,
    content: [
      {
        type: 'introduction',
        text: `Le Cours Mirabeau, axe majeur d’Aix-en-Provence, s’étire entre la Rotonde et la place Forbin. Conçu au XVIIe siècle comme promenade bordée d’hôtels particuliers, il demeure un repère pour comprendre les mutations urbaines provençales. Sa largeur généreuse, ponctuée de fontaines, répondait à la volonté des consuls d’aménager un espace de représentation civique. Aujourd’hui encore, la perspective arborée offre un cas d’école pour l’étude des alignements réguliers issus des modèles baroques italiens.

Les archives de la ville d’Aix indiquent que l’ordonnance primitive fut adoptée en 1646, mais que les travaux d’expropriation s’échelèrent sur plusieurs décennies. Les plans conservés à la bibliothèque Méjanes montrent la progression des chantiers et l’ajout progressif des alignements de platanes. Ces documents éclairent la manière dont les propriétaires rivaux furent intégrés au projet collectif, souvent par le biais de compromis négociés autour de la hauteur des façades et du dessin des balcons.

Au XVIIIe siècle, le Cours Mirabeau devient un théâtre social où se rencontrent magistrats, marchands et voyageurs. Les récits de voyageurs, notamment ceux de l’abbé Labat, relèvent la présence de cafés et de librairies qui participent à la diffusion des idées. Cette sociabilité bourgeoise imprime durablement l’imaginaire du lieu, transformé en symbole d’équilibre entre prestige aristocratique et ouverture commerciale.`,
      },
      {
        type: 'section',
        heading: 'Morphologie et matériaux',
        text: `La morphologie actuelle résulte d’interventions successives. Les hôtels particuliers conservent des façades ornées de mascarons et de ferronneries, tandis que les rez-de-chaussée ont été remaniés pour accueillir des vitrines modernes. Les études menées par le service Patrimoine de la ville montrent que la cohabitation entre pierre de Rognes et pierre de Bibémus confère un nuançage ocre distinctif. Les restaurations récentes privilégient des techniques de nettoyage douces pour éviter l’altération des reliefs sculptés.

Au sol, la chaussée a connu plusieurs transformations. Les pavés, remplacés par un enrobé lisse dans les années 1930, ont laissé place depuis 2002 à un revêtement mixte intégrant des bandes de pierre naturelle. Cette décision répond à des contraintes de circulation douce tout en réaffirmant le caractère monumental de la promenade. Les fontaines, quant à elles, font l’objet d’un suivi hydrique précis afin d’équilibrer le débit sans dénaturer les bassins d’origine.

La présence d’un réseau souterrain complexe, composé de caves voûtées et de galeries d’évacuation, constitue un élément peu visible mais déterminant. Les diagnostics réalisés lors des travaux de rénovation des réseaux d’eau ont mis en évidence des systèmes d’adduction datant du XVIIe siècle. Leur conservation implique des ajustements minutieux lorsque de nouveaux commerces s’installent, notamment en matière de ventilation et de sécurité incendie.`,
      },
      {
        type: 'section',
        heading: 'Usages sociaux et perceptions',
        text: `Les observatoires urbains locaux identifient plusieurs temporalités d’usage. Le matin, le Cours est fréquenté par les habitants qui y trouvent marchés ponctuels et terrasses calmes. L’après-midi, les flux touristiques s’intensifient, attirés par la perspective sur la montagne Sainte-Victoire. Les études menées par l’université d’Aix-Marseille montrent que les habitants s’approprient la promenade comme un espace de représentation familiale, privilégiant les parcours linéaires plutôt que les arrêts prolongés.

Les transformations commerciales, notamment l’installation de franchises internationales, suscitent des débats récurrents. Les associations de défense du patrimoine plaident pour un équilibre entre modernité commerciale et respect du caractère historique. Les données recueillies via des enquêtes participatives révèlent que la population locale valorise la diversité artisanale et les librairies indépendantes, considérées comme des relais de la mémoire intellectuelle du lieu.

Lors des évènements culturels, tels que les festivals de musique ou les processions traditionnelles, le Cours Mirabeau devient un plateau scénique. Les dispositifs temporaires, par exemple les structures d’éclairage, sont pensés pour ne pas abîmer les façades. Les urbanistes suivent ces installations afin d’évaluer l’impact sur la perception nocturne du site, question cruciale pour la mise en valeur patrimoniale.`,
      },
      {
        type: 'section',
        heading: 'Gestion climatique et végétale',
        text: `Les platanes, éléments identitaires, sont au centre de toutes les attentions. Les services techniques ont mis en place un suivi phytosanitaire régulier en raison des risques liés au chancre coloré. Des plans de remplacement échelonnés garantissent la continuité de l’ombrage sans perturber l’homogénéité de l’allée. Des essais de sols perméables ont été menés pour améliorer la circulation de l’eau autour des racines, limitant ainsi les phénomènes de tassement.

La question microclimatique est également traitée par l’installation de brumisateurs discrets durant les épisodes caniculaires. Les relevés de température montrent une baisse significative dans la zone centrale, bénéfique pour les piétons. Cette stratégie s’inscrit dans le plan climat d’Aix-en-Provence, démontrant que la conservation du patrimoine peut intégrer des objectifs environnementaux contemporains.

Enfin, les projections urbaines envisagent la création d’un parcours explicatif numérique. Un dispositif d’application mobile, développé avec le musée Granet, permettra de géolocaliser des documents d’archives et des récits sonores. Ce projet répond à un double objectif : renforcer la compréhension historique du Cours Mirabeau et réguler les déplacements des visiteurs en favorisant des haltes informatives. L’expérimentation amorcée en 2023 montre un intérêt croissant du public pour cette approche raisonnée du tourisme urbain.`,
      },
      {
        type: 'conclusion',
        heading: 'Conclusion',
        text: `Le Cours Mirabeau illustre une dynamique d’ajustement permanent entre prestige patrimonial et usages quotidiens. L’étude croisée des plans anciens, des évolutions matérielles et des pratiques sociales met en valeur la capacité d’un axe historique à absorber les transformations sans perdre son identité. La promenade aixoise demeure un terrain privilégié pour observer la manière dont les villes françaises articulent modernité, mémoire et confort urbain.`,
      },
    ],
    sources: [
      'Bibliothèque Méjanes, fonds iconographique du Cours Mirabeau (XVIIe-XXe siècles).',
      'Ville d’Aix-en-Provence, service Patrimoine, dossiers techniques 2000-2023.',
      'Université d’Aix-Marseille, Observatoire des pratiques urbaines, rapport 2022.',
    ],
  },
  {
    id: 3,
    slug: 'rue-du-musee-strasbourg',
    title: 'Rue du Musée : interface strasbourgeoise entre patrimoine et médiation',
    subtitle:
      'Une rue charnière reliant l’ancien chemin de ronde aux institutions culturelles contemporaines.',
    category: 'Strasbourg',
    theme: 'Patrimoine urbain',
    date: '2024-03-22',
    image: '/images/rue-du-musee.jpg',
    imageAlt:
      'Rue du Musée à Strasbourg avec façades Renaissance et visiteurs',
    excerpt:
      'Entre influences germaniques et héritage français, la rue du Musée à Strasbourg offre un terrain d’étude pour la cohabitation entre institutions culturelles et vie résidentielle.',
    readingTime: '10 min',
    featured: false,
    content: [
      {
        type: 'introduction',
        text: `La rue du Musée, tracée le long de l’ancienne enceinte médiévale de Strasbourg, relie la place Broglie au quai des Bateliers. Son nom témoigne de la proximité immédiate du Palais Rohan et des collections municipales. Dès le XVIe siècle, la voie constituait un passage stratégique pour accéder aux entrepôts fluviaux. Aujourd’hui, elle synthétise les influences franco-allemandes qui façonnent l’identité urbaine strasbourgeoise.

Les plans de Daniel Specklin, architecte de la ville au XVIe siècle, révèlent que la rue reprenait un ancien chemin de ronde. Les fortifications ayant été démantelées au XVIIIe siècle, l’alignement des façades s’est régularisé tout en conservant des décrochements visibles. Les archives de l’administration municipale montrent que cette régularisation s’est accompagnée d’une taxation différenciée des ouvertures selon leur largeur, ce qui explique la diversité des baies.

Lors de l’annexion de l’Alsace-Lorraine en 1871, la rue du Musée devient un enjeu symbolique. Les autorités impériales y installent des services administratifs, cherchant à démontrer leur attachement à l’héritage architectural local. Cette volonté de conciliation se traduit par des restaurations minutieuses des façades Renaissance, financées par la caisse municipale mais supervisées par des architectes allemands.`,
      },
      {
        type: 'section',
        heading: 'Assemblage architectural',
        text: `Les relevés récents effectués par l’Inventaire général montrent la coexistence de maisons à colombages et d’immeubles néoclassiques tardifs. Les structures à pans de bois sont dotées d’encorbellements sculptés, tandis que les édifices plus récents adoptent des façades enduites ornées de frontons. Les matériaux témoignent d’un dialogue entre grès rose des Vosges et pierre calcaire importée, offrant une palette chromatique raffinée.

Les travaux de restauration menés dans les années 1980 ont privilégié une approche différenciée. Chaque façade a fait l’objet d’une étude historique détaillée avant intervention. Cette méthodologie a permis d’éviter les uniformisations et de conserver la singularité de chaque parcelle. Les équipes ont également réhabilité les portails d’accès aux cours intérieures, mettant en lumière des poternes médiévales précédemment dissimulées.

En sous-sol, l’existence de caves voûtées du XIIIe siècle a été confirmée par des sondages. Certaines servent aujourd’hui de réserves pour les musées voisins, d’autres sont ouvertes au public lors d’évènements ponctuels. Ces espaces souterrains rappellent que la rue constituait jadis un maillon logistique essentiel entre la cathédrale et l’Ill.`,
      },
      {
        type: 'section',
        heading: 'Fonctions urbaines contemporaines',
        text: `La rue du Musée accueille un mélange d’institutions culturelles, de librairies spécialisées et de logements privés. Les statistiques de l’Office de tourisme indiquent un flux régulier de visiteurs, particulièrement durant les expositions temporaires du Palais Rohan. Toutefois, la municipalité veille à ne pas transformer la rue en simple galerie touristique : des quotas d’artisans locaux sont maintenus afin de préserver la diversité fonctionnelle.

Les habitants soulignent l’importance des circulations douces. Depuis 2015, un plan de mobilité favorise les piétons et les cyclistes. Le revêtement a été repensé pour réduire les vibrations ressenties par les résidents, en utilisant des pavés sciés. Cette initiative s’accompagne d’un éclairage adapté qui met en valeur les façades sans créer de nuisances lumineuses intrusives.

Les moments forts de la rue s’articulent autour des événements organisés par les musées strasbourgeois. Workshops, conférences et promenades sonores investissent les trottoirs et les cours. Les chercheurs en urbanisme y voient un exemple probant de coordination entre institutions culturelles et habitants, chacun contribuant à la valorisation de l’espace public.`,
      },
      {
        type: 'section',
        heading: 'Mémoire et médiation',
        text: `La rue du Musée a traversé les bouleversements politiques du XXe siècle. Des plaques commémoratives rappellent le rôle des résistants strasbourgeois et l’évacuation des collections pendant la Seconde Guerre mondiale. Les témoignages recueillis par les historiens locaux mettent en lumière le réseau de solidarités qui s’est formé autour des ateliers d’artisans pour protéger les œuvres et les habitants.

La médiation culturelle se matérialise aujourd’hui par des dispositifs multilingues. Des parcours audioguidés disponibles en français, allemand et alsacien restituent la complexité identitaire de la rue. Les applications numériques proposent des superpositions de plans historiques, permettant aux visiteurs de visualiser les transformations du parcellaire. Les retours d’expérience soulignent l’intérêt d’une approche pédagogique fondée sur les archives.

Les projets à venir incluent la création d’un centre de documentation accessible aux étudiants en architecture. L’objectif est de centraliser les relevés, photographies et études de cas portant sur la rue et son voisinage immédiat. Cette base de données contribuera à renforcer la recherche sur les interfaces entre patrimoine bâti et médiation culturelle.`,
      },
      {
        type: 'conclusion',
        heading: 'Conclusion',
        text: `La rue du Musée illustre la capacité de Strasbourg à articuler héritage médiéval, influences germaniques et innovations contemporaines. Son étude met en évidence l’importance d’une gouvernance partagée entre institutions, habitants et chercheurs. En observant ses façades, ses caves et ses usages, on saisit la densité d’un récit urbain collectif où chaque pierre participe à la narration d’une identité plurielle.`,
      },
    ],
    sources: [
      'Archives municipales de Strasbourg, série 804 W, plans Specklin.',
      'Inventaire général du patrimoine culturel, dossier Rue du Musée, 1981-2019.',
      'Office de tourisme de Strasbourg, indicateurs de fréquentation 2021-2023.',
    ],
  },
  {
    id: 4,
    slug: 'rue-du-panier-marseille',
    title: 'Rue du Panier : pentes marseillaises et héritages populaires',
    subtitle:
      'Entre mémoire portuaire et création contemporaine, un parcours dans le plus ancien quartier de Marseille.',
    category: 'Marseille',
    theme: 'Quartiers populaires',
    date: '2024-02-15',
    image: '/images/rue-du-panier.jpg',
    imageAlt:
      'Rue du Panier à Marseille avec façades colorées et perspective sur la Vieille Charité',
    excerpt:
      'La rue du Panier condense les transformations d’un quartier portuaire marseillais en équilibrant conservation matérielle, initiatives artistiques et vigilance technique.',
    readingTime: '10 min',
    featured: false,
    content: [
      {
        type: 'introduction',
        text: `La rue du Panier serpente dans le plus ancien quartier de Marseille, portant le nom d’une enseigne d’auberge du XVe siècle. Elle se faufile entre les façades colorées du quartier homonyme, reliant la Vieille Charité au Vieux-Port. Son tracé sinueux et ses escaliers abrupts témoignent d’un urbanisme préhaussmannien adapté aux reliefs calcaires de la colline.

Les archives municipales situent l’ouverture de la rue autour du XIIIe siècle, lorsque le port s’étendait vers l’intérieur des terres. Les plans napoléoniens conservés aux Archives départementales des Bouches-du-Rhône montrent que la rue du Panier formait un axe de transit pour les navires déchargeant des marchandises méditerranéennes. Les maisons de négociants qui la bordent gardent encore des rez-de-chaussée hauts sous plafond, destinés aux entrepôts.

Au XIXe siècle, la municipalité envisage une vaste opération de rénovation, finalement différée en raison des coûts élevés. Les interventions se limitent à des consolidations structurelles et à l’amélioration de l’assainissement. Cette relative absence de percée permet la conservation du gabarit originel, fait d’étroitesse et de perspectives changeantes.`,
      },
      {
        type: 'section',
        heading: 'Caractéristiques matérielles',
        text: `Les façades de la rue du Panier mêlent pierre calcaire, briques locales et enduits à la chaux teintés d’ocres. Les volets colorés ne relèvent pas d’une simple esthétique touristique : ils répondent à une tradition marseillaise de modulation de la lumière et de ventilation. Les relevés réalisés par le service Patrimoine montrent que certaines ferronneries datent du XVIIIe siècle et ont été restaurées avec des méthodes artisanales.

Au sol, les pavés irréguliers ont été partiellement consolidés lors des travaux de piétonnisation dans les années 1990. Les ingénieurs ont dû composer avec les réseaux souterrains anciens, notamment les canalisations d’eau héritées du canal de Marseille. L’implantation de mobiliers urbains discrets, tels que les bornes escamotables, vise à limiter l’accès automobile sans compromettre les livraisons.

Les bâtiments présentent des intérieurs fragmentés, parfois restructurés en lofts d’artistes. Les diagnostics patrimoniaux encouragent la préservation des escaliers en vis et des plafonds à poutres apparentes. Les copropriétés bénéficient de programmes d’accompagnement technique afin de respecter les normes de sécurité tout en maintenant les matériaux d’origine.`,
      },
      {
        type: 'section',
        heading: 'Tissu social et dynamique culturelle',
        text: `La rue du Panier est un laboratoire social où coexistent habitants de longue date, nouveaux résidents et ateliers artistiques. Les études menées par l’École d’architecture de Marseille montrent un taux de rotation modéré, signe d’une appropriation durable. Les commerces d’artisans, galeristes et restaurateurs s’y installent, favorisant un climat de convivialité tout en suscitant des interrogations sur l’évolution des loyers.

Les initiatives culturelles y abondent. La Vieille Charité organise des parcours reliant ses expositions à la rue du Panier, tandis que des collectifs d’artistes proposent des fresques éphémères. Ces interventions temporaires sont encadrées par la municipalité, qui veille à ce qu’elles ne détériorent pas les enduits anciens. Les habitants participent aux comités de quartier, discutant de la gestion des flux touristiques et de la propreté.

La mémoire migratoire occupe une place centrale. Des panneaux installés en 2019 retracent l’histoire des communautés italiennes, arméniennes et comoriennes qui ont marqué la rue. Les témoignages recueillis dans le cadre du projet “Panier Mémoires” fournissent un corpus précieux pour analyser les processus d’intégration et de cohabitation.`,
      },
      {
        type: 'section',
        heading: 'Gestion des risques et résilience',
        text: `Le quartier du Panier se situe en zone à risque sismique modéré. Les diagnostics réalisés après l’effondrement de deux immeubles rue d’Aubagne en 2018 ont conduit à renforcer la surveillance des structures. La rue du Panier fait l’objet de campagnes régulières de contrôle des fissures et des mouvements de terrain. Des capteurs sont installés dans les caves pour détecter les variations d’humidité.

La gestion des ruissellements constitue un autre enjeu. Les épisodes pluvieux intenses provoquent des écoulements rapides sur les pentes. Des rigoles discrètes ont été intégrées dans les escaliers pour canaliser l’eau vers les réseaux modernisés. Cette adaptation permet de protéger les façades des cloques et d’éviter le glissement des pavés.

À l’horizon 2026, la ville de Marseille prévoit un programme de médiation renforcée pour accompagner les visiteurs. Des fiches multilingues seront proposées aux points d’entrée du quartier, expliquant les règles de respect et la fragilité patrimoniale de la rue du Panier. Cette démarche vise à concilier attractivité culturelle et tranquillité résidentielle.`,
      },
      {
        type: 'conclusion',
        heading: 'Conclusion',
        text: `La rue du Panier illustre un équilibre délicat entre héritage portuaire, créativité contemporaine et vigilance technique. Son étude révèle la capacité de Marseille à valoriser un patrimoine populaire sans céder à la folklorisation. Les ajustements constants, menés en concertation avec les habitants, démontrent que la conservation peut se conjuguer avec des pratiques sociales vivantes et diversifiées.`,
      },
    ],
    sources: [
      'Archives municipales de Marseille, série 40 O, plans du quartier du Panier.',
      'École nationale supérieure d’architecture de Marseille, observatoire des pentes, rapport 2021.',
      'Ville de Marseille, programme “Panier Mémoires”, dossiers de médiation 2018-2023.',
    ],
  },
  {
    id: 5,
    slug: 'rue-sainte-catherine-bordeaux',
    title:
      'Rue Sainte-Catherine : colonne vertébrale piétonne du centre bordelais',
    subtitle:
      'Entre densité commerciale, patrimoine du XVIIIe siècle et innovations de gestion urbaine.',
    category: 'Bordeaux',
    theme: 'Rues commerçantes',
    date: '2024-01-18',
    image: '/images/rue-sainte-catherine.jpg',
    imageAlt:
      'Passants sur la rue Sainte-Catherine à Bordeaux avec façades XVIIIe',
    excerpt:
      'La rue Sainte-Catherine constitue un observatoire des régulations urbaines où se conjuguent patrimoine classé, flux piétonniers et expérimentations environnementales.',
    readingTime: '11 min',
    featured: false,
    content: [
      {
        type: 'introduction',
        text: `La rue Sainte-Catherine traverse Bordeaux du nord au sud sur plus d’un kilomètre, reliant la place de la Comédie à la porte d’Aquitaine. Piétonnisée depuis 1984, elle constitue la colonne vertébrale du centre historique. Son nom renvoie à l’ancienne église Sainte-Catherine, disparue au XIXe siècle, mais dont la mémoire subsiste dans les archives et la toponymie.

Les plans cadastraux de 1793 témoignent d’un tracé déjà dense, bordé d’immeubles marchands. L’alignement régulier des façades résulte d’une politique urbaine menée par l’intendant Tourny, qui imposa des règles strictes en matière de corniches et de hauteurs. Cette homogénéité apparente masque des ajustements subtils liés à la topographie et aux parcelles médiévales.

Avec l’essor commercial du XIXe siècle, la rue Sainte-Catherine devient un axe privilégié pour les grands magasins. Les photographies anciennes montrent des façades ornées de publicités peintes, témoignage de la compétition des enseignes. Les transformations du XXe siècle ont consisté à adapter les rez-de-chaussée aux nouvelles vitrines, tout en préservant les étages supérieurs résidentiels.`,
      },
      {
        type: 'section',
        heading: 'Morphologie commerciale et patrimoniale',
        text: `La diversité des commerces demeure l’une des caractéristiques majeures de la rue. On y trouve des librairies, des boutiques indépendantes et des enseignes nationales coexistant dans un périmètre contrôlé par la ville. Les études de flux piétons indiquent une moyenne de 60 000 passages quotidiens, ce qui entraîne une vigilance accrue sur l’état des revêtements.

Le sol est composé d’un granit clair, rénové en 2017 pour améliorer l’accessibilité. Des bandes podotactiles guident les personnes malvoyantes, insérées sans rompre la continuité visuelle. Les urbanistes bordelais ont également installé des bancs minimalistes et des points d’éclairage LED orientés vers les façades, accentuant les décors sculptés typiques du XVIIIe siècle.

Les structures porteuses des immeubles reposent sur des caves profondes, vestiges des entrepôts de vin. Des campagnes de consolidation ont été menées pour sécuriser les voûtes, notamment après des infiltrations causées par les réseaux d’eau. Les interventions privilégient des techniques de pierre armée, respectant la texture du calcaire blond.`,
      },
      {
        type: 'section',
        heading: 'Dynamiques sociales et gestion du tourisme',
        text: `La piétonnisation de la rue a modifié les habitudes de déplacement. Les commerçants notent une fréquentation en continu, sans pic horaire strict. Les habitants des étages supérieurs, majoritairement propriétaires occupants, participent aux associations de quartier pour réguler le bruit et l’occupation de l’espace public. Les études sociologiques soulignent une cohabitation relativement apaisée entre usages commerciaux et résidentiels.

Le tourisme constitue un enjeu majeur. Des parcours thématiques organisés par l’Office de tourisme mettent en avant les liens entre la rue Sainte-Catherine et l’histoire viticole de Bordeaux. Afin d’éviter la saturation, des horaires de livraison stricts ont été instaurés, limitant les camions aux premières heures du matin. Cette régulation contribue à préserver la qualité de l’air et la sécurité des piétons.

Des projets artistiques ponctuent le calendrier annuel. Des installations lumineuses accompagnent la fête du Fleuve, tandis que des artistes plasticiens interviennent sur les vitrines vides. Ces actions sont encadrées par un comité consultatif qui valide les propositions en fonction de leur respect du site inscrit au patrimoine mondial de l’UNESCO.`,
      },
      {
        type: 'section',
        heading: 'Résilience environnementale',
        text: `Les vagues de chaleur estivales ont conduit la ville à expérimenter des dispositifs de rafraîchissement passif. Des nappes de brumisation, installées pendant l’été 2022, abaissent la température ressentie de quelques degrés. Les mesures thermiques confirment l’efficacité du dispositif sans détériorer les matériaux. Parallèlement, des plantations en pot agrémentent certains tronçons pour renforcer la présence végétale.

La gestion des déchets constitue un autre volet. Les conteneurs enterrés, mis en service en 2019, permettent de maintenir la rue propre malgré l’intensité des flux. Les capteurs connectés renseignent le service de collecte, optimisant les tournées. Cette approche technologique s’inscrit dans la stratégie municipale visant à articuler patrimoine et innovation.

L’avenir de la rue Sainte-Catherine se dessine autour d’un plan de conservation participatif. Des ateliers réunissant commerçants, chercheurs et habitants ont élaboré une charte de bon voisinage, intégrant des recommandations sur l’éclairage, les enseignes et les matériaux de vitrine. Cette charte, adoptée en 2023, offre un cadre partagé pour assurer la pérennité de la rue.`,
      },
      {
        type: 'conclusion',
        heading: 'Conclusion',
        text: `Ainsi, la rue Sainte-Catherine demeure un observatoire privilégié des transformations des centres-villes français. Elle conjugue densité commerciale, patrimoine architectural rigoureux et innovations de gestion urbaine. L’attention portée à ses usages quotidiens révèle l’importance du dialogue entre acteurs publics et privés pour préserver l’identité bordelaise tout en répondant aux attentes contemporaines.`,
      },
    ],
    sources: [
      'Archives Bordeaux Métropole, dossiers Tourny et alignements (XVIIIe siècle).',
      'Observatoire de la vie urbaine de Bordeaux, flux piétons 2020-2023.',
      'Charte de la rue Sainte-Catherine, Ville de Bordeaux, édition 2023.',
    ],
  },
  {
    id: 6,
    slug: 'montee-du-gourguillon-lyon',
    title: 'Montée du Gourguillon : topographie et résilience sur les pentes lyonnaises',
    subtitle:
      'Lecture d’un itinéraire médiéval reliant la Saône à Fourvière, entre traboules et dispositifs de stabilisation.',
    category: 'Lyon',
    theme: 'Pentes urbaines',
    date: '2023-12-08',
    image: '/images/montee-du-gourguillon.jpg',
    imageAlt:
      'Escaliers de la montée du Gourguillon à Lyon avec murs en pierre',
    excerpt:
      'La montée du Gourguillon dévoile la manière dont Lyon articule héritage topographique, participation habitante et gestion des risques sur les pentes du Vieux-Lyon.',
    readingTime: '9 min',
    featured: false,
    content: [
      {
        type: 'introduction',
        text: `La montée du Gourguillon relie la place de la Trinité au plateau de Fourvière, sur la rive droite de la Saône. Ce chemin escarpé, jalonné d’escaliers et de successions de pentes, figure parmi les plus anciens tracés de Lyon. Sa topographie particulière a conditionné l’installation de maisons étroites et la formation de traboules permettant de relier les cours intérieures.

Les premières mentions de la montée datent du XIIe siècle, lorsqu’elle servait à relier le port Saint-Paul à la basilique. Les archives capitulaires conservent des plans montrant l’essor des couvents le long du parcours, notamment celui des Visitandines. La rue a traversé les siècles sans alignement haussmannien, ce qui en fait un témoin rare de l’urbanisme pré-moderne.

Le XIXe siècle marque une phase de délaissement, la montée étant jugée difficile d’accès pour les activités industrielles. Les projets de percement n’aboutissent pas, faute de financement et de consensus. Cette situation préserve les structures originelles mais entraîne un vieillissement du bâti qui nécessite aujourd’hui une attention minutieuse.`,
      },
      {
        type: 'section',
        heading: 'Configuration spatiale et bâti',
        text: `La montée du Gourguillon présente un profil irrégulier alternant ressauts pavés et volées d’escaliers. Les relevés topographiques indiquent des pentes pouvant atteindre 18 %. Les immeubles sont adossés au relief, avec des cages d’escalier latérales et des façades percées de fenêtres étroites. Les matériaux principaux sont le calcaire de Couzon et la brique, utilisés par strates selon les disponibilités historiques.

Les traboules, passages caractéristiques de Lyon, se multiplient le long du parcours. Elles permettent de contourner les dénivelés et d’accéder aux cours intérieures ventilées. Les associations patrimoniales ont recensé une dizaine de traboules ouvertes ponctuellement au public. Ces structures font l’objet de restaurations ciblées, notamment sur les voûtes en berceau et les puits de lumière.

Les travaux récents ont porté sur la consolidation des soutènements. Des micropieux ont été installés pour stabiliser les talus, tandis que les murs de soutènement ont été rejointoyés à la chaux hydraulique. Ces interventions, menées sous la supervision de la Mission patrimoine mondial, respectent l’inscription du site historique de Lyon.`,
      },
      {
        type: 'section',
        heading: 'Pratiques sociales et mobilités',
        text: `La montée du Gourguillon connaît des usages différenciés selon les heures. Les résidents empruntent les escaliers pour accéder aux commerces du bas de la colline, tandis que les visiteurs la parcourent dans le cadre de circuits patrimoniaux. Les relevés de fréquentation montrent une augmentation des flux depuis l’ouverture de promenades thématiques par la ville de Lyon.

Les mobilités douces sont favorisées par la limitation du trafic motorisé. Seuls les riverains peuvent y circuler en voiture, et des bornes escamotables contrôlent l’accès. Des bancs de repos, réalisés en pierre locale, jalonnent le parcours pour offrir des haltes aux piétons. Ces aménagements contribuent à l’appropriation quotidienne de la montée.

Des ateliers participatifs ont permis aux habitants de formuler des propositions pour la gestion des nuisances sonores. L’installation de revêtements absorbants sur les marches a été testée, réduisant le bruit des pas pendant la nuit. Les retours d’expérience soulignent l’importance de ces mesures pour maintenir la qualité de vie dans un environnement patrimonial sensible.`,
      },
      {
        type: 'section',
        heading: 'Interprétation patrimoniale',
        text: `La montée du Gourguillon est associée à plusieurs récits historiques, notamment celui du passage des rois de France lors de visites officielles. Des panneaux retraçant ces épisodes ont été implantés à hauteur du numéro 17. Ils s’appuient sur les chroniques lyonnaises et sur les plans anciens conservés aux Archives municipales.

Les universitaires lyonnais ont développé un programme de recherche intitulé “Gourguillon, laboratoire des pentes”. Il rassemble géographes, historiens et spécialistes des risques urbains. Les données collectées servent à modéliser les effets des ruissellements et à anticiper les impacts du changement climatique. Les résultats préliminaires mettent en lumière la fragilité des sols argilo-calcaires.

Dans une perspective de médiation, la montée accueille des projets artistiques discrets, tels que des concerts acoustiques à l’intérieur des traboules. Ces initiatives, encadrées par la mairie du 5e arrondissement, respectent les limites de fréquentation afin de ne pas saturer les espaces.`,
      },
      {
        type: 'conclusion',
        heading: 'Conclusion',
        text: `La montée du Gourguillon offre un condensé de l’histoire lyonnaise, de la topographie médiévale aux enjeux contemporains de résilience. Son observation révèle l’importance de conjuguer expertise technique, participation habitante et médiation culturelle. En suivant ses marches, on saisit la manière dont une rue peut relier, physiquement et symboliquement, les strates d’une ville inscrite dans la durée.`,
      },
    ],
    sources: [
      'Archives municipales de Lyon, série 6 S, plans des pentes de Fourvière.',
      'Mission patrimoine mondial – Ville de Lyon, dossier “Montée du Gourguillon”, 2019-2023.',
      'Université Lyon 2, programme “Gourguillon, laboratoire des pentes”, rapport intermédiaire 2022.',
    ],
  },
];

export default articles;