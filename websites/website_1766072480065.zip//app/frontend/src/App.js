import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, NavLink, useLocation } from "react-router-dom";
import "./App.css";

const navItems = [
  { to: "/", label: "Home", end: true },
  { to: "/expertise", label: "Expertise" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/about", label: "About" },
  { to: "/faq", label: "FAQ" },
  { to: "/contact", label: "Contact" },
];

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);
  return null;
};

const useDocumentTitle = (title) => {
  useEffect(() => {
    document.title = `${title} | Aurora Atelier`;
  }, [title]);
};

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [prefs, setPrefs] = useState({
    essential: true,
    analytics: false,
    marketing: false,
    acknowledged: false,
  });
  const [showPanel, setShowPanel] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("cookiePrefs");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setPrefs((previous) => ({ ...previous, ...parsed }));
        if (parsed.acknowledged) {
          setIsVisible(false);
          return;
        }
      } catch (error) {
        console.error("Unable to parse stored preferences", error);
      }
    }
    setIsVisible(true);
  }, []);

  const pushPreferences = async (nextPrefs) => {
    try {
      setSyncing(true);
      await fetch("/api/preferences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          analytics: nextPrefs.analytics,
          marketing: nextPrefs.marketing,
        }),
      });
    } catch (error) {
      console.warn("Preference sync deferred", error);
    } finally {
      setSyncing(false);
    }
  };

  const persist = async (overrides) => {
    let nextPrefs = null;
    setPrefs((previous) => {
      nextPrefs = { ...previous, ...overrides, acknowledged: true };
      return nextPrefs;
    });
    localStorage.setItem("cookiePrefs", JSON.stringify(nextPrefs));
    setIsVisible(false);
    await pushPreferences(nextPrefs);
  };

  const rejectAll = () => {
    setShowPanel(false);
    persist({ analytics: false, marketing: false });
  };

  const acceptAll = () => {
    setShowPanel(false);
    persist({ analytics: true, marketing: true });
  };

  const saveCustom = async () => {
    await persist({});
    setShowPanel(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-modal="true" aria-live="polite">
      <div className="cookie-body align-responsive">
        <h3>Manage your experience</h3>
        <p>
          We use cookies to deliver seamless collaborations. Essential cookies keep Aurora Atelier
          operational, while analytics and marketing help us craft better journeys. Customize anytime.
        </p>
        {showPanel && (
          <div className="cookie-panel" role="group" aria-label="Cookie preference toggles">
            <label className="cookie-toggle">
              <span>Essential</span>
              <input type="checkbox" checked readOnly />
            </label>
            <label className="cookie-toggle">
              <span>Analytics</span>
              <input
                type="checkbox"
                checked={prefs.analytics}
                onChange={(event) =>
                  setPrefs((previous) => ({ ...previous, analytics: event.target.checked }))
                }
              />
            </label>
            <label className="cookie-toggle">
              <span>Marketing</span>
              <input
                type="checkbox"
                checked={prefs.marketing}
                onChange={(event) =>
                  setPrefs((previous) => ({ ...previous, marketing: event.target.checked }))
                }
              />
            </label>
          </div>
        )}
        <div className="cookie-controls">
          <button className="btn btn-secondary" type="button" onClick={rejectAll} disabled={syncing}>
            Reject All
          </button>
          <button className="btn btn-primary" type="button" onClick={acceptAll} disabled={syncing}>
            Accept All
          </button>
          <button
            className="btn btn-ghost"
            type="button"
            onClick={() => setShowPanel((previous) => !previous)}
          >
            {showPanel ? "Hide Options" : "Customize"}
          </button>
          {showPanel && (
            <button className="btn btn-outline" type="button" onClick={saveCustom} disabled={syncing}>
              Save Preferences
            </button>
          )}
        </div>
        {syncing && <span className="cookie-status">Syncing your preferences...</span>}
      </div>
    </div>
  );
};

const Footer = () => (
  <footer className="footer align-responsive">
    <div className="footer-grid">
      <div className="footer-brand">
        <span className="footer-logo">Aurora Atelier</span>
        <p>
          Designing luminous digital experiences that harmonize strategy, storytelling, and tech artistry.
        </p>
        <div className="footer-badges">
          <span className="badge-pill">B-Corp Pending</span>
          <span className="badge-pill">Climate Positive</span>
          <span className="badge-pill">24/7 Support</span>
        </div>
      </div>
      <div className="footer-links">
        <h4>Studio</h4>
        <NavLink to="/about">Our Manifesto</NavLink>
        <NavLink to="/expertise">Capabilities</NavLink>
        <NavLink to="/portfolio">Selected Work</NavLink>
        <NavLink to="/faq">FAQ</NavLink>
      </div>
      <div className="footer-links">
        <h4>Governance</h4>
        <NavLink to="/privacy">Privacy Policy</NavLink>
        <NavLink to="/terms">Terms of Service</NavLink>
        <NavLink to="/contact">Request Proposal</NavLink>
      </div>
      <div className="footer-contact">
        <h4>Connect</h4>
        <a href="mailto:hello@aurorastudio.com">hello@aurorastudio.com</a>
        <a href="tel:+14155551234">+1 (415) 555-1234</a>
        <p>2050 Market Street, Suite 12, San Francisco, CA</p>
      </div>
    </div>
    <div className="footer-bottom">
      <span>© {new Date().getFullYear()} Aurora Atelier. Crafted with purpose.</span>
      <span className="footer-social">
        <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
          LinkedIn
        </a>
        <a href="https://www.behance.net" target="_blank" rel="noreferrer">
          Behance
        </a>
        <a href="https://dribbble.com" target="_blank" rel="noreferrer">
          Dribbble
        </a>
      </span>
    </div>
  </footer>
);

const Layout = () => {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <div className="app-shell">
      <div className="aurora-blur aurora-one" />
      <div className="aurora-blur aurora-two" />
      <header className="header">
        <NavLink to="/" className="logo">
          <span className="logo-glyph">Aurora</span>
          <span className="logo-detail">Atelier</span>
        </NavLink>
        <nav className={`nav ${menuOpen ? "is-open" : ""}`}>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `nav-link ${isActive ? "is-active" : ""}`}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <button
          className={`menu-toggle ${menuOpen ? "is-open" : ""}`}
          type="button"
          onClick={() => setMenuOpen((previous) => !previous)}
          aria-label="Toggle navigation"
        >
          <span />
          <span />
        </button>
      </header>
      <main className="page-wrapper">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/expertise" element={<ExpertisePage />} />
          <Route path="/portfolio" element={<PortfolioPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/faq" element={<FaqPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

const metricHighlights = [
  { title: "Campaign ROI uplift", value: "214%", caption: "Average improvement within 90 days" },
  { title: "Launch velocity", value: "28 days", caption: "From discovery to shippable experience" },
  { title: "Retention boost", value: "3.6x", caption: "Engagement growth for subscription brands" },
];

const featureHighlights = [
  {
    title: "Immersive brand worlds",
    description:
      "We compose experiential systems that translate your mission into tactile visuals, language, and behavior across every touchpoint.",
    focus: ["Narrative orchestration", "Interactive north-stars", "Sensory-driven design libraries"],
  },
  {
    title: "Modular growth engines",
    description:
      "Our growth squads build modular content and acquisition frameworks that iterate intelligently with your audience.",
    focus: ["Intelligent experimentation", "Audience modeling", "Bi-weekly momentum labs"],
  },
  {
    title: "Product evolution labs",
    description:
      "We partner with product teams to ship transformative features, calibrate usability, and evolve with a human-centered lens.",
    focus: ["Scenario co-creation", "Insight-driven roadmaps", "Inclusive interaction patterns"],
  },
];

const caseStudies = [
  {
    title: "Solstice Energy Launch",
    category: "Branding",
    results: ["72% uplift in qualified leads", "Awarded AIGA Showcase 2024"],
    image: "https://images.pexels.com/photos/3394651/pexels-photo-3394651.jpeg?auto=compress&cs=tinysrgb",
    alt: "Creative team reviewing energy brand layouts",
  },
  {
    title: "Atlas Wellness OS",
    category: "Digital Product",
    results: ["4.6★ app store rating", "Daily active users up 163%"],
    image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb",
    alt: "Designers prototyping mobile wellness application",
  },
  {
    title: "Nova Fashion Collective",
    category: "Growth",
    results: ["3.4x return on ad spend", "Global community expansion"],
    image: "https://images.pexels.com/photos/1661004/pexels-photo-1661004.jpeg?auto=compress&cs=tinysrgb",
    alt: "Fashion brand marketing team collaborating in studio",
  },
];

const serviceBlueprints = [
  {
    title: "Brand & Story Architecture",
    summary:
      "Define the sonic, visual, and verbal DNA that transforms your brand into a connected world.",
    deliverables: [
      "Vision & values activation",
      "Signature visual & motion system",
      "Tone architecture + messaging matrix",
    ],
    timeline: "4-6 weeks",
    image:
      "https://images.pexels.com/photos/3914752/pexels-photo-3914752.jpeg?auto=compress&cs=tinysrgb",
    alt: "Strategist mapping brand story on a wall",
  },
  {
    title: "Digital Product Design",
    summary:
      "Shape intuitive platforms with inclusive, data-backed interactions that unlock adoption.",
    deliverables: [
      "Experience audits & opportunity maps",
      "Component-driven design system",
      "Interactive prototypes & usability labs",
    ],
    timeline: "6-12 weeks",
    image:
      "https://images.pexels.com/photos/6804089/pexels-photo-6804089.jpeg?auto=compress&cs=tinysrgb",
    alt: "Product designers iterating on digital interface",
  },
  {
    title: "Growth Innovation Sprints",
    summary:
      "Deploy agile growth loops that synthesize audience intelligence with creative experimentation.",
    deliverables: [
      "Growth opportunity backlog",
      "12-week experimentation roadmap",
      "Analytics storytelling dashboards",
    ],
    timeline: "3 months",
    image:
      "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb",
    alt: "Strategists reviewing growth performance dashboards",
  },
];

const culturePrinciples = [
  {
    title: "Radical resonance",
    description:
      "We listen deeply and design experiences that echo the dreams of the communities you serve.",
  },
  {
    title: "Inclusive invention",
    description:
      "We steward progressive accessibility and diverse creativity at every step of the product lifecycle.",
  },
  {
    title: "Curated bravery",
    description:
      "We orchestrate bold moves that are anchored in insight, rigor, and measurable value.",
  },
];

const faqs = [
  {
    question: "How does Aurora Atelier onboard new collaborators?",
    answer:
      "We begin with a 90-minute immersion lab to map your ambitions, align on success signals, and prioritize opportunities. Within five days you receive a diagnostic blueprint with co-authored next steps.",
  },
  {
    question: "What industries do you specialize in?",
    answer:
      "We partner with climate tech, fintech, wellness, fashion, and cultural institutions. Our global bench allows us to assemble bespoke squads for emerging markets as well.",
  },
  {
    question: "How do you measure impact?",
    answer:
      "Each engagement includes a custom value dashboard. We combine quantitative signals like retention or CLV with qualitative resonance data gathered through interviews and live sessions.",
  },
  {
    question: "Can you collaborate with in-house teams?",
    answer:
      "Absolutely. We operate as an embedded partner, co-locating in your workflows, pairing with in-house creative, engineering, and growth teams to accelerate delivery.",
  },
];

const HomePage = () => {
  useDocumentTitle("Home");
  const [activeFeature, setActiveFeature] = useState(0);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setActiveFeature((previous) => (previous + 1) % featureHighlights.length);
    }, 5200);
    return () => window.clearInterval(interval);
  }, []);

  return (
    <div className="page home-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Boutique strategy & experience design</span>
            <h1>Illuminate bold ideas with signature digital craft.</h1>
            <p>
              Aurora Atelier is the studio for founders and leaders who demand poetic strategy, shimmering
              interfaces, and measurable momentum. We choreograph brands and products that feel inevitable.
            </p>
            <div className="cta-row">
              <NavLink to="/contact" className="btn btn-primary">
                Start a project
              </NavLink>
              <NavLink to="/portfolio" className="btn btn-outline">
                View craftsmanship
              </NavLink>
            </div>
            <div className="metrics-grid">
              {metricHighlights.map((metric) => (
                <div key={metric.title} className="metric-card">
                  <span className="metric-value">{metric.value}</span>
                  <span className="metric-title">{metric.title}</span>
                  <p>{metric.caption}</p>
                </div>
              ))}
            </div>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/3186654/pexels-photo-3186654.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/3186654/pexels-photo-3186654.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/3186654/pexels-photo-3186654.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Creative strategists collaborating in a bright studio"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section feature-section align-responsive">
        <div className="section-header">
          <h2>Signature focus areas</h2>
          <p>
            Choose a focus or glide through all three. Every stream is modular, data-enriched, and crafted
            in partnership with your team.
          </p>
        </div>
        <div className="feature-tabs">
          {featureHighlights.map((feature, index) => (
            <button
              key={feature.title}
              type="button"
              className={`feature-tab ${index === activeFeature ? "is-active" : ""}`}
              onMouseEnter={() => setActiveFeature(index)}
              onFocus={() => setActiveFeature(index)}
            >
              <span>{feature.title}</span>
            </button>
          ))}
        </div>
        <div className="feature-highlight">
          <h3>{featureHighlights[activeFeature].title}</h3>
          <p>{featureHighlights[activeFeature].description}</p>
          <ul>
            {featureHighlights[activeFeature].focus.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>
      <section className="section process-section align-responsive">
        <div className="section-header">
          <h2>Our process cadence</h2>
          <p>A rhythm built to keep clarity, momentum, and delight at the center of every collaboration.</p>
        </div>
        <div className="process-grid">
          <div className="process-card">
            <span className="process-step">01</span>
            <h3>Immersion Lab</h3>
            <p>
              Stakeholder interviews, resonance audits, and north star alignment in a 360° immersive session.
            </p>
          </div>
          <div className="process-card">
            <span className="process-step">02</span>
            <h3>Experience Blueprint</h3>
            <p>
              Modular roadmap blending brand, product, and growth workstreams with clear KPIs and rituals.
            </p>
          </div>
          <div className="process-card">
            <span className="process-step">03</span>
            <h3>Launch & Amplify</h3>
            <p>
              High-touch launch orchestration with resonance testing, live iteration labs, and success scoring.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

const ExpertisePage = () => {
  useDocumentTitle("Expertise");
  const [selectedService, setSelectedService] = useState(serviceBlueprints[0]);

  return (
    <div className="page expertise-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Capabilities</span>
            <h1>Polyphonic services tuned to your ambition.</h1>
            <p>
              From crystalizing brand universes to engineering growth systems, our squads integrate seamlessly
              with your team to unlock confident leaps.
            </p>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/3914752/pexels-photo-3914752.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/3914752/pexels-photo-3914752.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/3914752/pexels-photo-3914752.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Aurora Atelier strategist drafting creative plans"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section align-responsive">
        <div className="section-header">
          <h2>Service blueprints</h2>
          <p>Explore the spectrum of our craft. Select a stream to unfold the precise deliverables.</p>
        </div>
        <div className="service-grid">
          <div className="service-list">
            {serviceBlueprints.map((service) => (
              <button
                key={service.title}
                type="button"
                className={`service-item ${service.title === selectedService.title ? "is-active" : ""}`}
                onClick={() => setSelectedService(service)}
              >
                <span>{service.title}</span>
                <span className="service-timeline">{service.timeline}</span>
              </button>
            ))}
          </div>
          <div className="service-detail">
            <picture className="service-media">
              <source media="(max-width: 599px)" srcSet={`${selectedService.image}&w=600`} />
              <source media="(max-width: 1023px)" srcSet={`${selectedService.image}&w=900`} />
              <img src={`${selectedService.image}&w=1200`} alt={selectedService.alt} loading="lazy" />
            </picture>
            <div className="service-content">
              <h3>{selectedService.title}</h3>
              <p>{selectedService.summary}</p>
              <ul>
                {selectedService.deliverables.map((deliverable) => (
                  <li key={deliverable}>{deliverable}</li>
                ))}
              </ul>
              <span className="service-duration">Typical timeline: {selectedService.timeline}</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

const PortfolioPage = () => {
  useDocumentTitle("Portfolio");
  const [filter, setFilter] = useState("All");
  const categories = ["All", "Branding", "Digital Product", "Growth"];
  const filteredProjects =
    filter === "All" ? caseStudies : caseStudies.filter((project) => project.category === filter);

  return (
    <div className="page portfolio-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Selected collaborations</span>
            <h1>Case studies engineered for resonance.</h1>
            <p>
              Each engagement is a bespoke partnership. Dive into the stories behind launches, growth loops,
              and award-winning experiences we co-created.
            </p>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/4348404/pexels-photo-4348404.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/4348404/pexels-photo-4348404.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/4348404/pexels-photo-4348404.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Design team curating portfolio boards"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section align-responsive">
        <div className="section-header">
          <h2>Filter by focus</h2>
          <p>Select a specialty to surface the outcomes most relevant to your mission.</p>
        </div>
        <div className="filter-chips">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`chip ${filter === category ? "is-active" : ""}`}
              onClick={() => setFilter(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="project-grid">
          {filteredProjects.map((project) => (
            <article key={project.title} className="project-card">
              <picture className="project-media">
                <source media="(max-width: 599px)" srcSet={`${project.image}&w=600`} />
                <source media="(max-width: 1023px)" srcSet={`${project.image}&w=900`} />
                <img src={`${project.image}&w=1200`} alt={project.alt} loading="lazy" />
              </picture>
              <div className="project-content">
                <span className="project-category">{project.category}</span>
                <h3>{project.title}</h3>
                <ul>
                  {project.results.map((result) => (
                    <li key={result}>{result}</li>
                  ))}
                </ul>
                <NavLink to="/contact" className="btn btn-inline">
                  Request deep dive
                </NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

const AboutPage = () => {
  useDocumentTitle("About");
  return (
    <div className="page about-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Our manifesto</span>
            <h1>Designing luminous futures with curious hearts.</h1>
            <p>
              Aurora Atelier is an independent collective of strategists, designers, technologists, and
              storytellers spanning four continents. We cultivate experiences that uplift communities and
              accelerate responsible innovation.
            </p>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/4064830/pexels-photo-4064830.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/4064830/pexels-photo-4064830.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/4064830/pexels-photo-4064830.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Aurora Atelier team aligning on strategy"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section align-responsive">
        <div className="section-header">
          <h2>Principles we live by</h2>
          <p>The beliefs that guide every engagement, decision, and celebration.</p>
        </div>
        <div className="principles-grid">
          {culturePrinciples.map((principle) => (
            <div key={principle.title} className="principle-card">
              <h3>{principle.title}</h3>
              <p>{principle.description}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="section align-responsive">
        <div className="section-header">
          <h2>Timeline of impact</h2>
          <p>Milestones that shaped our practice and community.</p>
        </div>
        <div className="timeline">
          <div className="timeline-item">
            <span className="timeline-year">2016</span>
            <p>Founded in San Francisco with a mission to blend artistry and analytics.</p>
          </div>
          <div className="timeline-item">
            <span className="timeline-year">2019</span>
            <p>Opened our Amsterdam satellite studio and launched the first Aurora Residency.</p>
          </div>
          <div className="timeline-item">
            <span className="timeline-year">2022</span>
            <p>Certified carbon-neutral and introduced the Community Futures Grant program.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

const FaqPage = () => {
  useDocumentTitle("FAQ");
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="page faq-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Clarity, front and center</span>
            <h1>Answers to your most relevant questions.</h1>
            <p>
              We believe transparency is foundational to trust. Explore details on process, fit, and what
              collaboration feels like with us.
            </p>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/3184631/pexels-photo-3184631.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/3184631/pexels-photo-3184631.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/3184631/pexels-photo-3184631.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Creative partners discussing project roadmap"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section align-responsive">
        <div className="section-header">
          <h2>Frequently asked</h2>
          <p>Click a question to reveal deeper context.</p>
        </div>
        <div className="faq-list">
          {faqs.map((item, index) => (
            <div key={item.question} className={`faq-item ${index === activeIndex ? "is-open" : ""}`}>
              <button
                type="button"
                onClick={() => setActiveIndex(index === activeIndex ? -1 : index)}
                aria-expanded={index === activeIndex}
              >
                <span>{item.question}</span>
                <span className="faq-icon">{index === activeIndex ? "−" : "+"}</span>
              </button>
              {index === activeIndex && <p>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const PrivacyPage = () => {
  useDocumentTitle("Privacy Policy");
  return (
    <div className="page legal-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Privacy</span>
            <h1>Our commitment to protecting your data.</h1>
            <p>
              We operate with transparency and respect. This policy outlines how Aurora Atelier collects,
              uses, and safeguards your information.
            </p>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/3184296/pexels-photo-3184296.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/3184296/pexels-photo-3184296.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/3184296/pexels-photo-3184296.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Secure workspace with privacy-focused workflow"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section align-responsive legal-section">
        <h2>Information we collect</h2>
        <p>
          We collect information you provide directly such as contact details, project briefs, and feedback.
          We also gather limited analytics data to understand usage patterns when consented.
        </p>
        <h2>How we use information</h2>
        <p>
          Data powers project collaboration, client support, and product improvement. We do not sell personal
          information. Third-party vendors are carefully vetted for compliance.
        </p>
        <h2>Your rights</h2>
        <p>
          You can request access, updates, or deletion of your data at any time via privacy@aurorastudio.com.
          We honor all legal requirements including GDPR and CCPA.
        </p>
      </section>
    </div>
  );
};

const TermsPage = () => {
  useDocumentTitle("Terms of Service");
  return (
    <div className="page legal-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Terms</span>
            <h1>Guiding principles for partnership.</h1>
            <p>
              These terms govern your use of Aurora Atelier’s services. We prioritize openness, alignment, and
              mutual respect throughout our collaborations.
            </p>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/3184460/pexels-photo-3184460.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/3184460/pexels-photo-3184460.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/3184460/pexels-photo-3184460.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Team members aligning around partnership terms"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section align-responsive legal-section">
        <h2>Working relationship</h2>
        <p>
          Engagements commence with a Statement of Work outlining milestones, responsibilities, investment,
          and success measures. Either party may adjust scope with written agreement.
        </p>
        <h2>Intellectual property</h2>
        <p>
          Upon full payment, ownership of final deliverables transfers to you. Aurora Atelier retains a
          limited right to showcase non-sensitive work in portfolio narratives unless otherwise agreed.
        </p>
        <h2>Liability</h2>
        <p>
          We operate with industry best practices. Our liability is limited to fees paid within the past six
          months. Neither party is responsible for indirect or consequential damages.
        </p>
      </section>
    </div>
  );
};

const ContactPage = () => {
  useDocumentTitle("Contact");
  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    company: "",
    project_scope: "",
    message: "",
  });
  const [status, setStatus] = useState({
    sending: false,
    success: null,
    error: null,
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((previous) => ({ ...previous, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus({ sending: true, success: null, error: null });
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formValues),
      });
      if (!response.ok) {
        throw new Error("Failed to submit");
      }
      setStatus({
        sending: false,
        success: "We received your message. Expect a response within 24 hours.",
        error: null,
      });
      setFormValues({
        name: "",
        email: "",
        company: "",
        project_scope: "",
        message: "",
      });
    } catch (error) {
      setStatus({
        sending: false,
        success: null,
        error: "Something went wrong. Please email hello@aurorastudio.com directly.",
      });
    }
  };

  return (
    <div className="page contact-page">
      <section className="section hero-section align-responsive">
        <div className="section-split">
          <div className="hero-copy">
            <span className="super-title">Let’s co-create</span>
            <h1>Share your vision and we’ll orchestrate the path.</h1>
            <p>
              Hint at your dream state and constraints — we will assemble a bespoke squad and roadmap to
              elevate your brand or product.
            </p>
          </div>
          <picture className="hero-media">
            <source
              media="(max-width: 599px)"
              srcSet="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=600"
            />
            <source
              media="(max-width: 1023px)"
              srcSet="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=900"
            />
            <img
              src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Founder connecting with creative strategist"
              loading="lazy"
            />
          </picture>
        </div>
      </section>
      <section className="section align-responsive contact-section">
        <div className="section-header">
          <h2>Project request</h2>
          <p>Tell us about the opportunity and we will respond within one business day.</p>
        </div>
        <form className="contact-form" onSubmit={handleSubmit}>
          <div className="form-grid">
            <label>
              <span>Full name</span>
              <input
                name="name"
                value={formValues.name}
                onChange={handleChange}
                required
                placeholder="Taylor Morgan"
              />
            </label>
            <label>
              <span>Email</span>
              <input
                name="email"
                type="email"
                value={formValues.email}
                onChange={handleChange}
                required
                placeholder="taylor@brand.com"
              />
            </label>
            <label>
              <span>Company</span>
              <input
                name="company"
                value={formValues.company}
                onChange={handleChange}
                placeholder="Brand or organization"
              />
            </label>
            <label>
              <span>Project scope</span>
              <input
                name="project_scope"
                value={formValues.project_scope}
                onChange={handleChange}
                placeholder="Brand launch, product design, growth lab..."
              />
            </label>
          </div>
          <label className="full-width">
            <span>Story, goals, or challenges</span>
            <textarea
              name="message"
              value={formValues.message}
              onChange={handleChange}
              required
              rows={6}
              placeholder="Share the narrative, desired outcomes, and key milestones."
            />
          </label>
          <button className="btn btn-primary" type="submit" disabled={status.sending}>
            {status.sending ? "Sending..." : "Submit request"}
          </button>
          {status.success && <p className="form-status success">{status.success}</p>}
          {status.error && <p className="form-status error">{status.error}</p>}
        </form>
      </section>
    </div>
  );
};

const NotFoundPage = () => {
  useDocumentTitle("Page Not Found");
  return (
    <div className="page not-found-page">
      <section className="section align-responsive">
        <div className="section-header">
          <h1>Glow lost in transit.</h1>
          <p>The page you’re seeking has shifted. Let us guide you back to luminous territory.</p>
        </div>
        <NavLink to="/" className="btn btn-primary">
          Return home
        </NavLink>
      </section>
    </div>
  );
};

const App = () => (
  <Router>
    <ScrollToTop />
    <Layout />
  </Router>
);

export default App;