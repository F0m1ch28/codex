Aurora Atelier Frontend Suite
This project delivers a premium multi-page React experience with FastAPI backend utilities. All pages include responsive layouts, unique Pexels imagery, and a persistent cookies consent banner with customizable preferences.

Key scripts:
- npm install : install frontend dependencies
- npm start   : launch development server
- npm run build : generate optimized production bundle

Backend:
- uvicorn backend.server:app --reload : run API for contact submissions and cookie preference storage

Folder map:
- src/App.js : primary React application with routing, global layout, and page compositions
- src/App.css : bespoke design system with adaptive typography and mobile-first alignment
- src/data   : supplemental JSON datasets powering future data visualizations
- public     : manifest, sitemap, favicon, and SEO essentials
- backend    : FastAPI server providing resilient endpoints

Ensure environment variables for production API endpoints are stored in a secure .env file and never committed to source control. Review robots.txt and sitemap.xml before deployment to update the canonical domain. For image compliance, retain unique Pexels assets per page as implemented.