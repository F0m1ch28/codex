from datetime import datetime
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr

app = FastAPI(title="Aurora Atelier API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ContactMessage(BaseModel):
    name: str
    email: EmailStr
    company: str | None = None
    project_scope: str | None = None
    message: str


class PreferencesPayload(BaseModel):
    analytics: bool = False
    marketing: bool = False


@app.get("/api/health")
def health():
    return {
        "status": "online",
        "service": "Aurora Atelier API",
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


@app.post("/api/contact")
def contact(data: ContactMessage):
    return {
        "received": True,
        "submittedAt": datetime.utcnow().isoformat() + "Z",
        "payload": data.dict(),
        "message": "Thank you for trusting Aurora Atelier. Our strategists will connect within one business day.",
    }


@app.post("/api/preferences")
def preferences(prefs: PreferencesPayload):
    return {
        "status": "stored",
        "preferences": prefs.dict(),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }