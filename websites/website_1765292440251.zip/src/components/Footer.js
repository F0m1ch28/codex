import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.container}`}>
        <div className={styles.brandBlock}>
          <span className={styles.brand}>Parisian Bakeries Review</span>
          <p className={styles.tagline}>Revue culturelle dédiée aux boulangeries parisiennes.</p>
        </div>
        <div className={styles.columns}>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Navigation</h3>
            <ul className={styles.list}>
              <li><Link to="/">Accueil</Link></li>
              <li><Link to="/a-propos">À propos</Link></li>
              <li><Link to="/archives">Archives</Link></li>
              <li><Link to="/themes">Thèmes</Link></li>
              <li><Link to="/ressources">Ressources</Link></li>
              <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Informations</h3>
            <ul className={styles.list}>
              <li><Link to="/conditions-utilisation">Conditions d’utilisation</Link></li>
              <li><Link to="/politique-confidentialite">Politique de confidentialité</Link></li>
              <li><Link to="/politique-cookies">Politique de cookies</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Coordonnées</h3>
            <p className={styles.contact}>Parisian Bakeries Review<br />Boîte Postale 75001<br />Paris, France</p>
            <p className={styles.contact}>redaction@parisianbakeriesreview.fr</p>
          </div>
        </div>
        <p className={styles.meta}>© {new Date().getFullYear()} Parisian Bakeries Review. Tous droits réservés.</p>
      </div>
    </footer>
  );
};

export default Footer;