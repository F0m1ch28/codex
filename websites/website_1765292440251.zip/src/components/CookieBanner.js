import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const storedConsent = window.localStorage.getItem('pbr-cookie-consent');
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('pbr-cookie-consent', 'accepted');
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="region" aria-label="Bandeau de consentement aux cookies">
      <p className={styles.text}>
        Parisian Bakeries Review utilise des cookies techniques afin d’assurer une navigation stable et de mesurer la fréquentation de manière anonymisée.
      </p>
      <div className={styles.actions}>
        <Link to="/politique-cookies" className={styles.link}>Politique de cookies</Link>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Accepter
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;