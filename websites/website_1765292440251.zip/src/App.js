import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton, { ScrollToTopOnRoute } from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import MethodologyPage from './pages/MethodologyPage';
import ArchivesPage from './pages/ArchivesPage';
import ThemesPage from './pages/ThemesPage';
import ResourcesPage from './pages/ResourcesPage';
import ContactPage from './pages/ContactPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';

const App = () => {
  return (
    <Router>
      <ScrollToTopOnRoute />
      <Header />
      <main className="mainContent">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/a-propos" element={<AboutPage />} />
          <Route path="/methodologie" element={<MethodologyPage />} />
          <Route path="/archives" element={<ArchivesPage />} />
          <Route path="/themes" element={<ThemesPage />} />
          <Route path="/ressources" element={<ResourcesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/conditions-utilisation" element={<TermsPage />} />
          <Route path="/politique-confidentialite" element={<PrivacyPage />} />
          <Route path="/politique-cookies" element={<CookiePolicyPage />} />
          <Route path="*" element={<HomePage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </Router>
  );
};

export default App;