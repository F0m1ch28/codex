import React from 'react';
import Seo from '../components/Seo';
import styles from './ResourcesPage.module.css';

const ResourcesPage = () => {
  return (
    <>
      <Seo title="Ressources | Parisian Bakeries Review" description="Bibliographies, institutions et outils mobilisés par Parisian Bakeries Review." />
      <div className={styles.wrapper}>
        <section>
          <div className="container">
            <article className={styles.section}>
              <h1>Ressources</h1>
              <p>Les ressources consultées régulièrement couvrent l’histoire des métiers de bouche, la sociologie urbaine et les sciences de l’alimentation. Elles garantissent une approche plurielle des enquêtes.</p>
            </article>
          </div>
        </section>

        <section>
          <div className="container">
            <article className={styles.section}>
              <h2>Bibliographie de référence</h2>
              <ul>
                <li><span>Les boulangers de Paris (XVIIIe-XXIe siècles)</span>, Éditions du patrimoine culinaire, 2021.</li>
                <li><span>Atlas des pains d’Île-de-France</span>, Observatoire régional de l’alimentation, 2019.</li>
                <li><span>Chroniques des métiers de bouche</span>, Revue des cultures urbaines, numéro 87.</li>
              </ul>
            </article>
          </div>
        </section>

        <section>
          <div className="container">
            <article className={styles.section}>
              <h2>Institutions consultées</h2>
              <ul>
                <li>Bibliothèque historique de la Ville de Paris, fonds métiers de bouche.</li>
                <li>Archives de Paris, série D - règlements municipaux.</li>
                <li>Musée de la Vie quotidienne, département alimentation.</li>
              </ul>
            </article>
          </div>
        </section>

        <section>
          <div className="container">
            <article className={styles.section}>
              <h2>Outils de terrain</h2>
              <ul>
                <li>Grille d’observation des cycles de pétrissage et de fermentation.</li>
                <li>Enregistrements sonores contextualisés des fournils, conservés sur support sécurisé.</li>
                <li>Cartographie participative co-construite avec des associations de quartier.</li>
              </ul>
            </article>
          </div>
        </section>
      </div>
    </>
  );
};

export default ResourcesPage;