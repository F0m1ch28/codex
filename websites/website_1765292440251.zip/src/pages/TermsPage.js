import React from 'react';
import Seo from '../components/Seo';
import styles from './TermsPage.module.css';

const TermsPage = () => {
  return (
    <>
      <Seo title="Conditions d’utilisation | Parisian Bakeries Review" description="Conditions d’utilisation du site Parisian Bakeries Review." />
      <section className={styles.section}>
        <div className="container">
          <h1>Conditions d’utilisation</h1>
          <p>Les présentes conditions encadrent l’accès et l’usage du site Parisian Bakeries Review. Toute consultation implique l’acceptation des dispositions décrites ci-dessous.</p>
          <h2>Accès aux contenus</h2>
          <p>Parisian Bakeries Review met à disposition ses analyses à des fins d’information et de recherche. L’accès peut être momentanément interrompu pour maintenance ou mise à jour sans préavis.</p>
          <h2>Droits d’auteur</h2>
          <p>Les textes, photographies et éléments graphiques sont protégés par le Code de la propriété intellectuelle. Toute reproduction intégrale nécessite une autorisation écrite de la rédaction.</p>
          <h2>Utilisation des informations</h2>
          <p>Les contenus peuvent être cités en respectant les usages journalistiques, avec mention de la source et lien vers l’article d’origine. Toute modification susceptible de dénaturer les propos est proscrite.</p>
          <h2>Responsabilité</h2>
          <p>Les informations sont vérifiées avec rigueur. Parisian Bakeries Review ne peut toutefois être tenue responsable d’une utilisation détournée des contenus ou de l’interprétation qui en est faite.</p>
          <h2>Évolutions</h2>
          <p>Ces conditions peuvent être actualisées afin de refléter les évolutions légales ou éditoriales. Dernière mise à jour : 15 septembre 2024.</p>
        </div>
      </section>
    </>
  );
};

export default TermsPage;