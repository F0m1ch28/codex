import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => {
  return (
    <>
      <Seo title="Politique de cookies | Parisian Bakeries Review" description="Politique d’utilisation des cookies pour Parisian Bakeries Review." />
      <section className={styles.section}>
        <div className="container">
          <h1>Politique de cookies</h1>
          <p>Le site Parisian Bakeries Review utilise des cookies techniques indispensables au bon fonctionnement de la navigation et à la mesure anonymisée de la fréquentation.</p>
          <h2>Cookies essentiels</h2>
          <p>Ces cookies permettent d’assurer l’affichage des pages et le maintien des préférences (langue, consentement). Ils ne collectent aucune donnée permettant l’identification directe.</p>
          <h2>Mesure d’audience</h2>
          <p>Des outils de mesure agrègent des données statistiques anonymisées afin d’évaluer l’intérêt des rubriques. Les informations recueillies sont purement techniques et ne sont pas partagées avec des tiers commerciaux.</p>
          <h2>Gestion du consentement</h2>
          <p>Lors de la première visite, un bandeau informe de la présence de cookies. Le choix peut être modifié à tout moment en supprimant les cookies depuis le navigateur.</p>
          <h2>Contact</h2>
          <p>Pour toute question relative aux cookies, la rédaction peut être jointe à l’adresse redaction@parisianbakeriesreview.fr.</p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicyPage;