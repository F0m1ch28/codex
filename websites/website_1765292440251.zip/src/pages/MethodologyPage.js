import React from 'react';
import Seo from '../components/Seo';
import styles from './MethodologyPage.module.css';

const MethodologyPage = () => {
  return (
    <>
      <Seo title="Méthodologie | Parisian Bakeries Review" description="Les méthodes de travail mises en œuvre par Parisian Bakeries Review pour documenter les boulangeries parisiennes." />
      <section className={styles.hero}>
        <div className="container">
          <h1>Cadre méthodologique</h1>
          <p>
            La méthodologie articule observation participante, entretiens approfondis et consultation d’archives, avec un souci constant de vérification croisée. Chaque enquête est conçue comme une immersion longue dans la vie des
            ateliers.
          </p>
        </div>
      </section>

      <section className={styles.stepsSection}>
        <div className="container">
          <div className={styles.stepsGrid}>
            <article className={styles.stepCard}>
              <h2>Observation in situ</h2>
              <p>Les journalistes passent plusieurs journées par mois dans les fournils pour observer les rituels de fabrication, le rythme de travail et l’organisation de l’équipe.</p>
            </article>
            <article className={styles.stepCard}>
              <h2>Analyse documentaire</h2>
              <p>Les archives municipales, les fonds photographiques et les publications spécialisées sont mobilisés pour contextualiser les pratiques contemporaines.</p>
            </article>
            <article className={styles.stepCard}>
              <h2>Entretiens croisés</h2>
              <p>Les propos de boulangers, d’historiens, de meuniers et d’habitants sont recueillis, retranscrits et soumis à une validation collective avant publication.</p>
            </article>
            <article className={styles.stepCard}>
              <h2>Vérification continue</h2>
              <p>Chaque article est relu par deux membres de la rédaction, avec vérification des citations et des données techniques auprès des sources concernées.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <h2>Cycle d’une enquête</h2>
          <ul className={styles.timeline}>
            <li>
              <span className={styles.timelineTitle}>Préfiguration</span>
              <p>Identification du sujet grâce à une veille quotidienne sur l’actualité boulangère parisienne et sur les transformations urbaines.</p>
            </li>
            <li>
              <span className={styles.timelineTitle}>Immersion</span>
              <p>Présence régulière dans la boulangerie étudiée, carnet de notes détaillant gestes, sons, odeurs et interactions, avec accord préalable des équipes.</p>
            </li>
            <li>
              <span className={styles.timelineTitle}>Mise en perspective</span>
              <p>Recoupement des observations avec des données historiques, démographiques et réglementaires collectées auprès d’institutions spécialisées.</p>
            </li>
            <li>
              <span className={styles.timelineTitle}>Rédaction finale</span>
              <p>Construction d’un récit analytique, relecture par des pairs et accord final des personnes citées avant mise en ligne.</p>
            </li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default MethodologyPage;