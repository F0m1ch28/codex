import React from 'react';
import Seo from '../components/Seo';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => {
  return (
    <>
      <Seo title="Politique de confidentialité | Parisian Bakeries Review" description="Politique de confidentialité de Parisian Bakeries Review." />
      <section className={styles.section}>
        <div className="container">
          <h1>Politique de confidentialité</h1>
          <p>Parisian Bakeries Review respecte les normes européennes en matière de protection des données personnelles. Les informations déposées via le formulaire de contact sont utilisées exclusivement pour répondre aux messages reçus.</p>
          <h2>Données collectées</h2>
          <p>Les données collectées se limitent au nom, à l’adresse électronique, au sujet et au contenu du message. Aucune autre donnée n’est enregistrée.</p>
          <h2>Base légale</h2>
          <p>La collecte de données repose sur l’intérêt légitime consistant à assurer le suivi des échanges avec les lecteurs, sources ou partenaires institutionnels.</p>
          <h2>Durée de conservation</h2>
          <p>Les messages sont conservés pendant douze mois maximum, le temps d’étudier leur contribution aux enquêtes en cours. Passé ce délai, ils sont supprimés de manière sécurisée.</p>
          <h2>Droits des personnes</h2>
          <p>Toute personne peut demander l’accès, la rectification ou la suppression des informations la concernant en écrivant à redaction@parisianbakeriesreview.fr. Une réponse est adressée sous trente jours ouvrés.</p>
          <h2>Hébergement</h2>
          <p>Le site est hébergé sur une infrastructure européenne respectant les exigences du RGPD. Les journaux techniques sont conservés pour la sécurisation du site et ne permettent pas l’identification directe des visiteurs.</p>
        </div>
      </section>
    </>
  );
};

export default PrivacyPage;