import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus("Le formulaire requiert un nom, une adresse électronique et un message pour être transmis.");
      return;
    }
    setStatus("Message transmis. La rédaction analysera la proposition avant toute prise de contact.");
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: '',
    });
  };

  return (
    <>
      <Seo title="Contact | Parisian Bakeries Review" description="Formulaire de contact pour joindre la rédaction de Parisian Bakeries Review." />
      <div className="container">
        <div className={styles.wrapper}>
          <section className={styles.formSection}>
            <h1>Contact</h1>
            <p>Ce formulaire permet de partager des informations, des précisions méthodologiques ou des suggestions d’études avec Parisian Bakeries Review.</p>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.inlineGroup}>
                <div className={styles.inputGroup}>
                  <label htmlFor="name" className={styles.label}>
                    Nom complet
                  </label>
                  <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className={styles.input} placeholder="Nom et prénom" />
                </div>
                <div className={styles.inputGroup}>
                  <label htmlFor="email" className={styles.label}>
                    Adresse électronique
                  </label>
                  <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} className={styles.input} placeholder="adresse@example.fr" />
                </div>
              </div>
              <div className={styles.inputGroup}>
                <label htmlFor="subject" className={styles.label}>
                  Sujet
                </label>
                <input type="text" id="subject" name="subject" value={formData.subject} onChange={handleChange} className={styles.input} placeholder="Intitulé du message" />
              </div>
              <div className={styles.inputGroup}>
                <label htmlFor="message" className={styles.label}>
                  Message
                </label>
                <textarea id="message" name="message" value={formData.message} onChange={handleChange} className={styles.textarea} placeholder="Texte du message" />
              </div>
              <button type="submit" className={styles.submit}>
                Envoyer
              </button>
              {status && <p className={styles.status}>{status}</p>}
            </form>
          </section>
          <aside className={styles.infoSection}>
            <h2>Coordonnées officielles</h2>
            <p>Adresse postale : Parisian Bakeries Review, Boîte Postale 75001, Paris, France.</p>
            <p>Adresse électronique : redaction@parisianbakeriesreview.fr.</p>
            <p>La rédaction traite les messages une fois par semaine afin d’organiser les réponses pertinentes et de maintenir un suivi éditorial cohérent.</p>
            <h3>Informations complémentaires</h3>
            <p>Pour les demandes d’entretiens, il est recommandé d’indiquer le contexte, les dates envisagées et les interlocuteurs souhaités. Les propositions d’articles invités sont étudiées selon leur adéquation avec la ligne éditoriale.</p>
          </aside>
        </div>
      </div>
    </>
  );
};

export default ContactPage;