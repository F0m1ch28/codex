import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './HomePage.module.css';

const latestResearch = [
  {
    title: 'Chronologie des fournils de la Rive Droite',
    synopsis: 'Cette étude suit l’installation des boulangeries indépendantes le long des boulevards parisiens depuis les années 1950.',
    date: 'Publié le 12 septembre 2024',
    theme: 'Histoire urbaine',
  },
  {
    title: 'Techniques de viennoiserie dans le XIIIe arrondissement',
    synopsis: 'Une immersion dans les laboratoires mettant en lumière les adaptations des tournées du matin.',
    date: 'Publié le 28 août 2024',
    theme: 'Technique',
  },
  {
    title: 'Transmission familiale et ateliers de quartier',
    synopsis: 'Cartographie des dynasties boulangères et des écoles professionnelles qui les accompagnent.',
    date: 'Publié le 9 août 2024',
    theme: 'Sociologie',
  },
  {
    title: 'Dialogues entre boulangers et meuniers franciliens',
    synopsis: 'Analyse des circuits d’approvisionnement en céréales anciennes et de leur influence sur les pains spéciaux.',
    date: 'Publié le 24 juillet 2024',
    theme: 'Approvisionnement',
  },
];

const HomePage = () => {
  return (
    <>
      <Seo
        title="Parisian Bakeries Review | Observatoire des boulangeries parisiennes"
        description="Parisian Bakeries Review propose des analyses indépendantes sur les boulangeries de Paris, leurs pratiques artisanales et leur rôle culturel."
      />
      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <p className={styles.heroKicker}>Revue culturelle indépendante</p>
          <h1 className={styles.heroTitle}>Parisian Bakeries Review analyse les dynamiques des fournils parisiens</h1>
          <p className={styles.heroSubtitle}>
            La rédaction documente les gestes, les lieux et les communautés qui façonnent le pain à Paris, en croisant enquêtes de terrain, entretiens et archives spécialisées.
          </p>
        </div>
      </section>

      <section className={styles.latestSection}>
        <div className="container">
          <h2>Dernières recherches</h2>
          <div className={styles.latestGrid}>
            {latestResearch.map((item) => (
              <article key={item.title} className={styles.articleCard}>
                <span className={styles.articleTheme}>{item.theme}</span>
                <h3 className={styles.articleTitle}>{item.title}</h3>
                <p className={styles.articleSynopsis}>{item.synopsis}</p>
                <time className={styles.articleDate}>{item.date}</time>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.focusSection}>
        <div className="container">
          <div className={styles.focusContent}>
            <h2>Thème en lumière : fermentation naturelle et mémoire des quartiers</h2>
            <p>
              Cette thématique observe la manière dont les fermentations longues nourrissent l’identité gustative des arrondissements. Les carnets de terrain révèlent des pratiques héritées, mais aussi des innovations portées par
              de nouvelles générations de boulangers.
            </p>
            <Link to="/themes" className={styles.focusLink} aria-label="Accès à la section Thèmes">
              Section Thèmes
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.quoteSection}>
        <div className="container">
          <blockquote className={styles.quote}>« Chaque pétrin raconte l’histoire du quartier qui l’entoure. »</blockquote>
          <p className={styles.quoteSource}>Camille Renard, maître-boulangère à Belleville</p>
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className="container">
          <h2>Approche éditoriale</h2>
          <p>
            Parisian Bakeries Review croise observations, témoignages et données patrimoniales pour dresser un panorama des savoir-faire boulangers de la capitale. La publication privilégie des analyses contextualisées, sans plaidoyer
            commercial.
          </p>
          <Link to="/a-propos" className={styles.aboutLink} aria-label="Page À propos">
            Page À propos
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;