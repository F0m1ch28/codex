import React from 'react';
import Seo from '../components/Seo';
import styles from './AboutPage.module.css';

const teamMembers = [
  {
    name: 'Élise Moreau',
    role: 'Rédactrice en chef',
    focus: 'Coordonne les enquêtes de terrain, suit les archives municipales et supervise l’orientation éditoriale.',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80',
  },
  {
    name: 'Philippe Garnier',
    role: 'Responsable visuel',
    focus: 'Documente les ateliers par la photographie et développe les cartographies des itinéraires boulangers.',
    image: 'https://images.unsplash.com/photo-1522556189639-b150ed9c4330?auto=format&fit=crop&w=800&q=80',
  },
  {
    name: 'Sofia Laurent',
    role: 'Analyste des pratiques alimentaires',
    focus: 'Étudie les usages quotidiens du pain et mène les entretiens avec les acteurs associatifs.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=80',
  },
];

const AboutPage = () => {
  return (
    <>
      <Seo title="À propos | Parisian Bakeries Review" description="Présentation de l’équipe éditoriale et des principes de Parisian Bakeries Review." />
      <section className={styles.intro}>
        <div className="container">
          <h1>À propos</h1>
          <p>
            Parisian Bakeries Review est une publication culturelle indépendante dédiée à l’observation des boulangeries parisiennes. Les enquêtes explorent les gestes, l’organisation des ateliers et les dynamiques urbaines qui
            entourent la fabrication du pain.
          </p>
          <p>
            La rédaction croise archives municipales, corpus iconographiques et témoignages de terrain afin de restituer une vision nuancée des transformations boulangères.
          </p>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2>Équipe éditoriale</h2>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.memberCard}>
                <img src={member.image} alt={`Portrait de ${member.name}`} className={styles.memberPhoto} />
                <div className={styles.memberText}>
                  <h3>{member.name}</h3>
                  <p className={styles.memberRole}>{member.role}</p>
                  <p>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.valuesSection}>
        <div className="container">
          <h2>Principes éditoriaux</h2>
          <ul className={styles.valuesList}>
            <li>
              <span>Indépendance :</span> la sélection des sujets repose sur l’intérêt patrimonial et social, sans collaboration promotionnelle.
            </li>
            <li>
              <span>Transparence des sources :</span> chaque article précise l’origine des données et des témoignages recueillis.
            </li>
            <li>
              <span>Lenteur volontaire :</span> les enquêtes privilégient les temporalités longues afin de comprendre les évolutions durables.
            </li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default AboutPage;