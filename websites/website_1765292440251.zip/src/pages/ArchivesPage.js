import React from 'react';
import Seo from '../components/Seo';
import styles from './ArchivesPage.module.css';

const archives = [
  {
    year: '2024',
    items: [
      {
        title: 'Évolution réglementaire des boulangeries parisiennes',
        description: 'Étude des arrêtés municipaux entre 1970 et 2024 et de leur influence sur les horaires d’ouverture et la production.',
        date: 'Août 2024',
      },
      {
        title: 'Le renouveau des fournils de la Seine-Saint-Denis',
        description: 'Analyse du dialogue entre boulangeries parisiennes et communes limitrophes pour l’approvisionnement en céréales.',
        date: 'Juin 2024',
      },
    ],
  },
  {
    year: '2023',
    items: [
      {
        title: 'Cartographie des baguettes de tradition',
        description: 'Comparatif des profils de cuisson dans huit arrondissements parisiens.',
        date: 'Novembre 2023',
      },
      {
        title: 'Transmission familiale dans les ateliers parisiens',
        description: 'Enquête sur les lignées de maîtres-boulangers et leurs écoles de formation.',
        date: 'Septembre 2023',
      },
      {
        title: 'Viennoiseries et innovations végétales',
        description: 'Observation des pratiques d’inclusion de céréales anciennes et de matières grasses végétales.',
        date: 'Avril 2023',
      },
    ],
  },
  {
    year: '2022',
    items: [
      {
        title: 'Nocturne des fournils du cinquième arrondissement',
        description: 'Reportage sur les équipes de nuit et leur coordination logistique.',
        date: 'Décembre 2022',
      },
      {
        title: 'Styles boulangers et identité de quartier',
        description: 'Analyse de la manière dont la morphologie urbaine influence les vitrines et les gammes de pain.',
        date: 'Juillet 2022',
      },
    ],
  },
];

const ArchivesPage = () => {
  return (
    <>
      <Seo title="Archives | Parisian Bakeries Review" description="Accès aux archives d’articles publiés par Parisian Bakeries Review." />
      <section className={styles.intro}>
        <div className="container">
          <h1>Archives</h1>
          <p>Les archives regroupent les enquêtes par année de publication. Chaque dossier précise les sources, le contexte et les approches méthodologiques mobilisées.</p>
        </div>
      </section>

      <section className={styles.archiveList}>
        <div className="container">
          {archives.map((yearData) => (
            <div key={yearData.year} className={styles.yearBlock}>
              <h2>{yearData.year}</h2>
              <div className={styles.itemsGrid}>
                {yearData.items.map((item) => (
                  <article key={item.title} className={styles.archiveCard}>
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                    <time className={styles.date}>{item.date}</time>
                  </article>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default ArchivesPage;