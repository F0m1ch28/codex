import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './ThemesPage.module.css';

const themes = [
  {
    title: 'Fermentations et levains',
    description: 'Analyse des fermentations longues, des levains liquides ou durs et de leurs implications sensorielles.',
    focus: 'Comparaison de douze ateliers entre les arrondissements du nord et du sud de la capitale.',
  },
  {
    title: 'Patrimoine architectural',
    description: 'Étude des façades, enseignes peintes et intérieurs classés ou réhabilités.',
    focus: 'Inventaire photographique actualisé chaque saison avec annotations historiques.',
  },
  {
    title: 'Approvisionnement et céréales',
    description: 'Suivi des filières meunières franciliennes et des initiatives coopératives.',
    focus: 'Tableaux de correspondance entre terroirs céréaliers et pains proposés.',
  },
  {
    title: 'Vie de quartier et sociabilité',
    description: 'Observation des interactions quotidiennes entre artisans, habitants et commerces voisins.',
    focus: 'Cartes sensibles réalisées avec des collectifs urbains et associations locales.',
  },
];

const ThemesPage = () => {
  return (
    <>
      <Seo title="Thèmes | Parisian Bakeries Review" description="Les grands axes de recherche poursuivis par Parisian Bakeries Review." />
      <div className={styles.wrapper}>
        <section className={styles.intro}>
          <div className="container">
            <h1>Thèmes de recherche</h1>
            <p>Les chantiers d’étude structurent la publication et assurent la continuité des enquêtes. Chaque thème est nourri par un corpus documentaire et des immersions de terrain régulières.</p>
          </div>
        </section>
        <section>
          <div className="container">
            <div className={styles.grid}>
              {themes.map((theme) => (
                <article key={theme.title} className={styles.card}>
                  <h2 className={styles.cardTitle}>{theme.title}</h2>
                  <p>{theme.description}</p>
                  <p className={styles.cardFocus}>{theme.focus}</p>
                  <Link to="/archives" className={styles.link}>
                    Dossiers liés
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ThemesPage;