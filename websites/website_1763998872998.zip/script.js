document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navList = document.querySelector(".nav-list");

  if (navToggle && navList) {
    navToggle.addEventListener("click", () => {
      navList.classList.toggle("open");
      navToggle.classList.toggle("open");
      navToggle.setAttribute(
        "aria-expanded",
        navToggle.classList.contains("open")
      );
    });
  }

  const currentPage = document.body.dataset.page;
  document.querySelectorAll(".nav-list a").forEach((link) => {
    if (link.dataset.page === currentPage) {
      link.classList.add("active");
    }
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");

  if (cookieBanner && acceptBtn && declineBtn) {
    const consent = localStorage.getItem("nmgCookieConsent");
    if (!consent) {
      cookieBanner.classList.remove("hidden");
    }

    acceptBtn.addEventListener("click", () => {
      localStorage.setItem("nmgCookieConsent", "accepted");
      cookieBanner.classList.add("hidden");
    });

    declineBtn.addEventListener("click", () => {
      localStorage.setItem("nmgCookieConsent", "declined");
      cookieBanner.classList.add("hidden");
    });
  }
});