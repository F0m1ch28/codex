document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!isExpanded).toString());
      navToggle.classList.toggle("is-active");
      siteNav.classList.toggle("is-open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("is-open")) {
          siteNav.classList.remove("is-open");
          navToggle.classList.remove("is-active");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const storedConsent = localStorage.getItem("dfCookieConsent");
    if (storedConsent) {
      cookieBanner.classList.add("is-hidden");
    }

    cookieBanner.querySelectorAll("button[data-consent]").forEach((button) => {
      button.addEventListener("click", (event) => {
        const choice = event.currentTarget.getAttribute("data-consent");
        localStorage.setItem("dfCookieConsent", choice);
        cookieBanner.classList.add("is-hidden");
      });
    });
  }
});