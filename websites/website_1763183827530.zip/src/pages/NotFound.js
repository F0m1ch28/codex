import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './NotFound.module.css';

function NotFound() {
  return (
    <>
      <Helmet>
        <title>Page Not Found | TechSolutions</title>
        <meta
          name="description"
          content="The page you are looking for could not be found on TechSolutions. Return to the homepage or explore our services."
        />
      </Helmet>
      <section className={styles.section}>
        <div className="layout">
          <div className={styles.card}>
            <div className={styles.code}>404</div>
            <h1>We can’t find the page you’re looking for.</h1>
            <p>
              The page may have been moved or no longer exists. Let’s guide you back to the right place.
            </p>
            <div className={styles.actions}>
              <Link to="/" className={styles.primary}>
                Back to home
              </Link>
              <Link to="/services" className={styles.secondary}>
                View our services
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default NotFound;