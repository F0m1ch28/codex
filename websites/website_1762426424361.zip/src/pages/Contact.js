import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  nome: '',
  cognome: '',
  email: '',
  telefono: '',
  messaggio: '',
  percorso: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.nome.trim()) newErrors.nome = 'Inserisci il tuo nome.';
    if (!formData.cognome.trim()) newErrors.cognome = 'Inserisci il tuo cognome.';
    if (!formData.email.trim()) {
      newErrors.email = 'Inserisci un indirizzo email valido.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Formato email non valido.';
    }
    if (!formData.messaggio.trim()) newErrors.messaggio = 'Raccontaci le tue esigenze.';
    if (!formData.percorso) newErrors.percorso = 'Seleziona il percorso di interesse.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Contatti | Digital Master Academy</title>
        <meta
          name="description"
          content="Contatta Digital Master Academy per informazioni sui corsi di formazione digitale. Compila il form e ricevi supporto personalizzato entro 48 ore."
        />
        <meta
          name="keywords"
          content="contatti corsi digitali, academy digitale Milano, formazione digitale contatti, candidatura corsi digitali"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Parliamo del tuo prossimo obiettivo</h1>
          <p>
            Compila il form e un advisor ti contatterà per definire il percorso più adatto. Siamo disponibili
            anche per incontri con aziende e team HR.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formWrapper}>
              <h2>Richiedi informazioni</h2>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <div className={styles.formRow}>
                  <label htmlFor="nome">Nome*</label>
                  <input
                    id="nome"
                    name="nome"
                    value={formData.nome}
                    onChange={handleChange}
                    type="text"
                    autoComplete="given-name"
                    required
                  />
                  {errors.nome && (
                    <span className={styles.errorMessage} role="alert">
                      {errors.nome}
                    </span>
                  )}
                </div>

                <div className={styles.formRow}>
                  <label htmlFor="cognome">Cognome*</label>
                  <input
                    id="cognome"
                    name="cognome"
                    value={formData.cognome}
                    onChange={handleChange}
                    type="text"
                    autoComplete="family-name"
                    required
                  />
                  {errors.cognome && (
                    <span className={styles.errorMessage} role="alert">
                      {errors.cognome}
                    </span>
                  )}
                </div>

                <div className={styles.formRow}>
                  <label htmlFor="email">Email*</label>
                  <input
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    type="email"
                    autoComplete="email"
                    required
                  />
                  {errors.email && (
                    <span className={styles.errorMessage} role="alert">
                      {errors.email}
                    </span>
                  )}
                </div>

                <div className={styles.formRow}>
                  <label htmlFor="telefono">Telefono</label>
                  <input
                    id="telefono"
                    name="telefono"
                    value={formData.telefono}
                    onChange={handleChange}
                    type="tel"
                    autoComplete="tel"
                  />
                </div>

                <div className={styles.formRow}>
                  <label htmlFor="percorso">Percorso di interesse*</label>
                  <select
                    id="percorso"
                    name="percorso"
                    value={formData.percorso}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Seleziona un percorso</option>
                    <option value="advertising">Pubblicità Targetizzata</option>
                    <option value="coding">Coding</option>
                    <option value="social">Social Media Marketing</option>
                    <option value="azienda">Programma per aziende</option>
                  </select>
                  {errors.percorso && (
                    <span className={styles.errorMessage} role="alert">
                      {errors.percorso}
                    </span>
                  )}
                </div>

                <div className={styles.formRow}>
                  <label htmlFor="messaggio">Messaggio*</label>
                  <textarea
                    id="messaggio"
                    name="messaggio"
                    rows="5"
                    value={formData.messaggio}
                    onChange={handleChange}
                    required
                  />
                  {errors.messaggio && (
                    <span className={styles.errorMessage} role="alert">
                      {errors.messaggio}
                    </span>
                  )}
                </div>

                <button type="submit" className="btn-primary">
                  Invia richiesta
                </button>
                {submitted && (
                  <p className={styles.successMessage} role="status">
                    Grazie! Ti ricontatteremo entro 48 ore lavorative con tutte le informazioni.
                  </p>
                )}
              </form>
            </div>

            <div className={styles.infoCard}>
              <h2>Contattaci</h2>
              <p>
                <strong>Indirizzo:</strong><br />
                Via Roma, 100, 28821 Cannero Riviera VB
              </p>
              <p>
                <strong>Telefono:</strong><br />
                <a href="tel:+390212346751">+39 02 1234 6751</a>
              </p>
              <p>
                <strong>Email:</strong><br />
                <a href="mailto:info@digitalmasteracademy.it">info@digitalmasteracademy.it</a>
              </p>
              <p>
                <strong>Orari di risposta:</strong><br />
                Dal lunedì al venerdì, 9:00-18:30
              </p>
              <div className={styles.mapWrapper} aria-label="Mappa della sede di Milano">
                <iframe
                  title="Digital Master Academy - sede di Milano"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5587.617539701008!2d9.1366715!3d45.7348649!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDQ0JzA1LjUiTiA5wrAwOCcwMi4wIkU!5e0!3m2!1sit!2sit!4v1709815822455!5m2!1sit!2sit"
                  width="100%"
                  height="260"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;