import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>Chi siamo | Digital Master Academy</title>
      <meta
        name="description"
        content="Conosci la storia di Digital Master Academy: missione, team e metodologia che guidano la formazione digitale in Italia."
      />
      <meta
        name="keywords"
        content="formazione digitale, academy digitale Milano, corsi online Italia, docenti digital marketing, metodologia didattica digitale"
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <h1>Chi siamo</h1>
          <p>
            Siamo una community di professionisti che ha trasformato l’esperienza sul campo in
            percorsi didattici concreti. Dal 2014 accompagniamo talenti e aziende nel riprogettare
            strategie digitali con un approccio sperimentale e misurabile.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.storySection}>
      <div className="container">
        <div className={styles.storyGrid}>
          <div>
            <h2>La nostra storia</h2>
            <p>
              Digital Master Academy nasce a Milano dall’intuizione di un gruppo di consulenti e docenti universitari.
              Lavorando tra agenzie creative, reparti marketing e startup, abbiamo percepito la necessità di
              percorsi capaci di unire visione strategica, competenze tecniche e capacità di execution.
            </p>
            <p>
              In pochi anni abbiamo esteso la nostra presenza in tutta Italia grazie a classi remote altamente interattive,
              piattaforme proprietarie e partnership con aziende che desiderano far crescere le proprie persone in modo mirato.
            </p>
          </div>
          <div className={styles.missionCard}>
            <h3>Missione</h3>
            <p>
              Alimentare la crescita del tessuto digitale italiano mettendo a disposizione
              competenze, strumenti e metodi che portano innovazione concreta nei team.
            </p>
            <h3>Visione</h3>
            <p>
              Diventare il punto di riferimento per chi desidera guidare la trasformazione digitale,
              valorizzando talento, creatività e capacità analitica.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.timelineSection}>
      <div className="container">
        <h2>Punti chiave del nostro percorso</h2>
        <div className={styles.timeline}>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2014</span>
            <p>Fondazione dell’Academy a Milano con il primo Master in Digital Marketing integrato.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2017</span>
            <p>Introduzione dei percorsi Coding e Social Media con laboratori su casi reali.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2020</span>
            <p>Lancio della piattaforma virtual classroom con analytics personalizzati per ogni studente.</p>
          </div>
          <div className={styles.timelineItem}>
            <span className={styles.timelineYear}>2023</span>
            <p>Collaborazioni con oltre 70 aziende partner e network alumni attivo in tutta Europa.</p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.methodSection}>
      <div className="container">
        <h2>La nostra metodologia</h2>
        <div className={styles.methodGrid}>
          <article className={styles.methodCard}>
            <h3>Learning design</h3>
            <p>
              Ogni modulo viene progettato con framework didattici evidence-based, alternando teoria,
              esercitazioni immersive e momenti riflessivi per consolidare le competenze.
            </p>
          </article>
          <article className={styles.methodCard}>
            <h3>Mentorship</h3>
            <p>
              Ogni studente è affiancato da mentor certificati che supportano nella definizione di roadmap professionali
              e nella costruzione di progetti da presentare in portfolio.
            </p>
          </article>
          <article className={styles.methodCard}>
            <h3>Learning analytics</h3>
            <p>
              Attraverso dashboard personalizzate monitoriamo progressi, livelli di coinvolgimento e aree da potenziare,
              fornendo report trasparenti a studenti e aziende.
            </p>
          </article>
          <article className={styles.methodCard}>
            <h3>Partnership</h3>
            <p>
              Collaboriamo con brand, agenzie e startup per offrire brief reali, testimonianze e possibilità di inserimento
              in progetti ad alto impatto.
            </p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default About;