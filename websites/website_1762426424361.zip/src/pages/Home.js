import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Studenti attivi', value: 1800, suffix: '+' },
  { label: 'Progetti completati', value: 240, suffix: '' },
  { label: 'Tasso di soddisfazione', value: 96, suffix: '%' },
  { label: 'Mentor qualificati', value: 12, suffix: '' }
];

const testimonialsData = [
  {
    quote:
      'Il percorso di Pubblicità Targetizzata mi ha permesso di ridisegnare le campagne del mio studio con un approccio basato sui dati. Docenti disponibili e materiali sempre aggiornati.',
    name: 'Giulia Rinaldi',
    role: 'Digital Strategist, Torino'
  },
  {
    quote:
      'Ho scelto la traccia Coding per integrare competenze di sviluppo nel mio lavoro marketing. Le sessioni pratiche e i project work mi hanno aiutato a consolidare le competenze.',
    name: 'Marco Bellini',
    role: 'Marketing Technologist, Milano'
  },
  {
    quote:
      'Il programma Social Media Marketing mi ha dato metodo nella costruzione di format per brand nativi digitali. La community è un vero acceleratore.',
    name: 'Sara Colombo',
    role: 'Content Lead, Firenze'
  }
];

const projectsData = [
  {
    title: 'Campagna omnicanale per brand moda',
    category: 'Campagne Ads',
    image: 'https://picsum.photos/1200/800?random=9',
    description:
      'Ottimizzazione combinata di Facebook Ads e Google Ads con dashboard di controllo real-time per un marchio fashion italiano.'
  },
  {
    title: 'Piattaforma web per academy tech',
    category: 'Sviluppo Web',
    image: 'https://picsum.photos/1200/800?random=10',
    description:
      'Sviluppo di un portale modulare con React e integrazione API per la gestione di iscrizioni e contenuti formativi.'
  },
  {
    title: 'Strategia contenuti TikTok retail',
    category: 'Strategie Social',
    image: 'https://picsum.photos/1200/800?random=11',
    description:
      'Definizione di rubriche video, produzione format verticali e analisi KPI per un network retail nazionale.'
  },
  {
    title: 'Programma di marketing automation',
    category: 'Campagne Ads',
    image: 'https://picsum.photos/1200/800?random=12',
    description:
      'Implementazione flussi automatizzati con segmentazione predittiva per una scale-up B2B in ambito SaaS.'
  },
  {
    title: 'Dashboard analitica personalizzata',
    category: 'Sviluppo Web',
    image: 'https://picsum.photos/1200/800?random=13',
    description:
      'Creazione di una dashboard interattiva per monitorare conversioni e retention con visualizzazioni avanzate.'
  },
  {
    title: 'Calendario editoriale multi-brand',
    category: 'Strategie Social',
    image: 'https://picsum.photos/1200/800?random=14',
    description:
      'Coordinamento di un piano editoriale a 6 mesi con output cross-platform, linee guida e asset pronti per la pubblicazione.'
  }
];

const faqData = [
  {
    question: 'Quanto tempo serve per completare i corsi?',
    answer:
      'Ogni percorso è strutturato in moduli settimanali con momenti sincroni e asincroni. In media servono da tre a cinque mesi per completare tutte le attività, inclusi i project work.'
  },
  {
    question: 'Sono previsti momenti di mentorship individuale?',
    answer:
      'Sì, ogni studente viene affiancato da un mentor che offre sessioni one-to-one per allinearsi sugli obiettivi professionali e sull’applicazione pratica dei contenuti.'
  },
  {
    question: 'Quali sono i requisiti di ingresso?',
    answer:
      'È sufficiente una buona motivazione e familiarità con strumenti digitali di base. Durante il colloquio iniziale mappiamo le competenze per consigliare il percorso più adatto.'
  },
  {
    question: 'Come vengono valutati i progressi?',
    answer:
      'Ogni modulo prevede esercitazioni guidate, quiz di verifica e un progetto finale. I docenti forniscono feedback qualitativi e indicatori misurabili per monitorare i progressi.'
  },
  {
    question: 'Che tipo di community offre l’Academy?',
    answer:
      'La community comprende forum tematici, sessioni live con ospiti, gruppi di lavoro e canali dedicati al networking tra studenti e alumni.'
  }
];

const blogPosts = [
  {
    title: 'Framework per progettare customer journey ibridi',
    excerpt:
      'Dalla raccolta dati alle micro-conversioni: una guida pratica per costruire mappe esperienziali e orchestrare le leve digitali.',
    date: '14 Marzo 2024'
  },
  {
    title: 'Design di dashboard marketing orientate all’azione',
    excerpt:
      'Come impostare KPI, visualizzazioni e alert per trasformare i dati in decisioni operative rapide e condivise.',
    date: '2 Marzo 2024'
  },
  {
    title: 'Nuove competenze del Social Media Strategist 2024',
    excerpt:
      'Storytelling, automazioni e analisi predittive: il toolkit aggiornato per presidiare i canali social con efficacia.',
    date: '19 Febbraio 2024'
  }
];

const Home = () => {
  const statsRef = useRef(null);
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [statsStarted, setStatsStarted] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Tutti');
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setStatsStarted(true);
          observer.disconnect();
        }
      },
      { threshold: 0.35 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsStarted) return;
    const duration = 1600;
    const frameRate = 32;
    const totalFrames = Math.round(duration / frameRate);

    let frame = 0;
    const interval = setInterval(() => {
      frame += 1;
      setCounters((prev) =>
        prev.map((value, index) => {
          const progress = Math.min(frame / totalFrames, 1);
          const target = statsData[index].value;
          return Math.floor(target * progress);
        })
      );
      if (frame === totalFrames) {
        clearInterval(interval);
      }
    }, frameRate);

    return () => clearInterval(interval);
  }, [statsStarted]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Tutti') {
      return projectsData;
    }
    return projectsData.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <Helmet>
        <title>Digital Master Academy | Formazione digitale per professionisti</title>
        <meta
          name="description"
          content="Scopri i corsi avanzati di Digital Master Academy: Pubblicità Targetizzata, Coding e Social Media Marketing. Percorsi intensivi, mentor dedicati, progetti reali."
        />
        <meta
          name="keywords"
          content="corsi online Italia, pubblicità targetizzata, corso coding Milano, social media marketing, formazione digitale, corsi SMM, imparare programmazione, Facebook Ads, Instagram marketing, sviluppo web"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <img
          src="https://picsum.photos/1600/900?random=1"
          alt="Professionisti al lavoro su laptop e dashboard digitali"
          className={styles.heroImage}
        />
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.heroLabel}>Formazione digitale avanzata</p>
            <h1 className={styles.heroTitle}>Trasforma la Tua Carriera Digitale</h1>
            <p className={styles.heroSubtitle}>
              Percorsi concreti, project work reali e mentor esperti per sviluppare competenze
              in Pubblicità Targetizzata, Coding e Social Media Marketing.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contatti" className="btn-primary">
                Inizia Oggi
              </Link>
              <Link to="/programma" className="btn-secondary">
                Esplora il Programma
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <span className={styles.statNumber}>
                  {counters[index]}
                  {stat.suffix}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.introSection}>
        <div className="container">
          <div className={styles.introGrid}>
            <div className={styles.introContent}>
              <p className={styles.sectionLabel}>Chi siamo</p>
              <h2 className={styles.sectionTitle}>Un ecosistema dedicato alla crescita digitale</h2>
              <p>
                Digital Master Academy nasce a Milano dall’incontro tra professionisti del marketing,
                dello sviluppo e della strategia digitale. Crediamo in una formazione che unisce
                teoria, pratica e confronto continuo con i trend del settore.
              </p>
              <p>
                Ogni percorso è costruito su una metodologia blended: sessioni live, laboratori,
                mentorship individuale e risorse on demand. La community di studenti e alumni
                alimenta un ecosistema in cui condividere esperienze, strumenti e opportunità.
              </p>
              <div className={styles.introActions}>
                <Link to="/chi-siamo" className="btn-secondary">
                  Scopri di più
                </Link>
              </div>
            </div>
            <div className={styles.introMedia}>
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Studenti che collaborano durante un workshop digitale"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.coursesSection} id="corsi">
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>I nostri corsi</p>
            <h2 className={styles.sectionTitle}>Percorsi costruiti intorno alle tue ambizioni</h2>
            <p className={styles.sectionDescription}>
              Tre specializzazioni complementari per sviluppare competenze tecniche, strategiche e creative.
            </p>
          </div>
          <div className={styles.coursesGrid}>
            <article className={styles.courseCard}>
              <img
                src="https://picsum.photos/600/420?random=3"
                alt="Dashboard con grafici di campagne pubblicitarie"
                loading="lazy"
              />
              <div className={styles.courseContent}>
                <h3>Pubblicità Targetizzata</h3>
                <p>
                  Pianifica, gestisci e ottimizza campagne su Facebook Ads e Google Ads con un approccio
                  omnicanale. Dashboard avanzate, segmentazioni e A/B test guidati.
                </p>
                <Link to="/corsi" className={styles.courseLink}>
                  Dettagli percorso →
                </Link>
              </div>
            </article>
            <article className={styles.courseCard}>
              <img
                src="https://picsum.photos/600/420?random=4"
                alt="Schermo con codice di programmazione"
                loading="lazy"
              />
              <div className={styles.courseContent}>
                <h3>Coding</h3>
                <p>
                  Dalle fondamenta di HTML, CSS e JavaScript fino alle basi di Python.
                  Laboratori full-stack, versioning Git e deploy su ambienti moderni.
                </p>
                <Link to="/corsi" className={styles.courseLink}>
                  Moduli inclusi →
                </Link>
              </div>
            </article>
            <article className={styles.courseCard}>
              <img
                src="https://picsum.photos/600/420?random=5"
                alt="Strategia di social media marketing su laptop"
                loading="lazy"
              />
              <div className={styles.courseContent}>
                <h3>Social Media Marketing</h3>
                <p>
                  Strategie per Instagram, TikTok e content marketing con focus su community design,
                  format narrativi e analisi delle performance.
                </p>
                <Link to="/corsi" className={styles.courseLink}>
                  Scopri la traccia →
                </Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>Come funziona</p>
            <h2 className={styles.sectionTitle}>Un percorso strutturato per creare impatto</h2>
          </div>
          <div className={styles.processGrid}>
            <article className={styles.processStep}>
              <span className={styles.stepNumber}>01</span>
              <h3>Assessment iniziale</h3>
              <p>
                Colloquio di orientamento per analizzare competenze, obiettivi e definire un piano personalizzato.
              </p>
            </article>
            <article className={styles.processStep}>
              <span className={styles.stepNumber}>02</span>
              <h3>Laboratori e live session</h3>
              <p>
                Lezioni interattive con docenti senior, esercitazioni guidate e casi studio aggiornati.
              </p>
            </article>
            <article className={styles.processStep}>
              <span className={styles.stepNumber}>03</span>
              <h3>Project work reale</h3>
              <p>
                Team multidisciplinari lavorano a progetti commissionati da aziende partner con review dedicate.
              </p>
            </article>
            <article className={styles.processStep}>
              <span className={styles.stepNumber}>04</span>
              <h3>Portfolio e certificazioni</h3>
              <p>
                Creazione del portfolio digitale, attestati riconosciuti e supporto nel posizionamento professionale.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.whySection}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>Perché sceglierci</p>
            <h2 className={styles.sectionTitle}>Un modello didattico orientato ai risultati</h2>
          </div>
          <div className={styles.whyGrid}>
            <article className={styles.whyCard}>
              <h3>Metodologia blended</h3>
              <p>
                Combiniamo sessioni live, studio autonomo, mentoring e project work per favorire apprendimento continuo.
              </p>
            </article>
            <article className={styles.whyCard}>
              <h3>Docenti senior</h3>
              <p>
                Professionisti con esperienza in agenzie, aziende tech e startup accompagnano ogni classe passo dopo passo.
              </p>
            </article>
            <article className={styles.whyCard}>
              <h3>Community attiva</h3>
              <p>
                Forum dedicati, eventi e job hub interno per condividere opportunità, feedback e collaborazioni.
              </p>
            </article>
            <article className={styles.whyCard}>
              <h3>Learning analytics</h3>
              <p>
                Dashboard personalizzate per monitorare progressi, competenze sviluppate e milestone raggiunte.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.testimonialSection} aria-label="Testimonianze studenti">
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>Testimonianze</p>
            <h2 className={styles.sectionTitle}>Storie di crescita professionale</h2>
          </div>
          <div className={styles.testimonialWrapper}>
            <div className={styles.testimonialContent}>
              <blockquote className={styles.quote}>
                “{testimonialsData[activeTestimonial].quote}”
              </blockquote>
              <p className={styles.quoteAuthor}>{testimonialsData[activeTestimonial].name}</p>
              <span className={styles.quoteRole}>{testimonialsData[activeTestimonial].role}</span>
            </div>
            <div className={styles.testimonialControls}>
              {testimonialsData.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`${styles.dot} ${index === activeTestimonial ? styles.activeDot : ''}`}
                  aria-label={`Mostra testimonianza di ${testimonial.name}`}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>Team</p>
            <h2 className={styles.sectionTitle}>Mentor e docenti dedicati al tuo percorso</h2>
          </div>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=6"
                alt="Docente di advertising durante una lezione"
                loading="lazy"
              />
              <div className={styles.teamInfo}>
                <h3>Elena Mariani</h3>
                <p>Head of Performance Marketing</p>
              </div>
              <div className={styles.teamOverlay}>
                <p>
                  Ex performance lead in agenzie internazionali, specializzata in automazioni e integrazione CRM.
                </p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=7"
                alt="Mentor di sviluppo web con laptop"
                loading="lazy"
              />
              <div className={styles.teamInfo}>
                <h3>Davide Moretti</h3>
                <p>Lead Developer & Mentor</p>
              </div>
              <div className={styles.teamOverlay}>
                <p>
                  Full-stack engineer con esperienza in startup fintech, appassionato di architetture serverless.
                </p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=8"
                alt="Strategist social media impegnata in un workshop"
                loading="lazy"
              />
              <div className={styles.teamInfo}>
                <h3>Lara Gentili</h3>
                <p>Social Media Strategist</p>
              </div>
              <div className={styles.teamOverlay}>
                <p>
                  Coach di community design, ha guidato strategie per brand lifestyle e startup direct-to-consumer.
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} id="progetti">
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>Project gallery</p>
            <h2 className={styles.sectionTitle}>Esperienze applicate con aziende partner</h2>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Filtri progetti">
            {['Tutti', 'Campagne Ads', 'Sviluppo Web', 'Strategie Social'].map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={activeFilter === category}
                className={`${styles.filterButton} ${
                  activeFilter === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>FAQ</p>
            <h2 className={styles.sectionTitle}>Domande frequenti</h2>
          </div>
          <div className={styles.accordion} role="tablist">
            {faqData.map((faq, index) => (
              <div key={faq.question} className={styles.accordionItem}>
                <button
                  type="button"
                  className={styles.accordionButton}
                  aria-expanded={openFaq === index}
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <span>{faq.question}</span>
                  <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
                </button>
                {openFaq === index && (
                  <div className={styles.accordionPanel} role="region">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <p className={styles.sectionLabel}>Insights</p>
            <h2 className={styles.sectionTitle}>Trend e risorse dal nostro laboratorio</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/chi-siamo" className={styles.blogLink}>
                  Continua a leggere →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection} aria-label="Call to action finale">
        <div className="container">
          <div className={styles.ctaContent}>
            <div>
              <p className={styles.sectionLabel}>Pronti a partire?</p>
              <h2 className={styles.ctaTitle}>Costruiamo insieme il tuo prossimo capitolo professionale</h2>
              <p className={styles.ctaSubtitle}>
                Compila il form di candidatura: entro 48 ore un advisor ti contatterà per definire il percorso più adatto.
              </p>
            </div>
            <Link to="/contatti" className="btn-primary">
              Inizia Oggi
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;