import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Digital Master Academy</title>
      <meta
        name="description"
        content="Cookie Policy di Digital Master Academy: uso di cookie tecnici e strumenti di analisi nel rispetto del GDPR."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Ultimo aggiornamento: 1 Marzo 2024</p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <h2>Cosa sono i cookie</h2>
        <p>
          I cookie sono piccoli file di testo che il sito invia al dispositivo dell’utente, dove vengono memorizzati per
          essere poi ritrasmessi alla visita successiva. Consentono di ottimizzare navigazione, autenticazione e analisi dell’utilizzo.
        </p>

        <h2>Tipologie utilizzate</h2>
        <ul>
          <li>
            <strong>Cookie tecnici:</strong> necessari per il funzionamento della piattaforma (gestione sessioni, preferenze, sicurezza).
          </li>
          <li>
            <strong>Cookie di analisi:</strong> strumenti che raccolgono dati aggregati e anonimi sulle visite, utilizzati per migliorare i contenuti.
          </li>
        </ul>

        <h2>Gestione del consenso</h2>
        <p>
          Al primo accesso viene mostrato un banner che consente di accettare o rifiutare i cookie di analisi. Il consenso può essere modificato in qualsiasi momento cancellando i cookie dal browser.
        </p>

        <h2>Come disabilitare i cookie</h2>
        <p>
          È possibile impostare il browser per bloccare i cookie o richiedere conferma manuale. La disabilitazione dei cookie tecnici potrebbe limitare alcune funzionalità della piattaforma.
        </p>

        <h2>Contatti</h2>
        <p>
          Per chiarimenti sulla presente informativa è possibile scrivere a info@digitalmasteracademy.it.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;