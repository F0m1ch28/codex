import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Termini e condizioni | Digital Master Academy</title>
      <meta
        name="description"
        content="Termini e condizioni di utilizzo di Digital Master Academy. Informazioni su accesso, responsabilità e diritti."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Termini e condizioni</h1>
        <p>Ultimo aggiornamento: 1 Marzo 2024</p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <h2>1. Oggetto</h2>
        <p>
          I presenti termini disciplinano l’accesso alla piattaforma Digital Master Academy e l’utilizzo dei servizi
          formativi offerti. Utilizzando il sito o partecipando ai corsi, l’utente accetta integralmente le condizioni riportate.
        </p>

        <h2>2. Accesso alla piattaforma</h2>
        <p>
          L’accesso ai contenuti è consentito agli utenti registrati. Le credenziali sono personali e non possono essere condivise.
          L’utente è responsabile della corretta conservazione delle credenziali e dell’uso conforme ai termini.
        </p>

        <h2>3. Contenuti formativi</h2>
        <p>
          Tutti i materiali (video, slide, template, esercitazioni) sono protetti da copyright e destinati esclusivamente
          all’uso personale. È vietata qualsiasi riproduzione, distribuzione o modifica senza autorizzazione scritta.
        </p>

        <h2>4. Comportamento in piattaforma</h2>
        <p>
          È richiesto un comportamento rispettoso verso docenti, tutor e altri partecipanti. Digital Master Academy
          si riserva il diritto di sospendere l’accesso nei casi di uso improprio o violazioni delle regole di community.
        </p>

        <h2>5. Modifiche ai servizi</h2>
        <p>
          La direzione si riserva la facoltà di aggiornare i contenuti formativi, sostituire docenti e modificare il calendario
          per garantire la qualità dell’esperienza. Eventuali variazioni rilevanti saranno comunicate tempestivamente.
        </p>

        <h2>6. Limitazione di responsabilità</h2>
        <p>
          Pur mettendo in atto elevati standard qualitativi, Digital Master Academy non può garantire risultati specifici,
          poiché dipendono dall’impegno individuale e da fattori esterni. L’Academy non risponde di eventuali interruzioni
          del servizio dovute a cause di forza maggiore.
        </p>

        <h2>7. Legge applicabile</h2>
        <p>
          I presenti termini sono regolati dalla legge italiana. Per ogni controversia è competente il Foro di Milano.
        </p>
      </div>
    </section>
  </>
);

export default Terms;