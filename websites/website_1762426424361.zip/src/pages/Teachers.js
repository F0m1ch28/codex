import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Teachers.module.css';

const teachers = [
  {
    name: 'Elena Mariani',
    role: 'Head of Performance Marketing',
    bio: 'Ha guidato team media in agenzie globali e consulenze per brand fashion, fintech e travel. Specializzata in marketing automation e integrazione dati omnicanale.',
    image: 'https://picsum.photos/600/600?random=18'
  },
  {
    name: 'Davide Moretti',
    role: 'Lead Developer & Mentor',
    bio: 'Full-stack engineer, ha lavorato tra startup SaaS e aziende enterprise. Esperto di architetture cloud, React, Node.js e Python per automazioni data-driven.',
    image: 'https://picsum.photos/600/600?random=19'
  },
  {
    name: 'Lara Gentili',
    role: 'Social Media Strategist',
    bio: 'Coordina strategie digitali per brand lifestyle con focus su community design, contenuti video e collaborazione con creator.',
    image: 'https://picsum.photos/600/600?random=20'
  },
  {
    name: 'Riccardo Fabbri',
    role: 'Data & Analytics Advisor',
    bio: 'Data scientist con background in consulenza, aiuta team marketing e product a costruire dashboard, modelli predittivi e misurazioni avanzate.',
    image: 'httpsum.photos/600/600?random=21'
  },
  {
    name: 'Marta Belluzzo',
    role: 'Content Design Lead',
    bio: 'Ex giornalista digitale, progetta strategie editoriali e format per brand internazionali. Docente di storytelling e UX writing.',
    image: 'https://picsum.photos/600/600?random=22'
  },
  {
    name: 'Fabio Ricci',
    role: 'Growth Strategist',
    bio: 'Ha lavorato in scale-up italiane e internazionali. Supporta le aziende nello sviluppo di roadmap di crescita sostenibile e sperimentazione continua.',
    image: 'https://picsum.photos/600/600?random=23'
  }
];

const Teachers = () => (
  <>
    <Helmet>
      <title>Docenti | Digital Master Academy</title>
      <meta
        name="description"
        content="Conosci i docenti di Digital Master Academy: professionisti del digital marketing, coding e social media con esperienza sul campo."
      />
      <meta
        name="keywords"
        content="docenti digital marketing, mentor coding, formatori social media, esperti advertising, formazione digitale docenti"
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Docenti e mentor</h1>
        <p>
          Un team multidisciplinare che porta in aula competenze maturate lavorando su progetti di
          alto profilo. Ogni docente è affiancato da tutor e professionisti della community.
        </p>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <div className={styles.teamGrid}>
          {teachers.map((teacher) => (
            <article key={teacher.name} className={styles.teamCard}>
              <img src={teacher.image} alt={teacher.name} loading="lazy" />
              <div className={styles.teamBody}>
                <h3>{teacher.name}</h3>
                <p className={styles.role}>{teacher.role}</p>
                <p>{teacher.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Teachers;