import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Courses.module.css';

const Courses = () => (
  <>
    <Helmet>
      <title>Corsi | Digital Master Academy</title>
      <meta
        name="description"
        content="Scopri i corsi Digital Master Academy: Pubblicità Targetizzata, Coding e Social Media Marketing. Programmi intensivi con project work reali."
      />
      <meta
        name="keywords"
        content="corsi online Italia, Pubblicità Targetizzata, corso coding Milano, social media marketing, Facebook Ads, sviluppo web, Instagram marketing"
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Corsi</h1>
        <p>
          Tre percorsi specialistici, un’unica visione: costruire competenze digitali immediate
          da applicare in progetti concreti e nelle sfide quotidiane del tuo ruolo.
        </p>
      </div>
    </section>

    <section className={styles.courseSection}>
      <div className="container">
        <article className={styles.courseBlock}>
          <div className={styles.courseInfo}>
            <h2>Pubblicità Targetizzata</h2>
            <p>
              Impara a progettare strategie integrando Facebook Ads e Google Ads con focus su obiettivi,
              funnel e ottimizzazione continua. Lezioni pratiche, casi studio e simulazioni di budget management.
            </p>
            <ul>
              <li>Analisi del pubblico, segmentazione e customer journey digitale</li>
              <li>Set-up campagne: obiettivi, creatività, tracking avanzato</li>
              <li>Strategie di remarketing e marketing automation</li>
              <li>Dashboard personalizzate con Data Studio e fogli connessi</li>
              <li>Collaborazione con team creativi e stakeholder aziendali</li>
            </ul>
          </div>
          <div className={styles.courseMedia}>
            <img
              src="https://picsum.photos/800/600?random=15"
              alt="Dashboard con risultati di campagne pubblicitarie online"
              loading="lazy"
            />
          </div>
        </article>

        <article className={styles.courseBlock}>
          <div className={styles.courseInfo}>
            <h2>Coding</h2>
            <p>
              Un percorso che parte dalle basi di HTML e CSS e prosegue con JavaScript moderno e Python.
              Lavorerai su progetti end-to-end, versionamento Git e ambienti di deploy professionali.
            </p>
            <ul>
              <li>Foundation: semantica HTML, layout responsive, accessibilità</li>
              <li>CSS avanzato: Flexbox, Grid, preprocessori e componentizzazione</li>
              <li>JavaScript moderno: ES6+, asincronia, API REST e integrazioni</li>
              <li>Python essentials per automazioni e data handling</li>
              <li>Project work: applicazione single-page e microservizio backend</li>
            </ul>
          </div>
          <div className={styles.courseMedia}>
            <img
              src="https://picsum.photos/800/600?random=16"
              alt="Schermi con codice e sviluppatori in collaborazione"
              loading="lazy"
            />
          </div>
        </article>

        <article className={styles.courseBlock}>
          <div className={styles.courseInfo}>
            <h2>Social Media Marketing</h2>
            <p>
              Costruisci strategie orientate al coinvolgimento e alla crescita organica e paid.
              Dalla definizione dei format alla pianificazione editoriale, fino all’analisi delle performance.
            </p>
            <ul>
              <li>Audit canali, tone of voice e definizione dei pilastri narrativi</li>
              <li>Calendari editoriali dinamici per Instagram, TikTok e LinkedIn</li>
              <li>Content production: format video, live e storytelling cross-platform</li>
              <li>KPI, listening e strumenti di misurazione integrati</li>
              <li>Gestione community, escalation e collaborazione con creator</li>
            </ul>
          </div>
          <div className={styles.courseMedia}>
            <img
              src="https://picsum.photos/800/600?random=17"
              alt="Professionisti che analizzano contenuti social su un grande schermo"
              loading="lazy"
            />
          </div>
        </article>
      </div>
    </section>
  </>
);

export default Courses;