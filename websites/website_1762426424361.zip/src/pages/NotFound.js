import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './NotFound.module.css';

const NotFound = () => (
  <>
    <Helmet>
      <title>Pagina non trovata | Digital Master Academy</title>
      <meta
        name="description"
        content="La pagina richiesta non è disponibile. Torna alla home di Digital Master Academy."
      />
    </Helmet>
    <section className={styles.wrapper}>
      <div className="container">
        <div className={styles.content}>
          <h1>404</h1>
          <p>La pagina che stai cercando non è disponibile.</p>
          <Link to="/" className="btn-primary">
            Torna alla home
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default NotFound;