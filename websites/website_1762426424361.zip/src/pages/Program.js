import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Program.module.css';

const Program = () => (
  <>
    <Helmet>
      <title>Programma | Digital Master Academy</title>
      <meta
        name="description"
        content="Programma dei corsi Digital Master Academy: moduli, durata, project work e certificazioni per formazione digitale completa."
      />
      <meta
        name="keywords"
        content="programma corsi digitali, moduli formazione digitale, project work marketing, certificazioni digitali, corsi coding Italia"
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Programma dei corsi</h1>
        <p>
          Ogni traccia è organizzata in moduli settimanali, con un equilibrio tra sessioni sincrone,
          materiali on demand, mentorship e laboratori pratici. Di seguito una panoramica dei contenuti.
        </p>
      </div>
    </section>

    <section className={styles.structureSection}>
      <div className="container">
        <div className={styles.structureGrid}>
          <article className={styles.structureCard}>
            <h2>Struttura generale</h2>
            <ul>
              <li>Durata: 16-20 settimane in base al percorso scelto</li>
              <li>Lezioni live: 2 sere a settimana (90 minuti)</li>
              <li>Laboratori guidati: sabato mattina, casi reali con mentor</li>
              <li>Studio autonomo: risorse video, template e workbook</li>
              <li>Mentorship: 1 sessione individuale al mese</li>
            </ul>
          </article>
          <article className={styles.structureCard}>
            <h2>Project work</h2>
            <p>
              Ogni corso culmina con un project work commissionato da un partner. Gli studenti lavorano in team
              multidisciplinari e presentano i risultati di fronte a stakeholder reali ricevendo feedback puntuale.
            </p>
            <ul>
              <li>Project charter e definizione obiettivi</li>
              <li>Check settimanali con il mentor dedicato</li>
              <li>Revisione intermedia con stakeholder</li>
              <li>Demo day finale con valutazione qualitativa e quantitativa</li>
            </ul>
          </article>
          <article className={styles.structureCard}>
            <h2>Certificazioni e portfolio</h2>
            <p>
              Al termine del percorso riceverai un attestato certificato da Digital Master Academy
              e un dossier con i deliverable prodotti. Supportiamo la costruzione del portfolio con feedback personalizzati.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.moduleSection}>
      <div className="container">
        <h2>Moduli principali</h2>
        <div className={styles.moduleGrid}>
          <article className={styles.moduleCard}>
            <h3>Fundamentals</h3>
            <p>
              Concetti chiave, strumenti essenziali e contestualizzazione del percorso. Assessment iniziale
              con mappatura delle competenze e obiettivi individuali.
            </p>
          </article>
          <article className={styles.moduleCard}>
            <h3>Strumenti e piattaforme</h3>
            <p>
              Setup ambienti di lavoro, tool professionali, integrazioni tra piattaforme e best practice di collaborazione.
            </p>
          </article>
          <article className={styles.moduleCard}>
            <h3>Laboratori pratici</h3>
            <p>
              Esercitazioni hands-on con esercizi progressivi, analisi di casi reali e feedback immediati dei docenti.
            </p>
          </article>
          <article className={styles.moduleCard}>
            <h3>Soft skills digitali</h3>
            <p>
              Public speaking, gestione dei team remoti, pianificazione agile e stakeholder management per progetti digitali.
            </p>
          </article>
          <article className={styles.moduleCard}>
            <h3>Career coaching</h3>
            <p>
              Revisione CV e profilo LinkedIn, preparazione a colloqui tecnici, valorizzazione del portfolio e personal branding.
            </p>
          </article>
          <article className={styles.moduleCard}>
            <h3>Demo day</h3>
            <p>
              Presentazione finale dei progetti alla community e ai partner, con feedback e networking mirato.
            </p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default Program;