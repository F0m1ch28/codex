import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy | Digital Master Academy</title>
      <meta
        name="description"
        content="Informativa privacy di Digital Master Academy: trattamento dati personali in conformità al GDPR."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Informativa Privacy</h1>
        <p>Ultimo aggiornamento: 1 Marzo 2024</p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <h2>Titolare del trattamento</h2>
        <p>
          Digital Master Academy, con sede in Via Roma, 100, 28821 Cannero Riviera VB, è titolare del trattamento dei dati
          personali raccolti attraverso il sito e la piattaforma formativa.
        </p>

        <h2>Dati trattati</h2>
        <p>
          I dati raccolti includono identificativi (nome, cognome), recapiti (email, telefono), informazioni professionali
          e dati relativi alla fruizione dei servizi didattici. I dati di navigazione vengono trattati attraverso cookie tecnici
          e strumenti analitici per finalità statistiche aggregate.
        </p>

        <h2>Finalità e base giuridica</h2>
        <ul>
          <li>Gestione delle richieste di informazioni e iscrizioni (esecuzione di misure precontrattuali).</li>
          <li>Erogazione dei corsi e supporto didattico (esecuzione contrattuale).</li>
          <li>Comunicazioni su aggiornamenti dei servizi (legittimo interesse).</li>
          <li>Adempimento di obblighi legali e fiscali.</li>
        </ul>

        <h2>Modalità di trattamento</h2>
        <p>
          I dati sono trattati tramite strumenti elettronici e modalità organizzative funzionali alle finalità indicate.
          Adottiamo misure di sicurezza adeguate per proteggere le informazioni da accessi non autorizzati.
        </p>

        <h2>Conservazione</h2>
        <p>
          I dati relativi ai corsi sono conservati per la durata del rapporto formativo e successivamente per gli obblighi di legge.
          I dati di contatto raccolti per finalità informative sono conservati per 24 mesi salvo revoca del consenso.
        </p>

        <h2>Diritti dell’interessato</h2>
        <p>
          Gli interessati possono esercitare i diritti previsti dagli articoli 15-22 del GDPR (accesso, rettifica, cancellazione,
          limitazione, opposizione, portabilità) scrivendo a info@digitalmasteracademy.it. È sempre possibile proporre reclamo al Garante Privacy.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;