import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu}>
            <span aria-hidden="true">🎓</span>
            <span className={styles.logoText}>Digital Master Academy</span>
          </NavLink>
          <button
            className={styles.menuButton}
            aria-label="Apri navigazione"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((prev) => !prev)}
          >
            <span className={styles.menuLine} />
            <span className={styles.menuLine} />
            <span className={styles.menuLine} />
          </button>
          <nav
            className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
            aria-label="Navigazione principale"
          >
            <ul className={styles.navList}>
              <li>
                <NavLink
                  to="/"
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  Home
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/chi-siamo"
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  Chi siamo
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/corsi"
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  Corsi
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/programma"
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  Programma
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/docenti"
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  Docenti
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/contatti"
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  Contatti
                </NavLink>
              </li>
            </ul>
            <NavLink
              to="/contatti"
              className={styles.ctaLink}
              onClick={closeMenu}
            >
              Inizia Oggi
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;