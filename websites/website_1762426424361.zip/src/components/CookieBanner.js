import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('dma-cookie-consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('dma-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  const handleReject = () => {
    window.localStorage.setItem('dma-cookie-consent', 'rejected');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite" aria-label="Informativa sui cookie">
      <div className={styles.content}>
        <p className={styles.text}>
          Utilizziamo cookie tecnici e strumenti di analisi per offrire un&rsquo;esperienza coerente. Per maggiori informazioni consulta la nostra{' '}
          <Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link>.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.secondary} onClick={handleReject}>
            Rifiuta
          </button>
          <button type="button" className={styles.primary} onClick={handleAccept}>
            Accetta
          </button>
        </div>
      </div>
    </aside>
  );
};

export default CookieBanner;