import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div>
          <h3 className={styles.heading}>Digital Master Academy</h3>
          <p className={styles.text}>
            Formazione digitale avanzata per professionisti che vogliono progettare il futuro del marketing, dello sviluppo e dei media.
          </p>
          <div className={styles.contact}>
            <p>Via Roma, 100, 28821 Cannero Riviera VB</p>
            <p><a href="tel:+390212346751" className={styles.link}>+39 02 1234 6751</a></p>
            <p><a href="mailto:info@digitalmasteracademy.it" className={styles.link}>info@digitalmasteracademy.it</a></p>
          </div>
        </div>
        <div>
          <h4 className={styles.subHeading}>Esplora</h4>
          <ul className={styles.list}>
            <li><Link to="/" className={styles.link}>Home</Link></li>
            <li><Link to="/chi-siamo" className={styles.link}>Chi siamo</Link></li>
            <li><Link to="/corsi" className={styles.link}>Corsi</Link></li>
            <li><Link to="/programma" className={styles.link}>Programma</Link></li>
            <li><Link to="/docenti" className={styles.link}>Docenti</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.subHeading}>Supporto</h4>
          <ul className={styles.list}>
            <li><Link to="/contatti" className={styles.link}>Contatti</Link></li>
            <li><Link to="/termini" className={styles.link}>Termini e condizioni</Link></li>
            <li><Link to="/privacy" className={styles.link}>Privacy</Link></li>
            <li><Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.subHeading}>Newsletter</h4>
          <p className={styles.text}>Storie, case study e insight dal mondo della formazione digitale.</p>
          <form className={styles.form} aria-label="Iscrizione newsletter">
            <label htmlFor="newsletter-email" className="visually-hidden">
              Inserisci la tua email
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="newsletter-email"
              placeholder="La tua email"
              className={styles.input}
              required
            />
            <button type="submit" className={styles.button}>Iscriviti</button>
          </form>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p className={styles.copy}>© {new Date().getFullYear()} Digital Master Academy. Tutti i diritti riservati.</p>
      </div>
    </div>
  </footer>
);

export default Footer;