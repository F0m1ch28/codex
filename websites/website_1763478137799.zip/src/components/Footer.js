import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <div className={styles.logo}>
            <span className={styles.logoMark}>S</span>
            <span className={styles.logoText}>Silaventino</span>
          </div>
          <p>
            Wir begleiten Dich auf dem Weg zu klarer, respektvoller Kommunikation. Alltagstauglich,
            empathisch und immer auf Augenhöhe.
          </p>
          <div className={styles.socials} aria-label="Social Media">
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              LinkedIn
            </a>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
            >
              Instagram
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
            >
              YouTube
            </a>
          </div>
        </div>

        <div className={styles.column}>
          <h3>Kennlern</h3>
          <ul className={styles.linkList}>
            <li>
              <Link to="/guide">Leitfaden</Link>
            </li>
            <li>
              <Link to="/programs">Programme</Link>
            </li>
            <li>
              <Link to="/tools">Tools &amp; Checklisten</Link>
            </li>
            <li>
              <Link to="/blog">Blog &amp; Insights</Link>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3>Unternehmen</h3>
          <ul className={styles.linkList}>
            <li>
              <Link to="/about">Über Silaventino</Link>
            </li>
            <li>
              <Link to="/services">Leistungen</Link>
            </li>
            <li>
              <Link to="/contact">Kontakt</Link>
            </li>
            <li>
              <Link to="/guide">Nächsten Schritt</Link>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3>Rechtliches</h3>
          <ul className={styles.linkList}>
            <li>
              <Link to="/legal">AGB</Link>
            </li>
            <li>
              <Link to="/privacy">Datenschutz</Link>
            </li>
            <li>
              <Link to="/imprint">Impressum</Link>
            </li>
          </ul>
          <div className={styles.contactInfo}>
            <p>Silaventino.site</p>
            <p>Kommunikationsatelier</p>
            <p>Mustergasse 12</p>
            <p>10115 Berlin</p>
          </div>
        </div>
      </div>

      <div className={styles.bottomBar}>
        <div className="container">
          <p>&copy; {new Date().getFullYear()} Silaventino. Gemeinsam für bessere Gespräche.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

Need to ensure `Footer.module.css`. We'll create.