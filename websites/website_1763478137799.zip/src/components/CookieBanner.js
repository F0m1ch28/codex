import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'silaventino-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem(COOKIE_STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie-Hinweis">
      <div className={styles.text}>
        <strong>Cookies für bessere Erlebnisse</strong>
        <p>
          Wir verwenden technisch notwendige Cookies, um Dir ein stabiles Nutzungserlebnis zu
          ermöglichen. Weitere Analysen oder Tracking findet nicht statt.
        </p>
      </div>
      <div className={styles.actions}>
        <button
          type="button"
          className={`btn btnSecondary ${styles.button}`}
          onClick={() => handleConsent('declined')}
        >
          Ablehnen
        </button>
        <button
          type="button"
          className={`btn btnPrimary ${styles.button}`}
          onClick={() => handleConsent('accepted')}
        >
          Akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;