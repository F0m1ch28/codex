import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Start' },
  { path: '/guide', label: 'Leitfaden' },
  { path: '/programs', label: 'Programme' },
  { path: '/tools', label: 'Tools' },
  { path: '/services', label: 'Angebote' },
  { path: '/blog', label: 'Blog' },
  { path: '/about', label: 'Über uns' },
  { path: '/contact', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
    document.body.classList.remove('no-scroll');
  }, [location.pathname]);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [menuOpen]);

  return (
    <header className={styles.header} role="banner">
      <div className={`container ${styles.container}`}>
        <Link to="/" className={styles.logo} aria-label="Silaventino Startseite">
          <span className={styles.logoMark}>S</span>
          <span className={styles.logoText}>Silaventino</span>
        </Link>
        <nav className={styles.desktopNav} aria-label="Hauptnavigation">
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.path} className={styles.navItem}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.activeLink : ''}`
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <Link to="/contact" className={`btn btnPrimary ${styles.ctaButton}`}>
          Gespräch anfragen
        </Link>

        <button
          className={styles.menuButton}
          aria-label="Mobile Navigation öffnen"
          aria-expanded={menuOpen}
          aria-controls="hauptmenue"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
        </button>

        <nav
          id="hauptmenue"
          className={`${styles.mobileNav} ${menuOpen ? styles.mobileNavOpen : ''}`}
          aria-label="Mobile Navigation"
        >
          <ul className={styles.mobileNavList}>
            {navLinks.map((link) => (
              <li key={link.path} className={styles.mobileNavItem}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    `${styles.mobileNavLink} ${isActive ? styles.mobileNavLinkActive : ''}`
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
            <li className={styles.mobileNavItem}>
              <Link to="/contact" className={`btn btnPrimary ${styles.mobileCta}`}>
                Nachricht senden
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;