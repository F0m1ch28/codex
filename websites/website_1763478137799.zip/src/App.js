import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import Guide from './pages/Guide';
import Programs from './pages/Programs';
import Tools from './pages/Tools';
import Services from './pages/Services';
import Blog from './pages/Blog';
import BlogDetail from './pages/BlogDetail';
import About from './pages/About';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Imprint from './pages/Imprint';

function App() {
  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Silaventino – Besser reden. Konflikte fair lösen.</title>
        <meta
          name="description"
          content="Silaventino unterstützt Dich mit Programmen, Tools und Wissen rund um klare, respektvolle Kommunikation und faire Konfliktlösung."
        />
      </Helmet>
      <Header />
      <ScrollToTop />
      <main className="mainContent" id="hauptinhalt">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/guide" element={<Guide />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/tools" element={<Tools />} />
          <Route path="/services" element={<Services />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogDetail />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/legal" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/imprint" element={<Imprint />} />
          <Route
            path="*"
            element={
              <div className="fallback">
                <h1>Seite nicht gefunden</h1>
                <p>Diese Adresse führt leider ins Leere. Bitte nutze die Navigation, um weiterzukommen.</p>
              </div>
            }
          />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </>
  );
}

export default App;