import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte gib Deinen Namen ein.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) newErrors.message = 'Bitte formuliere Deine Nachricht.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Silaventino</title>
        <meta
          name="description"
          content="Nimm Kontakt zu Silaventino auf: Gemeinsam entwickeln wir ein Format für klare, respektvolle Kommunikation."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.hero}`}>
        <div className="container">
          <p className="badge">Kontakt</p>
          <h1>Sprich mit uns über Deinen nächsten Schritt</h1>
          <p className={styles.subtitle}>
            Hinterlass uns ein paar Zeilen zu Deinem Anliegen. Wir melden uns innerhalb von zwei
            Werktagen.
          </p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.content}`}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, name: event.target.value }))
                  }
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  placeholder="Vor- und Nachname"
                  required
                />
                {errors.name && (
                  <span id="name-error" className={styles.error} role="alert">
                    {errors.name}
                  </span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">E-Mail *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, email: event.target.value }))
                  }
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  placeholder="deine@mail.de"
                  required
                />
                {errors.email && (
                  <span id="email-error" className={styles.error} role="alert">
                    {errors.email}
                  </span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Nachricht *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, message: event.target.value }))
                  }
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  placeholder="Worum geht es Dir? Wie können wir unterstützen?"
                  required
                />
                {errors.message && (
                  <span id="message-error" className={styles.error} role="alert">
                    {errors.message}
                  </span>
                )}
              </div>

              <button type="submit" className="btn btnPrimary">
                Nachricht senden
              </button>

              <p className={styles.hint}>
                Mit dem Absenden stimmst Du zu, dass wir Deine Angaben zur Kontaktaufnahme nutzen.
                Einzelheiten findest Du in der{' '}
                <a href="/privacy" className={styles.hintLink}>
                  Datenschutzerklärung
                </a>
                .
              </p>

              {submitted && (
                <div className={styles.success} role="status" aria-live="polite">
                  Danke für Deine Nachricht! Wir melden uns zeitnah bei Dir.
                </div>
              )}
            </form>

            <aside className={styles.info}>
              <h2>So erreichst Du uns</h2>
              <p>
                Silaventino.site <br />
                Kommunikationsatelier
              </p>
              <p>
                Mustergasse 12 <br />
                10115 Berlin
              </p>
              <p>
                E-Mail: <a href="mailto:hallo@silaventino.site">hallo@silaventino.site</a>
              </p>
              <p>Telefon (optional): +49 30 123 456 78</p>
              <div className={styles.infoCard}>
                <h3>Wann wir passen</h3>
                <ul>
                  <li>Du willst Konflikte konstruktiv angehen</li>
                  <li>Ihr sucht nachhaltige Kommunikations-Rituale</li>
                  <li>Ihr möchtet einen neutralen Raum für Gespräche</li>
                </ul>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;

CSS.