import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const values = [
  {
    title: 'Empathie & Haltung',
    description:
      'Wir begegnen jedem Menschen respektvoll. Empathie bedeutet für uns, Bedürfnisse zu erkennen und Verantwortung zu teilen.'
  },
  {
    title: 'Alltagstauglichkeit',
    description:
      'Unsere Tools funktionieren zwischen Tür und Angel genauso wie im Workshop. Kurze Inputs, große Wirkung.'
  },
  {
    title: 'Seriosität & Datenschutz',
    description:
      'Wir arbeiten DSGVO-konform, speichern nur, was nötig ist, und kommunizieren transparent. Vertrauen ist die Basis.'
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>Über Silaventino | Mission &amp; Team</title>
        <meta
          name="description"
          content="Silaventino unterstützt Menschen in Deutschland mit Haltung, Struktur und Empathie auf dem Weg zu klarer, respektvoller Kommunikation."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.hero}`}>
        <div className="container">
          <p className="badge">Über uns</p>
          <h1>Wir glauben an Gespräche, die verbinden</h1>
          <p className={styles.subtitle}>
            Silaventino ist eine Plattform für Menschen, die Konflikte fair lösen wollen. Wir
            kombinieren Mediations-Know-how, Kommunikationsdidaktik und digitale Tools – ohne
            psychotherapeutische oder rechtliche Beratung zu ersetzen.
          </p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.values}`}>
        <div className="container">
          <div className={styles.grid}>
            {values.map((value) => (
              <article key={value.title} className={`${styles.card} card`}>
                <h2>{value.title}</h2>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.story}`}>
        <div className="container">
          <div className={styles.storyContent}>
            <div className={styles.storyImage}>
              <img
                src="https://picsum.photos/900/700?random=52"
                alt="Silaventino Team bei der Arbeit"
                loading="lazy"
              />
            </div>
            <div className={styles.storyText}>
              <h2>Unsere Geschichte</h2>
              <p>
                Silaventino entstand aus der Erfahrung, dass Konflikte meist daran scheitern, dass
                sie zu spät angesprochen oder zu schnell bewertet werden. Wir wollten einen Raum
                schaffen, in dem Menschen üben können, sich in Ruhe auszutauschen – ohne Druck, ohne
                Schubladen.
              </p>
              <p>
                Seit 2019 begleiten wir Teams, Paare, Familien und Communities deutschlandweit. Wir
                verbinden analoge und digitale Formate, damit Lernen genau dort passiert, wo Du es
                brauchst.
              </p>
              <ul>
                <li>Co-kreativ: Wir entwickeln Formate mit unseren Nutzer:innen</li>
                <li>Transparent: Wir erklären, warum wir welches Tool einsetzen</li>
                <li>Mutig: Wir sprechen aus, was oft unausgesprochen bleibt</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;

Need CSS.