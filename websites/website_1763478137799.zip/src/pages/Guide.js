import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const steps = [
  {
    title: 'Eigene Muster erkennen',
    points: [
      'Trigger-Momente festhalten und Gefühle benennen',
      'Gedanken- und Handlungsschleifen sichtbar machen',
      'Reflexionsjournal: 5-Minuten-Abends-Routine'
    ]
  },
  {
    title: 'Aktiv zuhören',
    points: [
      'Zwischenräume aushalten – nicht sofort reagieren',
      'Spiegeln, was Du gehört hast, bevor Du antwortest',
      'Nachfragen: „Habe ich Dich richtig verstanden, dass…?“'
    ]
  },
  {
    title: 'Ich-Botschaften nutzen',
    points: [
      'Vier Schritte: Situation, Wirkung, Bedürfnis, Bitte',
      'Keine Vorwürfe, sondern Verantwortung für die eigenen Gefühle',
      'Üben mit dem Ich-Botschaften-Coach von Silaventino'
    ]
  },
  {
    title: 'Grenzen klar formulieren',
    points: [
      'Grenze + Grund + Alternativangebot',
      'Körperhaltung und Stimme bewusst einsetzen',
      'Rituale für respektvolle Unterbrechungen entwickeln'
    ]
  },
  {
    title: 'Gemeinsame Lösungen finden',
    points: [
      'Ziele definieren, bevor Ihr Lösungen erarbeitet',
      'Optionen sammeln, bewerten, entscheiden – transparent',
      'Nächste Schritte festhalten und checken'
    ]
  }
];

const Guide = () => {
  return (
    <>
      <Helmet>
        <title>Kommunikations-Leitfaden | Silaventino</title>
        <meta
          name="description"
          content="Der Silaventino-Leitfaden führt Dich in fünf Schritten zu klarer, fairer Kommunikation – mit konkreten Übungen für Deinen Alltag."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.hero}`}>
        <div className="container">
          <p className="badge">Leitfaden</p>
          <h1>Dein roter Faden für konstruktive Gespräche</h1>
          <p className={styles.subtitle}>
            Geh jeden Schritt bewusst. Mit dem Leitfaden behältst Du in Konflikten den Überblick und
            findest zurück in einen Dialog auf Augenhöhe.
          </p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.steps}`} aria-labelledby="leitfaden-schritte">
        <div className="container">
          <h2 id="leitfaden-schritte" className="sectionTitle">
            Fünf Schritte, die Dich weiterbringen
          </h2>
          <p className="sectionSubtitle">
            Jeder Schritt enthält Reflexionsfragen, Übungen und Tools, die Du im Alltag anwenden
            kannst. Starte da, wo Du gerade stehst.
          </p>
          <div className={styles.grid}>
            {steps.map((step, index) => (
              <article key={step.title} className={`${styles.card} card`}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <ul>
                  {step.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <div className={styles.cta}>
            <Link to="/programs" className="btn btnPrimary">
              Nächsten Schritt ansehen
            </Link>
            <Link to="/tools" className="btn btnSecondary">
              Tools herunterladen
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Guide;

Need CSS.