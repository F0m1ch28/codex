import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './BlogDetail.module.css';
import blogPosts from '../data/blogPosts';

const BlogDetail = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className="sectionSpacing">
        <div className="container">
          <h1>Beitrag nicht gefunden</h1>
          <p>Dieser Beitrag existiert nicht. Schau Dir gern unsere anderen Artikel an.</p>
          <Link to="/blog" className="btn btnPrimary">
            Zur Blog-Übersicht
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Silaventino Blog</title>
        <meta name="description" content={post.metaDescription} />
      </Helmet>
      <article className={`sectionSpacing ${styles.article}`} itemScope itemType="https://schema.org/BlogPosting">
        <div className="container">
          <header className={styles.header}>
            <span className="badge" itemProp="articleSection">
              {post.category}
            </span>
            <h1 itemProp="headline">{post.title}</h1>
            <div className={styles.meta}>
              <span itemProp="author">{post.author}</span>
              <span aria-hidden="true">•</span>
              <time dateTime={post.published} itemProp="datePublished">
                {new Date(post.published).toLocaleDateString('de-DE', {
                  day: '2-digit',
                  month: 'long',
                  year: 'numeric'
                })}
              </time>
              <span aria-hidden="true">•</span>
              <span>{post.readTime}</span>
            </div>
            <div className={styles.cover}>
              <img src={post.coverImage} alt={post.title} loading="lazy" itemProp="image" />
            </div>
          </header>

          <section className={styles.content} itemProp="articleBody">
            {post.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
            <div className={styles.takeaways}>
              <h2>Das nimmst Du mit</h2>
              <ul>
                {post.takeaways.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </section>

          <footer className={styles.footer}>
            <Link to="/blog" className="btn btnSecondary">
              Zurück zum Blog
            </Link>
            <Link to="/contact" className="btn btnPrimary">
              Gespräch vereinbaren
            </Link>
          </footer>
        </div>
      </article>
    </>
  );
};

export default BlogDetail;

Need CSS detail.