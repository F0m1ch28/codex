import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import blogPosts from '../data/blogPosts';

const statsContent = [
  { label: 'Trainings-Teilnehmende', value: 3200, suffix: '+' },
  { label: 'Moderierte Dialoge', value: 480, suffix: '' },
  { label: 'Zufriedenheitsquote', value: 94, suffix: '%' }
];

const benefitItems = [
  {
    title: 'Weniger Streit',
    description: 'Du erkennst Muster schneller und kannst Konflikte früh stoppen.'
  },
  {
    title: 'Mehr Verständnis',
    description: 'Aktives Zuhören schafft Verbundenheit – auch in hitzigen Phasen.'
  },
  {
    title: 'Klarere Gespräche',
    description: 'Strukturierte Werkzeuge geben Dir Sicherheit und Fokus.'
  },
  {
    title: 'Souverän auftreten',
    description: 'Mit Ich-Botschaften und klaren Grenzen bleibst Du authentisch.'
  }
];

const topicTiles = [
  {
    title: 'Gespräche im Alltag',
    description: 'Von Nachbarn bis Freundeskreis – souverän bleiben, ohne hart zu wirken.'
  },
  {
    title: 'Familie & Partnerschaft',
    description: 'Emotionen verstehen, Nähe halten und trotzdem deutlich bleiben.'
  },
  {
    title: 'Job & Team',
    description: 'Konflikte sichtbar machen, Verantwortung teilen, Ergebnisse sichern.'
  },
  {
    title: 'Schwierige Situationen',
    description: 'Gut vorbereitet in Kritikgespräche, Feedbackrunden und Grenzen.'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Eigene Muster erkennen',
    text: 'Du holst Deine Trigger ins Bewusstsein und entwickelst neue Handlungsspielräume.'
  },
  {
    step: '02',
    title: 'Aktiv zuhören',
    text: 'Signale richtig deuten, Zwischenräume aushalten und gezielt nachfragen.'
  },
  {
    step: '03',
    title: 'Ich-Botschaften nutzen',
    text: 'Klar sagen, was Du brauchst – ohne Vorwurf, ohne Drama, mit Verantwortung.'
  },
  {
    step: '04',
    title: 'Grenzen respektvoll setzen',
    text: 'Rituale und Formulierungen, die Deine Position stärken und fair bleiben.'
  },
  {
    step: '05',
    title: 'Gemeinsame Lösungen finden',
    text: 'Strukturierte Dialoge, die Entscheidungen erleichtern und nachhalten.'
  }
];

const testimonialsData = [
  {
    quote:
      '„Wir haben mit Silaventino einen ganz neuen Ton in unserem Team etabliert. Konflikte sind kein Tabu mehr, sondern echte Chancen – das merkt man an der Stimmung und an den Ergebnissen.“',
    name: 'Miriam Krauß',
    role: 'Teamlead Customer Success, SaaS Scale-up'
  },
  {
    quote:
      '„Die 7-Tage-Challenge hat mir geholfen, eigene Muster zu durchbrechen. Ich spreche Grenzen klarer an und fühle mich dabei endlich sicher.“',
    name: 'Lukas Feld',
    role: 'Kommunikationstrainer in Ausbildung'
  },
  {
    quote:
      '„Was die Programme auszeichnet? Alltagstaugliche Übungen, klare Sprache und ganz viel Wertschätzung. So macht Lernen Sinn.“',
    name: 'Andrea Bosch',
    role: 'Mediatorin & HR-Partnerin'
  }
];

const projectsData = [
  {
    title: 'Team-Retreat „Respektvoll streiten“',
    category: 'Unternehmen',
    description:
      'Zweitägiger Workshop mit einem hybriden Team. Fokus: Konfliktkompetenzen und Feedbackgespräche.',
    image: 'https://picsum.photos/1200/800?random=31'
  },
  {
    title: 'Programm „7 Tage respektvoll reden“',
    category: 'Privatpersonen',
    description:
      'Geführte Lernreise mit Reflexionsimpulsen, Sprachnotizen und Live-Check-ins für nachhaltige Veränderung.',
    image: 'https://picsum.photos/1200/800?random=32'
  },
  {
    title: 'Moderation: Familienrat',
    category: 'Familie',
    description:
      'Begleitete Konfliktmoderation zwischen Eltern und erwachsenen Kindern – mit Zielbild, Regeln und Follow-up.',
    image: 'https://picsum.photos/1200/800?random=33'
  },
  {
    title: 'Kommunikationsstrategie für Pflegeeinrichtung',
    category: 'Unternehmen',
    description:
      'Schaffung verbindlicher Leitlinien für Feedback, Schichtübergaben und schwierige Gespräche.',
    image: 'https://picsum.photos/1200/800?random=34'
  }
];

const faqItems = [
  {
    question: 'Wie schnell sehe ich Fortschritte?',
    answer:
      'Viele Nutzer:innen berichten bereits nach wenigen Tagen von ersten Veränderungen – weil sie sich bewusster ausdrücken. Nachhaltig wird es, wenn Du regelmäßig reflektierst und dranbleibst.'
  },
  {
    question: 'Brauche ich Vorkenntnisse in Kommunikation?',
    answer:
      'Nein. Unsere Inhalte sind leicht verständlich und bauen auf Deiner Alltagserfahrung auf. Du bekommst Beispiele, Übungen und Reflexionsfragen, die Dich Schritt für Schritt begleiten.'
  },
  {
    question: 'Sind die Angebote psychotherapeutisch?',
    answer:
      'Nein. Silaventino richtet sich an Menschen, die ihre Kommunikation stärken möchten. Wir bieten keine psychotherapeutische oder rechtliche Beratung an und verweisen bei Bedarf an passende Stellen.'
  },
  {
    question: 'Kann ich Silaventino im Team nutzen?',
    answer:
      'Ja. Viele unserer Programme sind für Teams und Organisationen konzipiert. Wir passen Inhalte auf Anfrage an Eure Zielgruppe und Euer Format an.'
  }
];

const teamMembersData = [
  {
    name: 'Clara Niering',
    role: 'Gründerin & Kommunikationstrainerin',
    description:
      'Mediatorin, Coach und Facilitatorin. Spezialisiert auf Konfliktmoderation und wertschätzende Gesprächsführung.',
    image: 'https://picsum.photos/400/400?random=41',
    focus: 'Narrative Konfliktlösung & Sprache in emotionalen Situationen.'
  },
  {
    name: 'Jakob Riedel',
    role: 'Konfliktmoderator & Organisationsentwickler',
    description:
      'Begleitet Teams bei Kulturveränderung und Feedbackprozessen. Entwickelt nachhaltige Tools für den Alltag.',
    image: 'https://picsum.photos/400/400?random=42',
    focus: 'Teamkommunikation, Workshop-Design und Entscheidungsprozesse.'
  },
  {
    name: 'Noura Said',
    role: 'Learning Designerin',
    description:
      'Gestaltet Lernreisen, digitale Challenges und interaktive Tools – mit Blick auf Barrierefreiheit und Vielfalt.',
    image: 'https://picsum.photos/400/400?random=43',
    focus: 'User Experience, barrierefreie Lernformate und Community Building.'
  }
];

const Home = () => {
  const [statValues, setStatValues] = useState(statsContent.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeProjectFilter, setActiveProjectFilter] = useState('Alle');
  const [expandedFaq, setExpandedFaq] = useState(0);

  const latestPosts = useMemo(() => blogPosts.slice(0, 3), []);

  useEffect(() => {
    const duration = 1500;
    const frameRate = 40;
    const totalFrames = Math.round(duration / frameRate);
    let frame = 0;

    const interval = setInterval(() => {
      frame += 1;
      const progress = frame / totalFrames;
      setStatValues(
        statsContent.map((stat) => Math.round(stat.value * Math.min(progress, 1)))
      );
      if (frame === totalFrames) {
        clearInterval(interval);
      }
    }, frameRate);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6500);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeProjectFilter === 'Alle'
      ? projectsData
      : projectsData.filter((project) => project.category === activeProjectFilter);

  return (
    <>
      <Helmet>
        <title>Silaventino – Besser reden. Konflikte fair lösen.</title>
        <meta
          name="description"
          content="Stärke Deine Kommunikation mit Silaventino – Programmen, Tools und Workshops für faire Konflikte, klare Gespräche und souveränes Auftreten."
        />
      </Helmet>
      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <span className="badge fadeUp" style={{ animationDelay: '0.1s' }}>
              Für klarere Gespräche in Deutschland
            </span>
            <h1 id="hero-heading" className={`fadeUp ${styles.heroTitle}`} style={{ animationDelay: '0.2s' }}>
              Besser reden. Konflikte fair lösen.
            </h1>
            <p className="fadeUp" style={{ animationDelay: '0.3s' }}>
              Silaventino begleitet Dich mit klaren Methoden, Live-Impulsen und alltagstauglichen
              Ritualen. Damit Gespräche gelingen – im Job, in der Familie und überall dort, wo es
              Dir wichtig ist.
            </p>
            <div className={`${styles.heroActions} fadeUp`} style={{ animationDelay: '0.4s' }}>
              <Link to="/programs" className="btn btnPrimary">
                Jetzt starten
              </Link>
              <Link to="/guide" className="btn btnSecondary">
                Kommunikation stärken
              </Link>
            </div>
            <div className={`${styles.heroHighlights} fadeUp`} style={{ animationDelay: '0.5s' }}>
              <div>
                <strong>Live begleitet</strong>
                <span>Impulse, Check-ins & Feedback</span>
              </div>
              <div>
                <strong>Praxisnah</strong>
                <span>Übungen für Deinen Alltag</span>
              </div>
            </div>
          </div>
          <div className={styles.heroVisual} role="presentation" aria-hidden="true">
            <img
              src="https://picsum.photos/600/600?random=1"
              alt="Personen in einem konstruktiven Gespräch"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`${styles.stats} sectionSpacing`} aria-label="Ergebnisse auf einen Blick">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsContent.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {statValues[index]}
                  {stat.suffix}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="sectionSpacing" aria-labelledby="benefits-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="benefits-heading" className="sectionTitle">
              Warum gute Kommunikation Konflikte entschärft
            </h2>
            <p className="sectionSubtitle">
              Wenn wir zuhören, klar sprechen und Verantwortung übernehmen, bleiben Beziehungen auch
              bei Meinungsverschiedenheiten stabil. Silaventino macht Dich dabei sicher.
            </p>
          </div>
          <div className={styles.benefitGrid}>
            {benefitItems.map((benefit) => (
              <article key={benefit.title} className={`${styles.benefitCard} card`}>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.topics} sectionSpacing`} aria-labelledby="topics-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="topics-heading" className="sectionTitle">
              Themen, die Dich weiterbringen
            </h2>
            <p className="sectionSubtitle">
              Du bekommst fein aufeinander abgestimmte Inputs für unterschiedliche Lebensbereiche –
              flexibel, interaktiv und immer praxisorientiert.
            </p>
          </div>
          <div className={styles.topicGrid}>
            {topicTiles.map((topic) => (
              <div key={topic.title} className={styles.topicCard}>
                <h3>{topic.title}</h3>
                <p>{topic.description}</p>
                <Link to="/guide" className={styles.topicLink}>
                  Mehr erfahren →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.process} sectionSpacing`} aria-labelledby="process-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="process-heading" className="sectionTitle">
              Dein Weg mit Silaventino
            </h2>
            <p className="sectionSubtitle">
              Wir führen Dich Schritt für Schritt durch einen klaren Prozess. So behältst Du den
              Überblick und merkst schnell, was sich verändert.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.step} className={`${styles.processCard} card`}>
                <span className={styles.processNumber}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.why} sectionSpacing`} aria-labelledby="why-heading">
        <div className="container">
          <div className={styles.whyContent}>
            <div>
              <h2 id="why-heading" className="sectionTitle">
                Warum Silaventino?
              </h2>
              <p className="sectionSubtitle">
                Wir vereinen psychologisch fundiertes Wissen, Kommunikationserfahrung und
                didaktisches Handwerk. Alles ohne Fachjargon, dafür mit Haltung, Empathie und
                handfesten Ergebnissen.
              </p>
              <ul className={styles.whyList}>
                <li>Live-Begleitung &amp; digitale Ressourcen in einem flexiblen Set-up</li>
                <li>Tools, die in drei Minuten erklärt sind – und langfristig wirken</li>
                <li>Langjährige Erfahrung in Konfliktmoderation, Training &amp; Organisationsentwicklung</li>
              </ul>
              <div className={styles.whyActions}>
                <Link to="/about" className="btn btnSecondary">
                  Team kennenlernen
                </Link>
                <Link to="/contact" className={`btn btnPrimary ${styles.whyPrimary}`}>
                  Beratungsgespräch anfragen
                </Link>
              </div>
            </div>
            <div className={styles.whyImageWrapper}>
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Zwei Menschen, die sich in einem Workshop austauschen"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} sectionSpacing`} aria-labelledby="testimonials-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="testimonials-heading" className="sectionTitle">
              Stimmen aus unserer Community
            </h2>
            <p className="sectionSubtitle">
              Menschen, die ihre Kommunikationspraxis verändert haben – mit Programmen, Workshops
              oder digitaler Begleitung.
            </p>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonialsData.map((testimonial, index) => (
              <figure
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === currentTestimonial ? styles.testimonialActive : ''
                }`}
                aria-hidden={index !== currentTestimonial}
              >
                <blockquote>{testimonial.quote}</blockquote>
                <figcaption>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </figcaption>
              </figure>
            ))}
          </div>
          <div className={styles.testimonialDots} role="tablist" aria-label="Testimonials auswählen">
            {testimonialsData.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${index === currentTestimonial ? styles.dotActive : ''}`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Testimonial ${index + 1} anzeigen`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.team} sectionSpacing`} aria-labelledby="team-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="team-heading" className="sectionTitle">
              Menschen hinter Silaventino
            </h2>
            <p className="sectionSubtitle">
              Ein interdisziplinäres Team aus Kommunikation, Mediation und Lern-Design. Wir bringen
              Haltung und Struktur in jede Gesprächssituation.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembersData.map((member) => (
              <article key={member.name} className={`${styles.teamCard} card`}>
                <div className={styles.teamImage}>
                  <img
                    src={member.image}
                    alt={`Teammitglied ${member.name}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.teamBody}>
                  <h3>{member.name}</h3>
                  <span className={styles.teamRole}>{member.role}</span>
                  <p>{member.description}</p>
                  <span className={styles.teamFocus}>{member.focus}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.projects} sectionSpacing`} aria-labelledby="projects-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="projects-heading" className="sectionTitle">
              Projekte &amp; Highlights
            </h2>
            <p className="sectionSubtitle">
              Ein Einblick in Formate, die wir in den letzten Monaten begleitet haben – von
              Familienräten bis zu Organisationsentwicklung.
            </p>
          </div>
          <div className={styles.filterBar} role="group" aria-label="Projektfilter">
            {['Alle', 'Unternehmen', 'Privatpersonen', 'Familie'].map((category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${
                  activeProjectFilter === category ? styles.filterButtonActive : ''
                }`}
                type="button"
                onClick={() => setActiveProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={`${styles.projectCard} card`}>
                <div className={styles.projectImage}>
                  <img
                    src={project.image}
                    alt={`Projekt: ${project.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.projectBody}>
                  <span className="badge">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.faq} sectionSpacing`} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="faq-heading" className="sectionTitle">
              Häufige Fragen
            </h2>
            <p className="sectionSubtitle">
              Noch unsicher? Hier findest Du Antworten auf Fragen, die uns häufig erreichen. Deine
              ist nicht dabei? Schreib uns gern.
            </p>
          </div>
          <div className={styles.accordion} role="tablist" aria-label="FAQ">
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.accordionItem}>
                <button
                  type="button"
                  className={styles.accordionTrigger}
                  aria-expanded={expandedFaq === index}
                  onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                >
                  <span>{item.question}</span>
                  <span className={styles.accordionIcon}>{expandedFaq === index ? '−' : '+'}</span>
                </button>
                {expandedFaq === index && (
                  <div className={styles.accordionContent}>
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blogPreview} sectionSpacing`} aria-labelledby="blog-preview-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog-preview-heading" className="sectionTitle">
              Insights aus dem Blog
            </h2>
            <p className="sectionSubtitle">
              Regelmäßige Impulse, Checklisten und Reflexionsfragen rund um Kommunikation,
              Konfliktlösung und Selbstführung.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {latestPosts.map((post) => (
              <article key={post.slug} className={`${styles.blogCard} card`}>
                <div className={styles.blogImage}>
                  <img src={post.coverImage} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogBody}>
                  <span className="badge">{post.category}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <div className={styles.blogMeta}>
                    <span>{post.readTime}</span>
                    <Link to={`/blog/${post.slug}`} aria-label={`Weiterlesen: ${post.title}`}>
                      Weiterlesen →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.blogActions}>
            <Link to="/blog" className="btn btnSecondary">
              Alle Artikel entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.cta} sectionSpacing`} aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2 id="cta-heading">Bereit für klarere Gespräche?</h2>
              <p>
                Lass uns gemeinsam herausfinden, welches Format Dich oder Dein Team weiterbringt.
                Von kurzen Challenges bis zu begleiteter Konfliktmoderation – Du hast die Wahl.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/contact" className="btn btnPrimary">
                Kostenloses Erstgespräch sichern
              </Link>
              <Link to="/services" className="btn btnSecondary">
                Angebote vergleichen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;

Need to ensure `Home.module.css` matches class names used.

Let's craft CSS.