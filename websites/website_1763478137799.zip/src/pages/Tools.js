import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Gesprächs-Vorbereitungsbogen',
    description:
      'Klare Struktur für jedes schwierige Gespräch: Ziele, Botschaften, offene Fragen, mögliche Stolpersteine.',
    items: ['Vorlage zum Ausfüllen', 'Checkliste für den Gesprächseinstieg', 'Follow-up-Reminder']
  },
  {
    title: 'Ich-Botschaften-Formulierungshilfe',
    description:
      'Die vier Bausteine auf einen Blick: Formulierungsbeispiele, Mini-Übung, Reminder für Stimme & Haltung.',
    items: ['PDF & digitale Version', 'Beispielsätze für verschiedene Kontexte', 'Reflexionsfragen']
  },
  {
    title: 'Checkliste für schwierige Gespräche',
    description:
      'Alles, was Du vor, während und nach kritischen Situationen beachten solltest – kompakt und klar.',
    items: ['Vorbereitung, Durchführung, Nachbereitung', 'Hinweise für Eskalationen', 'Space für Notizen']
  }
];

const Tools = () => {
  return (
    <>
      <Helmet>
        <title>Tools &amp; Checklisten | Silaventino</title>
        <meta
          name="description"
          content="Kostenlose Tools und Checklisten von Silaventino: Gesprächsvorbereitung, Ich-Botschaften und Leitfäden für schwierige Situationen."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.hero}`}>
        <div className="container">
          <p className="badge">Toolbox</p>
          <h1>Deine Werkzeuge für klare Gespräche</h1>
          <p className={styles.subtitle}>
            Lade Dir strukturierte Vorlagen herunter, die Dich Schritt für Schritt durch heikle
            Gespräche führen. Direkt einsetzbar – ob am Küchentisch oder im Meetingraum.
          </p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.tools}`}>
        <div className="container">
          <div className={styles.grid}>
            {tools.map((tool) => (
              <article key={tool.title} className={`${styles.card} card`}>
                <h2>{tool.title}</h2>
                <p>{tool.description}</p>
                <ul>
                  {tool.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <button type="button" className={`btn btnPrimary ${styles.button}`}>
                  Tool herunterladen
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Tools;

CSS.