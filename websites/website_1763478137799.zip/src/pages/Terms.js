import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Allgemeine Geschäftsbedingungen | Silaventino</title>
        <meta
          name="description"
          content="Hier findest Du die Allgemeinen Geschäftsbedingungen von Silaventino."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.page}`}>
        <div className="container">
          <h1>Allgemeine Geschäftsbedingungen</h1>
          <p className={styles.intro}>
            Diese Allgemeinen Geschäftsbedingungen (AGB) regeln die Nutzung der Angebote von
            Silaventino (silaventino.site). Bitte lies die Bedingungen sorgfältig, bevor Du unsere
            Leistungen in Anspruch nimmst.
          </p>

          <div className={styles.content}>
            <section>
              <h2>1. Geltungsbereich</h2>
              <p>
                Die AGB gelten für alle Verträge zwischen Silaventino und den Nutzer:innen unserer
                Programme, Workshops, Coachings sowie digitalen Produkte. Abweichende Bedingungen
                erkennen wir nur an, wenn wir ihnen ausdrücklich zustimmen.
              </p>
            </section>

            <section>
              <h2>2. Leistungen</h2>
              <p>
                Silaventino bietet Trainings, Workshops, Moderationen und digitale Produkte zur
                Verbesserung von Kommunikations- und Konfliktkompetenzen an. Es handelt sich nicht
                um psychotherapeutische oder rechtliche Beratung. Unsere Leistungen ersetzen keine
                ärztliche oder therapeutische Behandlung.
              </p>
            </section>

            <section>
              <h2>3. Vertragsschluss</h2>
              <p>
                Der Vertrag kommt durch Bestätigung unserer Angebots-E-Mail oder durch Buchung eines
                Programms über unsere Plattform zustande. Du erhältst eine schriftliche Bestätigung.
              </p>
            </section>

            <section>
              <h2>4. Teilnahmevoraussetzungen</h2>
              <p>
                Unsere Angebote richten sich an volljährige Personen. Für Teamformate übernimmt die
                anfragende Organisation die Verantwortung für die Teilnahmeberechtigung. Nutzer:innen
                verpflichten sich, Informationen vertraulich zu behandeln.
              </p>
            </section>

            <section>
              <h2>5. Stornierung &amp; Umbuchung</h2>
              <p>
                Stornierungen sind bis 14 Tage vor Termin kostenfrei. Bei kurzfristigeren Absagen
                fallen bis zu 50 % der vereinbarten Teilnahmegebühr an. Digitale Programme können
                bis zum Startdatum kostenfrei storniert werden.
              </p>
            </section>

            <section>
              <h2>6. Haftung</h2>
              <p>
                Wir haften ausschließlich für Schäden, die auf Vorsatz oder grober Fahrlässigkeit
                beruhen. Für indirekte Schäden, entgangene Gewinne oder Folgeprobleme übernehmen wir
                keine Haftung. Die Eigenverantwortung der Teilnehmenden bleibt bestehen.
              </p>
            </section>

            <section>
              <h2>7. Datenschutz</h2>
              <p>
                Informationen zur Verarbeitung personenbezogener Daten findest Du in unserer{' '}
                <a href="/privacy">Datenschutzerklärung</a>. Wir behandeln alle Angaben vertraulich.
              </p>
            </section>

            <section>
              <h2>8. Schlussbestimmungen</h2>
              <p>
                Es gilt deutsches Recht. Sollten einzelne Bestimmungen unwirksam sein, bleibt die
                Wirksamkeit der übrigen Regelungen unberührt.
              </p>
            </section>
          </div>
        </div>
      </section>
    </>
  );
};

export default Terms;