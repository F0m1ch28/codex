import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programs = [
  {
    title: '7-Tage-Respektvoll-reden',
    duration: '7 Tage',
    target: 'Für Privatpersonen & Paare',
    description:
      'Tägliche Micro-Impulse, Audio-Reflexionen und Mini-Aufgaben für mehr Wertschätzung – perfekt für den Alltag.',
    advantages: ['Tägliche Check-ins', 'Partnerschaftsübungen', 'Live-Feedback-Session']
  },
  {
    title: 'Konfliktgespräche vorbereiten',
    duration: '2 Wochen',
    target: 'Für Führungskräfte & HR',
    description:
      'Strukturiere schwierige Gespräche, übe Formulierungen und sichere Nachbereitung. Mit Templates und Coaching.',
    advantages: ['Briefing-Canvas', 'Rollenspiel mit Feedback', 'Follow-up-Plan']
  },
  {
    title: '30 Tage bewusster zuhören',
    duration: '30 Tage',
    target: 'Für Teams & Communitys',
    description:
      'Trainiere aktives Zuhören, Perspektivwechsel und Mini-Mediation. Ideal, wenn viele Personen beteiligt sind.',
    advantages: ['Hör-Drills', 'Peer-Coaching', 'Wöchentliche Fokus-Session']
  }
];

const Programs = () => {
  return (
    <>
      <Helmet>
        <title>Programme &amp; Challenges | Silaventino</title>
        <meta
          name="description"
          content="Entdecke die Silaventino-Programme: geführte Challenges, Trainings und Begleitung für respektvolle Kommunikation und konstruktive Konfliktlösung."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.hero}`}>
        <div className="container">
          <p className="badge">Programme &amp; Challenges</p>
          <h1>Begleitete Lernreisen für klare Kommunikation</h1>
          <p className={styles.subtitle}>
            Unsere Programme kombinieren digitale Impulse, Live-Begleitung und Reflexion. So setzt
            Du Wissen direkt in wirksames Verhalten um – ohne überfordert zu sein.
          </p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.programs}`}>
        <div className="container">
          <div className={styles.grid}>
            {programs.map((program) => (
              <article key={program.title} className={`${styles.card} card`}>
                <div className={styles.cardHeader}>
                  <h2>{program.title}</h2>
                  <span className="badge">{program.duration}</span>
                </div>
                <p className={styles.target}>{program.target}</p>
                <p className={styles.description}>{program.description}</p>
                <ul className={styles.list}>
                  {program.advantages.map((advantage) => (
                    <li key={advantage}>{advantage}</li>
                  ))}
                </ul>
                <button type="button" className={`btn btnSecondary ${styles.button}`}>
                  Programm starten
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Programs;

Need CSS.