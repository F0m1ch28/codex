import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Imprint = () => {
  return (
    <>
      <Helmet>
        <title>Impressum | Silaventino</title>
        <meta
          name="description"
          content="Impressum von Silaventino – gesetzliche Angaben gemäß § 5 TMG."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.page}`}>
        <div className="container">
          <h1>Impressum</h1>
          <p className={styles.intro}>
            Angaben gemäß § 5 TMG für das Angebot silaventino.site. Verantwortlich für den Inhalt
            nach § 55 Abs. 2 RStV: Silaventino.site, Mustergasse&nbsp;12, 10115 Berlin.
          </p>

          <div className={styles.content}>
            <section>
              <h2>Kontakt</h2>
              <p>Silaventino.site</p>
              <p>Mustergasse 12</p>
              <p>10115 Berlin</p>
              <p>E-Mail: hallo@silaventino.site</p>
              <p>Telefon: +49 30 123 456 78</p>
            </section>

            <section>
              <h2>Verantwortliche</h2>
              <p>Clara Niering &amp; Jakob Riedel</p>
              <p>Inhaltlich verantwortlich nach § 55 Abs. 2 RStV</p>
            </section>

            <section>
              <h2>Umsatzsteuer-ID</h2>
              <p>USt-IdNr.: DE999999999 (Platzhalter)</p>
            </section>

            <section>
              <h2>Berufsbezeichnung</h2>
              <p>
                Kommunikationstrainer:in &amp; Mediator:in (Deutschland). Zuständige Kammern oder
                Aufsichtsbehörden bestehen nicht.
              </p>
            </section>

            <section>
              <h2>Streitschlichtung</h2>
              <p>
                Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS)
                bereit: https://ec.europa.eu/consumers/odr. Wir sind nicht verpflichtet und nicht
                bereit, an Streitbeilegungsverfahren vor Verbraucherschlichtungsstellen teilzunehmen.
              </p>
            </section>

            <section>
              <h2>Haftung für Inhalte</h2>
              <p>
                Wir sind für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen
                verantwortlich. Für externe Links übernehmen wir keine Haftung. Zum Zeitpunkt der
                Verlinkung waren keine rechtswidrigen Inhalte erkennbar.
              </p>
            </section>
          </div>
        </div>
      </section>
    </>
  );
};

export default Imprint;