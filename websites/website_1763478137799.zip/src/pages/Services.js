import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Kommunikations-Coaching',
    description:
      'Einzel- oder Duo-Sessions, in denen Du konkrete Gesprächssituationen vorbereitest, reflektierst und neue Strategien trainierst.',
    highlights: ['Live-Coaching via Video oder vor Ort', 'Rollenspiele &amp; Feedback', 'Handouts zum Nachlesen']
  },
  {
    title: 'Workshops &amp; Teamformate',
    description:
      'Intensive Workshops, Teamtage oder Retreats. Wir gestalten Formate, die Eure Kommunikationskultur stärken.',
    highlights: ['Vorgespräche &amp; Bedarfsklärung', 'Interaktive Übungen', 'Follow-up-Impulse']
  },
  {
    title: 'Konfliktmoderation',
    description:
      'Neutral moderierte Gespräche für Teams, Partnerschaften oder Familien. Wir schaffen Raum, damit alle Perspektiven gehört werden.',
    highlights: ['Vorgespräche mit Einzelpersonen', 'Gemeinsame Sessions mit klaren Regeln', 'Dokumentation &amp; nächste Schritte']
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Leistungen &amp; Angebote | Silaventino</title>
        <meta
          name="description"
          content="Silaventino bietet Coaching, Workshops und Konfliktmoderation für faire Lösungen und klare Kommunikation."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.hero}`}>
        <div className="container">
          <p className="badge">Angebote</p>
          <h1>Formate, die zu Dir passen</h1>
          <p className={styles.subtitle}>
            Ob Du allein übst, Dein Team stärkst oder im Konflikt Unterstützung brauchst – wir
            gestalten Formate, die Dich sicher begleiten.
          </p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.services}`}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={`${styles.card} card`}>
                <h2 dangerouslySetInnerHTML={{ __html: service.title }} />
                <p>{service.description}</p>
                <ul>
                  {service.highlights.map((highlight) => (
                    <li key={highlight} dangerouslySetInnerHTML={{ __html: highlight }} />
                  ))}
                </ul>
                <button type="button" className={`btn btnSecondary ${styles.button}`}>
                  Mehr erfahren
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;

Need CSS.