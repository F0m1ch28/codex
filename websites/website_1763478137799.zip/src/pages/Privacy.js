import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Datenschutzerklärung | Silaventino</title>
        <meta
          name="description"
          content="Transparente Informationen über die Datenverarbeitung bei Silaventino."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.page}`}>
        <div className="container">
          <h1>Datenschutzerklärung</h1>
          <p className={styles.intro}>
            Wir nehmen den Schutz Deiner Daten ernst. Nachfolgend erfährst Du, welche Daten wir
            verarbeiten und welche Rechte Du hast. Verantwortlich: Silaventino.site,
            Mustergasse&nbsp;12, 10115 Berlin.
          </p>

          <div className={styles.content}>
            <section>
              <h2>1. Verantwortliche Stelle</h2>
              <p>
                Verantwortlich im Sinne der DSGVO ist Silaventino.site, Mustergasse&nbsp;12, 10115
                Berlin. Kontakt: hallo@silaventino.site
              </p>
            </section>

            <section>
              <h2>2. Zugriffsdaten</h2>
              <p>
                Beim Besuch unserer Website speichern wir automatisch Server-Logfiles (IP-Adresse,
                Datum, Browser-Typ, Referrer). Die Verarbeitung dient der technischen Bereitstellung
                und Sicherheit der Seite. Rechtsgrundlage ist Art. 6 Abs. 1 lit. f DSGVO.
              </p>
            </section>

            <section>
              <h2>3. Kontaktformular</h2>
              <p>
                Wenn Du unser Kontaktformular nutzt, verarbeiten wir Deine Angaben (Name, E-Mail,
                Nachricht) zur Bearbeitung Deiner Anfrage. Rechtsgrundlage ist Art. 6 Abs. 1 lit. b
                DSGVO. Daten werden spätestens 12 Monate nach Abschluss der Anfrage gelöscht.
              </p>
            </section>

            <section>
              <h2>4. Cookies</h2>
              <p>
                Wir setzen ausschließlich technisch notwendige Cookies ein, um Grundfunktionen
                sicherzustellen. Du kannst die Speicherung über Deinen Browser verhindern. Analysen
                oder Tracking setzen wir nicht ein.
              </p>
            </section>

            <section>
              <h2>5. Deine Rechte</h2>
              <ul>
                <li>Auskunft über gespeicherte Daten (Art. 15 DSGVO)</li>
                <li>Berichtigung unrichtiger Daten (Art. 16 DSGVO)</li>
                <li>Löschung (Art. 17 DSGVO) und Einschränkung (Art. 18 DSGVO)</li>
                <li>Datenübertragbarkeit (Art. 20 DSGVO)</li>
                <li>Widerspruch gegen die Verarbeitung (Art. 21 DSGVO)</li>
              </ul>
              <p>
                Wende Dich hierzu an hallo@silaventino.site. Du kannst Dich außerdem bei einer
                Datenschutzaufsichtsbehörde beschweren.
              </p>
            </section>

            <section>
              <h2>6. Datensicherheit</h2>
              <p>
                Wir treffen organisatorische und technische Maßnahmen, um Deine Daten vor Verlust,
                Missbrauch oder unbefugtem Zugriff zu schützen. Dazu gehören verschlüsselte
                Verbindungen (HTTPS) und Zugriffskontrollen.
              </p>
            </section>

            <section>
              <h2>7. Aktualität</h2>
              <p>
                Diese Datenschutzerklärung ist aktuell gültig (Stand: März 2024). Bei Änderungen der
                Datenverarbeitung passen wir die Erklärung an.
              </p>
            </section>
          </div>
        </div>
      </section>
    </>
  );
};

export default Privacy;