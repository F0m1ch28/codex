import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';
import blogPosts from '../data/blogPosts';

const Blog = () => {
  const categories = useMemo(
    () => ['Alle', ...new Set(blogPosts.map((post) => post.category))],
    []
  );
  const [activeCategory, setActiveCategory] = useState('Alle');

  const filteredPosts =
    activeCategory === 'Alle'
      ? blogPosts
      : blogPosts.filter((post) => post.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Blog &amp; Insights | Silaventino</title>
        <meta
          name="description"
          content="Silaventino Blog: Inspiration, Methoden und Praxisbeispiele für wertschätzende Kommunikation und faire Konfliktlösung."
        />
      </Helmet>
      <section className={`sectionSpacing ${styles.hero}`}>
        <div className="container">
          <p className="badge">Blog &amp; Insights</p>
          <h1>Impulse für Gesprächskultur &amp; Konfliktlösung</h1>
          <p className={styles.subtitle}>
            Regelmäßige Inspiration, wie Du Konflikte souverän meisterst, Grenzen setzt und Gespräche
            bewusst gestaltest.
          </p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.blog}`}>
        <div className="container">
          <div className={styles.filterBar} role="group" aria-label="Kategorien filtern">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filteredPosts.map((post) => (
              <article key={post.slug} className={`${styles.card} card`}>
                <div className={styles.imageWrapper}>
                  <img src={post.coverImage} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.body}>
                  <span className="badge">{post.category}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <div className={styles.meta}>
                    <span>{post.readTime}</span>
                    <Link to={`/blog/${post.slug}`} aria-label={`Weiterlesen: ${post.title}`}>
                      Weiterlesen →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;

Need CSS.