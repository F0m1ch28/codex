const blogPosts = [
  {
    slug: 'wertschaetzende-kommunikation',
    title: 'Wertschätzende Kommunikation im Alltag',
    category: 'Wertschätzung',
    readTime: '6 Min.',
    author: 'Clara Niering',
    published: '2024-01-18',
    excerpt:
      'Warum eine respektvolle Grundhaltung Konflikte entschärft und wie Du Wertschätzung sichtbar machst – selbst wenn es schwierig wird.',
    coverImage: 'https://picsum.photos/1200/800?random=21',
    metaDescription:
      'Lerne, wie Du wertschätzende Kommunikation in Deinen Alltag integrierst und damit Konflikte nachhaltig entschärfst.',
    content: [
      'Wertschätzung ist mehr als ein freundliches Wort – sie zeigt sich in Haltung, Timing und Selbstreflexion. Wenn Menschen sich gesehen fühlen, sinkt das Konfliktpotenzial und öffnet sich Raum für Lösungen.',
      'Starte bei Dir: Welche Bedürfnisse treiben Dein Verhalten? Welche Trigger kennst Du? Eine ehrliche Selbstbeobachtung ist die stärkste Basis für respektvolle Gespräche.',
      'Im Gespräch helfen konkrete Signale: Blickkontakt, ein offener Körper, Gelassenheit in der Stimme. Wiederhole das, was Du gehört hast, bevor Du reagierst. So entsteht Vertrauen.',
      'Vermeide Killerphrasen wie „immer“ und „nie“. Sie wirken beschuldigend und lassen kaum Spielraum. Besser: konkret beschreiben, wie etwas auf Dich wirkt, und einladen, gemeinsam nach Lösungen zu suchen.',
      'Wertschätzende Kommunikation braucht Übung. Plane Dir kleine Reflexionsmomente ein, feiere Fortschritte und bilde neue Routinen – so wird Wertschätzung selbstverständlich.'
    ],
    takeaways: [
      'Wertschätzung beginnt mit Selbstreflexion.',
      'Konkrete Signale stärken Vertrauen.',
      'Kein Gespräch ohne aktives Zuhören.',
      'Kleine Routinen machen Kommunikation nachhaltig.'
    ]
  },
  {
    slug: 'konflikte-im-team-loesen',
    title: 'Konflikte im Team fair lösen',
    category: 'Team',
    readTime: '7 Min.',
    author: 'Jakob Riedel',
    published: '2024-02-01',
    excerpt:
      'Teams, die Konflikte klar ansprechen, arbeiten produktiver. Erfahre, wie Du Konflikte in Deinem Team sichtbar machst und gemeinsam auflöst.',
    coverImage: 'https://picsum.photos/1200/800?random=22',
    metaDescription:
      'Entdecke fünf Schritte, um Konflikte im Team konstruktiv anzugehen und Vertrauen zu stärken.',
    content: [
      'Konflikte sind ein natürlicher Bestandteil jeder Zusammenarbeit. Entscheidend ist, wie früh sie wahrgenommen und wie konstruktiv sie moderiert werden.',
      'Schaffe eine transparente Konfliktkultur: Erkläre, dass Unstimmigkeiten ausgesprochen werden dürfen. Vereinbart, wie ihr eskalierte Konflikte adressiert.',
      'Nutze neutrale Check-ins, um Spannungen rechtzeitig zu erkennen. Eine Frage wie „Wo stehen wir miteinander?“ öffnet Raum, ohne jemanden zu überfahren.',
      'Wenn der Konflikt konkret ist, strukturiere das Gespräch: Sachlage klären, Perspektiven spiegeln, gemeinsame Ziele definieren und erst dann in Lösungen denken.',
      'Halte Ergebnisse fest und überprüfe sie. So bleibt Verantwortlichkeit spürbar und niemand fühlt sich alleine gelassen.'
    ],
    takeaways: [
      'Konfliktkultur bewusst gestalten.',
      'Frühzeitig check-ins etablieren.',
      'Gespräche strukturiert moderieren.',
      'Verantwortung teilen und nachhalten.'
    ]
  },
  {
    slug: 'ich-botschaften-richtig-verwenden',
    title: 'Ich-Botschaften wirksam einsetzen',
    category: 'Techniken',
    readTime: '5 Min.',
    author: 'Clara Niering',
    published: '2024-03-12',
    excerpt:
      'Ich-Botschaften schaffen Nähe statt Distanz. Mit diesen vier Bausteinen formulierst Du klar, ohne zu verletzen.',
    coverImage: 'https://picsum.photos/1200/800?random=23',
    metaDescription:
      'Lerne, wie Du mit Ich-Botschaften Verantwortung übernimmst und Missverständnisse vermeidest.',
    content: [
      'Ich-Botschaften wirken, weil sie Verantwortung übernehmen. Statt andere zu beschuldigen, beschreibst Du, wie etwas auf Dich wirkt.',
      'Die vier Bausteine: Situation beschreiben, Wirkung auf Dich schildern, Bedürfnis benennen, Bitte formulieren.',
      'Achte darauf, dass Deine Stimme ruhig bleibt und Dein Körper offen wirkt. Sonst geht der Effekt verloren.',
      'Wenn Gegenwind kommt, bleib dran: Wiederhole ruhig Deine Botschaft, lade Dein Gegenüber ein, ebenfalls Ich-Botschaften zu nutzen.',
      'Regelmäßiges Üben hilft, auch in stressigen Momenten bei Dir zu bleiben.'
    ],
    takeaways: [
      'Verantwortung statt Schuldzuweisung.',
      'Vier Bausteine strukturieren die Botschaft.',
      'Körpersprache unterstützt die Wirkung.',
      'Übung macht Dich souverän.'
    ]
  },
  {
    slug: 'mit-kritik-achtsam-umgehen',
    title: 'Mit Kritik achtsam umgehen',
    category: 'Reflexion',
    readTime: '6 Min.',
    author: 'Jakob Riedel',
    published: '2024-03-28',
    excerpt:
      'Kritik tut weh – muss sie aber nicht. Mit diesen Strategien bleibst Du handlungsfähig und lernst aus Feedback.',
    coverImage: 'https://picsum.photos/1200/800?random=24',
    metaDescription:
      'Erhalte praxisnahe Strategien, um Kritik anzunehmen, ohne Dich zu verlieren – für mehr Gelassenheit im Alltag.',
    content: [
      'Kritik aktiviert unser Alarmsystem. Deshalb reagieren wir oft defensiv. Ein kurzer Atemzug und ein bewusstes „Danke fürs Mitteilen“ entschärfen den ersten Impuls.',
      'Trenne Sachverhalt und Interpretation. Frage nach Beispielen, um Missverständnisse aufzudecken und das Gespräch zu versachlichen.',
      'Führe eine innere Inventur durch: Was davon hilft Dir weiter? Was gehört eigentlich nicht zu Dir? Du entscheidest, was Du annimmst.',
      'Nutze Kritikgespräche, um Deinen Bedarf zu formulieren. Ein „Mir hilft es, wenn wir konkret besprechen, was ich beim nächsten Mal anders tun kann“ schafft Orientierung.',
      'Reflektiere das Gespräch im Nachgang. Notiere Dir Erkenntnisse und plane kleine Experimente, um Neues auszuprobieren.'
    ],
    takeaways: [
      'Erster Impuls: Atmen und bedanken.',
      'Fragen stellen statt interpretieren.',
      'Feedback sortieren und auswählen.',
      'Konkrete nächste Schritte vereinbaren.'
    ]
  }
];

export default blogPosts;