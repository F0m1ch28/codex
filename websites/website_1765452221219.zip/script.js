document.addEventListener("DOMContentLoaded", () => {
    const consentKey = "msd-cookie-consent";
    const banner = document.getElementById("cookie-banner");
    const yearEl = document.getElementById("year");
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }

    if (!banner) return;

    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
        banner.classList.add("is-visible");
    }

    banner.addEventListener("click", (event) => {
        const action = event.target.dataset.cookieAction;
        if (!action) return;

        if (action === "accept") {
            localStorage.setItem(consentKey, "accepted");
        } else if (action === "decline") {
            localStorage.setItem(consentKey, "declined");
        }
        banner.classList.remove("is-visible");
    });
});