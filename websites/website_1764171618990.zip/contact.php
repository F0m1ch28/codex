<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Energy Track | Vancouver Office &amp; Support</title>
  <meta name="description" content="Contact Energy Track for demos, support, and partnership inquiries. Visit our Vancouver office or request more information.">
  <link rel="stylesheet" href="style.css">
  <link rel="icon" href="https://placehold.co/32x32/png">
  <meta property="og:title" content="Contact Energy Track">
  <meta property="og:description" content="Get in touch with Energy Track’s Vancouver office for monitoring and analytics solutions.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.example.com/contact.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?vancouver">
</head>
<body>
  <header>
    <div class="navbar">
      <a class="brand" href="index.php">Energy Track <span>Infrastructure Intelligence</span></a>
      <nav>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="technology.html">Technology</a></li>
          <li><a href="case-studies.html">Case Studies</a></li>
          <li><a href="news.html">News</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main>
    <nav class="breadcrumb">
      <a href="index.php">Home</a> &raquo; Contact
    </nav>

    <section class="page-hero">
      <h1>Contact Energy Track</h1>
      <p>Connect with our Vancouver headquarters for product demos, technical support, and partnership opportunities.</p>
    </section>

    <section class="section">
      <h2>Send a Message</h2>
      <form action="thanks.php" method="post">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Full name" required>

        <label for="company">Company</label>
        <input type="text" id="company" name="company" placeholder="Organization" required>

        <label for="email">Work Email</label>
        <input type="email" id="email" name="email" placeholder="email@company.com" required>

        <label for="message">Message</label>
        <textarea id="message" name="message" placeholder="How can Energy Track assist?" required></textarea>

        <button class="btn btn-primary" type="submit">Submit Inquiry</button>
      </form>
    </section>

    <section class="section">
      <h2>Vancouver Office</h2>
      <div class="grid grid-2">
        <article class="card">
          <h3>Headquarters</h3>
          <p>Energy Track<br>1280 Georgia Street W<br>Vancouver, BC V6E 3J7</p>
          <p>Email: <a href="mailto:info@energytrack.com">info@energytrack.com</a><br>
             Phone: <a href="tel:+16045551234">+1 (604) 555-1234</a></p>
          <p>Office hours: Monday to Friday, 8:30 AM – 6:00 PM PT</p>
        </article>
        <article class="card map-embed">
          <h3>Location Map</h3>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.550079470829!2d-123.12449022351559!3d49.28883097139232!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548671803183f02f%3A0x8b4302bf5d8720ff!2s1280%20W%20Georgia%20St%2C%20Vancouver%2C%20BC%20V6E%204R3%2C%20Canada!5e0!3m2!1sen!2sca!4v1697040000000" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </article>
      </div>
    </section>
  </main>

  <footer>
    <div class="footer-inner">
      <div class="footer-brand">
        <h3>Energy Track</h3>
        <p>Operational intelligence platform engineered for energy infrastructure leaders seeking resilient, efficient, and lower-carbon assets.</p>
      </div>
      <div>
        <h4>Company</h4>
        <ul class="footer-links">
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="news.html">Newsroom</a></li>
          <li><a href="case-studies.html">Case Studies</a></li>
        </ul>
      </div>
      <div>
        <h4>Support</h4>
        <ul class="footer-links">
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="privacy.html">Privacy Policy</a></li>
          <li><a href="terms.html">Terms of Use</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>
      <div>
        <h4>Head Office</h4>
        <p>Energy Track<br>1280 Georgia Street W<br>Vancouver, BC V6E 3J7</p>
        <p>Phone: <a href="tel:+16045551234">+1 (604) 555-1234</a></p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> Energy Track. All rights reserved.</span>
      <div>
        <a href="privacy.html">Privacy</a> &middot;
        <a href="terms.html">Terms</a> &middot;
        <a href="sitemap.xml">Sitemap</a>
      </div>
    </div>
  </footer>

  <div class="cookie-banner">
    <div>
      <strong>Cookie Notice</strong>
      <p>Energy Track uses cookies to enhance experience, analyze usage, and deliver tailored content. Manage your preferences below.</p>
    </div>
    <div class="cookie-actions">
      <button class="btn btn-primary accept-cookies" type="button">Accept</button>
      <button class="btn btn-outline decline-cookies" type="button">Decline</button>
      <a href="privacy.html" class="btn btn-secondary" style="padding:0.6rem 1.2rem;">Privacy Policy</a>
    </div>
  </div>

  <script src="script.js" defer></script>
</body>
</html>