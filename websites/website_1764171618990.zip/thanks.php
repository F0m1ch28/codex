<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Thank You | Energy Track</title>
  <meta name="description" content="Thank you for contacting Energy Track. We have received your submission.">
  <link rel="stylesheet" href="style.css">
  <link rel="icon" href="https://placehold.co/32x32/png">
  <meta property="og:title" content="Thank You | Energy Track">
  <meta property="og:description" content="Energy Track has received your form submission.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.example.com/thanks.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?thanks">
</head>
<body>
  <header>
    <div class="navbar">
      <a class="brand" href="index.php">Energy Track <span>Infrastructure Intelligence</span></a>
      <nav>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="technology.html">Technology</a></li>
          <li><a href="case-studies.html">Case Studies</a></li>
          <li><a href="news.html">News</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main>
    <section class="page-hero">
      <h1>Submission Received</h1>
      <p>Energy Track appreciates your interest. A member of our team will respond shortly.</p>
    </section>

    <section class="section">
      <h2>Next Steps</h2>
      <p>Our specialists review every inquiry to ensure the right domain expert follows up. Expect a response within two business days.</p>
      <a class="btn btn-primary" href="index.php">Return to Homepage</a>
    </section>
  </main>

  <footer>
    <div class="footer-inner">
      <div class="footer-brand">
        <h3>Energy Track</h3>
        <p>Operational intelligence platform engineered for energy infrastructure leaders seeking resilient, efficient, and lower-carbon assets.</p>
      </div>
      <div>
        <h4>Company</h4>
        <ul class="footer-links">
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="news.html">Newsroom</a></li>
          <li><a href="case-studies.html">Case Studies</a></li>
        </ul>
      </div>
      <div>
        <h4>Support</h4>
        <ul class="footer-links">
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="privacy.html">Privacy Policy</a></li>
          <li><a href="terms.html">Terms of Use</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>
      <div>
        <h4>Head Office</h4>
        <p>Energy Track<br>1280 Georgia Street W<br>Vancouver, BC V6E 3J7</p>
        <p>Phone: <a href="tel:+16045551234">+1 (604) 555-1234</a></p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> Energy Track. All rights reserved.</span>
      <div>
        <a href="privacy.html">Privacy</a> &middot;
        <a href="terms.html">Terms</a> &middot;
        <a href="sitemap.xml">Sitemap</a>
      </div>
    </div>
  </footer>

  <div class="cookie-banner">
    <div>
      <strong>Cookie Notice</strong>
      <p>Energy Track uses cookies to enhance experience, analyze usage, and deliver tailored content. Manage your preferences below.</p>
    </div>
    <div class="cookie-actions">
      <button class="btn btn-primary accept-cookies" type="button">Accept</button>
      <button class="btn btn-outline decline-cookies" type="button">Decline</button>
      <a href="privacy.html" class="btn btn-secondary" style="padding:0.6rem 1.2rem;">Privacy Policy</a>
    </div>
  </div>

  <script src="script.js" defer></script>
</body>
</html>