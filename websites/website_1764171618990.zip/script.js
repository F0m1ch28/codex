document.addEventListener('DOMContentLoaded', () => {
  // Cookie banner control
  const banner = document.querySelector('.cookie-banner');
  if (banner) {
    const acceptBtn = banner.querySelector('.accept-cookies');
    const declineBtn = banner.querySelector('.decline-cookies');
    const cookieChoice = localStorage.getItem('et-cookie-consent');

    if (!cookieChoice) {
      banner.style.display = 'flex';
    }

    acceptBtn?.addEventListener('click', () => {
      localStorage.setItem('et-cookie-consent', 'accepted');
      banner.style.display = 'none';
    });

    declineBtn?.addEventListener('click', () => {
      localStorage.setItem('et-cookie-consent', 'declined');
      banner.style.display = 'none';
    });
  }

  // Navigation active state
  const currentPath = window.location.pathname.split('/').pop();
  document.querySelectorAll('nav a').forEach(link => {
    const linkPath = link.getAttribute('href');
    if (linkPath === currentPath || (currentPath === '' && linkPath === 'index.php')) {
      link.classList.add('active');
    }
  });
});