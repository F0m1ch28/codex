<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Energy Track | Real-Time Energy Infrastructure Intelligence</title>
  <meta name="description" content="Energy Track delivers real-time monitoring, AI predictive maintenance, digital twin simulations, and emissions tracking for energy infrastructure leaders.">
  <link rel="stylesheet" href="style.css">
  <link rel="icon" href="https://placehold.co/32x32/png">
  <meta property="og:title" content="Energy Track | Real-Time Energy Infrastructure Intelligence">
  <meta property="og:description" content="Monitor, optimize, and decarbonize energy assets with Energy Track's AI-powered analytics and digital twin simulations.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.example.com/">
  <meta property="og:image" content="https://picsum.photos/1200/630?energy">
  <meta name="twitter:card" content="summary_large_image">
</head>
<body>
  <header>
    <div class="navbar">
      <a class="brand" href="index.php">Energy Track <span>Infrastructure Intelligence</span></a>
      <nav>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="technology.html">Technology</a></li>
          <li><a href="case-studies.html">Case Studies</a></li>
          <li><a href="news.html">News</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main>
    <section class="hero">
      <div class="hero-wrapper">
        <div class="status-pill">Trusted by North American Operators</div>
        <div class="hero-content">
          <h1>Real-Time Energy Infrastructure Intelligence for Resilient Operations</h1>
          <p>Energy Track empowers energy producers with continuous monitoring, predictive analytics, and digital twin simulations to protect assets, reduce emissions, and optimize performance across critical infrastructure.</p>
          <div class="hero-actions">
            <a class="btn btn-primary" href="solutions.html">Explore Core Solutions</a>
            <a class="btn btn-secondary" href="#monitoring">View Platform Insights</a>
          </div>
        </div>
      </div>
      <img src="https://picsum.photos/720/520?energy" alt="Energy control center visualization" loading="lazy">
    </section>

    <section id="monitoring" class="section">
      <h2>Real-Time Energy Monitoring</h2>
      <p class="subtitle">Cross-asset visibility with sub-second telemetry, anomaly detection, and compliance-grade reporting delivered through a unified command interface.</p>
      <div class="grid grid-3">
        <article class="card">
          <div class="tag">Pipeline Flows</div>
          <h3>Integrated SCADA Telemetry</h3>
          <p>Ingest pipeline pressures, flow rates, and valve states from legacy SCADA and edge IoT devices into a secure, cloud-native observability layer.</p>
          <ul>
            <li>Adaptive thresholds and alerts</li>
            <li>Highly available data streams</li>
            <li>Encrypted asset-to-cloud channels</li>
          </ul>
        </article>
        <article class="card">
          <div class="tag">Power Plants</div>
          <h3>Generation Performance Dashboards</h3>
          <p>Track turbine efficiency, cooling loads, and fuel blends while comparing performance benchmarks and maintenance schedules in real time.</p>
          <ul>
            <li>Operator-centric dashboards</li>
            <li>Scenario modeling overlays</li>
            <li>Automated compliance exports</li>
          </ul>
        </article>
        <article class="card">
          <div class="tag">Substations</div>
          <h3>Grid Stability Insights</h3>
          <p>Monitor substations with synchronized phasor measurements to anticipate voltage imbalances and coordinate distributed energy resources.</p>
          <ul>
            <li>Predictive event detection</li>
            <li>Remedial action plans</li>
            <li>ISO data integrations</li>
          </ul>
        </article>
      </div>
    </section>

    <section class="section">
      <h2>AI Predictive Maintenance</h2>
      <p class="subtitle">Machine learning models trained on multivariate data streams deliver asset-level failure probability curves and maintenance prioritization.</p>
      <div class="grid grid-2">
        <article class="card">
          <h3>Failure Risk Forecasting</h3>
          <p>Gradient boosting ensembles evaluate vibration, acoustics, and thermal signatures to anticipate pump deterioration 45 days before threshold.</p>
          <blockquote>“Energy Track reduced forced outages by 32% across our Western Canadian compression fleet.” — Reliability Lead, Alberta Midstream</blockquote>
        </article>
        <article class="card">
          <h3>Maintenance Scheduling Optimizer</h3>
          <p>Dynamic models balance risk, cost, and resource availability to produce rolling maintenance plans optimized for production windows.</p>
          <table class="table-layout">
            <thead>
              <tr>
                <th>Asset</th>
                <th>Risk Level</th>
                <th>Intervention</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Compressor C-17</td>
                <td>High (0.82)</td>
                <td>Inspect seals &amp; bearings</td>
              </tr>
              <tr>
                <td>Turbine T-04</td>
                <td>Moderate (0.54)</td>
                <td>Rebalance rotor assembly</td>
              </tr>
              <tr>
                <td>Transformer TR-12</td>
                <td>Low (0.21)</td>
                <td>Oil sampling &amp; dissolved gas analysis</td>
              </tr>
            </tbody>
          </table>
        </article>
      </div>
    </section>

    <section class="section">
      <h2>Digital Twin Simulations</h2>
      <p class="subtitle">High-fidelity digital replicas combine physics-based modeling with machine learning calibration to stress test assets under variable conditions.</p>
      <div class="grid grid-3">
        <article class="card">
          <h3>Asset Integrity Twins</h3>
          <p>Simulate corrosion, fatigue, and fluid dynamics to optimize inspection intervals and validate mitigation strategies across upstream and downstream assets.</p>
        </article>
        <article class="card">
          <h3>Network Flow Optimization</h3>
          <p>Visualize network constraints and reroute flows with digital twin optimizers that integrate market prices, demand forecasts, and maintenance events.</p>
        </article>
        <article class="card">
          <h3>Emergency Response Scenarios</h3>
          <p>Run simulated incident drills that incorporate weather impacts, regulatory requirements, and mobilization timelines for more resilient response plans.</p>
        </article>
      </div>
    </section>

    <section class="section">
      <h2>Emissions Tracking Dashboards</h2>
      <p class="subtitle">Continuous emissions monitoring with automated quantification, regulatory alignment, and decarbonization performance analytics.</p>
      <div class="grid grid-2">
        <article class="card">
          <h3>GHG Inventory Automation</h3>
          <p>Aggregate combustion, venting, and fugitive data streams to produce auditable emissions inventories aligned with provincial and federal frameworks.</p>
          <ul>
            <li>Methane reconciliation workflows</li>
            <li>Carbon intensity benchmarking</li>
            <li>Automated ESG reporting packages</li>
          </ul>
        </article>
        <article class="card">
          <h3>Satellite and Drone Integration</h3>
          <p>Fuse satellite spectral data and drone-based optical gas imaging with ground sensors to detect, verify, and quantify emission events in near real time.</p>
          <a href="technology.html">Review Remote Diagnostics &raquo;</a>
        </article>
      </div>
    </section>

    <section class="section">
      <h2>Regional Case Studies</h2>
      <p class="subtitle">Field-proven results demonstrating measurable operational and environmental gains across Western Canadian energy assets.</p>
      <div class="case-studies-grid">
        <article class="case-card">
          <img src="https://picsum.photos/640/360?alberta" alt="Alberta energy infrastructure" loading="lazy">
          <div class="content">
            <h3>Alberta Upstream Efficiency Program</h3>
            <p>Integrated sensor networks and AI maintenance models decreased unplanned downtime by 29% while minimizing flaring events in the Clearwater region.</p>
            <a href="case-studies.html">Explore the Study</a>
          </div>
        </article>
        <article class="case-card">
          <img src="https://picsum.photos/640/360?saskatchewan" alt="Saskatchewan energy facility" loading="lazy">
          <div class="content">
            <h3>Saskatchewan Gas Processing Optimization</h3>
            <p>Digital twin-driven throughput optimization boosted processing efficiency by 11% and delivered a 24% reduction in methane emissions.</p>
            <a href="case-studies.html">Explore the Study</a>
          </div>
        </article>
      </div>
    </section>

    <section class="section">
      <h2>Expert Insights</h2>
      <p class="subtitle">Objective analysis and commentary from Energy Track’s research desk on regulatory shifts, technology adoption, and operational excellence.</p>
      <div class="grid grid-3">
        <article class="card">
          <h3>Navigating Tiered Carbon Pricing</h3>
          <p>How integrated emissions dashboards help producers align capital plans with evolving carbon policies across Canadian provinces.</p>
          <a href="news.html">Read the Update &raquo;</a>
        </article>
        <article class="card">
          <h3>Future-Proofing Asset Integrity</h3>
          <p>Combining robotics, non-destructive evaluation, and predictive AI to extend asset life cycles while controlling inspection costs.</p>
          <a href="technology.html">Discover the Technology</a>
        </article>
        <article class="card">
          <h3>Data Trust in Energy Analytics</h3>
          <p>Frameworks for ensuring data provenance, model governance, and transparency across integrated monitoring ecosystems.</p>
          <a href="about.html">Review Policies</a>
        </article>
      </div>
    </section>

    <section class="section">
      <h2>Subscribe to Energy Track Intelligence Briefings</h2>
      <p class="subtitle">Monthly analysis on operational technology, regulatory shifts, and energy infrastructure performance.</p>
      <form class="newsletter" action="thanks.php" method="post">
        <label for="newsletter-email">Email Address</label>
        <input type="email" id="newsletter-email" name="newsletter-email" placeholder="you@company.com" required>
        <button class="btn btn-primary" type="submit">Join the Newsletter</button>
      </form>
    </section>
  </main>

  <footer>
    <div class="footer-inner">
      <div class="footer-brand">
        <h3>Energy Track</h3>
        <p>Operational intelligence platform engineered for energy infrastructure leaders seeking resilient, efficient, and lower-carbon assets.</p>
      </div>
      <div>
        <h4>Company</h4>
        <ul class="footer-links">
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="news.html">Newsroom</a></li>
          <li><a href="case-studies.html">Case Studies</a></li>
        </ul>
      </div>
      <div>
        <h4>Support</h4>
        <ul class="footer-links">
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="privacy.html">Privacy Policy</a></li>
          <li><a href="terms.html">Terms of Use</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>
      <div>
        <h4>Head Office</h4>
        <p>Energy Track<br>1280 Georgia Street W<br>Vancouver, BC V6E 3J7</p>
        <p>Phone: <a href="tel:+16045551234">+1 (604) 555-1234</a></p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> Energy Track. All rights reserved.</span>
      <div>
        <a href="privacy.html">Privacy</a> &middot;
        <a href="terms.html">Terms</a> &middot;
        <a href="sitemap.xml">Sitemap</a>
      </div>
    </div>
  </footer>

  <div class="cookie-banner">
    <div>
      <strong>Cookie Notice</strong>
      <p>Energy Track uses cookies to enhance experience, analyze usage, and deliver tailored content. Manage your preferences below.</p>
    </div>
    <div class="cookie-actions">
      <button class="btn btn-primary accept-cookies" type="button">Accept</button>
      <button class="btn btn-outline decline-cookies" type="button">Decline</button>
      <a href="privacy.html" class="btn btn-secondary" style="padding:0.6rem 1.2rem;">Privacy Policy</a>
    </div>
  </div>

  <script src="script.js" defer></script>
</body>
</html>