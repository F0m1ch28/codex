import React from 'react';
import Header from './Header.jsx';
import Footer from './Footer.jsx';
import CookieBanner from './CookieBanner.jsx';

const Layout = ({ children }) => (
  <div className="app-shell">
    <div className="floating-gradient"></div>
    <div className="floating-gradient floating-gradient--two"></div>
    <Header />
    <main className="main-content">{children}</main>
    <Footer />
    <CookieBanner />
  </div>
);

export default Layout;