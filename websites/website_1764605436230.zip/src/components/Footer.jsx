import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="footer" id="footer">
      <div className="container footer__inner">
        <div className="footer__top">
          <div className="footer__brand">
            <div className="header__logo" aria-hidden="true">
              <span>СК</span>
              Сайт компании
            </div>
            <p>
              Мы создаём цифровые экосистемы, объединяющие стратегии бизнеса, технологическую
              архитектуру и безупречный пользовательский опыт.
            </p>
            <div className="footer__social" aria-label="Социальные сети">
              <a
                className="social-link"
                href="https://www.linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
              >
                in
              </a>
              <a
                className="social-link"
                href="https://www.facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
              >
                f
              </a>
              <a
                className="social-link"
                href="https://www.instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
              >
                ✶
              </a>
            </div>
          </div>
          <div className="footer__col">
            <h4>Навигация</h4>
            <div className="footer__links">
              <NavLink to="/">Главная</NavLink>
              <NavLink to="/about">О компании</NavLink>
              <NavLink to="/services">Услуги</NavLink>
              <NavLink to="/contact">Контакты</NavLink>
              <NavLink to="/faq">FAQ</NavLink>
            </div>
          </div>
          <div className="footer__col">
            <h4>Юридическая информация</h4>
            <div className="footer__links">
              <NavLink to="/privacy-policy">Политика конфиденциальности</NavLink>
              <NavLink to="/terms-of-service">Условия использования</NavLink>
              <a href="mailto:legal@company.ru">Юридический отдел</a>
            </div>
          </div>
          <div className="footer__col">
            <h4>Контакты</h4>
            <div className="footer__links">
              <span>г. Москва, ул. Премьерская, д. 10, офис 21</span>
              <a href="tel:+79990000000">+7 (999) 000-00-00</a>
              <a href="mailto:hello@company.ru">hello@company.ru</a>
            </div>
          </div>
        </div>
        <div className="footer__bottom">
          <span>© {currentYear} Сайт компании. Все права защищены.</span>
          <span>Создано с заботой о доступности и инновациях.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;