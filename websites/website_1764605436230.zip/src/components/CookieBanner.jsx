import React, { useEffect, useState } from 'react';

const COOKIE_KEY = 'cookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem(COOKIE_KEY, value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <aside className="cookie-banner" role="dialog" aria-live="assertive">
      <div>
        <strong>Мы ценим вашу конфиденциальность</strong>
      </div>
      <p>
        Мы используем cookies для персонализации сервисов и улучшения работы сайта. Вы можете принять
        или отклонить использование необязательных cookies. Обязательные cookies необходимы для
        корректной работы сайта.
      </p>
      <div className="cookie-actions">
        <button className="btn-accept" onClick={() => handleConsent('accepted')}>
          Принять
        </button>
        <button className="btn-decline" onClick={() => handleConsent('declined')}>
          Отклонить
        </button>
      </div>
    </aside>
  );
};

export default CookieBanner;