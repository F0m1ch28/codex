import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';

const navLinks = [
  { path: '/', label: 'Главная' },
  { path: '/about', label: 'О нас' },
  { path: '/services', label: 'Услуги' },
  { path: '/contact', label: 'Контакты' },
  { path: '/faq', label: 'FAQ' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [isMenuOpen]);

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={`header ${isScrolled ? 'is-scrolled' : ''}`}>
      <div className="container">
        <div className="header__inner">
          <NavLink to="/" className="header__logo" onClick={closeMenu} aria-label="На главную">
            <span>СК</span>
            Сайт компании
          </NavLink>
          <nav className="header__nav" aria-label="Главная навигация">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  `header__link ${isActive ? 'header__link--active' : ''}`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>
          <div className="header__cta">
            <NavLink to="/contact" className="btn btn-secondary">
              Связаться с нами
            </NavLink>
          </div>
          <button
            className="header__toggle"
            aria-expanded={isMenuOpen}
            aria-label="Меню"
            onClick={() => setIsMenuOpen((prev) => !prev)}
          >
            {isMenuOpen ? '✕' : '≡'}
          </button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="mobile-menu" role="dialog" aria-modal="true">
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              className="mobile-link"
              onClick={closeMenu}
            >
              {link.label}
            </NavLink>
          ))}
          <NavLink to="/privacy-policy" className="mobile-link" onClick={closeMenu}>
            Политика конфиденциальности
          </NavLink>
          <NavLink to="/terms-of-service" className="mobile-link" onClick={closeMenu}>
            Условия использования
          </NavLink>
        </div>
      )}
    </header>
  );
};

export default Header;