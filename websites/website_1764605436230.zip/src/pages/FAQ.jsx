import React, { useState } from 'react';
import { motion } from 'framer-motion';
import AccordionItem from '../components/AccordionItem.jsx';

const faqItems = [
  {
    question: 'Какие этапы включает цифровая трансформация с вашей командой?',
    answer:
      'Мы начинаем с диагностики и стратегического дизайна, затем переходим к формированию дорожной карты и архитектуры. Следующий этап — внедрение, пилотирование и обучение команд. Завершаем масштабированием и сопровождением.\n\nКаждый проект сопровождается выделенным трансформационным офисом и KPI-матрицей.'
  },
  {
    question: 'Как вы обеспечиваете безопасность и соответствие стандартам?',
    answer:
      'Мы руководствуемся международными стандартами ISO 27001, GDPR и требованиями отрасли. Все решения проходят аудит безопасности, тестирование на проникновение и проверку compliance. Кроме того, внедряем zero-trust подход и управляем доступом по принципу минимальных прав.'
  },
  {
    question: 'Можно ли подключиться только к аналитике и BI?',
    answer:
      'Да, мы предлагаем модульные сервисы. Команда аналитиков проведёт аудит текущего ландшафта данных, разработает архитектуру DWH/BI и внедрит инструменты визуализации и предиктивной аналитики.'
  },
  {
    question: 'Как построен процесс взаимодействия с вами?',
    answer:
      'Мы формируем совместную рабочую группу, определяем каналы коммуникации и регулярные сессии синхронизации. Используем гибридные методологии (Agile/PMI), предоставляем прозрачную отчётность и дашборды статуса проекта.'
  },
  {
    question: 'Вы работаете с международными командами и часовыми поясами?',
    answer:
      'Да, у нас распределённая команда с опытом ведения проектов в Европе, Азии и на Ближнем Востоке. Настраиваем гибкие графики, выделенные каналы и локальную поддержку при необходимости.'
  }
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <motion.div
      className="page"
      initial={{ opacity: 0, y: 28 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -24 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
    >
      <section className="section">
        <div className="container">
          <span className="badge">FAQ</span>
          <h1 className="section-title">Часто задаваемые вопросы</h1>
          <p className="section-lead">
            Прозрачно отвечаем на ключевые вопросы о подходах, компетенциях и форматах
            взаимодействия.
          </p>
          <div className="faq-list" style={{ marginTop: 32 }}>
            {faqItems.map((item, index) => (
              <AccordionItem
                key={item.question}
                index={index}
                question={item.question}
                answer={item.answer}
                isOpen={openIndex === index}
                onToggle={() => setOpenIndex(openIndex === index ? -1 : index)}
              />
            ))}
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default FAQ;