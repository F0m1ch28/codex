import React from 'react';
import { motion } from 'framer-motion';

const services = [
  {
    title: 'Цифровая трансформация',
    badge: 'Стратегия',
    description:
      'Комплексная трансформация бизнес-модели, операционных процессов и организационной культуры с упором на быстрые результаты.',
    capabilities: [
      'Диагностика цифровой зрелости',
      'Цифровая стратегия и дорожная карта',
      'Организация трансформационного офиса',
      'Управление изменениями и обучение команд'
    ]
  },
  {
    title: 'Продуктовая разработка',
    badge: 'Инновации',
    description:
      'Создание цифровых продуктов, платформ и сервисов полного цикла — от сессии дизайн-мышления до промышленного внедрения.',
    capabilities: [
      'Дизайн-системы и UX-исследования',
      'Разработка веб и мобильных приложений',
      'Интеграция с существующими системами',
      'Поддержка и развитие продуктов'
    ]
  },
  {
    title: 'Аналитика и AI',
    badge: 'Data-driven',
    description:
      'Управление данными, построение BI-решений, предиктивная аналитика, машинное обучение и интеллектуальная автоматизация.',
    capabilities: [
      'Стратегия данных и Data Governance',
      'BI и визуализация показателей',
      'ML-модели и прогнозирование',
      'Интеллектуальные чат-боты и NLP'
    ]
  },
  {
    title: 'Кибербезопасность',
    badge: 'Безопасность',
    description:
      'Комплексный подход к безопасности цифровых платформ: аудит, архитектура, внедрение решений и реагирование на инциденты.',
    capabilities: [
      'Аудит и стресс-тестирование',
      'Внедрение zero-trust архитектуры',
      'Мониторинг и реагирование 24/7',
      'Обучение и управление рисками'
    ]
  }
];

const processSteps = [
  {
    title: 'Совместное погружение',
    description:
      'Проводим discovery-сессии, интервью и оценку текущих процессов, чтобы сформировать единое понимание целей.'
  },
  {
    title: 'Проектирование решения',
    description:
      'Создаём прототипы, формируем архитектуру, описываем целевые бизнес-процессы и KPI для измерения успеха.'
  },
  {
    title: 'Интенсивная реализация',
    description:
      'Работаем спринтами, используя гибридные методологии. Сопровождаем внедрение и распределяем ответственность.'
  },
  {
    title: 'Сопровождение и масштабирование',
    description:
      'Оцениваем результаты, масштабируем успешные практики, расширяем экосистему и усиливаем команды клиентов.'
  }
];

const Services = () => (
  <motion.div
    className="page"
    initial={{ opacity: 0, y: 28 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -24 }}
    transition={{ duration: 0.6, ease: 'easeOut' }}
  >
    <section className="section">
      <div className="container">
        <span className="badge">Услуги</span>
        <h1 className="section-title">Комплексные digital-решения для лидеров</h1>
        <p className="section-lead">
          Мы создаём индивидуальные программы, которые трансформируют операционную модель бизнеса и
          укрепляют конкурентоспособность.
        </p>
        <div className="service-grid" style={{ marginTop: 36 }}>
          {services.map((service) => (
            <motion.div
              key={service.title}
              className="service-card"
              whileHover={{ translateY: -10 }}
              transition={{ duration: 0.35 }}
            >
              <div className="service-card__header">
                <span className="service-card__badge">{service.badge}</span>
                <h3 className="feature-title">{service.title}</h3>
              </div>
              <p>{service.description}</p>
              <ul className="service-card__list">
                {service.capabilities.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <div className="process-steps">
          {processSteps.map((step, index) => (
            <motion.div
              key={step.title}
              className="process-step"
              whileHover={{ translateY: -6 }}
              transition={{ duration: 0.35 }}
            >
              <div className="process-step__number">{index + 1}</div>
              <h3 className="feature-title">{step.title}</h3>
              <p>{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </motion.div>
);

export default Services;