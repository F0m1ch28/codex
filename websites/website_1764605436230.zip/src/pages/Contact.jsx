import React from 'react';
import { motion } from 'framer-motion';

const Contact = () => (
  <motion.div
    className="page"
    initial={{ opacity: 0, y: 28 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -24 }}
    transition={{ duration: 0.6, ease: 'easeOut' }}
  >
    <section className="section">
      <div className="container">
        <span className="badge">Контакты</span>
        <h1 className="section-title">Давайте обсудим вашу стратегию роста</h1>
        <p className="section-lead">
          Оставьте заявку — и мы подготовим персонализированное предложение, основанное на данных и
          лучших практиках отрасли.
        </p>

        <div className="contact-grid" style={{ marginTop: 36 }}>
          <div className="contact-card">
            <div className="contact-item">
              <span className="contact-label">Адрес</span>
              <span className="contact-value">г. Москва, ул. Премьерская, д. 10, офис 21</span>
            </div>
            <div className="contact-item">
              <span className="contact-label">Телефон</span>
              <a className="contact-value" href="tel:+79990000000">
                +7 (999) 000-00-00
              </a>
            </div>
            <div className="contact-item">
              <span className="contact-label">E-mail</span>
              <a className="contact-value" href="mailto:hello@company.ru">
                hello@company.ru
              </a>
            </div>
            <div className="contact-item">
              <span className="contact-label">Часы работы</span>
              <span>понедельник — пятница, 09:00–19:00 (MSK)</span>
            </div>
          </div>

          <form className="contact-form" aria-label="Форма обратной связи">
            <label htmlFor="name">
              Имя и фамилия
              <input type="text" id="name" name="name" placeholder="Иван Иванов" required />
            </label>
            <label htmlFor="email">
              Рабочий e-mail
              <input
                type="email"
                id="email"
                name="email"
                placeholder="name@company.ru"
                autoComplete="email"
                required
              />
            </label>
            <label htmlFor="company">
              Компания
              <input type="text" id="company" name="company" placeholder="Название организации" />
            </label>
            <label htmlFor="topic">
              Интересующий вопрос
              <select id="topic" name="topic" defaultValue="">
                <option value="" disabled>
                  Выберите тему
                </option>
                <option value="digital">Цифровая трансформация</option>
                <option value="product">Продуктовая разработка</option>
                <option value="data">Аналитика и AI</option>
                <option value="security">Кибербезопасность</option>
                <option value="other">Другое</option>
              </select>
            </label>
            <label htmlFor="message">
              Сообщение
              <textarea
                id="message"
                name="message"
                placeholder="Опишите вашу задачу или проект"
                rows="4"
                required
              ></textarea>
            </label>
            <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
              Отправить запрос
            </button>
          </form>
        </div>

        <div className="contact-map" style={{ marginTop: 36 }}>
          <iframe
            title="Офис компании"
            src="https://yandex.com/map-widget/v1/?um=constructor%3A13b6177180470b1b848a1e6f724296f390c96934616c7964d7e74eb54834bbb3&amp;source=constructor"
            width="100%"
            height="360"
            frameBorder="0"
            loading="lazy"
            style={{ border: 'none' }}
          ></iframe>
        </div>
      </div>
    </section>
  </motion.div>
);

export default Contact;