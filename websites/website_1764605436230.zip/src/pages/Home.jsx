import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const heroStats = [
  { value: '15+', label: 'лет опыта в цифровой трансформации' },
  { value: '240%', label: 'рост эффективности клиентов' },
  { value: '75+', label: 'международных проектов в портфеле' }
];

const featureBlocks = [
  {
    title: 'Стратегия и архитектура',
    description:
      'Формируем технологическую стратегию, управляем цифровым портфелем и создаём архитектуру решений с учётом будущего роста.',
    icon: '⚙️'
  },
  {
    title: 'Продуктовый дизайн',
    description:
      'Проектируем бесшовный клиентский путь, строим дизайн-системы и создаём цифровые продукты с фокусом на результаты.',
    icon: '🎨'
  },
  {
    title: 'Аналитика и автоматизация',
    description:
      'Внедряем сквозную аналитику, автоматизируем процессы на базе данных, внедряем BI и ML-решения.',
    icon: '📊'
  }
];

const highlights = [
  {
    title: 'Консалтинг нового уровня',
    description:
      'Интегрируем стратегию, технологии и организационную культуру, чтобы обеспечить устойчивый рост и гибкость бизнеса.',
    points: [
      'Продвинутая оценка цифровой зрелости',
      'Межфункциональные команды и кросс-индустриальный опыт',
      'Гибридные модели реализации проектов'
    ]
  },
  {
    title: 'Технологии без компромиссов',
    description:
      'Используем cloud-native архитектуру, микросервисы и современные фреймворки. Создаём масштабируемые экосистемы.',
    points: [
      'CI/CD пайплайны и автоматизированное тестирование',
      'Безопасность по стандартам ISO 27001',
      'Сертифицированные эксперты по Azure, AWS и GCP'
    ]
  }
];

const testimonials = [
  {
    quote:
      'Команда компании не просто разработала цифровой сервис, а выстроила новую модель взаимодействия с клиентами. Мы получили рост NPS на 42%.',
    author: 'Елена Морозова, директор по цифровой трансформации, Titan Group'
  },
  {
    quote:
      'За счёт комплексного подхода мы автоматизировали бэк-офис и сократили операционные издержки на 37% за первый год.',
    author: 'Андрей Климов, COO, InnoBank'
  }
];

const Home = () => (
  <motion.div
    className="page"
    initial={{ opacity: 0, y: 28 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -24 }}
    transition={{ duration: 0.6, ease: 'easeOut' }}
  >
    <section className="hero">
      <div className="container">
        <div className="hero-content">
          <span className="badge">Цифровые стратегии будущего</span>
          <h1 className="hero-title">
            Премиальные решения для лидеров, которые формируют новое завтра
          </h1>
          <p className="hero-description">
            Мы соединяем стратегию, дизайн и технологическую экспертизу, чтобы создавать
            экосистемы, ускоряющие рост вашего бизнеса и раскрывающие потенциал команд.
          </p>
          <div className="btn-group">
            <Link to="/contact" className="btn btn-primary">
              Запланировать консультацию
            </Link>
            <Link to="/services" className="btn btn-secondary">
              Изучить услуги
            </Link>
          </div>
          <div className="hero-stats" aria-label="Ключевые показатели компании">
            {heroStats.map((stat) => (
              <div key={stat.label} className="stat-card">
                <div className="stat-value">{stat.value}</div>
                <div className="stat-label">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>

    <section className="section section--light">
      <div className="container">
        <h2 className="section-title">Интеллект, скорость, масштаб</h2>
        <p className="section-lead">
          Мы сопровождаем компании на всех стадиях цифрового развития: от стратегии до внедрения
          решений, которые меняют правила игры.
        </p>
        <div className="features-grid" role="list">
          {featureBlocks.map((feature) => (
            <motion.div
              key={feature.title}
              className="feature-card"
              role="listitem"
              whileHover={{ y: -6 }}
              transition={{ duration: 0.4, ease: 'easeOut' }}
            >
              <div className="feature-icon" aria-hidden="true">
                {feature.icon}
              </div>
              <h3 className="feature-title">{feature.title}</h3>
              <p>{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        {highlights.map((highlight) => (
          <motion.div
            className="glass-card"
            key={highlight.title}
            whileHover={{ translateY: -6 }}
            transition={{ duration: 0.45, ease: 'easeOut' }}
          >
            <h3 className="feature-title">{highlight.title}</h3>
            <p style={{ marginBottom: 18 }}>{highlight.description}</p>
            <ul className="service-card__list">
              {highlight.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </section>

    <section className="section section--alt">
      <div className="container text-contrast">
        <span className="decor-pill">Доверие лидеров рынка</span>
        <h2 className="section-title">Результаты, подтверждённые бизнесом</h2>
        <p className="section-lead" style={{ color: 'rgba(255, 255, 255, 0.76)' }}>
          Наши проекты упрощают сложное, создают новый пользовательский опыт и повышают эффективность
          процессов.
        </p>
        <div className="features-grid">
          {testimonials.map((testimonial) => (
            <motion.blockquote
              key={testimonial.author}
              className="feature-card"
              style={{ background: 'rgba(5, 11, 26, 0.9)', color: '#FFFFFF' }}
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
            >
              <p style={{ marginBottom: 16, fontSize: 18, lineHeight: 1.7 }}>
                “{testimonial.quote}”
              </p>
              <cite style={{ fontStyle: 'normal', color: 'rgba(255,255,255,0.68)' }}>
                {testimonial.author}
              </cite>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className="cta-banner">
          <div className="cta-banner__content">
            <div>
              <h3 className="section-title text-contrast">
                Включите ваш бизнес в режим экспоненциального роста
              </h3>
              <p style={{ color: 'rgba(255,255,255,0.82)', fontSize: 18 }}>
                Наши архитекторы и продуктовые команды готовы провести аудит и предложить дорожную
                карту трансформации за 10 рабочих дней.
              </p>
            </div>
            <div className="btn-group">
              <Link to="/contact" className="btn btn-primary">
                Получить предложение
              </Link>
              <Link to="/about" className="btn btn-secondary" style={{ color: '#FFFFFF' }}>
                Узнать о команде
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  </motion.div>
);

export default Home;