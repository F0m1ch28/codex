import React from 'react';
import { motion } from 'framer-motion';

const milestones = [
  {
    year: '2009',
    title: 'Основание компании',
    description:
      'Мы начали как небольшая команда стратегов и разработчиков, объединённых идеей строить цифровые решения нового уровня.'
  },
  {
    year: '2014',
    title: 'Международные проекты',
    description:
      'Расширили портфель за счёт международных партнёрств и вывели продукты на рынки Европы и Ближнего Востока.'
  },
  {
    year: '2018',
    title: 'Фокус на аналитике и AI',
    description:
      'Создали центр компетенций по Data Science и внедрили решения на базе машинного обучения и прогнозной аналитики.'
  },
  {
    year: '2023',
    title: 'Экосистемный подход',
    description:
      'Перешли к интегрированным цифровым экосистемам и комплексному управлению продуктовыми ландшафтами клиентов.'
  }
];

const teamMembers = [
  {
    name: 'Александр Дьяков',
    role: 'Генеральный директор',
    bio: '15 лет опыта в стратегическом консалтинге и цифровой трансформации крупных корпораций.',
    photo:
      'https://images.pexels.com/photos/532220/pexels-photo-532220.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    name: 'Мария Кочеткова',
    role: 'Директор по продукту',
    bio: 'Руководит разработкой цифровых платформ, отвечает за клиентскую ценность и инновации.',
    photo:
      'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    name: 'Игорь Ковалев',
    role: 'Технический директор',
    bio: 'Эксперт в архитектуре, DevOps и кибербезопасности. Управляет инженерными командами.',
    photo:
      'https://images.pexels.com/photos/3777940/pexels-photo-3777940.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    name: 'Екатерина Руднева',
    role: 'Руководитель аналитики',
    bio: 'Разрабатывает data-driven подходы, курирует проекты BI и машинного обучения.',
    photo:
      'https://images.pexels.com/photos/3760855/pexels-photo-3760855.jpeg?auto=compress&cs=tinysrgb&w=800'
  }
];

const About = () => (
  <motion.div
    className="page"
    initial={{ opacity: 0, y: 28 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -24 }}
    transition={{ duration: 0.6, ease: 'easeOut' }}
  >
    <section className="section">
      <div className="container">
        <span className="badge">О компании</span>
        <h1 className="section-title">Мы создаём цифровое будущее без компромиссов</h1>
        <p className="section-lead">
          Наша миссия — помогать компаниям ускорять рост и трансформироваться благодаря смелым
          стратегиям, технологическим инновациям и безупречной реализации.
        </p>
      </div>
    </section>

    <section className="section section--light">
      <div className="container">
        <div className="glass-card">
          <h2 className="feature-title">Миссия</h2>
          <p>
            Мы делаем сложное простым, создавая устойчивые цифровые экосистемы, которые расширяют
            возможности бизнеса и открывают новые источники ценности.
          </p>
        </div>
        <div className="features-grid" style={{ marginTop: 32 }}>
          <div className="feature-card">
            <div className="feature-icon">🚀</div>
            <h3 className="feature-title">Видение</h3>
            <p>
              Быть стратегическим партнёром для компаний, определяющих индустриальные стандарты
              завтрашнего дня, и задавать темп цифровых инноваций.
            </p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🤝</div>
            <h3 className="feature-title">Ценности</h3>
            <p>
              Прозрачность в сотрудничестве, технологическая экспертиза, ориентация на результат и
              забота об устойчивом развитии клиентов.
            </p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🌐</div>
            <h3 className="feature-title">Команда</h3>
            <p>
              Мультидисциплинарные команды, объединяющие стратегов, дизайнеров, инженеров и
              аналитиков с международным опытом.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <h2 className="section-title">Ключевые этапы развития</h2>
        <p className="section-lead">
          Мы растём вместе с нашими клиентами, постоянно расширяя компетенции и внедряя новые
          практики.
        </p>
        <div className="timeline-grid" style={{ marginTop: 36 }}>
          {milestones.map((milestone) => (
            <motion.div
              key={milestone.year}
              className="timeline-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.35 }}
            >
              <div className="timeline-year">{milestone.year}</div>
              <h3 className="feature-title">{milestone.title}</h3>
              <p>{milestone.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <section className="section section--light">
      <div className="container">
        <h2 className="section-title">Лидерская команда</h2>
        <p className="section-lead">
          Мы объединяем экспертизу из консалтинга, АИ, разработки и бизнес-управления, чтобы
          формировать долгосрочные партнёрства.
        </p>
        <div className="team-grid" style={{ marginTop: 36 }}>
          {teamMembers.map((member) => (
            <motion.div
              key={member.name}
              className="team-card"
              whileHover={{ y: -8 }}
              transition={{ duration: 0.35 }}
            >
              <img src={member.photo} alt={member.name} className="team-avatar" loading="lazy" />
              <div className="team-role">{member.role}</div>
              <h3 className="feature-title">{member.name}</h3>
              <p className="team-bio">{member.bio}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </motion.div>
);

export default About;