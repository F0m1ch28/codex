import React, { useEffect } from 'react';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import Terms from './pages/Terms';
import NotFound from './pages/NotFound';
import { LanguageProvider } from './context/LanguageContext';

const LanguageSync = () => {
  const location = useLocation();
  useEffect(() => {
    if (location.search.includes('lang=es-AR')) {
      localStorage.setItem('tph-language', 'es');
    }
  }, [location]);
  return null;
};

const AppRoutes = () => (
  <Routes>
    <Route element={<Layout />}>
      <Route index element={<Home />} />
      <Route path="/inflation" element={<Inflation />} />
      <Route path="/course" element={<Course />} />
      <Route path="/resources" element={<Resources />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/thank-you" element={<ThankYou />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/cookies" element={<Cookies />} />
      <Route path="/terms" element={<Terms />} />
      <Route path="*" element={<NotFound />} />
    </Route>
  </Routes>
);

const App = () => {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <LanguageSync />
        <AppRoutes />
      </BrowserRouter>
    </LanguageProvider>
  );
};

export default App;