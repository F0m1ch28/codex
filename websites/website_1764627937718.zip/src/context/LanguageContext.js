import React, { createContext, useContext, useMemo, useState } from 'react';

const LanguageContext = createContext();

const translations = {
  en: {
    brand: 'Tu Progreso Hoy',
    nav: {
      home: 'Home',
      inflation: 'Inflation Lab',
      course: 'Course',
      resources: 'Resources',
      contact: 'Contact',
      privacy: 'Privacy',
      cookies: 'Cookies',
      terms: 'Terms of Service'
    },
    common: {
      language: 'Language',
      accept: 'Accept',
      decline: 'Decline',
      close: 'Close',
      readMore: 'Read more',
      learnMore: 'Learn more',
      confirm: 'Confirm subscription',
      confirmCheckbox: 'I confirm I clicked the link in the verification email',
      pendingTitle: 'Please confirm your email',
      pendingSubtitle: 'We sent a verification email. Confirm it to finish the subscription.',
      confirmed: 'Your subscription is confirmed.',
      submit: 'Submit',
      sendMessage: 'Send message',
      loading: 'Loading…',
      error: 'Something went wrong. Please try again.',
      optional: 'Optional field',
      nameLabel: 'Full name',
      emailLabel: 'Email',
      phoneLabel: 'Phone (optional)',
      messageLabel: 'Message',
      courseInterestLabel: 'Course focus',
      budgetLabel: 'Monthly budget range',
      thankYouLink: 'Back to homepage'
    },
    cookieBanner: {
      title: 'Cookies for a smarter experience',
      message:
        'We use cookies to measure engagement, improve accessibility, and remember your language preference. You can change your decision anytime in the Cookies Policy.'
    },
    disclaimer: {
      title: 'We do not provide financial services',
      messageEn:
        'Tu Progreso Hoy is an educational platform with curated data insights. We do not execute financial transactions or offer investment advice.',
      messageEs:
        'Tu Progreso Hoy es una plataforma educativa con datos esenciales. No brindamos asesoría financiera directa.',
      messageRu:
        'Tu Progreso Hoy — это образовательная платформа. Мы не оказываем финансовых услуг и не даём инвестиционных советов.'
    },
    footer: {
      tagline: 'Measured decisions for Argentina’s dynamic economy.',
      addressLabel: 'Visit us',
      contactLabel: 'Contact',
      socialLabel: 'Stay connected',
      rights: 'All rights reserved.',
      statement: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
    },
    home: {
      metaTitle: 'Tu Progreso Hoy | Inflation Insights & Personal Finance Course',
      metaDescription:
        'Bilingual platform combining ARS→USD data, inflation dashboards, and a starter finance course built for Argentina.',
      heroEyebrow: 'Argentina • Inflation Classroom',
      heroTitle: 'Navigate inflation with clarity and confidence',
      heroSubtitle:
        'Our premium learning journey blends real-time ARS→USD analytics with guided lessons so every plan stays grounded in verified market signals.',
      heroPrimaryCta: 'Explore methodology',
      heroSecondaryCta: 'See course overview',
      promisesTitle: 'Key promises for your daily planning',
      promisesSubtitle:
        'We combine live-market data, weekly narratives, and concise lessons so you can interpret Argentina’s inflation story with precision.',
      promisesItems: [
        {
          title: 'Trusted market signals',
          description:
            'Up-to-date CPI mixes, trusted FX sources, and context aligned with household budgets.',
          statement: 'Datos verificados para planificar tu presupuesto.'
        },
        {
          title: 'Clear decision framing',
          description:
            'Scenario templates designed to connect price trends with your financial ambitions.',
          statement: 'Decisiones responsables, objetivos nítidos.'
        },
        {
          title: 'Trend-led knowledge',
          description:
            'Video explainers and worksheets powered by weekly datasets, so learning never feels abstract.',
          statement: 'Conocimiento financiero impulsado por tendencias.'
        },
        {
          title: 'Future-ready moves',
          description:
            'Apply the methodology to your monthly check-ins for steady, well-informed adjustments.',
          statement: 'Pasos acertados hoy, mejor futuro mañana.'
        }
      ],
      trackerTitle: 'ARS to USD live tracker',
      trackerSubtitle:
        'Monitor daily FX movements together with short-term variance. See how the peso evolves and adjust your plan deliberately.',
      trackerBadge: 'Live data',
      insightsTitle: 'Insights snapshot',
      insightsSubtitle:
        'Practical takeaways from this week’s blended CPI for urban Argentina.',
      insightCards: [
        {
          title: 'Transparent analysis',
          description:
            'Weekly briefs tie inflation shocks to grocery, rent, and transport realities.',
          statement: 'Análisis transparentes y datos de mercado para decidir con seguridad.'
        },
        {
          title: 'Reliable information',
          description:
            'Each graph references official time series and curated independent monitors.',
          statement: 'Información confiable que respalda elecciones responsables sobre tu dinero.'
        }
      ],
      galleryTitle: 'Inside the Tu Progreso Hoy lab',
      gallerySubtitle: 'From collaborative classrooms to data dashboards supporting better judgement.',
      testimonialsTitle: 'Learners building confident money habits',
      testimonials: [
        {
          name: 'María Eugenia L.',
          title: 'Operations Lead, Buenos Aires',
          quote:
            '“The dual-language lessons plus actionable datasets finally let me align decisions with real ARS volatility.”'
        },
        {
          name: 'Diego P.',
          title: 'Emerging entrepreneur',
          quote:
            '“Modules are crisp, charts are interactive, and I can review each trend before adjusting my savings path.”'
        }
      ],
      statementsTitle: 'Guiding principles that stay with you',
      statementsSubtitle:
        'Spanish statements remain at the heart of our promise—each one frames our methodology.',
      statements: [
        'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
      ],
      trialTitle: 'Request your free trial lesson',
      trialSubtitle:
        'Start with our bilingual primer and receive guided instructions to access the platform.',
      trialSuccess:
        'Thank you for confirming! Your onboarding kit is on its way and you will be redirected.',
      secondaryStatement: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
    },
    inflation: {
      metaTitle: 'Inflation Lab | Tu Progreso Hoy',
      metaDescription:
        'Discover the methodology behind our CPI & FX dashboards, review interactive charts, and learn how we contextualize ARS volatility.',
      heroEyebrow: 'Inflation Lab',
      heroTitle: 'Methodology, charts, and CPI/FX context in one workspace',
      heroSubtitle:
        'Dive into how we blend official statistics, independent sources, and qualitative narratives so your budgeting mirrors Argentina’s reality.',
      methodTitle: 'Our methodology',
      methodParagraphs: [
        'Tu Progreso Hoy triangulates INDEC publications, reputable private panels, and crowdsourced price checks to surface realistic CPI scenarios.',
        'Datasets are recalibrated weekly to highlight seasonal adjustments, tariff shifts, and peso-dollar spreads that affect everyday expenses.'
      ],
      methodListTitle: 'Core pillars',
      methodList: [
        'Transparent sourcing and reproducible calculations',
        'Dual-language narrative summaries to support inclusive learning',
        'Scenario planning templates aligned with student and family budgets'
      ],
      chartTitle: 'CPI and ARS→USD dynamics',
      chartSubtitle:
        'Interactive charts compare headline CPI, core CPI, and FX evolution. Hover for exact monthly variances.',
      statsTitle: 'Contextual checkpoints',
      stats: [
        {
          title: 'FX variance alert',
          description:
            'We flag peso-dollar deviations above 4% week-on-week so you can revisit FX exposure plans in time.'
        },
        {
          title: 'CPI cluster insight',
          description:
            'Housing, transportation, and food categories are weighted according to Buenos Aires household surveys.'
        },
        {
          title: 'Scenario packs',
          description:
            'Downloadable spreadsheets allow you to plug individual expenses and stress-test against our baseline curves.'
        }
      ],
      faqTitle: 'Frequently asked questions'
    },
    course: {
      metaTitle: 'Course Overview | Tu Progreso Hoy',
      metaDescription:
        'Review the Tu Progreso Hoy syllabus, modules, and learning journey built for Argentina’s inflation landscape.',
      heroEyebrow: 'Learning pathway',
      heroTitle: 'A bilingual course to decode inflation and strengthen judgment',
      heroSubtitle:
        'Structured modules transform data into practical decisions. Every lesson is anchored in the latest ARS context and real-life cases.',
      modulesTitle: 'Syllabus at a glance',
      modules: [
        {
          title: 'Module 1 · Inflation fundamentals',
          description:
            'Understand CPI construction, peso dynamics, and why official and unofficial numbers diverge.'
        },
        {
          title: 'Module 2 · Data to decisions',
          description:
            'Translate dashboards into actionable weekly checklists, with worksheets in both languages.'
        },
        {
          title: 'Module 3 · Scenario design',
          description:
            'Build conservative, moderate, and stretch plans that adapt to FX swings and price shocks.'
        },
        {
          title: 'Module 4 · Personal finance practice',
          description:
            'Connect budgeting basics, savings priorities, and risk awareness tailored to Argentina.'
        }
      ],
      audienceTitle: 'Built for these learners',
      audienceList: [
        'Young professionals aligning peso income with USD-linked goals',
        'Families planning monthly budgets amid shifting tariffs',
        'Entrepreneurs tracking inventory costs and FX exposure'
      ],
      audienceStatement: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      ctaTitle: 'Your next lesson is a confirmation away',
      ctaSubtitle:
        'Request the free trial lesson and complete the double opt-in email to secure access.',
      ctaPrimary: 'Request trial',
      ctaSecondary: 'Download syllabus PDF',
      highlight: 'Información confiable que respalda elecciones responsables sobre tu dinero.'
    },
    resources: {
      metaTitle: 'Resources & Glossary | Tu Progreso Hoy',
      metaDescription:
        'Dive into curated articles, bilingual glossaries, and study aids supporting Argentina-focused personal finance learning.',
      heroEyebrow: 'Resource hub',
      heroTitle: 'Articles, glossaries, and in-session tools',
      heroSubtitle:
        'Stay current with short bilingual articles and keep crucial concepts at hand while reviewing the dashboards.',
      articlesTitle: 'Latest articles',
      articles: [
        {
          titleEn: 'How ARS volatility shapes grocery planning',
          titleEs: 'Cómo la volatilidad del peso impacta tu lista del súper',
          summaryEn:
            'Blend weekly CPI data with store-level checks before renewing household budgets.',
          summaryEs:
            'Cruza el IPC semanal con relevamientos de comercios para ajustar el presupuesto familiar.',
          image: 'https://picsum.photos/400/300?image=701'
        },
        {
          titleEn: 'Align savings goals with blended CPI',
          titleEs: 'Alinea tus metas de ahorro con el IPC combinado',
          summaryEn:
            'Use our scenario templates to keep peso and USD projections in sync.',
          summaryEs:
            'Usa nuestras plantillas para sostener proyecciones en pesos y dólares.',
          image: 'https://picsum.photos/400/300?image=702'
        }
      ],
      glossaryTitle: 'Glossary essentials',
      glossary: [
        {
          term: 'Blended CPI (Índice combinado)',
          definition:
            'Weighted indicator merging official INDEC data with private panels to capture fast-moving price shifts.'
        },
        {
          term: 'ARS→USD corridor (Corredor ARS→USD)',
          definition:
            'Reference band used to monitor peso-dollar evolution and trigger scenario adjustments.'
        },
        {
          term: 'Price bands (Bandas de precios)',
          definition:
            'Range mapping technique for essentials like food and transport, reflecting weekly volatility.'
        }
      ],
      statement: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
    },
    contact: {
      metaTitle: 'Contact | Tu Progreso Hoy',
      metaDescription:
        'Connect with Tu Progreso Hoy in Buenos Aires, request information, and complete double opt-in messaging.',
      heroEyebrow: 'Contact & map',
      heroTitle: 'We are based in Buenos Aires and ready to guide your onboarding',
      heroSubtitle:
        'Reach out in English or Spanish. Confirm your email to receive the welcome checklist and onboarding calendar.',
      officeTitle: 'Our location',
      officeDescription:
        'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina · Monday to Friday 9:00 - 18:00 (ART).',
      connectTitle: 'Write to the team',
      successMessage: 'Thank you! After confirming your email we will reply within one business day.'
    },
    thankYou: {
      metaTitle: 'Thank you | Tu Progreso Hoy',
      heroTitle: 'Thank you for confirming your interest',
      heroSubtitle:
        'Your onboarding kit is on its way. Explore more resources or revisit the dashboards anytime.',
      button: 'Return home'
    },
    privacy: {
      metaTitle: 'Privacy Policy | Tu Progreso Hoy',
      heroTitle: 'Privacy Policy',
      updated: 'Last updated: June 2024',
      sections: [
        {
          title: '1. Data we collect',
          content:
            'We collect identification data (name, email, language preference), engagement analytics, and form submissions required for double opt-in.'
        },
        {
          title: '2. How we use your data',
          content:
            'Data powers onboarding emails, product updates, aggregated analytics, and language personalisation.'
        },
        {
          title: '3. Legal basis',
          content:
            'Processing is based on consent (double opt-in) and legitimate interest in delivering educational services.'
        },
        {
          title: '4. Data sharing',
          content:
            'We do not sell personal data. Providers for analytics and email delivery process data under strict contracts.'
        },
        {
          title: '5. Your rights',
          content:
            'You can request access, rectification, deletion, or portability by emailing privacidad@tuprogresohoy.com.'
        }
      ]
    },
    cookiesPage: {
      metaTitle: 'Cookies Policy | Tu Progreso Hoy',
      heroTitle: 'Cookies Policy',
      intro:
        'Cookies help us deliver a tailored, accessible learning experience. This policy explains how we use them.',
      sections: [
        {
          title: 'Essential cookies',
          content:
            'Remember language preferences and session security. Required for platform functionality.'
        },
        {
          title: 'Analytics cookies',
          content:
            'Measure module completion rates and page performance to improve the course. We only activate these with your consent.'
        },
        {
          title: 'Managing cookies',
          content:
            'Use browser settings or our banner controls to revise consent at any moment.'
        }
      ]
    },
    terms: {
      metaTitle: 'Terms of Service | Tu Progreso Hoy',
      heroTitle: 'Terms of Service',
      intro:
        'These terms govern the use of Tu Progreso Hoy, our learning modules, and contextual data dashboards.',
      sections: [
        {
          title: 'Educational purpose',
          content:
            'Content is for educational use only. We provide information, not financial services or direct investment recommendations.'
        },
        {
          title: 'Account responsibilities',
          content:
            'Users must maintain accurate contact details and safeguard access credentials.'
        },
        {
          title: 'Intellectual property',
          content:
            'Course materials, datasets, and visuals are owned by Tu Progreso Hoy and licensed for enrolled learners.'
        },
        {
          title: 'Limitation of liability',
          content:
            'We are not liable for financial decisions taken based on our educational content.'
        }
      ]
    },
    notFound: {
      metaTitle: 'Page not found | Tu Progreso Hoy',
      title: 'Page not found',
      subtitle: 'The page you are looking for might have been moved or archived.',
      button: 'Go home'
    }
  },
  es: {
    brand: 'Tu Progreso Hoy',
    nav: {
      home: 'Inicio',
      inflation: 'Laboratorio de Inflación',
      course: 'Curso',
      resources: 'Recursos',
      contact: 'Contacto',
      privacy: 'Privacidad',
      cookies: 'Cookies',
      terms: 'Términos de servicio'
    },
    common: {
      language: 'Idioma',
      accept: 'Aceptar',
      decline: 'Rechazar',
      close: 'Cerrar',
      readMore: 'Leer más',
      learnMore: 'Conocer más',
      confirm: 'Confirmar suscripción',
      confirmCheckbox: 'Confirmo que hice clic en el enlace del correo de verificación',
      pendingTitle: 'Confirma tu correo',
      pendingSubtitle: 'Enviamos un correo de verificación. Confírmalo para finalizar la suscripción.',
      confirmed: 'Tu suscripción está confirmada.',
      submit: 'Enviar',
      sendMessage: 'Enviar mensaje',
      loading: 'Cargando…',
      error: 'Ocurrió un error. Intenta nuevamente.',
      optional: 'Campo opcional',
      nameLabel: 'Nombre completo',
      emailLabel: 'Correo electrónico',
      phoneLabel: 'Teléfono (opcional)',
      messageLabel: 'Mensaje',
      courseInterestLabel: 'Enfoque del curso',
      budgetLabel: 'Rango de presupuesto mensual',
      thankYouLink: 'Volver al inicio'
    },
    cookieBanner: {
      title: 'Cookies para una experiencia inteligente',
      message:
        'Usamos cookies para medir interacción, mejorar la accesibilidad y recordar tu preferencia de idioma. Puedes cambiar tu decisión en cualquier momento desde la Política de Cookies.'
    },
    disclaimer: {
      title: 'No brindamos servicios financieros',
      messageEn:
        'Tu Progreso Hoy es una plataforma educativa con datos seleccionados. No ejecutamos transacciones ni prestamos asesoramiento financiero.',
      messageEs:
        'Tu Progreso Hoy es una plataforma educativa con datos esenciales. No brindamos asesoría financiera directa.',
      messageRu:
        'Tu Progreso Hoy — это образовательная платформа. Мы не оказываем финансовых услуг и не даём инвестиционных советов.'
    },
    footer: {
      tagline: 'Decisiones medidas para la economía dinámica de Argentina.',
      addressLabel: 'Visítanos',
      contactLabel: 'Contacto',
      socialLabel: 'Redes y comunidad',
      rights: 'Todos los derechos reservados.',
      statement: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
    },
    home: {
      metaTitle: 'Tu Progreso Hoy | Insights de inflación y curso financiero',
      metaDescription:
        'Plataforma bilingüe con datos ARS→USD, tableros de inflación y curso inicial de finanzas personales para Argentina.',
      heroEyebrow: 'Argentina • Aula de Inflación',
      heroTitle: 'Navega la inflación con claridad y confianza',
      heroSubtitle:
        'Un recorrido premium que combina analíticas ARS→USD en tiempo real con lecciones guiadas para que cada plan se base en señales verificadas.',
      heroPrimaryCta: 'Explorar metodología',
      heroSecondaryCta: 'Ver itinerario del curso',
      promisesTitle: 'Promesas clave para tu planificación diaria',
      promisesSubtitle:
        'Integramos datos del mercado, relatos semanales y lecciones concisas para interpretar la inflación argentina con precisión.',
      promisesItems: [
        {
          title: 'Señales confiables',
          description:
            'CPI actualizado, fuentes FX de confianza y contexto alineado con presupuestos reales.',
          statement: 'Datos verificados para planificar tu presupuesto.'
        },
        {
          title: 'Marcos claros',
          description:
            'Plantillas de escenarios que conectan tendencias de precios con tus objetivos financieros.',
          statement: 'Decisiones responsables, objetivos nítidos.'
        },
        {
          title: 'Tendencias que educan',
          description:
            'Videos y guías impulsados por datos semanales para que el aprendizaje sea concreto.',
          statement: 'Conocimiento financiero impulsado por tendencias.'
        },
        {
          title: 'Acciones futuras',
          description:
            'Aplica la metodología a tus revisiones mensuales y ajusta con información confiable.',
          statement: 'Pasos acertados hoy, mejor futuro mañana.'
        }
      ],
      trackerTitle: 'Monitor ARS a USD en vivo',
      trackerSubtitle:
        'Sigue los movimientos diarios y el desvío de corto plazo. Observa la evolución del peso y ajusta tu plan con responsabilidad.',
      trackerBadge: 'Datos en vivo',
      insightsTitle: 'Instantáneas de insight',
      insightsSubtitle:
        'Conclusiones prácticas del CPI combinado para el Área Metropolitana de Buenos Aires.',
      insightCards: [
        {
          title: 'Análisis transparente',
          description:
            'Informes semanales conectan shocks inflacionarios con la realidad de alimentos, alquileres y transporte.',
          statement: 'Análisis transparentes y datos de mercado para decidir con seguridad.'
        },
        {
          title: 'Información confiable',
          description:
            'Cada gráfico referencia series oficiales y monitores independientes y verificados.',
          statement: 'Información confiable que respalda elecciones responsables sobre tu dinero.'
        }
      ],
      galleryTitle: 'Dentro del laboratorio Tu Progreso Hoy',
      gallerySubtitle: 'Aulas colaborativas y tableros que sostienen mejores decisiones.',
      testimonialsTitle: 'Personas que fortalecen sus hábitos financieros',
      testimonials: [
        {
          name: 'María Eugenia L.',
          title: 'Líder de Operaciones, Buenos Aires',
          quote:
            '“Las lecciones bilingües más los datos accionables me permiten alinear decisiones con la volatilidad real del peso.”'
        },
        {
          name: 'Diego P.',
          title: 'Emprendedor',
          quote:
            '“Los módulos son claros, los gráficos interactivos, y puedo revisar cada tendencia antes de ajustar mi ruta de ahorro.”'
        }
      ],
      statementsTitle: 'Principios guía que nos definen',
      statementsSubtitle:
        'Frases en español que sostienen nuestra promesa y enmarcan la metodología.',
      statements: [
        'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
      ],
      trialTitle: 'Solicita tu clase de prueba gratuita',
      trialSubtitle:
        'Recibe el primer módulo introductorio en ambos idiomas y sigue las instrucciones de acceso.',
      trialSuccess:
        '¡Gracias por confirmar! Tu kit de bienvenida está en camino y serás redirigido.',
      secondaryStatement: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
    },
    inflation: {
      metaTitle: 'Laboratorio de Inflación | Tu Progreso Hoy',
      metaDescription:
        'Conoce la metodología de nuestros tableros CPI y FX, explora gráficos interactivos y entiende cómo contextualizamos la volatilidad ARS.',
      heroEyebrow: 'Laboratorio de inflación',
      heroTitle: 'Metodología, gráficos y contexto CPI/FX en un mismo espacio',
      heroSubtitle:
        'Integramos estadísticas oficiales, fuentes privadas y relatos cualitativos para que tu presupuesto refleje la realidad argentina.',
      methodTitle: 'Nuestra metodología',
      methodParagraphs: [
        'Integramos informes de INDEC, paneles privados y relevamientos propios para construir escenarios CPI realistas.',
        'Recalibramos datasets cada semana para resaltar ajustes estacionales, cambios tarifarios y spreads peso-dólar que impactan gastos cotidianos.'
      ],
      methodListTitle: 'Pilares centrales',
      methodList: [
        'Fuentes transparentes y cálculos reproducibles',
        'Resúmenes narrativos bilingües que facilitan la inclusión',
        'Plantillas de planificación alineadas con presupuestos familiares y estudiantiles'
      ],
      chartTitle: 'Dinámica CPI y ARS→USD',
      chartSubtitle:
        'Gráficos interactivos comparan CPI general, CPI núcleo y evolución FX. Pasa el cursor para ver las variaciones exactas.',
      statsTitle: 'Puntos de control',
      stats: [
        {
          title: 'Alerta de variación FX',
          description:
            'Señalamos desvíos semanales superiores al 4% para que revises tu exposición cambiaria a tiempo.'
        },
        {
          title: 'Cluster CPI',
          description:
            'Las ponderaciones de vivienda, transporte y alimentos responden a encuestas del AMBA.'
        },
        {
          title: 'Paquetes de escenarios',
          description:
            'Hojas descargables para conectar tus gastos y testear contra nuestras curvas base.'
        }
      ],
      faqTitle: 'Preguntas frecuentes'
    },
    course: {
      metaTitle: 'Resumen del curso | Tu Progreso Hoy',
      metaDescription:
        'Revisa el programa de Tu Progreso Hoy, sus módulos y el recorrido de aprendizaje diseñado para la inflación argentina.',
      heroEyebrow: 'Ruta de aprendizaje',
      heroTitle: 'Curso bilingüe para decodificar la inflación y fortalecer el criterio',
      heroSubtitle:
        'Módulos estructurados transforman datos en decisiones prácticas. Cada lección se apoya en el contexto ARS más reciente.',
      modulesTitle: 'Programa de estudio',
      modules: [
        {
          title: 'Módulo 1 · Fundamentos de inflación',
          description:
            'Comprende la construcción del CPI, la dinámica del peso y por qué difieren los indicadores.'
        },
        {
          title: 'Módulo 2 · Datos a decisiones',
          description:
            'Traduce tableros en listas semanales accionables con guías bilingües.'
        },
        {
          title: 'Módulo 3 · Diseño de escenarios',
          description:
            'Construye planes conservadores, moderados y ambiciosos ante cambios FX.'
        },
        {
          title: 'Módulo 4 · Práctica financiera personal',
          description:
            'Une presupuesto, ahorro y conciencia de riesgo adaptados a Argentina.'
        }
      ],
      audienceTitle: 'Pensado para',
      audienceList: [
        'Profesionales jóvenes que alinean ingresos en pesos con metas en USD',
        'Familias que planifican presupuestos ante ajustes tarifarios',
        'Emprendedores que vigilan costos de inventario y exposición FX'
      ],
      audienceStatement: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      ctaTitle: 'Tu próxima lección está a un paso',
      ctaSubtitle:
        'Solicita la clase de prueba y completa el doble opt-in para activar tu acceso.',
      ctaPrimary: 'Pedir clase de prueba',
      ctaSecondary: 'Descargar programa PDF',
      highlight: 'Información confiable que respalda elecciones responsables sobre tu dinero.'
    },
    resources: {
      metaTitle: 'Recursos y glosario | Tu Progreso Hoy',
      metaDescription:
        'Accede a artículos curados, glosarios bilingües y materiales de apoyo para las finanzas personales en Argentina.',
      heroEyebrow: 'Centro de recursos',
      heroTitle: 'Artículos, glosarios y herramientas',
      heroSubtitle:
        'Mantente al día con artículos breves y bilingües, y ten a mano los conceptos clave durante las sesiones.',
      articlesTitle: 'Últimos artículos',
      articles: [
        {
          titleEn: 'How ARS volatility shapes grocery planning',
          titleEs: 'Cómo la volatilidad del peso impacta tu lista del súper',
          summaryEn:
            'Blend weekly CPI data with store-level checks before renewing household budgets.',
          summaryEs:
            'Cruza el IPC semanal con relevamientos de comercios para ajustar el presupuesto familiar.',
          image: 'https://picsum.photos/400/300?image=701'
        },
        {
          titleEn: 'Align savings goals with blended CPI',
          titleEs: 'Alinea tus metas de ahorro con el IPC combinado',
          summaryEn:
            'Use our scenario templates to keep peso and USD projections in sync.',
          summaryEs:
            'Usa nuestras plantillas para sostener proyecciones en pesos y dólares.',
          image: 'https://picsum.photos/400/300?image=702'
        }
      ],
      glossaryTitle: 'Glosario esencial',
      glossary: [
        {
          term: 'Blended CPI (Índice combinado)',
          definition:
            'Indicador ponderado que fusiona datos oficiales y privados para captar cambios rápidos de precios.'
        },
        {
          term: 'Corredor ARS→USD',
          definition:
            'Banda de referencia para monitorear la evolución peso-dólar y activar ajustes de escenario.'
        },
        {
          term: 'Bandas de precios',
          definition:
            'Técnica que acota rangos para esenciales como alimentos y transporte considerando la volatilidad semanal.'
        }
      ],
      statement: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
    },
    contact: {
      metaTitle: 'Contacto | Tu Progreso Hoy',
      metaDescription:
        'Conecta con Tu Progreso Hoy en Buenos Aires, solicita información y completa el doble opt-in.',
      heroEyebrow: 'Contacto y mapa',
      heroTitle: 'Estamos en Buenos Aires, listos para guiar tu onboarding',
      heroSubtitle:
        'Escríbenos en inglés o español. Confirma tu correo para recibir el checklist de bienvenida y el calendario de acompañamiento.',
      officeTitle: 'Nuestra ubicación',
      officeDescription:
        'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina · Lunes a viernes de 9:00 a 18:00 (ART).',
      connectTitle: 'Escríbenos',
      successMessage:
        '¡Gracias! Tras confirmar tu correo responderemos en un día hábil.'
    },
    thankYou: {
      metaTitle: 'Gracias | Tu Progreso Hoy',
      heroTitle: 'Gracias por confirmar tu interés',
      heroSubtitle:
        'Tu kit de bienvenida está en camino. Explora más recursos o vuelve al laboratorio cuando quieras.',
      button: 'Volver al inicio'
    },
    privacy: {
      metaTitle: 'Política de privacidad | Tu Progreso Hoy',
      heroTitle: 'Política de privacidad',
      updated: 'Última actualización: Junio 2024',
      sections: [
        {
          title: '1. Datos recopilados',
          content:
            'Recopilamos nombre, correo, preferencia de idioma, analíticas de interacción y formularios necesarios para el doble opt-in.'
        },
        {
          title: '2. Uso de datos',
          content:
            'Utilizamos los datos para onboarding, novedades del producto, analíticas agregadas y personalización de idioma.'
        },
        {
          title: '3. Base legal',
          content:
            'Procesamos datos con tu consentimiento (doble opt-in) y por interés legítimo en brindar servicios educativos.'
        },
        {
          title: '4. Compartir datos',
          content:
            'No vendemos datos personales. Proveedores de analítica y email los procesan bajo acuerdos estrictos.'
        },
        {
          title: '5. Tus derechos',
          content:
            'Puedes solicitar acceso, rectificación, eliminación o portabilidad escribiendo a privacidad@tuprogresohoy.com.'
        }
      ]
    },
    cookiesPage: {
      metaTitle: 'Política de cookies | Tu Progreso Hoy',
      heroTitle: 'Política de cookies',
      intro:
        'Las cookies nos permiten ofrecer una experiencia de aprendizaje accesible y personalizada. Aquí explicamos su uso.',
      sections: [
        {
          title: 'Cookies esenciales',
          content:
            'Recuerdan preferencias de idioma y seguridad de sesión. Son necesarias para el funcionamiento de la plataforma.'
        },
        {
          title: 'Cookies analíticas',
          content:
            'Miden el avance en los módulos y el rendimiento del sitio. Solo se activan con tu consentimiento.'
        },
        {
          title: 'Gestión de cookies',
          content:
            'Utiliza la configuración del navegador o nuestro banner para revisar tu consentimiento en cualquier momento.'
        }
      ]
    },
    terms: {
      metaTitle: 'Términos de servicio | Tu Progreso Hoy',
      heroTitle: 'Términos de servicio',
      intro:
        'Estos términos regulan el uso de Tu Progreso Hoy, sus módulos educativos y tableros de datos.',
      sections: [
        {
          title: 'Propósito educativo',
          content:
            'El contenido es educativo. No ejecutamos servicios financieros ni recomendaciones de inversión.'
        },
        {
          title: 'Responsabilidades de la cuenta',
          content:
            'Debes mantener datos de contacto correctos y proteger tus credenciales de acceso.'
        },
        {
          title: 'Propiedad intelectual',
          content:
            'Los materiales, datasets y visuales pertenecen a Tu Progreso Hoy y se licencian a estudiantes inscritos.'
        },
        {
          title: 'Limitación de responsabilidad',
          content:
            'No somos responsables por decisiones financieras tomadas a partir de nuestro contenido educativo.'
        }
      ]
    },
    notFound: {
      metaTitle: 'Página no encontrada | Tu Progreso Hoy',
      title: 'Página no encontrada',
      subtitle: 'La página que buscas fue movida o archivada.',
      button: 'Ir al inicio'
    }
  }
};

const getNestedValue = (obj, path) => {
  return path.split('.').reduce((acc, key) => {
    if (acc && typeof acc === 'object' && key in acc) {
      return acc[key];
    }
    return undefined;
  }, obj);
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');

  const value = useMemo(() => {
    const t = (path) => {
      const valueInLang = getNestedValue(translations[language], path);
      if (valueInLang !== undefined) {
        return valueInLang;
      }
      const fallback = getNestedValue(translations.en, path);
      return fallback !== undefined ? fallback : path;
    };

    return {
      language,
      setLanguage,
      t,
      content: translations[language],
      translations
    };
  }, [language]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => useContext(LanguageContext);