import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Hero from '../components/Hero';
import ExchangeRateTracker from '../components/ExchangeRateTracker';
import ImageGallery from '../components/ImageGallery';
import DoubleOptInForm from '../components/DoubleOptInForm';
import { useLanguage } from '../context/LanguageContext';

const Home = () => {
  const { t, language } = useLanguage();
  const content = t('home');

  const galleryItems = [
    {
      src: 'https://picsum.photos/1200/600?image=100',
      alt: language === 'en' ? 'Hero analytics with Argentina flag overlay' : 'Hero de analíticas con bandera de Argentina',
      caption: language === 'en' ? 'Hero: Live dashboards + Argentina flag overlay' : 'Hero: Tableros en vivo con bandera argentina'
    },
    {
      src: 'https://picsum.photos/800/500?image=600',
      alt: language === 'en' ? 'Buenos Aires workspace' : 'Espacio de trabajo en Buenos Aires',
      caption: language === 'en' ? 'Buenos Aires workspace' : 'Espacio de trabajo BA'
    },
    {
      src: 'https://picsum.photos/400/300?image=701',
      alt: language === 'en' ? 'Data visualization session' : 'Sesión de visualización de datos',
      caption: language === 'en' ? 'Analytics huddle' : 'Reunión de analíticas'
    },
    {
      src: 'https://picsum.photos/400/300?image=702',
      alt: language === 'en' ? 'Course material review' : 'Revisión de materiales del curso',
      caption: language === 'en' ? 'Course workshop' : 'Taller del curso'
    }
  ];

  const promiseItems = content.promisesItems;
  const insightsCards = content.insightCards;

  return (
    <>
      <Helmet>
        <title>{t('home.metaTitle')}</title>
        <meta name="description" content={t('home.metaDescription')} />
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=100"
        eyebrow={<span aria-label="Argentina insights">{t('home.heroEyebrow')}</span>}
        title={t('home.heroTitle')}
        subtitle={t('home.heroSubtitle')}
        actions={[
          <Link key="primary" to="/inflation" className="btn btn--primary">
            {t('home.heroPrimaryCta')}
          </Link>,
          <Link key="secondary" to="/course" className="btn btn--ghost">
            {t('home.heroSecondaryCta')}
          </Link>
        ]}
      />
      <section className="section">
        <div className="container">
          <header className="section__header">
            <h2>{t('home.promisesTitle')}</h2>
            <p>{t('home.promisesSubtitle')}</p>
          </header>
          <div className="grid grid--two">
            {promiseItems.map((item) => (
              <article key={item.title} className="card">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <p style={{ fontWeight: 700, color: 'var(--color-primary)' }}>{item.statement}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="section section--tight" aria-labelledby="tracker">
        <div className="container">
          <header className="section__header" id="tracker">
            <h2>{t('home.trackerTitle')}</h2>
            <p>{t('home.trackerSubtitle')}</p>
          </header>
          <div className="grid">
            <ExchangeRateTracker />
          </div>
        </div>
      </section>
      <section className="section" style={{ background: 'rgba(226,232,240,0.35)' }}>
        <div className="container">
          <header className="section__header">
            <h2>{t('home.insightsTitle')}</h2>
            <p>{t('home.insightsSubtitle')}</p>
          </header>
          <div className="grid grid--two">
            {insightsCards.map((card) => (
              <article key={card.title} className="card">
                <h3>{card.title}</h3>
                <p>{card.description}</p>
                <p style={{ fontWeight: 600 }}>{card.statement}</p>
              </article>
            ))}
            <div className="card">
              <h3>{language === 'en' ? 'Snapshot from the lab' : 'Instantánea del laboratorio'}</h3>
              <p>
                {language === 'en'
                  ? 'Weekly chart overlays compare housing, transport, and grocery CPI contributions for Buenos Aires households.'
                  : 'Gráficos semanales comparan aportes de vivienda, transporte y alimentos al CPI del AMBA.'}
              </p>
              <img
                loading="lazy"
                src="https://picsum.photos/400/300?image=701"
                alt={language === 'en' ? 'Analytics dashboard preview' : 'Vista previa de tablero analítico'}
              />
            </div>
            <div className="card">
              <h3>{language === 'en' ? 'Course toolkit' : 'Kit del curso'}</h3>
              <p>
                {language === 'en'
                  ? 'Each worksheet aligns with the live dashboard and the week’s annotated narrative.'
                  : 'Cada guía acompaña el tablero en vivo y la narrativa comentada de la semana.'}
              </p>
              <img
                loading="lazy"
                src="https://picsum.photos/400/300?image=702"
                alt={language === 'en' ? 'Course materials on desk' : 'Materiales del curso sobre un escritorio'}
              />
            </div>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <header className="section__header">
            <h2>{t('home.galleryTitle')}</h2>
            <p>{t('home.gallerySubtitle')}</p>
          </header>
          <ImageGallery items={galleryItems} />
        </div>
      </section>
      <section className="section" style={{ background: '#eef2ff' }}>
        <div className="container">
          <header className="section__header">
            <h2>{t('home.testimonialsTitle')}</h2>
          </header>
          <div className="grid grid--two">
            <article className="testimonial">
              <header className="testimonial__header">
                <img
                  loading="lazy"
                  src="https://picsum.photos/100/100?image=801"
                  alt={language === 'en' ? 'Portrait of María Eugenia' : 'Retrato de María Eugenia'}
                  className="testimonial__avatar"
                />
                <div>
                  <strong>{t('home.testimonials.0.name')}</strong>
                  <p style={{ margin: 0 }}>{t('home.testimonials.0.title')}</p>
                </div>
              </header>
              <blockquote>{t('home.testimonials.0.quote')}</blockquote>
            </article>
            <article className="testimonial">
              <header className="testimonial__header">
                <img
                  loading="lazy"
                  src="https://picsum.photos/100/100?image=802"
                  alt={language === 'en' ? 'Portrait of Diego' : 'Retrato de Diego'}
                  className="testimonial__avatar"
                />
                <div>
                  <strong>{t('home.testimonials.1.name')}</strong>
                  <p style={{ margin: 0 }}>{t('home.testimonials.1.title')}</p>
                </div>
              </header>
              <blockquote>{t('home.testimonials.1.quote')}</blockquote>
            </article>
          </div>
        </div>
      </section>
      <section className="section section--tight">
        <div className="container">
          <header className="section__header">
            <h2>{t('home.statementsTitle')}</h2>
            <p>{t('home.statementsSubtitle')}</p>
          </header>
          <div className="timeline">
            <div className="timeline__item">
              <p style={{ margin: 0, fontWeight: 600 }}>{t('home.statements.0')}</p>
            </div>
            <div className="timeline__item">
              <p style={{ margin: 0, fontWeight: 600 }}>{t('home.statements.1')}</p>
            </div>
            <div className="timeline__item">
              <p style={{ margin: 0, fontWeight: 600 }}>
                Análisis transparentes y datos de mercado para decidir con seguridad.
              </p>
            </div>
            <div className="timeline__item">
              <p style={{ margin: 0, fontWeight: 600 }}>
                Pasos acertados hoy, mejor futuro mañana.
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="section" id="trial">
        <div className="container">
          <div className="grid grid--two" style={{ alignItems: 'stretch' }}>
            <div className="card" style={{ background: 'linear-gradient(135deg, #2563eb, #1f3a6f)', color: 'white' }}>
              <h2 style={{ color: 'white' }}>{t('home.trialTitle')}</h2>
              <p>{t('home.trialSubtitle')}</p>
              <ul>
                <li>Conocimiento financiero impulsado por tendencias.</li>
                <li>{t('home.secondaryStatement')}</li>
              </ul>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=501"
                alt={language === 'en' ? 'Educator reviewing analytics' : 'Educadora revisando analíticas'}
                style={{ borderRadius: 'var(--radius-sm)', marginTop: '1.5rem' }}
              />
            </div>
            <DoubleOptInForm
              id="trial-form"
              title={t('home.trialTitle')}
              subtitle={t('home.trialSubtitle')}
              submitLabel={language === 'en' ? 'Request trial lesson' : 'Solicitar clase de prueba'}
              confirmLabel={language === 'en' ? 'Complete subscription' : 'Completar suscripción'}
              successMessage={t('home.trialSuccess')}
              redirectPath="/thank-you"
              includeFocus
              includeBudget
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;