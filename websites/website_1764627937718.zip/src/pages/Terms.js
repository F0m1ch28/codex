import React from 'react';
import { Helmet } from 'react-helmet-async';
import Hero from '../components/Hero';
import { useLanguage } from '../context/LanguageContext';

const Terms = () => {
  const { t } = useLanguage();
  const content = t('terms');

  return (
    <>
      <Helmet>
        <title>{t('terms.metaTitle')}</title>
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=400"
        eyebrow={<span>Policies</span>}
        title={t('terms.heroTitle')}
        subtitle={t('terms.intro')}
        overlayFlag
        actions={[]}
      />
      <section className="section">
        <div className="container">
          {t('terms.sections').map((section) => (
            <article key={section.title} className="card">
              <h3>{section.title}</h3>
              <p>{section.content}</p>
            </article>
          ))}
          <article className="card">
            <h3>{language === 'en' ? 'Responsible choices' : 'Decisiones responsables'}</h3>
            <p>Información confiable que respalda elecciones responsables sobre tu dinero.</p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Terms;