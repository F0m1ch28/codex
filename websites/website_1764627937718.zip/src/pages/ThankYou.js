import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import { useLanguage } from '../context/LanguageContext';

const ThankYou = () => {
  const { t, language } = useLanguage();
  const content = t('thankYou');

  return (
    <>
      <Helmet>
        <title>{t('thankYou.metaTitle')}</title>
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=300"
        eyebrow={<span>Tu Progreso Hoy</span>}
        title={t('thankYou.heroTitle')}
        subtitle={t('thankYou.heroSubtitle')}
        overlayFlag
        actions={[
          <Link key="home" to="/" className="btn btn--primary">
            {t('thankYou.button')}
          </Link>
        ]}
      />
      <section className="section">
        <div className="container">
          <div className="card">
            <p>
              {language === 'en'
                ? 'Datos verificados para planificar tu presupuesto. Gracias por sumarte a la comunidad Tu Progreso Hoy.'
                : 'Datos verificados para planificar tu presupuesto. Gracias por sumarte a la comunidad Tu Progreso Hoy.'}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default ThankYou;