import React from 'react';
import { Helmet } from 'react-helmet-async';
import Hero from '../components/Hero';
import DoubleOptInForm from '../components/DoubleOptInForm';
import { useLanguage } from '../context/LanguageContext';

const Contact = () => {
  const { t, language } = useLanguage();
  const content = t('contact');

  return (
    <>
      <Helmet>
        <title>{t('contact.metaTitle')}</title>
        <meta name="description" content={t('contact.metaDescription')} />
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=400"
        eyebrow={<span>{t('contact.heroEyebrow')}</span>}
        title={t('contact.heroTitle')}
        subtitle={t('contact.heroSubtitle')}
        overlayFlag
        actions={[]}
      />
      <section className="section">
        <div className="container">
          <div className="grid grid--two">
            <article className="card">
              <h3>{t('contact.officeTitle')}</h3>
              <p>{t('contact.officeDescription')}</p>
              <iframe
                title={language === 'en' ? 'Map of Tu Progreso Hoy in Buenos Aires' : 'Mapa de Tu Progreso Hoy en Buenos Aires'}
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.1312049640086!2d-58.38375932344957!3d-34.59972235835438!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccadb2cba1b01%3A0x8f1a96b86c09f70!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1ses-419!2sar!4v1717440000000!5m2!1ses-419!2sar"
                loading="lazy"
                className="map-embed"
                allowFullScreen
              />
              <img
                loading="lazy"
                src="https://picsum.photos/400/300?image=702"
                alt={language === 'en' ? 'Collaborative office in Buenos Aires' : 'Oficina colaborativa en Buenos Aires'}
                style={{ marginTop: '1.5rem' }}
              />
            </article>
            <DoubleOptInForm
              id="contact-form"
              title={t('contact.connectTitle')}
              subtitle={
                language === 'en'
                  ? 'Send us your message. After confirming your email, we reply within one business day.'
                  : 'Envíanos tu mensaje. Tras confirmar tu correo respondemos en un día hábil.'
              }
              submitLabel={language === 'en' ? 'Send message' : 'Enviar mensaje'}
              confirmLabel={language === 'en' ? 'Confirm and send' : 'Confirmar y enviar'}
              successMessage={t('contact.successMessage')}
              includeMessage
              includeFocus
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;