import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import { useLanguage } from '../context/LanguageContext';

const NotFound = () => {
  const { t } = useLanguage();
  const content = t('notFound');

  return (
    <>
      <Helmet>
        <title>{t('notFound.metaTitle')}</title>
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=100"
        eyebrow={<span>404</span>}
        title={t('notFound.title')}
        subtitle={t('notFound.subtitle')}
        overlayFlag
        actions={[
          <Link key="home" to="/" className="btn btn--primary">
            {t('notFound.button')}
          </Link>
        ]}
      />
    </>
  );
};

export default NotFound;