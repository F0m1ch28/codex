import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import DoubleOptInForm from '../components/DoubleOptInForm';
import { useLanguage } from '../context/LanguageContext';

const Course = () => {
  const { t, language } = useLanguage();
  const content = t('course');

  return (
    <>
      <Helmet>
        <title>{t('course.metaTitle')}</title>
        <meta name="description" content={t('course.metaDescription')} />
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=300"
        eyebrow={<span>{t('course.heroEyebrow')}</span>}
        title={t('course.heroTitle')}
        subtitle={t('course.heroSubtitle')}
        overlayFlag
        actions={[
          <a key="trial" href="/#trial" className="btn btn--primary">
            {t('course.ctaPrimary')}
          </a>,
          <Link key="syllabus" to="/resources" className="btn btn--ghost">
            {t('course.ctaSecondary')}
          </Link>
        ]}
      />
      <section className="section">
        <div className="container">
          <header className="section__header">
            <h2>{t('course.modulesTitle')}</h2>
          </header>
          <div className="grid grid--two">
            {t('course.modules').map((module) => (
              <article key={module.title} className="card">
                <h3>{module.title}</h3>
                <p>{module.description}</p>
              </article>
            ))}
            <article className="card" style={{ background: 'linear-gradient(135deg, rgba(37,99,235,0.12), rgba(31,58,111,0.08))' }}>
              <h3>{language === 'en' ? 'Instructor guidance' : 'Acompañamiento docente'}</h3>
              <p>
                {language === 'en'
                  ? 'Weekly office hours in English and Spanish ensure you can ask questions and bring real examples.'
                  : 'Horas de consulta semanales en inglés y español para resolver dudas con casos reales.'}
              </p>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=501"
                alt={language === 'en' ? 'Instructor hosting session' : 'Docente dictando una sesión'}
              />
            </article>
            <article className="card">
              <h3>{language === 'en' ? 'Peer circles' : 'Círculos de pares'}</h3>
              <p>
                {language === 'en'
                  ? 'Work with classmates to compare inflation-sensitive budgets and strengthen accountability.'
                  : 'Comparte presupuestos sensibles a la inflación con tus pares y refuerza la responsabilidad.'}
              </p>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=502"
                alt={language === 'en' ? 'Team collaboration' : 'Colaboración en equipo'}
              />
            </article>
          </div>
        </div>
      </section>
      <section className="section" style={{ background: '#eef2ff' }}>
        <div className="container">
          <header className="section__header">
            <h2>{t('course.audienceTitle')}</h2>
            <p>{t('course.highlight')}</p>
          </header>
          <div className="grid grid--two">
            <div className="card">
              <ul>
                {t('course.audienceList').map((item) => (
                  <li key={item} style={{ marginBottom: '0.75rem' }}>
                    {item}
                  </li>
                ))}
              </ul>
              <p style={{ fontWeight: 700 }}>{t('course.audienceStatement')}</p>
            </div>
            <div className="card">
              <img
                loading="lazy"
                src="https://picsum.photos/800/500?image=600"
                alt={language === 'en' ? 'Buenos Aires skyline' : 'Horizonte de Buenos Aires'}
              />
            </div>
          </div>
        </div>
      </section>
      <section className="section section--tight">
        <div className="container">
          <header className="section__header">
            <h2>{t('course.ctaTitle')}</h2>
            <p>{t('course.ctaSubtitle')}</p>
          </header>
          <div className="grid grid--two">
            <DoubleOptInForm
              id="course-form"
              title={language === 'en' ? 'Stay informed about the cohort' : 'Infórmate sobre la cohorte'}
              subtitle={
                language === 'en'
                  ? 'Complete the double opt-in to receive cohort dates, pricing, and onboarding resources.'
                  : 'Completa el doble opt-in para recibir fechas, inversión y recursos de onboarding.'
              }
              submitLabel={language === 'en' ? 'Request syllabus' : 'Solicitar programa'}
              confirmLabel={language === 'en' ? 'Confirm request' : 'Confirmar solicitud'}
              successMessage={language === 'en' ? 'Request confirmed. Check your inbox.' : 'Solicitud confirmada. Revisa tu correo.'}
              includeBudget
            />
            <div className="card" style={{ background: 'white' }}>
              <h3>{language === 'en' ? 'How double opt-in works' : 'Cómo funciona el doble opt-in'}</h3>
              <div className="timeline">
                <div className="timeline__item">
                  <strong>1. {language === 'en' ? 'Submit form' : 'Envía el formulario'}</strong>
                  <p>
                    {language === 'en'
                      ? 'Share your contact details and interests. We log the request instantly.'
                      : 'Comparte tus datos y preferencias. Registramos la solicitud al instante.'}
                  </p>
                </div>
                <div className="timeline__item">
                  <strong>2. {language === 'en' ? 'Verify email' : 'Verifica tu correo'}</strong>
                  <p>
                    {language === 'en'
                      ? 'Open the confirmation email and click the secure link.'
                      : 'Abre el correo de confirmación y presiona el enlace seguro.'}
                  </p>
                </div>
                <div className="timeline__item">
                  <strong>3. {language === 'en' ? 'Gain access' : 'Obtén acceso'}</strong>
                  <p>
                    {language === 'en'
                      ? 'Receive the syllabus, dashboards preview, and onboarding checklist.'
                      : 'Recibe el programa, los tableros de muestra y el checklist de onboarding.'}
                  </p>
                </div>
                <div className="timeline__item">
                  <strong>4. {language === 'en' ? 'Keep learning' : 'Sigue aprendiendo'}</strong>
                  <p>
                    {language === 'en'
                      ? 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
                      : 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'}
                  </p>
                </div>
              </div>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=503"
                alt={language === 'en' ? 'Course facilitator leading session' : 'Facilitadora del curso dirigiendo la sesión'}
                style={{ marginTop: '1.5rem' }}
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Course;