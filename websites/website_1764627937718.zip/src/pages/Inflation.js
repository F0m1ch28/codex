import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import Hero from '../components/Hero';
import { useLanguage } from '../context/LanguageContext';

const Inflation = () => {
  const { t, language } = useLanguage();
  const content = t('inflation');

  const chartData = useMemo(
    () => [
      { month: '2023-11', headline: 8.1, core: 7.6, arsUsd: 4.2 },
      { month: '2023-12', headline: 12.5, core: 11.9, arsUsd: 5.1 },
      { month: '2024-01', headline: 10.4, core: 9.6, arsUsd: 4.7 },
      { month: '2024-02', headline: 9.8, core: 9.1, arsUsd: 4.4 },
      { month: '2024-03', headline: 7.9, core: 7.1, arsUsd: 3.8 },
      { month: '2024-04', headline: 7.3, core: 6.9, arsUsd: 3.5 }
    ],
    []
  );

  const formatMonth = (value) =>
    new Date(`${value}-01`).toLocaleDateString(language === 'en' ? 'en-US' : 'es-AR', {
      month: 'short',
      year: 'numeric'
    });

  return (
    <>
      <Helmet>
        <title>{t('inflation.metaTitle')}</title>
        <meta name="description" content={t('inflation.metaDescription')} />
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=200"
        eyebrow={<span>{t('inflation.heroEyebrow')}</span>}
        title={t('inflation.heroTitle')}
        subtitle={t('inflation.heroSubtitle')}
        overlayFlag
        actions={[]}
      />
      <section className="section">
        <div className="container">
          <header className="section__header">
            <h2>{t('inflation.methodTitle')}</h2>
          </header>
          <div className="grid grid--two">
            <article className="card">
              {t('inflation.methodParagraphs').map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
              ))}
              <ul>
                {t('inflation.methodList').map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
            <div className="card">
              <img
                loading="lazy"
                src="https://picsum.photos/400/300?image=701"
                alt={language === 'en' ? 'Analyst reviewing inflation charts' : 'Analista revisando gráficos de inflación'}
              />
              <p style={{ marginTop: '1rem', fontWeight: 600 }}>
                Análisis transparentes y datos de mercado para decidir con seguridad.
              </p>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=502"
                alt={language === 'en' ? 'Team member working with data' : 'Integrante del equipo trabajando con datos'}
                style={{ marginTop: '1.25rem' }}
              />
            </div>
          </div>
        </div>
      </section>
      <section className="section" style={{ background: 'rgba(15, 23, 42, 0.05)' }}>
        <div className="container">
          <header className="section__header">
            <h2>{t('inflation.chartTitle')}</h2>
            <p>{t('inflation.chartSubtitle')}</p>
          </header>
          <div className="card" style={{ padding: '2rem' }}>
            <div style={{ height: 360 }}>
              <ResponsiveContainer>
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,23,42,0.1)" />
                  <XAxis
                    dataKey="month"
                    tickFormatter={formatMonth}
                    stroke="#475569"
                    tickMargin={12}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    stroke="#475569"
                    tickFormatter={(value) => `${value}%`}
                    tickMargin={12}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    formatter={(value) => `${value}%`}
                    labelFormatter={(label) => formatMonth(label)}
                    contentStyle={{
                      borderRadius: '16px',
                      border: '1px solid rgba(15,23,42,0.1)',
                      boxShadow: 'var(--shadow-soft)'
                    }}
                  />
                  <Legend />
                  <Area type="monotone" dataKey="headline" stroke="#2563eb" fill="rgba(37,99,235,0.25)" name={language === 'en' ? 'Headline CPI' : 'CPI general'} />
                  <Area type="monotone" dataKey="core" stroke="#1f3a6f" fill="rgba(31,58,111,0.25)" name={language === 'en' ? 'Core CPI' : 'CPI núcleo'} />
                  <Area type="monotone" dataKey="arsUsd" stroke="#38bdf8" fill="rgba(56,189,248,0.2)" name={language === 'en' ? 'ARS→USD variance' : 'Desvío ARS→USD'} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <header className="section__header">
            <h2>{t('inflation.statsTitle')}</h2>
          </header>
          <div className="grid grid--three">
            {t('inflation.stats').map((item) => (
              <article key={item.title} className="card">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
            <article className="card">
              <h3>{language === 'en' ? 'Field observations' : 'Observaciones de campo'}</h3>
              <p>
                {language === 'en'
                  ? 'Weekly spot checks in Buenos Aires neighbourhoods feed into our blended CPI adjustments.'
                  : 'Relevamientos semanales en barrios de Buenos Aires alimentan los ajustes del CPI combinado.'}
              </p>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=503"
                alt={language === 'en' ? 'Field survey in Buenos Aires' : 'Relevamiento en la Ciudad de Buenos Aires'}
              />
            </article>
          </div>
        </div>
      </section>
      <section className="section section--tight" style={{ background: '#f8fafc' }}>
        <div className="container">
          <header className="section__header">
            <h2>{t('inflation.faqTitle')}</h2>
          </header>
          <div className="faq">
            <details className="faq__item">
              <summary>
                {language === 'en'
                  ? 'How often are the dashboards updated?'
                  : '¿Con qué frecuencia se actualizan los tableros?'}
              </summary>
              <p>
                {language === 'en'
                  ? 'Inflation dashboards refresh weekly with interim bulletins when FX moves more than 4% intraday.'
                  : 'Los tableros se refrescan semanalmente con boletines intermedios cuando el FX supera variaciones intradiarias del 4%.'}
              </p>
            </details>
            <details className="faq__item">
              <summary>
                {language === 'en'
                  ? 'Which sources feed the CPI composite?'
                  : '¿Qué fuentes alimentan el CPI combinado?'}
              </summary>
              <p>
                {language === 'en'
                  ? 'INDEC releases, provincial statistics, trusted private consultancies, and on-the-ground checks from our community.'
                  : 'Publicaciones de INDEC, datos provinciales, consultoras privadas confiables y relevamientos propios de la comunidad.'}
              </p>
            </details>
            <details className="faq__item">
              <summary>
                {language === 'en'
                  ? 'Do you provide financial advice?'
                  : '¿Brindan asesoramiento financiero?'}
              </summary>
              <p>
                {language === 'en'
                  ? 'No. We share educational content and contextual data. Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
                  : 'No. Ofrecemos contenido educativo y datos contextuales. Plataforma educativa con datos esenciales, sin asesoría financiera directa.'}
              </p>
            </details>
            <details className="faq__item">
              <summary>
                {language === 'en'
                  ? 'Can I export the data?'
                  : '¿Puedo exportar los datos?'}
              </summary>
              <p>
                {language === 'en'
                  ? 'Yes, subscribers can download CSV files and scenario templates aligned with each update.'
                  : 'Sí, las personas suscriptoras pueden descargar archivos CSV y plantillas de escenarios con cada actualización.'}
              </p>
            </details>
          </div>
        </div>
      </section>
    </>
  );
};

export default Inflation;