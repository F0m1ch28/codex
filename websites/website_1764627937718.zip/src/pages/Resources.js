import React from 'react';
import { Helmet } from 'react-helmet-async';
import Hero from '../components/Hero';
import { useLanguage } from '../context/LanguageContext';

const Resources = () => {
  const { t, language } = useLanguage();
  const content = t('resources');

  return (
    <>
      <Helmet>
        <title>{t('resources.metaTitle')}</title>
        <meta name="description" content={t('resources.metaDescription')} />
      </Helmet>
      <Hero
        image="https://picsum.photos/800/500?image=600"
        eyebrow={<span>{t('resources.heroEyebrow')}</span>}
        title={t('resources.heroTitle')}
        subtitle={t('resources.heroSubtitle')}
        overlayFlag
        actions={[]}
      />
      <section className="section">
        <div className="container">
          <header className="section__header">
            <h2>{t('resources.articlesTitle')}</h2>
          </header>
          <div className="grid grid--two">
            {t('resources.articles').map((article) => (
              <article key={article.titleEn} className="card">
                <img loading="lazy" src={article.image} alt={article.titleEn} />
                <h3>{language === 'en' ? article.titleEn : article.titleEs}</h3>
                <p>{language === 'en' ? article.summaryEn : article.summaryEs}</p>
                <a href="#!" className="btn btn--ghost">
                  {t('common.readMore')}
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="section" style={{ background: '#eef2ff' }}>
        <div className="container">
          <header className="section__header">
            <h2>{t('resources.glossaryTitle')}</h2>
            <p>{t('resources.statement')}</p>
          </header>
          <div className="glossary">
            {t('resources.glossary').map((item) => (
              <div key={item.term} className="glossary__item">
                <h4>{item.term}</h4>
                <p>{item.definition}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="section section--tight">
        <div className="container">
          <div className="grid grid--two">
            <div className="card">
              <h3>{language === 'en' ? 'Team knowledge sessions' : 'Sesiones del equipo'}</h3>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=501"
                alt={language === 'en' ? 'Educators discussing curriculum' : 'Educadores revisando el programa'}
              />
            </div>
            <div className="card">
              <h3>{language === 'en' ? 'Buenos Aires insights studio' : 'Estudio de insights en Buenos Aires'}</h3>
              <img
                loading="lazy"
                src="https://picsum.photos/300/300?image=502"
                alt={language === 'en' ? 'Data team analyzing charts' : 'Equipo de datos analizando gráficos'}
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Resources;