import React from 'react';
import { Helmet } from 'react-helmet-async';
import Hero from '../components/Hero';
import { useLanguage } from '../context/LanguageContext';

const Cookies = () => {
  const { t } = useLanguage();
  const content = t('cookiesPage');

  return (
    <>
      <Helmet>
        <title>{t('cookiesPage.metaTitle')}</title>
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=200"
        eyebrow={<span>Policies</span>}
        title={t('cookiesPage.heroTitle')}
        subtitle={t('cookiesPage.intro')}
        overlayFlag
        actions={[]}
      />
      <section className="section">
        <div className="container">
          {t('cookiesPage.sections').map((section) => (
            <article key={section.title} className="card">
              <h3>{section.title}</h3>
              <p>{section.content}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Cookies;