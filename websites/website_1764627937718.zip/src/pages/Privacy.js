import React from 'react';
import { Helmet } from 'react-helmet-async';
import Hero from '../components/Hero';
import { useLanguage } from '../context/LanguageContext';

const Privacy = () => {
  const { t } = useLanguage();
  const content = t('privacy');

  return (
    <>
      <Helmet>
        <title>{t('privacy.metaTitle')}</title>
      </Helmet>
      <Hero
        image="https://picsum.photos/1200/600?image=300"
        eyebrow={<span>Policies</span>}
        title={t('privacy.heroTitle')}
        subtitle={t('privacy.updated')}
        overlayFlag
        actions={[]}
      />
      <section className="section">
        <div className="container">
          {t('privacy.sections').map((section) => (
            <article key={section.title} className="card">
              <h3>{section.title}</h3>
              <p>{section.content}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Privacy;