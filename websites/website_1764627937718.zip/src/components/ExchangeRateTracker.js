import React, { useEffect, useMemo, useState } from 'react';
import { Line, LineChart, CartesianGrid, Tooltip, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { useLanguage } from '../context/LanguageContext';

const fetchTimeseries = async () => {
  const end = new Date();
  const start = new Date();
  start.setDate(end.getDate() - 6);

  const endDate = end.toISOString().slice(0, 10);
  const startDate = start.toISOString().slice(0, 10);

  const response = await fetch(
    `https://api.exchangerate.host/timeseries?base=ARS&symbols=USD&start_date=${startDate}&end_date=${endDate}`
  );
  if (!response.ok) {
    throw new Error('Failed to fetch');
  }
  const data = await response.json();
  if (!data.rates) {
    throw new Error('No rates');
  }
  return Object.entries(data.rates)
    .map(([date, value]) => ({
      date,
      rate: value.USD ? Number((1 / value.USD).toFixed(4)) : null
    }))
    .filter((item) => item.rate !== null)
    .sort((a, b) => new Date(a.date) - new Date(b.date));
};

const ExchangeRateTracker = () => {
  const { t, language } = useLanguage();
  const [history, setHistory] = useState([]);
  const [latest, setLatest] = useState(null);
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    let isMounted = true;

    const loadRates = async () => {
      try {
        const timeseries = await fetchTimeseries();
        if (!isMounted) return;
        setHistory(timeseries);
        setLatest(timeseries[timeseries.length - 1]);
        setStatus('ready');
      } catch (error) {
        if (!isMounted) return;
        const fallback = [
          { date: '2024-05-01', rate: 0.0012 },
          { date: '2024-05-02', rate: 0.00118 },
          { date: '2024-05-03', rate: 0.00119 },
          { date: '2024-05-04', rate: 0.00121 },
          { date: '2024-05-05', rate: 0.00122 },
          { date: '2024-05-06', rate: 0.0012 },
          { date: '2024-05-07', rate: 0.00123 }
        ];
        setHistory(fallback);
        setLatest(fallback[fallback.length - 1]);
        setStatus('fallback');
      }
    };

    loadRates();

    return () => {
      isMounted = false;
    };
  }, []);

  const formattedHistory = useMemo(
    () =>
      history.map((item) => ({
        ...item,
        label: new Date(item.date).toLocaleDateString(language === 'en' ? 'en-US' : 'es-AR', {
          month: 'short',
          day: 'numeric'
        })
      })),
    [history, language]
  );

  return (
    <div className="card" role="region" aria-live="polite">
      <span className="card__badge">{t('home.trackerBadge')}</span>
      <h3 style={{ marginBottom: '0.5rem' }}>{t('home.trackerTitle')}</h3>
      <p>{t('home.trackerSubtitle')}</p>
      <div style={{ marginTop: '1.5rem', display: 'grid', gap: '0.75rem' }}>
        <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'baseline' }}>
          <div>
            <small style={{ letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>
              {language === 'en' ? 'ARS per USD' : 'ARS por USD'}
            </small>
            <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--color-primary)' }}>
              {latest ? (1 / latest.rate).toFixed(2) : '--'}
            </div>
          </div>
          <div>
            <small style={{ color: '#475569' }}>
              {language === 'en' ? 'Updated' : 'Actualizado'}:{' '}
              {latest
                ? new Date(latest.date).toLocaleDateString(language === 'en' ? 'en-US' : 'es-AR', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric'
                  })
                : '--'}
            </small>
            {status === 'fallback' && (
              <p className="alert alert--warning" style={{ marginTop: '0.5rem' }}>
                {language === 'en'
                  ? 'Live data temporarily unavailable. Displaying sample trend.'
                  : 'Datos en vivo no disponibles. Mostramos una serie de ejemplo.'}
              </p>
            )}
          </div>
        </div>
        <div style={{ height: 220 }}>
          <ResponsiveContainer>
            <LineChart data={formattedHistory}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,23,42,0.1)" />
              <XAxis
                dataKey="label"
                stroke="#475569"
                fontSize={12}
                tickMargin={8}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                stroke="#475569"
                fontSize={12}
                tickMargin={8}
                axisLine={false}
                tickLine={false}
                domain={['dataMin - 0.05', 'dataMax + 0.05']}
              />
              <Tooltip
                contentStyle={{
                  borderRadius: '12px',
                  border: '1px solid rgba(15,23,42,0.1)',
                  boxShadow: 'var(--shadow-soft)'
                }}
                formatter={(value) => [(1 / value).toFixed(2), language === 'en' ? 'ARS per USD' : 'ARS por USD']}
                labelFormatter={(label) => label}
              />
              <Line
                type="monotone"
                dataKey="rate"
                stroke="var(--color-secondary)"
                strokeWidth={3}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default ExchangeRateTracker;