import React from 'react';

const Hero = ({ image, eyebrow, title, subtitle, actions, overlayFlag = true }) => {
  return (
    <section className="hero" role="banner">
      <div className="hero__image" style={{ backgroundImage: `url(${image})` }} aria-hidden="true" />
      {overlayFlag && <div className="hero__flag" aria-hidden="true" />}
      <div className="container">
        <div className="hero__content">
          {eyebrow && <div className="hero__eyebrow">{eyebrow}</div>}
          <h1>{title}</h1>
          {subtitle && <p>{subtitle}</p>}
          {actions && <div className="hero__actions">{actions}</div>}
        </div>
      </div>
    </section>
  );
};

export default Hero;