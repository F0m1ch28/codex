import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const LanguageToggle = () => {
  const { language, setLanguage, t } = useLanguage();

  const handleToggle = () => {
    setLanguage(language === 'en' ? 'es' : 'en');
  };

  return (
    <button
      type="button"
      className="language-toggle"
      onClick={handleToggle}
      aria-label={t('common.language')}
    >
      {language === 'en' ? 'ES' : 'EN'}
    </button>
  );
};

export default LanguageToggle;