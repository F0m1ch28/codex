import React from 'react';
import { Outlet } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Header from './Header';
import Footer from './Footer';
import CookieBanner from './CookieBanner';
import DisclaimerModal from './DisclaimerModal';
import ScrollToTop from './ScrollToTop';
import { useLanguage } from '../context/LanguageContext';

const Layout = () => {
  const { language } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es'} />
        <link rel="alternate" hrefLang="en" href="/" />
        <link rel="alternate" hrefLang="es-AR" href="/?lang=es-AR" />
      </Helmet>
      <ScrollToTop />
      <a href="#main-content" className="skip-link">
        {language === 'en' ? 'Skip to content' : 'Saltar al contenido'}
      </a>
      <Header />
      <main id="main-content">
        <Outlet />
      </main>
      <Footer />
      <CookieBanner />
      <DisclaimerModal />
    </>
  );
};

export default Layout;