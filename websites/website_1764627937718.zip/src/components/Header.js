import React from 'react';
import { NavLink } from 'react-router-dom';
import LanguageToggle from './LanguageToggle';
import { useLanguage } from '../context/LanguageContext';

const Header = () => {
  const { t, language } = useLanguage();

  return (
    <header className="navbar" role="banner">
      <div className="container navbar__inner">
        <NavLink to="/" className="navbar__brand" aria-label={t('brand')}>
          <span aria-hidden="true">📊</span>
          <div>
            <span>{t('brand')}</span>
          </div>
        </NavLink>
        <nav aria-label={language === 'en' ? 'Primary navigation' : 'Navegación principal'}>
          <div className="navbar__links">
            <NavLink to="/" end>
              {t('nav.home')}
            </NavLink>
            <NavLink to="/inflation">{t('nav.inflation')}</NavLink>
            <NavLink to="/course">{t('nav.course')}</NavLink>
            <NavLink to="/resources">{t('nav.resources')}</NavLink>
            <NavLink to="/contact">{t('nav.contact')}</NavLink>
          </div>
        </nav>
        <div className="navbar__cta">
          <LanguageToggle />
          <NavLink to="/contact" className="btn btn--primary">
            {language === 'en' ? 'Book a call' : 'Agenda una llamada'}
          </NavLink>
        </div>
      </div>
    </header>
  );
};

export default Header;