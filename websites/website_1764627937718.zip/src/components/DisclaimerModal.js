import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const DisclaimerModal = () => {
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const dismissed = sessionStorage.getItem('tph-disclaimer-dismissed');
    if (!dismissed) {
      const timer = setTimeout(() => setOpen(true), 1800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    sessionStorage.setItem('tph-disclaimer-dismissed', 'true');
    setOpen(false);
  };

  if (!open) {
    return null;
  }

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="modal">
        <button
          type="button"
          className="modal__close"
          onClick={handleClose}
          aria-label={t('common.close')}
        >
          ×
        </button>
        <h3 id="disclaimer-title">{t('disclaimer.title')}</h3>
        <p>{t('disclaimer.messageEn')}</p>
        <p>{t('disclaimer.messageEs')}</p>
        <p>{t('disclaimer.messageRu')}</p>
        <button type="button" className="btn btn--primary" onClick={handleClose}>
          {t('common.close')}
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;