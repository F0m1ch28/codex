import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Footer = () => {
  const { t, language } = useLanguage();

  return (
    <footer className="footer" role="contentinfo">
      <div className="container">
        <div className="footer__grid">
          <div>
            <h3 className="footer__title">{t('brand')}</h3>
            <p>{t('footer.tagline')}</p>
            <div className="badge-grid" aria-label="Core statements">
              <span className="badge-grid__item">
                <span aria-hidden="true">✅</span>
                Datos verificados para planificar tu presupuesto.
              </span>
              <span className="badge-grid__item">
                <span aria-hidden="true">🧭</span>
                Decisiones responsables, objetivos nítidos.
              </span>
            </div>
          </div>
          <div>
            <h4 className="footer__title">{language === 'en' ? 'Explore' : 'Explora'}</h4>
            <ul className="footer__links">
              <li>
                <Link to="/inflation">{t('nav.inflation')}</Link>
              </li>
              <li>
                <Link to="/course">{t('nav.course')}</Link>
              </li>
              <li>
                <Link to="/resources">{t('nav.resources')}</Link>
              </li>
              <li>
                <Link to="/contact">{t('nav.contact')}</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="footer__title">{t('footer.addressLabel')}</h4>
            <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
            <p>+54 11 5555-1234</p>
            <p>hola@tuprogresohoy.com</p>
          </div>
          <div>
            <h4 className="footer__title">{t('footer.socialLabel')}</h4>
            <ul className="footer__links">
              <li>
                <a href="https://linkedin.com" target="_blank" rel="noreferrer">
                  LinkedIn
                </a>
              </li>
              <li>
                <a href="https://twitter.com" target="_blank" rel="noreferrer">
                  X / Twitter
                </a>
              </li>
              <li>
                <a href="https://instagram.com" target="_blank" rel="noreferrer">
                  Instagram
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="footer__bottom">
          <strong>{t('footer.statement')}</strong>
          <span>
            Tu Progreso Hoy · {t('footer.rights')} © {new Date().getFullYear()}
          </span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;