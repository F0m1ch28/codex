import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const CookieBanner = () => {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('tph-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => {
        setVisible(true);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem('tph-cookie-consent', value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent">
      <h4 style={{ margin: '0 0 0.75rem', fontFamily: 'var(--font-heading)', color: 'var(--color-deep)' }}>
        {t('cookieBanner.title')}
      </h4>
      <p style={{ margin: 0 }}>{t('cookieBanner.message')}</p>
      <div className="cookie-banner__actions">
        <button type="button" className="btn btn--primary" onClick={() => handleConsent('accepted')}>
          {t('common.accept')}
        </button>
        <button type="button" className="btn btn--ghost" onClick={() => handleConsent('declined')}>
          {t('common.decline')}
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;