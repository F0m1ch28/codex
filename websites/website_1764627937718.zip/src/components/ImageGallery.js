import React from 'react';

const ImageGallery = ({ items }) => {
  return (
    <div className="image-gallery">
      {items.map((item) => (
        <div className="image-gallery__item" key={item.alt}>
          <figure>
            <img loading="lazy" src={item.src} alt={item.alt} />
            <figcaption>{item.caption}</figcaption>
          </figure>
        </div>
      ))}
    </div>
  );
};

export default ImageGallery;