import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const initialState = {
  name: '',
  email: '',
  phone: '',
  message: '',
  focus: '',
  budget: ''
};

const DoubleOptInForm = ({
  id,
  title,
  subtitle,
  submitLabel,
  confirmLabel,
  successMessage,
  redirectPath,
  includeMessage = false,
  includeFocus = false,
  includeBudget = false
}) => {
  const { language, t } = useLanguage();
  const navigate = useNavigate();
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [step, setStep] = useState('form');
  const [confirmChecked, setConfirmChecked] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  const options = useMemo(
    () => ({
      focus: [
        language === 'en' ? 'Inflation dashboards' : 'Tableros de inflación',
        language === 'en' ? 'Personal finance course' : 'Curso de finanzas personales',
        language === 'en' ? 'Both curriculum tracks' : 'Ambos itinerarios'
      ],
      budget: [
        language === 'en' ? 'Under ARS 250,000' : 'Menos de ARS 250.000',
        language === 'en' ? 'ARS 250,000 - 600,000' : 'ARS 250.000 - 600.000',
        language === 'en' ? 'Above ARS 600,000' : 'Más de ARS 600.000'
      ]
    }),
    [language]
  );

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = language === 'en' ? 'Please add your name.' : 'Ingresa tu nombre.';
    }
    if (!formData.email.trim()) {
      newErrors.email = language === 'en' ? 'Email is required.' : 'El correo es obligatorio.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email.trim())) {
      newErrors.email = language === 'en' ? 'Enter a valid email.' : 'Ingresa un correo válido.';
    }
    if (includeMessage && !formData.message.trim()) {
      newErrors.message = language === 'en' ? 'Add a brief message.' : 'Escribe un mensaje breve.';
    }
    if (includeFocus && !formData.focus) {
      newErrors.focus = language === 'en' ? 'Select an option.' : 'Selecciona una opción.';
    }
    if (includeBudget && !formData.budget) {
      newErrors.budget = language === 'en' ? 'Choose a budget range.' : 'Elige un rango de presupuesto.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const resetForm = () => {
    setFormData(initialState);
    setErrors({});
    setConfirmChecked(false);
    setStatusMessage('');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStep('pending');
    setStatusMessage('');
  };

  const handleConfirm = () => {
    if (!confirmChecked) {
      setStatusMessage(
        language === 'en'
          ? 'Please mark the confirmation checkbox before finishing.'
          : 'Marca la casilla de confirmación antes de finalizar.'
      );
      return;
    }
    if (redirectPath) {
      navigate(redirectPath);
    } else {
      setStep('confirmed');
    }
    resetForm();
  };

  return (
    <form id={id} className="form-card" onSubmit={handleSubmit} noValidate>
      <h3>{title}</h3>
      {subtitle && <p style={{ marginTop: '0.5rem', marginBottom: '2rem' }}>{subtitle}</p>}
      {step === 'form' && (
        <>
          <div className="form-group">
            <label htmlFor={`${id}-name`}>{t('common.nameLabel')}</label>
            <input
              id={`${id}-name`}
              type="text"
              name="name"
              autoComplete="name"
              value={formData.name}
              onChange={(event) => setFormData((state) => ({ ...state, name: event.target.value }))}
              aria-invalid={errors.name ? 'true' : 'false'}
              aria-describedby={errors.name ? `${id}-name-error` : undefined}
            />
            {errors.name && (
              <span id={`${id}-name-error`} className="form-error">
                {errors.name}
              </span>
            )}
          </div>
          <div className="form-group">
            <label htmlFor={`${id}-email`}>{t('common.emailLabel')}</label>
            <input
              id={`${id}-email`}
              type="email"
              name="email"
              autoComplete="email"
              value={formData.email}
              onChange={(event) => setFormData((state) => ({ ...state, email: event.target.value }))}
              aria-invalid={errors.email ? 'true' : 'false'}
              aria-describedby={errors.email ? `${id}-email-error` : undefined}
            />
            {errors.email && (
              <span id={`${id}-email-error`} className="form-error">
                {errors.email}
              </span>
            )}
          </div>
          <div className="form-group">
            <label htmlFor={`${id}-phone`}>
              {t('common.phoneLabel')} <span aria-hidden="true">({t('common.optional')})</span>
            </label>
            <input
              id={`${id}-phone`}
              type="tel"
              name="phone"
              autoComplete="tel"
              value={formData.phone}
              onChange={(event) => setFormData((state) => ({ ...state, phone: event.target.value }))}
            />
          </div>
          {includeFocus && (
            <div className="form-group">
              <label htmlFor={`${id}-focus`}>{t('common.courseInterestLabel')}</label>
              <select
                id={`${id}-focus`}
                name="focus"
                value={formData.focus}
                onChange={(event) => setFormData((state) => ({ ...state, focus: event.target.value }))}
                aria-invalid={errors.focus ? 'true' : 'false'}
              >
                <option value="">{language === 'en' ? 'Select an option' : 'Selecciona una opción'}</option>
                {options.focus.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              {errors.focus && <span className="form-error">{errors.focus}</span>}
            </div>
          )}
          {includeBudget && (
            <div className="form-group">
              <label htmlFor={`${id}-budget`}>{t('common.budgetLabel')}</label>
              <select
                id={`${id}-budget`}
                name="budget"
                value={formData.budget}
                onChange={(event) => setFormData((state) => ({ ...state, budget: event.target.value }))}
                aria-invalid={errors.budget ? 'true' : 'false'}
              >
                <option value="">{language === 'en' ? 'Select a range' : 'Selecciona un rango'}</option>
                {options.budget.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              {errors.budget && <span className="form-error">{errors.budget}</span>}
            </div>
          )}
          {includeMessage && (
            <div className="form-group">
              <label htmlFor={`${id}-message`}>{t('common.messageLabel')}</label>
              <textarea
                id={`${id}-message`}
                name="message"
                rows="4"
                value={formData.message}
                onChange={(event) => setFormData((state) => ({ ...state, message: event.target.value }))}
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && <span className="form-error">{errors.message}</span>}
            </div>
          )}
          <button type="submit" className="btn btn--primary">
            {submitLabel || t('common.submit')}
          </button>
        </>
      )}
      {step === 'pending' && (
        <div>
          <div className="alert" role="status">
            <strong>{t('common.pendingTitle')}</strong>
            <p style={{ margin: '0.5rem 0 0' }}>{t('common.pendingSubtitle')}</p>
          </div>
          <div className="form-checkbox">
            <input
              id={`${id}-checkbox`}
              type="checkbox"
              checked={confirmChecked}
              onChange={(event) => setConfirmChecked(event.target.checked)}
            />
            <label htmlFor={`${id}-checkbox`}>{t('common.confirmCheckbox')}</label>
          </div>
          {statusMessage && <p className="form-error">{statusMessage}</p>}
          <button type="button" className="btn btn--primary" onClick={handleConfirm}>
            {confirmLabel || t('common.confirm')}
          </button>
        </div>
      )}
      {step === 'confirmed' && (
        <div className="alert alert--success" role="status">
          <p style={{ margin: 0 }}>{successMessage || t('common.confirmed')}</p>
        </div>
      )}
    </form>
  );
};

export default DoubleOptInForm;