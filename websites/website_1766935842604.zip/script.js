document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNavigation = document.querySelector(".primary-navigation");
  if (navToggle && primaryNavigation) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      primaryNavigation.classList.toggle("is-open");
    });
  }

  const toast = document.querySelector("[data-toast]");
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    window.setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 3200);
  };

  const addToCartButtons = document.querySelectorAll("[data-add-to-cart]");
  addToCartButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const giftName = button.getAttribute("data-gift-name") || "gift selection";
      showToast(`“${giftName}” added to your gift box.`);
    });
  });

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector("[data-cookie-accept]");
    const declineButton = cookieBanner.querySelector("[data-cookie-decline]");
    const storedConsent = localStorage.getItem("luxeGiftCookieConsent");
    if (storedConsent === "accepted" || storedConsent === "declined") {
      cookieBanner.classList.add("is-hidden");
    }
    if (acceptButton) {
      acceptButton.addEventListener("click", () => {
        localStorage.setItem("luxeGiftCookieConsent", "accepted");
        cookieBanner.classList.add("is-hidden");
        showToast("Thanks! Cookies accepted for a smoother experience.");
      });
    }
    if (declineButton) {
      declineButton.addEventListener("click", () => {
        localStorage.setItem("luxeGiftCookieConsent", "declined");
        cookieBanner.classList.add("is-hidden");
        showToast("Preferences saved without cookies.");
      });
    }
  }

  const customizerForm = document.querySelector("[data-customizer-form]");
  if (customizerForm) {
    const totalField = customizerForm.querySelector("[data-custom-total]");
    const summaryList = customizerForm.querySelector("[data-selection-summary]");
    const budgetRange = customizerForm.querySelector("[data-budget]");
    const budgetOutput = customizerForm.querySelector("[data-budget-output]");
    const basePrice = Number(customizerForm.getAttribute("data-base-price")) || 0;

    const updateCustomizer = () => {
      let total = basePrice;
      const selections = [];

      const selectableInputs = customizerForm.querySelectorAll("select[data-option], input[data-option]");
      selectableInputs.forEach((input) => {
        if (input.tagName === "SELECT") {
          const selectedOption = input.options[input.selectedIndex];
          const label = selectedOption.getAttribute("data-label") || selectedOption.textContent.trim();
          const price = Number(selectedOption.getAttribute("data-price")) || 0;
          total += price;
          selections.push(`${label}${price > 0 ? ` (+$${price.toFixed(2)})` : ""}`);
        } else if ((input.type === "checkbox" || input.type === "radio") && input.checked) {
          const label = input.getAttribute("data-label") || input.value;
          const price = Number(input.getAttribute("data-price")) || 0;
          total += price;
          selections.push(`${label}${price > 0 ? ` (+$${price.toFixed(2)})` : ""}`);
        } else if (input.type === "number") {
          const count = Number(input.value) || 0;
          const price = Number(input.getAttribute("data-price")) || 0;
          if (count > 0) {
            const subtotal = price * count;
            total += subtotal;
            const label = input.getAttribute("data-label") || input.name;
            selections.push(`${label} x${count} (+$${subtotal.toFixed(2)})`);
          }
        }
      });

      if (summaryList) {
        summaryList.innerHTML = "";
        if (selections.length === 0) {
          summaryList.insertAdjacentHTML("beforeend", "<span>Select custom features to personalize your gift box.</span>");
        } else {
          selections.forEach((text) => {
            const item = document.createElement("span");
            item.textContent = text;
            summaryList.appendChild(item);
          });
        }
      }

      if (totalField) {
        totalField.textContent = `$${total.toFixed(2)}`;
      }
    };

    if (budgetRange && budgetOutput) {
      budgetRange.addEventListener("input", () => {
        budgetOutput.textContent = `$${Number(budgetRange.value).toFixed(0)}`;
      });
    }

    customizerForm.addEventListener("input", updateCustomizer);
    customizerForm.addEventListener("change", updateCustomizer);

    customizerForm.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Your custom box is ready in the cart!");
    });

    updateCustomizer();
  }

  const occasionButtons = document.querySelectorAll("[data-occasion-button]");
  const occasionPanels = document.querySelectorAll("[data-occasion-panel]");
  if (occasionButtons.length && occasionPanels.length) {
    const activateOccasion = (targetId) => {
      occasionButtons.forEach((button) => {
        const isTarget = button.getAttribute("data-target") === targetId;
        button.classList.toggle("is-active", isTarget);
      });
      occasionPanels.forEach((panel) => {
        panel.classList.toggle("is-active", panel.id === targetId);
      });
    };

    const firstTarget = occasionButtons[0].getAttribute("data-target");
    activateOccasion(firstTarget);

    occasionButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const target = button.getAttribute("data-target");
        activateOccasion(target);
      });
    });

    if (window.location.hash) {
      const hashTarget = window.location.hash.replace("#", "");
      const matchedPanel = document.getElementById(hashTarget);
      if (matchedPanel) {
        activateOccasion(hashTarget);
      }
    }
  }

  const occasionSelect = document.querySelector("[data-occasion-select]");
  const occasionMessage = document.querySelector("[data-occasion-message]");
  if (occasionSelect && occasionMessage) {
    const updateMessage = () => {
      const chosen = occasionSelect.value;
      const recommendation = occasionSelect.selectedOptions[0]?.getAttribute("data-tip") || "";
      occasionMessage.textContent = recommendation
        ? recommendation
        : "Select an occasion to unlock tailored gift inspiration.";
    };
    occasionSelect.addEventListener("change", updateMessage);
    updateMessage();
  }

  const simpleForms = document.querySelectorAll("[data-simple-form]");
  simpleForms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Thank you! We will be in touch shortly.");
      form.reset();
    });
  });
});