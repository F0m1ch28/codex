document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".nav-menu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const isOpen = navMenu.classList.toggle("nav-menu--open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("corsairsCookies");
    if (!storedChoice) {
      requestAnimationFrame(() => cookieBanner.classList.add("cookie-banner--visible"));
    }

    cookieBanner.querySelectorAll("button[data-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        localStorage.setItem("corsairsCookies", button.dataset.choice);
        cookieBanner.classList.remove("cookie-banner--visible");
      });
    });
  }
});