document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.mobile-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-links a');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');
    const contactForm = document.getElementById('contact-form');
    const formStatus = document.getElementById('formStatus');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = siteNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                siteNav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    window.history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollBtn.style.display = 'flex';
            } else {
                scrollBtn.style.display = 'none';
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAccept) {
        const cookieConsent = localStorage.getItem('muejpi_cookie_consent');

        if (cookieConsent === 'accepted') {
            cookieBanner.classList.add('hidden');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem('muejpi_cookie_consent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    if (contactForm && formStatus) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();

            const formData = new FormData(contactForm);
            const name = formData.get('name').trim();
            const email = formData.get('email').trim();
            const message = formData.get('message').trim();

            if (!name || !email || !message) {
                formStatus.textContent = 'Please complete all required fields before sending.';
                formStatus.style.color = '#D32F2F';
                return;
            }

            formStatus.textContent = 'Sending your message…';
            formStatus.style.color = '#0D47A1';

            setTimeout(() => {
                formStatus.textContent = 'Thank you! We have received your message and will respond within one working day.';
                formStatus.style.color = '#0D47A1';
                contactForm.reset();
            }, 900);
        });
    }

    const yearEl = document.getElementById('currentYear');
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }
});