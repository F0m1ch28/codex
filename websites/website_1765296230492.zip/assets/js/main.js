document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      siteNav.classList.toggle("is-open");
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const choice = localStorage.getItem("cookieChoice");

    if (!choice) {
      requestAnimationFrame(() => cookieBanner.classList.add("is-visible"));
    }

    const handleChoice = (value) => {
      localStorage.setItem("cookieChoice", value);
      cookieBanner.classList.remove("is-visible");
    };

    acceptBtn?.addEventListener("click", () => handleChoice("accepted"));
    declineBtn?.addEventListener("click", () => handleChoice("declined"));
  }
});