document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      siteNav.classList.toggle("is-open");
    });
    siteNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        siteNav.classList.remove("is-open");
      });
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const cookieAccept = document.getElementById("cookieAccept");
  const cookieDecline = document.getElementById("cookieDecline");
  const cookieKey = "storageSyncCookiePreference";

  if (cookieBanner && cookieAccept && cookieDecline) {
    const storedPreference = localStorage.getItem(cookieKey);
    if (storedPreference) {
      cookieBanner.classList.add("is-hidden");
    } else {
      setTimeout(function () {
        cookieBanner.classList.add("is-visible");
      }, 600);
    }

    cookieAccept.addEventListener("click", function () {
      localStorage.setItem(cookieKey, "accepted");
      cookieBanner.classList.remove("is-visible");
      cookieBanner.classList.add("is-hidden");
    });

    cookieDecline.addEventListener("click", function () {
      localStorage.setItem(cookieKey, "declined");
      cookieBanner.classList.remove("is-visible");
      cookieBanner.classList.add("is-hidden");
    });
  }
});