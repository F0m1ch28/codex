import React, { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Services.module.css';

const services = [
  {
    id: 'strategy',
    title: 'Стратегия и дорожные карты',
    intro:
      'Формируем цифровую стратегию и ROI-ориентированную дорожную карту, которая учитывает зрелость процессов и цели бизнеса.',
    benefits: [
      'Оценка зрелости и аудит цифровых процессов',
      'Портфель инициатив с приоритетами и сроками',
      'Модель управления изменениями и KPI контроля',
    ],
  },
  {
    id: 'delivery',
    title: 'Разработка и внедрение решений',
    intro:
      'Создаем продукты с использованием современных архитектур и Agile-подхода. Внедряем DevOps и CI/CD с упором на безопасность.',
    benefits: [
      'UI/UX дизайн и прототипирование',
      'Microservices, cloud native, API-first подход',
      'QA, автоматизация тестирования и observability',
    ],
  },
  {
    id: 'data',
    title: 'Data & Analytics',
    intro:
      'Выстраиваем архитектуру данных, внедряем BI-платформы и искусственный интеллект для прогноза и предиктивной аналитики.',
    benefits: [
      'Data lake, MDM, интеграция источников',
      'BI-панели, self-service analytics',
      'ML-модели, рекомендательные системы',
    ],
  },
  {
    id: 'operations',
    title: 'Операционная эффективность',
    intro:
      'Автоматизируем ключевые процессы, внедряем RPA и BPM, оптимизируем цепочки поставок и планирование производства.',
    benefits: [
      'Process mining и диагностика узких мест',
      'RPA/Low-code сценарии, цифровые двойники',
      'Отчетность по SLA и контроль производительности',
    ],
  },
];

const accelerators = [
  {
    title: 'Intellital Launchpad',
    description: 'Платформа быстрой разработки MVP с готовыми модулями авторизации, интеграций и аналитики.',
  },
  {
    title: 'Data Boost',
    description: 'Шаблоны Data Lake и BI отчётности, которые ускоряют запуск аналитики в 3 раза.',
  },
  {
    title: 'Cloud Shift',
    description: 'Методология миграции в облако с референсной архитектурой и планом оптимизации затрат.',
  },
];

const process = [
  {
    title: 'Discovery',
    text: 'Интервью, анализ процессов, определение KPI и бизнес-эффекта.',
  },
  {
    title: 'Solution Design',
    text: 'UX/UI, архитектура, выбор стека, план зависимостей и roadmap.',
  },
  {
    title: 'Delivery',
    text: 'Agile-команда, контроль качества, интеграции и запуск релизов.',
  },
  {
    title: 'Adoption',
    text: 'Обучение и поддержка, управление эффектами, развитие продукта.',
  },
];

const ServicesPage = () => {
  const [activeService, setActiveService] = useState(services[0].id);

  const currentService = services.find((service) => service.id === activeService);

  return (
    <div className={styles.services}>
      <PageHelmet
        title="Услуги Интеллитал Групп — стратегия, разработка, аналитика"
        description="Интеллитал Групп предлагает услуги по цифровой трансформации, разработке, аналитике данных и оптимизации процессов."
        keywords="цифровая трансформация услуги, IT-консалтинг Москва, разработка ПО"
      />
      <section className={styles.hero}>
        <h1>Услуги и подход Интеллитал Групп</h1>
        <p>
          Сопровождаем клиентов на всем пути трансформации: от диагностики и стратегии до внедрения, адаптации и
          измерения эффекта.
        </p>
      </section>

      <section className={styles.serviceTabs}>
        <div className={styles.tabList} role="tablist" aria-orientation="horizontal">
          {services.map((service) => (
            <button
              key={service.id}
              type="button"
              role="tab"
              aria-selected={activeService === service.id}
              className={`${styles.tabButton} ${activeService === service.id ? styles.tabActive : ''}`}
              onClick={() => setActiveService(service.id)}
            >
              {service.title}
            </button>
          ))}
        </div>
        <article className={styles.tabPanel} role="tabpanel">
          <h2>{currentService.title}</h2>
          <p>{currentService.intro}</p>
          <ul>
            {currentService.benefits.map((benefit) => (
              <li key={benefit}>{benefit}</li>
            ))}
          </ul>
        </article>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Наш процесс работы</h2>
          <p>Прозрачные этапы и единая команда, ориентированная на результат.</p>
        </div>
        <div className={styles.processGrid}>
          {process.map((step, index) => (
            <article key={step.title}>
              <span>{`0${index + 1}`}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.accelerators}>
        <div className={styles.sectionHeader}>
          <h2>Цифровые акселераторы</h2>
          <p>Готовые решения, которые сокращают время вывода продукта на рынок.</p>
        </div>
        <div className={styles.acceleratorGrid}>
          {accelerators.map((item) => (
            <article key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;