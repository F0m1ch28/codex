import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Пять шагов к эффективной цифровой стратегии',
    excerpt:
      'Рассматриваем, как определить цель трансформации, оценить зрелость компании и построить реалистичную дорожную карту.',
    date: '10.02.2024',
    category: 'Стратегия',
    image: 'https://picsum.photos/900/600?random=115',
  },
  {
    title: 'Как внедрить DevOps без боли',
    excerpt:
      'Делимся практиками организации команд, автоматизации тестирования и мониторинга, снижая риски релизов.',
    date: '24.01.2024',
    category: 'Инжиниринг',
    image: 'https://picsum.photos/900/600?random=116',
  },
  {
    title: 'Data Governance: что важно учесть',
    excerpt:
      'Выстраиваем работу с данными, определяем роли, процессы управления качеством и безопасности информации.',
    date: '15.12.2023',
    category: 'Аналитика',
    image: 'https://picsum.photos/900/600?random=117',
  },
  {
    title: 'RPA: автоматизация операционных процессов',
    excerpt:
      'Разбираем, какие процессы отдать роботам, как измерять эффект и сочетать RPA с BPM-подходом.',
    date: '28.11.2023',
    category: 'Автоматизация',
    image: 'https://picsum.photos/900/600?random=118',
  },
];

const BlogPage = () => {
  return (
    <div className={styles.blog}>
      <PageHelmet
        title="Блог Интеллитал Групп — аналитика и цифровые инсайты"
        description="Полезные статьи Интеллитал Групп про цифровую трансформацию, DevOps, аналитику и автоматизацию."
        keywords="цифровая трансформация блог, аналитика, DevOps"
      />
      <section className={styles.hero}>
        <h1>Инсайты и практики</h1>
        <p>
          Делимся аналитикой, практическими кейсами и методологиями, которые помогают нашим клиентам ускорять цифровые
          изменения.
        </p>
      </section>

      <section className={styles.grid}>
        {posts.map((post) => (
          <article key={post.title} className={styles.card}>
            <div className={styles.image}>
              <img src={post.image} alt={post.title} loading="lazy" />
            </div>
            <div className={styles.body}>
              <span className={styles.meta}>
                {post.category} · {post.date}
              </span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <button type="button" className={styles.readMore}>
                Подробнее в ближайшее время
              </button>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default BlogPage;