import React, { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Contacts.module.css';

const ContactsPage = () => {
  const [form, setForm] = useState({ name: '', email: '', company: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const updateField = ({ target }) => {
    const { name, value } = target;
    setForm((state) => ({ ...state, [name]: value }));
    setErrors((state) => ({ ...state, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Введите имя';
    if (!form.email.trim()) {
      newErrors.email = 'Введите email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'Email указан некорректно';
    }
    if (!form.message.trim()) newErrors.message = 'Опишите запрос';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setForm({ name: '', email: '', company: '', message: '' });
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <div className={styles.contacts}>
      <PageHelmet
        title="Контакты Интеллитал Групп — Москва, Россия"
        description="Свяжитесь с Интеллитал Групп: адрес в Москве, телефон +7 (495) 123-45-67, email info@intellital.ru."
        keywords="контакты Интеллитал Групп, IT-консалтинг Москва"
      />
      <section className={styles.intro}>
        <h1>Контакты</h1>
        <p>
          Оставьте заявку или напишите нам напрямую. Мы подготовим предложение, основанное на ваших целях и метриках
          эффективности.
        </p>
      </section>

      <section className={styles.grid}>
        <div className={styles.card}>
          <h2>Наш офис</h2>
          <address>
            <p>Россия, 125047, г. Москва, ул. Лесная, д. 5, офис 210</p>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:info@intellital.ru">info@intellital.ru</a>
          </address>
          <p className={styles.schedule}>
            График: пн-пт с 10:00 до 19:00 (GMT+3). Встречи в офисе по предварительному согласованию.
          </p>
        </div>
        <div className={styles.card}>
          <h2>Напишите нам</h2>
          <form onSubmit={handleSubmit} noValidate>
            <label htmlFor="contact-name">
              Имя
              <input
                id="contact-name"
                name="name"
                type="text"
                value={form.name}
                onChange={updateField}
                placeholder="Имя"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </label>
            <label htmlFor="contact-email">
              Email
              <input
                id="contact-email"
                name="email"
                type="email"
                value={form.email}
                onChange={updateField}
                placeholder="name@company.ru"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </label>
            <label htmlFor="contact-company">
              Компания
              <input
                id="contact-company"
                name="company"
                type="text"
                value={form.company}
                onChange={updateField}
                placeholder="Название компании"
              />
            </label>
            <label htmlFor="contact-message">
              Запрос
              <textarea
                id="contact-message"
                name="message"
                rows="4"
                value={form.message}
                onChange={updateField}
                placeholder="Расскажите о проекте или задайте вопрос"
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </label>
            <button type="submit">Отправить</button>
            {submitted && <p className={styles.success}>Спасибо! Мы свяжемся в ближайший рабочий день.</p>}
          </form>
        </div>
      </section>

      <section className={styles.mapSection} aria-label="Карта офиса">
        <iframe
          title="Офис Интеллитал Групп на карте"
          src="https://yandex.ru/map-widget/v1/?um=constructor%3A7f6b4a5816688c36f360d35b9b97a1d5fb4ba4e847ef98a32956543d4d6acdfd&source=constructor"
          frameBorder="0"
        ></iframe>
      </section>
    </div>
  );
};

export default ContactsPage;