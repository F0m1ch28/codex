import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Проектов внедрено', value: 120 },
  { label: 'Экономия клиентам, млн ₽', value: 540 },
  { label: 'Средний NPS', value: 87 },
];

const servicesData = [
  {
    title: 'Цифровая трансформация',
    description:
      'Комплексная диагностика бизнес-процессов и построение дорожной карты цифровых инициатив в рамках стратегии роста.',
    icon: '⚙️',
  },
  {
    title: 'IT-консалтинг',
    description:
      'Экспертиза в архитектуре, управлении данными и оптимизации ИТ-портфеля для повышения эффективности инвестиций.',
    icon: '🧭',
  },
  {
    title: 'Разработка ПО',
    description:
      'Создаем безопасные облачные и on-premise решения с использованием современных архитектурных подходов и DevOps.',
    icon: '💻',
  },
  {
    title: 'Аналитика и BI',
    description:
      'Визуализация ключевых показателей, построение data-lake и автоматизация отчетности для быстрого принятия решений.',
    icon: '📊',
  },
];

const steps = [
  {
    title: 'Исследование и дизайн',
    description: 'Погружаемся в бизнес-контекст, проводим интервью, строим карту процессов и определяем метрики успеха.',
  },
  {
    title: 'Прототип и MVP',
    description: 'Разрабатываем UX-концепцию, согласуем архитектуру и выводим минимально жизнеспособный продукт.',
  },
  {
    title: 'Масштабирование',
    description: 'Интегрируемся с существующими системами, оптимизируем производительность и автоматизируем CI/CD.',
  },
  {
    title: 'Поддержка',
    description: 'Обеспечиваем сопровождение 24/7, обучение команд и развитие решений с учетом обратной связи.',
  },
];

const projectCards = [
  {
    id: 1,
    title: 'Автоматизация закупок крупного холдинга',
    category: 'Автоматизация',
    result: 'Сокращение цикла закупок на 28% и экономия 64 млн ₽',
    image: 'https://picsum.photos/1200/800?random=104',
  },
  {
    id: 2,
    title: 'Построение единого data lake',
    category: 'Аналитика',
    result: 'Сокращение времени подготовки отчетности с 5 дней до 4 часов',
    image: 'https://picsum.photos/1200/800?random=105',
  },
  {
    id: 3,
    title: 'Мобильное приложение для логистики',
    category: 'Разработка',
    result: 'Повышение SLA доставки до 97% и снижение возвратов на 18%',
    image: 'https://picsum.photos/1200/800?random=106',
  },
  {
    id: 4,
    title: 'Миграция инфраструктуры в облако',
    category: 'Инфраструктура',
    result: 'Оптимизация расходов на 32% и повышение отказоустойчивости',
    image: 'https://picsum.photos/1200/800?random=107',
  },
];

const testimonials = [
  {
    quote:
      'Интеллитал Групп помогли нам выстроить прозрачную систему управления данными. Решения по аналитике позволили руководителям видеть актуальные показатели в режиме реального времени.',
    author: 'Анна Петрова',
    role: 'Директор по цифровому развитию, «НордИнвест»',
  },
  {
    quote:
      'Команда создала высоконагруженную платформу для наших партнеров. Грамотно выстроили взаимодействие, соблюдая сроки и SLA на каждом этапе.',
    author: 'Алексей Иванов',
    role: 'Руководитель ИТ, «Global Logistics»',
  },
  {
    quote:
      'В рамках трансформации производства специалисты Intellital предложили масштабируемую архитектуру и обучили нашу команду работать по Agile-подходу.',
    author: 'Марина Смирнова',
    role: 'COO, «TechFabric»',
  },
];

const teamMembers = [
  {
    name: 'Дмитрий Волков',
    role: 'Партнер, директор по стратегии',
    expertise: '20 лет опыта в цифровой трансформации и управлении инновациями.',
    image: 'https://picsum.photos/400/400?random=108',
  },
  {
    name: 'Софья Крылова',
    role: 'Руководитель практики разработки',
    expertise: 'Эксперт в построении высоконагруженных облачных решений и DevOps.',
    image: 'https://picsum.photos/400/400?random=109',
  },
  {
    name: 'Игорь Савельев',
    role: 'Head of Data & AI',
    expertise: 'Специалист по BI и ML. Реализовал свыше 40 проектов по data-driven путешеству клиента.',
    image: 'https://picsum.photos/400/400?random=110',
  },
];

const faqs = [
  {
    question: 'Как быстро вы можете запустить пилотный проект?',
    answer:
      'Пилотный проект стартует в среднем за 4 недели: 2 недели Discovery, 1 неделя прототипирования и 1 неделя настройки инфраструктуры.',
  },
  {
    question: 'Работаете ли вы с распределёнными командами заказчика?',
    answer:
      'Да, мы формируем смешанные проектные команды с учетом часовых поясов и используем гибридные методологии управления.',
  },
  {
    question: 'Предоставляете ли вы поддержку после внедрения?',
    answer:
      'Мы обеспечиваем поддержку 24/7 с выделенной линией и SLA, а также проводим обучение и передаем документацию.',
  },
];

const blogPosts = [
  {
    title: 'Как построить дорожную карту цифровой трансформации',
    excerpt:
      'Разбираем ключевые шаги формирования стратегии и KPI, которые помогают измерять прогресс трансформации.',
    date: '12.02.2024',
    image: 'https://picsum.photos/800/600?random=111',
  },
  {
    title: 'Data Mesh: подход к масштабированию аналитики',
    excerpt:
      'Преимущества и практические советы по внедрению Data Mesh в компаниях со сложной продуктовой линейкой.',
    date: '28.01.2024',
    image: 'https://picsum.photos/800/600?random=112',
  },
  {
    title: 'Как ускорить релизы с помощью DevOps-практик',
    excerpt:
      'Рассказываем, как оптимизировать конвейер поставки и повысить стабильность релизов с помощью автоматизации.',
    date: '15.12.2023',
    image: 'https://picsum.photos/800/600?random=113',
  },
];

const HomePage = () => {
  const [displayedStats, setDisplayedStats] = useState(statsData.map(() => 0));
  const [activeProjectFilter, setActiveProjectFilter] = useState('Все');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeFaq, setActiveFaq] = useState(null);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [formSent, setFormSent] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setDisplayedStats((prev) =>
        prev.map((value, index) => {
          const target = statsData[index].value;
          if (value >= target) {
            return target;
          }
          const increment = Math.ceil(target / 60);
          const nextValue = value + increment;
          return nextValue > target ? target : nextValue;
        })
      );
    }, 40);

    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeProjectFilter === 'Все') {
      return projectCards;
    }
    return projectCards.filter((project) => project.category === activeProjectFilter);
  }, [activeProjectFilter]);

  const handleTestimonialChange = (direction) => {
    setTestimonialIndex((prev) => {
      if (direction === 'next') {
        return prev === testimonials.length - 1 ? 0 : prev + 1;
      }
      return prev === 0 ? testimonials.length - 1 : prev - 1;
    });
  };

  const handleFaqToggle = (index) => {
    setActiveFaq((prev) => (prev === index ? null : index));
  };

  const updateFormValue = (event) => {
    const { name, value } = event.target;
    setFormData((state) => ({ ...state, [name]: value }));
    setFormErrors((state) => ({ ...state, [name]: '' }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Укажите ваше имя';
    }
    if (!formData.email.trim()) {
      errors.email = 'Введите рабочий email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Проверьте корректность email';
    }
    if (!formData.message.trim()) {
      errors.message = 'Расскажите о задаче';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validateForm()) return;
    setFormSent(true);
    setFormData({ name: '', email: '', message: '' });
    window.setTimeout(() => setFormSent(false), 4000);
  };

  return (
    <div className={styles.home}>
      <PageHelmet
        title="Интеллитал Групп — цифровая трансформация и IT-консалтинг"
        description="Интеллитал Групп помогает компаниям в Москве и по всей России проводить цифровую трансформацию, внедрять IT-решения и развивать аналитику."
        keywords="цифровая трансформация, IT-консалтинг, разработка ПО"
      />

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroTag}>Цифровая трансформация бизнеса</span>
          <h1 className={styles.heroTitle}>
            Ускоряем рост компаний через стратегию, аналитику и технологические решения
          </h1>
          <p className={styles.heroDescription}>
            Интеллитал Групп — команда экспертов по цифровой трансформации, которая помогает создавать продукты,
            повышающие операционную эффективность и открывающие новые источники дохода.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.primaryButton}>
              Обсудить проект
            </Link>
            <Link to="/o-kompanii" className={styles.secondaryButton}>
              Узнать о подходе
            </Link>
          </div>
          <div className={styles.statsGrid} aria-label="Ключевые показатели компании">
            {statsData.map((item, index) => (
              <article key={item.label} className={styles.statCard}>
                <p className={styles.statValue}>{displayedStats[index]}+</p>
                <p className={styles.statLabel}>{item.label}</p>
              </article>
            ))}
          </div>
        </div>
        <div
          className={styles.heroImageContainer}
          role="presentation"
          aria-hidden="true"
        >
          <img
            src="https://picsum.photos/1600/900?random=101"
            alt="Команда IT-специалистов планирует цифровую трансформацию"
          />
        </div>
      </section>

      <section className={styles.aboutBrief}>
        <div className={styles.sectionHeader}>
          <h2>О нас кратко</h2>
          <p>
            Мы интегрируем стратегию, технологию и операционное управление, чтобы ваши продукты и сервисы были
            востребованы рынком. Работаем по всей России с HQ в Москве.
          </p>
        </div>
        <div className={styles.aboutGrid}>
          <article>
            <h3>Миссия</h3>
            <p>
              Помогать лидерам рынка создавать устойчивую цифровую экосистему, в которой данные, процессы и команды
              работают синхронно.
            </p>
          </article>
          <article>
            <h3>Ценности</h3>
            <ul>
              <li>Прагматичность и измеримость результатов</li>
              <li>Прозрачность и партнерство с заказчиком</li>
              <li>Экспериментальность и инновации</li>
            </ul>
          </article>
          <article className={styles.aboutCta}>
            <p>
              Узнайте подробнее о нашей экспертизе, команде и проектах на странице «О компании».
            </p>
            <Link to="/o-kompanii">Перейти к подробностям</Link>
          </article>
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Ключевые направления</h2>
          <p>
            Мы сопровождаем путь от стратегии до внедрения и поддержки, формируя эффективную экосистему для вашего
            бизнеса.
          </p>
        </div>
        <div className={styles.serviceCards}>
          {servicesData.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Как мы работаем</h2>
          <p>От Discovery до поддержки: прозрачные этапы и согласованные KPI на каждом шаге проекта.</p>
        </div>
        <div className={styles.processTimeline}>
          {steps.map((step, index) => (
            <article key={step.title} className={styles.processStep}>
              <span className={styles.processNumber}>{`0${index + 1}`}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeader}>
          <h2>Проекты и результаты</h2>
          <p>
            Подход основан на твердой аналитике и четко измеряемых эффектах. Посмотрите, как мы трансформируем бизнес.
          </p>
        </div>
        <div className={styles.projectFilters}>
          {['Все', 'Автоматизация', 'Аналитика', 'Разработка', 'Инфраструктура'].map((filter) => (
            <button
              key={filter}
              type="button"
              className={`${styles.filterButton} ${activeProjectFilter === filter ? styles.filterActive : ''}`}
              onClick={() => setActiveProjectFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectBody}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.result}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.evidence}>
        <div className={styles.sectionHeader}>
          <h2>Доверие и команда</h2>
          <p>Мы объединяем экспертов с многолетним опытом, чтобы вместе с вами создавать цифровые продукты.</p>
        </div>
        <div className={styles.evidenceGrid}>
          <article className={styles.testimonials}>
            <header>
              <h3>Отзывы клиентов</h3>
            </header>
            <div className={styles.testimonialCard}>
              <p className={styles.testimonialQuote}>"{testimonials[testimonialIndex].quote}"</p>
              <p className={styles.testimonialAuthor}>{testimonials[testimonialIndex].author}</p>
              <p className={styles.testimonialRole}>{testimonials[testimonialIndex].role}</p>
            </div>
            <div className={styles.testimonialControls}>
              <button type="button" onClick={() => handleTestimonialChange('prev')}>
                ←
              </button>
              <button type="button" onClick={() => handleTestimonialChange('next')}>
                →
              </button>
            </div>
          </article>
          <article className={styles.team}>
            <header>
              <h3>Команда лидеров</h3>
            </header>
            <div className={styles.teamGrid}>
              {teamMembers.map((member) => (
                <div key={member.name} className={styles.teamCard}>
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                  <div>
                    <h4>{member.name}</h4>
                    <p className={styles.teamRole}>{member.role}</p>
                    <p className={styles.teamExpertise}>{member.expertise}</p>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </div>
      </section>

      <section className={styles.insights}>
        <div className={styles.sectionHeader}>
          <h2>Инсайты и ответы</h2>
          <p>Поделимся лучшими практиками и ответим на популярные вопросы по цифровым проектам.</p>
        </div>
        <div className={styles.insightsGrid}>
          <div className={styles.blogPreview}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImage}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/blog" className={styles.blogLink}>
                    Читать в блоге →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.faq}>
            {faqs.map((item, index) => (
              <div
                key={item.question}
                className={`${styles.faqItem} ${activeFaq === index ? styles.faqActive : ''}`}
              >
                <button
                  type="button"
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={activeFaq === index}
                >
                  {item.question}
                  <span aria-hidden="true">{activeFaq === index ? '−' : '+'}</span>
                </button>
                {activeFaq === index && <p>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Обсудим ваши задачи?</h2>
          <p>
            Оставьте контакты, и мы предложим конкретные сценарии трансформации с учетом ваших целей и ограничений.
          </p>
        </div>
        <form className={styles.ctaForm} onSubmit={handleSubmit} noValidate>
          <label htmlFor="cta-name">
            Имя
            <input
              id="cta-name"
              name="name"
              type="text"
              placeholder="Ваше имя"
              value={formData.name}
              onChange={updateFormValue}
              aria-invalid={Boolean(formErrors.name)}
            />
            {formErrors.name && <span className={styles.errorText}>{formErrors.name}</span>}
          </label>
          <label htmlFor="cta-email">
            Email
            <input
              id="cta-email"
              name="email"
              type="email"
              placeholder="name@company.ru"
              value={formData.email}
              onChange={updateFormValue}
              aria-invalid={Boolean(formErrors.email)}
            />
            {formErrors.email && <span className={styles.errorText}>{formErrors.email}</span>}
          </label>
          <label htmlFor="cta-message">
            Сообщение
            <textarea
              id="cta-message"
              name="message"
              rows="4"
              placeholder="Кратко опишите задачу"
              value={formData.message}
              onChange={updateFormValue}
              aria-invalid={Boolean(formErrors.message)}
            />
            {formErrors.message && <span className={styles.errorText}>{formErrors.message}</span>}
          </label>
          <button type="submit" className={styles.ctaButton}>
            Отправить запрос
          </button>
          {formSent && <p className={styles.successText}>Спасибо! Мы свяжемся с вами в течение рабочего дня.</p>}
        </form>
      </section>
    </div>
  );
};

export default HomePage;