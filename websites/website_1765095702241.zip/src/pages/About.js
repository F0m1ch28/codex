import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './About.module.css';

const milestones = [
  {
    year: '2015',
    title: 'Основание компании',
    description:
      'Создали Интеллитал Групп как команду экспертов по цифровым продуктам и управлению IT-проектами в крупных компаниях.',
  },
  {
    year: '2018',
    title: 'Развитие аналитики',
    description: 'Запустили направление Data & Analytics, сформировали собственную методологию внедрения BI-решений.',
  },
  {
    year: '2021',
    title: 'Облачные платформы',
    description:
      'Разработали платформу для быстрой миграции в облако и поставки продуктов по принципам DevOps и инфраструктуры как кода.',
  },
  {
    year: '2023',
    title: 'Экспансия и новые отрасли',
    description:
      'Расширили практику на промышленность, ритейл и финтех, сохранив экспертность и гибкость команды.',
  },
];

const values = [
  {
    title: 'Результат выше ожиданий',
    description:
      'Каждый проект заканчиваем измеримыми бизнес-эффектами. KPI и экономический эффект фиксируем уже на этапе Discovery.',
  },
  {
    title: 'Открытость и прозрачность',
    description:
      'Строим партнёрские отношения, совместно принимаем решения, делимся знаниями и оставляем документацию без «белых пятен».',
  },
  {
    title: 'Смелость в инновациях',
    description:
      'Постоянно тестируем гипотезы, используем дизайн-мышление и lean-подходы, чтобы создавать актуальные цифровые продукты.',
  },
];

const expertise = [
  'Комплексная цифровая трансформация и управление портфелем инициатив',
  'Дизайн и разработка цифровых продуктов по Agile и DevOps',
  'Стратегия и внедрение решений для анализа данных и искусственного интеллекта',
  'Построение облачной и гибридной инфраструктуры с высоким SLA',
  'Обучение, change management и развитие компетенций внутренних команд',
];

const AboutPage = () => {
  return (
    <div className={styles.about}>
      <PageHelmet
        title="О компании Интеллитал Групп — цифровая трансформация бизнеса"
        description="История, ценности и экспертиза Интеллитал Групп. Мы создаем цифровые продукты, развиваем аналитику и помогаем бизнесу масштабироваться."
        keywords="Интеллитал Групп, цифровая трансформация, IT-консалтинг Москва"
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Мы создаем платформу для устойчивого цифрового роста</h1>
          <p>
            Интеллитал Групп объединяет стратегов, инженеров и аналитиков. Мы создаем технологические решения, которые
            помогают лидерам рынка адаптироваться к изменениям и опережать конкурентов.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1200/800?random=114"
            alt="Команда Интеллитал Групп обсуждает стратегию цифровой трансформации"
          />
        </div>
      </section>

      <section className={styles.mission}>
        <div className={styles.sectionHeader}>
          <h2>Наша миссия и подход</h2>
          <p>
            Мы верим в долгосрочное партнерство и синхронизацию бизнеса и технологий. Поэтому каждое решение строим на
            трех опорах: стратегии, данных и культуре.
          </p>
        </div>
        <div className={styles.missionGrid}>
          <article>
            <h3>Стратегия</h3>
            <p>Формируем понятную цифровую стратегию, где каждая инициатива имеет KPI и срок окупаемости.</p>
          </article>
          <article>
            <h3>Данные</h3>
          <p>Строим сквозную аналитику и инфраструктуру данных, чтобы управлять на основе фактов и сценариев.</p>
          </article>
          <article>
            <h3>Культура</h3>
            <p>Развиваем продуктовое мышление и навыки команд, чтобы изменения закрепились и масштабировались.</p>
          </article>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className={styles.sectionHeader}>
          <h2>Вехи развития</h2>
          <p>Путь от небольшой консалтинговой команды до мультидисциплинарного партнера цифровой трансформации.</p>
        </div>
        <div className={styles.timeline}>
          {milestones.map((item) => (
            <article key={item.year}>
              <span className={styles.timelineYear}>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.values}>
        <div className={styles.sectionHeader}>
          <h2>Ценности, на которых строим работу</h2>
        </div>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.expertise}>
        <div className={styles.sectionHeader}>
          <h2>Экспертиза и компетенции</h2>
        </div>
        <ul className={styles.expertiseList}>
          {expertise.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className={styles.culture}>
        <div className={styles.sectionHeader}>
          <h2>Мы работаем как единая команда с заказчиком</h2>
          <p>
            Организуем совместные центры компетенций, внедряем гибкие методологии и развиваем внутренние команды, чтобы
            изменения были устойчивыми.
          </p>
        </div>
        <div className={styles.cultureGrid}>
          <article>
            <h3>Совместное управление</h3>
            <p>Создаем общие KPI и единый проектный офис, чтобы видеть эффекты в реальном времени.</p>
          </article>
          <article>
            <h3>Обучение и сопровождение</h3>
            <p>Проводим тренинги, воркшопы, передаем рабочие материалы и поддерживаем команды после релиза.</p>
          </article>
          <article>
            <h3>Инновации и эксперименты</h3>
            <p>Помогаем запускать лаборатории инноваций, тестировать гипотезы и быстро выводить MVP.</p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;