import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} id="footer">
      <div className={styles.container}>
        <div className={styles.brandColumn}>
          <div className={styles.logoGroup}>
            <span className={styles.logoMark}>IG</span>
            <div>
              <p className={styles.logoText}>Интеллитал Групп</p>
              <p className={styles.logoSub}>Цифровая трансформация и IT-консалтинг</p>
            </div>
          </div>
          <p className={styles.brandDescription}>
            Создаем технологические решения, которые ускоряют рост бизнеса и укрепляют конкурентоспособность на рынке.
          </p>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Навигация</h3>
          <ul className={styles.linkList}>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/uslugi">Услуги</Link></li>
            <li><Link to="/o-kompanii">О компании</Link></li>
            <li><Link to="/blog">Блог</Link></li>
            <li><Link to="/kontakty">Контакты</Link></li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Документы</h3>
          <ul className={styles.linkList}>
            <li><Link to="/polzovatelskoe-soglashenie">Пользовательское соглашение</Link></li>
            <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
            <li><Link to="/politika-cookie">Политика использования cookie</Link></li>
          </ul>
        </div>
        <div className={styles.contactsColumn}>
          <h3 className={styles.columnTitle}>Контакты</h3>
          <address className={styles.address}>
            <span>Россия, 125047, г. Москва, ул. Лесная, д. 5, офис 210</span>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:info@intellital.ru">info@intellital.ru</a>
          </address>
          <div className={styles.socials}>
            <a href="https://www.linkedin.com" aria-label="LinkedIn" target="_blank" rel="noreferrer">
              <span aria-hidden="true">in</span>
            </a>
            <a href="https://www.youtube.com" aria-label="YouTube" target="_blank" rel="noreferrer">
              <span aria-hidden="true">YT</span>
            </a>
            <a href="https://t.me" aria-label="Telegram" target="_blank" rel="noreferrer">
              <span aria-hidden="true">TG</span>
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Интеллитал Групп. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;