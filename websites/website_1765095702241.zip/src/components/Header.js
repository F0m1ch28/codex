import React, { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Главная' },
  { path: '/uslugi', label: 'Услуги' },
  { path: '/o-kompanii', label: 'О компании' },
  { path: '/blog', label: 'Блог' },
  { path: '/kontakty', label: 'Контакты' },
];

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [isMenuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="Интеллитал Групп">
          <span className={styles.logoMark}>IG</span>
          <span className={styles.logoText}>Интеллитал Групп</span>
        </Link>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
              onClick={closeMenu}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <Link to="/kontakty" className={styles.actionButton}>
          Связаться
        </Link>
        <button
          type="button"
          className={`${styles.burger} ${isMenuOpen ? styles.burgerOpen : ''}`}
          onClick={toggleMenu}
          aria-label="Меню"
          aria-expanded={isMenuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;