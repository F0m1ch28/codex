import { useEffect } from 'react';

const PageHelmet = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }

    const existingDescription = document.querySelector('meta[name="description"]');
    if (description && existingDescription) {
      existingDescription.setAttribute('content', description);
    }

    const existingKeywords = document.querySelector('meta[name="keywords"]');
    if (keywords && existingKeywords) {
      existingKeywords.setAttribute('content', keywords);
    }
  }, [title, description, keywords]);

  return null;
};

export default PageHelmet;