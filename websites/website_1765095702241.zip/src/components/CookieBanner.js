import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('cookieConsent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return () => {};
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem('cookieConsent', value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Мы используем cookie</h4>
        <p>
          Cookie помогают улучшить работу сайта и адаптировать контент под ваши задачи. Вы можете изменить настройки в
          любое время в политике использования cookie.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondary} onClick={() => handleConsent('declined')}>
          Отклонить
        </button>
        <button type="button" className={styles.primary} onClick={() => handleConsent('accepted')}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;