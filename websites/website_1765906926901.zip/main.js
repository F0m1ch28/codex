document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.site-nav-toggle');
    const navigation = document.querySelector('.site-navigation');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            navigation.classList.toggle('open');
        });

        navigation.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navigation.classList.remove('open');
            });
        });
    }

    const flowNodes = document.querySelectorAll('.flow-node');
    if (flowNodes.length) {
        flowNodes.forEach(node => {
            node.addEventListener('mouseenter', () => setActiveNode(node.dataset.node));
            node.addEventListener('focus', () => setActiveNode(node.dataset.node));
            node.addEventListener('click', () => setActiveNode(node.dataset.node));
        });
    }

    function setActiveNode(target) {
        flowNodes.forEach(node => {
            if (node.dataset.node === target) {
                node.classList.add('active');
            } else {
                node.classList.remove('active');
            }
        });
    }

    const contactForm = document.getElementById('contactForm');
    const contactStatus = document.getElementById('contactStatus');

    if (contactForm) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();

            const name = contactForm.contactName.value.trim();
            const email = contactForm.contactEmail.value.trim();
            const organization = contactForm.contactOrganization.value.trim();
            const message = contactForm.contactMessage.value.trim();

            if (!name || !email || !organization || !message) {
                contactStatus.textContent = 'Please complete all required fields before submitting.';
                contactStatus.style.color = '#f2994a';
                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                contactStatus.textContent = 'Please enter a valid email address.';
                contactStatus.style.color = '#f2994a';
                return;
            }

            contactStatus.textContent = 'Thank you! Our district energy team will reach out within two business days.';
            contactStatus.style.color = '#1e6f5c';
            contactForm.reset();
        });
    }
});