import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import styles from "./Header.module.css";

const navLinks = [
  { to: "/", label: "Start" },
  { to: "/services", label: "Angebote" },
  { to: "/guide", label: "Guide" },
  { to: "/programs", label: "Programme" },
  { to: "/tools", label: "Tools" },
  { to: "/blog", label: "Blog" },
  { to: "/about", label: "Über uns" },
  { to: "/contact", label: "Kontakt" }
];

function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ""}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Morilavero Startseite">
          <span className={styles.logoMark}>Morilavero</span>
          <span className={styles.logoTag}>Digitale Balance</span>
        </NavLink>
        <nav className={`${styles.nav} ${isOpen ? styles.open : ""}`} aria-label="Hauptnavigation">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ""}`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <button
          className={`${styles.burger} ${isOpen ? styles.burgerOpen : ""}`}
          onClick={() => setIsOpen((prev) => !prev)}
          aria-expanded={isOpen}
          aria-controls="mobile-navigation"
          aria-label="Hauptmenü umschalten"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
}

export default Header;