import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <div className={styles.logo}>Morilavero</div>
          <p>
            Deine digitale Begleiterin, um wieder mehr Energie, Fokus und Ruhe in deinen Alltag zu holen.
          </p>
          <p className={styles.address}>
            Morilavero GmbH<br />
            Lindenstraße 12<br />
            10115 Berlin<br />
            Deutschland
          </p>
        </div>
        <div className={styles.column}>
          <h4>Navigation</h4>
          <NavLink to="/">Start</NavLink>
          <NavLink to="/services">Angebote</NavLink>
          <NavLink to="/programs">Programme</NavLink>
          <NavLink to="/tools">Tools</NavLink>
          <NavLink to="/blog">Blog</NavLink>
        </div>
        <div className={styles.column}>
          <h4>Rechtliches</h4>
          <NavLink to="/terms">Nutzungsbedingungen</NavLink>
          <NavLink to="/legal">Rechtliche Hinweise</NavLink>
          <NavLink to="/privacy">Datenschutz</NavLink>
          <NavLink to="/imprint">Impressum</NavLink>
        </div>
        <div className={styles.column}>
          <h4>Kontakt</h4>
          <NavLink to="/contact">Kontaktformular</NavLink>
          <a href="mailto:hello@morilavero.de">hello@morilavero.de</a>
          <span className={styles.note}>
            Keine medizinische Beratung. Bitte wende dich bei ernsthaften Anliegen an qualifizierte Fachpersonen.
          </span>
        </div>
      </div>
      <div className={styles.subFooter}>
        <span>© {year} Morilavero. Alle Rechte vorbehalten.</span>
        <span className={styles.made}>Mit Fokus auf Menschen &amp; digitale Balance.</span>
      </div>
    </footer>
  );
}

export default Footer;