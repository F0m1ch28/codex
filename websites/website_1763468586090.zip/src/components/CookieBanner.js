import React, { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

const storageKey = "morilavero-cookie-consent";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(storageKey);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(storageKey, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h3>Cookies für mehr Klarheit</h3>
        <p>
          Wir nutzen Cookies, um unsere Inhalte für dich zu verbessern. Du kannst selbst entscheiden, ob du einverstanden bist.
        </p>
      </div>
      <div className={styles.actions}>
        <button onClick={() => handleConsent("declined")} className={styles.secondary}>
          Ablehnen
        </button>
        <button onClick={() => handleConsent("accepted")} className={styles.primary}>
          Akzeptieren
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;