import React, { useEffect, useState } from "react";
import styles from "./ScrollToTop.module.css";

function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setVisible(window.scrollY > 320);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <button
      type="button"
      className={`${styles.button} ${visible ? styles.show : ""}`}
      onClick={handleClick}
      aria-label="Zurück nach oben scrollen"
    >
      ↑
    </button>
  );
}

export default ScrollToTop;