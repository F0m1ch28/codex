import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import styles from "./Home.module.css";

const statsConfig = [
  { label: "Fokus-Momente pro Woche", target: 1200 },
  { label: "Begleitete Reflexionen", target: 480 },
  { label: "Positive Rückmeldungen", target: 320 }
];

const testimonials = [
  {
    name: "Lena, Teamlead aus Köln",
    quote:
      "Morilavero hat mir geholfen, achtsamere Breaks einzuplanen und Grenzen klarer zu setzen. Ich spüre wieder mehr Energie für die richtigen Dinge."
  },
  {
    name: "Jonas, Produktmanager",
    quote:
      "Die Tools sind unkompliziert und realitätsnah. Besonders die Reflexionsfragen bringen mich in herausfordernden Wochen zurück auf Kurs."
  },
  {
    name: "Mira, Selbstständig",
    quote:
      "Seit ich mit den Mikropausen-Challenges arbeite, fühle ich mich weniger ausgelaugt und kann kreativer arbeiten."
  }
];

const themes = [
  { title: "Akuter Stress", description: "Wie du Mikro-Pausen findest, ohne deinen Flow zu verlieren.", link: "/tools" },
  { title: "Überlastung", description: "Klarheit darüber, welche Aufgaben du heute wirklich brauchst.", link: "/programs" },
  { title: "Ständige Erreichbarkeit", description: "Impulse für digitale Grenzen, die du auch mutig kommunizierst.", link: "/guide" },
  { title: "Innere Leere", description: "Reflexionen, die dein inneres Feuer wieder anstoßen.", link: "/blog" }
];

const services = [
  {
    title: "Energie-Reset Pfad",
    description: "Geführte Audios & Reflexionen, die dich in weniger als 10 Minuten pro Tag zurück zu dir bringen.",
    link: "/programs",
    icon: "🌿"
  },
  {
    title: "Grenzen-Kompass",
    description: "Konkrete Formulierungen & Checklisten für respektvolle Grenzen in Meetings und Chats.",
    link: "/tools",
    icon: "🧭"
  },
  {
    title: "Routinen-Studio",
    description: "Kleine Experimente für mehr Fokus & Pause, individuell auf deine Woche abgestimmt.",
    link: "/services",
    icon: "🧩"
  }
];

const process = [
  {
    step: "1. Beobachten",
    description: "Wir beginnen mit ehrlichem Check-in: Wie fühlt sich dein Alltag gerade an? Was zieht Energie?"
  },
  {
    step: "2. Entlasten",
    description: "Kurze Mikro-Pausen, klare Grenzen und Prioritäten bringen dich zurück in Balance."
  },
  {
    step: "3. Stärken",
    description: "Du etablierst Rituale, die sich wirklich in dein Leben fügen – ohne Perfektionsdruck."
  },
  {
    step: "4. Verstetigen",
    description: "Wir begleiten dich mit Erinnerungen und Kurskorrekturen, damit du langfristig dranbleibst."
  }
];

const projects = [
  { id: 1, category: "Teams", title: "Team-Rhythmus Canvas", image: "https://picsum.photos/1200/800?random=41" },
  { id: 2, category: "Individuals", title: "Deep Work Sprint", image: "https://picsum.photos/1200/800?random=42" },
  { id: 3, category: "Leaders", title: "Leadership Reset Sessions", image: "https://picsum.photos/1200/800?random=43" },
  { id: 4, category: "Individuals", title: "Evening Wind-Down Flow", image: "https://picsum.photos/1200/800?random=44" }
];

const team = [
  { name: "Sofia Kramer", role: "Head of Wellbeing", image: "https://picsum.photos/400/400?random=31", bio: "Coachin für achtsame Performance, liebt klare Prioritäten und Kaffee in Ruhe." },
  { name: "Max Ritter", role: "Digital Habit Designer", image: "https://picsum.photos/400/400?random=32", bio: "Entwickelt Tools, die auch in vollen Kalendern realistisch funktionieren." },
  { name: "Ana Schubert", role: "Community Guide", image: "https://picsum.photos/400/400?random=33", bio: "Verbindet Menschen und sorgt dafür, dass niemand mit seinen Fragen allein bleibt." }
];

const faqs = [
  {
    question: "Ist Morilavero eine Therapie?",
    answer: "Nein. Wir bieten digitale Ressourcen für dein tägliches Wohlbefinden. Bei psychischen Krisen oder anhaltendem Leidensdruck kontaktiere bitte professionelle Hilfe."
  },
  {
    question: "Wie viel Zeit brauche ich pro Woche?",
    answer: "Viele unserer Impulse dauern 5-12 Minuten. Du wählst flexibel aus, was zu deiner Woche passt."
  },
  {
    question: "Brauche ich zusätzliche Apps?",
    answer: "Nein. Morilavero läuft in deinem Browser – sowohl mobil als auch am Desktop."
  },
  {
    question: "Kann ich das im Team nutzen?",
    answer: "Ja. Wir haben Module speziell für Teams, damit ihr gemeinsam gesunde Grenzen etabliert."
  }
];

const blogPreview = [
  {
    slug: "achtsame-pausen-im-hybrid-alltag",
    title: "Achtsame Pausen im Hybrid-Alltag",
    excerpt: "Warum Micro-Breaks deine Energie schützen – und wie du sie wirklich umsetzt.",
    image: "https://picsum.photos/800/600?random=51"
  },
  {
    slug: "grenzen-kommunizieren-ohne-schuldgefuehl",
    title: "Grenzen kommunizieren ohne Schuldgefühl",
    excerpt: "Eine Schritt-für-Schritt-Anleitung, wie du klar und respektvoll Nein sagst.",
    image: "https://picsum.photos/800/600?random=52"
  },
  {
    slug: "digital-detox-oder-digitale-balance",
    title: "Digital Detox oder digitale Balance?",
    excerpt: "Wie du einen realistischen Umgang mit deinen Geräten findest.",
    image: "https://picsum.photos/800/600?random=53"
  }
];

function Home() {
  const countersRef = useRef([]);
  const [counterValues, setCounterValues] = useState(statsConfig.map(() => 0));
  const [filter, setFilter] = useState("Alle");

  useEffect(() => {
    const observers = countersRef.current.map((element, index) => {
      if (!element) return null;
      return new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              animateCounter(index, statsConfig[index].target);
            }
          });
        },
        { threshold: 0.6 }
      );
    });

    countersRef.current.forEach((element, index) => {
      if (element && observers[index]) {
        observers[index].observe(element);
      }
    });

    return () => {
      observers.forEach((observer) => observer && observer.disconnect());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const animateCounter = (index, target) => {
    let start = 0;
    const duration = 1800;
    const increment = target / (duration / 16);
    const step = () => {
      start += increment;
      if (start < target) {
        setCounterValues((prev) => {
          const updated = [...prev];
          updated[index] = Math.floor(start);
          return updated;
        });
        requestAnimationFrame(step);
      } else {
        setCounterValues((prev) => {
          const updated = [...prev];
          updated[index] = target;
          return updated;
        });
      }
    };
    requestAnimationFrame(step);
  };

  const filteredProjects =
    filter === "Alle"
      ? projects
      : projects.filter((project) => project.category === filter);

  return (
    <>
      <Helmet>
        <title>Morilavero | Weniger Ausgebranntsein. Mehr Energie für dich.</title>
        <meta
          name="description"
          content="Morilavero unterstützt dich mit digitalen Guides, Programmen und Tools auf dem Weg zu mehr Energie, Klarheit und gesunden Grenzen."
        />
        <link rel="canonical" href="https://www.morilavero.de/" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.badge}>Digitale Balance für deinen Alltag</span>
          <h1>Weniger Ausgebranntsein. Mehr Energie für dich.</h1>
          <p>
            Morilavero hilft dir dabei, achtsamer Pause zu machen, Grenzen klar zu kommunizieren und deinen Fokus zu schützen. Empathisch, praktisch, ohne Esoterik.
          </p>
          <div className={styles.heroActions}>
            <Link to="/programs" className={styles.primaryCta}>
              Jetzt starten
            </Link>
            <Link to="/contact" className={styles.secondaryCta}>
              Energie zurückholen
            </Link>
          </div>
          <div className={styles.heroMeta}>
            <div>
              <strong>100%</strong>
              <span>Realtime Tools</span>
            </div>
            <div>
              <strong>Community</strong>
              <span>Unterstützende Impulse</span>
            </div>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Professionelle Person blickt fokussiert aus dem Fenster"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.intro}>
        <div className={styles.sectionHeader}>
          <h2>Emotionale Erschöpfung verstehen</h2>
          <p>
            Manchmal fühlt sich alles grau an – selbst die Dinge, die du früher geliebt hast. Emotionale Erschöpfung entsteht, wenn deine inneren Speicher permanent schrumpfen. Bei Morilavero findest du realistische Wege heraus aus dieser Dauerschleife.
          </p>
        </div>
      </section>

      <section className={styles.stats} aria-label="Ergebnisse in Zahlen">
        {statsConfig.map((stat, index) => (
          <div
            className={styles.statCard}
            key={stat.label}
            ref={(el) => (countersRef.current[index] = el)}
          >
            <span className={styles.statValue}>{counterValues[index]}</span>
            <span className={styles.statLabel}>{stat.label}</span>
          </div>
        ))}
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHeader}>
          <h2>Was sich für dich verändert</h2>
          <p>Wir konzentrieren uns auf realistische Schritte, die deine Energie wieder auffüllen.</p>
        </div>
        <div className={styles.benefitGrid}>
          <article>
            <h3>Mehr Klarheit</h3>
            <p>Du sortierst Prioritäten ehrlich und schaffst Raum für das, was dir wichtig ist.</p>
          </article>
          <article>
            <h3>Bewusste Pausen</h3>
            <p>Kleine Pausen sind ein Commitment an dich selbst – nicht nur ein Luxus.</p>
          </article>
          <article>
            <h3>Starke Grenzen</h3>
            <p>Du sagst selbstbewusst Nein und schützt deine Energie, ohne dich schuldig zu fühlen.</p>
          </article>
          <article>
            <h3>Neue Rituale</h3>
            <p>Du verankerst Routinen, die dich wirklich tragen – ohne Druck, perfekt sein zu müssen.</p>
          </article>
        </div>
      </section>

      <section className={styles.themes} aria-label="Themen-Übersicht">
        <div className={styles.sectionHeader}>
          <h2>Themen, die wir mit dir angehen</h2>
        </div>
        <div className={styles.themeGrid}>
          {themes.map((theme) => (
            <Link to={theme.link} key={theme.title} className={styles.themeCard}>
              <div>
                <h3>{theme.title}</h3>
                <p>{theme.description}</p>
              </div>
              <span aria-hidden="true">→</span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Warum Morilavero</h2>
          <p>Wir kombinieren aktuelle Erkenntnisse aus Arbeitspsychologie, Habit Design und Community-Support zu einem flexiblen System für dich.</p>
        </div>
        <div className={styles.serviceGrid}>
          {services.map((service) => (
            <article className={styles.serviceCard} key={service.title}>
              <span className={styles.icon}>{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to={service.link} className={styles.serviceLink}>
                Mehr erfahren
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-label="So arbeiten wir">
        <div className={styles.sectionHeader}>
          <h2>Dein Weg mit Morilavero</h2>
          <p>Wir halten den Prozess transparent, damit du jederzeit weißt, wo du stehst.</p>
        </div>
        <div className={styles.processTimeline}>
          {process.map((item) => (
            <div className={styles.processStep} key={item.step}>
              <span className={styles.stepBadge}>{item.step}</span>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Stimmen aus der Community</h2>
        </div>
        <div className={styles.carousel} role="list">
          {testimonials.map((testimonial) => (
            <article key={testimonial.name} className={styles.testimonial} role="listitem">
              <p className={styles.quote}>“{testimonial.quote}”</p>
              <span className={styles.name}>{testimonial.name}</span>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className={styles.sectionHeader}>
          <h2>Unser Team an deiner Seite</h2>
          <p>Wir verbinden Empathie mit pragmatischen Lösungen.</p>
        </div>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article className={styles.teamCard} key={member.name}>
              <div className={styles.teamImage}>
                <img src={member.image} alt={`Porträt von ${member.name}`} loading="lazy" />
              </div>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeader}>
          <h2>Projekte & Experimente</h2>
          <p>Entdecke Formate, die bereits klarer gemacht haben, was gesunde Arbeit bedeutet.</p>
        </div>
        <div className={styles.filters}>
          {["Alle", "Individuals", "Teams", "Leaders"].map((category) => (
            <button
              key={category}
              className={`${styles.filterButton} ${filter === category ? styles.filterActive : ""}`}
              onClick={() => setFilter(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article className={styles.projectCard} key={project.id}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={`Projekt ${project.title}`} loading="lazy" />
              </div>
              <div className={styles.projectBody}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <h2>FAQ: Häufige Fragen</h2>
        </div>
        <div className={styles.accordion}>
          {faqs.map((item, index) => (
            <details key={item.question} className={styles.accordionItem} open={index === 0}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={styles.sectionHeader}>
          <h2>Neu im Blog</h2>
          <p>Inspirationen für mehr Energie und Klarheit.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPreview.map((post) => (
            <article className={styles.blogCard} key={post.slug}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogBody}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                  Weiterlesen
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaInner}>
          <h2>Bist du bereit, deine Energie zurückzuholen?</h2>
          <p>
            Morilavero begleitet dich Schritt für Schritt. Ohne Druck, dafür mit Fokus auf das, was dich wirklich stärkt.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/contact" className={styles.primaryCta}>
              Gespräch anfragen
            </Link>
            <Link to="/guide" className={styles.secondaryCta}>
              Zum Quick-Start Guide
            </Link>
          </div>
          <span className={styles.disclaimer}>
            Hinweis: Morilavero ersetzt keine medizinische oder psychotherapeutische Beratung. Bei ernsthaften Belastungen suche bitte professionelle Hilfe.
          </span>
        </div>
      </section>
    </>
  );
}

export default Home;