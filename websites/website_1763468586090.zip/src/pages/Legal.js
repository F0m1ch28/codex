import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Legal.module.css";

function Legal() {
  return (
    <>
      <Helmet>
        <title>Rechtliche Hinweise | Morilavero</title>
        <meta
          name="description"
          content="Rechtliche Hinweise zur Nutzung der Morilavero Plattform und ihrer Inhalte."
        />
        <link rel="canonical" href="https://www.morilavero.de/legal" />
      </Helmet>
      <section className={styles.page}>
        <h1>Rechtliche Hinweise</h1>
        <p>
          Morilavero ist eine Plattform für digitale Ressourcen rund um Wohlbefinden, Fokus und Grenzen. Wir stellen keine Diagnosen und ersetzen keine medizinische oder psychotherapeutische Beratung.
        </p>
        <p>
          Unsere Inhalte werden sorgfältig erstellt, dennoch übernehmen wir keine Haftung für die Aktualität, Richtigkeit oder Vollständigkeit. Eigene Entscheidungen triffst du auf eigene Verantwortung. Verlinkte Inhalte externer Seiten liegen außerhalb unseres Einflussbereichs.
        </p>
        <p>
          Bei ernsthaften gesundheitlichen Anliegen wende dich bitte an Ärzt:innen, Psychotherapeut:innen oder andere qualifizierte Fachpersonen.
        </p>
      </section>
    </>
  );
}

export default Legal;