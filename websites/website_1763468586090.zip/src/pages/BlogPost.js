import React from "react";
import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import styles from "./BlogPost.module.css";

const posts = {
  "achtsame-pausen-im-hybrid-alltag": {
    title: "Achtsame Pausen im Hybrid-Alltag",
    date: "12. März 2024",
    content: [
      "Hybrid bedeutet oft: Grenzen verschwimmen. Zwischen Studio, Büro und Homeoffice bleibt wenig Raum, wirklich herunterzufahren.",
      "Starte mit einem Mikro-Check-in: Welche Stimmung bringst du gerade mit? Danach lege eine Pause fest – ja, trage sie in deinen Kalender ein.",
      "Nutze Techniken wie Box Breathing oder einen 90-Sekunden-Reset, um dein Nervensystem zu beruhigen. Mit Pausen-Tags signalisierst du deinem Umfeld: Ich bin wieder da um 14:25 Uhr.",
      "Am Ende des Tages reflektiere kurz: Welche Pause hat sich gut angefühlt, was brauchst du morgen?"
    ],
    image: "https://picsum.photos/1200/800?random=71"
  },
  "grenzen-kommunizieren-ohne-schuldgefuehl": {
    title: "Grenzen kommunizieren ohne Schuldgefühl",
    date: "05. März 2024",
    content: [
      "Grenzen klar zu artikulieren schützt deine Energie. Gleichzeitig löst es oft innere Zweifel aus.",
      "Bereite deine Botschaft vor: Was ist dein Wunsch, was ist dein Bedürfnis? Verknüpfe beides mit einem konkreten Vorschlag.",
      "Beispiel: „Ich merke, dass mich spontane Aufgaben ziehen. Lass uns Anfragen sammeln und nachmittags priorisieren.“",
      "Du darfst dich danach unwohl fühlen – das ist normal. Feiere trotzdem, dass du für dich eingestanden bist."
    ],
    image: "https://picsum.photos/1200/800?random=72"
  },
  "digital-detox-oder-digitale-balance": {
    title: "Digital Detox oder digitale Balance?",
    date: "22. Februar 2024",
    content: [
      "Komplett offline zu gehen ist nicht immer realistisch – und oft auch nicht nötig.",
      "Digitale Balance bedeutet, bewusst zu wählen, was dir Energie gibt. Starte mit Screens, die du reduzieren willst, und kreiere neue Rituale.",
      "Definiere Fokusfenster, in denen Apps auf stumm sind. Leg dir Abschlussrituale für den Feierabend zurecht.",
      "Feiere kleine Schritte: Eine Stunde ohne Scrollen, ein Abend mit einem analogen Hobby."
    ],
    image: "https://picsum.photos/1200/800?random=73"
  }
};

function BlogPost() {
  const { slug } = useParams();
  const post = posts[slug];

  if (!post) {
    return (
      <section className={styles.notFound}>
        <h1>Artikel nicht gefunden</h1>
        <p>Bitte wähle einen anderen Beitrag aus.</p>
        <Link to="/blog" className={styles.linkBack}>
          Zurück zum Blog
        </Link>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Morilavero Blog</title>
        <meta name="description" content={post.content[0]} />
        <link rel="canonical" href={`https://www.morilavero.de/blog/${slug}`} />
      </Helmet>
      <article className={styles.article}>
        <header>
          <span>{post.date}</span>
          <h1>{post.title}</h1>
        </header>
        <div className={styles.heroImage}>
          <img src={post.image} alt={post.title} loading="lazy" />
        </div>
        <div className={styles.content}>
          {post.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>
        <footer className={styles.footer}>
          <span>
            Dieser Beitrag ersetzt keine medizinische Beratung. Bitte suche professionelle Hilfe, wenn du sie brauchst.
          </span>
          <Link to="/blog" className={styles.linkBack}>
            Weitere Artikel
          </Link>
        </footer>
      </article>
    </>
  );
}

export default BlogPost;