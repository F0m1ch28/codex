import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Guide.module.css";

const steps = [
  {
    title: "Check-in",
    description: "Bewerte deine Energie auf einer Skala von 1 bis 5. Notiere, was heute Energie zieht."
  },
  {
    title: "Mini-Pause planen",
    description: "Plane mindestens zwei bewusst freigehaltene Atem-Minuten in deinem Kalender ein."
  },
  {
    title: "Grenze formulieren",
    description: "Überlege, welche Nachricht oder Anfrage du heute freundlich begrenzen möchtest."
  },
  {
    title: "Reflexion am Abend",
    description: "Was hat dir Energie gegeben? Was möchtest du morgen wiederholen?"
  }
];

function Guide() {
  return (
    <>
      <Helmet>
        <title>Quick-Start Guide | Morilavero</title>
        <meta
          name="description"
          content="Dein Quick-Start Guide für weniger Überforderung und mehr Energie in vier klaren Schritten."
        />
        <link rel="canonical" href="https://www.morilavero.de/guide" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Dein Quick-Start Guide</h1>
        <p>
          Vier Schritte, die du heute ausprobieren kannst. Ohne Druck, dafür mit Klarheit.
        </p>
      </section>
      <section className={styles.steps}>
        {steps.map((step, index) => (
          <article key={step.title} className={styles.step}>
            <span className={styles.badge}>{index + 1}</span>
            <h2>{step.title}</h2>
            <p>{step.description}</p>
          </article>
        ))}
      </section>
    </>
  );
}

export default Guide;