import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import styles from "./Blog.module.css";

const posts = [
  {
    slug: "achtsame-pausen-im-hybrid-alltag",
    title: "Achtsame Pausen im Hybrid-Alltag",
    excerpt:
      "Wie du in vollgepackten Tagen Mini-Auszeiten schaffst und dadurch konzentrierter bleibst.",
    date: "12. März 2024",
    image: "https://picsum.photos/800/600?random=61"
  },
  {
    slug: "grenzen-kommunizieren-ohne-schuldgefuehl",
    title: "Grenzen kommunizieren ohne Schuldgefühl",
    excerpt:
      "Raus aus dem Kopfkino: So formulierst du Nein-Botschaften freundlich und klar.",
    date: "05. März 2024",
    image: "https://picsum.photos/800/600?random=62"
  },
  {
    slug: "digital-detox-oder-digitale-balance",
    title: "Digital Detox oder digitale Balance?",
    excerpt:
      "Warum radikal offline nicht immer die Lösung ist – und wie du passende Rituale findest.",
    date: "22. Februar 2024",
    image: "https://picsum.photos/800/600?random=63"
  }
];

function Blog() {
  return (
    <>
      <Helmet>
        <title>Morilavero Blog | Impulse für digitale Balance</title>
        <meta
          name="description"
          content="Frische Artikel zu Stress, Grenzen, Energie und digitalen Routinen – geschrieben von Morilavero für dich."
        />
        <link rel="canonical" href="https://www.morilavero.de/blog" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Blog & Insights</h1>
        <p>Gedanken, Impulse und kleine Experimente, die dich wieder mit dir verbinden.</p>
      </section>
      <section className={styles.grid}>
        {posts.map((post) => (
          <article className={styles.card} key={post.slug}>
            <div className={styles.imageWrapper}>
              <img src={post.image} alt={post.title} loading="lazy" />
            </div>
            <div className={styles.body}>
              <span>{post.date}</span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <Link to={`/blog/${post.slug}`} className={styles.link}>
                Zum Artikel
              </Link>
            </div>
          </article>
        ))}
      </section>
    </>
  );
}

export default Blog;