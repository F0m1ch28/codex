import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Tools.module.css";

const tools = [
  {
    title: "Energie Radar",
    type: "Check-in",
    description: "Visualisiere dein Energielevel über die Woche hinweg.",
    linkText: "Template öffnen"
  },
  {
    title: "Grenzen-Canvas",
    type: "Vorlage",
    description: "Definiere klare Grenzen für Meetings, Chats und Auszeiten.",
    linkText: "Canvas nutzen"
  },
  {
    title: "Pause Reminder",
    type: "Planner",
    description: "Plane Mikro-Pausen anhand deiner Termine – automatisch und individuell.",
    linkText: "Reminder aktivieren"
  },
  {
    title: "Reflexionskarten",
    type: "Impulse",
    description: "Kurze Fragen, die dich abends wieder zu dir bringen.",
    linkText: "Fragen entdecken"
  }
];

function Tools() {
  return (
    <>
      <Helmet>
        <title>Tools & Ressourcen | Morilavero</title>
        <meta
          name="description"
          content="Digitale Tools, Checklisten und Templates von Morilavero, die deine Energie im Alltag schützen."
        />
        <link rel="canonical" href="https://www.morilavero.de/tools" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Tools & Ressourcen</h1>
        <p>Nutze digitale Helfer, die dir deine Energie sichtbar machen und schützen.</p>
      </section>
      <section className={styles.grid}>
        {tools.map((tool) => (
          <article className={styles.card} key={tool.title}>
            <header>
              <span>{tool.type}</span>
              <h2>{tool.title}</h2>
            </header>
            <p>{tool.description}</p>
            <button className={styles.button} type="button">
              {tool.linkText}
            </button>
          </article>
        ))}
      </section>
    </>
  );
}

export default Tools;