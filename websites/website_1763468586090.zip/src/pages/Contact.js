import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Contact.module.css";

const initialState = {
  name: "",
  email: "",
  topic: "",
  message: ""
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const errors = {
    name: !formData.name ? "Bitte gib deinen Namen ein." : "",
    email: !formData.email
      ? "Bitte gib deine E-Mail ein."
      : !/\S+@\S+\.\S+/.test(formData.email)
      ? "Bitte nutze eine gültige E-Mail-Adresse."
      : "",
    topic: !formData.topic ? "Bitte wähle ein Thema." : "",
    message:
      !formData.message || formData.message.length < 10
        ? "Bitte formuliere dein Anliegen mit mindestens 10 Zeichen."
        : ""
  };

  const isValid = Object.values(errors).every((err) => err === "");

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleBlur = (event) => {
    const { name } = event.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setTouched({
      name: true,
      email: true,
      topic: true,
      message: true
    });
    if (isValid) {
      setSubmitted(true);
      setFormData(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Morilavero</title>
        <meta
          name="description"
          content="Nimm Kontakt zu Morilavero auf. Wir beantworten deine Fragen rund um digitale Balance und unsere Angebote."
        />
        <link rel="canonical" href="https://www.morilavero.de/contact" />
      </Helmet>
      <section className={styles.contact}>
        <div className={styles.info}>
          <h1>Schreib uns</h1>
          <p>
            Du hast Fragen, Feedback oder möchtest mit Morilavero arbeiten? Wir melden uns in der Regel innerhalb von zwei Werktagen.
          </p>
          <div className={styles.details}>
            <div>
              <span>E-Mail</span>
              <a href="mailto:hello@morilavero.de">hello@morilavero.de</a>
            </div>
            <div>
              <span>Adresse</span>
              <p>
                Morilavero GmbH<br />
                Lindenstraße 12<br />
                10115 Berlin
              </p>
            </div>
          </div>
          <p className={styles.disclaimer}>
            Hinweis: Wir können keine medizinischen oder psychotherapeutischen Fragen beantworten. Bitte wende dich bei akuten Anliegen an qualifizierte Fachpersonen.
          </p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">
            Name
            <input
              id="name"
              name="name"
              type="text"
              autoComplete="name"
              value={formData.name}
              onChange={handleChange}
              onBlur={handleBlur}
            />
            {touched.name && errors.name && <span className={styles.error}>{errors.name}</span>}
          </label>
          <label htmlFor="email">
            E-Mail
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={formData.email}
              onChange={handleChange}
              onBlur={handleBlur}
            />
            {touched.email && errors.email && <span className={styles.error}>{errors.email}</span>}
          </label>
          <label htmlFor="topic">
            Anliegen
            <select
              id="topic"
              name="topic"
              value={formData.topic}
              onChange={handleChange}
              onBlur={handleBlur}
            >
              <option value="">Bitte wählen</option>
              <option value="Programme">Programme & Challenges</option>
              <option value="Team">Team-Begleitung</option>
              <option value="Kooperation">Kooperation</option>
              <option value="Feedback">Feedback & Grüße</option>
            </select>
            {touched.topic && errors.topic && <span className={styles.error}>{errors.topic}</span>}
          </label>
          <label htmlFor="message">
            Nachricht
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              onBlur={handleBlur}
            />
            {touched.message && errors.message && (
              <span className={styles.error}>{errors.message}</span>
            )}
          </label>
          <button type="submit" className={styles.submit}>
            Nachricht senden
          </button>
          {submitted && (
            <p className={styles.success}>
              Danke für deine Nachricht! Wir melden uns so schnell wie möglich bei dir.
            </p>
          )}
        </form>
      </section>
    </>
  );
}

export default Contact;