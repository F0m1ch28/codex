import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Imprint.module.css";

function Imprint() {
  return (
    <>
      <Helmet>
        <title>Impressum | Morilavero</title>
        <meta
          name="description"
          content="Impressum von Morilavero. Rechtliche Angaben gemäß deutschem Telemediengesetz."
        />
        <link rel="canonical" href="https://www.morilavero.de/imprint" />
      </Helmet>
      <section className={styles.page}>
        <h1>Impressum</h1>
        <div className={styles.block}>
          <strong>Morilavero GmbH</strong>
          <p>
            Lindenstraße 12<br />
            10115 Berlin<br />
            Deutschland
          </p>
        </div>
        <div className={styles.block}>
          <strong>Vertreten durch:</strong>
          <p>Sofia Kramer (Geschäftsführung)</p>
        </div>
        <div className={styles.block}>
          <strong>Kontakt:</strong>
          <p>
            E-Mail: <a href="mailto:hello@morilavero.de">hello@morilavero.de</a>
          </p>
        </div>
        <div className={styles.block}>
          <strong>Registereintrag:</strong>
          <p>Fiktives Handelsregister, HRB 123456, Amtsgericht Berlin.</p>
        </div>
        <div className={styles.block}>
          <strong>USt-ID:</strong>
          <p>DE123456789 (fiktiv)</p>
        </div>
      </section>
    </>
  );
}

export default Imprint;