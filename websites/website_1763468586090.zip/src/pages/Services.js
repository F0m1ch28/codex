import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Services.module.css";

const services = [
  {
    title: "Reset Sessions",
    description: "Geführte Audio-Sessions für kurze, tiefe Regenerationsmomente zwischen Meetings.",
    details: "10 Minuten pro Session, Fokus auf Atmung & Klarheit, inkl. Reflektionsfragen."
  },
  {
    title: "Grenzen-Kommunikation",
    description: "Templates & Übungen, um Grenzen im Team klar zu formulieren, ohne hart zu wirken.",
    details: "Mit praktischen Beispielen aus Remote- und Office-Settings."
  },
  {
    title: "Routine-Lab",
    description: "Design dein individuelles Morgen- oder Abendritual, das wirklich Bestand hat.",
    details: "Schritt-für-Schritt, inkl. Habit-Tracker und Check-ins."
  },
  {
    title: "Focus Sprint",
    description:
      "Workflows für konzentrierte Arbeit: Fokusfenster, Pausen und Reflexion in Kombination.",
    details: "Planer, Timer-Inspirationen und Review-Vorlagen."
  },
  {
    title: "Team Pulse",
    description:
      "Moderierte Sessions, um im Team Bedürfnisse zu hören und gemeinsame Regeln zu vereinbaren.",
    details: "Tools für Meeting-Hygiene, Kommunikationswege und klare Signale."
  },
  {
    title: "Energie-Journal",
    description: "Ein digitales Journal für tägliche Energie-Checks und Micro-Erfolgsmomente.",
    details: "Gamified Elemente, Erinnerungen & Platz für persönliche Notizen."
  }
];

function Services() {
  return (
    <>
      <Helmet>
        <title>Morilavero Angebote | Programme für digitale Balance</title>
        <meta
          name="description"
          content="Entdecke die Morilavero-Angebote für mehr Energie, Realitätssinn und gesunde Grenzen im Alltag."
        />
        <link rel="canonical" href="https://www.morilavero.de/services" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Unsere Angebote für deinen Alltag</h1>
        <p>
          Wähle aus modularen Begleitungen, die sich flexibel in deinen Kalender einfügen. Alle Formate sind mobil und am Desktop nutzbar.
        </p>
      </section>
      <section className={styles.grid}>
        {services.map((service) => (
          <article className={styles.card} key={service.title}>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <span>{service.details}</span>
          </article>
        ))}
      </section>
      <section className={styles.note}>
        <p>
          Hinweis: Morilavero ersetzt keine medizinische oder psychotherapeutische Behandlung. Unsere Inhalte sind Begleiter für deinen Alltag – bei starken Belastungen hole dir bitte professionelle Unterstützung.
        </p>
      </section>
    </>
  );
}

export default Services;