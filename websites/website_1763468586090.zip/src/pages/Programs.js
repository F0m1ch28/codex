import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Programs.module.css";

const programs = [
  {
    title: "7-Tage Energie-Reset",
    duration: "7 Tage",
    focus: "Alltag entlasten",
    description: "Geführte Audio-Impulse, Journaling und Mikro-Übungen für mehr Klarheit."
  },
  {
    title: "Grenzen Woche",
    duration: "5 Tage",
    focus: "Kommunikation",
    description: "Daily Challenges, um Nein zu sagen, Erwartungen zu klären und dich zu schützen."
  },
  {
    title: "Calm Morning Challenge",
    duration: "10 Tage",
    focus: "Routinen",
    description: "10-minütige Startsequenzen für Fokus, Körpergefühl und Prioritäten."
  },
  {
    title: "Team Energie Sprint",
    duration: "2 Wochen",
    focus: "Teamkultur",
    description: "Moderierte Check-ins, Fokuszeiten und Reflexionen für euch als Team."
  }
];

function Programs() {
  return (
    <>
      <Helmet>
        <title>Programme & Challenges | Morilavero</title>
        <meta
          name="description"
          content="Flexibel kombinierbare Programme und Challenges von Morilavero für nachhaltige Energie und Grenzen."
        />
        <link rel="canonical" href="https://www.morilavero.de/programs" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Programme & Challenges</h1>
        <p>Modulare Begleitungen, die dich Schritt für Schritt unterstützen.</p>
      </section>
      <section className={styles.grid}>
        {programs.map((program) => (
          <article className={styles.card} key={program.title}>
            <header>
              <h2>{program.title}</h2>
              <span>{program.duration}</span>
            </header>
            <p>{program.description}</p>
            <footer>
              <span className={styles.focus}>{program.focus}</span>
            </footer>
          </article>
        ))}
      </section>
    </>
  );
}

export default Programs;