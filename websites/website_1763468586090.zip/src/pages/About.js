import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./About.module.css";

function About() {
  return (
    <>
      <Helmet>
        <title>Über Morilavero | Digitale Plattform für Wohlbefinden</title>
        <meta
          name="description"
          content="Lerne das Team von Morilavero kennen. Wir kombinieren Empathie, Habit Design und digitale Tools, um dich nachhaltig zu unterstützen."
        />
        <link rel="canonical" href="https://www.morilavero.de/about" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroBody}>
          <h1>Wir glauben an Balance, die wirklich in den Alltag passt.</h1>
          <p>
            Morilavero ist in Berlin entstanden – aus der Sehnsucht nach einem digitalen Ort, der Menschen dabei hilft, ihre Energie ernst zu nehmen, ohne unrealistische Erwartungen. Wir nutzen Erkenntnisse aus Arbeitspsychologie, Habit Design und Community-Coaching, um Tools zu entwickeln, die ehrlich, liebevoll und umsetzbar sind.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/800/600?random=21"
            alt="Team von Morilavero bei einer gemeinsamen Strategie-Session"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.values}>
        <h2>Werte, die uns leiten</h2>
        <div className={styles.valueGrid}>
          <article>
            <h3>Empathie</h3>
            <p>Wir hören zu. Jede Person bringt ihre Geschichte mit – wir arbeiten nicht mit generischen Schablonen.</p>
          </article>
          <article>
            <h3>Realismus</h3>
            <p>Tools müssen in echte Kalender passen. Wir testen jede Idee unter Alltagsbedingungen.</p>
          </article>
          <article>
            <h3>Transparenz</h3>
            <p>Wir teilen offen, wie Morilavero funktioniert, wo unsere Grenzen liegen und was wir gerade lernen.</p>
          </article>
          <article>
            <h3>Co-Kreation</h3>
            <p>Viele unserer Programme entstehen gemeinsam mit der Community. Deine Stimme zählt.</p>
          </article>
        </div>
      </section>

      <section className={styles.story}>
        <div>
          <h2>Unsere Geschichte</h2>
          <p>
            Wir haben Morilavero gegründet, nachdem uns auffiel, dass viele Kolleg:innen – auch in modernen Unternehmen – kurz vor dem Ausbrennen standen.
            Was fehlte: ein Ort, an dem man ohne Scham ehrlich sein darf, Alltagsrituale lernt und sich Schritt für Schritt wieder spürt. Heute begleiten wir Einzelpersonen, Teams und Führungskräfte auf diesem Weg.
          </p>
        </div>
        <div className={styles.storyCard}>
          <span>Hinweis</span>
          <p>
            Morilavero bietet keine medizinische oder psychotherapeutische Behandlung. Wenn du dich in einer akuten Krise befindest, wende dich bitte an professionelle Stellen oder den Notruf.
          </p>
        </div>
      </section>
    </>
  );
}

export default About;