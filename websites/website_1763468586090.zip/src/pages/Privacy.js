import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Privacy.module.css";

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Datenschutz | Morilavero</title>
        <meta
          name="description"
          content="Datenschutzhinweise zu Morilavero. Erfahre, wie wir mit deinen Daten umgehen."
        />
        <link rel="canonical" href="https://www.morilavero.de/privacy" />
      </Helmet>
      <section className={styles.page}>
        <h1>Datenschutz</h1>
        <p>
          Der Schutz deiner Daten hat bei Morilavero hohe Priorität. Wir verarbeiten personenbezogene Daten ausschließlich, wenn es notwendig ist, um die Plattform bereitzustellen oder mit dir zu kommunizieren.
        </p>
        <p>
          Wenn du unser Kontaktformular nutzt, speichern wir die von dir angegebenen Daten, um deine Anfrage zu beantworten. Nach Abschluss des Austauschs löschen wir sie, sofern keine gesetzlichen Aufbewahrungspflichten bestehen.
        </p>
        <p>
          Wir setzen Cookies ein, um die Nutzererfahrung zu verbessern. Du kannst dem zustimmen oder widersprechen. Analyse-Tools nutzen wir nur in anonymisierter Form.
        </p>
        <p>
          Für Auskunft, Berichtigung oder Löschung deiner Daten wende dich an: <a href="mailto:privacy@morilavero.de">privacy@morilavero.de</a>.
        </p>
      </section>
    </>
  );
}

export default Privacy;