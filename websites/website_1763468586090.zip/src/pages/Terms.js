import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Terms.module.css";

function Terms() {
  return (
    <>
      <Helmet>
        <title>Nutzungsbedingungen | Morilavero</title>
        <meta
          name="description"
          content="Nutzungsbedingungen für die Verwendung der Morilavero Plattform."
        />
        <link rel="canonical" href="https://www.morilavero.de/terms" />
      </Helmet>
      <section className={styles.page}>
        <h1>Nutzungsbedingungen</h1>
        <p>
          Mit der Nutzung der Morilavero Plattform akzeptierst du diese Bedingungen. Sie dienen dazu, einen wertschätzenden und sicheren Raum zu gewährleisten.
        </p>
        <ul>
          <li>Die Inhalte sind ausschließlich für den persönlichen Gebrauch bestimmt.</li>
          <li>Du verpflichtest dich, respektvoll mit der Community umzugehen.</li>
          <li>Wir behalten uns vor, Inhalte anzupassen oder zu entfernen, wenn sie nicht mehr aktuell sind.</li>
          <li>Bei Verstößen gegen die Bedingungen können Zugänge vorübergehend gesperrt werden.</li>
        </ul>
        <p>
          Morilavero bietet keine medizinische oder psychotherapeutische Beratung. Bitte suche bei ernsthaften Anliegen professionelle Unterstützung.
        </p>
      </section>
    </>
  );
}

export default Terms;