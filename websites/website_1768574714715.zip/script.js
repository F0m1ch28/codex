document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    const navLinks = document.querySelectorAll('.primary-nav .nav-links a');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navToggle.classList.toggle('open');
            primaryNav.classList.toggle('open');
        });

        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 900) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navToggle.classList.remove('open');
                    primaryNav.classList.remove('open');
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 900) {
                navToggle.setAttribute('aria-expanded', 'false');
                navToggle.classList.remove('open');
                primaryNav.classList.remove('open');
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('garglejral-cookie-consent');
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }

        const consentButtons = cookieBanner.querySelectorAll('[data-consent]');
        consentButtons.forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const choice = button.dataset.consent;
                localStorage.setItem('garglejral-cookie-consent', choice);
                cookieBanner.classList.add('hidden');
                window.location.href = button.getAttribute('href');
            });
        });
    }
});