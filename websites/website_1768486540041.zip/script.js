document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".nav-list a");
    const cookieBanner = document.getElementById("cookieBanner");
    const cookieClose = document.querySelector(".cookie-close");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isExpanded));
            navToggle.classList.toggle("is-active");
            siteNav.classList.toggle("nav-visible");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("nav-visible")) {
                    siteNav.classList.remove("nav-visible");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    if (cookieBanner && cookieClose) {
        cookieClose.addEventListener("click", () => {
            cookieBanner.style.display = "none";
        });
    }
});