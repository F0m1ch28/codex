document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
      navToggle.setAttribute(
        'aria-expanded',
        navLinks.classList.contains('open').toString()
      );
    });

    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const currentPage = document.body.dataset.page;
  document.querySelectorAll('nav a[data-page]').forEach((anchor) => {
    if (anchor.dataset.page === currentPage) {
      anchor.classList.add('active');
    }
  });

  const cookieBanner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');

  const cookieStatus = localStorage.getItem('clarityNorthCookies');
  if (cookieStatus === 'accepted' || cookieStatus === 'declined') {
    cookieBanner?.classList.add('hidden');
  }

  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('clarityNorthCookies', 'accepted');
    cookieBanner.classList.add('hidden');
  });

  declineBtn?.addEventListener('click', () => {
    localStorage.setItem('clarityNorthCookies', 'declined');
    cookieBanner.classList.add('hidden');
  });
});