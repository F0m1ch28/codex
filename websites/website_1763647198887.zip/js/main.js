document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.primary-nav');
  const navLinks = document.querySelectorAll('.primary-nav .nav-link');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen);
      document.body.classList.toggle('nav-open', isOpen);
    });
  }

  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      if (nav && nav.classList.contains('is-open')) {
        nav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('nav-open');
      }
    });
  });

  const currentPage = document.body.dataset.page;
  if (currentPage) {
    navLinks.forEach((link) => {
      if (link.dataset.page === currentPage) {
        link.classList.add('is-active');
      }
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (event) => {
      const targetID = anchor.getAttribute('href');
      if (targetID.length > 1) {
        const target = document.querySelector(targetID);
        if (target) {
          event.preventDefault();
          target.scrollIntoView({ behavior: 'smooth' });
          target.setAttribute('tabindex', '-1');
          target.focus({ preventScroll: true });
          target.addEventListener(
            'blur',
            () => {
              target.removeAttribute('tabindex');
            },
            { once: true }
          );
        }
      }
    });
  });

  const cookieBanner = document.getElementById('cookie-banner');
  const storedConsent = localStorage.getItem('cookieConsent');

  if (cookieBanner) {
    const toggleBanner = (state) => {
      if (state === 'show') {
        cookieBanner.classList.add('is-visible');
      } else {
        cookieBanner.classList.remove('is-visible');
        cookieBanner.classList.add('is-hidden');
      }
    };

    if (!storedConsent) {
      requestAnimationFrame(() => toggleBanner('show'));
    } else {
      toggleBanner('hide');
    }

    cookieBanner.querySelectorAll('button[data-consent]').forEach((button) => {
      button.addEventListener('click', () => {
        const choice = button.dataset.consent;
        localStorage.setItem('cookieConsent', choice);
        toggleBanner('hide');
      });
    });
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const formMessage = contactForm.querySelector('#form-message');
      const name = contactForm.elements['name'].value.trim();
      const email = contactForm.elements['email'].value.trim();
      const message = contactForm.elements['message'].value.trim();
      const errors = [];

      if (!name) {
        errors.push('Please provide your name.');
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailPattern.test(email)) {
        errors.push('Please enter a valid email address.');
      }

      if (!message) {
        errors.push('Please share a brief project overview.');
      }

      if (errors.length > 0) {
        formMessage.textContent = errors.join(' ');
        formMessage.classList.remove('success');
        formMessage.classList.add('error');
      } else {
        formMessage.textContent = 'Thank you! A member of our team will reach out within one business day.';
        formMessage.classList.remove('error');
        formMessage.classList.add('success');
        contactForm.reset();
      }
    });
  }
});