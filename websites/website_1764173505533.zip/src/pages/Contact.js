import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("");

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please provide your name.";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!formData.message.trim()) newErrors.message = "Let us know how we can help.";
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      setStatus("");
      return;
    }

    setStatus("loading");
    setTimeout(() => {
      setStatus("success");
      setFormData({ name: "", email: "", company: "", message: "" });
    }, 1200);
  };

  return (
    <div className="page">
      <section className="page-hero contact-hero">
        <div className="container">
          <span className="hero-badge">Let’s connect</span>
          <h1>Tell us about the future you’re building.</h1>
          <p>We’ll pair you with the right experts to explore partnership opportunities within one business day.</p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-field">
              <label htmlFor="name">Full name*</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Jane Doe"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={errors.name ? "true" : "false"}
              />
              {errors.name && <span className="error-message">{errors.name}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="email">Work email*</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="you@company.com"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={errors.email ? "true" : "false"}
              />
              {errors.email && <span className="error-message">{errors.email}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                placeholder="Organization"
                value={formData.company}
                onChange={handleChange}
              />
            </div>
            <div className="form-field">
              <label htmlFor="message">How can we help?*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Share your goals, challenges, and timeline."
                value={formData.message}
                onChange={handleChange}
                aria-invalid={errors.message ? "true" : "false"}
              />
              {errors.message && <span className="error-message">{errors.message}</span>}
            </div>
            <button type="submit" className="btn-primary btn-large" disabled={status === "loading"}>
              {status === "loading" ? "Sending..." : "Submit inquiry"}
            </button>
            {status === "success" && <p className="success-message">Thank you! We’ll be in touch shortly.</p>}
          </form>
          <div className="contact-info">
            <div className="contact-card">
              <h3>Project partnerships</h3>
              <p>hello@precisionworks.com</p>
              <p>+1 (415) 555-0198</p>
            </div>
            <div className="contact-card">
              <h3>Visit our studio</h3>
              <p>102 Market Street<br />San Francisco, CA 94105</p>
            </div>
            <div className="contact-card">
              <h3>Join the team</h3>
              <p>talent@precisionworks.com</p>
              <a href="#careers" className="contact-link">
                Explore careers →
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;