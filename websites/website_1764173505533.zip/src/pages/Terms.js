import React from "react";

const Terms = () => (
  <div className="legal-page">
    <div className="container legal-container">
      <h1>Terms of Service</h1>
      <p>Last updated: March 1, 2024</p>
      <h2>1. Acceptance of terms</h2>
      <p>
        By accessing or using the PrecisionWorks website, products, or services, you agree to be bound by these Terms of Service and all applicable laws.
      </p>
      <h2>2. Use of services</h2>
      <p>
        You agree to use our services only for lawful purposes. You are responsible for adherence to all applicable regulations and compliance obligations.
      </p>
      <h2>3. Intellectual property</h2>
      <p>
        All content, trademarks, and materials on this site are the property of PrecisionWorks or its licensors. Unauthorized use is prohibited.
      </p>
      <h2>4. Confidentiality</h2>
      <p>
        Any confidential information exchanged during engagements must remain confidential unless both parties agree otherwise in writing.
      </p>
      <h2>5. Limitation of liability</h2>
      <p>
        PrecisionWorks is not liable for indirect, incidental, or consequential damages arising from the use of our services.
      </p>
      <h2>6. Governing law</h2>
      <p>These Terms are governed by the laws of the State of California without regard to conflict of law principles.</p>
      <h2>7. Updates</h2>
      <p>We may update these Terms periodically. Continued use of our services constitutes acceptance of the revised Terms.</p>
      <p>If you have any questions about these Terms, please contact us at legal@precisionworks.com.</p>
    </div>
  </div>
);

export default Terms;