import React from "react";

const Privacy = () => (
  <div className="legal-page">
    <div className="container legal-container">
      <h1>Privacy Policy</h1>
      <p>Effective date: March 1, 2024</p>
      <h2>Introduction</h2>
      <p>
        PrecisionWorks respects your privacy and is committed to protecting the personal information you share with us. This policy explains how we collect, use, and safeguard your data.
      </p>
      <h2>Information we collect</h2>
      <ul>
        <li>Contact details such as name, email, company, and phone number.</li>
        <li>Professional information related to inquiries or engagements.</li>
        <li>Analytics data gathered through cookies or similar technologies.</li>
      </ul>
      <h2>How we use information</h2>
      <p>
        We use your information to respond to inquiries, provide services, personalize communications, and improve our website.
      </p>
      <h2>Cookies</h2>
      <p>
        We use cookies to understand website performance and enhance user experience. You may control cookies via your browser settings.
      </p>
      <h2>Data sharing</h2>
      <p>
        We do not sell your personal information. We may share data with trusted partners who assist in delivering our services under confidentiality agreements.
      </p>
      <h2>Your rights</h2>
      <p>
        Depending on your jurisdiction, you may have rights to access, correct, or delete personal data we hold about you. Contact privacy@precisionworks.com to submit requests.
      </p>
      <h2>Security</h2>
      <p>
        We implement administrative, technical, and physical safeguards to protect your information.
      </p>
      <h2>Updates</h2>
      <p>
        We may update this policy over time. Material changes will be posted here with an updated effective date.
      </p>
      <p>If you have any privacy concerns, please reach out to privacy@precisionworks.com.</p>
    </div>
  </div>
);

export default Privacy;