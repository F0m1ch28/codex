import React, { useState } from "react";

const offerings = [
  {
    title: "Digital Strategy & Transformation",
    description:
      "Define north-star visions, operating models, and measurable roadmaps that empower resilient growth.",
    benefits: ["Vision & operating model alignment", "Value stream mapping", "Capability accelerators", "Change management"],
  },
  {
    title: "Experience Design & Research",
    description:
      "Human-centered design rooted in behavioral insights to craft services and products customers love.",
    benefits: ["Journey mapping", "Service blueprints", "Design systems", "Usability testing"],
  },
  {
    title: "Product Engineering & Delivery",
    description:
      "Modern architectures and cross-functional squads delivering scalable products with velocity.",
    benefits: ["Cloud-native engineering", "API design", "Quality automation", "DevOps enablement"],
  },
  {
    title: "Intelligent Automation & AI",
    description:
      "Operational excellence through data pipelines, predictive modeling, and adaptive automation.",
    benefits: ["Data modernization", "AI strategy", "Automation at scale", "Responsible AI governance"],
  },
];

const caseStudies = [
  {
    title: "Accelerating digital lending with real-time decisions",
    outcome: "Reduced loan processing time from 5 days to 2 hours.",
  },
  {
    title: "Designing a unified patient portal experience",
    outcome: "Improved patient satisfaction scores by 34%.",
  },
  {
    title: "Operationalizing predictive maintenance for manufacturers",
    outcome: "Cut unplanned downtime by 48% across three plants.",
  },
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="page">
      <section className="page-hero services-hero">
        <div className="container">
          <span className="hero-badge">What we do</span>
          <h1>Full-spectrum capabilities to orchestrate breakthrough outcomes.</h1>
          <p>
            Our multidisciplinary teams connect strategic foresight, human-centered design, and engineering rigor to deliver solutions that scale with your ambitions.
          </p>
        </div>
      </section>

      <section className="services-tabs">
        <div className="container">
          <div className="tabs-nav" role="tablist">
            {offerings.map((offering, index) => (
              <button
                key={offering.title}
                className={`tab-button ${activeIndex === index ? "active" : ""}`}
                onClick={() => setActiveIndex(index)}
                role="tab"
                aria-selected={activeIndex === index}
              >
                {offering.title}
              </button>
            ))}
          </div>
          <div className="tab-panel" role="tabpanel">
            <h2>{offerings[activeIndex].title}</h2>
            <p>{offerings[activeIndex].description}</p>
            <ul className="benefits-list">
              {offerings[activeIndex].benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="services-outcomes">
        <div className="container">
          <h2>Recent outcomes</h2>
          <div className="outcomes-grid">
            {caseStudies.map((caseStudy) => (
              <article key={caseStudy.title}>
                <h3>{caseStudy.title}</h3>
                <p>{caseStudy.outcome}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-content">
          <h2>Let’s architect a roadmap to your next milestone.</h2>
          <p>From discovery workshops to delivery squads, we’ll customize an engagement model that meets your objectives.</p>
          <div className="cta-actions">
            <a href="mailto:hello@precisionworks.com" className="btn-primary btn-large">
              hello@precisionworks.com
            </a>
            <a href="/contact" className="btn-ghost">
              Contact us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;