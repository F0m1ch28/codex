import React from "react";

const leadership = [
  {
    name: "Avery Chen",
    role: "Managing Partner",
    image: "https://picsum.photos/400/400?random=51",
    description:
      "Former chief strategy officer with 18 years in enterprise transformation, guiding Fortune 500 innovations.",
  },
  {
    name: "Rohan Patel",
    role: "Director of Experience Design",
    image: "https://picsum.photos/400/400?random=52",
    description:
      "Champion of design systems and inclusive product thinking, leading award-winning customer experiences.",
  },
  {
    name: "Lucia Fernandez",
    role: "Chief Data Scientist",
    image: "https://picsum.photos/400/400?random=53",
    description:
      "Data storyteller and AI ethicist advising on scalable analytics and predictive intelligence.",
  },
];

const principles = [
  {
    title: "Co-create with clarity",
    description: "We cultivate shared understanding and align stakeholders from the start.",
  },
  {
    title: "Design for trust",
    description: "Inclusive experiences and transparent data practices power lasting relationships.",
  },
  {
    title: "Deliver measurable impact",
    description: "Every engagement is evaluated with crystal-clear metrics and outcomes.",
  },
  {
    title: "Empower teams",
    description: "We upskill, embed, and ensure your teams sustain momentum beyond launch.",
  },
];

const About = () => (
  <div className="page">
    <section className="page-hero about-hero">
      <div className="container">
        <span className="hero-badge">Who we are</span>
        <h1>We orchestrate strategy, design, and technology for bold, measurable change.</h1>
        <p>
          PrecisionWorks is a collective of strategists, designers, engineers, and data scientists committed to bridging vision and execution. Our teams operate across North America, Europe, and APAC to deliver unified experiences and operational excellence.
        </p>
      </div>
    </section>

    <section className="about-story">
      <div className="container about-grid">
        <div className="about-story-text">
          <h2>Purpose-built to scale transformation</h2>
          <p>
            Over the past decade, we have partnered with startups to global enterprises to transform how people experience products, services, and workplaces. Our modular engagement model adapts to your operating rhythm, delivering cross-functional squads that maintain momentum.
          </p>
          <p>
            We believe the most resilient organizations marry human insight with intelligent technology. That’s why we invest deeply in discovery, experimentation, and outcomes-driven metrics.
          </p>
        </div>
        <div className="about-story-metrics">
          <div>
            <strong>2014</strong>
            <span>Founded with a mission to build better experiences</span>
          </div>
          <div>
            <strong>250+</strong>
            <span>Consultants, makers, and strategists across 7 timezones</span>
          </div>
          <div>
            <strong>92%</strong>
            <span>Client retention driven by consistent value delivery</span>
          </div>
        </div>
      </div>
    </section>

    <section className="principles-section">
      <div className="container">
        <h2>Guiding principles</h2>
        <div className="principles-grid">
          {principles.map((principle) => (
            <article key={principle.title} className="principle-card">
              <h3>{principle.title}</h3>
              <p>{principle.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="leadership-section">
      <div className="container">
        <h2>Leadership team</h2>
        <div className="team-grid">
          {leadership.map((leader) => (
            <article className="team-card" key={leader.name}>
              <div className="team-photo">
                <img src={leader.image} alt={`${leader.name}, ${leader.role}`} loading="lazy" />
              </div>
              <div className="team-info">
                <h3>{leader.name}</h3>
                <span>{leader.role}</span>
                <p>{leader.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="cta-section secondary-cta">
      <div className="container cta-content">
        <h2>Join our mission to shape the future of digital experiences.</h2>
        <p>We’re always looking for strategic thinkers, curious builders, and empathetic designers.</p>
        <div className="cta-actions">
          <a href="#careers" className="btn-primary btn-large">
            View careers
          </a>
          <a href="mailto:talent@precisionworks.com" className="btn-ghost">
            talent@precisionworks.com
          </a>
        </div>
      </div>
    </section>
  </div>
);

export default About;