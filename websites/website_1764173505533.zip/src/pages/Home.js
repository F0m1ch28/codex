import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

const statsData = [
  { label: "Enterprise Transformations", value: 128 },
  { label: "Customer Journeys Crafted", value: 540 },
  { label: "Automation Workflows", value: 212 },
  { label: "Client Satisfaction", value: 98, suffix: "%" },
];

const servicesData = [
  {
    title: "Digital Strategy",
    description: "Future-ready roadmaps that align technology investments with measurable business outcomes.",
    icon: "📈",
  },
  {
    title: "Experience Design",
    description: "Human-centered design sprints that translate insights into intuitive digital products.",
    icon: "🎨",
  },
  {
    title: "Data Intelligence",
    description: "Modern data platforms, analytics, and AI solutions crafted for decision confidence.",
    icon: "🧠",
  },
  {
    title: "Automation & Ops",
    description: "Streamlined workflows and intelligent automation to unlock operational excellence.",
    icon: "⚙️",
  },
];

const processSteps = [
  {
    title: "Discover & Align",
    description: "Immersive workshops uncover core challenges, ambitions, and success metrics.",
  },
  {
    title: "Design & Validate",
    description: "Rapid prototyping, user testing, and architectural planning bring clarity.",
  },
  {
    title: "Build & Launch",
    description: "Agile squads deliver resilient solutions, integrating seamlessly with your teams.",
  },
  {
    title: "Scale & Optimize",
    description: "Continuous improvement loops, data insights, and strategic guidance for ongoing impact.",
  },
];

const testimonials = [
  {
    quote:
      "PrecisionWorks elevated our customer experience and doubled our digital conversion rate in just six months.",
    name: "Elena McCarthy",
    role: "Chief Digital Officer, Asterix Labs",
  },
  {
    quote: "Their team bridged strategy and execution flawlessly. We unlocked new revenue streams with confidence.",
    name: "Marcus Reed",
    role: "VP Innovation, Skyline Ventures",
  },
  {
    quote:
      "From discovery to scale, PrecisionWorks became a true partner. They over-delivered on every milestone.",
    name: "Priya Natarajan",
    role: "Head of Transformation, Lumina Health",
  },
];

const teamMembers = [
  {
    name: "Avery Chen",
    role: "Managing Partner",
    bio: "Leads client vision, strategy alignment, and enterprise modernization programs.",
    image: "https://picsum.photos/400/400?random=31",
  },
  {
    name: "Rohan Patel",
    role: "Director of Experience Design",
    bio: "Drives human-centered research and product innovation across sectors.",
    image: "https://picsum.photos/400/400?random=32",
  },
  {
    name: "Lucia Fernandez",
    role: "Chief Data Scientist",
    bio: "Architects intelligent data ecosystems that fuel transformative decisioning.",
    image: "https://picsum.photos/400/400?random=33",
  },
];

const projects = [
  {
    title: "Omnichannel Commerce Revamp",
    category: "Experience",
    image: "https://picsum.photos/1200/800?random=41",
  },
  {
    title: "AI-Powered Claims Automation",
    category: "Automation",
    image: "https://picsum.photos/1200/800?random=42",
  },
  {
    title: "Data Lakehouse Modernization",
    category: "Data",
    image: "https://picsum.photos/1200/800?random=43",
  },
  {
    title: "Customer Journey Analytics",
    category: "Data",
    image: "https://picsum.photos/1200/800?random=44",
  },
  {
    title: "Digital Workplace Transformation",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=45",
  },
  {
    title: "Connected Health Platform",
    category: "Experience",
    image: "https://picsum.photos/1200/800?random=46",
  },
];

const faqItems = [
  {
    question: "How do you approach new engagements?",
    answer:
      "We begin with collaborative discovery to understand your business context, customers, and operational realities. From there, we co-create a roadmap grounded in measurable outcomes and validate through rapid experimentation.",
  },
  {
    question: "What industries do you specialize in?",
    answer:
      "Our cross-disciplinary teams have delivered projects in financial services, healthcare, retail, manufacturing, and SaaS. We focus on solving complex challenges where technology, operations, and customer experience intersect.",
  },
  {
    question: "Do you integrate with internal teams?",
    answer:
      "Yes. We pride ourselves on embedding with internal stakeholders, upskilling teams, and ensuring knowledge transfer so your organization sustains momentum beyond launch.",
  },
  {
    question: "What is your typical project timeline?",
    answer:
      "Depending on the engagement, our sprints range from 6 weeks for targeted initiatives to 6-12 month transformation programs with incremental value released along the way.",
  },
];

const blogPosts = [
  {
    title: "Designing AI Experiences Your Customers Trust",
    excerpt: "Explore ethical frameworks and design principles that ensure AI-driven experiences remain transparent and human-centered.",
    date: "April 3, 2024",
    link: "#",
  },
  {
    title: "Blueprint for Modernizing Legacy Systems",
    excerpt: "A proven approach to transitioning complex enterprise platforms into flexible, cloud-native ecosystems.",
    date: "March 19, 2024",
    link: "#",
  },
  {
    title: "The Power of Product-Led Transformation",
    excerpt: "How product thinking aligns leadership, operations, and technology to unlock continuous innovation.",
    date: "February 28, 2024",
    link: "#",
  },
];

const Home = () => {
  const [activeProjectFilter, setActiveProjectFilter] = useState("All");
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [counterValues, setCounterValues] = useState(statsData.map(() => 0));
  const countersActivated = useRef(false);
  const statsRef = useRef(null);

  const filteredProjects = useMemo(() => {
    if (activeProjectFilter === "All") return projects;
    return projects.filter((project) => project.category === activeProjectFilter);
  }, [activeProjectFilter]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const animateCounters = () => {
      countersActivated.current = true;
      const duration = 1400;
      const start = performance.now();

      const tick = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        setCounterValues(
          statsData.map((stat) => Math.floor(progress * stat.value))
        );
        if (progress < 1) {
          requestAnimationFrame(tick);
        }
      };

      requestAnimationFrame(tick);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !countersActivated.current) {
            animateCounters();
          }
        });
      },
      { threshold: 0.45 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const animatedElements = document.querySelectorAll("[data-animate]");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );

    animatedElements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <section className="hero-section" data-animate>
        <div className="hero-media">
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Strategic leaders collaborating on digital innovation"
            loading="lazy"
          />
        </div>
        <div className="container hero-content">
          <span className="hero-badge">Trusted innovation partner</span>
          <h1>Designing confident futures through strategy, data, and experience.</h1>
          <p>
            PrecisionWorks helps ambitious teams align vision with execution. Together we architect digital products, modernize operations, and accelerate customer value.
          </p>
          <div className="hero-actions">
            <Link to="/contact" className="btn-primary btn-large">
              Start a project
            </Link>
            <Link to="/services" className="btn-ghost">
              Explore solutions
            </Link>
          </div>
          <div className="hero-meta">
            <div>
              <strong>Global footprint</strong>
              <span>11 delivery hubs, 26 countries served</span>
            </div>
            <div>
              <strong>Industry recognition</strong>
              <span>Top innovation partner 2023</span>
            </div>
          </div>
        </div>
      </section>

      <section className="stats-section" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label} data-animate>
              <span className="stat-number">
                {counterValues[index]}
                {stat.suffix || ""}
                <span className="stat-plus">+</span>
              </span>
              <span className="stat-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="services-section" id="services">
        <div className="container section-heading">
          <h2 data-animate>Solutions engineered for measurable impact</h2>
          <p data-animate>
            Strategic consultants, designers, and engineers working as one cross-functional team to deliver business outcomes with speed and focus.
          </p>
        </div>
        <div className="container services-grid">
          {servicesData.map((service) => (
            <article className="service-card" key={service.title} data-animate>
              <span className="service-icon" aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-link">
                Learn more →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="process-section">
        <div className="container">
          <div className="section-heading" data-animate>
            <h2>Our end-to-end partnership model</h2>
            <p>Transparent collaboration from vision to value unlocks momentum and delivers sustainable transformation.</p>
          </div>
          <div className="process-timeline">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title} data-animate>
                <span className="process-number">{index + 1}</span>
                <div className="process-body">
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonial-section">
        <div className="container testimonial-wrapper">
          <div className="testimonial-header" data-animate>
            <h2>What our clients say</h2>
            <p>We co-create with visionary leaders to accelerate enduring change.</p>
          </div>
          <div className="testimonial-slider" data-animate>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`testimonial-card ${index === currentTestimonial ? "active" : ""}`}
              >
                <blockquote>
                  <p>“{testimonial.quote}”</p>
                </blockquote>
                <footer>
                  <span className="testimonial-name">{testimonial.name}</span>
                  <span className="testimonial-role">{testimonial.role}</span>
                </footer>
              </article>
            ))}
            <div className="testimonial-controls">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`dot ${index === currentTestimonial ? "active" : ""}`}
                  onClick={() => setCurrentTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team-section">
        <div className="container">
          <div className="section-heading" data-animate>
            <h2>Leadership fueling relentless progress</h2>
            <p>Hands-on leaders who champion clarity, excellence, and outcomes from start to finish.</p>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <article className="team-card" key={member.name} data-animate>
                <div className="team-photo">
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                  <div className="team-overlay">
                    <p>{member.bio}</p>
                  </div>
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects-section">
        <div className="container">
          <div className="section-heading" data-animate>
            <h2>Selected engagements</h2>
            <p>Cross-industry wins proving the power of integrated strategy, design, and engineering.</p>
          </div>
          <div className="project-filters" role="tablist">
            {["All", "Strategy", "Experience", "Data", "Automation"].map((category) => (
              <button
                key={category}
                className={`filter-btn ${activeProjectFilter === category ? "active" : ""}`}
                onClick={() => setActiveProjectFilter(category)}
                role="tab"
                aria-selected={activeProjectFilter === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title} data-animate>
                <div className="project-image">
                  <img src={project.image} alt={`${project.title} case study visual`} loading="lazy" />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <Link to="/services" className="project-link">
                    View case study →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section">
        <div className="container faq-grid">
          <div className="faq-intro" data-animate>
            <h2>Frequently asked questions</h2>
            <p>Still exploring if we’re the right partner? Here are a few things our clients often ask before getting started.</p>
          </div>
          <div className="faq-items">
            {faqItems.map((item, index) => (
              <FAQItem key={item.question} item={item} index={index} />
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section">
        <div className="container">
          <div className="section-heading" data-animate>
            <h2>Insights to move you forward</h2>
            <p>Ideas, frameworks, and stories from the teams building the next generation of experiences.</p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title} data-animate>
                <img src="https://picsum.photos/800/600?random=2" alt="Business professionals collaborating in a modern workspace" loading="lazy" />
                <div className="blog-content">
                  <span className="blog-date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href={post.link} className="blog-link">
                    Read article →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section" data-animate>
        <div className="container cta-content">
          <h2>Ready to architect what’s next?</h2>
          <p>Let’s co-create experiences, products, and operations that scale with ambition. Our specialists will respond within one business day.</p>
          <div className="cta-actions">
            <Link to="/contact" className="btn-primary btn-large">
              Book discovery session
            </Link>
            <Link to="/about" className="btn-ghost">
              Meet the team
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

const FAQItem = ({ item, index }) => {
  const [open, setOpen] = useState(index === 0);

  return (
    <article className={`faq-item ${open ? "open" : ""}`} data-animate>
      <button className="faq-question" onClick={() => setOpen((prev) => !prev)} aria-expanded={open}>
        <span>{item.question}</span>
        <span className="faq-icon">{open ? "−" : "+"}</span>
      </button>
      <div className="faq-answer" style={{ maxHeight: open ? "240px" : "0px" }}>
        <p>{item.answer}</p>
      </div>
    </article>
  );
};

export default Home;