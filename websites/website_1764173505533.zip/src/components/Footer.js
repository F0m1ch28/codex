import React from "react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-grid">
      <div className="footer-about">
        <div className="footer-logo">
          <span className="logo-mark">PW</span>
          <span className="logo-title">PrecisionWorks</span>
        </div>
        <p>
          We partner with ambitious brands to design digital products, transform operations, and accelerate growth through creative technology.
        </p>
        <div className="social-links">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            <span>LinkedIn</span>
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
            <span>Twitter</span>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
            <span>YouTube</span>
          </a>
        </div>
      </div>
      <div className="footer-links">
        <h4>Company</h4>
        <Link to="/about">About</Link>
        <Link to="/services">Services</Link>
        <Link to="/contact">Contact</Link>
        <Link to="/privacy">Privacy Policy</Link>
        <Link to="/terms">Terms of Service</Link>
      </div>
      <div className="footer-links">
        <h4>Solutions</h4>
        <a href="#services" className="footer-anchor">Digital Transformation</a>
        <a href="#services" className="footer-anchor">Experience Design</a>
        <a href="#services" className="footer-anchor">Data Intelligence</a>
        <a href="#services" className="footer-anchor">Automation</a>
      </div>
      <div className="footer-newsletter">
        <h4>Stay in the loop</h4>
        <p>Monthly insights on digital innovation, directly in your inbox.</p>
        <form className="newsletter-form">
          <label htmlFor="newsletter-email" className="sr-only">
            Email
          </label>
          <input id="newsletter-email" type="email" placeholder="you@example.com" required />
          <button type="submit">Subscribe</button>
        </form>
        <span className="small-print">We respect your privacy. Unsubscribe anytime.</span>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} PrecisionWorks. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;