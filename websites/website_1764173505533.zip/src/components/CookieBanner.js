import React, { useState, useEffect } from "react";

const COOKIE_KEY = "precisionworks-cookie-consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(COOKIE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <h4>We value your privacy</h4>
        <p>
          We use cookies to enhance your browsing experience, serve personalized content, and analyze our traffic. By clicking “Accept”, you consent to our use of cookies.
        </p>
      </div>
      <div className="cookie-actions">
        <button type="button" className="btn-secondary" onClick={handleDecline}>
          Decline
        </button>
        <button type="button" className="btn-primary" onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;