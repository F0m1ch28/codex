document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-link');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieDecline = document.getElementById('cookieDecline');
    const COOKIE_KEY = 'anonfmjx-cookie-choice';

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            nav.classList.toggle('active');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (nav.classList.contains('active')) {
                    nav.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });

        document.addEventListener('click', event => {
            if (!nav.contains(event.target) && !navToggle.contains(event.target)) {
                nav.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (cookieBanner && cookieAccept && cookieDecline) {
        const storedChoice = localStorage.getItem(COOKIE_KEY);
        if (!storedChoice) {
            setTimeout(() => {
                cookieBanner.classList.add('active');
            }, 600);
        }

        const handleChoice = choice => {
            localStorage.setItem(COOKIE_KEY, choice);
            cookieBanner.classList.remove('active');
        };

        cookieAccept.addEventListener('click', () => handleChoice('accepted'));
        cookieDecline.addEventListener('click', () => handleChoice('declined'));
    }
});