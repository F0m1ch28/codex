document.addEventListener('DOMContentLoaded', function () {
    const header = document.querySelector('.site-header');
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });
    }

    navLinks.forEach((link) => {
        link.addEventListener('click', () => {
            if (navToggle && navMenu && navMenu.classList.contains('open')) {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });

    window.addEventListener('scroll', () => {
        if (header) {
            if (window.scrollY > 30) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    });

    if (cookieBanner) {
        const savedChoice = localStorage.getItem('soyflorongCookieChoice');
        if (savedChoice) {
            cookieBanner.classList.add('hidden');
        }

        cookieButtons.forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const choice = button.dataset.choice || 'decline';
                localStorage.setItem('soyflorongCookieChoice', choice);
                cookieBanner.classList.add('hidden');
            });
        });
    }
});