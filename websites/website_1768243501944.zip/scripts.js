document.addEventListener('DOMContentLoaded', function () {
    var consentKey = 'genuscayqg_cookie_consent';
    var cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner && !localStorage.getItem(consentKey)) {
        cookieBanner.classList.add('active');
    }
    document.querySelectorAll('.cookie-button').forEach(function (button) {
        button.addEventListener('click', function () {
            localStorage.setItem(consentKey, button.dataset.choice);
            if (cookieBanner) {
                cookieBanner.classList.remove('active');
            }
        });
    });

    var mobileToggle = document.querySelector('.mobile-menu-toggle');
    var siteNav = document.querySelector('.site-nav');
    if (mobileToggle && siteNav) {
        mobileToggle.addEventListener('click', function () {
            siteNav.classList.toggle('active');
        });
    }

    var filterButtons = document.querySelectorAll('.filter-button');
    var destinationCards = document.querySelectorAll('.destination-card');
    if (filterButtons.length && destinationCards.length) {
        filterButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                var selected = button.dataset.filter;
                filterButtons.forEach(function (btn) {
                    btn.classList.toggle('active', btn === button);
                });
                destinationCards.forEach(function (card) {
                    var matches = selected === 'all' || card.dataset.region === selected;
                    card.style.display = matches ? 'flex' : 'none';
                });
            });
        });
    }

    var storyTrack = document.querySelector('.story-carousel-track');
    var storySlides = document.querySelectorAll('.story-slide');
    if (storyTrack && storySlides.length) {
        var currentIndex = 0;
        var updateCarousel = function () {
            var offset = currentIndex * storyTrack.clientWidth;
            storyTrack.scrollTo({ left: offset, behavior: 'smooth' });
        };
        document.querySelectorAll('.carousel-button').forEach(function (button) {
            button.addEventListener('click', function () {
                if (button.dataset.direction === 'prev') {
                    currentIndex = (currentIndex - 1 + storySlides.length) % storySlides.length;
                } else {
                    currentIndex = (currentIndex + 1) % storySlides.length;
                }
                updateCarousel();
            });
        });
        window.addEventListener('resize', updateCarousel);
    }

    document.querySelectorAll('.toggle-comments').forEach(function (toggle) {
        toggle.addEventListener('click', function () {
            var targetId = toggle.dataset.target;
            var target = document.getElementById(targetId);
            if (target) {
                var expanded = toggle.getAttribute('aria-expanded') === 'true';
                toggle.setAttribute('aria-expanded', (!expanded).toString());
                target.classList.toggle('active', !expanded);
            }
        });
    });
});