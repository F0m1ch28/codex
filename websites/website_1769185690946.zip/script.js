document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".mobile-nav-toggle");
  const primaryNavigation = document.querySelector(".primary-navigation");
  const navLinks = document.querySelectorAll(".primary-navigation a");

  if (navToggle && primaryNavigation) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNavigation.dataset.visible = String(!expanded);
      navToggle.classList.toggle("is-active");
      document.body.classList.toggle("nav-open", !expanded);
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 1024) {
          primaryNavigation.dataset.visible = "false";
          navToggle.setAttribute("aria-expanded", "false");
          navToggle.classList.remove("is-active");
          document.body.classList.remove("nav-open");
        }
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("alintaCookieChoice");
    if (!storedChoice) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add("is-visible");
      });
    } else {
      cookieBanner.classList.add("is-hidden");
    }

    cookieBanner.querySelectorAll("button[data-cookie-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        const choice = button.dataset.cookieChoice;
        localStorage.setItem("alintaCookieChoice", choice);
        cookieBanner.classList.remove("is-visible");
        setTimeout(() => {
          cookieBanner.classList.add("is-hidden");
        }, 320);
      });
    });
  }

  const forms = document.querySelectorAll("form[data-redirect]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const redirectTarget = form.getAttribute("data-redirect") || "thank-you.html";
      showToast("Thank you for your message. We will provide a considered reply soon.");
      setTimeout(() => {
        window.location.href = redirectTarget;
      }, 1600);
    });
  });

  function showToast(message) {
    let toast = document.querySelector(".toast-message");
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "toast-message";
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    requestAnimationFrame(() => {
      toast.classList.add("is-visible");
    });
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 3400);
  }

  const observerElements = document.querySelectorAll(".observe");
  if ("IntersectionObserver" in window) {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    observerElements.forEach((el) => revealObserver.observe(el));
  } else {
    observerElements.forEach((el) => el.classList.add("in-view"));
  }

  const yearSpans = document.querySelectorAll(".current-year");
  const currentYear = new Date().getFullYear();
  yearSpans.forEach((span) => (span.textContent = currentYear));
});