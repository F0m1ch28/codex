document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('.main-nav');
    const scrollBtn = document.getElementById('scrollTop');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAccept = document.getElementById('cookieAccept');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            mainNav.classList.toggle('open');
        });
    }

    document.querySelectorAll('a[data-target]').forEach(link => {
        link.addEventListener('click', event => {
            const targetId = link.dataset.target;
            const isHome = document.body.classList.contains('page-home');
            if (mainNav && mainNav.classList.contains('open')) {
                mainNav.classList.remove('open');
                navToggle?.setAttribute('aria-expanded', 'false');
            }
            if (isHome) {
                event.preventDefault();
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
                } else if (targetId === 'intro') {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            } else {
                event.preventDefault();
                window.location.href = `index.html#${targetId}`;
            }
        });
    });

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const currentYear = new Date().getFullYear();
    const yearSpans = [
        document.getElementById('copyright-year'),
        document.getElementById('copyright-year-terms'),
        document.getElementById('copyright-year-privacy'),
        document.getElementById('copyright-year-cookie')
    ];
    yearSpans.forEach(span => {
        if (span) {
            span.textContent = currentYear;
        }
    });

    const cookieKey = 'xirendexyraCookies';
    if (cookieBanner && localStorage.getItem(cookieKey) === 'accepted') {
        cookieBanner.classList.add('hidden');
        cookieBanner.setAttribute('aria-hidden', 'true');
    }

    if (cookieBanner && cookieAccept) {
        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            cookieBanner.classList.add('hidden');
            cookieBanner.setAttribute('aria-hidden', 'true');
        });
    }
});