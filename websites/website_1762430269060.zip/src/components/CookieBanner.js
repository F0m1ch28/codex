import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem('aecd-cookie-consent');
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('aecd-cookie-consent', 'accepted');
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Informativa sui cookie">
      <div className={styles.text}>
        Utilizziamo cookie tecnici e di analisi per migliorare la tua esperienza formativa. Puoi consultare la nostra
        <a href="/cookie-policy"> Cookie Policy</a> per maggiori dettagli.
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Accetto
      </button>
    </div>
  );
};

export default CookieBanner;