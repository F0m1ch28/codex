import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.container}>
        <div className={styles.column}>
          <h2 id="footer-heading" className={styles.brand}>
            Accademia Europea di Comunicazione Digitale
          </h2>
          <p className={styles.description}>
            Formiamo professionisti capaci di progettare strategie digitali, branding distintivi e contenuti capaci di creare valore nel lungo periodo.
          </p>
          <div className={styles.contactBlock}>
            <p className={styles.contactRow}>
              Via Milano, 22, 20121 Milano MI
            </p>
            <p className={styles.contactRow}>
              Tel: <a href="tel:+390294568113">+39 02 9456 8113</a>
            </p>
            <p className={styles.contactRow}>
              Email: [будет добавлен в форме контакtos]
            </p>
          </div>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Esplora</h3>
          <ul className={styles.linkList}>
            <li><Link to="/chi-siamo">Chi siamo</Link></li>
            <li><Link to="/corsi">Corsi</Link></li>
            <li><Link to="/programma">Programma</Link></li>
            <li><Link to="/docenti">Docenti</Link></li>
            <li><Link to="/contatti">Contatti</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Informazioni legali</h3>
          <ul className={styles.linkList}>
            <li><Link to="/termini">Termini di utilizzo</Link></li>
            <li><Link to="/privacy">Privacy Policy</Link></li>
            <li><Link to="/cookie-policy">Cookie Policy</Link></li>
          </ul>
          <p className={styles.note}>
            Milano è la nostra casa: laboratori immersivi, mentoring continuo e partnership con realtà europee del digitale.
          </p>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <span>© {new Date().getFullYear()} Accademia Europea di Comunicazione Digitale. Tutti i diritti riservati.</span>
        <div className={styles.badges} aria-hidden="true">
          <span>Branding</span>
          <span>Content Strategy</span>
          <span>Growth Lab</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;