import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Informativa sulla protezione dei dati personali (GDPR) dell’Accademia Europea di Comunicazione Digitale."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Informativa ai sensi degli articoli 13 e 14 del GDPR (Regolamento UE 2016/679)</p>
        </div>
      </section>

      <section className={`${styles.legalContent} sectionSpacing`}>
        <div className="container">
          <h2>Titolare del trattamento</h2>
          <p>Accademia Europea di Comunicazione Digitale, Via Milano, 22, 20121 Milano MI.</p>

          <h2>Finalità del trattamento</h2>
          <p>
            I dati raccolti tramite form di contatto, eventi e attività informative sono utilizzati esclusivamente per rispondere alle richieste degli interessati, pianificare colloqui di orientamento e inviare comunicazioni sulle attività formative.
          </p>

          <h2>Basi giuridiche</h2>
          <p>
            Il trattamento si basa sul consenso dell’interessato e sull’esecuzione di misure precontrattuali richieste dall’utente (art. 6, lett. a) e b) GDPR).
          </p>

          <h2>Modalità e tempi di conservazione</h2>
          <p>
            Il trattamento avviene mediante strumenti informatici e cartacei, con misure di sicurezza adeguate. I dati sono conservati per il tempo necessario a soddisfare la richiesta informativa e per eventuali successive attività di orientamento, comunque non oltre 24 mesi.
          </p>

          <h2>Diritti degli interessati</h2>
          <p>
            Gli interessati possono richiedere l’accesso ai dati, la rettifica, la cancellazione, la limitazione o l’opposizione al trattamento, nonché il diritto alla portabilità, scrivendo agli uffici dell’accademia.
          </p>

          <h2>Comunicazione e trasferimento</h2>
          <p>
            I dati non vengono diffusi. Possono essere comunicati a partner tecnici per finalità strettamente connesse alla gestione della piattaforma informativa, con impegni contrattuali di riservatezza e conformità al GDPR. Non è previsto il trasferimento verso paesi terzi.
          </p>

          <h2>Reclami</h2>
          <p>
            In caso di violazione dei diritti, l’interessato può rivolgersi al Garante per la Protezione dei Dati Personali.
          </p>

          <h2>Aggiornamenti</h2>
          <p>
            L’accademia potrà aggiornare l’informativa per adeguamenti normativi o evoluzione dei servizi. Eventuali modifiche saranno pubblicate su questa pagina.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;