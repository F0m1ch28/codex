import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Corsi | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Dettagli sui corsi dell’Accademia Europea: Pubblicità Targetizzata, Coding e Social Media Marketing con laboratori immersivi e project work."
        />
        <meta
          name="keywords"
          content="corsi digitali Milano, pubblicità targetizzata, corso coding, social media marketing, content strategy"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>I nostri corsi</h1>
          <p>
            Tre esperienze complementari che alimentano il Corso Avanzato di Branding Online e Content Strategy. Ogni modulo è curato da specialisti che operano quotidianamente nel settore.
          </p>
        </div>
      </section>

      <section className={`${styles.courses} sectionSpacing`}>
        <div className="container">
          <article className={styles.course}>
            <div className={styles.courseMedia}>
              <img
                src="https://picsum.photos/800/600?random=6"
                alt="Dashboard di campagne pubblicitarie con grafici e metriche"
                loading="lazy"
              />
            </div>
            <div className={styles.courseContent}>
              <span className={styles.courseTag}>Campaign Lab</span>
              <h2>Pubblicità Targetizzata</h2>
              <p>
                Impara a progettare campagne Facebook Ads e Google Ads multi-canale, definendo segmentazioni evolute, creatività pertinenti e KPI misurabili. Dalla pianificazione al post-campagna, passerai per ottimizzazione, A/B test, attribution modeling e reporting narrativo.
              </p>
              <ul>
                <li>Framework di acquisizione e remarketing</li>
                <li>Budgeting dinamico e gestione di bid strategy</li>
                <li>Analisi dei funnel e costruzione di dashboard personalizzate</li>
                <li>Case study con partner B2B e DTC europei</li>
              </ul>
            </div>
          </article>

          <article className={styles.course}>
            <div className={styles.courseMedia}>
              <img
                src="https://picsum.photos/800/600?random=16"
                alt="Codice e wireframe su due monitor con interfaccia moderna"
                loading="lazy"
              />
            </div>
            <div className={styles.courseContent}>
              <span className={styles.courseTag}>Creative Coding</span>
              <h2>Coding</h2>
              <p>
                Dalla progettazione di layout responsive allo sviluppo di componenti interattive, costruirai un mindset tecnico per dialogare con designer e sviluppatori. HTML semantico, CSS modulare, JavaScript moderno e introduzione alla prototipazione con React.
              </p>
              <ul>
                <li>Architettura front-end e accessibilità</li>
                <li>Librerie e componenti riutilizzabili con CSS Modules</li>
                <li>Automazione e analisi con Python per il marketing</li>
                <li>Versionamento con Git e documentazione</li>
              </ul>
            </div>
          </article>

          <article className={styles.course}>
            <div className={styles.courseMedia}>
              <img
                src="https://picsum.photos/800/600?random=26"
                alt="Strategia social media su un tavolo con laptop e smartphone"
                loading="lazy"
              />
            </div>
            <div className={styles.courseContent}>
              <span className={styles.courseTag}>Social Studio</span>
              <h2>Social Media Marketing</h2>
              <p>
                Progetta una presenza social coerente con la personalità del brand. Dal tone of voice alle rubriche editoriali, fino a campagne su Instagram e TikTok con analisi delle performance e community management.
              </p>
              <ul>
                <li>Strategia editoriale e content calendar</li>
                <li>Produzione di format video e visual dinamici</li>
                <li>Gestione community, moderazione e crisis plan</li>
                <li>Misurazione: KPI, sentiment analysis, social listening</li>
              </ul>
            </div>
          </article>
        </div>
      </section>
    </>
  );
};

export default Services;