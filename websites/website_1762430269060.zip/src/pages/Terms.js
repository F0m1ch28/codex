import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Termini di utilizzo | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Condizioni generali di utilizzo del sito e dei servizi della Accademia Europea di Comunicazione Digitale."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Termini di utilizzo</h1>
          <p>Ultimo aggiornamento: 10 gennaio 2024</p>
        </div>
      </section>

      <section className={`${styles.legalContent} sectionSpacing`}>
        <div className="container">
          <h2>1. Oggetto</h2>
          <p>
            I presenti termini regolano l’accesso e l’utilizzo del sito web dell’Accademia Europea di Comunicazione Digitale e dei relativi contenuti informativi. Accedendo al sito, l’utente accetta integralmente le condizioni qui riportate.
          </p>

          <h2>2. Diritti di proprietà intellettuale</h2>
          <p>
            Testi, immagini, grafiche e materiali didattici pubblicati sono di proprietà dell’accademia o dei rispettivi licenziatari. È vietata la riproduzione, anche parziale, senza previa autorizzazione scritta.
          </p>

          <h2>3. Uso consentito</h2>
          <p>
            Il sito è destinato a utenti interessati alle attività formative dell’accademia. È vietato qualsiasi utilizzo che possa compromettere la sicurezza del sito o che sia contrario alla normativa vigente.
          </p>

          <h2>4. Limitazione di responsabilità</h2>
          <p>
            Le informazioni pubblicate sono fornite con accuratezza. Tuttavia, l’accademia non garantisce l’assenza di errori o interruzioni e declina ogni responsabilità per eventuali danni derivanti da un uso improprio del sito.
          </p>

          <h2>5. Link esterni</h2>
          <p>
            Il sito può contenere collegamenti a risorse esterne per semplice riferimento. L’accademia non è responsabile dei contenuti di tali risorse né dell’eventuale utilizzo che ne facciano gli utenti.
          </p>

          <h2>6. Modifiche ai termini</h2>
          <p>
            L’accademia si riserva il diritto di aggiornare i presenti termini. Le modifiche saranno pubblicate in questa pagina e avranno effetto dalla data di pubblicazione.
          </p>

          <h2>7. Contatti</h2>
          <p>
            Per chiarimenti sui presenti termini è possibile rivolgersi alla sede di Via Milano, 22, 20121 Milano MI, Tel: +39 02 9456 8113.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;