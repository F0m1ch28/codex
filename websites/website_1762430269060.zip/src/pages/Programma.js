import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programma.module.css';

const Programma = () => {
  return (
    <>
      <Helmet>
        <title>Programma | Corso Avanzato di Branding Online e Content Strategy</title>
        <meta
          name="description"
          content="Struttura del corso avanzato: moduli, durata, project work, certificazioni e competenze sviluppate in branding digitale e content strategy."
        />
        <meta
          name="keywords"
          content="programma corso branding, moduli content strategy, project work digitale, certificazioni comunicazione digitale"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Programma del Corso Avanzato</h1>
          <p>
            Un percorso di 24 settimane strutturato in quattro blocchi: scoperta, design strategico, execution e validazione finale. Ogni fase unisce teoria, pratica e mentorship.
          </p>
        </div>
      </section>

      <section className={`${styles.structure} sectionSpacing`}>
        <div className="container">
          <div className={styles.modules}>
            <article>
              <span className={styles.moduleBadge}>Modulo 01 · 4 settimane</span>
              <h2>Research & Brand Discovery</h2>
              <p>
                Ricerca qualitativa e quantitativa, analisi delle audience, definizione di architetture di marca e tone of voice. Introduzione agli strumenti di social listening e competitive benchmarking.
              </p>
              <ul>
                <li>Workshop: Insight mapping</li>
                <li>Canvas: Brand blueprint</li>
                <li>Strumenti: Similarweb, Brandwatch, Google Data Studio</li>
              </ul>
            </article>
            <article>
              <span className={styles.moduleBadge}>Modulo 02 · 8 settimane</span>
              <h2>Content Strategy & Experience Design</h2>
              <p>
                Pianificazione editoriale multi-canale, storytelling, UX writing e progettazione di customer journey. Si lavora su editorial plan, campagne multiformato e prototipi interattivi.
              </p>
              <ul>
                <li>Laboratori cross-platform con team interfunzionali</li>
                <li>Coaching su voce del brand e design system</li>
                <li>Case study con brand retail, tech e cultura</li>
              </ul>
            </article>
            <article>
              <span className={styles.moduleBadge}>Modulo 03 · 8 settimane</span>
              <h2>Campaign Execution & Growth</h2>
              <p>
                Attivazione di campagne paid, automazioni, ottimizzazione dei funnel, misurazione KPI e reportistica narrativa. Ogni team gestisce budget, targetizzazione e iterazioni in tempo reale.
              </p>
              <ul>
                <li>Google Ads, Meta Ads, TikTok Ads manager</li>
                <li>Dashboard personalizzate e data visualization</li>
                <li>Workshop con Growth Manager ospiti</li>
              </ul>
            </article>
            <article>
              <span className={styles.moduleBadge}>Modulo 04 · 4 settimane</span>
              <h2>Capstone Project & Certification</h2>
              <p>
                Progetto finale integrato con presentazione a una commissione di professionisti. Revisione portfoli, storytelling personale e definizione del piano di crescita professionale.
              </p>
              <ul>
                <li>Pitching, public speaking e trattativa</li>
                <li>Report finale con metriche e lesson learned</li>
                <li>Certificazione AECD + endorsements dei partner</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.details} sectionSpacing`}>
        <div className="container">
          <div className={styles.detailGrid}>
            <div className={styles.detailCard}>
              <h3>Project Work</h3>
              <p>
                Due project sprint di 6 settimane ciascuno con brief forniti da realtà attive in moda, tech, cultura e impatto sociale. Supervisor dedicati, check settimanali e demo finale con feedback.
              </p>
            </div>
            <div className={styles.detailCard}>
              <h3>Strumenti inclusi</h3>
              <p>
                Accesso a suite professionali per analytics, content design, automazione e prototipazione. Supporto tecnico e tutorial on demand disponibili in piattaforma.
              </p>
            </div>
            <div className={styles.detailCard}>
              <h3>Mentorship</h3>
              <p>
                Sessioni one-to-one mensili per allineamento obiettivi, coaching sul mindset e sviluppo del portfolio personale orientato al posizionamento professionale.
              </p>
            </div>
            <div className={styles.detailCard}>
              <h3>Community & eventi</h3>
              <p>
                Visite in agenzia, talk con ospiti internazionali, eventi di networking e accesso a un hub digitale con risorse, workshop extra e offerte professionali.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Programma;