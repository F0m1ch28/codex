import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    messaggio: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.nome.trim() || formData.nome.trim().length < 2) {
      newErrors.nome = 'Inserisci il tuo nome completo.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Inserisci un indirizzo email valido.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Il formato email non è corretto.';
    }
    if (!formData.messaggio.trim() || formData.messaggio.trim().length < 10) {
      newErrors.messaggio = 'Raccontaci in breve i tuoi obiettivi formativi.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus(null);
      return;
    }
    setStatus('Richiesta inviata. Ti ricontatteremo entro 24 ore lavorative.');
    setFormData({ nome: '', email: '', messaggio: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contatti | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Contatta l’Accademia Europea di Comunicazione Digitale: sede a Milano, form pre-iscrizione, orientamento e informazioni sul corso avanzato."
        />
        <meta
          name="keywords"
          content="contatti accademia, comunicazione digitale Milano, orientamento corsi, sede via Milano 22"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Contattaci</h1>
          <p>
            Raccontaci la tua esperienza e i tuoi obiettivi: costruiremo insieme il percorso ideale per entrare nel Corso Avanzato di Branding Online e Content Strategy.
          </p>
        </div>
      </section>

      <section className={`${styles.contactSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.info}>
              <h2>Accademia Europea di Comunicazione Digitale</h2>
              <p>
                Via Milano, 22, 20121 Milano MI<br />
                Tel: <a href="tel:+390294568113">+39 02 9456 8113</a><br />
                Email: [будет добавлен в форме контактов]
              </p>
              <p>
                Riceviamo su appuntamento dal lunedì al venerdì, dalle 9:30 alle 18:30. Prenota un colloquio di orientamento oppure partecipa a un open day per esplorare laboratori e project room.
              </p>
              <div className={styles.mapWrapper} aria-label="Mappa della sede di Milano">
                <iframe
                  title="Mappa sede Milano"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2796.769643163148!2d9.188876315891435!3d45.46679774086538!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4786c6a24ed2d2b7%3A0x6c3fb4bf9a9eca94!2sVia%20Milano%2C%2022%2C%2020121%20Milano%20MI!5e0!3m2!1sit!2sit!4v1700000000000!5m2!1sit!2sit"
                  width="100%"
                  height="250"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
            <div className={styles.formCard}>
              <h2>Richiedi informazioni</h2>
              <p>Compila il modulo: il nostro team admissions ti contatterà con le prossime disponibilità.</p>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label htmlFor="nome">Nome e cognome</label>
                <input
                  type="text"
                  id="nome"
                  name="nome"
                  value={formData.nome}
                  onChange={handleChange}
                  required
                  aria-invalid={!!errors.nome}
                />
                {errors.nome && <span className={styles.error}>{errors.nome}</span>}

                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}

                <label htmlFor="messaggio">Messaggio</label>
                <textarea
                  id="messaggio"
                  name="messaggio"
                  rows="5"
                  value={formData.messaggio}
                  onChange={handleChange}
                  required
                  aria-invalid={!!errors.messaggio}
                />
                {errors.messaggio && <span className={styles.error}>{errors.messaggio}</span>}

                <button type="submit" className="btnPrimary">
                  Invia la tua richiesta
                </button>
                {status && (
                  <p className={styles.success} role="status" aria-live="polite">
                    {status}
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;