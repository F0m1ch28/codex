import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Informativa sull’utilizzo dei cookie dell’Accademia Europea di Comunicazione Digitale in conformità alla normativa europea."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>Informazioni sull’uso dei cookie in conformità al Regolamento UE 2016/679 e al provvedimento del Garante Privacy.</p>
        </div>
      </section>

      <section className={`${styles.legalContent} sectionSpacing`}>
        <div className="container">
          <h2>Cosa sono i cookie?</h2>
          <p>
            I cookie sono piccoli file di testo che i siti visitati inviano al terminale dell’utente, dove vengono memorizzati per essere poi ritrasmessi agli stessi siti alle visite successive. Servono a migliorare l’esperienza di navigazione e fornire informazioni ai gestori del sito.
          </p>

          <h2>Cookie utilizzati</h2>
          <ul>
            <li><strong>Cookie tecnici</strong>: indispensabili per il funzionamento del sito e per fornire i servizi richiesti dagli utenti.</li>
            <li><strong>Cookie di analisi</strong>: utilizzati in forma aggregata per comprendere come viene utilizzato il sito e migliorare i contenuti pubblicati.</li>
          </ul>

          <h2>Gestione del consenso</h2>
          <p>
            Al primo accesso viene mostrato un banner che consente di accettare l’uso dei cookie. È sempre possibile modificare il consenso attraverso le impostazioni del browser.
          </p>

          <h2>Come disabilitare i cookie</h2>
          <p>
            È possibile configurare il proprio browser per rifiutare o cancellare i cookie. Di seguito alcuni link di riferimento: Chrome, Firefox, Edge, Safari. La disabilitazione dei cookie tecnici può compromettere il corretto funzionamento del sito.
          </p>

          <h2>Contatti</h2>
          <p>
            Per ulteriori informazioni è possibile contattare l’accademia presso Via Milano, 22, 20121 Milano MI, Tel: +39 02 9456 8113.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;