import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const Home = () => {
  const statsData = [
    { label: 'Talenti formati', value: 480, suffix: '+' },
    { label: 'Progetti reali consegnati', value: 92, suffix: '%' },
    { label: 'Partner europei', value: 28, suffix: '' }
  ];

  const [counters, setCounters] = useState(statsData.map(() => 0));

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const increment = Math.max(1, Math.ceil(stat.value / 60));
      return setInterval(() => {
        setCounters((prev) => {
          const next = [...prev];
          if (next[index] < stat.value) {
            next[index] = Math.min(stat.value, next[index] + increment);
          }
          return next;
        });
      }, 40);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  const testimonials = [
    {
      name: 'Giulia Rinaldi',
      role: 'Content Strategist presso Studio Blend',
      quote:
        'Il percorso mi ha insegnato a leggere i dati con occhi nuovi e a trasformarli in storytelling coerente. Le mentorship one-to-one hanno accelerato la mia crescita professionale.'
    },
    {
      name: 'Alessandro Lupini',
      role: 'Digital Marketing Specialist, Milano',
      quote:
        'Ho lavorato su campagne Facebook e Google Ads reali, con budget e vincoli concreti. Il supporto dei docenti e dei compagni ha creato una community che dura ancora oggi.'
    },
    {
      name: 'Sofia Marchi',
      role: 'Brand Designer freelance',
      quote:
        'Dal laboratorio di branding ho portato a casa un metodo replicabile. Ogni modulo combina teoria, strumenti e project work con brand internazionali: impagabile.'
    }
  ];

  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const teamPreview = [
    {
      name: 'Martina Bianchi',
      role: 'Head of Content Strategy',
      image: 'https://picsum.photos/400/400?random=3',
      bio: 'Ha guidato progetti di storytelling digitale per brand fashion e fintech in Europa.'
    },
    {
      name: 'Diego Carminati',
      role: 'Lead SEO & Data Analyst',
      image: 'https://picsum.photos/400/400?random=13',
      bio: 'Specialista in analisi dei dati e ottimizzazione organica per hub editoriali internazionali.'
    },
    {
      name: 'Laura Conti',
      role: 'Creative Technologist',
      image: 'https://picsum.photos/400/400?random=23',
      bio: 'Integra design, coding e motion per esperienze digitali immersive e accessibili.'
    }
  ];

  const categories = ['Tutti', 'Branding', 'Coding', 'Social Media'];
  const projects = [
    {
      id: 1,
      title: 'Rebranding per startup fintech',
      category: 'Branding',
      description:
        'Analisi del tone of voice, architettura dei contenuti e campagne di lancio con target B2B europeo.',
      image: 'https://picsum.photos/1200/800?random=4',
      alt: 'Dashboard di branding digitale con grafici di performance'
    },
    {
      id: 2,
      title: 'Piattaforma di e-learning interattiva',
      category: 'Coding',
      description:
        'Prototipo front-end in React con UI modulare, microinterazioni e contenuti dinamici.',
      image: 'https://picsum.photos/1200/800?random=14',
      alt: 'Codice su monitor con layout modulare responsive'
    },
    {
      id: 3,
      title: 'Campagna social per brand fashion',
      category: 'Social Media',
      description:
        'Piano editoriale TikTok e Instagram, creazione di rubriche narrative e misurazione delle metriche chiave.',
      image: 'https://picsum.photos/1200/800?random=24',
      alt: 'Storyboard di contenuti social con grafici di engagement'
    },
    {
      id: 4,
      title: 'Storytelling data-driven per ONG',
      category: 'Branding',
      description:
        'Data visualization, report interattivi e storytelling per campagne di awareness paneuropee.',
      image: 'https://picsum.photos/1200/800?random=34',
      alt: 'Team creativo che lavora su grafici e contenuti digitali'
    }
  ];

  const [activeCategory, setActiveCategory] = useState('Tutti');

  const faqItems = [
    {
      question: 'Qual è la durata complessiva del Corso Avanzato?',
      answer:
        'Il percorso si articola in 24 settimane di training intensivo, con 2 project sprint guidati e un modulo finale di presentazione davanti a un board di esperti.'
    },
    {
      question: 'Quanto è pratica l’esperienza formativa?',
      answer:
        'Ogni settimana alterna workshop operativi, analisi di casi studio, momenti di mentorship e attività laboratoriali su brief reali forniti dai partner dell’accademia.'
    },
    {
      question: 'Che tipo di supporto offrite sul job placement?',
      answer:
        'Organizziamo sessioni di career coaching, revisione del portfolio, simulazioni di colloqui digitali e speed meeting con agenzie e aziende tech di Milano e dell’Europa centrale.'
    },
    {
      question: 'È previsto un certificato finale riconosciuto?',
      answer:
        'Al termine del percorso si ottiene un certificato avanzato AECD, corredato da un report delle skill acquisite e dei progetti realizzati durante l’esperienza formativa.'
    }
  ];

  const blogPosts = [
    {
      id: 1,
      title: 'Come costruire una content strategy guidata dai dati',
      excerpt:
        'Dal brief alla calendarizzazione, passando per le metriche da monitorare per ottimizzare ogni campagna.',
      image: 'https://picsum.photos/800/600?random=5',
      alt: 'Planner editoriale digitale con grafici di analytics',
      link: '/programma'
    },
    {
      id: 2,
      title: 'Tre trend del branding digitale nel 2024',
      excerpt:
        'Identità fluide, presenza cross-platform e community design: ecco come le aziende stanno evolvendo il proprio racconto.',
      image: 'https://picsum.photos/800/600?random=15',
      alt: 'Moodboard di brand digitali moderni',
      link: '/corsi'
    },
    {
      id: 3,
      title: 'UX writing e content design: integrare voce e interazione',
      excerpt:
        'Linee guida e strumenti per progettare microtesti efficaci che accompagnino l’utente lungo il journey digitale.',
      image: 'https://picsum.photos/800/600?random=25',
      alt: 'Designer che lavora su interfaccia con testi e wireframe',
      link: '/chi-siamo'
    }
  ];

  const [openFaq, setOpenFaq] = useState(null);

  const filteredProjects =
    activeCategory === 'Tutti'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const handleFaqToggle = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Trasforma la tua carriera digitale | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Corso Avanzato di Branding Online e Content Strategy a Milano: laboratori immersivi, project work reali, mentorship e certificazione AECD."
        />
        <meta
          name="keywords"
          content="corsi online Italia, comunicazione digitale, formazione digitale, branding, content strategy, social media marketing, corso coding Milano"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Corso Avanzato 2024 · Milano & Online</span>
          <h1 className={styles.heroTitle}>Trasforma la Tua Carriera Digitale</h1>
          <p className={styles.heroText}>
            Un percorso intensivo che fonde branding, content strategy e marketing data-driven. Scopri come riprogettare la presenza digitale di brand internazionali con metodologie sperimentate sul campo.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contatti" className="btnPrimary">
              Inizia Oggi
            </Link>
            <Link to="/programma" className="btnSecondary">
              Guarda il programma
            </Link>
          </div>
        </div>
        <div
          className={styles.heroImage}
          role="img"
          aria-label="Studenti che collaborano su laptop durante un workshop digitale"
        />
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.intro}>
            <div className={styles.introText}>
              <h2>Accademia Europea di Comunicazione Digitale</h2>
              <p>
                Dal cuore di Milano accompagniamo professionisti, creativi e marketer verso un nuovo approccio alla comunicazione digitale. Crediamo in un metodo che unisce ricerca, progettazione e sperimentazione rapida, per costruire esperienze di marca coerenti e memorabili su ogni touchpoint.
              </p>
              <p>
                Il nostro Corso Avanzato di Branding Online e Content Strategy è pensato per chi desidera padroneggiare strumenti, linguaggi e framework che guidano i migliori team digitali europei. Ogni modulo è supportato da mentor di settore, project work su brief reali e feedback continui.
              </p>
            </div>
            <div className={styles.introMedia}>
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Team di studenti durante un laboratorio di strategia digitale"
                loading="lazy"
              />
              <div className={styles.mediaNote}>
                <strong>Metodo sperimentale</strong>
                <p>Laboratori blended, analisi di dati, storytelling e design system per piattaforme digitali.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section aria-label="Risultati dell'accademia" className={`${styles.statsSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {counters[index]}
                  {stat.suffix}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="corsi" className={`${styles.corsi} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="corsi">I Nostri Corsi</h2>
            <p>
              Tre percorsi integrati per completare la tua visione strategica: campagne media avanzate, coding creativo e strategie social che generano connessioni durature.
            </p>
          </div>
          <div className={styles.corsiGrid}>
            <article className={styles.courseCard}>
              <div className={styles.courseIcon} aria-hidden="true">🎯</div>
              <h3>Pubblicità Targetizzata</h3>
              <p>
                Pianifica campagne Facebook Ads e Google Ads multi-touch. Impara a leggere insight, ottimizzare funnel e attivare audience basate su comportamenti reali.
              </p>
              <Link to="/corsi" className={styles.linkArrow}>
                Esplora il corso
                <span aria-hidden="true">→</span>
              </Link>
            </article>
            <article className={styles.courseCard}>
              <div className={styles.courseIcon} aria-hidden="true">💻</div>
              <h3>Coding</h3>
              <p>
                Dalla prototipazione HTML/CSS al JavaScript moderno e alle basi di Python per l’automazione: costruisci esperienze digitali scalabili e accessibili.
              </p>
              <Link to="/corsi" className={styles.linkArrow}>
                Esplora il corso
                <span aria-hidden="true">→</span>
              </Link>
            </article>
            <article className={styles.courseCard}>
              <div className={styles.courseIcon} aria-hidden="true">📣</div>
              <h3>Social Media Marketing</h3>
              <p>
                Padroneggia la progettazione editoriale, le attivazioni su Instagram e TikTok e le strategie di community management orientate agli obiettivi di business.
              </p>
              <Link to="/corsi" className={styles.linkArrow}>
                Esplora il corso
                <span aria-hidden="true">→</span>
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section aria-labelledby="process" className={`${styles.processSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="process">Come Funziona</h2>
            <p>Un percorso chiaro, scandito da fasi progettuali e feedback costanti, per consolidare competenze e mindset.</p>
          </div>
          <ol className={styles.processList}>
            <li>
              <span className={styles.stepNumber}>1</span>
              <h3>Diagnosi iniziale</h3>
              <p>Assessment delle competenze, definizione degli obiettivi personali e piano di crescita condiviso con il mentor.</p>
            </li>
            <li>
              <span className={styles.stepNumber}>2</span>
              <h3>Laboratori intensivi</h3>
              <p>Workshop guidati, casi studio europei e simulazioni su dataset reali per imparare metodologie replicabili.</p>
            </li>
            <li>
              <span className={styles.stepNumber}>3</span>
              <h3>Project sprint</h3>
              <p>Team dedicati lavorano su brief concreti con momenti di revisione, prototipazione e presentazione agli stakeholder.</p>
            </li>
            <li>
              <span className={styles.stepNumber}>4</span>
              <h3>Portfolio & networking</h3>
              <p>Costruzione di artefatti professionali, orientamento al job placement e accesso a eventi in collaborazione con partner.</p>
            </li>
          </ol>
        </div>
      </section>

      <section aria-labelledby="perche-sceglierci" className={`${styles.percheSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="perche-sceglierci">Perché Sceglierci</h2>
            <p>Esperienza immersiva, rete di professionisti e strumenti concreti per guidare progetti digitali complessi.</p>
          </div>
          <div className={styles.percheGrid}>
            <article className={styles.percheCard}>
              <h3>Mentor dal settore</h3>
              <p>Docenti provenienti da agenzie e aziende internazionali che portano casi reali in aula ogni settimana.</p>
            </article>
            <article className={styles.percheCard}>
              <h3>Metodo blended</h3>
              <p>Lezioni live, moduli on demand, laboratorio fisico a Milano e supporto continuo con strumenti collaborativi.</p>
            </article>
            <article className={styles.percheCard}>
              <h3>Community europea</h3>
              <p>Network di alumni, ospiti e partner da tutta Europa per confrontarsi, collaborare e crescere insieme.</p>
            </article>
            <article className={styles.percheCard}>
              <h3>Progetti certificati</h3>
              <p>Ogni attività genera deliverable tangibili per arricchire il tuo portfolio e comunicare il tuo valore.</p>
            </article>
            <article className={styles.percheCard}>
              <h3>Approccio data-driven</h3>
              <p>Dashboard, insight e processi decisionali basati sui dati per migliorare campagne e contenuti.</p>
            </article>
            <article className={styles.percheCard}>
              <h3>Accessibilità</h3>
              <p>Design inclusivo, attenzione all’esperienza utente e strumenti per garantire una comunicazione equa.</p>
            </article>
          </div>
        </div>
      </section>

      <section aria-label="Testimonianze" className={`${styles.testimonials} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Testimonianze</h2>
            <p>Voce a chi ha scelto l’Accademia e oggi guida strategie digitali in contesti internazionali.</p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
                <div className={styles.testimonialMeta}>
                  <span className={styles.testimonialName}>{testimonial.name}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.testimonialNav}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                aria-label={`Mostra testimonianza ${index + 1}`}
                onClick={() => setActiveTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="team" className={`${styles.teamSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="team">Team Accademico</h2>
            <p>Professionisti che uniscono strategia, creatività e tecnologia per guidare ogni modulo.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamPreview.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`Ritratto di ${member.name}`} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                  <Link to="/docenti" className={styles.moreLink}>
                    Scopri il profilo completo
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="progetti" className={`${styles.projectsSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="progetti">Progetti in evidenza</h2>
            <p>Una selezione dei project work sviluppati durante gli sprint: ogni team racconta un risultato reale.</p>
          </div>
          <div className={styles.filterBar}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.alt} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectTag}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="faq" className={`${styles.faqSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="faq">Domande Frequenti</h2>
            <p>Informazioni pratiche per comprendere come funziona il nostro ecosistema formativo.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={openFaq === index}
                >
                  <span>{item.question}</span>
                  <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
                </button>
                {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="blog" className={`${styles.blogSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog">Insight dal nostro laboratorio</h2>
            <p>Approfondimenti, framework e casi studio sviluppati durante le sessioni di ricerca dell’Accademia.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.alt} loading="lazy" />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.linkArrow}>
                    Continua a leggere
                    <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} sectionSpacing`} aria-labelledby="cta">
        <div className="container">
          <div className={styles.ctaContent}>
            <h2 id="cta">Porta il tuo talento al livello successivo</h2>
            <p>
              Entra nel Corso Avanzato di Branding Online e Content Strategy. Unisciti a una community in continua evoluzione e progetta esperienze digitali che generano impatto.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contatti" className="btnPrimary">
                Prenota un colloquio di orientamento
              </Link>
              <Link to="/chi-siamo" className="btnSecondary">
                Conosci l’accademia
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;