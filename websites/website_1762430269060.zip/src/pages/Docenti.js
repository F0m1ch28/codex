import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Docenti.module.css';

const Docenti = () => {
  const docenti = [
    {
      name: 'Martina Bianchi',
      role: 'Head of Content Strategy · ex Condé Nast',
      bio: 'Oltre 12 anni di esperienza nel guidare team editoriali digitali. Specializzata in storytelling, UX writing e integrazione di dati qualitativi nelle strategie multi-channel.',
      image: 'https://picsum.photos/400/400?random=7'
    },
    {
      name: 'Diego Carminati',
      role: 'Lead SEO & Data Analyst · Growth Lab',
      bio: 'Ha lavorato per agenzie di performance marketing in Italia e Germania, sviluppando framework di analisi data-driven per brand e media company.',
      image: 'https://picsum.photos/400/400?random=17'
    },
    {
      name: 'Laura Conti',
      role: 'Creative Technologist · Freelance',
      bio: 'Designer ibrida con background in interaction design e motion. Porta in aula workshop su prototipazione rapida, front-end creativo e accessibility by design.',
      image: 'https://picsum.photos/400/400?random=27'
    },
    {
      name: 'Amina Rahimi',
      role: 'Paid Media Specialist · Agency Eleven',
      bio: 'Gestisce campagne multi-mercato per brand fashion e travel. Esperta di targetizzazione avanzata, misurazione incrementale e testing creativo.',
      image: 'https://picsum.photos/400/400?random=37'
    },
    {
      name: 'Luca Pederzani',
      role: 'Senior Copy Strategist · Stories & Co.',
      bio: 'Aiuta i brand a definire voce e posizionamento narrativo. Nel corso segue esercitazioni su copywriting, tono di voce e script per video verticali.',
      image: 'https://picsum.photos/400/400?random=47'
    },
    {
      name: 'Elisabeth Krüger',
      role: 'UX Research Lead · Berlin Digital Studio',
      bio: 'Esperta di ricerca qualitativa e quantitativa, guida i moduli su insight generation, customer journey e human-centered design in contesti internazionali.',
      image: 'https://picsum.photos/400/400?random=57'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Docenti | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Conosci i docenti dell’Accademia Europea: professionisti europei di branding, content strategy, paid media, coding e ricerca UX."
        />
        <meta
          name="keywords"
          content="docenti branding, mentor content strategy, professionisti comunicazione digitale, team formatori Milano"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Docenti e mentor</h1>
          <p>
            Professionisti europei che portano in aula visione, pratiche e strumenti aggiornati. Ogni modulo è guidato da chi sperimenta ogni giorno sul campo.
          </p>
        </div>
      </section>

      <section className={`${styles.gridSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.grid}>
            {docenti.map((docente) => (
              <article key={docente.name} className={styles.card}>
                <img src={docente.image} alt={`Ritratto di ${docente.name}`} loading="lazy" />
                <div className={styles.cardBody}>
                  <h2>{docente.name}</h2>
                  <span>{docente.role}</span>
                  <p>{docente.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Docenti;