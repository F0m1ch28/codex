import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <Helmet>
        <title>Chi siamo | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Scopri la storia dell’Accademia Europea di Comunicazione Digitale: missione, valori, metodologia didattica e team fondatore."
        />
        <meta
          name="keywords"
          content="Accademia Europea, comunicazione digitale, missione accademia, metodologia didattica, formazione digitale Milano"
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="about-hero">
        <div className="container">
          <h1 id="about-hero">La nostra storia</h1>
          <p>
            L’Accademia Europea di Comunicazione Digitale nasce a Milano nel 2016 per colmare il divario tra formazione tradizionale e le competenze richieste dai team digitali più innovativi. Siamo strateghe, designer, marketer e storyteller che hanno deciso di condividere strumenti, visione e cultura progettuale.
          </p>
        </div>
      </section>

      <section className={`${styles.story} sectionSpacing`}>
        <div className="container">
          <div className={styles.timeline}>
            <div className={styles.event}>
              <span className={styles.year}>2016</span>
              <div>
                <h3>Fondazione</h3>
                <p>
                  Un gruppo di professionisti europei sceglie Milano per creare un hub formativo centrato su contenuti e branding digitale. Nasce un primo laboratorio con 25 studenti e partnership con agenzie creative.
                </p>
              </div>
            </div>
            <div className={styles.event}>
              <span className={styles.year}>2019</span>
              <div>
                <h3>Metodo blended</h3>
                <p>
                  Introduciamo il modello blended: lezioni in presenza, moduli online e mentorship personalizzate. L’accademia ottiene riconoscimenti per i progetti sviluppati con ONG e istituzioni europee.
                </p>
              </div>
            </div>
            <div className={styles.event}>
              <span className={styles.year}>2023</span>
              <div>
                <h3>Network europeo</h3>
                <p>
                  Apriamo collaborazioni con realtà di Berlino, Amsterdam e Barcellona, ampliando la rete di aziende e professionisti che ospitano i nostri studenti in project work e internship.
                </p>
              </div>
            </div>
          </div>
          <aside className={styles.mission}>
            <h2>Missione</h2>
            <p>
              Coltiviamo professionisti consapevoli, capaci di coniugare dati, creatività e responsabilità sociale nella progettazione di esperienze digitali. Ogni decisione formativa è orientata all’impatto e alla sostenibilità.
            </p>
            <h2>Visone</h2>
            <p>
              Costruire una community europea di talenti che condividono linguaggio, metodologie e etica per generare valore attraverso la comunicazione digitale.
            </p>
          </aside>
        </div>
      </section>

      <section className={`${styles.methodology} sectionSpacing`} aria-labelledby="method">
        <div className="container">
          <h2 id="method">Metodologia</h2>
          <div className={styles.methodGrid}>
            <article>
              <h3>Ricerca</h3>
              <p>
                Analizziamo dati, insight e trend di settore per definire ogni strategia. Gli studenti lavorano con strumenti professionali per comprendere come nascono decisioni guidate dai numeri.
              </p>
            </article>
            <article>
              <h3>Design collaborativo</h3>
              <p>
                Sprint, workshop e sessioni co-design coinvolgono docenti, partner e studenti. Ogni deliverable nasce da un processo condiviso, documentato e replicabile.
              </p>
            </article>
            <article>
              <h3>Testing continuo</h3>
              <p>
                Presentazioni, retrospettive e peer review sono parte integrante del percorso. Ogni progetto viene affinato grazie ai feedback del nostro comitato scientifico.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.values} sectionSpacing`} aria-labelledby="values">
        <div className="container">
          <h2 id="values">Valori</h2>
          <div className={styles.valuesGrid}>
            <div>
              <h3>Integrità</h3>
              <p>Operiamo con trasparenza, rispetto dei dati e attenzione alle persone per cui progettiamo esperienze digitali.</p>
            </div>
            <div>
              <h3>Curiosità</h3>
              <p>La ricerca continua alimenta ogni nostro modulo. Esploriamo tecnologie emergenti e nuovi linguaggi per restare pertinenti.</p>
            </div>
            <div>
              <h3>Collaborazione</h3>
              <p>Crediamo in ecosistemi aperti: partner, alumni e docenti costruiscono insieme opportunità e innovazione.</p>
            </div>
            <div>
              <h3>Impatto</h3>
              <p>Misuriamo risultati concreti, ricadute sociali e crescita personale di chi entra nella nostra community.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.teamIntro} sectionSpacing`} aria-labelledby="teamAbout">
        <div className="container">
          <h2 id="teamAbout">Direzione accademica</h2>
          <div className={styles.leadership}>
            <article>
              <h3>Elena Fumagalli · Co-founder e Direttrice</h3>
              <p>Stratega della comunicazione con esperienza in multinazionali lifestyle e tech. Guida l’evoluzione del curriculum e la definizione delle partnership internazionali.</p>
            </article>
            <article>
              <h3>André Lefèvre · Responsabile Innovazione</h3>
              <p>Creative technologist franco-belga, si occupa di integrare sperimentazione e tecnologie emergenti nei nostri laboratori digitali.</p>
            </article>
            <article>
              <h3>Stefania D’Ottavio · Head of Career Services</h3>
              <p>Coordina coaching, orientamento e connessioni tra studenti e aziende, accompagnando ogni talento verso percorsi professionali coerenti.</p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;