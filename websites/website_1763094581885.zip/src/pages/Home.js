```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => (
  <div className={styles.page}>
    <Helmet>
      <title>TechSolutions Inc. — Инновационные IT-решения для бизнеса</title>
      <meta
        name="description"
        content="TechSolutions Inc. помогает компаниям реализовывать цифровые стратегии, внедрять облачные решения, автоматизировать процессы и создавать устойчивые IT-системы."
      />
    </Helmet>

    <section className={`${styles.hero} container`}>
      <div className={styles.heroContent}>
        <p className={styles.preTitle}>Инновации. Надежность. Результат.</p>
        <h1 className={styles.title}>
          Цифровые решения, которые ускоряют трансформацию вашего бизнеса
        </h1>
        <p className={styles.subtitle}>
          Мы объединяем стратегию, инженерию и технологии, чтобы запускать масштабируемые продукты,
          оптимизировать процессы и обеспечивать бескомпромиссное качество на каждом этапе.
        </p>
        <div className={styles.heroActions}>
          <Link to="/contact" className={styles.primaryButton}>
            Связаться с экспертами
          </Link>
          <Link to="/services" className={styles.secondaryButton}>
            Все услуги
          </Link>
        </div>
      </div>
      <div className={styles.heroImageWrapper}>
        <img
          src="https://picsum.photos/640/480?tech"
          alt="Команда TechSolutions Inc. разрабатывает инновационные IT-решения"
          className={styles.heroImage}
        />
      </div>
    </section>

    <section className={`${styles.services} container`}>
      <h2 className={styles.sectionTitle}>Ключевые направления</h2>
      <p className={styles.sectionIntro}>
        Комплексный подход объединяет технологическую экспертизу, продуманную архитектуру и
        прозрачную коммуникацию. Мы покрываем весь цикл разработки — от стратегии до поддержки.
      </p>
      <div className={styles.cards}>
        <article className={styles.card}>
          <h3>IT-консалтинг</h3>
          <p>
            Анализ цифровой зрелости, дорожные карты трансформации, аудит архитектуры и сопровождение
            ключевых решений для устойчивого роста.
          </p>
          <Link to="/services" className={styles.cardLink}>Подробнее</Link>
        </article>
        <article className={styles.card}>
          <h3>Разработка ПО</h3>
          <p>
            Проектирование и создание адаптивных приложений, корпоративных платформ и интеграционных
            решений с упором на безопасность и масштабируемость.
          </p>
          <Link to="/services" className={styles.cardLink}>Подробнее</Link>
        </article>
        <article className={styles.card}>
          <h3>Облачные решения</h3>
          <p>
            Миграция в облако, настройка инфраструктуры, DevOps-практики и автоматизация процессов,
            обеспечивающие гибкость и скорость.
          </p>
          <Link to="/services" className={styles.cardLink}>Подробнее</Link>
        </article>
        <article className={styles.card}>
          <h3>Техническая поддержка</h3>
          <p>
            Проактивный мониторинг, SLA-обслуживание, управление инцидентами и постоянное улучшение
            производственных систем.
          </p>
          <Link to="/services" className={styles.cardLink}>Подробнее</Link>
        </article>
      </div>
    </section>

    <section className={styles.metrics}>
      <div className="container">
        <div className={styles.metricsGrid}>
          <div className={styles.metric}>
            <span className={styles.metricValue}>+120</span>
            <span className={styles.metricLabel}>успешных проектов</span>
          </div>
          <div className={styles.metric}>
            <span className={styles.metricValue}>15+</span>
            <span className={styles.metricLabel}>лет опыта команды</span>
          </div>
          <div className={styles.metric}>
            <span className={styles.metricValue}>24/7</span>
            <span className={styles.metricLabel}>экспертная поддержка</span>
          </div>
          <div className={styles.metric}>
            <span className={styles.metricValue}>98%</span>
            <span className={styles.metricLabel}>клиентов рекомендуют нас</span>
          </div>
        </div>
      </div>
    </section>

    <section className={`${styles.aboutPreview} container`}>
      <div className={styles.aboutText}>
        <h2>Инженерная культура, ориентированная на результат</h2>
        <p>
          В TechSolutions Inc. мы строим продукты и сервисы, которые выдерживают высокие нагрузки и
          меняющиеся требования. Глубокое понимание отраслей и сильная культура сотрудничества
          позволяют создавать решения, которые приносят реальную ценность.
        </p>
        <ul className={styles.list}>
          <li>Архитектура и дизайн систем уровня enterprise</li>
          <li>Прозрачные процессы и регулярная отчетность</li>
          <li>Долгосрочное партнерство и поддержка изменений</li>
        </ul>
        <Link to="/about" className={styles.moreLink}>
          Узнать больше о компании
        </Link>
      </div>
      <div className={styles.aboutImageWrapper}>
        <img
          src="https://picsum.photos/600/500?collaboration"
          alt="Партнерская работа специалистов TechSolutions Inc."
          className={styles.aboutImage}
        />
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className="container">
        <div className={styles.ctaCard}>
          <div>
            <h2>Готовы ускорить цифровое развитие?</h2>
            <p>
              Расскажите нам о своих задачах, и мы подготовим индивидуальное предложение: от
              стратегии до внедрения и поддержки.
            </p>
          </div>
          <Link to="/contact" className={styles.ctaButton}>
            Назначить консультацию
          </Link>
        </div>
      </div>
    </section>
  </div>
);

export default Home;
```