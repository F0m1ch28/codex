```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={`container ${styles.page}`}>
    <Helmet>
      <title>Политика использования cookies — TechSolutions Inc.</title>
      <meta
        name="description"
        content="Политика использования cookies TechSolutions Inc. Описывает типы файлов cookie и настройки пользователя."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Политика использования cookies</h1>
      <p className={styles.lead}>
        Мы используем cookies, чтобы сделать работу сайта удобнее, собирать аналитику и адаптировать
        материалы под интересы пользователей.
      </p>
    </header>

    <section className={styles.section}>
      <h2>1. Что такое cookies</h2>
      <p>
        Cookies — это небольшие текстовые файлы, которые сохраняются на вашем устройстве, когда вы
        посещаете сайт. Они позволяют запоминать ваши предпочтения и улучшать пользовательский опыт.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Какие cookies мы используем</h2>
      <ul>
        <li>Обязательные — необходимы для корректной работы сайта.</li>
        <li>Функциональные — запоминают ваши настройки и предпочтения.</li>
        <li>Аналитические — помогают понимать, как пользователи используют сайт.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>3. Управление cookies</h2>
      <p>
        Вы можете настроить использование cookies в настройках браузера. Учтите, что отключение
        обязательных cookies может ограничить функциональность сайта.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Обновления</h2>
      <p>
        Мы можем периодически обновлять политику cookies. Изменения будут опубликованы на этой
        странице.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Контакты</h2>
      <p>
        Вопросы по использованию cookies направляйте на{' '}
        <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
      </p>
    </section>
  </div>
);

export default CookiePolicy;
```