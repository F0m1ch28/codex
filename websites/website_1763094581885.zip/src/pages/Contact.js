```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите имя.';
    } else if (formData.name.trim().length < 2) {
      newErrors.name = 'Имя должно содержать не менее 2 символов.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Укажите рабочий email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Введите корректный email.';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите кратко о задаче.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Сообщение должно содержать не менее 10 символов.';
    }

    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }

    setIsSubmitting(true);
    setStatus('loading');

    setTimeout(() => {
      setIsSubmitting(false);
      setStatus('success');
      setFormData(initialState);
    }, 1500);
  };

  return (
    <div className={`container ${styles.page}`}>
      <Helmet>
        <title>Контакты TechSolutions Inc. — Свяжитесь с нами</title>
        <meta
          name="description"
          content="Свяжитесь с TechSolutions Inc. по адресу 123 Innovation Street, Tech City, TC 10101. Заполните форму, напишите на info@techsolutions.com или позвоните +1 (555) 123-4567."
        />
      </Helmet>

      <header className={styles.header}>
        <p className={styles.preTitle}>Контакты</p>
        <h1>Давайте обсудим ваш проект</h1>
        <p className={styles.lead}>
          Оставьте заявку, и команда TechSolutions Inc. свяжется с вами, чтобы подробно обсудить
          задачи, сроки и возможные подходы к реализации.
        </p>
      </header>

      <section className={styles.content}>
        <div className={styles.formWrapper}>
          <h2>Напишите нам</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Имя *</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Как к вам обращаться?"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
                required
              />
              {errors.name && (
                <p className={styles.error} id="name-error">
                  {errors.name}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Email *</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="name@company.com"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
                required
              />
              {errors.email && (
                <p className={styles.error} id="email-error">
                  {errors.email}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="company">Компания</label>
              <input
                id="company"
                name="company"
                type="text"
                placeholder="Название компании"
                value={formData.company}
                onChange={handleChange}
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Сообщение *</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Опишите задачу, текущие вызовы или желаемый результат"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
                required
              />
              {errors.message && (
                <p className={styles.error} id="message-error">
                  {errors.message}
                </p>
              )}
            </div>

            <button type="submit" disabled={isSubmitting} className={styles.submitButton}>
              {isSubmitting ? 'Отправка...' : 'Отправить сообщение'}
            </button>

            {status === 'success' && (
              <p className={styles.success}>
                Спасибо! Мы получили ваше сообщение и свяжемся с вами в ближайшее время.
              </p>
            )}
          </form>
        </div>

        <div className={styles.infoWrapper}>
          <div className={styles.infoCard}>
            <h2>Контактная информация</h2>
            <ul className={styles.infoList}>
              <li>
                <span>Адрес</span>
                <p>123 Innovation Street, Tech City, TC 10101</p>
              </li>
              <li>
                <span>Телефон</span>
                <p><a href="tel:+15551234567">+1 (555) 123-4567</a></p>
              </li>
              <li>
                <span>Email</span>
                <p><a href="mailto:info@techsolutions.com">info@techsolutions.com</a></p>
              </li>
              <li>
                <span>Режим работы</span>
                <p>Понедельник — Пятница, 09:00–18:00</p>
              </li>
            </ul>
          </div>

          <div className={styles.mapWrapper}>
            <iframe
              title="Офис TechSolutions Inc."
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345093736!2d144.9537363153602!3d-37.81627974201139!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzfCsDQ5JzAwLjYiUyAxNDTCsDU3JzE0LjAiRQ!5e0!3m2!1sru!2s!4v1633072800000!5m2!1sru!2s"
              loading="lazy"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```