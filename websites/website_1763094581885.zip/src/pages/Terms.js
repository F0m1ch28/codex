```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <div className={`container ${styles.page}`}>
    <Helmet>
      <title>Условия использования — TechSolutions Inc.</title>
      <meta
        name="description"
        content="Условия использования сайта TechSolutions Inc. Определяют правила доступа, ответственность и ограничения."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Условия использования</h1>
      <p className={styles.lead}>
        Пожалуйста, внимательно ознакомьтесь с условиями перед использованием сайта и сервисов
        TechSolutions Inc.
      </p>
    </header>

    <section className={styles.section}>
      <h2>1. Общие положения</h2>
      <p>
        Используя наш сайт, вы соглашаетесь с условиями, изложенными в данном документе. Если вы не
        согласны с условиями, пожалуйста, воздержитесь от использования сайта.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Использование материалов</h2>
      <p>
        Материалы сайта предоставляются для информационных целей. Запрещено использовать контент без
        согласия TechSolutions Inc. или нарушать авторские и смежные права.
      </p>
    </section>

    <section className={styles.section}>
      <h2>3. Ограничение ответственности</h2>
      <p>
        Мы стремимся к актуальности и точности информации, однако не гарантируем отсутствия ошибок.
        TechSolutions Inc. не несет ответственности за прямые или косвенные убытки, возникшие вследствие
        использования сайта.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Изменения условий</h2>
      <p>
        Компания оставляет за собой право изменять условия без предварительного уведомления.
        Актуальная версия всегда доступна на этой странице.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Контакты</h2>
      <p>
        Вопросы по условиям использования направляйте на email:{' '}
        <a href="mailto:info@techsolutions.com">info@techsolutions.com</a> или по телефону{' '}
        <a href="tel:+15551234567">+1 (555) 123-4567</a>.
      </p>
    </section>
  </div>
);

export default Terms;
```