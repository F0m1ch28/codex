```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <div className={`container ${styles.page}`}>
    <Helmet>
      <title>О компании TechSolutions Inc. — История, миссия, команда</title>
      <meta
        name="description"
        content="Узнайте больше о TechSolutions Inc.: история компании, миссия, ценности и команда экспертов, объединяющих стратегию, разработку и поддержку."
      />
    </Helmet>

    <header className={styles.header}>
      <p className={styles.preTitle}>О нас</p>
      <h1>TechSolutions Inc. — технологический партнер роста</h1>
      <p className={styles.lead}>
        С 2009 года мы помогаем компаниям внедрять инновации, оптимизировать процессы и создавать
        продукты, которыми гордятся команды и пользователи.
      </p>
    </header>

    <section className={styles.history}>
      <div className={styles.historyText}>
        <h2>История и путь развития</h2>
        <p>
          TechSolutions Inc. начиналась как небольшая группа энтузиастов, объединенных идеей
          создания технологически сильных продуктов. За годы мы выросли в международную команду,
          реализовавшую проекты в финансовом, промышленном, телекоммуникационном и государственном
          секторах.
        </p>
        <p>
          Развивая экспертизу, мы инвестировали в инженерную культуру, стандарты качества и
          партнерские отношения с ведущими технологическими вендорами. Сегодня мы продолжаем строить
          решения, которые становятся ядром цифровой экосистемы наших клиентов.
        </p>
      </div>
      <div className={styles.historyImageWrapper}>
        <img
          src="https://picsum.photos/680/520?teamwork"
          alt="Специалисты TechSolutions Inc. обсуждают стратегию проекта"
          className={styles.historyImage}
        />
      </div>
    </section>

    <section className={styles.missionSection}>
      <div className={styles.missionCard}>
        <h2>Миссия и подход</h2>
        <p>
          Наша миссия — создавать технологические решения, которые помогают бизнесу расти быстрее и
          безопаснее. Мы уделяем внимание каждой детали: от архитектуры до пользовательского опыта,
          от процессов до культуры взаимодействия.
        </p>
        <ul>
          <li>Ответственность за результат и долгосрочный эффект</li>
          <li>Прозрачное партнерство и доверие в коммуникации</li>
          <li>Непрерывное развитие команды и обмен опытом</li>
        </ul>
      </div>
    </section>

    <section className={styles.teamSection}>
      <h2>Команда экспертов</h2>
      <p className={styles.teamIntro}>
        В ядре TechSolutions Inc. — специалисты по архитектуре, DevOps, анализу данных, кибербезопасности
        и управлению продуктом. Мы ценим экспертизу, обмен знаниями и стремление к совершенству.
      </p>
      <div className={styles.teamGrid}>
        <article className={styles.teamCard}>
          <img
            src="https://picsum.photos/300/300?face1"
            alt="Анна Смирнова — директор по стратегии TechSolutions Inc."
          />
          <h3>Анна Смирнова</h3>
          <p className={styles.position}>Директор по стратегии</p>
          <p>
            Курирует стратегические проекты и помогает клиентам выстраивать дорожные карты цифровой
            трансформации.
          </p>
        </article>
        <article className={styles.teamCard}>
          <img
            src="https://picsum.photos/300/300?face2"
            alt="Марк Джонсон — технический директор TechSolutions Inc."
          />
          <h3>Марк Джонсон</h3>
          <p className={styles.position}>Технический директор</p>
          <p>
            Отвечает за инженерные стандарты, архитектуру решений и культуру непрерывного улучшения.
          </p>
        </article>
        <article className={styles.teamCard}>
          <img
            src="https://picsum.photos/300/300?face3"
            alt="Елена Чжан — директор по работе с клиентами TechSolutions Inc."
          />
          <h3>Елена Чжан</h3>
          <p className={styles.position}>Директор по работе с клиентами</p>
          <p>
            Обеспечивает высокий уровень сервиса и коммуникации, управляет ожиданиями и успехом проектов.
          </p>
        </article>
      </div>
    </section>
  </div>
);

export default About;
```