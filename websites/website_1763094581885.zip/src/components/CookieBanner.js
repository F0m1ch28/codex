```javascript
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('ts_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('ts_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Мы используем cookies для улучшения качества сервиса и аналитики. Подробнее в{' '}
        <Link to="/cookie-policy">политике cookies</Link>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;
```