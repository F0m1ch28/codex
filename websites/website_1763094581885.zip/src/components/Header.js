```javascript
import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const handleClose = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={`${styles.inner} container`}>
        <Link to="/" className={styles.logo} onClick={handleClose}>
          <span className={styles.logoAccent}>Tech</span>Solutions Inc.
        </Link>

        <button
          className={styles.burger}
          aria-label="Открыть основное меню"
          aria-expanded={isMenuOpen}
          onClick={handleToggle}
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`}>
          <ul className={styles.navList}>
            <li>
              <NavLink
                to="/"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
                onClick={handleClose}
              >
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/services"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
                onClick={handleClose}
              >
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/about"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
                onClick={handleClose}
              >
                О компании
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/contact"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
                onClick={handleClose}
              >
                Контакты
              </NavLink>
            </li>
          </ul>
          <Link to="/contact" className={styles.cta} onClick={handleClose}>
            Обсудить проект
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;
```