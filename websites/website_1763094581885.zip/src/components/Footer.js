```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.grid}`}>
      <div>
        <h3 className={styles.logo}>
          <span className={styles.logoAccent}>Tech</span>Solutions Inc.
        </h3>
        <p className={styles.text}>
          Мы создаем цифровые решения, которые ускоряют рост, повышают устойчивость
          и помогают нашим клиентам уверенно двигаться в будущее.
        </p>
        <p className={styles.copy}>&copy; {new Date().getFullYear()} TechSolutions Inc. Все права защищены.</p>
      </div>

      <div>
        <h4 className={styles.heading}>Контакты</h4>
        <ul className={styles.list}>
          <li>Адрес: 123 Innovation Street, Tech City, TC 10101</li>
          <li>Телефон: <a href="tel:+15551234567">+1 (555) 123-4567</a></li>
          <li>Email: <a href="mailto:info@techsolutions.com">info@techsolutions.com</a></li>
          <li>Режим работы: Пн–Пт, 09:00–18:00</li>
        </ul>
      </div>

      <div>
        <h4 className={styles.heading}>Навигация</h4>
        <ul className={styles.links}>
          <li><Link to="/">Главная</Link></li>
          <li><Link to="/services">Услуги</Link></li>
          <li><Link to="/about">О компании</Link></li>
          <li><Link to="/contact">Контакты</Link></li>
          <li><Link to="/privacy">Политика конфиденциальности</Link></li>
          <li><Link to="/terms">Условия использования</Link></li>
          <li><Link to="/cookie-policy">Политика Cookies</Link></li>
        </ul>
      </div>
    </div>
  </footer>
);

export default Footer;
```