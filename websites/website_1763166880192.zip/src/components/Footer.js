import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <div className={styles.logoWrap}>
            <span className={styles.logoMark}>TS</span>
            <span className={styles.logoText}>TechSolutions Inc.</span>
          </div>
          <p className={styles.tagline}>
            Partnering with forward-thinking organizations to architect resilient cloud ecosystems and seamless digital experiences.
          </p>
        </div>

        <div className={styles.column}>
          <h4>Navigation</h4>
          <ul className={styles.links}>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Compliance</h4>
          <ul className={styles.links}>
            <li><Link to="/privacy">Privacy Policy</Link></li>
            <li><Link to="/terms">Terms of Use</Link></li>
            <li><Link to="/cookie-policy">Cookie Policy</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Contact</h4>
          <ul className={styles.contacts}>
            <li>123 Innovation Drive, Tech Park,<br />San Francisco, CA 94105</li>
            <li><a href="tel:+15551234567">+1 (555) 123-4567</a></li>
            <li><a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a></li>
          </ul>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} TechSolutions Inc. All rights reserved.</p>
      </div>
    </div>
  </footer>
);

export default Footer;