import React from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'techsolutions-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive">
      <div className={styles.content}>
        <p>
          We use cookies to enhance your experience, analyze traffic, and optimize our digital services. By continuing, you agree to our cookie policy.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={acceptCookies}>
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;