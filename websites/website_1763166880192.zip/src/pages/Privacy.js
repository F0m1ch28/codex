import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Understand how TechSolutions Inc. collects, uses, and safeguards personal information."
      />
    </Helmet>

    <section className={styles.page}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p className={styles.updated}>Effective date: January 5, 2024</p>

        <h2>Information We Collect</h2>
        <p>
          We collect contact details and business information voluntarily provided through inquiry forms, email communication, or event registration. We may also gather usage analytics to improve site performance and content relevance.
        </p>

        <h2>How We Use Information</h2>
        <p>
          Information is used to respond to inquiries, deliver professional services, manage client relationships, and personalize digital experiences. We do not sell personal data to third parties.
        </p>

        <h2>Data Security</h2>
        <p>
          TechSolutions Inc. employs administrative, technical, and physical safeguards to protect information. While we strive to maintain robust security, no transmission method is completely secure.
        </p>

        <h2>Your Rights</h2>
        <p>
          You may request access, correction, or deletion of your personal information by contacting us at info@techsolutions-inc.com. We will respond in accordance with applicable regulations.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this Privacy Policy periodically. Material changes will be posted on this page with an updated effective date.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;