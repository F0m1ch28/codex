import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>About Us | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Learn about TechSolutions Inc., our mission, leadership team, and commitment to driving cloud-enabled transformation."
      />
      <meta
        name="keywords"
        content="TechSolutions Inc team, mission, cloud transformation experts"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Guiding Enterprises Through Complex Digital Journeys</h1>
        <p>
          TechSolutions Inc. is an independent IT consulting firm headquartered in San Francisco. We exist to help organizations reimagine their technology foundations, align teams around shared goals, and deliver differentiated experiences in the cloud era.
        </p>
      </div>
    </section>

    <section className={styles.mission}>
      <div className="container">
        <div className={styles.missionGrid}>
          <div>
            <h2>Our Mission</h2>
            <p>
              Enable visionary leaders to embrace cloud-native capabilities with confidence, so they can accelerate innovation, enhance resilience, and craft digitally empowered futures. We bridge the gap between strategy and execution with pragmatic guidance and hands-on expertise.
            </p>
          </div>
          <div className={styles.values}>
            <h2>Values We Live By</h2>
            <ul>
              <li><span>Integrity:</span> Independent advice rooted in transparency, accountability, and trust.</li>
              <li><span>Curiosity:</span> Relentless pursuit of emerging practices and technologies that deliver value.</li>
              <li><span>Co-creation:</span> Collaboration with clients to transfer knowledge and build lasting capabilities.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <h2>Leadership Team</h2>
        <p>
          Our multidisciplinary experts have led global transformation initiatives across financial services, healthcare, retail, and high-tech industries.
        </p>
        <div className={styles.teamGrid}>
          <article className={styles.member}>
            <img
              src="https://picsum.photos/300/320"
              alt="Portrait of Emma Collins, CEO of TechSolutions Inc."
            />
            <h3>Emma Collins</h3>
            <span>Chief Executive Officer</span>
            <p>
              Emma brings 18 years of experience orchestrating enterprise cloud transformations, with a focus on creating resilient operating models and cultivating high-performing cultures.
            </p>
          </article>
          <article className={styles.member}>
            <img
              src="https://picsum.photos/301/320"
              alt="Portrait of David Nguyen, CTO of TechSolutions Inc."
            />
            <h3>David Nguyen</h3>
            <span>Chief Technology Officer</span>
            <p>
              David is a cloud architect and automation leader who has delivered large-scale modernization programs and platform engineering strategies across global enterprises.
            </p>
          </article>
          <article className={styles.member}>
            <img
              src="https://picsum.photos/302/320"
              alt="Portrait of Priya Desai, Head of Consulting"
            />
            <h3>Priya Desai</h3>
            <span>Head of Consulting</span>
            <p>
              Priya leads our consulting practice, ensuring engagements are aligned to strategic outcomes while embedding governance, measurement, and change enablement.
            </p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default About;