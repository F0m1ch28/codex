import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => (
  <>
    <Helmet>
      <title>TechSolutions Inc. | Cloud Consulting & Digital Transformation</title>
      <meta
        name="description"
        content="TechSolutions Inc. drives digital transformation with cloud-first strategies, modern architectures, and intelligent automation."
      />
      <meta
        name="keywords"
        content="cloud consulting, digital transformation, IT strategy, TechSolutions Inc."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroGrid}>
          <div className={styles.heroContent}>
            <span className={styles.badge}>Cloud-native excellence</span>
            <h1>
              Architecting Future-Ready Digital Platforms for Visionary Enterprises
            </h1>
            <p>
              TechSolutions Inc. accelerates innovation by orchestrating secure cloud foundations, modernizing critical workloads, and empowering teams with intelligent digital capabilities.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className={styles.primaryAction}>
                Schedule a Consultation
              </Link>
              <Link to="/services" className={styles.secondaryAction}>
                Explore Services
              </Link>
            </div>
            <div className={styles.statsRow}>
              <div>
                <h3>250+</h3>
                <p>Successful cloud migrations and modernization programs.</p>
              </div>
              <div>
                <h3>98%</h3>
                <p>Client satisfaction across multi-year transformation initiatives.</p>
              </div>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/640/520?grayscale"
              alt="Engineers collaborating on cloud strategy"
            />
            <div className={styles.heroCard}>
              <p>“TechSolutions transformed our digital operations with a resilient hybrid cloud framework.”</p>
              <span>VP Technology, Global Retail Brand</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.servicesPreview}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Strategic Services That Propel Digital Momentum</h2>
          <p>
            From discovery to scaled delivery, we align cloud capabilities with business priorities to unlock measurable outcomes.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          <article className={styles.card}>
            <div className={styles.icon}>☁️</div>
            <h3>Cloud Architecture &amp; Engineering</h3>
            <p>
              Design adaptable, secure, and automated cloud environments spanning public, private, and hybrid ecosystems.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Learn more
            </Link>
          </article>
          <article className={styles.card}>
            <div className={styles.icon}>⚙️</div>
            <h3>Application Modernization</h3>
            <p>
              Re-platform legacy systems, implement microservices, and embed DevSecOps to accelerate product delivery.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Learn more
            </Link>
          </article>
          <article className={styles.card}>
            <div className={styles.icon}>📊</div>
            <h3>Data &amp; Intelligent Automation</h3>
            <p>
              Activate data pipelines, analytics, and automation to fuel insight-driven decision making across the enterprise.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Learn more
            </Link>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.transform}>
      <div className="container">
        <div className={styles.transformGrid}>
          <div className={styles.transformImage}>
            <img
              src="https://picsum.photos/560/420"
              alt="Digital transformation roadmap planning"
            />
          </div>
          <div className={styles.transformContent}>
            <h2>Transformation with Clarity, Speed, and Governance</h2>
            <p>
              We partner deeply with business and technology leaders to co-create transformation roadmaps, establish agile governance models, and activate agile operating frameworks that sustain value delivery.
            </p>
            <ul className={styles.transformList}>
              <li>Cloud operating model design and change enablement</li>
              <li>Security, compliance, and FinOps integration from day one</li>
              <li>Embedded coaching to upskill engineering and product teams</li>
            </ul>
            <Link to="/about" className={styles.inlineLink}>
              Discover our approach →
            </Link>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.insights}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Why Leaders Choose TechSolutions Inc.</h2>
        </div>
        <div className={styles.highlightsGrid}>
          <div className={styles.highlight}>
            <h3>Holistic Transformation</h3>
            <p>
              We harmonize strategy, technology, and culture to deliver scalable digital ecosystems that withstand rapid change.
            </p>
          </div>
          <div className={styles.highlight}>
            <h3>Certified Cloud Specialists</h3>
            <p>
              Cross-functional experts certified across AWS, Azure, and Google Cloud ensure vendor-agnostic solutions tailored to your context.
            </p>
          </div>
          <div className={styles.highlight}>
            <h3>Outcome-Focused Engagements</h3>
            <p>
              Every initiative is guided by quantifiable KPIs, iterative checkpoints, and transparent communication frameworks.
            </p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Home;