import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Learn how TechSolutions Inc. uses cookies to enhance website performance and user experience."
      />
    </Helmet>

    <section className={styles.page}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p className={styles.updated}>Effective date: January 5, 2024</p>

        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a website. They help us remember preferences, measure site performance, and deliver relevant content.
        </p>

        <h2>Types of Cookies We Use</h2>
        <ul>
          <li><strong>Essential:</strong> Required for core site functionality and security.</li>
          <li><strong>Analytics:</strong> Help us understand site usage patterns and optimize content.</li>
          <li><strong>Functional:</strong> Remember your preferences to enhance usability.</li>
        </ul>

        <h2>Managing Cookies</h2>
        <p>
          You can control cookies at the browser level and adjust settings to accept, reject, or delete cookies. Note that disabling certain cookies may impact site functionality.
        </p>

        <h2>Contact</h2>
        <p>
          For questions about our cookie practices, contact us at info@techsolutions-inc.com.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;