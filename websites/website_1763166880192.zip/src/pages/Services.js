import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Services | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Detailed overview of TechSolutions Inc. services, including cloud strategy, modernization, and intelligent automation."
      />
      <meta
        name="keywords"
        content="cloud architecture, digital transformation services, application modernization, automation"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Consulting Services Engineered for Sustainable Transformation</h1>
        <p>
          We combine deep technical expertise with a pragmatic delivery mindset to guide enterprises through every stage of cloud adoption and digital modernization.
        </p>
      </div>
    </section>

    <section className={styles.servicesList}>
      <div className="container">
        <div className={styles.serviceCard}>
          <h2>Cloud Strategy &amp; Operating Model</h2>
          <p>
            Align cloud adoption with corporate objectives through targeted assessments, business case development, and operating model blueprints. We build cloud centers of excellence, define governance structures, and enable decision frameworks that accelerate adoption while managing risk.
          </p>
          <ul>
            <li>Enterprise cloud roadmap and value realization planning</li>
            <li>Cloud governance, FinOps, and compliance frameworks</li>
            <li>Organizational change management and capability building</li>
          </ul>
        </div>

        <div className={styles.serviceCard}>
          <h2>Cloud Architecture &amp; Engineering</h2>
          <p>
            Architect resilient, scalable, and secure cloud environments tailored to workload requirements. Our architects design landing zones, automation pipelines, and secure connectivity patterns that streamline deployment, operations, and observability across cloud providers.
          </p>
          <ul>
            <li>Landing zone design for AWS, Azure, and Google Cloud</li>
            <li>Infrastructure as Code, CI/CD, and platform automation</li>
            <li>Security, identity, and zero-trust frameworks</li>
          </ul>
        </div>

        <div className={styles.serviceCard}>
          <h2>Application Modernization &amp; Product Delivery</h2>
          <p>
            Re-architect critical applications using microservices, containers, and serverless to enhance reliability and speed. We embed DevSecOps practices, implement automated testing, and establish product-centric delivery models that elevate customer experiences.
          </p>
          <ul>
            <li>Legacy modernization and re-platforming strategies</li>
            <li>Cloud-native application engineering and acceleration</li>
            <li>Agile product governance and value stream improvements</li>
          </ul>
        </div>

        <div className={styles.serviceCard}>
          <h2>Data Platforms &amp; Intelligent Automation</h2>
          <p>
            Unlock data value with modern data platforms, analytics, and automation. We design data ingestion, governance, and visualization capabilities while integrating intelligent automation to streamline operations and enhance decision-making.
          </p>
          <ul>
            <li>Data lakehouse, warehouse, and analytics platform design</li>
            <li>AI-driven insights, ML model operationalization</li>
            <li>Process automation with low-code and RPA solutions</li>
          </ul>
        </div>

        <div className={styles.serviceCard}>
          <h2>Managed Transformation Office</h2>
          <p>
            Provide ongoing stewardship to ensure transformation programs sustain momentum. Our managed services include performance dashboards, KPI governance, risk mitigation, and continuous improvement practices that keep initiatives aligned with strategic outcomes.
          </p>
          <ul>
            <li>Program leadership and stakeholder alignment</li>
            <li>Benefit tracking, metrics, and executive reporting</li>
            <li>Continuous optimization and operating model refinement</li>
          </ul>
        </div>
      </div>
    </section>
  </>
);

export default Services;