import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.message.trim()) newErrors.message = 'Please share a brief overview of your needs.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
    setSubmitted(false);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Contact | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Connect with TechSolutions Inc. to discuss cloud strategy, modernization, and digital transformation initiatives."
        />
        <meta
          name="keywords"
          content="contact TechSolutions, cloud consulting contact, digital transformation experts"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Let’s Build What’s Next</h1>
          <p>
            Share your objectives and we will align the right experts to co-create your transformation roadmap. We typically respond within two business days.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formCard}>
              <h2>Tell us about your initiative</h2>
              <form onSubmit={handleSubmit} noValidate>
                <div className={styles.field}>
                  <label htmlFor="name">Full Name *</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Alex Johnson"
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                  />
                  {errors.name && <span id="name-error">{errors.name}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="email">Work Email *</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="alex.johnson@company.com"
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                  />
                  {errors.email && <span id="email-error">{errors.email}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="company">Company</label>
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="Your organization"
                  />
                </div>

                <div className={styles.field}>
                  <label htmlFor="message">Project Context *</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Describe your current objectives, timelines, and success criteria."
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                  />
                  {errors.message && <span id="message-error">{errors.message}</span>}
                </div>

                <button type="submit">Submit Inquiry</button>
                {submitted && (
                  <p className={styles.success}>
                    Thank you for reaching out. Our consulting team will connect with you shortly.
                  </p>
                )}
              </form>
            </div>

            <div className={styles.infoCard}>
              <div className={styles.contactBlock}>
                <h3>Contact Details</h3>
                <p>
                  123 Innovation Drive, Tech Park<br />
                  San Francisco, CA 94105
                </p>
                <a href="tel:+15551234567">+1 (555) 123-4567</a>
                <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>
              </div>
              <div className={styles.contactBlock}>
                <h3>Engagement Hours</h3>
                <p>Monday – Friday, 8:30 AM – 6:00 PM PT</p>
              </div>
              <div className={styles.mapWrapper}>
                <iframe
                  title="TechSolutions Inc. office location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.0636017502826!2d-122.39251552340814!3d37.78940161343805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064f4d9245b%3A0xa7e5bf4f2dc6c0b7!2s123%20Innovation%20Dr%2C%20San%20Francisco%2C%20CA%2094105%2C%20USA!5e0!3m2!1sen!2sus!4v1700000000000!5m2!1sen!2sus"
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;