import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Review the terms of use for TechSolutions Inc. digital properties and consulting information."
      />
    </Helmet>

    <section className={styles.page}>
      <div className="container">
        <h1>Terms of Use</h1>
        <p className={styles.updated}>Last updated: January 5, 2024</p>

        <h2>1. Acceptance</h2>
        <p>
          By accessing or using the TechSolutions Inc. website, you agree to these Terms of Use and all applicable laws and regulations. If you do not agree, please discontinue use of our digital properties.
        </p>

        <h2>2. Intellectual Property</h2>
        <p>
          All content, branding, and materials on this site are owned by TechSolutions Inc. or our licensors and may not be copied, reproduced, or redistributed without prior written consent.
        </p>

        <h2>3. Professional Services</h2>
        <p>
          Information presented on this site is for informational purposes only and does not constitute a binding consulting offer. Engagement terms are governed by separate written agreements between TechSolutions Inc. and its clients.
        </p>

        <h2>4. Limitation of Liability</h2>
        <p>
          TechSolutions Inc. will not be liable for any indirect, incidental, or consequential damages resulting from the use or inability to use our website or reliance on any information presented herein.
        </p>

        <h2>5. Governing Law</h2>
        <p>
          These terms are governed by the laws of the State of California, without regard to conflict of law principles.
        </p>
      </div>
    </section>
  </>
);

export default Terms;