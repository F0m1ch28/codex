document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  const navLinks = document.querySelectorAll(".nav-menu a");

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = mainNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    navLinks.forEach((link) =>
      link.addEventListener("click", () => {
        mainNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      })
    );
  }

  document.querySelectorAll("[data-progress]").forEach((bar) => {
    const value = Math.min(parseInt(bar.dataset.progress, 10) || 0, 100);
    const fill = bar.querySelector(".metric-bar__fill");
    if (fill) {
      requestAnimationFrame(() => {
        fill.style.setProperty("--progress", `${value}%`);
      });
    }
  });

  document.querySelectorAll("[data-gauge]").forEach((gauge) => {
    const value = Math.min(parseInt(gauge.dataset.gauge, 10) || 0, 100);
    gauge.style.setProperty("--gauge", value * 3.6);
    const span = gauge.querySelector("span");
    if (span) {
      span.textContent = `${value}%`;
    }
  });

  const toggleButtons = document.querySelectorAll("[data-dashboard-toggle]");
  toggleButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const group = button.closest(".dashboard-card");
      if (!group) return;

      group
        .querySelectorAll("[data-dashboard-toggle]")
        .forEach((btn) => btn.classList.remove("is-active"));
      button.classList.add("is-active");

      const target = button.dataset.dashboardToggle;
      const scoreBlock = group.querySelector(".dashboard-score");
      if (scoreBlock && target) {
        const dataset = JSON.parse(button.dataset.dashboardPayload || "{}");
        scoreBlock.querySelector(".dashboard-score__label").textContent = dataset.label || "";
        scoreBlock.querySelector(".dashboard-score__value").textContent = dataset.value || "";
        scoreBlock.querySelector(".dashboard-score__hint").textContent = dataset.hint || "";
      }
    });
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const COOKIE_KEY = "cms_cookie_consent";

  const storedConsent = localStorage.getItem(COOKIE_KEY);
  if (!storedConsent && cookieBanner) {
    setTimeout(() => cookieBanner.classList.add("is-visible"), 600);
  }

  const handleConsent = (value) => {
    localStorage.setItem(COOKIE_KEY, value);
    cookieBanner?.classList.remove("is-visible");
  };

  acceptBtn?.addEventListener("click", () => handleConsent("accepted"));
  declineBtn?.addEventListener("click", () => handleConsent("declined"));
});