import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Portfolio.module.css";

const projects = [
  {
    title: "Digital Bank Experience",
    description: "Комплексный редизайн мобильного и веб-банкинга для финтех-бренда с фокусом на удобстве клиентов.",
    image: "https://picsum.photos/600/420?random=11",
  },
  {
    title: "Lifestyle E-commerce",
    description: "Творческая витрина для бренда одежды с акцентом на storytelling и интерактивные коллекции.",
    image: "https://picsum.photos/600/420?random=12",
  },
  {
    title: "AI SaaS Platform",
    description: "Информационная архитектура и дизайн-система для B2B платформы искусственного интеллекта.",
    image: "https://picsum.photos/600/420?random=13",
  },
  {
    title: "Wellness App",
    description: "Мобильное приложение для mindful-практик с нейтральной цветовой палитрой и мягкой анимацией.",
    image: "https://picsum.photos/600/420?random=14",
  },
  {
    title: "EdTech Hub",
    description: "UX-оптимизация платформы онлайн-курсов, улучшение навигации и прогресс-трекинга.",
    image: "https://picsum.photos/600/420?random=15",
  },
  {
    title: "Corporate Rebranding",
    description: "Обновление визуальной идентичности международной консалтинговой компании.",
    image: "https://picsum.photos/600/420?random=16",
  },
];

const Portfolio = () => {
  return (
    <>
      <Helmet>
        <title>Портфолио ArtVision Studio — избранные проекты</title>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Портфолио проектов</h1>
          <p>
            Мы создаем решения, которые помогают бизнесу говорить на языке своих пользователей. Каждый проект — баланс
            визуальной выразительности и стратегической задачи.
          </p>
        </div>
      </section>

      <section className={styles.gallerySection}>
        <div className="container">
          <div className={styles.galleryGrid}>
            {projects.map((project) => (
              <article key={project.title} className={styles.card}>
                <div className={styles.imageWrap}>
                  <img src={project.image} alt={`Проект ArtVision Studio: ${project.title}`} />
                </div>
                <div className={styles.cardBody}>
                  <h2>{project.title}</h2>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Portfolio;