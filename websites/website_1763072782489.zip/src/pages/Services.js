import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const Services = () => {
  const services = [
    {
      title: "Исследования и стратегия",
      description:
        "Анализируем аудиторию, проводим воркшопы, формируем позиционирование и стратегию продукта, чтобы дизайн был точным и релевантным.",
      bullets: ["Интервью и UX-исследования", "Customer Journey Map", "Дизайн-стратегия"],
    },
    {
      title: "UI/UX дизайн",
      description:
        "Проектируем удобный пользовательский путь, создаем wireframes и прототипы, разрабатываем дизайн-системы и библиотеки компонентов.",
      bullets: ["Прототипирование", "Дизайн-системы", "Адаптивный UI"],
    },
    {
      title: "Брендинг и айдентика",
      description:
        "Разрабатываем визуальный стиль бренда, создаем логотипы, гайды по айдентике, расширяем брендовую экосистему.",
      bullets: ["Нейминг и платформа бренда", "Логотип и фирменный стиль", "Брендбук"],
    },
    {
      title: "Дизайн сопровождение",
      description:
        "Поддерживаем продукты после релиза, проводим регулярные улучшения, работаем с командами разработки и маркетинга.",
      bullets: ["Дизайн-менторинг", "АРТ-дирекшн", "Обновление дизайн-систем"],
    },
  ];

  return (
    <>
      <Helmet>
        <title>Услуги ArtVision Studio — веб-дизайн, брендинг, UI/UX</title>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <p className={styles.kicker}>Полный спектр услуг</p>
          <h1>Комплексный дизайн для сильных брендов</h1>
          <p className={styles.description}>
            Мы берем на себя весь цикл: от аналитики и стратегии до визуальной реализации и сопровождения. Команда ArtVision Studio работает гибко, прозрачно и с высокой степенью вовлеченности.
          </p>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.bullets.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.highlightSection}>
        <div className="container">
          <div className={styles.highlightCard}>
            <h2>Команда, которая становится частью вашего продукта</h2>
            <p>
              Мы строим партнерские отношения и фокусируемся на измеримых результатах. Регулярные синки, прозрачные процессы и креативная энергия — ключевые элементы нашего подхода.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;