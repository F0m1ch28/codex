import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const Home = () => {
  const highlightStats = [
    { label: "Проектов реализовано", value: "120+" },
    { label: "Лет в индустрии", value: "8" },
    { label: "Клиентов по всему миру", value: "60+" },
  ];

  const servicePreview = [
    {
      title: "Дизайн цифровых продуктов",
      description: "Создаем масштабируемые пользовательские интерфейсы, объединяющие эстетику и функциональность.",
      icon: "🎨",
    },
    {
      title: "Стратегический брендинг",
      description: "Помогаем брендам звучать громко: от платформы бренда до визуальной идентичности.",
      icon: "✨",
    },
    {
      title: "Опыт пользователя",
      description: "Проводим исследования, строим CJM и прототипируем решения, которые любят пользователи.",
      icon: "🧭",
    },
  ];

  const process = [
    {
      title: "Погружение в задачу",
      description: "Изучаем бизнес-контекст, аудиторию и цели, чтобы сформировать четкую стратегию дизайна.",
    },
    {
      title: "Творческая разработка",
      description: "Создаем концепции, визуальные референсы, прототипы и тестируем гипотезы.",
    },
    {
      title: "Запуск и сопровождение",
      description: "Передаем дизайн-команды, готовим гайды и сопровождаем внедрение без потери качества.",
    },
  ];

  return (
    <>
      <Helmet>
        <title>ArtVision Studio — Современная дизайн-студия</title>
      </Helmet>
      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <p className={styles.kicker}>Студия цифрового дизайна</p>
            <h1 className={styles.title}>
              Создаем визуальные истории, <span>которые усиливают бренды</span>
            </h1>
            <p className={styles.subtitle}>
              ArtVision Studio проектирует продукты, которые выделяются без компромиссов. Мы соединяем креатив, мыслительный дизайн и заботу о пользователе.
            </p>
            <div className={styles.actions}>
              <Link to="/portfolio" className={styles.primaryButton}>
                Смотреть портфолио
              </Link>
              <Link to="/contact" className={styles.secondaryButton}>
                Обсудить проект
              </Link>
            </div>
            <div className={styles.statsGrid}>
              {highlightStats.map((item) => (
                <div key={item.label} className={styles.statCard}>
                  <span className={styles.statValue}>{item.value}</span>
                  <span className={styles.statLabel}>{item.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className={styles.heroMedia}>
            <img
              src="https://picsum.photos/600/720?random=19"
              alt="Команда дизайнеров ArtVision Studio за креативным процессом"
              className={styles.heroImage}
            />
            <div className={styles.heroBadge}>
              <span>Design excellence</span>
              <span className={styles.badgeAccent}>2024</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <h2 className={styles.sectionTitle}>Что мы делаем</h2>
          <p className={styles.sectionSubtitle}>
            Полный цикл дизайн-услуг: от исследований и стратегии до дизайн-систем и арт-дирекшена.
          </p>
          <div className={styles.serviceGrid}>
            {servicePreview.map((service) => (
              <div key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon}>{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.serviceLink}>
                  Подробнее
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.processHeader}>
            <h2>Наш путь от идеи до реализации</h2>
            <p>
              Каждый проект — это сотрудничество. Мы работаем как партнеры, делимся инсайтами и создаем дизайн, который
              помогает бизнесу расти.
            </p>
          </div>
          <div className={styles.processGrid}>
            {process.map((stage, index) => (
              <div key={stage.title} className={styles.processCard}>
                <span className={styles.processIndex}>{index + 1}</span>
                <h3>{stage.title}</h3>
                <p>{stage.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={`container ${styles.ctaInner}`}>
          <div>
            <h2>Готовы преобразить ваш продукт?</h2>
            <p>Свяжитесь с нами, чтобы обсудить идеи, получить консультацию и сформировать мощный дизайн-результат.</p>
          </div>
          <Link to="/contact" className={styles.ctaButton}>
            Связаться с командой
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;