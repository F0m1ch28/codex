import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const About = () => {
  const values = [
    {
      title: "Креатив с измеримым результатом",
      description: "Каждое визуальное решение привязано к бизнес-целям. Мы соединяем исследовательские инсайты с яркой подачей.",
    },
    {
      title: "Партнерская глубина",
      description: "Мы вникаем в процессы клиентов, доходим до сути, чтобы выстроить сильную стратегию дизайна.",
    },
    {
      title: "Эстетика деталей",
      description: "Тщательно выверяем типографику, сетки и взаимодействия. Качество — в мелочах.",
    },
  ];

  const timeline = [
    {
      year: "2016",
      title: "Запуск студии",
      copy: "ArtVision Studio появилась как команда арт-директоров и UX дизайнеров с общей философией осознанного дизайна.",
    },
    {
      year: "2018",
      title: "Глобальные клиенты",
      copy: "Расширили географию работ — от СНГ до Европы и Азии, запустили проекты для финтеха и e-commerce.",
    },
    {
      year: "2021",
      title: "Собственная методология",
      copy: "Оформили фреймворк Vision Framework, который позволяет управлять сложными продуктами и дизайн-системами.",
    },
    {
      year: "2023",
      title: "Комплексные продуктовые команды",
      copy: "Создали внутренние кросс-функциональные команды, чтобы сопровождать клиентов на каждом этапе развития.",
    },
  ];

  return (
    <>
      <Helmet>
        <title>О студии ArtVision — команда, подход, история</title>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Мы создаем дизайн, который живет долго</h1>
          <p>
            ArtVision Studio — это коллектив дизайнеров, исследователей, арт-директоров и продюсеров. Мы объединены идеей
            создавать смелые и продуманные цифровые решения, которые формируют впечатления на всех уровнях взаимодействия.
          </p>
        </div>
      </section>

      <section className={styles.valuesSection}>
        <div className="container">
          <div className={styles.valueGrid}>
            {values.map((value) => (
              <div key={value.title} className={styles.valueCard}>
                <h2>{value.title}</h2>
                <p>{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <h2>Наш путь</h2>
          <div className={styles.timeline}>
            {timeline.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <span className={styles.year}>{item.year}</span>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.copy}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.teamCard}>
            <img
              src="https://picsum.photos/600/420?random=21"
              alt="Команда ArtVision Studio в процессе работы"
            />
            <div>
              <h2>Команда ArtVision Studio</h2>
              <p>
                Мы объединяем разный опыт — от продуктового дизайна и брендинга до motion и creative direction. Внутри
                студии ценим открытый диалог, обмен знаниями и стремление экспериментировать. Именно так рождаются проекты, которые выделяются.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;