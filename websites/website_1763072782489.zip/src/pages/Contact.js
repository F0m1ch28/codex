import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormData({
      name: "",
      company: "",
      email: "",
      message: "",
    });
  };

  return (
    <>
      <Helmet>
        <title>Контакты ArtVision Studio — обсудите проект</title>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Давайте делать красивое и полезное вместе</h1>
          <p>
            Расскажите о проекте, задаче или идее — команда ArtVision Studio свяжется с вами и предложит следующие шаги.
          </p>
        </div>
      </section>

      <section className={styles.contentSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoBlock}>
              <h2>Контакты</h2>
              <p>Москва, ул. Креативная, 15</p>
              <p>
                Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                <br />
                Email: <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
              </p>
              <div className={styles.infoCard}>
                <h3>Рабочий график</h3>
                <p>
                  Пн — Пт: 10:00 — 19:00
                  <br />
                  Обсуждаем проекты онлайн и офлайн.
                </p>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit}>
              <label className={styles.label}>
                Ваше имя
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Ирина Иванова"
                  required
                />
              </label>
              <label className={styles.label}>
                Компания / бренд
                <input
                  type="text"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="CreativeTech"
                />
              </label>
              <label className={styles.label}>
                Email
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="hello@company.com"
                  required
                />
              </label>
              <label className={styles.label}>
                Расскажите о задаче
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Опишите продукт, цель и желаемые сроки..."
                  rows="5"
                  required
                />
              </label>
              <button type="submit" className={styles.submitButton}>
                Отправить запрос
              </button>
              {submitted && (
                <p className={styles.successMessage}>
                  Спасибо! Мы свяжемся с вами в ближайшее время и обсудим детали.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;