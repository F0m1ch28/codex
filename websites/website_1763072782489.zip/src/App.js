import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTopButton";
import Home from "./pages/Home";
import Services from "./pages/Services";
import Portfolio from "./pages/Portfolio";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import CookiePolicy from "./pages/CookiePolicy";
import styles from "./App.module.css";

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <Router>
      <Helmet>
        <title>ArtVision Studio — Дизайн-студия</title>
        <meta
          name="description"
          content="ArtVision Studio создает выразительный веб-дизайн, брендинг и UI/UX решения. Мы объединяем эстетику и стратегию для сильных цифровых продуктов."
        />
      </Helmet>
      <div className={styles.appWrapper}>
        <Header />
        <main className={styles.main}>
          <ScrollToTopOnRouteChange />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<Services />} />
            <Route path="/portfolio" element={<Portfolio />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookie-policy" element={<CookiePolicy />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTopButton />
      </div>
    </Router>
  );
}

export default App;