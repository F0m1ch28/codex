import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div>
          <p className={styles.brand}>ArtVision Studio</p>
          <p className={styles.text}>
            Москва, ул. Креативная, 15 <br />
            Тел.: <a href="tel:+74951234567">+7 (495) 123-45-67</a> <br />
            Email: <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
          </p>
        </div>
        <div className={styles.navColumn}>
          <p className={styles.columnTitle}>Навигация</p>
          <NavLink to="/services" className={styles.link}>
            Услуги
          </NavLink>
          <NavLink to="/portfolio" className={styles.link}>
            Портфолио
          </NavLink>
          <NavLink to="/about" className={styles.link}>
            О нас
          </NavLink>
          <NavLink to="/contact" className={styles.link}>
            Контакты
          </NavLink>
        </div>
        <div className={styles.navColumn}>
          <p className={styles.columnTitle}>Документы</p>
          <NavLink to="/terms" className={styles.link}>
            Условия использования
          </NavLink>
          <NavLink to="/privacy" className={styles.link}>
            Политика конфиденциальности
          </NavLink>
          <NavLink to="/cookie-policy" className={styles.link}>
            Cookie политика
          </NavLink>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} ArtVision Studio. Создаем визуальные истории.</span>
      </div>
    </footer>
  );
};

export default Footer;