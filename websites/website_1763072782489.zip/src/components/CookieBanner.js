import React, { useEffect, useState } from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const storageKey = "artvision-cookie-consent";

  useEffect(() => {
    const consent = localStorage.getItem(storageKey);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(storageKey, "accepted");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Мы используем cookies для улучшения вашего взаимодействия и аналитики. Продолжая пользоваться сайтом, вы
        соглашаетесь с нашей{" "}
        <a href="/cookie-policy" className={styles.link}>
          Cookie политикой
        </a>
        .
      </div>
      <button type="button" className={styles.button} onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;