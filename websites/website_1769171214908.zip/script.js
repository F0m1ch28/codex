document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".site-nav");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navToggle.classList.toggle("is-active");
      navMenu.classList.toggle("is-open");
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll(".animate-on-scroll").forEach((element) => {
    observer.observe(element);
  });

  const toast = document.getElementById("global-toast");
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-active");
    setTimeout(() => {
      toast.classList.remove("is-active");
    }, 2400);
  }

  document.querySelectorAll('form[data-redirect="thank-you"]').forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Mesaj transmis. Redirecționăm către confirmare...");
      setTimeout(() => {
        window.location.href = form.getAttribute("action") || "thank-you.html";
      }, 1200);
    });
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const storageKey = "culinary_cookie_choice";
  if (cookieBanner) {
    const storedChoice = localStorage.getItem(storageKey);
    if (storedChoice) {
      cookieBanner.classList.add("is-hidden");
    }

    cookieBanner.querySelectorAll("button[data-cookie-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        const choice = button.getAttribute("data-cookie-choice");
        localStorage.setItem(storageKey, choice || "decline");
        cookieBanner.classList.add("is-hidden");
        showToast("Preferința privind cookie-urile a fost salvată.");
      });
    });
  }

  const currentYear = document.getElementById("current-year");
  if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
  }
});