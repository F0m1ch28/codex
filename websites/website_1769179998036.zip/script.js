document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const navMenu = document.querySelector("[data-nav-menu]");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const isOpen = navMenu.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  const animatedElements = document.querySelectorAll("[data-animate]");
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in-view");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  animatedElements.forEach((element) => observer.observe(element));

  const cookieBanner = document.getElementById("cookieBanner");
  const cookieKey = "impactVolunteersCookieChoice";
  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (storedChoice) {
      cookieBanner.classList.add("is-hidden");
    }
    cookieBanner.addEventListener("click", (event) => {
      const trigger = event.target.closest("[data-cookie-choice]");
      if (trigger) {
        const choice = trigger.getAttribute("data-cookie-choice");
        localStorage.setItem(cookieKey, choice);
        cookieBanner.classList.add("is-hidden");
      }
    });
  }

  const forms = document.querySelectorAll("[data-enhanced-form]");
  if (forms.length > 0) {
    const toast = document.createElement("div");
    toast.className = "form-toast";
    toast.textContent = "Mesajul a fost trimis. Urmează redirecționarea.";
    document.body.appendChild(toast);

    forms.forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        toast.classList.add("is-visible");
        setTimeout(() => {
          toast.classList.remove("is-visible");
          window.location.href = form.getAttribute("action") || "thank-you.html";
        }, 1400);
      });
    });
  }
});