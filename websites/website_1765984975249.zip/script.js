(function () {
  function generateDynamicImages() {
    const elements = document.querySelectorAll('.dynamic-img');
    elements.forEach(function (element) {
      const type = element.dataset.type || 'default';
      const seed = Date.now() + Math.floor(Math.random() * 1000000);
      generateRealisticImage(element, type, seed);
    });
  }

  function generateRealisticImage(element, type, seed) {
    const rng = createSeededRandom(seed);
    const canvasData = setupCanvas(element);
    const ctx = canvasData.ctx;
    const width = canvasData.width;
    const height = canvasData.height;

    switch (type) {
      case 'solar':
        drawRealisticSolarPanels(ctx, width, height, rng);
        break;
      case 'wind':
        drawRealisticWindTurbines(ctx, width, height, rng);
        break;
      case 'hybrid':
        drawRealisticHybridSystem(ctx, width, height, rng);
        break;
      case 'dashboard':
        drawRealisticDashboard(ctx, width, height, rng);
        break;
      case 'team':
        drawRealisticTeam(ctx, width, height, rng);
        break;
      case 'environment':
        drawRealisticEnvironment(ctx, width, height, rng);
        break;
      case 'map':
        drawRealisticMap(ctx, width, height, rng);
        break;
      default:
        drawDefaultScene(ctx, width, height, rng);
        break;
    }
  }

  function setupCanvas(element) {
    const rect = element.getBoundingClientRect();
    const computed = window.getComputedStyle(element);
    const width = Math.max(rect.width || parseFloat(computed.width) || 480, 280);
    const height = Math.max(rect.height || parseFloat(computed.height) || 260, 240);
    const dpr = window.devicePixelRatio || 1;

    const canvas = document.createElement('canvas');
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';

    element.innerHTML = '';
    element.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    return { ctx: ctx, width: width, height: height };
  }

  function createSeededRandom(seed) {
    let value = Math.floor(seed) % 2147483647;
    if (value <= 0) {
      value += 2147483646;
    }
    return function () {
      value = (value * 16807) % 2147483647;
      return (value - 1) / 2147483646;
    };
  }

  function drawRealisticSolarPanels(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    const horizon = height * 0.62;
    drawDistantHills(ctx, width, height, horizon, rng);

    ctx.fillStyle = '#475569';
    ctx.fillRect(0, horizon, width, height - horizon);
    ctx.fillStyle = '#64748b';
    ctx.fillRect(0, horizon, width, (height - horizon) * 0.5);

    const rowCount = 3 + Math.floor(rng() * 2);
    const baseWidth = width / (rowCount * 1.6);

    for (let row = 0; row < rowCount; row++) {
      const panelsInRow = 5 + Math.floor(rng() * 3);
      const panelWidth = baseWidth * (1 + rng() * 0.4);
      const panelHeight = height * 0.1;
      const depth = panelHeight * 0.65;
      const baseY = horizon + row * (panelHeight * 1.6) + panelHeight * 0.3;
      const rowOffset = (width - panelsInRow * panelWidth * 0.9) / 2;

      for (let p = 0; p < panelsInRow; p++) {
        const x = rowOffset + p * panelWidth * 0.9;
        const gradient = ctx.createLinearGradient(x, baseY - depth, x, baseY + panelHeight);
        gradient.addColorStop(0, '#1e3a8a');
        gradient.addColorStop(1, '#3b82f6');
        ctx.fillStyle = gradient;

        ctx.beginPath();
        ctx.moveTo(x - panelWidth * 0.08, baseY - depth);
        ctx.lineTo(x + panelWidth * 0.92, baseY - depth);
        ctx.lineTo(x + panelWidth, baseY + panelHeight * 0.2);
        ctx.lineTo(x, baseY + panelHeight);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 2;
        ctx.stroke();

        const columns = 6;
        const rows = 3;
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'rgba(148,163,184,0.6)';
        for (let c = 1; c < columns; c++) {
          const xPos = x - panelWidth * 0.08 + (panelWidth * 1.08 * c) / columns;
          ctx.beginPath();
          ctx.moveTo(xPos, baseY - depth);
          ctx.lineTo(xPos + panelWidth * 0.08, baseY + panelHeight * 0.2);
          ctx.stroke();
        }
        for (let r = 1; r < rows; r++) {
          const yFront = baseY + (panelHeight * r) / rows;
          const yBack = baseY - depth + (depth * r) / rows;
          ctx.beginPath();
          ctx.moveTo(x - panelWidth * 0.08, yBack);
          ctx.lineTo(x, yFront);
          ctx.lineTo(x + panelWidth, yFront - depth * 0.25);
          ctx.lineTo(x + panelWidth * 0.92, yBack);
          ctx.stroke();
        }

        ctx.fillStyle = '#1f2937';
        const supportWidth = panelWidth * 0.06;
        const supportHeight = panelHeight * 0.9;
        ctx.fillRect(x + panelWidth * 0.15, baseY + panelHeight, supportWidth, supportHeight);
        ctx.fillRect(x + panelWidth * 0.75, baseY + panelHeight, supportWidth, supportHeight);
      }
    }

    const sunX = width * 0.1 + rng() * width * 0.3;
    const sunY = height * 0.15 + rng() * height * 0.2;
    const sunRadius = 35 + rng() * 40;
    const radial = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, sunRadius * 2);
    radial.addColorStop(0, 'rgba(255,255,255,0.8)');
    radial.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = radial;
    ctx.beginPath();
    ctx.arc(sunX, sunY, sunRadius * 2, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawRealisticWindTurbines(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    const horizon = height * 0.65;
    drawDistantHills(ctx, width, height, horizon, rng);

    ctx.fillStyle = '#9ca3af';
    ctx.fillRect(0, horizon, width, height - horizon);
    ctx.fillStyle = '#64748b';
    ctx.fillRect(0, horizon + (height - horizon) * 0.2, width, (height - horizon) * 0.6);

    drawClouds(ctx, width, height * 0.5, 4 + Math.floor(rng() * 4), rng);

    const turbineCount = 3 + Math.floor(rng() * 2);
    for (let i = 0; i < turbineCount; i++) {
      const scale = 0.7 + rng() * 0.4;
      const baseX = width * (0.2 + rng() * 0.6);
      const baseY = horizon + (rng() * 20 - 10);
      const towerHeight = height * 0.3 * scale;
      const towerWidth = width * 0.015 * scale;

      const gradient = ctx.createLinearGradient(baseX, baseY - towerHeight, baseX + towerWidth, baseY);
      gradient.addColorStop(0, '#cbd5f5');
      gradient.addColorStop(1, '#94a3b8');
      ctx.fillStyle = gradient;

      ctx.beginPath();
      ctx.moveTo(baseX - towerWidth * 0.6, baseY);
      ctx.lineTo(baseX + towerWidth * 0.6, baseY);
      ctx.lineTo(baseX + towerWidth * 0.2, baseY - towerHeight);
      ctx.lineTo(baseX - towerWidth * 0.2, baseY - towerHeight);
      ctx.closePath();
      ctx.fill();

      const hubX = baseX;
      const hubY = baseY - towerHeight;
      const hubRadius = towerWidth * 1.4;
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.arc(hubX, hubY, hubRadius, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = towerWidth * 0.35;
      const bladeLength = towerHeight * 0.9;
      for (let blade = 0; blade < 3; blade++) {
        const angle = rng() * Math.PI * 2 + (Math.PI * 2 * blade) / 3;
        const endX = hubX + Math.cos(angle) * bladeLength;
        const endY = hubY + Math.sin(angle) * bladeLength;
        ctx.beginPath();
        ctx.moveTo(hubX, hubY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
      }

      ctx.fillStyle = 'rgba(15,23,42,0.25)';
      ctx.beginPath();
      ctx.ellipse(baseX, baseY + 8, towerWidth * 2.5, towerWidth * 1.5, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawRealisticHybridSystem(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    const horizon = height * 0.62;
    drawDistantHills(ctx, width, height, horizon, rng);
    drawClouds(ctx, width, height * 0.5, 3 + Math.floor(rng() * 4), rng);

    ctx.fillStyle = '#475569';
    ctx.fillRect(0, horizon, width, height - horizon);
    ctx.fillStyle = '#64748b';
    ctx.fillRect(0, horizon + (height - horizon) * 0.2, width, (height - horizon) * 0.6);

    const panelWidth = width * 0.18;
    const panelHeight = height * 0.12;
    const panelX = width * 0.12;
    const panelY = horizon + height * 0.05;
    ctx.fillStyle = ctx.createLinearGradient(panelX, panelY - panelHeight, panelX, panelY + panelHeight);
    ctx.fillStyle.addColorStop;
  }
})();