import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'miraloventa-cookie-consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.inner}>
        <div>
          <h4>Cookies für mehr Klarheit</h4>
          <p>
            Wir verwenden Cookies, um anonyme Nutzungsstatistiken zu speichern. So verbessern wir
            Miraloventa für Dich. Es werden keine persönlichen Profile erstellt.
          </p>
        </div>
        <div className={styles.actions}>
          <button className="secondary-btn" onClick={handleConsent}>
            Einverstanden
          </button>
          <button className={styles.linkButton} onClick={() => setVisible(false)}>
            Nur notwendige Cookies
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;