import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.footerInner}`}>
        <div className={styles.brand}>
          <div className={styles.logo}>
            <span>M</span>
          </div>
          <p>
            Miraloventa hilft Dir, Alltagsaufgaben mit einem klaren Handlungssystem anzugehen –
            strukturiert, fokussiert und in Deinem Tempo.
          </p>
          <div className={styles.contact}>
            <a href="mailto:kontakt@miraloventa.site">kontakt@miraloventa.site</a>
            <span>Platzhalterstraße 12, 10117 Berlin</span>
            <span>+49 (0)30 000 000</span>
          </div>
        </div>

        <div className={styles.links}>
          <h4>Navigation</h4>
          <nav>
            <Link to="/guide">Leitfaden</Link>
            <Link to="/programs">Programme</Link>
            <Link to="/tools">Tools &amp; Checklisten</Link>
            <Link to="/blog">Blog</Link>
            <Link to="/about">Über uns</Link>
            <Link to="/contact">Kontakt</Link>
          </nav>
        </div>

        <div className={styles.links}>
          <h4>Rechtliches</h4>
          <nav>
            <Link to="/legal">AGB</Link>
            <Link to="/privacy">Datenschutz</Link>
            <Link to="/imprint">Impressum</Link>
          </nav>
          <p className={styles.note}>
            Miraloventa bietet keine psychologische oder medizinische Beratung. Bei klinischen Fragen
            wende Dich bitte an ärztliches Fachpersonal.
          </p>
        </div>

        <div className={styles.newsletter}>
          <h4>Dranbleiben</h4>
          <p>Kurze Impulse für Fokus und kleine Schritte. Kein Spam, nur Klarheit.</p>
          <form className={styles.newsletterForm}>
            <label htmlFor="footer-email" className="visually-hidden">
              E-Mail für Updates
            </label>
            <input
              id="footer-email"
              type="email"
              name="email"
              placeholder="Deine E-Mail-Adresse"
              aria-label="E-Mail-Adresse"
            />
            <button type="submit">Benachrichtigen</button>
          </form>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <span>© {new Date().getFullYear()} Miraloventa. Alle Rechte vorbehalten.</span>
        </div>
      </div>
    </footer>
  );
}

export default Footer;