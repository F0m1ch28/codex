import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { label: 'Start', to: '/' },
  { label: 'Leitfaden', to: '/guide' },
  { label: 'Programme', to: '/programs' },
  { label: 'Tools', to: '/tools' },
  { label: 'Blog', to: '/blog' },
  { label: 'Über uns', to: '/about' },
  { label: 'Kontakt', to: '/contact' }
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={`container ${styles.headerInner}`}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoMark}>M</span>
          <span className={styles.logoText}>Miraloventa</span>
        </Link>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.activeNavLink : ''}`
              }
              onClick={closeMenu}
            >
              {item.label}
            </NavLink>
          ))}
          <Link to="/guide" className={`${styles.navCTA} primary-btn`} onClick={closeMenu}>
            Jetzt starten
          </Link>
        </nav>
        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-label={menuOpen ? 'Menü schließen' : 'Menü öffnen'}
          aria-expanded={menuOpen}
        >
          <span className={styles.menuIcon} />
          <span className="visually-hidden">{menuOpen ? 'Menü schließen' : 'Menü öffnen'}</span>
        </button>
      </div>
    </header>
  );
}

export default Header;