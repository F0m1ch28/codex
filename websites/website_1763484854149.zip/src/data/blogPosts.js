export const blogPosts = [
  {
    id: 1,
    slug: 'aufschieben-entwirren',
    title: 'Aufschieben entwirren: Schritt für Schritt wieder handlungsfähig',
    teaser:
      'Woran erkennst Du, dass Prokrastination ein System-Problem ist und keine Frage der Disziplin? Hier findest Du klare Anhaltspunkte.',
    category: 'Prokrastination',
    readTime: '6 Min.',
    image: 'https://picsum.photos/800/600?random=12',
    alt: 'Arbeitsplatz mit Notizbuch und Tee',
    content: [
      'Prokrastination ist selten ein Zeichen von Faulheit. Häufig ist es ein Hinweis darauf, dass Regeln, Räume oder Routinen fehlen. Wenn Aufgaben zu groß, zu unklar oder zu wenig priorisiert sind, reagiert unser Gehirn mit Ausweichmanövern.',
      'Ein erster Schritt ist, das Muster zu kartieren: Wann tritt Aufschieben auf, was passiert in diesen Momenten, welche Gedanken begleiten Dich? Dadurch entdeckst Du wiederholte Auslöser.',
      'Im zweiten Schritt bringst Du Ordnung in Aufgaben und Zeit. Kleine, sichtbare Entscheidungen wie „Was ist die nächste Aktion?“ oder „Wie lange investiere ich heute?“ helfen, den Startwiderstand zu senken.',
      'Miraloventa unterstützt Dich mit alltagstauglichen Fragen, Templates und Routinen, die Du schnell an Deinen Kontext anpassen kannst. Kein Druck, sondern ein System, das Dich zügig ins Tun bringt.'
    ]
  },
  {
    id: 2,
    slug: 'fokus-30-minuten',
    title: '30-Minuten-Fokus-Blöcke: So nutzt Du kurze Zeitfenster maximal',
    teaser:
      'Kurze Fokus-Sprints sind ideal, wenn der Kalender dicht ist. Mit diesen drei Regeln holst Du das Maximum aus 30 Minuten.',
    category: 'Fokus',
    readTime: '4 Min.',
    image: 'https://picsum.photos/800/600?random=14',
    alt: 'Person mit Kopfhörern an Laptop konzentriert',
    content: [
      'Kurze, klar definierte Arbeitsblöcke helfen dabei, Aufgaben realistisch einzugrenzen. Entscheidend ist, dass Du vorher festlegst, was am Ende sichtbar sein soll.',
      'Nutze eine Mini-Checkliste: Kontext klären, Hilfsmittel bereitlegen, Störquellen blocken. Danach stellst Du einen Timer auf 25–30 Minuten.',
      'Nach dem Block entscheidest Du direkt, ob Du einen zweiten Block anhängst oder eine Mikropause einlegst. So trainierst Du, Entscheidungen nicht aufzuschieben, sondern bewusst zu treffen.'
    ]
  },
  {
    id: 3,
    slug: 'mini-routinen',
    title: 'Mini-Routinen für den Alltag: Mit kleinen Gewohnheiten Momentum gewinnen',
    teaser:
      'Große Veränderungen starten oft mit winzigen Handlungen. Drei Mini-Routinen, die Dir helfen, handlungsfähig zu bleiben.',
    category: 'Gewohnheiten',
    readTime: '5 Min.',
    image: 'https://picsum.photos/800/600?random=16',
    alt: 'Schreibtisch mit Notizzetteln und Kalender',
    content: [
      'Mini-Routinen sind bewusste 5-Minuten-Aktionen, die Deinem Tag Struktur geben. Sie sind so klein, dass Dein innerer Widerstand keine Chance bekommt.',
      'Beispiele: Einen Aufgabenstapel jeden Abend kurz sortieren, jeden Morgen einen Fokus-Satz formulieren, jede Woche eine Aufgabe bewusst streichen.',
      'Wichtig: Feiere das Ausführen, nicht das Ergebnis. So verankerst Du die Routine langfristig.'
    ]
  }
];