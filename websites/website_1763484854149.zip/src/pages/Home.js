import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import { blogPosts } from '../data/blogPosts';

const statsData = [
  { label: 'Strukturierte Sessions', value: 480 },
  { label: 'Fokus-Routinen im Einsatz', value: 36 },
  { label: 'Community-Mitglieder', value: 1240 },
  { label: 'Reflexionsfragen geprüft', value: 210 }
];

const benefitCards = [
  {
    title: 'Klarheit in kleinen Schritten',
    description:
      'Statt Perfektion zählt, dass Du in Bewegung bleibst. Unsere Leitfragen brechen Aufgaben auf handhabbare Aktionen herunter.'
  },
  {
    title: 'Routinen, die sich flexibel anfühlen',
    description:
      'Plane nicht für Idealbedingungen, sondern für Deinen Alltag. Miraloventa passt sich an schwankende Energie und Zeitfenster an.'
  },
  {
    title: 'Strukturen, die Dich stützen',
    description:
      'Von Fokus-Blocks bis Wochen-Action-System: Du erhältst erprobte Templates, die Du ohne Overload sofort nutzen kannst.'
  },
  {
    title: 'Motivation ohne Druck',
    description:
      'Wir setzen auf ehrliche Selbstreflexion und Mikro-Erfolge – nicht auf Durchhalteparolen. So bleibt Dein System stabil.'
  }
];

const topics = [
  {
    title: 'Fokus & Ablenkungen',
    description: 'Praktische Fokus-Rituale, die auch funktionieren, wenn Slack & Co. ständig pingt.'
  },
  {
    title: 'Aufgaben strukturieren',
    description: 'Von chaotischen To-dos zur klaren Aktionsliste mit Prioritäten, Kontext und Zeitbudget.'
  },
  {
    title: 'Motivation & Energie',
    description: 'Arbeite mit Deiner Energie, nicht dagegen. Finde Dein persönliches Aktivierungsritual.'
  },
  {
    title: 'Realistische Planung',
    description: 'Plane in kleinen Blöcken und erkenne Engpässe frühzeitig, statt in Stressphasen anzukommen.'
  }
];

const processSteps = [
  {
    title: 'Status checken',
    points: ['Was bremst Dich wirklich?', 'Trigger erkennen & dokumentieren', 'Aufgabenwüste sortieren']
  },
  {
    title: 'Aufräumen & Priorisieren',
    points: ['Kontext klären', 'Nächste konkrete Aktion definieren', 'Zeit-Slots realistisch setzen']
  },
  {
    title: 'Regeln vereinbaren',
    points: [
      'Simple Regeln für Fokus-Zeiten',
      '„Wenn-dann“-Pläne für Störungen',
      'Visualisierung für laufende Aufgaben'
    ]
  },
  {
    title: 'Routinen & Review',
    points: ['Kurze Tageschecks', 'Win-Log statt To-do-Stress', 'Wöchentlicher System-Review']
  }
];

const testimonials = [
  {
    quote:
      'Miraloventa hat mir geholfen, meine Uni-Aufgaben nicht mehr vor mir herzuschieben. Die 30-Minuten-Blöcke sind inzwischen Standard.',
    name: 'Svenja, Studentin Informationsmanagement'
  },
  {
    quote:
      'Ich dachte, ich brauche mehr Disziplin. Tatsächlich brauchte ich klare Regeln. Die Wochenübersicht spart mir täglich Zeit.',
    name: 'Jonas, Product Owner'
  },
  {
    quote:
      'Die Reflexionsfragen helfen mir, ehrlich zu prüfen, was funktioniert. Kleine Routinen – große Wirkung auf meine Energie.',
    name: 'Nadia, UX Designerin'
  }
];

const projects = [
  {
    id: 1,
    title: 'Fokus-Sprints im hybriden Team',
    category: 'Teamarbeit',
    image: 'https://picsum.photos/1200/800?random=21',
    description:
      'Ein Remote-Team führte 2x täglich Kurz-Checks ein und reduzierte unerledigte Aufgaben um 35%.'
  },
  {
    id: 2,
    title: 'Studium mit Wochen-Action-System',
    category: 'Studium',
    image: 'https://picsum.photos/1200/800?random=22',
    description:
      'Strukturierte Lernblöcke und klar definierte Recovery-Zeiten sorgten für konsistente Prüfungsvorbereitung.'
  },
  {
    id: 3,
    title: 'Solo-Selbstständige mit Fokus-Routinen',
    category: 'Selbstständigkeit',
    image: 'https://picsum.photos/1200/800?random=23',
    description:
      'Eine kreative Freelancerin etablierte Mikro-Routinen und steigerte die Projektabschlüsse um 28%.'
  },
  {
    id: 4,
    title: 'Neues Aufgabenboard in der Pflegeleitung',
    category: 'Teamarbeit',
    image: 'https://picsum.photos/1200/800?random=24',
    description:
      'Ein Pflege-Team definierte klare Übergaben, wodurch kritische Aufgaben transparenter und pünktlicher erledigt wurden.'
  }
];

const faqItems = [
  {
    question: 'Ist Miraloventa eine Therapie gegen Prokrastination?',
    answer:
      'Nein. Miraloventa bietet strukturierte Selbstmanagement-Impulse. Wenn Dich psychische Belastungen stark einschränken, wende Dich bitte an therapeutische Fachstellen.'
  },
  {
    question: 'Wie viel Zeit sollte ich pro Tag einplanen?',
    answer:
      'Schon 20 bis 30 Minuten reichen, um mit Fokus-Blocks zu starten. Wichtig ist die Regelmäßigkeit, nicht die Dauer.'
  },
  {
    question: 'Brauche ich spezielle Tools?',
    answer:
      'Nein. Wir arbeiten mit leicht zugänglichen Vorlagen (PDF, Notion, Google Docs) und Papier-Alternativen. Du wählst das Tool, das zu Dir passt.'
  },
  {
    question: 'Gibt es Community-Austausch?',
    answer:
      'Ja. Du kannst Dich mit anderen Mitgliedern zu Fokus-Sessions verabreden und Erfahrungen teilen – jedoch völlig freiwillig.'
  }
];

function Home() {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Alle');
  const categories = useMemo(
    () => ['Alle', ...new Set(projects.map((project) => project.category))],
    []
  );
  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Alle') return projects;
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((count, index) => {
          if (count >= statsData[index].value) return statsData[index].value;
          const increment = Math.ceil(statsData[index].value / 40);
          return Math.min(count + increment, statsData[index].value);
        })
      );
    }, 60);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const slider = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(slider);
  }, []);

  const latestPosts = useMemo(() => blogPosts.slice(0, 3), []);

  return (
    <>
      <Helmet>
        <title>Miraloventa | Weniger Aufschieben. Mehr ins Tun.</title>
        <meta
          name="description"
          content="Miraloventa unterstützt Dich dabei, Prokrastination zu überwinden und ein alltagstaugliches Handlungssystem aufzubauen. Starte mit klaren Fokus-Blöcken und Routinen."
        />
      </Helmet>
      <div className={styles.hero} style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=5)' }}>
        <div className={styles.heroOverlay} />
        <div className={`container ${styles.heroContent}`}>
          <span className="section-label">Miraloventa</span>
          <h1>Weniger Aufschieben. Mehr ins Tun kommen.</h1>
          <p>
            Du brauchst keine neue To-do-App. Du brauchst ein System, das zu Deinem Alltag passt.
            Miraloventa verbindet klare Strukturen mit alltagstauglichen Routinen – damit Du wieder
            handlungsfähig wirst.
          </p>
          <div className={styles.heroActions}>
            <Link to="/guide" className="primary-btn">
              Prokrastination angehen
            </Link>
            <Link to="/programs" className="secondary-btn">
              Programme entdecken
            </Link>
          </div>
        </div>
      </div>

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introCard}>
            <div>
              <h2>Prokrastination ist ein System-Thema – nicht Dein Charakter.</h2>
              <p>
                Aufschieben entsteht, wenn Aufgaben zu diffus, zu groß oder zu wenig priorisiert
                sind. Miraloventa hilft Dir, Muster sichtbar zu machen und sie Schritt für Schritt zu
                verändern. Ohne Druck, dafür mit klaren Rahmenbedingungen.
              </p>
            </div>
            <div className={styles.statsGrid}>
              {statsData.map((stat, index) => (
                <div key={stat.label} className={styles.statCard}>
                  <span className={styles.statValue}>{counters[index]}+</span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="section-label">Was Dir Miraloventa gibt</span>
            <h2>Praktische Unterstützung, die Dich nicht überfordert.</h2>
            <p>
              Fokus auf machbare Schritte, klare Sprache, flexible Umsetzung – so wird Dein
              Handlungssystem tragfähig.
            </p>
          </div>
          <div className={styles.benefitGrid}>
            {benefitCards.map((card) => (
              <article key={card.title} className={styles.benefitCard}>
                <h3>{card.title}</h3>
                <p>{card.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.topics}>
        <div className="container">
          <div className={styles.sectionHeaderCompact}>
            <h2>Vier Themen, die Dein System aufbauen.</h2>
            <p>Kompakte Module führen Dich durch die wichtigsten Handlungsfelder.</p>
          </div>
          <div className={styles.topicGrid}>
            {topics.map((topic) => (
              <article key={topic.title} className={styles.topicCard}>
                <h3>{topic.title}</h3>
                <p>{topic.description}</p>
                <Link to="/guide" className="text-link">
                  Mehr erfahren →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="section-label">Der Miraloventa-Prozess</span>
            <h2>In vier pragmatischen Schritten zu Deinem Handlungssystem.</h2>
            <p>
              Unser Leitfaden zeigt Dir, wie Du Strukturen findest, die zu Deiner Realität passen –
              ohne zusätzlichen Stress.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.stepBadge}>{index + 1}</span>
                <h3>{step.title}</h3>
                <ul>
                  {step.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <div className={styles.processCTA}>
            <Link to="/guide" className="primary-btn">
              Zum Leitfaden
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.servicesPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="section-label">Programme & Challenges</span>
            <h2>Strukturiert ins Tun – mit klar abgegrenzten Programmen.</h2>
            <p>Ganz gleich, ob Du einen kurzen Fokus-Boost oder ein Wochen-System brauchst.</p>
          </div>
          <div className={styles.serviceGrid}>
            <article className={styles.serviceCard}>
              <span className={styles.serviceDuration}>7 Tage</span>
              <h3>Anti-Aufschiebe-Challenge</h3>
              <p>
                Tägliche Micro-Missionen, die Deine wichtigsten Aufgaben konsequent anstoßen –
                inklusive Review-Fragen.
              </p>
              <Link to="/programs" className="text-link">
                Challenge ansehen →
              </Link>
            </article>
            <article className={styles.serviceCard}>
              <span className={styles.serviceDuration}>30 Minuten</span>
              <h3>Fokus-Blocks Toolkit</h3>
              <p>
                Timer, Reflexions-Log und Aktivierungsfragen, mit denen Du auch bei knapper Zeit in
                den Fokus kommst.
              </p>
              <Link to="/programs" className="text-link">
                Toolkit entdecken →
              </Link>
            </article>
            <article className={styles.serviceCard}>
              <span className={styles.serviceDuration}>1 Woche</span>
              <h3>Wochen-Action-System</h3>
              <p>
                Dein persönliches Board für Pflichten, Fokus und Recovery. Mit klaren Regeln für
                Prioritäten & Grenzen.
              </p>
              <Link to="/programs" className="text-link">
                System starten →
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialWrapper}>
            <div className={styles.testimonialContent}>
              <span className="section-label">Feedback aus der Praxis</span>
              <h2>Echte Stimmen – ehrliche Ergebnisse.</h2>
              <p>
                Miraloventa wurde mit Menschen entwickelt, die zwischen Meetings, Studium und
                Privatleben handlungsfähig bleiben müssen.
              </p>
            </div>
            <aside className={styles.testimonialSlider}>
              <blockquote>
                „{testimonials[activeTestimonial].quote}“
              </blockquote>
              <cite>{testimonials[activeTestimonial].name}</cite>
              <div className={styles.sliderControls} role="group" aria-label="Testimonials wechseln">
                <button
                  type="button"
                  onClick={() =>
                    setActiveTestimonial(
                      (prev) => (prev - 1 + testimonials.length) % testimonials.length
                    )
                  }
                  aria-label="Vorheriges Feedback"
                >
                  ←
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
                  }
                  aria-label="Nächstes Feedback"
                >
                  →
                </button>
              </div>
            </aside>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="section-label">Praxisbeispiele</span>
            <h2>So sieht Umsetzung mit Miraloventa aus.</h2>
            <p>
              Filtere nach Kontext und sieh, wie andere ihr Handlungssystem aufgebaut haben – mit
              klaren Ergebnissen.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Projektfilter">
            {categories.map((category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
                aria-pressed={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={project.description} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/guide" className="text-link">
                    Umsetzung nachbauen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeaderCompact}>
            <h2>Fragen, die wir häufig hören.</h2>
            <p>Klare Antworten, damit Du einschätzen kannst, ob Miraloventa zu Dir passt.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="section-label">Insights & Impulse</span>
            <h2>Blog: kleine Schritte, große Wirkung.</h2>
            <p>
              Kurze Artikel, die Dir helfen, Muster zu erkennen, Routinen zu etablieren und Dich nicht
              zu überfordern.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {latestPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.alt} loading="lazy" />
                <div className={styles.blogMeta}>
                  <span>{post.category}</span>
                  <span>{post.readTime}</span>
                </div>
                <h3>{post.title}</h3>
                <p>{post.teaser}</p>
                <Link to={`/blog/${post.slug}`} className="text-link">
                  Artikel lesen →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Bereit für klare Aktionen statt Kopfkino?</h2>
              <p>
                Starte heute mit einer 7-Tage-Challenge oder baue Dein Wochen-Action-System. Wir
                begleiten Dich mit Fragen, Templates und ehrlichem Feedback.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/guide" className="primary-btn">
                Leitfaden öffnen
              </Link>
              <Link to="/contact" className="secondary-btn">
                Frage stellen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;