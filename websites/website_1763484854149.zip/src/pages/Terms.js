import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

function Terms() {
  return (
    <>
      <Helmet>
        <title>AGB | Miraloventa</title>
        <meta
          name="description"
          content="Allgemeine Geschäftsbedingungen der Miraloventa Plattform. Transparente Regeln für eine faire Zusammenarbeit."
        />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <div className={styles.card}>
            <h1>Allgemeine Geschäftsbedingungen</h1>
            <p>Stand: Januar 2024</p>

            <h2>1. Geltungsbereich</h2>
            <p>
              Diese Allgemeinen Geschäftsbedingungen gelten für die Nutzung der Miraloventa-Plattform.
              Abweichende Bedingungen werden nicht anerkannt, es sei denn, Miraloventa stimmt ihnen
              ausdrücklich schriftlich zu.
            </p>

            <h2>2. Leistungen</h2>
            <p>
              Miraloventa stellt Selbstmanagement-Inhalte, Programme und Tools zur Verfügung. Es handelt
              sich nicht um medizinische oder psychologische Beratung. Nutzerinnen und Nutzer setzen die
              Inhalte eigenverantwortlich ein.
            </p>

            <h2>3. Verantwortung der Nutzer*innen</h2>
            <ul>
              <li>Angaben bei Anfragen müssen vollständig und korrekt sein.</li>
              <li>Inhalte sind ausschließlich zur persönlichen Nutzung bestimmt.</li>
              <li>
                Die Weitergabe von Inhalten an Dritte bedarf der schriftlichen Zustimmung von
                Miraloventa.
              </li>
            </ul>

            <h2>4. Haftung</h2>
            <p>
              Miraloventa haftet nur für Schäden, die auf vorsätzliches oder grob fahrlässiges Verhalten
              zurückzuführen sind. Für indirekte Schäden wird keine Haftung übernommen. Die Nutzung erfolgt
              auf eigenes Risiko.
            </p>

            <h2>5. Datenschutz</h2>
            <p>
              Der Schutz personenbezogener Daten ist uns wichtig. Details finden sich in der gesonderten{' '}
              <a href="/privacy">Datenschutzerklärung</a>.
            </p>

            <h2>6. Schlussbestimmungen</h2>
            <p>
              Es gilt das Recht der Bundesrepublik Deutschland. Gerichtsstand ist Berlin, soweit gesetzlich
              zulässig. Sollte eine Bestimmung unwirksam sein, bleibt die Wirksamkeit der übrigen
              Bestimmungen unberührt.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Terms;