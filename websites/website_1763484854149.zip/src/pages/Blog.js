import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';
import { blogPosts } from '../data/blogPosts';

function Blog() {
  return (
    <>
      <Helmet>
        <title>Blog | Miraloventa</title>
        <meta
          name="description"
          content="Impulse und Strategien rund um Prokrastination, Fokus und Gewohnheiten. Unsere Blogartikel geben Dir praktische Tipps."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">Blog</span>
            <h1>Impulse, die Dich ins Handeln bringen.</h1>
            <p>
              Unsere Artikel liefern Dir praktische Beispiele, reflektierte Fragen und kurze
              Experimente, die Du sofort ausprobieren kannst.
            </p>
          </div>
        </div>
      </section>
      <section className={styles.posts}>
        <div className="container">
          <div className={styles.grid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.postCard}>
                <img src={post.image} alt={post.alt} loading="lazy" />
                <div className={styles.meta}>
                  <span>{post.category}</span>
                  <span>{post.readTime}</span>
                </div>
                <h2>{post.title}</h2>
                <p>{post.teaser}</p>
                <Link to={`/blog/${post.slug}`} className="text-link">
                  Weiterlesen →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Blog;