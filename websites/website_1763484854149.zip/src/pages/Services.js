import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const programs = [
  {
    title: '7-Tage-Anti-Aufschiebe-Challenge',
    duration: '7 Tage',
    target: 'Ideal, wenn Du schnell Momentum aufbauen möchtest.',
    description:
      'Tägliche Micro-Aufgaben, Fokus-Fragen und ein tägliches Check-in, damit Du konsequent ins Tun kommst.'
  },
  {
    title: '30-Minuten-Fokus-Blocks',
    duration: 'Flexibel',
    target: 'Für Menschen mit engen Kalendern, die dennoch vorankommen wollen.',
    description:
      'Ein Baukasten aus Aktivierungsritual, Timer-Setup und Reflexion, um kurze Zeitfenster effektiv zu nutzen.'
  },
  {
    title: 'Dein Wochen-Action-System',
    duration: '1 Woche Setup',
    target: 'Wenn Du Deinen Alltag strukturiert und verlässlich gestalten möchtest.',
    description:
      'Baue ein persönliches Board mit klaren Regeln für Planung, Fokus und Erholung – inklusive wöchentlichem Review.'
  }
];

function Services() {
  return (
    <>
      <Helmet>
        <title>Programme | Miraloventa</title>
        <meta
          name="description"
          content="Miraloventa-Programme unterstützen Dich mit klaren Strukturen dabei, Prokrastination Schritt für Schritt zu überwinden."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">Programme</span>
            <h1>Wähle das Programm, das zu Deinem Alltag passt.</h1>
            <p>
              Kurze Challenges oder umfassende Systeme – Du entscheidest, wie intensiv Deine nächste
              Umsetzungssession wird.
            </p>
            <Link to="/contact" className="secondary-btn">
              Fragen? Schreib uns!
            </Link>
          </div>
        </div>
      </section>
      <section className={styles.programs}>
        <div className="container">
          <div className={styles.programGrid}>
            {programs.map((program) => (
              <article key={program.title} className={styles.programCard}>
                <div className={styles.programHeader}>
                  <span>{program.duration}</span>
                  <h2>{program.title}</h2>
                </div>
                <p>{program.description}</p>
                <div className={styles.target}>
                  <strong>Für wen?</strong>
                  <p>{program.target}</p>
                </div>
                <Link to="/guide" className="text-link">
                  Programm starten →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;