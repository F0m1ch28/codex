import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './BlogDetail.module.css';
import { blogPosts } from '../data/blogPosts';

function BlogDetail() {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Artikel nicht gefunden</h1>
          <p>Der gesuchte Artikel existiert nicht mehr oder wurde verschoben.</p>
          <Link to="/blog" className="primary-btn">
            Zurück zum Blog
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Miraloventa</title>
        <meta name="description" content={post.teaser} />
      </Helmet>
      <article className={styles.article}>
        <div className="container">
          <header className={styles.header}>
            <span className="section-label">{post.category}</span>
            <h1>{post.title}</h1>
            <div className={styles.meta}>
              <span>{post.readTime} Lesezeit</span>
              <Link to="/blog">Zurück zur Übersicht</Link>
            </div>
          </header>
          <img src={post.image} alt={post.alt} loading="lazy" className={styles.cover} />
          <div className={styles.content}>
            {post.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>
      </article>
    </>
  );
}

export default BlogDetail;