import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Imprint.module.css';

function Imprint() {
  return (
    <>
      <Helmet>
        <title>Impressum | Miraloventa</title>
        <meta
          name="description"
          content="Impressum der Miraloventa Plattform. Gesetzliche Informationen gemäß § 5 TMG."
        />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <div className={styles.card}>
            <h1>Impressum</h1>
            <p>Angaben gemäß § 5 TMG</p>

            <h2>Miraloventa Plattform</h2>
            <p>
              Platzhalterstraße 12 <br />
              10117 Berlin <br />
              Deutschland
            </p>

            <h2>Kontakt</h2>
            <p>
              Telefon: +49 (0)30 000 000 <br />
              E-Mail: kontakt@miraloventa.site
            </p>

            <h2>Vertretungsberechtigte</h2>
            <p>Lea Miralova</p>

            <h2>Umsatzsteuer-ID</h2>
            <p>Wird aktuell nicht ausgewiesen (Kleinunternehmerregelung gemäß § 19 UStG).</p>

            <h2>Verantwortlich für den Inhalt</h2>
            <p>
              Lea Miralova <br />
              Anschrift wie oben
            </p>

            <h2>Haftungsausschluss</h2>
            <p>
              Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für externe Links.
              Für den Inhalt verlinkter Seiten sind ausschließlich deren Betreiber verantwortlich.
            </p>

            <h2>Hinweis</h2>
            <p>
              Miraloventa ersetzt keine medizinische oder psychologische Beratung. Bitte wende Dich bei
              gesundheitlichen Fragen an ärztliches Fachpersonal.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Imprint;