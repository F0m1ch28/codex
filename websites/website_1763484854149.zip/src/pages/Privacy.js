import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Datenschutzerklärung | Miraloventa</title>
        <meta
          name="description"
          content="Informationen zum Datenschutz bei Miraloventa. Wir erklären transparent, welche Daten wir erheben und wie wir sie nutzen."
        />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <div className={styles.card}>
            <h1>Datenschutzerklärung</h1>
            <p>Stand: Januar 2024</p>

            <h2>1. Verantwortliche Stelle</h2>
            <p>
              Miraloventa Plattform <br />
              Platzhalterstraße 12 <br />
              10117 Berlin <br />
              E-Mail: kontakt@miraloventa.site
            </p>

            <h2>2. Erhebung und Nutzung personenbezogener Daten</h2>
            <p>
              Wir erheben personenbezogene Daten, wenn Du uns kontaktierst oder unsere Angebote nutzt.
              Dazu zählen Name, E-Mail-Adresse und die bereitgestellten Inhalte. Diese Daten verwenden wir
              ausschließlich zur Bearbeitung Deiner Anfrage.
            </p>

            <h2>3. Cookies & Analyse</h2>
            <p>
              Wir setzen Cookies ein, um die Nutzung unserer Website anonym zu analysieren. Die Cookies
              dienen ausschließlich statistischen Zwecken und ermöglichen keine Rückschlüsse auf Deine
              Person. Du kannst den Einsatz von Cookies in Deinem Browser deaktivieren.
            </p>

            <h2>4. Datenweitergabe</h2>
            <p>
              Eine Weitergabe an Dritte erfolgt nur, wenn wir rechtlich dazu verpflichtet sind oder Du
              ausdrücklich einwilligst.
            </p>

            <h2>5. Speicherdauer</h2>
            <p>
              Wir löschen personenbezogene Daten, sobald der Zweck der Speicherung entfällt und keine
              gesetzlichen Aufbewahrungspflichten entgegenstehen.
            </p>

            <h2>6. Deine Rechte</h2>
            <ul>
              <li>Auskunft über gespeicherte Daten</li>
              <li>Berichtigung unrichtiger Daten</li>
              <li>Löschung oder Einschränkung der Verarbeitung</li>
              <li>Widerspruch gegen die Verarbeitung</li>
              <li>Beschwerderecht bei einer Datenschutzbehörde</li>
            </ul>

            <h2>7. Kontakt</h2>
            <p>
              Für Fragen zum Datenschutz erreichst Du uns unter{' '}
              <a href="mailto:kontakt@miraloventa.site">kontakt@miraloventa.site</a>. Wir beantworten Dein
              Anliegen zeitnah.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Privacy;