import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    name: 'Tages-Action-Plan',
    description:
      'Deine Tagesstruktur mit Fokus-Block, Mini-Aufgaben und Recovery-Check. Ideal für hektische Tage.',
    features: ['3-Block-Layout', 'Kurzer Rückblick am Abend', 'PDF & Notion-Version']
  },
  {
    name: '„Wenn-dann“-Planung',
    description:
      'Reagiere auf Störungen mit klaren Regeln. Plane Alternativen, bevor Ablenkungen auftauchen.',
    features: ['Trigger identifizieren', 'Konkrete Ersatzhandlungen', 'Team-kompatibel']
  },
  {
    name: 'Prioritäten-Matrix',
    description:
      'Schnell erkennen, was wichtig ist. Priorisiere nach Wirkung und Energiebedarf.',
    features: ['Einschätzung nach Wirkung/Energie', 'Entscheidungsfragen inklusive', 'Visuelle Priorisierung']
  },
  {
    name: 'Wochenübersicht Fokuszeiten',
    description:
      'Ein Board für Deine Fokus-Zeiten, Meetings und Puffer. Damit Du Grenzen setzen kannst.',
    features: ['Planungschecklisten', 'Review-Fragen', 'Export als PDF oder Tabellenblatt']
  }
];

function Tools() {
  return (
    <>
      <Helmet>
        <title>Tools & Checklisten | Miraloventa</title>
        <meta
          name="description"
          content="Handfeste Tools und Checklisten, die Dich täglich unterstützen: Tages-Action-Plan, Wenn-Dann-Planung, Prioritäten-Matrix und mehr."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">Tools & Checklisten</span>
            <h1>Struktur zum Mitnehmen. Direkt anwendbar.</h1>
            <p>
              Unsere Vorlagen sind so gestaltet, dass Du sie in wenigen Minuten an Deine Realität
              anpassen kannst – digital oder auf Papier.
            </p>
          </div>
        </div>
      </section>
      <section className={styles.toolList}>
        <div className="container">
          <div className={styles.grid}>
            {tools.map((tool) => (
              <article key={tool.name} className={styles.toolCard}>
                <img
                  src="https://picsum.photos/800/600?random=30"
                  alt="Abstraktes Produktbild"
                  loading="lazy"
                />
                <div className={styles.toolContent}>
                  <h2>{tool.name}</h2>
                  <p>{tool.description}</p>
                  <ul>
                    {tool.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Tools;