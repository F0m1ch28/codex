import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Lea Miralova',
    role: 'Gründerin & System-Coach',
    quote: '„Ich glaube an klare Regeln, die sich menschlich anfühlen.“',
    image: 'https://picsum.photos/400/400?random=33'
  },
  {
    name: 'Tobias Lenz',
    role: 'Struktur-Designer',
    quote: '„Vorlagen müssen sich leicht anfühlen – sonst werden sie nie genutzt.“',
    image: 'https://picsum.photos/400/400?random=34'
  },
  {
    name: 'Amina Becker',
    role: 'Community & Content',
    quote: '„Erfahrungsaustausch zeigt, wie vielseitig kleine Schritte sein können.“',
    image: 'https://picsum.photos/400/400?random=35'
  }
];

function About() {
  return (
    <>
      <Helmet>
        <title>Über uns | Miraloventa</title>
        <meta
          name="description"
          content="Miraloventa setzt auf alltagstaugliche Strukturen und kleine Schritte. Erfahre, wer dahinter steckt und warum wir keine medizinische Beratung ersetzen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">Über uns</span>
            <h1>Wir bauen Systeme, die Deinen Alltag respektieren.</h1>
            <p>
              Miraloventa ist aus der Erfahrung entstanden, dass kleine, machbare Schritte nachhaltiger
              sind als strenge Pläne. Wir entwickeln Tools, die in echten Kalendern funktionieren –
              nicht nur in Idealwelten.
            </p>
          </div>
        </div>
      </section>
      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div className={styles.textBlock}>
              <h2>Unsere Mission</h2>
              <p>
                Wir unterstützen Dich dabei, Deine Aufgaben mit einem klaren Handlungssystem zu
                bewältigen. Fokus, Prioritäten, Energie – alles hängt zusammen. Deshalb kombinieren wir
                Struktur mit Reflexion.
              </p>
              <ul>
                <li>Alltagstaugliche Templates statt starre Regeln</li>
                <li>Kurze Impulse, die Dich wirklich ins Tun bringen</li>
                <li>Wertschätzung für Dein Tempo und Deine Realität</li>
              </ul>
            </div>
            <div className={styles.values}>
              <article>
                <h3>Seriosität</h3>
                <p>
                  Wir arbeiten transparent, datenschutzkonform und respektvoll. Keine leeren Versprechen,
                  kein Produktivitäts-Dogma.
                </p>
              </article>
              <article>
                <h3>Eigenverantwortung</h3>
                <p>
                  Du entscheidest, welche Tools zu Dir passen. Wir liefern Dir Möglichkeiten, keine
                  starren Vorgaben.
                </p>
              </article>
              <article>
                <h3>Menschenfreundliche Systeme</h3>
                <p>
                  Strukturen sollen entlasten – nicht zusätzlich Druck machen. Deshalb setzen wir auf
                  kleine Schritte und ehrliche Reflexion.
                </p>
              </article>
            </div>
          </div>
        </div>
      </section>
      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Das Team hinter Miraloventa</h2>
            <p>Wir verbinden Struktur-Expertise mit Empathie und praktischer Umsetzungsliebe.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.avatarWrapper}>
                  <img src={member.image} alt={`${member.name} – ${member.role}`} loading="lazy" />
                  <div className={styles.overlay}>
                    <p>{member.quote}</p>
                  </div>
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className={styles.disclaimer}>
        <div className="container">
          <div className={styles.disclaimerCard}>
            <h2>Wichtiger Hinweis</h2>
            <p>
              Miraloventa bietet keine psychologische oder medizinische Beratung. Unsere Inhalte ersetzen
              keine Therapie oder ärztliche Diagnose. Wenn Du Dich stark belastet fühlst, wende Dich bitte
              an professionelle Unterstützung.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;