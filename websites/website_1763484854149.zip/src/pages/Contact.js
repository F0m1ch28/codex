import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte gib Deinen Namen an.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse an.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/.test(formData.email)) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) newErrors.message = 'Was möchtest Du uns mitteilen?';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Miraloventa</title>
        <meta
          name="description"
          content="Schreib uns Dein Anliegen. Wir beantworten Deine Fragen zu Miraloventa, Tools und Programmen zügig."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">Kontakt</span>
            <h1>Deine Frage – unser Feedback.</h1>
            <p>
              Egal ob Du Dir bei einem Tool unsicher bist oder Unterstützung für Dein Team suchst: Wir
              melden uns innerhalb von zwei Werktagen.
            </p>
          </div>
        </div>
      </section>
      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Kontaktdaten</h2>
              <p>Miraloventa Plattform</p>
              <p>Platzhalterstraße 12</p>
              <p>10117 Berlin</p>
              <p>E-Mail: <a href="mailto:kontakt@miraloventa.site">kontakt@miraloventa.site</a></p>
              <p>Telefon (optional): +49 (0)30 000 000</p>
              <p className={styles.note}>
                Bitte beachte: Wir ersetzen keine medizinische oder psychologische Beratung.
              </p>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">Name*</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}

              <label htmlFor="email">E-Mail*</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}

              <label htmlFor="message">Nachricht*</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}

              <button type="submit" className="primary-btn">
                Nachricht senden
              </button>

              {submitted && (
                <div className={styles.success} role="status">
                  Danke für Deine Nachricht! Wir melden uns so schnell wie möglich bei Dir.
                </div>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;