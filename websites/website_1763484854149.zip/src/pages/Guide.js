import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Guide.module.css';

const steps = [
  {
    title: '1. Status-Check & Muster erkennen',
    description:
      'Finde heraus, wann und warum Du aufschiebst. Sammle Situationen, Gedanken und Auslöser, um Muster sichtbar zu machen.',
    bullets: [
      'Kurz-Reflexion: Was schiebe ich auf? Warum?',
      'Energie-Level tracken, um Engpässe zu erkennen',
      'Trigger-Log führen und Kategorien bilden'
    ]
  },
  {
    title: '2. Aufräumen & Priorisieren',
    description:
      'Sortiere Aufgaben nach Kontext und Relevanz. Einfache Entscheidungen sorgen dafür, dass Du weißt, was als Nächstes dran ist.',
    bullets: ['Aufgabenliste entmisten', 'Prioritäten mit 1-2-3-Regel festlegen', 'Nächste Aktion definieren']
  },
  {
    title: '3. Klare Regeln für Aufgaben & Zeit',
    description:
      'Fokus-Slots, „Wenn-dann“-Pläne und klare Deadlines schaffen Verbindlichkeit – nicht durch Druck, sondern durch Struktur.',
    bullets: [
      'Fokus-Zeiten festlegen und kommunizieren',
      '„Wenn-dann“-Plan für Störungen erstellen',
      'Zeitpuffer realistisch einplanen'
    ]
  },
  {
    title: '4. Tägliche Routinen & Review',
    description:
      'Mini-Reflexionen halten Dein System stabil. Du lernst aus jedem Tag und justierst nach, statt das System einzureißen.',
    bullets: ['Tagesstart mit Fokus-Frage', 'Abendliches Win-Log', 'Wöchentlicher Review mit Lessons Learned']
  }
];

function Guide() {
  return (
    <>
      <Helmet>
        <title>Leitfaden | Miraloventa</title>
        <meta
          name="description"
          content="Ein klarer Leitfaden in vier Schritten, der Dich von Prokrastination zu einem funktionierenden Handlungssystem führt."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">Leitfaden</span>
            <h1>Vom Aufschieben zur Umsetzung – Schritt für Schritt.</h1>
            <p>
              Unser Leitfaden führt Dich durch bewährte Schritte, damit Du Deine Aufgaben nicht mehr
              nur planst, sondern konsequent umsetzt.
            </p>
          </div>
        </div>
      </section>
      <section className={styles.steps}>
        <div className="container">
          <div className={styles.stepList}>
            {steps.map((step) => (
              <article key={step.title} className={styles.stepCard}>
                <h2>{step.title}</h2>
                <p>{step.description}</p>
                <ul>
                  {step.bullets.map((bullet) => (
                    <li key={bullet}>{bullet}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <div className={styles.cta}>
            <Link to="/programs" className="primary-btn">
              Nächsten Schritt ansehen
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Guide;