document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const links = cookieBanner.querySelectorAll(".cookie-btn");
        links.forEach((link) => {
            link.addEventListener("click", () => {
                cookieBanner.style.display = "none";
            });
        });
    }
});